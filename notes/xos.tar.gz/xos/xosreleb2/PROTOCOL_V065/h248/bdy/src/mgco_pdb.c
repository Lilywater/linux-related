/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Megaco package database file

     Type:     C source file

     Desc:     global database definition elements for Megaco packages

     File:     mgco_pdb.c

     Sid:      mgco_pdb.c@@/main/mgcp_rel_1.5_mnt/2 - Tue May 31 11:48:50 2005

     Prg:      nct

*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_mblk.h"       /* common event memory management */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_inet.h"       /* Inet header file */
#include "cm_tpt.h"        /* Transport  header file */
#include "cm_sdp.h"
#include "cm_dns.h"
#ifdef ZG
#include "cm_ftha.h"
#include "cm_psfft.h"
#endif /* ZG */
#include "mgt.h"

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_lib.x"        /* common library file */
#include "cm_inet.x"       /* Inet header file */
#include "cm_tpt.x"        /* Transport  header file */
#include "cm_sdp.x"
#ifdef ZG
#include "cm_ftha.x"
#include "cm_psfft.x"
#endif /* ZG */
#include "cm_abndb.x"
#include "cm_sdpdb.x"
#include "mgt.x"
#include "mgco_db.x"

/* added new include file under new Pkg support flags */

#if ( defined (GCP_PKG_MGCO_ANCILLARYINPUT) || \
      defined (GCP_PKG_MGCO_CALLTYPDISCR)   || \
      defined (GCP_PKG_MGCO_DISPLAY) || \
      defined (GCP_PKG_MGCO_FAX) || \
      defined (GCP_PKG_MGCO_FAXTONEDET) || \
      defined (GCP_PKG_MGCO_FUNCKEY) || \
      defined (GCP_PKG_MGCO_GENANNC) || \
      defined (GCP_PKG_MGCO_INDICATOR) || \
      defined (GCP_PKG_MGCO_IPFAX) || \
      defined (GCP_PKG_MGCO_KEY) || \
      defined (GCP_PKG_MGCO_KEYPAD) || \
      defined (GCP_PKG_MGCO_LABELKEY) || \
      defined (GCP_PKG_MGCO_SOFTKEY) || \
      defined (GCP_PKG_MGCO_TXTCNVR) || \
      defined (GCP_PKG_MGCO_TXTTELPHONE) || \
      defined (GCP_PKG_MGCO_ADVAUSRVRBASE) || \
      defined (GCP_PKG_MGCO_AASDIGCOLLECT) || \
      defined (GCP_PKG_MGCO_AASRECODING) || \
      defined (GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT) || \
      defined (GCP_PKG_MGCO_BCASADDR) || \
      defined (GCP_PKG_MGCO_INT_TNGN) || \
      defined (GCP_PKG_MGCO_OSES) || \
      defined (GCP_PKG_MGCO_OSEXT) || \
      defined (GCP_PKG_MGCO_BCAS)|| \
      defined (GCP_PKG_MGCO_BSC_CAL_TN) || \
      defined (GCP_PKG_MGCO_BSNS_TNGN) || \
      defined (GCP_PKG_MGCO_BSC_SRV_TN) || \
      defined (GCP_PKG_MGCO_XD_CALPG_TNGN) || \
      defined (GCP_PKG_MGCO_XD_SRV_TNGN) || \
      defined (GCP_PKG_MGCO_TRIG_XD_CALPG_TNGN) || \
      defined (GCP_PKG_MGCO_TRIG_FLEX_TN) || \
      defined (GCP_PKG_MGCO_RBS) || \
      defined (GCP_PKG_MGCO_TRI_GCSD) || \
      defined (GCP_PKG_MGCO_LP_BK_LTR) || \
      defined (GCP_PKG_MGCO_QT_TM_LTC) || \
      defined (GCP_PKG_MGCO_ITU_LT_404) || \
      defined (GCP_PKG_MGCO_ITU_LT_816) || \
      defined (GCP_PKG_MGCO_ITU_LT_1020) || \
      defined (GCP_PKG_MGCO_ITU_LT_ATME2) || \
      defined (GCP_PKG_MGCO_ITU_LT_2804) || \
      defined (GCP_PKG_MGCO_ITU_LT_DIST) || \
      defined (GCP_PKG_MGCO_ITU_LT_DSEC) || \
      defined (GCP_PKG_MGCO_ITU_LT_NTT) || \
      defined (GCP_PKG_MGCO_ITU_LT_DPRT) || \
      defined (GCP_PKG_MGCO_BRR_CTL_TN) || \
      defined (GCP_PKG_MGCO_ANSI_LT_TR) || \
      defined (GCP_PKG_MGCO_ANSI_LT_DTS) || \
      defined (GCP_PKG_MGCO_ANSI_LT_1004) || \
      defined (GCP_PKG_MGCO_ANSI_LT_2225) || \
      defined (GCP_PKG_MGCO_ANSI_IN_LTR) || \
      defined (GCP_PKG_MGCO_TRI_GUP) || \
      defined (GCP_PKG_MGCO_INACTTIMER) || \
      defined (GCP_PKG_MGCO_BNCT) || \
      defined (GCP_PKG_MGCO_TRI_GCTM) || \
      defined (GCP_PKG_MGCO_TRI_GMLC) || \
      defined (GCP_PKG_MGCO_RI) || \
      defined (GCP_PKG_MGCO_CHP) || \
      defined (GCP_PKG_MGCO_TRI_GTFO) || \
      defined (GCP_PKG_MGCO_TRI_GIPTRA) || \
      defined (GCP_PKG_MGCO_BRR_CHAR) || \
      defined (GCP_PKG_MGCO_OCP) || \
      defined (GCP_PKG_MGCO_FLR_CTL) || \
      defined (GCP_PKG_MGCO_IND_VIEW) || \
      defined (GCP_PKG_MGCO_VOL_CTL) || \
      defined (GCP_PKG_MGCO_VOL_DET) || \
      defined (GCP_PKG_MGCO_VOL_LEV_MIX) || \
      defined (GCP_PKG_MGCO_VOI_ACT_VID_SW) || \
      defined (GCP_PKG_MGCO_LEC_VID_MOD) || \
      defined (GCP_PKG_MGCO_CON_VID_SRC) || \
      defined (GCP_PKG_MGCO_PROF) || \
      defined (GCP_PKG_MGCO_SEM_PER) || \
      defined (GCP_PKG_MGCO_VID_WIN) || \
      defined (GCP_PKG_MGCO_TIL_WIN) || \
      defined (GCP_PKG_MGCO_EN_ALERT) || \
      defined (GCP_PKG_MGCO_SH_RISK) || \
      defined (GCP_PKG_MGCO_MIX_VOL_CTL) || \
      defined (GCP_PKG_MGCO_CAS_BLK) || \
      defined (GCP_PKG_MGCO_CONF_TN) || \
      defined (GCP_PKG_MGCO_TEST) || \
      defined (GCP_PKG_MGCO_CARR_TN) || \
      defined (GCP_PKG_MGCO_AN_DISP) || \
      defined (GCP_PKG_MGCO_EXT_ALG) || \
      defined (GCP_PKG_MGCO_AUT_MET) || \
      defined (GCP_PKG_MGCO_H_324) || \
      defined (GCP_PKG_MGCO_H_245_COM) || \
      defined (GCP_PKG_MGCO_H_245_IND) || \
      defined (GCP_PKG_MGCO_H245_COM_EXT) || \
      defined (GCP_PKG_MGCO_H245_IND_EXT) || \
      defined (GCP_PKG_MGCO_QTY_ALT) || \
      defined (GCP_PKG_MGCO_H324_EXT) || \
      defined (GCP_PKG_MGCO_AD_JIT_BUFF) || \
      defined (GCP_PKG_MGCO_ICAS) || \
      defined (GCP_PKG_MGCO_MFQ_TN_GEN) || \
      defined (GCP_PKG_MGCO_MFQ_TN_DET) || \
      defined (GCP_PKG_MGCO_EXT_DTMF) || \
      defined (GCP_PKG_MGCO_ENH_DTMF) || \
      defined (GCP_PKG_MGCO_MSF_UK_CG) || \
      defined (GCP_PKG_MGCO_MSF_UK_AN) || \
      defined (GCP_PKG_MGCO_MSF_UK_ALG) || \
      defined (GCP_PKG_MGCO_MSF_UK_AUTOMET) || \
      defined (GCP_PKG_MGCO_GAT_REC_INF) || \
      defined (GCP_PKG_MGCO_GEN_BRR_CON) )
 

#include "mgcopdb1.x"
#ifdef GCP_MGCO
#ifdef GCP_VER_1_3
#include "mgcopdb2.x"      /* [TEL]: Extern declarations for megaco packages */
#include "mgcopdb3.x"      /* [TEL2]: Extern declarations for megaco packages */
#endif /* GCP_VER_1_3 */
#endif /* GCP_MGCO */

#endif /* Big if */

#ifdef GCP_MGCO 


/************************************************************************
                     Package name values

Package                              Name      Value     Symbolic
unknown                               -          254     MGT_PKG_UNKNOWN
generic                               g            1     MGT_PKG_GENERIC
root                                 root          2     MGT_PKG_ROOT
tone generator                      tonegen        3     MGT_PKG_TONEGEN
tone detection                      tonedet        4     MGT_PKG_TONEDET
DTMF generator                        dg           5     MGT_PKG_DTMFGEN
DTMF detection                        dd           6     MGT_PKG_DTMFDET
Call progress tones generator         cg           7     MGT_PKG_CALLPROGGEN
Call progress tones detection         cd           8     MGT_PKG_CALLPROGDET
analog                                al           9     MGT_PKG_ANALOG
basic continuity                      ct          10     MGT_PKG_CONTINUITY
network                               nt          11     MGT_PKG_NETWORK
RTP                                   rtp         12     MGT_PKG_RTP
TDM circuit                          tdmc         13     MGT_PKG_TDM_CKT
all (*)                               *           14     MGT_PKG_ALL
NAS                                  nas          15     MGT_PKG_NAS
NAS Incoming                        nasin         16     MGT_PKG_NAS_IN
NAS outgoing                        nasout        17     MGT_PKG_NAS_OUT
NAS control                         nasctl        18     MGT_PKG_NAS_CTL
NAS root                            nasroot       19     MGT_PKG_NAS_ROOT

Current maximum                                  255     MGT_PKG_MAX  

************************************************************************/
/* mg004.105: Support for on/off to true/false */
#ifdef MGT_INIT_EQUALTO_FALSE

#define MGT_PKG_FALSE 0
#define MGT_PKG_TRUE  1
PUBLIC CmAbnfElmTypeEnum mgMgcoFalseDefEnum =
{
     (Data *)"false",
       MGT_PKG_FALSE
};
PUBLIC CmAbnfElmDef mgMgcoPkgFalseDef =
{
#ifdef CM_ABNF_DBG
   "False enum",
   "NULLP",
#endif
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 786,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoFalseDefEnum,
   NULLP
};



PUBLIC CmAbnfElmTypeEnum mgMgcoTrueDefEnum =
{
   (Data *)"true",
   MGT_PKG_TRUE
};
PUBLIC CmAbnfElmDef mgMgcoPkgTrueDef =
{
#ifdef CM_ABNF_DBG
   "True enum",
   "NULLP",
#endif
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 787,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoTrueDefEnum,
   NULLP
};
#endif /* MGT_INIT_EQUALTO_FALSE */

PUBLIC CmAbnfElmTypeEnum mgMgcoOffDefEnum =
{
  (Data *)"OFF",
  MGT_PKG_OFF
};
PUBLIC CmAbnfElmDef mgMgcoPkgOffDef =
{
#ifdef CM_ABNF_DBG
  "Off enum",
  "NULLP",
#endif
  CM_ABNF_ELMNID_MGCO_PKG_BASE + 786,
  sizeof(TknU8),
  0,
  CM_ABNF_TYPE_ENUM,
  (U8 *)&mgMgcoOffDefEnum,
  NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMgcoOnDefEnum =
{
  (Data *)"ON",
  MGT_PKG_ON
};
PUBLIC CmAbnfElmDef mgMgcoPkgOnDef =
{
#ifdef CM_ABNF_DBG
  "On enum",
  "NULLP",
#endif
  CM_ABNF_ELMNID_MGCO_PKG_BASE + 787,
  sizeof(TknU8),
  0,
  CM_ABNF_TYPE_ENUM,
  (U8 *)&mgMgcoOnDefEnum,
  NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameUnknownEnum =
{
   (Data *)NULLP,
   MGT_PKG_UNKNOWN
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameUnknownEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - Unknown",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameUnknownEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameGenericEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameGenericEnum =
#endif
{
   (Data *)"g",
   MGT_PKG_GENERIC
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameGenericEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - Generic",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 2,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameGenericEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameRootEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameRootEnum =
#endif
{
   (Data *)"root",
   MGT_PKG_ROOT
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameRootEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - Root",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 3,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameRootEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameToneGenEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameToneGenEnum =
#endif
{
   (Data *)"tonegen",
   MGT_PKG_TONEGEN
};

/* mg005.105: Support for Package Id U16 */
PUBLIC CmAbnfElmDef mgMgcoPkgNameToneGenEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - ToneGen",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameToneGenEnum,
   NULLP
};

/* mg005.105: Support for Package Id U16 */
#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameToneDetEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameToneDetEnum =
#endif
{
   (Data *)"tonedet",
   MGT_PKG_TONEDET
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameToneDetEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - ToneDet",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 5,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameToneDetEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameDtmfGenEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameDtmfGenEnum =
#endif
{
   (Data *)"dg",
   MGT_PKG_DTMFGEN
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameDtmfGenEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - DtmfGen",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 6,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameDtmfGenEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameDtmfDetEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameDtmfDetEnum =
#endif
{
   (Data *)"dd",
   MGT_PKG_DTMFDET
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameDtmfDetEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - DtmfDet",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 7,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameDtmfDetEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameCpGenEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameCpGenEnum =
#endif
{
   (Data *)"cg",
   MGT_PKG_CALLPROGGEN
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameCpGenEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - CpGen",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 8,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameCpGenEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameCpDetEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameCpDetEnum =
#endif
{
   (Data *)"cd",
   MGT_PKG_CALLPROGDET
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameCpDetEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - CpDet",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 9,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameCpDetEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameAnalogEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameAnalogEnum =
#endif
{
   (Data *)"al",
   MGT_PKG_ANALOG
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameAnalogEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - Analog",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 10,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameAnalogEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameContEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameContEnum =
#endif
{
   (Data *)"ct",
   MGT_PKG_CONTINUITY
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameContEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - Cont",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 11,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameContEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameNetworkEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameNetworkEnum =
#endif
{
   (Data *)"nt",
   MGT_PKG_NETWORK
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameNetworkEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - Network",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 12,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameNetworkEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameRtpEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameRtpEnum =
#endif
{
   (Data *)"rtp",
   MGT_PKG_RTP
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameRtpEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - Rtp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 13,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameRtpEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameTdmcEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameTdmcEnum =
#endif
{
   (Data *)"tdmc",
   MGT_PKG_TDM_CKT
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameTdmcEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - Tdmc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 14,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameTdmcEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameAllEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameAllEnum =
#endif
{
   (Data *)"*",
   MGT_PKG_ALL
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameAllEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - All",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 15,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameAllEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameNasEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameNasEnum =
#endif
{
   (Data *)"nas",
   MGT_PKG_NAS
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameNasEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - Nas",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 16,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameNasEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameNasInEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameNasInEnum =
#endif
{
   (Data *)"nasin",
   MGT_PKG_NAS_IN
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameNasInEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - NasIn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 17,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameNasInEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameNasOutEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameNasOutEnum =
#endif
{
   (Data *)"nasout",
   MGT_PKG_NAS_OUT
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameNasOutEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - NasOut",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 1010,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameNasOutEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameNasCtlEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameNasCtlEnum =
#endif
{
   (Data *)"nasctl",
   MGT_PKG_NAS_CTL
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameNasCtlEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - NasCtl",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 19,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameNasCtlEnum,
   NULLP
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Enum mgMgcoPkgNameNasRootEnum =
#else
PUBLIC CmAbnfElmTypeEnum mgMgcoPkgNameNasRootEnum =
#endif
{
   (Data *)"nasroot",
   MGT_PKG_NAS_ROOT
};

PUBLIC CmAbnfElmDef mgMgcoPkgNameNasRootEnumDef =
{
#ifdef CM_ABNF_DBG
   "Package enum - NasRoot",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 20,
   sizeof(TknPkgId),
   0,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_ENUM_U16,
#else
   CM_ABNF_TYPE_ENUM,
#endif
   (U8 *)&mgMgcoPkgNameNasRootEnum,
   NULLP
};

PUBLIC CmAbnfElmDef mgMgcoSkipPkgNameDef =
{
#ifdef CM_ABNF_DBG
   "Skip package name",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 21,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoGenTypeAllEnum =
{
   (Data *)"*",
   MGT_GEN_TYPE_ALL
};

PUBLIC CmAbnfElmDef mgMgcoGenTypeAllEnumDef =
{
#ifdef CM_ABNF_DBG
   "General type - All",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 22,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGenTypeAllEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoGenTypeUnknownEnum =
{
   (Data *)NULLP,
   MGT_GEN_TYPE_UNKNOWN
};

PUBLIC CmAbnfElmDef mgMgcoGenTypeUnknownEnumDef =
{
#ifdef CM_ABNF_DBG
   "General type - Unknown",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 23,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGenTypeUnknownEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoGenTypeKnownEnum =
{
   (Data *)NULLP,
   MGT_GEN_TYPE_KNOWN
};

PUBLIC CmAbnfElmDef mgMgcoGenTypeKnownEnumDef =
{
#ifdef CM_ABNF_DBG
   "General type - Known",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 24,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGenTypeKnownEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoGenTypeEnum[] =
{
   &mgMgcoGenTypeUnknownEnumDef,
   &mgMgcoGenTypeAllEnumDef,
   &mgMgcoGenTypeKnownEnumDef
};

PUBLIC CmAbnfElmTypeRange mgMgcoSkipStarDefRng = {1, 1};

PUBLIC CmAbnfElmDef mgMgcoSkipStarDef =
{
#ifdef CM_ABNF_DBG
   "Skip * in NAME",
   "Star",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 25,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   (U8 *)&mgMgcoSkipStarDefRng,
   cmAbnfRegExpStar
};

PUBLIC CmAbnfElmTypeRange mgMgcoUnknownNameDefRng = {1, 64};

PUBLIC CmAbnfElmDef mgMgcoUnknownNameDef =
{
#ifdef CM_ABNF_DBG
   "Unknown name",
   "NAME",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 26,
   sizeof(((MgMgcoName *)0)->u), /* sizeof(TknStrOSXL), */
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoUnknownNameDefRng,
   mgMgcoRegExpNAME
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecUnknownNameDefSeqElmnts[] =
{
   &mgMgcoUnknownNameDef,
   &mgMgcoEvtSecParmQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecUnknownNameDefSeq =
{
   2,
   mgMgcoEvtSecUnknownNameDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecUnknownNameDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - unknown name, known package",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 27,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecUnknownNameDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecUnknownNameDefSeqElmnts[] =
{
   &mgMgcoUnknownNameDef,
   &mgMgcoEvtSpecParmQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecUnknownNameDefSeq =
{
   2,
   mgMgcoEvSpecUnknownNameDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecUnknownNameDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - unknown name, known package",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 28,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecUnknownNameDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtUnknownNameDefSeqElmnts[] =
{
   &mgMgcoUnknownNameDef,
   &mgMgcoEvtParmQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtUnknownNameDefSeq =
{
   2,
   mgMgcoReqEvtUnknownNameDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtUnknownNameDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - unknown name, known package",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 29,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtUnknownNameDefSeq,
   NULLP
};


/* mgMgcoObsEvtUnknownNameDef def added */

PUBLIC CmAbnfElmDef *mgMgcoObsEvtUnknownNameDefSeqElmnts[] =
{
   &mgMgcoUnknownNameDef,
   &mgMgcoObsEvtParQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtUnknownNameDefSeq =
{
   2,
   mgMgcoObsEvtUnknownNameDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtUnknownNameDef =
{
#ifdef CM_ABNF_DBG
   "Obs Evt - unknown name, known package",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 29,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtUnknownNameDefSeq,
   NULLP
};



PUBLIC CmAbnfElmDef mgMgcoEvtSecSkipParLstDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - skip parmLst for *",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 30,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecSkipAllDefSeqElmnts[] =
{
   &mgMgcoSkipStarDef,
   &mgMgcoEvtSecSkipParLstDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecSkipAllDefSeq = 
{
   2,
   mgMgcoEvtSecSkipAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecSkipAllDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - skip name->u and parmLst for *",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 31,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecSkipAllDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecSkipParLstDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - skip parmLst for *", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 32,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecSkipAllDefSeqElmnts[] =
{
   &mgMgcoSkipStarDef,
   &mgMgcoEvSpecSkipParLstDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecSkipAllDefSeq =
{
   2,
   mgMgcoEvSpecSkipAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecSkipAllDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - skip name->u and parmLst for *", 
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 33,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecSkipAllDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherUnknownDefSeqElmnts[] =
{
   &mgMgcoUnknownNameDef,
   &mgMgcoParmValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherUnknownDefSeq =
{
   2,
   mgMgcoEvtOtherUnknownDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherUnknownDef =
{
#ifdef CM_ABNF_DBG
   "Unknown event parameter",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 34,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherUnknownDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef mgMgcoSkipValueDef =
{
#ifdef CM_ABNF_DBG
   "Skip value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 35,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmDef mgMgcoSkipParmValueDef =
{
#ifdef CM_ABNF_DBG
   "Skip parameter value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 36,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherSkipAllDefSeqElmnts[] =
{
   &mgMgcoSkipStarDef,
   &mgMgcoSkipParmValueDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherSkipAllDefSeq =
{
   2,
   mgMgcoEvtOtherSkipAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherSkipAllDef =
{
#ifdef CM_ABNF_DBG
   "Skip event parameter name->u + parmValue",
   "EMPTY",
#endif /* CM_ABNF_DBG */ 
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 37,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherSkipAllDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSigOtherUnknownDefSeqElmnts[] =
{
   &mgMgcoUnknownNameDef,
   &mgMgcoParmValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherUnknownDefSeq =
{
   2,
   mgMgcoSigOtherUnknownDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherUnknownDef =
{
#ifdef CM_ABNF_DBG
   "Unknown event parameter",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 38,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherUnknownDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSigOtherSkipAllDefSeqElmnts[] =
{
   &mgMgcoSkipStarDef,
   &mgMgcoSkipParmValueDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherSkipAllDefSeq =
{
   2,
   mgMgcoSigOtherSkipAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherSkipAllDef =
{
#ifdef CM_ABNF_DBG
   "Skip event parameter name->u + parmValue",
   "EMPTY",
#endif /* CM_ABNF_DBG */ 
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 39,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherSkipAllDefSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValueEnumeEnum =
{
   (Data *)NULLP,
   MGT_VALTYPE_ENUM
};

PUBLIC CmAbnfElmDef mgMgcoParmValueEnumeEnumDef =
{
#ifdef CM_ABNF_DBG
   "ParmValue type Enume",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 40,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValueEnumeEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValueDecUintEnum =
{
   (Data *)NULLP,
   MGT_VALTYPE_UINT32
};

PUBLIC CmAbnfElmDef mgMgcoParmValueDecUintEnumDef =
{
#ifdef CM_ABNF_DBG
   "ParmValue type DecUint",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 41,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValueDecUintEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValueHexUintEnum =
{
   (Data *)NULLP,
   MGT_VALTYPE_HEX_UINT32
};

PUBLIC CmAbnfElmDef mgMgcoParmValueHexUintEnumDef =
{
#ifdef CM_ABNF_DBG
   "ParmValue type HexUint",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 42,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValueHexUintEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValueStrEnum =
{
   (Data *)NULLP,
   MGT_VALTYPE_OCTSTRXL
};

PUBLIC CmAbnfElmDef mgMgcoParmValueStrEnumDef =
{
#ifdef CM_ABNF_DBG
   "ParmValue type Str",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 43,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValueStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValueTknBufEnum =
{
   (Data *)NULLP,
   MGT_VALTYPE_TKNBUF
};

PUBLIC CmAbnfElmDef mgMgcoParmValueTknBufEnumDef =
{
#ifdef CM_ABNF_DBG
   "ParmValue type TknBuf",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 44,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValueTknBufEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValueSigNameEnum =
{
   (Data *)NULLP,
   MGT_VALTYPE_SIGNAME
};

PUBLIC CmAbnfElmDef mgMgcoParmValueSigNameEnumDef =
{
#ifdef CM_ABNF_DBG
   "ParmValue type SigName",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 45,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValueSigNameEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValueSigLstEnum =
{
   (Data *)NULLP,
   MGT_VALTYPE_SIGLST
};

PUBLIC CmAbnfElmDef mgMgcoParmValueSigLstEnumDef =
{
#ifdef CM_ABNF_DBG
   "ParmValue type SigLst",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 46,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValueSigLstEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValueTermIdEnum =
{
   (Data *)NULLP,
   MGT_VALTYPE_TERMID
};

PUBLIC CmAbnfElmDef mgMgcoParmValueTermIdEnumDef =
{
#ifdef CM_ABNF_DBG
   "ParmValue type TermId",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 47,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValueTermIdEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValueTermIdLstEnum =
{
   (Data *)NULLP,
   MGT_VALTYPE_TERMIDLST
};

PUBLIC CmAbnfElmDef mgMgcoParmValueTermIdLstEnumDef =
{
#ifdef CM_ABNF_DBG
   "ParmValue type TermIdLst",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 48,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValueTermIdLstEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValueDecSintEnum =
{
   (Data *)NULLP,
   MGT_VALTYPE_SINT32
};

PUBLIC CmAbnfElmDef mgMgcoParmValueDecSintEnumDef =
{
#ifdef CM_ABNF_DBG
   "ParmValue type HexUint",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 42,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValueDecSintEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoParmValueHexSintEnum =
{
   (Data *)NULLP,
   MGT_VALTYPE_HEX_SINT32
};

PUBLIC CmAbnfElmDef mgMgcoParmValueHexSintEnumDef =
{
#ifdef CM_ABNF_DBG
   "ParmValue type HexUint",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 42,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValueHexSintEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMgcoParmValueAdvAuSegLstEnum =
{
   (Data *)NULLP,
   MGT_VALTYPE_ADV_AUD_SEGLST
};

PUBLIC CmAbnfElmDef mgMgcoParmValueAdvAuSegLstEnumDef =
{
#ifdef CM_ABNF_DBG
   "ParmValue type AnncSpec",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 42,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValueAdvAuSegLstEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum mgMgcoParmValueAdvAuProvSegSpecEnum =
{
   (Data *)NULLP,
   MGT_VALTYPE_ADV_AUD_PROVSEGSPEC
};

PUBLIC CmAbnfElmDef mgMgcoParmValueAdvAuProvSegSpecEnumDef =
{
#ifdef CM_ABNF_DBG
   "ParmValue type ProvSegSpec",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 42,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoParmValueAdvAuProvSegSpecEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoParmValueTypeEnum[] =
{
   &mgMgcoParmValueEnumeEnumDef,
   &mgMgcoParmValueDecUintEnumDef,
   &mgMgcoParmValueHexUintEnumDef,
   &mgMgcoParmValueStrEnumDef,
   &mgMgcoParmValueTknBufEnumDef,
   &mgMgcoParmValueSigNameEnumDef,
   &mgMgcoParmValueSigLstEnumDef,
   &mgMgcoParmValueTermIdEnumDef,
   &mgMgcoParmValueTermIdLstEnumDef,

   &mgMgcoParmValueDecSintEnumDef,
   &mgMgcoParmValueHexSintEnumDef,

   &mgMgcoParmValueAdvAuSegLstEnumDef,
   &mgMgcoParmValueAdvAuProvSegSpecEnumDef,
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmUnknownDefSeqElmnts[] =
{
   &mgMgcoUnknownNameDef,
   &mgMgcoParmValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmUnknownDefSeq =
{
   2,
   mgMgcoPropParmUnknownDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoPropParmUnknownDef =
{
#ifdef CM_ABNF_DBG
   "Unknown property parameter",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 49,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmUnknownDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmSkipAllDefSeqElmnts[] =
{
   &mgMgcoSkipStarDef,
   &mgMgcoSkipParmValueDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmSkipAllDefSeq =
{
   2,
   mgMgcoPropParmSkipAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoPropParmSkipAllDef =
{
#ifdef CM_ABNF_DBG
   "Skip property parameter name->u + parmValue",
   "EMPTY",
#endif /* CM_ABNF_DBG */ 
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 50,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmSkipAllDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParUnknownDefSeqElmnts[] =
{
   &mgMgcoUnknownNameDef,
   &mgMgcoOptStatsValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoStatsParUnknownDefSeq =
{
   2,
   mgMgcoStatsParUnknownDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoStatsParUnknownDef =
{
#ifdef CM_ABNF_DBG
   "Unknown statistics parameter",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 51,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoStatsParUnknownDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParSkipAllDefSeqElmnts[] =
{
   &mgMgcoSkipStarDef,
   &mgMgcoEQUALDef,
   &mgMgcoSkipValueDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoStatsParSkipAllDefSeq =
{
   3,
   mgMgcoStatsParSkipAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoStatsParSkipAllDef =
{
#ifdef CM_ABNF_DBG
   "statistics parameter - skip name->u and value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 52,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoStatsParSkipAllDefSeq,
   NULLP
};


PUBLIC CmAbnfElmDef *mgMgcoSignalUnknownDefSeqElmnts[] =
{
   &mgMgcoUnknownNameDef,
   &mgMgcoSigParQDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalUnknownDefSeq =
{
   2,
   mgMgcoSignalUnknownDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalUnknownDef =
{
#ifdef CM_ABNF_DBG
   "Unknown signal parameter",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 53,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSignalUnknownDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef mgMgcoSignalSkipParLstDef =
{
#ifdef CM_ABNF_DBG
   "Skip signal parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */ 
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 54,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSignalSkipAllDefSeqElmnts[] =
{
   &mgMgcoSkipStarDef,
   &mgMgcoSignalSkipParLstDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalSkipAllDefSeq =
{
   2,
   mgMgcoSignalSkipAllDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalSkipAllDef =
{
#ifdef CM_ABNF_DBG
   "Skip signal name->u + sigParList",
   "EMPTY",
#endif /* CM_ABNF_DBG */ 
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 55,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSignalSkipAllDefSeq,
   NULLP
};

/************************************************************************
                        Global - Tone IDs 
************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_d0Enum =
{
   (Data *)"d0",
   MGT_PKG_TONEID_D0
};

PUBLIC CmAbnfElmDef mgMgcoToneId_d0EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - d0",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 56,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_d0Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_d1Enum =
{
   (Data *)"d1",
   MGT_PKG_TONEID_D1
};

PUBLIC CmAbnfElmDef mgMgcoToneId_d1EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - d1",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 57,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_d1Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_d2Enum =
{
   (Data *)"d2",
   MGT_PKG_TONEID_D2
};

PUBLIC CmAbnfElmDef mgMgcoToneId_d2EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - d2",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 58,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_d2Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_d3Enum =
{
   (Data *)"d3",
   MGT_PKG_TONEID_D3
};

PUBLIC CmAbnfElmDef mgMgcoToneId_d3EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - d3",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 59,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_d3Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_d4Enum =
{
   (Data *)"d4",
   MGT_PKG_TONEID_D4
};

PUBLIC CmAbnfElmDef mgMgcoToneId_d4EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - d4",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 60,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_d4Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_d5Enum =
{
   (Data *)"d5",
   MGT_PKG_TONEID_D5
};

PUBLIC CmAbnfElmDef mgMgcoToneId_d5EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - d5",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 61,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_d5Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_d6Enum =
{
   (Data *)"d6",
   MGT_PKG_TONEID_D6
};

PUBLIC CmAbnfElmDef mgMgcoToneId_d6EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - d6",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 62,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_d6Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_d7Enum =
{
   (Data *)"d7",
   MGT_PKG_TONEID_D7
};

PUBLIC CmAbnfElmDef mgMgcoToneId_d7EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - d7",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 63,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_d7Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_d8Enum =
{
   (Data *)"d8",
   MGT_PKG_TONEID_D8
};

PUBLIC CmAbnfElmDef mgMgcoToneId_d8EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - d8",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 64,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_d8Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_d9Enum =
{
   (Data *)"d9",
   MGT_PKG_TONEID_D9
};

PUBLIC CmAbnfElmDef mgMgcoToneId_d9EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - d9",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 65,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_d9Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_daEnum =
{
   (Data *)"da",
   MGT_PKG_TONEID_DA
};

PUBLIC CmAbnfElmDef mgMgcoToneId_daEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - da",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 66,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_daEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_dbEnum =
{
   (Data *)"db",
   MGT_PKG_TONEID_DB
};

PUBLIC CmAbnfElmDef mgMgcoToneId_dbEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - db",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 67,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_dbEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_dcEnum =
{
   (Data *)"dc",
   MGT_PKG_TONEID_DC
};

PUBLIC CmAbnfElmDef mgMgcoToneId_dcEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - dc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 68,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_dcEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_ddEnum =
{
   (Data *)"dd",
   MGT_PKG_TONEID_DD
};

PUBLIC CmAbnfElmDef mgMgcoToneId_ddEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - dd",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 69,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_ddEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_dsEnum =
{
   (Data *)"ds",
   MGT_PKG_TONEID_DS
};

PUBLIC CmAbnfElmDef mgMgcoToneId_dsEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - ds",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 70,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_dsEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_doEnum =
{
   (Data *)"do",
   MGT_PKG_TONEID_DO
};

PUBLIC CmAbnfElmDef mgMgcoToneId_doEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - do",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 71,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_doEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_dtEnum =
{
   (Data *)"dt",
   MGT_PKG_TONEID_DT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_dtEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - dt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 72,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_dtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_rtEnum =
{
   (Data *)"rt",
   MGT_PKG_TONEID_RT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_rtEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - rt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 73,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_rtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_btEnum =
{
   (Data *)"bt",
   MGT_PKG_TONEID_BT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_btEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - bt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 74,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_btEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_ctEnum =
{
   (Data *)"ct",
   MGT_PKG_TONEID_CT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_ctEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - ct",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 75,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_ctEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_sitEnum =
{
   (Data *)"sit",
   MGT_PKG_TONEID_SIT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_sitEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - sit",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 76,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_sitEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_wtEnum =
{
   (Data *)"wt",
   MGT_PKG_TONEID_WT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_wtEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - wt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 77,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_wtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_ptEnum =
{
   (Data *)"prt",
   MGT_PKG_TONEID_PT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_ptEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - pt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 78,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_ptEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_cwEnum =
{
   (Data *)"cw",
   MGT_PKG_TONEID_CW
};

PUBLIC CmAbnfElmDef mgMgcoToneId_cwEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - cw",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 79,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_cwEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_crEnum =
{
   (Data *)"cr",
   MGT_PKG_TONEID_CR
};

PUBLIC CmAbnfElmDef mgMgcoToneId_crEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - cr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 80,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_crEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_bdtEnum =
{
   (Data *)"bdt",
   MGT_PKG_TONEID_BDT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_bdtEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - bdt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4105,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_bdtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_brtEnum =
{
   (Data *)"brt",
   MGT_PKG_TONEID_BRT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_brtEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - brt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4106,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_brtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_bbtEnum =
{
   (Data *)"bbt",
   MGT_PKG_TONEID_BBT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_bbtEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - bbt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4107,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_bbtEnum,
   NULLP
};
PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_bctEnum =
{
   (Data *)"bct",
   MGT_PKG_TONEID_BCT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_bctEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - bct",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4108,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_bctEnum,
   NULLP
};
PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_bsitEnum =
{
   (Data *)"bsit",
   MGT_PKG_TONEID_BSIT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_bsitEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - bsit",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4109,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_bsitEnum,
   NULLP
};
PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_bwtEnum =
{
   (Data *)"bwt",
   MGT_PKG_TONEID_BWT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_bwtEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - bwt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4110,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_bwtEnum,
   NULLP
};
PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_bptEnum =
{
   (Data *)"bpt",
   MGT_PKG_TONEID_BPT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_bptEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - bpt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4111,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_bptEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_bcwEnum =
{
   (Data *)"bcw",
   MGT_PKG_TONEID_BCW
};

PUBLIC CmAbnfElmDef mgMgcoToneId_bcwEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - bcw",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4112,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_bcwEnum,
   NULLP
};
PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_bcrEnum =
{
   (Data *)"bcr",
   MGT_PKG_TONEID_BCR
};
PUBLIC CmAbnfElmDef mgMgcoToneId_bcrEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - bcr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4113,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_bcrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_bpyEnum =
{
   (Data *)"bpy",
   MGT_PKG_TONEID_BPY
};

PUBLIC CmAbnfElmDef mgMgcoToneId_bpyEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - bpy",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4114,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_bpyEnum,
   NULLP
};

/*
 * [TEL2]: Definitions for new Tone Ids
 */

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_enterEnum =
{
   (Data *)"enter",
   MGT_PKG_TONEID_ENTER
};

PUBLIC CmAbnfElmDef mgMgcoToneId_enterEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - enter",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4115,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_enterEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_exitEnum =
{
   (Data *)"exit",
   MGT_PKG_TONEID_EXIT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_exitEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - exit",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4116,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_exitEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_lockEnum =
{
   (Data *)"lock",
   MGT_PKG_TONEID_LOCK
};

PUBLIC CmAbnfElmDef mgMgcoToneId_lockEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - lock",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4117,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_lockEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_unlockEnum =
{
   (Data *)"unlock",
   MGT_PKG_TONEID_UNLOCK
};

PUBLIC CmAbnfElmDef mgMgcoToneId_unlockEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - unlock",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4118,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_unlockEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_timelimEnum =
{
   (Data *)"timelim",
   MGT_PKG_TONEID_TIMELIM
};

PUBLIC CmAbnfElmDef mgMgcoToneId_timelimEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - timelim",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4119,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_timelimEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_lowEnum =
{
   (Data *)"low",
   MGT_PKG_TONEID_LOW
};

PUBLIC CmAbnfElmDef mgMgcoToneId_lowEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - low",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4120,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_lowEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_highEnum =
{
   (Data *)"high",
   MGT_PKG_TONEID_HIGH
};

PUBLIC CmAbnfElmDef mgMgcoToneId_highEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - high",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4121,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_highEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_loudEnum =
{
   (Data *)"loud",
   MGT_PKG_TONEID_LOUD
};

PUBLIC CmAbnfElmDef mgMgcoToneId_loudEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - loud",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4122,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_loudEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_faintEnum =
{
   (Data *)"faint",
   MGT_PKG_TONEID_FAINT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_faintEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - faint",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4123,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_faintEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_slowEnum =
{
   (Data *)"slow",
   MGT_PKG_TONEID_SLOW
};

PUBLIC CmAbnfElmDef mgMgcoToneId_slowEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - slow",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4124,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_slowEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_fastEnum =
{
   (Data *)"fast",
   MGT_PKG_TONEID_FAST
};

PUBLIC CmAbnfElmDef mgMgcoToneId_fastEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - fast",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4125,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_fastEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_cdtEnum =
{
   (Data *)"cdt",
   MGT_PKG_TONEID_CDT
};

PUBLIC CmAbnfElmDef mgMgcoToneId_cdtEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - cdt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4126,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_cdtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_ansEnum =
{
   (Data *)"ans",
   MGT_PKG_TONEID_ANS
};

PUBLIC CmAbnfElmDef mgMgcoToneId_ansEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - ans",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4127,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_ansEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_chgEnum =
{
   (Data *)"chg",
   MGT_PKG_TONEID_CHG
};

PUBLIC CmAbnfElmDef mgMgcoToneId_chgEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - chg",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4128,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_chgEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_ldiEnum =
{
   (Data *)"ldi",
   MGT_PKG_TONEID_LDI
};

PUBLIC CmAbnfElmDef mgMgcoToneId_ldiEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - ldi",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4129,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_ldiEnum,
   NULLP
};

/* [TEL2]: Tone Id definitions for Multi-Frequency Tone Generation Package */

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mf0Enum =
{
   (Data *)"mf0",
   MGT_PKG_TONEID_MF0
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mf0EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mf0",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4130,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mf0Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mf1Enum =
{
   (Data *)"mf1",
   MGT_PKG_TONEID_MF1
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mf1EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mf1",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4131,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mf1Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mf2Enum =
{
   (Data *)"mf2",
   MGT_PKG_TONEID_MF2
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mf2EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mf2",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4132,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mf2Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mf3Enum =
{
   (Data *)"mf3",
   MGT_PKG_TONEID_MF3
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mf3EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mf3",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4133,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mf3Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mf4Enum =
{
   (Data *)"mf4",
   MGT_PKG_TONEID_MF4
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mf4EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mf4",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4134,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mf4Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mf5Enum =
{
   (Data *)"mf5",
   MGT_PKG_TONEID_MF5
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mf5EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mf5",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4135,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mf5Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mf6Enum =
{
   (Data *)"mf6",
   MGT_PKG_TONEID_MF6
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mf6EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mf6",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4136,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mf6Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mf7Enum =
{
   (Data *)"mf7",
   MGT_PKG_TONEID_MF7
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mf7EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mf7",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4137,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mf7Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mf8Enum =
{
   (Data *)"mf8",
   MGT_PKG_TONEID_MF8
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mf8EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mf8",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4138,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mf8Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mf9Enum =
{
   (Data *)"mf9",
   MGT_PKG_TONEID_MF9
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mf9EnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mf9",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4139,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mf9Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mfaEnum =
{
   (Data *)"mfa",
   MGT_PKG_TONEID_MFA
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mfaEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mfa",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4140,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mfaEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mfbEnum =
{
   (Data *)"mfb",
   MGT_PKG_TONEID_MFB
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mfbEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mfb",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4141,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mfbEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mfcEnum =
{
   (Data *)"mfc",
   MGT_PKG_TONEID_MFC
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mfcEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mfc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4142,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mfcEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mfdEnum =
{
   (Data *)"mfd",
   MGT_PKG_TONEID_MFD
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mfdEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mfd",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4143,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mfdEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mfeEnum =
{
   (Data *)"mfe",
   MGT_PKG_TONEID_MFE
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mfeEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mfe",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4144,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mfeEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mffEnum =
{
   (Data *)"mff",
   MGT_PKG_TONEID_MFF
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mffEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mff",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4145,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mffEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mfgEnum =
{
   (Data *)"mfg",
   MGT_PKG_TONEID_MFG
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mfgEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mfg",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4146,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mfgEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_mfhEnum =
{
   (Data *)"mfh",
   MGT_PKG_TONEID_MFH
};

PUBLIC CmAbnfElmDef mgMgcoToneId_mfhEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - mfh",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4147,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_mfhEnum,
   NULLP
};

/* [TEL2]: End of addtions for Multi-Frequency Tone Generation Package */

PUBLIC CmAbnfElmTypeEnum mgMgcoToneId_allEnum =
{
   (Data *)"*",
   MGT_PKG_TONEID_ALL
};

PUBLIC CmAbnfElmDef mgMgcoToneId_allEnumDef =
{
#ifdef CM_ABNF_DBG
   "Tone ID Enum - all",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 81,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoToneId_allEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoToneIdEnum[] =
{
   /* 0x00 */     &mgMgcoToneId_allEnumDef,
   /* 0x01 */     NULLP,
   /* 0x02 */     NULLP,
   /* 0x03 */     NULLP,
   /* 0x04 */     NULLP,
   /* 0x05 */     NULLP,
   /* 0x06 */     NULLP,
   /* 0x07 */     NULLP,
   /* 0x08 */     NULLP,
   /* 0x09 */     NULLP,
   /* 0x0a */     NULLP,
   /* 0x0b */     NULLP,
   /* 0x0c */     NULLP,
   /* 0x0d */     NULLP,
   /* 0x0e */     NULLP,
   /* 0x0f */     NULLP,
   /* 0x10 */     &mgMgcoToneId_d0EnumDef,
   /* 0x11 */     &mgMgcoToneId_d1EnumDef,
   /* 0x12 */     &mgMgcoToneId_d2EnumDef,
   /* 0x13 */     &mgMgcoToneId_d3EnumDef,
   /* 0x14 */     &mgMgcoToneId_d4EnumDef,
   /* 0x15 */     &mgMgcoToneId_d5EnumDef,
   /* 0x16 */     &mgMgcoToneId_d6EnumDef,
   /* 0x17 */     &mgMgcoToneId_d7EnumDef,
   /* 0x18 */     &mgMgcoToneId_d8EnumDef,
   /* 0x19 */     &mgMgcoToneId_d9EnumDef,
   /* 0x1a */     &mgMgcoToneId_daEnumDef,
   /* 0x1b */     &mgMgcoToneId_dbEnumDef,
   /* 0x1c */     &mgMgcoToneId_dcEnumDef,
   /* 0x1d */     &mgMgcoToneId_ddEnumDef,
   /* 0x1e */     NULLP,
   /* 0x1f */     NULLP,
   /* 0x20 */     &mgMgcoToneId_dsEnumDef,
   /* 0x21 */     &mgMgcoToneId_doEnumDef,
   /* 0x22 */     NULLP,
   /* 0x23 */     NULLP,
   /* 0x24 */     NULLP,
   /* 0x25 */     NULLP,
   /* 0x26 */     NULLP,
   /* 0x27 */     NULLP,
   /* 0x28 */     NULLP,
   /* 0x29 */     NULLP,
   /* 0x2a */     NULLP,
   /* 0x2b */     NULLP,
   /* 0x2c */     NULLP,
   /* 0x2d */     NULLP,
   /* 0x2e */     NULLP,
   /* 0x2f */     NULLP,
   /* 0x30 */     &mgMgcoToneId_dtEnumDef,
   /* 0x31 */     &mgMgcoToneId_rtEnumDef,
   /* 0x32 */     &mgMgcoToneId_btEnumDef,
   /* 0x33 */     &mgMgcoToneId_ctEnumDef,
   /* 0x34 */     &mgMgcoToneId_sitEnumDef,
   /* 0x35 */     &mgMgcoToneId_wtEnumDef,
   /* 0x36 */     &mgMgcoToneId_ptEnumDef,
   /* 0x37 */     &mgMgcoToneId_cwEnumDef,
   /* 0x38 */     &mgMgcoToneId_crEnumDef,
   /* 0x39 */     NULLP,
   /* 0x3a */     NULLP,
   /* 0x3b */     NULLP,
   /* 0x3c */     NULLP,
   /* 0x3d */     NULLP,
   /* 0x3e */     NULLP,
   /* 0x3f */     NULLP,
   /* 0x40 */     &mgMgcoToneId_bdtEnumDef,
   /* 0x41 */     &mgMgcoToneId_brtEnumDef,
   /* 0x42 */     &mgMgcoToneId_bbtEnumDef,
   /* 0x43 */     &mgMgcoToneId_bctEnumDef,
   /* 0x44 */     &mgMgcoToneId_bsitEnumDef,
   /* 0x45 */     &mgMgcoToneId_bwtEnumDef,
   /* 0x46 */     &mgMgcoToneId_bptEnumDef,
   /* 0x47 */     &mgMgcoToneId_bcwEnumDef,
   /* 0x48 */     &mgMgcoToneId_bcrEnumDef,
   /* 0x49 */     &mgMgcoToneId_bpyEnumDef,
   /* 0x4a */     NULLP,
   /* 0x4b */     NULLP,
   /* 0x4c */     NULLP,
   /* 0x4d */     NULLP,
   /* 0x4e */     NULLP,
   /* 0x4f */     &mgMgcoToneId_mfhEnumDef, /* [TEL2]: Conflicting with 0x61 - TBD */
   /* 0x50 */     &mgMgcoToneId_mf0EnumDef,
   /* 0x51 */     &mgMgcoToneId_mf1EnumDef,
   /* 0x52 */     &mgMgcoToneId_mf2EnumDef,
   /* 0x53 */     &mgMgcoToneId_mf3EnumDef,
   /* 0x54 */     &mgMgcoToneId_mf4EnumDef,
   /* 0x55 */     &mgMgcoToneId_mf5EnumDef,
   /* 0x56 */     &mgMgcoToneId_mf6EnumDef,
   /* 0x57 */     &mgMgcoToneId_mf7EnumDef,
   /* 0x58 */     &mgMgcoToneId_mf8EnumDef,
   /* 0x59 */     &mgMgcoToneId_mf9EnumDef,
   /* 0x5a */     &mgMgcoToneId_mfaEnumDef,
   /* 0x5b */     &mgMgcoToneId_mfbEnumDef,
   /* 0x5c */     &mgMgcoToneId_mfcEnumDef,
   /* 0x5d */     &mgMgcoToneId_mfdEnumDef,
   /* 0x5e */     &mgMgcoToneId_mfeEnumDef,
   /* 0x5f */     &mgMgcoToneId_mffEnumDef,
   /* 0x60 */     &mgMgcoToneId_mfgEnumDef,
   /* 0x61 */     &mgMgcoToneId_enterEnumDef,
   /* 0x62 */     &mgMgcoToneId_exitEnumDef,
   /* 0x63 */     &mgMgcoToneId_lockEnumDef,
   /* 0x64 */     &mgMgcoToneId_unlockEnumDef,
   /* 0x65 */     &mgMgcoToneId_timelimEnumDef,
   /* 0x66 */     &mgMgcoToneId_lowEnumDef,
   /* 0x67 */     &mgMgcoToneId_highEnumDef,
   /* 0x68 */     &mgMgcoToneId_loudEnumDef,
   /* 0x69 */     &mgMgcoToneId_faintEnumDef,
   /* 0x6a */     &mgMgcoToneId_slowEnumDef,
   /* 0x6b */     &mgMgcoToneId_fastEnumDef,
   /* 0x6c */     &mgMgcoToneId_cdtEnumDef,
   /* 0x6d */     &mgMgcoToneId_ansEnumDef,
   /* 0x6e */     &mgMgcoToneId_chgEnumDef,
   /* 0x6f */     &mgMgcoToneId_ldiEnumDef,
};


#ifdef GCP_PKG_MGCO_GENERIC
/************************************************************************

                     Package - Generic (g) (0x0001)

************************************************************************/

/************************************************************************
                        Properties - None
************************************************************************/

/************************************************************************
                           Events
************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEventGenericCauseEnum =
{
   (Data *)"cause",
   MGT_PKG_GENERIC_EVT_CAUSE
};

PUBLIC CmAbnfElmDef mgMgcoEventGenericCauseEnumDef =
{
#ifdef CM_ABNF_DBG
   "Event enum - Generic - Cause",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 82,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventGenericCauseEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEventGenericSigComplEnum =
{
   (Data *)"sc",
   MGT_PKG_GENERIC_EVT_SIG_COMPL
};

PUBLIC CmAbnfElmDef mgMgcoEventGenericSigComplEnumDef =
{
#ifdef CM_ABNF_DBG
   "Event enum - Generic - SigCompl",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 83,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventGenericSigComplEnum,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoGenericCauseGeneralNREnum =
{
   (Data *)"NR",
   MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_NR
};

PUBLIC CmAbnfElmDef mgMgcoGenericCauseGeneralNREnumDef =
{
#ifdef CM_ABNF_DBG
   "GenericCauseGeneral - NR - Normal Release",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 84,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGenericCauseGeneralNREnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoGenericCauseGeneralUREnum =
{
   (Data *)"UR",
   MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_UR
};

PUBLIC CmAbnfElmDef mgMgcoGenericCauseGeneralUREnumDef =
{
#ifdef CM_ABNF_DBG
   "GenericCauseGeneral - UR - Unavailable resources",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 85,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGenericCauseGeneralUREnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoGenericCauseGeneralFTEnum =
{
   (Data *)"FT",
   MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_FT
};

PUBLIC CmAbnfElmDef mgMgcoGenericCauseGeneralFTEnumDef =
{
#ifdef CM_ABNF_DBG
   "GenericCauseGeneral - FT - Failure, temporary",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 86,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGenericCauseGeneralFTEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoGenericCauseGeneralFPEnum =
{
   (Data *)"FP",
   MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_FP
};

PUBLIC CmAbnfElmDef mgMgcoGenericCauseGeneralFPEnumDef =
{
#ifdef CM_ABNF_DBG
   "GenericCauseGeneral - FP - Failure, permanent",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 87,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGenericCauseGeneralFPEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoGenericCauseGeneralIWEnum =
{
   (Data *)"IW",
   MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_IW
};

PUBLIC CmAbnfElmDef mgMgcoGenericCauseGeneralIWEnumDef =
{
#ifdef CM_ABNF_DBG
   "GenericCauseGeneral - IW - Interworking error",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 88,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGenericCauseGeneralIWEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoGenericCauseGeneralUNEnum =
{
   (Data *)"UN",
   MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_UN
};

PUBLIC CmAbnfElmDef mgMgcoGenericCauseGeneralUNEnumDef =
{
#ifdef CM_ABNF_DBG
   "GenericCauseGeneral - UN - Unsupported",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 89,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGenericCauseGeneralUNEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseGeneralValueChcEnum[] =
{
   NULLP,
   &mgMgcoGenericCauseGeneralNREnumDef,
   &mgMgcoGenericCauseGeneralUREnumDef,
   &mgMgcoGenericCauseGeneralFTEnumDef,
   &mgMgcoGenericCauseGeneralFPEnumDef,
   &mgMgcoGenericCauseGeneralIWEnumDef,
   &mgMgcoGenericCauseGeneralUNEnumDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericCauseGeneralValueChc =
{
   7,
   0,
   NULLP,
   NULLP,
   mgMgcoEvtOtherGenericCauseGeneralValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseGeneralValue =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericCauseGeneralValue",
   "EvtOtherGenericCauseGeneralValue",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 90,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericCauseGeneralValueChc,
   mgMgcoRegExpEvtOtherGenericCauseGeneralValue
};

/************************************************************************/

/* NOTE: This is not a choice as such, just to indicate the type of value
 * we artificially make this a choice element, whose type (MgMgcoValue->type)
 * is always expected to be MGT_VALTYPE_ENUM. 
 * The actual causes are differentiated in MgMgcoValue->u.enume values.
 * We follow this practice for other ParmValues as well, whose types maybe
 * MGT_VALTYPE_UINT32 or MGT_VALTYPE_OCTSTRXL. The regular expression
 * (in this case mgMgcoRegExpParmValEnume) alwyas returns one particular
 * MGT_VALTYPE_ENUM while decoding. While encoding, we always expect
 * MgMgcoValue->type to be MGT_VALTYPE_ENUM.
 */

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseGeneralValDefChcElmnts[] =
{
   &mgMgcoEvtOtherGenericCauseGeneralValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericCauseGeneralValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoEvtOtherGenericCauseGeneralValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseGeneralValDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericCauseGeneralVal",
   "ParmValEnume",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 91,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericCauseGeneralValDefChc,
   mgMgcoRegExpParmValEnume
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseGeneralValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoEvtOtherGenericCauseGeneralValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseGeneralValEqDefSeq =
{
   2,
   mgMgcoEvtOtherGenericCauseGeneralValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseGeneralValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 92,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericCauseGeneralValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseGeneralValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoEvtOtherGenericCauseGeneralValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseGeneralValGtDefSeq =
{
   2,
   mgMgcoEvtOtherGenericCauseGeneralValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseGeneralValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 93,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoEvtOtherGenericCauseGeneralValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseGeneralValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoEvtOtherGenericCauseGeneralValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseGeneralValLtDefSeq =
{
   2,
   mgMgcoEvtOtherGenericCauseGeneralValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseGeneralValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 94,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericCauseGeneralValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseGeneralValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoEvtOtherGenericCauseGeneralValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseGeneralValNeDefSeq =
{
   2,
   mgMgcoEvtOtherGenericCauseGeneralValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseGeneralValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 95,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericCauseGeneralValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseGeneralValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtOtherGenericCauseGeneralValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtOtherGenericCauseGeneralValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoEvtOtherGenericCauseGeneralValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseGeneralValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 96,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtOtherGenericCauseGeneralValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseGeneralValLstDefSeqElmnts[]   =
{
   &mgMgcoEvtOtherGenericCauseGeneralValDef,
   &mgMgcoEvtOtherGenericCauseGeneralValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseGeneralValLstDefSeq =
{
   2,
   mgMgcoEvtOtherGenericCauseGeneralValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseGeneralValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 97,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtOtherGenericCauseGeneralValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseGeneralValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoEvtOtherGenericCauseGeneralValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseGeneralValAndDefSeq =
{
   4,
   mgMgcoEvtOtherGenericCauseGeneralValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseGeneralValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 98,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericCauseGeneralValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseGeneralValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoEvtOtherGenericCauseGeneralValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseGeneralValOrDefSeq =
{
   4,
   mgMgcoEvtOtherGenericCauseGeneralValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseGeneralValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 99,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericCauseGeneralValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseGeneralValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoEvtOtherGenericCauseGeneralValDef,
   &cmMsgDefMetaColon,
   &mgMgcoEvtOtherGenericCauseGeneralValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseGeneralValRngDefSeq =
{
   6,
   mgMgcoEvtOtherGenericCauseGeneralValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseGeneralValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 100,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoEvtOtherGenericCauseGeneralValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseGeneralDefChcElmnts[] =
{
   &mgMgcoEvtOtherGenericCauseGeneralValEqDef,
   &mgMgcoEvtOtherGenericCauseGeneralValGtDef,
   &mgMgcoEvtOtherGenericCauseGeneralValLtDef,
   &mgMgcoEvtOtherGenericCauseGeneralValNeDef,
   &mgMgcoEvtOtherGenericCauseGeneralValAndDef,
   &mgMgcoEvtOtherGenericCauseGeneralValOrDef,
   &mgMgcoEvtOtherGenericCauseGeneralValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericCauseGeneralDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoEvtOtherGenericCauseGeneralDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseGeneralDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericCauseGeneral",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 101,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericCauseGeneralDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeRange mgMgcoEvtOtherGenericCauseFailureValueRng =
{
   1,
   0xFFFF
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseFailureValue =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericCauseFailureValue",
   "EvtOtherGenericCauseFailureValue",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 102,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoEvtOtherGenericCauseFailureValueRng,
   mgMgcoRegExpEvtOtherGenericCauseFailureValue
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseFailureValDefChcElmnts[] =
{
   NULLP, NULLP, NULLP, 
   &mgMgcoEvtOtherGenericCauseFailureValue,
   NULLP, NULLP, NULLP, NULLP, NULLP,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericCauseFailureValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoEvtOtherGenericCauseFailureValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseFailureValDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericCauseFailureVal",
   "ParmValOctStrXL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 103,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericCauseFailureValDefChc,
   mgMgcoRegExpParmValOctStrXL
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseFailureValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoEvtOtherGenericCauseFailureValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseFailureValEqDefSeq =
{
   2,
   mgMgcoEvtOtherGenericCauseFailureValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseFailureValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 104,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericCauseFailureValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseFailureValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoEvtOtherGenericCauseFailureValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseFailureValGtDefSeq =
{
   2,
   mgMgcoEvtOtherGenericCauseFailureValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseFailureValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 105,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoEvtOtherGenericCauseFailureValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseFailureValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoEvtOtherGenericCauseFailureValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseFailureValLtDefSeq =
{
   2,
   mgMgcoEvtOtherGenericCauseFailureValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseFailureValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 106,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericCauseFailureValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseFailureValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoEvtOtherGenericCauseFailureValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseFailureValNeDefSeq =
{
   2,
   mgMgcoEvtOtherGenericCauseFailureValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseFailureValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 107,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericCauseFailureValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseFailureValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtOtherGenericCauseFailureValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtOtherGenericCauseFailureValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoEvtOtherGenericCauseFailureValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseFailureValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 108,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtOtherGenericCauseFailureValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseFailureValLstDefSeqElmnts[]   =
{
   &mgMgcoEvtOtherGenericCauseFailureValDef,
   &mgMgcoEvtOtherGenericCauseFailureValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseFailureValLstDefSeq =
{
   2,
   mgMgcoEvtOtherGenericCauseFailureValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseFailureValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 109,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtOtherGenericCauseFailureValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseFailureValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoEvtOtherGenericCauseFailureValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseFailureValAndDefSeq =
{
   4,
   mgMgcoEvtOtherGenericCauseFailureValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseFailureValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 110,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericCauseFailureValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseFailureValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoEvtOtherGenericCauseFailureValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseFailureValOrDefSeq =
{
   4,
   mgMgcoEvtOtherGenericCauseFailureValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseFailureValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 111,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericCauseFailureValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseFailureValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoEvtOtherGenericCauseFailureValDef,
   &cmMsgDefMetaColon,
   &mgMgcoEvtOtherGenericCauseFailureValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericCauseFailureValRngDefSeq =
{
   6,
   mgMgcoEvtOtherGenericCauseFailureValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseFailureValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 112,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoEvtOtherGenericCauseFailureValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseFailureDefChcElmnts[] =
{
   &mgMgcoEvtOtherGenericCauseFailureValEqDef,
   &mgMgcoEvtOtherGenericCauseFailureValGtDef,
   &mgMgcoEvtOtherGenericCauseFailureValLtDef,
   &mgMgcoEvtOtherGenericCauseFailureValNeDef,
   &mgMgcoEvtOtherGenericCauseFailureValAndDef,
   &mgMgcoEvtOtherGenericCauseFailureValOrDef,
   &mgMgcoEvtOtherGenericCauseFailureValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericCauseFailureDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoEvtOtherGenericCauseFailureDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseFailureDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericCauseFailure",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 113,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericCauseFailureDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherGenericCauseGeneralEnum =
{
   (Data *)"GeneralCause",
   MGT_PKG_GENERIC_EVT_CAUSE_GENERAL
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseGeneralEnumDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericCauseGeneralEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 114,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherGenericCauseGeneralEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherGenericCauseFailureEnum =
{
   (Data *)"FailureCause",
   MGT_PKG_GENERIC_EVT_CAUSE_FAILURE
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseFailureEnumDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericCauseFailureEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 115,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherGenericCauseFailureEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseParDefChcEnum[] =
{
   NULLP,
   &mgMgcoEvtOtherGenericCauseGeneralEnumDef,
   &mgMgcoEvtOtherGenericCauseFailureEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtOtherGenericCauseGeneralDef,
   &mgMgcoEvtOtherGenericCauseFailureDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericCauseParDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtOtherGenericCauseParDefChcElmnts,
   mgMgcoEvtOtherGenericCauseParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseParDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericCausePar",
   "EvtOtherGenericCausePar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 116,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericCauseParDefChc,
   mgMgcoRegExpEvtOtherGenericCausePar
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericCauseDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoEvtOtherGenericCauseParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericCauseDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtOtherGenericCauseDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericCauseDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericCause",
   "EvtOtherGenericCauseType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 117,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericCauseDefChc,
   mgMgcoRegExpEvtOtherGenericCauseType
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecGenericCauseParmDefChcElmnts[] =
{
   &mgMgcoEvtOtherGenericCauseDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecGenericCauseParmDefChc =
{
   5,
   6,        
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecGenericCauseParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecGenericCauseParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecGenericCause - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 118,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecGenericCauseParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecGenericCauseParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecGenericCauseParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecGenericCauseParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecGenericCauseParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecGenericCauseParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecGenericCause - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 119,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecGenericCauseParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecGenericCauseParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecGenericCauseParmDef,
   &mgMgcoEvtSecGenericCauseParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecGenericCauseParmLstDefSeq =
{
   2,
   mgMgcoEvtSecGenericCauseParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecGenericCauseParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecGenericCause - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 120,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecGenericCauseParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecGenericCauseDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecGenericCauseParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecGenericCauseDefSeq =
{
   3,
   mgMgcoEvtSecGenericCauseDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecGenericCauseDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecGenericCause - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 121,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecGenericCauseDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

#ifdef GCP_PKG_MGCO_TONEGEN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameToneGenRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalToneGenRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameToneGenRealDef =
{
#ifdef CM_ABNF_DBG
   "Real signal name - package ToneGen",
   "SigNameToneGen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 122,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameToneGenRealDefChc,
   mgMgcoRegExpSigNameToneGen
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameToneGenChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameToneGenRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameToneGenChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameToneGenChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameToneGenChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of signal names in package ToneGen",
   "PkgToneGenSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 123,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameToneGenChcDefChc,
   mgMgcoRegExpPkgToneGenSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameToneGenDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameToneGenChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameToneGenDefSeq =
{
   3,
   mgMgcoSigIdSigNameToneGenDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameToneGenDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameToneGen",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 124,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameToneGenDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_TONEGEN */

/************************************************************************/

#ifdef GCP_PKG_MGCO_DTMFGEN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameDtmfGenRealDefChc =
{
   34,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalDtmfGenRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameDtmfGenRealDef =
{
#ifdef CM_ABNF_DBG
   "Real signal name - package DtmfGen",
   "SigNameDtmfGen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 125,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameDtmfGenRealDefChc,
   mgMgcoRegExpSigNameDtmfGen
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameDtmfGenChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameDtmfGenRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameDtmfGenChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameDtmfGenChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameDtmfGenChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of signal names in package DtmfGen",
   "PkgDtmfGenSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 126,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameDtmfGenChcDefChc,
   mgMgcoRegExpPkgDtmfGenSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameDtmfGenDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameDtmfGenChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameDtmfGenDefSeq =
{
   3,
   mgMgcoSigIdSigNameDtmfGenDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameDtmfGenDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameDtmfGen",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 127,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameDtmfGenDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_DTMFGEN */

/************************************************************************/

#ifdef GCP_PKG_MGCO_CPGEN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameCpGenRealDefChc =
{
   64,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalCpGenRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameCpGenRealDef =
{
#ifdef CM_ABNF_DBG
   "Real signal name - package CpGen",
   "SigNameCpGen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 128,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameCpGenRealDefChc,
   mgMgcoRegExpSigNameCpGen
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameCpGenChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameCpGenRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameCpGenChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameCpGenChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameCpGenChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of signal names in package CpGen",
   "PkgCpGenSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 129,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameCpGenChcDefChc,
   mgMgcoRegExpPkgCpGenSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameCpGenDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameCpGenChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameCpGenDefSeq =
{
   3,
   mgMgcoSigIdSigNameCpGenDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameCpGenDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameCpGen",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 130,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameCpGenDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_CPGEN */

/************************************************************************/

#ifdef GCP_PKG_MGCO_ANALOG

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameAnalogRealDefChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalAnalogRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAnalogRealDef =
{
#ifdef CM_ABNF_DBG
   "Real signal name - package Analog",
   "SigNameAnalog",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 131,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameAnalogRealDefChc,
   mgMgcoRegExpSigNameAnalog
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameAnalogChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameAnalogRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameAnalogChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameAnalogChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAnalogChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of signal names in package Analog",
   "PkgAnalogSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 132,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameAnalogChcDefChc,
   mgMgcoRegExpPkgAnalogSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameAnalogDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameAnalogChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameAnalogDefSeq =
{
   3,
   mgMgcoSigIdSigNameAnalogDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAnalogDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameAnalog",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 133,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameAnalogDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ANALOG */

/************************************************************************/

#ifdef GCP_PKG_MGCO_CONT

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameContRealDefChc =
{
   5,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalContRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameContRealDef =
{
#ifdef CM_ABNF_DBG
   "Real signal name - package Cont",
   "SigNameCont",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 134,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameContRealDefChc,
   mgMgcoRegExpSigNameCont
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameContChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameContRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameContChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameContChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameContChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of signal names in package Cont",
   "PkgContSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 135,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameContChcDefChc,
   mgMgcoRegExpPkgContSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameContDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameContChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameContDefSeq =
{
   3,
   mgMgcoSigIdSigNameContDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameContDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameCont",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 136,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameContDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_CONT */



/************************************************************************/
/* Added new code for support of SigId SigName for new pkgs */

   /* start of additions for the new packages of rel 1.3 */

#ifdef GCP_PKG_MGCO_GENANNC

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameGenAnncRealDefChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalGenAnncValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameGenAnncRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package GenAnnc",
   "mgMgcoRegExpGenAnncSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4102,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameGenAnncRealDefChc,
   mgMgcoRegExpGenAnncSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameGenAnncChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameGenAnncRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameGenAnncChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameGenAnncChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameGenAnncChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg GenAnnc",
   "mgMgcoRegExpGenAnncSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4103,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameGenAnncChcDefChc,
   mgMgcoRegExpGenAnncSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameGenAnncDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameGenAnncChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameGenAnncDefSeq =
{
   3,
   mgMgcoSigIdSigNameGenAnncDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameGenAnncDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameGenAnnc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4104,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameGenAnncDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_GENANNC */

/******************************************************************/

#ifdef GCP_PKG_MGCO_CALLTYPDISCR

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameCallTypDiscrRealDefChc =
{
   6,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalCallTypDiscrValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameCallTypDiscrRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package CallTypDiscr",
   "mgMgcoRegExpCallTypDiscrSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4105,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameCallTypDiscrRealDefChc,
   mgMgcoRegExpCallTypDiscrSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameCallTypDiscrChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameCallTypDiscrRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameCallTypDiscrChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameCallTypDiscrChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameCallTypDiscrChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg CallTypDiscr",
   "mgMgcoRegExpCallTypDiscrSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4106,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameCallTypDiscrChcDefChc,
   mgMgcoRegExpCallTypDiscrSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameCallTypDiscrDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameCallTypDiscrChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameCallTypDiscrDefSeq =
{
   3,
   mgMgcoSigIdSigNameCallTypDiscrDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameCallTypDiscrDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameCallTypDiscr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4107,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameCallTypDiscrDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_CALLTYPDISCR */

/******************************************************************/

#ifdef GCP_PKG_MGCO_DISPLAY

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameDisplayRealDefChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalDisplayValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameDisplayRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package Display",
   "mgMgcoRegExpDisplaySig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4108,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameDisplayRealDefChc,
   mgMgcoRegExpDisplaySig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameDisplayChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameDisplayRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameDisplayChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameDisplayChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameDisplayChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg Display",
   "mgMgcoRegExpDisplaySigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4109,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameDisplayChcDefChc,
   mgMgcoRegExpDisplaySigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameDisplayDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameDisplayChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameDisplayDefSeq =
{
   3,
   mgMgcoSigIdSigNameDisplayDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameDisplayDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameDisplay",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4110,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameDisplayDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_DISPLAY */

/******************************************************************/

#ifdef GCP_PKG_MGCO_INDICATOR

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameIndicatorRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalIndicatorValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameIndicatorRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package Indicator",
   "mgMgcoRegExpIndicatorSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4111,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameIndicatorRealDefChc,
   mgMgcoRegExpIndicatorSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameIndicatorChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameIndicatorRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameIndicatorChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameIndicatorChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameIndicatorChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg Indicator",
   "mgMgcoRegExpIndicatorSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4112,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameIndicatorChcDefChc,
   mgMgcoRegExpIndicatorSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameIndicatorDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameIndicatorChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameIndicatorDefSeq =
{
   3,
   mgMgcoSigIdSigNameIndicatorDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameIndicatorDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameIndicator",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4113,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameIndicatorDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_INDICATOR */

/******************************************************************/

#ifdef GCP_PKG_MGCO_SOFTKEY

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameSoftKeyRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalSoftKeyValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameSoftKeyRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package SoftKey",
   "mgMgcoRegExpSoftKeySig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4114,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameSoftKeyRealDefChc,
   mgMgcoRegExpSoftKeySig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameSoftKeyChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameSoftKeyRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameSoftKeyChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameSoftKeyChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameSoftKeyChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg SoftKey",
   "mgMgcoRegExpSoftKeySigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4115,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameSoftKeyChcDefChc,
   mgMgcoRegExpSoftKeySigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameSoftKeyDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameSoftKeyChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameSoftKeyDefSeq =
{
   3,
   mgMgcoSigIdSigNameSoftKeyDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameSoftKeyDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameSoftKey",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4116,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameSoftKeyDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_SOFTKEY */

/******************************************************************/

#ifdef GCP_PKG_MGCO_ADVAUSRVRBASE

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameAdvAuSrvrBaseRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalAdvAuSrvrBaseValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAdvAuSrvrBaseRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package AdvAuSrvrBase",
   "mgMgcoRegExpAdvAuSrvrBaseSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4117,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameAdvAuSrvrBaseRealDefChc,
   mgMgcoRegExpAdvAuSrvrBaseSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameAdvAuSrvrBaseChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameAdvAuSrvrBaseRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameAdvAuSrvrBaseChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameAdvAuSrvrBaseChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAdvAuSrvrBaseChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg AdvAuSrvrBase",
   "mgMgcoRegExpAdvAuSrvrBaseSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4118,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameAdvAuSrvrBaseChcDefChc,
   mgMgcoRegExpAdvAuSrvrBaseSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameAdvAuSrvrBaseDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameAdvAuSrvrBaseChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameAdvAuSrvrBaseDefSeq =
{
   3,
   mgMgcoSigIdSigNameAdvAuSrvrBaseDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAdvAuSrvrBaseDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameAdvAuSrvrBase",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4119,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameAdvAuSrvrBaseDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ADVAUSRVRBASE */

/******************************************************************/

#ifdef GCP_PKG_MGCO_AASDIGCOLLECT

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameAasDigCollectRealDefChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalAasDigCollectValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAasDigCollectRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package AasDigCollect",
   "mgMgcoRegExpAasDigCollectSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4120,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameAasDigCollectRealDefChc,
   mgMgcoRegExpAasDigCollectSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameAasDigCollectChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameAasDigCollectRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameAasDigCollectChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameAasDigCollectChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAasDigCollectChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg AasDigCollect",
   "mgMgcoRegExpAasDigCollectSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4121,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameAasDigCollectChcDefChc,
   mgMgcoRegExpAasDigCollectSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameAasDigCollectDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameAasDigCollectChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameAasDigCollectDefSeq =
{
   3,
   mgMgcoSigIdSigNameAasDigCollectDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAasDigCollectDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameAasDigCollect",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4122,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameAasDigCollectDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_AASDIGCOLLECT */

/******************************************************************/

#ifdef GCP_PKG_MGCO_AASRECODING

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameAasRecodingRealDefChc =
{
   4,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalAasRecodingValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAasRecodingRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package AasRecoding",
   "mgMgcoRegExpAasRecodingSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4123,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameAasRecodingRealDefChc,
   mgMgcoRegExpAasRecodingSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameAasRecodingChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameAasRecodingRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameAasRecodingChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameAasRecodingChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAasRecodingChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg AasRecoding",
   "mgMgcoRegExpAasRecodingSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4124,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameAasRecodingChcDefChc,
   mgMgcoRegExpAasRecodingSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameAasRecodingDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameAasRecodingChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameAasRecodingDefSeq =
{
   3,
   mgMgcoSigIdSigNameAasRecodingDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAasRecodingDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameAasRecoding",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4125,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameAasRecodingDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_AASRECODING */

/******************************************************************/

#ifdef GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameAdvAuSrvrSegMngmtRealDefChc =
{
   4,
   0,
   NULLP,
   NULLP,
   mgMgcoSignalAdvAuSrvrSegMngmtValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAdvAuSrvrSegMngmtRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package AdvAuSrvrSegMngmt",
   "mgMgcoRegExpAdvAuSrvrSegMngmtSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4126,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameAdvAuSrvrSegMngmtRealDefChc,
   mgMgcoRegExpAdvAuSrvrSegMngmtSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameAdvAuSrvrSegMngmtChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigNameAdvAuSrvrSegMngmtRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameAdvAuSrvrSegMngmtChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigNameAdvAuSrvrSegMngmtChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAdvAuSrvrSegMngmtChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg AdvAuSrvrSegMngmt",
   "mgMgcoRegExpAdvAuSrvrSegMngmtSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4127,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigNameAdvAuSrvrSegMngmtChcDefChc,
   mgMgcoRegExpAdvAuSrvrSegMngmtSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameAdvAuSrvrSegMngmtDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigNameAdvAuSrvrSegMngmtChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigNameAdvAuSrvrSegMngmtDefSeq =
{
   3,
   mgMgcoSigIdSigNameAdvAuSrvrSegMngmtDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameAdvAuSrvrSegMngmtDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameAdvAuSrvrSegMngmt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4128,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigNameAdvAuSrvrSegMngmtDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT */

/*
 * [TEL]: Generic bearer connection package code added
 */
#ifdef GCP_PKG_MGCO_GEN_BRR_CON

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_gen_brr_conRealDefChc =
{
   4,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_gen_brr_conValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_gen_brr_conRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _gen_brr_con",
   "mgMgcoRegExp_gen_brr_conSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4364,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_gen_brr_conRealDefChc,
   mgMgcoRegExp_gen_brr_conSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_gen_brr_conChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_gen_brr_conRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_gen_brr_conChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_gen_brr_conChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_gen_brr_conChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _gen_brr_con",
   "mgMgcoRegExp_gen_brr_conSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4365,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_gen_brr_conChcDefChc,
   mgMgcoRegExp_gen_brr_conSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_gen_brr_conDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_gen_brr_conChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_gen_brr_conDefSeq =
{
   3,
   mgMgcoSigIdSigName_gen_brr_conDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_gen_brr_conDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_gen_brr_con",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4366,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_gen_brr_conDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_GEN_BRR_CON */

/*
 * [TEL]: Basic CAS addressing package code added
 */
#ifdef GCP_PKG_MGCO_BCASADDR

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_bcasaddrRealDefChc =
{
   6,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_bcasaddrValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bcasaddrRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _bcasaddr",
   "mgMgcoRegExp_bcasaddrSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4345,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_bcasaddrRealDefChc,
   mgMgcoRegExp_bcasaddrSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_bcasaddrChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_bcasaddrRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_bcasaddrChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_bcasaddrChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bcasaddrChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _bcasaddr",
   "mgMgcoRegExp_bcasaddrSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4346,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_bcasaddrChcDefChc,
   mgMgcoRegExp_bcasaddrSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_bcasaddrDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_bcasaddrChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_bcasaddrDefSeq =
{
   3,
   mgMgcoSigIdSigName_bcasaddrDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bcasaddrDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_bcasaddr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4347,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_bcasaddrDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_BCASADDR */

/*
 * [TEL]: Intrusion Tone Generator Package code added
 */
#ifdef GCP_PKG_MGCO_INT_TNGN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_int_tngnRealDefChc =
{
   93,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_int_tngnValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_int_tngnRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _int_tngn",
   "mgMgcoRegExp_int_tngnSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4348,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_int_tngnRealDefChc,
   mgMgcoRegExp_int_tngnSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_int_tngnChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_int_tngnRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_int_tngnChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_int_tngnChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_int_tngnChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _int_tngn",
   "mgMgcoRegExp_int_tngnSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4349,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_int_tngnChcDefChc,
   mgMgcoRegExp_int_tngnSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_int_tngnDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_int_tngnChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_int_tngnDefSeq =
{
   3,
   mgMgcoSigIdSigName_int_tngnDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_int_tngnDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_int_tngn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4350,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_int_tngnDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_INT_TNGN */

/*
 * [TEL]: Business Tonegen package code added
 */
#ifdef GCP_PKG_MGCO_BSNS_TNGN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_bsns_tngnRealDefChc =
{
   97,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_bsns_tngnValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bsns_tngnRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _bsns_tngn",
   "mgMgcoRegExp_bsns_tngnSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4430,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_bsns_tngnRealDefChc,
   mgMgcoRegExp_bsns_tngnSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_bsns_tngnChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_bsns_tngnRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_bsns_tngnChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_bsns_tngnChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bsns_tngnChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _bsns_tngn",
   "mgMgcoRegExp_bsns_tngnSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4431,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_bsns_tngnChcDefChc,
   mgMgcoRegExp_bsns_tngnSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_bsns_tngnDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_bsns_tngnChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_bsns_tngnDefSeq =
{
   3,
   mgMgcoSigIdSigName_bsns_tngnDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bsns_tngnDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_bsns_tngn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4432,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_bsns_tngnDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_BSNS_TNGN */

/*
 * [TEL]: Expanded Service Tonegen package code added
 */
#ifdef GCP_PKG_MGCO_XD_SRV_TNGN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_xd_srv_tngnRealDefChc =
{
   87,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_xd_srv_tngnValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_xd_srv_tngnRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _xd_srv_tngn",
   "mgMgcoRegExp_xd_srv_tngnSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4330,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_xd_srv_tngnRealDefChc,
   mgMgcoRegExp_xd_srv_tngnSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_xd_srv_tngnChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_xd_srv_tngnRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_xd_srv_tngnChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_xd_srv_tngnChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_xd_srv_tngnChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _xd_srv_tngn",
   "mgMgcoRegExp_xd_srv_tngnSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4331,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_xd_srv_tngnChcDefChc,
   mgMgcoRegExp_xd_srv_tngnSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_xd_srv_tngnDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_xd_srv_tngnChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_xd_srv_tngnDefSeq =
{
   3,
   mgMgcoSigIdSigName_xd_srv_tngnDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_xd_srv_tngnDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_xd_srv_tngn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4332,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_xd_srv_tngnDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_XD_SRV_TNGN */

/*
 * [TEL]: Basic Service Tonegen package code added
 */
#ifdef GCP_PKG_MGCO_BSC_SRV_TN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_bsc_srv_tnRealDefChc =
{
   83,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_bsc_srv_tnValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bsc_srv_tnRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _bsc_srv_tn",
   "mgMgcoRegExp_bsc_srv_tnSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4424,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_bsc_srv_tnRealDefChc,
   mgMgcoRegExp_bsc_srv_tnSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_bsc_srv_tnChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_bsc_srv_tnRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_bsc_srv_tnChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_bsc_srv_tnChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bsc_srv_tnChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _bsc_srv_tn",
   "mgMgcoRegExp_bsc_srv_tnSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4425,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_bsc_srv_tnChcDefChc,
   mgMgcoRegExp_bsc_srv_tnSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_bsc_srv_tnDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_bsc_srv_tnChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_bsc_srv_tnDefSeq =
{
   3,
   mgMgcoSigIdSigName_bsc_srv_tnDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bsc_srv_tnDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_bsc_srv_tn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4426,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_bsc_srv_tnDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_BSC_SRV_TN */

/*
 * [TEL]: Operator Service and Extension package code added
 */
#ifdef GCP_PKG_MGCO_OSEXT

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_osextRealDefChc =
{
   7,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_osextValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_osextRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _osext",
   "mgMgcoRegExp_osextSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4406,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_osextRealDefChc,
   mgMgcoRegExp_osextSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_osextChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_osextRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_osextChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_osextChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_osextChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _osext",
   "mgMgcoRegExp_osextSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4407,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_osextChcDefChc,
   mgMgcoRegExp_osextSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_osextDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_osextChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_osextDefSeq =
{
   3,
   mgMgcoSigIdSigName_osextDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_osextDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_osext",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4408,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_osextDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_OSEXT */

/*
 * [TEL]: Expanded Call Progress Tonegen package code added
 */
#ifdef GCP_PKG_MGCO_XD_CALPG_TNGN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_xd_calpg_tngnRealDefChc =
{
   79,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_xd_calpg_tngnValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_xd_calpg_tngnRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _xd_calpg_tngn",
   "mgMgcoRegExp_xd_calpg_tngnSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4333,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_xd_calpg_tngnRealDefChc,
   mgMgcoRegExp_xd_calpg_tngnSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_xd_calpg_tngnChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_xd_calpg_tngnRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_xd_calpg_tngnChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_xd_calpg_tngnChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_xd_calpg_tngnChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _xd_calpg_tngn",
   "mgMgcoRegExp_xd_calpg_tngnSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4334,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_xd_calpg_tngnChcDefChc,
   mgMgcoRegExp_xd_calpg_tngnSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_xd_calpg_tngnDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_xd_calpg_tngnChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_xd_calpg_tngnDefSeq =
{
   3,
   mgMgcoSigIdSigName_xd_calpg_tngnDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_xd_calpg_tngnDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_xd_calpg_tngn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4335,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_xd_calpg_tngnDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_XD_CALPG_TNGN */

/*
 * [TEL]: 3G Expanded Call Progress Tonegen package code added
 */
#ifdef GCP_PKG_MGCO_TRIG_XD_CALPG_TNGN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_trig_xd_calpg_tngnRealDefChc =
{
   80,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_trig_xd_calpg_tngnValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_trig_xd_calpg_tngnRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _trig_xd_calpg_tngn",
   "mgMgcoRegExp_trig_xd_calpg_tngnSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4342,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_trig_xd_calpg_tngnRealDefChc,
   mgMgcoRegExp_trig_xd_calpg_tngnSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_trig_xd_calpg_tngnChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_trig_xd_calpg_tngnRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_trig_xd_calpg_tngnChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_trig_xd_calpg_tngnChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_trig_xd_calpg_tngnChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _trig_xd_calpg_tngn",
   "mgMgcoRegExp_trig_xd_calpg_tngnSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4343,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_trig_xd_calpg_tngnChcDefChc,
   mgMgcoRegExp_trig_xd_calpg_tngnSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_trig_xd_calpg_tngnDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_trig_xd_calpg_tngnChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_trig_xd_calpg_tngnDefSeq =
{
   3,
   mgMgcoSigIdSigName_trig_xd_calpg_tngnDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_trig_xd_calpg_tngnDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_trig_xd_calpg_tngn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4344,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_trig_xd_calpg_tngnDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_TRIG_XD_CALPG_TNGN */

/*
 * [TEL]: Flexible Tonegen package code added
 */
#ifdef GCP_PKG_MGCO_TRIG_FLEX_TN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_trig_flex_tnRealDefChc =
{
   81,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_trig_flex_tnValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_trig_flex_tnRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _trig_flex_tn",
   "mgMgcoRegExp_trig_flex_tnSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4427,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_trig_flex_tnRealDefChc,
   mgMgcoRegExp_trig_flex_tnSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_trig_flex_tnChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_trig_flex_tnRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_trig_flex_tnChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_trig_flex_tnChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_trig_flex_tnChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _trig_flex_tn",
   "mgMgcoRegExp_trig_flex_tnSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4428,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_trig_flex_tnChcDefChc,
   mgMgcoRegExp_trig_flex_tnSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_trig_flex_tnDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_trig_flex_tnChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_trig_flex_tnDefSeq =
{
   3,
   mgMgcoSigIdSigName_trig_flex_tnDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_trig_flex_tnDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_trig_flex_tn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4429,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_trig_flex_tnDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_TRIG_FLEX_TN */

/*
 * [TEL]: Basic Call Progress Tonegen package code added
 */
#ifdef GCP_PKG_MGCO_BSC_CAL_TN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_bsc_cal_tnRealDefChc =
{
   74,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_bsc_cal_tnValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bsc_cal_tnRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _bsc_cal_tn",
   "mgMgcoRegExp_bsc_cal_tnSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4418,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_bsc_cal_tnRealDefChc,
   mgMgcoRegExp_bsc_cal_tnSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_bsc_cal_tnChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_bsc_cal_tnRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_bsc_cal_tnChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_bsc_cal_tnChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bsc_cal_tnChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _bsc_cal_tn",
   "mgMgcoRegExp_bsc_cal_tnSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4419,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_bsc_cal_tnChcDefChc,
   mgMgcoRegExp_bsc_cal_tnSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_bsc_cal_tnDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_bsc_cal_tnChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_bsc_cal_tnDefSeq =
{
   3,
   mgMgcoSigIdSigName_bsc_cal_tnDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bsc_cal_tnDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_bsc_cal_tn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4420,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_bsc_cal_tnDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_BSC_CAL_TN */

/*
 * [TEL]: ITU-T 2804 Hz tone line test package code added
 */
#ifdef GCP_PKG_MGCO_ITU_LT_2804

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_2804RealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_itu_lt_2804ValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_2804RealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _itu_lt_2804",
   "mgMgcoRegExp_itu_lt_2804Sig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4324,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_2804RealDefChc,
   mgMgcoRegExp_itu_lt_2804Sig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_2804ChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_itu_lt_2804RealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_2804ChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_itu_lt_2804ChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_2804ChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _itu_lt_2804",
   "mgMgcoRegExp_itu_lt_2804SigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4325,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_2804ChcDefChc,
   mgMgcoRegExp_itu_lt_2804SigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_2804DefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_itu_lt_2804ChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_itu_lt_2804DefSeq =
{
   3,
   mgMgcoSigIdSigName_itu_lt_2804DefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_2804Def =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_itu_lt_2804",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4326,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_2804DefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ITU_LT_2804 */

/*
 * [TEL]: ANSI 1004 Hz test tone line test package code added
 */
#ifdef GCP_PKG_MGCO_ANSI_LT_1004

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_ansi_lt_1004RealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_ansi_lt_1004ValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_lt_1004RealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _ansi_lt_1004",
   "mgMgcoRegExp_ansi_lt_1004Sig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4327,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_ansi_lt_1004RealDefChc,
   mgMgcoRegExp_ansi_lt_1004Sig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_ansi_lt_1004ChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_ansi_lt_1004RealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_ansi_lt_1004ChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_ansi_lt_1004ChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_lt_1004ChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _ansi_lt_1004",
   "mgMgcoRegExp_ansi_lt_1004SigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4328,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_ansi_lt_1004ChcDefChc,
   mgMgcoRegExp_ansi_lt_1004SigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_ansi_lt_1004DefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_ansi_lt_1004ChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_ansi_lt_1004DefSeq =
{
   3,
   mgMgcoSigIdSigName_ansi_lt_1004DefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_lt_1004Def =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_ansi_lt_1004",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4329,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_ansi_lt_1004DefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ANSI_LT_1004 */

/*
 * [TEL]: ANSI 2225 Hz test progress tone line test package code added
 */
#ifdef GCP_PKG_MGCO_ANSI_LT_2225

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_ansi_lt_2225RealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_ansi_lt_2225ValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_lt_2225RealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _ansi_lt_2225",
   "mgMgcoRegExp_ansi_lt_2225Sig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4330,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_ansi_lt_2225RealDefChc,
   mgMgcoRegExp_ansi_lt_2225Sig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_ansi_lt_2225ChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_ansi_lt_2225RealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_ansi_lt_2225ChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_ansi_lt_2225ChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_lt_2225ChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _ansi_lt_2225",
   "mgMgcoRegExp_ansi_lt_2225SigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4331,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_ansi_lt_2225ChcDefChc,
   mgMgcoRegExp_ansi_lt_2225SigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_ansi_lt_2225DefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_ansi_lt_2225ChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_ansi_lt_2225DefSeq =
{
   3,
   mgMgcoSigIdSigName_ansi_lt_2225DefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_lt_2225Def =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_ansi_lt_2225",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4332,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_ansi_lt_2225DefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ANSI_LT_2225 */

/*
 * [TEL]: ITU-T 404 Hz line test package code added
 */
#ifdef GCP_PKG_MGCO_ITU_LT_404

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_404RealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_itu_lt_404ValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_404RealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _itu_lt_404",
   "mgMgcoRegExp_itu_lt_404Sig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4333,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_404RealDefChc,
   mgMgcoRegExp_itu_lt_404Sig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_404ChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_itu_lt_404RealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_404ChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_itu_lt_404ChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_404ChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _itu_lt_404",
   "mgMgcoRegExp_itu_lt_404SigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4334,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_404ChcDefChc,
   mgMgcoRegExp_itu_lt_404SigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_404DefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_itu_lt_404ChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_itu_lt_404DefSeq =
{
   3,
   mgMgcoSigIdSigName_itu_lt_404DefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_404Def =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_itu_lt_404",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4335,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_404DefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ITU_LT_404 */

/*
 * [TEL]: ITU-T 816 Hz line test package code added
 */
#ifdef GCP_PKG_MGCO_ITU_LT_816

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_816RealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_itu_lt_816ValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_816RealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _itu_lt_816",
   "mgMgcoRegExp_itu_lt_816Sig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4336,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_816RealDefChc,
   mgMgcoRegExp_itu_lt_816Sig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_816ChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_itu_lt_816RealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_816ChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_itu_lt_816ChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_816ChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _itu_lt_816",
   "mgMgcoRegExp_itu_lt_816SigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4337,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_816ChcDefChc,
   mgMgcoRegExp_itu_lt_816SigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_816DefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_itu_lt_816ChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_itu_lt_816DefSeq =
{
   3,
   mgMgcoSigIdSigName_itu_lt_816DefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_816Def =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_itu_lt_816",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4338,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_816DefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ITU_LT_816 */

/*
 * [TEL]: ITU-T 1020 Hz line test package code added
 */
#ifdef GCP_PKG_MGCO_ITU_LT_1020

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_1020RealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_itu_lt_1020ValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_1020RealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _itu_lt_1020",
   "mgMgcoRegExp_itu_lt_1020Sig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4339,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_1020RealDefChc,
   mgMgcoRegExp_itu_lt_1020Sig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_1020ChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_itu_lt_1020RealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_1020ChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_itu_lt_1020ChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_1020ChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _itu_lt_1020",
   "mgMgcoRegExp_itu_lt_1020SigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4340,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_1020ChcDefChc,
   mgMgcoRegExp_itu_lt_1020SigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_1020DefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_itu_lt_1020ChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_itu_lt_1020DefSeq =
{
   3,
   mgMgcoSigIdSigName_itu_lt_1020DefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_1020Def =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_itu_lt_1020",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4341,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_1020DefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ITU_LT_1020 */

/*
 * [TEL]: ITU-T ATME No 2 test line response package code added 
 */
#ifdef GCP_PKG_MGCO_ITU_LT_ATME2

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_atme2RealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_itu_lt_atme2ValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_atme2RealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _itu_lt_atme2",
   "mgMgcoRegExp_itu_lt_atme2Sig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4342,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_atme2RealDefChc,
   mgMgcoRegExp_itu_lt_atme2Sig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_atme2ChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_itu_lt_atme2RealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_atme2ChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_itu_lt_atme2ChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_atme2ChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _itu_lt_atme2",
   "mgMgcoRegExp_itu_lt_atme2SigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4343,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_atme2ChcDefChc,
   mgMgcoRegExp_itu_lt_atme2SigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_atme2DefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_itu_lt_atme2ChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_itu_lt_atme2DefSeq =
{
   3,
   mgMgcoSigIdSigName_itu_lt_atme2DefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_atme2Def =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_itu_lt_atme2",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4344,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_atme2DefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ITU_LT_ATME2 */

/* 
 * [TEL]: Bearer Control Tunneling package code added
 */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_brr_ctl_tnRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_brr_ctl_tnValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_brr_ctl_tnRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _brr_ctl_tn",
   "mgMgcoRegExp_brr_ctl_tnSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4327,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_brr_ctl_tnRealDefChc,
   mgMgcoRegExp_brr_ctl_tnSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_brr_ctl_tnChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_brr_ctl_tnRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_brr_ctl_tnChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_brr_ctl_tnChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_brr_ctl_tnChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _brr_ctl_tn",
   "mgMgcoRegExp_brr_ctl_tnSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4328,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_brr_ctl_tnChcDefChc,
   mgMgcoRegExp_brr_ctl_tnSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_brr_ctl_tnDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_brr_ctl_tnChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_brr_ctl_tnDefSeq =
{
   3,
   mgMgcoSigIdSigName_brr_ctl_tnDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_brr_ctl_tnDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_brr_ctl_tn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4329,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_brr_ctl_tnDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_BRR_CTL_TN */

/*
 * [TEL]: Operator Services and Emergency services package code added
 */
#ifdef GCP_PKG_MGCO_OSES

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_osesRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_osesValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_osesRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _oses",
   "mgMgcoRegExp_osesSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4410,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_osesRealDefChc,
   mgMgcoRegExp_osesSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_osesChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_osesRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_osesChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_osesChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_osesChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _oses",
   "mgMgcoRegExp_osesSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4411,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_osesChcDefChc,
   mgMgcoRegExp_osesSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_osesDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_osesChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_osesDefSeq =
{
   3,
   mgMgcoSigIdSigName_osesDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_osesDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_oses",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4412,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_osesDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_OSES */

/*
 * [TEL]: Basic CAS package code added
 */
#ifdef GCP_PKG_MGCO_BCAS

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_bcasRealDefChc =
{
   5,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_bcasValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bcasRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _bcas",
   "mgMgcoRegExp_bcasSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 5477,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_bcasRealDefChc,
   mgMgcoRegExp_bcasSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_bcasChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_bcasRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_bcasChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_bcasChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bcasChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _bcas",
   "mgMgcoRegExp_bcasSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 5478,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_bcasChcDefChc,
   mgMgcoRegExp_bcasSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_bcasDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_bcasChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_bcasDefSeq =
{
   3,
   mgMgcoSigIdSigName_bcasDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_bcasDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_bcas",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 5479,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_bcasDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_BCAS */

/*
 * [TEL]: Robbed bit signaling package code added
 */
#ifdef GCP_PKG_MGCO_RBS

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_rbsRealDefChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_rbsValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_rbsRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _rbs",
   "mgMgcoRegExp_rbsSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4413,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_rbsRealDefChc,
   mgMgcoRegExp_rbsSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_rbsChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_rbsRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_rbsChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_rbsChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_rbsChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _rbs",
   "mgMgcoRegExp_rbsSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4414,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_rbsChcDefChc,
   mgMgcoRegExp_rbsSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_rbsDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_rbsChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_rbsDefSeq =
{
   3,
   mgMgcoSigIdSigName_rbsDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_rbsDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_rbs",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4415,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_rbsDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_RBS */

/*
 * [TEL]: Circuit switched data package code added
 */
#ifdef GCP_PKG_MGCO_TRI_GCSD

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_tri_gcsdRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_tri_gcsdValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_tri_gcsdRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _tri_gcsd",
   "mgMgcoRegExp_tri_gcsdSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4425,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_tri_gcsdRealDefChc,
   mgMgcoRegExp_tri_gcsdSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_tri_gcsdChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_tri_gcsdRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_tri_gcsdChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_tri_gcsdChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_tri_gcsdChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _tri_gcsd",
   "mgMgcoRegExp_tri_gcsdSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4426,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_tri_gcsdChcDefChc,
   mgMgcoRegExp_tri_gcsdSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_tri_gcsdDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_tri_gcsdChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_tri_gcsdDefSeq =
{
   3,
   mgMgcoSigIdSigName_tri_gcsdDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_tri_gcsdDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_tri_gcsd",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4427,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_tri_gcsdDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_TRI_GCSD */

/*
 * [TEL]: Loopback line test response package code added
 */
#ifdef GCP_PKG_MGCO_LP_BK_LTR

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_lp_bk_ltrRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_lp_bk_ltrValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_lp_bk_ltrRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _lp_bk_ltr",
   "mgMgcoRegExp_lp_bk_ltrSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4340,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_lp_bk_ltrRealDefChc,
   mgMgcoRegExp_lp_bk_ltrSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_lp_bk_ltrChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_lp_bk_ltrRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_lp_bk_ltrChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_lp_bk_ltrChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_lp_bk_ltrChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _lp_bk_ltr",
   "mgMgcoRegExp_lp_bk_ltrSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4341,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_lp_bk_ltrChcDefChc,
   mgMgcoRegExp_lp_bk_ltrSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_lp_bk_ltrDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_lp_bk_ltrChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_lp_bk_ltrDefSeq =
{
   3,
   mgMgcoSigIdSigName_lp_bk_ltrDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_lp_bk_ltrDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_lp_bk_ltr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4342,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_lp_bk_ltrDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_LP_BK_LTR */

/*
 * [TEL]: Quiet termination line test component package code added
 */
#ifdef GCP_PKG_MGCO_QT_TM_LTC

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_qt_tm_ltcRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_qt_tm_ltcValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_qt_tm_ltcRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _qt_tm_ltc",
   "mgMgcoRegExp_qt_tm_ltcSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4270,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_qt_tm_ltcRealDefChc,
   mgMgcoRegExp_qt_tm_ltcSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_qt_tm_ltcChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_qt_tm_ltcRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_qt_tm_ltcChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_qt_tm_ltcChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_qt_tm_ltcChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _qt_tm_ltc",
   "mgMgcoRegExp_qt_tm_ltcSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4271,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_qt_tm_ltcChcDefChc,
   mgMgcoRegExp_qt_tm_ltcSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_qt_tm_ltcDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_qt_tm_ltcChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_qt_tm_ltcDefSeq =
{
   3,
   mgMgcoSigIdSigName_qt_tm_ltcDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_qt_tm_ltcDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_qt_tm_ltc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4272,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_qt_tm_ltcDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_QT_TM_LTC */

/*
 * [TEL]: ITU-T 2100 Hz disable tone line test package code added
 */
#ifdef GCP_PKG_MGCO_ITU_LT_DIST

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_distRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_itu_lt_distValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_distRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _itu_lt_dist",
   "mgMgcoRegExp_itu_lt_distSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4419,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_distRealDefChc,
   mgMgcoRegExp_itu_lt_distSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_distChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_itu_lt_distRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_distChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_itu_lt_distChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_distChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _itu_lt_dist",
   "mgMgcoRegExp_itu_lt_distSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4420,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_distChcDefChc,
   mgMgcoRegExp_itu_lt_distSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_distDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_itu_lt_distChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_itu_lt_distDefSeq =
{
   3,
   mgMgcoSigIdSigName_itu_lt_distDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_distDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_itu_lt_dist",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4421,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_distDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ITU_LT_DIST */

/*
 * [TEL]: ITU-T 2100 Hz disable echo chancellor tone line test package code 
 * added
 */
#ifdef GCP_PKG_MGCO_ITU_LT_DSEC

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_dsecRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_itu_lt_dsecValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_dsecRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _itu_lt_dsec",
   "mgMgcoRegExp_itu_lt_dsecSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4422,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_dsecRealDefChc,
   mgMgcoRegExp_itu_lt_dsecSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_dsecChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_itu_lt_dsecRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_dsecChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_itu_lt_dsecChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_dsecChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _itu_lt_dsec",
   "mgMgcoRegExp_itu_lt_dsecSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4423,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_dsecChcDefChc,
   mgMgcoRegExp_itu_lt_dsecSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_dsecDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_itu_lt_dsecChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_itu_lt_dsecDefSeq =
{
   3,
   mgMgcoSigIdSigName_itu_lt_dsecDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_dsecDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_itu_lt_dsec",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4424,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_dsecDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ITU_LT_DSEC */

/*
 * [TEL]: ITU-T Noise test tone line test package code added
 */
#ifdef GCP_PKG_MGCO_ITU_LT_NTT

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_nttRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_itu_lt_nttValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_nttRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _itu_lt_ntt",
   "mgMgcoRegExp_itu_lt_nttSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4425,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_nttRealDefChc,
   mgMgcoRegExp_itu_lt_nttSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_nttChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_itu_lt_nttRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_nttChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_itu_lt_nttChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_nttChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _itu_lt_ntt",
   "mgMgcoRegExp_itu_lt_nttSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4426,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_nttChcDefChc,
   mgMgcoRegExp_itu_lt_nttSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_nttDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_itu_lt_nttChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_itu_lt_nttDefSeq =
{
   3,
   mgMgcoSigIdSigName_itu_lt_nttDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_nttDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_itu_lt_ntt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4427,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_nttDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ITU_LT_NTT */

/*
 * [TEL]: ITU-T Digital pseudo random test tone line test package code added
 */
#ifdef GCP_PKG_MGCO_ITU_LT_DPRT

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_dprtRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_itu_lt_dprtValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_dprtRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _itu_lt_dprt",
   "mgMgcoRegExp_itu_lt_dprtSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4428,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_dprtRealDefChc,
   mgMgcoRegExp_itu_lt_dprtSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_dprtChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_itu_lt_dprtRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_itu_lt_dprtChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_itu_lt_dprtChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_dprtChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _itu_lt_dprt",
   "mgMgcoRegExp_itu_lt_dprtSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4429,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_dprtChcDefChc,
   mgMgcoRegExp_itu_lt_dprtSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_itu_lt_dprtDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_itu_lt_dprtChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_itu_lt_dprtDefSeq =
{
   3,
   mgMgcoSigIdSigName_itu_lt_dprtDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_itu_lt_dprtDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_itu_lt_dprt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4430,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_itu_lt_dprtDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ITU_LT_DPRT */

/*
 * [TEL]: ANSI Test responder line test package code added
 */
#ifdef GCP_PKG_MGCO_ANSI_LT_TR

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_ansi_lt_trRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_ansi_lt_trValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_lt_trRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _ansi_lt_tr",
   "mgMgcoRegExp_ansi_lt_trSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4431,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_ansi_lt_trRealDefChc,
   mgMgcoRegExp_ansi_lt_trSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_ansi_lt_trChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_ansi_lt_trRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_ansi_lt_trChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_ansi_lt_trChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_lt_trChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _ansi_lt_tr",
   "mgMgcoRegExp_ansi_lt_trSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4432,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_ansi_lt_trChcDefChc,
   mgMgcoRegExp_ansi_lt_trSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_ansi_lt_trDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_ansi_lt_trChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_ansi_lt_trDefSeq =
{
   3,
   mgMgcoSigIdSigName_ansi_lt_trDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_lt_trDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_ansi_lt_tr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4433,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_ansi_lt_trDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ANSI_LT_TR */

/*
 * [TEL]: ANSI Digital test signal line test package code added
 */
#ifdef GCP_PKG_MGCO_ANSI_LT_DTS

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_ansi_lt_dtsRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_ansi_lt_dtsValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_lt_dtsRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _ansi_lt_dts",
   "mgMgcoRegExp_ansi_lt_dtsSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4434,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_ansi_lt_dtsRealDefChc,
   mgMgcoRegExp_ansi_lt_dtsSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_ansi_lt_dtsChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_ansi_lt_dtsRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_ansi_lt_dtsChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_ansi_lt_dtsChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_lt_dtsChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _ansi_lt_dts",
   "mgMgcoRegExp_ansi_lt_dtsSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4435,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_ansi_lt_dtsChcDefChc,
   mgMgcoRegExp_ansi_lt_dtsSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_ansi_lt_dtsDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_ansi_lt_dtsChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_ansi_lt_dtsDefSeq =
{
   3,
   mgMgcoSigIdSigName_ansi_lt_dtsDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_lt_dtsDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_ansi_lt_dts",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4436,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_ansi_lt_dtsDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ANSI_LT_DTS */

/*
 * [TEL]: ANSI Inverting loopback line test response package code added
 */
#ifdef GCP_PKG_MGCO_ANSI_IN_LTR

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_ansi_in_ltrRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_ansi_in_ltrValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_in_ltrRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _ansi_in_ltr",
   "mgMgcoRegExp_ansi_in_ltrSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4437,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_ansi_in_ltrRealDefChc,
   mgMgcoRegExp_ansi_in_ltrSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_ansi_in_ltrChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_ansi_in_ltrRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_ansi_in_ltrChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_ansi_in_ltrChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_in_ltrChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _ansi_in_ltr",
   "mgMgcoRegExp_ansi_in_ltrSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4438,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_ansi_in_ltrChcDefChc,
   mgMgcoRegExp_ansi_in_ltrSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_ansi_in_ltrDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_ansi_in_ltrChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_ansi_in_ltrDefSeq =
{
   3,
   mgMgcoSigIdSigName_ansi_in_ltrDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_ansi_in_ltrDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_ansi_in_ltr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4439,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_ansi_in_ltrDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ANSI_IN_LTR */

/*
 * [TEL2]: Indication Of Being Viewed package code added
 */
#ifdef GCP_PKG_MGCO_IND_VIEW

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Ind_ViewRealDefChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_Ind_ViewValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Ind_ViewRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _Ind_View",
   "mgMgcoRegExp_Ind_ViewSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4477,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Ind_ViewRealDefChc,
   mgMgcoRegExp_Ind_ViewSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Ind_ViewChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_Ind_ViewRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Ind_ViewChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_Ind_ViewChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Ind_ViewChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _Ind_View",
   "mgMgcoRegExp_Ind_ViewSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4478,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Ind_ViewChcDefChc,
   mgMgcoRegExp_Ind_ViewSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Ind_ViewDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_Ind_ViewChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_Ind_ViewDefSeq =
{
   3,
   mgMgcoSigIdSigName_Ind_ViewDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Ind_ViewDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_Ind_View",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4479,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_Ind_ViewDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_IND_VIEW */

/*
 * [TEL2]: Enhanced Alerting package code added
 */
#ifdef GCP_PKG_MGCO_EN_ALERT

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_En_AlertRealDefChc =
{
   4,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_En_AlertValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_En_AlertRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _En_Alert",
   "mgMgcoRegExp_En_AlertSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4439,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_En_AlertRealDefChc,
   mgMgcoRegExp_En_AlertSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_En_AlertChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_En_AlertRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_En_AlertChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_En_AlertChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_En_AlertChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _En_Alert",
   "mgMgcoRegExp_En_AlertSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4440,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_En_AlertChcDefChc,
   mgMgcoRegExp_En_AlertSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_En_AlertDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_En_AlertChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_En_AlertDefSeq =
{
   3,
   mgMgcoSigIdSigName_En_AlertDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_En_AlertDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_En_Alert",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4441,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_En_AlertDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_EN_ALERT */

/*
 * [TEL2]: CAS Blocking package code added
 */
#ifdef GCP_PKG_MGCO_CAS_BLK

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Cas_BlkRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_Cas_BlkValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Cas_BlkRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _Cas_Blk",
   "mgMgcoRegExp_Cas_BlkSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4442,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Cas_BlkRealDefChc,
   mgMgcoRegExp_Cas_BlkSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Cas_BlkChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_Cas_BlkRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Cas_BlkChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_Cas_BlkChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Cas_BlkChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _Cas_Blk",
   "mgMgcoRegExp_Cas_BlkSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4443,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Cas_BlkChcDefChc,
   mgMgcoRegExp_Cas_BlkSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Cas_BlkDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_Cas_BlkChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_Cas_BlkDefSeq =
{
   3,
   mgMgcoSigIdSigName_Cas_BlkDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Cas_BlkDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_Cas_Blk",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4444,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_Cas_BlkDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_CAS_BLK */

/*
 * [TEL2]: Conferencing Tones Generation package code added
 */
#ifdef GCP_PKG_MGCO_CONF_TN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Conf_TnRealDefChc =
{
   102,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_Conf_TnValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Conf_TnRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _Conf_Tn",
   "mgMgcoRegExp_Conf_TnSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4489,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Conf_TnRealDefChc,
   mgMgcoRegExp_Conf_TnSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Conf_TnChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_Conf_TnRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Conf_TnChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_Conf_TnChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Conf_TnChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _Conf_Tn",
   "mgMgcoRegExp_Conf_TnSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4490,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Conf_TnChcDefChc,
   mgMgcoRegExp_Conf_TnSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Conf_TnDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_Conf_TnChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_Conf_TnDefSeq =
{
   3,
   mgMgcoSigIdSigName_Conf_TnDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Conf_TnDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_Conf_Tn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4491,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_Conf_TnDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_CONF_TN */

/*
 * [TEL2]: Diagnostic Tones Generation package code added
 */
#ifdef GCP_PKG_MGCO_TEST

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_TestRealDefChc =
{
   108,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_TestValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_TestRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _Test",
   "mgMgcoRegExp_TestSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4492,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_TestRealDefChc,
   mgMgcoRegExp_TestSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_TestChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_TestRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_TestChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_TestChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_TestChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _Test",
   "mgMgcoRegExp_TestSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4493,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_TestChcDefChc,
   mgMgcoRegExp_TestSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_TestDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_TestChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_TestDefSeq =
{
   3,
   mgMgcoSigIdSigName_TestDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_TestDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_Test",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4494,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_TestDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_TEST */

/*
 * [TEL2]: Carrier Tones Generation package code added
 */
#ifdef GCP_PKG_MGCO_CARR_TN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Carr_TnRealDefChc =
{
   112,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_Carr_TnValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Carr_TnRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _Carr_Tn",
   "mgMgcoRegExp_Carr_TnSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4495,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Carr_TnRealDefChc,
   mgMgcoRegExp_Carr_TnSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Carr_TnChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_Carr_TnRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Carr_TnChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_Carr_TnChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Carr_TnChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _Carr_Tn",
   "mgMgcoRegExp_Carr_TnSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4496,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Carr_TnChcDefChc,
   mgMgcoRegExp_Carr_TnSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Carr_TnDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_Carr_TnChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_Carr_TnDefSeq =
{
   3,
   mgMgcoSigIdSigName_Carr_TnDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Carr_TnDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_Carr_Tn",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4497,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_Carr_TnDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_CARR_TN */

/*
 * [TEL2]: Analog Display Signalling package code added
 */
#ifdef GCP_PKG_MGCO_AN_DISP

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_An_DispRealDefChc =
{
   7,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_An_DispValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_An_DispRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _An_Disp",
   "mgMgcoRegExp_An_DispSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4498,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_An_DispRealDefChc,
   mgMgcoRegExp_An_DispSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_An_DispChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_An_DispRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_An_DispChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_An_DispChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_An_DispChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _An_Disp",
   "mgMgcoRegExp_An_DispSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4499,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_An_DispChcDefChc,
   mgMgcoRegExp_An_DispSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_An_DispDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_An_DispChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_An_DispDefSeq =
{
   3,
   mgMgcoSigIdSigName_An_DispDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_An_DispDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_An_Disp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4500,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_An_DispDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_AN_DISP */

/*
 * [TEL2]: Extended Analog Line Supervision package code added
 */
#ifdef GCP_PKG_MGCO_EXT_ALG

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Ext_AlgRealDefChc =
{
   5,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_Ext_AlgValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Ext_AlgRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _Ext_Alg",
   "mgMgcoRegExp_Ext_AlgSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4501,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Ext_AlgRealDefChc,
   mgMgcoRegExp_Ext_AlgSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Ext_AlgChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_Ext_AlgRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Ext_AlgChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_Ext_AlgChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Ext_AlgChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _Ext_Alg",
   "mgMgcoRegExp_Ext_AlgSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4502,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Ext_AlgChcDefChc,
   mgMgcoRegExp_Ext_AlgSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Ext_AlgDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_Ext_AlgChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_Ext_AlgDefSeq =
{
   3,
   mgMgcoSigIdSigName_Ext_AlgDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Ext_AlgDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_Ext_Alg",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4503,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_Ext_AlgDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_EXT_ALG */

/*
 * [TEL2]: Automatic Metering package code added
 */
#ifdef GCP_PKG_MGCO_AUT_MET

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Aut_MetRealDefChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_Aut_MetValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Aut_MetRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _Aut_Met",
   "mgMgcoRegExp_Aut_MetSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4504,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Aut_MetRealDefChc,
   mgMgcoRegExp_Aut_MetSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Aut_MetChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_Aut_MetRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Aut_MetChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_Aut_MetChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Aut_MetChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _Aut_Met",
   "mgMgcoRegExp_Aut_MetSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4505,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Aut_MetChcDefChc,
   mgMgcoRegExp_Aut_MetSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Aut_MetDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_Aut_MetChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_Aut_MetDefSeq =
{
   3,
   mgMgcoSigIdSigName_Aut_MetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Aut_MetDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_Aut_Met",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4506,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_Aut_MetDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO__AUT_MET */

/*
 * [TEL2]: International CAS package code added
 */
#ifdef GCP_PKG_MGCO_ICAS

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_IcasRealDefChc =
{
   10,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_IcasValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_IcasRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _Icas",
   "mgMgcoRegExp_IcasSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4608,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_IcasRealDefChc,
   mgMgcoRegExp_IcasSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_IcasChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_IcasRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_IcasChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_IcasChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_IcasChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _Icas",
   "mgMgcoRegExp_IcasSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4609,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_IcasChcDefChc,
   mgMgcoRegExp_IcasSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_IcasDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_IcasChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_IcasDefSeq =
{
   3,
   mgMgcoSigIdSigName_IcasDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_IcasDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_Icas",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4610,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_IcasDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_ICAS */

/*
 * [TEL2]: Multi-Frequency Tond Generation package code added
 */
#ifdef GCP_PKG_MGCO_MFQ_TN_GEN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_MFq_tn_genRealDefChc =
{
   98,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_MFq_tn_genValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_MFq_tn_genRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _MFq_tn_gen",
   "mgMgcoRegExp_MFq_tn_genSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4661,
   sizeof(((MgMgcoName *)0)->u),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_MFq_tn_genRealDefChc,
   mgMgcoRegExp_MFq_tn_genSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_MFq_tn_genChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_MFq_tn_genRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_MFq_tn_genChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_MFq_tn_genChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_MFq_tn_genChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _MFq_tn_gen",
   "mgMgcoRegExp_MFq_tn_genSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4662,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_MFq_tn_genChcDefChc,
   mgMgcoRegExp_MFq_tn_genSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_MFq_tn_genDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_MFq_tn_genChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_MFq_tn_genDefSeq =
{
   3,
   mgMgcoSigIdSigName_MFq_tn_genDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_MFq_tn_genDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_MFq_tn_gen",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4663,
   sizeof(MgMgcoPkgdName),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_MFq_tn_genDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_MFQ_TN_GEN */

/*
 * [TEL3]: MSF UK Call Progess Tones Generator package code added
 */
#ifdef GCP_PKG_MGCO_MSF_UK_CG

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Msf_Uk_CgRealDefChc =
{
   9,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_Msf_Uk_CgValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Msf_Uk_CgRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _Msf_Uk_Cg",
   "mgMgcoRegExp_Msf_Uk_CgSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4664,
   sizeof(((MgMgcoName *)0)->u),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Msf_Uk_CgRealDefChc,
   mgMgcoRegExp_Msf_Uk_CgSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Msf_Uk_CgChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_Msf_Uk_CgRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Msf_Uk_CgChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_Msf_Uk_CgChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Msf_Uk_CgChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _Msf_Uk_Cg",
   "mgMgcoRegExp_Msf_Uk_CgSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4665,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Msf_Uk_CgChcDefChc,
   mgMgcoRegExp_Msf_Uk_CgSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Msf_Uk_CgDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_Msf_Uk_CgChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_Msf_Uk_CgDefSeq =
{
   3,
   mgMgcoSigIdSigName_Msf_Uk_CgDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Msf_Uk_CgDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_Msf_Uk_Cg",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4666,
   sizeof(MgMgcoPkgdName),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_Msf_Uk_CgDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_MSF_UK_CG */

/*
 * [TEL3]: MSF UK Announcement package code added
 */
#ifdef GCP_PKG_MGCO_MSF_UK_AN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Msf_Uk_AnRealDefChc =
{
   11,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_Msf_Uk_AnValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Msf_Uk_AnRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _Msf_Uk_An",
   "mgMgcoRegExp_Msf_Uk_AnSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4667,
   sizeof(((MgMgcoName *)0)->u),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Msf_Uk_AnRealDefChc,
   mgMgcoRegExp_Msf_Uk_AnSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Msf_Uk_AnChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_Msf_Uk_AnRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Msf_Uk_AnChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_Msf_Uk_AnChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Msf_Uk_AnChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _Msf_Uk_An",
   "mgMgcoRegExp_Msf_Uk_AnSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4668,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Msf_Uk_AnChcDefChc,
   mgMgcoRegExp_Msf_Uk_AnSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Msf_Uk_AnDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_Msf_Uk_AnChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_Msf_Uk_AnDefSeq =
{
   3,
   mgMgcoSigIdSigName_Msf_Uk_AnDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Msf_Uk_AnDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_Msf_Uk_An",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4669,
   sizeof(MgMgcoPkgdName),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_Msf_Uk_AnDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_MSF_UK_AN */

/*
 * [TEL3]: MSF UK Analogue Line package code added
 */
#ifdef GCP_PKG_MGCO_MSF_UK_ALG

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Msf_Uk_AlgRealDefChc =
{
   7,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_Msf_Uk_AlgValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Msf_Uk_AlgRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _Msf_Uk_Alg",
   "mgMgcoRegExp_Msf_Uk_AlgSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4670,
   sizeof(((MgMgcoName *)0)->u),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Msf_Uk_AlgRealDefChc,
   mgMgcoRegExp_Msf_Uk_AlgSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Msf_Uk_AlgChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_Msf_Uk_AlgRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Msf_Uk_AlgChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_Msf_Uk_AlgChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Msf_Uk_AlgChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _Msf_Uk_Alg",
   "mgMgcoRegExp_Msf_Uk_AlgSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4671,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Msf_Uk_AlgChcDefChc,
   mgMgcoRegExp_Msf_Uk_AlgSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Msf_Uk_AlgDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_Msf_Uk_AlgChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_Msf_Uk_AlgDefSeq =
{
   3,
   mgMgcoSigIdSigName_Msf_Uk_AlgDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Msf_Uk_AlgDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_Msf_Uk_Alg",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4672,
   sizeof(MgMgcoPkgdName),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_Msf_Uk_AlgDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_MSF_UK_ALG */

/*
 * [TEL3]: MSF UK Automatic Metering package code added
 */
#ifdef GCP_PKG_MGCO_MSF_UK_AUTOMET

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Msf_Uk_AutometRealDefChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_Msf_Uk_AutometValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Msf_Uk_AutometRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _Msf_Uk_Automet",
   "mgMgcoRegExp_Msf_Uk_AutometSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4670,
   sizeof(((MgMgcoName *)0)->u),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Msf_Uk_AutometRealDefChc,
   mgMgcoRegExp_Msf_Uk_AutometSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Msf_Uk_AutometChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_Msf_Uk_AutometRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Msf_Uk_AutometChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_Msf_Uk_AutometChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Msf_Uk_AutometChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _Msf_Uk_Automet",
   "mgMgcoRegExp_Msf_Uk_AutometSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4671,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Msf_Uk_AutometChcDefChc,
   mgMgcoRegExp_Msf_Uk_AutometSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Msf_Uk_AutometDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_Msf_Uk_AutometChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_Msf_Uk_AutometDefSeq =
{
   3,
   mgMgcoSigIdSigName_Msf_Uk_AutometDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Msf_Uk_AutometDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_Msf_Uk_Automet",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 4672,
   sizeof(MgMgcoPkgdName),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_Msf_Uk_AutometDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_MSF_UK_AUTOMET */

/*
 * [TEL3]: Stimulus Lines Analogue Package code added
 */

#ifdef GCP_PKG_MGCO_STIM_AL
PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Stim_AlRealDefChc =
{
   6,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_Stim_AlValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Stim_AlRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _Stim_Al",
   "mgMgcoRegExp_Stim_AlSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 5113,
   sizeof(((MgMgcoName *)0)->u),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Stim_AlRealDefChc,
   mgMgcoRegExp_Stim_AlSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Stim_AlChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_Stim_AlRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_Stim_AlChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_Stim_AlChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Stim_AlChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _Stim_Al",
   "mgMgcoRegExp_Stim_AlSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 5114,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_Stim_AlChcDefChc,
   mgMgcoRegExp_Stim_AlSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_Stim_AlDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_Stim_AlChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_Stim_AlDefSeq =
{
   3,
   mgMgcoSigIdSigName_Stim_AlDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_Stim_AlDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_Stim_Al",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 5115,
   sizeof(MgMgcoPkgdName),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_Stim_AlDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_STIM_AL */

/*
 * Enhanced Circuit Switched Data Package code added
 */

#ifdef GCP_PKG_MGCO_TRI_GCSDEN

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_tri_gcsdenRealDefChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoSignal_tri_gcsdenValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_tri_gcsdenRealDef =
{
#ifdef CM_ABNF_DBG
   "Real Signal Name - package _tri_gcsden",
   "mgMgcoRegExp_tri_gcsdenSig",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 5153,
   sizeof(((MgMgcoName *)0)->u),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_tri_gcsdenRealDefChc,
   mgMgcoRegExp_tri_gcsdenSig
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_tri_gcsdenChcDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoSigIdSigName_tri_gcsdenRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigName_tri_gcsdenChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigIdSigName_tri_gcsdenChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_tri_gcsdenChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of Signal Names in pkg _tri_gcsden",
   "mgMgcoRegExp_tri_gcsdenSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 5154,
   sizeof(MgMgcoName),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigIdSigName_tri_gcsdenChcDefChc,
   mgMgcoRegExp_tri_gcsdenSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigName_tri_gcsdenDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSigIdSigName_tri_gcsdenChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigIdSigName_tri_gcsdenDefSeq =
{
   3,
   mgMgcoSigIdSigName_tri_gcsdenDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigName_tri_gcsdenDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigName_tri_gcsden",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 5155,
   sizeof(MgMgcoPkgdName),
   CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigIdSigName_tri_gcsdenDefSeq,
   NULLP
};

#endif /* GCP_PKG_MGCO_TRI_GCSDEN */


/* end of additions */

/************************************************************************/




/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoSigIdSigNameKnownPkgDefChcElmnts[] =
{
   NULLP,   /* Unknown package */
   NULLP,   /* GCP_PKG_MGCO_GENERIC */
   NULLP,   /* GCP_PKG_MGCO_ROOT */
#ifdef GCP_PKG_MGCO_TONEGEN
   &mgMgcoSigIdSigNameToneGenDef,
#else /* !GCP_PKG_MGCO_TONEGEN */
   NULLP,
#endif /* GCP_PKG_MGCO_TONEGEN */
   NULLP,   /* GCP_PKG_MGCO_TONEDET */
#ifdef GCP_PKG_MGCO_DTMFGEN
   &mgMgcoSigIdSigNameDtmfGenDef,
#else /* !GCP_PKG_MGCO_DTMFGEN */
   NULLP,
#endif /* GCP_PKG_MGCO_DTMFGEN */
   NULLP,   /* GCP_PKG_MGCO_DTMFDET */
#ifdef GCP_PKG_MGCO_CPGEN
   &mgMgcoSigIdSigNameCpGenDef,
#else /* !GCP_PKG_MGCO_CPGEN */
   NULLP,
#endif /* GCP_PKG_MGCO_CPGEN */
   NULLP,   /* GCP_PKG_MGCO_CPDET */
#ifdef GCP_PKG_MGCO_ANALOG
   &mgMgcoSigIdSigNameAnalogDef,
#else /* !GCP_PKG_MGCO_ANALOG */
   NULLP,
#endif /* GCP_PKG_MGCO_ANALOG */
#ifdef GCP_PKG_MGCO_CONT
   &mgMgcoSigIdSigNameContDef,
#else /* !GCP_PKG_MGCO_CONT */
   NULLP,
#endif /* GCP_PKG_MGCO_CONT */
   NULLP,   /* GCP_PKG_MGCO_NETWORK */
   NULLP,   /* GCP_PKG_MGCO_RTP */
   NULLP,   /* GCP_PKG_MGCO_TDMC */

   /* 
    *            Added new pkg support under flag as explained below -
    *            If any of the new Pkg support flags is defined, it =>s
    *            that the new database defs should be used. Otherwise.
    *            use the old database defs.
    */

#if ( defined (GCP_PKG_MGCO_ANCILLARYINPUT) || \
      defined (GCP_PKG_MGCO_CALLTYPDISCR)   || \
      defined (GCP_PKG_MGCO_DISPLAY) || \
      defined (GCP_PKG_MGCO_FAX) || \
      defined (GCP_PKG_MGCO_FAXTONEDET) || \
      defined (GCP_PKG_MGCO_FUNCKEY) || \
      defined (GCP_PKG_MGCO_GENANNC) || \
      defined (GCP_PKG_MGCO_INDICATOR) || \
      defined (GCP_PKG_MGCO_IPFAX) || \
      defined (GCP_PKG_MGCO_KEY) || \
      defined (GCP_PKG_MGCO_KEYPAD) || \
      defined (GCP_PKG_MGCO_LABELKEY) || \
      defined (GCP_PKG_MGCO_SOFTKEY) || \
      defined (GCP_PKG_MGCO_TXTCNVR) || \
      defined (GCP_PKG_MGCO_TXTTELPHONE) || \
      defined (GCP_PKG_MGCO_ADVAUSRVRBASE) || \
      defined (GCP_PKG_MGCO_AASDIGCOLLECT) || \
      defined (GCP_PKG_MGCO_AASRECODING) || \
      defined (GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT) || \
      defined (GCP_PKG_MGCO_BCASADDR) || \
      defined (GCP_PKG_MGCO_INT_TNGN) || \
      defined (GCP_PKG_MGCO_OSES) || \
      defined (GCP_PKG_MGCO_OSEXT) || \
      defined (GCP_PKG_MGCO_BCAS) || \
      defined (GCP_PKG_MGCO_RBS) || \
      defined (GCP_PKG_MGCO_XD_SRV_TNGN) || \
      defined (GCP_PKG_MGCO_BSC_SRV_TN) || \
      defined (GCP_PKG_MGCO_BSNS_TNGN) || \
      defined (GCP_PKG_MGCO_BSC_CAL_TN) || \
      defined (GCP_PKG_MGCO_XD_CALPG_TNGN) || \
      defined (GCP_PKG_MGCO_TRIG_XD_CALPG_TNGN) || \
      defined (GCP_PKG_MGCO_TRIG_FLEX_TN) || \
      defined (GCP_PKG_MGCO_TRI_GCSD) || \
      defined (GCP_PKG_MGCO_LP_BK_LTR) || \
      defined (GCP_PKG_MGCO_QT_TM_LTC) || \
      defined (GCP_PKG_MGCO_ITU_LT_404) || \
      defined (GCP_PKG_MGCO_ITU_LT_816) || \
      defined (GCP_PKG_MGCO_ITU_LT_1020) || \
      defined (GCP_PKG_MGCO_ITU_LT_ATME2) || \
      defined (GCP_PKG_MGCO_ITU_LT_2804) || \
      defined (GCP_PKG_MGCO_ITU_LT_DIST) || \
      defined (GCP_PKG_MGCO_ITU_LT_DSEC) || \
      defined (GCP_PKG_MGCO_ITU_LT_NTT) || \
      defined (GCP_PKG_MGCO_ITU_LT_DPRT) || \
      defined (GCP_PKG_MGCO_BRR_CTL_TN) || \
      defined (GCP_PKG_MGCO_ANSI_LT_TR) || \
      defined (GCP_PKG_MGCO_ANSI_LT_DTS) || \
      defined (GCP_PKG_MGCO_ANSI_LT_1004) || \
      defined (GCP_PKG_MGCO_ANSI_LT_2225) || \
      defined (GCP_PKG_MGCO_ANSI_IN_LTR) || \
      defined (GCP_PKG_MGCO_IND_VIEW) || \
      defined (GCP_PKG_MGCO_EN_ALERT) || \
      defined (GCP_PKG_MGCO_CAS_BLK) || \
      defined (GCP_PKG_MGCO_CONF_TN) || \
      defined (GCP_PKG_MGCO_TEST) || \
      defined (GCP_PKG_MGCO_CARR_TN) || \
      defined (GCP_PKG_MGCO_AN_DISP) || \
      defined (GCP_PKG_MGCO_EXT_ALG) || \
      defined (GCP_PKG_MGCO_AUT_MET) || \
      defined (GCP_PKG_MGCO_ICAS) || \
      defined (GCP_PKG_MGCO_MFQ_TN_GEN) || \
      defined (GCP_PKG_MGCO_MSF_UK_CG) || \
      defined (GCP_PKG_MGCO_MSF_UK_AN) || \
      defined (GCP_PKG_MGCO_MSF_UK_ALG) || \
      defined (GCP_PKG_MGCO_MSF_UK_AUTOMET) || \
      defined (GCP_PKG_MGCO_TRI_GCSDEN) || \
      defined (GCP_PKG_MGCO_GEN_BRR_CON) ) 


   /*****************************************************************/
   /* start of additions for the new packages of rel 1.3 */

   NULLP,   /* GCP_PKG_MGCO_FAXTONEDET       package ID 14 */
   NULLP,   /* GCP_PKG_MGCO_TXTCNVR          package ID 15 */
   NULLP,   /* GCP_PKG_MGCO_TXTTELPHONE      package ID 16 */

#ifdef GCP_PKG_MGCO_CALLTYPDISCR
   &mgMgcoSigIdSigNameCallTypDiscrDef,    /* package ID 17 */
#else /* !GCP_PKG_MGCO_CALLTYPDISCR */
   NULLP,
#endif /* GCP_PKG_MGCO_CALLTYPDISCR */

   NULLP,   /* GCP_PKG_MGCO_FAX              package ID 18 */
   NULLP,   /* GCP_PKG_MGCO_IPFAX            package ID 19 */

#ifdef GCP_PKG_MGCO_DISPLAY
   &mgMgcoSigIdSigNameDisplayDef,         /* package ID 20 */
#else /* !GCP_PKG_MGCO_DISPLAY */
   NULLP,
#endif /* GCP_PKG_MGCO_DISPLAY */

   NULLP,   /* GCP_PKG_MGCO_KEY              package ID 21 */
   NULLP,   /* GCP_PKG_MGCO_KEYPAD           package ID 22 */
   NULLP,   /* GCP_PKG_MGCO_LABELKEY         package ID 23 */
   NULLP,   /* GCP_PKG_MGCO_FUNCKEY          package ID 24 */

#ifdef GCP_PKG_MGCO_INDICATOR
   &mgMgcoSigIdSigNameIndicatorDef,       /* package ID 25 */
#else /* !GCP_PKG_MGCO_INDICATOR */
   NULLP,
#endif /* GCP_PKG_MGCO_INDICATOR */

#ifdef GCP_PKG_MGCO_SOFTKEY
   &mgMgcoSigIdSigNameSoftKeyDef,         /* package ID 26 */
#else /* !GCP_PKG_MGCO_SOFTKEY */
   NULLP,
#endif /* GCP_PKG_MGCO_SOFTKEY */

   NULLP,   /* GCP_PKG_MGCO_ANCILLARYINPUT   package ID 27 */

            /* ------ package IDs 28-32 ------ */
   NULLP,             /* package ID 28 */
#ifdef GCP_PKG_MGCO_GENANNC
   &mgMgcoSigIdSigNameGenAnncDef,         /* package ID 29 */
#else /* !GCP_PKG_MGCO_GENANNC */
   NULLP,
#endif /* GCP_PKG_MGCO_GENANNC */

   NULLP, NULLP, NULLP,               /* package Ids 30 - 32 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_GEN_BRR_CON           /* package ID 33 */ 
   &mgMgcoSigIdSigName_gen_brr_conDef,
#else /* !GCP_PKG_MGCO_GEN_BRR_CON */
   NULLP,
#endif /* GCP_PKG_MGCO_GEN_BRR_CON */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BRR_CTL_TN            /* package ID 34 */
   &mgMgcoSigIdSigName_brr_ctl_tnDef,
#else /* !GCP_PKG_MGCO_BRR_CTL_TN */
   NULLP,
#endif /* GCP_PKG_MGCO_BRR_CTL_TN */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BSC_CAL_TN            /* package ID 35 */
   &mgMgcoSigIdSigName_bsc_cal_tnDef,
#else /* !GCP_PKG_MGCO_BSC_CAL_TN */
   NULLP,
#endif /* GCP_PKG_MGCO_BSC_CAL_TN */


   /* end of additions */
   /*****************************************************************/

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_XD_CALPG_TNGN         /* package ID 36 */
   &mgMgcoSigIdSigName_xd_calpg_tngnDef,
#else /* !GCP_PKG_MGCO_XD_CALPG_TNGN */
   NULLP,
#endif /* GCP_PKG_MGCO_XD_CALPG_TNGN */   

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BSC_SRV_TN            /* package ID 37 */
    &mgMgcoSigIdSigName_bsc_srv_tnDef,
#else /* !GCP_PKG_MGCO_BSC_SRV_TN */
    NULLP,
#endif /* GCP_PKG_MGCO_BSC_SRV_TN */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_XD_SRV_TNGN           /* package ID 38 */
   &mgMgcoSigIdSigName_xd_srv_tngnDef,
#else /* !GCP_PKG_MGCO_XD_SRV_TNGN */
   NULLP,
#endif /* GCP_PKG_MGCO_XD_SRV_TNGN */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_INT_TNGN              /* package ID 39 */
   &mgMgcoSigIdSigName_int_tngnDef,
#else /* !GCP_PKG_MGCO_INT_TNGN */
   NULLP,
#endif /* GCP_PKG_MGCO_INT_TNGN */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BSNS_TNGN             /* package ID 40 */
   &mgMgcoSigIdSigName_bsns_tngnDef,
#else /* !GCP_PKG_MGCO_BSNS_TNGN */
   NULLP,
#endif /* GCP_PKG_MGCO_BSNS_TNGN */

   NULLP,                                 /* package ID 41 */

   /*****************************************************************/
   /* start of additions for the new packages of rel 1.3 */

            /* ------ package IDs 42-47 ------ */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRI_GCSD              /* package ID 48 */
   &mgMgcoSigIdSigName_tri_gcsdDef,
#else /* !GCP_PKG_MGCO_TRI_GCSD */
   NULLP,
#endif /* GCP_PKG_MGCO_TRI_GCSD */

   NULLP,                                 /* package ID 49 */
   
   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRIG_XD_CALPG_TNGN    /* package ID 50 */
   &mgMgcoSigIdSigName_trig_xd_calpg_tngnDef,
#else /* !GCP_PKG_MGCO_TRIG_XD_CALPG_TNGN */
   NULLP,
#endif /* GCP_PKG_MGCO_TRIG_XD_CALPG_TNGN */

#ifdef GCP_PKG_MGCO_ADVAUSRVRBASE
   &mgMgcoSigIdSigNameAdvAuSrvrBaseDef,   /* package ID 51 */
#else /* !GCP_PKG_MGCO_ADVAUSRVRBASE */
   NULLP,
#endif /* GCP_PKG_MGCO_ADVAUSRVRBASE */

#ifdef GCP_PKG_MGCO_AASDIGCOLLECT
   &mgMgcoSigIdSigNameAasDigCollectDef,   /* package ID 52 */
#else /* !GCP_PKG_MGCO_AASDIGCOLLECT */
   NULLP,
#endif /* GCP_PKG_MGCO_AASDIGCOLLECT */

#ifdef GCP_PKG_MGCO_AASRECODING
   &mgMgcoSigIdSigNameAasRecodingDef,     /* package ID 53 */
#else /* !GCP_PKG_MGCO_AASRECODING */
   NULLP,
#endif /* GCP_PKG_MGCO_AASRECODING */

#ifdef GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT
   &mgMgcoSigIdSigNameAdvAuSrvrSegMngmtDef, /* package ID 54 */
#else /* !GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT */
   NULLP,
#endif /* GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT */

   NULLP,                                 /* package ID 55 */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_CONF_TN               /* package ID 56 */
   &mgMgcoSigIdSigName_Conf_TnDef,
#else /* !GCP_PKG_MGCO_CONF_TN */
   NULLP,
#endif /* GCP_PKG_MGCO_CONF_TN */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TEST                  /* package ID 57 */
   &mgMgcoSigIdSigName_TestDef,
#else /* !GCP_PKG_MGCO_TEST */
   NULLP,
#endif /* GCP_PKG_MGCO_TEST */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_CARR_TN               /* package ID 58 */
   &mgMgcoSigIdSigName_Carr_TnDef,
#else /* !GCP_PKG_MGCO_CARR_TN */
   NULLP,
#endif /* GCP_PKG_MGCO_CARR_TN */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_EN_ALERT              /* package ID 59 */
   &mgMgcoSigIdSigName_En_AlertDef,
#else /* !GCP_PKG_MGCO_EN_ALERT */
   NULLP,
#endif /* GCP_PKG_MGCO_EN_ALERT */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_AN_DISP               /* package ID 60 */
   &mgMgcoSigIdSigName_An_DispDef,
#else /* !GCP_PKG_MGCO_AN_DISP */
   NULLP,
#endif /* GCP_PKG_MGCO_AN_DISP */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MFQ_TN_GEN             /* package ID 61 */
   &mgMgcoSigIdSigName_MFq_tn_genDef,
#else /* !GCP_PKG_MGCO_MFQ_TN_GEN */
   NULLP,
#endif /* GCP_PKG_MGCO_MFQ_TN_GEN */

   /* package IDs 62 */
   NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BCAS                  /* package ID 63 */
   &mgMgcoSigIdSigName_bcasDef,
#else /* !GCP_PKG_MGCO_BCAS */
   NULLP,
#endif /* GCP_PKG_MGCO_BCAS */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_RBS                   /* package ID 64 */
   &mgMgcoSigIdSigName_rbsDef,
#else /* !GCP_PKG_MGCO_RBS */
   NULLP,
#endif /* GCP_PKG_MGCO_RBS */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSES                  /* package ID 65 */
   &mgMgcoSigIdSigName_osesDef,
#else /* !GCP_PKG_MGCO_OSES */
   NULLP,
#endif /* GCP_PKG_MGCO_OSES */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_OSEXT                 /* package ID 66 */
   &mgMgcoSigIdSigName_osextDef,
#else /* !GCP_PKG_MGCO_OSEXT */
   NULLP,
#endif /* GCP_PKG_MGCO_OSEXT */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_EXT_ALG               /* package ID 67 */
   &mgMgcoSigIdSigName_Ext_AlgDef,
#else /* !GCP_PKG_MGCO_EXT_ALG */
   NULLP,
#endif /* GCP_PKG_MGCO_EXT_ALG */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_AUT_MET               /* package ID 68 */
   &mgMgcoSigIdSigName_Aut_MetDef,
#else /* !GCP_PKG_MGCO_AUT_MET */
   NULLP,
#endif /* GCP_PKG_MGCO_AUT_MET */

   NULLP, NULLP, NULLP, NULLP, NULLP,     /* package IDs 69 - 73 */

   NULLP,             /* package ID 74 */

   /* IDs 75 -82  */
   NULLP, NULLP, NULLP, NULLP, NULLP,     /* GCP_PKG_MGCO_NAS_SUPPORT */
   NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_QT_TM_LTC             /* package ID 83 */
   &mgMgcoSigIdSigName_qt_tm_ltcDef,
#else /* !GCP_PKG_MGCO_QT_TM_LTC */
   NULLP,
#endif /* GCP_PKG_MGCO_QT_TM_LTC */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_LP_BK_LTR             /* package ID 84 */
   &mgMgcoSigIdSigName_lp_bk_ltrDef,
#else /* !GCP_PKG_MGCO_LP_BK_LTR */
   NULLP,
#endif /* GCP_PKG_MGCO_LP_BK_LTR */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_404            /* package ID 85 */ 
   &mgMgcoSigIdSigName_itu_lt_404Def,
#else /* !GCP_PKG_MGCO_ITU_LT_404 */
   NULLP,
#endif /* GCP_PKG_MGCO_ITU_LT_404 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_816            /* package ID 86 */
   &mgMgcoSigIdSigName_itu_lt_816Def,
#else /* !GCP_PKG_MGCO_ITU_LT_816 */
   NULLP,
#endif /* GCP_PKG_MGCO_ITU_LT_816 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_1020           /* package ID 87 */
   &mgMgcoSigIdSigName_itu_lt_1020Def,
#else /* !GCP_PKG_MGCO_ITU_LT_1020 */
   NULLP,
#endif /* GCP_PKG_MGCO_ITU_LT_1020 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DIST           /* package ID 88 */
   &mgMgcoSigIdSigName_itu_lt_distDef,
#else /* !GCP_PKG_MGCO_ITU_LT_DIST */
   NULLP,
#endif /* GCP_PKG_MGCO_ITU_LT_DIST */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DSEC           /* package ID 89 */
   &mgMgcoSigIdSigName_itu_lt_dsecDef,
#else /* !GCP_PKG_MGCO_ITU_LT_DSEC */
   NULLP,
#endif /* GCP_PKG_MGCO_ITU_LT_DSEC */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_2804           /* package ID 90 */
   &mgMgcoSigIdSigName_itu_lt_2804Def,
#else /* !GCP_PKG_MGCO_ITU_LT_2804 */
   NULLP,
#endif /* GCP_PKG_MGCO_ITU_LT_2804 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_NTT            /* package ID 91 */
   &mgMgcoSigIdSigName_itu_lt_nttDef,
#else /* !GCP_PKG_MGCO_ITU_LT_NTT */
   NULLP,
#endif /* GCP_PKG_MGCO_ITU_LT_NTT */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_DPRT           /* package ID 92 */
   &mgMgcoSigIdSigName_itu_lt_dprtDef,
#else /* !GCP_PKG_MGCO_ITU_LT_DPRT */
   NULLP,
#endif /* GCP_PKG_MGCO_ITU_LT_DPRT */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ITU_LT_ATME2          /* package ID 93 */
   &mgMgcoSigIdSigName_itu_lt_atme2Def,
#else /* !GCP_PKG_MGCO_ITU_LT_ATME2 */
   NULLP,
#endif /* GCP_PKG_MGCO_ITU_LT_ATME2 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_1004          /* package ID 94 */
   &mgMgcoSigIdSigName_ansi_lt_1004Def,
#else /* !GCP_PKG_MGCO_ANSI_LT_1004 */
   NULLP,
#endif /* GCP_PKG_MGCO_ANSI_LT_1004 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_TR            /* package ID 95 */
   &mgMgcoSigIdSigName_ansi_lt_trDef,
#else /* !GCP_PKG_MGCO_ANSI_LT_TR */
   NULLP,
#endif /* GCP_PKG_MGCO_ANSI_LT_TR */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_2225          /* package ID 96 */
   &mgMgcoSigIdSigName_ansi_lt_2225Def,
#else /* !GCP_PKG_MGCO_ANSI_LT_2225 */
   NULLP,
#endif /* GCP_PKG_MGCO_ANSI_LT_2225 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_LT_DTS           /* package ID 97 */ 
   &mgMgcoSigIdSigName_ansi_lt_dtsDef,
#else /* !GCP_PKG_MGCO_ANSI_LT_DTS */
   NULLP,
#endif /* GCP_PKG_MGCO_ANSI_LT_DTS */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ANSI_IN_LTR           /* package ID 98 */
   &mgMgcoSigIdSigName_ansi_in_ltrDef,
#else /* !GCP_PKG_MGCO_ANSI_IN_LTR */
   NULLP,
#endif /* GCP_PKG_MGCO_ANSI_IN_LTR */

   NULLP, NULLP, NULLP, NULLP, NULLP,     /* package IDs 99-108 */
   NULLP, NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_BCASADDR              /* package ID 109 */
   &mgMgcoSigIdSigName_bcasaddrDef,
#else /* !GCP_PKG_MGCO_BCASADDR */
   NULLP,
#endif /* GCP_PKG_MGCO_BCASADDR */

   NULLP,                                 /* package ID 110 */ 

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_IND_VIEW              /* package ID 111 */
   &mgMgcoSigIdSigName_Ind_ViewDef,
#else /* !GCP_PKG_MGCO_IND_VIEW */
   NULLP,
#endif /* GCP_PKG_MGCO_IND_VIEW */

   NULLP, NULLP,                          /* package ID 112-113 */

   NULLP, NULLP, NULLP, NULLP, NULLP,     /* package IDs 114-122 */
   NULLP, NULLP, NULLP, NULLP,

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_ICAS                  /* package ID 123 */
   &mgMgcoSigIdSigName_IcasDef,
#else /* !GCP_PKG_MGCO_ICAS */
   NULLP,
#endif /* GCP_PKG_MGCO_ICAS */

   /*
    * [TEL2]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_CAS_BLK               /* package ID 124 */
   &mgMgcoSigIdSigName_Cas_BlkDef,
#else /* !GCP_PKG_MGCO_CAS_BLK */
   NULLP,
#endif /* GCP_PKG_MGCO_CAS_BLK */

   NULLP, NULLP, NULLP, NULLP, NULLP,     /* package IDs 125 - 129 */

#ifdef GCP_PKG_MGCO_TRI_GCSDEN            /* package ID 130 */
   &mgMgcoSigIdSigName_tri_gcsdenDef,
#else /* !GCP_PKG_MGCO_TRI_GCSDEN */
   NULLP,
#endif /* GCP_PKG_MGCO_TRI_GCSDEN */
   
   NULLP,                                 /* package ID 131 */

   /*
    * [TEL]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_TRIG_FLEX_TN          /* package ID 132 */
   &mgMgcoSigIdSigName_trig_flex_tnDef,
#else /* !GCP_PKG_MGCO_TRIG_FLEX_TN */
   NULLP,
#endif /* GCP_PKG_MGCO_TRIG_FLEX_TN */

   /* [TEL]: Moved from location 36 */
   NULLP,                                 /* package ID 133 */

   /*
    * [TEL3]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MSF_UK_CG             /* package ID 134 */
   &mgMgcoSigIdSigName_Msf_Uk_CgDef,
#else /* !GCP_PKG_MGCO_MSF_UK_CG */
   NULLP,
#endif /* GCP_PKG_MGCO_MSF_UK_CG */

   /*
    * [TEL3]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MSF_UK_AN             /* package ID 135 */
   &mgMgcoSigIdSigName_Msf_Uk_AnDef,
#else /* !GCP_PKG_MGCO_MSF_UK_AN */
   NULLP,
#endif /* GCP_PKG_MGCO_MSF_UK_AN */

   /*
    * [TEL3]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MSF_UK_ALG            /* package ID 136 */
   &mgMgcoSigIdSigName_Msf_Uk_AlgDef,
#else /* !GCP_PKG_MGCO_MSF_UK_ALG */
   NULLP,
#endif /* GCP_PKG_MGCO_MSF_UK_ALG */

   /*
    * [TEL3]: Changed from NULLP
    */
#ifdef GCP_PKG_MGCO_MSF_UK_AUTOMET        /* package ID 137 */
   &mgMgcoSigIdSigName_Msf_Uk_AutometDef,
#else /* !GCP_PKG_MGCO_MSF_UK_AUTOMET */
   NULLP,
#endif /* GCP_PKG_MGCO_MSF_UK_AUTOMET */

   NULLP, NULLP, NULLP, NULLP, NULLP,     /* package IDs 138 - 146 */
   NULLP, NULLP, NULLP, NULLP,

#ifdef GCP_PKG_MGCO_STIM_AL               /* package ID 147 */
   &mgMgcoSigIdSigName_Stim_AlDef,
#else /* !GCP_PKG_MGCO_STIM_AL */
   NULLP,
#endif /* GCP_PKG_MGCO_STIM_AL */

   

/* end of additions */
/*****************************************************************/


#else       

   /* 
    * [TEL]: Added NULLP for all packages in the #if clause
    */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, 
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, /* GCP_PKG_MGCO_NAS_SUPPORT */
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, 

   NULLP,   /* NOTE: no wildcarding allowed so no all signame */ 
   NULLP, NULLP, NULLP, NULLP
   NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP,
#endif /* Big #if */

};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigIdSigNameKnownPkgDefChc =
{
   MGT_PKG_MAX,
   0,
   NULLP,
   mgMgcoSigIdSigNameKnownPkgDefChcElmnts,
   mgMgcoPkgNameEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigIdSigNameKnownPkgDef =
{
#ifdef CM_ABNF_DBG
   "SigIdSigNameKnownPkg",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 137,
   sizeof(MgMgcoSigName),
   (CM_ABNF_MANDATORY) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoSigIdSigNameKnownPkgDefChc,
   mgMgcoRegExpPackageName
};

PUBLIC CmAbnfElmDef *mgMgcoGenericSigComplSigIdSigNameDefChcElmnts[] =
{
   &mgMgcoPkgdNameDef,
   &mgMgcoSigIdSigNameKnownPkgDef
};

#ifdef MGT_PROPR_PKG_SUPPORT
PUBLIC CmAbnfElmTypeU16Choice mgMgcoGenericSigComplSigIdSigNameDefChc =
#else
PUBLIC CmAbnfElmTypeChoice mgMgcoGenericSigComplSigIdSigNameDefChc =
#endif
{
   2,
   MGT_PKG_MAX,   /* changed from a magic number */
   mgMgcoPkgChcIdx,
   mgMgcoGenericSigComplSigIdSigNameDefChcElmnts,
   mgMgcoPkgChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoGenericSigComplSigIdSigNameDef =
{
#ifdef CM_ABNF_DBG
   "GenericSigComplSigIdSigName",
   "PackageName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 138,
   sizeof(MgMgcoSigName),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
#ifdef MGT_PROPR_PKG_SUPPORT
   CM_ABNF_TYPE_CHOICE_U16,
#else
   CM_ABNF_TYPE_CHOICE,
#endif
   (U8 *)&mgMgcoGenericSigComplSigIdSigNameDefChc,
   mgMgcoRegExpPackageName
};

PUBLIC CmAbnfElmDef *mgMgcoGenericSigComplSigIdSigNameArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoGenericSigComplSigIdSigNameDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoGenericSigComplSigIdSigNameArrayDefSeqOf =
{
   1,
   MGT_MAX_SIGNAMES,
   2,
   mgMgcoGenericSigComplSigIdSigNameArrayDefSeqOfElmnts,
   sizeof(MgMgcoSigName)
};

PUBLIC CmAbnfElmDef mgMgcoGenericSigComplSigIdSigNameArrayDef =
{
#ifdef CM_ABNF_DBG
   "GenericSigComplSigIdSigNameArray",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 139,
   sizeof(MgMgcoSigLst) - sizeof(TknU16),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoGenericSigComplSigIdSigNameArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoGenericSigComplSigIdSigNameLstDefSeqElmnts[] =
{
   &mgMgcoGenericSigComplSigIdSigNameDef,
   &mgMgcoGenericSigComplSigIdSigNameArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoGenericSigComplSigIdSigNameLstDefSeq =
{
   2,
   mgMgcoGenericSigComplSigIdSigNameLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoGenericSigComplSigIdSigNameLstDef =
{
#ifdef CM_ABNF_DBG
   "GenericSigComplSigIdSigNameLst",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 140,
   sizeof(MgMgcoSigLst) - sizeof(TknU16),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoGenericSigComplSigIdSigNameLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoGenericSigComplSigIdSigLstDefSeqElmnts[] =
{
   &mgMgcoSigLstIdDef,
   &mgMgcoLBRKTDef,
   &mgMgcoGenericSigComplSigIdSigNameLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoGenericSigComplSigIdSigLstDefSeq =
{
   4,
   mgMgcoGenericSigComplSigIdSigLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoGenericSigComplSigIdSigLstDef =
{
#ifdef CM_ABNF_DBG
   "GenericSigComplSigIdSigLst",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 141,
   sizeof(MgMgcoSigLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoGenericSigComplSigIdSigLstDefSeq,
   NULLP,
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigIdValDefChcElmnts[] =
{
   NULLP, NULLP, NULLP, NULLP, NULLP,
   &mgMgcoGenericSigComplSigIdSigNameDef,
   &mgMgcoGenericSigComplSigIdSigLstDef, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericSigComplSigIdValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoEvtOtherGenericSigComplSigIdValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

/* NOTE: E.1 says the paramater ID value is a list of signals or sequential 
 * signal lists, so I assume there's only one signal/sequential signal list 
 * as a val.
 */
 /* NOTE: the choice returns MGT_VALTYPE_SIGNAME(5) or
  * MGT_VALTYPE_SIGLST(6).
  */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigIdValDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericSigComplSigIdVal",
   "ParmValSigNameOrLst",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 142,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigIdValDefChc,
   mgMgcoRegExpParmValSigNameOrLst
};



/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigIdValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigIdValEqDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplSigIdValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigIdValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 143,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigIdValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigIdValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigIdValGtDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplSigIdValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigIdValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 144,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigIdValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigIdValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigIdValLtDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplSigIdValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigIdValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 145,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigIdValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigIdValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigIdValNeDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplSigIdValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigIdValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 146,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigIdValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigIdValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtOtherGenericSigComplSigIdValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtOtherGenericSigComplSigIdValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoEvtOtherGenericSigComplSigIdValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigIdValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 147,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigIdValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigIdValLstDefSeqElmnts[]   =
{
   &mgMgcoEvtOtherGenericSigComplSigIdValDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigIdValLstDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplSigIdValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigIdValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 148,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigIdValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigIdValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigIdValAndDefSeq =
{
   4,
   mgMgcoEvtOtherGenericSigComplSigIdValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigIdValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 149,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigIdValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigIdValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigIdValOrDefSeq =
{
   4,
   mgMgcoEvtOtherGenericSigComplSigIdValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigIdValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 150,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigIdValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigIdValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValDef,
   &cmMsgDefMetaColon,
   &mgMgcoEvtOtherGenericSigComplSigIdValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigIdValRngDefSeq =
{
   6,
   mgMgcoEvtOtherGenericSigComplSigIdValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigIdValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 151,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigIdValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigIdDefChcElmnts[] =
{
   &mgMgcoEvtOtherGenericSigComplSigIdValEqDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValGtDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValLtDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValNeDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValAndDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValOrDef,
   &mgMgcoEvtOtherGenericSigComplSigIdValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericSigComplSigIdDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoEvtOtherGenericSigComplSigIdDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigIdDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericSigComplSigId",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 152,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigIdDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoGenericSigComplTermMethTOEnum =
{
   (Data *)"TO",
   MGT_PKG_GENERIC_EVT_SIG_COMPL_METH_TO
};

PUBLIC CmAbnfElmDef mgMgcoGenericSigComplTermMethTOEnumDef =
{
#ifdef CM_ABNF_DBG
   "GenericSigComplTermMeth - TO - Timeout (duration expired)",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 153,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGenericSigComplTermMethTOEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoGenericSigComplTermMethEVEnum =
{
   (Data *)"EV",
   MGT_PKG_GENERIC_EVT_SIG_COMPL_METH_EV
};

PUBLIC CmAbnfElmDef mgMgcoGenericSigComplTermMethEVEnumDef =
{
#ifdef CM_ABNF_DBG
   "GenericSigComplTermMeth - EV - interrupted by event",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 154,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGenericSigComplTermMethEVEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoGenericSigComplTermMethSDEnum =
{
   (Data *)"SD",
   MGT_PKG_GENERIC_EVT_SIG_COMPL_METH_SD
};

PUBLIC CmAbnfElmDef mgMgcoGenericSigComplTermMethSDEnumDef =
{
#ifdef CM_ABNF_DBG
   "GenericSigComplTermMeth - SD - halted by new signals descriptor",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 155,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGenericSigComplTermMethSDEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoGenericSigComplTermMethNCEnum =
{
   (Data *)"NC",
   MGT_PKG_GENERIC_EVT_SIG_COMPL_METH_NC
};

PUBLIC CmAbnfElmDef mgMgcoGenericSigComplTermMethNCEnumDef =
{
#ifdef CM_ABNF_DBG
   "GenericSigComplTermMeth - NC - Not completed, other cause",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 156,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoGenericSigComplTermMethNCEnum,
   NULLP
};


/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplTermMethValueChcEnum[] =
{
   NULLP,
   &mgMgcoGenericSigComplTermMethTOEnumDef,
   &mgMgcoGenericSigComplTermMethEVEnumDef,
   &mgMgcoGenericSigComplTermMethSDEnumDef,
   &mgMgcoGenericSigComplTermMethNCEnumDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericSigComplTermMethValueChc =
{
   5,
   0,
   NULLP,
   NULLP,
   mgMgcoEvtOtherGenericSigComplTermMethValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplTermMethValue =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericSigComplTermMethValue",
   "EvtOtherGenericSigComplTermMethValue",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 157,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericSigComplTermMethValueChc,
   mgMgcoRegExpEvtOtherGenericSigComplTermMethValue
};

/************************************************************************/

/* NOTE: This is not a choice as such, just to indicate the type of value
 * we artificially make this a choice element, whose type (MgMgcoValue->type)
 * is always expected to be MGT_VALTYPE_ENUM. 
 * The actual causes are differentiated in MgMgcoValue->u.enume values.
 * We follow this practice for other ParmValues as well, whose types maybe
 * MGT_VALTYPE_UINT32 or MGT_VALTYPE_OCTSTRXL. The regular expression
 * (in this case mgMgcoRegExpParmValEnume) alwyas returns one particular
 * MGT_VALTYPE_YYY while decoding. While encoding, we always expect
 * MgMgcoValue->type to be MGT_VALTYPE_ENUM.
 */

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplTermMethValDefChcElmnts[] =
{
   &mgMgcoEvtOtherGenericSigComplTermMethValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericSigComplTermMethValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoEvtOtherGenericSigComplTermMethValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplTermMethValDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericSigComplTermMethVal",
   "ParmValEnume",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 158,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericSigComplTermMethValDefChc,
   mgMgcoRegExpParmValEnume
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplTermMethValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplTermMethValEqDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplTermMethValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplTermMethValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 159,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplTermMethValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplTermMethValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplTermMethValGtDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplTermMethValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplTermMethValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 160,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ, 
   (U8 *)&mgMgcoEvtOtherGenericSigComplTermMethValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplTermMethValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplTermMethValLtDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplTermMethValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplTermMethValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 161,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplTermMethValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplTermMethValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplTermMethValNeDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplTermMethValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplTermMethValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 162,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplTermMethValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplTermMethValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtOtherGenericSigComplTermMethValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtOtherGenericSigComplTermMethValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoEvtOtherGenericSigComplTermMethValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplTermMethValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 163,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtOtherGenericSigComplTermMethValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplTermMethValLstDefSeqElmnts[]   =
{
   &mgMgcoEvtOtherGenericSigComplTermMethValDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplTermMethValLstDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplTermMethValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplTermMethValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 164,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtOtherGenericSigComplTermMethValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplTermMethValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplTermMethValAndDefSeq =
{
   4,
   mgMgcoEvtOtherGenericSigComplTermMethValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplTermMethValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 165,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplTermMethValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplTermMethValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplTermMethValOrDefSeq =
{
   4,
   mgMgcoEvtOtherGenericSigComplTermMethValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplTermMethValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 166,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplTermMethValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplTermMethValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValDef,
   &cmMsgDefMetaColon,
   &mgMgcoEvtOtherGenericSigComplTermMethValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplTermMethValRngDefSeq =
{
   6,
   mgMgcoEvtOtherGenericSigComplTermMethValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplTermMethValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 167,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplTermMethValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplTermMethDefChcElmnts[] =
{
   &mgMgcoEvtOtherGenericSigComplTermMethValEqDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValGtDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValLtDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValNeDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValAndDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValOrDef,
   &mgMgcoEvtOtherGenericSigComplTermMethValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericSigComplTermMethDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoEvtOtherGenericSigComplTermMethDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplTermMethDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericSigComplTermMeth",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 168,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericSigComplTermMethDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};


PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigLstIdValDecUintDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericSigComplSigLstIdValDecUint",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 169,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoU32DefRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigLstIdValDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValDecUintDef,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericSigComplSigLstIdValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoEvtOtherGenericSigComplSigLstIdValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigLstIdValDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericSigComplSigLstIdVal",
   "ParmValDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 170,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigLstIdValDefChc,
   mgMgcoRegExpParmValDecUint
};


/* = value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigLstIdValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigLstIdValEqDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplSigLstIdValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigLstIdValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 171,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigLstIdValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigLstIdValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigLstIdValGtDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplSigLstIdValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigLstIdValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 172,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigLstIdValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigLstIdValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigLstIdValLtDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplSigLstIdValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigLstIdValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 173,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigLstIdValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigLstIdValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigLstIdValNeDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplSigLstIdValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigLstIdValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 174,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigLstIdValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigLstIdValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtOtherGenericSigComplSigLstIdValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoEvtOtherGenericSigComplSigLstIdValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigLstIdValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 175,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigLstIdValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigLstIdValLstDefSeqElmnts[]   =
{
   &mgMgcoEvtOtherGenericSigComplSigLstIdValDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigLstIdValLstDefSeq =
{
   2,
   mgMgcoEvtOtherGenericSigComplSigLstIdValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigLstIdValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 176,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigLstIdValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigLstIdValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigLstIdValAndDefSeq =
{
   4,
   mgMgcoEvtOtherGenericSigComplSigLstIdValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigLstIdValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 177,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigLstIdValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigLstIdValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigLstIdValOrDefSeq =
{
   4,
   mgMgcoEvtOtherGenericSigComplSigLstIdValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigLstIdValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 178,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigLstIdValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigLstIdValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValDef,
   &cmMsgDefMetaColon,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherGenericSigComplSigLstIdValRngDefSeq =
{
   6,
   mgMgcoEvtOtherGenericSigComplSigLstIdValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigLstIdValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 179,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigLstIdValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplSigLstIdDefChcElmnts[] =
{
   &mgMgcoEvtOtherGenericSigComplSigLstIdValEqDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValGtDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValLtDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValNeDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValAndDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValOrDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericSigComplSigLstIdDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoEvtOtherGenericSigComplSigLstIdDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigLstIdDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericSigComplSigLstId",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 180,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigLstIdDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherGenericSigComplSigIdEnum =
{
   (Data *)"SigID",
   MGT_PKG_GENERIC_EVT_SIG_COMPL_SIGID
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigIdEnumDef =
{
#ifdef CM_ABNF_DBG
   "GenericSigComplSigIdEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 181,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigIdEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherGenericSigComplTermMethEnum =
{
   (Data *)"Meth",
   MGT_PKG_GENERIC_EVT_SIG_COMPL_METH
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplTermMethEnumDef =
{
#ifdef CM_ABNF_DBG
   "GenericSigComplTermMethEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 182,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherGenericSigComplTermMethEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherGenericSigComplSigLstIdEnum =
{
   (Data *)"SLID",
   MGT_PKG_GENERIC_EVT_SIG_COMPL_SIGLSTID
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplSigLstIdEnumDef =
{
#ifdef CM_ABNF_DBG
   "GenericSigComplSigLstIdEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 183,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherGenericSigComplSigLstIdEnum,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplParDefChcEnum[] =
{
   NULLP,
   &mgMgcoEvtOtherGenericSigComplSigIdEnumDef,
   &mgMgcoEvtOtherGenericSigComplTermMethEnumDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdEnumDef,
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtOtherGenericSigComplSigIdDef,
   &mgMgcoEvtOtherGenericSigComplTermMethDef,
   &mgMgcoEvtOtherGenericSigComplSigLstIdDef
};


PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericSigComplParDefChc =
{
   4,
   0,
   NULLP,
   mgMgcoEvtOtherGenericSigComplParDefChcElmnts,
   mgMgcoEvtOtherGenericSigComplParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplParDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericSigComplPar",
   "EvtOtherGenericSigComplPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 184,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericSigComplParDefChc,
   mgMgcoRegExpEvtOtherGenericSigComplPar
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherGenericSigComplDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoEvtOtherGenericSigComplParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherGenericSigComplDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtOtherGenericSigComplDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherGenericSigComplDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherGenericSigCompl",
   "EvtOtherGenericSigComplType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 185,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherGenericSigComplDefChc,
   mgMgcoRegExpEvtOtherGenericSigComplType
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecGenericSigComplParmDefChcElmnts[] =
{
   &mgMgcoEvtOtherGenericSigComplDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecGenericSigComplParmDefChc =
{
   5,
   6,      
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecGenericSigComplParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecGenericSigComplParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecGenericSigCompl - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 186,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecGenericSigComplParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecGenericSigComplParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecGenericSigComplParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecGenericSigComplParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecGenericSigComplParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecGenericSigComplParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecGenericSigCompl - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 187,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecGenericSigComplParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecGenericSigComplParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecGenericSigComplParmDef,
   &mgMgcoEvtSecGenericSigComplParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecGenericSigComplParmLstDefSeq =
{
   2,
   mgMgcoEvtSecGenericSigComplParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecGenericSigComplParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecGenericSigCompl - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 188,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecGenericSigComplParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecGenericSigComplDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecGenericSigComplParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecGenericSigComplDefSeq =
{
   3,
   mgMgcoEvtSecGenericSigComplDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecGenericSigComplDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecGenericSigCompl - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 189,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecGenericSigComplDefSeq,
   mgMgcoRegExpLBRKT
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecGenericRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecGenericCauseDef,
   &mgMgcoEvtSecGenericSigComplDef
};

PUBLIC CmAbnfElmDef *mgMgcoEventGenericRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoEventGenericCauseEnumDef,
   &mgMgcoEventGenericSigComplEnumDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecGenericRealDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtSecGenericRealDefChcElmnts,
   mgMgcoEventGenericRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecGenericRealDef =
{
#ifdef CM_ABNF_DBG
   "Real second requested event - package Generic",
   "EvtNameGeneric",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 190,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecGenericRealDefChc,
   mgMgcoRegExpEvtNameGeneric
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecGenericChcDefChcElmnts[] =
{
   &mgMgcoEvtSecUnknownNameDef,
   &mgMgcoEvtSecSkipAllDef,
   &mgMgcoEvtSecGenericRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecGenericChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtSecGenericChcDefChcElmnts,
   mgMgcoGenTypeEnum 
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecGenericChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of second req event in package Generic",
   "PkgGenericEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 191,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecGenericChcDefChc,
   mgMgcoRegExpPkgGenericEvtType
};

/* Second requested event */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecGenericDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvtSecGenericChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecGenericDefSeq =
{
   3,
   mgMgcoEvtSecGenericDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecGenericDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - package Generic",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 192,
   sizeof(MgMgcoEvtSec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecGenericDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecGenericCauseParmDefChcElmnts[] =
{
   &mgMgcoEvtOtherGenericCauseDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecGenericCauseParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecGenericCauseParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecGenericCauseParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecGenericCause - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 193,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecGenericCauseParmDefChc,
   mgMgcoRegExpEvtPar
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecGenericCauseParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecGenericCauseParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecGenericCauseParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecGenericCauseParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecGenericCauseParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecGenericCause - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 194,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecGenericCauseParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecGenericCauseParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecGenericCauseParmDef,
   &mgMgcoEvSpecGenericCauseParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecGenericCauseParmLstDefSeq =
{
   2,
   mgMgcoEvSpecGenericCauseParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecGenericCauseParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecGenericCause - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 195,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecGenericCauseParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecGenericCauseDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecGenericCauseParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecGenericCauseDefSeq =
{
   3,
   mgMgcoEvSpecGenericCauseDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecGenericCauseDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecGenericCause - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 196,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecGenericCauseDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecGenericSigComplParmDefChcElmnts[] =
{
   &mgMgcoEvtOtherGenericSigComplDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecGenericSigComplParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecGenericSigComplParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecGenericSigComplParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecGenericSigCompl - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 197,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecGenericSigComplParmDefChc,
   mgMgcoRegExpEvtPar
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecGenericSigComplParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecGenericSigComplParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecGenericSigComplParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecGenericSigComplParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecGenericSigComplParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecGenericSigCompl - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 198,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecGenericSigComplParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecGenericSigComplParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecGenericSigComplParmDef,
   &mgMgcoEvSpecGenericSigComplParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecGenericSigComplParmLstDefSeq =
{
   2,
   mgMgcoEvSpecGenericSigComplParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecGenericSigComplParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecGenericSigCompl - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 199,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecGenericSigComplParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecGenericSigComplDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecGenericSigComplParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecGenericSigComplDefSeq =
{
   3,
   mgMgcoEvSpecGenericSigComplDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecGenericSigComplDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecGenericSigCompl - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 200,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecGenericSigComplDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecGenericRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecGenericCauseDef,
   &mgMgcoEvSpecGenericSigComplDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecGenericRealDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecGenericRealDefChcElmnts,
   mgMgcoEventGenericRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecGenericRealDef =
{
#ifdef CM_ABNF_DBG
   "Real event spec -  package Generic",
   "EvtNameGeneric",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 201,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecGenericRealDefChc,
   mgMgcoRegExpEvtNameGeneric
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecGenericChcDefChcElmnts[] =
{
   &mgMgcoEvSpecUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoEvSpecGenericRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecGenericChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecGenericChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecGenericChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of event spec in package Generic",
   "PkgGenericEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 202,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecGenericChcDefChc,
   mgMgcoRegExpPkgGenericEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecGenericDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvSpecGenericChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecGenericDefSeq =
{
   3,
   mgMgcoEvSpecGenericDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecGenericDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - package Generic",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 203,
   sizeof(MgMgcoEvSpec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecGenericDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtGenericCauseParmDefChcElmnts[] =
{
   &mgMgcoEvtOtherGenericCauseDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtGenericCauseParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtGenericCauseParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtGenericCauseParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtGenericCause - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 204,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtGenericCauseParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtGenericCauseParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtGenericCauseParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtGenericCauseParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtGenericCauseParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtGenericCauseParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtGenericCause - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 205,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtGenericCauseParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtGenericCauseParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtGenericCauseParmDef,
   &mgMgcoReqEvtGenericCauseParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtGenericCauseParmLstDefSeq =
{
   2,
   mgMgcoReqEvtGenericCauseParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtGenericCauseParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtGenericCause - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 206,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtGenericCauseParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtGenericCauseDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtGenericCauseParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtGenericCauseDefSeq =
{
   3,
   mgMgcoReqEvtGenericCauseDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtGenericCauseDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtGenericCause - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 207,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtGenericCauseDefSeq,
   mgMgcoRegExpLBRKT
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtGenericSigComplParmDefChcElmnts[] =
{
   &mgMgcoEvtOtherGenericSigComplDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtGenericSigComplParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtGenericSigComplParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtGenericSigComplParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtGenericSigCompl - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 208,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtGenericSigComplParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtGenericSigComplParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtGenericSigComplParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtGenericSigComplParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtGenericSigComplParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtGenericSigComplParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtGenericSigCompl - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 209,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtGenericSigComplParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtGenericSigComplParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtGenericSigComplParmDef,
   &mgMgcoReqEvtGenericSigComplParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtGenericSigComplParmLstDefSeq =
{
   2,
   mgMgcoReqEvtGenericSigComplParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtGenericSigComplParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtGenericSigCompl - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 210,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtGenericSigComplParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtGenericSigComplDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtGenericSigComplParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtGenericSigComplDefSeq =
{
   3,
   mgMgcoReqEvtGenericSigComplDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtGenericSigComplDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtGenericSigCompl - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 211,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtGenericSigComplDefSeq,
   mgMgcoRegExpLBRKT
};


/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtGenericRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtGenericCauseDef,
   &mgMgcoReqEvtGenericSigComplDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtGenericRealDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtGenericRealDefChcElmnts,
   mgMgcoEventGenericRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtGenericRealDef =
{
#ifdef CM_ABNF_DBG
   "Real requested event - package Generic",
   "EvtNameGeneric",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 212,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtGenericRealDefChc,
   mgMgcoRegExpEvtNameGeneric
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtGenericChcDefChcElmnts[] =
{
   &mgMgcoReqEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoReqEvtGenericRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtGenericChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtGenericChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtGenericChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of requested event in package Generic",
   "PkgGenericEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 213,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtGenericChcDefChc,
   mgMgcoRegExpPkgGenericEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtGenericDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoReqEvtGenericChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtGenericDefSeq =
{
   3,
   mgMgcoReqEvtGenericDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtGenericDef =
{
#ifdef CM_ABNF_DBG
   "Requested event - package Generic",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 214,
   sizeof(MgMgcoReqEvt) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtGenericDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtGenericRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecGenericCauseDef,
   &mgMgcoEvSpecGenericSigComplDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtGenericRealDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtGenericRealDefChcElmnts,
   mgMgcoEventGenericRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtGenericRealDef =
{
#ifdef CM_ABNF_DBG
   "Real observed event - package Generic",
   "EvtNameGeneric",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 215,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtGenericRealDefChc,
   mgMgcoRegExpEvtNameGeneric
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtGenericChcDefChcElmnts[] =
{
   &mgMgcoObsEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoObsEvtGenericRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtGenericChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtGenericChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtGenericChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of observed event in package Generic",
   "PkgGenericEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 216,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtGenericChcDefChc,
   mgMgcoRegExpPkgGenericEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtGenericDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoObsEvtGenericChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtGenericDefSeq =
{
   3,
   mgMgcoObsEvtGenericDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtGenericDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - package Generic",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 217,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtGenericDefSeq,
   NULLP
};

/************************************************************************
                        Signals - None
************************************************************************/

/************************************************************************
                        Statistics - None
************************************************************************/

#endif /* GCP_PKG_MGCO_GENERIC */

#ifdef GCP_PKG_MGCO_ROOT
/************************************************************************

                     Package - Base Root (root) (0x0002)

************************************************************************/

/************************************************************************
                              Properties
************************************************************************/

PUBLIC CmAbnfElmDef mgMgcoPropParmRootAnyValDecUintDef =
{
#ifdef CM_ABNF_DBG
   "PropParmRootAnyValDecUint",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 218,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoU32DefRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmRootAnyValDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmRootAnyValDecUintDef,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmRootAnyValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoPropParmRootAnyValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmRootAnyValDef =
{
#ifdef CM_ABNF_DBG
   "PropParmRootAnyVal",
   "ParmValDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 219,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmRootAnyValDefChc,
   mgMgcoRegExpParmValDecUint
};


/* = value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmRootAnyValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmRootAnyValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmRootAnyValEqDefSeq =
{
   2,
   mgMgcoPropParmRootAnyValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmRootAnyValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 220,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmRootAnyValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmRootAnyValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoPropParmRootAnyValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmRootAnyValGtDefSeq =
{
   2,
   mgMgcoPropParmRootAnyValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmRootAnyValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 221,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoPropParmRootAnyValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmRootAnyValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoPropParmRootAnyValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmRootAnyValLtDefSeq =
{
   2,
   mgMgcoPropParmRootAnyValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmRootAnyValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 222,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmRootAnyValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmRootAnyValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoPropParmRootAnyValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmRootAnyValNeDefSeq =
{
   2,
   mgMgcoPropParmRootAnyValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmRootAnyValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 223,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmRootAnyValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmRootAnyValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmRootAnyValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmRootAnyValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoPropParmRootAnyValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmRootAnyValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 224,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmRootAnyValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmRootAnyValLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmRootAnyValDef,
   &mgMgcoPropParmRootAnyValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmRootAnyValLstDefSeq =
{
   2,
   mgMgcoPropParmRootAnyValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmRootAnyValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 225,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmRootAnyValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmRootAnyValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmRootAnyValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmRootAnyValAndDefSeq =
{
   4,
   mgMgcoPropParmRootAnyValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmRootAnyValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 226,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmRootAnyValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmRootAnyValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPropParmRootAnyValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmRootAnyValOrDefSeq =
{
   4,
   mgMgcoPropParmRootAnyValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmRootAnyValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 227,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmRootAnyValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmRootAnyValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmRootAnyValDef,
   &cmMsgDefMetaColon,
   &mgMgcoPropParmRootAnyValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmRootAnyValRngDefSeq =
{
   6,
   mgMgcoPropParmRootAnyValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmRootAnyValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 228,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPropParmRootAnyValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmRootAnyDefChcElmnts[] =
{
   &mgMgcoPropParmRootAnyValEqDef,
   &mgMgcoPropParmRootAnyValGtDef,
   &mgMgcoPropParmRootAnyValLtDef,
   &mgMgcoPropParmRootAnyValNeDef,
   &mgMgcoPropParmRootAnyValAndDef,
   &mgMgcoPropParmRootAnyValOrDef,
   &mgMgcoPropParmRootAnyValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmRootAnyDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmRootAnyDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmRootAnyDef =
{
#ifdef CM_ABNF_DBG
   "PropParmRootAny",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 229,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmRootAnyDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmRootMaxNrOfCxtsEnum =
{
   (Data *)"maxNumberOfContexts",
   MGT_PKG_ROOT_PROP_MAXNROFCXTS
};

PUBLIC CmAbnfElmDef mgMgcoPropParmRootMaxNrOfCxtsEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmRootMaxNrOfCxtsEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 230,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmRootMaxNrOfCxtsEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmRootMaxTermsPerCxtEnum =
{
   (Data *)"maxTerminationsPerContext",
   MGT_PKG_ROOT_PROP_MAXTERMSPERCXT
};

PUBLIC CmAbnfElmDef mgMgcoPropParmRootMaxTermsPerCxtEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmRootMaxTermsPerCxtEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 231,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmRootMaxTermsPerCxtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmRootMGExecTimeEnum =
{
   (Data *)"normalMGExecutionTime",
   MGT_PKG_ROOT_PROP_MGEXECTIME
};

PUBLIC CmAbnfElmDef mgMgcoPropParmRootMGExecTimeEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmRootMGExecTimeEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 232,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmRootMGExecTimeEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmRootMGCExecTimeEnum =
{
   (Data *)"normalMGCExecutionTime",
   MGT_PKG_ROOT_PROP_MGCEXECTIME
};

PUBLIC CmAbnfElmDef mgMgcoPropParmRootMGCExecTimeEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmRootMGCExecTimeEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 233,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmRootMGCExecTimeEnum,
   NULLP
};

/* Changed to "MGProv.." from "Prov.." */
PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmRootMGProvRspTmrValEnum =
{
   (Data *)"MGProvisionalResponseTimerValue",
   MGT_PKG_ROOT_PROP_MGPROVRSPTMRVAL
};

PUBLIC CmAbnfElmDef mgMgcoPropParmRootMGProvRspTmrValEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmRootMGProvRspTmrValEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 234,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmRootMGProvRspTmrValEnum,
   NULLP
};

/* new enum def for "MGCProv.." added */
PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmRootMGCProvRspTmrValEnum =
{
   (Data *)"MGCProvisionalResponseTimerValue",
   MGT_PKG_ROOT_PROP_MGCPROVRSPTMRVAL
};

/*MAHESH */
PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmRootMGOriginatedPendingLimitEnum =
{
   (Data *)"MGOriginatedPendingLimit",
    MGT_PKG_ROOT_PROP_MGORIGPENDLIMIT       
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmRootMGCOriginatedPendingLimitEnum =
{
   (Data *)"MGCOriginatedPendingLimit",
    MGT_PKG_ROOT_PROP_MGCORIGPENDLIMIT       
};
/*MAHESH */

PUBLIC CmAbnfElmDef mgMgcoPropParmRootMGCProvRspTmrValEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmRootMGCProvRspTmrValEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 234,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmRootMGCProvRspTmrValEnum,
   NULLP
};
/*MAHESH */
PUBLIC CmAbnfElmDef mgMgcoPropParmRootMGOriginatedPendingLimitEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmRootMGOriginated pendig limit",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 200,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmRootMGOriginatedPendingLimitEnum,
   NULLP
};

PUBLIC CmAbnfElmDef mgMgcoPropParmRootMGCOriginatedPendingLimitEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmRootMGCOriginated pendig limit",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 234,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmRootMGCOriginatedPendingLimitEnum,
   NULLP
};
/*MAHESH */


PUBLIC CmAbnfElmDef *mgMgcoPropParmRootRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoPropParmRootMaxNrOfCxtsEnumDef,
   &mgMgcoPropParmRootMaxTermsPerCxtEnumDef,
   &mgMgcoPropParmRootMGExecTimeEnumDef,
   &mgMgcoPropParmRootMGCExecTimeEnumDef,
   &mgMgcoPropParmRootMGProvRspTmrValEnumDef,     /* changed */
   &mgMgcoPropParmRootMGCProvRspTmrValEnumDef,    /* added */
   &mgMgcoPropParmRootMGOriginatedPendingLimitEnumDef,     /* MAHESH*/
   &mgMgcoPropParmRootMGCOriginatedPendingLimitEnumDef     /* MAHESH*/
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmRootRealDefChcElmnts[] =
{
   &mgMgcoPropParmRootAnyDef
};

/* added */
PUBLIC U8 mgMgcoPropParmRootRealDefChcIdx[] = {0, 0, 0, 0, 0, 0, 0, 0, 0};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmRootRealDefChc =
{
   1,
   9,   /* incremented by 1 */ /*MAHESH */
   mgMgcoPropParmRootRealDefChcIdx,
   mgMgcoPropParmRootRealDefChcElmnts,
   mgMgcoPropParmRootRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmRootRealDef =
{
#ifdef CM_ABNF_DBG
   "PropParmRoot",
   "PropParmRoot",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 235,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmRootRealDefChc,
   mgMgcoRegExpPropParmRoot
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmRootChcDefChcElmnts[] =
{
   &mgMgcoPropParmUnknownDef,
   &mgMgcoPropParmSkipAllDef,
   &mgMgcoPropParmRootRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmRootChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoPropParmRootChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmRootChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of property parameter in package Root",
   "PkgRootPropType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 236,
   sizeof(MgMgcoName) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmRootChcDefChc,
   mgMgcoRegExpPkgRootPropType 
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmRootDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoPropParmRootChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmRootDefSeq =
{
   3,
   mgMgcoPropParmRootDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoPropParmRootDef =
{
#ifdef CM_ABNF_DBG
   "Property parameter - package Root",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 237,
   sizeof(MgMgcoPropParm) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmRootDefSeq,
   NULLP
};

/************************************************************************
                              Events - none
************************************************************************/

/************************************************************************
                              Signals - none
************************************************************************/

/************************************************************************
                              Statistics - none
************************************************************************/

#endif /* GCP_PKG_MGCO_ROOT */


/*
 * [TEL]: Added compilation flags for all the extended packages extending
 * Tonegen package.
 */
#if (defined(GCP_PKG_MGCO_TONEGEN) || defined(GCP_PKG_MGCO_DTMFGEN) || \
     defined(GCP_PKG_MGCO_CPGEN)   || defined(GCP_PKG_MGCO_TONEDET) || \
     defined(GCP_PKG_MGCO_DTMFDET)   || defined(GCP_PKG_MGCO_CPDET) || \
     defined(GCP_PKG_MGCO_BSC_CAL_TN) ||                              \
     defined(GCP_PKG_MGCO_XD_CALPG_TNGN) ||                           \
     defined(GCP_PKG_MGCO_BSC_SRV_TN) ||                              \
     defined(GCP_PKG_MGCO_XD_SRV_TNGN) ||                             \
     defined(GCP_PKG_MGCO_INT_TNGN) ||                                \
     defined(GCP_PKG_MGCO_BSNS_TNGN) ||                               \
     defined(GCP_PKG_MGCO_TRIG_XD_CALPG_TNGN) ||                      \
     defined(GCP_PKG_MGCO_TRIG_FLEX_TN) ||                            \
     defined(GCP_PKG_MGCO_CONF_TN) ||                                 \
     defined(GCP_PKG_MGCO_TEST) ||                                    \
     defined(GCP_PKG_MGCO_CARR_TN) ||                                 \
     defined(GCP_PKG_MGCO_MFQ_TN_GEN))
 
/************************************************************************
 
               Package - Tone Generator (tonegen) (0x0003)

************************************************************************/

/************************************************************************
                        Properties - none
************************************************************************/

/************************************************************************
                           Events - none
************************************************************************/

/************************************************************************
                              Signals
************************************************************************/

PUBLIC CmAbnfElmTypeChoice mgMgcoSigOtherToneGenPtToneIdLstValueChc =
{
   /* [TEL2]: Increased from existing 0x4a */
   /* [TEL]: Increased from existing 0x40 */
   0x6f,
   0,
   NULLP,
   NULLP,
   mgMgcoToneIdEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtToneIdLstValue =
{
#ifdef CM_ABNF_DBG
   "SigOtherToneGenPtToneIdLstValue",
   "ToneID",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 238,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigOtherToneGenPtToneIdLstValueChc,
   mgMgcoRegExpToneID
};

PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtToneIdLstValDefChcElmnts[] =
{
   &mgMgcoSigOtherToneGenPtToneIdLstValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigOtherToneGenPtToneIdLstValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoSigOtherToneGenPtToneIdLstValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtToneIdLstValDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherToneGenPtToneIdLstVal",
   "ParmValEnume",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 239,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigOtherToneGenPtToneIdLstValDefChc,
   mgMgcoRegExpParmValEnume
};



/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtToneIdLstValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtToneIdLstValEqDefSeq =
{
   2,
   mgMgcoSigOtherToneGenPtToneIdLstValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtToneIdLstValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 240,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherToneGenPtToneIdLstValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtToneIdLstValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtToneIdLstValGtDefSeq =
{
   2,
   mgMgcoSigOtherToneGenPtToneIdLstValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtToneIdLstValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 241,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoSigOtherToneGenPtToneIdLstValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtToneIdLstValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtToneIdLstValLtDefSeq =
{
   2,
   mgMgcoSigOtherToneGenPtToneIdLstValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtToneIdLstValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 242,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherToneGenPtToneIdLstValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtToneIdLstValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtToneIdLstValNeDefSeq =
{
   2,
   mgMgcoSigOtherToneGenPtToneIdLstValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtToneIdLstValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 243,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherToneGenPtToneIdLstValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtToneIdLstValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoSigOtherToneGenPtToneIdLstValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoSigOtherToneGenPtToneIdLstValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoSigOtherToneGenPtToneIdLstValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtToneIdLstValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 244,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoSigOtherToneGenPtToneIdLstValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtToneIdLstValLstDefSeqElmnts[]   =
{
   &mgMgcoSigOtherToneGenPtToneIdLstValDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtToneIdLstValLstDefSeq =
{
   2,
   mgMgcoSigOtherToneGenPtToneIdLstValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtToneIdLstValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 245,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoSigOtherToneGenPtToneIdLstValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtToneIdLstValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtToneIdLstValAndDefSeq =
{
   4,
   mgMgcoSigOtherToneGenPtToneIdLstValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtToneIdLstValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 246,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherToneGenPtToneIdLstValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtToneIdLstValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtToneIdLstValOrDefSeq =
{
   4,
   mgMgcoSigOtherToneGenPtToneIdLstValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtToneIdLstValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 247,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherToneGenPtToneIdLstValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtToneIdLstValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValDef,
   &cmMsgDefMetaColon,
   &mgMgcoSigOtherToneGenPtToneIdLstValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtToneIdLstValRngDefSeq =
{
   6,
   mgMgcoSigOtherToneGenPtToneIdLstValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtToneIdLstValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 248,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoSigOtherToneGenPtToneIdLstValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtToneIdLstDefChcElmnts[] =
{
   &mgMgcoSigOtherToneGenPtToneIdLstValEqDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValGtDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValLtDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValNeDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValAndDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValOrDef,
   &mgMgcoSigOtherToneGenPtToneIdLstValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigOtherToneGenPtToneIdLstDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoSigOtherToneGenPtToneIdLstDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtToneIdLstDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherToneGenPtToneIdLst",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 249,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigOtherToneGenPtToneIdLstDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtInterSigDurValue =
{
#ifdef CM_ABNF_DBG
   "SigOtherToneGenPtInterSigDurValue",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 250,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoU32DefRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtInterSigDurValDefChcElmnts[] =
{
   NULLP,
   &mgMgcoSigOtherToneGenPtInterSigDurValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigOtherToneGenPtInterSigDurValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoSigOtherToneGenPtInterSigDurValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtInterSigDurValDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherToneGenPtInterSigDurVal",
   "ParmValueDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 251,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigOtherToneGenPtInterSigDurValDefChc,
   mgMgcoRegExpParmValDecUint
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtInterSigDurValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtInterSigDurValEqDefSeq =
{
   2,
   mgMgcoSigOtherToneGenPtInterSigDurValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtInterSigDurValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 252,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherToneGenPtInterSigDurValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtInterSigDurValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtInterSigDurValGtDefSeq =
{
   2,
   mgMgcoSigOtherToneGenPtInterSigDurValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtInterSigDurValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 253,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,   
   (U8 *)&mgMgcoSigOtherToneGenPtInterSigDurValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtInterSigDurValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtInterSigDurValLtDefSeq =
{
   2,
   mgMgcoSigOtherToneGenPtInterSigDurValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtInterSigDurValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 254,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherToneGenPtInterSigDurValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtInterSigDurValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtInterSigDurValNeDefSeq =
{
   2,
   mgMgcoSigOtherToneGenPtInterSigDurValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtInterSigDurValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 255,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherToneGenPtInterSigDurValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtInterSigDurValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoSigOtherToneGenPtInterSigDurValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoSigOtherToneGenPtInterSigDurValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoSigOtherToneGenPtInterSigDurValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtInterSigDurValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 256,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoSigOtherToneGenPtInterSigDurValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtInterSigDurValLstDefSeqElmnts[]   =
{
   &mgMgcoSigOtherToneGenPtInterSigDurValDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtInterSigDurValLstDefSeq =
{
   2,
   mgMgcoSigOtherToneGenPtInterSigDurValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtInterSigDurValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 257,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoSigOtherToneGenPtInterSigDurValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtInterSigDurValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtInterSigDurValAndDefSeq =
{
   4,
   mgMgcoSigOtherToneGenPtInterSigDurValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtInterSigDurValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 258,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherToneGenPtInterSigDurValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtInterSigDurValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtInterSigDurValOrDefSeq =
{
   4,
   mgMgcoSigOtherToneGenPtInterSigDurValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtInterSigDurValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 259,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherToneGenPtInterSigDurValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtInterSigDurValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValDef,
   &cmMsgDefMetaColon,
   &mgMgcoSigOtherToneGenPtInterSigDurValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherToneGenPtInterSigDurValRngDefSeq =
{
   6,
   mgMgcoSigOtherToneGenPtInterSigDurValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtInterSigDurValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 260,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoSigOtherToneGenPtInterSigDurValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtInterSigDurDefChcElmnts[] =
{
   &mgMgcoSigOtherToneGenPtInterSigDurValEqDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValGtDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValLtDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValNeDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValAndDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValOrDef,
   &mgMgcoSigOtherToneGenPtInterSigDurValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigOtherToneGenPtInterSigDurDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoSigOtherToneGenPtInterSigDurDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtInterSigDurDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherToneGenPtInterSigDur",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 261,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigOtherToneGenPtInterSigDurDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};


PUBLIC CmAbnfElmTypeEnum mgMgcoSigOtherToneGenPtToneIdLstEnum =
{
   (Data *)"tl",
   MGT_PKG_TONEGEN_SIG_PT_TONEIDLST
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtToneIdLstEnumDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherToneGenPtToneIdLstEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 262,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSigOtherToneGenPtToneIdLstEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoSigOtherToneGenPtInterSigDurEnum =
{
   (Data *)"ind",
   MGT_PKG_TONEGEN_SIG_PT_INTERSIGDURATION
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtInterSigDurEnumDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherToneGenPtInterSigDurEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 263,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSigOtherToneGenPtInterSigDurEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoSigOtherToneGenPtToneIdLstDef,
   &mgMgcoSigOtherToneGenPtInterSigDurDef
};

PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtParDefChcEnum[] =
{
   NULLP,
   &mgMgcoSigOtherToneGenPtToneIdLstEnumDef,
   &mgMgcoSigOtherToneGenPtInterSigDurEnumDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigOtherToneGenPtParDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigOtherToneGenPtParDefChcElmnts,
   mgMgcoSigOtherToneGenPtParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtParDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherToneGenPtPar",
   "SigOtherToneGenPtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 264,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigOtherToneGenPtParDefChc,
   mgMgcoRegExpSigOtherToneGenPtPar
};


PUBLIC CmAbnfElmDef *mgMgcoSigOtherToneGenPtDefChcElmnts[] =
{
   &mgMgcoSigOtherUnknownDef,
   &mgMgcoSigOtherSkipAllDef,
   &mgMgcoSigOtherToneGenPtParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigOtherToneGenPtDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigOtherToneGenPtDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherToneGenPtDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherToneGenPt",
   "SigOtherToneGenPt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 265,
   sizeof(MgMgcoSigOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigOtherToneGenPtDefChc,
   mgMgcoRegExpSigOtherToneGenPt
};

PUBLIC CmAbnfElmDef *mgMgcoSignalToneGenPtParmDefChcElmnts[] =
{
   &mgMgcoSigOtherToneGenPtDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoSigTypeDef,
   &mgMgcoSigDurationDef,
   &mgMgcoSigNtfyCmplDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalToneGenPtParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoSignalToneGenPtParmDefChcElmnts,
   mgMgcoSigParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalToneGenPtParmDef =
{
#ifdef CM_ABNF_DBG
   "SignalToneGenPt - parameter",
   "SigPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 266,
   sizeof(MgMgcoSigPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalToneGenPtParmDefChc,
   mgMgcoRegExpSigPar
};

PUBLIC CmAbnfElmDef *mgMgcoSignalToneGenPtParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoSignalToneGenPtParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoSignalToneGenPtParmArrayDefSeqOf =
{
   1,
   MGT_MAX_SIGPARS,
   2,
   mgMgcoSignalToneGenPtParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoSigPar)
};

PUBLIC CmAbnfElmDef mgMgcoSignalToneGenPtParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "SignalToneGenPt - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 267,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoSignalToneGenPtParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoSignalToneGenPtParmLstDefSeqElmnts[] =
{
   &mgMgcoSignalToneGenPtParmDef,
   &mgMgcoSignalToneGenPtParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalToneGenPtParmLstDefSeq =
{
   2,
   mgMgcoSignalToneGenPtParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalToneGenPtParmLstDef =
{
#ifdef CM_ABNF_DBG
   "SignalToneGenPt - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 268,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoSignalToneGenPtParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSignalToneGenPtDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoSignalToneGenPtParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalToneGenPtDefSeq =
{
   3,
   mgMgcoSignalToneGenPtDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalToneGenPtDef =
{
#ifdef CM_ABNF_DBG
   "ToneGenPt - signal parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 269,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoSignalToneGenPtDefSeq,
   mgMgcoRegExpLBRKT
};

PUBLIC CmAbnfElmTypeEnum mgMgcoSignalToneGenPtEnum =
{
   (Data *)"pt",
   MGT_PKG_TONEGEN_SIG_PT
};

PUBLIC CmAbnfElmDef mgMgcoSignalToneGenPtEnumDef =
{
#ifdef CM_ABNF_DBG
   "SignalToneGenPtEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 270,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSignalToneGenPtEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSignalToneGenRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoSignalToneGenPtDef
};

PUBLIC CmAbnfElmDef *mgMgcoSignalToneGenRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoSignalToneGenPtEnumDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalToneGenRealDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoSignalToneGenRealDefChcElmnts,
   mgMgcoSignalToneGenRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalToneGenRealDef =
{
#ifdef CM_ABNF_DBG
   "Real signal - package ToneGen",
   "SigNameToneGen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 271,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalToneGenRealDefChc,
   mgMgcoRegExpSigNameToneGen
};

PUBLIC CmAbnfElmDef *mgMgcoSignalToneGenChcDefChcElmnts[] =
{
   &mgMgcoSignalUnknownDef,
   &mgMgcoSignalSkipAllDef,
   &mgMgcoSignalToneGenRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalToneGenChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSignalToneGenChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalToneGenChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of signals in package ToneGen",
   "PkgToneGenSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 272,
   sizeof(MgMgcoName) + sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalToneGenChcDefChc,
   mgMgcoRegExpPkgToneGenSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSignalToneGenDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSignalToneGenChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalToneGenDefSeq =
{
   3,
   mgMgcoSignalToneGenDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalToneGenDef =
{
#ifdef CM_ABNF_DBG
   "Signal request - package ToneGen",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 273,
   sizeof(MgMgcoSignalsReq) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSignalToneGenDefSeq,
   NULLP
};
#endif /* (defined(GCP_PKG_MGCO_TONEGEN) || defined(GCP_PKG_MGCO_DTMFGEN)
        || defined(GCP_PKG_MGCO_CPGEN)  || defined(GCP_PKG_MGCO_TONEDET)
        || defined(GCP_PKG_MGCO_DTMFDET) || defined(GCP_PKG_MGCO_CPDET) ||
           defined(GCP_PKG_MGCO_BSC_CAL_TN)  
           defined(GCP_PKG_MGCO_XD_CALPG_TNGN) ||
           defined(GCP_PKG_MGCO_BSC_SRV_TN) || 
           defined(GCP_PKG_MGCO_XD_SRV_TNGN)|| 
           defined(GCP_PKG_MGCO_INT_TNGN) || 
           defined(GCP_PKG_MGCO_BSNS_TNGN) ||
           defined(GCP_PKG_MGCO_TRIG_XD_CALPG_TNGN) ||
           defined(GCP_PKG_MGCO_TRIG_FLEX_TN) || 
           defined(GCP_PKG_MGCO_CONF_TN) ||
           defined(GCP_PKG_MGCO_TEST) ||
           defined(GCP_PKG_MGCO_CARR_TN) ||
           defined(GCP_PKG_MGCO_MFQ_TN_GEN)) */
 
/*
 * [TEL2]: Added compilation flags for all the extended packages extending
 * Tonedet package.
 */
#if (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) || \
     defined(GCP_PKG_MGCO_CPDET) || defined(GCP_PKG_MGCO_MFQ_TN_DET))
/************************************************************************

                  Package - Tone Detection (tonedet) (0x0004)

************************************************************************/

/************************************************************************
                        Properties - None
************************************************************************/

/************************************************************************
                           Events
************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEventToneDetStdEnum =
{
   (Data *)"std",
   MGT_PKG_TONEDET_EVT_STD
};

PUBLIC CmAbnfElmDef mgMgcoEventToneDetStdEnumDef =
{
#ifdef CM_ABNF_DBG
   "EventToneDetStdEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */   
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 274,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventToneDetStdEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEventToneDetEtdEnum =
{
   (Data *)"etd",
   MGT_PKG_TONEDET_EVT_ETD
};

PUBLIC CmAbnfElmDef mgMgcoEventToneDetEtdEnumDef =
{
#ifdef CM_ABNF_DBG
   "EventToneDetEtdEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */   
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 275,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventToneDetEtdEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEventToneDetLtdEnum =
{
   (Data *)"ltd",
   MGT_PKG_TONEDET_EVT_LTD
};

PUBLIC CmAbnfElmDef mgMgcoEventToneDetLtdEnumDef =
{
#ifdef CM_ABNF_DBG
   "EventToneDetLtdEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */   
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 276,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventToneDetLtdEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEventToneDetRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoEventToneDetStdEnumDef,
   &mgMgcoEventToneDetEtdEnumDef,
   &mgMgcoEventToneDetLtdEnumDef
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherToneDetStdParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoSigOtherToneGenPtToneIdLstDef
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherToneDetStdParDefChcEnum[] =
{
   NULLP,
   &mgMgcoSigOtherToneGenPtToneIdLstEnumDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherToneDetStdParDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoReqEvtOtherToneDetStdParDefChcElmnts,
   mgMgcoReqEvtOtherToneDetStdParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherToneDetStdParDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherToneDetStdPar",
   "ReqEvtOtherToneDetStdPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 277,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherToneDetStdParDefChc,
   mgMgcoRegExpReqEvtOtherToneDetStdPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherToneDetStdDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoReqEvtOtherToneDetStdParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherToneDetStdDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtOtherToneDetStdDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherToneDetStdDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherToneDetStd",
   "ReqEvtOtherToneDetStdType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 278,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherToneDetStdDefChc,
   mgMgcoRegExpReqEvtOtherToneDetStdType
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoObsEvtOtherToneDetStdTidEnum =
{
   (Data *)"tid",
   MGT_PKG_TONEDET_EVT_STD_TID
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherToneDetStdTidEnumDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherToneDetStdTidEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 279,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoObsEvtOtherToneDetStdTidEnum,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherToneDetStdParDefChcEnum[] =
{
   NULLP, NULLP, NULLP, 
   &mgMgcoObsEvtOtherToneDetStdTidEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherToneDetStdParDefChcElmnts[] =
{
   &mgMgcoSigOtherToneGenPtToneIdLstDef
};

PUBLIC U8 mgMgcoObsEvtOtherToneDetStdParDefChcIdx[] = {0, 0, 0, 0};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherToneDetStdParDefChc =
{
   1,
   4,
   mgMgcoObsEvtOtherToneDetStdParDefChcIdx,
   mgMgcoObsEvtOtherToneDetStdParDefChcElmnts,
   mgMgcoObsEvtOtherToneDetStdParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherToneDetStdParDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherToneDetStdPar",
   "ObsEvtOtherToneDetStdPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 280,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherToneDetStdParDefChc,
   mgMgcoRegExpObsEvtOtherToneDetStdPar
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherToneDetStdDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoObsEvtOtherToneDetStdParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherToneDetStdDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherToneDetStdDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherToneDetStdDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherToneDetStd",
   "ObsEvtOtherToneDetStdType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 281,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherToneDetStdDefChc,
   mgMgcoRegExpObsEvtOtherToneDetStdType
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecToneDetStdParmDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherToneDetStdDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecToneDetStdParmDefChc =
{
   5,
   6,         
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecToneDetStdParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecToneDetStdParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecToneDetStd - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 282,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecToneDetStdParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecToneDetStdParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecToneDetStdParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecToneDetStdParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecToneDetStdParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecToneDetStdParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecToneDetStd - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 283,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecToneDetStdParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecToneDetStdParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecToneDetStdParmDef,
   &mgMgcoEvtSecToneDetStdParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecToneDetStdParmLstDefSeq =
{
   2,
   mgMgcoEvtSecToneDetStdParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecToneDetStdParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecToneDetStd - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 284,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecToneDetStdParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecToneDetStdDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecToneDetStdParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecToneDetStdDefSeq =
{
   3,
   mgMgcoEvtSecToneDetStdDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecToneDetStdDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecToneDetStd - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 285,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecToneDetStdDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoReqEvtOtherToneDetLtdDurEnum =
{
   (Data *)"dur",
   MGT_PKG_TONEDET_EVT_LTD_DUR
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherToneDetLtdDurEnumDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherToneDetLtdDurEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 286,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoReqEvtOtherToneDetLtdDurEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherToneDetLtdParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoSigOtherToneGenPtToneIdLstDef,
   &mgMgcoSigOtherToneGenPtInterSigDurDef,
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherToneDetLtdParDefChcEnum[] =
{
   NULLP,
   &mgMgcoSigOtherToneGenPtToneIdLstEnumDef,
   &mgMgcoReqEvtOtherToneDetLtdDurEnumDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherToneDetLtdParDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtOtherToneDetLtdParDefChcElmnts,
   mgMgcoReqEvtOtherToneDetLtdParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherToneDetLtdParDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherToneDetLtdPar",
   "ReqEvtOtherToneDetLtdPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 287,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherToneDetLtdParDefChc,
   mgMgcoRegExpReqEvtOtherToneDetLtdPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherToneDetLtdDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoReqEvtOtherToneDetLtdParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherToneDetLtdDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtOtherToneDetLtdDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherToneDetLtdDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherToneDetLtd",
   "ReqEvtOtherToneDetLtdType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 288,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherToneDetLtdDefChc,
   mgMgcoRegExpReqEvtOtherToneDetLtdType
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecToneDetLtdParmDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherToneDetLtdDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecToneDetLtdParmDefChc =
{
   5,
   6,          
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecToneDetLtdParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecToneDetLtdParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecToneDetLtd - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 289,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecToneDetLtdParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecToneDetLtdParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecToneDetLtdParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecToneDetLtdParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecToneDetLtdParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecToneDetLtdParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecToneDetLtd - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 290,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecToneDetLtdParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecToneDetLtdParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecToneDetLtdParmDef,
   &mgMgcoEvtSecToneDetLtdParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecToneDetLtdParmLstDefSeq =
{
   2,
   mgMgcoEvtSecToneDetLtdParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecToneDetLtdParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecToneDetLtd - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 291,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecToneDetLtdParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecToneDetLtdDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecToneDetLtdParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecToneDetLtdDefSeq =
{
   3,
   mgMgcoEvtSecToneDetLtdDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecToneDetLtdDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecToneDetLtd - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 292,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecToneDetLtdDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecToneDetRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecToneDetStdDef,
   &mgMgcoEvtSecToneDetStdDef,
   &mgMgcoEvtSecToneDetLtdDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecToneDetRealDefChc =
{
   4,
   0,
   NULLP,
   mgMgcoEvtSecToneDetRealDefChcElmnts,
   mgMgcoEventToneDetRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecToneDetRealDef =
{
#ifdef CM_ABNF_DBG
   "Real second requested event - package ToneDet",
   "EvtNameToneDet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 293,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecToneDetRealDefChc,
   mgMgcoRegExpEvtNameToneDet
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecToneDetChcDefChcElmnts[] =
{
   &mgMgcoEvtSecUnknownNameDef,
   &mgMgcoEvtSecSkipAllDef,
   &mgMgcoEvtSecToneDetRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecToneDetChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtSecToneDetChcDefChcElmnts,
   mgMgcoGenTypeEnum 
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecToneDetChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of second req event in package ToneDet",
   "PkgToneDetEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 294,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecToneDetChcDefChc,
   mgMgcoRegExpPkgToneDetEvtType
};

/* Second requested event */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecToneDetDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvtSecToneDetChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecToneDetDefSeq =
{
   3,
   mgMgcoEvtSecToneDetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecToneDetDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - package ToneDet",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 295,
   sizeof(MgMgcoEvtSec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecToneDetDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecToneDetStdParmDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherToneDetStdDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecToneDetStdParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecToneDetStdParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecToneDetStdParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecToneDetStd - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 296,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecToneDetStdParmDefChc,
   mgMgcoRegExpEvtPar
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecToneDetStdParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecToneDetStdParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecToneDetStdParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecToneDetStdParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecToneDetStdParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecToneDetStd - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 297,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecToneDetStdParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecToneDetStdParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecToneDetStdParmDef,
   &mgMgcoEvSpecToneDetStdParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecToneDetStdParmLstDefSeq =
{
   2,
   mgMgcoEvSpecToneDetStdParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecToneDetStdParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecToneDetStd - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 298,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecToneDetStdParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecToneDetStdDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecToneDetStdParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecToneDetStdDefSeq =
{
   3,
   mgMgcoEvSpecToneDetStdDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecToneDetStdDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecToneDetStd - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 299,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecToneDetStdDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherToneDetEtdParDefChcEnum[] =
{
   NULLP, NULLP, 
   &mgMgcoReqEvtOtherToneDetLtdDurEnumDef,
   &mgMgcoObsEvtOtherToneDetStdTidEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherToneDetEtdParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoSigOtherToneGenPtInterSigDurDef,
   &mgMgcoSigOtherToneGenPtToneIdLstDef
};

PUBLIC U8 mgMgcoObsEvtOtherToneDetEtdParDefChcIdx[] = {0, 0, 1, 2 }; 

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherToneDetEtdParDefChc =
{
   3,
   4,
   mgMgcoObsEvtOtherToneDetEtdParDefChcIdx,
   mgMgcoObsEvtOtherToneDetEtdParDefChcElmnts,
   mgMgcoObsEvtOtherToneDetEtdParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherToneDetEtdParDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherToneDetEtdPar",
   "ObsEvtOtherToneDetEtdPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 300,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherToneDetEtdParDefChc,
   mgMgcoRegExpObsEvtOtherToneDetEtdPar
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherToneDetEtdDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoObsEvtOtherToneDetEtdParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherToneDetEtdDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherToneDetEtdDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherToneDetEtdDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherToneDetEtd",
   "ObsEvtOtherToneDetEtdType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 301,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherToneDetEtdDefChc,
   mgMgcoRegExpObsEvtOtherToneDetEtdType
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecToneDetEtdParmDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherToneDetEtdDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecToneDetEtdParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecToneDetEtdParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecToneDetEtdParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecToneDetEtd - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 302,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecToneDetEtdParmDefChc,
   mgMgcoRegExpEvtPar
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecToneDetEtdParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecToneDetEtdParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecToneDetEtdParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecToneDetEtdParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecToneDetEtdParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecToneDetEtd - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 303,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecToneDetEtdParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecToneDetEtdParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecToneDetEtdParmDef,
   &mgMgcoEvSpecToneDetEtdParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecToneDetEtdParmLstDefSeq =
{
   2,
   mgMgcoEvSpecToneDetEtdParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecToneDetEtdParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecToneDetEtd - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 304,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecToneDetEtdParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecToneDetEtdDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecToneDetEtdParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecToneDetEtdDefSeq =
{
   3,
   mgMgcoEvSpecToneDetEtdDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecToneDetEtdDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecToneDetEtd - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 305,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecToneDetEtdDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecToneDetRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecToneDetStdDef,
   &mgMgcoEvSpecToneDetEtdDef,
   &mgMgcoEvSpecToneDetStdDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecToneDetRealDefChc =
{
   4,
   0,
   NULLP,
   mgMgcoEvSpecToneDetRealDefChcElmnts,
   mgMgcoEventToneDetRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecToneDetRealDef =
{
#ifdef CM_ABNF_DBG
   "Real event spec -  package ToneDet",
   "EvtNameToneDet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 306,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecToneDetRealDefChc,
   mgMgcoRegExpEvtNameToneDet
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecToneDetChcDefChcElmnts[] =
{
   &mgMgcoEvSpecUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoEvSpecToneDetRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecToneDetChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecToneDetChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecToneDetChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of event spec in package ToneDet",
   "PkgToneDetEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 307,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecToneDetChcDefChc,
   mgMgcoRegExpPkgToneDetEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecToneDetDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvSpecToneDetChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecToneDetDefSeq =
{
   3,
   mgMgcoEvSpecToneDetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecToneDetDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - package ToneDet",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 308,
   sizeof(MgMgcoEvSpec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecToneDetDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtToneDetStdParmDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherToneDetStdDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtToneDetStdParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtToneDetStdParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtToneDetStdParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtToneDetStd - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 309,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtToneDetStdParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtToneDetStdParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtToneDetStdParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtToneDetStdParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtToneDetStdParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtToneDetStdParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtToneDetStd - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 310,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtToneDetStdParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtToneDetStdParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtToneDetStdParmDef,
   &mgMgcoReqEvtToneDetStdParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtToneDetStdParmLstDefSeq =
{
   2,
   mgMgcoReqEvtToneDetStdParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtToneDetStdParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtToneDetStd - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 311,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtToneDetStdParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtToneDetStdDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtToneDetStdParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtToneDetStdDefSeq =
{
   3,
   mgMgcoReqEvtToneDetStdDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtToneDetStdDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtToneDetStd - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 312,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtToneDetStdDefSeq,
   mgMgcoRegExpLBRKT
};


PUBLIC CmAbnfElmDef *mgMgcoReqEvtToneDetLtdParmDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherToneDetLtdDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtToneDetLtdParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtToneDetLtdParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtToneDetLtdParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtToneDetLtd - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 313,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtToneDetLtdParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtToneDetLtdParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtToneDetLtdParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtToneDetLtdParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtToneDetLtdParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtToneDetLtdParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtToneDetLtd - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 314,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtToneDetLtdParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtToneDetLtdParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtToneDetLtdParmDef,
   &mgMgcoReqEvtToneDetLtdParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtToneDetLtdParmLstDefSeq =
{
   2,
   mgMgcoReqEvtToneDetLtdParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtToneDetLtdParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtToneDetLtd - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 315,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtToneDetLtdParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtToneDetLtdDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtToneDetLtdParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtToneDetLtdDefSeq =
{
   3,
   mgMgcoReqEvtToneDetLtdDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtToneDetLtdDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtToneDetLtd - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 316,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtToneDetLtdDefSeq,
   mgMgcoRegExpLBRKT
};


/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtToneDetRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtToneDetStdDef,
   &mgMgcoReqEvtToneDetStdDef,
   &mgMgcoReqEvtToneDetLtdDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtToneDetRealDefChc =
{
   4,
   0,
   NULLP,
   mgMgcoReqEvtToneDetRealDefChcElmnts,
   mgMgcoEventToneDetRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtToneDetRealDef =
{
#ifdef CM_ABNF_DBG
   "Real requested event - package ToneDet",
   "EvtNameToneDet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 317,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtToneDetRealDefChc,
   mgMgcoRegExpEvtNameToneDet
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtToneDetChcDefChcElmnts[] =
{
   &mgMgcoReqEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoReqEvtToneDetRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtToneDetChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtToneDetChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtToneDetChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of requested event in package ToneDet",
   "PkgToneDetEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 318,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtToneDetChcDefChc,
   mgMgcoRegExpPkgToneDetEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtToneDetDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoReqEvtToneDetChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtToneDetDefSeq =
{
   3,
   mgMgcoReqEvtToneDetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtToneDetDef =
{
#ifdef CM_ABNF_DBG
   "Requested event - package ToneDet",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 319,
   sizeof(MgMgcoReqEvt) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtToneDetDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtToneDetRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecToneDetStdDef,
   &mgMgcoEvSpecToneDetEtdDef,
   &mgMgcoEvSpecToneDetStdDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtToneDetRealDefChc =
{
   4,
   0,
   NULLP,
   mgMgcoObsEvtToneDetRealDefChcElmnts,
   mgMgcoEventToneDetRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtToneDetRealDef =
{
#ifdef CM_ABNF_DBG
   "Real observed event - package ToneDet",
   "EvtNameToneDet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 320,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtToneDetRealDefChc,
   mgMgcoRegExpEvtNameToneDet
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtToneDetChcDefChcElmnts[] =
{
   &mgMgcoObsEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoObsEvtToneDetRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtToneDetChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtToneDetChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtToneDetChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of observed event in package ToneDet",
   "PkgToneDetEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 321,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtToneDetChcDefChc,
   mgMgcoRegExpPkgToneDetEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtToneDetDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoObsEvtToneDetChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtToneDetDefSeq =
{
   3,
   mgMgcoObsEvtToneDetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtToneDetDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - package ToneDet",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 322,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtToneDetDefSeq,
   NULLP
};

/************************************************************************
                        Signals - None
************************************************************************/

/************************************************************************
                        Statistics - None
************************************************************************/
#endif /* (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) 
        || defined(GCP_PKG_MGCO_CPDET) || defined(GCP_PKG_MGCO_MFQ_TN_DET)) */

#ifdef GCP_PKG_MGCO_DTMFGEN
/************************************************************************

               Package - Basic DTMF Generator (dg) (0x0005)

************************************************************************/

/************************************************************************
                        Properties - none
************************************************************************/

/************************************************************************
                          Events - None
************************************************************************/

/************************************************************************
                              Signals
************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoSignalDtmfGen_dxParmDefChcElmnts[] =
{
   NULLP,   /* No additional parameters */
   &mgMgcoEvtStreamDef,
   &mgMgcoSigTypeDef,
   &mgMgcoSigDurationDef,
   &mgMgcoSigNtfyCmplDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalDtmfGen_dxParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoSignalDtmfGen_dxParmDefChcElmnts,
   mgMgcoSigParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalDtmfGen_dxParmDef =
{
#ifdef CM_ABNF_DBG
   "SignalDtmfGen_dx - parameter",
   "SigPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 323,
   sizeof(MgMgcoSigPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalDtmfGen_dxParmDefChc,
   mgMgcoRegExpSigPar
};

PUBLIC CmAbnfElmDef *mgMgcoSignalDtmfGen_dxParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoSignalDtmfGen_dxParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoSignalDtmfGen_dxParmArrayDefSeqOf =
{
   1,
   MGT_MAX_SIGPARS,
   2,
   mgMgcoSignalDtmfGen_dxParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoSigPar)
};

PUBLIC CmAbnfElmDef mgMgcoSignalDtmfGen_dxParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "SignalDtmfGen_dx - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 324,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoSignalDtmfGen_dxParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoSignalDtmfGen_dxParmLstDefSeqElmnts[] =
{
   &mgMgcoSignalDtmfGen_dxParmDef,
   &mgMgcoSignalDtmfGen_dxParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalDtmfGen_dxParmLstDefSeq =
{
   2,
   mgMgcoSignalDtmfGen_dxParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalDtmfGen_dxParmLstDef =
{
#ifdef CM_ABNF_DBG
   "SignalDtmfGen_dx - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 325,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoSignalDtmfGen_dxParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSignalDtmfGen_dxDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoSignalDtmfGen_dxParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalDtmfGen_dxDefSeq =
{
   3,
   mgMgcoSignalDtmfGen_dxDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalDtmfGen_dxDef =
{
#ifdef CM_ABNF_DBG
   "DtmfGen_dx - signal parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 326,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoSignalDtmfGen_dxDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoSignalDtmfGenRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoSignalToneGenPtDef,
   &mgMgcoSignalDtmfGen_dxDef
};

PUBLIC CmAbnfElmDef *mgMgcoSignalDtmfGenRealDefChcEnum[] =
{
   /* 0x00 */     NULLP,
   /* 0x01 */     &mgMgcoSignalToneGenPtEnumDef,
   /* 0x02 */     NULLP,
   /* 0x03 */     NULLP,
   /* 0x04 */     NULLP,
   /* 0x05 */     NULLP,
   /* 0x06 */     NULLP,
   /* 0x07 */     NULLP,
   /* 0x08 */     NULLP,
   /* 0x09 */     NULLP,
   /* 0x0a */     NULLP,
   /* 0x0b */     NULLP,
   /* 0x0c */     NULLP,
   /* 0x0d */     NULLP,
   /* 0x0e */     NULLP,
   /* 0x0f */     NULLP,
   /* 0x10 */     &mgMgcoToneId_d0EnumDef,
   /* 0x11 */     &mgMgcoToneId_d1EnumDef,
   /* 0x12 */     &mgMgcoToneId_d2EnumDef,
   /* 0x13 */     &mgMgcoToneId_d3EnumDef,
   /* 0x14 */     &mgMgcoToneId_d4EnumDef,
   /* 0x15 */     &mgMgcoToneId_d5EnumDef,
   /* 0x16 */     &mgMgcoToneId_d6EnumDef,
   /* 0x17 */     &mgMgcoToneId_d7EnumDef,
   /* 0x18 */     &mgMgcoToneId_d8EnumDef,
   /* 0x19 */     &mgMgcoToneId_d9EnumDef,
   /* 0x1a */     &mgMgcoToneId_daEnumDef,
   /* 0x1b */     &mgMgcoToneId_dbEnumDef,
   /* 0x1c */     &mgMgcoToneId_dcEnumDef,
   /* 0x1d */     &mgMgcoToneId_ddEnumDef,
   /* 0x1e */     NULLP,
   /* 0x1f */     NULLP,
   /* 0x20 */     &mgMgcoToneId_dsEnumDef,
   /* 0x21 */     &mgMgcoToneId_doEnumDef,
};

PUBLIC U8 mgMgcoSignalDtmfGenRealDefChcIdx[] =
{
    0,  1,  0,  0,  0,  0,  0,  0,  0,  0,   /* 0        -     9 */
    0,  0,  0,  0,  0,  0,  2,  2,  2,  2,   /* 10(0x0a) - 19(0x13) */
    2,  2,  2,  2,  2,  2,  2,  2,  2,  2,   /* 20(0x14) - 29(0x1d) */
    0,  0,  2,  2                            /* 30(0x1e) - 33(0x21) */
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalDtmfGenRealDefChc =
{
   3,
   34,
   mgMgcoSignalDtmfGenRealDefChcIdx,
   mgMgcoSignalDtmfGenRealDefChcElmnts,
   mgMgcoSignalDtmfGenRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalDtmfGenRealDef =
{
#ifdef CM_ABNF_DBG
   "Real signal - package DtmfGen",
   "SigNameDtmfGen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 327,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalDtmfGenRealDefChc,
   mgMgcoRegExpSigNameDtmfGen
};

PUBLIC CmAbnfElmDef *mgMgcoSignalDtmfGenChcDefChcElmnts[] =
{
   &mgMgcoSignalUnknownDef,
   &mgMgcoSignalSkipAllDef,
   &mgMgcoSignalDtmfGenRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalDtmfGenChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSignalDtmfGenChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalDtmfGenChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of signals in package DtmfGen",
   "PkgDtmfGenSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 328,
   sizeof(MgMgcoName) + sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalDtmfGenChcDefChc,
   mgMgcoRegExpPkgDtmfGenSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSignalDtmfGenDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSignalDtmfGenChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalDtmfGenDefSeq =
{
   3,
   mgMgcoSignalDtmfGenDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalDtmfGenDef =
{
#ifdef CM_ABNF_DBG
   "Signal request - package DtmfGen",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 329,
   sizeof(MgMgcoSignalsReq) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSignalDtmfGenDefSeq,
   NULLP
};

/************************************************************************
                        Statistics - None
************************************************************************/
#endif /* GCP_PKG_MGCO_DTMFGEN */

#ifdef GCP_PKG_MGCO_DTMFDET 
/************************************************************************

               Package - Basic DTMF detection (dd) (0x0006)

************************************************************************/

/************************************************************************
                        Properties - None
************************************************************************/

/************************************************************************
                              Events
************************************************************************/

PUBLIC CmAbnfElmTypeRange mgMgcoObsEvtOtherDtmfDetCeDigitStringValueRng =
{
   2,
   0xFFFF
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDigitStringValue =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherDtmfDetCeDigitStringValue",
   "ObsEvtOtherDtmfDetCeDigitStringValue",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 330,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDigitStringValueRng,
   mgMgcoRegExpObsEvtOtherDtmfDetCeDigitStringValue
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeDigitStringValDefChcElmnts[] =
{
   NULLP, NULLP, NULLP,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValue,
   NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherDtmfDetCeDigitStringValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoObsEvtOtherDtmfDetCeDigitStringValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDigitStringValDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherDtmfDetCeDigitStringVal",
   "ParmValOctStrXL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 331,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDigitStringValDefChc,
   mgMgcoRegExpParmValOctStrXL
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeDigitStringValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeDigitStringValEqDefSeq =
{
   2,
   mgMgcoObsEvtOtherDtmfDetCeDigitStringValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDigitStringValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 332,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDigitStringValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeDigitStringValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeDigitStringValGtDefSeq =
{
   2,
   mgMgcoObsEvtOtherDtmfDetCeDigitStringValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDigitStringValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 333,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,   
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDigitStringValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeDigitStringValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeDigitStringValLtDefSeq =
{
   2,
   mgMgcoObsEvtOtherDtmfDetCeDigitStringValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDigitStringValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 334,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDigitStringValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeDigitStringValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeDigitStringValNeDefSeq =
{
   2,
   mgMgcoObsEvtOtherDtmfDetCeDigitStringValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDigitStringValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 335,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDigitStringValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeDigitStringValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoObsEvtOtherDtmfDetCeDigitStringValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoObsEvtOtherDtmfDetCeDigitStringValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDigitStringValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 336,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDigitStringValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeDigitStringValLstDefSeqElmnts[]   =
{
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeDigitStringValLstDefSeq =
{
   2,
   mgMgcoObsEvtOtherDtmfDetCeDigitStringValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDigitStringValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 337,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDigitStringValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeDigitStringValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeDigitStringValAndDefSeq =
{
   4,
   mgMgcoObsEvtOtherDtmfDetCeDigitStringValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDigitStringValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 338,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDigitStringValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeDigitStringValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeDigitStringValOrDefSeq =
{
   4,
   mgMgcoObsEvtOtherDtmfDetCeDigitStringValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDigitStringValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 339,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDigitStringValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeDigitStringValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValDef,
   &cmMsgDefMetaColon,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeDigitStringValRngDefSeq =
{
   6,
   mgMgcoObsEvtOtherDtmfDetCeDigitStringValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDigitStringValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 340,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDigitStringValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeDigitStringDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValEqDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValGtDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValLtDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValNeDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValAndDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValOrDef,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherDtmfDetCeDigitStringDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoObsEvtOtherDtmfDetCeDigitStringDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDigitStringDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherDtmfDetCeDigitString",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 341,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDigitStringDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDtmfDetCeTermMethUMEnum =
{
   (Data *)"UM",
   MGT_PKG_DTMFDET_EVT_CE_METH_UM
};

PUBLIC CmAbnfElmDef mgMgcoDtmfDetCeTermMethUMEnumDef =
{
#ifdef CM_ABNF_DBG
   "DtmfDetCeTermMeth - UM enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 342,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDtmfDetCeTermMethUMEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDtmfDetCeTermMethPMEnum =
{
   (Data *)"PM",
   MGT_PKG_DTMFDET_EVT_CE_METH_PM
};

PUBLIC CmAbnfElmDef mgMgcoDtmfDetCeTermMethPMEnumDef =
{
#ifdef CM_ABNF_DBG
   "DtmfDetCeTermMeth - PM enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 343,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDtmfDetCeTermMethPMEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoDtmfDetCeTermMethFMEnum =
{
   (Data *)"FM",
   MGT_PKG_DTMFDET_EVT_CE_METH_FM
};

PUBLIC CmAbnfElmDef mgMgcoDtmfDetCeTermMethFMEnumDef =
{
#ifdef CM_ABNF_DBG
   "DtmfDetCeTermMeth - FM enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 344,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoDtmfDetCeTermMethFMEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeTermMethValueChcEnum[] =
{
   NULLP,
   &mgMgcoDtmfDetCeTermMethUMEnumDef,
   &mgMgcoDtmfDetCeTermMethPMEnumDef,
   &mgMgcoDtmfDetCeTermMethFMEnumDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherDtmfDetCeTermMethValueChc =
{
   4,
   0,
   NULLP,
   NULLP,
   mgMgcoObsEvtOtherDtmfDetCeTermMethValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeTermMethValue =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherDtmfDetCeTermMethValue",
   "ObsEvtOtherDtmfDetCeTermMethValue",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 345,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeTermMethValueChc,
   mgMgcoRegExpObsEvtOtherDtmfDetCeTermMethValue
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeTermMethValDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherDtmfDetCeTermMethValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoObsEvtOtherDtmfDetCeTermMethValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeTermMethValDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherDtmfDetCeTermMethVal",
   "ParmValEnume",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 346,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeTermMethValDefChc,
   mgMgcoRegExpParmValEnume
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeTermMethValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeTermMethValEqDefSeq =
{
   2,
   mgMgcoObsEvtOtherDtmfDetCeTermMethValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeTermMethValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 347,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeTermMethValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeTermMethValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeTermMethValGtDefSeq =
{
   2,
   mgMgcoObsEvtOtherDtmfDetCeTermMethValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeTermMethValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 348,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeTermMethValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeTermMethValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeTermMethValLtDefSeq =
{
   2,
   mgMgcoObsEvtOtherDtmfDetCeTermMethValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeTermMethValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 349,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeTermMethValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeTermMethValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeTermMethValNeDefSeq =
{
   2,
   mgMgcoObsEvtOtherDtmfDetCeTermMethValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeTermMethValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 350,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeTermMethValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeTermMethValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoObsEvtOtherDtmfDetCeTermMethValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoObsEvtOtherDtmfDetCeTermMethValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeTermMethValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 351,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeTermMethValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeTermMethValLstDefSeqElmnts[]   =
{
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeTermMethValLstDefSeq =
{
   2,
   mgMgcoObsEvtOtherDtmfDetCeTermMethValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeTermMethValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 352,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeTermMethValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeTermMethValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeTermMethValAndDefSeq =
{
   4,
   mgMgcoObsEvtOtherDtmfDetCeTermMethValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeTermMethValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 353,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeTermMethValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeTermMethValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeTermMethValOrDefSeq =
{
   4,
   mgMgcoObsEvtOtherDtmfDetCeTermMethValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeTermMethValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 354,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeTermMethValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeTermMethValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValDef,
   &cmMsgDefMetaColon,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherDtmfDetCeTermMethValRngDefSeq =
{
   6,
   mgMgcoObsEvtOtherDtmfDetCeTermMethValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeTermMethValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 355,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeTermMethValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeTermMethDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValEqDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValGtDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValLtDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValNeDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValAndDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValOrDef,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherDtmfDetCeTermMethDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoObsEvtOtherDtmfDetCeTermMethDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeTermMethDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherDtmfDetCeTermMeth",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 356,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeTermMethDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoObsEvtOtherDtmfDetCeDigitStringEnum =
{
   (Data *)"ds",
   MGT_PKG_DTMFDET_EVT_CE_DS
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDigitStringEnumDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherDtmfDetCeDigitStringEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 357,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDigitStringEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoObsEvtOtherDtmfDetCeTermMethEnum =
{
   (Data *)"Meth",
   MGT_PKG_DTMFDET_EVT_CE_METH
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeTermMethEnumDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherDtmfDetCeTermMethEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 358,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeTermMethEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringDef,
   NULLP,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethDef
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeParDefChcEnum[] =
{
   NULLP,
   &mgMgcoObsEvtOtherDtmfDetCeDigitStringEnumDef,
   NULLP,
   &mgMgcoObsEvtOtherDtmfDetCeTermMethEnumDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherDtmfDetCeParDefChc =
{
   4,
   0,
   NULLP,
   mgMgcoObsEvtOtherDtmfDetCeParDefChcElmnts,
   mgMgcoObsEvtOtherDtmfDetCeParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeParDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherDtmfDetCePar",
   "ObsEvtOtherDtmfDetCePar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 359,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeParDefChc,
   mgMgcoRegExpObsEvtOtherDtmfDetCePar
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherDtmfDetCeDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoObsEvtOtherDtmfDetCeParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherDtmfDetCeDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherDtmfDetCeDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherDtmfDetCeDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherDtmfDetCe",
   "ObsEvtOtherDtmfDetCeType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 360,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherDtmfDetCeDefChc,
   mgMgcoRegExpObsEvtOtherDtmfDetCeType
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecDtmfDetCeParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecDtmfDetCeParmDefChc =
{
   5,
   6,      
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecDtmfDetCeParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecDtmfDetCeParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecDtmfDetCe - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 361,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecDtmfDetCeParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecDtmfDetCeParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecDtmfDetCeParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecDtmfDetCeParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecDtmfDetCeParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecDtmfDetCeParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecDtmfDetCe - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 362,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecDtmfDetCeParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecDtmfDetCeParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecDtmfDetCeParmDef,
   &mgMgcoEvtSecDtmfDetCeParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecDtmfDetCeParmLstDefSeq =
{
   2,
   mgMgcoEvtSecDtmfDetCeParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecDtmfDetCeParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecDtmfDetCe - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 363,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecDtmfDetCeParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecDtmfDetCeDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecDtmfDetCeParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecDtmfDetCeDefSeq =
{
   3,
   mgMgcoEvtSecDtmfDetCeDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecDtmfDetCeDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecDtmfDetCe - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 364,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecDtmfDetCeDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecDtmfDet_dxParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecDtmfDet_dxParmDefChc =
{
   5,
   6,       
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecDtmfDet_dxParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecDtmfDet_dxParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecDtmfDet_dx - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 365,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecDtmfDet_dxParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecDtmfDet_dxParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecDtmfDet_dxParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecDtmfDet_dxParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecDtmfDet_dxParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecDtmfDet_dxParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecDtmfDet_dx - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 366,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecDtmfDet_dxParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecDtmfDet_dxParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecDtmfDet_dxParmDef,
   &mgMgcoEvtSecDtmfDet_dxParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecDtmfDet_dxParmLstDefSeq =
{
   2,
   mgMgcoEvtSecDtmfDet_dxParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecDtmfDet_dxParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecDtmfDet_dx - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 367,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecDtmfDet_dxParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecDtmfDet_dxDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecDtmfDet_dxParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecDtmfDet_dxDefSeq =
{
   3,
   mgMgcoEvtSecDtmfDet_dxDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecDtmfDet_dxDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecDtmfDet_dx - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 368,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecDtmfDet_dxDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtDtmfDetCeParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtDtmfDetCeParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtDtmfDetCeParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDtmfDetCeParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtDtmfDetCe - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 369,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtDtmfDetCeParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtDtmfDetCeParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtDtmfDetCeParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtDtmfDetCeParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtDtmfDetCeParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDtmfDetCeParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtDtmfDetCe - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 370,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtDtmfDetCeParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtDtmfDetCeParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtDtmfDetCeParmDef,
   &mgMgcoReqEvtDtmfDetCeParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtDtmfDetCeParmLstDefSeq =
{
   2,
   mgMgcoReqEvtDtmfDetCeParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDtmfDetCeParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtDtmfDetCe - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 371,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtDtmfDetCeParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtDtmfDetCeDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtDtmfDetCeParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtDtmfDetCeDefSeq =
{
   3,
   mgMgcoReqEvtDtmfDetCeDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDtmfDetCeDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtDtmfDetCe - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 372,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtDtmfDetCeDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtDtmfDet_dxParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtDtmfDet_dxParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtDtmfDet_dxParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDtmfDet_dxParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtDtmfDet_dx - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 373,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtDtmfDet_dxParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtDtmfDet_dxParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtDtmfDet_dxParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtDtmfDet_dxParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtDtmfDet_dxParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDtmfDet_dxParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtDtmfDet_dx - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 374,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtDtmfDet_dxParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtDtmfDet_dxParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtDtmfDet_dxParmDef,
   &mgMgcoReqEvtDtmfDet_dxParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtDtmfDet_dxParmLstDefSeq =
{
   2,
   mgMgcoReqEvtDtmfDet_dxParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDtmfDet_dxParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtDtmfDet_dx - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 375,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtDtmfDet_dxParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtDtmfDet_dxDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtDtmfDet_dxParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtDtmfDet_dxDefSeq =
{
   3,
   mgMgcoReqEvtDtmfDet_dxDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDtmfDet_dxDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtDtmfDet_dx - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 376,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtDtmfDet_dxDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecDtmfDet_dxParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecDtmfDet_dxParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecDtmfDet_dxParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecDtmfDet_dxParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecDtmfDet_dx - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 377,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecDtmfDet_dxParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecDtmfDetCeParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecDtmfDetCeParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecDtmfDetCeParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecDtmfDetCeParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecDtmfDetCeParmDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherDtmfDetCeDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecDtmfDetCeParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecDtmfDetCeParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecDtmfDetCeParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecDtmfDetCe - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 378,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecDtmfDetCeParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecDtmfDetCeParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecDtmfDetCe - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 379,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecDtmfDetCeParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecDtmfDetCeParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecDtmfDetCeParmDef,
   &mgMgcoEvSpecDtmfDetCeParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecDtmfDetCeParmLstDefSeq =
{
   2,
   mgMgcoEvSpecDtmfDetCeParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecDtmfDetCeParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecDtmfDetCe - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 380,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecDtmfDetCeParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecDtmfDetCeDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecDtmfDetCeParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecDtmfDetCeDefSeq =
{
   3,
   mgMgcoEvSpecDtmfDetCeDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecDtmfDetCeDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecDtmfDetCe - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 381,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecDtmfDetCeDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecDtmfDet_dxParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecDtmfDet_dxParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecDtmfDet_dxParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecDtmfDet_dxParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecDtmfDet_dxParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecDtmfDet_dx - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 382,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecDtmfDet_dxParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecDtmfDet_dxParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecDtmfDet_dxParmDef,
   &mgMgcoEvSpecDtmfDet_dxParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecDtmfDet_dxParmLstDefSeq =
{
   2,
   mgMgcoEvSpecDtmfDet_dxParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecDtmfDet_dxParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecDtmfDet_dx - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 383,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecDtmfDet_dxParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecDtmfDet_dxDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecDtmfDet_dxParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecDtmfDet_dxDefSeq =
{
   3,
   mgMgcoEvSpecDtmfDet_dxDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecDtmfDet_dxDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecDtmfDet_dx - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 384,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecDtmfDet_dxDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEventDtmfDetCeEnum =
{
   (Data *)"ce",
   MGT_PKG_DTMFDET_EVT_CE
};

PUBLIC CmAbnfElmDef mgMgcoEventDtmfDetCeEnumDef =
{
#ifdef CM_ABNF_DBG
   "Event enum - DtmfDet - Ce",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 385,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventDtmfDetCeEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEventDtmfDetRealDefChcEnum[] =
{
   /* 0x00 */     NULLP,
   /* 0x01 */     &mgMgcoEventToneDetStdEnumDef,
   /* 0x02 */     &mgMgcoEventToneDetEtdEnumDef,
   /* 0x03 */     &mgMgcoEventToneDetLtdEnumDef,
   /* 0x04 */     &mgMgcoEventDtmfDetCeEnumDef,
   /* 0x05 */     NULLP,
   /* 0x06 */     NULLP,
   /* 0x07 */     NULLP,
   /* 0x08 */     NULLP,
   /* 0x09 */     NULLP,
   /* 0x0a */     NULLP,
   /* 0x0b */     NULLP,
   /* 0x0c */     NULLP,
   /* 0x0d */     NULLP,
   /* 0x0e */     NULLP,
   /* 0x0f */     NULLP,
   /* 0x10 */     &mgMgcoToneId_d0EnumDef,
   /* 0x11 */     &mgMgcoToneId_d1EnumDef,
   /* 0x12 */     &mgMgcoToneId_d2EnumDef,
   /* 0x13 */     &mgMgcoToneId_d3EnumDef,
   /* 0x14 */     &mgMgcoToneId_d4EnumDef,
   /* 0x15 */     &mgMgcoToneId_d5EnumDef,
   /* 0x16 */     &mgMgcoToneId_d6EnumDef,
   /* 0x17 */     &mgMgcoToneId_d7EnumDef,
   /* 0x18 */     &mgMgcoToneId_d8EnumDef,
   /* 0x19 */     &mgMgcoToneId_d9EnumDef,
   /* 0x1a */     &mgMgcoToneId_daEnumDef,
   /* 0x1b */     &mgMgcoToneId_dbEnumDef,
   /* 0x1c */     &mgMgcoToneId_dcEnumDef,
   /* 0x1d */     &mgMgcoToneId_ddEnumDef,
   /* 0x1e */     NULLP,
   /* 0x1f */     NULLP,
   /* 0x20 */     &mgMgcoToneId_dsEnumDef,
   /* 0x21 */     &mgMgcoToneId_doEnumDef,
};

PUBLIC U8 mgMgcoEventDtmfDetRealDefChcIdx[] =
{
    0,  1,  2,  3,  4,  0,  0,  0,  0,  0,   /* 0        -     9 */
    0,  0,  0,  0,  0,  0,  5,  5,  5,  5,   /* 10(0x0a) - 19(0x13) */
    5,  5,  5,  5,  5,  5,  5,  5,  5,  5,   /* 20(0x14) - 29(0x1d) */
    0,  0,  5,  5                            /* 30(0x1e) - 33(0x21) */
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecDtmfDetRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecToneDetStdDef,
   &mgMgcoEvtSecToneDetStdDef,
   &mgMgcoEvtSecToneDetLtdDef,
   &mgMgcoEvtSecDtmfDetCeDef,
   &mgMgcoEvtSecDtmfDet_dxDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecDtmfDetRealDefChc =
{
   6,
   34,
   mgMgcoEventDtmfDetRealDefChcIdx,
   mgMgcoEvtSecDtmfDetRealDefChcElmnts,
   mgMgcoEventDtmfDetRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecDtmfDetRealDef =
{
#ifdef CM_ABNF_DBG
   "Real second requested event - package DtmfDet",
   "EvtNameDtmfDet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 386,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecDtmfDetRealDefChc,
   mgMgcoRegExpEvtNameDtmfDet
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecDtmfDetChcDefChcElmnts[] =
{
   &mgMgcoEvtSecUnknownNameDef,
   &mgMgcoEvtSecSkipAllDef,
   &mgMgcoEvtSecDtmfDetRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecDtmfDetChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtSecDtmfDetChcDefChcElmnts,
   mgMgcoGenTypeEnum 
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecDtmfDetChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of second req event in package DtmfDet",
   "PkgDtmfDetEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 387,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecDtmfDetChcDefChc,
   mgMgcoRegExpPkgDtmfDetEvtType
};

/* Second requested event */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecDtmfDetDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvtSecDtmfDetChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecDtmfDetDefSeq =
{
   3,
   mgMgcoEvtSecDtmfDetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecDtmfDetDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - package DtmfDet",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 388,
   sizeof(MgMgcoEvtSec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecDtmfDetDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtDtmfDetRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtToneDetStdDef,
   &mgMgcoReqEvtToneDetStdDef,
   &mgMgcoReqEvtToneDetLtdDef,
   &mgMgcoReqEvtDtmfDetCeDef,
   &mgMgcoReqEvtDtmfDet_dxDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtDtmfDetRealDefChc =
{
   6,
   34,
   mgMgcoEventDtmfDetRealDefChcIdx,
   mgMgcoReqEvtDtmfDetRealDefChcElmnts,
   mgMgcoEventDtmfDetRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDtmfDetRealDef =
{
#ifdef CM_ABNF_DBG
   "Real requested event - package DtmfDet",
   "EvtNameDtmfDet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 389,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtDtmfDetRealDefChc,
   mgMgcoRegExpEvtNameDtmfDet
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtDtmfDetChcDefChcElmnts[] =
{
   &mgMgcoReqEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoReqEvtDtmfDetRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtDtmfDetChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtDtmfDetChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDtmfDetChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of requested event in package DtmfDet",
   "PkgDtmfDetEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 390,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtDtmfDetChcDefChc,
   mgMgcoRegExpPkgDtmfDetEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtDtmfDetDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoReqEvtDtmfDetChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtDtmfDetDefSeq =
{
   3,
   mgMgcoReqEvtDtmfDetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtDtmfDetDef =
{
#ifdef CM_ABNF_DBG
   "Requested event - package DtmfDet",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 391,
   sizeof(MgMgcoReqEvt) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtDtmfDetDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtDtmfDetRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecToneDetStdDef,
   &mgMgcoEvSpecToneDetEtdDef,
   &mgMgcoEvSpecToneDetStdDef,
   &mgMgcoEvSpecDtmfDetCeDef,
   &mgMgcoEvSpecDtmfDet_dxDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtDtmfDetRealDefChc =
{
   6,
   34,
   mgMgcoEventDtmfDetRealDefChcIdx,
   mgMgcoObsEvtDtmfDetRealDefChcElmnts,
   mgMgcoEventDtmfDetRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtDtmfDetRealDef =
{
#ifdef CM_ABNF_DBG
   "Real observed event - package DtmfDet",
   "EvtNameDtmfDet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 392,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtDtmfDetRealDefChc,
   mgMgcoRegExpEvtNameDtmfDet
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtDtmfDetChcDefChcElmnts[] =
{
   &mgMgcoObsEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoObsEvtDtmfDetRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtDtmfDetChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtDtmfDetChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtDtmfDetChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of observed event in package DtmfDet",
   "PkgDtmfDetEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 393,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtDtmfDetChcDefChc,
   mgMgcoRegExpPkgDtmfDetEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtDtmfDetDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoObsEvtDtmfDetChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtDtmfDetDefSeq =
{
   3,
   mgMgcoObsEvtDtmfDetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtDtmfDetDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - package DtmfDet",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 394,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtDtmfDetDefSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecDtmfDetRealDefChc =
{
   6,
   34,
   mgMgcoEventDtmfDetRealDefChcIdx,
   mgMgcoObsEvtDtmfDetRealDefChcElmnts,
   mgMgcoEventDtmfDetRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecDtmfDetRealDef =
{
#ifdef CM_ABNF_DBG
   "Real event spec -  package ToneDet",
   "EvtNameToneDet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 395,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecDtmfDetRealDefChc,
   mgMgcoRegExpEvtNameToneDet
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecDtmfDetChcDefChcElmnts[] =
{
   &mgMgcoEvSpecUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoEvSpecDtmfDetRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecDtmfDetChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecDtmfDetChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecDtmfDetChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of event spec in package ToneDet",
   "PkgToneDetEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 396,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecDtmfDetChcDefChc,
   mgMgcoRegExpPkgToneDetEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecDtmfDetDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvSpecDtmfDetChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecDtmfDetDefSeq =
{
   3,
   mgMgcoEvSpecDtmfDetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecDtmfDetDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - package ToneDet",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 397,
   sizeof(MgMgcoEvSpec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecDtmfDetDefSeq,
   NULLP
};


/************************************************************************
                        Signals - None
************************************************************************/

/************************************************************************
                        Statistics - None
************************************************************************/

#endif /* GCP_PKG_MGCO_DTMFDET */

#ifdef GCP_PKG_MGCO_CPGEN
/************************************************************************

      Package - Basic Call Progress Tones Generator (cg) (0x0007)

************************************************************************/

/************************************************************************
                        Properties - none
************************************************************************/

/************************************************************************
                          Events - None
************************************************************************/

/************************************************************************
                              Signals
************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoSignalCpGen_dxParmDefChcElmnts[] =
{
   NULLP,   /* No additional parameters */
   &mgMgcoEvtStreamDef,
   &mgMgcoSigTypeDef,
   &mgMgcoSigDurationDef,
   &mgMgcoSigNtfyCmplDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalCpGen_dxParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoSignalCpGen_dxParmDefChcElmnts,
   mgMgcoSigParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalCpGen_dxParmDef =
{
#ifdef CM_ABNF_DBG
   "SignalCpGen_dx - parameter",
   "SigPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 398,
   sizeof(MgMgcoSigPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalCpGen_dxParmDefChc,
   mgMgcoRegExpSigPar
};

PUBLIC CmAbnfElmDef *mgMgcoSignalCpGen_dxParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoSignalCpGen_dxParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoSignalCpGen_dxParmArrayDefSeqOf =
{
   1,
   MGT_MAX_SIGPARS,
   2,
   mgMgcoSignalCpGen_dxParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoSigPar)
};

PUBLIC CmAbnfElmDef mgMgcoSignalCpGen_dxParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "SignalCpGen_dx - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 399,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoSignalCpGen_dxParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoSignalCpGen_dxParmLstDefSeqElmnts[] =
{
   &mgMgcoSignalCpGen_dxParmDef,
   &mgMgcoSignalCpGen_dxParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalCpGen_dxParmLstDefSeq =
{
   2,
   mgMgcoSignalCpGen_dxParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalCpGen_dxParmLstDef =
{
#ifdef CM_ABNF_DBG
   "SignalCpGen_dx - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 400,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoSignalCpGen_dxParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSignalCpGen_dxDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoSignalCpGen_dxParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalCpGen_dxDefSeq =
{
   3,
   mgMgcoSignalCpGen_dxDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalCpGen_dxDef =
{
#ifdef CM_ABNF_DBG
   "CpGen_dx - signal parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 401,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoSignalCpGen_dxDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoSignalCpGenRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoSignalToneGenPtDef,
   &mgMgcoSignalCpGen_dxDef
};

PUBLIC CmAbnfElmDef *mgMgcoSignalCpGenRealDefChcEnum[] =
{
   /* 0x00 */     NULLP,
   /* 0x01 */     &mgMgcoSignalToneGenPtEnumDef,
   /* 0x02 */     NULLP,
   /* 0x03 */     NULLP,
   /* 0x04 */     NULLP,
   /* 0x05 */     NULLP,
   /* 0x06 */     NULLP,
   /* 0x07 */     NULLP,
   /* 0x08 */     NULLP,
   /* 0x09 */     NULLP,
   /* 0x0a */     NULLP,
   /* 0x0b */     NULLP,
   /* 0x0c */     NULLP,
   /* 0x0d */     NULLP,
   /* 0x0e */     NULLP,
   /* 0x0f */     NULLP,
   /* 0x10 */     &mgMgcoToneId_d0EnumDef,
   /* 0x11 */     &mgMgcoToneId_d1EnumDef,
   /* 0x12 */     &mgMgcoToneId_d2EnumDef,
   /* 0x13 */     &mgMgcoToneId_d3EnumDef,
   /* 0x14 */     &mgMgcoToneId_d4EnumDef,
   /* 0x15 */     &mgMgcoToneId_d5EnumDef,
   /* 0x16 */     &mgMgcoToneId_d6EnumDef,
   /* 0x17 */     &mgMgcoToneId_d7EnumDef,
   /* 0x18 */     &mgMgcoToneId_d8EnumDef,
   /* 0x19 */     &mgMgcoToneId_d9EnumDef,
   /* 0x1a */     &mgMgcoToneId_daEnumDef,
   /* 0x1b */     &mgMgcoToneId_dbEnumDef,
   /* 0x1c */     &mgMgcoToneId_dcEnumDef,
   /* 0x1d */     &mgMgcoToneId_ddEnumDef,
   /* 0x1e */     NULLP,
   /* 0x1f */     NULLP,
   /* 0x20 */     &mgMgcoToneId_dsEnumDef,
   /* 0x21 */     &mgMgcoToneId_doEnumDef,
   /* 0x22 */     NULLP,
   /* 0x23 */     NULLP,
   /* 0x24 */     NULLP,
   /* 0x25 */     NULLP,
   /* 0x26 */     NULLP,
   /* 0x27 */     NULLP,
   /* 0x28 */     NULLP,
   /* 0x29 */     NULLP,
   /* 0x2a */     NULLP,
   /* 0x2b */     NULLP,
   /* 0x2c */     NULLP,
   /* 0x2d */     NULLP,
   /* 0x2e */     NULLP,
   /* 0x2f */     NULLP,
   /* 0x30 */     &mgMgcoToneId_dtEnumDef,
   /* 0x31 */     &mgMgcoToneId_rtEnumDef,
   /* 0x32 */     &mgMgcoToneId_btEnumDef,
   /* 0x33 */     &mgMgcoToneId_ctEnumDef,
   /* 0x34 */     &mgMgcoToneId_sitEnumDef,
   /* 0x35 */     &mgMgcoToneId_wtEnumDef,
   /* 0x36 */     &mgMgcoToneId_ptEnumDef,
   /* 0x37 */     &mgMgcoToneId_cwEnumDef,
   /* 0x38 */     &mgMgcoToneId_crEnumDef,
   /* 0x39 */     NULLP,
   /* 0x3a */     NULLP,
   /* 0x3b */     NULLP,
   /* 0x3c */     NULLP,
   /* 0x3d */     NULLP,
   /* 0x3e */     NULLP,
   /* 0x3f */     NULLP
};

PUBLIC U8 mgMgcoSignalCpGenRealDefChcIdx[] =
{
    0,  1,  0,  0,  0,  0,  0,  0,  0,  0,   /* 0        -     9 */
    0,  0,  0,  0,  0,  0,  2,  2,  2,  2,   /* 10(0x0a) - 19(0x13) */
    2,  2,  2,  2,  2,  2,  2,  2,  2,  2,   /* 20(0x14) - 29(0x1d) */
    0,  0,  2,  2,  0,  0,  0,  0,  0,  0,   /* 30(0x1e) - 39(0x27) */
    0,  0,  0,  0,  0,  0,  0,  0,  2,  2,   /* 40(0x28) - 49(0x31) */
    2,  2,  2,  2,  2,  2,  2,  0,  0,  0,   /* 50(0x32) - 59(0x3b) */
    0,  0,  0,  0                            /* 60(0x3c) - 63(0x3f) */
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalCpGenRealDefChc =
{
   3,
   64,
   mgMgcoSignalCpGenRealDefChcIdx,
   mgMgcoSignalCpGenRealDefChcElmnts,
   mgMgcoSignalCpGenRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalCpGenRealDef =
{
#ifdef CM_ABNF_DBG
   "Real signal - package CpGen",
   "SigNameCpGen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 402,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalCpGenRealDefChc,
   mgMgcoRegExpSigNameCpGen
};

PUBLIC CmAbnfElmDef *mgMgcoSignalCpGenChcDefChcElmnts[] =
{
   &mgMgcoSignalUnknownDef,
   &mgMgcoSignalSkipAllDef,
   &mgMgcoSignalCpGenRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalCpGenChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSignalCpGenChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalCpGenChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of signals in package CpGen",
   "PkgCpGenSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 403,
   sizeof(MgMgcoName) + sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalCpGenChcDefChc,
   mgMgcoRegExpPkgCpGenSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSignalCpGenDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSignalCpGenChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalCpGenDefSeq =
{
   3,
   mgMgcoSignalCpGenDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalCpGenDef =
{
#ifdef CM_ABNF_DBG
   "Signal request - package CpGen",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 404,
   sizeof(MgMgcoSignalsReq) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSignalCpGenDefSeq,
   NULLP
};

/************************************************************************
                        Statistics - None
************************************************************************/
#endif /* GCP_PKG_MGCO_CPGEN */

#ifdef GCP_PKG_MGCO_CPDET
/************************************************************************

      Package - Basic Call Progress Tones detection (cd) (0x0008)

************************************************************************/

/************************************************************************
                        Properties - None
************************************************************************/

/************************************************************************
                              Events
************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecCpDet_dxParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecCpDet_dxParmDefChc =
{
   5,
   6,       
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecCpDet_dxParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecCpDet_dxParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecCpDet_dx - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 405,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecCpDet_dxParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecCpDet_dxParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecCpDet_dxParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecCpDet_dxParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecCpDet_dxParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecCpDet_dxParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecCpDet_dx - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 406,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecCpDet_dxParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecCpDet_dxParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecCpDet_dxParmDef,
   &mgMgcoEvtSecCpDet_dxParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecCpDet_dxParmLstDefSeq =
{
   2,
   mgMgcoEvtSecCpDet_dxParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecCpDet_dxParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecCpDet_dx - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 407,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecCpDet_dxParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecCpDet_dxDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecCpDet_dxParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecCpDet_dxDefSeq =
{
   3,
   mgMgcoEvtSecCpDet_dxDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecCpDet_dxDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecCpDet_dx - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 408,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecCpDet_dxDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtCpDet_dxParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtCpDet_dxParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtCpDet_dxParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtCpDet_dxParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtCpDet_dx - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 409,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtCpDet_dxParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtCpDet_dxParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtCpDet_dxParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtCpDet_dxParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtCpDet_dxParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtCpDet_dxParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtCpDet_dx - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 410,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtCpDet_dxParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtCpDet_dxParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtCpDet_dxParmDef,
   &mgMgcoReqEvtCpDet_dxParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtCpDet_dxParmLstDefSeq =
{
   2,
   mgMgcoReqEvtCpDet_dxParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtCpDet_dxParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtCpDet_dx - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 411,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtCpDet_dxParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtCpDet_dxDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtCpDet_dxParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtCpDet_dxDefSeq =
{
   3,
   mgMgcoReqEvtCpDet_dxDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtCpDet_dxDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtCpDet_dx - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 412,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtCpDet_dxDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecCpDet_dxParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecCpDet_dxParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecCpDet_dxParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecCpDet_dxParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecCpDet_dx - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 413,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecCpDet_dxParmDefChc,
   mgMgcoRegExpEvtPar
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecCpDet_dxParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecCpDet_dxParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecCpDet_dxParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecCpDet_dxParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecCpDet_dxParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecCpDet_dx - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 414,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecCpDet_dxParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecCpDet_dxParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecCpDet_dxParmDef,
   &mgMgcoEvSpecCpDet_dxParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecCpDet_dxParmLstDefSeq =
{
   2,
   mgMgcoEvSpecCpDet_dxParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecCpDet_dxParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecCpDet_dx - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 415,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecCpDet_dxParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecCpDet_dxDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecCpDet_dxParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecCpDet_dxDefSeq =
{
   3,
   mgMgcoEvSpecCpDet_dxDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecCpDet_dxDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecCpDet_dx - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 416,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecCpDet_dxDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEventCpDetRealDefChcEnum[] =
{
   /* 0x00 */     NULLP,
   /* 0x01 */     &mgMgcoEventToneDetStdEnumDef,
   /* 0x02 */     &mgMgcoEventToneDetEtdEnumDef,
   /* 0x03 */     &mgMgcoEventToneDetLtdEnumDef,
   /* 0x04 */     NULLP,
   /* 0x05 */     NULLP,
   /* 0x06 */     NULLP,
   /* 0x07 */     NULLP,
   /* 0x08 */     NULLP,
   /* 0x09 */     NULLP,
   /* 0x0a */     NULLP,
   /* 0x0b */     NULLP,
   /* 0x0c */     NULLP,
   /* 0x0d */     NULLP,
   /* 0x0e */     NULLP,
   /* 0x0f */     NULLP,
   /* 0x10 */     &mgMgcoToneId_d0EnumDef,
   /* 0x11 */     &mgMgcoToneId_d1EnumDef,
   /* 0x12 */     &mgMgcoToneId_d2EnumDef,
   /* 0x13 */     &mgMgcoToneId_d3EnumDef,
   /* 0x14 */     &mgMgcoToneId_d4EnumDef,
   /* 0x15 */     &mgMgcoToneId_d5EnumDef,
   /* 0x16 */     &mgMgcoToneId_d6EnumDef,
   /* 0x17 */     &mgMgcoToneId_d7EnumDef,
   /* 0x18 */     &mgMgcoToneId_d8EnumDef,
   /* 0x19 */     &mgMgcoToneId_d9EnumDef,
   /* 0x1a */     &mgMgcoToneId_daEnumDef,
   /* 0x1b */     &mgMgcoToneId_dbEnumDef,
   /* 0x1c */     &mgMgcoToneId_dcEnumDef,
   /* 0x1d */     &mgMgcoToneId_ddEnumDef,
   /* 0x1e */     NULLP,
   /* 0x1f */     NULLP,
   /* 0x20 */     &mgMgcoToneId_dsEnumDef,
   /* 0x21 */     &mgMgcoToneId_doEnumDef,
   /* 0x22 */     NULLP,
   /* 0x23 */     NULLP,
   /* 0x24 */     NULLP,
   /* 0x25 */     NULLP,
   /* 0x26 */     NULLP,
   /* 0x27 */     NULLP,
   /* 0x28 */     NULLP,
   /* 0x29 */     NULLP,
   /* 0x2a */     NULLP,
   /* 0x2b */     NULLP,
   /* 0x2c */     NULLP,
   /* 0x2d */     NULLP,
   /* 0x2e */     NULLP,
   /* 0x2f */     NULLP,
   /* 0x30 */     &mgMgcoToneId_dtEnumDef,
   /* 0x31 */     &mgMgcoToneId_rtEnumDef,
   /* 0x32 */     &mgMgcoToneId_btEnumDef,
   /* 0x33 */     &mgMgcoToneId_ctEnumDef,
   /* 0x34 */     &mgMgcoToneId_sitEnumDef,
   /* 0x35 */     &mgMgcoToneId_wtEnumDef,
   /* 0x36 */     &mgMgcoToneId_ptEnumDef,
   /* 0x37 */     &mgMgcoToneId_cwEnumDef,
   /* 0x38 */     &mgMgcoToneId_crEnumDef,
   /* 0x39 */     NULLP,
   /* 0x3a */     NULLP,
   /* 0x3b */     NULLP,
   /* 0x3c */     NULLP,
   /* 0x3d */     NULLP,
   /* 0x3e */     NULLP,
   /* 0x3f */     NULLP
};

PUBLIC U8 mgMgcoEventCpDetRealDefChcIdx[] =
{
    0,  1,  2,  3,  0,  0,  0,  0,  0,  0,   /* 0        -     9 */
    0,  0,  0,  0,  0,  0,  5,  5,  5,  5,   /* 10(0x0a) - 19(0x13) */
    5,  5,  5,  5,  5,  5,  5,  5,  5,  5,   /* 20(0x14) - 29(0x1d) */
    0,  0,  5,  5,  0,  0,  0,  0,  0,  0,   /* 30(0x1e) - 39(0x27) */
    0,  0,  0,  0,  0,  0,  0,  0,  5,  5,   /* 40(0x28) - 49(0x31) */
    5,  5,  5,  5,  5,  5,  5,  0,  0,  0,   /* 50(0x32) - 59(0x3b) */
    0,  0,  0,  0                            /* 60(0x3c) - 63(0x3f) */
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecCpDetRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecToneDetStdDef,
   &mgMgcoEvtSecToneDetStdDef,
   &mgMgcoEvtSecToneDetLtdDef,
   NULLP,
   &mgMgcoEvtSecCpDet_dxDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecCpDetRealDefChc =
{
   6,
   64,
   mgMgcoEventCpDetRealDefChcIdx,
   mgMgcoEvtSecCpDetRealDefChcElmnts,
   mgMgcoEventCpDetRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecCpDetRealDef =
{
#ifdef CM_ABNF_DBG
   "Real second requested event - package CpDet",
   "EvtNameCpDet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 417,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecCpDetRealDefChc,
   mgMgcoRegExpEvtNameCpDet
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecCpDetChcDefChcElmnts[] =
{
   &mgMgcoEvtSecUnknownNameDef,
   &mgMgcoEvtSecSkipAllDef,
   &mgMgcoEvtSecCpDetRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecCpDetChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtSecCpDetChcDefChcElmnts,
   mgMgcoGenTypeEnum 
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecCpDetChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of second req event in package CpDet",
   "PkgCpDetEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 418,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecCpDetChcDefChc,
   mgMgcoRegExpPkgCpDetEvtType
};

/* Second requested event */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecCpDetDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvtSecCpDetChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecCpDetDefSeq =
{
   3,
   mgMgcoEvtSecCpDetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecCpDetDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - package CpDet",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 419,
   sizeof(MgMgcoEvtSec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecCpDetDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtCpDetRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtToneDetStdDef,
   &mgMgcoReqEvtToneDetStdDef,
   &mgMgcoReqEvtToneDetLtdDef,
   NULLP,
   &mgMgcoReqEvtCpDet_dxDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtCpDetRealDefChc =
{
   6,
   64,
   mgMgcoEventCpDetRealDefChcIdx,
   mgMgcoReqEvtCpDetRealDefChcElmnts,
   mgMgcoEventCpDetRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtCpDetRealDef =
{
#ifdef CM_ABNF_DBG
   "Real requested event - package CpDet",
   "EvtNameCpDet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 420,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtCpDetRealDefChc,
   mgMgcoRegExpEvtNameCpDet
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtCpDetChcDefChcElmnts[] =
{
   &mgMgcoReqEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoReqEvtCpDetRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtCpDetChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtCpDetChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtCpDetChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of requested event in package CpDet",
   "PkgCpDetEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 421,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtCpDetChcDefChc,
   mgMgcoRegExpPkgCpDetEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtCpDetDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoReqEvtCpDetChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtCpDetDefSeq =
{
   3,
   mgMgcoReqEvtCpDetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtCpDetDef =
{
#ifdef CM_ABNF_DBG
   "Requested event - package CpDet",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 422,
   sizeof(MgMgcoReqEvt) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtCpDetDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtCpDetRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecToneDetStdDef,
   &mgMgcoEvSpecToneDetEtdDef,
   &mgMgcoEvSpecToneDetStdDef,
   NULLP,
   &mgMgcoEvSpecCpDet_dxDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtCpDetRealDefChc =
{
   6,
   64,
   mgMgcoEventCpDetRealDefChcIdx,
   mgMgcoObsEvtCpDetRealDefChcElmnts,
   mgMgcoEventCpDetRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtCpDetRealDef =
{
#ifdef CM_ABNF_DBG
   "Real observed event - package CpDet",
   "EvtNameCpDet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 423,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtCpDetRealDefChc,
   mgMgcoRegExpEvtNameCpDet
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtCpDetChcDefChcElmnts[] =
{
   &mgMgcoObsEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoObsEvtCpDetRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtCpDetChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtCpDetChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtCpDetChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of observed event in package CpDet",
   "PkgCpDetEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 424,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtCpDetChcDefChc,
   mgMgcoRegExpPkgCpDetEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtCpDetDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoObsEvtCpDetChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtCpDetDefSeq =
{
   3,
   mgMgcoObsEvtCpDetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtCpDetDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - package CpDet",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 425,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtCpDetDefSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecCpDetRealDefChc =
{
   6,
   64,
   mgMgcoEventCpDetRealDefChcIdx,
   mgMgcoObsEvtCpDetRealDefChcElmnts,
   mgMgcoEventCpDetRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecCpDetRealDef =
{
#ifdef CM_ABNF_DBG
   "Real event spec -  package ToneDet",
   "EvtNameToneDet",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 426,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecCpDetRealDefChc,
   mgMgcoRegExpEvtNameToneDet
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecCpDetChcDefChcElmnts[] =
{
   &mgMgcoEvSpecUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoEvSpecCpDetRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecCpDetChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecCpDetChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecCpDetChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of event spec in package ToneDet",
   "PkgToneDetEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 427,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecCpDetChcDefChc,
   mgMgcoRegExpPkgToneDetEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecCpDetDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvSpecCpDetChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecCpDetDefSeq =
{
   3,
   mgMgcoEvSpecCpDetDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecCpDetDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - package ToneDet",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 428,
   sizeof(MgMgcoEvSpec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecCpDetDefSeq,
   NULLP
};


/************************************************************************
                        Signals - None
************************************************************************/

/************************************************************************
                        Statistics - None
************************************************************************/
#endif /* GCP_PKG_MGCO_CPDET */

#ifdef GCP_PKG_MGCO_ANALOG
/************************************************************************

      Package - Analog line supervision (al) (0x0009)

************************************************************************/

/************************************************************************
                        Properties - None
************************************************************************/

/************************************************************************
                              Events
************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEventAnalogOnHookEnum =
{
   (Data *)"on",
   MGT_PKG_ANALOG_EVT_ON
};

PUBLIC CmAbnfElmDef mgMgcoEventAnalogOnHookEnumDef =
{
#ifdef CM_ABNF_DBG
   "Event enum - Analog - OnHook",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 429,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventAnalogOnHookEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEventAnalogOffHookEnum =
{
   (Data *)"of",
   MGT_PKG_ANALOG_EVT_OF
};

PUBLIC CmAbnfElmDef mgMgcoEventAnalogOffHookEnumDef =
{
#ifdef CM_ABNF_DBG
   "Event enum - Analog - OffHook",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 430,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventAnalogOffHookEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEventAnalogFlashHookEnum =
{
   (Data *)"fl",
   MGT_PKG_ANALOG_EVT_FL
};

PUBLIC CmAbnfElmDef mgMgcoEventAnalogFlashHookEnumDef =
{
#ifdef CM_ABNF_DBG
   "Event enum - Analog - FlashHook",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 431,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventAnalogFlashHookEnum,
   NULLP
};

PUBLIC U8 mgMgcoEventAnalogRealDefChcIdx[] = {0, 0, 0, 0, 1, 2, 3};
PUBLIC CmAbnfElmDef *mgMgcoEventAnalogRealDefChcEnum[] =
{
   NULLP, NULLP, NULLP, NULLP,
   &mgMgcoEventAnalogOnHookEnumDef,
   &mgMgcoEventAnalogOffHookEnumDef,
   &mgMgcoEventAnalogFlashHookEnumDef
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoAnalogOnHookStrictExactEnum =
{
   (Data *)"exact",
   MGT_PKG_ANALOG_EVT_ONHOOK_STRICT_EXACT
};

PUBLIC CmAbnfElmDef mgMgcoAnalogOnHookStrictExactEnumDef =
{
#ifdef CM_ABNF_DBG
   "AnalogOnHookStrictExactEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 432,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoAnalogOnHookStrictExactEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoAnalogOnHookStrictStateEnum =
{
   (Data *)"state",
   MGT_PKG_ANALOG_EVT_ONHOOK_STRICT_STATE
};

PUBLIC CmAbnfElmDef mgMgcoAnalogOnHookStrictStateEnumDef =
{
#ifdef CM_ABNF_DBG
   "AnalogOnHookStrictStateEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 433,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoAnalogOnHookStrictStateEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoAnalogOnHookStrictFailWrongEnum =
{
   (Data *)"failWrong",
   MGT_PKG_ANALOG_EVT_ONHOOK_STRICT_FAILWRONG
};

PUBLIC CmAbnfElmDef mgMgcoAnalogOnHookStrictFailWrongEnumDef =
{
#ifdef CM_ABNF_DBG
   "AnalogOnHookStrictFailWrongEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 434,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoAnalogOnHookStrictFailWrongEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookStrictValueChcEnum[] =
{
   &mgMgcoAnalogOnHookStrictExactEnumDef,
   &mgMgcoAnalogOnHookStrictStateEnumDef,
   &mgMgcoAnalogOnHookStrictFailWrongEnumDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherAnalogOnHookStrictValueChc =
{
   3,
   0,
   NULLP,
   NULLP,
   mgMgcoReqEvtOtherAnalogOnHookStrictValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookStrictValue =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherAnalogOnHookStrictValue",
   "ReqEvtOtherAnalogOnHookStrictValue",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 435,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookStrictValueChc,
   mgMgcoRegExpReqEvtOtherAnalogOnHookStrictValue
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookStrictValDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherAnalogOnHookStrictValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherAnalogOnHookStrictValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoReqEvtOtherAnalogOnHookStrictValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookStrictValDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherAnalogOnHookStrictVal",
   "ParmValEnume",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 436,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookStrictValDefChc,
   mgMgcoRegExpParmValEnume
};


/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookStrictValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogOnHookStrictValEqDefSeq =
{
   2,
   mgMgcoReqEvtOtherAnalogOnHookStrictValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookStrictValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 437,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookStrictValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookStrictValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogOnHookStrictValGtDefSeq =
{
   2,
   mgMgcoReqEvtOtherAnalogOnHookStrictValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookStrictValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 438,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookStrictValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookStrictValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogOnHookStrictValLtDefSeq =
{
   2,
   mgMgcoReqEvtOtherAnalogOnHookStrictValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookStrictValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 439,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookStrictValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookStrictValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogOnHookStrictValNeDefSeq =
{
   2,
   mgMgcoReqEvtOtherAnalogOnHookStrictValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookStrictValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 440,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookStrictValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookStrictValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtOtherAnalogOnHookStrictValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoReqEvtOtherAnalogOnHookStrictValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookStrictValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 441,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookStrictValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookStrictValLstDefSeqElmnts[]   =
{
   &mgMgcoReqEvtOtherAnalogOnHookStrictValDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogOnHookStrictValLstDefSeq =
{
   2,
   mgMgcoReqEvtOtherAnalogOnHookStrictValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookStrictValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 442,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookStrictValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookStrictValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogOnHookStrictValAndDefSeq =
{
   4,
   mgMgcoReqEvtOtherAnalogOnHookStrictValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookStrictValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 443,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookStrictValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookStrictValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogOnHookStrictValOrDefSeq =
{
   4,
   mgMgcoReqEvtOtherAnalogOnHookStrictValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookStrictValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 444,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookStrictValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookStrictValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValDef,
   &cmMsgDefMetaColon,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogOnHookStrictValRngDefSeq =
{
   6,
   mgMgcoReqEvtOtherAnalogOnHookStrictValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookStrictValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 445,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookStrictValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookStrictDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherAnalogOnHookStrictValEqDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValGtDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValLtDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValNeDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValAndDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValOrDef,
   &mgMgcoReqEvtOtherAnalogOnHookStrictValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherAnalogOnHookStrictDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoReqEvtOtherAnalogOnHookStrictDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookStrictDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherAnalogOnHookStrict",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 446,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookStrictDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

PUBLIC CmAbnfElmTypeEnum mgMgcoReqEvtOtherAnalogOnHookStrictEnum =
{
   (Data *)"strict",
   MGT_PKG_ANALOG_EVT_ONHOOK_STRICT
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookStrictEnumDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherAnalogOnHookStrictEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 447,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookStrictEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookParDefChcEnum[] =
{
   NULLP,
   &mgMgcoReqEvtOtherAnalogOnHookStrictEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtOtherAnalogOnHookStrictDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherAnalogOnHookParDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoReqEvtOtherAnalogOnHookParDefChcElmnts,
   mgMgcoReqEvtOtherAnalogOnHookParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookParDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherAnalogOnHookPar",
   "ReqEvtOtherAnalogOnHookPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 448,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookParDefChc,
   mgMgcoRegExpReqEvtOtherAnalogOnHookPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogOnHookDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoReqEvtOtherAnalogOnHookParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherAnalogOnHookDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtOtherAnalogOnHookDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogOnHookDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherAnalogOnHook",
   "ReqEvtOtherAnalogOnHookType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 449,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherAnalogOnHookDefChc,
   mgMgcoRegExpReqEvtOtherAnalogOnHookType
};

/************************************************************************/

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValue =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherAnalogFlashHookMinMaxDurValue",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 450,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoU32DefRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherAnalogFlashHookMinMaxDurVal",
   "ParmValDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 451,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValDefChc,
   mgMgcoRegExpParmValDecUint
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValEqDefSeq =
{
   2,
   mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 452,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValGtDefSeq =
{
   2,
   mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 453,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValLtDefSeq =
{
   2,
   mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 454,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValNeDefSeq =
{
   2,
   mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 455,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 456,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValLstDefSeqElmnts[]   =
{
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValLstDefSeq =
{
   2,
   mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 457,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValAndDefSeq =
{
   4,
   mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 458,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValOrDefSeq =
{
   4,
   mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 459,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValDef,
   &cmMsgDefMetaColon,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValRngDefSeq =
{
   6,
   mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 460,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValEqDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValGtDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValLtDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValNeDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValAndDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValOrDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherAnalogFlashHookMinMaxDur",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 461,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoReqEvtOtherAnalogFlashHookMinDurEnum =
{
   (Data *)"mindur",
   MGT_PKG_ANALOG_EVT_FLASHHOOK_MINDUR
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMinDurEnumDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherAnalogFlashHookMinDurEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 462,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookMinDurEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoReqEvtOtherAnalogFlashHookMaxDurEnum =
{
   (Data *)"maxdur",
   MGT_PKG_ANALOG_EVT_FLASHHOOK_MAXDUR
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookMaxDurEnumDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherAnalogFlashHookMaxDurEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 463,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookMaxDurEnum,
   NULLP
};

/************************************************************************/

PUBLIC U8 mgMgcoReqEvtOtherAnalogFlashHookParDefChcIdx[] = 
   {0, 0, 0, 0, 1, 1};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtOtherAnalogFlashHookMinMaxDurDef
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookParDefChcEnum[] =
{
   NULLP, NULLP, NULLP, NULLP,
   &mgMgcoReqEvtOtherAnalogFlashHookMinDurEnumDef,
   &mgMgcoReqEvtOtherAnalogFlashHookMaxDurEnumDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherAnalogFlashHookParDefChc =
{
   2,
   6,
   mgMgcoReqEvtOtherAnalogFlashHookParDefChcIdx,
   mgMgcoReqEvtOtherAnalogFlashHookParDefChcElmnts,
   mgMgcoReqEvtOtherAnalogFlashHookParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookParDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherAnalogFlashHookPar",
   "ReqEvtOtherAnalogFlashHookPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 464,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookParDefChc,
   mgMgcoRegExpReqEvtOtherAnalogFlashHookPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherAnalogFlashHookDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoReqEvtOtherAnalogFlashHookParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherAnalogFlashHookDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtOtherAnalogFlashHookDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherAnalogFlashHookDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherAnalogFlashHook",
   "ReqEvtOtherAnalogFlashHookType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 465,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherAnalogFlashHookDefChc,
   mgMgcoRegExpReqEvtOtherAnalogFlashHookType
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtAnalogOnHookParmDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherAnalogOnHookDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtAnalogOnHookParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtAnalogOnHookParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtAnalogOnHookParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtAnalogOnHook - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 466,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtAnalogOnHookParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtAnalogOnHookParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtAnalogOnHookParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtAnalogOnHookParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtAnalogOnHookParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtAnalogOnHookParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtAnalogOnHook - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 467,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtAnalogOnHookParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtAnalogOnHookParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtAnalogOnHookParmDef,
   &mgMgcoReqEvtAnalogOnHookParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtAnalogOnHookParmLstDefSeq =
{
   2,
   mgMgcoReqEvtAnalogOnHookParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtAnalogOnHookParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtAnalogOnHook - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 468,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtAnalogOnHookParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtAnalogOnHookDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtAnalogOnHookParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtAnalogOnHookDefSeq =
{
   3,
   mgMgcoReqEvtAnalogOnHookDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtAnalogOnHookDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtAnalogOnHook - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 469,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtAnalogOnHookDefSeq,
   mgMgcoRegExpLBRKT
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtAnalogFlashHookParmDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherAnalogFlashHookDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtAnalogFlashHookParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtAnalogFlashHookParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtAnalogFlashHookParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtAnalogFlashHook - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 470,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtAnalogFlashHookParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtAnalogFlashHookParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtAnalogFlashHookParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtAnalogFlashHookParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtAnalogFlashHookParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtAnalogFlashHookParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtAnalogFlashHook - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 471,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtAnalogFlashHookParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtAnalogFlashHookParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtAnalogFlashHookParmDef,
   &mgMgcoReqEvtAnalogFlashHookParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtAnalogFlashHookParmLstDefSeq =
{
   2,
   mgMgcoReqEvtAnalogFlashHookParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtAnalogFlashHookParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtAnalogFlashHook - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 472,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtAnalogFlashHookParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtAnalogFlashHookDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtAnalogFlashHookParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtAnalogFlashHookDefSeq =
{
   3,
   mgMgcoReqEvtAnalogFlashHookDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtAnalogFlashHookDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtAnalogFlashHook - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 473,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtAnalogFlashHookDefSeq,
   mgMgcoRegExpLBRKT
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtAnalogRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtAnalogOnHookDef,
   &mgMgcoReqEvtAnalogOnHookDef,
   &mgMgcoReqEvtAnalogFlashHookDef,
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtAnalogRealDefChc =
{
   4,
   7,
   mgMgcoEventAnalogRealDefChcIdx,
   mgMgcoReqEvtAnalogRealDefChcElmnts,
   mgMgcoEventAnalogRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtAnalogRealDef =
{
#ifdef CM_ABNF_DBG
   "Real requested event - package Analog",
   "EvtNameAnalog",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 474,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtAnalogRealDefChc,
   mgMgcoRegExpEvtNameAnalog
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtAnalogChcDefChcElmnts[] =
{
   &mgMgcoReqEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoReqEvtAnalogRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtAnalogChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtAnalogChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtAnalogChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of requested event in package Analog",
   "PkgAnalogEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 475,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtAnalogChcDefChc,
   mgMgcoRegExpPkgAnalogEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtAnalogDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoReqEvtAnalogChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtAnalogDefSeq =
{
   3,
   mgMgcoReqEvtAnalogDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtAnalogDef =
{
#ifdef CM_ABNF_DBG
   "Requested event - package Analog",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 476,
   sizeof(MgMgcoReqEvt) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtAnalogDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogOnHookParmDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherAnalogOnHookDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecAnalogOnHookParmDefChc =
{
   5,
   6,         
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecAnalogOnHookParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogOnHookParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecAnalogOnHook - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 477,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecAnalogOnHookParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogOnHookParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecAnalogOnHookParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecAnalogOnHookParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecAnalogOnHookParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogOnHookParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecAnalogOnHook - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 478,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecAnalogOnHookParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogOnHookParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecAnalogOnHookParmDef,
   &mgMgcoEvtSecAnalogOnHookParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecAnalogOnHookParmLstDefSeq =
{
   2,
   mgMgcoEvtSecAnalogOnHookParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogOnHookParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecAnalogOnHook - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 479,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecAnalogOnHookParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogOnHookDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecAnalogOnHookParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecAnalogOnHookDefSeq =
{
   3,
   mgMgcoEvtSecAnalogOnHookDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogOnHookDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecAnalogOnHook - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 480,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecAnalogOnHookDefSeq,
   mgMgcoRegExpLBRKT
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogOffHookParmDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherAnalogOnHookDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecAnalogOffHookParmDefChc =
{
   5,
   6,         
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecAnalogOffHookParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogOffHookParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecAnalogOffHook - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 481,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecAnalogOffHookParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogOffHookParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecAnalogOffHookParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecAnalogOffHookParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecAnalogOffHookParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogOffHookParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecAnalogOffHook - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 482,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecAnalogOffHookParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogOffHookParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecAnalogOffHookParmDef,
   &mgMgcoEvtSecAnalogOffHookParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecAnalogOffHookParmLstDefSeq =
{
   2,
   mgMgcoEvtSecAnalogOffHookParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogOffHookParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecAnalogOffHook - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 483,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecAnalogOffHookParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogOffHookDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecAnalogOffHookParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecAnalogOffHookDefSeq =
{
   3,
   mgMgcoEvtSecAnalogOffHookDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogOffHookDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecAnalogOffHook - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 484,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecAnalogOffHookDefSeq,
   mgMgcoRegExpLBRKT
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogFlashHookParmDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherAnalogFlashHookDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecAnalogFlashHookParmDefChc =
{
   5,
   6,      
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecAnalogFlashHookParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogFlashHookParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecAnalogFlashHook - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 485,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecAnalogFlashHookParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogFlashHookParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecAnalogFlashHookParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecAnalogFlashHookParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecAnalogFlashHookParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogFlashHookParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecAnalogFlashHook - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 486,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecAnalogFlashHookParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogFlashHookParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecAnalogFlashHookParmDef,
   &mgMgcoEvtSecAnalogFlashHookParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecAnalogFlashHookParmLstDefSeq =
{
   2,
   mgMgcoEvtSecAnalogFlashHookParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogFlashHookParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecAnalogFlashHook - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 487,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecAnalogFlashHookParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogFlashHookDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecAnalogFlashHookParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecAnalogFlashHookDefSeq =
{
   3,
   mgMgcoEvtSecAnalogFlashHookDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogFlashHookDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecAnalogFlashHook - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 488,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecAnalogFlashHookDefSeq,
   mgMgcoRegExpLBRKT
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecAnalogOnHookDef,
   &mgMgcoEvtSecAnalogOffHookDef,
   &mgMgcoEvtSecAnalogFlashHookDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecAnalogRealDefChc =
{
   4,
   7,
   mgMgcoEventAnalogRealDefChcIdx,
   mgMgcoEvtSecAnalogRealDefChcElmnts,
   mgMgcoEventAnalogRealDefChcEnum
};


PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogRealDef =
{
#ifdef CM_ABNF_DBG
   "Real second requested event - package Analog",
   "EvtNameAnalog",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 489,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecAnalogRealDefChc,
   mgMgcoRegExpEvtNameAnalog
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogChcDefChcElmnts[] =
{
   &mgMgcoEvtSecUnknownNameDef,
   &mgMgcoEvtSecSkipAllDef,
   &mgMgcoEvtSecAnalogRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecAnalogChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtSecAnalogChcDefChcElmnts,
   mgMgcoGenTypeEnum 
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of second req event in package Analog",
   "PkgAnalogEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 490,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecAnalogChcDefChc,
   mgMgcoRegExpPkgAnalogEvtType
};

/* Second requested event */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecAnalogDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvtSecAnalogChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecAnalogDefSeq =
{
   3,
   mgMgcoEvtSecAnalogDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecAnalogDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - package Analog",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 491,
   sizeof(MgMgcoEvtSec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecAnalogDefSeq,
   NULLP
};

/************************************************************************/

/* mg004.105: Support for on/off to true/false */
#ifdef MGT_INIT_EQUALTO_FALSE
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookInitValueChcEnum[] =
{
   &mgMgcoPkgFalseDef,
   &mgMgcoPkgTrueDef
};
#else
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookInitValueChcEnum[] =
{
   &mgMgcoPkgOffDef,  
   &mgMgcoPkgOnDef   
};
#endif

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherAnalogOnHookInitValueChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoObsEvtOtherAnalogOnHookInitValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookInitValue =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherAnalogOnHookInitValue",
   "SDPFalseTrue",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 492,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookInitValueChc,
   mgMgcoRegExpOffOn     
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookInitValDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherAnalogOnHookInitValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherAnalogOnHookInitValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoObsEvtOtherAnalogOnHookInitValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookInitValDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherAnalogOnHookInitVal",
   "ParmValEnume",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 493,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookInitValDefChc,
   mgMgcoRegExpParmValEnume
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookInitValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherAnalogOnHookInitValEqDefSeq =
{
   2,
   mgMgcoObsEvtOtherAnalogOnHookInitValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookInitValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 494,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookInitValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookInitValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherAnalogOnHookInitValGtDefSeq =
{
   2,
   mgMgcoObsEvtOtherAnalogOnHookInitValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookInitValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 495,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookInitValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherAnalogOnHookInitValLtDefSeq =
{
   2,
   mgMgcoObsEvtOtherAnalogOnHookInitValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookInitValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 496,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookInitValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookInitValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherAnalogOnHookInitValNeDefSeq =
{
   2,
   mgMgcoObsEvtOtherAnalogOnHookInitValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookInitValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 497,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookInitValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookInitValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoObsEvtOtherAnalogOnHookInitValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoObsEvtOtherAnalogOnHookInitValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookInitValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 498,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookInitValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookInitValLstDefSeqElmnts[]   =
{
   &mgMgcoObsEvtOtherAnalogOnHookInitValDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherAnalogOnHookInitValLstDefSeq =
{
   2,
   mgMgcoObsEvtOtherAnalogOnHookInitValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookInitValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 499,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookInitValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookInitValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherAnalogOnHookInitValAndDefSeq =
{
   4,
   mgMgcoObsEvtOtherAnalogOnHookInitValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookInitValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 500,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookInitValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookInitValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherAnalogOnHookInitValOrDefSeq =
{
   4,
   mgMgcoObsEvtOtherAnalogOnHookInitValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookInitValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 501,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookInitValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookInitValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValDef,
   &cmMsgDefMetaColon,
   &mgMgcoObsEvtOtherAnalogOnHookInitValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherAnalogOnHookInitValRngDefSeq =
{
   6,
   mgMgcoObsEvtOtherAnalogOnHookInitValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookInitValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 502,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookInitValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookInitDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherAnalogOnHookInitValEqDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValGtDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValLtDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValNeDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValAndDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValOrDef,
   &mgMgcoObsEvtOtherAnalogOnHookInitValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherAnalogOnHookInitDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoObsEvtOtherAnalogOnHookInitDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookInitDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherAnalogOnHookInit",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 503,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookInitDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

PUBLIC CmAbnfElmTypeEnum mgMgcoObsEvtOtherAnalogOnHookInitEnum =
{
   (Data *)"init",
   MGT_PKG_ANALOG_EVT_ONHOOK_INIT
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookInitEnumDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherAnalogOnHookInitEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 504,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookInitEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookParDefChcEnum[] =
{
   NULLP,
   NULLP,
   &mgMgcoObsEvtOtherAnalogOnHookInitEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookParDefChcElmnts[] =
{
   NULLP,
   NULLP,
   &mgMgcoObsEvtOtherAnalogOnHookInitDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherAnalogOnHookParDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherAnalogOnHookParDefChcElmnts,
   mgMgcoObsEvtOtherAnalogOnHookParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookParDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherAnalogOnHookPar",
   "ObsEvtOtherAnalogOnHookPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 505,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookParDefChc,
   mgMgcoRegExpObsEvtOtherAnalogOnHookPar
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherAnalogOnHookDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoObsEvtOtherAnalogOnHookParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherAnalogOnHookDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherAnalogOnHookDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherAnalogOnHookDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherAnalogOnHook",
   "ObsEvtOtherAnalogOnHookType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 506,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherAnalogOnHookDefChc,
   mgMgcoRegExpObsEvtOtherAnalogOnHookType
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogOnHookParmDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherAnalogOnHookDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecAnalogOnHookParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecAnalogOnHookParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogOnHookParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecAnalogOnHook - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 507,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecAnalogOnHookParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogOnHookParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecAnalogOnHookParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecAnalogOnHookParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecAnalogOnHookParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogOnHookParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecAnalogOnHook - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 508,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecAnalogOnHookParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogOnHookParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecAnalogOnHookParmDef,
   &mgMgcoEvSpecAnalogOnHookParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecAnalogOnHookParmLstDefSeq =
{
   2,
   mgMgcoEvSpecAnalogOnHookParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogOnHookParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecAnalogOnHook - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 509,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecAnalogOnHookParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogOnHookDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecAnalogOnHookParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecAnalogOnHookDefSeq =
{
   3,
   mgMgcoEvSpecAnalogOnHookDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogOnHookDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecAnalogOnHook - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 510,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecAnalogOnHookDefSeq,
   mgMgcoRegExpLBRKT
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogOffHookParmDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherAnalogOnHookDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecAnalogOffHookParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecAnalogOffHookParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogOffHookParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecAnalogOffHook - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 511,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecAnalogOffHookParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogOffHookParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecAnalogOffHookParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecAnalogOffHookParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecAnalogOffHookParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogOffHookParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecAnalogOffHook - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 512,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecAnalogOffHookParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogOffHookParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecAnalogOffHookParmDef,
   &mgMgcoEvSpecAnalogOffHookParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecAnalogOffHookParmLstDefSeq =
{
   2,
   mgMgcoEvSpecAnalogOffHookParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogOffHookParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecAnalogOffHook - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 513,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecAnalogOffHookParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogOffHookDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecAnalogOffHookParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecAnalogOffHookDefSeq =
{
   3,
   mgMgcoEvSpecAnalogOffHookDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogOffHookDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecAnalogOffHook - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 514,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecAnalogOffHookDefSeq,
   mgMgcoRegExpLBRKT
};


PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogFlashHookParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecAnalogFlashHookParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecAnalogFlashHookParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogFlashHookParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecAnalogFlashHook - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 515,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecAnalogFlashHookParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogFlashHookParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecAnalogFlashHookParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecAnalogFlashHookParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecAnalogFlashHookParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogFlashHookParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecAnalogFlashHook - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 516,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecAnalogFlashHookParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogFlashHookParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecAnalogFlashHookParmDef,
   &mgMgcoEvSpecAnalogFlashHookParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecAnalogFlashHookParmLstDefSeq =
{
   2,
   mgMgcoEvSpecAnalogFlashHookParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogFlashHookParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecAnalogFlashHook - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 517,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecAnalogFlashHookParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogFlashHookDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecAnalogFlashHookParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecAnalogFlashHookDefSeq =
{
   3,
   mgMgcoEvSpecAnalogFlashHookDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogFlashHookDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecAnalogFlashHook - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 518,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecAnalogFlashHookDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecAnalogOnHookDef,
   &mgMgcoEvSpecAnalogOffHookDef,
   &mgMgcoEvSpecAnalogFlashHookDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecAnalogRealDefChc =
{
   4,
   7,
   mgMgcoEventAnalogRealDefChcIdx,
   mgMgcoEvSpecAnalogRealDefChcElmnts,
   mgMgcoEventAnalogRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogRealDef =
{
#ifdef CM_ABNF_DBG
   "Real event spec -  package Analog",
   "EvtNameAnalog",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 519,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecAnalogRealDefChc,
   mgMgcoRegExpEvtNameAnalog
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogChcDefChcElmnts[] =
{
   &mgMgcoEvSpecUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoEvSpecAnalogRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecAnalogChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecAnalogChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of event spec in package Analog",
   "PkgAnalogEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 520,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecAnalogChcDefChc,
   mgMgcoRegExpPkgAnalogEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecAnalogDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvSpecAnalogChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecAnalogDefSeq =
{
   3,
   mgMgcoEvSpecAnalogDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecAnalogDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - package Analog",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 521,
   sizeof(MgMgcoEvSpec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecAnalogDefSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtAnalogRealDefChc =
{
   4,
   7,
   mgMgcoEventAnalogRealDefChcIdx,
   mgMgcoEvSpecAnalogRealDefChcElmnts,
   mgMgcoEventAnalogRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtAnalogRealDef =
{
#ifdef CM_ABNF_DBG
   "Real observed event - package Analog",
   "EvtNameAnalog",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 522,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtAnalogRealDefChc,
   mgMgcoRegExpEvtNameAnalog
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtAnalogChcDefChcElmnts[] =
{
   &mgMgcoObsEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoObsEvtAnalogRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtAnalogChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtAnalogChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtAnalogChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of observed event in package Analog",
   "PkgAnalogEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 523,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtAnalogChcDefChc,
   mgMgcoRegExpPkgAnalogEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtAnalogDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoObsEvtAnalogChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtAnalogDefSeq =
{
   3,
   mgMgcoObsEvtAnalogDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtAnalogDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - package Analog",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 524,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtAnalogDefSeq,
   NULLP
};

/************************************************************************
                              Signals
************************************************************************/

PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingFreqValue =
{
#ifdef CM_ABNF_DBG
   "SigOtherAnalogRingFreqValue",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 525,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoU32DefRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingFreqValDefChcElmnts[] =
{
   NULLP, 
   &mgMgcoSigOtherAnalogRingFreqValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigOtherAnalogRingFreqValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoSigOtherAnalogRingFreqValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingFreqValDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherAnalogRingFreqVal",
   "ParmValueDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 526,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigOtherAnalogRingFreqValDefChc,
   mgMgcoRegExpParmValDecUint
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingFreqValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoSigOtherAnalogRingFreqValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingFreqValEqDefSeq =
{
   2,
   mgMgcoSigOtherAnalogRingFreqValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingFreqValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 527,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherAnalogRingFreqValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingFreqValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoSigOtherAnalogRingFreqValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingFreqValGtDefSeq =
{
   2,
   mgMgcoSigOtherAnalogRingFreqValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingFreqValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 528,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoSigOtherAnalogRingFreqValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingFreqValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoSigOtherAnalogRingFreqValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingFreqValLtDefSeq =
{
   2,
   mgMgcoSigOtherAnalogRingFreqValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingFreqValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 529,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherAnalogRingFreqValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingFreqValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoSigOtherAnalogRingFreqValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingFreqValNeDefSeq =
{
   2,
   mgMgcoSigOtherAnalogRingFreqValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingFreqValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 530,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherAnalogRingFreqValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingFreqValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoSigOtherAnalogRingFreqValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoSigOtherAnalogRingFreqValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoSigOtherAnalogRingFreqValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingFreqValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 531,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoSigOtherAnalogRingFreqValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingFreqValLstDefSeqElmnts[]   =
{
   &mgMgcoSigOtherAnalogRingFreqValDef,
   &mgMgcoSigOtherAnalogRingFreqValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingFreqValLstDefSeq =
{
   2,
   mgMgcoSigOtherAnalogRingFreqValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingFreqValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 532,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoSigOtherAnalogRingFreqValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingFreqValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoSigOtherAnalogRingFreqValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingFreqValAndDefSeq =
{
   4,
   mgMgcoSigOtherAnalogRingFreqValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingFreqValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 533,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherAnalogRingFreqValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingFreqValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoSigOtherAnalogRingFreqValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingFreqValOrDefSeq =
{
   4,
   mgMgcoSigOtherAnalogRingFreqValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingFreqValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 534,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherAnalogRingFreqValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingFreqValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoSigOtherAnalogRingFreqValDef,
   &cmMsgDefMetaColon,
   &mgMgcoSigOtherAnalogRingFreqValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingFreqValRngDefSeq =
{
   6,
   mgMgcoSigOtherAnalogRingFreqValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingFreqValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 535,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoSigOtherAnalogRingFreqValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingFreqDefChcElmnts[] =
{
   &mgMgcoSigOtherAnalogRingFreqValEqDef,
   &mgMgcoSigOtherAnalogRingFreqValGtDef,
   &mgMgcoSigOtherAnalogRingFreqValLtDef,
   &mgMgcoSigOtherAnalogRingFreqValNeDef,
   &mgMgcoSigOtherAnalogRingFreqValAndDef,
   &mgMgcoSigOtherAnalogRingFreqValOrDef,
   &mgMgcoSigOtherAnalogRingFreqValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigOtherAnalogRingFreqDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoSigOtherAnalogRingFreqDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingFreqDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherAnalogRingFreq",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 536,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigOtherAnalogRingFreqDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingCadValue =
{
#ifdef CM_ABNF_DBG
   "SigOtherAnalogRingCadValue",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 537,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoU32DefRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingCadValDefChcElmnts[] =
{
   NULLP,
   &mgMgcoSigOtherAnalogRingCadValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigOtherAnalogRingCadValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoSigOtherAnalogRingCadValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingCadValDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherAnalogRingCadVal",
   "ParmValueDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 538,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigOtherAnalogRingCadValDefChc,
   mgMgcoRegExpParmValDecUint
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingCadValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoSigOtherAnalogRingCadValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingCadValEqDefSeq =
{
   2,
   mgMgcoSigOtherAnalogRingCadValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingCadValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 539,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherAnalogRingCadValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingCadValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoSigOtherAnalogRingCadValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingCadValGtDefSeq =
{
   2,
   mgMgcoSigOtherAnalogRingCadValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingCadValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 540,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoSigOtherAnalogRingCadValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingCadValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoSigOtherAnalogRingCadValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingCadValLtDefSeq =
{
   2,
   mgMgcoSigOtherAnalogRingCadValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingCadValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 541,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherAnalogRingCadValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingCadValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoSigOtherAnalogRingCadValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingCadValNeDefSeq =
{
   2,
   mgMgcoSigOtherAnalogRingCadValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingCadValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 542,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherAnalogRingCadValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingCadValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoSigOtherAnalogRingCadValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoSigOtherAnalogRingCadValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoSigOtherAnalogRingCadValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingCadValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 543,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoSigOtherAnalogRingCadValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingCadValLstDefSeqElmnts[]   =
{
   &mgMgcoSigOtherAnalogRingCadValDef,
   &mgMgcoSigOtherAnalogRingCadValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingCadValLstDefSeq =
{
   2,
   mgMgcoSigOtherAnalogRingCadValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingCadValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 544,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoSigOtherAnalogRingCadValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingCadValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoSigOtherAnalogRingCadValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingCadValAndDefSeq =
{
   4,
   mgMgcoSigOtherAnalogRingCadValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingCadValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 545,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherAnalogRingCadValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingCadValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoSigOtherAnalogRingCadValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingCadValOrDefSeq =
{
   4,
   mgMgcoSigOtherAnalogRingCadValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingCadValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 546,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSigOtherAnalogRingCadValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingCadValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoSigOtherAnalogRingCadValDef,
   &cmMsgDefMetaColon,
   &mgMgcoSigOtherAnalogRingCadValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSigOtherAnalogRingCadValRngDefSeq =
{
   6,
   mgMgcoSigOtherAnalogRingCadValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingCadValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 547,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoSigOtherAnalogRingCadValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingCadDefChcElmnts[] =
{
   &mgMgcoSigOtherAnalogRingCadValEqDef,
   &mgMgcoSigOtherAnalogRingCadValGtDef,
   &mgMgcoSigOtherAnalogRingCadValLtDef,
   &mgMgcoSigOtherAnalogRingCadValNeDef,
   &mgMgcoSigOtherAnalogRingCadValAndDef,
   &mgMgcoSigOtherAnalogRingCadValOrDef,
   &mgMgcoSigOtherAnalogRingCadValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigOtherAnalogRingCadDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoSigOtherAnalogRingCadDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingCadDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherAnalogRingCad",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 548,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigOtherAnalogRingCadDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoSigOtherAnalogRingCadEnum =
{
   (Data *)"cad",
   MGT_PKG_ANALOG_SIG_RI_CAD
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingCadEnumDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherAnalogRingCadEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 549,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSigOtherAnalogRingCadEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoSigOtherAnalogRingFreqEnum =
{
   (Data *)"freq",
   MGT_PKG_ANALOG_SIG_RI_FREQ
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingFreqEnumDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherAnalogRingFreqEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 550,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSigOtherAnalogRingFreqEnum,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingParDefChcEnum[] =
{
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
   &mgMgcoSigOtherAnalogRingCadEnumDef,
   &mgMgcoSigOtherAnalogRingFreqEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoSigOtherAnalogRingCadDef,
   &mgMgcoSigOtherAnalogRingFreqDef
};

PUBLIC U8 mgMgcoSigOtherAnalogRingParDefChcIdx[] = 
   {0, 0, 0, 0, 0, 0, 1, 2};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigOtherAnalogRingParDefChc =
{
   3,
   8,
   mgMgcoSigOtherAnalogRingParDefChcIdx,
   mgMgcoSigOtherAnalogRingParDefChcElmnts,
   mgMgcoSigOtherAnalogRingParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingParDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherAnalogRingPar",
   "SigOtherAnalogRingPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 551,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigOtherAnalogRingParDefChc,
   mgMgcoRegExpSigOtherAnalogRingPar
};


PUBLIC CmAbnfElmDef *mgMgcoSigOtherAnalogRingDefChcElmnts[] =
{
   &mgMgcoSigOtherUnknownDef,
   &mgMgcoSigOtherSkipAllDef,
   &mgMgcoSigOtherAnalogRingParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSigOtherAnalogRingDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSigOtherAnalogRingDefChcElmnts,
   mgMgcoGenTypeEnum
};


PUBLIC CmAbnfElmDef mgMgcoSigOtherAnalogRingDef =
{
#ifdef CM_ABNF_DBG
   "SigOtherAnalogRing",
   "SigOtherAnalogRingType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 552,
   sizeof(MgMgcoSigOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSigOtherAnalogRingDefChc,
   mgMgcoRegExpSigOtherAnalogRingType
};

PUBLIC CmAbnfElmDef *mgMgcoSignalAnalogRingParmDefChcElmnts[] =
{
   &mgMgcoSigOtherAnalogRingDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoSigTypeDef,
   &mgMgcoSigDurationDef,
   &mgMgcoSigNtfyCmplDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalAnalogRingParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoSignalAnalogRingParmDefChcElmnts,
   mgMgcoSigParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalAnalogRingParmDef =
{
#ifdef CM_ABNF_DBG
   "SignalAnalogRing - parameter",
   "SigPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 553,
   sizeof(MgMgcoSigPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalAnalogRingParmDefChc,
   mgMgcoRegExpSigPar
};

PUBLIC CmAbnfElmDef *mgMgcoSignalAnalogRingParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoSignalAnalogRingParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoSignalAnalogRingParmArrayDefSeqOf =
{
   1,
   MGT_MAX_SIGPARS,
   2,
   mgMgcoSignalAnalogRingParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoSigPar)
};

PUBLIC CmAbnfElmDef mgMgcoSignalAnalogRingParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "SignalAnalogRing - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 554,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoSignalAnalogRingParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoSignalAnalogRingParmLstDefSeqElmnts[] =
{
   &mgMgcoSignalAnalogRingParmDef,
   &mgMgcoSignalAnalogRingParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalAnalogRingParmLstDefSeq =
{
   2,
   mgMgcoSignalAnalogRingParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalAnalogRingParmLstDef =
{
#ifdef CM_ABNF_DBG
   "SignalAnalogRing - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 555,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoSignalAnalogRingParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSignalAnalogRingDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoSignalAnalogRingParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalAnalogRingDefSeq =
{
   3,
   mgMgcoSignalAnalogRingDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalAnalogRingDef =
{
#ifdef CM_ABNF_DBG
   "AnalogRing - signal parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 556,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoSignalAnalogRingDefSeq,
   mgMgcoRegExpLBRKT
};

PUBLIC CmAbnfElmTypeEnum mgMgcoSignalAnalogRingEnum =
{
   (Data *)"ri",
   MGT_PKG_ANALOG_SIG_RI
};

PUBLIC CmAbnfElmDef mgMgcoSignalAnalogRingEnumDef =
{
#ifdef CM_ABNF_DBG
   "SignalAnalogRingEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 557,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSignalAnalogRingEnum,
   NULLP
};


PUBLIC CmAbnfElmDef *mgMgcoSignalAnalogRealDefChcEnum[] =
{
   NULLP,
   NULLP,
   &mgMgcoSignalAnalogRingEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoSignalAnalogRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoSignalAnalogRingDef
};

PUBLIC U8 mgMgcoSignalAnalogRealDefChcIdx[] = {0, 0, 1};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalAnalogRealDefChc =
{
   2,
   3,
   mgMgcoSignalAnalogRealDefChcIdx,
   mgMgcoSignalAnalogRealDefChcElmnts,
   mgMgcoSignalAnalogRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalAnalogRealDef =
{
#ifdef CM_ABNF_DBG
   "Real signal - package Analog",
   "SigNameAnalog",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 558,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalAnalogRealDefChc,
   mgMgcoRegExpSigNameAnalog
};

PUBLIC CmAbnfElmDef *mgMgcoSignalAnalogChcDefChcElmnts[] =
{
   &mgMgcoSignalUnknownDef,
   &mgMgcoSignalSkipAllDef,
   &mgMgcoSignalAnalogRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalAnalogChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSignalAnalogChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalAnalogChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of signals in package Analog",
   "PkgAnalogSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 559,
   sizeof(MgMgcoName) + sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalAnalogChcDefChc,
   mgMgcoRegExpPkgAnalogSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSignalAnalogDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSignalAnalogChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalAnalogDefSeq =
{
   3,
   mgMgcoSignalAnalogDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalAnalogDef =
{
#ifdef CM_ABNF_DBG
   "Signal request - package Analog",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 560,
   sizeof(MgMgcoSignalsReq) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSignalAnalogDefSeq,
   NULLP
};

/************************************************************************
                        Statistics - None
************************************************************************/
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_CONT
/************************************************************************
      
               Package - Basic Continuity (ct) (0x000a)

************************************************************************/

/************************************************************************
                           Properties - none
************************************************************************/

/************************************************************************
                              Events
************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoContCmpResFailureEnum =
{
   (Data *)"failure",
   MGT_PKG_CONT_EVT_CMP_RES_FAILURE
};

PUBLIC CmAbnfElmDef mgMgcoContCmpResFailureEnumDef =
{
#ifdef CM_ABNF_DBG
   "ContCmpRes - Failure enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 561,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoContCmpResFailureEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoContCmpResSuccessEnum =
{
   (Data *)"success",
   MGT_PKG_CONT_EVT_CMP_RES_SUCCESS
};

PUBLIC CmAbnfElmDef mgMgcoContCmpResSuccessEnumDef =
{
#ifdef CM_ABNF_DBG
   "ContCmpRes - Success enum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 562,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoContCmpResSuccessEnum,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpResValueChcEnum[] =
{
   &mgMgcoContCmpResFailureEnumDef,
   &mgMgcoContCmpResSuccessEnumDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherContCmpResValueChc =
{
   2,
   0,
   NULLP,
   NULLP,
   mgMgcoObsEvtOtherContCmpResValueChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpResValue =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherContCmpResValue",
   "ObsEvtOtherContCmpResValue",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 563,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherContCmpResValueChc,
   mgMgcoRegExpObsEvtOtherContCmpResValue
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpResValDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherContCmpResValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherContCmpResValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoObsEvtOtherContCmpResValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpResValDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherContCmpResVal",
   "ParmValEnume",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 564,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherContCmpResValDefChc,
   mgMgcoRegExpParmValEnume
};


/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpResValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoObsEvtOtherContCmpResValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherContCmpResValEqDefSeq =
{
   2,
   mgMgcoObsEvtOtherContCmpResValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpResValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 565,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherContCmpResValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpResValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoObsEvtOtherContCmpResValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherContCmpResValGtDefSeq =
{
   2,
   mgMgcoObsEvtOtherContCmpResValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpResValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 566,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoObsEvtOtherContCmpResValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpResValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoObsEvtOtherContCmpResValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherContCmpResValLtDefSeq =
{
   2,
   mgMgcoObsEvtOtherContCmpResValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpResValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 567,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherContCmpResValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpResValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoObsEvtOtherContCmpResValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherContCmpResValNeDefSeq =
{
   2,
   mgMgcoObsEvtOtherContCmpResValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpResValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 568,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherContCmpResValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpResValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoObsEvtOtherContCmpResValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoObsEvtOtherContCmpResValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoObsEvtOtherContCmpResValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpResValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 569,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoObsEvtOtherContCmpResValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpResValLstDefSeqElmnts[]   =
{
   &mgMgcoObsEvtOtherContCmpResValDef,
   &mgMgcoObsEvtOtherContCmpResValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherContCmpResValLstDefSeq =
{
   2,
   mgMgcoObsEvtOtherContCmpResValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpResValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 570,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoObsEvtOtherContCmpResValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpResValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherContCmpResValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherContCmpResValAndDefSeq =
{
   4,
   mgMgcoObsEvtOtherContCmpResValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpResValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 571,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherContCmpResValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpResValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoObsEvtOtherContCmpResValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherContCmpResValOrDefSeq =
{
   4,
   mgMgcoObsEvtOtherContCmpResValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpResValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 572,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherContCmpResValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpResValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherContCmpResValDef,
   &cmMsgDefMetaColon,
   &mgMgcoObsEvtOtherContCmpResValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherContCmpResValRngDefSeq =
{
   6,
   mgMgcoObsEvtOtherContCmpResValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpResValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 573,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoObsEvtOtherContCmpResValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpResDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherContCmpResValEqDef,
   &mgMgcoObsEvtOtherContCmpResValGtDef,
   &mgMgcoObsEvtOtherContCmpResValLtDef,
   &mgMgcoObsEvtOtherContCmpResValNeDef,
   &mgMgcoObsEvtOtherContCmpResValAndDef,
   &mgMgcoObsEvtOtherContCmpResValOrDef,
   &mgMgcoObsEvtOtherContCmpResValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherContCmpResDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoObsEvtOtherContCmpResDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpResDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherContCmpRes",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 574,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherContCmpResDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoObsEvtOtherContCmpResEnum =
{
   (Data *)"res",
   MGT_PKG_CONT_EVT_CMP_RES
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpResEnumDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherContCmpResEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 575,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoObsEvtOtherContCmpResEnum,
   NULLP
};


/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoObsEvtOtherContCmpResDef
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpParDefChcEnum[] =
{
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
   &mgMgcoObsEvtOtherContCmpResEnumDef
};

PUBLIC U8 mgMgcoObsEvtOtherContCmpParDefChcIdx[] =
   { 0, 0, 0, 0, 0, 0, 0, 0, 1};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherContCmpParDefChc =
{
   2,
   9,
   mgMgcoObsEvtOtherContCmpParDefChcIdx,
   mgMgcoObsEvtOtherContCmpParDefChcElmnts,
   mgMgcoObsEvtOtherContCmpParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpParDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherContCmpPar",
   "ObsEvtOtherContCmpPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 576,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherContCmpParDefChc,
   mgMgcoRegExpObsEvtOtherContCmpPar
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecContCmpParmDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherContCmpDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecContCmpParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecContCmpParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecContCmpParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecContCmp - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 577,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecContCmpParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecContCmpParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecContCmpParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecContCmpParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecContCmpParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecContCmpParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecContCmp - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 578,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecContCmpParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecContCmpParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecContCmpParmDef,
   &mgMgcoEvSpecContCmpParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecContCmpParmLstDefSeq =
{
   2,
   mgMgcoEvSpecContCmpParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecContCmpParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecContCmp - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 579,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecContCmpParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecContCmpDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecContCmpParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecContCmpDefSeq =
{
   3,
   mgMgcoEvSpecContCmpDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecContCmpDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecContCmp - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 580,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecContCmpDefSeq,
   mgMgcoRegExpLBRKT
};


/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtContCmpParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtContCmpParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtContCmpParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtContCmpParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtContCmp - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 581,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtContCmpParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtContCmpParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtContCmpParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtContCmpParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtContCmpParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtContCmpParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtContCmp - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 582,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtContCmpParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtContCmpParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtContCmpParmDef,
   &mgMgcoReqEvtContCmpParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtContCmpParmLstDefSeq =
{
   2,
   mgMgcoReqEvtContCmpParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtContCmpParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtContCmp - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 583,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtContCmpParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtContCmpDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtContCmpParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtContCmpDefSeq =
{
   3,
   mgMgcoReqEvtContCmpDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtContCmpDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtContCmp - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 584,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtContCmpDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherContCmpDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoObsEvtOtherContCmpParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherContCmpDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherContCmpDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherContCmpDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherContCmp",
   "ObsEvtOtherContCmpType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 585,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherContCmpDefChc,
   mgMgcoRegExpObsEvtOtherContCmpType
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecContCmpParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecContCmpParmDefChc =
{
   5,
   6,       
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecContCmpParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecContCmpParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecContCmp - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 586,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecContCmpParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecContCmpParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecContCmpParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecContCmpParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecContCmpParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecContCmpParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecContCmp - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 587,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecContCmpParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecContCmpParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecContCmpParmDef,
   &mgMgcoEvtSecContCmpParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecContCmpParmLstDefSeq =
{
   2,
   mgMgcoEvtSecContCmpParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecContCmpParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecContCmp - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 588,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecContCmpParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecContCmpDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecContCmpParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecContCmpDefSeq =
{
   3,
   mgMgcoEvtSecContCmpDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecContCmpDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecContCmp - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 589,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecContCmpDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEventContCmpEnum =
{
   (Data *)"cmp",
   MGT_PKG_CONT_EVT_CMP
};

PUBLIC CmAbnfElmDef mgMgcoEventContCmpEnumDef =
{
#ifdef CM_ABNF_DBG
   "Event enum - Cont - Cmp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 590,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventContCmpEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEventContRealDefChcEnum[] =
{
   NULLP, NULLP, NULLP, NULLP, NULLP,
   &mgMgcoEventContCmpEnumDef
};

PUBLIC U8 mgMgcoEventContRealDefChcIdx[] = {0, 0, 0, 0, 0, 1};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecContRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecContCmpDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecContRealDefChc =
{
   2,
   6,
   mgMgcoEventContRealDefChcIdx,
   mgMgcoEvtSecContRealDefChcElmnts,
   mgMgcoEventContRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecContRealDef =
{
#ifdef CM_ABNF_DBG
   "Real second requested event - package Cont",
   "EvtNameCont",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 591,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecContRealDefChc,
   mgMgcoRegExpEvtNameCont
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecContChcDefChcElmnts[] =
{
   &mgMgcoEvtSecUnknownNameDef,
   &mgMgcoEvtSecSkipAllDef,
   &mgMgcoEvtSecContRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecContChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtSecContChcDefChcElmnts,
   mgMgcoGenTypeEnum 
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecContChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of second req event in package Cont",
   "PkgContEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 592,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecContChcDefChc,
   mgMgcoRegExpPkgContEvtType
};

/* Second requested event */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecContDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvtSecContChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecContDefSeq =
{
   3,
   mgMgcoEvtSecContDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecContDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - package Cont",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 593,
   sizeof(MgMgcoEvtSec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecContDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtContRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtContCmpDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtContRealDefChc =
{
   2,
   6,
   mgMgcoEventContRealDefChcIdx,
   mgMgcoReqEvtContRealDefChcElmnts,
   mgMgcoEventContRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtContRealDef =
{
#ifdef CM_ABNF_DBG
   "Real requested event - package Cont",
   "EvtNameCont",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 594,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtContRealDefChc,
   mgMgcoRegExpEvtNameCont
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtContChcDefChcElmnts[] =
{
   &mgMgcoReqEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoReqEvtContRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtContChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtContChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtContChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of requested event in package Cont",
   "PkgContEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 595,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtContChcDefChc,
   mgMgcoRegExpPkgContEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtContDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoReqEvtContChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtContDefSeq =
{
   3,
   mgMgcoReqEvtContDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtContDef =
{
#ifdef CM_ABNF_DBG
   "Requested event - package Cont",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 596,
   sizeof(MgMgcoReqEvt) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtContDefSeq,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtContRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecContCmpDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtContRealDefChc =
{
   2,
   6,
   mgMgcoEventContRealDefChcIdx,
   mgMgcoObsEvtContRealDefChcElmnts,
   mgMgcoEventContRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtContRealDef =
{
#ifdef CM_ABNF_DBG
   "Real observed event - package Cont",
   "EvtNameCont",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 597,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtContRealDefChc,
   mgMgcoRegExpEvtNameCont
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtContChcDefChcElmnts[] =
{
   &mgMgcoObsEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoObsEvtContRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtContChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtContChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtContChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of observed event in package Cont",
   "PkgContEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 598,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtContChcDefChc,
   mgMgcoRegExpPkgContEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtContDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoObsEvtContChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtContDefSeq =
{
   3,
   mgMgcoObsEvtContDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtContDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - package Cont",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 599,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtContDefSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecContRealDefChc =
{
   2,
   6,
   mgMgcoEventContRealDefChcIdx,
   mgMgcoObsEvtContRealDefChcElmnts,
   mgMgcoEventContRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecContRealDef =
{
#ifdef CM_ABNF_DBG
   "Real event spec -  package Cont",
   "EvtNameCont",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 600,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecContRealDefChc,
   mgMgcoRegExpEvtNameCont
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecContChcDefChcElmnts[] =
{
   &mgMgcoEvSpecUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoEvSpecContRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecContChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecContChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecContChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of event spec in package Cont",
   "PkgContEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 601,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecContChcDefChc,
   mgMgcoRegExpPkgContEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecContDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvSpecContChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecContDefSeq =
{
   3,
   mgMgcoEvSpecContDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecContDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - package Cont",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 602,
   sizeof(MgMgcoEvSpec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecContDefSeq,
   NULLP
};

/************************************************************************
                              Signals
************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoSignalContCtOrRspParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef,
   &mgMgcoSigTypeDef,
   &mgMgcoSigDurationDef,
   &mgMgcoSigNtfyCmplDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalContCtOrRspParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoSignalContCtOrRspParmDefChcElmnts,
   mgMgcoSigParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalContCtOrRspParmDef =
{
#ifdef CM_ABNF_DBG
   "SignalContCtOrRsp - parameter",
   "SigPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 603,
   sizeof(MgMgcoSigPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalContCtOrRspParmDefChc,
   mgMgcoRegExpSigPar
};

PUBLIC CmAbnfElmDef *mgMgcoSignalContCtOrRspParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoSignalContCtOrRspParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoSignalContCtOrRspParmArrayDefSeqOf =
{
   1,
   MGT_MAX_SIGPARS,
   2,
   mgMgcoSignalContCtOrRspParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoSigPar)
};

PUBLIC CmAbnfElmDef mgMgcoSignalContCtOrRspParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "SignalContCtOrRsp - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 604,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoSignalContCtOrRspParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoSignalContCtOrRspParmLstDefSeqElmnts[] =
{
   &mgMgcoSignalContCtOrRspParmDef,
   &mgMgcoSignalContCtOrRspParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalContCtOrRspParmLstDefSeq =
{
   2,
   mgMgcoSignalContCtOrRspParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalContCtOrRspParmLstDef =
{
#ifdef CM_ABNF_DBG
   "SignalContCtOrRsp - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 605,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoSignalContCtOrRspParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSignalContCtOrRspDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoSignalContCtOrRspParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalContCtOrRspDefSeq =
{
   3,
   mgMgcoSignalContCtOrRspDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalContCtOrRspDef =
{
#ifdef CM_ABNF_DBG
   "ContCtOrRsp - signal parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 606,
   sizeof(MgMgcoSigParLst),
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoSignalContCtOrRspDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoSignalContCtEnum =
{
   (Data *)"ct",
   MGT_PKG_CONT_SIG_CT
};

PUBLIC CmAbnfElmDef mgMgcoSignalContCtEnumDef =
{
#ifdef CM_ABNF_DBG
   "SignalContCtEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 607,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSignalContCtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoSignalContRspEnum =
{
   (Data *)"rsp",
   MGT_PKG_CONT_SIG_RSP
};

PUBLIC CmAbnfElmDef mgMgcoSignalContRspEnumDef =
{
#ifdef CM_ABNF_DBG
   "SignalContRspEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 608,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoSignalContRspEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoSignalContRealDefChcEnum[] =
{
   NULLP, NULLP, NULLP,
   &mgMgcoSignalContCtEnumDef,
   &mgMgcoSignalContRspEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoSignalContRealDefChcElmnts[] =
{
   NULLP, NULLP, NULLP,
   &mgMgcoSignalContCtOrRspDef,
   &mgMgcoSignalContCtOrRspDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalContRealDefChc =
{
   5,
   0,
   NULLP,
   mgMgcoSignalContRealDefChcElmnts,
   mgMgcoSignalContRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalContRealDef =
{
#ifdef CM_ABNF_DBG
   "Real signal - package Cont",
   "SigNameCont",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 609,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalContRealDefChc,
   mgMgcoRegExpSigNameCont
};

PUBLIC CmAbnfElmDef *mgMgcoSignalContChcDefChcElmnts[] =
{
   &mgMgcoSignalUnknownDef,
   &mgMgcoSignalSkipAllDef,
   &mgMgcoSignalContRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoSignalContChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoSignalContChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoSignalContChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of signals in package Cont",
   "PkgContSigType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 610,
   sizeof(MgMgcoName) + sizeof(MgMgcoSigParLst),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoSignalContChcDefChc,
   mgMgcoRegExpPkgContSigType
};

PUBLIC CmAbnfElmDef *mgMgcoSignalContDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoSignalContChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoSignalContDefSeq =
{
   3,
   mgMgcoSignalContDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoSignalContDef =
{
#ifdef CM_ABNF_DBG
   "Signal request - package Cont",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 611,
   sizeof(MgMgcoSignalsReq) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoSignalContDefSeq,
   NULLP
};

/************************************************************************
                        Statistics - None
************************************************************************/
#endif /* GCP_PKG_MGCO_CONT */

#if (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) || \
     defined(GCP_PKG_MGCO_TDMC))
/************************************************************************

               Package - Network (nt) (0x000b)

************************************************************************/

/************************************************************************
                           Properties
************************************************************************/

PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkJitValDecUintDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNetworkJitValDecUint",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 612,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoU32DefRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkJitValDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmNetworkJitValDecUintDef,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNetworkJitValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoPropParmNetworkJitValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkJitValDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNetworkJitVal",
   "ParmValDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 613,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNetworkJitValDefChc,
   mgMgcoRegExpParmValDecUint
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkEqJitValDefSeqElmnts[] =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmNetworkJitValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNetworkEqJitValDefSeq =
{
   2,
   mgMgcoPropParmNetworkEqJitValDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkEqJitValDef =
{
#ifdef CM_ABNF_DBG
   "== PropParmNetworkJitVal",
   "EQUAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 614,
   sizeof(MgMgcoValue),
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNetworkEqJitValDefSeq,
   mgMgcoRegExpEQUAL
};


/* = value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkJitValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmNetworkJitValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNetworkJitValEqDefSeq =
{
   2,
   mgMgcoPropParmNetworkJitValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkJitValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 615,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNetworkJitValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkJitValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoPropParmNetworkJitValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNetworkJitValGtDefSeq =
{
   2,
   mgMgcoPropParmNetworkJitValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkJitValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 616,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoPropParmNetworkJitValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkJitValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoPropParmNetworkJitValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNetworkJitValLtDefSeq =
{
   2,
   mgMgcoPropParmNetworkJitValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkJitValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 617,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNetworkJitValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkJitValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoPropParmNetworkJitValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNetworkJitValNeDefSeq =
{
   2,
   mgMgcoPropParmNetworkJitValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkJitValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 618,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNetworkJitValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkJitValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmNetworkJitValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmNetworkJitValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoPropParmNetworkJitValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkJitValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 619,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmNetworkJitValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkJitValLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmNetworkJitValDef,
   &mgMgcoPropParmNetworkJitValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNetworkJitValLstDefSeq =
{
   2,
   mgMgcoPropParmNetworkJitValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkJitValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 620,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmNetworkJitValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkJitValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNetworkJitValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNetworkJitValAndDefSeq =
{
   4,
   mgMgcoPropParmNetworkJitValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkJitValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 621,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNetworkJitValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkJitValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPropParmNetworkJitValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNetworkJitValOrDefSeq =
{
   4,
   mgMgcoPropParmNetworkJitValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkJitValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 622,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNetworkJitValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkJitValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmNetworkJitValDef,
   &cmMsgDefMetaColon,
   &mgMgcoPropParmNetworkJitValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNetworkJitValRngDefSeq =
{
   6,
   mgMgcoPropParmNetworkJitValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkJitValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 623,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPropParmNetworkJitValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkJitDefChcElmnts[] =
{
   &mgMgcoPropParmNetworkJitValEqDef,
   &mgMgcoPropParmNetworkJitValGtDef,
   &mgMgcoPropParmNetworkJitValLtDef,
   &mgMgcoPropParmNetworkJitValNeDef,
   &mgMgcoPropParmNetworkJitValAndDef,
   &mgMgcoPropParmNetworkJitValOrDef,
   &mgMgcoPropParmNetworkJitValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNetworkJitDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmNetworkJitDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkJitDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNetworkJit",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 624,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNetworkJitDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmNetworkJitEnum =
{
   (Data *)"jit",
   MGT_PKG_NETWORK_PROP_JIT
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkJitEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNetworkJitEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 625,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmNetworkJitEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmNetworkJitDef
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkRealDefChcEnum[] =
{
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
   &mgMgcoPropParmNetworkJitEnumDef
};

PUBLIC U8 mgMgcoPropParmNetworkRealDefChcIdx[] = {0, 0, 0, 0, 0, 0, 0, 1};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNetworkRealDefChc =
{
   2,
   8,
   mgMgcoPropParmNetworkRealDefChcIdx,
   mgMgcoPropParmNetworkRealDefChcElmnts,
   mgMgcoPropParmNetworkRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkRealDef =
{
#ifdef CM_ABNF_DBG
   "PropParmNetwork",
   "PropParmNetwork",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 626,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNetworkRealDefChc,
   mgMgcoRegExpPropParmNetwork
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkChcDefChcElmnts[] =
{
   &mgMgcoPropParmUnknownDef,
   &mgMgcoPropParmSkipAllDef,
   &mgMgcoPropParmNetworkRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmNetworkChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoPropParmNetworkChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of property parameter in package Network",
   "PkgNetworkPropType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 627,
   sizeof(MgMgcoName) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmNetworkChcDefChc,
   mgMgcoRegExpPkgNetworkPropType 
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmNetworkDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoPropParmNetworkChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmNetworkDefSeq =
{
   3,
   mgMgcoPropParmNetworkDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoPropParmNetworkDef =
{
#ifdef CM_ABNF_DBG
   "Property parameter - package Network",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 628,
   sizeof(MgMgcoPropParm) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmNetworkDefSeq,
   NULLP
};

/************************************************************************
                              Events
************************************************************************/

PUBLIC CmAbnfElmTypeRange mgMgcoObsEvtOtherNetworkNetfailCauseValueRng =
{
   1,
   0xFFFF
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailCauseValue =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNetworkNetfailCauseValue",
   "Value",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 629,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailCauseValueRng,
   mgMgcoRegExpValue
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailCauseValDefChcElmnts[] =
{
   NULLP, NULLP, NULLP, 
   &mgMgcoObsEvtOtherNetworkNetfailCauseValue,
   NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNetworkNetfailCauseValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoObsEvtOtherNetworkNetfailCauseValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailCauseValDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNetworkNetfailCauseVal",
   "ParmValOctStrXL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 630,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailCauseValDefChc,
   mgMgcoRegExpParmValOctStrXL
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailCauseValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNetworkNetfailCauseValEqDefSeq =
{
   2,
   mgMgcoObsEvtOtherNetworkNetfailCauseValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailCauseValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 631,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailCauseValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailCauseValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNetworkNetfailCauseValGtDefSeq =
{
   2,
   mgMgcoObsEvtOtherNetworkNetfailCauseValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailCauseValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 632,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailCauseValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailCauseValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNetworkNetfailCauseValLtDefSeq =
{
   2,
   mgMgcoObsEvtOtherNetworkNetfailCauseValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailCauseValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 633,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailCauseValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailCauseValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNetworkNetfailCauseValNeDefSeq =
{
   2,
   mgMgcoObsEvtOtherNetworkNetfailCauseValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailCauseValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 634,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailCauseValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailCauseValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoObsEvtOtherNetworkNetfailCauseValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoObsEvtOtherNetworkNetfailCauseValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailCauseValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 635,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailCauseValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailCauseValLstDefSeqElmnts[]   =
{
   &mgMgcoObsEvtOtherNetworkNetfailCauseValDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNetworkNetfailCauseValLstDefSeq =
{
   2,
   mgMgcoObsEvtOtherNetworkNetfailCauseValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailCauseValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 636,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailCauseValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailCauseValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNetworkNetfailCauseValAndDefSeq =
{
   4,
   mgMgcoObsEvtOtherNetworkNetfailCauseValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailCauseValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 637,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailCauseValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailCauseValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNetworkNetfailCauseValOrDefSeq =
{
   4,
   mgMgcoObsEvtOtherNetworkNetfailCauseValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailCauseValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 638,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailCauseValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailCauseValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValDef,
   &cmMsgDefMetaColon,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherNetworkNetfailCauseValRngDefSeq =
{
   6,
   mgMgcoObsEvtOtherNetworkNetfailCauseValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailCauseValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 639,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailCauseValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailCauseDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherNetworkNetfailCauseValEqDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValGtDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValLtDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValNeDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValAndDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValOrDef,
   &mgMgcoObsEvtOtherNetworkNetfailCauseValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNetworkNetfailCauseDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoObsEvtOtherNetworkNetfailCauseDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailCauseDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNetworkNetfailCause",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 640,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailCauseDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange mgMgcoEvtOtherNetworkQualertThValueRng
           = {1, 2, 0, 99};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange    mgMgcoEvtOtherNetworkQualertThValueRng
           = {1, 2};
#endif /* CM_ABNF_V_1_2 */


PUBLIC CmAbnfElmDef mgMgcoEvtOtherNetworkQualertThValue =
{
#ifdef CM_ABNF_DBG
   "EvtOtherNetworkQualertThValue",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 641,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&mgMgcoEvtOtherNetworkQualertThValueRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherNetworkQualertThValDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtOtherNetworkQualertThValue,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherNetworkQualertThValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoEvtOtherNetworkQualertThValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherNetworkQualertThValDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherNetworkQualertThVal",
   "ParmValueDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 642,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherNetworkQualertThValDefChc,
   mgMgcoRegExpParmValDecUint
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherNetworkQualertThValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoEvtOtherNetworkQualertThValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherNetworkQualertThValEqDefSeq =
{
   2,
   mgMgcoEvtOtherNetworkQualertThValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherNetworkQualertThValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 643,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherNetworkQualertThValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherNetworkQualertThValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoEvtOtherNetworkQualertThValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherNetworkQualertThValGtDefSeq =
{
   2,
   mgMgcoEvtOtherNetworkQualertThValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherNetworkQualertThValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 644,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoEvtOtherNetworkQualertThValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherNetworkQualertThValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoEvtOtherNetworkQualertThValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherNetworkQualertThValLtDefSeq =
{
   2,
   mgMgcoEvtOtherNetworkQualertThValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherNetworkQualertThValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 645,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherNetworkQualertThValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherNetworkQualertThValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoEvtOtherNetworkQualertThValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherNetworkQualertThValNeDefSeq =
{
   2,
   mgMgcoEvtOtherNetworkQualertThValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherNetworkQualertThValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 646,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherNetworkQualertThValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherNetworkQualertThValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtOtherNetworkQualertThValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtOtherNetworkQualertThValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoEvtOtherNetworkQualertThValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherNetworkQualertThValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 647,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtOtherNetworkQualertThValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherNetworkQualertThValLstDefSeqElmnts[]   =
{
   &mgMgcoEvtOtherNetworkQualertThValDef,
   &mgMgcoEvtOtherNetworkQualertThValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherNetworkQualertThValLstDefSeq =
{
   2,
   mgMgcoEvtOtherNetworkQualertThValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherNetworkQualertThValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 648,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtOtherNetworkQualertThValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherNetworkQualertThValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoEvtOtherNetworkQualertThValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherNetworkQualertThValAndDefSeq =
{
   4,
   mgMgcoEvtOtherNetworkQualertThValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherNetworkQualertThValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 649,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherNetworkQualertThValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherNetworkQualertThValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoEvtOtherNetworkQualertThValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherNetworkQualertThValOrDefSeq =
{
   4,
   mgMgcoEvtOtherNetworkQualertThValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherNetworkQualertThValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 650,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtOtherNetworkQualertThValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoEvtOtherNetworkQualertThValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoEvtOtherNetworkQualertThValDef,
   &cmMsgDefMetaColon,
   &mgMgcoEvtOtherNetworkQualertThValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtOtherNetworkQualertThValRngDefSeq =
{
   6,
   mgMgcoEvtOtherNetworkQualertThValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoEvtOtherNetworkQualertThValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 651,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoEvtOtherNetworkQualertThValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtOtherNetworkQualertThDefChcElmnts[] =
{
   &mgMgcoEvtOtherNetworkQualertThValEqDef,
   &mgMgcoEvtOtherNetworkQualertThValGtDef,
   &mgMgcoEvtOtherNetworkQualertThValLtDef,
   &mgMgcoEvtOtherNetworkQualertThValNeDef,
   &mgMgcoEvtOtherNetworkQualertThValAndDef,
   &mgMgcoEvtOtherNetworkQualertThValOrDef,
   &mgMgcoEvtOtherNetworkQualertThValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtOtherNetworkQualertThDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoEvtOtherNetworkQualertThDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherNetworkQualertThDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherNetworkQualertTh",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 652,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtOtherNetworkQualertThDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherNetworkQualertThEnum =
{
   (Data *)"th",
   MGT_PKG_NETWORK_EVT_QUALERT_TH
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherNetworkQualertThEnumDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherNetworkQualertThEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 653,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherNetworkQualertThEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherNetworkQualertParDefChcEnum[] =
{
   NULLP,
   &mgMgcoEvtOtherNetworkQualertThEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherNetworkQualertParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtOtherNetworkQualertThDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherNetworkQualertParDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoReqEvtOtherNetworkQualertParDefChcElmnts,
   mgMgcoReqEvtOtherNetworkQualertParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherNetworkQualertParDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherNetworkQualertPar",
   "ReqEvtOtherNetworkQualertPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 654,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherNetworkQualertParDefChc,
   mgMgcoRegExpReqEvtOtherNetworkQualertPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtOtherNetworkQualertDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoReqEvtOtherNetworkQualertParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtOtherNetworkQualertDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtOtherNetworkQualertDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtOtherNetworkQualertDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtOtherNetworkQualert",
   "ReqEvtOtherNetworkQualertType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 655,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtOtherNetworkQualertDefChc,
   mgMgcoRegExpReqEvtOtherNetworkQualertType
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoObsEvtOtherNetworkNetfailCauseEnum =
{
   (Data *)"cs",
   MGT_PKG_NETWORK_EVT_NETFAIL_CAUSE
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailCauseEnumDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNetworkNetfailCauseEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 656,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailCauseEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailParDefChcEnum[] =
{
   NULLP,
   &mgMgcoObsEvtOtherNetworkNetfailCauseEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoObsEvtOtherNetworkNetfailCauseDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNetworkNetfailParDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoObsEvtOtherNetworkNetfailParDefChcElmnts,
   mgMgcoObsEvtOtherNetworkNetfailParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailParDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNetworkNetfailPar",
   "ObsEvtOtherNetworkNetfailPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 657,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailParDefChc,
   mgMgcoRegExpObsEvtOtherNetworkNetfailPar
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkNetfailDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoObsEvtOtherNetworkNetfailParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNetworkNetfailDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherNetworkNetfailDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkNetfailDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNetworkNetfail",
   "ObsEvtOtherNetworkNetfailType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 658,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNetworkNetfailDefChc,
   mgMgcoRegExpObsEvtOtherNetworkNetfailType
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkQualertParDefChcEnum[] =
{
   NULLP,
   &mgMgcoEvtOtherNetworkQualertThEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkQualertParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtOtherNetworkQualertThDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNetworkQualertParDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoObsEvtOtherNetworkQualertParDefChcElmnts,
   mgMgcoObsEvtOtherNetworkQualertParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkQualertParDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNetworkQualertPar",
   "ObsEvtOtherNetworkQualertPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 659,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNetworkQualertParDefChc,
   mgMgcoRegExpObsEvtOtherNetworkQualertPar
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherNetworkQualertDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoObsEvtOtherNetworkQualertParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherNetworkQualertDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherNetworkQualertDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherNetworkQualertDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherNetworkQualert",
   "ObsEvtOtherNetworkQualertType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 660,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherNetworkQualertDefChc,
   mgMgcoRegExpObsEvtOtherNetworkQualertType
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEventNetworkNetfailEnum =
{
   (Data *)"netfail",
   MGT_PKG_NETWORK_EVT_NETFAIL
};

PUBLIC CmAbnfElmDef mgMgcoEventNetworkNetfailEnumDef =
{
#ifdef CM_ABNF_DBG
   "EventNetworkNetfailEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 661,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventNetworkNetfailEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoEventNetworkQualertEnum =
{
   (Data *)"qualert",
   MGT_PKG_NETWORK_EVT_QUALERT
};

PUBLIC CmAbnfElmDef mgMgcoEventNetworkQualertEnumDef =
{
#ifdef CM_ABNF_DBG
   "EventNetworkQualertEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 662,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventNetworkQualertEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEventNetworkRealDefChcEnum[] =
{
   NULLP, NULLP, NULLP, NULLP, NULLP,
   &mgMgcoEventNetworkNetfailEnumDef,
   &mgMgcoEventNetworkQualertEnumDef
};

PUBLIC U8 mgMgcoEventNetworkRealDefChcIdx[] = {0, 0, 0, 0, 0, 1, 2};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNetworkNetfailParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNetworkNetfailParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtNetworkNetfailParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNetworkNetfailParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNetworkNetfail - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 663,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNetworkNetfailParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNetworkNetfailParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtNetworkNetfailParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtNetworkNetfailParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtNetworkNetfailParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNetworkNetfailParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNetworkNetfail - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 664,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtNetworkNetfailParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNetworkNetfailParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtNetworkNetfailParmDef,
   &mgMgcoReqEvtNetworkNetfailParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNetworkNetfailParmLstDefSeq =
{
   2,
   mgMgcoReqEvtNetworkNetfailParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNetworkNetfailParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNetworkNetfail - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 665,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtNetworkNetfailParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNetworkNetfailDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtNetworkNetfailParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNetworkNetfailDefSeq =
{
   3,
   mgMgcoReqEvtNetworkNetfailDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNetworkNetfailDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNetworkNetfail - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 666,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtNetworkNetfailDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNetworkQualertParmDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherNetworkQualertDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNetworkQualertParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtNetworkQualertParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNetworkQualertParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNetworkQualert - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 667,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNetworkQualertParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNetworkQualertParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtNetworkQualertParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtNetworkQualertParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtNetworkQualertParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNetworkQualertParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNetworkQualert - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 668,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtNetworkQualertParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNetworkQualertParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtNetworkQualertParmDef,
   &mgMgcoReqEvtNetworkQualertParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNetworkQualertParmLstDefSeq =
{
   2,
   mgMgcoReqEvtNetworkQualertParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNetworkQualertParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNetworkQualert - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 669,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtNetworkQualertParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNetworkQualertDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtNetworkQualertParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNetworkQualertDefSeq =
{
   3,
   mgMgcoReqEvtNetworkQualertDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNetworkQualertDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtNetworkQualert - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 670,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtNetworkQualertDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNetworkNetfailParmDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherNetworkNetfailDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNetworkNetfailParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecNetworkNetfailParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNetworkNetfailParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNetworkNetfail - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 671,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNetworkNetfailParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNetworkNetfailParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecNetworkNetfailParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecNetworkNetfailParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecNetworkNetfailParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNetworkNetfailParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNetworkNetfail - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 672,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecNetworkNetfailParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNetworkNetfailParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecNetworkNetfailParmDef,
   &mgMgcoEvSpecNetworkNetfailParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNetworkNetfailParmLstDefSeq =
{
   2,
   mgMgcoEvSpecNetworkNetfailParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNetworkNetfailParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNetworkNetfail - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 673,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecNetworkNetfailParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNetworkNetfailDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecNetworkNetfailParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNetworkNetfailDefSeq =
{
   3,
   mgMgcoEvSpecNetworkNetfailDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNetworkNetfailDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNetworkNetfail - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 674,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecNetworkNetfailDefSeq,
   mgMgcoRegExpLBRKT
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNetworkQualertParmDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherNetworkQualertDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNetworkQualertParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecNetworkQualertParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNetworkQualertParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNetworkQualert - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 675,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNetworkQualertParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNetworkQualertParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecNetworkQualertParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecNetworkQualertParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecNetworkQualertParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNetworkQualertParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNetworkQualert - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 676,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecNetworkQualertParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNetworkQualertParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecNetworkQualertParmDef,
   &mgMgcoEvSpecNetworkQualertParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNetworkQualertParmLstDefSeq =
{
   2,
   mgMgcoEvSpecNetworkQualertParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNetworkQualertParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNetworkQualert - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 677,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecNetworkQualertParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNetworkQualertDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecNetworkQualertParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNetworkQualertDefSeq =
{
   3,
   mgMgcoEvSpecNetworkQualertDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNetworkQualertDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecNetworkQualert - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 678,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecNetworkQualertDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNetworkNetfailParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNetworkNetfailParmDefChc =
{
   5,
   6,        
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecNetworkNetfailParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNetworkNetfailParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNetworkNetfail - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 679,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNetworkNetfailParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecNetworkNetfailParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecNetworkNetfailParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecNetworkNetfailParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecNetworkNetfailParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNetworkNetfailParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNetworkNetfail - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 680,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecNetworkNetfailParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNetworkNetfailParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecNetworkNetfailParmDef,
   &mgMgcoEvtSecNetworkNetfailParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNetworkNetfailParmLstDefSeq =
{
   2,
   mgMgcoEvtSecNetworkNetfailParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNetworkNetfailParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNetworkNetfail - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 681,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecNetworkNetfailParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNetworkNetfailDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecNetworkNetfailParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNetworkNetfailDefSeq =
{
   3,
   mgMgcoEvtSecNetworkNetfailDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNetworkNetfailDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNetworkNetfail - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 682,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecNetworkNetfailDefSeq,
   mgMgcoRegExpLBRKT
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNetworkQualertParmDefChcElmnts[] =
{
   &mgMgcoReqEvtOtherNetworkQualertDef,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNetworkQualertParmDefChc =
{
   5,
   6,       
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecNetworkQualertParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNetworkQualertParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNetworkQualert - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 683,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNetworkQualertParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecNetworkQualertParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecNetworkQualertParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecNetworkQualertParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecNetworkQualertParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNetworkQualertParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNetworkQualert - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 684,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecNetworkQualertParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNetworkQualertParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecNetworkQualertParmDef,
   &mgMgcoEvtSecNetworkQualertParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNetworkQualertParmLstDefSeq =
{
   2,
   mgMgcoEvtSecNetworkQualertParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNetworkQualertParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNetworkQualert - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 685,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecNetworkQualertParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNetworkQualertDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecNetworkQualertParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNetworkQualertDefSeq =
{
   3,
   mgMgcoEvtSecNetworkQualertDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNetworkQualertDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecNetworkQualert - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 686,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecNetworkQualertDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNetworkRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtNetworkNetfailDef,
   &mgMgcoReqEvtNetworkQualertDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNetworkRealDefChc =
{
   3,
   7,
   mgMgcoEventNetworkRealDefChcIdx,
   mgMgcoReqEvtNetworkRealDefChcElmnts,
   mgMgcoEventNetworkRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNetworkRealDef =
{
#ifdef CM_ABNF_DBG
   "Real requested event - package Network",
   "EvtNameNetwork",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 687,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNetworkRealDefChc,
   mgMgcoRegExpEvtNameNetwork
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNetworkChcDefChcElmnts[] =
{
   &mgMgcoReqEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoReqEvtNetworkRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtNetworkChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtNetworkChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNetworkChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of requested event in package Network",
   "PkgNetworkEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 688,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtNetworkChcDefChc,
   mgMgcoRegExpPkgNetworkEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtNetworkDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoReqEvtNetworkChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtNetworkDefSeq =
{
   3,
   mgMgcoReqEvtNetworkDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtNetworkDef =
{
#ifdef CM_ABNF_DBG
   "Requested event - package Network",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 689,
   sizeof(MgMgcoReqEvt) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtNetworkDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNetworkRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecNetworkNetfailDef,
   &mgMgcoEvtSecNetworkQualertDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNetworkRealDefChc =
{
   3,
   7,
   mgMgcoEventNetworkRealDefChcIdx,
   mgMgcoEvtSecNetworkRealDefChcElmnts,
   mgMgcoEventNetworkRealDefChcEnum
};


PUBLIC CmAbnfElmDef mgMgcoEvtSecNetworkRealDef =
{
#ifdef CM_ABNF_DBG
   "Real second requested event - package Network",
   "EvtNameNetwork",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 690,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNetworkRealDefChc,
   mgMgcoRegExpEvtNameNetwork
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecNetworkChcDefChcElmnts[] =
{
   &mgMgcoEvtSecUnknownNameDef,
   &mgMgcoEvtSecSkipAllDef,
   &mgMgcoEvtSecNetworkRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecNetworkChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtSecNetworkChcDefChcElmnts,
   mgMgcoGenTypeEnum 
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNetworkChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of second req event in package Network",
   "PkgNetworkEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 691,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecNetworkChcDefChc,
   mgMgcoRegExpPkgNetworkEvtType
};

/* Second requested event */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecNetworkDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvtSecNetworkChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecNetworkDefSeq =
{
   3,
   mgMgcoEvtSecNetworkDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecNetworkDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - package Network",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 692,
   sizeof(MgMgcoEvtSec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecNetworkDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNetworkRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecNetworkNetfailDef,
   &mgMgcoEvSpecNetworkQualertDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNetworkRealDefChc =
{
   3,
   7,
   mgMgcoEventNetworkRealDefChcIdx,
   mgMgcoEvSpecNetworkRealDefChcElmnts,
   mgMgcoEventNetworkRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNetworkRealDef =
{
#ifdef CM_ABNF_DBG
   "Real event spec -  package Network",
   "EvtNameNetwork",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 693,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNetworkRealDefChc,
   mgMgcoRegExpEvtNameNetwork
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNetworkChcDefChcElmnts[] =
{
   &mgMgcoEvSpecUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoEvSpecNetworkRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecNetworkChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecNetworkChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNetworkChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of event spec in package Network",
   "PkgNetworkEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 694,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecNetworkChcDefChc,
   mgMgcoRegExpPkgNetworkEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecNetworkDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvSpecNetworkChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecNetworkDefSeq =
{
   3,
   mgMgcoEvSpecNetworkDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecNetworkDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - package Network",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 695,
   sizeof(MgMgcoEvSpec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecNetworkDefSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtNetworkRealDefChc =
{
   3,
   7,
   mgMgcoEventNetworkRealDefChcIdx,
   mgMgcoEvSpecNetworkRealDefChcElmnts,
   mgMgcoEventNetworkRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtNetworkRealDef =
{
#ifdef CM_ABNF_DBG
   "Real observed event - package Network",
   "EvtNameNetwork",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 696,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtNetworkRealDefChc,
   mgMgcoRegExpEvtNameNetwork
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtNetworkChcDefChcElmnts[] =
{
   &mgMgcoObsEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoObsEvtNetworkRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtNetworkChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtNetworkChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtNetworkChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of observed event in package Network",
   "PkgNetworkEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 697,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtNetworkChcDefChc,
   mgMgcoRegExpPkgNetworkEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtNetworkDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoObsEvtNetworkChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtNetworkDefSeq =
{
   3,
   mgMgcoObsEvtNetworkDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtNetworkDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - package Network",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 698,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtNetworkDefSeq,
   NULLP
};

/************************************************************************
                              Signals - None
************************************************************************/

/************************************************************************
                              Statistics
************************************************************************/

PUBLIC CmAbnfElmTypeRange mgMgcoStatsParDoubleIntValueRng = {1, 20};

PUBLIC CmAbnfElmDef mgMgcoStatsParDoubleIntValue =
{
#ifdef CM_ABNF_DBG
   "StatsParDoubleIntValue",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 699,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoStatsParDoubleIntValueRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParDoubleIntActualDefChcElmnts[] =
{
   NULLP, NULLP, NULLP,
   &mgMgcoStatsParDoubleIntValue,
   NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoStatsParDoubleIntActualDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoStatsParDoubleIntActualDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoStatsParDoubleIntActualDef =
{
#ifdef CM_ABNF_DBG
   "StatsParDoubleInt",
   "ParmValOctStrXL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 700,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoStatsParDoubleIntActualDefChc,
   mgMgcoRegExpParmValOctStrXL
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParDoubleIntDefSeqElmnts[] =
{
   &mgMgcoEQUALDef,
   &mgMgcoStatsParDoubleIntActualDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoStatsParDoubleIntDefSeq =
{
   2,
   mgMgcoStatsParDoubleIntDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoStatsParDoubleIntDef =
{
#ifdef CM_ABNF_DBG
   "StatsParDoubleInt",
   "EQUAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 701,
   sizeof(MgMgcoValue),
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoStatsParDoubleIntDefSeq,
   mgMgcoRegExpEQUAL
};

PUBLIC CmAbnfElmTypeRange mgMgcoStatsParIntFracValueRng = {1, 21};

PUBLIC CmAbnfElmDef mgMgcoStatsParIntFracValue =
{
#ifdef CM_ABNF_DBG
   "StatsParIntFracValue",
   "IntFrac",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 702,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoStatsParIntFracValueRng,
   mgMgcoRegExpIntFrac
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParIntFracActualDefChcElmnts[] =
{
   NULLP, NULLP, NULLP,
   &mgMgcoStatsParIntFracValue,
   NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoStatsParIntFracActualDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoStatsParIntFracActualDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoStatsParIntFracActualDef =
{
#ifdef CM_ABNF_DBG
   "StatsParIntFrac",
   "ParmValOctStrXL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 703,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoStatsParIntFracActualDefChc,
   mgMgcoRegExpParmValOctStrXL
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParIntFracDefSeqElmnts[] =
{
   &mgMgcoEQUALDef,
   &mgMgcoStatsParIntFracActualDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoStatsParIntFracDefSeq =
{
   2,
   mgMgcoStatsParIntFracDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoStatsParIntFracDef =
{
#ifdef CM_ABNF_DBG
   "StatsParIntFrac",
   "EQUAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 704,
   sizeof(MgMgcoValue),
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoStatsParIntFracDefSeq,
   mgMgcoRegExpEQUAL
};

PUBLIC CmAbnfElmTypeEnum mgMgcoStatsParNetworkDurEnum =
{
   (Data *)"dur",
   MGT_PKG_NETWORK_STATS_DUR
};

PUBLIC CmAbnfElmDef mgMgcoStatsParNetworkDurEnumDef =
{
#ifdef CM_ABNF_DBG
   "StatsParNetworkDurEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 705,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoStatsParNetworkDurEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoStatsParNetworkOsEnum =
{
   (Data *)"os",
   MGT_PKG_NETWORK_STATS_OS
};

PUBLIC CmAbnfElmDef mgMgcoStatsParNetworkOsEnumDef =
{
#ifdef CM_ABNF_DBG
   "StatsParNetworkOsEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 706,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoStatsParNetworkOsEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoStatsParNetworkOrEnum =
{
   (Data *)"or",
   MGT_PKG_NETWORK_STATS_OR
};

PUBLIC CmAbnfElmDef mgMgcoStatsParNetworkOrEnumDef =
{
#ifdef CM_ABNF_DBG
   "StatsParNetworkOrEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 707,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoStatsParNetworkOrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParNetworkRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoStatsParNetworkDurEnumDef,
   &mgMgcoStatsParNetworkOsEnumDef,
   &mgMgcoStatsParNetworkOrEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParNetworkRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoStatsParDoubleIntDef
};

PUBLIC U8 mgMgcoStatsParNetworkRealDefChcIdx[] = {0, 1, 1, 1};

PUBLIC CmAbnfElmTypeChoice mgMgcoStatsParNetworkRealDefChc =
{
   2,
   4,
   mgMgcoStatsParNetworkRealDefChcIdx,
   mgMgcoStatsParNetworkRealDefChcElmnts,
   mgMgcoStatsParNetworkRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoStatsParNetworkRealDef =
{
#ifdef CM_ABNF_DBG
   "StatsParNetwork",
   "StatsParNetwork",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 708,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoStatsParNetworkRealDefChc,
   mgMgcoRegExpStatsParNetwork
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParNetworkChcDefChcElmnts[] =
{
   &mgMgcoStatsParUnknownDef,
   &mgMgcoStatsParSkipAllDef,
   &mgMgcoStatsParNetworkRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoStatsParNetworkChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoStatsParNetworkChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoStatsParNetworkChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of statistics parameter in package Network",
   "PkgNetworkStatsType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 709,
   sizeof(MgMgcoName) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoStatsParNetworkChcDefChc,
   mgMgcoRegExpPkgNetworkStatsType
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParNetworkDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoStatsParNetworkChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoStatsParNetworkDefSeq =
{
   3,
   mgMgcoStatsParNetworkDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoStatsParNetworkDef =
{
#ifdef CM_ABNF_DBG
   "Statistics parameter - package Network",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 710,
   sizeof(MgMgcoStatsPar) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoStatsParNetworkDefSeq,
   NULLP
};
#endif /* (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) ||
     defined(GCP_PKG_MGCO_TDMC)) */

#ifdef GCP_PKG_MGCO_RTP
/************************************************************************

                     Package - RTP (rtp) (0x000c)

************************************************************************/

/************************************************************************
                             Properties - None
************************************************************************/

/************************************************************************
                                 Events
************************************************************************/

PUBLIC CmAbnfElmTypeRange mgMgcoObsEvtOtherRtpPltransPayloadValueRng =
   {1, 0xFFFF};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransPayloadValue =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherRtpPltransPayloadValue",
   "SDPEncUnknown",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 711,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&mgMgcoObsEvtOtherRtpPltransPayloadValueRng,
   cmSdpRegExpEncUnknown
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransPayloadValDefChcElmnts[] =
{
   NULLP, NULLP, NULLP,
   &mgMgcoObsEvtOtherRtpPltransPayloadValue,
   NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherRtpPltransPayloadValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoObsEvtOtherRtpPltransPayloadValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransPayloadValDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherRtpPltransPayloadVal",
   "ParmValOctStrXL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 712,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherRtpPltransPayloadValDefChc,
   mgMgcoRegExpParmValOctStrXL
};

/************************************************************************/

/* = value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransPayloadValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherRtpPltransPayloadValEqDefSeq =
{
   2,
   mgMgcoObsEvtOtherRtpPltransPayloadValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransPayloadValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 713,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherRtpPltransPayloadValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransPayloadValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherRtpPltransPayloadValGtDefSeq =
{
   2,
   mgMgcoObsEvtOtherRtpPltransPayloadValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransPayloadValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 714,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoObsEvtOtherRtpPltransPayloadValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransPayloadValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherRtpPltransPayloadValLtDefSeq =
{
   2,
   mgMgcoObsEvtOtherRtpPltransPayloadValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransPayloadValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 715,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherRtpPltransPayloadValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransPayloadValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherRtpPltransPayloadValNeDefSeq =
{
   2,
   mgMgcoObsEvtOtherRtpPltransPayloadValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransPayloadValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 716,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherRtpPltransPayloadValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransPayloadValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoObsEvtOtherRtpPltransPayloadValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoObsEvtOtherRtpPltransPayloadValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransPayloadValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 717,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoObsEvtOtherRtpPltransPayloadValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransPayloadValLstDefSeqElmnts[]   =
{
   &mgMgcoObsEvtOtherRtpPltransPayloadValDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherRtpPltransPayloadValLstDefSeq =
{
   2,
   mgMgcoObsEvtOtherRtpPltransPayloadValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransPayloadValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 718,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoObsEvtOtherRtpPltransPayloadValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransPayloadValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherRtpPltransPayloadValAndDefSeq =
{
   4,
   mgMgcoObsEvtOtherRtpPltransPayloadValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransPayloadValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 719,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherRtpPltransPayloadValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransPayloadValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherRtpPltransPayloadValOrDefSeq =
{
   4,
   mgMgcoObsEvtOtherRtpPltransPayloadValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransPayloadValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 720,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtOtherRtpPltransPayloadValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransPayloadValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValDef,
   &cmMsgDefMetaColon,
   &mgMgcoObsEvtOtherRtpPltransPayloadValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtOtherRtpPltransPayloadValRngDefSeq =
{
   6,
   mgMgcoObsEvtOtherRtpPltransPayloadValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransPayloadValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 721,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoObsEvtOtherRtpPltransPayloadValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransPayloadDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherRtpPltransPayloadValEqDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValGtDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValLtDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValNeDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValAndDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValOrDef,
   &mgMgcoObsEvtOtherRtpPltransPayloadValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherRtpPltransPayloadDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoObsEvtOtherRtpPltransPayloadDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransPayloadDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherRtpPltransPayload",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 722,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherRtpPltransPayloadDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEvtOtherRtpPltransPayloadEnum =
{
   (Data *)"rtppltype",
   MGT_PKG_RTP_EVT_PLTRANS_PAYLOAD
};

PUBLIC CmAbnfElmDef mgMgcoEvtOtherRtpPltransPayloadEnumDef =
{
#ifdef CM_ABNF_DBG
   "EvtOtherRtpPltransPayloadEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 723,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEvtOtherRtpPltransPayloadEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransParDefChcEnum[] =
{
   NULLP,
   &mgMgcoEvtOtherRtpPltransPayloadEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransParDefChcElmnts[] =
{
   NULLP,
   &mgMgcoObsEvtOtherRtpPltransPayloadDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherRtpPltransParDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoObsEvtOtherRtpPltransParDefChcElmnts,
   mgMgcoObsEvtOtherRtpPltransParDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransParDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherRtpPltransPar",
   "ObsEvtOtherRtpPltransPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 724,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherRtpPltransParDefChc,
   mgMgcoRegExpObsEvtOtherRtpPltransPar
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtOtherRtpPltransDefChcElmnts[] =
{
   &mgMgcoEvtOtherUnknownDef,
   &mgMgcoEvtOtherSkipAllDef,
   &mgMgcoObsEvtOtherRtpPltransParDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtOtherRtpPltransDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtOtherRtpPltransDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtOtherRtpPltransDef =
{
#ifdef CM_ABNF_DBG
   "ObsEvtOtherRtpPltrans",
   "ObsEvtOtherRtpPltransType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 725,
   sizeof(MgMgcoEvtOther),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtOtherRtpPltransDefChc,
   mgMgcoRegExpObsEvtOtherRtpPltransType
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoReqEvtRtpPltransParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtEmbWithSigDef,
   &mgMgcoEvtEmbNoSigDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtRtpPltransParmDefChc =
{
   6,
   0,
   NULLP,
   mgMgcoReqEvtRtpPltransParmDefChcElmnts,
   mgMgcoEvtParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtRtpPltransParmDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtRtpPltrans - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 726,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtRtpPltransParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtRtpPltransParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoReqEvtRtpPltransParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoReqEvtRtpPltransParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTPARMS,
   2,
   mgMgcoReqEvtRtpPltransParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtPar)
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtRtpPltransParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtRtpPltrans - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 727,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoReqEvtRtpPltransParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtRtpPltransParmLstDefSeqElmnts[] =
{
   &mgMgcoReqEvtRtpPltransParmDef,
   &mgMgcoReqEvtRtpPltransParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtRtpPltransParmLstDefSeq =
{
   2,
   mgMgcoReqEvtRtpPltransParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtRtpPltransParmLstDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtRtpPltrans - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 728,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoReqEvtRtpPltransParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtRtpPltransDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoReqEvtRtpPltransParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtRtpPltransDefSeq =
{
   3,
   mgMgcoReqEvtRtpPltransDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtRtpPltransDef =
{
#ifdef CM_ABNF_DBG
   "ReqEvtRtpPltrans - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 729,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoReqEvtRtpPltransDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvtSecRtpPltransParmDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtStreamDef,
   &mgMgcoEvtDigMapDef,
   &mgMgcoEvtKAConsumeSkipDef,
   &mgMgcoEvtEmbSigDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecRtpPltransParmDefChc =
{
   5,
   6,       
   mgMgcoEvtSecParmChcIdx,
   mgMgcoEvtSecRtpPltransParmDefChcElmnts,
   mgMgcoEvtSecParmChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecRtpPltransParmDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecRtpPltrans - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 730,
   sizeof(MgMgcoEvtParSec),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecRtpPltransParmDefChc,
   mgMgcoRegExpEvtPar
};


PUBLIC CmAbnfElmDef *mgMgcoEvtSecRtpPltransParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvtSecRtpPltransParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvtSecRtpPltransParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSECPARMS,
   2,
   mgMgcoEvtSecRtpPltransParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecRtpPltransParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecRtpPltrans - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 731,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvtSecRtpPltransParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecRtpPltransParmLstDefSeqElmnts[] =
{
   &mgMgcoEvtSecRtpPltransParmDef,
   &mgMgcoEvtSecRtpPltransParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecRtpPltransParmLstDefSeq =
{
   2,
   mgMgcoEvtSecRtpPltransParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecRtpPltransParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecRtpPltrans - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 732,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvtSecRtpPltransParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecRtpPltransDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvtSecRtpPltransParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecRtpPltransDefSeq =
{
   3,
   mgMgcoEvtSecRtpPltransDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecRtpPltransDef =
{
#ifdef CM_ABNF_DBG
   "EvtSecRtpPltrans - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 733,
   sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvtSecRtpPltransDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoEvSpecRtpPltransParmDefChcElmnts[] =
{
   &mgMgcoObsEvtOtherRtpPltransDef,
   &mgMgcoEvtStreamDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecRtpPltransParmDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecRtpPltransParmDefChcElmnts,
   mgMgcoEvtSpecParmDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecRtpPltransParmDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecRtpPltrans - parameter",
   "EvtPar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 734,
   sizeof(MgMgcoEvtPar),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecRtpPltransParmDefChc,
   mgMgcoRegExpEvtPar
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecRtpPltransParmArrayDefSeqOfElmnts[] =
{
   &mgMgcoCOMMADef,
   &mgMgcoEvSpecRtpPltransParmDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoEvSpecRtpPltransParmArrayDefSeqOf =
{
   1,
   MGT_MAX_EVTSPECPARMS,
   2,
   mgMgcoEvSpecRtpPltransParmArrayDefSeqOfElmnts,
   sizeof(MgMgcoEvtParSec)
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecRtpPltransParmArrayDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecRtpPltrans - parameter array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 735,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoEvSpecRtpPltransParmArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecRtpPltransParmLstDefSeqElmnts[] =
{
   &mgMgcoEvSpecRtpPltransParmDef,
   &mgMgcoEvSpecRtpPltransParmArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecRtpPltransParmLstDefSeq =
{
   2,
   mgMgcoEvSpecRtpPltransParmLstDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecRtpPltransParmLstDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecRtpPltrans - parameter list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 736,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoEvSpecRtpPltransParmLstDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecRtpPltransDefSeqElmnts[] =
{
   &mgMgcoLBRKTDef,
   &mgMgcoEvSpecRtpPltransParmLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecRtpPltransDefSeq =
{
   3,
   mgMgcoEvSpecRtpPltransDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecRtpPltransDef =
{
#ifdef CM_ABNF_DBG
   "EvSpecRtpPltrans - parameter queue",
   "LBRKT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 737,
   sizeof(MgMgcoEvtParLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CONDSEQOF,
   (U8 *)&mgMgcoEvSpecRtpPltransDefSeq,
   mgMgcoRegExpLBRKT
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoEventRtpPltransEnum =
{
   (Data *)"pltrans",
   MGT_PKG_RTP_EVT_PLTRANS
};

PUBLIC CmAbnfElmDef mgMgcoEventRtpPltransEnumDef =
{
#ifdef CM_ABNF_DBG
   "EventRtpPltransEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 738,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoEventRtpPltransEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEventRtpRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoEventRtpPltransEnumDef,
   NULLP, NULLP, NULLP,
   &mgMgcoEventNetworkNetfailEnumDef,
   &mgMgcoEventNetworkQualertEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtRtpRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoReqEvtRtpPltransDef,
   NULLP, NULLP, NULLP,
   &mgMgcoReqEvtNetworkNetfailDef,
   &mgMgcoReqEvtNetworkQualertDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtRtpRealDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoReqEvtRtpRealDefChcElmnts,
   mgMgcoEventRtpRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtRtpRealDef =
{
#ifdef CM_ABNF_DBG
   "Real requested event - package Rtp",
   "EvtNameRtp",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 739,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtRtpRealDefChc,
   mgMgcoRegExpEvtNameRtp
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtRtpChcDefChcElmnts[] =
{
   &mgMgcoReqEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoReqEvtRtpRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoReqEvtRtpChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoReqEvtRtpChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtRtpChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of requested event in package Rtp",
   "PkgRtpEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 740,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoReqEvtRtpChcDefChc,
   mgMgcoRegExpPkgRtpEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoReqEvtRtpDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoReqEvtRtpChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoReqEvtRtpDefSeq =
{
   3,
   mgMgcoReqEvtRtpDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoReqEvtRtpDef =
{
#ifdef CM_ABNF_DBG
   "Requested event - package Rtp",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 741,
   sizeof(MgMgcoReqEvt) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoReqEvtRtpDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecRtpRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvtSecRtpPltransDef,
   NULLP, NULLP, NULLP,
   &mgMgcoEvtSecNetworkNetfailDef,
   &mgMgcoEvtSecNetworkQualertDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecRtpRealDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoEvtSecRtpRealDefChcElmnts,
   mgMgcoEventRtpRealDefChcEnum
};


PUBLIC CmAbnfElmDef mgMgcoEvtSecRtpRealDef =
{
#ifdef CM_ABNF_DBG
   "Real second requested event - package Rtp",
   "EvtNameRtp",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 742,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecRtpRealDefChc,
   mgMgcoRegExpEvtNameRtp
};

PUBLIC CmAbnfElmDef *mgMgcoEvtSecRtpChcDefChcElmnts[] =
{
   &mgMgcoEvtSecUnknownNameDef,
   &mgMgcoEvtSecSkipAllDef,
   &mgMgcoEvtSecRtpRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvtSecRtpChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvtSecRtpChcDefChcElmnts,
   mgMgcoGenTypeEnum 
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecRtpChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of second req event in package Rtp",
   "PkgRtpEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 743,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParSecLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvtSecRtpChcDefChc,
   mgMgcoRegExpPkgRtpEvtType
};

/* Second requested event */
PUBLIC CmAbnfElmDef *mgMgcoEvtSecRtpDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvtSecRtpChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvtSecRtpDefSeq =
{
   3,
   mgMgcoEvtSecRtpDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvtSecRtpDef =
{
#ifdef CM_ABNF_DBG
   "Second req event - package Rtp",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 744,
   sizeof(MgMgcoEvtSec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvtSecRtpDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecRtpRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoEvSpecRtpPltransDef,
   NULLP, NULLP, NULLP,
   &mgMgcoEvSpecNetworkNetfailDef,
   &mgMgcoEvSpecNetworkQualertDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecRtpRealDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoEvSpecRtpRealDefChcElmnts,
   mgMgcoEventRtpRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecRtpRealDef =
{
#ifdef CM_ABNF_DBG
   "Real event spec -  package Rtp",
   "EvtNameRtp",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 745,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecRtpRealDefChc,
   mgMgcoRegExpEvtNameRtp
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecRtpChcDefChcElmnts[] =
{
   &mgMgcoEvSpecUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoEvSpecRtpRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoEvSpecRtpChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoEvSpecRtpChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecRtpChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of event spec in package Rtp",
   "PkgRtpEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 746,
   sizeof(MgMgcoName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoEvSpecRtpChcDefChc,
   mgMgcoRegExpPkgRtpEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoEvSpecRtpDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoEvSpecRtpChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoEvSpecRtpDefSeq =
{
   3,
   mgMgcoEvSpecRtpDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoEvSpecRtpDef =
{
#ifdef CM_ABNF_DBG
   "Event spec - package Rtp",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 747,
   sizeof(MgMgcoEvSpec) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoEvSpecRtpDefSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtRtpRealDefChc =
{
   2,
   0,
   NULLP,
   mgMgcoEvSpecRtpRealDefChcElmnts,
   mgMgcoEventRtpRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtRtpRealDef =
{
#ifdef CM_ABNF_DBG
   "Real observed event - package Rtp",
   "EvtNameRtp",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 748,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtRtpRealDefChc,
   mgMgcoRegExpEvtNameRtp
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtRtpChcDefChcElmnts[] =
{
   &mgMgcoObsEvtUnknownNameDef,
   &mgMgcoEvSpecSkipAllDef,
   &mgMgcoObsEvtRtpRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoObsEvtRtpChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoObsEvtRtpChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtRtpChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of observed event in package Rtp",
   "PkgRtpEvtType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 749,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoObsEvtRtpChcDefChc,
   mgMgcoRegExpPkgRtpEvtType
};

PUBLIC CmAbnfElmDef *mgMgcoObsEvtRtpDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoObsEvtRtpChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoObsEvtRtpDefSeq =
{
   3,
   mgMgcoObsEvtRtpDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoObsEvtRtpDef =
{
#ifdef CM_ABNF_DBG
   "Observed event - package Rtp",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 750,
   sizeof(MgMgcoPkgdName) + sizeof(MgMgcoEvtParLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoObsEvtRtpDefSeq,
   NULLP
};

/************************************************************************
                              Signals - none
************************************************************************/

/************************************************************************
                              Statistics
************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoStatsParRtpPsEnum =
{
   (Data *)"ps",
   MGT_PKG_RTP_STATS_PS
};

PUBLIC CmAbnfElmDef mgMgcoStatsParRtpPsEnumDef =
{
#ifdef CM_ABNF_DBG
   "StatsParRtpPsEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 751,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoStatsParRtpPsEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoStatsParRtpPrEnum =
{
   (Data *)"pr",
   MGT_PKG_RTP_STATS_PR
};

PUBLIC CmAbnfElmDef mgMgcoStatsParRtpPrEnumDef =
{
#ifdef CM_ABNF_DBG
   "StatsParRtpPrEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 752,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoStatsParRtpPrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoStatsParRtpPlEnum =
{
   (Data *)"pl",
   MGT_PKG_RTP_STATS_PL
};

PUBLIC CmAbnfElmDef mgMgcoStatsParRtpPlEnumDef =
{
#ifdef CM_ABNF_DBG
   "StatsParRtpPlEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 753,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoStatsParRtpPlEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoStatsParRtpJitEnum =
{
   (Data *)"jit",
   MGT_PKG_RTP_STATS_JIT
};

PUBLIC CmAbnfElmDef mgMgcoStatsParRtpJitEnumDef =
{
#ifdef CM_ABNF_DBG
   "StatsParRtpJitEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 754,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoStatsParRtpJitEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoStatsParRtpDelayEnum =
{
   (Data *)"delay",
   MGT_PKG_RTP_STATS_DELAY
};

PUBLIC CmAbnfElmDef mgMgcoStatsParRtpDelayEnumDef =
{
#ifdef CM_ABNF_DBG
   "StatsParRtpDelayEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 755,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoStatsParRtpDelayEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParRtpRealDefChcEnum[] =
{
   NULLP,
   &mgMgcoStatsParNetworkDurEnumDef,
   &mgMgcoStatsParNetworkOsEnumDef,
   &mgMgcoStatsParNetworkOrEnumDef,
   &mgMgcoStatsParRtpPsEnumDef,
   &mgMgcoStatsParRtpPrEnumDef,
   &mgMgcoStatsParRtpPlEnumDef,
   &mgMgcoStatsParRtpJitEnumDef,
   &mgMgcoStatsParRtpDelayEnumDef
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParRtpRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoStatsParDoubleIntDef,
   &mgMgcoPropParmNetworkEqJitValDef,
   &mgMgcoStatsParIntFracDef
};

PUBLIC U8 mgMgcoStatsParRtpRealDefChcIdx[] = 
   {0, 1, 1, 1, 1, 1, 3, 1, 1};   /* IG 2004 changes : jit & delay r double */

PUBLIC CmAbnfElmTypeChoice mgMgcoStatsParRtpRealDefChc =
{
   4,
   9,
   mgMgcoStatsParRtpRealDefChcIdx,
   mgMgcoStatsParRtpRealDefChcElmnts,
   mgMgcoStatsParRtpRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoStatsParRtpRealDef =
{
#ifdef CM_ABNF_DBG
   "StatsParRtp",
   "StatsParRtp",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 756,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoStatsParRtpRealDefChc,
   mgMgcoRegExpStatsParRtp
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParRtpChcDefChcElmnts[] =
{
   &mgMgcoStatsParUnknownDef,
   &mgMgcoStatsParSkipAllDef,
   &mgMgcoStatsParRtpRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoStatsParRtpChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoStatsParRtpChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoStatsParRtpChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of statistics parameter in package Rtp",
   "PkgRtpStatsType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 757,
   sizeof(MgMgcoName) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoStatsParRtpChcDefChc,
   mgMgcoRegExpPkgRtpStatsType
};

PUBLIC CmAbnfElmDef *mgMgcoStatsParRtpDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoStatsParRtpChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoStatsParRtpDefSeq =
{
   3,
   mgMgcoStatsParRtpDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoStatsParRtpDef =
{
#ifdef CM_ABNF_DBG
   "Statistics parameter - package Rtp",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 758,
   sizeof(MgMgcoStatsPar) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoStatsParRtpDefSeq,
   NULLP
};
#endif /* GCP_PKG_MGCO_RTP */

#ifdef GCP_PKG_MGCO_TDMC
/************************************************************************

                     Package - TDM Circuit (tdmc) (0x000d)

************************************************************************/

/************************************************************************
                             Properties
************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcEcValDefChcElmnts[] =
{
   &cmMsgDefSdpOnOffOrNull,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmTdmcEcValDefChc =
{
   9,
   0,
   NULLP,
   mgMgcoPropParmTdmcEcValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcEcValDef =
{
#ifdef CM_ABNF_DBG
   "PropParmTdmcEcVal",
   "ParmValEnume",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 759,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmTdmcEcValDefChc,
   mgMgcoRegExpParmValEnume
};


/* = value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcEcValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmTdmcEcValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcEcValEqDefSeq =
{
   2,
   mgMgcoPropParmTdmcEcValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcEcValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 760,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmTdmcEcValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcEcValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoPropParmTdmcEcValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcEcValGtDefSeq =
{
   2,
   mgMgcoPropParmTdmcEcValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcEcValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 761,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,   
   (U8 *)&mgMgcoPropParmTdmcEcValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcEcValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoPropParmTdmcEcValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcEcValLtDefSeq =
{
   2,
   mgMgcoPropParmTdmcEcValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcEcValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 762,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmTdmcEcValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcEcValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoPropParmTdmcEcValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcEcValNeDefSeq =
{
   2,
   mgMgcoPropParmTdmcEcValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcEcValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 763,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmTdmcEcValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcEcValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmTdmcEcValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmTdmcEcValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoPropParmTdmcEcValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcEcValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 764,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmTdmcEcValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcEcValLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmTdmcEcValDef,
   &mgMgcoPropParmTdmcEcValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcEcValLstDefSeq =
{
   2,
   mgMgcoPropParmTdmcEcValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcEcValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 765,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmTdmcEcValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcEcValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmTdmcEcValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcEcValAndDefSeq =
{
   4,
   mgMgcoPropParmTdmcEcValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcEcValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 766,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmTdmcEcValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcEcValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPropParmTdmcEcValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcEcValOrDefSeq =
{
   4,
   mgMgcoPropParmTdmcEcValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcEcValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 767,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmTdmcEcValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcEcValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmTdmcEcValDef,
   &cmMsgDefMetaColon,
   &mgMgcoPropParmTdmcEcValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcEcValRngDefSeq =
{
   6,
   mgMgcoPropParmTdmcEcValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcEcValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 768,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPropParmTdmcEcValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcEcDefChcElmnts[] =
{
   &mgMgcoPropParmTdmcEcValEqDef,
   &mgMgcoPropParmTdmcEcValGtDef,
   &mgMgcoPropParmTdmcEcValLtDef,
   &mgMgcoPropParmTdmcEcValNeDef,
   &mgMgcoPropParmTdmcEcValAndDef,
   &mgMgcoPropParmTdmcEcValOrDef,
   &mgMgcoPropParmTdmcEcValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmTdmcEcDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmTdmcEcDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcEcDef =
{
#ifdef CM_ABNF_DBG
   "PropParmTdmcEc",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 769,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmTdmcEcDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/
#ifdef CM_ABNF_V_1_2
/*mg001.105 corrected the maximum and the minimum values */
PUBLIC CmAbnfElmTypeSIntRange mgMgcoPropParmTdmcGainValSignedValRng = {   1 , 10 , - (S32)(((U32)(~0))>>1),
                                                                      (S32)(((U32)(~0))>>1) - 1    };
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange mgMgcoPropParmTdmcGainValSignedValRng = {1,10};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcGainValSignedVal = 
{
#ifdef CM_ABNF_DBG
   "MGCP: GC_VAL ",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MG_BASE + 82,
   sizeof(TknS32),   
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SINT32,
   (U8 *)&mgMgcoPropParmTdmcGainValSignedValRng,
   cmAbnfRegExpSDgt
};


PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcGainValDefChcElmnts[] =
{
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
   &mgMgcoPropParmTdmcGainValSignedVal,
   NULLP
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmTdmcGainValDefChc =
{
   11,
   0,
   NULLP,
   mgMgcoPropParmTdmcGainValDefChcElmnts,
   mgMgcoParmValueTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcGainValDef =
{
#ifdef CM_ABNF_DBG
   "PropParmTdmcGainVal",
   "ParmValDecUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 770,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmTdmcGainValDefChc,
   mgMgcoRegExpParmValDecSint
};


/* = value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcGainValEqDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoPropParmTdmcGainValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcGainValEqDefSeq =
{
   2,
   mgMgcoPropParmTdmcGainValEqDefSeqElmnts
};

/* EQUAL VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcGainValEqDef   =
{
#ifdef CM_ABNF_DBG
   "= value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 771,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmTdmcGainValEqDefSeq,
   NULLP
};

/************************************************************************/

/* > value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcGainValGtDefSeqElmnts[]   =
{
   &mgMgcoGREATERTHANDef,
   &mgMgcoPropParmTdmcGainValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcGainValGtDefSeq =
{
   2,
   mgMgcoPropParmTdmcGainValGtDefSeqElmnts
};

/* LWSP ">" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcGainValGtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 772,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,  
   (U8 *)&mgMgcoPropParmTdmcGainValGtDefSeq,
   NULLP
};

/************************************************************************/

/* < value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcGainValLtDefSeqElmnts[]   =
{
   &mgMgcoLESSTHANDef,
   &mgMgcoPropParmTdmcGainValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcGainValLtDefSeq =
{
   2,
   mgMgcoPropParmTdmcGainValLtDefSeqElmnts
};

/* LWSP "<" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcGainValLtDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 773,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmTdmcGainValLtDefSeq,
   NULLP
};

/************************************************************************/

/* # value */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcGainValNeDefSeqElmnts[]   =
{
   &mgMgcoNOTEQUALDef,
   &mgMgcoPropParmTdmcGainValDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcGainValNeDefSeq =
{
   2,
   mgMgcoPropParmTdmcGainValNeDefSeqElmnts
};

/* LWSP "#" LWSP VALUE */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcGainValNeDef   =
{
#ifdef CM_ABNF_DBG
   "> value",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 774,
   sizeof(MgMgcoValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmTdmcGainValNeDefSeq,
   NULLP
};

/************************************************************************/

/* Parameter value array */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcGainValArrayDefSeqOfElmnts[]   =
{
   &mgMgcoCOMMADef,
   &mgMgcoPropParmTdmcGainValDef
};

PUBLIC CmAbnfElmTypeSeqOf mgMgcoPropParmTdmcGainValArrayDefSeqOf =
{
   1,
   MGT_MAX_VALUES,
   2,
   mgMgcoPropParmTdmcGainValArrayDefSeqOfElmnts,
   sizeof(MgMgcoValue)
};

/* *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcGainValArrayDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value array",
   "COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 775,
   sizeof(MgMgcoValLst),
   (CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_OPTIONAL << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&mgMgcoPropParmTdmcGainValArrayDefSeqOf,
   mgMgcoRegExpCOMMA
};

/************************************************************************/

/* Parameter value list */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcGainValLstDefSeqElmnts[]   =
{
   &mgMgcoPropParmTdmcGainValDef,
   &mgMgcoPropParmTdmcGainValArrayDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcGainValLstDefSeq =
{
   2,
   mgMgcoPropParmTdmcGainValLstDefSeqElmnts
};

/* VALUE *(COMMA VALUE) */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcGainValLstDef   =
{
#ifdef CM_ABNF_DBG
   "Parameter value list",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 776,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&mgMgcoPropParmTdmcGainValLstDefSeq,
   NULLP
};

/************************************************************************/

/* AND of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcGainValAndDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmTdmcGainValLstDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcGainValAndDefSeq =
{
   4,
   mgMgcoPropParmTdmcGainValAndDefSeqElmnts
};

/* LSBRKT VALUE *(COMMA VALUE) RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcGainValAndDef   =
{
#ifdef CM_ABNF_DBG
   "AND of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 777,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmTdmcGainValAndDefSeq,
   NULLP
};

/************************************************************************/

/* OR of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcGainValOrDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLBRKTDef,
   &mgMgcoPropParmTdmcGainValLstDef,
   &mgMgcoRBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcGainValOrDefSeq =
{
   4,
   mgMgcoPropParmTdmcGainValOrDefSeqElmnts
};

/* LBRKT VALUE *(COMMA VALUE) RBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcGainValOrDef   =
{
#ifdef CM_ABNF_DBG
   "OR of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 778,
   sizeof(MgMgcoValLst),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmTdmcGainValOrDefSeq,
   NULLP
};

/************************************************************************/

/* Range of values */
PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcGainValRngDefSeqElmnts[]   =
{
   &mgMgcoEQUALDef,
   &mgMgcoLSBRKTDef,
   &mgMgcoPropParmTdmcGainValDef,
   &cmMsgDefMetaColon,
   &mgMgcoPropParmTdmcGainValDef,
   &mgMgcoRSBRKTDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcGainValRngDefSeq =
{
   6,
   mgMgcoPropParmTdmcGainValRngDefSeqElmnts
};

/* LSBRKT VALUE COLON VALUE RSBRKT */
PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcGainValRngDef   =
{
#ifdef CM_ABNF_DBG
   "Range of values",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 779,
   sizeof(MgMgcoValRng),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&mgMgcoPropParmTdmcGainValRngDefSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcGainDefChcElmnts[] =
{
   &mgMgcoPropParmTdmcGainValEqDef,
   &mgMgcoPropParmTdmcGainValGtDef,
   &mgMgcoPropParmTdmcGainValLtDef,
   &mgMgcoPropParmTdmcGainValNeDef,
   &mgMgcoPropParmTdmcGainValAndDef,
   &mgMgcoPropParmTdmcGainValOrDef,
   &mgMgcoPropParmTdmcGainValRngDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmTdmcGainDefChc =
{
   7,
   0,
   NULLP,
   mgMgcoPropParmTdmcGainDefChcElmnts,
   mgMgcoParmValDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcGainDef =
{
#ifdef CM_ABNF_DBG
   "PropParmTdmcGain",
   "EqGtLtNeAndOrRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 780,
   sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmTdmcGainDefChc,
   mgMgcoRegExpEqGtLtNeAndOrRng
};

/************************************************************************/

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmTdmcEcEnum =
{
   (Data *)"ec",
   MGT_PKG_TDMC_PROP_EC
};

PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcEcEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmTdmcEcEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 781,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmTdmcEcEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum mgMgcoPropParmTdmcGainEnum =
{
   (Data *)"gain",
   MGT_PKG_TDMC_PROP_GAIN
};

PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcGainEnumDef =
{
#ifdef CM_ABNF_DBG
   "PropParmTdmcGainEnum",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 782,
   sizeof(((MgMgcoName *)0)->u),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&mgMgcoPropParmTdmcGainEnum,
   NULLP
};

/************************************************************************/

PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcRealDefChcElmnts[] =
{
   NULLP,
   &mgMgcoPropParmNetworkJitDef,
   &mgMgcoPropParmTdmcEcDef,
   &mgMgcoPropParmTdmcGainDef
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcRealDefChcEnum[] =
{
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
   &mgMgcoPropParmNetworkJitEnumDef,
   &mgMgcoPropParmTdmcEcEnumDef,
   NULLP,
   &mgMgcoPropParmTdmcGainEnumDef
};

PUBLIC U8 mgMgcoPropParmTdmcRealDefChcIdx[] =
   {0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 3};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmTdmcRealDefChc =
{
   4,
   11,
   mgMgcoPropParmTdmcRealDefChcIdx,
   mgMgcoPropParmTdmcRealDefChcElmnts,
   mgMgcoPropParmTdmcRealDefChcEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcRealDef =
{
#ifdef CM_ABNF_DBG
   "PropParmTdmc",
   "PropParmTdmc",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 783,
   sizeof(((MgMgcoName *)0)->u) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmTdmcRealDefChc,
   mgMgcoRegExpPropParmTdmc
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcChcDefChcElmnts[] =
{
   &mgMgcoPropParmUnknownDef,
   &mgMgcoPropParmSkipAllDef,
   &mgMgcoPropParmTdmcRealDef
};

PUBLIC CmAbnfElmTypeChoice mgMgcoPropParmTdmcChcDefChc =
{
   3,
   0,
   NULLP,
   mgMgcoPropParmTdmcChcDefChcElmnts,
   mgMgcoGenTypeEnum
};

PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcChcDef =
{
#ifdef CM_ABNF_DBG
   "Choice of property parameter in package Tdmc",
   "PkgTdmcPropType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 784,
   sizeof(MgMgcoName) + sizeof(MgMgcoParmValue),
   (CM_ABNF_MANDATORY |  CM_ABNF_TKN_NOT_CONSUMED) << CM_ABNF_PROT_MEGACO_DEF_OFFSET,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&mgMgcoPropParmTdmcChcDefChc,
   mgMgcoRegExpPkgTdmcPropType 
};

PUBLIC CmAbnfElmDef *mgMgcoPropParmTdmcDefSeqElmnts[] =
{
   &cmMsgDefMetaSlash,
   &mgMgcoSkipPkgNameDef,
   &mgMgcoPropParmTdmcChcDef
};

PUBLIC CmAbnfElmTypeSeq mgMgcoPropParmTdmcDefSeq =
{
   3,
   mgMgcoPropParmTdmcDefSeqElmnts
};

PUBLIC CmAbnfElmDef mgMgcoPropParmTdmcDef =
{
#ifdef CM_ABNF_DBG
   "Property parameter - package Tdmc",
   "Empty",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_MGCO_PKG_BASE + 785,
   sizeof(MgMgcoPropParm) - sizeof(TknU8),
   (CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_DEF_OFFSET)|(CM_ABNF_MANDATORY << CM_ABNF_PROT_MEGACO_V2_OFFSET),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&mgMgcoPropParmTdmcDefSeq,
   NULLP
};

/************************************************************************
                           Events - None
************************************************************************/

/************************************************************************
                        Signals - None
************************************************************************/

/************************************************************************
                        Statistics - None
************************************************************************/
#endif /* GCP_PKG_MGCO_TDMC */

#endif /* GCP_MGCO */

/********************************************************************30**

         End of file:     mgco_pdb.c@@/main/mgcp_rel_1.5_mnt/2 - Tue May 31 11:48:50 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      nct  1. Initial version
            mg001.102 nct  1. Changed a few SEQs in GtDef to OPTSEQs.
            mg002.102 sk   1. Changed no of IDx elements ( 7 to 6) in 
                              mgMgcoEvtSecGenericCauseParmDefChc and and in few 
                              others.
                           2. Added new enum elements for  "On" and "Off"
            mg014.102 ra   1. Changed gain control val of tdmc pkg to
                              signed integer
/main/2      ---      ra   1. GCP 1.3 release
            mg006.103 ra   1. Changes to reflect Root package changes.
                           2. Lots of changes to accept unknown events/signals
                              etc. within the context of a package.
                           3. Added missing def of mgMgcoObsEvtUnknownNameDef.
            mg014.103 ra   1. Changes to support SigId SigName in OE params
                              for the new packages added in rel 1.3.
/main/3      ---      TEL Global database definition elements added for:
                          1. Bearer Characteristic Package
                          2. Bearer Network Connection Cut Through Package
                          3. Reuse Idle Package
                          4. Generic Bearer Connection Package
                          5. Bearer Control Tunneling Package 
                          6. Basic Call Progress Tones Generator with 
                             Directionality Package
                          7. Expanded Call Progress Tones Generator Package
                          8. Basic Services Tone Generator Package
                          9. Expanded Services Tone Generation Package
                          10. Intrusion Tone Generation Package
                          11. Business Tone Generation Package
                          12. 3GUP User Plane Package
                          13. Circuit Switched Data Package
                          14. TFO Package
                          15. 3G Expanded Call Progress Tones Generator 
                              Package
                          16. Modification of Link characteristics Bearer 
                              Capability Package
                          17. Cellular Text Telephone Modem Text Transport 
                              Package
                          18. IP Transport Package
                          19. Flexible Tone Generator Package
                          20. Media Gateway Resource Congestion Handling 
                              Package
                          21. Quiet Termination Line Test Component Package
                          22. Loop back Line Test Response Package
                          23. ITU-T 404Hz Line Test Package
                          24. ITU-T 816Hz Line Test Package
                          25. ITU-T 1020Hz Line Test Package
                          26. ITU-T 2100Hz Disable Tone Line Test Package
                          27. ITU-T 2100Hz Disable Echo Chancellor Tone Line 
                              Test Package
                          28. ITU-T 2804Hz Tone Line Test Package
                          29. ITU-T Noise Test Tone Line Test Package
                          30. ITU-T Digital Pseudo Random Test Tone Line Test 
                              Package
                          31. ITU-T ATME No.2 Test Line Response Package
                          32. ANSI 1004Hz Test Tone Line Test Package
                          33. ANSI Test Responder Line Test Package
                          34. ANSI 2225Hz Test Progress Tone Line Test Package
                          35. ANSI Digital Test Signal line Test Package
                          36. ANSI Inverting Loop Back Line Test Response 
                              Package
                          37. Basic CAS Package
                          38. Basic CAS Addressing Package
                          39. Robbed Bit Signaling Package
                          40. Operator Service and Emergency Services Package
                          41. Operator Service and Extension Package
                          42. Inactivity Timer Package
/main/4      ---      TEL2 Global database definition elements added for:
                          1. Media Gateway Overload Control package 
                          2. Floor Control package
                          3. Indication of being viewed package
                          4. Volume Control package
                          5. Volume Detection package
                          6. Volume Level Mixing package
                          7. Voice Activated Video Switch package
                          8. Lecture Video Mode package
                          9. Contributing Video Source package
                          10. Profile package
                          11. Semi-permanent connection package
                          12. Video Window package
                          13. Tiled Window package
                          14. Enhanced Alerting package
                          15. Shared Risk Group package
                          16. Mixing Volume Level Control package
                          17. CAS Blocking package
                          18. Conferencing Tones Generation package
                          19. Diagnostic Tones Generation package
                          20. Carrier Tones Generation package
                          21. Analog Display Signalling package
                          22. Extended Analog Line Supervision package
                          23. Automatic Metering package
                          24. H.324 package
                          25. H.245 Command package
                          26. H.245 Indication package
                          27. Extended H.245 Command package
                          28. Extended H.245 Indication package
                          29. Quality Alert Ceasing package
                          30. Extended H.324 package
                          31. Adaptive Jitter Buffer package
                          32. International CAS package
                          33. Multi-Frequency Tone Generation package
                          34. Multi-Frequency Tone Detection package
                          35. Extended DTMF Detection package
                          36. Enhanced DTMF Detection package
/main/4      ---      TEL3 Global database definition elements added for:
                           1. MSF UK Call Progess Tones Generator package
                           2. MSF UK Announcement package
                           3. MSF UK Analogue Line package
                           4. MSF UK Automatic Metering package
/main/3      ---       ka 1. Changes for Release v 1.4
             mg007.104 mi 1. Corrected the range for tdmc gain property
/main/4      ---      pk   1. GCP 1.5 release
             mg001.105 mi  1. Corrected the range for tdmc gain property
             mg002.105 ps  1. Removed patch reference for 1.3
             mg003.105 ps  1. Enhanced Circuit Switched Data Package Added
                       ps  2. Stimulus Lines Analogue Package added 
             mg004.105 gk  1. Support for on/off to true/false
             mg005.105 gk  1. Support for Package Id U16 under the flag
                              MGT_PROPR_PKG_SUPPORT
*********************************************************************91*/
