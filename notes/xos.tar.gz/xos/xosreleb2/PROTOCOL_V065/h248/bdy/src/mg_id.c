/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     GCP layer -- identification file

     Type:     C source file

     Desc:     Version information

     File:     mg_id.c

     Sid:      mg_id.c@@/main/6 - Wed Mar 30 07:51:46 2005

     Prg:      rrp

*********************************************************************21*/


/* header include files (.h) */

#include "envopt.h"           /* environment options */
#include "envdep.h"           /* environment dependent */
#include "envind.h"           /* environment independent */

#include "gen.h"              /* general layer */
#include "ssi.h"              /* system services */


/* header/extern include files (.x) */

#include "gen.x"              /* general layer */
#include "ssi.x"              /* system services */


/* defines */

#define MGSWMV 1              /* main version */
#define MGSWMR 5              /* main revision */
#define MGSWBV 0              /* branch version */
/* mg008.105 - Change: for patch mg008.105 */
#define MGSWBR 8              /* branch revision */
#define MGSWPN "1000177"      /* part number */


/* forward references */

PUBLIC S16 mgGetSId     ARGS((SystemId *sId));


/* copyright banner */

CONSTANT PUBLIC Txt mgBan1[] =
   {"(c) COPYRIGHT 1989-2005, Continuous Computing Corporation"};
CONSTANT PUBLIC Txt mgBan2[] =
   {"                 All rights reserved.                  "};

/* system id */

CONSTANT PUBLIC SystemId mgSId =
{
   MGSWMV,                    /* main version */
   MGSWMR,                    /* main revision */
   MGSWBV,                    /* branch version */
   MGSWBR,                    /* branch revision */
   MGSWPN,                    /* part number */
};


/*
*
*       Fun:   mgGetSId
*
*       Desc:  Get system ID consisting of part number, main version,
*              revision, branch version and branch.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  mg_id.c
*
*/
#ifdef ANSI
PUBLIC S16 mgGetSId
(
SystemId *systm             /* system id */
)
#else
PUBLIC S16 mgGetSId(systm)
SystemId *systm;            /* system id */
#endif
{
   TRC2(mgGetSId);


   systm->mVer = mgSId.mVer;
   systm->mRev = mgSId.mRev;
   systm->bVer = mgSId.bVer;
   systm->bRev = mgSId.bRev;
   systm->ptNmb = mgSId.ptNmb;

   RETVALUE(ROK);
}




/********************************************************************30**

         End of file:     mg_id.c@@/main/6 - Wed Mar 30 07:51:46 2005

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rrp  1. initial release
1.2          ---      bbk  1. Fixed C++ compilation warnings
1.2+        mg001.101 bbk  1. Branch Revision 1 for mg001.101
            mg002.101  pk  2. Branch Revision 2 for mg002.101
            mg003.101 bbk  1. Corrected part number
                           2. Branch revision is 3 for mg003.101
            mg004.101 bbk  1. Branch revision is 4 for mg004.101
            mg005.101 nct  1. Branch revision is 5 for mg005.101
            mg006.101 nct  1. Branch revision is 6 for mg006.101
            mg007.101 bbk  1. Branch revision is 7 for mg007.101
            mg008.101 bbk  1. Branch revision is 8 for mg008.101
/main/3      ---       pk  1. Modified Version, Revision and branch 
                              for new release.
/main/4      ---      ra   1. New release GCP 1.3
            mg001.103 ra   1. Branch Revision 1 for mg001.103
            mg002.103 ra   1. Branch Revision 2 for mg002.103
            mg003.103 ra   1. Branch Revision 3 for mg003.103
            mg004.103 ra   1. Branch Revision 4 for mg004.103
            mg005.103 ra   1. Branch Revision 5 for mg005.103
            mg006.103 ra   1. Branch Revision 6 for mg006.103
            mg007.103 ra   1. Branch Revision 7 for mg007.103
            mg008.103 ra   1. Branch Revision 8 for mg008.103
            mg009.103 rg   1. Branch Revision 9 for mg009.103
            mg010.103 rg   1. Branch Revision 10 for mg010.103
            mg011.103 ra   1. Branch Revision 11 for mg011.103
            mg012.103 ra   1. Branch Revision 12 for mg012.103
            mg013.103 ra   1. Branch Revision 13 for mg013.103
            mg014.103 ra   1. Branch Revision 14 for mg014.103
            mg015.103 ra   1. Branch Revision 15 for mg015.103
            mg016.103 ra   1. Branch Revision 16 for mg016.103
            mg017.103 ra   1. Branch Revision 17 for mg017.103
/main/5      ---      ka   1. Changes for Release v 1.4
            mg001.104 ka   1. Branch Revision 1 for mg001.104
            mg002.104 ka   1. Branch Revision 2 for mg002.104
            mg003.104 ka   1. Branch Revision 3 for mg003.104
            mg004.104 ka   1. Branch Revision 4 for mg004.104
            mg005.104 ka   1. Branch Revision 5 for mg005.104
            mg006.104 ka   1. Branch Revision 6 for mg006.104
            mg007.104 ra   1. Branch Revision 7 for mg007.104
            mg008.104 ra   1. Branch Revision 8 for mg008.104
            mg009.104 ra   1. Branch Revision 9 for mg009.104
/main/6      ---      pk   1. GCP 1.5 release
            mg001.105 ra   1. Branch Revision 1 for mg001.105
            mg002.105 ra   1. Branch Revision 2 for mg002.105
            mg003.105 gk   1. Branch Revision 3 for mg003.105
            mg004.105 gk   1. Branch Revision 4 for mg004.105
            mg005.105 gk   1. Branch Revision 5 for mg005.105
            mg006.105 gk   1. Branch Revision 6 for mg006.105
            mg007.105 gk   1. Branch Revision 7 for mg007.105
            mg008.105 gk   1. Branch Revision 8 for mg008.105
*********************************************************************91*/
