/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     GCP - Utility Functions

     Type:     C source file

     Desc:     C code for support fns supplied by TRILLIUM.

     File:     mp_util.c

     Sid:      mp_util.c@@/main/mgcp_rel_1.5_mnt/6 - Thu Jul 14 12:32:51 2005

     Prg:      pk

*********************************************************************21*/


/************************************************************************

     

     This file has been extracted to support the following options:

     Option             Description
     ------    ------------------------------


************************************************************************/


/************************************************************************

Upper layer primitives:

The following functions are provided in this file:

   MgUiUiMgtBndReq     Bind Request
   MgUiMgtUbndReq      Unbind Request
   MgUiMgtCntrlReq     Unbind Request
   MgUiMgtMgcpTxnReq   MGCP Transaction request
   MgUiMgtMgcoTxnReq   MEGACO Transaction request

It is assumed that the following functions are provided in the
MGCP service user file:

   MgUiMgtMgcoStaInd       MEGACO Status Indication
   MgUiMgtMgcoTxnInd       MEGACO Transaction indication
   MgUiMgtMgcpTxnInd       MGCP Transaction indication
   MgUiMgtBndCfm           Bind confirm

************************************************************************/


/************************************************************************

System services are the functions required by the protocol layer for
buffer management, timer management, date/time management, resource
checking and initialization.

The following functions are provided in this file:

     mgActvInit     Activate layer - initialization task
     mgActvTmr      Activate layer - timer task 1
     mgActvTmrTTL   Activate layer - timer task 2

It is assumed that the following functions are provided in the system
services service provider file:

     SRegInit       Register initialization task
     SFndProcId     Finds id of processor on which task is running
     SRegTmr        Register timer activation task
     SRegActvTsk    Register layer activation task
     SPstTsk        Post a message buffer to a destination task
     SExitTsk       Exit a task

     SInitQueue     Initialize Queue (used only for testing)
     SQueueLast     Queue to Last Place (used only for testing)
     SDequeueFirst  Dequeue from First Place (used only for testing)
     SFndLenQueue   Find Length of Queue (used only for testing)

     SGetSMem       Allocate a static memory block
     SGetSBuf       Allocate a buffer from static memory block
     SPutSBuf       Deallocate a buffer from static memory block

     SGetMsg        Get a message buffer
     SPutMsg        Put a message buffer

     SAddPstMsg     Add an octet at the tail of a message
     SRemPreMsg     Remove an octet from the head of a message
     SExMgMsg       Return the value of a specified octet in a message
     SRepMsg        Replace a  specified octet in a message with new value
     SFndLenMsg     Find the length of a message
     SPrntMsg       Print a message buffer
     SCpyMsgMsg     Copy a message into a new buffer

     SPkS8          Add a signed  8-bit value at the head of a message
     SPkS16         Add a signed 16-bit value at the head of a message
     SPkS32         Add a signed 32-bit value at the head of a message
     SPkU8          Add an unsigned  8-bit value at the head of a message
     SPkU16         Add an unsigned 16-bit value at the head of a message
     SPkU32         Add an unsigned 32-bit value at the head of a message

     SUnpkS8        Remove a signed  8-bit value from the head of a message
     SUnpkS16       Remove a signed 16-bit value from the head of a message
     SUnpkS32       Remove a signed 32-bit value from the head of a message
     SUnpkU8        Remove an unsigned  8-bit value from the head of a message
     SUnpkU16       Remove an unsigned 16-bit value from the head of a message
     SUnpkU32       Remove an unsigned 32-bit value from the head of a message

     SChkRes        Report available system dynMgic memory
     SLogError      Handle fatal system error
     SPrint         Print a pre-formatted string
     SGetDateTime   Get current date and time
     SGetSysTime    Get current system time in ticks

************************************************************************/


/*
 *    this software may be combined with the following TRILLIUM
 *    software:
 *
 *    part no.             description
 *    --------    ----------------------------------------------
 *
 */




/* Header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hash functions */
#include "cm5.h"           /* common timer functions */
#include "cm_llist.h"      /* common linked list */
#include "cm_inet.h"       /* common sockets lib */
#include "cm_tpt.h"        /* common transport */
#include "cm_mblk.h"       /* ASN memory management */
#include "cm_tkns.h"       /* common tokens */
#include "lmg.h"           /* layer management interface */
#include "cm_dns.h"        /* common DNS library defines */
#include "cm_sdp.h"        /* SDP related constants */
#include "cm_abnf.h"        /*ABNF related types */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.h"        /* Common SS7 defines */
#include "snt.h"           /* MTP3 Interface defines */
#endif   /* GCP_PROV_MTP3 */

#include "mgt.h"           /* upper interface */
#include "mg.h"            /* MGCP contol related */
#include "hit.h"           /* TUCL layer */
#include "mg_err.h"        /* MGCP error */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */


#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* hashing functions */
#include "cm5.x"           /* timer functions */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common lib */
#include "cm_inet.x"       /* common sockets lib */
#include "cm_tpt.x"        /* common transport */
#include "cm_mblk.x"       /* ASN memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_dns.x"        /* common DNS library defines */
#include "cm_sdp.x"        /* SDP related types */
#include "cm_abnf.x"       /* ABNF related types */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.x"        /* Common SS7 structure */
#include "snt.x"           /* MTP3 Interface structure */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.x"           /* upper interface */
#include "lmg.x"           /* layer management interface */
#include "mg.x"            /* MGCP contol related */
#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */

#ifdef LEAK_TEST
#include "leak.h"
#endif /* LEAK_TEST */


/* Global control block */
extern MgCb  mgCb;
 
EXTERN S16 mgAllocEventMem ARGS((
       Ptr       *memPtr,
       Size      memSize
    ));
       
EXTERN S16 mgFreeEventMem ARGS((
       Ptr       memPtr
    ));

/* mg007.105: Bug fixes */
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
/*EXTERN MgtMgcoCmdReq muLiMgtMgcoCommandMt[];
EXTERN MgtMgcoUpdCtxtReq muLiMgtMgcoUpdateCntxtMt[];
EXTERN MgtMgcoErrReq muLiMgtMgcoTxnStaIndMt[];*/

PUBLIC Void mgChHandleMgcoCmdReqErr ARGS((
         MgSSAPCb           *ssap,              /* SSAP Control Block */
         MgMgcoCommand      *chCmd,             /* MGCO Command       */
         U8                 mgtError,           /* Error to be reported */
         U8                 source              /* Initiated by user/ internal */
));
 
PUBLIC Void mgChHandleMgcoPrcIndErr ARGS((
         MgSSAPCb           *ssap,              /* SSAP Control Block */
         MgMgcoInd      *mgInd,             /* MGCO Command       */
         U8                 mgtError,           /* Error to be reported */
         U8                 source              /* Initiated by user/ internal */
));
 
PUBLIC Void mgChHandleMgcoCntxtUpdErr ARGS((
         MgSSAPCb           *ssap,              /* SSAP Control Block */
         MgMgcoUpdateCntxt      *mgCntxt,             /* MGCO Command       */
         U8                 mgtError,           /* Error to be reported */
         U8                 source              /* Initiated by user/ internal */
));

EXTERN PUBLIC S16 mgChFreeCmds ARGS ((
         MgMgcoMsg *txn,
         U16        txnCnt
));

#endif /* GCP_CH && GCP_VER_1_5 */ 

EXTERN S16 mgChSendPrim  ARGS((
   Ptr                ptr,          /* CH primitive struct*/
   MgPeerCb           *peer,         /* Peer Control Block */
   S16                *err,          /* error code         */
   U8                 primType       /* Primitive type     */
));


#ifdef DEBUGP
extern Txt dnsPrntBuf[PRNTSZE];
#endif /* DEBUGP */


/* local defines */
/* local typedefs */  
/* local externs */
/* forward references */
/* private variable declarations */
/* public variable declarations */

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#if (defined(GCP_CH) && defined(GCP_VER_1_5))
 
EXTERN PUBLIC MgtMgcoTxnStaInd mgUiMgtMgcoTxnStaIndMt[];
#endif /* GCP_CH && GCP_VER_1_5 */ 


/***********************************************************************
                           Support Functions
 ***********************************************************************/


/*
*
*       Fun:   mgLocatePeer
*
*       Desc:  Function locates peer from the information provided
*              in the peerInfo structure (i.e from layer manager/
*              from upper interface)
*
*       Ret:   Pointer to MgPeerCb - SUCCESS;
*              NULLP - FAILURE
*
*       Notes:
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC MgPeerCb * mgLocatePeer
(
MgPeerInfo         *peerInfo,           /* Peer Information */
MgSSAPCb           *ssap                /* Associated SAP id */
)
#else
PUBLIC MgPeerCb * mgLocatePeer(peerInfo, ssap)
MgPeerInfo         *peerInfo;          /* Peer Information */
MgSSAPCb           *ssap;               /* Associated SAP id */
#endif
{
   MgPeerCb        *peer = NULLP;              /* Peer Control Block  */
   U16             nameLen = 0;            /* Name Length */
   Bool            done = FALSE;
#ifdef GCP_MGCP
   MgIpAddrEnt     *addrEnt;               /* address entry */
#endif /* GCP_MGCP */

   TRC2(mgLocatePeer)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (peerInfo->pres.pres != PRSNT_NODEF)
   {
      RETVALUE(NULLP);
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   /* If peer Id is used */
#ifdef GCP_USE_PEERID
   /* Get peer from peer id if peer id is present */
   if (peerInfo->id.pres != NOTPRSNT)
   {
      if (peerInfo->id.val != MG_INVALID_PEERID)
      {
         U32    peerId;

         peerId = (peerInfo->id.val & MG_PEERID_MASK);
         /* Implies gateway Id is present */
         if (peerId < mgCb.genCfg.maxPeer)
         {
            peer = MG_GET_PEER_FRM_PEERID(peerInfo->id.val);

            if (peer != NULLP)
            {
               RETVALUE(peer);
            }
         }
      }
   }
#endif /* GCP_USE_PEERID */

#ifdef GCP_MGCO
   if(PRSNT_NODEF == peerInfo->mid.pres)
   {
      done = TRUE;

      nameLen = peerInfo->mid.len;
      /* Search for peer based on MID */
      MG_FIND_PEER_FROM_DOMAIN_INFO(&(mgCb.peerNameLst),
                        (peerInfo->mid.val), nameLen, peer);
      /* 
       * MG side, virtual MG case, it is possible that dupliactes may exist in
       * the list. Ensure that this is the correct peer
       */
#ifdef GCP_MG
      if(mgCb.genCfg.entType == LMG_ENT_GW)
      {
         if(NULLP != peer)
         {
            if (TRUE == peer->mgcoInfo.dupPeerPrsnt) 
            {
               U16  i = 1;
               do
               {
                  if(peer->ssap == ssap)
                     break;
                  peer = NULLP;
                  if(ROK != cmHashListFind(&(mgCb.peerNameLst),
                                (U8 *)(peerInfo->mid.val),peerInfo->mid.len, 
                                (U16)(MG_HASH_SEQNMB_DEF + i), (PTR *)&peer))
                  {
                     break;
                  }
                  i++;
               } while (1);
            }
         }
      }
#endif /* GCP_MG */
   }
#endif /* GCP_MGCO */

#ifdef GCP_MGCP
   /* Ensure that the search for the peer on the basis of IP address or on the
    * basis of domain name id done only if this is MGCP, and MID is not
    * present */
   if( (NULLP == peer) && (FALSE == done) )
   {
      if ((peerInfo->dname.netAddr.type  == CM_NETADDR_IPV4) ||
          (peerInfo->dname.netAddr.type  == CM_NETADDR_IPV6))
      {
         /* Check if IP Address can be used to locate Peer */
         addrEnt = NULLP;
         mgFindIpAddrLst(peerInfo->dname.netAddr.type,
                         &(peerInfo->dname.netAddr.u.ipv4NetAddr),
                         &(peerInfo->dname.netAddr.u.ipv6NetAddr),
                         0, &addrEnt);
         if (addrEnt != NULLP)
            peer = addrEnt->peer;
      }
      else if(PRSNT_NODEF == peerInfo->dname.namePres.pres)
      {
         nameLen =  cmStrlen((CONSTANT U8 *) (peerInfo->dname.name));   
         /* Check if domain name can be used to locate Peer */
         MG_FIND_PEER_FROM_DOMAIN_INFO(&(mgCb.peerNameLst),
                     (peerInfo->dname.name), nameLen, peer);
      }
   }
#endif /* GCP_MGCP */

   RETVALUE(peer);

} /* end of mgLocatePeer() */






#ifdef GCP_MG

/*
*
*       Fun:   mgRemSsapSrvrs
*
*       Desc:  This function disables the TSAP.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC U16 mgRemSsapSrvrs
(
MgSSAPCb *ssap,
Bool      delSrvr
)
#else
PUBLIC U16 mgRemSsapSrvrs(ssap, delSrvr)
MgSSAPCb *ssap;
Bool      delSrvr;
#endif
{
  MgTptSrvrInfo *srvrInfo;

#ifdef GCP_MGCO 
  srvrInfo = &(ssap->mgcoUDPSrvrLst);
  MG_REM_SRVRS(srvrInfo, delSrvr);
#endif /* GCP_MGCO */

#ifdef GCP_MGCP 
  srvrInfo = &(ssap->mgcpUDPSrvrLst);
  MG_REM_SRVRS(srvrInfo, delSrvr);
#endif /* GCP_MGCO */

  RETVALUE(ROK);
}



/*
*
* Added new function.
*
*       Fun:   mgRemSsapSrvrsForThisTsap
*
*       Desc:  This function disables the servers attached to the
*              ssap pointed to by the first arg which use the tsap
*              pointed to by the second arg.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mp_util.c
*
*/
#ifdef ANSI
PUBLIC U16 mgRemSsapSrvrsForThisTsap
(
MgSSAPCb *ssap,
MgTSAPCb *tsap,
Bool      delSrvr
)
#else
PUBLIC U16 mgRemSsapSrvrsForThisTsap(ssap, tsap, delSrvr)
MgSSAPCb *ssap;
MgTSAPCb *tsap;
Bool      delSrvr;
#endif
{
   MgTptSrvrInfo *srvrInfo = NULLP;
   CmLListCp     *lCp      = NULLP;
   CmLList       *tmp      = NULLP;
   MgTptSrvr     *tptSrvr  = NULLP;

#ifdef GCP_MGCO 
   srvrInfo = &(ssap->mgcoUDPSrvrLst);
   lCp = &srvrInfo->srvrLstCp;
   tmp = lCp->first;
   while(tmp)
   {
      tptSrvr = (MgTptSrvr *)(tmp->node);
      tmp    = tmp->next;
      /* this will send HitDiscReq */
      if (tptSrvr->tsap == tsap)
         mgSrvDiscReq(tptSrvr, delSrvr);
   }
#endif /* GCP_MGCO */


#ifdef GCP_MGCP 
   srvrInfo = NULLP;
   lCp      = NULLP;
   tmp      = NULLP;
   tptSrvr  = NULLP;

   srvrInfo = &(ssap->mgcpUDPSrvrLst);
   lCp = &srvrInfo->srvrLstCp;
   tmp = lCp->first;
   while(tmp)
   {
      tptSrvr = (MgTptSrvr *)(tmp->node);
      tmp    = tmp->next;
      /* this will send HitDiscReq */
      if (tptSrvr->tsap == tsap)
         mgSrvDiscReq(tptSrvr, delSrvr);
   }
#endif /* GCP_MGCP */

  RETVALUE(ROK);
}


#endif /* GCP_MG */




/*
*
*       Fun:   mgStartTsapServers
*
*       Desc:  This function starts listeners on TSAP or SSAP
*
*       Ret:   ROK              - successful
*              RFAILED          - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC U16 mgStartTsapServers
(
MgTSAPCb      *tsapCb
)
#else
PUBLIC U16 mgStartTsapServers(tsapCb)
MgTSAPCb      *tsapCb;
#endif
{
   MgTptSrvrInfo *srvrInfo;

   TRC2(mgStartTsapServers);

#ifdef GCP_MGCP
   srvrInfo = &(tsapCb->mgcpUDPSrvrLst);
   mgStartServers(srvrInfo);
#endif /* GCP_MGCP */

#ifdef GCP_MGCO 

   srvrInfo = &(tsapCb->mgcoUDPSrvrLst);
   mgStartServers(srvrInfo);

#ifdef GCP_MGC
   srvrInfo = &(tsapCb->tcpSrvrInfo);
   mgStartServers(srvrInfo);
#endif /* GCP_MGC */
#endif /* GCP_MGCO */
   RETVALUE(ROK);

} /* end of mgStartTsapServers() */



/*
*
*       Fun:   mgRslvDomainNameStr
*
*       Desc:  This function parses the domain name string received in the
*              message buffer. The string can contain domain name in following
*              formats:
*              1) www.trillium.com
*              2) [206.216.108.253]
*              3) #(decimal_equivalent_of 206.216.108.253)
*
*       Ret:   Pointer to MgPeerCb - SUCCESS; 
*              NULLP               - FAILURE
*
*       Notes: 
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC MgPeerCb * mgRslvDomainNameStr
(
U16                len,                /* Length of the String */
U8                 *val,               /* Domain Name String */
MgDName            *dname              /* Domain Name */
)
#else
PUBLIC MgPeerCb * mgRslvDomainNameStr (len, val, dname)
U16                len;                /* Length of the String */
U8                 *val;               /* Domain Name String */
MgDName            *dname;             /* Domain Name */
#endif
{
   CmNetAddr       ipAddr;             /* IPV4/IPV6 Address */
   MgPeerCb        *peer;              /* Peer Control Block */
   MgIpAddrEnt     *ipAddrEnt;         /* IP Address Entry */

   TRC2(mgRslvDomainNameStr)

   peer = NULLP;
   cmMemset((U8 *)dname, 0, sizeof(MgDName));

   /* First Check for format 1 */
   if (val[0] != '#' && val[0] != '[')
   {
      cmMemcpy((U8 *)dname->name, (CONSTANT U8 *)val, len);


      if (len < CM_DNS_DNAME_LEN)
         dname->name[len] = '\0';

      dname->namePres.pres = PRSNT_NODEF;

      cmHashListFind(&(mgCb.peerNameLst), val, len, MG_HASH_SEQNMB_DEF, 
                     (PTR *) &peer);

      RETVALUE(peer);
   }


   if ((mgGetIpAddrFromDomainNameStr(len, val, &ipAddr, LMG_PROTOCOL_MGCP)) 
                      != ROK)
      RETVALUE(NULLP);


   /*  Locate the peer using IP Address now */
   cmMemcpy((U8 *)&(dname->netAddr), (CONSTANT U8*) &ipAddr, 
            sizeof(CmNetAddr));

   ipAddrEnt = NULLP;
   mgFindIpAddrLst(ipAddr.type, &(ipAddr.u.ipv4NetAddr),
                   &(ipAddr.u.ipv6NetAddr), MG_HASH_SEQNMB_DEF,       
                   &ipAddrEnt);

   if (ipAddrEnt != NULLP)
      peer = ipAddrEnt->peer;

   RETVALUE(peer);

} /* end of mgRslvDomainNameStr() */





/*
*
*       Fun:   mgGetIpAddrFromDomainNameStr
*
*       Desc:  This function parses the domain name string received in the
*              message buffer. The string can contain domain name in following
*              formats:
*              1) [206.216.108.253]
*              2) #(decimal_equivalent_of 206.216.108.253)
*              3) For MEGACO 206.216.108.253
*
*       Ret:   ROK     - SUCCESS
*              RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC S16 mgGetIpAddrFromDomainNameStr
(
U16                len,                /* Length of IP address */
U8                 *val,               /* Domain Name String */
CmNetAddr          *address,           /* IP Address */
U8                 protocol            /* MEGACO/MGCP */
)
#else
PUBLIC S16 mgGetIpAddrFromDomainNameStr(len, val, address, protocol)
U16                len;                /* Length of IP address */
U8                 *val;               /* Domain Name String */
CmNetAddr          *address;           /* IP Address */
U8                 protocol;           /* MEGACO/MGCP */
#endif
{
   S16             retVal;               /* return value */
   U16             idx;


   TRC2(mgGetIpAddrFromDomainNameStr)

   retVal = RFAILED;
   /* Check for IP Address in format 2 i.e. [a.b.c.d] */
   if ((val[0] == '[') || (protocol == LMG_PROTOCOL_MGCO))
   {
      /* Format 2 processing */
      if (protocol == LMG_PROTOCOL_MGCO)
         idx = 0;
      else
         idx = 1;

      /* the length for the string is len - 2*idx (for '[' and ']' */
      /* CmInetNetAddr is the same as CmNetAddr */
      retVal = cmInetConvertStrToIpAddr((U16)(len - (2*idx)), &(val[idx]), 
                                        (CmInetNetAddr*) address);
   } /* if, '[' or MGCO */
   else
   if (val[0] == '#')
   {
      address->type = CM_NETADDR_IPV4;
      MG_GET_IPV4_ADDR_FRM_STRING(address->u.ipv4NetAddr, (val+1));
      retVal = ROK;
   }

   RETVALUE(retVal);

} /* end of mgGetIpAddrFromDomainNameStr() */



/*
*
*       Fun:   mgMalloc
*
*       Desc:  This function allocates a static memory buffer of 
*              requested size.
*
*       Ret:   (Data *) - on success
*              NULLP    - on failure
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC Data * mgMalloc
(
Size               size                /* Static Buffer Size Requested */
)
#else
PUBLIC Data * mgMalloc (size)
Size               size;               /* Static Buffer Size Requested */
#endif
{
   TskInit         *mgInit;            /* MGCP Task Init Structure */
   Data            *buf;               /* Buffer to be allocated */

   TRC2(mgMalloc)

   buf    = NULLP;
   mgInit = &(mgCb.init);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (size <= 0)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG318, size,
                   "[MGCP] mgMalloc(): invalid size\n");
 
      RETVALUE (NULLP);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   /* Obtain the Static Buffer */
   if((SGetSBuf(mgInit->region, mgInit->pool, &buf, size) != ROK) ||
      (buf == NULLP))
   {
      RETVALUE(NULLP);
   }

   /* Initialise the buffer */
   cmMemset (buf, 0, size);

#ifdef LEAK_TEST
   mgInsertInLeakLst((PTR)(buf), LEAK_LEVEL_SBUF);
#endif /* LEAK_TEST */

   RETVALUE(buf);

} /* end of mgMalloc */





/*
*
*       Fun:   mgDeAlloc
*
*       Desc:  This function returns a static memory buffer to 
*              the buffer pool.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC Void mgDeAlloc
(
Data               *buf,               /* Static Buffer to be freed */
Size               size                /* Size of Buffer */
)
#else
PUBLIC Void mgDeAlloc (buf, size)
Data               *buf;               /* Static Buffer to be freed */
Size               size;               /* Size of Buffer */
#endif
{
   TskInit         *mgInit;            /* MGCP Task Init Structure */

   TRC2(mgDeAlloc)

#if (ERRCLASS & ERRCLS_DEBUG)
   if ((buf == NULLP) || (size <= 0) )
   {
      Txt   prntBuf[PRNTSZE];
 
      sprintf(prntBuf, "[MGCP] mgDeAlloc(): buf=%p, size=%ld\n", buf, size);
      MGLOGERROR(ERRCLS_DEBUG, EMG319, size, prntBuf);
      RETVOID;
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   mgInit = &(mgCb.init);

#if (ERRCLASS & ERRCLS_DEBUG)
   /* Initialize the memory to 0 before releasing it */
   cmMemset (buf, 0, size);
#endif /* ERRCLASS & ERRCLS_DEBUG */

#ifdef LEAK_TEST
   mgFreeFromLeakLst((PTR)buf);
#endif /* LEAK_TEST */

   /* Free the memory */
   SPutSBuf (mgInit->region, mgInit->pool, buf, size);

   RETVOID;

} /* end of mgDeAlloc */


/*
*
*       Fun:   mgAllocEventMem
*
*       Desc:  This function allocates event memory 
*
*       Ret:   (Data *) - on success
*              NULLP    - on failure
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAllocEventMem
(
Ptr       *memPtr,
Size      memSize
)
#else
PUBLIC S16 mgAllocEventMem(memPtr, memSize)
Ptr       *memPtr;
Size      memSize;
#endif
{
   Mem   sMem;

   TRC2(mgAllocEventMem)

   sMem.region = mgCb.init.region;
   sMem.pool = mgCb.init.pool;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (memSize<= 0)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG320, memSize,
                   "[MGCP] mgAllocEventMem(): invalid size\n");
      RETVALUE (RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   if(ROK != cmAllocEvnt(memSize, mgCb.genCfg.maxBlkSize, &sMem, memPtr))
   {
      RETVALUE(RFAILED);
   }

#ifdef LEAK_TEST
   mgInsertInLeakLst((PTR)(*memPtr), LEAK_LEVEL_EVENT_MEM);
#endif /* LEAK_TEST */

   RETVALUE(ROK);

} /* end of mgAllocEventMem*/


/*
*
*       Fun:   mgFreeEventMem
*
*       Desc:  This function frees event memory 
*
*       Ret:   
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC S16 mgFreeEventMem
(
Ptr       memPtr
)
#else
PUBLIC S16 mgFreeEventMem(memPtr)
Ptr       memPtr;
#endif
{
   TRC2(mgFreeEventMem)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (memPtr == NULLP)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG321, (ErrVal)0,
                   "[MGCP] mgFreeEventMem(): invalid ptr\n");
      RETVALUE (RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

#ifdef LEAK_TEST
   mgFreeFromLeakLst((PTR)memPtr);
#endif /* LEAK_TEST */

   cmFreeMem(memPtr);

   RETVALUE(ROK);
} /* end of mgFreeEventMem */


#ifdef LEAK_TEST
#ifdef L4
/*
*
*       Fun:   mgGetMsg
*
*       Desc:  This function allocates mBuf
*
*       Ret:   (Data *) - on success
*              NULLP    - on failure
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC S16 mgGetMsg
(
Region    region,
Pool      pool,
Buffer    **mBuf
)
#else
PUBLIC S16 mgGetMsg(region, pool, mBuf)
Region    region;
Pool      pool;
Buffer    **mBuf;
#endif
{
   TRC2(mgGetMsg)

   if (SGetMsg(region, pool, mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }

   mgInsertInLeakLst((PTR)(*mBuf), LEAK_LEVEL_MBUF);

   RETVALUE(ROK);
} /* end of mgGetMsg */


/*
*
*       Fun:   mgPutMsg
*
*       Desc:  This function Frees mBuf
*
*       Ret:   
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC S16 mgPutMsg
(
Buffer    *mBuf
)
#else
PUBLIC S16 mgPutMsg(mBuf)
Buffer    *mBuf;
#endif
{
   TRC2(mgPutMsg)

   mgFreeFromLeakLst((PTR)mBuf);

   SPutMsg(mBuf);

   RETVALUE(ROK);
} /* end of mgPutMsg */

#endif /* L4 */
#endif /* LEAK_TEST */

/* mg008.105: we are using this function only in MGCP */
#ifdef GCP_MGCP

/*
*
*       Fun:    mgGetIpAddrForTx   
*
*       Desc:   This function locates a IP Address for transmission of a 
*               transaction and also copies the same in Transaction Control
*               block
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_util.c
*
*/

#ifdef ANSI
PUBLIC S16 mgGetIpAddrForTx
(
MgTxTransIdEnt     *txCb,              /* Transaction Control Block */
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PUBLIC S16 mgGetIpAddrForTx (txCb, peer)
MgTxTransIdEnt     *txCb;              /* Transaction Control Block */
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
   U16             gwAddrIdx;          /* Index into gateway address table */
   U16             txnAddrIdx;         /* Index into transaction addr table */
   Bool            found;              /* Addresses found */
   MgNetAddrTbl    *addrTbl;           /* Peer Addresses */
   MgNetAddrTbl    *taddrTbl;          /* TxCb Addresses */

   TRC2(mgGetIpAddrForTx)

   addrTbl  = &(peer->accessInfo.peerAddrTbl);
   taddrTbl = &(txCb->addrTbl);

   /* If transaction is being transmitted first time..pick first address */
   if (txCb->addrTbl.count == MG_NONE)
   {
      cmMemcpy((U8 *)&(taddrTbl->netAddr[taddrTbl->count++]), 
               (CONSTANT U8 *) &(addrTbl->netAddr[0]),
               sizeof(CmNetAddr));

      RETVALUE(ROK);
   }



   /*
    *   See if the addrTbl & the taddrTbl address are the same;
    *   If they are different, we need to update the txCb address;
    *   Otherwise, we should just return ROKDNA or RFAILED
    *   depending on the suspThold/disconTholds.
    */

   /* Search for a new IP Address */
   for (gwAddrIdx = 0; gwAddrIdx < addrTbl->count; gwAddrIdx++)
   {
      found = FALSE;

      for (txnAddrIdx = 0; txnAddrIdx < taddrTbl->count; txnAddrIdx++)
      {
         if ((cmMemcmp((U8 *)&(taddrTbl->netAddr[txnAddrIdx]),
                      (CONSTANT U8 *)&(addrTbl->netAddr[gwAddrIdx]),
                      sizeof(CmNetAddr))) == 0)
         {
            /* Address was used by the transaction */
            found = TRUE;
            break;
         }
      }

      if (found == FALSE)
      {
         /* 
          * Implies address of the peer at gwAddrIdx not used so far - 
          * New IP Address found ....copy it into transaction cb 
          */
         cmMemcpy((U8 *)&(taddrTbl->netAddr[txCb->addrTbl.count]), 
                  (CONSTANT U8 *) &(addrTbl->netAddr[gwAddrIdx]),
                  sizeof(CmNetAddr));

         /* Increment IP Address count for Transaction control block */
         taddrTbl->count++;

         RETVALUE(ROK);
      }
   }


   /*
    *   Coming here implies that the addrTbl had the same addresses
    *   as taddrTbl. The addrTbl count is the same or less than the
    *   taddrTbl count. eg. a same count example is -
    *
    *      addrTbl={A1,A2,A3} and taddrTbl={A1,A2,A3}
    *
    *   A lower count example is -
    *
    *      addrTbl={A2,A1} and taddrTbl={A1,A2,A3}
    *
    */

/* #ifdef GCP_MGCP */
   /*
    * If this is the first/last IP Address used and this is the only one 
    * ever available even after contacting DNS (i.e. we have crossed
    * suspicion threshold; then return this address as one to be used
    * for retransmission until we reach disconnect threshold
    */
   if (addrTbl->count <= taddrTbl->count)
   {
      /* Use first address for retransmission */
      if ((txCb->retxCnt >= peer->mgcpInfo.suspThold) &&
          (txCb->retxCnt < peer->mgcpInfo.disconThold))
      {
         RETVALUE(ROKDNA);
      }
      else
      if (txCb->retxCnt >= peer->mgcpInfo.disconThold)
      {
         RETVALUE(RFAILED);
      }
   }
/* #endif */

   RETVALUE(RFAILED);

} /* end of mgGetIpAddrForTx () */


#endif /* GCP_MGCP */


/*
*
*       Fun:   mgSendSsapEnbStaInd
*
*       Desc:  This function sends Status Indication to the Layer Manager
*              when SSAP reaches enabled state
*
*       Ret:   None
*
*       Notes: This function is called when this SSAP has all its gateways 
*              resolved and has atleast one active listener attached to it
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC Void mgSendSsapEnbStaInd
(
MgSSAPCb           *ssap               /* SSAP Control Block */
)
#else
PUBLIC Void mgSendSsapEnbStaInd (ssap)
MgSSAPCb           *ssap;              /* SSAP Control Block */
#endif
{
   U16             loopIdx;            /* Loop Index */
   MgSSAPSta       alarmInfo;          /* SSAP Status Structure */
   MgPeerCb        *peer;              /* Peer Control Block */
   CmLList         *cmLstEnt;          /* Linked List Node */

   TRC2(mgSendSsapEnbStaInd)

   loopIdx = 0;
   cmMemset((U8 *)&alarmInfo, 0, sizeof(MgSSAPSta));

   /* Update count for current number of active ssaps */
#ifdef GCP_MGC

#ifdef GCP_MGCP
   if ((ssap->ssapCfg.protocol & LMG_PROTOCOL_MGCP) &&
       (mgCb.nxtMgcpSsapId == MG_INVALID_SSAP_ID))
   {
      mgCb.nxtMgcpSsapId = ssap->ssapCfg.sSAPId;
   }
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
   if ((ssap->ssapCfg.protocol & LMG_PROTOCOL_MGCO) &&
       (mgCb.nxtMgcoSsapId == MG_INVALID_SSAP_ID))
   {
      mgCb.nxtMgcoSsapId = ssap->ssapCfg.sSAPId;
   }
#endif /* GCP_MGCO */

#endif /* GCP_MGC */




   /* Fill the Sap Status Structure for Status Indication */
   alarmInfo.sapId        = ssap->ssapCfg.sSAPId;
   alarmInfo.state        = ssap->state;
#ifdef GCP_MGCP
#ifdef GCP_MG
   alarmInfo.numServers   = 
      (U16) cmLListLen (&(ssap->mgcpUDPSrvrLst.srvrLstCp));
#endif /* GCP_MG */
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
#ifdef GCP_MG
   alarmInfo.numServers   = 
      (U16) cmLListLen (&(ssap->mgcoUDPSrvrLst.srvrLstCp));
#endif /* GCP_MG */
#endif /* GCP_MGCO */
   alarmInfo.numAssocPeer = 0;
   alarmInfo.more         = FALSE;


   cmLstEnt = (ssap->peerLst.first);

   while (cmLstEnt != NULLP)
   {
      peer = (MgPeerCb *)cmLstEnt->node;

#ifdef GCP_MGCP
      if(LMG_PROTOCOL_MGCP == peer->mntInfo.protocolType)
      {
         MG_COPY_PEERINFO_INTO_MGCPTXN(alarmInfo.peerInfo[loopIdx], peer);
      }
#endif /* GCP_MGCP */
#ifdef GCP_MGCO 
      if(LMG_PROTOCOL_MGCO == peer->mntInfo.protocolType)
      {
         MG_COPY_PEERINFO_INTO_MGCOMSG(alarmInfo.peerInfo[loopIdx], peer);
      }
#endif /* GCP_MGCO */

      /* Increment loopIdx */
      loopIdx++;

      /* Move to next entry in the list */
      cmLstEnt = cmLstEnt->next;

      if (loopIdx >= LMG_MAX_PEER_ENT)
      {
         if (cmLstEnt != NULLP)
         {
            alarmInfo.numAssocPeer = LMG_MAX_PEER_ENT;
            alarmInfo.more         = TRUE;
            mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, LMG_EVENT_SSAP_ENABLED,
                        LCM_CAUSE_UNKNOWN, LMG_ALARMINFO_SSAP_STA, 
                        (Ptr)&(alarmInfo), sizeof(MgSSAPSta), 
                        LMG_ALARMINFO_INVSAPID);

            loopIdx = 0;
            alarmInfo.more = FALSE;
         }
      }
   }

   /* Mark that SSAP Enable has been sent */
   ssap->enbIndSent = TRUE;

#ifdef ZG
   /* send updates */
   /* mg003.105: Bug fix for GCP PSF */
   zgRtUpd(ZG_CBTYPE_SSAP, (Ptr)ssap, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
   /* Send the number of associated peer */
   alarmInfo.numAssocPeer = loopIdx;

   /* Send Status Indication to the layer manager */
   mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, LMG_EVENT_SSAP_ENABLED,
               LCM_CAUSE_UNKNOWN, LMG_ALARMINFO_SSAP_STA,
               (Ptr)&(alarmInfo), sizeof(MgSSAPSta), LMG_ALARMINFO_INVSAPID);

   RETVOID;

} /* end of mgSendSsapEnbStaInd */





/*
*
*       Fun:   mgAdmitTxn
*
*       Desc:  Admit a transaction
*
*       Ret:   ROK     success
*              RFAILED failed
*
*       Notes: Check resource availability on TSAP and SSAP and
*              admit the transaction. If resource is not available 
*              a flow control indication is issues to the service 
*              user.
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAdmitTxn
(
MgSSAPCb           *ssap,              /* session SAP control block */
MgTSAPCb           *tsap               /* transport SAP control block */
)
#else
PUBLIC S16 mgAdmitTxn(ssap, tsap) 
MgSSAPCb           *ssap;              /* session SAP control block */
MgTSAPCb           *tsap;              /* transport SAP control block */
#endif
{
   Reason reason;

   TRC2 (mgAdmitTxn)
 
   mgChkRes (ssap->suPst.region, ssap->suPst.pool, &ssap->resCong);
 
   if (ssap->resCong != TRUE)
   {
      mgChkRes (tsap->spPst.region, tsap->spPst.pool, &tsap->resCong);
 
      if (tsap->resCong != TRUE)
         RETVALUE (ROK);
      else
      {
        reason = HI_FLC_STRT;
        mgGenUserStaInd(NULLP, NULLP, MGT_STATUS_FLOW, (Ptr) &reason);
      }
   }
   else
   {
     reason = HI_FLC_STRT;
     mgGenUserStaInd(NULLP, ssap, MGT_STATUS_FLOW, (Ptr) &reason);
   }
   
   RETVALUE(RFAILED);

} /* end of mgAdmitTxn */




/*
*
*       Fun:   mgCnvrtAddrTbl
*
*       Desc:  This function converts the address tbl returned
*              by GetHostByName2 to the format used in mg
*
*
*       Ret:   ROK     - SUCCESS
*              RFAILED - FAILED
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC S16 mgCnvrtAddrTbl
(
CmInetIpAddrArr *ipAddrTbl,        /* Ip Address in GetHostByName format */
MgNetAddrTbl    *mgAddrTbl         /* IP Address in MgAddrTbl format */
)
#else
PUBLIC S16 mgCnvrtAddrTbl(ipAddrTbl, mgAddrTbl)
CmInetIpAddrArr *ipAddrTbl;        /* Ip Address in GetHostByName format */
MgNetAddrTbl    *mgAddrTbl;        /* IP Address in MgAddrTbl format */
#endif
{
   U16                  i;         /* Temporary Variable */
   CmInetIpv4AddrArr    *ipv4Arr;  /* IPV4 address array */
#ifdef IPV6_SUPPORTED
   CmInetIpv6AddrArr    *ipv6Arr;  /* IPV6 address array */
#endif /* IPV6_SUPPORTED */

   if (ipAddrTbl->type == CM_INET_IPV4ADDR_TYPE)
   {
      ipv4Arr = &(ipAddrTbl->u.ipv4AddrArr);

      mgAddrTbl->count = ipv4Arr->count;

      for(i=0; i< ipv4Arr->count; i++)
      {
         mgAddrTbl->netAddr[i].type = CM_NETADDR_IPV4;
         cmMemcpy((U8 *)&mgAddrTbl->netAddr[i].u.ipv4NetAddr, 
                  (U8 *)&ipv4Arr->netAddr[i], sizeof(CmInetIpAddr));

         if (i >= LMG_MAX_NET_ADDR)
            break;
      }
   }
#ifdef IPV6_SUPPORTED
   else
   {
      ipv6Arr = &(ipAddrTbl->u.ipv6AddrArr);

      mgAddrTbl->count = ipv6Arr->count;

      for(i=0; i< ipv6Arr->count; i++)
      {
         mgAddrTbl->netAddr[i].type = CM_NETADDR_IPV6;
         cmMemcpy((U8 *)&(mgAddrTbl->netAddr[i].u.ipv6NetAddr), 
                  (U8 *)&(ipv6Arr->netAddr[i]), sizeof(CmInetIpAddr6));

         if (i >= LMG_MAX_NET_ADDR)
            break;
      }
   }
#endif /* IPV6_SUPPORTED */

   RETVALUE(ROK);

} /* end of mgCnvrtAddrTbl */





/*
*
*       Fun:   mgChkRes
*
*       Desc:  check resource availability
*
*       Ret:   RETVOID
*
*       Notes: Check resource availability on the appropriate pool/region
*
*       File:  mg_ui.c
*
*/
#ifdef ANSI
PUBLIC Void mgChkRes
(
Region   region,         /* region identifier */
Pool     pool,           /* pool identifier */
Bool     *resCong        /* resouce congestion flag */
)
#else
PUBLIC  Void mgChkRes(region, pool, resCong)
Region   region;         /* region identifier */
Pool     pool;           /* pool identifier */
Bool     *resCong;       /* resouce congestion flag */
#endif
{
   Status res;           /* resouces available */

   TRC3 (mgChkRes);

  (Void)SChkRes(region, pool, &res);

   if (*resCong == TRUE)
   {
      if (res >= mgCb.genCfg.resThUpper)
      {
         /* if we were in cong and pool is back */
         *resCong = FALSE;

         mgGenStaInd(STGEN,LCM_CATEGORY_RESOURCE, LMG_EVENT_RES_CONG_OFF,
                     LCM_CAUSE_UNKNOWN, LMG_ALARMINFO_NONE, NULLP, 0, 
                     LMG_ALARMINFO_INVSAPID);
      }
   }
   else
   {
      if (res < mgCb.genCfg.resThLower)
      {
         /*
          * if we were not congested and availability goes below lower
          * threshold
          */
         *resCong = TRUE;

         mgGenStaInd(STGEN,LCM_CATEGORY_RESOURCE, LMG_EVENT_RES_CONG_ON,
                     LCM_CAUSE_UNKNOWN, LMG_ALARMINFO_NONE, NULLP, 0, 
                     LMG_ALARMINFO_INVSAPID);
      }
   }

   RETVOID;
} /* end of mgChkRes */






#ifdef DEBUGP
/*
*
*       Fun:   mgGetPortAndAscAddr
*
*       Desc:  Get IP port and IP address ASCII string
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  mg_li.c
*
*/
#ifdef ANSI
PUBLIC Void mgGetPortAndAscAddr
(
CmTptAddr  *addr,                   /* transport address */
U16        *port,                   /* port */
Txt        *str                     /* address string */
)
#else
PUBLIC Void mgGetPortAndAscAddr (addr, port, str)
CmTptAddr  *addr;                   /* transport address */
U16        *port;                   /* port */
Txt        *str;                    /* address string */
#endif
{
   TRC2 (mgGetPortAndAscAddr);

   if (addr && addr->type == CM_TPTADDR_IPV4)
   {
      *port = addr->u.ipv4TptAddr.port;
      sprintf (str, "%lX", addr->u.ipv4TptAddr.address);
   }
   else if (addr && addr->type == CM_TPTADDR_IPV6)
   {
      *port = addr->u.ipv6TptAddr.port;
      /* BCD address into ASCII */
      mgBcdToAsc (addr->u.ipv6TptAddr.ipv6NetAddr, CM_IPV6ADDR_SIZE, str);
   }
   else
   {
      *port = 0;
      str[0] = '\0';
   }

   RETVOID;
} /* end of mgGetPortAndAscAddr */




/*
*
*       Fun:   mgBcdToAsc
*
*       Desc:  Converts a BCD address into printable ASCII format.
*              The length is specified in octets.
*              The ASCII string is null terminated. The length
*              of the ascii string should be 2*len + 1
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  mg_li.c
*
*/

#ifdef ANSI
PUBLIC Void mgBcdToAsc
(
U8  *str,                    /* input address string to be converted */
U8  len,                     /* length of input string in octets */
Txt *ascStr                  /* output ASCII string */
)
#else
PUBLIC Void mgBcdToAsc(str, len, ascStr)
U8  *str;                    /* input address string to be converted */
U8  len;                     /* length of input string in octets */
Txt *ascStr;                 /* output ASCII string */
#endif
{
   U8 i;                     /* counter */
   U8 j;                     /* counter */

   TRC2 (mgBcdToAsc);

   /* convert BCD address into ASCII */
   for (i = 0, j = 0; i < len; i++, j += 2)
   {
      ascStr[j]     = BCD_TO_ASCII(str[i] >> 4);
      ascStr[j + 1] = BCD_TO_ASCII(str[i] & 0x0F);
   }

   ascStr[j] = '\0';
} /* end of mgBcdToAsc */


#endif /* DEBUGP */







/*
*
*       Fun:   mgCmpTptAddr
*
*       Desc:  Compare two transport addresses of the type CmTptAddr
*
*       Ret:   -ve  if addr1 < addr2
*              zero if addr1 == addr2
*              +ve  if addr1 > addr2
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC S16 mgCmpTptAddr
(
CmTptAddr  *addr1,       /* first transport address */
CmTptAddr  *addr2        /* first transport address */
)
#else
PUBLIC S16 mgCmpTptAddr(addr1, addr2)
CmTptAddr  *addr1;       /* first transport address */
CmTptAddr  *addr2;       /* first transport address */
#endif
{
   S16     retVal;       /* return value */

   TRC2 (mgCmpTptAddr)

   if (addr1->type != addr2->type)
   {
      RETVALUE (1);
   }

   if ((addr1->type != CM_TPTADDR_IPV4) && (addr1->type != CM_TPTADDR_IPV6))
   {
      RETVALUE (1);
   }

   if (addr1->type == CM_TPTADDR_IPV4)
   {
      if (addr1->u.ipv4TptAddr.address ^ addr2->u.ipv4TptAddr.address)
         RETVALUE(addr1->u.ipv4TptAddr.address -
                  addr2->u.ipv4TptAddr.address);
      else
         RETVALUE(addr1->u.ipv4TptAddr.port - addr2->u.ipv4TptAddr.port);
   }
   else if (addr1->type == CM_TPTADDR_IPV6)
   {
      if ((retVal = cmMemcmp (addr1->u.ipv6TptAddr.ipv6NetAddr,
                              addr2->u.ipv6TptAddr.ipv6NetAddr,
                              sizeof (CmIpv6NetAddr))))
         RETVALUE(retVal);
      else
         RETVALUE(addr1->u.ipv6TptAddr.port - addr2->u.ipv6TptAddr.port);
   }

   RETVALUE(1);
} /* end of mgCmpTptAddr */




/*
*
*       Fun:   mgConvertIpAddrToAscii
*
*       Desc:  This function converts the IP address in U32 format to a IP
*       address in ascii format(X.Y.Z.A). The ascii format IP address is
*       carried in "buF" param, and encodeLen carries its length.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_util.c
*
*/
#ifdef ANSI
PUBLIC Void mgConvertIpAddrToAscii
(
CmNetAddr          *ipAddr,            /* IP Address */
U8                 *buf,               /* Buffer to put ascii string into */
U8                 bufLen,             /* Allocated Buffer Length */
U16                *encodeLen,         /* Length of ASCII String */
U8                 protocol            /* MGCP/MEGACO */
)
#else
PUBLIC Void mgConvertIpAddrToAscii(ipAddr, buf, bufLen, encodeLen, protocol)
CmNetAddr          *ipAddr;            /* IP Address */
U8                 *buf;               /* Buffer to put ascii string into */
U8                 bufLen;             /* Allocated Buffer Length */
U16                *encodeLen;         /* Length of ASCII String */
U8                 protocol;           /* MGCP/MEGACO */
#endif
{
   U8              byteCount;          /* Number of bytes */
   U8              addr[MG_IPV4_ADDRLEN]; /* IP Address Byte Array */
   U8              s[MG_DNAME_FRMT2_LEN]; /* Array for[a.b.c.d] format */
   U16             i;                   /* counter for IPV6 */
   Bool            compressed = FALSE;  /* is IPV6 already compressed */
   Bool            print0 = FALSE;      /* do I want to print out 0 */
   Bool            printColon = TRUE;   /* do I want to print an extra : */
   U16             ipv6Block;           /* IPV6 block, 8 total blocks */
   U16             idx = 0;             /* IPV6 index for buffer*/
   S16             ret;                 /* sprintf return */

   TRC2(mgConvertIpAddrToAscii)

   ipv6Block = 0;  /* initialized */

#if (ERRCLASS & ERRCLS_DEBUG)
   if (bufLen == 0 || bufLen < MG_DNAME_FRMT2_LEN)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG322, 0,
               "[MGCP]mgConvertIpAddrToAscii: Improper buffer length \n");
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   /* 
    * IP Address needs to be encoded in the format of [100.101.102.103]
    * 17 ASCII characters; We are going to convert digits in reverse order
    * so string will be filled reverse first
    */

   if(ipAddr->type == CM_NETADDR_IPV4)
   {
      /* Initialise variables */
      *encodeLen = 0;

      if (protocol == LMG_PROTOCOL_MGCP)   
         s[(*encodeLen)++] = ']';

      /* Get IP Address in a array as four separate bytes */
      addr[0] =  GetLoByte(GetLoWord(ipAddr->u.ipv4NetAddr));
      addr[1] =  GetHiByte(GetLoWord(ipAddr->u.ipv4NetAddr));
      addr[2] =  GetLoByte(GetHiWord(ipAddr->u.ipv4NetAddr));
      addr[3] =  GetHiByte(GetHiWord(ipAddr->u.ipv4NetAddr));

      for (byteCount = 0; byteCount < MG_IPV4_ADDRLEN; byteCount++)
      {
         do
         {
            s[(*encodeLen)++] = ((addr[byteCount]) % 10) + '0';
         }while (((addr[byteCount]) /= 10) > 0); 

         if (byteCount < (MG_IPV4_ADDRLEN -1))
           s[(*encodeLen)++] = '.';
      }

      if (protocol == LMG_PROTOCOL_MGCP)
        /* All digits have been converted to ASCII In reverse; add '[' now  */
         s[(*encodeLen)++] = '[';

      /* Reverse the string */
      for (byteCount = 0; byteCount < *encodeLen; byteCount++)
      {
        buf[byteCount] = s[(*encodeLen) - (byteCount + 1)];
      }
   } /* if, IPV4 processing */
   else
   {
      if (protocol == LMG_PROTOCOL_MGCP)
      {
         buf[0] = '[';
         idx = 1;
      }

      /* we need to print out the 1st block regardless of 0, colon, etc */
      i= 0;
      ipv6Block = PutHiByte(ipv6Block, ipAddr->u.ipv6NetAddr[i]);
      ipv6Block = PutLoByte(ipv6Block, ipAddr->u.ipv6NetAddr[i+1]);
      ret = sprintf((S8 *)(buf+idx),"%x:",ipv6Block);
      idx += ret;
      /* starting with 2nd block, we can compress the 0s */
      for (i = 2; i < 16; i =i+2)
      {
         ipv6Block = PutHiByte(ipv6Block, ipAddr->u.ipv6NetAddr[i]);
         ipv6Block = PutLoByte(ipv6Block, ipAddr->u.ipv6NetAddr[i+1]);
         if ((ipv6Block == 0) && (print0 == FALSE))
         {
           if (printColon == TRUE)
           {
              ret = sprintf((S8 *)(buf+idx),":");
              idx += ret;
              printColon = FALSE;
           }
           compressed = TRUE;
           continue;
         }
         if ((compressed == TRUE) && (print0 == FALSE))
         {
            print0 = TRUE;
         }
         sprintf((S8 *)(buf+idx),"%x:",ipv6Block);
         idx += ret;
      }
      idx --; /* go back a space to remove the last : */
      if (protocol == LMG_PROTOCOL_MGCP)
      {
         buf[idx] = ']'; /* for MGCP, we need the closing ] */
         idx++;
      }
      else
      {
         buf[idx] = '\0'; /* for MGCO, just remove : */
      }
      *encodeLen = idx;
   } /* else IPV6 processing */

   RETVOID;

} /* end of mgConvertIpAddrToAscii() */




/*
*
*       Fun:    mgCheckEnbSsap
*
*       Desc:   This function checks whether enable indication is to be sent
*               to LM and also starts restart avalanche timer if required 
*
*       Ret:    Void
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC Void mgCheckEnbSsap
(
MgSSAPCb           *ssap               /* SSAP Control Block */
)
#else
PUBLIC Void mgCheckEnbSsap (ssap)
MgSSAPCb           *ssap;              /* SSAP Control Block */
#endif
{
   Bool            enb;                /* Send SSAP Enable StaInd ? */

#ifdef GCP_MG
   Random          randTmr;            /* Random Timer for Restart Avalanche */
   U8              idx;                /* Index */
   MgPeerCb        *peer;              /* MGC */
   CmLList         *node;              /* Linked List Node */
#endif /* GCP_MG */
   MgTSAPCb        *tsap;              /* TSAP Control Block */
   U32             i;                  /* Temporary variable */
   CmLListCp       *srvLstCp;
   MgTptSrvr       *nxtSrvr;


   TRC2(mgCheckEnbSsap);


   enb = FALSE;

   /*
    *   On the MGC side -> if there is any server (UDP/TCP) or
    *                      end point, enable the SSAP
    *   On the MG side  -> TCP servers are not needed;
    *                      Atleast one UDP server should be there
    *                      if any peer of this ssap uses UDP;
    *                      One endpoint is needed if any peer of
    *                      this ssap uses SCTP;
    *
    */


   if (ssap->enbIndSent != TRUE)
   {   
      if (mgCb.genCfg.entType == LMG_ENT_GW)
      {
#ifdef GCP_MG
         if ((ssap->numPeerRslvd >= cmLListLen(&(ssap->peerLst))))       
         {
           /* If no peer is
            * configured before enabling the SSAP, the registration
            * procedure will never be triggered */           
           if (cmLListLen(&(ssap->peerLst)) == MG_NONE)
             RETVOID;

#ifdef GCP_MGCP
            if (ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCP)
            {
              if ((cmLListLen(&(ssap->mgcpUDPSrvrLst.srvrLstCp)) > MG_NONE) &&
                  (ssap->nxtUseMgcpSrvr != NULLP))
              {
                enb = TRUE;
              }
            }
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
            if (ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCO)
            {
 
               if ((cmLListLen(&(ssap->mgcoUDPSrvrLst.srvrLstCp)) > MG_NONE) &&
                   (ssap->nxtUseMgcoSrvr != NULLP))
               {
                  enb = TRUE;
               }
            }
#endif /* GCP_MGCO */
         }
#endif /* GCP_MG */
      }



      /* If nothing is enabled yet, check fr the UDP servers in the 
         TSAP. This is done for both MG & MGC */
      if (enb != TRUE)
      {
        for (i=0; i < mgCb.genCfg.maxTSaps; ++i)
        {
          if (mgCb.tSAPLst[i] == NULLP)
            continue;
         
          tsap = mgCb.tSAPLst[i];

          if (tsap->tsapCfg.provType == LMG_PROV_TYPE_TUCL)
          {
            
#ifdef GCP_MGCP
            if (ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCP)
            {
              srvLstCp = &(tsap->mgcpUDPSrvrLst.srvrLstCp);
              nxtSrvr = tsap->nxtUseMgcpSrvr;
            }
#endif /* GCP_MGCP */
            
            
#ifdef GCP_MGCO
            if (ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCO)
            {
              srvLstCp = &(tsap->mgcoUDPSrvrLst.srvrLstCp);
              nxtSrvr = tsap->nxtUseMgcoSrvr;
            }
#endif /* GCP_MGCO */
            
            if (((cmLListLen(srvLstCp)) > MG_NONE)
                && (nxtSrvr != NULLP))
            {
              enb = TRUE;
              break;                      /* break the for tsaps loop */
            }
           
#ifdef GCP_MGCO
#ifdef GCP_MGC
            /* For Megaco, MGC check for tsap server atleast */
            else if ((ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCO) &&
                     (mgCb.genCfg.entType == LMG_ENT_GC))
            {
              if ((cmLListLen(&(tsap->tcpSrvrInfo.srvrLstCp))
                   > MG_NONE)) 
              {
                  enb = TRUE;
                  break;                      /* break the for tsaps loop */
              }              
            }
#endif /* GCP_MGC */
#endif /* GCP_MGCO */
            
          } /* If TUCL */ 

#ifdef GCP_MGCO
#ifdef GCP_MGC
#ifdef GCP_PROV_SCTP
          /* Else for MEGACO check if transport type is SCTP */
          else if ((ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCO) &&
                   (mgCb.genCfg.entType == LMG_ENT_GC) &&
                   (tsap->tsapCfg.provType == LMG_PROV_TYPE_SCTP))
          {
            if (tsap->endpCfgDone == TRUE)
            {
              enb = TRUE;
              break;                      /* break the for tsaps loop */
            }
          }
#endif /* GCP_PROV_SCTP */
#endif /* GCP_MGC */
#endif /* GCP_MGCO */

#ifdef GCP_MGCO
#ifdef GCP_MGC
#ifdef GCP_PROV_MTP3
          /* Else for MEGACO check if transport type is MTP3 */
          else if ((ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCO) &&
                   (mgCb.genCfg.entType == LMG_ENT_GC) &&
                   (tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3))
          {
              enb = TRUE;
              break;                      /* break the for tsaps loop */
          }
#endif /* GCP_PROV_MTP3 */
#endif /* GCP_MGC */
#endif /* GCP_MGCO */

        } /* for */

      } /* If not enabled */



      /* If still not enabled, try the peer lst for the GW side */
#ifdef GCP_MG
      if (mgCb.genCfg.entType == LMG_ENT_GW)
      {

#ifdef GCP_MGCO
        if ((ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCO) &&
            (enb == FALSE))
        {
          /*
           * No UDP servers are found in any tsap or in this ssap;
           *
           * Now go thru the list of peers -
           *
           *    If any of the peers uses UDP, =>s UDP servers
           *    still need to be configured. Therefore enb should
           *    be set to FALSE.
           *
           *    If any of the peers uses SCTP, look if the
           *    SCTP endpoint has been configured.
           *
           *    For TCP on the MG side, there is no need to
           *    configure any servers
           *
           */
          CmLListCp *lCp;
          CmLList   *tmp;
          
          enb = TRUE;
          lCp = &ssap->peerLst;
          
          for(tmp = lCp->first; tmp; tmp = tmp->next)
          {
            peer = (MgPeerCb *)(tmp->node);
            if (peer->accessInfo.transportType == LMG_TPT_UDP)
            {
              enb = FALSE;
              break;
            }
            
#ifdef    GCP_PROV_SCTP
            else if (peer->accessInfo.transportType == LMG_TPT_SCTP)
            {
              if (peer->tsap->endpCfgDone == FALSE)
              {
                enb = FALSE;
                break;
              }
            }
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3
            else if (peer->accessInfo.transportType == LMG_TPT_MTP3)
            {
                enb = TRUE;
            }
#endif    /* GCP_PROV_MTP3 */

          }
        }
#endif /* GCP_MGCO */

        /* If SSAp is enabled, send Reg on MG side */
        if ((enb == TRUE) && (ssap->ssapCfg.initReg == TRUE))
        {
          /* 
           * SSAP is enabled and layer is running on Media Gateway, 
           * initiate the restart avalanche timer 
           */

          /* Calculate a random timer value for restart avalanche timer */
          SRandom(&randTmr);

          /* 
           * mwdTimer with value 0 is not allowed; already ensured in
           * configuration
           */
          randTmr %= ssap->ssapCfg.mwdTimer;
          
          if (randTmr == 0)
            randTmr = ssap->ssapCfg.mwdTimer;
          
          idx = MG_RST_AVLNCH_TMR - MG_PEER_TMR_BASE;
          CM_LLIST_FIRST_NODE(&(ssap->peerLst), node);
          peer =  (MgPeerCb *)(node->node);
          mgStartTmr(MG_RST_AVLNCH_TMR, randTmr, 
                     (PTR)peer,&(peer->mntInfo.tmr[idx]));
        }

      } /* if MG */
#endif /* GCP_MG */

      if(TRUE == enb)
      {
        mgSendSsapEnbStaInd(ssap);
      }

   }

   RETVOID;

} /* end of mgCheckEnbSsap */


/********************************************************************/
/*                   Upper Interface Related Functions              */
/********************************************************************/

/********************************************************************/
/*                   User Status Indication                         */
/********************************************************************/


/*
*
*       Fun:   mgGenUserStaInd
*
*       Desc: Function issues a status indication to the service user.
*               
*       Ret:   
*
*       Notes:
*
*       File:  mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgGenUserStaInd
(
MgPeerCb *peer,           /* Peer Control Block */
MgSSAPCb *ssap,           /* SSAP Control Block */
U8       statusType,      /* Type of Status Ind : Version ind/ flow control */
Ptr      statusInfo       /* Status Information */
)
#else
PUBLIC S16 mgGenUserStaInd(peer, ssap, statusType, statusInfo)
MgPeerCb *peer;           /* Peer Control Block */
MgSSAPCb *ssap;           /* SSAP Control Block */
U8       statusType;      /* Type of Status Ind : Version ind/ flow control */
Ptr      statusInfo;      /* Status Information */
#endif
{
  MgMgtSta      sta;          /* Status Information Structure */
  U16           i;            /* Counter */
  U32           *version;     /* MGCP Version Information */
  Reason        *reason;      /* Reason */

  TRC2(mgGenUserStaInd);

  cmMemset((U8 *)&sta, 0, sizeof(MgMgtSta));

#ifdef MG_RUG
#ifdef GCP_MGCP 
  LMG_SET_BITVECTOR_BIT(sta.bitVector, LMG_GCP_MGCP_BIT);
#endif /* GCP_MGCP */

#ifdef GCP_MGCO 
  LMG_SET_BITVECTOR_BIT(sta.bitVector, LMG_GCP_MGCO_BIT);
#endif /* GCP_MGCO */
#endif /* MG_RUG */

  if (peer != NULLP)
  {
    if(LMG_PROTOCOL_MGCP == peer->mntInfo.protocolType)
    {
#ifdef GCP_MGCP 
       MG_COPY_PEERINFO_INTO_MGCPTXN(sta.peerInfo, peer);
       /*
        * If peerPointer is not NULL, also provide the remote port number
        * information as a part of user indication.
        */
       if(LMG_INVALID_PEER_PORT != peer->accessInfo.remotePort)
       {
          sta.peerInfo.port.pres = PRSNT_NODEF;
          sta.peerInfo.port.val = peer->accessInfo.remotePort;
       }
#endif /* GCP_MGCP */
    }
    else
    {
#ifdef GCP_MGCO
       MG_COPY_PEERINFO_INTO_MGCOMSG(sta.peerInfo, peer);    
#endif /* GCP_MGCO */
    }

    if (ssap != NULLP)
    {
      ssap = peer->ssap;
    }
  }


  sta.type     = statusType;

  switch (statusType)
  {
#ifdef GCP_MGCO
     case MGT_STATUS_MGCO_VER:
       {
         version  = (U32 *)statusInfo;
         sta.u.mgcoVersion.pres = PRSNT_NODEF;
         sta.u.mgcoVersion.val = *version;
         peer->mntInfo.usrKnows = TRUE;
       }
       break;
#endif /* GCP_MGCO */

#ifdef GCP_MGCP 
    case MGT_STATUS_MGCP_VER:
      {
        version  = (U32 *)statusInfo;  
        sta.u.mgcpVersion.pres = PRSNT_NODEF;
        sta.u.mgcpVersion.val = *version;
        peer->mntInfo.usrKnows = TRUE;
      }
       break;
#endif /* GCP_MGCP */

    case MGT_STATUS_FLOW:
      {
        reason = (Reason *)statusInfo;

        if (*reason == HI_FLC_STRT)
          sta.u.action = MGT_FLC_STRT;
        else if (*reason == HI_FLC_STOP)
          sta.u.action = MGT_FLC_STOP;
        else if (*reason == HI_FLC_DROP)
          sta.u.action = MGT_FLC_DROP;        
        else
          RETVALUE(RFAILED);
      }       
      break;
    case MGT_STATUS_HANDOFF_FAILED:
    case MGT_STATUS_REDIRECTION_FAILED:
    case MGT_STATUS_SRVC_PRVDR_FAILED:
    case MGT_STATUS_SAP_RECVRY_SUCCESS:
    case MGT_STATUS_SAP_RECVRY_FAILED:
      break;
    case MGT_STATUS_PEER:
      reason = (Reason *)statusInfo;
      sta.u.reason = (U8)*reason;
      break;
    default:
      RETVALUE(RFAILED);
  }

  if (ssap != NULLP)
  {
    MgUiMgtStaInd(&(ssap->suPst), ssap->suId, &sta);
    RETVALUE(ROK);
  }

  /* If ssap is not specified it implies a flow control for the tsap.
     In such a case all ssaps must be informed */

  for (i=0; i < mgCb.genCfg.maxSSaps; i++)
  {
    ssap = *(mgCb.sSAPLst + i);
    if (ssap == NULLP)
      continue;
    MgUiMgtStaInd(&(ssap->suPst), ssap->suId, &sta);
  }

  RETVALUE(ROK);

} /* end of mgGenUserStaInd() */



/********************************************************************/
/*          Transport Server/Listener Specific Functions            */
/********************************************************************/


/*
*
*       Fun:   mgGetLstnrForTx
*
*       Desc:  This function obtains a listener for next transmission 
*              from SSAP. 
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_util.c
*
*/


#ifdef ANSI
PUBLIC MgTptSrvr * mgGetLstnrForTx
(
MgSSAPCb           *ssap,               /* SSAP Control Block */
MgTSAPCb           *tsap,               /* TSAP Control Block */
U8                 protocol             /* protocol - MGCP/MEGACO */
)
#else
PUBLIC MgTptSrvr * mgGetLstnrForTx (ssap, tsap, protocol)
MgSSAPCb           *ssap;               /* SSAP Control Block */
MgTSAPCb           *tsap;               /* TSAP Control Block */
U8                 protocol;            /* protocol - MGCP/MEGACO */
#endif
{
   MgTptSrvr        *srvrCb;            /* Listener Control Block */
   CmLList         *cmLstEnt;           /* Linked List Entry */
   U32             loopIdx;             /* Loop Index */
   MgTptSrvr       *nxtUseSrvr;         /* next use server */ 
   CmLListCp       *lstCp;              /* server list control point */

   TRC2(mgGetLstnrForTx)

   srvrCb   = NULLP;
   loopIdx  = 0;
   cmLstEnt = NULLP;
   nxtUseSrvr = NULLP;

#ifdef GCP_MG
   if (ssap != NULLP)
   {
      if (protocol == LMG_PROTOCOL_MGCP)
      {
#ifdef GCP_MGCP
         nxtUseSrvr = ssap->nxtUseMgcpSrvr;
         lstCp      = &(ssap->mgcpUDPSrvrLst.srvrLstCp);
#endif /* MG_MGCP */
      }
      else if (protocol == LMG_PROTOCOL_MGCO)
      {
#ifdef GCP_MGCO
         nxtUseSrvr = ssap->nxtUseMgcoSrvr;
         lstCp      = &(ssap->mgcoUDPSrvrLst.srvrLstCp);
#endif /* GCP_MGCO */
      }
   }


   if ((mgCb.genCfg.entType == LMG_ENT_GW) && (ssap != NULLP))
   {
      if (cmLListLen(lstCp) > 0)
      {
         /* Some listeners are configured in SSAP */
         if (nxtUseSrvr == NULLP) 
            RETVALUE(NULLP);
         /*
          * If the following if is valid, instead of returning nxtUseSrvr,
          * make sure that wrap around of SSAP server list is done. Modified 
          * the line RETVALUE(nxtUseSrvr) from the if condition. 
          */
         if ((cmLstEnt = nxtUseSrvr->lstnrNode.next) == NULLP)
         {
            cmLstEnt = lstCp->first;
         }
         /* Check this while loop for correct operation */
         while (loopIdx < cmLListLen(lstCp))
         {				
            /* mg002.105: Check for Null Entity if we are at tail of the list so point again to first node */
             if(cmLstEnt == NULLP)
             { 
                cmLstEnt = lstCp->first;
             }        
            srvrCb = (MgTptSrvr *) cmLstEnt->node;

            /*mg002.105: Check if srvrCb is NULL dont access its element*/
            if ((srvrCb) && (srvrCb->state == LMG_LSTNR_STATE_CONNECTED))
               RETVALUE(srvrCb);
            cmLstEnt = cmLstEnt->next;
            srvrCb  = NULLP;
            /* Increment Loop Counter */
            loopIdx++;
         }
         if (srvrCb == NULLP)
            RETVALUE(NULLP);
      }
   }
#endif /* GCP_MG */


   if (protocol == LMG_PROTOCOL_MGCP)
   {
#ifdef GCP_MGCP
      nxtUseSrvr = tsap->nxtUseMgcpSrvr;
      lstCp      = &(tsap->mgcpUDPSrvrLst.srvrLstCp);
#endif /* MG_MGCP */
   }
   else if (protocol == LMG_PROTOCOL_MGCO)
   {
#ifdef GCP_MGCO
      nxtUseSrvr = tsap->nxtUseMgcoSrvr;
      lstCp      = &(tsap->mgcoUDPSrvrLst.srvrLstCp);
#endif /* GCP_MGCO */
   }


   if (nxtUseSrvr == NULLP) 
      RETVALUE(NULLP);
   /*
    * If the following if is valid, instead of returning nxtUseSrvr,
    * make sure that wrap around of TSAP server list is done. Modified the 
    * line RETVALUE(nxtUseSrvr) from the if condition. 
    */
   if ((cmLstEnt = nxtUseSrvr->lstnrNode.next) == NULLP)
   {
      cmLstEnt = lstCp->first;
   }


      /* Check this while loop for correct operation */
   while (loopIdx < cmLListLen(lstCp))
   {
      srvrCb = (MgTptSrvr *) cmLstEnt->node;

      /*mg002.105: Check if srvrCb is NULL dont access its element*/
      if ((srvrCb) && (srvrCb->state == LMG_LSTNR_STATE_CONNECTED))
         RETVALUE(srvrCb);
      cmLstEnt = cmLstEnt->next;
      srvrCb  = NULLP;
      /* Increment Loop Counter */
      loopIdx++;
   }
   
   RETVALUE(srvrCb);

} /* end of mgGetLstnrForTx */


#ifdef GCP_MGCO
#ifdef GCP_MGC
/*
*
*       Fun:   mgGetSrvrForRedirection
*
*       Desc:  This function obtains a Redirection server for redirecting 
*              an MG from a default server to a server attached to SSAP. 
*              This function is only applicable for MEGACO protocol at MGC 
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC MgTptSrvr * mgGetSrvrForRedirection
(
U8                 transportType,       /* Transport Type */
MgTSAPCb           *tsap                /* TSAP Control Block */
)
#else
PUBLIC MgTptSrvr * mgGetSrvrForRedirection (transportType, tsap)
U8                 transportType;       /* Transport Type */
MgTSAPCb           *tsap;               /* TSAP Control Block */
#endif 
{
   MgTptSrvr        *srvrCb;            /* Server Control Block */
   CmLList         *cmLstEnt;           /* Linked List Entry */
   U32             loopIdx;             /* Loop Index */
   MgTptSrvr       *nxtUseSrvr = NULLP; /* next use server */ 
   CmLListCp       *lstCp;              /* server list control point */

   TRC2(mgGetSrvrForRedirection)

   srvrCb   = NULLP;
   loopIdx  = 0;
   cmLstEnt = NULLP;

   if (transportType == LMG_TPT_UDP)
   {
      nxtUseSrvr = tsap->mgcoUDPSrvrLst.nxtSrvr2Use;
      lstCp      = &(tsap->mgcoUDPSrvrLst.srvrLstCp);
   }
   else if (transportType == LMG_TPT_TCP)
   {
      nxtUseSrvr = tsap->tcpSrvrInfo.nxtSrvr2Use;
      lstCp      = &(tsap->tcpSrvrInfo.srvrLstCp);
   }

   if (nxtUseSrvr == NULLP) 
      RETVALUE(NULLP);

   /* if there is no listener other than nxtUseLstnr..return nxtUseLstnr */
   if ((cmLstEnt = nxtUseSrvr->lstnrNode.next) == NULLP)
      RETVALUE(nxtUseSrvr);

   while (loopIdx < cmLListLen(lstCp))
   {
      srvrCb = (MgTptSrvr *) cmLstEnt->node;

      /*mg002.105: Check if srvrCb is NULL dont access its element*/
      if ((srvrCb) && (srvrCb->state == LMG_LSTNR_STATE_CONNECTED))
         RETVALUE(srvrCb);

      cmLstEnt = cmLstEnt->next;
      srvrCb  = NULLP;

      /* Increment Loop Counter */
      loopIdx++;
   }

   if (srvrCb == NULLP)
      RETVALUE(nxtUseSrvr);
   
   RETVALUE(srvrCb);

} /* end of mgGetSrvrForRedirection */

#endif /* GCP_MGC */
#endif /* GCP_MGCO */




#ifdef GCP_MGCO
/*
*
*       Fun:   mgGetNxtUseConnForTx
*
*       Desc:  This function obtains a listener for next transmission from SSAP. 
*              If there is no listener available in SSAP and if default is 
*              desired a  default listener will be returned
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC MgTptSrvr * mgGetNxtUseConnForTx
(
MgPeerCb           *peer               /* peer for this request */
)
#else
PUBLIC MgTptSrvr * mgGetNxtUseConnForTx(peer)
MgPeerCb           *peer;              /* peer for this request */
#endif
{
    MgTptSrvr        *srvr;              /* Listener Control Block */
    CmLListCp       *lstCp;              /* server list control point */
    CmLList         *cmLstEnt;           /* Linked List Entry */
    U32             loopIdx;             /* Loop Index */
    MgTptSrvr       *nxtUseConn;         /* Last Connection Used */

    TRC2(mgGetNxtUseConnForTx);

    srvr     = NULLP;
    loopIdx  = 0;
    cmLstEnt = NULLP;
   
    nxtUseConn = peer->mgcoInfo.nxtUseConn;
    lstCp      = &(peer->mgcoInfo.tcpConnLst);
   
    /* Try to get the next available Connection. If none is available maintain
       the old one */
    if(nxtUseConn == NULLP)
      RETVALUE(nxtUseConn);
    if ((cmLstEnt = nxtUseConn->lstnrNode.next) == NULLP)
      RETVALUE(nxtUseConn);
   
    while (loopIdx < cmLListLen(lstCp))
    {
      srvr = NULLP;
      srvr = (MgTptSrvr *) cmLstEnt->node;

      if (srvr->state == LMG_LSTNR_STATE_CONNECTED)
        RETVALUE(srvr);

      cmLstEnt = cmLstEnt->next;
      loopIdx++;
    }

    RETVALUE(nxtUseConn);
}



/********************************************************************/
/*               MEGACO Txn Error Processing Functions              */
/********************************************************************/


/*
*
*       Fun:   mgIssueMgcoTxnErr
*
*       Desc:  Issue Megaco message err to the service user.This is used 
*              when an error is encountered in the transaction event
*              or when the transaction event structure is not valid.
*
*              In this function a new event structure is allocated and 
*              the error is filled in the first transaction in the 
*              event and an indication is issued to the user. 
*
*       Ret:   ROK              - successful
*              RFAILED          - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC U16 mgIssueMgcoTxnErr
(
MgSSAPCb      *sSAPCb,       /* SSAP control block */
U16           errType,       /* Type of Error to be reported */
MgPeerCb      *peer,         /* Peer Control Block */
MgTransId     transId        /* Transaction Id */
)
#else
PUBLIC  U16 mgIssueMgcoTxnErr(sSAPCb, errType, peer, transId)
MgSSAPCb      *sSAPCb;       /* SSAP control block */
U16           errType;       /* Type of Error to be reported */
MgPeerCb      *peer;         /* Peer Control Block */
MgTransId     transId;       /* Transaction Id */
#endif
{
   U16 ret;                  /* Return Value */
   MgMgcoMsg *msg;           /* Megaco Message */
   MgMgcoTxn *mgcotxn;       /* Megaco Txn */
/* mg003.105: Changes to send command in case of CH to inform user
              about transaction being aborted */
#if (defined(GCP_CH) && defined(GCP_VER_1_5))   
   MgMgcoInd chInd; 
#endif /* GCP_CH && GCP_VER_1_5 */
   

   TRC2(mgIssueMgcoTxnErr)
/* mg003.105: Changes to send command in case of CH to inform user
              about transaction being aborted */
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
   if (sSAPCb->ssapCfg.chEnabled == TRUE)
   {
      chInd.transId.pres = PRSNT_NODEF;
      chInd.transId.val = transId;
      mgChHandleMgcoPrcIndErr(sSAPCb, &chInd, errType, MG_USER);
      RETVALUE(ROK);
   }
#endif /* GCP_CH && GCP_VER_1_5 */     

   ret = mgAllocEventMem((Ptr *)&msg, sizeof(MgMgcoMsg)); 
  
   if (ret != ROK)
   {
     RETVALUE(ret);
   }
   else   
   {
      msg->pres.pres = PRSNT_NODEF;
   }
  
   msg->body.type.pres = PRSNT_NODEF;
   msg->body.type.val = MGT_TXN;
   msg->body.u.tl.num.pres = PRSNT_NODEF;
   msg->body.u.tl.num.val = 1;

   /*
    * added GCP_VER_1_3 flag for evnt struct allocation
    */
#ifdef GCP_VER_1_3   
   mgcotxn = msg->body.u.tl.txns[0];
   if(ROK != mgAllocEventMem((Ptr *)&mgcotxn, sizeof(MgMgcoTxn)))
   {
      mgFreeEventMem(msg);
      RETVALUE(RFAILED);
   }
   msg->body.u.tl.txns[0] = mgcotxn;
#else
   MGGETMEM((Ptr *)&(msg->body.u.tl.txns), sizeof(Ptr), (Ptr)msg, ret);
   if (ret != ROK)
   {
      mgFreeEventMem(msg);
      RETVALUE(ret);
   }
   MGGETMEM((Ptr *)&(msg->body.u.tl.txns[0]), sizeof(MgMgcoTxn), 
            (Ptr)msg, ret);
   if (ret != ROK)
   {
      mgFreeEventMem(msg);
      RETVALUE(ret);
   }
   mgcotxn = msg->body.u.tl.txns[0];
#endif /* GCP_VER_1_3 */
   mgcotxn->type.pres = PRSNT_NODEF;
   mgcotxn->type.val = MGT_NONE;
   mgcotxn->mgLclErr.errType.pres = PRSNT_NODEF;
   mgcotxn->mgLclErr.errType.val = (U8)errType;

   if (transId !=  MG_IGNORE_TRANSID)
   {
     mgcotxn->mgLclErr.trId.pres = PRSNT_NODEF;
     mgcotxn->mgLclErr.trId.val  = transId;
   }
   else
     mgcotxn->mgLclErr.trId.pres = NOTPRSNT;
     
   if (peer != NULLP)
   {
     MG_COPY_PEERINFO_INTO_MGCOMSG(msg->lcl, peer);
   }
   else
     /* Fill local info Transaction Structure */
     msg->lcl.pres.pres = NOTPRSNT;

   MgUiMgtMgcoTxnInd (&(sSAPCb->suPst), sSAPCb->suId, msg);
   RETVALUE(ROK);

} /* end of mgIssueMgcoTxnErr */




/*
*
*       Fun:   mgHandleMgcoTxnReqErr
*
*       Desc:  This function reports rejection of a transaction to Service
*              user
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC Void mgHandleMgcoTxnReqErr
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgcoMsg          *msg,               /* MGCO Transaction */
U8                 mgtError,           /* Error to be reported */
U8                 source              /* Initiated by user/ internal */
)
#else
PUBLIC Void mgHandleMgcoTxnReqErr(ssap, msg, mgtError, source)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgcoMsg          *msg;               /* MGCO Transaction */
U8                 mgtError;           /* Error to be reported */
U8                 source;             /* Initiated by user/ internal */
#endif
{
   U16             loopIdx;            /* Loop Index */
   MgMgcoTxn       *mgcoTxn;           /* MGCO Txn */
   MgTransId       transId;            /* Transaction ID */
/* mg003.105: Changes to send command in case of CH to inform user
              about transaction being aborted */
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
   MgMgcoInd       chInd;
#endif /*  GCP_CH && GCP_VER_1_5 */ 


   TRC2(mgHandleMgcoTxnReqErr);

   /* If message was internally generated by GCP then dont send
      err indication to the user */
   if (source == MG_INTERNAL)
     RETVOID;

   if (mgtError != MG_IGNORE)
   {  
     /* added check for error descriptor in message body */
     if (msg->body.type.val == MGT_ERRDESC)
     {

#ifdef DEBUGP   
         MGDBGP(DBGMASK_UI,(mgCb.init.prntBuf,
                            "\nmgHandleMgcoTxnReqErr: Error in the processing"
                            " of outgoing msg having error Descriptor"
                            " in messageBody\n"));
#endif /* DEBUGP */

        /*
         * If the stack encountered any error in the processing of an
         * outgoing msg having errorDescriptor in message body, then simply
         * drop that message since a transaction indication with local error
         * is not possible as the message does not have any transaction Id;
         * without the trnId the user will not be able to relate the error
         */
         RETVOID;
     }
     else
     {
        for(loopIdx =0; loopIdx< msg->body.u.tl.num.val; loopIdx++)
        {
          mgcoTxn = *(msg->body.u.tl.txns + loopIdx);

          if (mgcoTxn == NULLP)
            continue;
      
          mgcoTxn->type.pres = PRSNT_NODEF;
          mgcoTxn->type.val  = MGT_TXNLOCAL_ERR;
          mgcoTxn->mgLclErr.errType.pres = PRSNT_NODEF;
          mgcoTxn->mgLclErr.errType.val  = mgtError;
          mgcoTxn->mgLclErr.trId.pres = PRSNT_NODEF;

          MG_GET_TRANSID(mgcoTxn, transId);

          mgcoTxn->mgLclErr.trId.pres = PRSNT_NODEF;
          mgcoTxn->mgLclErr.trId.val = transId;
        }
  
     }
   } /* end of if (mgtError != MG_IGNORE) */
/* mg003.105: Changes to send command in case of CH to inform user
              about transaction being aborted */
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
   if (ssap->ssapCfg.chEnabled == TRUE) 
   {
      for(loopIdx =0; loopIdx< msg->body.u.tl.num.val; loopIdx++)
      {
         mgcoTxn = *(msg->body.u.tl.txns + loopIdx);

         if (mgcoTxn == NULLP)
            continue;
         /* mg003.105: Bug fixes */ 
         if(mgtError == MG_IGNORE)
         {
            if( mgcoTxn->mgLclErr.errType.pres == PRSNT_NODEF)
               mgtError = mgcoTxn->mgLclErr.errType.val;
      
            if( mgcoTxn->mgLclErr.trId.pres == PRSNT_NODEF)
            {   
               transId = mgcoTxn->mgLclErr.trId.val;
               chInd.transId.pres = PRSNT_NODEF;
               chInd.transId.val = transId;
            }
         }   
         else
         {   
         MG_GET_TRANSID(mgcoTxn, transId);
         chInd.transId.pres = PRSNT_NODEF;
         chInd.transId.val = transId;
         }
         mgChHandleMgcoPrcIndErr(ssap, &chInd, mgtError, MG_USER);
      }
      mgFreeEventMem((Ptr)(msg)->body.u.tl.txns[0]);
      mgFreeEventMem((Ptr) msg);
   }
   else
#endif /* GCP_CH && GCP_VER_1_5 */
    /* Indicate Error to user */
   MgUiMgtMgcoTxnInd (&(ssap->suPst), ssap->suId, msg);

   RETVOID;

} /* end of mgHandleMgcoTxnReqErr() */
 


#if (defined(GCP_CH) && defined(GCP_VER_1_5))
 
/*
*
*       Fun:   mgChHandleMgcoCmdReqErr
*
*       Desc:  This function reports rejection of a command to Service
*              user
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC Void mgChHandleMgcoCmdReqErr
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgcoCommand      *chCmd,             /* MGCO Command       */
U8                 mgtError,           /* Error to be reported */
U8                 source              /* Initiated by user/ internal */
)
#else
PUBLIC Void mgChHandleMgcoCmdReqErr(ssap, chCmd, mgtError, source)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgcoCommand      *chCmd;             /* MGCO Command     */
U8                 mgtError;           /* Error to be reported */
U8                 source;             /* Initiated by user/ internal */
#endif
{
   MgMgcoInd       ind;                /* CH Error Ind   */
   MgPeerCb        *peer;

   TRC2(mgChHandleMgcoCmdReqErr);

   /* If message was internally generated by GCP then dont send
      err indication to the user */
   if ((source == MG_INTERNAL) || 
       (chCmd->peerId.pres == NOTPRSNT) ||
       (chCmd == NULLP))
     RETVOID;
 
   cmMemset( (U8 *) &ind, 0, sizeof(MgMgcoInd) );
 
   if (mgtError != MG_IGNORE)
   {
      /* Fill MGT primitive error using the MgtInd Primitive which is  */
      /* used by CH */
      CH_CP_IND_TRANSID(ind, chCmd->transId)
      CH_CP_IND_CNTXTID(ind, chCmd->contextId)
      CH_CP_IND_PEERID(ind, chCmd->peerId.val)
      CH_SET_IND_ERRDESC(ind, mgtError)
   } /* end of if (mgtError != MG_IGNORE) */

   /* Indicate Error to user */
   CH_GET_PEER_FRM_PEERID(chCmd->peerId.val, peer);

   /* If peer is NULL then dont send err indication to the user */
   if (peer == NULLP)
     RETVOID;

   mgChSendPrim ((Ptr)&ind, peer, NULLP, CH_PRIM_TYPE_IND); 
   RETVOID;
} /* end of mgChHandleMgcoCmdReqErr() */

/*
*
*       Fun:   mgChHandleMgcoCntxtUpdErr
*
*       Desc:  This function reports rejection of a update context primitive
*              to Service user.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC Void mgChHandleMgcoCntxtUpdErr
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgcoUpdateCntxt      *mgCntxt,             /* MGCO Command       */
U8                 mgtError,           /* Error to be reported */
U8                 source              /* Initiated by user/ internal */
)
#else
PUBLIC Void mgChHandleMgcoCntxtUpdErr(ssap, mgCntxt, mgtError, source)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgcoUpdateCntxt  *mgCntxt;         /* MGCO Command     */
U8                 mgtError;           /* Error to be reported */
U8                 source;             /* Initiated by user/ internal */
#endif
{
   MgMgcoInd       ind;                /* CH Error Ind   */
   MgPeerCb        *peer;

   TRC2(mgChHandleMgcoCntxtUpdErr);

   /* If message was internally generated by GCP then dont send
      err indication to the user */
   if ((source == MG_INTERNAL) || 
       (mgCntxt->peerId.pres == NOTPRSNT) ||
       (mgCntxt == NULLP))
     RETVOID;

   cmMemset( (U8 *) &ind, 0, sizeof(MgMgcoInd) );
   if (mgtError != MG_IGNORE)
   {
      /* Fill MGT primitive error using the MgtInd Primitive which is  */
      /* used by CH */
      CH_CP_IND_TRANSID(ind, mgCntxt->transId)
      CH_CP_IND_CNTXTID(ind, mgCntxt->contextId)
      CH_CP_IND_PEERID(ind, mgCntxt->peerId.val)
      CH_SET_IND_ERRDESC(ind, mgtError)
   } /* end of if (mgtError != MG_IGNORE) */

   /* Indicate Error to user */
   CH_GET_PEER_FRM_PEERID(mgCntxt->peerId.val, peer);
   mgChSendPrim ((Ptr)&ind, peer, NULLP, CH_PRIM_TYPE_IND); 

   RETVOID;

} /* end of mgChHandleMgcoCntxtUpdErr() */
 
/*
*
*       Fun:   mgChHandleMgcoPrcIndErr
*
*       Desc:  This function reports rejection of a MGCO Indication primitive
*              to Service user.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC Void mgChHandleMgcoPrcIndErr
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgcoInd      *mgInd,             /* MGCO Command       */
U8                 mgtError,           /* Error to be reported */
U8                 source              /* Initiated by user/ internal */
)
#else
PUBLIC Void mgChHandleMgcoPrcIndErr(ssap, mgInd, mgtError, source)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgcoInd  *mgInd;         /* MGCO Command     */
U8                 mgtError;           /* Error to be reported */
U8                 source;             /* Initiated by user/ internal */
#endif
{
   MgMgcoInd       ind;                /* CH Error Ind   */

   TRC2(mgChHandleMgcoPrcIndErr);

   /* If message was internally generated by GCP then dont send
      err indication to the user */
   if ((source == MG_INTERNAL) || (mgInd == NULLP))
     RETVOID;

   cmMemset( (U8 *) &ind, 0, sizeof(MgMgcoInd) );
   if (mgtError != MG_IGNORE)
   {
      /* Fill MGT primitive error using the MgtInd Primitive which is  */
      /* used by CH */
      CH_CP_IND_TRANSID(ind, mgInd->transId)
      CH_CP_IND_CNTXTID(ind, mgInd->cntxtId)
      CH_SET_IND_ERRDESC(ind, mgtError)
   } /* end of if (mgtError != MG_IGNORE) */

   /* Indicate Error to user */
   (*mgUiMgtMgcoTxnStaIndMt[(ssap->suPst.selector)]) (&(ssap->suPst), ssap->suId, &ind);


   RETVOID;

} /* end of mgChHandleMgcoPrcIndErr() */


  
/*
 *
 *       Fun:   mgChAllocatePeerCb
 *
 *       Desc:  This function allocates a CH peer block, initializes the
 *              various lists in it and inserts it into the mgChCb peer Id
 *              based list.
 *
 *       Ret:   None
 *
 *       Notes: None
 *
 *       File:  mg_util.c
 *
 */

#ifdef ANSI
PUBLIC S8 mgChAllocatePeerCb
(
U32                    peerId,            /* CH peer Id */
MgMgcoChPeerCmdCtl     **peerCmdCtl       /* CH peer CB */
)
#else
PUBLIC S8 mgChAllocatePeerCb(peerId, peerCmdCtl)
U32                    peerId;            /* CH peer Id */
MgMgcoChPeerCmdCtl     **peerCmdCtl;      /* CH peer CB */
#endif
{
   U16                  idx;              /* Index */

   TRC2(mgChAllocatePeerCb);

   if (((*peerCmdCtl) = (MgMgcoChPeerCmdCtl *)
                      mgMalloc(sizeof(MgMgcoChPeerCmdCtl))) == NULLP)
   {
      RETVALUE(RFAILED);
   }

   /* Fill Peer Id */
   (*peerCmdCtl)->peerId = peerId;


   /* Init the Transaction response/incoming request List */
   idx = (U16)(((PTR) &(((MgMgcoChTransIndRsp*) 0)->transEnt)));
   if(ROK != cmHashListInit(&((*peerCmdCtl)->transIndRspLst), 
                               mgCb.genCfg.numBinsTransIndRspCmdHl, idx, 
                               FALSE, MG_CH_TXNID_HASH_FUNC, 
                               mgCb.init.region, mgCb.init.pool))
   {
      mgDeAlloc((Data *) (*peerCmdCtl), sizeof(peerCmdCtl));
      RETVALUE(RFAILED);
   }

   /* Init the Transaction request List */
   idx = (U16)(((PTR) &(((MgMgcoChTransReq*) 0)->transReqEnt)));
   if(ROK != cmHashListInit(&((*peerCmdCtl)->transReqLst), 
                               mgCb.genCfg.numBinsTransReqHl, idx, 
                               FALSE, MG_CH_TXNID_HASH_FUNC, 
                               mgCb.init.region, mgCb.init.pool))
   {
      mgDeAlloc((Data *) (*peerCmdCtl), sizeof(peerCmdCtl));
      RETVALUE(RFAILED);
   }
   
   
   /* Insert PeerCommand Ctl Node in the List */
   if ((cmHashListInsert(&(mgCb.chCb.peerCmdCtlLst),
                         (PTR)(*peerCmdCtl),
                         (U8 *)&((*peerCmdCtl)->peerId),
                         MG_CH_PEERID_LEN)) != ROK)
   {
      mgDeAlloc((Data *) (*peerCmdCtl), sizeof(peerCmdCtl));
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}

  
/*
 *
 *       Fun:   mgChAllocateTxnIndRspCb
 *
 *       Desc:  This function allocates a CH txnIndRsp  block, initializes the
 *              various lists in it and inserts it into the CH peerCb txn Id
 *              based list.
 *
 *       Ret:   None
 *
 *       Notes: None
 *
 *       File:  mg_util.c
 *
 */

#ifdef ANSI
PUBLIC S8 mgChAllocateTxnIndRspCb
(
MgMgcoChPeerCmdCtl     *peerCmdCtl,       /* Peer Command Control */
MgMgcoTransId          transId,           /* Transaction Id       */
MgMgcoChTransIndRsp    **trIndRsp,        /* CH Trans IndRsp      */
U32                    numAxn             /* number of actions    */
)
#else
PUBLIC S8 mgChAllocateTxnIndRspCb(peerCmdCtl, transId, trIndRsp, numAxn)
MgMgcoChPeerCmdCtl     *peerCmdCtl;       /* Peer Command Control */
MgMgcoTransId          transId;           /* Transaction Id       */
MgMgcoChTransIndRsp    **trIndRsp;        /* CH Trans IndRsp      */
U32                    numAxn;            /* number of actions    */
#endif
{

   TRC2(mgChAllocateTxnIndRspCb);


   if (((*trIndRsp) = (MgMgcoChTransIndRsp *)
               mgMalloc(sizeof(MgMgcoChTransIndRsp))) == NULLP)
   {
       RETVALUE(RFAILED);
   }

   MG_CH_COPY_STRUCT(&((*trIndRsp)->transId), &transId,
                     sizeof(MgMgcoTransId))

   (*trIndRsp)->peerId = peerCmdCtl->peerId;

   /* (*trIndRsp)->type is populated later in mgChAllocateAxnIndRspCb */

   (*trIndRsp)->curActionId = CH_FIRST_AXN_ID;

   /* initialize the linked list control points */
   cmLListInit(&((*trIndRsp)->userCntxtLst));

   cmLListInit(&((*trIndRsp)->chCntxtLst));

   /* Insert TransIndRsp in TransInd Rsp List */
   if ((cmHashListInsert(&(peerCmdCtl->transIndRspLst), (PTR) (*trIndRsp),
                   (U8 *)&((*trIndRsp)->transId.val), MG_TRANSID_LEN)) != ROK)
   {
       mgDeAlloc((Data *) (*trIndRsp), sizeof(MgMgcoChTransIndRsp));
       RETVALUE(RFAILED);
   }

   /* initialize the number of actions in the txn */
   (*trIndRsp)->numOfIndRspAxns = numAxn;

   /* allocate the array of pointers to the axns */
   if (((*trIndRsp)->axnIndRsp = (MgMgcoChAxnIndRsp **)
               mgMalloc(numAxn * sizeof(MgMgcoChAxnIndRsp *))) == NULLP)
   {
       mgDeAlloc((Data *) (*trIndRsp), sizeof(MgMgcoChTransIndRsp));
       RETVALUE(RFAILED);
   }


   RETVALUE(ROK);
}

  
/*
 *
 *       Fun:   mgChAllocateTxnReqCb
 *
 *       Desc:  This function allocates a CH txnReq  block, initializes the
 *              various lists in it and inserts it into the CH peerCb txn Id
 *              based list.
 *
 *       Ret:   None
 *
 *       Notes: None
 *
 *       File:  mg_util.c
 *
 */

#ifdef ANSI
PUBLIC S8 mgChAllocateTxnReqCb
(
MgMgcoChPeerCmdCtl     *peerCmdCtl,       /* Peer Command Control */
MgMgcoTransId          transId,           /* Transaction Id       */
MgMgcoChTransReq       **transReq         /* CH Trans Req         */
)
#else
PUBLIC S8 mgChAllocateTxnReqCb(peerCmdCtl, transId, transReq)
MgMgcoChPeerCmdCtl     *peerCmdCtl;       /* Peer Command Control */
MgMgcoTransId          transId;           /* Transaction Id       */
MgMgcoChTransReq       **transReq;        /* CH Trans Req         */
#endif
{

   TRC2(mgChAllocateTxnReqCb);


   if (((*transReq) = (MgMgcoChTransReq *)mgMalloc(sizeof(MgMgcoChTransReq)))
                    == NULLP)
   {
      RETVALUE(RFAILED);
   }

   (*transReq)->tmr.tmrEvnt = TMR_NONE;

   cmMemcpy((U8 *)&((*transReq)->transId), (U8 *)&(transId), 
            sizeof(MgMgcoTransId));

   (*transReq)->peerId = peerCmdCtl->peerId;

   (*transReq)->curActionId = CH_FIRST_AXN_ID;

   /* Initialise the various lists in the TransReq Node */
   cmLListInit(&((*transReq)->axnReqLst));

   cmLListInit(&((*transReq)->contextPropLst));

   /* Insert TransReqNode in TransReq List */
   if ((cmHashListInsert(&(peerCmdCtl->transReqLst), (PTR) (*transReq),
                         (U8 *)&((*transReq)->transId.val), 
                         MG_TRANSID_LEN)) != ROK)
   {
      mgDeAlloc((Data *) (*transReq), sizeof(MgMgcoChTransReq));
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}

  
/*
 *
 *       Fun:   mgChAllocateAxnReqCb
 *
 *       Desc:  This function allocates a CH AxnReq  block, initializes the
 *              various lists in it and inserts it into the CH txnReqCb axn Id
 *              based list.
 *
 *       Ret:   None
 *
 *       Notes: None
 *
 *       File:  mg_util.c
 *
 */

#ifdef ANSI
PUBLIC S8 mgChAllocateAxnReqCb
(
MgMgcoChTransReq       *transReq,         /* CH Trans Req         */
U32                    axnId,             /* action Id            */
MgMgcoChAxnReq         **axnReq,          /* CH Axn Req           */
MgMgcoContextId        cntxtId            /* Context Id           */
)
#else
PUBLIC S8 mgChAllocateAxnReqCb(transReq, axnId, axnReq, cntxtId)
MgMgcoChTransReq       *transReq;         /* CH Trans Req         */
U32                    axnId;             /* action Id            */
MgMgcoChAxnReq         **axnReq;          /* CH Axn Req           */
MgMgcoContextId        cntxtId;           /* Context Id           */
#endif
{

   TRC2(mgChAllocateAxnReqCb);

 
   /* Create a Axn Request Node */
   if (((*axnReq) = (MgMgcoChAxnReq*)mgMalloc(sizeof(MgMgcoChAxnReq))) == NULLP)
   {
      RETVALUE(RFAILED);
   }

   /* First action */
   (*axnReq)->actionId = axnId;

   /* add reference to the parent struct */
   (*axnReq)->txnReq   = transReq;

   cmMemcpy((U8 *)&((*axnReq)->cntxtId), (U8*)&(cntxtId),
              sizeof(MgMgcoContextId));

   /* Insert Action Req node in the Axn Req List */
   (*axnReq)->node.node = (PTR)(*axnReq);

   cmLListAdd2Tail (&(transReq->axnReqLst), &((*axnReq)->node));

   RETVALUE(ROK);
}
  
/* mg008.105: New function added for handling wildcard context */
/*
 *
 *       Fun:   mgChAllocateWildCardAxnIndRspCb
 *
 *       Desc:  This function allocates a CH AxnIndRsp  block, initializes the
 *              various lists in it and inserts it into the CH txnIndRspCb
 *              axn Id based list.
 *
 *       Ret:   None
 *
 *       Notes: None
 *
 *       File:  mg_util.c
 *
 */

#ifdef ANSI
PUBLIC S8 mgChAllocateWildCardAxnIndRspCb
(
MgMgcoChTransIndRsp       *trIndRsp,         /* CH Trans IndRsp      */
MgMgcoChAxnIndRsp         **axnIndRsp,       /* CH Axn IndRsp        */
MgMgcoContextId           cntxtId,           /* Context Id           */
U8                        axnType,           /* type - CH_AXN_TYPE_BOTH ...   */
U8                        txnType,           /* type - CH_AXN_TYPE_BOTH ...   */
U32                       crntAxnIdx,        /* current axn index (0 based)   */
U32                       numCmds            /* number of commands in Txn ind */
)
#else
PUBLIC S8 mgChAllocateWildCardAxnIndRspCb(trIndRsp, axnIndRsp, cntxtId,
                                  axnType, txnType, crntAxnIdx, numCmds)
MgMgcoChTransIndRsp       *trIndRsp;         /* CH Trans IndRsp      */
MgMgcoChAxnIndRsp         **axnIndRsp;       /* CH Axn IndRsp        */
MgMgcoContextId           cntxtId;           /* Context Id           */
U8                        axnType;           /* type - CH_AXN_TYPE_BOTH ...   */
U8                        txnType;           /* type - CH_AXN_TYPE_BOTH ...   */
U32                       crntAxnIdx;        /* current axn index (0 based)   */
U32                       numCmds;           /* number of commands in Txn ind */
#endif
{

   TRC2(mgChAllocateWildCardAxnIndRspCb);


   if (((*axnIndRsp) = (MgMgcoChAxnIndRsp *)
            mgMalloc(sizeof(MgMgcoChAxnIndRsp ))) == NULLP)
   {
      RETVALUE(RFAILED);
   }   

   /* fill in the actionId in axnIndRsp */
   (*axnIndRsp)->actionId  = crntAxnIdx;

   MG_CH_COPY_STRUCT(&((*axnIndRsp)->cntxtId), &cntxtId, 
                       sizeof(MgMgcoContextId));

   /* Update the type in Trans Ind Rsp node */
   MG_CH_INIT_TOKEN_VALUE(&(trIndRsp->type), txnType)


   /* Update the type in the AxnIndRsp Node */
   MG_CH_INIT_TOKEN_VALUE(&((*axnIndRsp)->type), axnType)

   /* if there are any cmds in the ind, initialize the array */
   if (numCmds)
   {
      /* Command requests present */
      (*axnIndRsp)->numOfCmdInds = numCmds;

      if ((((*axnIndRsp)->cmdInds) = (MgMgcoCommandReq **)
                  mgMalloc(numCmds * sizeof(MgMgcoCommandReq *))) == NULLP)
      {
          mgDeAlloc((Data *)(*axnIndRsp), sizeof(MgMgcoChAxnIndRsp));
          RETVALUE(RFAILED);        
      }

      /* This event structure will be sent to MU directly */
      /* and hence coping the relevant information */
      /* Copy the command Type  */
      if ((((*axnIndRsp)->cmdIndInfo) = (MgMgcoCmdIndInfo **)
               mgMalloc(numCmds * sizeof(MgMgcoCmdIndInfo *))) == NULLP)
      {
         mgDeAlloc((Data *)((*axnIndRsp)->cmdInds),
                    numCmds * sizeof(MgMgcoCommandReq *));

         mgDeAlloc((Data *)(*axnIndRsp), sizeof(MgMgcoChAxnIndRsp));
         RETVALUE(RFAILED);        
      }
   }

   RETVALUE(ROK);
}
  
/*
 *
 *       Fun:   mgChAllocateAxnIndRspCb
 *
 *       Desc:  This function allocates a CH AxnIndRsp  block, initializes the
 *              various lists in it and inserts it into the CH txnIndRspCb
 *              axn Id based list.
 *
 *       Ret:   None
 *
 *       Notes: None
 *
 *       File:  mg_util.c
 *
 */

#ifdef ANSI
PUBLIC S8 mgChAllocateAxnIndRspCb
(
MgMgcoChTransIndRsp       *trIndRsp,         /* CH Trans IndRsp      */
MgMgcoChAxnIndRsp         **axnIndRsp,       /* CH Axn IndRsp        */
MgMgcoContextId           cntxtId,           /* Context Id           */
U8                        axnType,           /* type - CH_AXN_TYPE_BOTH ...   */
U8                        txnType,           /* type - CH_AXN_TYPE_BOTH ...   */
U32                       crntAxnIdx,        /* current axn index (0 based)   */
U32                       numCmds            /* number of commands in Txn ind */
)
#else
PUBLIC S8 mgChAllocateAxnIndRspCb(trIndRsp, axnIndRsp, cntxtId,
                                  axnType, txnType, crntAxnIdx, numCmds)
MgMgcoChTransIndRsp       *trIndRsp;         /* CH Trans IndRsp      */
MgMgcoChAxnIndRsp         **axnIndRsp;       /* CH Axn IndRsp        */
MgMgcoContextId           cntxtId;           /* Context Id           */
U8                        axnType;           /* type - CH_AXN_TYPE_BOTH ...   */
U8                        txnType;           /* type - CH_AXN_TYPE_BOTH ...   */
U32                       crntAxnIdx;        /* current axn index (0 based)   */
U32                       numCmds;           /* number of commands in Txn ind */
#endif
{

   TRC2(mgChAllocateAxnIndRspCb);


   if (((*axnIndRsp) = (MgMgcoChAxnIndRsp *)
            mgMalloc(sizeof(MgMgcoChAxnIndRsp ))) == NULLP)
   {
      RETVALUE(RFAILED);
   }   

   /* insert the axn into the list of axn pointers in txn */
   trIndRsp->axnIndRsp[crntAxnIdx] = (*axnIndRsp);

   /* add reference to the parent struct */
   (*axnIndRsp)->txnIndRsp = trIndRsp;

   /* fill in the actionId in axnIndRsp */
   (*axnIndRsp)->actionId  = crntAxnIdx;

   MG_CH_COPY_STRUCT(&((*axnIndRsp)->cntxtId), &cntxtId, 
                       sizeof(MgMgcoContextId));

   /* Update the type in Trans Ind Rsp node */
   MG_CH_INIT_TOKEN_VALUE(&(trIndRsp->type), txnType)

   /* Update the type in the AxnIndRsp Node */
   MG_CH_INIT_TOKEN_VALUE(&((*axnIndRsp)->type), axnType)

   /* if there are any cmds in the ind, initialize the array */
   if (numCmds)
   {
      /* Command requests present */
      (*axnIndRsp)->numOfCmdInds = numCmds;

      if ((((*axnIndRsp)->cmdInds) = (MgMgcoCommandReq **)
                  mgMalloc(numCmds * sizeof(MgMgcoCommandReq *))) == NULLP)
      {
          mgDeAlloc((Data *)(*axnIndRsp), sizeof(MgMgcoChAxnIndRsp));
          RETVALUE(RFAILED);        
      }

      /* This event structure will be sent to MU directly */
      /* and hence coping the relevant information */
      /* Copy the command Type  */
      if ((((*axnIndRsp)->cmdIndInfo) = (MgMgcoCmdIndInfo **)
               mgMalloc(numCmds * sizeof(MgMgcoCmdIndInfo *))) == NULLP)
      {
         mgDeAlloc((Data *)((*axnIndRsp)->cmdInds),
                    numCmds * sizeof(MgMgcoCommandReq *));

         mgDeAlloc((Data *)(*axnIndRsp), sizeof(MgMgcoChAxnIndRsp));
         RETVALUE(RFAILED);        
      }
   }
   /* mg008.105: Handling for wild card context */
   if ((cntxtId.type.pres == PRSNT_NODEF) && (cntxtId.type.val == MGT_CXTID_ALL)) 
   {
      if ((((*axnIndRsp)->axnIndWildCardRsp) = (MgMgcoChAxnIndRsp  **)
            mgMalloc(sizeof(MgMgcoChAxnIndRsp  *))) == NULLP)
      {
         mgDeAlloc((Data *)((*axnIndRsp)->cmdIndInfo),
                    numCmds * sizeof(MgMgcoCommandReq *));

         mgDeAlloc((Data *)((*axnIndRsp)->cmdInds),
                    numCmds * sizeof(MgMgcoCommandReq *));

          mgDeAlloc((Data *)(*axnIndRsp), sizeof(MgMgcoChAxnIndRsp));
          RETVALUE(RFAILED);        
      }
      (*axnIndRsp)->numOfWildCardRspAxns = 0;
      (*axnIndRsp)->curWildActionId = 0;
      (*axnIndRsp)->wildCardPres = TRUE;
      
   }

   RETVALUE(ROK);
}

  
/*
 *
 *       Fun:   mgChAllocateCntxtProp
 *
 *       Desc:  This function allocates a CH MgMgcoChCntxtProps block.
 *
 *       Ret:   None
 *
 *       Notes: None.
 *
 *       File:  mg_util.c
 *
 */

#ifdef ANSI
PUBLIC S8 mgChAllocateCntxtProp
(
U32                       crntAxnIdx,        /* current axn index (0 based) */
MgMgcoContextId           cxtId,             /* Context Id                  */
MgMgcoChCntxtProp         **chCntxt,         /* CH cxt prop to be allocated */
MgMgcoContextProps        *cxtProps          /* source Context properties   */
)
#else
PUBLIC S8 mgChAllocateCntxtProp(crntAxnIdx, cxtId, chCntxt, cxtProps)
U32                       crntAxnIdx;        /* current axn index (0 based) */
MgMgcoContextId           cxtId;             /* Context Id                  */
MgMgcoChCntxtProp         **chCntxt;         /* CH cxt prop to be allocated */
MgMgcoContextProps        *cxtProps;         /* source Context properties   */
#endif
{
   U16      tlCnt;
   U16      idx;
   Bool     allocToLclName   = FALSE;
   Bool     allocToDomName   = FALSE;
   Bool     allocFromLclName = FALSE;
   Bool     allocFromDomName = FALSE;
   Bool     allocDesc        = FALSE;
   Bool     allocDescLst     = FALSE;
   Bool     allocCntxtProps  = FALSE;


   TRC2(mgChAllocateCntxtProp);


   if (((*chCntxt) = (MgMgcoChCntxtProp *)
               mgMalloc(sizeof(MgMgcoChCntxtProp))) == NULLP)
   {
       RETVALUE(RFAILED);        
   }   

   allocCntxtProps = TRUE;

   /* Copy Context Information */
   CH_SET_PRESENT((*chCntxt)->pres) 

   MG_CH_COPY_STRUCT(&((*chCntxt)->cxtId), &cxtId, 
                     sizeof(MgMgcoContextId))

   (*chCntxt)->actionId = crntAxnIdx; 

   MG_CH_COPY_STRUCT(&((*chCntxt)->cxtProps), cxtProps,
                     sizeof(MgMgcoContextProps))

   /* Copy topology descriptor if present */
   if ((*chCntxt)->cxtProps.tl.num.pres != NOTPRSNT)
   {
      /* Topology descriptor is present */
      /* Allocate for the double pointer first */
      if (((*chCntxt)->cxtProps.tl.descs = (MgMgcoTopoDesc **)
               mgMalloc((*chCntxt)->cxtProps.tl.num.val * 
               sizeof(MgMgcoTopoDesc *))) == NULLP)
      {
         goto ALLOC_ERR;        
      }

      allocDescLst = TRUE;

      for (tlCnt = 0; tlCnt < (*chCntxt)->cxtProps.tl.num.val;
           tlCnt++)
      {
         /* initialize boolean variables */
         allocDesc = allocFromDomName = allocFromLclName =
         allocToDomName = allocToLclName = FALSE;

         /* Allocate for the double pointer first */
         if (((*chCntxt)->cxtProps.tl.descs[tlCnt] = (MgMgcoTopoDesc *)
                  mgMalloc(sizeof(MgMgcoTopoDesc))) == NULLP)
         {
            goto ALLOC_ERR;
         }

         allocDesc = TRUE;

         /* Copy topology descriptor */
         MG_CH_COPY_STRUCT((*chCntxt)->cxtProps.tl.descs[tlCnt],
                           cxtProps->tl.descs[tlCnt],
                           sizeof(MgMgcoTopoDesc))

         /* Need to allocate for pathnames in termId with type is OTHER */
         if (((*chCntxt)->cxtProps.tl.descs[tlCnt]->from.type.val ==
                        MGT_TERMID_OTHER)
                              &&
             ((*chCntxt)->cxtProps.tl.descs[tlCnt]->from.name.pres.pres !=
                        NOTPRSNT))
         {
            /* Allocate for the pathname for lcl */
            if ((*chCntxt)->cxtProps.tl.descs[tlCnt]->from.name.lcl.pres
                            != NOTPRSNT) 
            {
               if (((*chCntxt)->cxtProps.tl.descs[tlCnt]->from.name.lcl.val
                            = (U8*)
                        mgMalloc((*chCntxt)->cxtProps.tl.descs[tlCnt]\
                           ->from.name.lcl.len)) == NULLP)
               {
                  goto ALLOC_ERR;
               }

               allocFromLclName = TRUE;

               MG_CH_COPY_STRUCT((*chCntxt)->cxtProps.tl.descs[tlCnt]\
                                 ->from.name.lcl.val,
                                 cxtProps->tl.descs[tlCnt]->from.name.lcl.val,
                                 (*chCntxt)->cxtProps.tl.descs[tlCnt]\
                                 ->from.name.lcl.len)
            }

             /* Allocate for the pathname for dom */
            if ((*chCntxt)->cxtProps.tl.descs[tlCnt]->from.name.dom.pres
                             != NOTPRSNT) 
            {
               if (((*chCntxt)->cxtProps.tl.descs[tlCnt]->from.name.dom.val
                                = (U8*)
                        mgMalloc((*chCntxt)->cxtProps.tl.descs[tlCnt]\
                           ->from.name.dom.len)) == NULLP)
               {
                  goto ALLOC_ERR;
               }

               allocFromDomName = TRUE;

               MG_CH_COPY_STRUCT((*chCntxt)->cxtProps.tl.descs[tlCnt]\
                                 ->from.name.dom.val,
                                 cxtProps->tl.descs[tlCnt]->from.name.dom.val,
                                 (*chCntxt)->cxtProps.tl.descs[tlCnt]\
                                 ->from.name.dom.len)
            }
         } /* TERMID = OTHER */

         /* for to */
         if (((*chCntxt)->cxtProps.tl.descs[tlCnt]->to.type.val
                       == MGT_TERMID_OTHER)
                                &&
             ((*chCntxt)->cxtProps.tl.descs[tlCnt]->to.name.pres.pres
                       != NOTPRSNT))
         {
            /* Allocate for the pathname for lcl */
            if((*chCntxt)->cxtProps.tl.descs[tlCnt]->to.name.lcl.pres
                       != NOTPRSNT)
            {
               if (((*chCntxt)->cxtProps.tl.descs[tlCnt]->to.name.lcl.val
                              = (U8*)
                        mgMalloc((*chCntxt)->cxtProps.tl.descs[tlCnt]\
                           ->to.name.lcl.len)) == NULLP)
               {
                  goto ALLOC_ERR;
               }

               allocToLclName = TRUE;

               MG_CH_COPY_STRUCT((*chCntxt)->cxtProps.tl.descs[tlCnt]\
                                 ->to.name.lcl.val,
                                 cxtProps->tl.descs[tlCnt]->to.name.lcl.val,
                                 (*chCntxt)->cxtProps.tl.descs[tlCnt]\
                                 ->to.name.lcl.len)
            }

         }
             /* Allocate for the pathname for dom */
         if ((*chCntxt)->cxtProps.tl.descs[tlCnt]->to.name.dom.pres != NOTPRSNT)
         {
            if (((*chCntxt)->cxtProps.tl.descs[tlCnt]->to.name.dom.val = (U8*)
                     mgMalloc((*chCntxt)->cxtProps.tl.descs[tlCnt]\
                        ->to.name.dom.len)) == NULLP)
            {
               goto ALLOC_ERR;
            }

            allocToDomName = TRUE;

            MG_CH_COPY_STRUCT((*chCntxt)->cxtProps.tl.descs[tlCnt]\
                              ->to.name.dom.val,
                              cxtProps->tl.descs[tlCnt]->to.name.dom.val,
                              (*chCntxt)->cxtProps.tl.descs[tlCnt]\
                              ->to.name.dom.len)
         }
             /* Allocate for the pathname for dom */
      }
   } /* Topology desc present */

   RETVALUE(ROK);



ALLOC_ERR:

   if (TRUE == allocDesc)
   {
      /* free the memory taken by the current desc's term names */
      if (TRUE == allocToLclName)
      {
         mgDeAlloc((Data *)((*chCntxt)->cxtProps.tl.descs[tlCnt]\
                   ->to.name.lcl.val), (*chCntxt)->cxtProps.tl.descs[tlCnt]\
                                         ->to.name.lcl.len);
      }

      if (TRUE == allocToDomName)
      {
         mgDeAlloc((Data *)((*chCntxt)->cxtProps.tl.descs[tlCnt]\
                   ->to.name.dom.val), (*chCntxt)->cxtProps.tl.descs[tlCnt]\
                                         ->to.name.dom.len);
      }

      if (TRUE == allocFromLclName)
      {
         mgDeAlloc((Data *)((*chCntxt)->cxtProps.tl.descs[tlCnt]\
                   ->from.name.lcl.val), (*chCntxt)->cxtProps.tl.descs[tlCnt]\
                                         ->from.name.lcl.len);
      }

      if (TRUE == allocFromDomName)
      {
         mgDeAlloc((Data *)((*chCntxt)->cxtProps.tl.descs[tlCnt]\
                   ->from.name.dom.val), (*chCntxt)->cxtProps.tl.descs[tlCnt]\
                                         ->from.name.dom.len);
      }

      /* free the memory taken by all the previous descs */
      for (idx = 0; idx < tlCnt; idx++)
      {
         /* now free the memory taken by the term names in each of these desc */
         if (((*chCntxt)->cxtProps.tl.descs[idx]->to.name.lcl.pres)
               != NOTPRSNT)
         {
            mgDeAlloc((Data *)((*chCntxt)->cxtProps.tl.descs[idx]\
                      ->to.name.lcl.val), (*chCntxt)->cxtProps.tl.descs[idx]\
                                            ->to.name.lcl.len);
         }

         if (((*chCntxt)->cxtProps.tl.descs[idx]->to.name.dom.pres)
               != NOTPRSNT)
         {
            mgDeAlloc((Data *)((*chCntxt)->cxtProps.tl.descs[idx]\
                      ->to.name.dom.val), (*chCntxt)->cxtProps.tl.descs[idx]\
                                            ->to.name.dom.len);
         }

         if (((*chCntxt)->cxtProps.tl.descs[idx]->from.name.lcl.pres)
               != NOTPRSNT)
         {
            mgDeAlloc((Data *)((*chCntxt)->cxtProps.tl.descs[idx]\
                      ->from.name.lcl.val), (*chCntxt)->cxtProps.tl.descs[idx]\
                                            ->from.name.lcl.len);
         }

         if (((*chCntxt)->cxtProps.tl.descs[idx]->from.name.dom.pres)
               != NOTPRSNT)
         {
            mgDeAlloc((Data *)((*chCntxt)->cxtProps.tl.descs[idx]\
                      ->from.name.dom.val), (*chCntxt)->cxtProps.tl.descs[idx]\
                                            ->from.name.dom.len);
         }

         mgDeAlloc((Data *)((*chCntxt)->cxtProps.tl.descs[idx]),
                   sizeof(MgMgcoTopoDesc));
      }
   }

   /* free the desc list memory */
   if (TRUE == allocDescLst)
      mgDeAlloc((Data *)((*chCntxt)->cxtProps.tl.descs),
                (*chCntxt)->cxtProps.tl.num.val *
                sizeof(MgMgcoTopoDesc *));

   /* free the context props memory */
   if (TRUE == allocCntxtProps)
      mgDeAlloc((Data *)(*chCntxt), sizeof(MgMgcoChCntxtProp));


   RETVALUE(RFAILED);

}


  
/*
 *
 *       Fun:   mgChAllocateCntxtReqCb
 *
 *       Desc:  This function allocates a CH MgMgcoChCntxtProp block,
 *              initializes the various lists in it and inserts it into
 *              the CH txnIndRsp/transReq linked list.
 *
 *       Ret:   None
 *
 *       Notes: Its inserted in the txnIndRsp list if its an incoming
 *              context request. Its inserted in the transReq list if
 *              its an outgoing context request.
 *
 *       File:  mg_util.c
 *
 */

#ifdef ANSI
PUBLIC S8 mgChAllocateCntxtReqCb
(
U8                        txnType,           /*                             */
MgMgcoChTransIndRsp       *trIndRsp,         /* CH Trans IndRsp             */
MgMgcoChTransReq          *transReq,         /* CH Trans Req                */
U32                       crntAxnIdx,        /* current axn index (0 based) */
MgMgcoContextId           cxtId,             /* Context Id                  */
MgMgcoChCntxtProp         **chCntxt,         /* CH cxt prop to be allocated */
MgMgcoContextProps        *cxtProps,         /* source Context properties   */
MgMgcoContextAudit        *cxtAud            /* source Context audit        */
)
#else
PUBLIC S8 mgChAllocateCntxtReqCb(txnType, trIndRsp, transReq, crntAxnIdx,
                                 cxtId, chCntxt, cxtProps, cxtAud)
U8                        txnType;           /*                             */
MgMgcoChTransIndRsp       *trIndRsp;         /* CH Trans IndRsp             */
MgMgcoChTransReq          *transReq;         /* CH Trans Req                */
U32                       crntAxnIdx;        /* current axn index (0 based) */
MgMgcoContextId           cxtId;             /* Context Id                  */
MgMgcoChCntxtProp         **chCntxt;         /* CH cxt prop to be allocated */
MgMgcoContextProps        *cxtProps;         /* source Context properties   */
MgMgcoContextAudit        *cxtAud;           /* source Context audit        */
#endif
{

   TRC2(mgChAllocateCntxtReqCb);

   if (RFAILED == mgChAllocateCntxtProp(crntAxnIdx, cxtId, chCntxt, cxtProps))
      RETVALUE(RFAILED);

   /* now copy the context audit */
   MG_CH_COPY_STRUCT(&((*chCntxt)->cxtAud), cxtAud, sizeof(MgMgcoContextAudit))

   /* Insert Context Info node in the Context List */
   (*chCntxt)->node.node = (PTR)(*chCntxt);

   (*chCntxt)->txnType   = txnType;

   if (txnType == MG_CH_TXN_INDRSP_PEER)
   {
      /* add reference to the parent struct */
      (*chCntxt)->u.txnIndRsp = trIndRsp;

      /* insert block in list */
      cmLListAdd2Tail(&(trIndRsp->chCntxtLst), &((*chCntxt)->node));
   }
   else if (txnType == MG_CH_TXN_REQ)
   {
      /* add reference to the parent struct */
      (*chCntxt)->u.txnReq = transReq;

      /* insert block in list */
      cmLListAdd2Tail(&(transReq->contextPropLst), &((*chCntxt)->node));
   }

   RETVALUE(ROK);

}


  
/*
 *
 *       Fun:   mgChAllocateCntxtRspCb
 *
 *       Desc:  This function allocates a CH MgMgcoChCntxtProp block,
 *              initializes the various lists in it and inserts it into
 *              the CH txnIndRsp linked list.
 *
 *       Ret:   None
 *
 *       Notes: This block can be inserted only in the txnIndRsp list since
 *              a context response can only be generated for incoming
 *              context requests.
 *
 *       File:  mg_util.c
 *
 */

#ifdef ANSI
PUBLIC S8 mgChAllocateCntxtRspCb
(
MgMgcoChTransIndRsp       *trIndRsp,         /* CH Trans IndRsp             */
U32                       crntAxnIdx,        /* current axn index (0 based) */
MgMgcoContextId           cxtId,             /* Context Id                  */
MgMgcoChCntxtProp         **chCntxt,         /* CH cxt prop to be allocated */
MgMgcoContextProps        *cxtProps,         /* source Context properties   */
MgMgcoContextAudit        *cxtAud            /* source Context audit        */
)
#else
PUBLIC S8 mgChAllocateCntxtRspCb(trIndRsp, crntAxnIdx, cxtId,
                                  chCntxt, cxtProps, cxtAud)
MgMgcoChTransIndRsp       *trIndRsp;         /* CH Trans IndRsp             */
U32                       crntAxnIdx;        /* current axn index (0 based) */
MgMgcoContextId           cxtId;             /* Context Id                  */
MgMgcoChCntxtProp         **chCntxt;         /* CH cxt prop to be allocated */
MgMgcoContextProps        *cxtProps;         /* source Context properties   */
MgMgcoContextAudit        *cxtAud;           /* source Context audit        */
#endif
{

   TRC2(mgChAllocateCntxtRspCb);

   if (RFAILED == mgChAllocateCntxtProp(crntAxnIdx, cxtId, chCntxt, cxtProps))
      RETVALUE(RFAILED);

   (*chCntxt)->txnType   = MG_CH_TXN_INDRSP_USR;

   /* add reference to the parent struct */
   (*chCntxt)->u.txnIndRsp = trIndRsp;

   /* context reply does not have context audit */

   /* Insert Context Info node in the Context List */
   (*chCntxt)->node.node = (PTR)(*chCntxt);

   /* mg008.105: Handling for wild card context */
   if(trIndRsp->axnIndRsp[crntAxnIdx]->wildCardPres)
   {
      (*chCntxt)->wildActionId = trIndRsp->axnIndRsp[crntAxnIdx]->curWildActionId;
   }
   cmLListAdd2Tail(&(trIndRsp->userCntxtLst), &((*chCntxt)->node));
   RETVALUE(ROK);
}

  
/*
 *
 *       Fun:   mgChAllocateIncCmdReqCb
 *
 *       Desc:  This function allocates a CH MgMgcoCmdIndInfo block
 *              in the CH axnIndRsp.
 *
 *       Ret:   None
 *
 *       Notes: This function is called in the incoming path.
 *
 *       File:  mg_util.c
 *
 */

#ifdef ANSI
PUBLIC S8 mgChAllocateIncCmdReqCb
(
MgMgcoChAxnIndRsp         *axnIndRsp,        /* axn ind rsp block           */
U32                       crntCmdIdx,        /* current cmd index (0 based) */
MgMgcoTermId              *termId,           /* Termination Id              */
U8                        cmdType,           /* command type                */
MgMgcoCommandReq          *peerCmdReq        /* cmdReq event struct from peer */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
,U8                       encodingScheme     /* Encoding Scheme */ 
#endif /* GCP_VER_1_5 GCP_ASN */
)
#else
PUBLIC S8 mgChAllocateIncCmdReqCb(axnIndRsp, crntCmdIdx, termId,
                                  cmdType, peerCmdReq
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
                                 ,encodingScheme
#endif /* GCP_VER_1_5 GCP_ASN */                                  
                                  )
MgMgcoChAxnIndRsp         *axnIndRsp;        /* axn ind rsp block           */
U32                       crntCmdIdx;        /* current cmd index (0 based) */
MgMgcoTermId              *termId;           /* Termination Id              */
U8                        cmdType;           /* command type                */
MgMgcoCommandReq          *peerCmdReq;       /* cmdReq event struct from peer */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
U8                        encodingScheme;    /* Encoding Scheme */ 
#endif /* GCP_VER_1_5 GCP_ASN */

#endif
{
   U8                   *pTmp = NULLP;       /* Temp pointer         */
   Bool                 allocDomName = FALSE;

   TRC2(mgChAllocateIncCmdReqCb);


   /* copy the cmd req event struct */
   axnIndRsp->cmdInds[crntCmdIdx] = peerCmdReq;
   
   /* Copy the command request block to CH data structure */
   if ((axnIndRsp->cmdIndInfo[crntCmdIdx] = (MgMgcoCmdIndInfo *)
            mgMalloc(sizeof(MgMgcoCmdIndInfo ))) == NULLP)
   {
      RETVALUE(RFAILED);        
   }

   axnIndRsp->cmdIndInfo[crntCmdIdx]->type = cmdType;

   /* add reference to the parent struct */
   axnIndRsp->cmdIndInfo[crntCmdIdx]->axnIndRsp = axnIndRsp;

   /* fill the command id field in MgMgcoCmdIndInfo */
   axnIndRsp->cmdIndInfo[crntCmdIdx]->cmdId     = crntCmdIdx;
 
   MG_CH_COPY_STRUCT(&axnIndRsp->cmdIndInfo[crntCmdIdx]->termId,
                     termId, sizeof(MgMgcoTermId))
   /* Copy Wild field */
   MG_CH_COPY_STRUCT(&axnIndRsp->cmdIndInfo[crntCmdIdx]->wild,
                     &peerCmdReq->wild, sizeof(TknPres))
   /* Copy option field */
   MG_CH_COPY_STRUCT(&axnIndRsp->cmdIndInfo[crntCmdIdx]->opt,
                     &peerCmdReq->opt, sizeof(TknPres))

   if ((termId->type.val == MGT_TERMID_OTHER) &&
       (termId->name.pres.pres!= NOTPRSNT) &&
       (termId->name.dom.pres != NOTPRSNT)) 
   {
      pTmp = (U8 *)termId->name.dom.val;

      if ((axnIndRsp->cmdIndInfo[crntCmdIdx]->termId.name.dom.val = (U8*)
               mgMalloc(termId->name.dom.len)) == NULLP)
      {
         mgDeAlloc((Data *)axnIndRsp->cmdIndInfo[crntCmdIdx],
                   sizeof(MgMgcoCmdIndInfo));

         RETVALUE(RFAILED);       
      }

      MG_CH_COPY_STRUCT(axnIndRsp->cmdIndInfo[crntCmdIdx]->termId.name.dom.val,
                        pTmp, termId->name.dom.len) 

      allocDomName = TRUE;
   }

   if ((termId->type.val == MGT_TERMID_OTHER) &&
       (termId->name.pres.pres != NOTPRSNT) &&
       (termId->name.lcl.pres != NOTPRSNT)) 
   {
      pTmp = (U8 *)termId->name.lcl.val;

      if ((axnIndRsp->cmdIndInfo[crntCmdIdx]->termId.name.lcl.val = (U8*)
               mgMalloc(termId->name.lcl.len)) == NULLP)
      {
         if (TRUE == allocDomName)
         {
            mgDeAlloc((Data *)axnIndRsp->cmdIndInfo[crntCmdIdx]->\
                      termId.name.lcl.val, sizeof(termId->name.lcl.len));
         }

         mgDeAlloc((Data *)axnIndRsp->cmdIndInfo[crntCmdIdx],
                   sizeof(MgMgcoCmdIndInfo));

         RETVALUE(RFAILED);       
      }

      MG_CH_COPY_STRUCT(axnIndRsp->cmdIndInfo[crntCmdIdx]->termId.name.lcl.val,
                        pTmp, termId->name.lcl.len) 
   }

#ifdef GCP_ASN
   if(encodingScheme == LMG_ENCODE_BIN)
   {   
      /* copy the wildcard contents also */
      if (((termId->type.val == MGT_TERMID_ALL) || 
          (termId->type.val == MGT_TERMID_CHOOSE)) &&
          (termId->name.pres.pres != NOTPRSNT) &&
          (termId->name.lcl.pres != NOTPRSNT)) 
      {
         pTmp = (U8 *)termId->name.lcl.val;

         if ((axnIndRsp->cmdIndInfo[crntCmdIdx]->termId.name.lcl.val = (U8*)
                  mgMalloc(termId->name.lcl.len)) == NULLP)
         {
            if (TRUE == allocDomName)
            {
               mgDeAlloc((Data *)axnIndRsp->cmdIndInfo[crntCmdIdx]->\
                         termId.name.lcl.val, sizeof(termId->name.lcl.len));
            }

            mgDeAlloc((Data *)axnIndRsp->cmdIndInfo[crntCmdIdx],
                      sizeof(MgMgcoCmdIndInfo));

            RETVALUE(RFAILED);       
         }

         MG_CH_COPY_STRUCT(axnIndRsp->cmdIndInfo[crntCmdIdx]->termId.name.lcl.val,
                           pTmp, termId->name.lcl.len) 
      }

      if ((termId->wildcard.num.pres == PRSNT_NODEF) &&
          (termId->wildcard.num.val != 0) &&
          (termId->wildcard.wildcard))
      {
         U16   ix, nmbr;

         nmbr = termId->wildcard.num.val;

         (axnIndRsp)->cmdIndInfo[crntCmdIdx]->termId.wildcard.num = termId->wildcard.num;

         if (((axnIndRsp)->cmdIndInfo[crntCmdIdx]->termId.wildcard.wildcard = 
                     (MgMgcoWildcardField **)
                     mgMalloc( nmbr * sizeof(MgMgcoWildcardField *))) == NULLP)
         {
             mgDeAlloc((Data *) ((axnIndRsp->cmdIndInfo[crntCmdIdx]->
                                  termId.wildcard.wildcard)), 
                                  (nmbr * sizeof(MgMgcoWildcardField *)));
             RETVALUE(RFAILED);
         }

         for (ix=0; ix < nmbr; ++ix)
         {
            if (((axnIndRsp)->cmdIndInfo[crntCmdIdx]->termId.wildcard.wildcard[ix] =
              (MgMgcoWildcardField *) mgMalloc(sizeof(MgMgcoWildcardField))) == NULLP)
            {
                mgDeAlloc((Data *) ((axnIndRsp->cmdIndInfo[crntCmdIdx]->termId.wildcard.wildcard[ix])),
                                       sizeof(MgMgcoWildcardField));
                RETVALUE(RFAILED);
            }
            MG_CH_COPY_STRUCT((axnIndRsp->cmdIndInfo[crntCmdIdx]->termId.wildcard.wildcard[ix]),
                              (termId->wildcard.wildcard[ix]),
                              sizeof(MgMgcoWildcardField ))
         }

      }
   }   
#endif /* GCP_ASN */

   RETVALUE(ROK);
}


/*
 *
 *       Fun:   mgChAllocateOutCmdReqCb
 *
 *       Desc:  This function allocates a CH MgMgcoChCmdReq block
 *              in the CH axnReq.
 *
 *       Ret:   None
 *
 *       Notes: This function is called in the Outgoing path.
 *
 *       File:  mg_util.c
 *
 */

#ifdef ANSI
PUBLIC S8 mgChAllocateOutCmdReqCb
(
MgMgcoChTransReq          *transReq,         /* trans Req block             */
MgMgcoChAxnReq            *axnReq,           /* axn Req block               */
MgMgcoChCmdReq            **cmdReqNode,      /* Cmd Req Node                */
MgMgcoCommandReq          *usrCmdReq         /* Cmd Req event struct frm usr */
)
#else
PUBLIC S8 mgChAllocateOutCmdReqCb(transReq, axnReq, cmdReqNode, usrCmdReq)
MgMgcoChTransReq          *transReq;         /* trans Req block             */
MgMgcoChAxnReq            *axnReq;           /* axn Req block               */
MgMgcoChCmdReq            **cmdReqNode;      /* Cmd Req Node                */
MgMgcoCommandReq          *usrCmdReq;        /* Cmd Req event struct frm usr */
#endif
{

   TRC2(mgChAllocateOutCmdReqCb);


   if (((*cmdReqNode) = (MgMgcoChCmdReq *)
            mgMalloc(sizeof(MgMgcoChCmdReq))) == NULLP)
   {
       RETVALUE(RFAILED);
   }

   /* Now just assign the pointer to the cmdReq in primitive
    * structure to the CmdReqNode in CH. */
   (*cmdReqNode)->cmdReq = usrCmdReq;

   /* add reference to the parent struct */
   (*cmdReqNode)->axnReq = axnReq;

   /* fill in the command Id. This is the same as new count (which is
    * calculated below after adding this cmd to the list) - 1 since cmd
    * Id is zero based. Therefore the cmdId is the same as the current
    * cmd count in the list */
   (*cmdReqNode)->cmdId  = axnReq->cmdReqLst.count;

   /* Insert Command Req node in the Cmd Req List */
   (*cmdReqNode)->node.node = (PTR)(*cmdReqNode);

   cmLListAdd2Tail(&(axnReq->cmdReqLst), &((*cmdReqNode)->node));
    
   /* modify the transReq type to indicate that cmds have been issued */
   if (transReq->type.val == (U8)CH_AXN_TYPE_NONE)
   {
      transReq->type.val = (U8)CH_AXN_TYPE_ONLY_CMDS;
   }
   else if (transReq->type.val == (U8)CH_AXN_TYPE_ONLY_CNTXT)
   {
      transReq->type.val = (U8)CH_AXN_TYPE_BOTH;
   }
   
   RETVALUE(ROK); 
}


/*
 *
 *       Fun:   mgChAllocateCmdRspCb
 *
 *       Desc:  This function allocates a CH MgMgcoChCmdResp block
 *              in the CH axnIndRsp.
 *
 *       Ret:   None
 *
 *       Notes: This function is called only in the outgoing path in
 *              response to an earlier cmd req.
 *
 *       File:  mg_util.c
 *
 */

#ifdef ANSI
PUBLIC S8 mgChAllocateCmdRspCb
(
MgMgcoChAxnIndRsp         *axnIndRsp,        /* axn ind rsp block           */
MgMgcoChCmdResp           **cmdRsp,          /* cmd Resp to be allocated    */
MgMgcoCmdReply            *usrCmdRsp         /* cmd rsp event struct frm usr */
)
#else
PUBLIC S8 mgChAllocateCmdRspCb(axnIndRsp, cmdRsp, usrCmdRsp)
MgMgcoChAxnIndRsp         *axnIndRsp;        /* axn ind rsp block           */
MgMgcoChCmdResp           **cmdRsp;          /* cmd Resp to be allocated    */
MgMgcoCmdReply            *usrCmdRsp;        /* cmd rsp event struct frm usr */
#endif
{
   MgMgcoChAxnIndRsp      *axnIndWildCardRsp = NULLP;    /* Actions contains command      */

   TRC2(mgChAllocateCmdRspCb);


   /* Assuming resp List would have been initialised */
   /* Concatenate the response list with the received response */
   if (((*cmdRsp) = (MgMgcoChCmdResp*)
               mgMalloc(sizeof(MgMgcoChCmdResp))) == NULLP)
   {
       RETVALUE(RFAILED);
   }

   /* Now copy the cmd Rsp event struct in the cmdRsp cb */
   (*cmdRsp)->cmdResp = usrCmdRsp;

   /* add reference to the parent struct */
   /* mg008.105: Handling for wild card context */
   if (axnIndRsp->wildCardPres)
   {
      axnIndWildCardRsp = axnIndRsp->axnIndWildCardRsp[axnIndRsp->curWildActionId];
      (*cmdRsp)->axnIndRsp = axnIndWildCardRsp;
      /* Insert command Resp node in the cmd resp List */
      (*cmdRsp)->node.node = (PTR)(*cmdRsp);
      cmLListAdd2Tail(&(axnIndWildCardRsp->respLst), &((*cmdRsp)->node));
   }
   else
   {

      (*cmdRsp)->axnIndRsp = axnIndRsp;
      (*cmdRsp)->cmdIndId  = axnIndRsp->curCmdIndId;
      /* Insert command Resp node in the cmd resp List */
      (*cmdRsp)->node.node = (PTR)(*cmdRsp);
      cmLListAdd2Tail(&(axnIndRsp->respLst), &((*cmdRsp)->node));
   }

   RETVALUE(ROK);
}


/* The following function frees the txnIndRsp CB */

#ifdef ANSI
PUBLIC Void   mgChFreeTxnIndRspCb
(
MgMgcoChTransIndRsp         *txnIndRsp         /* txn ind rsp block           */
)
#else
PUBLIC Void   mgChFreeTxnIndRspCb(txnIndRsp)
MgMgcoChTransIndRsp         *txnIndRsp;        /* txn ind rsp block           */
#endif
{

   TRC3(mgChFreeTxnIndRspCb)


   mgDeAlloc((Data *)txnIndRsp->axnIndRsp,
             txnIndRsp->numOfIndRspAxns * sizeof(MgMgcoChAxnIndRsp *));

   mgDeAlloc((Data *)txnIndRsp, sizeof(MgMgcoChTransIndRsp));

   RETVOID;
}


/* The following function frees the chCntxt CB */

#ifdef ANSI
PUBLIC Void   mgChFreeChCntxtLstInTransIndRspCb
(
MgMgcoChTransIndRsp         *txnIndRsp         /* txn ind rsp block           */
)
#else
PUBLIC Void   mgChFreeChCntxtLstInTransIndRspCb(txnIndRsp)
MgMgcoChTransIndRsp         *txnIndRsp;        /* txn ind rsp block           */
#endif
{
   U32                 idx;
   U32                 jdx;
   U32                 cntxtCount;
   MgMgcoChCntxtProp   *chCntxt; 
   /* MgMgcoChCntxtProp   *bakChCntxt = NULLP; */
   CmLList             *pTemp = NULLP;            /* List Node          */
   CmLList             *pNode =  txnIndRsp->chCntxtLst.first;
                                

   TRC3(mgChFreeChCntxtLstInTransIndRspCb)

   cntxtCount = txnIndRsp->chCntxtLst.count;
   for (idx = 0; idx < cntxtCount; idx++)
   {
      chCntxt = (MgMgcoChCntxtProp *)pNode->node;
      pTemp = pNode->next;
      /* Free the context prop node */
      cmLListDelFrm (&(txnIndRsp->chCntxtLst), pNode);
      if (chCntxt->cxtProps.tl.num.pres == PRSNT_NODEF)
      {
         for (jdx = 0; jdx < chCntxt->cxtProps.tl.num.val; jdx++)
         {
            if (chCntxt->cxtProps.tl.descs[jdx]->from.name.lcl.pres ==
                  PRSNT_NODEF)
               mgDeAlloc((Data *)chCntxt->cxtProps.tl.descs[jdx]->from.name.\
                         lcl.val,
                         chCntxt->cxtProps.tl.descs[jdx]->from.name.lcl.len);

            if (chCntxt->cxtProps.tl.descs[jdx]->from.name.dom.pres ==
                  PRSNT_NODEF)
               mgDeAlloc((Data *)chCntxt->cxtProps.tl.descs[jdx]->from.name.\
                         dom.val,
                         chCntxt->cxtProps.tl.descs[jdx]->from.name.dom.len);

            if (chCntxt->cxtProps.tl.descs[jdx]->to.name.lcl.pres ==
                  PRSNT_NODEF)
               mgDeAlloc((Data *)chCntxt->cxtProps.tl.descs[jdx]->to.name.\
                         lcl.val,
                         chCntxt->cxtProps.tl.descs[jdx]->to.name.lcl.len);

            if (chCntxt->cxtProps.tl.descs[jdx]->to.name.dom.pres ==
                  PRSNT_NODEF)
               mgDeAlloc((Data *)chCntxt->cxtProps.tl.descs[jdx]->to.name.\
                         dom.val,
                         chCntxt->cxtProps.tl.descs[jdx]->to.name.dom.len);

            mgDeAlloc((Data *)chCntxt->cxtProps.tl.descs[jdx],
                      sizeof(MgMgcoTopoDesc));
         }

         mgDeAlloc((Data *)chCntxt->cxtProps.tl.descs,
                   chCntxt->cxtProps.tl.num.val * sizeof(MgMgcoTopoDesc *));
      }

      mgDeAlloc ((Data *) chCntxt, sizeof(MgMgcoChCntxtProp));
      pNode = pTemp;
      

      /* chCntxt = (MgMgcoChCntxtProp *)(chCntxt->node->next->node); */

      /* mgDeAlloc((Data *)bakChCntxt, sizeof(MgMgcoChCntxtProp)); */
   }

   RETVOID;
}





/* The following function frees the axnIndRsp CB */

#ifdef ANSI
PUBLIC Void   mgChFreeAxnIndRspCb
(
MgMgcoChAxnIndRsp         *axnIndRsp         /* axn ind rsp block           */
)
#else
PUBLIC Void   mgChFreeAxnIndRspCb(axnIndRsp)
MgMgcoChAxnIndRsp         *axnIndRsp;        /* axn ind rsp block           */
#endif
{

   TRC3(mgChFreeAxnIndRspCb)


   mgDeAlloc((Data *)axnIndRsp->cmdInds,
             axnIndRsp->numOfCmdInds * sizeof(MgMgcoCommandReq *));

   mgDeAlloc((Data *)axnIndRsp->cmdIndInfo,
             axnIndRsp->numOfCmdInds * sizeof(MgMgcoCmdIndInfo *));

   mgDeAlloc((Data *)axnIndRsp, sizeof(MgMgcoChAxnIndRsp));

   RETVOID;
}



/* The following function frees the incCmdReq CB */

#ifdef ANSI
PUBLIC Void   mgChFreeIncCmdReqCb
(
MgMgcoChAxnIndRsp         *axnIndRsp,        /* axn ind rsp block     */
U16                       cmdIdx             /* cmd index             */
)
#else
PUBLIC Void   mgChFreeIncCmdReqCb(axnIndRsp, cmdIdx)
MgMgcoChAxnIndRsp         *axnIndRsp;        /* axn ind rsp block     */
U16                       cmdIdx;            /* cmd index             */
#endif
{

   TRC3(mgChFreeIncCmdReqCb)

   if (axnIndRsp->cmdIndInfo[cmdIdx]->termId.name.dom.pres == PRSNT_NODEF)
      mgDeAlloc((Data *)axnIndRsp->cmdIndInfo[cmdIdx]->termId.name.dom.val,
                axnIndRsp->cmdIndInfo[cmdIdx]->termId.name.dom.len);

   if (axnIndRsp->cmdIndInfo[cmdIdx]->termId.name.lcl.pres == PRSNT_NODEF)
      mgDeAlloc((Data *)axnIndRsp->cmdIndInfo[cmdIdx]->termId.name.lcl.val,
                axnIndRsp->cmdIndInfo[cmdIdx]->termId.name.lcl.len);

   mgDeAlloc((Data *)axnIndRsp->cmdIndInfo[cmdIdx], sizeof(MgMgcoCmdIndInfo));

   RETVOID;
}

/* mg008.105: Function added to grow the double pointer list */
#ifdef ANSI
PUBLIC S16    mgChGrowMem
(
Ptr         *ptr,      /* address */
MsgLen       newSiz,   /* new size */
MsgLen       oldSiz,   /* old size */
MsgLen       siz       /* how much size */
)
#else
PUBLIC S16    mgChGrowMem(ptr, newSiz, oldSiz, siz)
Ptr         *ptr;      /* address */
MsgLen       newSiz;   /* new size */
MsgLen       oldSiz;   /* old size */
MsgLen       siz;      /* how much size */
#endif
{
   Ptr *tmpPtr;

   TRC3(mgChGrowMem)

   if(((tmpPtr) = (Ptr*) mgMalloc(newSiz * siz)) == NULLP)
   {
      RETVALUE(RFAILED);
   }
   /* deal with old memory */
   if ((*ptr) && (oldSiz != 0))
   {
      (void)cmMemcpy((U8*)tmpPtr, (CONSTANT U8*)*ptr, oldSiz * siz);
      mgDeAlloc((Data *)ptr, oldSiz * siz);
   }
   *ptr = tmpPtr;
   RETVALUE(ROK);
}

/* adding new utility functions which call zgDelMapping for a Ch block
 * and all its child blocks */
#ifdef ZG

/* The following function calls zgDelMapping for txnIndRsp & for all
 * its child blocks */

#ifdef ANSI
PUBLIC Void   mgChDelMappingTxnIndRspAndChilds
(
MgMgcoChTransIndRsp       *trIndRsp          /* txn ind rsp block */
)
#else
PUBLIC Void   mgChDelMappingTxnIndRspAndChilds(trIndRsp)
MgMgcoChTransIndRsp       *trIndRsp;         /* txn ind rsp block */
#endif
{
   U16                 idx, jdx;
   MgMgcoChCmdResp     *cmdRsp   = NULLP;
   MgMgcoChCntxtProp   *chCntxt  = NULLP;
   CmLList             *listNode = NULLP;


   TRC3(mgChDelMappingTxnIndRspAndChilds)


   /* for each cmd within each axn free the cmd rsp event struct */
   for (idx = 0; idx < trIndRsp->numOfIndRspAxns; idx++)
   {
      if (trIndRsp->axnIndRsp[idx]->respLst.count)
      {
         for (jdx = 0, cmdRsp = (MgMgcoChCmdResp *)
                          (trIndRsp->axnIndRsp[idx]->respLst.first->node);
              jdx < trIndRsp->axnIndRsp[idx]->respLst.count;
              jdx++)
         {
            /* free the cmdResp event struct */
            /* if (cmdRsp->cmdResp) */
               /* mgFreeEventMem((Ptr)cmdRsp->cmdResp); */
             if(cmdRsp == NULL)
                continue;

            zgDelMapping(ZG_CBTYPE_CH_OUT_CMDRSP, (Ptr)cmdRsp);
            /* the cmd resp would be freed in mgChCleanupTransIndRsp */

            if (cmdRsp->node.next)
               cmdRsp = (MgMgcoChCmdResp *)cmdRsp->node.next->node;
         }
      }

      for (jdx = 0; jdx < trIndRsp->axnIndRsp[idx]->numOfCmdInds;
           jdx++)
      {
         if(trIndRsp->axnIndRsp[idx]->cmdIndInfo[jdx] == NULLP)
            continue;
         zgDelMapping(ZG_CBTYPE_CH_INC_CMDREQ,
                      (Ptr)(trIndRsp->axnIndRsp[idx]->cmdIndInfo[jdx]));
         /* the cmd req would be freed in mgChCleanupTransIndRsp */
      }

      zgDelMapping(ZG_CBTYPE_CH_AXN_INDRSP, (Ptr)trIndRsp->axnIndRsp[idx]);
      /* the axn resp would be freed in mgChCleanupTransIndRsp */
   }


   /* delete mapping for all the user contexts */
   listNode = trIndRsp->userCntxtLst.first;
   for (idx=0; idx < trIndRsp->userCntxtLst.count;
        idx++)
   {
      chCntxt = (MgMgcoChCntxtProp *)(listNode->node);

      zgDelMapping(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCntxt));
      /* chCntxt is freed in mgChCleanupTransIndRsp */

      listNode = listNode->next;
   }

   /* delete mapping for all the peer contexts */
   listNode = trIndRsp->chCntxtLst.first;
   for (idx=0; idx < trIndRsp->chCntxtLst.count;
        idx++)
   {
      chCntxt = (MgMgcoChCntxtProp *)(listNode->node);

      zgDelMapping(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCntxt));
      /* chCntxt is freed in mgChCleanupTransIndRsp */

      listNode = listNode->next;
   }


   /* Delete mapping of control block from resource set */
   zgDelMapping(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)trIndRsp);

   RETVOID;
}


/* The following function calls zgDelMapping for txnReq & for all
 * its child blocks */

#ifdef ANSI
PUBLIC Void   mgChDelMappingTxnReqAndChilds
(
MgMgcoChTransReq          *trans             /* txn req block */
)
#else
PUBLIC Void   mgChDelMappingTxnReqAndChilds(trans)
MgMgcoChTransReq          *trans;            /* txn req block */
#endif
{
   U16                 idx, jdx;
   MgMgcoChAxnReq      *axnReq   = NULLP;
   MgMgcoChCmdReq      *cmdReq   = NULLP;
   MgMgcoChCntxtProp   *chCntxt  = NULLP;
   CmLList             *listNode;


   TRC3(mgChDelMappingTxnReqAndChilds)


   /* for each cmd within each axn free the cmd req event struct */
   if (trans->axnReqLst.count)
   {
      for (idx = 0, axnReq = (MgMgcoChAxnReq *)(trans->axnReqLst.first->node);
           idx < trans->axnReqLst.count;
           idx++)
      {
         if (axnReq->cmdReqLst.count)
         {
            for (jdx=0, cmdReq = (MgMgcoChCmdReq *)\
                                 (axnReq->cmdReqLst.first->node);
                 jdx < axnReq->cmdReqLst.count;
                 jdx++)
            {
               /* free the stored event struct */
               /* if (cmdReq->cmdReq) */
                  /* mgFreeEventMem((Ptr)cmdReq->cmdReq); */

               zgDelMapping(ZG_CBTYPE_CH_OUT_CMDREQ, (Ptr)cmdReq);
               /* the cmd would be freed in the mgChCleanupTransReq func */

               if (cmdReq->node.next)
                  cmdReq = (MgMgcoChCmdReq *)cmdReq->node.next->node;
            }
         }

         zgDelMapping(ZG_CBTYPE_CH_AXN_REQ, (Ptr)axnReq);
         /* the axn would be freed in the mgChCleanupTransReq func */

         if (axnReq->node.next)
            axnReq = (MgMgcoChAxnReq *)axnReq->node.next->node;
      }
   }


   /* delete mapping for all the user contexts */
   listNode = trans->contextPropLst.first;
   for (idx=0; idx < trans->contextPropLst.count;
        idx++)
   {
      chCntxt = (MgMgcoChCntxtProp *)(listNode->node);

      zgDelMapping(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCntxt));
      /* chCntxt is freed in mgChCleanupTransIndRsp */

      listNode = listNode->next;
   }


   /* Delete mapping of control block from resource set */
   zgDelMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)trans);

   RETVOID;
}
 
 
 
#endif /* ZG */

#endif /* GCP_CH && GCP_VER_1_5 */ 



/*
*
*       Fun:   mgFillMgcoErrMsg
*
*       Desc:  
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC Void mgFillMgcoErrMsg
(
MgMgcoMsg          **errMsg,              /* Error Message */
U8                 reason,                /* Reason for error */
Buffer             *mBuf,                 /* mBuf to be freed */
MgRxTransIdEnt     *rxCb,                 /* rxCb to be freed */
MgTxTransIdEnt     *txCb,                 /* txCb to be freed */
MgTransId          transId                /* Transaction Id */
)
#else
PUBLIC Void mgFillMgcoErrMsg(errMsg, reason, mBuf, rxCb, txCb, transId)
MgMgcoMsg          **errMsg;              /* Error Message */
U8                 reason;                /* Reason for error */
Buffer             *mBuf;                 /* mBuf to be freed */
MgRxTransIdEnt     *rxCb;                 /* rxCb to be freed */
MgTxTransIdEnt     *txCb;                 /* txCb to be freed */
MgTransId          transId;               /* Transaction Id */
#endif
{
#ifndef GCP_VER_1_3
   S16       ret = ROK;
#endif
   U16       idx = 0;

   if ((*errMsg) == NULLP)
   {
      if(ROK != mgAllocEventMem((Ptr *)errMsg, sizeof(MgMgcoMsg)))
      {
        (*errMsg) = NULLP;
        RETVOID;
      }
      (*errMsg)->body.u.tl.num.pres = PRSNT_NODEF;
   }
#ifdef GCP_VER_1_3
   idx = (*errMsg)->body.u.tl.num.val;
   if(ROK != mgAllocEventMem((Ptr *)&((*errMsg)->body.u.tl.txns[idx]), 
                         sizeof(MgMgcoTxn)))
   {
      if ((*errMsg)->body.u.tl.num.val == 0)
      {
         (*errMsg) = NULLP;
         MG_FREE_MGCO_EVNT_MEM((*errMsg), TRUE);
      }
      RETVOID;
   }
#else
   MGGETMEM((Ptr *)&((*errMsg)->body.u.tl.txns), sizeof(Ptr), 
                        (Ptr)*errMsg, ret);
   if (ret != ROK)
   {
      if ((*errMsg)->body.u.tl.num.val == 0)
      {
         (*errMsg) = NULLP;
         MG_FREE_MGCO_EVNT_MEM((*errMsg), TRUE);
      }
      RETVOID;
   }
   MGGETMEM((Ptr *)&((*errMsg)->body.u.tl.txns[(*errMsg)->body.u.tl.num.val]),
                         sizeof(MgMgcoTxn),(Ptr)*errMsg, ret);
   if (ret != ROK)
   {
      if ((*errMsg)->body.u.tl.num.val == 0)
      {
         (*errMsg) = NULLP;
         MG_FREE_MGCO_EVNT_MEM((*errMsg), TRUE);
      }
      RETVOID;
   }
#endif /* GCP_VER_1_3 */
   idx = (*errMsg)->body.u.tl.num.val;
   (((*errMsg)->body.u.tl.txns)[idx])->type.pres = PRSNT_NODEF;
   (((*errMsg)->body.u.tl.txns)[idx])->type.val = MGT_TXNLOCAL_ERR;
   (((*errMsg)->body.u.tl.txns)[idx])->mgLclErr.errType.pres = PRSNT_NODEF;
   (((*errMsg)->body.u.tl.txns)[idx])->mgLclErr.errType.val = reason;  
   if (transId == MG_INVALID_TRANSID)
   {
      (((*errMsg)->body.u.tl.txns)[idx])->mgLclErr.trId.pres = PRSNT_NODEF;
   }
   else
   {
      (((*errMsg)->body.u.tl.txns)[idx])->mgLclErr.trId.pres = PRSNT_NODEF;
      (((*errMsg)->body.u.tl.txns)[idx])->mgLclErr.trId.val = transId;
   }
   (*errMsg)->body.u.tl.num.val++;
   (*errMsg)->body.type.pres = PRSNT_NODEF;
   (*errMsg)->body.type.val = MGT_TXN;

   if (txCb != NULLP)
      mgDeAllocTxTransIdEnt (txCb->peer, txCb, FALSE);

/*
 * Change below;
 *             added an additional check :- the 30 sec timer has been
 *             disabled before deallocating the rxCb. If the timer has been
 *             enabled, the deallocation would be done after it expires.
 *             If an outgoing response has been rejected by the stack and
 *             if the 30 sec timer has been enabled, the service user can
 *             try to resend the response if that timer has not expired.
 */


   /*
    *
    *   Since mBuf is being freed at the end of this function,
    *   assign rxCb->mBuf as NULLP so as to ensure that the
    *   rxCb->mBuf does not have any hanging buffer values
    */
   if ((rxCb != NULLP) &&
       (mBuf == rxCb->mBuf))
      rxCb->mBuf = NULLP;

   if ((rxCb != NULLP) &&
       (rxCb->tmr[MG_30SEC_TMR - MG_INTXN_TMR_BASE].tmrEvnt == TMR_NONE))
      mgDeAllocRxTransIdEnt (rxCb->peer, rxCb, FALSE);

   /* moved the following statement to this place from above */
   if (mBuf != NULLP)
      mgPutMsg(mBuf);

   RETVOID;
} /* end of mgFillMgcoErrMsg() */

#endif /* GCP_MGCO */







/********************************************************************/
/*         MGCP Transaction Error Processing Functions              */
/********************************************************************/
#ifdef GCP_MGCP

/*
*
*       Fun:   mgIssueMgcpTxnErr
*
*       Desc:  Issue transaction err to the service user
*
*       Ret:   ROK              - successful
*              RFAILED          - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC U16 mgIssueMgcpTxnErr
(
MgSSAPCb      *sSAPCb,       /* SSAP control block */
U16           errType,       /* Type of Error to be reported */
MgPeerCb      *peer,         /* Peer Control Block */
MgTransId     transId        /* Transaction Id */
)
#else
PUBLIC  U16 mgIssueMgcpTxnErr(sSAPCb, errType, peer, transId)
MgSSAPCb      *sSAPCb;       /* SSAP control block */
U16           errType;       /* Type of Error to be reported */
MgPeerCb      *peer;         /* Peer Control Block */
MgTransId     transId;       /* Transaction Id */
#endif
{
   U16       ret;            /* Return Value */
   MgMgcpTxn *txn;           /* Mgcp Txn */
  
   ret = mgAllocEventMem((Ptr *)&txn, sizeof(MgMgcpTxn)); 
   
   if (ret != ROK)
     RETVALUE(ret);

   /* Fill local info Transaction Structure */
   txn->mgLclInfo.pres.pres  = NOTPRSNT;

   ret = mgAllocEventMem((Ptr *)&(txn->mgcpMsg[0]), sizeof(MgMgcpMsg));
   if(ret == ROK)
   {
      txn->numMsg = 1;
      txn->mgcpMsg[0]->mgLclErr.errType.pres = PRSNT_NODEF;
      txn->mgcpMsg[0]->mgLclErr.errType.val = (U8)errType;
      txn->mgcpMsg[0]->msgType.pres = PRSNT_NODEF;
      txn->mgcpMsg[0]->msgType.val = MGT_MSG_NONE;
      if (transId !=  MG_IGNORE_TRANSID)
      {
        txn->mgcpMsg[0]->mgLclErr.trId.pres = PRSNT_NODEF;
        txn->mgcpMsg[0]->mgLclErr.trId.val  = transId;
      }
      else
        txn->mgcpMsg[0]->mgLclErr.trId.pres = NOTPRSNT;
   }

   if (peer != NULLP)
   {
     MG_COPY_PEERINFO_INTO_MGCPTXN(txn->mgLclInfo, peer);
   }
   else
     /* Fill local info Transaction Structure */
     txn->mgLclInfo.pres.pres = NOTPRSNT;

   MgUiMgtMgcpTxnInd (&(sSAPCb->suPst), sSAPCb->suId, txn);

   RETVALUE(ROK);

} /* end of mgIssueMgcpTxnErr */






/*
*
*       Fun:   mgHandleMgcpTxnReqErr
*
*       Desc:  This function reports rejection of a transaction to Service
*              user
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC Void mgHandleMgcpTxnReqErr
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgcpTxn          *txn,               /* MGCP Transaction */
U8                 mgtError            /* Error to be reported */
)
#else
PUBLIC Void mgHandleMgcpTxnReqErr(ssap, txn, mgtError)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgcpTxn          *txn;               /* MGCP Transaction */
U8                 mgtError;           /* Error to be reported */
#endif
{
   U16             loopIdx;            /* Loop Index */
   MgMgcpMsg       *msg;               /* MGCP Message */
   MgMgcpCmd       *command;           /* Command */
   MgMgcpRsp       *response;          /* Response */

   TRC2(mgHandleMgcpTxnReqErr)

   if (mgtError != MG_IGNORE)
   {
      /* Fill in the error report */
      for (loopIdx = 0; loopIdx < txn->numMsg; loopIdx++)
      {
         msg = txn->mgcpMsg[loopIdx];

         if (msg == NULLP)
            continue;

         msg->mgLclErr.errType.pres = PRSNT_NODEF;
         msg->mgLclErr.errType.val  = mgtError;

         command = NULLP;

         switch (msg->msgType.val)
         {
            case MGT_MSG_NONSTD:
            {
               command = &(msg->t.nonStdCmd.cmd);
            }
               /* Fall Through */

            case MGT_MSG_EPCF:
            case MGT_MSG_CRCX:
            case MGT_MSG_MDCX:
            case MGT_MSG_DLCX:
            case MGT_MSG_RQNT:
            case MGT_MSG_AUEP:
            case MGT_MSG_AUCX:

#ifdef GCP_PKG_MGCP_BASE
            case MGT_MSG_MESG:
#endif /* GCP_PKG_MGCP_BASE */
            {
               /* Initialise command structure */
               if (command == NULLP)
                  command = &(msg->t.epcfCmd);

               /* copy transaction id information */
               cmMemcpy((U8 *)&(msg->mgLclErr.trId),
                        (CONSTANT U8 *)&(command->cmdLine.trId),
                        sizeof(TknU32));
            }
            break;

            case MGT_MSG_RSP:
            {
               /* Initialise response */
               response = &(msg->t.mgcpRsp);

               /* copy transaction id information */
               cmMemcpy((U8 *)&(msg->mgLclErr.trId),
                        (CONSTANT U8 *)&(response->trId), sizeof(TknU32));
            }
            break;

            default:
            {
               continue;
            }

         } /* end of switch */

      } /* end of for loop */

   } /* end of if (mgtError != MG_IGNORE) */
  
   /* Indicate Error to user */
   MgUiMgtMgcpTxnInd (&(ssap->suPst), ssap->suId, txn);

   RETVOID;

} /* end of mgHandleMgcpTxnReqErr() */

#endif /* MG_MGCP */


/*
*
*       Fun:   mgStartServers
*
*       Desc:  This function starts the UDP servers from the list specified in
*              MgTptSrvrInfo. 
*
*       Ret:   ROK     - SUCCESS
*              RFAILED - FAILED
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC S16 mgStartServers
(
MgTptSrvrInfo      *srvrInfo           /* Server Information */
)
#else
PUBLIC S16 mgStartServers (srvrInfo)
MgTptSrvrInfo      *srvrInfo;          /* Server Information */
#endif
{
   CmLListCp       *lCp;               /* Linked List Control Point */
   CmLList         *tmp;               /* Linked List Node */
   MgTptSrvr       *tptCb;             /* Transport Server */
   MgTptSrvSta     srvrSta;            /* Server Status Information */
                                                                          
   TRC2(mgStartServers)

   lCp = &(srvrInfo->srvrLstCp);
   tmp = lCp->first;

   while(tmp) 
   {                                                                      
      tptCb =  (MgTptSrvr *)tmp->node;
      tmp = tmp->next;
      if ((mgSrvOpenReq(tptCb, &(tptCb->tptParam),                        
                        &(tptCb->tptAddr))) != ROK)                      
      {                                                                   
         srvrSta.transportType  = tptCb->transportType;
         srvrSta.state          = tptCb->state;
#ifdef GCP_MGCO
         srvrSta.encodingScheme = tptCb->encodingScheme;
#endif /* GCP_MGCO */
         cmMemcpy((U8 *)&srvrSta.tptAddr, 
                  (U8 *)&tptCb->tptAddr, sizeof(CmTptAddr));

         mgDeAllocSrvrCb(tptCb);
                                                                         
         mgGenStaInd (STSERVER, LCM_CATEGORY_INTERNAL,LMG_EVENT_SRVR_OPEN_FAIL,
                      LMG_CAUSE_MGMT_INITIATED, LMG_ALARMINFO_SRVR,
                      (Ptr)&srvrSta, sizeof(MgTptSrvSta), LMG_ALARMINFO_INVSAPID);
         continue;
      }  
   } /* while tmp */                                                                      
#ifdef ZG
   /* send update mod to standby  for all servers */
   tmp = lCp->first;
   while(tmp) 
   {
      tptCb = (MgTptSrvr *)tmp->node;
      if (tptCb != NULLP)
      {
         zgRtUpd(ZG_CBTYPE_TPTSRVR,(Ptr)tptCb,CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD);
      }
      tmp = tmp->next;
   } /* while */
#endif /* ZG */

   RETVALUE(ROK);

} /* end of mgStartServers() */



#ifdef CM_SDP_OPAQUE

#ifdef GCP_MGCO

/*
 * Added 2 new functions -
 *             mgMgcoFreeMedDsTkBf
 *             mgMgcoFreeAllTkBfs
 * within the flag CM_SDP_OPAQUE.
 * The function mgMgcoFreeAllTkBfs is called from the macro -
 * MG_FREE_MGCO_EVNT_MEM.
 * This function ensures that the SDP TknBuf (if any) allocated by the
 * decoder is freed.
 */

#ifdef ANSI
PUBLIC  S16 mgMgcoFreeMedDsTkBf
(
MgMgcoMediaDesc  *meDs
)
#else
PUBLIC  S16 mgMgcoFreeMedDsTkBf(meDs)
MgMgcoMediaDesc  *meDs;
#endif
{
   if (meDs == NULLP)
        RETVALUE(RFAILED);

   if ((meDs->num.pres == PRSNT_NODEF) && (meDs->parms))
   {
        U16   i;

        for (i=0; i<meDs->num.val; i++)
        {
             if (meDs->parms[i]->type.val == MGT_MEDIAPAR_STRPAR)
             {
                     if (meDs->parms[i]->u.stream.sl.local.pres.pres
                                     == PRSNT_NODEF)
                     {
                             if (meDs->parms[i]->u.stream.sl.local.\
                                             sdpStr.pres
                                             == PRSNT_NODEF)
                             {
                                     if (meDs->parms[i]->u.stream.sl.\
                                         local.sdpStr.val)
                                        SPutMsg(meDs->parms[i]->u.\
                                                stream.sl.local.\
                                                sdpStr.val);
                             }
                     }
                     if (meDs->parms[i]->u.stream.sl.remote.pres.pres
                                     == PRSNT_NODEF)
                     {
                             if (meDs->parms[i]->u.stream.sl.remote.\
                                             sdpStr.pres
                                             == PRSNT_NODEF)
                             {
                                     if (meDs->parms[i]->u.stream.sl.\
                                         remote.sdpStr.val)
                                        SPutMsg(meDs->parms[i]->u.\
                                                stream.sl.remote.\
                                                sdpStr.val);
                             }
                     }

             }
             else if (meDs->parms[i]->type.val == MGT_MEDIAPAR_LOCAL)
             {
                     if (meDs->parms[i]->u.local.pres.pres == PRSNT_NODEF)
                     {
                             if (meDs->parms[i]->u.local.sdpStr.pres
                                             == PRSNT_NODEF)
                             {
                                     if (meDs->parms[i]->u.local.sdpStr.\
                                         val)
                                        SPutMsg(meDs->parms[i]->u.local.\
                                                sdpStr.val);
                             }
                     }
             }
             else if (meDs->parms[i]->type.val == MGT_MEDIAPAR_REMOTE)
             {
                     if (meDs->parms[i]->u.remote.pres.pres == PRSNT_NODEF)
                     {
                             if (meDs->parms[i]->u.remote.sdpStr.pres
                                             == PRSNT_NODEF)
                             {
                                     if (meDs->parms[i]->u.remote.sdpStr.\
                                                     val)
                                        SPutMsg(meDs->parms[i]->u.remote.\
                                                sdpStr.val);
                             }
                     }

             }
        }
   }
   RETVALUE(ROK);
}


#ifdef ANSI
PUBLIC  S16 mgMgcoFreeAllTkBfs
(
MgMgcoTxn  *mgTrn
)
#else
PUBLIC  S16 mgMgcoFreeAllTkBfs(mgTrn)
MgMgcoTxn  *mgTrn;
#endif
{
  if (mgTrn == NULLP)
        RETVALUE(RFAILED);

  if (mgTrn->type.val == MGT_TXNREQ)
  {
       if (mgTrn->u.req.pres.pres == PRSNT_NODEF)
       {
            if ((mgTrn->u.req.al.num.pres == PRSNT_NODEF)
                            &&
                (mgTrn->u.req.al.actns))
            {
                 U16 j;

                 for (j=0; j<mgTrn->u.req.al.num.val; j++)
                 {
                         if ((mgTrn->u.req.al.actns[j]->cl.num.pres == PRSNT_NODEF)
                                         &&
                             (mgTrn->u.req.al.actns[j]->cl.cmds))
                         {
                              U16 k;

                              for (k=0; k<mgTrn->u.req.al.actns[j]->cl.num.val;k++)
                              {
                                   if(mgTrn->u.req.al.actns[j]->cl.cmds[k]->pres.\
                                                   pres == PRSNT_NODEF)
                                   {
                                        MgMgcoAmmReq  *amr = NULLP;

                                        if (mgTrn->u.req.al.actns[j]->cl.cmds[k]->\
                                                        cmd.type.val
                                                        == MGT_ADD)
                                        {
                                             amr = &(mgTrn->u.req.al.actns[j]->cl.\
                                                     cmds[k]->cmd.u.add);

                                        }
                                        else if (mgTrn->u.req.al.actns[j]->cl.cmds\
                                                        [k]->cmd.type.val
                                                        == MGT_MOVE)
                                        {
                                             amr = &(mgTrn->u.req.al.actns[j]->cl.\
                                                     cmds[k]->cmd.u.move);
                                        }
                                        else if (mgTrn->u.req.al.actns[j]->cl.cmds\
                                                        [k]->cmd.type.val
                                                        == MGT_MODIFY)
                                        {
                                             amr = &(mgTrn->u.req.al.actns[j]->cl.\
                                                     cmds[k]->cmd.u.mod);
                                        }
                                        if (amr && (amr->pres.pres == PRSNT_NODEF))
                                        {
                                             if ((amr->dl.num.pres ==
                                                         PRSNT_NODEF)
                                                             &&
                                                 (amr->dl.descs))
                                             {
                                                  U16  des;
                                                  for (des=0; des<amr->dl.num.\
                                                                  val; des++)
                                                  {
                                                       if (amr->dl.descs[des]->\
                                                                 type.val ==
                                                                 MGT_MEDIADESC)
                                                       {
                                                            mgMgcoFreeMedDsTkBf
                                                              (&(amr->dl.descs\
                                                               [des]->u.media));
                                                       }
                                                  }
                                             }
                                        }
                                   }
                              }
                         }
                 }
            }
       }
  }
  else if (mgTrn->type.val == MGT_TXNREPLY)
  {
       if (mgTrn->u.reply.pres.pres == PRSNT_NODEF)
       {
            if (mgTrn->u.reply.type.pres == MGT_ACTIONREPLY)
            {
                 if ((mgTrn->u.reply.u.arl.num.pres == PRSNT_NODEF)
                                 &&
                     (mgTrn->u.reply.u.arl.repl))
                 {
                      U16  j;
                      for (j=0; j<mgTrn->u.reply.u.arl.num.val; j++)
                      {
                           if ((mgTrn->u.reply.u.arl.repl[j]->pres.pres
                                           == PRSNT_NODEF)
                                           &&
                               (mgTrn->u.reply.u.arl.repl[j]->type.val
                                            == MGT_CXTCMDREPLY))
                           {
                                if ((mgTrn->u.reply.u.arl.repl[j]->u.reply.pres\
                                               .pres == PRSNT_NODEF)
                                                &&
                                    (mgTrn->u.reply.u.arl.repl[j]->u.reply.cl.\
                                              num.pres ==PRSNT_NODEF)
                                                &&
                                    (mgTrn->u.reply.u.arl.repl[j]->u.reply.cl.\
                                             repl))
                                {
                                     U16 k;
                                     for (k=0; k<mgTrn->u.reply.u.arl.repl[j]\
                                                     ->u.reply.cl.num.val; k++)
                                     {
                                       if (mgTrn->u.reply.u.arl.repl[j]->u.\
                                                 reply.cl.repl[k]->pres.pres
                                                 == PRSNT_NODEF)
                                       {
                                         MgMgcoTermAuditRes *term = NULLP;
                                         if (mgTrn->u.reply.u.arl.repl[j]->u.\
                                              reply.cl.repl[k]->type.val
                                              == MGT_ADD)
                                         {
                                                 if ( (mgTrn->u.reply.u.arl.\
                                                        repl[j]->u.reply.cl.\
                                                        repl[k]->u.add.pres.\
                                                        pres) == PRSNT_NODEF )
                                                 {
                                                   term = &((mgTrn->u.reply\
                                                            .u.arl.repl[j]->u.\
                                                            reply.cl.repl[k]->\
                                                            u.add.audit));
                                                 }
                                         }
                                         else if (mgTrn->u.reply.u.arl.repl[j]\
                                                   ->u.reply.cl.repl[k]->type.\
                                                   val == MGT_MOVE)
                                         {
                                                 if ( (mgTrn->u.reply.u.arl.\
                                                        repl[j]->u.reply.cl.\
                                                        repl[k]->u.move.pres.\
                                                        pres) == PRSNT_NODEF)
                                                 {
                                                   term = &((mgTrn->u.reply\
                                                            .u.arl.repl[j]->u.\
                                                            reply.cl.repl[k]->\
                                                            u.move.audit));
                                                 }
                                         }
                                         else if (mgTrn->u.reply.u.arl.repl[j]\
                                                   ->u.reply.cl.repl[k]->type.\
                                                   val == MGT_MODIFY)
                                         {
                                                 if ( (mgTrn->u.reply.u.arl.\
                                                        repl[j]->u.reply.cl.\
                                                        repl[k]->u.mod.pres.\
                                                        pres) == PRSNT_NODEF)
                                                 {
                                                   term = &((mgTrn->u.reply\
                                                            .u.arl.repl[j]->u.\
                                                            reply.cl.repl[k]->\
                                                            u.mod.audit));
                                                 }
                                         }
                                         else if (mgTrn->u.reply.u.arl.repl[j]\
                                                   ->u.reply.cl.repl[k]->type.\
                                                   val == MGT_SUB)
                                         {
                                                 if ( (mgTrn->u.reply.u.arl.\
                                                        repl[j]->u.reply.cl.\
                                                        repl[k]->u.sub.pres.\
                                                        pres) == PRSNT_NODEF)
                                                 {
                                                   term = &((mgTrn->u.reply\
                                                            .u.arl.repl[j]->u.\
                                                            reply.cl.repl[k]->\
                                                            u.sub.audit));
                                                 }
                                         }
                                         else if (mgTrn->u.reply.u.arl.repl[j]\
                                                   ->u.reply.cl.repl[k]->type.\
                                                   val == MGT_AUDITCAP)
                                         {
                                                 if ( (mgTrn->u.reply.u.arl.\
                                                        repl[j]->u.reply.cl.\
                                                        repl[k]->u.acap.type.\
                                                        val) == MGT_TERMAUDIT)
                                                 {
                                                    if ( (mgTrn->u.reply.u.arl.\
                                                        repl[j]->u.reply.cl.\
                                                        repl[k]->u.acap.u.other\
                                                        .pres.pres) ==
                                                              PRSNT_NODEF)
                                                   {
                                                        term =&(mgTrn->u.reply.\
                                                               u.arl.repl[j]->\
                                                               u.reply.cl.repl\
                                                               [k]->u.acap.u.\
                                                               other.audit);
                                                   }
                                                 }
                                         }
                                         else if (mgTrn->u.reply.u.arl.repl[j]\
                                                   ->u.reply.cl.repl[k]->type.\
                                                   val == MGT_AUDITVAL)
                                         {
                                                 if ( (mgTrn->u.reply.u.arl.\
                                                        repl[j]->u.reply.cl.\
                                                        repl[k]->u.aval.type.\
                                                        val) == MGT_TERMAUDIT)                                                            {
                                                    if ( (mgTrn->u.reply.u.arl.\
                                                        repl[j]->u.reply.cl.\
                                                        repl[k]->u.aval.u.other\
                                                        .pres.pres) ==
                                                              PRSNT_NODEF)
                                                   {
                                                        term =&(mgTrn->u.reply.\
                                                               u.arl.repl[j]->\
                                                               u.reply.cl.repl\
                                                               [k]->u.aval.u.\
                                                               other.audit);
                                                   }
                                                 }

                                         }

                                         if (term && (term->num.pres == PRSNT_NODEF)
                                                         &&
                                             (term->parms))
                                         {
                                           U16 l;
                                           for (l=0; l<term->num.val; l++)
                                           {
                                             if (term->parms[l]->type.val ==
                                                             MGT_MEDIADESC)
                                             {
                                                   mgMgcoFreeMedDsTkBf(
                                                             &(term->parms[l]->\
                                                               u.media));
                                             }
                                           }
                                         }

                                       }
                                     }
                                }
                           }
                      }
                 }
            }
       }
  }
  RETVALUE(ROK);
}

#endif  /* GCP_MGCO */


#ifdef GCP_MGCP

/*
 * Added new functions -
 *                  mgMgcpFreeAllTxnTkBfs
 *                  mgMgcpFreeAllTkBfs
 * within the flag CM_SDP_OPAQUE.
 * This function mgMgcpFreeAllTxnTkBfs is called from the macro -
 * MG_FREE_MGCP_EVNT_MEM.
 * This function calls the function mgMgcpFreeAllTkBfs in a loop for
 * all the MgMgcpMsg s in the transaction.
 * This function ensures that the SDP TknBuf (if any) allocated by the
 * decoder is freed.
 */

#ifdef ANSI
PUBLIC  S16 mgMgcpFreeAllTxnTkBfs
(
MgMgcpTxn  *mgTrn
)
#else
PUBLIC  S16 mgMgcpFreeAllTxnTkBfs(mgTrn)
MgMgcpTxn  *mgTrn;
#endif
{
     U16  num;

     if (mgTrn == NULLP)
           RETVALUE(RFAILED);

     for (num=0; num<mgTrn->numMsg; num++)
     {
          mgMgcpFreeAllTkBfs(mgTrn->mgcpMsg[num]);
     /* We don't care what the return val of the above func is */
     }

     RETVALUE(ROK);
}


#ifdef ANSI
PUBLIC  S16 mgMgcpFreeAllTkBfs
(
MgMgcpMsg  *mgMsg
)
#else
PUBLIC  S16 mgMgcpFreeAllTkBfs(mgMsg)
MgMgcpMsg  *mgMsg;
#endif
{

    if (mgMsg)
    {
       TknBuf  *sdpStr;

       switch (mgMsg->msgType.val)
       {
            case MGT_MSG_EPCF:
             sdpStr = &(mgMsg->t.epcfCmd.\
                             sdpStr);
                    break;
            case MGT_MSG_CRCX:
             sdpStr = &(mgMsg->t.crcxCmd.\
                             sdpStr);
                    break;
            case MGT_MSG_MDCX:
             sdpStr = &(mgMsg->t.mdcxCmd.\
                             sdpStr);
                    break;
            case MGT_MSG_DLCX:
             sdpStr = &(mgMsg->t.dlcxCmd.\
                             sdpStr);
                    break;
            case MGT_MSG_RQNT:
             sdpStr = &(mgMsg->t.rqntCmd.\
                             sdpStr);
                    break;
            case MGT_MSG_NTFY:
             sdpStr = &(mgMsg->t.ntfyCmd.\
                             sdpStr);
                    break;
            case MGT_MSG_AUEP:
             sdpStr = &(mgMsg->t.auepCmd.\
                             sdpStr);
                    break;
            case MGT_MSG_AUCX:
             sdpStr = &(mgMsg->t.aucxCmd.\
                             sdpStr);
                    break;
            case MGT_MSG_RSIP:
             sdpStr = &(mgMsg->t.rsipCmd.\
                             sdpStr);
                    break;
            case MGT_MSG_NONSTD:
             sdpStr = &(mgMsg->t.nonStdCmd.\
                             cmd.sdpStr);
                    break;
            case MGT_MSG_RSP:
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
             if (((mgMsg->t.mgcpRsp.sdpInfo.\
                       numComp.pres) == PRSNT_NODEF)
                             &&
                  (mgMsg->t.mgcpRsp.sdpInfo.\
                       set))
             {
                U16  nbr;
                for(nbr=0; nbr < (mgMsg->t.\
                                 mgcpRsp.sdpInfo.numComp.val);
                           nbr++)
                {
                   if (mgMsg->t.mgcpRsp.sdpInfo.set[nbr])
                   {
                       sdpStr = &(mgMsg->t.mgcpRsp.\
                                     sdpInfo.set[nbr]->sdpStr);
                       if ((sdpStr->pres == PRSNT_NODEF)
                                    &&
                           (sdpStr->val))
                       {
                           SPutMsg(sdpStr->val);
                           sdpStr->val = NULLP;
                       }
                   }
                }
             }
                /*
                 * Return.
                 * otherwise the freeing of already freed
                 * memory wud be done after the end of the
                 * switch case below.
                 */
                RETVALUE(ROK);
#else
             sdpStr = &(mgMsg->t.mgcpRsp.\
                             sdpStr);
#endif
                    break;
            default:
                      RETVALUE(ROK);
                    break;
       }

       if ((sdpStr->pres == PRSNT_NODEF)
                      &&
            (sdpStr->val))
       {
           SPutMsg(sdpStr->val);
           sdpStr->val = NULLP;
       }
    }
    else
    {
        RETVALUE(RFAILED);
    }

     RETVALUE(ROK);
}



#endif  /* GCP_MGCP */
 
#endif /* CM_SDP_OPAQUE */




#ifdef CM_ABNF_MT_LIB
/*
*
*       Fun:   mgFreeEncDecRsrc
*
*       Desc:  This function free encode/decode resources..typically event
*       structure with some other inforamation are stored , when Enc/Dec Req is
*       sent to one of ED Instances.
*
*       Ret:   Void
*
*       Notes:
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC Void mgFreeEncDecRsrc
(
Void
)
#else
PUBLIC Void mgFreeEncDecRsrc ()
#endif
{
   MgStoreList      *node;          /* queue node */
   MgStoreDecReq    *decReq;        /* Stored decode req */
   MgStoreEncReq    *encReq;        /* stored encode req */
#ifdef GCP_MGCO
   MgMgcoMsg        *mgcoMsg;       /* megaco message */
#endif /* GCP_MGCO */
#ifdef GCP_MGCP
   MgMgcpTxn        *txn;           /* mgcp txn */
#endif /* GCP_MGCP */
   U32              nodeIndx;       /* node Index */
   U16              noOfMsg;        /* no of message in txn*/
   U16              cnt;            /* counter */

   TRC2(mgFreeEncDecRsrc)
  
   /* Free all the resource attached to decode List */ 
   node = mgCb.decList.next;
   while(node != NULLP)
   {
      MgStoreList     *prv;
      decReq = ((MgStoreDecReq *)node->info);
      nodeIndx = node->nodeIndx;
      /* Stop timer, if started */ 
      if(decReq->mgEDTimer.tmrEvnt == MG_ED_DECTMR)
      {
         mgStopTmr(MG_ED_DECTMR, (PTR)(nodeIndx), &decReq->mgEDTimer); 
      }
      /* free mBuf..and decReq */
      mgPutMsg(decReq->mBuf);
      mgDeAlloc((Data *)decReq, sizeof(MgStoreDecReq));  
      /* Now free associated event structure */
      if(decReq->protoVar == CM_ABNF_PROT_MEGACO_H248)/*MAH_TODO */
      {
#ifdef GCP_MGCO
         mgcoMsg = (MgMgcoMsg *)(decReq->event);
         MG_FREE_MGCO_EVNT_MEM(mgcoMsg, TRUE);
#endif /* GCP_MGCO */
      }
      else
      {
#ifdef GCP_MGCP
         txn = (MgMgcpTxn *)(decReq->event);
         MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
#endif /* GCP_MGCP */
      }
      prv = node;
      node = node->next; 
      /* free node */
      mgDeAlloc((Data *)prv, sizeof(MgStoreList));
   }
   mgCb.decList.next = NULLP;

   /* Now free all encode req */
   node = mgCb.encList.next;
   while(node != NULLP)
   {
      MgStoreList     *prv;
      encReq = ((MgStoreEncReq *)node->info);
      nodeIndx = node->nodeIndx;
      /* Stop timer, if started */ 
      if(encReq->mgEDTimer.tmrEvnt == MG_ED_ENCTMR)
      {
         mgStopTmr(MG_ED_ENCTMR, (PTR)(nodeIndx), &encReq->mgEDTimer); 
      }
      /* Now free associated event structure */
      if(encReq->protoVar == CM_ABNF_PROT_MEGACO_H248)/*MAH_TODO */
      {
#ifdef GCP_MGCO
         mgcoMsg = (MgMgcoMsg *)(encReq->event);
         /* get no of message */
         /* add one for megaco Message header part */
         noOfMsg = mgcoMsg->body.u.tl.num.val + 1;
         MG_FREE_MGCO_EVNT_MEM(mgcoMsg, TRUE);
#endif /* GCP_MGCO */
      }
      else
      {
#ifdef GCP_MGCP
         txn = (MgMgcpTxn *)(encReq->event);
         /* get no of message */
         noOfMsg = txn->numMsg;
         MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
#endif /* GCP_MGCP */
      }
      /* Now free each mBuf ..corresponding to each message in txn */
      for(cnt = 0; cnt < noOfMsg; cnt++)
      {
         mgPutMsg((Buffer *)(encReq->encBuf[cnt]->buf));
         mgDeAlloc((Data *)encReq->encBuf[cnt], sizeof(MgEncBuffer));
      }
      /* now free encBuf itself */
      mgDeAlloc((Data *)(encReq->encBuf), noOfMsg * (sizeof(MgEncBuffer *)));
      /* now free encReq */
      mgDeAlloc((Data *)encReq, sizeof(MgStoreEncReq));
      prv = node;
      node = node->next; 
      /* free node */
      mgDeAlloc((Data *)prv, sizeof(MgStoreList));
   }
   mgCb.encList.next = NULLP;
   
} /* mgFreeEncDecRsrc () */ 
#endif /* CM_ABNF_MT_LIB */


/******************* IPV4/IPV6 support functions ************************/

/*
*
*       Fun:   mgInitIpAddrLst
*
*       Desc:  initialize the 2 peer address list, IPV4 and IPV6
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC S16 mgInitIpAddrLst
(
Bool               dupFlag             /* Isduplicate allowed in Hsh list/not*/
)
#else
PUBLIC S16 mgInitIpAddrLst (dupFlag)
Bool               dupFlag;            /* Isduplicate allowed in Hsh list/not*/
#endif
{
   S16     retVal;         /* return value */

   TRC2(mgInitIpAddrLst)

   retVal = cmHashListInit(&(mgCb.ipv4AddrLst), mgCb.genCfg.numBinsNameHl,
                           0,  dupFlag, MG_IPV4ADDR_HASH_FUNC, mgCb.init.region,
                           mgCb.init.pool);
   if (retVal != ROK)
   {
      RETVALUE(retVal);
   }

#ifdef IPV6_SUPPORTED
   retVal = cmHashListInit(&(mgCb.ipv6AddrLst), mgCb.genCfg.numBinsNameHl,
                           0,  dupFlag, MG_IPV6ADDR_HASH_FUNC, mgCb.init.region,
                           mgCb.init.pool);

   if (retVal != ROK)
   {
      cmHashListDeinit(&(mgCb.ipv4AddrLst));
   }
#endif /* IPV6_SUPPORTED */

   RETVALUE(retVal);
} /* mgInitIpAddrLst */


/*
*
*       Fun:   mgDeinitIpAddrLst
*
*       Desc:  de-initialize the 2 peer address list, IPV$ and IPV6
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC Void mgDeinitIpAddrLst
(
Void
)
#else
PUBLIC Void mgDeinitIpAddrLst ( )
#endif
{
   TRC2(mgDeinitIpAddrLst)

   cmHashListDeinit(&(mgCb.ipv4AddrLst));
#ifdef IPV6_SUPPORTED
   cmHashListDeinit(&(mgCb.ipv6AddrLst));
#endif /* IPV6_SUPPORTED */

   RETVOID;
} /* mgDeinitIpAddrLst */


/*
*
*       Fun:   mgFindIpAddrLst
*
*       Desc:  search through the peer address list (IPV4 and IPV6)
*              for a particular address
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC S16 mgFindIpAddrLst
(
U8                 type,               /* address type IPV4 or IPV6 */
CmIpv4NetAddr      *ipv4Addr,          /* Ipv4 address */
CmIpv6NetAddr      *ipv6Addr,          /* Ipv6 address */
U16                seqNmb,             /* sequence number for dup keys */
MgIpAddrEnt        **addrEnt           /* entry to be returned */
)
#else
PUBLIC S16 mgFindIpAddrLst (type, ipv4Addr, ipv6Addr, seqNmb, addrEnt)
U8                 type;               /* address type IPV4 or IPV6 */
CmIpv4NetAddr      *ipv4Addr;          /* Ipv4 address */
CmIpv6NetAddr      *ipv6Addr;          /* Ipv6 address */
U16                seqNmb;             /* sequence number for dup keys */
MgIpAddrEnt        **addrEnt;          /* entry to be returned */
#endif
{
   S16     retVal;         /* return value */

   TRC2(mgFindIpAddrLst)

   retVal = RFAILED;
   if (type == CM_NETADDR_IPV4)
   {
      retVal= cmHashListFind (&(mgCb.ipv4AddrLst), (U8 *) (ipv4Addr), 
                              MG_IPV4_ADDRLEN, seqNmb, 
                              (PTR *) addrEnt);
   }
#ifdef IPV6_SUPPORTED
   else
   {
      retVal= cmHashListFind (&(mgCb.ipv6AddrLst), (U8 *) (ipv6Addr),
                              MG_IPV6_ADDRLEN, seqNmb, 
                              (PTR *) addrEnt);
   }
#endif /* IPV6_SUPPORTED */
   RETVALUE(retVal);
} /* mgFindIpAddrLst */


/*
*
*       Fun:   mgInsertIpAddrLst
*
*       Desc:  insert a peer address in the peer address list (IPV4 and 
*              IPV6)
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC S16 mgInsertIpAddrLst
(
MgIpAddrEnt        *addrEnt            /* entry to be inserted */
)
#else
PUBLIC S16 mgInsertIpAddrLst (addrEnt)
MgIpAddrEnt        *addrEnt;           /* entry to be inserted */
#endif
{
   S16     retVal;         /* return value */

   TRC2(mgInsertIpAddrLst)

   retVal = RFAILED;
   if (addrEnt->ipAddr.type == CM_NETADDR_IPV4)
   {
      retVal= cmHashListInsert(&(mgCb.ipv4AddrLst), (PTR) addrEnt,
                               (U8 *)&(addrEnt->ipAddr.u.ipv4NetAddr),
                               MG_IPV4_ADDRLEN);
   }
#ifdef IPV6_SUPPORTED
   else
   {
      retVal= cmHashListInsert(&(mgCb.ipv6AddrLst), (PTR) addrEnt,
                               (U8 *)&(addrEnt->ipAddr.u.ipv6NetAddr),
                               MG_IPV6_ADDRLEN);
   }
#endif /* IPV6_SUPPORTED */

   RETVALUE(retVal);
} /* mgInsertpAddrLst */


/*
*
*       Fun:   mgDeleteIpAddrLst
*
*       Desc:  delete an entry from the IPV4/IPV6 peer address list
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC S16 mgDeleteIpAddrLst
(
MgIpAddrEnt        *addrEnt            /* entry to be inserted */
)
#else
PUBLIC S16 mgDeleteIpAddrLst (addrEnt)
MgIpAddrEnt        *addrEnt;           /* entry to be inserted */
#endif
{
   S16     retVal;         /* return value */

   TRC2(mgDeleteIpAddrLst)

   retVal = RFAILED;
   if (addrEnt->ipAddr.type == CM_NETADDR_IPV4)
   {
      retVal= cmHashListDelete(&(mgCb.ipv4AddrLst), (PTR) addrEnt);
   }
#ifdef IPV6_SUPPORTED
   else
   {
      retVal= cmHashListDelete(&(mgCb.ipv6AddrLst), (PTR) addrEnt);
   }
#endif /* IPV6_SUPPORTED */

   RETVALUE(retVal);
} /* mgDeleteIpAddrLst */




#ifdef    GCP_PROV_SCTP

/*
*
*       Fun:   mgExtractCtxIdFrmMsg
*
*       Desc:  Find out the value of integer type of context ID
*              from the first transaction in the MEGACO msg.
*              It fills the 2nd arg with the integer type value
*              of the context ID if present; otherwise it fills
*              the 2nd arg's pres field as not present.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC Void mgExtractCtxIdFrmMsg
(
MgMgcoMsg          *msg,               /* pointer to MEGACO msg */
TknU32             *ctxId              /* pointer to Context-Id */
)
#else
PUBLIC Void mgExtractCtxIdFrmMsg (msg, ctxId)
MgMgcoMsg          *msg;               /* pointer to MEGACO msg */
TknU32             *ctxId;             /* pointer to Context-Id */
#endif
{
   /* Initialize this field to indicate absence */
   ctxId->pres = NOTPRSNT;

   /*
    *   The following if check eliminates error descriptor
    *   in msg body and other such MEGACO msgs which do NOT
    *   have a transaction
    */

   if ((msg) && (PRSNT_NODEF == msg->body.type.pres) &&
       (MGT_TXN == msg->body.type.val)               &&
       (PRSNT_NODEF == msg->body.u.tl.num.pres)      &&
       (msg->body.u.tl.txns)                         &&
       (msg->body.u.tl.txns[0])                      &&
       (PRSNT_NODEF == msg->body.u.tl.txns[0]->type.pres))
   {
      MgMgcoTxn         *txn;
      MgMgcoContextId   *msgCtxId = NULLP;

      txn = msg->body.u.tl.txns[0];

      if (MGT_TXNREQ == txn->type.val)
      {
         /*
          *   Find the context ID in the transactionRequest
          *   if any
          */
         if ((PRSNT_NODEF == txn->u.req.pres.pres)   &&
             (PRSNT_NODEF == txn->u.req.al.num.pres) &&
             (txn->u.req.al.actns)                   &&
             (txn->u.req.al.actns[0]))
         {
            msgCtxId = &(txn->u.req.al.actns[0]->cxtId);
         }

      }
      else if (MGT_TXNREPLY == txn->type.val)
      {
         /*
          *   Find the context ID in the transactionReply
          *   if any
          */
         if ((PRSNT_NODEF == txn->u.reply.pres.pres)      &&
             (PRSNT_NODEF == txn->u.reply.type.pres)      &&
             (MGT_ACTIONREPLY == txn->u.reply.type.val)   &&
             (PRSNT_NODEF == txn->u.reply.u.arl.num.pres) &&
             (txn->u.reply.u.arl.repl)                    &&
             (txn->u.reply.u.arl.repl[0])                 &&
             (PRSNT_NODEF == txn->u.reply.u.arl.repl[0]->pres.pres))
         {
            msgCtxId = &(txn->u.reply.u.arl.repl[0]->cxtId);
         }

      }
      /*
       *   Context ID is absent in transactionPending and
       *   transactionResponseAck
       */


      /*
       *   If Context ID is present in transactionRequest or
       *   transactionReply, check if its in integer format
       */
      if ((msgCtxId) && (PRSNT_NODEF == msgCtxId->type.pres) &&
          (MGT_CXTID_OTHER == msgCtxId->type.val) &&
          (PRSNT_NODEF == msgCtxId->val.pres))
      {
         ctxId->pres = PRSNT_NODEF;
         ctxId->val  = msgCtxId->val.val;
      }

   }

}   /* mgExtractCtxIdFrmMsg */

#endif    /* GCP_PROV_SCTP */

/* Added Utility copy function from AGSF product */
/* mg003.105: Added Utility copy function from AGSF product */
#if (defined(GCP_MGCO) && defined(GCP_CH))

/* mg008.105: moving unused function within AG compiler flag */
#ifdef AG


/*
*
*    Fun:    mgUtlCpyMgMgcoIndAudStreamParm
*
*    Desc:    copy the structure MgMgcoIndAudStreamParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoIndAudStreamParm
(
MgMgcoIndAudStreamParm *dst,
MgMgcoIndAudStreamParm *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoIndAudStreamParm(dst, src, mem)
MgMgcoIndAudStreamParm *dst;
MgMgcoIndAudStreamParm *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoIndAudStreamParm)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoIndAudStreamParm));

   if (mgUtlCpyMgMgcoPkgdName(&dst->name, &src->name, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoIndAudStreamParm*/

/*
*
*    Fun:    mgUtlCpyMgMgcoIndAudStreamDesc
*
*    Desc:    copy the structure MgMgcoIndAudStreamDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoIndAudStreamDesc
(
MgMgcoIndAudStreamDesc *dst,
MgMgcoIndAudStreamDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoIndAudStreamDesc(dst, src, mem)
MgMgcoIndAudStreamDesc *dst;
MgMgcoIndAudStreamDesc *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoIndAudStreamDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoIndAudStreamDesc));

   if (mgUtlCpyMgMgcoIndAudStreamParm(&dst->streamParm, &src->streamParm, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoIndAudStreamDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoIndAudTermStateDesc
*
*    Desc:    copy the structure MgMgcoIndAudTermStateDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoIndAudTermStateDesc
(
MgMgcoIndAudTermStateDesc *dst,
MgMgcoIndAudTermStateDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoIndAudTermStateDesc(dst, src, mem)
MgMgcoIndAudTermStateDesc *dst;
MgMgcoIndAudTermStateDesc *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoIndAudTermStateDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoIndAudTermStateDesc));

   if (mgUtlCpyMgMgcoPkgdName(&dst->name, &src->name, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoIndAudTermStateDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoIndAudMediaParm
*
*    Desc:    copy the structure MgMgcoIndAudMediaParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoIndAudMediaParm
(
MgMgcoIndAudMediaParm *dst,
MgMgcoIndAudMediaParm *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoIndAudMediaParm(dst, src, mem)
MgMgcoIndAudMediaParm *dst;
MgMgcoIndAudMediaParm *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoIndAudMediaParm)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoIndAudMediaParm));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_INDAUD_STPAR :
            if (mgUtlCpyMgMgcoIndAudStreamParm(&dst->u.streamParm, &src->u.streamParm, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_STRDESC :
            if (mgUtlCpyMgMgcoIndAudStreamDesc(&dst->u.streamDesc, &src->u.streamDesc, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_TERSTDESC :
            if (mgUtlCpyMgMgcoIndAudTermStateDesc(&dst->u.termStateDesc, &src->u.termStateDesc, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoIndAudMediaParm*/

/*
*
*    Fun:    mgUtlCpyMgMgcoIndAudEvents
*
*    Desc:    copy the structure MgMgcoIndAudEvents
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoIndAudEvents
(
MgMgcoIndAudEvents *dst,
MgMgcoIndAudEvents *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoIndAudEvents(dst, src, mem)
MgMgcoIndAudEvents *dst;
MgMgcoIndAudEvents *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoIndAudEvents)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoIndAudEvents));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoPkgdName(&dst->name, &src->name, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoIndAudEvents*/

/*
*
*    Fun:    mgUtlCpyMgMgcoIndAudSigLst
*
*    Desc:    copy the structure MgMgcoIndAudSigLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoIndAudSigLst
(
MgMgcoIndAudSigLst *dst,
MgMgcoIndAudSigLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoIndAudSigLst(dst, src, mem)
MgMgcoIndAudSigLst *dst;
MgMgcoIndAudSigLst *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoIndAudSigLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoIndAudSigLst));

   if (mgUtlCpyMgMgcoSigName(&dst->sigName, &src->sigName, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoIndAudSigLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoIndAudSignals
*
*    Desc:    copy the structure MgMgcoIndAudSignals
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoIndAudSignals
(
MgMgcoIndAudSignals *dst,
MgMgcoIndAudSignals *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoIndAudSignals(dst, src, mem)
MgMgcoIndAudSignals *dst;
MgMgcoIndAudSignals *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoIndAudSignals)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoIndAudSignals));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_INDAUD_SIGLST :
            if (mgUtlCpyMgMgcoIndAudSigLst(&dst->u.sigList, &src->u.sigList, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_SIGNAME :
            if (mgUtlCpyMgMgcoSigName(&dst->u.sigName, &src->u.sigName, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoIndAudSignals*/

/*
*
*    Fun:    mgUtlCpyMgMgcoIndAudEventSpecParm
*
*    Desc:    copy the structure MgMgcoIndAudEventSpecParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoIndAudEventSpecParm
(
MgMgcoIndAudEventSpecParm *dst,
MgMgcoIndAudEventSpecParm *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoIndAudEventSpecParm(dst, src, mem)
MgMgcoIndAudEventSpecParm *dst;
MgMgcoIndAudEventSpecParm *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoIndAudEventSpecParm)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoIndAudEventSpecParm));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_INDAUD_EVPRM :
            if (mgUtlCpyMgMgcoName(&dst->u.evParmName, &src->u.evParmName, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_EVSTREAM :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoIndAudEventSpecParm*/

/*
*
*    Fun:    mgUtlCpyMgMgcoIndAudEventBuffer
*
*    Desc:    copy the structure MgMgcoIndAudEventBuffer
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoIndAudEventBuffer
(
MgMgcoIndAudEventBuffer *dst,
MgMgcoIndAudEventBuffer *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoIndAudEventBuffer(dst, src, mem)
MgMgcoIndAudEventBuffer *dst;
MgMgcoIndAudEventBuffer *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoIndAudEventBuffer)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoIndAudEventBuffer));

   if (mgUtlCpyMgMgcoPkgdName(&dst->name, &src->name, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyMgMgcoIndAudEventSpecParm(&dst->evSpecParm, &src->evSpecParm, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoPkgdName(&dst->name);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoIndAudEventBuffer*/

/*
*
*    Fun:    mgUtlCpyMgMgcoIndAudAuditRetParm
*
*    Desc:    copy the structure MgMgcoIndAudAuditRetParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoIndAudAuditRetParm
(
MgMgcoIndAudAuditRetParm *dst,
MgMgcoIndAudAuditRetParm *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoIndAudAuditRetParm(dst, src, mem)
MgMgcoIndAudAuditRetParm *dst;
MgMgcoIndAudAuditRetParm *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoIndAudAuditRetParm)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoIndAudAuditRetParm));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_INDAUD_AUDDIGITMAP :
            if (mgUtlCpyMgMgcoName(&dst->u.audDigMap, &src->u.audDigMap, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_AUDEVTBUF :
            if (mgUtlCpyMgMgcoIndAudEventBuffer(&dst->u.audEvtBuf, &src->u.audEvtBuf, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_AUDEVTS :
            if (mgUtlCpyMgMgcoIndAudEvents(&dst->u.audEvents, &src->u.audEvents, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_AUDMEDIA :
            if (mgUtlCpyMgMgcoIndAudMediaParm(&dst->u.audMedia, &src->u.audMedia, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_AUDPKG :
            if (mgUtlCpyMgMgcoPkgsItem(&dst->u.audPkgs, &src->u.audPkgs, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_AUDSIG :
            if (mgUtlCpyMgMgcoIndAudSignals(&dst->u.audSignals, &src->u.audSignals, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_AUDSTAT :
            if (mgUtlCpyMgMgcoSigName(&dst->u.audStats, &src->u.audStats, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoIndAudAuditRetParm*/

/*
*
*    Fun:    mgUtlCpyMgMgcoIndAudTermAudit
*
*    Desc:    copy the structure MgMgcoIndAudTermAudit
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoIndAudTermAudit
(
MgMgcoIndAudTermAudit *dst,
MgMgcoIndAudTermAudit *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoIndAudTermAudit(dst, src, mem)
MgMgcoIndAudTermAudit *dst;
MgMgcoIndAudTermAudit *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoIndAudTermAudit)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoIndAudTermAudit));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->parm), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->parm[i]), sizeof(MgMgcoIndAudAuditRetParm), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoIndAudAuditRetParm(dst->parm[i], src->parm[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->parm[i], sizeof(MgMgcoIndAudAuditRetParm));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoIndAudAuditRetParm(dst->parm[i]);
         MGFREE(dst->parm[i], sizeof(MgMgcoIndAudAuditRetParm));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->parm, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoIndAudTermAudit*/

/*
*
*    Fun:    mgUtlCpyMgMgcoAuditItem
*
*    Desc:    copy the structure MgMgcoAuditItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoAuditItem
(
MgMgcoAuditItem *dst,
MgMgcoAuditItem *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoAuditItem(dst, src, mem)
MgMgcoAuditItem *dst;
MgMgcoAuditItem *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoAuditItem)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoAuditItem));

   if (mgUtlCpyMgMgcoIndAudTermAudit(&dst->termAudit, &src->termAudit, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoAuditItem*/

#endif /* AG */

/*
*
*    Fun:    mgUtlCpyMgMgcoPathName
*
*    Desc:    copy the structure MgMgcoPathName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoPathName
(
MgMgcoPathName *dst,
MgMgcoPathName *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoPathName(dst, src, mem)
MgMgcoPathName *dst;
MgMgcoPathName *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoPathName)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoPathName));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyTknStrOSXL(&dst->lcl, &src->lcl, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyTknStrOSXL(&dst->dom, &src->dom, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelTknStrOSXL(&dst->lcl);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoPathName*/

/*
*
*    Fun:    mgUtlCpyMgMgcoTermId
*
*    Desc:    copy the structure MgMgcoTermId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTermId
(
MgMgcoTermId *dst,
MgMgcoTermId *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTermId(dst, src, mem)
MgMgcoTermId *dst;
MgMgcoTermId *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoTermId)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTermId));

   if (mgUtlCpyMgMgcoPathName(&dst->name, &src->name, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoTermId*/

/* mg008.105: moving unused function within AG compiler flag */
#ifdef AG

/*
*
*    Fun:    mgUtlCpyMgMgcoTermIdLst
*
*    Desc:    copy the structure MgMgcoTermIdLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTermIdLst
(
MgMgcoTermIdLst *dst,
MgMgcoTermIdLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTermIdLst(dst, src, mem)
MgMgcoTermIdLst *dst;
MgMgcoTermIdLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoTermIdLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTermIdLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->terms), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->terms[i]), sizeof(MgMgcoTermId), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoTermId(dst->terms[i], src->terms[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->terms[i], sizeof(MgMgcoTermId));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoTermId(dst->terms[i]);
         MGFREE(dst->terms[i], sizeof(MgMgcoTermId));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->terms, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoTermIdLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoName
*
*    Desc:    copy the structure MgMgcoName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoName
(
MgMgcoName *dst,
MgMgcoName *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoName(dst, src, mem)
MgMgcoName *dst;
MgMgcoName *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoName)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoName));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_GEN_TYPE_ALL :
            break;
         case  MGT_GEN_TYPE_KNOWN :
            break;
         case  MGT_GEN_TYPE_UNKNOWN :
            if (mgUtlCpyTknStrOSXL(&dst->u.str, &src->u.str, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoName*/

/*
*
*    Fun:    mgUtlCpyMgMgcoPkgdName
*
*    Desc:    copy the structure MgMgcoPkgdName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoPkgdName
(
MgMgcoPkgdName *dst,
MgMgcoPkgdName *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoPkgdName(dst, src, mem)
MgMgcoPkgdName *dst;
MgMgcoPkgdName *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoPkgdName)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoPkgdName));

   if (mgUtlCpyTknStrOSXL(&dst->pkgName, &src->pkgName, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyMgMgcoName(&dst->name, &src->name, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelTknStrOSXL(&dst->pkgName);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoPkgdName*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSigName
*
*    Desc:    copy the structure MgMgcoSigName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSigName
(
MgMgcoSigName *dst,
MgMgcoSigName *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSigName(dst, src, mem)
MgMgcoSigName *dst;
MgMgcoSigName *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSigName)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSigName));

   if (mgUtlCpyMgMgcoPkgdName(&dst->name, &src->name, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoSigName*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSigLst
*
*    Desc:    copy the structure MgMgcoSigLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSigLst
(
MgMgcoSigLst *dst,
MgMgcoSigLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSigLst(dst, src, mem)
MgMgcoSigLst *dst;
MgMgcoSigLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoSigLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSigLst));

   if( dst->numSigs.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->sigs), sizeof(Ptr)*(dst->numSigs.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->numSigs.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->sigs[i]), sizeof(MgMgcoSigName), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoSigName(dst->sigs[i], src->sigs[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->sigs[i], sizeof(MgMgcoSigName));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoSigName(dst->sigs[i]);
         MGFREE(dst->sigs[i], sizeof(MgMgcoSigName));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->sigs, sizeof(Ptr)*(dst->numSigs.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoSigLst*/
#if(  defined(  GCP_PKG_MGCO_ADVAUSRVRBASE)  || defined(  GCP_PKG_MGCO_AASDIGCOLLECT)  || defined(  GCP_PKG_MGCO_AASRECODING)  || defined(  GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT) ) 

/*
*
*    Fun:    mgUtlCpyMgMgcoFileUrl
*
*    Desc:    copy the structure MgMgcoFileUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoFileUrl
(
MgMgcoFileUrl *dst,
MgMgcoFileUrl *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoFileUrl(dst, src, mem)
MgMgcoFileUrl *dst;
MgMgcoFileUrl *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoFileUrl)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoFileUrl));

   if (mgUtlCpyTknStrOSXL(&dst->host, &src->host, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyTknStrOSXL(&dst->fpath, &src->fpath, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelTknStrOSXL(&dst->host);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoFileUrl*/

/*
*
*    Fun:    mgUtlCpyMgMgcoHostPort
*
*    Desc:    copy the structure MgMgcoHostPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoHostPort
(
MgMgcoHostPort *dst,
MgMgcoHostPort *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoHostPort(dst, src, mem)
MgMgcoHostPort *dst;
MgMgcoHostPort *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoHostPort)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoHostPort));

   if (mgUtlCpyTknStrOSXL(&dst->host, &src->host, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoHostPort*/

/*
*
*    Fun:    mgUtlCpyMgMgcoUsrPw
*
*    Desc:    copy the structure MgMgcoUsrPw
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoUsrPw
(
MgMgcoUsrPw *dst,
MgMgcoUsrPw *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoUsrPw(dst, src, mem)
MgMgcoUsrPw *dst;
MgMgcoUsrPw *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoUsrPw)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoUsrPw));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyTknStrOSXL(&dst->user, &src->user, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyTknStrOSXL(&dst->pswd, &src->pswd, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelTknStrOSXL(&dst->user);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoUsrPw*/

/*
*
*    Fun:    mgUtlCpyMgMgcoLogin
*
*    Desc:    copy the structure MgMgcoLogin
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoLogin
(
MgMgcoLogin *dst,
MgMgcoLogin *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoLogin(dst, src, mem)
MgMgcoLogin *dst;
MgMgcoLogin *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoLogin)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoLogin));

   if (mgUtlCpyMgMgcoUsrPw(&dst->usrPw, &src->usrPw, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyMgMgcoHostPort(&dst->hp, &src->hp, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoUsrPw(&dst->usrPw);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoLogin*/

/*
*
*    Fun:    mgUtlCpyMgMgcoPathType
*
*    Desc:    copy the structure MgMgcoPathType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoPathType
(
MgMgcoPathType *dst,
MgMgcoPathType *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoPathType(dst, src, mem)
MgMgcoPathType *dst;
MgMgcoPathType *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoPathType)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoPathType));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyTknStrOSXL(&dst->fpath, &src->fpath, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoPathType*/

/*
*
*    Fun:    mgUtlCpyMgMgcoFtpUrl
*
*    Desc:    copy the structure MgMgcoFtpUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoFtpUrl
(
MgMgcoFtpUrl *dst,
MgMgcoFtpUrl *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoFtpUrl(dst, src, mem)
MgMgcoFtpUrl *dst;
MgMgcoFtpUrl *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoFtpUrl)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoFtpUrl));

   if (mgUtlCpyMgMgcoLogin(&dst->login, &src->login, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyMgMgcoPathType(&dst->patTyp, &src->patTyp, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoLogin(&dst->login);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoFtpUrl*/

/*
*
*    Fun:    mgUtlCpyMgMgcoPathSearch
*
*    Desc:    copy the structure MgMgcoPathSearch
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoPathSearch
(
MgMgcoPathSearch *dst,
MgMgcoPathSearch *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoPathSearch(dst, src, mem)
MgMgcoPathSearch *dst;
MgMgcoPathSearch *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoPathSearch)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoPathSearch));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyTknStrOSXL(&dst->hpath, &src->hpath, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyTknStrOSXL(&dst->search, &src->search, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelTknStrOSXL(&dst->hpath);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoPathSearch*/

/*
*
*    Fun:    mgUtlCpyMgMgcoHttpUrl
*
*    Desc:    copy the structure MgMgcoHttpUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoHttpUrl
(
MgMgcoHttpUrl *dst,
MgMgcoHttpUrl *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoHttpUrl(dst, src, mem)
MgMgcoHttpUrl *dst;
MgMgcoHttpUrl *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoHttpUrl)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoHttpUrl));

   if (mgUtlCpyMgMgcoHostPort(&dst->hp, &src->hp, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyMgMgcoPathSearch(&dst->ps, &src->ps, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoHostPort(&dst->hp);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoHttpUrl*/

/*
*
*    Fun:    mgUtlCpyMgMgcoProvSegSpec
*
*    Desc:    copy the structure MgMgcoProvSegSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoProvSegSpec
(
MgMgcoProvSegSpec *dst,
MgMgcoProvSegSpec *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoProvSegSpec(dst, src, mem)
MgMgcoProvSegSpec *dst;
MgMgcoProvSegSpec *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoProvSegSpec)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoProvSegSpec));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_MGCO_FILE_URL :
            if (mgUtlCpyMgMgcoFileUrl(&dst->u.file, &src->u.file, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_FTP_URL :
            if (mgUtlCpyMgMgcoFtpUrl(&dst->u.ftp, &src->u.ftp, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_HTTP_URL :
            if (mgUtlCpyMgMgcoHttpUrl(&dst->u.http, &src->u.http, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_SIMPLE :
            if (mgUtlCpyTknStrOSXL(&dst->u.simple, &src->u.simple, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoProvSegSpec*/

/*
*
*    Fun:    mgUtlCpyMgMgcoVvarSpec
*
*    Desc:    copy the structure MgMgcoVvarSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoVvarSpec
(
MgMgcoVvarSpec *dst,
MgMgcoVvarSpec *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoVvarSpec(dst, src, mem)
MgMgcoVvarSpec *dst;
MgMgcoVvarSpec *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoVvarSpec)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoVvarSpec));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_MGCO_CHAR_SPEC :
            if (mgUtlCpyTknStrOSXL(&dst->u.chr, &src->u.chr, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_DATE_SPEC :
            break;
         case  MGT_MGCO_DIG_SPEC :
            if (mgUtlCpyTknStrOSXL(&dst->u.dig, &src->u.dig, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_DOW_SPEC :
            break;
         case  MGT_MGCO_DUR_SPEC :
            break;
         case  MGT_MGCO_HUSH_SPEC :
            break;
         case  MGT_MGCO_INT_SPEC :
            break;
         case  MGT_MGCO_MONEY_SPEC :
            break;
         case  MGT_MGCO_MONTH_SPEC :
            break;
         case  MGT_MGCO_PHRASE_SPEC :
            if (mgUtlCpyTknStrOSXL(&dst->u.phrase, &src->u.phrase, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_TOD_SPEC :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoVvarSpec*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSelType
*
*    Desc:    copy the structure MgMgcoSelType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSelType
(
MgMgcoSelType *dst,
MgMgcoSelType *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSelType(dst, src, mem)
MgMgcoSelType *dst;
MgMgcoSelType *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSelType)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSelType));

   if (mgUtlCpyTknStrOSXL(&dst->other, &src->other, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoSelType*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSelSpecLst
*
*    Desc:    copy the structure MgMgcoSelSpecLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSelSpecLst
(
MgMgcoSelSpecLst *dst,
MgMgcoSelSpecLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSelSpecLst(dst, src, mem)
MgMgcoSelSpecLst *dst;
MgMgcoSelSpecLst *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSelSpecLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSelSpecLst));

   if (mgUtlCpyMgMgcoSelType(&dst->type, &src->type, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyTknStrOSXL(&dst->val, &src->val, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoSelType(&dst->type);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoSelSpecLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSelList
*
*    Desc:    copy the structure MgMgcoSelList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSelList
(
MgMgcoSelList *dst,
MgMgcoSelList *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSelList(dst, src, mem)
MgMgcoSelList *dst;
MgMgcoSelList *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoSelList)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSelList));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->selSpec), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->selSpec[i]), sizeof(MgMgcoSelSpecLst), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoSelSpecLst(dst->selSpec[i], src->selSpec[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->selSpec[i], sizeof(MgMgcoSelSpecLst));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoSelSpecLst(dst->selSpec[i]);
         MGFREE(dst->selSpec[i], sizeof(MgMgcoSelSpecLst));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->selSpec, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoSelList*/

/*
*
*    Fun:    mgUtlCpyMgMgcoVarSegSpec
*
*    Desc:    copy the structure MgMgcoVarSegSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoVarSegSpec
(
MgMgcoVarSegSpec *dst,
MgMgcoVarSegSpec *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoVarSegSpec(dst, src, mem)
MgMgcoVarSegSpec *dst;
MgMgcoVarSegSpec *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoVarSegSpec)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoVarSegSpec));

   if (mgUtlCpyMgMgcoVvarSpec(&dst->vvarSpec, &src->vvarSpec, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyMgMgcoSelList(&dst->selList, &src->selList, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoVvarSpec(&dst->vvarSpec);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoVarSegSpec*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSpec
*
*    Desc:    copy the structure MgMgcoSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSpec
(
MgMgcoSpec *dst,
MgMgcoSpec *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSpec(dst, src, mem)
MgMgcoSpec *dst;
MgMgcoSpec *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSpec)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSpec));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_MGCO_PROV_SEG_SPEC :
            if (mgUtlCpyMgMgcoProvSegSpec(&dst->u.provSs, &src->u.provSs, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_VAR_SEG_SPEC :
            if (mgUtlCpyMgMgcoVarSegSpec(&dst->u.staSs, &src->u.staSs, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoSpec*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSegSpec
*
*    Desc:    copy the structure MgMgcoSegSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSegSpec
(
MgMgcoSegSpec *dst,
MgMgcoSegSpec *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSegSpec(dst, src, mem)
MgMgcoSegSpec *dst;
MgMgcoSegSpec *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSegSpec)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSegSpec));

   if (mgUtlCpyMgMgcoSpec(&dst->spec, &src->spec, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoSegSpec*/

/*
*
*    Fun:    mgUtlCpyMgMgcoAnncSpec
*
*    Desc:    copy the structure MgMgcoAnncSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoAnncSpec
(
MgMgcoAnncSpec *dst,
MgMgcoAnncSpec *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoAnncSpec(dst, src, mem)
MgMgcoAnncSpec *dst;
MgMgcoAnncSpec *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoAnncSpec)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoAnncSpec));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->segSpec), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->segSpec[i]), sizeof(MgMgcoSegSpec), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoSegSpec(dst->segSpec[i], src->segSpec[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->segSpec[i], sizeof(MgMgcoSegSpec));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoSegSpec(dst->segSpec[i]);
         MGFREE(dst->segSpec[i], sizeof(MgMgcoSegSpec));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->segSpec, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoAnncSpec*/
#endif

/*
*
*    Fun:    mgUtlCpyMgMgcoValue
*
*    Desc:    copy the structure MgMgcoValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoValue
(
MgMgcoValue *dst,
MgMgcoValue *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoValue(dst, src, mem)
MgMgcoValue *dst;
MgMgcoValue *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoValue)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoValue));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_VALTYPE_ADV_AUD_PROVSEGSPEC :
            if (mgUtlCpyMgMgcoProvSegSpec(&dst->u.prSpec, &src->u.prSpec, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_ADV_AUD_SEGLST :
            if (mgUtlCpyMgMgcoAnncSpec(&dst->u.anSpec, &src->u.anSpec, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_ENUM :
            break;
         case  MGT_VALTYPE_HEX_SINT32 :
            break;
         case  MGT_VALTYPE_HEX_UINT32 :
            break;
         case  MGT_VALTYPE_OCTSTRXL :
            if (mgUtlCpyTknStrOSXL(&dst->u.osxl, &src->u.osxl, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_SIGLST :
            if (mgUtlCpyMgMgcoSigLst(&dst->u.sigLst, &src->u.sigLst, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_SIGNAME :
            if (mgUtlCpyMgMgcoSigName(&dst->u.sigName, &src->u.sigName, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_SINT32 :
            break;
         case  MGT_VALTYPE_TERMID :
            if (mgUtlCpyMgMgcoTermId(&dst->u.termId, &src->u.termId, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_TERMIDLST :
            if (mgUtlCpyMgMgcoTermIdLst(&dst->u.termIdLst, &src->u.termIdLst, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_TKNBUF :
            break;
         case  MGT_VALTYPE_UINT32 :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoValue*/

/*
*
*    Fun:    mgUtlCpyMgMgcoAuthHdr
*
*    Desc:    copy the structure MgMgcoAuthHdr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoAuthHdr
(
MgMgcoAuthHdr *dst,
MgMgcoAuthHdr *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoAuthHdr(dst, src, mem)
MgMgcoAuthHdr *dst;
MgMgcoAuthHdr *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoAuthHdr)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoAuthHdr));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyTknStrOSXL(&dst->aData, &src->aData, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoAuthHdr*/

/*
*
*    Fun:    mgUtlCpyMgMgcoDomAddrPort
*
*    Desc:    copy the structure MgMgcoDomAddrPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoDomAddrPort
(
MgMgcoDomAddrPort *dst,
MgMgcoDomAddrPort *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoDomAddrPort(dst, src, mem)
MgMgcoDomAddrPort *dst;
MgMgcoDomAddrPort *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoDomAddrPort)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoDomAddrPort));

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_IPV4 :
               if (mgUtlCpyTknStrOSXL(&dst->u.ipv4, &src->u.ipv4, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_IPV6 :
               if (mgUtlCpyTknStrOSXL(&dst->u.ipv6, &src->u.ipv6, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoDomAddrPort*/

/*
*
*    Fun:    mgUtlCpyMgMgcoDomNamePort
*
*    Desc:    copy the structure MgMgcoDomNamePort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoDomNamePort
(
MgMgcoDomNamePort *dst,
MgMgcoDomNamePort *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoDomNamePort(dst, src, mem)
MgMgcoDomNamePort *dst;
MgMgcoDomNamePort *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoDomNamePort)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoDomNamePort));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyTknStrOSXL(&dst->name, &src->name, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoDomNamePort*/

/*
*
*    Fun:    mgUtlCpyMgMgcoMid
*
*    Desc:    copy the structure MgMgcoMid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoMid
(
MgMgcoMid *dst,
MgMgcoMid *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoMid(dst, src, mem)
MgMgcoMid *dst;
MgMgcoMid *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoMid)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoMid));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_MID_DADDRPORT :
            if (mgUtlCpyMgMgcoDomAddrPort(&dst->u.dAddrPort, &src->u.dAddrPort, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MID_DEVICE :
            if (mgUtlCpyMgMgcoPathName(&dst->u.dev, &src->u.dev, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MID_DNAMEPORT :
            if (mgUtlCpyMgMgcoDomNamePort(&dst->u.dNamePort, &src->u.dNamePort, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MID_MTPADDR :
            break;
         case  MGT_MID_PORT :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoMid*/

/*
*
*    Fun:    mgUtlCpyMgMgcoErrDesc
*
*    Desc:    copy the structure MgMgcoErrDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoErrDesc
(
MgMgcoErrDesc *dst,
MgMgcoErrDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoErrDesc(dst, src, mem)
MgMgcoErrDesc *dst;
MgMgcoErrDesc *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoErrDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoErrDesc));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyTknStrOSXL(&dst->text, &src->text, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoErrDesc*/

#endif /* AG */

/*
*
*    Fun:    mgUtlCpyMgMgcoTopoDesc
*
*    Desc:    copy the structure MgMgcoTopoDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTopoDesc
(
MgMgcoTopoDesc *dst,
MgMgcoTopoDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTopoDesc(dst, src, mem)
MgMgcoTopoDesc *dst;
MgMgcoTopoDesc *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoTopoDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTopoDesc));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoTermId(&dst->from, &src->from, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoTermId(&dst->to, &src->to, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoTermId(&dst->from);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoTopoDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoTopoDescLst
*
*    Desc:    copy the structure MgMgcoTopoDescLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTopoDescLst
(
MgMgcoTopoDescLst *dst,
MgMgcoTopoDescLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTopoDescLst(dst, src, mem)
MgMgcoTopoDescLst *dst;
MgMgcoTopoDescLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoTopoDescLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTopoDescLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->descs), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->descs[i]), sizeof(MgMgcoTopoDesc), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoTopoDesc(dst->descs[i], src->descs[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->descs[i], sizeof(MgMgcoTopoDesc));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoTopoDesc(dst->descs[i]);
         MGFREE(dst->descs[i], sizeof(MgMgcoTopoDesc));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->descs, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoTopoDescLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoContextProps
*
*    Desc:    copy the structure MgMgcoContextProps
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoContextProps
(
MgMgcoContextProps *dst,
MgMgcoContextProps *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoContextProps(dst, src, mem)
MgMgcoContextProps *dst;
MgMgcoContextProps *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoContextProps)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoContextProps));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoTopoDescLst(&dst->tl, &src->tl, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoContextProps*/

/* mg008.105: moving unused function within AG compiler flag */
#ifdef AG

/*
*
*    Fun:    mgUtlCpyMgMgcoValLst
*
*    Desc:    copy the structure MgMgcoValLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoValLst
(
MgMgcoValLst *dst,
MgMgcoValLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoValLst(dst, src, mem)
MgMgcoValLst *dst;
MgMgcoValLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoValLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoValLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->vals), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->vals[i]), sizeof(MgMgcoValue), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoValue(dst->vals[i], src->vals[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->vals[i], sizeof(MgMgcoValue));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoValue(dst->vals[i]);
         MGFREE(dst->vals[i], sizeof(MgMgcoValue));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->vals, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoValLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoValRng
*
*    Desc:    copy the structure MgMgcoValRng
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoValRng
(
MgMgcoValRng *dst,
MgMgcoValRng *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoValRng(dst, src, mem)
MgMgcoValRng *dst;
MgMgcoValRng *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoValRng)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoValRng));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoValue(&dst->low, &src->low, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoValue(&dst->up, &src->up, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoValue(&dst->low);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoValRng*/

/*
*
*    Fun:    mgUtlCpyMgMgcoParmValue
*
*    Desc:    copy the structure MgMgcoParmValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoParmValue
(
MgMgcoParmValue *dst,
MgMgcoParmValue *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoParmValue(dst, src, mem)
MgMgcoParmValue *dst;
MgMgcoParmValue *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoParmValue)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoParmValue));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_VALUE_AND :
            if (mgUtlCpyMgMgcoValLst(&dst->u.and, &src->u.and, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALUE_EQUAL :
            if (mgUtlCpyMgMgcoValue(&dst->u.eq, &src->u.eq, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALUE_GREATERTHAN :
            if (mgUtlCpyMgMgcoValue(&dst->u.gt, &src->u.gt, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALUE_LESSTHAN :
            if (mgUtlCpyMgMgcoValue(&dst->u.lt, &src->u.lt, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALUE_NOTEQUAL :
            if (mgUtlCpyMgMgcoValue(&dst->u.ne, &src->u.ne, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALUE_OR :
            if (mgUtlCpyMgMgcoValLst(&dst->u.or, &src->u.or, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALUE_RANGE :
            if (mgUtlCpyMgMgcoValRng(&dst->u.rng, &src->u.rng, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoParmValue*/

/*
*
*    Fun:    mgUtlCpyMgMgcoPropParm
*
*    Desc:    copy the structure MgMgcoPropParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoPropParm
(
MgMgcoPropParm *dst,
MgMgcoPropParm *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoPropParm(dst, src, mem)
MgMgcoPropParm *dst;
MgMgcoPropParm *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoPropParm)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoPropParm));

   if (mgUtlCpyMgMgcoPkgdName(&dst->name, &src->name, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyMgMgcoParmValue(&dst->val, &src->val, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoPkgdName(&dst->name);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoPropParm*/

/*
*
*    Fun:    mgUtlCpyMgMgcoPropParmLst
*
*    Desc:    copy the structure MgMgcoPropParmLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoPropParmLst
(
MgMgcoPropParmLst *dst,
MgMgcoPropParmLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoPropParmLst(dst, src, mem)
MgMgcoPropParmLst *dst;
MgMgcoPropParmLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoPropParmLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoPropParmLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->parms), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->parms[i]), sizeof(MgMgcoPropParm), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoPropParm(dst->parms[i], src->parms[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->parms[i], sizeof(MgMgcoPropParm));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoPropParm(dst->parms[i]);
         MGFREE(dst->parms[i], sizeof(MgMgcoPropParm));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoPropParmLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoLocalParm
*
*    Desc:    copy the structure MgMgcoLocalParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoLocalParm
(
MgMgcoLocalParm *dst,
MgMgcoLocalParm *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoLocalParm(dst, src, mem)
MgMgcoLocalParm *dst;
MgMgcoLocalParm *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoLocalParm)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoLocalParm));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_LCLCTL_MODE :
            break;
         case  MGT_LCLCTL_PROPPARM :
            if (mgUtlCpyMgMgcoPropParm(&dst->u.propParm, &src->u.propParm, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_LCLCTL_RESGRP :
            break;
         case  MGT_LCLCTL_RESVAL :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoLocalParm*/

/*
*
*    Fun:    mgUtlCpyMgMgcoLclCtlDesc
*
*    Desc:    copy the structure MgMgcoLclCtlDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoLclCtlDesc
(
MgMgcoLclCtlDesc *dst,
MgMgcoLclCtlDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoLclCtlDesc(dst, src, mem)
MgMgcoLclCtlDesc *dst;
MgMgcoLclCtlDesc *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoLclCtlDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoLclCtlDesc));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->parms), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->parms[i]), sizeof(MgMgcoLocalParm), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoLocalParm(dst->parms[i], src->parms[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->parms[i], sizeof(MgMgcoLocalParm));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoLocalParm(dst->parms[i]);
         MGFREE(dst->parms[i], sizeof(MgMgcoLocalParm));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoLclCtlDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoPropGrpLst
*
*    Desc:    copy the structure MgMgcoPropGrpLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoPropGrpLst
(
MgMgcoPropGrpLst *dst,
MgMgcoPropGrpLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoPropGrpLst(dst, src, mem)
MgMgcoPropGrpLst *dst;
MgMgcoPropGrpLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoPropGrpLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoPropGrpLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->grps), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->grps[i]), sizeof(MgMgcoPropParmLst), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoPropParmLst(dst->grps[i], src->grps[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->grps[i], sizeof(MgMgcoPropParmLst));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoPropParmLst(dst->grps[i]);
         MGFREE(dst->grps[i], sizeof(MgMgcoPropParmLst));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->grps, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoPropGrpLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoLocalDesc
*
*    Desc:    copy the structure MgMgcoLocalDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoLocalDesc
(
MgMgcoLocalDesc *dst,
MgMgcoLocalDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoLocalDesc(dst, src, mem)
MgMgcoLocalDesc *dst;
MgMgcoLocalDesc *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoLocalDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoLocalDesc));

   if(dst->pres.pres != NOTPRSNT)
   {
     /* if (mgUtlCpyCmSdpInfoSet(&dst->sdp, &src->sdp, mem) != ROK) 
         RETVALUE(RFAILED); */
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoLocalDesc*/
/* :03/15/05:01:01   */


/*
*
*    Fun:    mgUtlCpyMgMgcoTermStateParm
*
*    Desc:    copy the structure MgMgcoTermStateParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTermStateParm
(
MgMgcoTermStateParm *dst,
MgMgcoTermStateParm *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTermStateParm(dst, src, mem)
MgMgcoTermStateParm *dst;
MgMgcoTermStateParm *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoTermStateParm)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTermStateParm));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_TERMST_EVTBUFCTL :
            break;
         case  MGT_TERMST_PROPLST :
            if (mgUtlCpyMgMgcoPropParm(&dst->u.parm, &src->u.parm, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TERMST_SVCST :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoTermStateParm*/

/*
*
*    Fun:    mgUtlCpyMgMgcoTermStateDesc
*
*    Desc:    copy the structure MgMgcoTermStateDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTermStateDesc
(
MgMgcoTermStateDesc *dst,
MgMgcoTermStateDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTermStateDesc(dst, src, mem)
MgMgcoTermStateDesc *dst;
MgMgcoTermStateDesc *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoTermStateDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTermStateDesc));

   if( dst->numComp.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->trmStPar), sizeof(Ptr)*(dst->numComp.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->numComp.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->trmStPar[i]), sizeof(MgMgcoTermStateParm), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoTermStateParm(dst->trmStPar[i], src->trmStPar[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->trmStPar[i], sizeof(MgMgcoTermStateParm));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoTermStateParm(dst->trmStPar[i]);
         MGFREE(dst->trmStPar[i], sizeof(MgMgcoTermStateParm));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->trmStPar, sizeof(Ptr)*(dst->numComp.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoTermStateDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoStreamParm
*
*    Desc:    copy the structure MgMgcoStreamParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoStreamParm
(
MgMgcoStreamParm *dst,
MgMgcoStreamParm *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoStreamParm(dst, src, mem)
MgMgcoStreamParm *dst;
MgMgcoStreamParm *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoStreamParm)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoStreamParm));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoLclCtlDesc(&dst->locCtl, &src->locCtl, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoLocalDesc(&dst->local, &src->local, mem) != ROK)
         goto soCpyErr1;
      if (mgUtlCpyMgMgcoLocalDesc(&dst->remote, &src->remote, mem) != ROK)
         goto soCpyErr2;
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoLocalDesc(&dst->local);
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoLclCtlDesc(&dst->locCtl);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoStreamParm*/

/*
*
*    Fun:    mgUtlCpyMgMgcoStreamDesc
*
*    Desc:    copy the structure MgMgcoStreamDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoStreamDesc
(
MgMgcoStreamDesc *dst,
MgMgcoStreamDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoStreamDesc(dst, src, mem)
MgMgcoStreamDesc *dst;
MgMgcoStreamDesc *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoStreamDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoStreamDesc));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoStreamParm(&dst->sl, &src->sl, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoStreamDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoMediaPar
*
*    Desc:    copy the structure MgMgcoMediaPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoMediaPar
(
MgMgcoMediaPar *dst,
MgMgcoMediaPar *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoMediaPar(dst, src, mem)
MgMgcoMediaPar *dst;
MgMgcoMediaPar *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoMediaPar)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoMediaPar));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_MEDIAPAR_LOCAL :
            if (mgUtlCpyMgMgcoLocalDesc(&dst->u.local, &src->u.local, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MEDIAPAR_LOCCTL :
            if (mgUtlCpyMgMgcoLclCtlDesc(&dst->u.locCtl, &src->u.locCtl, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MEDIAPAR_REMOTE :
            if (mgUtlCpyMgMgcoLocalDesc(&dst->u.remote, &src->u.remote, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MEDIAPAR_STRPAR :
            if (mgUtlCpyMgMgcoStreamDesc(&dst->u.stream, &src->u.stream, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MEDIAPAR_TERMST :
            if (mgUtlCpyMgMgcoTermStateDesc(&dst->u.tstate, &src->u.tstate, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoMediaPar*/

/*
*
*    Fun:    mgUtlCpyMgMgcoMediaDesc
*
*    Desc:    copy the structure MgMgcoMediaDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoMediaDesc
(
MgMgcoMediaDesc *dst,
MgMgcoMediaDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoMediaDesc(dst, src, mem)
MgMgcoMediaDesc *dst;
MgMgcoMediaDesc *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoMediaDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoMediaDesc));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->parms), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->parms[i]), sizeof(MgMgcoMediaPar), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoMediaPar(dst->parms[i], src->parms[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->parms[i], sizeof(MgMgcoMediaPar));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoMediaPar(dst->parms[i]);
         MGFREE(dst->parms[i], sizeof(MgMgcoMediaPar));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoMediaDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoNonStdId
*
*    Desc:    copy the structure MgMgcoNonStdId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoNonStdId
(
MgMgcoNonStdId *dst,
MgMgcoNonStdId *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoNonStdId(dst, src, mem)
MgMgcoNonStdId *dst;
MgMgcoNonStdId *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoNonStdId)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoNonStdId));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_EXTNPARM_MAND :
            break;
         case  MGT_EXTNPARM_OPT :
            break;
         case  MGT_NONSTD_H221 :
            break;
         case  MGT_NONSTD_OBJID :
            if (mgUtlCpyTknStrOSXL(&dst->u.objId, &src->u.objId, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoNonStdId*/

/*
*
*    Fun:    mgUtlCpyMgMgcoModemType
*
*    Desc:    copy the structure MgMgcoModemType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoModemType
(
MgMgcoModemType *dst,
MgMgcoModemType *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoModemType(dst, src, mem)
MgMgcoModemType *dst;
MgMgcoModemType *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoModemType)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoModemType));

   if (mgUtlCpyMgMgcoNonStdId(&dst->extnId, &src->extnId, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoModemType*/

/*
*
*    Fun:    mgUtlCpyMgMgcoModemTypeLst
*
*    Desc:    copy the structure MgMgcoModemTypeLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoModemTypeLst
(
MgMgcoModemTypeLst *dst,
MgMgcoModemTypeLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoModemTypeLst(dst, src, mem)
MgMgcoModemTypeLst *dst;
MgMgcoModemTypeLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoModemTypeLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoModemTypeLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->modems), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->modems[i]), sizeof(MgMgcoModemType), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoModemType(dst->modems[i], src->modems[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->modems[i], sizeof(MgMgcoModemType));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoModemType(dst->modems[i]);
         MGFREE(dst->modems[i], sizeof(MgMgcoModemType));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->modems, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoModemTypeLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoNonStdExtn
*
*    Desc:    copy the structure MgMgcoNonStdExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoNonStdExtn
(
MgMgcoNonStdExtn *dst,
MgMgcoNonStdExtn *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoNonStdExtn(dst, src, mem)
MgMgcoNonStdExtn *dst;
MgMgcoNonStdExtn *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoNonStdExtn)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoNonStdExtn));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoNonStdId(&dst->id, &src->id, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoParmValue(&dst->val, &src->val, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoNonStdId(&dst->id);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoNonStdExtn*/

/*
*
*    Fun:    mgUtlCpyMgMgcoModemDesc
*
*    Desc:    copy the structure MgMgcoModemDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoModemDesc
(
MgMgcoModemDesc *dst,
MgMgcoModemDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoModemDesc(dst, src, mem)
MgMgcoModemDesc *dst;
MgMgcoModemDesc *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoModemDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoModemDesc));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoModemTypeLst(&dst->mtl, &src->mtl, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoPropParmLst(&dst->mpl, &src->mpl, mem) != ROK)
         goto soCpyErr1;
      if (mgUtlCpyMgMgcoNonStdExtn(&dst->extn, &src->extn, mem) != ROK)
         goto soCpyErr2;
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoPropParmLst(&dst->mpl);
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoModemTypeLst(&dst->mtl);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoModemDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoMuxDesc
*
*    Desc:    copy the structure MgMgcoMuxDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoMuxDesc
(
MgMgcoMuxDesc *dst,
MgMgcoMuxDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoMuxDesc(dst, src, mem)
MgMgcoMuxDesc *dst;
MgMgcoMuxDesc *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoMuxDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoMuxDesc));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoNonStdId(&dst->id, &src->id, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoTermIdLst(&dst->tl, &src->tl, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoNonStdId(&dst->id);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoMuxDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoEvtOther
*
*    Desc:    copy the structure MgMgcoEvtOther
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEvtOther
(
MgMgcoEvtOther *dst,
MgMgcoEvtOther *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEvtOther(dst, src, mem)
MgMgcoEvtOther *dst;
MgMgcoEvtOther *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoEvtOther)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoEvtOther));

   if (mgUtlCpyMgMgcoName(&dst->name, &src->name, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyMgMgcoParmValue(&dst->val, &src->val, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoName(&dst->name);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoEvtOther*/

/*
*
*    Fun:    mgUtlCpyMgMgcoNtfyCmpl
*
*    Desc:    copy the structure MgMgcoNtfyCmpl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoNtfyCmpl
(
MgMgcoNtfyCmpl *dst,
MgMgcoNtfyCmpl *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoNtfyCmpl(dst, src, mem)
MgMgcoNtfyCmpl *dst;
MgMgcoNtfyCmpl *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoNtfyCmpl)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoNtfyCmpl));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->reasons), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->reasons[i]), sizeof(TknU8), mem) != ROK)
            goto soCpyErr1;
         cmMemcpy((U8 *)dst->reasons[i], (U8 *)src->reasons[i], sizeof(TknU8));
      }
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         MGFREE(dst->reasons[i], sizeof(TknU8));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->reasons, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);

} /*end of function soCpyMgMgcoNtfyCmpl*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSigPar
*
*    Desc:    copy the structure MgMgcoSigPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSigPar
(
MgMgcoSigPar *dst,
MgMgcoSigPar *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSigPar(dst, src, mem)
MgMgcoSigPar *dst;
MgMgcoSigPar *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSigPar)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSigPar));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_SIGPAR_DURATION :
            break;
         case  MGT_SIGPAR_KEEPACTIVE :
            break;
         case  MGT_SIGPAR_NTFYCMPL :
            if (mgUtlCpyMgMgcoNtfyCmpl(&dst->u.nc, &src->u.nc, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SIGPAR_OTHER :
            if (mgUtlCpyMgMgcoEvtOther(&dst->u.other, &src->u.other, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SIGPAR_STREAMID :
            break;
         case  MGT_SIGPAR_TYPE :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoSigPar*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSigParLst
*
*    Desc:    copy the structure MgMgcoSigParLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSigParLst
(
MgMgcoSigParLst *dst,
MgMgcoSigParLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSigParLst(dst, src, mem)
MgMgcoSigParLst *dst;
MgMgcoSigParLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoSigParLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSigParLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->parms), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->parms[i]), sizeof(MgMgcoSigPar), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoSigPar(dst->parms[i], src->parms[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->parms[i], sizeof(MgMgcoSigPar));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoSigPar(dst->parms[i]);
         MGFREE(dst->parms[i], sizeof(MgMgcoSigPar));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoSigParLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSignalsReq
*
*    Desc:    copy the structure MgMgcoSignalsReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSignalsReq
(
MgMgcoSignalsReq *dst,
MgMgcoSignalsReq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSignalsReq(dst, src, mem)
MgMgcoSignalsReq *dst;
MgMgcoSignalsReq *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSignalsReq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSignalsReq));

   if (mgUtlCpyMgMgcoPkgdName(&dst->name, &src->name, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyMgMgcoSigParLst(&dst->pl, &src->pl, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoPkgdName(&dst->name);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoSignalsReq*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSignalsReqLst
*
*    Desc:    copy the structure MgMgcoSignalsReqLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSignalsReqLst
(
MgMgcoSignalsReqLst *dst,
MgMgcoSignalsReqLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSignalsReqLst(dst, src, mem)
MgMgcoSignalsReqLst *dst;
MgMgcoSignalsReqLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoSignalsReqLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSignalsReqLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->reqs), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->reqs[i]), sizeof(MgMgcoSignalsReq), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoSignalsReq(dst->reqs[i], src->reqs[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->reqs[i], sizeof(MgMgcoSignalsReq));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoSignalsReq(dst->reqs[i]);
         MGFREE(dst->reqs[i], sizeof(MgMgcoSignalsReq));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->reqs, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoSignalsReqLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSignalsLst
*
*    Desc:    copy the structure MgMgcoSignalsLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSignalsLst
(
MgMgcoSignalsLst *dst,
MgMgcoSignalsLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSignalsLst(dst, src, mem)
MgMgcoSignalsLst *dst;
MgMgcoSignalsLst *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSignalsLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSignalsLst));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoSignalsReqLst(&dst->pl, &src->pl, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoSignalsLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSignalsParm
*
*    Desc:    copy the structure MgMgcoSignalsParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSignalsParm
(
MgMgcoSignalsParm *dst,
MgMgcoSignalsParm *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSignalsParm(dst, src, mem)
MgMgcoSignalsParm *dst;
MgMgcoSignalsParm *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSignalsParm)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSignalsParm));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_SIGSPAR_LST :
            if (mgUtlCpyMgMgcoSignalsLst(&dst->u.lst, &src->u.lst, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SIGSPAR_REQ :
            if (mgUtlCpyMgMgcoSignalsReq(&dst->u.req, &src->u.req, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoSignalsParm*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSignalsDesc
*
*    Desc:    copy the structure MgMgcoSignalsDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSignalsDesc
(
MgMgcoSignalsDesc *dst,
MgMgcoSignalsDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSignalsDesc(dst, src, mem)
MgMgcoSignalsDesc *dst;
MgMgcoSignalsDesc *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoSignalsDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSignalsDesc));

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->num.pres != NOTPRSNT )
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->parms), sizeof(Ptr)*(dst->num.val), mem) != ROK)
            goto soCpyErr0;
         for (i=0;i<dst->num.val;i++)
         {
            if (mgUtlCpyGetMem((Ptr*)&(dst->parms[i]), sizeof(MgMgcoSignalsParm), mem) != ROK)
               goto soCpyErr1;
            if (mgUtlCpyMgMgcoSignalsParm(dst->parms[i], src->parms[i], mem) != ROK)
               goto soCpyErr2;
         }
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->parms[i], sizeof(MgMgcoSignalsParm));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoSignalsParm(dst->parms[i]);
         MGFREE(dst->parms[i], sizeof(MgMgcoSignalsParm));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoSignalsDesc*/
/* MILESTONE_6: New function to have fun */

/*
*
*    Fun:    mgUtlCpyMgMgcoEmbEvtDesc
*
*    Desc:   copy the structure MgMgcoReqEvtDesc from
*            structure MgMgcoEmbedFirst
*
*    Ret:    ROK  -ok
*
*    Notes:  None
*
*    File:   mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEmbEvtDesc
(
MgMgcoReqEvtDesc  *dst,
MgMgcoEmbedFirst  *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEmbEvtDesc(dst, src, mem)
MgMgcoReqEvtDesc  *dst;
MgMgcoEmbedFirst  *src;
CmMemListCp *mem;
#endif
{
   TRC3(mgUtlCpyMgMgcoEmbEvtDesc);

   /*-- Destination has memory allocated, just check for it --*/
   if (dst == NULLP)
      RETVALUE(RFAILED);

   /*-- Copy the presence field --*/
   cmMemcpy((U8 *)&dst->pres, (U8 *)&src->pres, sizeof(TknU8));

   if(dst->pres.pres != NOTPRSNT)
   {
      /*-- Copy request identifier --*/
      cmMemcpy((U8 *)&dst->reqId, (U8 *)&src->reqId, sizeof(MgMgcoRequestId));

      if (mgUtlCpyMgMgcoEmbEvtLst(&dst->el, &src->sl, mem) != ROK)
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}

/*
*
*    Fun:    mgUtlCpyMgMgcoDigMapLet
*
*    Desc:    copy the structure MgMgcoDigMapLet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoDigMapLet
(
MgMgcoDigMapLet *dst,
MgMgcoDigMapLet *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoDigMapLet(dst, src, mem)
MgMgcoDigMapLet *dst;
MgMgcoDigMapLet *src;
CmMemListCp *mem;
#endif
{
   S16 i;

   TRC3(mgUtlCpyMgMgcoDigMapLet)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoDigMapLet));

   if( dst->num.pres != NOTPRSNT )
   {
       if (mgUtlCpyGetMem((Ptr*)&(dst->mapLets), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->mapLets[i]), sizeof(MgMgcoDigRng), mem) != ROK)
            goto soCpyErr1;
         cmMemcpy((U8 *)dst->mapLets[i], (U8 *)src->mapLets[i], 
                                                sizeof(MgMgcoDigRng));
      }

   }
   RETVALUE(ROK);
 

 soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         MGFREE(dst->mapLets[i], sizeof(MgMgcoDigRng));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->mapLets, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(RFAILED);
 
soCpyErr0 :
   RETVALUE(RFAILED);

} /*end of function soCpyMgMgcoDigMapLet*/

/*
*
*    Fun:    mgUtlCpyMgMgcoDigMapRng
*
*    Desc:    copy the structure MgMgcoDigMapRng
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoDigMapRng
(
MgMgcoDigMapRng *dst,
MgMgcoDigMapRng *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoDigMapRng(dst, src, mem)
MgMgcoDigMapRng *dst;
MgMgcoDigMapRng *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoDigMapRng)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoDigMapRng));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_DIGMAP_LET :
            if (mgUtlCpyMgMgcoDigMapLet(&dst->u.let, &src->u.let, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_DIGMAP_X :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoDigMapRng*/

/*
*
*    Fun:    mgUtlCpyMgMgcoDigStrElem
*
*    Desc:    copy the structure MgMgcoDigStrElem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoDigStrElem
(
MgMgcoDigStrElem *dst,
MgMgcoDigStrElem *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoDigStrElem(dst, src, mem)
MgMgcoDigStrElem *dst;
MgMgcoDigStrElem *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoDigStrElem)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoDigStrElem));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_DIGSTR_LET :
            break;
         case  MGT_DIGSTR_RNG :
            if (mgUtlCpyMgMgcoDigMapRng(&dst->u.range, &src->u.range, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoDigStrElem*/

/*
*
*    Fun:    mgUtlCpyMgMgcoDigStr
*
*    Desc:    copy the structure MgMgcoDigStr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoDigStr
(
MgMgcoDigStr *dst,
MgMgcoDigStr *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoDigStr(dst, src, mem)
MgMgcoDigStr *dst;
MgMgcoDigStr *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoDigStr)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoDigStr));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->elems), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->elems[i]), sizeof(MgMgcoDigStrElem), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoDigStrElem(dst->elems[i], src->elems[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->elems[i], sizeof(MgMgcoDigStrElem));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoDigStrElem(dst->elems[i]);
         MGFREE(dst->elems[i], sizeof(MgMgcoDigStrElem));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->elems, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoDigStr*/

/*
*
*    Fun:    mgUtlCpyMgMgcoDigMap
*
*    Desc:    copy the structure MgMgcoDigMap
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoDigMap
(
MgMgcoDigMap *dst,
MgMgcoDigMap *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoDigMap(dst, src, mem)
MgMgcoDigMap *dst;
MgMgcoDigMap *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoDigMap)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoDigMap));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->ds), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->ds[i]), sizeof(MgMgcoDigStr), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoDigStr(dst->ds[i], src->ds[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->ds[i], sizeof(MgMgcoDigStr));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoDigStr(dst->ds[i]);
         MGFREE(dst->ds[i], sizeof(MgMgcoDigStr));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->ds, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoDigMap*/

/*
*
*    Fun:    mgUtlCpyMgMgcoDigMapVal
*
*    Desc:    copy the structure MgMgcoDigMapVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoDigMapVal
(
MgMgcoDigMapVal *dst,
MgMgcoDigMapVal *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoDigMapVal(dst, src, mem)
MgMgcoDigMapVal *dst;
MgMgcoDigMapVal *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoDigMapVal)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoDigMapVal));

   if(dst->pres.pres != NOTPRSNT)
   {
#if defined(  GCP_VER_1_3)  && defined(  GCP_MGCO_PARSE_DIG_MAP) 
      if (mgUtlCpyTknStrOSXL(&dst->dm, &src->dm, mem) != ROK)
      {
         if (mem == NULLP)
         {
            mgUtlDelTknStrOSXL(&dst->dm);
            RETVALUE(RFAILED);
         }
      }
#else /*  defined(  GCP_VER_1_3)  && defined(  GCP_MGCO_PARSE_DIG_MAP)  */ 
      if (mgUtlCpyMgMgcoDigMap(&dst->dm, &src->dm, mem) != ROK)
      {
         if (mem == NULLP)
         {
            mgUtlDelMgMgcoDigMap(&dst->dm);
            RETVALUE(RFAILED);
         }
      }
#endif /*  defined(  GCP_VER_1_3)  && defined(  GCP_MGCO_PARSE_DIG_MAP)   */
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoDigMapVal*/

/*
*
*    Fun:    mgUtlCpyMgMgcoEvtDM
*
*    Desc:    copy the structure MgMgcoEvtDM
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEvtDM
(
MgMgcoEvtDM *dst,
MgMgcoEvtDM *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEvtDM(dst, src, mem)
MgMgcoEvtDM *dst;
MgMgcoEvtDM *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoEvtDM)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoEvtDM));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_DIGMAP_NAME :
            if (mgUtlCpyMgMgcoName(&dst->u.name, &src->u.name, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_DIGMAP_VAL :
            if (mgUtlCpyMgMgcoDigMapVal(&dst->u.val, &src->u.val, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoEvtDM*/

/*
*
*    Fun:    mgUtlCpyMgMgcoEvtParSec
*
*    Desc:    copy the structure MgMgcoEvtParSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEvtParSec
(
MgMgcoEvtParSec *dst,
MgMgcoEvtParSec *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEvtParSec(dst, src, mem)
MgMgcoEvtParSec *dst;
MgMgcoEvtParSec *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoEvtParSec)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoEvtParSec));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_EVTPAR_DIGMAP :
            if (mgUtlCpyMgMgcoEvtDM(&dst->u.dm, &src->u.dm, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_EMBEDWITHSIG :
            if (mgUtlCpyMgMgcoSignalsDesc(&dst->u.embSig, &src->u.embSig, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_KEEPACTIVE :
            break;
         case  MGT_EVTPAR_OTHER :
            if (mgUtlCpyMgMgcoEvtOther(&dst->u.other, &src->u.other, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_STREAMID :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoEvtParSec*/

/*
*
*    Fun:    mgUtlCpyMgMgcoEvtParSecLst
*
*    Desc:    copy the structure MgMgcoEvtParSecLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEvtParSecLst
(
MgMgcoEvtParSecLst *dst,
MgMgcoEvtParSecLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEvtParSecLst(dst, src, mem)
MgMgcoEvtParSecLst *dst;
MgMgcoEvtParSecLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoEvtParSecLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoEvtParSecLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->parms), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->parms[i]), sizeof(MgMgcoEvtParSec), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoEvtParSec(dst->parms[i], src->parms[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->parms[i], sizeof(MgMgcoEvtParSec));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoEvtParSec(dst->parms[i]);
         MGFREE(dst->parms[i], sizeof(MgMgcoEvtParSec));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoEvtParSecLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoEvtSec
*
*    Desc:    copy the structure MgMgcoEvtSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEvtSec
(
MgMgcoEvtSec *dst,
MgMgcoEvtSec *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEvtSec(dst, src, mem)
MgMgcoEvtSec *dst;
MgMgcoEvtSec *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoEvtSec)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoEvtSec));

   if (mgUtlCpyMgMgcoPkgdName(&dst->name, &src->name, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyMgMgcoEvtParSecLst(&dst->pl, &src->pl, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoPkgdName(&dst->name);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoEvtSec*/

/*
*
*    Fun:    mgUtlCpyMgMgcoEvtSecLst
*
*    Desc:    copy the structure MgMgcoEvtSecLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEvtSecLst
(
MgMgcoEvtSecLst *dst,
MgMgcoEvtSecLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEvtSecLst(dst, src, mem)
MgMgcoEvtSecLst *dst;
MgMgcoEvtSecLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoEvtSecLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoEvtSecLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->evts), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->evts[i]), sizeof(MgMgcoEvtSec), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoEvtSec(dst->evts[i], src->evts[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->evts[i], sizeof(MgMgcoEvtSec));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoEvtSec(dst->evts[i]);
         MGFREE(dst->evts[i], sizeof(MgMgcoEvtSec));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->evts, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoEvtSecLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoEmbedFirst
*
*    Desc:    copy the structure MgMgcoEmbedFirst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEmbedFirst
(
MgMgcoEmbedFirst *dst,
MgMgcoEmbedFirst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEmbedFirst(dst, src, mem)
MgMgcoEmbedFirst *dst;
MgMgcoEmbedFirst *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoEmbedFirst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoEmbedFirst));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoEvtSecLst(&dst->sl, &src->sl, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoEmbedFirst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoEmbWithSig
*
*    Desc:    copy the structure MgMgcoEmbWithSig
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEmbWithSig
(
MgMgcoEmbWithSig *dst,
MgMgcoEmbWithSig *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEmbWithSig(dst, src, mem)
MgMgcoEmbWithSig *dst;
MgMgcoEmbWithSig *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoEmbWithSig)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoEmbWithSig));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoSignalsDesc(&dst->sig, &src->sig, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoEmbedFirst(&dst->emb, &src->emb, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoSignalsDesc(&dst->sig);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoEmbWithSig*/

/*
*
*    Fun:    mgUtlCpyMgMgcoEvtPar
*
*    Desc:    copy the structure MgMgcoEvtPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEvtPar
(
MgMgcoEvtPar *dst,
MgMgcoEvtPar *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEvtPar(dst, src, mem)
MgMgcoEvtPar *dst;
MgMgcoEvtPar *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoEvtPar)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoEvtPar));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_EVTPAR_DIGMAP :
            if (mgUtlCpyMgMgcoEvtDM(&dst->u.dm, &src->u.dm, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_EMBEDNOSIG :
            if (mgUtlCpyMgMgcoEmbedFirst(&dst->u.embNoSig, &src->u.embNoSig, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_EMBEDWITHSIG :
            if (mgUtlCpyMgMgcoEmbWithSig(&dst->u.embWithSig, &src->u.embWithSig, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_KEEPACTIVE :
            break;
         case  MGT_EVTPAR_OTHER :
            if (mgUtlCpyMgMgcoEvtOther(&dst->u.other, &src->u.other, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_STREAMID :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoEvtPar*/
/* MILESTONE_6 */

/*
*
*    Fun:    mgUtlCpyMgMgcoEmbEvtPar
*
*    Desc:    copy the structure MgMgcoEvtPar from MgMgcoEvtParSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEmbEvtPar
(
MgMgcoEvtPar      *dst,
MgMgcoEvtParSec   *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEmbEvtPar(dst, src, mem)
MgMgcoEvtPar      *dst;
MgMgcoEvtParSec   *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoEmbEvtPar)

   cmMemcpy((U8 *)(&dst->type), (U8 *)(&src->type), sizeof(TknU8));

   if( src->type.pres != NOTPRSNT )
   {
      switch( src->type.val )
      {
         case  MGT_EVTPAR_DIGMAP :
            if (mgUtlCpyMgMgcoEvtDM(&dst->u.dm, &src->u.dm, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_EMBEDWITHSIG :
            /* Copy embSig into embWithSig */
            /* Assuming that structure has been memset to 0 */
            dst->u.embWithSig.pres.pres = PRSNT_NODEF;
            if (mgUtlCpyMgMgcoSignalsDesc(&dst->u.embWithSig.sig, &src->u.embSig,
                     mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_KEEPACTIVE :
            break;
         case  MGT_EVTPAR_OTHER :
            if (mgUtlCpyMgMgcoEvtOther(&dst->u.other, &src->u.other, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_STREAMID :
            break;
         case  MGT_EVTPAR_EMBEDNOSIG :
            /*-- This is an error scenario as this is an embedded event --*/
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlCpyMgMgcoEmbEvtPar*/

/*
*
*    Fun:    mgUtlCpyMgMgcoEvtParLst
*
*    Desc:    copy the structure MgMgcoEvtParLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEvtParLst
(
MgMgcoEvtParLst *dst,
MgMgcoEvtParLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEvtParLst(dst, src, mem)
MgMgcoEvtParLst *dst;
MgMgcoEvtParLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoEvtParLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoEvtParLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->parms), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->parms[i]), sizeof(MgMgcoEvtPar), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoEvtPar(dst->parms[i], src->parms[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->parms[i], sizeof(MgMgcoEvtPar));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoEvtPar(dst->parms[i]);
         MGFREE(dst->parms[i], sizeof(MgMgcoEvtPar));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoEvtParLst*/
/* MILESTONE_6 */

/*
*
*    Fun:    mgUtlCpyMgMgcoEmbEvtParLst
*
*    Desc:    copy the structure MgMgcoEvtParLst from MgMgcoEvtParSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEmbEvtParLst
(
MgMgcoEvtParLst      *dst,
MgMgcoEvtParSecLst   *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEmbEvtParLst(dst, src, mem)
MgMgcoEvtParLst      *dst;
MgMgcoEvtParSecLst   *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoEmbEvtParLst)

   cmMemcpy((U8 *)&dst->num, (U8 *)&src->num, sizeof(TknU16));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->parms), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->parms[i]), sizeof(MgMgcoEvtPar), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoEmbEvtPar(dst->parms[i], src->parms[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->parms[i], sizeof(MgMgcoEvtPar));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoEvtPar(dst->parms[i]);
         MGFREE(dst->parms[i], sizeof(MgMgcoEvtPar));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function mgUtlCpyMgMgcoEmbEvtParLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoReqEvt
*
*    Desc:    copy the structure MgMgcoReqEvt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoReqEvt
(
MgMgcoReqEvt *dst,
MgMgcoReqEvt *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoReqEvt(dst, src, mem)
MgMgcoReqEvt *dst;
MgMgcoReqEvt *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoReqEvt)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoReqEvt));

   if (mgUtlCpyMgMgcoPkgdName(&dst->name, &src->name, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyMgMgcoEvtParLst(&dst->pl, &src->pl, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoPkgdName(&dst->name);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoReqEvt*/
/* MILESTONE_6 */

/*
*
*    Fun:    mgUtlCpyMgMgcoEmbEvt
*
*    Desc:    copy the structure MgMgcoReqEvt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEmbEvt
(
MgMgcoReqEvt   *dst,
MgMgcoEvtSec   *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEmbEvt(dst, src, mem)
MgMgcoReqEvt   *dst;
MgMgcoEvtSec   *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoEmbEvt)

   cmMemcpy((U8 *)&dst->pkg, (U8 *)&src->pkg, sizeof(TknU8));

   if (mgUtlCpyMgMgcoPkgdName(&dst->name, &src->name, mem) != ROK)
      goto soCpyErr0;

   if (mgUtlCpyMgMgcoEmbEvtParLst(&dst->pl, &src->pl, mem) != ROK)
      goto soCpyErr1;

   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoPkgdName(&dst->name);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function mgUtlCpyMgMgcoEmbEvt*/

/*
*
*    Fun:    mgUtlCpyMgMgcoEvtLst
*
*    Desc:    copy the structure MgMgcoEvtLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEvtLst
(
MgMgcoEvtLst *dst,
MgMgcoEvtLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEvtLst(dst, src, mem)
MgMgcoEvtLst *dst;
MgMgcoEvtLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoEvtLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoEvtLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->revts), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->revts[i]), sizeof(MgMgcoReqEvt), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoReqEvt(dst->revts[i], src->revts[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->revts[i], sizeof(MgMgcoReqEvt));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoReqEvt(dst->revts[i]);
         MGFREE(dst->revts[i], sizeof(MgMgcoReqEvt));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->revts, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoEvtLst*/

/* MILESTONE_6 */
/*
*
*    Fun:    mgUtlCpyMgMgcoEmbEvtLst
*
*    Desc:    copy the structure MgMgcoEvtLst from MgMgcoEvtSecLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEmbEvtLst
(
MgMgcoEvtLst      *dst,
MgMgcoEvtSecLst   *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEmbEvtLst(dst, src, mem)
MgMgcoEvtLst      *dst;
MgMgcoEvtSecLst   *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoEmbEvtLst)

   cmMemcpy((U8 *)&dst->num, (U8 *)&src->num, sizeof(TknU16));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->revts), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->revts[i]), sizeof(MgMgcoReqEvt), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoEmbEvt(dst->revts[i], src->evts[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->revts[i], sizeof(MgMgcoReqEvt));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoReqEvt(dst->revts[i]);
         MGFREE(dst->revts[i], sizeof(MgMgcoReqEvt));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->revts, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function mgUtlCpyMgMgcoEmbEvtLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoReqEvtDesc
*
*    Desc:    copy the structure MgMgcoReqEvtDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoReqEvtDesc
(
MgMgcoReqEvtDesc *dst,
MgMgcoReqEvtDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoReqEvtDesc(dst, src, mem)
MgMgcoReqEvtDesc *dst;
MgMgcoReqEvtDesc *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoReqEvtDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoReqEvtDesc));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoEvtLst(&dst->el, &src->el, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoReqEvtDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoEvBufDesc
*
*    Desc:    copy the structure MgMgcoEvBufDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoEvBufDesc
(
MgMgcoEvBufDesc *dst,
MgMgcoEvBufDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoEvBufDesc(dst, src, mem)
MgMgcoEvBufDesc *dst;
MgMgcoEvBufDesc *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoEvBufDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoEvBufDesc));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->evts), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->evts[i]), sizeof(MgMgcoReqEvt), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoReqEvt(dst->evts[i], src->evts[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->evts[i], sizeof(MgMgcoReqEvt));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoReqEvt(dst->evts[i]);
         MGFREE(dst->evts[i], sizeof(MgMgcoReqEvt));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->evts, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoEvBufDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoDigMapDesc
*
*    Desc:    copy the structure MgMgcoDigMapDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoDigMapDesc
(
MgMgcoDigMapDesc *dst,
MgMgcoDigMapDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoDigMapDesc(dst, src, mem)
MgMgcoDigMapDesc *dst;
MgMgcoDigMapDesc *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoDigMapDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoDigMapDesc));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoName(&dst->name, &src->name, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoDigMapVal(&dst->val, &src->val, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoName(&dst->name);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoDigMapDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoAuditDesc
*
*    Desc:    copy the structure MgMgcoAuditDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoAuditDesc
(
MgMgcoAuditDesc *dst,
MgMgcoAuditDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoAuditDesc(dst, src, mem)
MgMgcoAuditDesc *dst;
MgMgcoAuditDesc *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoAuditDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoAuditDesc));

   if(dst->pres.pres != NOTPRSNT)
   {
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoAuditDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoAmmDesc
*
*    Desc:    copy the structure MgMgcoAmmDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoAmmDesc
(
MgMgcoAmmDesc *dst,
MgMgcoAmmDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoAmmDesc(dst, src, mem)
MgMgcoAmmDesc *dst;
MgMgcoAmmDesc *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoAmmDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoAmmDesc));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_AUDITDESC :
            if (mgUtlCpyMgMgcoAuditDesc(&dst->u.audit, &src->u.audit, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_DIGMAPDESC :
            if (mgUtlCpyMgMgcoDigMapDesc(&dst->u.dm, &src->u.dm, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVBUFDESC :
            if (mgUtlCpyMgMgcoEvBufDesc(&dst->u.evBuf, &src->u.evBuf, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MEDIADESC :
            if (mgUtlCpyMgMgcoMediaDesc(&dst->u.media, &src->u.media, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MODEMDESC :
            if (mgUtlCpyMgMgcoModemDesc(&dst->u.modem, &src->u.modem, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MUXDESC :
            if (mgUtlCpyMgMgcoMuxDesc(&dst->u.mux, &src->u.mux, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_REQEVTDESC :
            if (mgUtlCpyMgMgcoReqEvtDesc(&dst->u.evts, &src->u.evts, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SIGNALSDESC :
            if (mgUtlCpyMgMgcoSignalsDesc(&dst->u.sig, &src->u.sig, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoAmmDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoAmmDescLst
*
*    Desc:    copy the structure MgMgcoAmmDescLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoAmmDescLst
(
MgMgcoAmmDescLst *dst,
MgMgcoAmmDescLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoAmmDescLst(dst, src, mem)
MgMgcoAmmDescLst *dst;
MgMgcoAmmDescLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoAmmDescLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoAmmDescLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->descs), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->descs[i]), sizeof(MgMgcoAmmDesc), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoAmmDesc(dst->descs[i], src->descs[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->descs[i], sizeof(MgMgcoAmmDesc));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoAmmDesc(dst->descs[i]);
         MGFREE(dst->descs[i], sizeof(MgMgcoAmmDesc));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->descs, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoAmmDescLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoAmmReq
*
*    Desc:    copy the structure MgMgcoAmmReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoAmmReq
(
MgMgcoAmmReq *dst,
MgMgcoAmmReq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoAmmReq(dst, src, mem)
MgMgcoAmmReq *dst;
MgMgcoAmmReq *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoAmmReq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoAmmReq));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoTermId(&dst->termId, &src->termId, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoAmmDescLst(&dst->dl, &src->dl, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoTermId(&dst->termId);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoAmmReq*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSubAudReq
*
*    Desc:    copy the structure MgMgcoSubAudReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSubAudReq
(
MgMgcoSubAudReq *dst,
MgMgcoSubAudReq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSubAudReq(dst, src, mem)
MgMgcoSubAudReq *dst;
MgMgcoSubAudReq *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSubAudReq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSubAudReq));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoTermId(&dst->termId, &src->termId, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoAuditDesc(&dst->audit, &src->audit, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoTermId(&dst->termId);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoSubAudReq*/

/*
*
*    Fun:    mgUtlCpyMgMgcoObsEvt
*
*    Desc:    copy the structure MgMgcoObsEvt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoObsEvt
(
MgMgcoObsEvt *dst,
MgMgcoObsEvt *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoObsEvt(dst, src, mem)
MgMgcoObsEvt *dst;
MgMgcoObsEvt *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoObsEvt)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoObsEvt));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoPkgdName(&dst->name, &src->name, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoEvtParLst(&dst->pl, &src->pl, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoPkgdName(&dst->name);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoObsEvt*/

/*
*
*    Fun:    mgUtlCpyMgMgcoObsEvtLst
*
*    Desc:    copy the structure MgMgcoObsEvtLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoObsEvtLst
(
MgMgcoObsEvtLst *dst,
MgMgcoObsEvtLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoObsEvtLst(dst, src, mem)
MgMgcoObsEvtLst *dst;
MgMgcoObsEvtLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoObsEvtLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoObsEvtLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->evts), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->evts[i]), sizeof(MgMgcoObsEvt), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoObsEvt(dst->evts[i], src->evts[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->evts[i], sizeof(MgMgcoObsEvt));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoObsEvt(dst->evts[i]);
         MGFREE(dst->evts[i], sizeof(MgMgcoObsEvt));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->evts, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoObsEvtLst*/

/*
*
*    Fun:    mgUtlCpyMgMgcoObsEvtDesc
*
*    Desc:    copy the structure MgMgcoObsEvtDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoObsEvtDesc
(
MgMgcoObsEvtDesc *dst,
MgMgcoObsEvtDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoObsEvtDesc(dst, src, mem)
MgMgcoObsEvtDesc *dst;
MgMgcoObsEvtDesc *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoObsEvtDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoObsEvtDesc));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoObsEvtLst(&dst->el, &src->el, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoObsEvtDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoNtfyReq
*
*    Desc:    copy the structure MgMgcoNtfyReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoNtfyReq
(
MgMgcoNtfyReq *dst,
MgMgcoNtfyReq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoNtfyReq(dst, src, mem)
MgMgcoNtfyReq *dst;
MgMgcoNtfyReq *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoNtfyReq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoNtfyReq));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoTermId(&dst->termId, &src->termId, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoObsEvtDesc(&dst->obs, &src->obs, mem) != ROK)
         goto soCpyErr1;
      if (mgUtlCpyMgMgcoErrDesc(&dst->err, &src->err, mem) != ROK)
         goto soCpyErr2;
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoObsEvtDesc(&dst->obs);
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoTermId(&dst->termId);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoNtfyReq*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSvcChgMethod
*
*    Desc:    copy the structure MgMgcoSvcChgMethod
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSvcChgMethod
(
MgMgcoSvcChgMethod *dst,
MgMgcoSvcChgMethod *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSvcChgMethod(dst, src, mem)
MgMgcoSvcChgMethod *dst;
MgMgcoSvcChgMethod *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSvcChgMethod)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSvcChgMethod));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoNonStdId(&dst->extn, &src->extn, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoSvcChgMethod*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSvcChgProf
*
*    Desc:    copy the structure MgMgcoSvcChgProf
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSvcChgProf
(
MgMgcoSvcChgProf *dst,
MgMgcoSvcChgProf *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSvcChgProf(dst, src, mem)
MgMgcoSvcChgProf *dst;
MgMgcoSvcChgProf *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSvcChgProf)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSvcChgProf));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoName(&dst->name, &src->name, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoSvcChgProf*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSvcChgPar
*
*    Desc:    copy the structure MgMgcoSvcChgPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSvcChgPar
(
MgMgcoSvcChgPar *dst,
MgMgcoSvcChgPar *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSvcChgPar(dst, src, mem)
MgMgcoSvcChgPar *dst;
MgMgcoSvcChgPar *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSvcChgPar)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSvcChgPar));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoNonStdExtn(&dst->extn, &src->extn, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoSvcChgMethod(&dst->meth, &src->meth, mem) != ROK)
         goto soCpyErr1;
      if (mgUtlCpyMgMgcoMid(&dst->addr, &src->addr, mem) != ROK)
         goto soCpyErr2;
      if (mgUtlCpyMgMgcoSvcChgProf(&dst->prof, &src->prof, mem) != ROK)
         goto soCpyErr3;
      if (mgUtlCpyTknStrOSXL(&dst->reason, &src->reason, mem) != ROK)
         goto soCpyErr4;
      if (mgUtlCpyMgMgcoMid(&dst->mgcId, &src->mgcId, mem) != ROK)
         goto soCpyErr5;
#ifdef MGT_MGCO_V2
      if (mgUtlCpyMgMgcoAuditItem(&dst->auditItem, &src->auditItem, mem) != ROK)
         goto soCpyErr6;
#endif /*  MGT_MGCO_V2  */
   }
   RETVALUE(ROK);
soCpyErr6 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoMid(&dst->mgcId);
   }
soCpyErr5 :
   if (mem == NULLP)
   {
      mgUtlDelTknStrOSXL(&dst->reason);
   }
soCpyErr4 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoSvcChgProf(&dst->prof);
   }
soCpyErr3 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoMid(&dst->addr);
   }
soCpyErr2 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoSvcChgMethod(&dst->meth);
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoNonStdExtn(&dst->extn);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoSvcChgPar*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSvcChgReq
*
*    Desc:    copy the structure MgMgcoSvcChgReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSvcChgReq
(
MgMgcoSvcChgReq *dst,
MgMgcoSvcChgReq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSvcChgReq(dst, src, mem)
MgMgcoSvcChgReq *dst;
MgMgcoSvcChgReq *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSvcChgReq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSvcChgReq));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoTermId(&dst->termId, &src->termId, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoSvcChgPar(&dst->parm, &src->parm, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoTermId(&dst->termId);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoSvcChgReq*/

/*
*
*    Fun:    mgUtlCpyMgMgcoCmd
*
*    Desc:    copy the structure MgMgcoCmd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoCmd
(
MgMgcoCmd *dst,
MgMgcoCmd *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoCmd(dst, src, mem)
MgMgcoCmd *dst;
MgMgcoCmd *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoCmd)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoCmd));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_ADD :
            if (mgUtlCpyMgMgcoAmmReq(&dst->u.add, &src->u.add, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_AUDITCAP :
            if (mgUtlCpyMgMgcoSubAudReq(&dst->u.acap, &src->u.acap, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_AUDITVAL :
            if (mgUtlCpyMgMgcoSubAudReq(&dst->u.aval, &src->u.aval, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MODIFY :
            if (mgUtlCpyMgMgcoAmmReq(&dst->u.mod, &src->u.mod, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MOVE :
            if (mgUtlCpyMgMgcoAmmReq(&dst->u.move, &src->u.move, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_NTFY :
            if (mgUtlCpyMgMgcoNtfyReq(&dst->u.ntfy, &src->u.ntfy, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SUB :
            if (mgUtlCpyMgMgcoSubAudReq(&dst->u.sub, &src->u.sub, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SVCCHG :
            if (mgUtlCpyMgMgcoSvcChgReq(&dst->u.svc, &src->u.svc, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoCmd*/
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlCpyMgMgcoCommandReq
*
*    Desc:    copy the structure MgMgcoCommandReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoCommandReq
(
MgMgcoCommandReq *dst,
MgMgcoCommandReq *src
)
#else
PUBLIC S16 mgUtlCpyMgMgcoCommandReq(dst, src)
MgMgcoCommandReq *dst;
MgMgcoCommandReq *src;
#endif
{

   TRC3(mgUtlCpyMgMgcoCommandReq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoCommandReq));

   if(dst->pres.pres != NOTPRSNT)
   {
      /* if (mgUtlCpyMgMgcoCmd(&dst->cmd, &src->cmd, mem) != ROK) */
      if (mgUtlCpyMgMgcoCmd(&dst->cmd, &src->cmd, NULLP) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoCommandReq*/
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoCommandReq
*
*    Desc:    copy the structure MgMgcoCommandReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoCommandReq
(
MgMgcoCommandReq *dst,
MgMgcoCommandReq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoCommandReq(dst, src, mem)
MgMgcoCommandReq *dst;
MgMgcoCommandReq *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoCommandReq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoCommandReq));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoCmd(&dst->cmd, &src->cmd, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoCommandReq*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlCpyMgMgcoActionReq
*
*    Desc:    copy the structure MgMgcoActionReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoActionReq
(
MgMgcoActionReq *dst,
MgMgcoActionReq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoActionReq(dst, src, mem)
MgMgcoActionReq *dst;
MgMgcoActionReq *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoActionReq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoActionReq));

   if (mgUtlCpyMgMgcoContextProps(&dst->cxtProps, &src->cxtProps, mem) != ROK)
      goto soCpyErr0;
   /* if (mgUtlCpyMgMgcoCmdReqLst(&dst->cl, &src->cl, mem) != ROK) */
      /* goto soCpyErr1; */
   RETVALUE(ROK);
/* soCpyErr1 : */
   /* if (mem == NULLP) */
   /* { */
      /* mgUtlDelMgMgcoContextProps(&dst->cxtProps); */
   /* } */
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoActionReq*/
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoActionReq
*
*    Desc:    copy the structure MgMgcoActionReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoActionReq
(
MgMgcoActionReq *dst,
MgMgcoActionReq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoActionReq(dst, src, mem)
MgMgcoActionReq *dst;
MgMgcoActionReq *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoActionReq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoActionReq));

   if (mgUtlCpyMgMgcoContextProps(&dst->cxtProps, &src->cxtProps, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyMgMgcoCmdReqLst(&dst->cl, &src->cl, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoContextProps(&dst->cxtProps);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoActionReq*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlCpyMgMgcoActionLst
*
*    Desc:    copy the structure MgMgcoActionLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoActionLst
(
MgMgcoActionLst *dst,
MgMgcoActionLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoActionLst(dst, src, mem)
MgMgcoActionLst *dst;
MgMgcoActionLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoActionLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoActionLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->actns), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->actns[i]), sizeof(MgMgcoActionReq), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoActionReq(dst->actns[i], src->actns[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->actns[i], sizeof(MgMgcoActionReq));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoActionReq(dst->actns[i]);
         MGFREE(dst->actns[i], sizeof(MgMgcoActionReq));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->actns, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoActionLst*/
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoActionLst
*
*    Desc:    copy the structure MgMgcoActionLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoActionLst
(
MgMgcoActionLst *dst,
MgMgcoActionLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoActionLst(dst, src, mem)
MgMgcoActionLst *dst;
MgMgcoActionLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoActionLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoActionLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->actns), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->actns[i]), sizeof(MgMgcoActionReq), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoActionReq(dst->actns[i], src->actns[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->actns[i], sizeof(MgMgcoActionReq));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoActionReq(dst->actns[i]);
         MGFREE(dst->actns[i], sizeof(MgMgcoActionReq));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->actns, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoActionLst*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlCpyMgMgcoTxnReq
*
*    Desc:    copy the structure MgMgcoTxnReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTxnReq
(
MgMgcoTxnReq *dst,
MgMgcoTxnReq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTxnReq(dst, src, mem)
MgMgcoTxnReq *dst;
MgMgcoTxnReq *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoTxnReq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTxnReq));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoActionLst(&dst->al, &src->al, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoTxnReq*/
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoTxnReq
*
*    Desc:    copy the structure MgMgcoTxnReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTxnReq
(
MgMgcoTxnReq *dst,
MgMgcoTxnReq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTxnReq(dst, src, mem)
MgMgcoTxnReq *dst;
MgMgcoTxnReq *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoTxnReq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTxnReq));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoActionLst(&dst->al, &src->al, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoTxnReq*/
#endif

/*
*
*    Fun:    mgUtlCpyMgMgcoStatsPar
*
*    Desc:    copy the structure MgMgcoStatsPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoStatsPar
(
MgMgcoStatsPar *dst,
MgMgcoStatsPar *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoStatsPar(dst, src, mem)
MgMgcoStatsPar *dst;
MgMgcoStatsPar *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoStatsPar)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoStatsPar));

   if (mgUtlCpyMgMgcoPkgdName(&dst->name, &src->name, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyMgMgcoValue(&dst->val, &src->val, mem) != ROK)
      goto soCpyErr1;
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoPkgdName(&dst->name);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoStatsPar*/

/*
*
*    Fun:    mgUtlCpyMgMgcoStatsDesc
*
*    Desc:    copy the structure MgMgcoStatsDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoStatsDesc
(
MgMgcoStatsDesc *dst,
MgMgcoStatsDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoStatsDesc(dst, src, mem)
MgMgcoStatsDesc *dst;
MgMgcoStatsDesc *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoStatsDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoStatsDesc));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->parms), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->parms[i]), sizeof(MgMgcoStatsPar), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoStatsPar(dst->parms[i], src->parms[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->parms[i], sizeof(MgMgcoStatsPar));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoStatsPar(dst->parms[i]);
         MGFREE(dst->parms[i], sizeof(MgMgcoStatsPar));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoStatsDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoPkgsItem
*
*    Desc:    copy the structure MgMgcoPkgsItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoPkgsItem
(
MgMgcoPkgsItem *dst,
MgMgcoPkgsItem *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoPkgsItem(dst, src, mem)
MgMgcoPkgsItem *dst;
MgMgcoPkgsItem *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoPkgsItem)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoPkgsItem));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoName(&dst->name, &src->name, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoPkgsItem*/

/*
*
*    Fun:    mgUtlCpyMgMgcoPkgsDesc
*
*    Desc:    copy the structure MgMgcoPkgsDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoPkgsDesc
(
MgMgcoPkgsDesc *dst,
MgMgcoPkgsDesc *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoPkgsDesc(dst, src, mem)
MgMgcoPkgsDesc *dst;
MgMgcoPkgsDesc *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoPkgsDesc)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoPkgsDesc));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->items), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->items[i]), sizeof(MgMgcoPkgsItem), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoPkgsItem(dst->items[i], src->items[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->items[i], sizeof(MgMgcoPkgsItem));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoPkgsItem(dst->items[i]);
         MGFREE(dst->items[i], sizeof(MgMgcoPkgsItem));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->items, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoPkgsDesc*/

/*
*
*    Fun:    mgUtlCpyMgMgcoAudRetParm
*
*    Desc:    copy the structure MgMgcoAudRetParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoAudRetParm
(
MgMgcoAudRetParm *dst,
MgMgcoAudRetParm *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoAudRetParm(dst, src, mem)
MgMgcoAudRetParm *dst;
MgMgcoAudRetParm *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoAudRetParm)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoAudRetParm));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_AUDITDESC :
            break;
         case  MGT_DIGMAPDESC :
            if (mgUtlCpyMgMgcoDigMapDesc(&dst->u.dm, &src->u.dm, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_ERRDESC :
            if (mgUtlCpyMgMgcoErrDesc(&dst->u.err, &src->u.err, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVBUFDESC :
            if (mgUtlCpyMgMgcoEvBufDesc(&dst->u.evBuf, &src->u.evBuf, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MEDIADESC :
            if (mgUtlCpyMgMgcoMediaDesc(&dst->u.media, &src->u.media, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MODEMDESC :
            if (mgUtlCpyMgMgcoModemDesc(&dst->u.modem, &src->u.modem, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MUXDESC :
            if (mgUtlCpyMgMgcoMuxDesc(&dst->u.mux, &src->u.mux, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_OBSEVTDESC :
            if (mgUtlCpyMgMgcoObsEvtDesc(&dst->u.obs, &src->u.obs, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_PKGSDESC :
            if (mgUtlCpyMgMgcoPkgsDesc(&dst->u.pkgs, &src->u.pkgs, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_REQEVTDESC :
            if (mgUtlCpyMgMgcoReqEvtDesc(&dst->u.evts, &src->u.evts, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SIGNALSDESC :
            if (mgUtlCpyMgMgcoSignalsDesc(&dst->u.sig, &src->u.sig, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_STATSDESC :
            if (mgUtlCpyMgMgcoStatsDesc(&dst->u.stats, &src->u.stats, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoAudRetParm*/

/*
*
*    Fun:    mgUtlCpyMgMgcoTermAuditRes
*
*    Desc:    copy the structure MgMgcoTermAuditRes
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTermAuditRes
(
MgMgcoTermAuditRes *dst,
MgMgcoTermAuditRes *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTermAuditRes(dst, src, mem)
MgMgcoTermAuditRes *dst;
MgMgcoTermAuditRes *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoTermAuditRes)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTermAuditRes));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->parms), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->parms[i]), sizeof(MgMgcoAudRetParm), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoAudRetParm(dst->parms[i], src->parms[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->parms[i], sizeof(MgMgcoAudRetParm));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoAudRetParm(dst->parms[i]);
         MGFREE(dst->parms[i], sizeof(MgMgcoAudRetParm));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoTermAuditRes*/

/*
*
*    Fun:    mgUtlCpyMgMgcoAmmsReply
*
*    Desc:    copy the structure MgMgcoAmmsReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoAmmsReply
(
MgMgcoAmmsReply *dst,
MgMgcoAmmsReply *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoAmmsReply(dst, src, mem)
MgMgcoAmmsReply *dst;
MgMgcoAmmsReply *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoAmmsReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoAmmsReply));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoTermId(&dst->termId, &src->termId, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoTermAuditRes(&dst->audit, &src->audit, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoTermId(&dst->termId);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoAmmsReply*/

/*
*
*    Fun:    mgUtlCpyMgMgcoAuditOther
*
*    Desc:    copy the structure MgMgcoAuditOther
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoAuditOther
(
MgMgcoAuditOther *dst,
MgMgcoAuditOther *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoAuditOther(dst, src, mem)
MgMgcoAuditOther *dst;
MgMgcoAuditOther *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoAuditOther)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoAuditOther));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoTermId(&dst->termId, &src->termId, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoTermAuditRes(&dst->audit, &src->audit, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoTermId(&dst->termId);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoAuditOther*/

/*
*
*    Fun:    mgUtlCpyMgMgcoAuditReply
*
*    Desc:    copy the structure MgMgcoAuditReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoAuditReply
(
MgMgcoAuditReply *dst,
MgMgcoAuditReply *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoAuditReply(dst, src, mem)
MgMgcoAuditReply *dst;
MgMgcoAuditReply *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoAuditReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoAuditReply));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_CXTAUDIT :
            if (mgUtlCpyMgMgcoTermIdLst(&dst->u.cxt, &src->u.cxt, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_ERRDESC :
            if (mgUtlCpyMgMgcoErrDesc(&dst->u.err, &src->u.err, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TERMAUDIT :
            if (mgUtlCpyMgMgcoAuditOther(&dst->u.other, &src->u.other, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoAuditReply*/

/*
*
*    Fun:    mgUtlCpyMgMgcoNtfyReply
*
*    Desc:    copy the structure MgMgcoNtfyReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoNtfyReply
(
MgMgcoNtfyReply *dst,
MgMgcoNtfyReply *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoNtfyReply(dst, src, mem)
MgMgcoNtfyReply *dst;
MgMgcoNtfyReply *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoNtfyReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoNtfyReply));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoTermId(&dst->termId, &src->termId, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoErrDesc(&dst->err, &src->err, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoTermId(&dst->termId);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoNtfyReply*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSvcChgResPar
*
*    Desc:    copy the structure MgMgcoSvcChgResPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSvcChgResPar
(
MgMgcoSvcChgResPar *dst,
MgMgcoSvcChgResPar *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSvcChgResPar(dst, src, mem)
MgMgcoSvcChgResPar *dst;
MgMgcoSvcChgResPar *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSvcChgResPar)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSvcChgResPar));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoMid(&dst->addr, &src->addr, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoSvcChgProf(&dst->prof, &src->prof, mem) != ROK)
         goto soCpyErr1;
      if (mgUtlCpyMgMgcoMid(&dst->mgcId, &src->mgcId, mem) != ROK)
         goto soCpyErr2;
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoSvcChgProf(&dst->prof);
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoMid(&dst->addr);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoSvcChgResPar*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSvcChgRes
*
*    Desc:    copy the structure MgMgcoSvcChgRes
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSvcChgRes
(
MgMgcoSvcChgRes *dst,
MgMgcoSvcChgRes *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSvcChgRes(dst, src, mem)
MgMgcoSvcChgRes *dst;
MgMgcoSvcChgRes *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSvcChgRes)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSvcChgRes));

   if( ( dst->type.pres != NOTPRSNT )&& ( dst->type.pres != NOTPRSNT ))
   {
      switch( dst->type.val )
      {
         case  MGT_ERRDESC :
            if (mgUtlCpyMgMgcoErrDesc(&dst->u.err, &src->u.err, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SVCCHGDESC :
            if (mgUtlCpyMgMgcoSvcChgResPar(&dst->u.parm, &src->u.parm, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoSvcChgRes*/

/*
*
*    Fun:    mgUtlCpyMgMgcoSvcChgReply
*
*    Desc:    copy the structure MgMgcoSvcChgReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoSvcChgReply
(
MgMgcoSvcChgReply *dst,
MgMgcoSvcChgReply *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoSvcChgReply(dst, src, mem)
MgMgcoSvcChgReply *dst;
MgMgcoSvcChgReply *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoSvcChgReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoSvcChgReply));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoTermId(&dst->termId, &src->termId, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoSvcChgRes(&dst->res, &src->res, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoTermId(&dst->termId);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoSvcChgReply*/
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlCpyMgMgcoCmdReply
*
*    Desc:    copy the structure MgMgcoCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoCmdReply
(
MgMgcoCmdReply *dst,
MgMgcoCmdReply *src
)
#else
PUBLIC S16 mgUtlCpyMgMgcoCmdReply(dst, src)
MgMgcoCmdReply *dst;
MgMgcoCmdReply *src;
#endif
{
   CmMemListCp mem;

   TRC3(mgUtlCpyMgMgcoCmdReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoCmdReply));

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_ADD :
/* :03/14/05:22:47   */
               if (mgUtlCpyMgMgcoAmmsReply(&dst->u.add, &src->u.add, &mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_AUDITCAP :
               if (mgUtlCpyMgMgcoAuditReply(&dst->u.acap, &src->u.acap, &mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_AUDITVAL :
               if (mgUtlCpyMgMgcoAuditReply(&dst->u.aval, &src->u.aval, &mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_MODIFY :
               if (mgUtlCpyMgMgcoAmmsReply(&dst->u.mod, &src->u.mod, &mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_MOVE :
               if (mgUtlCpyMgMgcoAmmsReply(&dst->u.move, &src->u.move, &mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_NTFY :
               if (mgUtlCpyMgMgcoNtfyReply(&dst->u.ntfy, &src->u.ntfy, &mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_SUB :
               if (mgUtlCpyMgMgcoAmmsReply(&dst->u.sub, &src->u.sub, &mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_SVCCHG :
               if (mgUtlCpyMgMgcoSvcChgReply(&dst->u.svc, &src->u.svc, &mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoCmdReply*/
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoCmdReply
*
*    Desc:    copy the structure MgMgcoCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoCmdReply
(
MgMgcoCmdReply *dst,
MgMgcoCmdReply *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoCmdReply(dst, src, mem)
MgMgcoCmdReply *dst;
MgMgcoCmdReply *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoCmdReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoCmdReply));

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_ADD :
               if (mgUtlCpyMgMgcoAmmsReply(&dst->u.add, &src->u.add, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_AUDITCAP :
               if (mgUtlCpyMgMgcoAuditReply(&dst->u.acap, &src->u.acap, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_AUDITVAL :
               if (mgUtlCpyMgMgcoAuditReply(&dst->u.aval, &src->u.aval, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_MODIFY :
               if (mgUtlCpyMgMgcoAmmsReply(&dst->u.mod, &src->u.mod, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_MOVE :
               if (mgUtlCpyMgMgcoAmmsReply(&dst->u.move, &src->u.move, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_NTFY :
               if (mgUtlCpyMgMgcoNtfyReply(&dst->u.ntfy, &src->u.ntfy, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_SUB :
               if (mgUtlCpyMgMgcoAmmsReply(&dst->u.sub, &src->u.sub, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_SVCCHG :
               if (mgUtlCpyMgMgcoSvcChgReply(&dst->u.svc, &src->u.svc, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoCmdReply*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlCpyMgMgcoCmdReplyLst
*
*    Desc:    copy the structure MgMgcoCmdReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoCmdReplyLst
(
MgMgcoCmdReplyLst *dst,
MgMgcoCmdReplyLst *src,
CmMemListCp       *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoCmdReplyLst(dst, src, mem)
MgMgcoCmdReplyLst *dst;
MgMgcoCmdReplyLst *src;
CmMemListCp       *mem;
#endif
{
   RETVALUE(ROK);
}
#endif 
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlCpyMgMgcoCxtCmdReply
*
*    Desc:    copy the structure MgMgcoCxtCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoCxtCmdReply
(
MgMgcoCxtCmdReply *dst,
MgMgcoCxtCmdReply *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoCxtCmdReply(dst, src, mem)
MgMgcoCxtCmdReply *dst;
MgMgcoCxtCmdReply *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoCxtCmdReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoCxtCmdReply));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoContextProps(&dst->cxt, &src->cxt, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoCmdReplyLst(&dst->cl, &src->cl, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoContextProps(&dst->cxt);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoCxtCmdReply*/
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoCxtCmdReply
*
*    Desc:    copy the structure MgMgcoCxtCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoCxtCmdReply
(
MgMgcoCxtCmdReply *dst,
MgMgcoCxtCmdReply *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoCxtCmdReply(dst, src, mem)
MgMgcoCxtCmdReply *dst;
MgMgcoCxtCmdReply *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoCxtCmdReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoCxtCmdReply));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoContextProps(&dst->cxt, &src->cxt, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoCmdReplyLst(&dst->cl, &src->cl, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoContextProps(&dst->cxt);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoCxtCmdReply*/
#endif
#ifdef MGT_GCP_VER_1_4
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlCpyMgMgcoErrCmdRepSet
*
*    Desc:    copy the structure MgMgcoErrCmdRepSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoErrCmdRepSet
(
MgMgcoErrCmdRepSet *dst,
MgMgcoErrCmdRepSet *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoErrCmdRepSet(dst, src, mem)
MgMgcoErrCmdRepSet *dst;
MgMgcoErrCmdRepSet *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoErrCmdRepSet)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoErrCmdRepSet));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoErrDesc(&dst->err, &src->err, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoCxtCmdReply(&dst->reply, &src->reply, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoErrDesc(&dst->err);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoErrCmdRepSet*/
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoErrCmdRepSet
*
*    Desc:    copy the structure MgMgcoErrCmdRepSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoErrCmdRepSet
(
MgMgcoErrCmdRepSet *dst,
MgMgcoErrCmdRepSet *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoErrCmdRepSet(dst, src, mem)
MgMgcoErrCmdRepSet *dst;
MgMgcoErrCmdRepSet *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoErrCmdRepSet)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoErrCmdRepSet));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoErrDesc(&dst->err, &src->err, mem) != ROK)
         goto soCpyErr0;
      if (mgUtlCpyMgMgcoCxtCmdReply(&dst->reply, &src->reply, mem) != ROK)
         goto soCpyErr1;
   }
   RETVALUE(ROK);
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoErrDesc(&dst->err);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoErrCmdRepSet*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlCpyMgMgcoActnReply
*
*    Desc:    copy the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoActnReply
(
MgMgcoActnReply *dst,
MgMgcoActnReply *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoActnReply(dst, src, mem)
MgMgcoActnReply *dst;
MgMgcoActnReply *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoActnReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoActnReply));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoErrCmdRepSet(&dst->repErrSet, &src->repErrSet, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoActnReply*/
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoActnReply
*
*    Desc:    copy the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoActnReply
(
MgMgcoActnReply *dst,
MgMgcoActnReply *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoActnReply(dst, src, mem)
MgMgcoActnReply *dst;
MgMgcoActnReply *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoActnReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoActnReply));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoErrCmdRepSet(&dst->repErrSet, &src->repErrSet, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoActnReply*/
#endif
#else /* MGT_GCP_VER_1_4 */
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlCpyMgMgcoActnReply
*
*    Desc:    copy the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoActnReply
(
MgMgcoActnReply *dst,
MgMgcoActnReply *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoActnReply(dst, src, mem)
MgMgcoActnReply *dst;
MgMgcoActnReply *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoActnReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoActnReply));

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_CXTCMDREPLY :
               if (mgUtlCpyMgMgcoCxtCmdReply(&dst->u.reply, &src->u.reply, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_ERRDESC :
               if (mgUtlCpyMgMgcoErrDesc(&dst->u.err, &src->u.err, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoActnReply*/
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoActnReply
*
*    Desc:    copy the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoActnReply
(
MgMgcoActnReply *dst,
MgMgcoActnReply *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoActnReply(dst, src, mem)
MgMgcoActnReply *dst;
MgMgcoActnReply *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoActnReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoActnReply));

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_CXTCMDREPLY :
               if (mgUtlCpyMgMgcoCxtCmdReply(&dst->u.reply, &src->u.reply, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_ERRDESC :
               if (mgUtlCpyMgMgcoErrDesc(&dst->u.err, &src->u.err, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoActnReply*/
#endif
#endif /* MGT_GCP_VER_1_4 */
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlCpyMgMgcoActnReplyLst
*
*    Desc:    copy the structure MgMgcoActnReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoActnReplyLst
(
MgMgcoActnReplyLst *dst,
MgMgcoActnReplyLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoActnReplyLst(dst, src, mem)
MgMgcoActnReplyLst *dst;
MgMgcoActnReplyLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoActnReplyLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoActnReplyLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->repl), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->repl[i]), sizeof(MgMgcoActnReply), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoActnReply(dst->repl[i], src->repl[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->repl[i], sizeof(MgMgcoActnReply));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoActnReply(dst->repl[i]);
         MGFREE(dst->repl[i], sizeof(MgMgcoActnReply));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->repl, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoActnReplyLst*/
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoActnReplyLst
*
*    Desc:    copy the structure MgMgcoActnReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoActnReplyLst
(
MgMgcoActnReplyLst *dst,
MgMgcoActnReplyLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoActnReplyLst(dst, src, mem)
MgMgcoActnReplyLst *dst;
MgMgcoActnReplyLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(mgUtlCpyMgMgcoActnReplyLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoActnReplyLst));

   if( dst->num.pres != NOTPRSNT )
   {
      if (mgUtlCpyGetMem((Ptr*)&(dst->repl), sizeof(Ptr)*(dst->num.val), mem) != ROK)
         goto soCpyErr0;
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlCpyGetMem((Ptr*)&(dst->repl[i]), sizeof(MgMgcoActnReply), mem) != ROK)
            goto soCpyErr1;
         if (mgUtlCpyMgMgcoActnReply(dst->repl[i], src->repl[i], mem) != ROK)
            goto soCpyErr2;
      }
   }
   RETVALUE(ROK);
soCpyErr2 :
   if (mem == NULLP)
   {
      MGFREE(dst->repl[i], sizeof(MgMgcoActnReply));
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         mgUtlDelMgMgcoActnReply(dst->repl[i]);
         MGFREE(dst->repl[i], sizeof(MgMgcoActnReply));
      }
   }
   if (mem == NULLP)
   {
      MGFREE(dst->repl, sizeof(Ptr)*(dst->num.val));
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoActnReplyLst*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlCpyMgMgcoTxnReply
*
*    Desc:    copy the structure MgMgcoTxnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTxnReply
(
MgMgcoTxnReply *dst,
MgMgcoTxnReply *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTxnReply(dst, src, mem)
MgMgcoTxnReply *dst;
MgMgcoTxnReply *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoTxnReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTxnReply));

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_ACTIONREPLY :
               if (mgUtlCpyMgMgcoActnReplyLst(&dst->u.arl, &src->u.arl, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_ERRDESC :
               if (mgUtlCpyMgMgcoErrDesc(&dst->u.err, &src->u.err, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoTxnReply*/
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoTxnReply
*
*    Desc:    copy the structure MgMgcoTxnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTxnReply
(
MgMgcoTxnReply *dst,
MgMgcoTxnReply *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTxnReply(dst, src, mem)
MgMgcoTxnReply *dst;
MgMgcoTxnReply *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoTxnReply)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTxnReply));

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_ACTIONREPLY :
               if (mgUtlCpyMgMgcoActnReplyLst(&dst->u.arl, &src->u.arl, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_ERRDESC :
               if (mgUtlCpyMgMgcoErrDesc(&dst->u.err, &src->u.err, mem) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoTxnReply*/
#endif

/*
*
*    Fun:    mgUtlCpyMgMgcoTxnRspAck
*
*    Desc:    copy the structure MgMgcoTxnRspAck
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTxnRspAck
(
MgMgcoTxnRspAck *dst,
MgMgcoTxnRspAck *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTxnRspAck(dst, src, mem)
MgMgcoTxnRspAck *dst;
MgMgcoTxnRspAck *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoTxnRspAck)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTxnRspAck));

   if( dst->num.pres != NOTPRSNT )
   {
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoTxnRspAck*/
#ifdef GCP_VER_1_3
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlCpyMgMgcoTxn
*
*    Desc:    copy the structure MgMgcoTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTxn
(
MgMgcoTxn *dst,
MgMgcoTxn *src
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTxn(dst, src)
MgMgcoTxn *dst;
MgMgcoTxn *src;
#endif
{
   CmMemListCp mem;

   TRC3(mgUtlCpyMgMgcoTxn)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTxn));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_TXNLOCAL_ERR :
            break;
         case  MGT_TXNPEND :
            break;
         case  MGT_TXNREPLY :
/* :03/14/05:22:51   */
            if (mgUtlCpyMgMgcoTxnReply(&dst->u.reply, &src->u.reply, &mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXNREQ :
            if (mgUtlCpyMgMgcoTxnReq(&dst->u.req, &src->u.req, &mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXNRSPACK :
            if (mgUtlCpyMgMgcoTxnRspAck(&dst->u.rspAck, &src->u.rspAck, &mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
#if(  defined(  ZG_DFTHA)  || defined(  DG) ) 
#endif /*   defined(  ZG_DFTHA)  || defined(  DG) )   */
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoTxn*/
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoTxn
*
*    Desc:    copy the structure MgMgcoTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTxn
(
MgMgcoTxn *dst,
MgMgcoTxn *src
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTxn(dst, src)
MgMgcoTxn *dst;
MgMgcoTxn *src;
#endif
{
   S16 ret;
   CmMemListCp mem;

   TRC3(mgUtlCpyMgMgcoTxn)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTxn));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_TXNLOCAL_ERR :
            break;
         case  MGT_TXNPEND :
            break;
         case  MGT_TXNREPLY :
            if (mgUtlCpyMgMgcoTxnReply(&dst->u.reply, &src->u.reply, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXNREQ :
            if (mgUtlCpyMgMgcoTxnReq(&dst->u.req, &src->u.req, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXNRSPACK :
            if (mgUtlCpyMgMgcoTxnRspAck(&dst->u.rspAck, &src->u.rspAck, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
#if(  defined(  ZG_DFTHA)  || defined(  DG) ) 
#endif /*   defined(  ZG_DFTHA)  || defined(  DG) )   */
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoTxn*/
#endif
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoTxn
*
*    Desc:    copy the structure MgMgcoTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTxn
(
MgMgcoTxn *dst,
MgMgcoTxn *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTxn(dst, src, mem)
MgMgcoTxn *dst;
MgMgcoTxn *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoTxn)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoTxn));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_TXNLOCAL_ERR :
            break;
         case  MGT_TXNPEND :
            break;
         case  MGT_TXNREPLY :
            if (mgUtlCpyMgMgcoTxnReply(&dst->u.reply, &src->u.reply, &mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXNREQ :
            if (mgUtlCpyMgMgcoTxnReq(&dst->u.req, &src->u.req, &mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXNRSPACK :
            if (mgUtlCpyMgMgcoTxnRspAck(&dst->u.rspAck, &src->u.rspAck, &mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoTxn*/
#endif
#ifdef GCP_VER_1_3

/*
*
*    Fun:    mgUtlCpyMgMgcoTxnLst
*
*    Desc:    copy the structure MgMgcoTxnLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
/* :03/14/05:22:51   */
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTxnLst
(
MgMgcoTxnLst *dst,
MgMgcoTxnLst *src,
CmMemListCp  *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTxnLst(dst, src, mem)
MgMgcoTxnLst *dst;
MgMgcoTxnLst *src;
CmMemListCp  *mem;
#endif
{
   RETVALUE(ROK);
}

#else
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoTxnLst
(
MgMgcoTxnLst *dst,
MgMgcoTxnLst *src,
CmMemListCp  *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoTxnLst(dst, src, mem)
MgMgcoTxnLst *dst;
MgMgcoTxnLst *src;
CmMemListCp  *mem;
#endif
{
}


/*
*
*    Fun:    mgUtlCpyMgMgcoTxnLst
*
*    Desc:    copy the structure MgMgcoTxnLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
/* :03/14/05:22:52   */
 
#endif
#ifdef GCP_VER_1_3

/*
*
*    Fun:    mgUtlCpyMgMgcoMsgBody
*
*    Desc:    copy the structure MgMgcoMsgBody
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoMsgBody
(
MgMgcoMsgBody *dst,
MgMgcoMsgBody *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoMsgBody(dst, src, mem)
MgMgcoMsgBody *dst;
MgMgcoMsgBody *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoMsgBody)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoMsgBody));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_ERRDESC :
            if (mgUtlCpyMgMgcoErrDesc(&dst->u.err, &src->u.err, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXN :
            if (mgUtlCpyMgMgcoTxnLst(&dst->u.tl, &src->u.tl, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoMsgBody*/
#else

/*
*
*    Fun:    mgUtlCpyMgMgcoMsgBody
*
*    Desc:    copy the structure MgMgcoMsgBody
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoMsgBody
(
MgMgcoMsgBody *dst,
MgMgcoMsgBody *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoMsgBody(dst, src, mem)
MgMgcoMsgBody *dst;
MgMgcoMsgBody *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoMsgBody)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoMsgBody));

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_ERRDESC :
            if (mgUtlCpyMgMgcoErrDesc(&dst->u.err, &src->u.err, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXN :
            if (mgUtlCpyMgMgcoTxnLst(&dst->u.tl, &src->u.tl, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoMsgBody*/
#endif

/*
*
*    Fun:    mgUtlCpyMgMgcoMsg
*
*    Desc:    copy the structure MgMgcoMsg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoMsg
(
MgMgcoMsg *dst,
MgMgcoMsg *src
)
#else
PUBLIC S16 mgUtlCpyMgMgcoMsg(dst, src)
MgMgcoMsg *dst;
MgMgcoMsg *src;
#endif
{
/* :03/14/05:22:54   */
   CmMemListCp *mem;
/* Just leaving for now */

   TRC3(mgUtlCpyMgMgcoMsg)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoMsg));
/* :03/14/05:22:53  */
   if (mgUtlCpyMgMgcoAuthHdr(&dst->ah, &src->ah, mem) != ROK)
      goto soCpyErr0;
   if (mgUtlCpyTknStrOSXL(&dst->mid, &src->mid, mem) != ROK)
      goto soCpyErr1;
#ifdef GCP_VER_1_3
   if (mgUtlCpyMgMgcoMsgBody(&dst->body, &src->body, mem) != ROK)
      goto soCpyErr2;
#else /*  GCP_VER_1_3 */ 
   if (mgUtlCpyMgMgcoMsgBody(&dst->body, &src->body, mem) != ROK)
      goto soCpyErr3;
#endif /*  GCP_VER_1_3  */
#ifdef GCP_PROV_SCTP
#endif /*  GCP_PROV_SCTP  */
   RETVALUE(ROK);

soCpyErr2 :
   if (mem == NULLP)
   {
      mgUtlDelTknStrOSXL(&dst->mid);
   }
soCpyErr1 :
   if (mem == NULLP)
   {
      mgUtlDelMgMgcoAuthHdr(&dst->ah);
   }
soCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soCpyMgMgcoMsg*/
#if(  defined(  GCP_CH)  && defined(  GCP_VER_1_5) ) 

/*
*
*    Fun:    mgUtlCpyMgMgcoCommand
*
*    Desc:    copy the structure MgMgcoCommand
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
/* :03/14/05:22:55   */


/*
*
*    Fun:    mgUtlCpyMgMgcoChCntxt
*
*    Desc:    copy the structure MgMgcoChCntxt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoChCntxt
(
MgMgcoChCntxt *dst,
MgMgcoChCntxt *src,
CmMemListCp *mem
)
#else
PUBLIC S16 mgUtlCpyMgMgcoChCntxt(dst, src, mem)
MgMgcoChCntxt *dst;
MgMgcoChCntxt *src;
CmMemListCp *mem;
#endif
{

   TRC3(mgUtlCpyMgMgcoChCntxt)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoChCntxt));

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlCpyMgMgcoContextProps(&dst->cxtProps, &src->cxtProps, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoChCntxt*/

/*
*
*    Fun:    mgUtlCpyMgMgcoUpdateCntxt
*
*    Desc:    copy the structure MgMgcoUpdateCntxt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoUpdateCntxt
(
MgMgcoUpdateCntxt *dst,
MgMgcoUpdateCntxt *src
)
#else
PUBLIC S16 mgUtlCpyMgMgcoUpdateCntxt(dst, src)
MgMgcoUpdateCntxt *dst;
MgMgcoUpdateCntxt *src;
#endif
{
   CmMemListCp mem;

   TRC3(mgUtlCpyMgMgcoUpdateCntxt)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoUpdateCntxt));
/* :03/14/05:22:56  */
   if (mgUtlCpyMgMgcoChCntxt(&dst->contextProp, &src->contextProp, &mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoUpdateCntxt*/

/*
*
*    Fun:    mgUtlCpyMgMgcoInd
*
*    Desc:    copy the structure MgMgcoInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyMgMgcoInd
(
MgMgcoInd *dst,
MgMgcoInd *src
)
#else
PUBLIC S16 mgUtlCpyMgMgcoInd(dst, src)
MgMgcoInd *dst;
MgMgcoInd *src;
#endif
{
   CmMemListCp mem;

   TRC3(mgUtlCpyMgMgcoInd)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(MgMgcoInd));
/* :03/14/05:22:56  */
   if (mgUtlCpyMgMgcoErrDesc(&dst->err, &src->err, &mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soCpyMgMgcoInd*/
#endif /* GCP_CH && GCP_VER_1_5 */

#ifdef MGT_MGCO_V2

/*
*
*    Fun:    mgUtlDelMgMgcoIndAudStreamParm
*
*    Desc:    Delete the structure MgMgcoIndAudStreamParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoIndAudStreamParm
(
MgMgcoIndAudStreamParm *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoIndAudStreamParm(dst)
MgMgcoIndAudStreamParm *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoIndAudStreamParm)

   if (mgUtlDelMgMgcoPkgdName(&dst->name) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoIndAudStreamParm*/

/*
*
*    Fun:    mgUtlDelMgMgcoIndAudStreamDesc
*
*    Desc:    Delete the structure MgMgcoIndAudStreamDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoIndAudStreamDesc
(
MgMgcoIndAudStreamDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoIndAudStreamDesc(dst)
MgMgcoIndAudStreamDesc *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoIndAudStreamDesc)

   if (mgUtlDelMgMgcoIndAudStreamParm(&dst->streamParm) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoIndAudStreamDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoIndAudTermStateDesc
*
*    Desc:    Delete the structure MgMgcoIndAudTermStateDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoIndAudTermStateDesc
(
MgMgcoIndAudTermStateDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoIndAudTermStateDesc(dst)
MgMgcoIndAudTermStateDesc *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoIndAudTermStateDesc)

   if (mgUtlDelMgMgcoPkgdName(&dst->name) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoIndAudTermStateDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoIndAudMediaParm
*
*    Desc:    Delete the structure MgMgcoIndAudMediaParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoIndAudMediaParm
(
MgMgcoIndAudMediaParm *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoIndAudMediaParm(dst)
MgMgcoIndAudMediaParm *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoIndAudMediaParm)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_INDAUD_STPAR :
            if (mgUtlDelMgMgcoIndAudStreamParm(&dst->u.streamParm) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_STRDESC :
            if (mgUtlDelMgMgcoIndAudStreamDesc(&dst->u.streamDesc) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_TERSTDESC :
            if (mgUtlDelMgMgcoIndAudTermStateDesc(&dst->u.termStateDesc) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoIndAudMediaParm*/

/*
*
*    Fun:    mgUtlDelMgMgcoIndAudEvents
*
*    Desc:    Delete the structure MgMgcoIndAudEvents
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoIndAudEvents
(
MgMgcoIndAudEvents *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoIndAudEvents(dst)
MgMgcoIndAudEvents *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoIndAudEvents)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoPkgdName(&dst->name) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoIndAudEvents*/

/*
*
*    Fun:    mgUtlDelMgMgcoIndAudSigLst
*
*    Desc:    Delete the structure MgMgcoIndAudSigLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoIndAudSigLst
(
MgMgcoIndAudSigLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoIndAudSigLst(dst)
MgMgcoIndAudSigLst *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoIndAudSigLst)

   if (mgUtlDelMgMgcoSigName(&dst->sigName) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoIndAudSigLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoIndAudSignals
*
*    Desc:    Delete the structure MgMgcoIndAudSignals
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoIndAudSignals
(
MgMgcoIndAudSignals *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoIndAudSignals(dst)
MgMgcoIndAudSignals *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoIndAudSignals)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_INDAUD_SIGLST :
            if (mgUtlDelMgMgcoIndAudSigLst(&dst->u.sigList) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_SIGNAME :
            if (mgUtlDelMgMgcoSigName(&dst->u.sigName) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoIndAudSignals*/

/*
*
*    Fun:    mgUtlDelMgMgcoIndAudEventSpecParm
*
*    Desc:    Delete the structure MgMgcoIndAudEventSpecParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoIndAudEventSpecParm
(
MgMgcoIndAudEventSpecParm *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoIndAudEventSpecParm(dst)
MgMgcoIndAudEventSpecParm *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoIndAudEventSpecParm)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_INDAUD_EVPRM :
            if (mgUtlDelMgMgcoName(&dst->u.evParmName) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_EVSTREAM :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoIndAudEventSpecParm*/

/*
*
*    Fun:    mgUtlDelMgMgcoIndAudEventBuffer
*
*    Desc:    Delete the structure MgMgcoIndAudEventBuffer
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoIndAudEventBuffer
(
MgMgcoIndAudEventBuffer *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoIndAudEventBuffer(dst)
MgMgcoIndAudEventBuffer *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoIndAudEventBuffer)

   if (mgUtlDelMgMgcoPkgdName(&dst->name) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoIndAudEventSpecParm(&dst->evSpecParm) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoIndAudEventBuffer*/

/*
*
*    Fun:    mgUtlDelMgMgcoIndAudAuditRetParm
*
*    Desc:    Delete the structure MgMgcoIndAudAuditRetParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoIndAudAuditRetParm
(
MgMgcoIndAudAuditRetParm *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoIndAudAuditRetParm(dst)
MgMgcoIndAudAuditRetParm *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoIndAudAuditRetParm)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_INDAUD_AUDDIGITMAP :
            if (mgUtlDelMgMgcoName(&dst->u.audDigMap) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_AUDEVTBUF :
            if (mgUtlDelMgMgcoIndAudEventBuffer(&dst->u.audEvtBuf) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_AUDEVTS :
            if (mgUtlDelMgMgcoIndAudEvents(&dst->u.audEvents) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_AUDMEDIA :
            if (mgUtlDelMgMgcoIndAudMediaParm(&dst->u.audMedia) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_AUDPKG :
            if (mgUtlDelMgMgcoPkgsItem(&dst->u.audPkgs) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_AUDSIG :
            if (mgUtlDelMgMgcoIndAudSignals(&dst->u.audSignals) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_INDAUD_AUDSTAT :
            if (mgUtlDelMgMgcoSigName(&dst->u.audStats) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoIndAudAuditRetParm*/

/*
*
*    Fun:    mgUtlDelMgMgcoIndAudTermAudit
*
*    Desc:    Delete the structure MgMgcoIndAudTermAudit
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoIndAudTermAudit
(
MgMgcoIndAudTermAudit *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoIndAudTermAudit(dst)
MgMgcoIndAudTermAudit *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoIndAudTermAudit)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoIndAudAuditRetParm(dst->parm[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->parm[i], sizeof(MgMgcoIndAudAuditRetParm));
      }
      MGFREE(dst->parm, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoIndAudTermAudit*/
#endif /* MGT_MGCO_V2 */
#ifdef MGT_MGCO_V2

/*
*
*    Fun:    mgUtlDelMgMgcoAuditItem
*
*    Desc:    Delete the structure MgMgcoAuditItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoAuditItem
(
MgMgcoAuditItem *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoAuditItem(dst)
MgMgcoAuditItem *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoAuditItem)

   if (mgUtlDelMgMgcoIndAudTermAudit(&dst->termAudit) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoAuditItem*/
#else /* MGT_MGCO_V2 */
#endif /* MGT_MGCO_V2 */
#endif /* AG */

/*
*
*    Fun:    mgUtlDelMgMgcoPathName
*
*    Desc:    Delete the structure MgMgcoPathName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoPathName
(
MgMgcoPathName *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoPathName(dst)
MgMgcoPathName *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoPathName)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelTknStrOSXL(&dst->lcl) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelTknStrOSXL(&dst->dom) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoPathName*/


/*
*
*    Fun:    mgUtlDelMgMgcoTermId
*
*    Desc:    Delete the structure MgMgcoTermId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTermId
(
MgMgcoTermId *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTermId(dst)
MgMgcoTermId *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoTermId)

   if (mgUtlDelMgMgcoPathName(&dst->name) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTermId*/

/* mg008.105: moving unused function within AG compiler flag */
#ifdef AG

/*
*
*    Fun:    mgUtlDelMgMgcoTermIdLst
*
*    Desc:    Delete the structure MgMgcoTermIdLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTermIdLst
(
MgMgcoTermIdLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTermIdLst(dst)
MgMgcoTermIdLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoTermIdLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoTermId(dst->terms[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->terms[i], sizeof(MgMgcoTermId));
      }
      MGFREE(dst->terms, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTermIdLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoName
*
*    Desc:    Delete the structure MgMgcoName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoName
(
MgMgcoName *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoName(dst)
MgMgcoName *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoName)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_GEN_TYPE_ALL :
            break;
         case  MGT_GEN_TYPE_KNOWN :
            break;
         case  MGT_GEN_TYPE_UNKNOWN :
            if (mgUtlDelTknStrOSXL(&dst->u.str) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoName*/

/*
*
*    Fun:    mgUtlDelMgMgcoPkgdName
*
*    Desc:    Delete the structure MgMgcoPkgdName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoPkgdName
(
MgMgcoPkgdName *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoPkgdName(dst)
MgMgcoPkgdName *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoPkgdName)

   if (mgUtlDelTknStrOSXL(&dst->pkgName) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoName(&dst->name) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoPkgdName*/

/*
*
*    Fun:    mgUtlDelMgMgcoSigName
*
*    Desc:    Delete the structure MgMgcoSigName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSigName
(
MgMgcoSigName *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSigName(dst)
MgMgcoSigName *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSigName)

   if (mgUtlDelMgMgcoPkgdName(&dst->name) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSigName*/

/*
*
*    Fun:    mgUtlDelMgMgcoSigLst
*
*    Desc:    Delete the structure MgMgcoSigLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSigLst
(
MgMgcoSigLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSigLst(dst)
MgMgcoSigLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoSigLst)

   if( dst->numSigs.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numSigs.val;i++)
      {
         if (mgUtlDelMgMgcoSigName(dst->sigs[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->sigs[i], sizeof(MgMgcoSigName));
      }
      MGFREE(dst->sigs, sizeof(Ptr)*(dst->numSigs.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSigLst*/
#if(  defined(  GCP_PKG_MGCO_ADVAUSRVRBASE)  || defined(  GCP_PKG_MGCO_AASDIGCOLLECT)  || defined(  GCP_PKG_MGCO_AASRECODING)  || defined(  GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT) ) 

/*
*
*    Fun:    mgUtlDelMgMgcoFileUrl
*
*    Desc:    Delete the structure MgMgcoFileUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoFileUrl
(
MgMgcoFileUrl *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoFileUrl(dst)
MgMgcoFileUrl *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoFileUrl)

   if (mgUtlDelTknStrOSXL(&dst->host) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelTknStrOSXL(&dst->fpath) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoFileUrl*/

/*
*
*    Fun:    mgUtlDelMgMgcoHostPort
*
*    Desc:    Delete the structure MgMgcoHostPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoHostPort
(
MgMgcoHostPort *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoHostPort(dst)
MgMgcoHostPort *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoHostPort)

   if (mgUtlDelTknStrOSXL(&dst->host) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoHostPort*/

/*
*
*    Fun:    mgUtlDelMgMgcoUsrPw
*
*    Desc:    Delete the structure MgMgcoUsrPw
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoUsrPw
(
MgMgcoUsrPw *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoUsrPw(dst)
MgMgcoUsrPw *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoUsrPw)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelTknStrOSXL(&dst->user) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelTknStrOSXL(&dst->pswd) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoUsrPw*/

/*
*
*    Fun:    mgUtlDelMgMgcoLogin
*
*    Desc:    Delete the structure MgMgcoLogin
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoLogin
(
MgMgcoLogin *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoLogin(dst)
MgMgcoLogin *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoLogin)

   if (mgUtlDelMgMgcoUsrPw(&dst->usrPw) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoHostPort(&dst->hp) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoLogin*/

/*
*
*    Fun:    mgUtlDelMgMgcoPathType
*
*    Desc:    Delete the structure MgMgcoPathType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoPathType
(
MgMgcoPathType *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoPathType(dst)
MgMgcoPathType *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoPathType)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelTknStrOSXL(&dst->fpath) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoPathType*/

/*
*
*    Fun:    mgUtlDelMgMgcoFtpUrl
*
*    Desc:    Delete the structure MgMgcoFtpUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoFtpUrl
(
MgMgcoFtpUrl *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoFtpUrl(dst)
MgMgcoFtpUrl *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoFtpUrl)

   if (mgUtlDelMgMgcoLogin(&dst->login) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoPathType(&dst->patTyp) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoFtpUrl*/

/*
*
*    Fun:    mgUtlDelMgMgcoPathSearch
*
*    Desc:    Delete the structure MgMgcoPathSearch
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoPathSearch
(
MgMgcoPathSearch *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoPathSearch(dst)
MgMgcoPathSearch *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoPathSearch)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelTknStrOSXL(&dst->hpath) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelTknStrOSXL(&dst->search) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoPathSearch*/

/*
*
*    Fun:    mgUtlDelMgMgcoHttpUrl
*
*    Desc:    Delete the structure MgMgcoHttpUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoHttpUrl
(
MgMgcoHttpUrl *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoHttpUrl(dst)
MgMgcoHttpUrl *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoHttpUrl)

   if (mgUtlDelMgMgcoHostPort(&dst->hp) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoPathSearch(&dst->ps) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoHttpUrl*/

/*
*
*    Fun:    mgUtlDelMgMgcoProvSegSpec
*
*    Desc:    Delete the structure MgMgcoProvSegSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoProvSegSpec
(
MgMgcoProvSegSpec *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoProvSegSpec(dst)
MgMgcoProvSegSpec *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoProvSegSpec)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_MGCO_FILE_URL :
            if (mgUtlDelMgMgcoFileUrl(&dst->u.file) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_FTP_URL :
            if (mgUtlDelMgMgcoFtpUrl(&dst->u.ftp) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_HTTP_URL :
            if (mgUtlDelMgMgcoHttpUrl(&dst->u.http) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_SIMPLE :
            if (mgUtlDelTknStrOSXL(&dst->u.simple) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoProvSegSpec*/

/*
*
*    Fun:    mgUtlDelMgMgcoVvarSpec
*
*    Desc:    Delete the structure MgMgcoVvarSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoVvarSpec
(
MgMgcoVvarSpec *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoVvarSpec(dst)
MgMgcoVvarSpec *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoVvarSpec)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_MGCO_CHAR_SPEC :
            if (mgUtlDelTknStrOSXL(&dst->u.chr) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_DATE_SPEC :
            break;
         case  MGT_MGCO_DIG_SPEC :
            if (mgUtlDelTknStrOSXL(&dst->u.dig) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_DOW_SPEC :
            break;
         case  MGT_MGCO_DUR_SPEC :
            break;
         case  MGT_MGCO_HUSH_SPEC :
            break;
         case  MGT_MGCO_INT_SPEC :
            break;
         case  MGT_MGCO_MONEY_SPEC :
            break;
         case  MGT_MGCO_MONTH_SPEC :
            break;
         case  MGT_MGCO_PHRASE_SPEC :
            if (mgUtlDelTknStrOSXL(&dst->u.phrase) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_TOD_SPEC :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoVvarSpec*/

/*
*
*    Fun:    mgUtlDelMgMgcoSelType
*
*    Desc:    Delete the structure MgMgcoSelType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSelType
(
MgMgcoSelType *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSelType(dst)
MgMgcoSelType *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSelType)

   if (mgUtlDelTknStrOSXL(&dst->other) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSelType*/

/*
*
*    Fun:    mgUtlDelMgMgcoSelSpecLst
*
*    Desc:    Delete the structure MgMgcoSelSpecLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSelSpecLst
(
MgMgcoSelSpecLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSelSpecLst(dst)
MgMgcoSelSpecLst *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSelSpecLst)

   if (mgUtlDelMgMgcoSelType(&dst->type) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelTknStrOSXL(&dst->val) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSelSpecLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoSelList
*
*    Desc:    Delete the structure MgMgcoSelList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSelList
(
MgMgcoSelList *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSelList(dst)
MgMgcoSelList *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoSelList)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoSelSpecLst(dst->selSpec[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->selSpec[i], sizeof(MgMgcoSelSpecLst));
      }
      MGFREE(dst->selSpec, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSelList*/

/*
*
*    Fun:    mgUtlDelMgMgcoVarSegSpec
*
*    Desc:    Delete the structure MgMgcoVarSegSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoVarSegSpec
(
MgMgcoVarSegSpec *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoVarSegSpec(dst)
MgMgcoVarSegSpec *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoVarSegSpec)

   if (mgUtlDelMgMgcoVvarSpec(&dst->vvarSpec) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoSelList(&dst->selList) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoVarSegSpec*/

/*
*
*    Fun:    mgUtlDelMgMgcoSpec
*
*    Desc:    Delete the structure MgMgcoSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSpec
(
MgMgcoSpec *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSpec(dst)
MgMgcoSpec *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSpec)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_MGCO_PROV_SEG_SPEC :
            if (mgUtlDelMgMgcoProvSegSpec(&dst->u.provSs) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MGCO_VAR_SEG_SPEC :
            if (mgUtlDelMgMgcoVarSegSpec(&dst->u.staSs) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSpec*/

/*
*
*    Fun:    mgUtlDelMgMgcoSegSpec
*
*    Desc:    Delete the structure MgMgcoSegSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSegSpec
(
MgMgcoSegSpec *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSegSpec(dst)
MgMgcoSegSpec *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSegSpec)

   if (mgUtlDelMgMgcoSpec(&dst->spec) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSegSpec*/

/*
*
*    Fun:    mgUtlDelMgMgcoAnncSpec
*
*    Desc:    Delete the structure MgMgcoAnncSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoAnncSpec
(
MgMgcoAnncSpec *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoAnncSpec(dst)
MgMgcoAnncSpec *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoAnncSpec)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoSegSpec(dst->segSpec[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->segSpec[i], sizeof(MgMgcoSegSpec));
      }
      MGFREE(dst->segSpec, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoAnncSpec*/
#endif

/*
*
*    Fun:    mgUtlDelMgMgcoValue
*
*    Desc:    Delete the structure MgMgcoValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoValue
(
MgMgcoValue *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoValue(dst)
MgMgcoValue *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoValue)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_VALTYPE_ADV_AUD_PROVSEGSPEC :
            if (mgUtlDelMgMgcoProvSegSpec(&dst->u.prSpec) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_ADV_AUD_SEGLST :
            if (mgUtlDelMgMgcoAnncSpec(&dst->u.anSpec) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_ENUM :
            break;
         case  MGT_VALTYPE_HEX_SINT32 :
            break;
         case  MGT_VALTYPE_HEX_UINT32 :
            break;
         case  MGT_VALTYPE_OCTSTRXL :
            if (mgUtlDelTknStrOSXL(&dst->u.osxl) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_SIGLST :
            if (mgUtlDelMgMgcoSigLst(&dst->u.sigLst) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_SIGNAME :
            if (mgUtlDelMgMgcoSigName(&dst->u.sigName) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_SINT32 :
            break;
         case  MGT_VALTYPE_TERMID :
            if (mgUtlDelMgMgcoTermId(&dst->u.termId) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_TERMIDLST :
            if (mgUtlDelMgMgcoTermIdLst(&dst->u.termIdLst) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALTYPE_TKNBUF :
            break;
         case  MGT_VALTYPE_UINT32 :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoValue*/

/*
*
*    Fun:    mgUtlDelMgMgcoAuthHdr
*
*    Desc:    Delete the structure MgMgcoAuthHdr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoAuthHdr
(
MgMgcoAuthHdr *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoAuthHdr(dst)
MgMgcoAuthHdr *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoAuthHdr)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelTknStrOSXL(&dst->aData) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoAuthHdr*/

/*
*
*    Fun:    mgUtlDelMgMgcoDomAddrPort
*
*    Desc:    Delete the structure MgMgcoDomAddrPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoDomAddrPort
(
MgMgcoDomAddrPort *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoDomAddrPort(dst)
MgMgcoDomAddrPort *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoDomAddrPort)

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_IPV4 :
               if (mgUtlDelTknStrOSXL(&dst->u.ipv4) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_IPV6 :
               if (mgUtlDelTknStrOSXL(&dst->u.ipv6) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoDomAddrPort*/

/*
*
*    Fun:    mgUtlDelMgMgcoDomNamePort
*
*    Desc:    Delete the structure MgMgcoDomNamePort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoDomNamePort
(
MgMgcoDomNamePort *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoDomNamePort(dst)
MgMgcoDomNamePort *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoDomNamePort)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelTknStrOSXL(&dst->name) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoDomNamePort*/

/*
*
*    Fun:    mgUtlDelMgMgcoMid
*
*    Desc:    Delete the structure MgMgcoMid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoMid
(
MgMgcoMid *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoMid(dst)
MgMgcoMid *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoMid)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_MID_DADDRPORT :
            if (mgUtlDelMgMgcoDomAddrPort(&dst->u.dAddrPort) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MID_DEVICE :
            if (mgUtlDelMgMgcoPathName(&dst->u.dev) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MID_DNAMEPORT :
            if (mgUtlDelMgMgcoDomNamePort(&dst->u.dNamePort) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MID_MTPADDR :
            break;
         case  MGT_MID_PORT :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoMid*/

/*
*
*    Fun:    mgUtlDelMgMgcoErrDesc
*
*    Desc:    Delete the structure MgMgcoErrDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoErrDesc
(
MgMgcoErrDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoErrDesc(dst)
MgMgcoErrDesc *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoErrDesc)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelTknStrOSXL(&dst->text) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoErrDesc*/

#endif /* AG */

/*
*
*    Fun:    mgUtlDelMgMgcoTopoDesc
*
*    Desc:    Delete the structure MgMgcoTopoDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTopoDesc
(
MgMgcoTopoDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTopoDesc(dst)
MgMgcoTopoDesc *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoTopoDesc)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoTermId(&dst->from) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoTermId(&dst->to) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTopoDesc*/

/* mg008.105: moving unused function within AG compiler flag */
#ifdef AG

/*
*
*    Fun:    mgUtlDelMgMgcoTopoDescLst
*
*    Desc:    Delete the structure MgMgcoTopoDescLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTopoDescLst
(
MgMgcoTopoDescLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTopoDescLst(dst)
MgMgcoTopoDescLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoTopoDescLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoTopoDesc(dst->descs[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->descs[i], sizeof(MgMgcoTopoDesc));
      }
      MGFREE(dst->descs, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTopoDescLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoContextProps
*
*    Desc:    Delete the structure MgMgcoContextProps
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoContextProps
(
MgMgcoContextProps *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoContextProps(dst)
MgMgcoContextProps *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoContextProps)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoTopoDescLst(&dst->tl) != ROK)
         RETVALUE(RFAILED);
#ifdef MGT_GCP_VER_1_4
#endif /*  MGT_GCP_VER_1_4  */
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoContextProps*/

/*
*
*    Fun:    mgUtlDelMgMgcoValLst
*
*    Desc:    Delete the structure MgMgcoValLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoValLst
(
MgMgcoValLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoValLst(dst)
MgMgcoValLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoValLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoValue(dst->vals[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->vals[i], sizeof(MgMgcoValue));
      }
      MGFREE(dst->vals, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoValLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoValRng
*
*    Desc:    Delete the structure MgMgcoValRng
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoValRng
(
MgMgcoValRng *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoValRng(dst)
MgMgcoValRng *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoValRng)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoValue(&dst->low) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoValue(&dst->up) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoValRng*/

/*
*
*    Fun:    mgUtlDelMgMgcoParmValue
*
*    Desc:    Delete the structure MgMgcoParmValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoParmValue
(
MgMgcoParmValue *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoParmValue(dst)
MgMgcoParmValue *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoParmValue)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_VALUE_AND :
            if (mgUtlDelMgMgcoValLst(&dst->u.and) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALUE_EQUAL :
            if (mgUtlDelMgMgcoValue(&dst->u.eq) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALUE_GREATERTHAN :
            if (mgUtlDelMgMgcoValue(&dst->u.gt) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALUE_LESSTHAN :
            if (mgUtlDelMgMgcoValue(&dst->u.lt) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALUE_NOTEQUAL :
            if (mgUtlDelMgMgcoValue(&dst->u.ne) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALUE_OR :
            if (mgUtlDelMgMgcoValLst(&dst->u.or) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_VALUE_RANGE :
            if (mgUtlDelMgMgcoValRng(&dst->u.rng) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoParmValue*/

/*
*
*    Fun:    mgUtlDelMgMgcoPropParm
*
*    Desc:    Delete the structure MgMgcoPropParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoPropParm
(
MgMgcoPropParm *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoPropParm(dst)
MgMgcoPropParm *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoPropParm)

   if (mgUtlDelMgMgcoPkgdName(&dst->name) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoParmValue(&dst->val) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoPropParm*/

/*
*
*    Fun:    mgUtlDelMgMgcoPropParmLst
*
*    Desc:    Delete the structure MgMgcoPropParmLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoPropParmLst
(
MgMgcoPropParmLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoPropParmLst(dst)
MgMgcoPropParmLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoPropParmLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoPropParm(dst->parms[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->parms[i], sizeof(MgMgcoPropParm));
      }
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoPropParmLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoLocalParm
*
*    Desc:    Delete the structure MgMgcoLocalParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoLocalParm
(
MgMgcoLocalParm *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoLocalParm(dst)
MgMgcoLocalParm *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoLocalParm)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_LCLCTL_MODE :
            break;
         case  MGT_LCLCTL_PROPPARM :
            if (mgUtlDelMgMgcoPropParm(&dst->u.propParm) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_LCLCTL_RESGRP :
            break;
         case  MGT_LCLCTL_RESVAL :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoLocalParm*/

/*
*
*    Fun:    mgUtlDelMgMgcoLclCtlDesc
*
*    Desc:    Delete the structure MgMgcoLclCtlDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoLclCtlDesc
(
MgMgcoLclCtlDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoLclCtlDesc(dst)
MgMgcoLclCtlDesc *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoLclCtlDesc)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoLocalParm(dst->parms[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->parms[i], sizeof(MgMgcoLocalParm));
      }
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoLclCtlDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoPropGrpLst
*
*    Desc:    Delete the structure MgMgcoPropGrpLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoPropGrpLst
(
MgMgcoPropGrpLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoPropGrpLst(dst)
MgMgcoPropGrpLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoPropGrpLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoPropParmLst(dst->grps[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->grps[i], sizeof(MgMgcoPropParmLst));
      }
      MGFREE(dst->grps, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoPropGrpLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoLocalDesc
*
*    Desc:    Delete the structure MgMgcoLocalDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoLocalDesc
(
MgMgcoLocalDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoLocalDesc(dst)
MgMgcoLocalDesc *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoLocalDesc)

   if(dst->pres.pres != NOTPRSNT)
   {
      /* if (mgUtlDelCmSdpInfoSet(&dst->sdp) != ROK)
         RETVALUE(RFAILED);*/
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoLocalDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoTermStateParm
*
*    Desc:    Delete the structure MgMgcoTermStateParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTermStateParm
(
MgMgcoTermStateParm *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTermStateParm(dst)
MgMgcoTermStateParm *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoTermStateParm)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_TERMST_EVTBUFCTL :
            break;
         case  MGT_TERMST_PROPLST :
            if (mgUtlDelMgMgcoPropParm(&dst->u.parm) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TERMST_SVCST :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTermStateParm*/

/*
*
*    Fun:    mgUtlDelMgMgcoTermStateDesc
*
*    Desc:    Delete the structure MgMgcoTermStateDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTermStateDesc
(
MgMgcoTermStateDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTermStateDesc(dst)
MgMgcoTermStateDesc *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoTermStateDesc)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (mgUtlDelMgMgcoTermStateParm(dst->trmStPar[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->trmStPar[i], sizeof(MgMgcoTermStateParm));
      }
      MGFREE(dst->trmStPar, sizeof(Ptr)*(dst->numComp.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTermStateDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoStreamParm
*
*    Desc:    Delete the structure MgMgcoStreamParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoStreamParm
(
MgMgcoStreamParm *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoStreamParm(dst)
MgMgcoStreamParm *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoStreamParm)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoLclCtlDesc(&dst->locCtl) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoLocalDesc(&dst->local) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoLocalDesc(&dst->remote) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoStreamParm*/

/*
*
*    Fun:    mgUtlDelMgMgcoStreamDesc
*
*    Desc:    Delete the structure MgMgcoStreamDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoStreamDesc
(
MgMgcoStreamDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoStreamDesc(dst)
MgMgcoStreamDesc *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoStreamDesc)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoStreamParm(&dst->sl) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoStreamDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoMediaPar
*
*    Desc:    Delete the structure MgMgcoMediaPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoMediaPar
(
MgMgcoMediaPar *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoMediaPar(dst)
MgMgcoMediaPar *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoMediaPar)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_MEDIAPAR_LOCAL :
            if (mgUtlDelMgMgcoLocalDesc(&dst->u.local) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MEDIAPAR_LOCCTL :
            if (mgUtlDelMgMgcoLclCtlDesc(&dst->u.locCtl) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MEDIAPAR_REMOTE :
            if (mgUtlDelMgMgcoLocalDesc(&dst->u.remote) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MEDIAPAR_STRPAR :
            if (mgUtlDelMgMgcoStreamDesc(&dst->u.stream) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MEDIAPAR_TERMST :
            if (mgUtlDelMgMgcoTermStateDesc(&dst->u.tstate) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoMediaPar*/

/*
*
*    Fun:    mgUtlDelMgMgcoMediaDesc
*
*    Desc:    Delete the structure MgMgcoMediaDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoMediaDesc
(
MgMgcoMediaDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoMediaDesc(dst)
MgMgcoMediaDesc *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoMediaDesc)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoMediaPar(dst->parms[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->parms[i], sizeof(MgMgcoMediaPar));
      }
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoMediaDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoNonStdId
*
*    Desc:    Delete the structure MgMgcoNonStdId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoNonStdId
(
MgMgcoNonStdId *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoNonStdId(dst)
MgMgcoNonStdId *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoNonStdId)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_EXTNPARM_MAND :
            break;
         case  MGT_EXTNPARM_OPT :
            break;
         case  MGT_NONSTD_H221 :
            break;
         case  MGT_NONSTD_OBJID :
            if (mgUtlDelTknStrOSXL(&dst->u.objId) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoNonStdId*/

/*
*
*    Fun:    mgUtlDelMgMgcoModemType
*
*    Desc:    Delete the structure MgMgcoModemType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoModemType
(
MgMgcoModemType *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoModemType(dst)
MgMgcoModemType *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoModemType)

   if (mgUtlDelMgMgcoNonStdId(&dst->extnId) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoModemType*/

/*
*
*    Fun:    mgUtlDelMgMgcoModemTypeLst
*
*    Desc:    Delete the structure MgMgcoModemTypeLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoModemTypeLst
(
MgMgcoModemTypeLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoModemTypeLst(dst)
MgMgcoModemTypeLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoModemTypeLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoModemType(dst->modems[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->modems[i], sizeof(MgMgcoModemType));
      }
      MGFREE(dst->modems, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoModemTypeLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoNonStdExtn
*
*    Desc:    Delete the structure MgMgcoNonStdExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoNonStdExtn
(
MgMgcoNonStdExtn *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoNonStdExtn(dst)
MgMgcoNonStdExtn *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoNonStdExtn)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoNonStdId(&dst->id) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoParmValue(&dst->val) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoNonStdExtn*/

/*
*
*    Fun:    mgUtlDelMgMgcoModemDesc
*
*    Desc:    Delete the structure MgMgcoModemDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoModemDesc
(
MgMgcoModemDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoModemDesc(dst)
MgMgcoModemDesc *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoModemDesc)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoModemTypeLst(&dst->mtl) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoPropParmLst(&dst->mpl) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoNonStdExtn(&dst->extn) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoModemDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoMuxDesc
*
*    Desc:    Delete the structure MgMgcoMuxDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoMuxDesc
(
MgMgcoMuxDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoMuxDesc(dst)
MgMgcoMuxDesc *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoMuxDesc)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoNonStdId(&dst->id) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoTermIdLst(&dst->tl) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoMuxDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoEvtOther
*
*    Desc:    Delete the structure MgMgcoEvtOther
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoEvtOther
(
MgMgcoEvtOther *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoEvtOther(dst)
MgMgcoEvtOther *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoEvtOther)

   if (mgUtlDelMgMgcoName(&dst->name) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoParmValue(&dst->val) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoEvtOther*/

/*
*
*    Fun:    mgUtlDelMgMgcoNtfyCmpl
*
*    Desc:    Delete the structure MgMgcoNtfyCmpl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoNtfyCmpl
(
MgMgcoNtfyCmpl *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoNtfyCmpl(dst)
MgMgcoNtfyCmpl *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoNtfyCmpl)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         MGFREE(dst->reasons[i], sizeof(TknU8));
      }
      MGFREE(dst->reasons, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoNtfyCmpl*/

/*
*
*    Fun:    mgUtlDelMgMgcoSigPar
*
*    Desc:    Delete the structure MgMgcoSigPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSigPar
(
MgMgcoSigPar *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSigPar(dst)
MgMgcoSigPar *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSigPar)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_SIGPAR_DURATION :
            break;
         case  MGT_SIGPAR_KEEPACTIVE :
            break;
         case  MGT_SIGPAR_NTFYCMPL :
            if (mgUtlDelMgMgcoNtfyCmpl(&dst->u.nc) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SIGPAR_OTHER :
            if (mgUtlDelMgMgcoEvtOther(&dst->u.other) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SIGPAR_STREAMID :
            break;
         case  MGT_SIGPAR_TYPE :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSigPar*/

/*
*
*    Fun:    mgUtlDelMgMgcoSigParLst
*
*    Desc:    Delete the structure MgMgcoSigParLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSigParLst
(
MgMgcoSigParLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSigParLst(dst)
MgMgcoSigParLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoSigParLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoSigPar(dst->parms[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->parms[i], sizeof(MgMgcoSigPar));
      }
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSigParLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoSignalsReq
*
*    Desc:    Delete the structure MgMgcoSignalsReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSignalsReq
(
MgMgcoSignalsReq *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSignalsReq(dst)
MgMgcoSignalsReq *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSignalsReq)

   if (mgUtlDelMgMgcoPkgdName(&dst->name) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoSigParLst(&dst->pl) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSignalsReq*/

/*
*
*    Fun:    mgUtlDelMgMgcoSignalsReqLst
*
*    Desc:    Delete the structure MgMgcoSignalsReqLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSignalsReqLst
(
MgMgcoSignalsReqLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSignalsReqLst(dst)
MgMgcoSignalsReqLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoSignalsReqLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoSignalsReq(dst->reqs[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->reqs[i], sizeof(MgMgcoSignalsReq));
      }
      MGFREE(dst->reqs, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSignalsReqLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoSignalsLst
*
*    Desc:    Delete the structure MgMgcoSignalsLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSignalsLst
(
MgMgcoSignalsLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSignalsLst(dst)
MgMgcoSignalsLst *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSignalsLst)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoSignalsReqLst(&dst->pl) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSignalsLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoSignalsParm
*
*    Desc:    Delete the structure MgMgcoSignalsParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSignalsParm
(
MgMgcoSignalsParm *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSignalsParm(dst)
MgMgcoSignalsParm *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSignalsParm)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_SIGSPAR_LST :
            if (mgUtlDelMgMgcoSignalsLst(&dst->u.lst) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SIGSPAR_REQ :
            if (mgUtlDelMgMgcoSignalsReq(&dst->u.req) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSignalsParm*/

/*
*
*    Fun:    mgUtlDelMgMgcoSignalsDesc
*
*    Desc:    Delete the structure MgMgcoSignalsDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSignalsDesc
(
MgMgcoSignalsDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSignalsDesc(dst)
MgMgcoSignalsDesc *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoSignalsDesc)

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->num.pres != NOTPRSNT )
      {
         for (i=0;i<dst->num.val;i++)
         {
            if (mgUtlDelMgMgcoSignalsParm(dst->parms[i]) != ROK)
               RETVALUE(RFAILED);
            MGFREE(dst->parms[i], sizeof(MgMgcoSignalsParm));
         }
         MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSignalsDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoDigMapLet
*
*    Desc:    Delete the structure MgMgcoDigMapLet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoDigMapLet
(
MgMgcoDigMapLet *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoDigMapLet(dst)
MgMgcoDigMapLet *dst;
#endif
{

   U16   i;

   TRC3(mgUtlDelMgMgcoDigMapLet)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         MGFREE(dst->mapLets[i], sizeof(MgMgcoDigRng));
      }
      MGFREE(dst->mapLets, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoDigMapLet*/

/*
*
*    Fun:    mgUtlDelMgMgcoDigMapRng
*
*    Desc:    Delete the structure MgMgcoDigMapRng
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoDigMapRng
(
MgMgcoDigMapRng *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoDigMapRng(dst)
MgMgcoDigMapRng *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoDigMapRng)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_DIGMAP_LET :
            if (mgUtlDelMgMgcoDigMapLet(&dst->u.let) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_DIGMAP_X :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoDigMapRng*/

/*
*
*    Fun:    mgUtlDelMgMgcoDigStrElem
*
*    Desc:    Delete the structure MgMgcoDigStrElem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoDigStrElem
(
MgMgcoDigStrElem *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoDigStrElem(dst)
MgMgcoDigStrElem *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoDigStrElem)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_DIGSTR_LET :
            break;
         case  MGT_DIGSTR_RNG :
            if (mgUtlDelMgMgcoDigMapRng(&dst->u.range) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoDigStrElem*/

/*
*
*    Fun:    mgUtlDelMgMgcoDigStr
*
*    Desc:    Delete the structure MgMgcoDigStr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoDigStr
(
MgMgcoDigStr *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoDigStr(dst)
MgMgcoDigStr *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoDigStr)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoDigStrElem(dst->elems[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->elems[i], sizeof(MgMgcoDigStrElem));
      }
      MGFREE(dst->elems, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoDigStr*/

/*
*
*    Fun:    mgUtlDelMgMgcoDigMap
*
*    Desc:    Delete the structure MgMgcoDigMap
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoDigMap
(
MgMgcoDigMap *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoDigMap(dst)
MgMgcoDigMap *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoDigMap)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoDigStr(dst->ds[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->ds[i], sizeof(MgMgcoDigStr));
      }
      MGFREE(dst->ds, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoDigMap*/

/*
*
*    Fun:    mgUtlDelMgMgcoDigMapVal
*
*    Desc:    Delete the structure MgMgcoDigMapVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoDigMapVal
(
MgMgcoDigMapVal *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoDigMapVal(dst)
MgMgcoDigMapVal *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoDigMapVal)

   if(dst->pres.pres != NOTPRSNT)
   {
#if defined(  GCP_VER_1_3)  && defined(  GCP_MGCO_PARSE_DIG_MAP) 
      if (mgUtlDelTknStrOSXL(&dst->dm) != ROK)
         RETVALUE(RFAILED);
#else /*  defined(  GCP_VER_1_3)  && defined(  GCP_MGCO_PARSE_DIG_MAP)  */ 
      if (mgUtlDelMgMgcoDigMap(&dst->dm) != ROK)
         RETVALUE(RFAILED);
#endif /*  defined(  GCP_VER_1_3)  && defined(  GCP_MGCO_PARSE_DIG_MAP)   */
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoDigMapVal*/

/*
*
*    Fun:    mgUtlDelMgMgcoEvtDM
*
*    Desc:    Delete the structure MgMgcoEvtDM
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoEvtDM
(
MgMgcoEvtDM *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoEvtDM(dst)
MgMgcoEvtDM *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoEvtDM)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_DIGMAP_NAME :
            if (mgUtlDelMgMgcoName(&dst->u.name) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_DIGMAP_VAL :
            if (mgUtlDelMgMgcoDigMapVal(&dst->u.val) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoEvtDM*/

/*
*
*    Fun:    mgUtlDelMgMgcoEvtParSec
*
*    Desc:    Delete the structure MgMgcoEvtParSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoEvtParSec
(
MgMgcoEvtParSec *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoEvtParSec(dst)
MgMgcoEvtParSec *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoEvtParSec)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_EVTPAR_DIGMAP :
            if (mgUtlDelMgMgcoEvtDM(&dst->u.dm) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_EMBEDWITHSIG :
            if (mgUtlDelMgMgcoSignalsDesc(&dst->u.embSig) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_KEEPACTIVE :
            break;
         case  MGT_EVTPAR_OTHER :
            if (mgUtlDelMgMgcoEvtOther(&dst->u.other) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_STREAMID :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoEvtParSec*/

/*
*
*    Fun:    mgUtlDelMgMgcoEvtParSecLst
*
*    Desc:    Delete the structure MgMgcoEvtParSecLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoEvtParSecLst
(
MgMgcoEvtParSecLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoEvtParSecLst(dst)
MgMgcoEvtParSecLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoEvtParSecLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoEvtParSec(dst->parms[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->parms[i], sizeof(MgMgcoEvtParSec));
      }
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoEvtParSecLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoEvtSec
*
*    Desc:    Delete the structure MgMgcoEvtSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoEvtSec
(
MgMgcoEvtSec *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoEvtSec(dst)
MgMgcoEvtSec *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoEvtSec)

   if (mgUtlDelMgMgcoPkgdName(&dst->name) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoEvtParSecLst(&dst->pl) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoEvtSec*/

/*
*
*    Fun:    mgUtlDelMgMgcoEvtSecLst
*
*    Desc:    Delete the structure MgMgcoEvtSecLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoEvtSecLst
(
MgMgcoEvtSecLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoEvtSecLst(dst)
MgMgcoEvtSecLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoEvtSecLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoEvtSec(dst->evts[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->evts[i], sizeof(MgMgcoEvtSec));
      }
      MGFREE(dst->evts, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoEvtSecLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoEmbedFirst
*
*    Desc:    Delete the structure MgMgcoEmbedFirst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoEmbedFirst
(
MgMgcoEmbedFirst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoEmbedFirst(dst)
MgMgcoEmbedFirst *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoEmbedFirst)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoEvtSecLst(&dst->sl) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoEmbedFirst*/

/*
*
*    Fun:    mgUtlDelMgMgcoEmbWithSig
*
*    Desc:    Delete the structure MgMgcoEmbWithSig
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoEmbWithSig
(
MgMgcoEmbWithSig *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoEmbWithSig(dst)
MgMgcoEmbWithSig *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoEmbWithSig)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoSignalsDesc(&dst->sig) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoEmbedFirst(&dst->emb) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoEmbWithSig*/

/*
*
*    Fun:    mgUtlDelMgMgcoEvtPar
*
*    Desc:    Delete the structure MgMgcoEvtPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoEvtPar
(
MgMgcoEvtPar *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoEvtPar(dst)
MgMgcoEvtPar *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoEvtPar)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_EVTPAR_DIGMAP :
            if (mgUtlDelMgMgcoEvtDM(&dst->u.dm) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_EMBEDNOSIG :
            if (mgUtlDelMgMgcoEmbedFirst(&dst->u.embNoSig) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_EMBEDWITHSIG :
            if (mgUtlDelMgMgcoEmbWithSig(&dst->u.embWithSig) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_KEEPACTIVE :
            break;
         case  MGT_EVTPAR_OTHER :
            if (mgUtlDelMgMgcoEvtOther(&dst->u.other) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVTPAR_STREAMID :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoEvtPar*/

/*
*
*    Fun:    mgUtlDelMgMgcoEvtParLst
*
*    Desc:    Delete the structure MgMgcoEvtParLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoEvtParLst
(
MgMgcoEvtParLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoEvtParLst(dst)
MgMgcoEvtParLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoEvtParLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoEvtPar(dst->parms[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->parms[i], sizeof(MgMgcoEvtPar));
      }
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoEvtParLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoReqEvt
*
*    Desc:    Delete the structure MgMgcoReqEvt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoReqEvt
(
MgMgcoReqEvt *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoReqEvt(dst)
MgMgcoReqEvt *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoReqEvt)

   if (mgUtlDelMgMgcoPkgdName(&dst->name) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoEvtParLst(&dst->pl) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoReqEvt*/

/*
*
*    Fun:    mgUtlDelMgMgcoEvtLst
*
*    Desc:    Delete the structure MgMgcoEvtLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoEvtLst
(
MgMgcoEvtLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoEvtLst(dst)
MgMgcoEvtLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoEvtLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoReqEvt(dst->revts[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->revts[i], sizeof(MgMgcoReqEvt));
      }
      MGFREE(dst->revts, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoEvtLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoReqEvtDesc
*
*    Desc:    Delete the structure MgMgcoReqEvtDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoReqEvtDesc
(
MgMgcoReqEvtDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoReqEvtDesc(dst)
MgMgcoReqEvtDesc *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoReqEvtDesc)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoEvtLst(&dst->el) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoReqEvtDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoEvBufDesc
*
*    Desc:    Delete the structure MgMgcoEvBufDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoEvBufDesc
(
MgMgcoEvBufDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoEvBufDesc(dst)
MgMgcoEvBufDesc *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoEvBufDesc)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoReqEvt(dst->evts[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->evts[i], sizeof(MgMgcoReqEvt));
      }
      MGFREE(dst->evts, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoEvBufDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoDigMapDesc
*
*    Desc:    Delete the structure MgMgcoDigMapDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoDigMapDesc
(
MgMgcoDigMapDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoDigMapDesc(dst)
MgMgcoDigMapDesc *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoDigMapDesc)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoName(&dst->name) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoDigMapVal(&dst->val) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoDigMapDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoAuditDesc
*
*    Desc:    Delete the structure MgMgcoAuditDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoAuditDesc
(
MgMgcoAuditDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoAuditDesc(dst)
MgMgcoAuditDesc *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoAuditDesc)

   if(dst->pres.pres != NOTPRSNT)
   {
#ifdef MGT_MGCO_V2
      if( dst->num.pres != NOTPRSNT )
      {
      }
#else /*  MGT_MGCO_V2 */ 
      if( dst->num.pres != NOTPRSNT )
      {
      }
#endif /*  MGT_MGCO_V2  */
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoAuditDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoAmmDesc
*
*    Desc:    Delete the structure MgMgcoAmmDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoAmmDesc
(
MgMgcoAmmDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoAmmDesc(dst)
MgMgcoAmmDesc *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoAmmDesc)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_AUDITDESC :
            if (mgUtlDelMgMgcoAuditDesc(&dst->u.audit) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_DIGMAPDESC :
            if (mgUtlDelMgMgcoDigMapDesc(&dst->u.dm) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVBUFDESC :
            if (mgUtlDelMgMgcoEvBufDesc(&dst->u.evBuf) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MEDIADESC :
            if (mgUtlDelMgMgcoMediaDesc(&dst->u.media) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MODEMDESC :
            if (mgUtlDelMgMgcoModemDesc(&dst->u.modem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MUXDESC :
            if (mgUtlDelMgMgcoMuxDesc(&dst->u.mux) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_REQEVTDESC :
            if (mgUtlDelMgMgcoReqEvtDesc(&dst->u.evts) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SIGNALSDESC :
            if (mgUtlDelMgMgcoSignalsDesc(&dst->u.sig) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoAmmDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoAmmDescLst
*
*    Desc:    Delete the structure MgMgcoAmmDescLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoAmmDescLst
(
MgMgcoAmmDescLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoAmmDescLst(dst)
MgMgcoAmmDescLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoAmmDescLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoAmmDesc(dst->descs[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->descs[i], sizeof(MgMgcoAmmDesc));
      }
      MGFREE(dst->descs, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoAmmDescLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoAmmReq
*
*    Desc:    Delete the structure MgMgcoAmmReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoAmmReq
(
MgMgcoAmmReq *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoAmmReq(dst)
MgMgcoAmmReq *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoAmmReq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoTermId(&dst->termId) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoAmmDescLst(&dst->dl) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoAmmReq*/

/*
*
*    Fun:    mgUtlDelMgMgcoSubAudReq
*
*    Desc:    Delete the structure MgMgcoSubAudReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSubAudReq
(
MgMgcoSubAudReq *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSubAudReq(dst)
MgMgcoSubAudReq *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSubAudReq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoTermId(&dst->termId) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoAuditDesc(&dst->audit) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSubAudReq*/

/*
*
*    Fun:    mgUtlDelMgMgcoObsEvt
*
*    Desc:    Delete the structure MgMgcoObsEvt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoObsEvt
(
MgMgcoObsEvt *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoObsEvt(dst)
MgMgcoObsEvt *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoObsEvt)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoPkgdName(&dst->name) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoEvtParLst(&dst->pl) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoObsEvt*/

/*
*
*    Fun:    mgUtlDelMgMgcoObsEvtLst
*
*    Desc:    Delete the structure MgMgcoObsEvtLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoObsEvtLst
(
MgMgcoObsEvtLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoObsEvtLst(dst)
MgMgcoObsEvtLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoObsEvtLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoObsEvt(dst->evts[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->evts[i], sizeof(MgMgcoObsEvt));
      }
      MGFREE(dst->evts, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoObsEvtLst*/

/*
*
*    Fun:    mgUtlDelMgMgcoObsEvtDesc
*
*    Desc:    Delete the structure MgMgcoObsEvtDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoObsEvtDesc
(
MgMgcoObsEvtDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoObsEvtDesc(dst)
MgMgcoObsEvtDesc *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoObsEvtDesc)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoObsEvtLst(&dst->el) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoObsEvtDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoNtfyReq
*
*    Desc:    Delete the structure MgMgcoNtfyReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoNtfyReq
(
MgMgcoNtfyReq *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoNtfyReq(dst)
MgMgcoNtfyReq *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoNtfyReq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoTermId(&dst->termId) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoObsEvtDesc(&dst->obs) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoErrDesc(&dst->err) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoNtfyReq*/

/*
*
*    Fun:    mgUtlDelMgMgcoSvcChgMethod
*
*    Desc:    Delete the structure MgMgcoSvcChgMethod
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSvcChgMethod
(
MgMgcoSvcChgMethod *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSvcChgMethod(dst)
MgMgcoSvcChgMethod *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSvcChgMethod)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoNonStdId(&dst->extn) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSvcChgMethod*/

/*
*
*    Fun:    mgUtlDelMgMgcoSvcChgProf
*
*    Desc:    Delete the structure MgMgcoSvcChgProf
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSvcChgProf
(
MgMgcoSvcChgProf *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSvcChgProf(dst)
MgMgcoSvcChgProf *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSvcChgProf)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoName(&dst->name) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSvcChgProf*/

/*
*
*    Fun:    mgUtlDelMgMgcoSvcChgPar
*
*    Desc:    Delete the structure MgMgcoSvcChgPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSvcChgPar
(
MgMgcoSvcChgPar *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSvcChgPar(dst)
MgMgcoSvcChgPar *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSvcChgPar)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoNonStdExtn(&dst->extn) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoSvcChgMethod(&dst->meth) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoMid(&dst->addr) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoSvcChgProf(&dst->prof) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelTknStrOSXL(&dst->reason) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoMid(&dst->mgcId) != ROK)
         RETVALUE(RFAILED);
#ifdef MGT_MGCO_V2
      if (mgUtlDelMgMgcoAuditItem(&dst->auditItem) != ROK)
         RETVALUE(RFAILED);
#endif /*  MGT_MGCO_V2  */
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSvcChgPar*/

/*
*
*    Fun:    mgUtlDelMgMgcoSvcChgReq
*
*    Desc:    Delete the structure MgMgcoSvcChgReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSvcChgReq
(
MgMgcoSvcChgReq *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSvcChgReq(dst)
MgMgcoSvcChgReq *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSvcChgReq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoTermId(&dst->termId) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoSvcChgPar(&dst->parm) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSvcChgReq*/

/*
*
*    Fun:    mgUtlDelMgMgcoCmd
*
*    Desc:    Delete the structure MgMgcoCmd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoCmd
(
MgMgcoCmd *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoCmd(dst)
MgMgcoCmd *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoCmd)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_ADD :
            if (mgUtlDelMgMgcoAmmReq(&dst->u.add) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_AUDITCAP :
            if (mgUtlDelMgMgcoSubAudReq(&dst->u.acap) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_AUDITVAL :
            if (mgUtlDelMgMgcoSubAudReq(&dst->u.aval) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MODIFY :
            if (mgUtlDelMgMgcoAmmReq(&dst->u.mod) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MOVE :
            if (mgUtlDelMgMgcoAmmReq(&dst->u.move) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_NTFY :
            if (mgUtlDelMgMgcoNtfyReq(&dst->u.ntfy) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SUB :
            if (mgUtlDelMgMgcoSubAudReq(&dst->u.sub) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SVCCHG :
            if (mgUtlDelMgMgcoSvcChgReq(&dst->u.svc) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoCmd*/
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoCommandReq
*
*    Desc:    Delete the structure MgMgcoCommandReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoCommandReq
(
MgMgcoCommandReq *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoCommandReq(dst)
MgMgcoCommandReq *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoCommandReq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoCmd(&dst->cmd) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoCommandReq*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoCommandReq
*
*    Desc:    Delete the structure MgMgcoCommandReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoCommandReq
(
MgMgcoCommandReq *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoCommandReq(dst)
MgMgcoCommandReq *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoCommandReq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoCmd(&dst->cmd) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoCommandReq*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoCmdReqLst
*
*    Desc:    Delete the structure MgMgcoCmdReqLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoCmdReqLst
(
MgMgcoCmdReqLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoCmdReqLst(dst)
MgMgcoCmdReqLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoCmdReqLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoCommandReq(dst->cmds[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->cmds[i], sizeof(MgMgcoCommandReq));
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoCmdReqLst*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoCmdReqLst
*
*    Desc:    Delete the structure MgMgcoCmdReqLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoCmdReqLst
(
MgMgcoCmdReqLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoCmdReqLst(dst)
MgMgcoCmdReqLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoCmdReqLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoCommandReq(dst->cmds[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->cmds[i], sizeof(MgMgcoCommandReq));
      }
      MGFREE(dst->cmds, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoCmdReqLst*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoActionReq
*
*    Desc:    Delete the structure MgMgcoActionReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoActionReq
(
MgMgcoActionReq *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoActionReq(dst)
MgMgcoActionReq *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoActionReq)

   if (mgUtlDelMgMgcoContextProps(&dst->cxtProps) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoCmdReqLst(&dst->cl) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoActionReq*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoActionReq
*
*    Desc:    Delete the structure MgMgcoActionReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoActionReq
(
MgMgcoActionReq *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoActionReq(dst)
MgMgcoActionReq *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoActionReq)

   if (mgUtlDelMgMgcoContextProps(&dst->cxtProps) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoCmdReqLst(&dst->cl) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoActionReq*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoActionLst
*
*    Desc:    Delete the structure MgMgcoActionLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoActionLst
(
MgMgcoActionLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoActionLst(dst)
MgMgcoActionLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoActionLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoActionReq(dst->actns[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->actns[i], sizeof(MgMgcoActionReq));
      }
      MGFREE(dst->actns, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoActionLst*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoActionLst
*
*    Desc:    Delete the structure MgMgcoActionLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoActionLst
(
MgMgcoActionLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoActionLst(dst)
MgMgcoActionLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoActionLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoActionReq(dst->actns[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->actns[i], sizeof(MgMgcoActionReq));
      }
      MGFREE(dst->actns, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoActionLst*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoTxnReq
*
*    Desc:    Delete the structure MgMgcoTxnReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTxnReq
(
MgMgcoTxnReq *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTxnReq(dst)
MgMgcoTxnReq *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoTxnReq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoActionLst(&dst->al) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTxnReq*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoTxnReq
*
*    Desc:    Delete the structure MgMgcoTxnReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTxnReq
(
MgMgcoTxnReq *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTxnReq(dst)
MgMgcoTxnReq *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoTxnReq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoActionLst(&dst->al) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTxnReq*/
#endif

/*
*
*    Fun:    mgUtlDelMgMgcoStatsPar
*
*    Desc:    Delete the structure MgMgcoStatsPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoStatsPar
(
MgMgcoStatsPar *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoStatsPar(dst)
MgMgcoStatsPar *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoStatsPar)

   if (mgUtlDelMgMgcoPkgdName(&dst->name) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelMgMgcoValue(&dst->val) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoStatsPar*/

/*
*
*    Fun:    mgUtlDelMgMgcoStatsDesc
*
*    Desc:    Delete the structure MgMgcoStatsDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoStatsDesc
(
MgMgcoStatsDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoStatsDesc(dst)
MgMgcoStatsDesc *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoStatsDesc)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoStatsPar(dst->parms[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->parms[i], sizeof(MgMgcoStatsPar));
      }
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoStatsDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoPkgsItem
*
*    Desc:    Delete the structure MgMgcoPkgsItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoPkgsItem
(
MgMgcoPkgsItem *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoPkgsItem(dst)
MgMgcoPkgsItem *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoPkgsItem)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoName(&dst->name) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoPkgsItem*/

/*
*
*    Fun:    mgUtlDelMgMgcoPkgsDesc
*
*    Desc:    Delete the structure MgMgcoPkgsDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoPkgsDesc
(
MgMgcoPkgsDesc *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoPkgsDesc(dst)
MgMgcoPkgsDesc *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoPkgsDesc)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoPkgsItem(dst->items[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->items[i], sizeof(MgMgcoPkgsItem));
      }
      MGFREE(dst->items, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoPkgsDesc*/

/*
*
*    Fun:    mgUtlDelMgMgcoAudRetParm
*
*    Desc:    Delete the structure MgMgcoAudRetParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoAudRetParm
(
MgMgcoAudRetParm *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoAudRetParm(dst)
MgMgcoAudRetParm *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoAudRetParm)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_AUDITDESC :
            break;
         case  MGT_DIGMAPDESC :
            if (mgUtlDelMgMgcoDigMapDesc(&dst->u.dm) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_ERRDESC :
            if (mgUtlDelMgMgcoErrDesc(&dst->u.err) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_EVBUFDESC :
            if (mgUtlDelMgMgcoEvBufDesc(&dst->u.evBuf) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MEDIADESC :
            if (mgUtlDelMgMgcoMediaDesc(&dst->u.media) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MODEMDESC :
            if (mgUtlDelMgMgcoModemDesc(&dst->u.modem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_MUXDESC :
            if (mgUtlDelMgMgcoMuxDesc(&dst->u.mux) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_OBSEVTDESC :
            if (mgUtlDelMgMgcoObsEvtDesc(&dst->u.obs) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_PKGSDESC :
            if (mgUtlDelMgMgcoPkgsDesc(&dst->u.pkgs) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_REQEVTDESC :
            if (mgUtlDelMgMgcoReqEvtDesc(&dst->u.evts) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SIGNALSDESC :
            if (mgUtlDelMgMgcoSignalsDesc(&dst->u.sig) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_STATSDESC :
            if (mgUtlDelMgMgcoStatsDesc(&dst->u.stats) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoAudRetParm*/

/*
*
*    Fun:    mgUtlDelMgMgcoTermAuditRes
*
*    Desc:    Delete the structure MgMgcoTermAuditRes
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTermAuditRes
(
MgMgcoTermAuditRes *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTermAuditRes(dst)
MgMgcoTermAuditRes *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoTermAuditRes)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoAudRetParm(dst->parms[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->parms[i], sizeof(MgMgcoAudRetParm));
      }
      MGFREE(dst->parms, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTermAuditRes*/

/*
*
*    Fun:    mgUtlDelMgMgcoAmmsReply
*
*    Desc:    Delete the structure MgMgcoAmmsReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoAmmsReply
(
MgMgcoAmmsReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoAmmsReply(dst)
MgMgcoAmmsReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoAmmsReply)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoTermId(&dst->termId) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoTermAuditRes(&dst->audit) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoAmmsReply*/

/*
*
*    Fun:    mgUtlDelMgMgcoAuditOther
*
*    Desc:    Delete the structure MgMgcoAuditOther
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoAuditOther
(
MgMgcoAuditOther *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoAuditOther(dst)
MgMgcoAuditOther *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoAuditOther)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoTermId(&dst->termId) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoTermAuditRes(&dst->audit) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoAuditOther*/

/*
*
*    Fun:    mgUtlDelMgMgcoAuditReply
*
*    Desc:    Delete the structure MgMgcoAuditReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoAuditReply
(
MgMgcoAuditReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoAuditReply(dst)
MgMgcoAuditReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoAuditReply)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_CXTAUDIT :
            if (mgUtlDelMgMgcoTermIdLst(&dst->u.cxt) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_ERRDESC :
            if (mgUtlDelMgMgcoErrDesc(&dst->u.err) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TERMAUDIT :
            if (mgUtlDelMgMgcoAuditOther(&dst->u.other) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoAuditReply*/

/*
*
*    Fun:    mgUtlDelMgMgcoNtfyReply
*
*    Desc:    Delete the structure MgMgcoNtfyReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoNtfyReply
(
MgMgcoNtfyReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoNtfyReply(dst)
MgMgcoNtfyReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoNtfyReply)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoTermId(&dst->termId) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoErrDesc(&dst->err) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoNtfyReply*/

/*
*
*    Fun:    mgUtlDelMgMgcoSvcChgResPar
*
*    Desc:    Delete the structure MgMgcoSvcChgResPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSvcChgResPar
(
MgMgcoSvcChgResPar *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSvcChgResPar(dst)
MgMgcoSvcChgResPar *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSvcChgResPar)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoMid(&dst->addr) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoSvcChgProf(&dst->prof) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoMid(&dst->mgcId) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSvcChgResPar*/

/*
*
*    Fun:    mgUtlDelMgMgcoSvcChgRes
*
*    Desc:    Delete the structure MgMgcoSvcChgRes
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSvcChgRes
(
MgMgcoSvcChgRes *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSvcChgRes(dst)
MgMgcoSvcChgRes *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSvcChgRes)

   if( ( dst->type.pres != NOTPRSNT )&& ( dst->type.pres != NOTPRSNT ))
   {
      switch( dst->type.val )
      {
         case  MGT_ERRDESC :
            if (mgUtlDelMgMgcoErrDesc(&dst->u.err) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_SVCCHGDESC :
            if (mgUtlDelMgMgcoSvcChgResPar(&dst->u.parm) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSvcChgRes*/

/*
*
*    Fun:    mgUtlDelMgMgcoSvcChgReply
*
*    Desc:    Delete the structure MgMgcoSvcChgReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoSvcChgReply
(
MgMgcoSvcChgReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoSvcChgReply(dst)
MgMgcoSvcChgReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoSvcChgReply)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoTermId(&dst->termId) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoSvcChgRes(&dst->res) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoSvcChgReply*/
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoCmdReply
*
*    Desc:    Delete the structure MgMgcoCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoCmdReply
(
MgMgcoCmdReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoCmdReply(dst)
MgMgcoCmdReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoCmdReply)

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_ADD :
               if (mgUtlDelMgMgcoAmmsReply(&dst->u.add) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_AUDITCAP :
               if (mgUtlDelMgMgcoAuditReply(&dst->u.acap) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_AUDITVAL :
               if (mgUtlDelMgMgcoAuditReply(&dst->u.aval) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_MODIFY :
               if (mgUtlDelMgMgcoAmmsReply(&dst->u.mod) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_MOVE :
               if (mgUtlDelMgMgcoAmmsReply(&dst->u.move) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_NTFY :
               if (mgUtlDelMgMgcoNtfyReply(&dst->u.ntfy) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_SUB :
               if (mgUtlDelMgMgcoAmmsReply(&dst->u.sub) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_SVCCHG :
               if (mgUtlDelMgMgcoSvcChgReply(&dst->u.svc) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoCmdReply*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoCmdReply
*
*    Desc:    Delete the structure MgMgcoCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoCmdReply
(
MgMgcoCmdReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoCmdReply(dst)
MgMgcoCmdReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoCmdReply)

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_ADD :
               if (mgUtlDelMgMgcoAmmsReply(&dst->u.add) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_AUDITCAP :
               if (mgUtlDelMgMgcoAuditReply(&dst->u.acap) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_AUDITVAL :
               if (mgUtlDelMgMgcoAuditReply(&dst->u.aval) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_MODIFY :
               if (mgUtlDelMgMgcoAmmsReply(&dst->u.mod) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_MOVE :
               if (mgUtlDelMgMgcoAmmsReply(&dst->u.move) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_NTFY :
               if (mgUtlDelMgMgcoNtfyReply(&dst->u.ntfy) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_SUB :
               if (mgUtlDelMgMgcoAmmsReply(&dst->u.sub) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_SVCCHG :
               if (mgUtlDelMgMgcoSvcChgReply(&dst->u.svc) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoCmdReply*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoCmdReplyLst
*
*    Desc:    Delete the structure MgMgcoCmdReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoCmdReplyLst
(
MgMgcoCmdReplyLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoCmdReplyLst(dst)
MgMgcoCmdReplyLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoCmdReplyLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoCmdReply(dst->repl[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->repl[i], sizeof(MgMgcoCmdReply));
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoCmdReplyLst*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoCmdReplyLst
*
*    Desc:    Delete the structure MgMgcoCmdReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoCmdReplyLst
(
MgMgcoCmdReplyLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoCmdReplyLst(dst)
MgMgcoCmdReplyLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoCmdReplyLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoCmdReply(dst->repl[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->repl[i], sizeof(MgMgcoCmdReply));
      }
      MGFREE(dst->repl, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoCmdReplyLst*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoCxtCmdReply
*
*    Desc:    Delete the structure MgMgcoCxtCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoCxtCmdReply
(
MgMgcoCxtCmdReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoCxtCmdReply(dst)
MgMgcoCxtCmdReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoCxtCmdReply)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoContextProps(&dst->cxt) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoCmdReplyLst(&dst->cl) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoCxtCmdReply*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoCxtCmdReply
*
*    Desc:    Delete the structure MgMgcoCxtCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoCxtCmdReply
(
MgMgcoCxtCmdReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoCxtCmdReply(dst)
MgMgcoCxtCmdReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoCxtCmdReply)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoContextProps(&dst->cxt) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoCmdReplyLst(&dst->cl) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoCxtCmdReply*/
#endif
#ifdef MGT_GCP_VER_1_4
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoErrCmdRepSet
*
*    Desc:    Delete the structure MgMgcoErrCmdRepSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoErrCmdRepSet
(
MgMgcoErrCmdRepSet *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoErrCmdRepSet(dst)
MgMgcoErrCmdRepSet *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoErrCmdRepSet)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoErrDesc(&dst->err) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoCxtCmdReply(&dst->reply) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoErrCmdRepSet*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoErrCmdRepSet
*
*    Desc:    Delete the structure MgMgcoErrCmdRepSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoErrCmdRepSet
(
MgMgcoErrCmdRepSet *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoErrCmdRepSet(dst)
MgMgcoErrCmdRepSet *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoErrCmdRepSet)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoErrDesc(&dst->err) != ROK)
         RETVALUE(RFAILED);
      if (mgUtlDelMgMgcoCxtCmdReply(&dst->reply) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoErrCmdRepSet*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoActnReply
*
*    Desc:    Delete the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoActnReply
(
MgMgcoActnReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoActnReply(dst)
MgMgcoActnReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoActnReply)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoErrCmdRepSet(&dst->repErrSet) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoActnReply*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoActnReply
*
*    Desc:    Delete the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoActnReply
(
MgMgcoActnReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoActnReply(dst)
MgMgcoActnReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoActnReply)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoErrCmdRepSet(&dst->repErrSet) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoActnReply*/
#endif
#else /* MGT_GCP_VER_1_4 */
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoActnReply
*
*    Desc:    Delete the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoActnReply
(
MgMgcoActnReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoActnReply(dst)
MgMgcoActnReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoActnReply)

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_CXTCMDREPLY :
               if (mgUtlDelMgMgcoCxtCmdReply(&dst->u.reply) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_ERRDESC :
               if (mgUtlDelMgMgcoErrDesc(&dst->u.err) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoActnReply*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoActnReply
*
*    Desc:    Delete the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoActnReply
(
MgMgcoActnReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoActnReply(dst)
MgMgcoActnReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoActnReply)

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_CXTCMDREPLY :
               if (mgUtlDelMgMgcoCxtCmdReply(&dst->u.reply) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_ERRDESC :
               if (mgUtlDelMgMgcoErrDesc(&dst->u.err) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoActnReply*/
#endif
#endif /* MGT_GCP_VER_1_4 */
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoActnReplyLst
*
*    Desc:    Delete the structure MgMgcoActnReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoActnReplyLst
(
MgMgcoActnReplyLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoActnReplyLst(dst)
MgMgcoActnReplyLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoActnReplyLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoActnReply(dst->repl[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->repl[i], sizeof(MgMgcoActnReply));
      }
      MGFREE(dst->repl, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoActnReplyLst*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoActnReplyLst
*
*    Desc:    Delete the structure MgMgcoActnReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoActnReplyLst
(
MgMgcoActnReplyLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoActnReplyLst(dst)
MgMgcoActnReplyLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoActnReplyLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoActnReply(dst->repl[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->repl[i], sizeof(MgMgcoActnReply));
      }
      MGFREE(dst->repl, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoActnReplyLst*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoTxnReply
*
*    Desc:    Delete the structure MgMgcoTxnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTxnReply
(
MgMgcoTxnReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTxnReply(dst)
MgMgcoTxnReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoTxnReply)

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_ACTIONREPLY :
               if (mgUtlDelMgMgcoActnReplyLst(&dst->u.arl) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_ERRDESC :
               if (mgUtlDelMgMgcoErrDesc(&dst->u.err) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTxnReply*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoTxnReply
*
*    Desc:    Delete the structure MgMgcoTxnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTxnReply
(
MgMgcoTxnReply *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTxnReply(dst)
MgMgcoTxnReply *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoTxnReply)

   if(dst->pres.pres != NOTPRSNT)
   {
      if( dst->type.pres != NOTPRSNT )
      {
         switch( dst->type.val )
         {
            case  MGT_ACTIONREPLY :
               if (mgUtlDelMgMgcoActnReplyLst(&dst->u.arl) != ROK)
                  RETVALUE(RFAILED);
               break;
            case  MGT_ERRDESC :
               if (mgUtlDelMgMgcoErrDesc(&dst->u.err) != ROK)
                  RETVALUE(RFAILED);
               break;
            default:
               RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTxnReply*/
#endif

/*
*
*    Fun:    mgUtlDelMgMgcoTxnRspAck
*
*    Desc:    Delete the structure MgMgcoTxnRspAck
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTxnRspAck
(
MgMgcoTxnRspAck *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTxnRspAck(dst)
MgMgcoTxnRspAck *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoTxnRspAck)

   if( dst->num.pres != NOTPRSNT )
   {
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTxnRspAck*/
#ifdef GCP_VER_1_3
#ifdef GCP_CH

/*
*
*    Fun:    mgUtlDelMgMgcoTxn
*
*    Desc:    Delete the structure MgMgcoTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTxn
(
MgMgcoTxn *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTxn(dst)
MgMgcoTxn *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoTxn)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_TXNLOCAL_ERR :
            break;
         case  MGT_TXNPEND :
            break;
         case  MGT_TXNREPLY :
            if (mgUtlDelMgMgcoTxnReply(&dst->u.reply) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXNREQ :
            if (mgUtlDelMgMgcoTxnReq(&dst->u.req) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXNRSPACK :
            if (mgUtlDelMgMgcoTxnRspAck(&dst->u.rspAck) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
#if(  defined(  ZG_DFTHA)  || defined(  DG) ) 
#endif /*   defined(  ZG_DFTHA)  || defined(  DG) )   */
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTxn*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoTxn
*
*    Desc:    Delete the structure MgMgcoTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTxn
(
MgMgcoTxn *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTxn(dst)
MgMgcoTxn *dst;
#endif
{
   S16 ret;
   CmMemListCp mem;

   TRC3(mgUtlDelMgMgcoTxn)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_TXNLOCAL_ERR :
            break;
         case  MGT_TXNPEND :
            break;
         case  MGT_TXNREPLY :
            if (mgUtlDelMgMgcoTxnReply(&dst->u.reply) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXNREQ :
            if (mgUtlDelMgMgcoTxnReq(&dst->u.req) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXNRSPACK :
            if (mgUtlDelMgMgcoTxnRspAck(&dst->u.rspAck) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
#if(  defined(  ZG_DFTHA)  || defined(  DG) ) 
#endif /*   defined(  ZG_DFTHA)  || defined(  DG) )   */
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTxn*/
#endif
#else

/*
*
*    Fun:    mgUtlDelMgMgcoTxn
*
*    Desc:    Delete the structure MgMgcoTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTxn
(
MgMgcoTxn *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTxn(dst)
MgMgcoTxn *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoTxn)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_TXNLOCAL_ERR :
            break;
         case  MGT_TXNPEND :
            break;
         case  MGT_TXNREPLY :
            if (mgUtlDelMgMgcoTxnReply(&dst->u.reply) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXNREQ :
            if (mgUtlDelMgMgcoTxnReq(&dst->u.req) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXNRSPACK :
            if (mgUtlDelMgMgcoTxnRspAck(&dst->u.rspAck) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTxn*/
#endif
#ifdef GCP_VER_1_3

/*
*
*    Fun:    mgUtlDelMgMgcoTxnLst
*
*    Desc:    Delete the structure MgMgcoTxnLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTxnLst
(
MgMgcoTxnLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTxnLst(dst)
MgMgcoTxnLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoTxnLst)

   for (i=0;i<dst->num.val;i++)
   {
      if (mgUtlDelMgMgcoTxn(dst->txns[i]) != ROK)
         RETVALUE(RFAILED);
      MGFREE(dst->txns[i], sizeof(MgMgcoTxn));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTxnLst*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoTxnLst
*
*    Desc:    Delete the structure MgMgcoTxnLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoTxnLst
(
MgMgcoTxnLst *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoTxnLst(dst)
MgMgcoTxnLst *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoTxnLst)

   if( dst->num.pres != NOTPRSNT )
   {
      for (i=0;i<dst->num.val;i++)
      {
         if (mgUtlDelMgMgcoTxn(dst->txns[i]) != ROK)
            RETVALUE(RFAILED);
         MGFREE(dst->txns[i], sizeof(MgMgcoTxn));
      }
      MGFREE(dst->txns, sizeof(Ptr)*(dst->num.val));
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoTxnLst*/
#endif
#ifdef GCP_VER_1_3

/*
*
*    Fun:    mgUtlDelMgMgcoMsgBody
*
*    Desc:    Delete the structure MgMgcoMsgBody
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoMsgBody
(
MgMgcoMsgBody *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoMsgBody(dst)
MgMgcoMsgBody *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoMsgBody)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_ERRDESC :
            if (mgUtlDelMgMgcoErrDesc(&dst->u.err) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXN :
            if (mgUtlDelMgMgcoTxnLst(&dst->u.tl) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoMsgBody*/
#else

/*
*
*    Fun:    mgUtlDelMgMgcoMsgBody
*
*    Desc:    Delete the structure MgMgcoMsgBody
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoMsgBody
(
MgMgcoMsgBody *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoMsgBody(dst)
MgMgcoMsgBody *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoMsgBody)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  MGT_ERRDESC :
            if (mgUtlDelMgMgcoErrDesc(&dst->u.err) != ROK)
               RETVALUE(RFAILED);
            break;
         case  MGT_TXN :
            if (mgUtlDelMgMgcoTxnLst(&dst->u.tl) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoMsgBody*/
#endif

/*
*
*    Fun:    mgUtlDelMgMgcoMsg
*
*    Desc:    Delete the structure MgMgcoMsg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoMsg
(
MgMgcoMsg *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoMsg(dst)
MgMgcoMsg *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoMsg)

   if (mgUtlDelMgMgcoAuthHdr(&dst->ah) != ROK)
      RETVALUE(RFAILED);
   if (mgUtlDelTknStrOSXL(&dst->mid) != ROK)
      RETVALUE(RFAILED);
#ifdef GCP_VER_1_3
   if (mgUtlDelMgMgcoMsgBody(&dst->body) != ROK)
      RETVALUE(RFAILED);
#else /*  GCP_VER_1_3 */ 
   if (mgUtlDelMgMgcoMsgBody(&dst->body) != ROK)
      RETVALUE(RFAILED);
#endif /*  GCP_VER_1_3  */
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoMsg*/
#if(  defined(  GCP_CH)  && defined(  GCP_VER_1_5) ) 

/*
*
*    Fun:    mgUtlDelMgMgcoCommand
*
*    Desc:    Delete the structure MgMgcoCommand
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoCommand
(
MgMgcoCommand *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoCommand(dst)
MgMgcoCommand *dst;
#endif
{
   Cntr i;

   TRC3(mgUtlDelMgMgcoCommand)

   if( dst->cmdType.pres != NOTPRSNT )
   {
      switch( dst->cmdType.val )
      {
         case  CH_CMD_TYPE_CFM :
            for (i=0;i<MGT_ONE_CMD;i++)
            {
               if (mgUtlDelMgMgcoCmdReply(dst->u.mgCmdCfm[i]) != ROK)
                  RETVALUE(RFAILED);
               MGFREE(dst->u.mgCmdCfm[i], sizeof(MgMgcoCmdReply));
            }
            break;
         case  CH_CMD_TYPE_IND :
            for (i=0;i<MGT_ONE_CMD;i++)
            {
               if (mgUtlDelMgMgcoCommandReq(dst->u.mgCmdInd[i]) != ROK)
                  RETVALUE(RFAILED);
               MGFREE(dst->u.mgCmdInd[i], sizeof(MgMgcoCommandReq));
            }
            break;
         case  CH_CMD_TYPE_REQ :
            for (i=0;i<MGT_ONE_CMD;i++)
            {
               if (mgUtlDelMgMgcoCommandReq(dst->u.mgCmdReq[i]) != ROK)
                  RETVALUE(RFAILED);
               MGFREE(dst->u.mgCmdReq[i], sizeof(MgMgcoCommandReq));
            }
            break;
         case  CH_CMD_TYPE_RSP :
            for (i=0;i<MGT_ONE_CMD;i++)
            {
               if (mgUtlDelMgMgcoCmdReply(dst->u.mgCmdRsp[i]) != ROK)
                  RETVALUE(RFAILED);
               MGFREE(dst->u.mgCmdRsp[i], sizeof(MgMgcoCmdReply));
            }
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoCommand*/

/*
*
*    Fun:    mgUtlDelMgMgcoChCntxt
*
*    Desc:    Delete the structure MgMgcoChCntxt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoChCntxt
(
MgMgcoChCntxt *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoChCntxt(dst)
MgMgcoChCntxt *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoChCntxt)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (mgUtlDelMgMgcoContextProps(&dst->cxtProps) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoChCntxt*/

/*
*
*    Fun:    mgUtlDelMgMgcoUpdateCntxt
*
*    Desc:    Delete the structure MgMgcoUpdateCntxt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoUpdateCntxt
(
MgMgcoUpdateCntxt *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoUpdateCntxt(dst)
MgMgcoUpdateCntxt *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoUpdateCntxt)

   if (mgUtlDelMgMgcoChCntxt(&dst->contextProp) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoUpdateCntxt*/

/*
*
*    Fun:    mgUtlDelMgMgcoInd
*
*    Desc:    Delete the structure MgMgcoInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_util.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelMgMgcoInd
(
MgMgcoInd *dst
)
#else
PUBLIC S16 mgUtlDelMgMgcoInd(dst)
MgMgcoInd *dst;
#endif
{

   TRC3(mgUtlDelMgMgcoInd)

   if (mgUtlDelMgMgcoErrDesc(&dst->err) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function mgUtlDelMgMgcoInd*/
#endif /* GCP_CH && GCP_VER_1_5 */


/*****************************************************************************
*
*       Fun  : mgUtlCmpTknStrOSXL
*
*       Desc : Compares Open strings
*
*       Ret  : TRUE, strings are equal
*              FALSE, not equal
*
*       Notes: Case insensitive comparison possible if specified
*
*
*       File:  so_cm.c
*
*****************************************************************************/
#ifdef ANSI
PUBLIC Bool mgUtlCmpTknStrOSXL
(
TknStrOSXL *str1,             /* String to compare                    */
TknStrOSXL *str2,             /* String to compare to                 */
Bool       caseSensitive      /* FALSE -> case insensitive comparison */
)
#else
PUBLIC Bool mgUtlCmpTknStrOSXL(str1, str2, caseSensitive)
TknStrOSXL *str1;             /* String to compare                    */
TknStrOSXL *str2;             /* String to compare to                 */
Bool       caseSensitive;     /* FALSE -> case insensitive comparison */
#endif
{
   U32      i;    /* Counter */
   TRC2(mgUtlCmpTknStrOSXL)

   if(str1->len != str2->len)
      RETVALUE (FALSE);
   if (caseSensitive == FALSE)
   {
      if(cmMemcmp((U8 *)str1->val,(U8 *)str2->val,(sizeof(U8)*str1->len)) == 0)
         RETVALUE(TRUE);
      RETVALUE(FALSE);
   }
   /* Case insensitive comparison */
   for (i=0; i < str1->len; i++)
   {
      if (SO_LOWERCASE(str1->val[i]) != SO_LOWERCASE(str2->val[i]))
      {
         RETVALUE(FALSE);
      }
   }
   /* Match in all characters */
   RETVALUE(TRUE);

}/* mgUtlCmpTknStrOSXL */

/*
*
*       Fun:   mgUtlCmpTknStrOSXLCi
*
*       Desc:  Case-insensitive comparison of TknStrOSXL with literal.
*
*       Ret:   ROK        match
*              RFAILED    no match
*
*       Notes:
*
*       File:  sogenutl.c
*
*/

#ifdef ANSI
PUBLIC S16 mgUtlCmpTknStrOSXLCi
(
TknStrOSXL    *tknStr,    /* Value to compare */
U8            *str,       /* literal string   */
U16           len         /* compare length   */
)
#else
PUBLIC S16 mgUtlCmpTknStrOSXLCi(tknStr, str, len)
TknStrOSXL    *tknStr;    /* Value to compare */
U8            *str;       /* literal string   */
U16           len;        /* compare length   */
#endif
{
   U16 i;  /* counter */

   TRC2(mgUtlCmpTknStrOSXLCi);

   if (tknStr == NULLP)
   {
      /* No match */
      RETVALUE(RFAILED);
   }

   if (tknStr->pres == NOTPRSNT)
   {
      RETVALUE(RFAILED);
   }

   if (tknStr->len < len)
   {
      RETVALUE(RFAILED);
   }

   for (i = 0; i < len; i++)
   {
      if (SO_LOWERCASE(tknStr->val[i]) != SO_LOWERCASE(str[i]))
      {
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);
} /* mgUtlCmpTknStrOSXLCi */

#endif /* AG */

/*
*
*       Fun:    mgUtlCpyGetMem
*
*       Desc:   Get memory for the copy function
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   sogenutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyGetMem
(
Ptr         *dstPtr,
U16         memSize,
CmMemListCp *cpyMemCp
)
#else
PUBLIC S16 mgUtlCpyGetMem(dstPtr, memSize, cpyMemCp)
Ptr         *dstPtr;
U16         memSize;
CmMemListCp *cpyMemCp;
#endif
{

   TRC2(mgUtlCpyGetMem);

   if (cpyMemCp != NULLP)
   {
      if (cmGetMem(cpyMemCp, memSize, dstPtr) != ROK)
      {
        /* :03/15/05:00:57   */
         /* SO_GEN_SMEM_ALARM; */
         RETVALUE(RFAILED);
      }
   }
   else
   {
      MGALLOC(dstPtr, memSize);
      if (*dstPtr == NULLP)
      {
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);
} /* mgUtlCpyGetMem */

/*
*
*       Fun:    mgUtlCpyTknStrOSXL
*
*       Desc:   Copies the TknStrOSXL struct
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   sogenutl.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlCpyTknStrOSXL
(
TknStrOSXL  *dstTknStrOSXL,
TknStrOSXL  *srcTknStrOSXL,
CmMemListCp *cpyMemCp
)
#else
PUBLIC S16 mgUtlCpyTknStrOSXL(dstTknStrOSXL, srcTknStrOSXL, cpyMemCp)
TknStrOSXL  *dstTknStrOSXL;
TknStrOSXL  *srcTknStrOSXL;
CmMemListCp *cpyMemCp;
#endif
{
   TRC2(mgUtlCpyTknStrOSXL);

   dstTknStrOSXL->pres = srcTknStrOSXL->pres;

   if (srcTknStrOSXL->pres == NOTPRSNT)
      RETVALUE(ROK);

   /* Alloc mem block for val */
   if (srcTknStrOSXL->len > 0)
   {
      dstTknStrOSXL->len = srcTknStrOSXL->len;

      if (mgUtlCpyGetMem((Ptr *)&dstTknStrOSXL->val,
                      (U16)(sizeof(U8) * srcTknStrOSXL->len), cpyMemCp) != ROK)
      {
         dstTknStrOSXL->pres = NOTPRSNT;
         dstTknStrOSXL->len = 0;
         RETVALUE(RFAILED);
      }
      cmMemcpy(dstTknStrOSXL->val, srcTknStrOSXL->val,
               srcTknStrOSXL->len);
   }

   RETVALUE(ROK);
} /* mgUtlCpyTknStrOSXL */


/* mg008.105: moving unused function within AG compiler flag */
#ifdef AG

#ifdef DEBUGP
/*
*
*       Fun:   mgUtlPrntMsg
*
*       Desc:  This function is used for debugging purposes to output the
*              contents of an encoded message buffer.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: bytesDec is set to -1 if this message has not been decoded.
*
*       File:  sogenutl.c
*
*/

#ifdef ANSI
PUBLIC S16 mgUtlPrntMsg
(
Buffer *mBuf,    /* encoded buffer */
Txt    *dbg,     /* debug message  */
U8     rxMsg,    /* TRUE if it is an incoming message */
MsgLen bytesDec  /* bytes decoded  */
)
#else
PUBLIC S16 mgUtlPrntMsg(mBuf, dbg, rxMsg, bytesDec)
Buffer *mBuf;     /* encoded buffer */
Txt    *dbg;      /* debug message  */
U8     rxMsg;     /* TRUE if it is an incoming message */
MsgLen bytesDec;  /* bytes decoded  */
#endif
{
   Data    *bufOut;              /* Unpacked message                    */
   U8      ch;                   /* Temporary character                 */
   MsgLen  bufOutLen;            /* Message length                      */
   MsgLen  unpacked;             /* number of bytes unpacked            */
   S16     ret;                  /* value returned by function calls    */
   MsgLen  i;                    /* Index into string                   */
   MsgLen  sLen;                 /* Length of string                    */
   Txt     *pPrintBuf;           /* Pointer to part of string to print  */
   Txt     linePrefix1[10];      /* Line at start of each message       */
   Txt     linePrefix2[10];      /* Index line for message              */
   U8      firstLine;            /* TRUE for 1st line of message        */

   TRC2(mgUtlPrntMsg);

   bufOutLen = 0;

   if (rxMsg == TRUE)
   {
      cmMemcpy((U8 *)linePrefix1, (U8 *)"---->", 6);
   }
   else
   {
      cmMemcpy((U8 *)linePrefix1,(U8 *) "<----", 6); 
   }
   cmMemcpy((U8 *)linePrefix2,(U8 *)"     ", 6);
   firstLine = TRUE;

   (Void) SFndLenMsg(mBuf, &bufOutLen);

   if (bufOutLen == 0)
   {
      SPrint(dbg);
      SPrint("\n---- Zero-length message! ----\n");
      RETVALUE(ROK);
   }

   /* Include zero terminator */
   MGALLOC(&bufOut, bufOutLen + 1);
   if (bufOut == NULLP)
   {
      RETVALUE(RFAILED);
   }

   ret = SCpyMsgFix(mBuf, 0, bufOutLen, bufOut, &unpacked);
   bufOutLen++;
   if (ret != ROK)
   {
      MGFREE(bufOut, bufOutLen);
      RETVALUE(ret);
   }

   /* Print debug header if supplied */
   if (dbg != (Txt *) NULLP)
   {
      if (cmStrlen((U8 *)dbg)>0)
      {
         SPrint(dbg);
         SPrint("\n");
      }
   }

   if ((bytesDec == 0) && (rxMsg == TRUE))
   {
      /* Nothing decoded */
      SPrint("*** Message not decoded ***\n");
   }

   sLen      = cmStrlen((U8 *)bufOut);
   /* Remember the beginning of the first line */
   pPrintBuf = (Txt *)bufOut;

   for (i = 0; i < sLen; i++)
   {
      /* Is this a non-printable character ? */
      if ( (bufOut[i] < ' ') || (bufOut[i] >= 127) )
      {
         /* Is this the end of the line ? */
         if (bufOut[i] == '\n')
         {
            /* Terminate the end of the line with string terminator -> \0 */
            bufOut[i] = 0;

            /* Print formatting strings */
            if (firstLine == TRUE)
            {
               SPrint(linePrefix1);
            }
            else
            {
               SPrint(linePrefix2);
            }
            firstLine = FALSE;
            /* Print the line, if string is 1 byte or more */
            if(*pPrintBuf)
               SPrint(pPrintBuf);
            SPrint("\n");
            /* Remember the start of the next line */
            pPrintBuf = (Txt *)&bufOut[i + 1];
         }
         else
         {
            /* Replace Unprintable control character witn '!'*/
            bufOut[i] = '!';
         }
      }
      /* Have we reached the last decoded byte ? */
      if ((rxMsg == TRUE) && (i == (bytesDec-1)) && (bytesDec < (sLen-3)) &&
          (bytesDec > 0))
      {
         /* Print last line before end of bytes decoded */
         if(pPrintBuf != (Txt *)&bufOut[i])
         {
            /* Last line is not empty */
            ch        = bufOut[i];
            bufOut[i] = 0;

            SPrint(pPrintBuf);

            bufOut[i] = ch;
            pPrintBuf = (Txt *)&bufOut[i];
         }
         SPrint("\n");
         SPrint("Undecoded part of message:\n");
      }
   }                                        

   SPrint("\n");

   MGFREE(bufOut, bufOutLen);

   RETVALUE(ROK);
} /* end of mgUtlPrntMsg */
#endif /* DEBUGP */
#endif /* AG */

/*
*
*       Fun:    mgUtlDelTknStrOSXL
*
*       Desc:   Frees the internal mem for the TknStrOSXL struct
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   ag_cpy.c
*
*/
#ifdef ANSI
PUBLIC S16 mgUtlDelTknStrOSXL
(
TknStrOSXL *delTknStrOSXL
)
#else
PUBLIC S16 mgUtlDelTknStrOSXL(delTknStrOSXL)
TknStrOSXL *delTknStrOSXL;
#endif
{
   TRC2(mgUtlDelTknStrOSXL);

   if (delTknStrOSXL->pres == NOTPRSNT)
      RETVALUE(ROK);

   if (delTknStrOSXL->len > 0)
      MGFREE(delTknStrOSXL->val, sizeof(U8) * delTknStrOSXL->len);

   delTknStrOSXL->pres = NOTPRSNT;
   delTknStrOSXL->len  = 0;

   RETVALUE(ROK);
} /* mgUtlDelTknStrOSXL */

/* mg008.105: moving unused function within AG compiler flag */
#ifdef AG

/*
*
*       Fun:   mgUtlGrowList
*
*       Desc:  This function grows a dynamic array.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: Providing a NULL pMemCp will result in allocation from
*              heap, otherwise pMemCp->memCp will be used.
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 mgUtlGrowList
(
Void     ***list,              /* Pointer to array to be resized     */
U16      typeSize,             /* Size if an array element           */
TknU16   *numComp,             /* Pointer to numComp                 */
CmMemListCp   *pMemCp                 /* event for allocating memory        */
)
#else
PUBLIC S16 mgUtlGrowList(list, typeSize, numComp, pMemCp)
Void     ***list;              /* Pointer to array to be resized     */
U16      typeSize;             /* Size if an array element           */
TknU16   *numComp;             /* Pointer to numComp                 */
CmMemListCp   *pMemCp;                /* event for allocating memory        */
#endif
{
   S16   ret;                  /* Function return values  */
   U16   numCompVal;           /* Numeric numComp         */

   TRC2(mgUtlGrowList)

   numCompVal = MG_GET_NUM_COMP(numComp);

   if (pMemCp != (CmMemListCp *)NULLP)
   {
      ret = mgUtlResizeEvntList((PTR *)list, numComp, (U16)(numCompVal + 1),
                                 pMemCp);
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

      ret = cmGetMem(pMemCp, (Size)typeSize,
                        (Ptr *)(&(*list)[numCompVal]));
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

      (Void) cmMemset((U8 *)(*list)[numCompVal], 0, (PTR)typeSize);
   }
   else
   {
      /* set numComp->val to 0 if numComp->pres == NOTPRSNT */
      /* it is used in the next step without checking */
      if (numComp->pres == NOTPRSNT)
         numComp->val = 0;

      ret = mgUtlResizeList((PTR *)list, &(numComp->val),
                              (U16)(numCompVal + 1));
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

      MGALLOC(&(*list)[numCompVal], typeSize);
      if ((*list)[numCompVal] == (Void *)NULLP)
      {
         RETVALUE(RFAILED);
      }
   }

   MG_FILL_NUM_COMP(numComp, numCompVal + 1);

   RETVALUE(ROK);
} /* mgUtlGrowList */


/*
*
*       Fun:   mgUtlShrinkList
*
*       Desc:  This function shrinks a dynamic array.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: Set pMemCp to NULL to deallocate the HEAP.
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 mgUtlShrinkList
(
Void     ***list,              /* Pointer to array to be resized     */
U16      typeSize,             /* Size if an array element           */
TknU16   *numComp,             /* Pointer to numComp                 */
CmMemListCp   *pMemCp                 /* event for allocating memory        */
)
#else
PUBLIC S16 mgUtlShrinkList(list, typeSize, numComp, pMemCp)
Void     ***list;              /* Pointer to array to be resized     */
U16      typeSize;             /* Size if an array element           */
TknU16   *numComp;             /* Pointer to numComp                 */
CmMemListCp   *pMemCp;                /* event for allocating memory        */
#endif
{
   U16   numCompVal;           /* Numeric numComp         */
   S16   ret;                  /* return Value */

   TRC2(mgUtlShrinkList)

   numCompVal = MG_GET_NUM_COMP(numComp);

   if (numCompVal > 0)
   {
      if (pMemCp == (CmMemListCp *)NULLP)
      {
         MGFREE((*list)[numCompVal - 1], typeSize);

         ret = mgUtlResizeList((PTR *)(list), &(numComp->val),
                              (U16)(numCompVal - 1));
         if (ret != ROK)
           RETVALUE(RFAILED);
      }
      else
      {
         (Void) mgUtlResizeEvntList((PTR *)(list), numComp,
                                    (U16)(numCompVal - 1),
                                    pMemCp);
      }
   }

   RETVALUE(ROK);
} /* mgUtlShrinkList */

/*
*
*       Fun:   mgUtlResizeEvntList
*
*       Desc:  Resizes a dynamic list in event structure.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: List must be a triple pointer.
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 mgUtlResizeEvntList
(
PTR      *list,      /* List to be resized         */
TknU16   *numComp,   /* Number of elements in list */
U16      newSize,    /* New number of elements     */
CmMemListCp   *pMemCp       /* Event structure            */
)
#else
PUBLIC S16 mgUtlResizeEvntList(list, numComp, newSize, pMemCp)
PTR      *list;      /* List to be resized         */
TknU16   *numComp;   /* Number of elements in list */
U16      newSize;    /* New number of elements     */
CmMemListCp   *pMemCp;      /* Event structure            */
#endif
{
   PTR newList;     /* New pointer list to be allocated   */
   U16 numCompVal;  /* Value of numComp                   */
   U16 granSize;    /* Granular size of pointer array     */

   TRC2(mgUtlResizeEvntList);

   numCompVal = MG_GET_NUM_COMP(numComp);

   if (newSize > 0)
   {
      /* compute current list size */
      if (numCompVal > 0)
      {
         granSize  = (U16)((numCompVal)/MG_DYNLIST_GRANULARITY);
         if (granSize * MG_DYNLIST_GRANULARITY < numCompVal)
         {
            granSize++;
         }

         granSize *= MG_DYNLIST_GRANULARITY;
      }
      else
      {
         granSize = 0;
      }

      /* Allocate a new block? */
      if (newSize > granSize)
      {
         granSize  = (U16)((newSize)/MG_DYNLIST_GRANULARITY);
         if (granSize * MG_DYNLIST_GRANULARITY < newSize)
         {
            granSize++;
         }
         granSize *= MG_DYNLIST_GRANULARITY;

         if (cmGetMem(pMemCp, granSize * sizeof(PTR),
                      (Ptr *)&newList) != ROK)
           RETVALUE(RFAILED);

         (Void) cmMemset((U8 *)newList, 0,
                         (PTR)granSize * sizeof(PTR));
      }
      else
      {
          newList = *list;
      }

      if (newSize < numCompVal)
      {
         (Void) cmMemset((U8 *)(newList + newSize * sizeof(PTR)), 0,
                         (PTR)(granSize - newSize) * sizeof(PTR));

         numCompVal = newSize;
      }
      if ((numCompVal > 0) && (newList != *list))
      {
         cmMemcpy((U8 *)newList, (U8 *) *list, numCompVal * sizeof(PTR));
      }
   }
   else
   {
      newList = (PTR)NULLP;
   }

   /* Can't free memory from event block until whole event is freed */

   *list = newList;
   MG_FILL_NUM_COMP(numComp, newSize);

   RETVALUE(ROK);
} /* end of mgUtlResizeEvntList */


/*
*
*       Fun:   mgUtlResizeList
*
*       Desc:  Resizes list in event structure.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: List must be a triple pointer.
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 mgUtlResizeList
(
PTR      *list,      /* List to be resized         */
U16      *numComp,   /* Number of elements in list */
U16      newSize     /* New number of elements     */
)
#else
PUBLIC S16 mgUtlResizeList(list, numComp, newSize)
PTR      *list;      /* List to be resized         */
U16      *numComp;   /* Number of elements in list */
U16      newSize;    /* New number of elements     */
#endif
{
   PTR newList;      /* Possible new list to allocate                 */
   U16 numCompVal;   /* Integer numComp value                         */
   U16 curGranSize;  /* Current array size in granular units          */
   U16 newGranSize;  /* New array size in granular units              */
   U16 granSize;     /* Granular array size (X * granular size)       */

   TRC2(mgUtlResizeList)

   numCompVal = *numComp;

   if (newSize > 0)
   {

      /* compute current list size in granular units */
      if (numCompVal > 0)
      {
         curGranSize = (U16)((numCompVal)/MG_DYNLIST_GRANULARITY);
         if ((U16)((numCompVal)%MG_DYNLIST_GRANULARITY) != 0)
            curGranSize ++;
      }
      else
      {
         curGranSize = 0;
      }

      newGranSize = (U16)(newSize/MG_DYNLIST_GRANULARITY);
      if ((U16)(newSize%MG_DYNLIST_GRANULARITY) != 0)
         newGranSize ++;

      granSize  = (U16)((newSize)/MG_DYNLIST_GRANULARITY);
      if ((U16)((newSize)%MG_DYNLIST_GRANULARITY) != 0)
         granSize ++;

      granSize *= MG_DYNLIST_GRANULARITY;

      /* Allocate a new block? */
      if (newGranSize != curGranSize)
      {
         MGALLOC(&newList, granSize * sizeof(PTR));
         if (newList == NULLP)
           RETVALUE(RFAILED);
      }
      else
      {
          newList = *list;
      }

      if (newSize < numCompVal)
      {
         (Void) cmMemset((U8 *)(newList + newSize * sizeof(PTR)), 0,
                         (PTR)(granSize - newSize) * sizeof(PTR));

         numCompVal = newSize;
      }
      if ((numCompVal > 0) && (newList != *list))
      {
         cmMemcpy((U8 *)newList, (U8 *) *list, numCompVal * sizeof(PTR));
      }
   }
   else
   {
      newList = (PTR)NULLP;
   }

   /* Free old list if a new one was allocated */
   if ((*list != (PTR)NULLP) && (*list != newList))
   {
      MGFREE(*list, *numComp * sizeof(PTR));
   }

   *list    = newList;
   *numComp = newSize;

   RETVALUE(ROK);

} /* end of mgUtlResizeList */

#endif /* AG */

#endif /* GCP_MGCO && GCP_CH */
/********************************************************************30**
 
         End of file:     mp_util.c@@/main/mgcp_rel_1.5_mnt/6 - Thu Jul 14 12:32:51 2005
 
*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---       pk  1. Initial release.
             mg003.102 vj  1. As a part of MGT status indication, provide 
                              the remote port number as a part of peerInfo, 
                              if it is available. 
             mg004.102 vj  1. Made mgCb & dnsPrntBuf declarations as extern, 
                              since they are already defined in mg_ui.c
             mg005.102 bbk 1. Made changes to mgLocatePeer(). The function 
                              was calling a macro MG_FIND_PEER_FROM_DOMAIN_INFO
                              with adequate information to distinguish between
                              whether address entry needs to be located or
                              peer entry needs to be located.
                           2. Optimised the mgLocatePeer() function
            mg007.102  vj  1. Modified encodeLen param of mgConvertIpAddrToAscii 
                              from U8* to U16*
            mg008.102  vj  1. Modify mgGetLstnrForTx so that next server 
                              updation is correct when wrap-around happens. 
                              Made changes for SSAP servers as well as TSAP 
                              server list.
            mg011.102  vj  1. Modified mgLocatePeer to ensure that proper lists
                              are searched.
                           2. Since the macros MG_ISSUE_PEER_STAIND and 
                              MG_COPY_PEERINFO_INTO_TXN have been broken into 
                              MGCP & MGCO specific macros, converted the calls 
                              to each specific macro.
/main/2      ---      ra   1. GCP 1.3 release
            mg007.103 ra   1. The function -
                              mgFillMgcoErrMsg
                              has been changed. In the function, rxCb is not
                              being deallocated if the 30 sec timer has been
                              enabled. This will allow an outgoing response
                              rejected by the stack to be resent by the service
                              user. However, if the 30 sec timer has been
                              disabled, we are deallocating the rxCb because
                              not doing that may leave scope for hanging buffers.
            mg010.103 rg   1. Added check for peer configuration before
                              enabling the SSAP on MG side.
            mg011.103 ra   1. Added 3 new functions -
                              mgMgcoFreeMedDsTkBf
                              mgMgcoFreeAllTkBfs
                              mgMgcpFreeAllTkBfs
                              mgMgcpFreeAllTxnTkBfs
                              The 2nd & 4th functions are called from the
                              corresponding FREE_EVNT macros for MGCP and
                              MEGACO. The first function is called from the
                              mgMgcoFreeAllTkBfs function. These functions
                              find and release any SDP TknBuf type buffers
                              if the CM_SDP_OPAQUE flag has been used.
            mg013.103 ra   1. Changes for supporting errorDesc in msgBody.
            mg014.103 ra   1. Initialized some variables.
            mg017.103 ra   1. Enhanced the macro MG_FREE_RSRCS_ON_TXNREQ_ERROR
                              to ensure that the rxCb->mBuf gets re-initialized
                              to NULLP in case the mBuf is to be deleted.
/main/3      ---      ka   1. Changes for Release v 1.4            
            mg008.104 ra   1. Added new function - mgRemSsapSrvrsForThisTsap,
                              which works on a peer tsap basis.
/main/4      ---      pk   1. GCP 1.5 release
            mg002.105 dp   1. Check for Null Entity if we are at tail of the 
                              list so point again to first node
                           2. Removed patch reference for 1.3 and 1.4
                           3. Check if srvrCb is NULL dont access its element
            mg003.105 dp   1. Changes to send command in case of CH to inform user
                              about transaction being aborted 
                           2. Added Utility copy function from AGSF product 
                           3. Bug fix for GCP PSF 
                           4. Changes to send command in case of CH to inform user
                              about transaction being aborted
                      pk  5. Bug fixes  
            mg004.105 gk  1. Removed mgChDelMappingAxnReqAndChilds
                          2. If peer is NULL then dont send err indication
                             to the user
            mg005.105 gk  1. Removal of warning
            mg007.105 gk  1. Bug fixes
            mg008.105 gk  1. we are using this function only in MGCP
                          2. New function added for handling wildcard context
                          3. Function added to grow the memory double pointer list
*********************************************************************91*/
