/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Mgcp Package database file

     Type:     C source file

     Desc:     Package support database for mgcp packages

     File:     mgcp_pdb.c

     Sid:      mgcp_pdb.c@@/main/mgcp_rel_1.5_mnt/2 - Wed Apr 27 15:07:34 2005

     Prg:      ra

*********************************************************************21*/
   

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#ifdef GCP_MGCP 

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_inet.h"       /* Inet header file */
#include "cm_tpt.h"        /* Transport  header file */
#include "cm_dns.h"
#ifdef ZG
#include "cm_psfft.h"      /* common PSF defines */
#include "cm_ftha.h"       /* common DFT/HA defines */
#endif /* ZG */
#include "mgt.h"
#include "cm_sdp.h"
#include "cm_mblk.h"       /* common event memory management */
#include "mgcp_pdb.h"

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_inet.x"       /* Inet header file */
#include "cm_tpt.x"        /* Transport  header file */
#include "cm_sdp.x"
#ifdef ZG
#include "cm_ftha.x"       /* common DFT/HA types */
#include "cm_psfft.x"      /* common PSF types */
#endif /* ZG */
#include "mgt.x"
#include "cm_abndb.x"
#include "cm_sdpdb.x"
#include "mg_db.x"
#include "mgcp_pdb.x"
   



/*
*  THE FOLLOWING PACKAGES ARE SUPPORTED GCP RELEASE 1.3 ONWARDS ONLY
*/
#ifdef GCP_VER_1_3



#ifdef  GCP_PKG_MGCP_ANNC_SERVER

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgARqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_A_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgARqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG A RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 700,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgARqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgARqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_A_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgARqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG A RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 701,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgARqEvSymOperFailEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgARqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgARqEvSymOperCompltEnumDef ,
&mgMsgDefPkgARqEvSymOperFailEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgARqEvEvntKnownChc =
{
    2 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgARqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgARqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG A RQ EV EVNT KNOWN " ,
    "PkgARqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 702,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgARqEvEvntKnownChc ,
    mgMsgRegExpPkgARqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgARqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgARqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgARqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgARqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgARqEvEvntDescChcElmnt ,
    mgMsgDefPkgARqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgARqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG A RQ EV EVNT DESC " ,
    "PkgARqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 703,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgARqEvEvntDescChc ,
    mgMsgRegExpPkgARqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgARqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgARqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgARqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgARqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgARqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG A RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 704,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgARqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgASgRqSymPlayAnAnncEnum =
{
    (Data *)"ann" ,
    MGT_MGCP_PKG_A_SG_RQ_SYM_PLAY_AN_ANNC
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgASgRqSymPlayAnAnncEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG A SG RQ SYM PLAY AN ANNC ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 705,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgASgRqSymPlayAnAnncEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgASgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgASgRqSymPlayAnAnncEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgASgRqEvntKnownChc =
{
    1 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgASgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgASgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG A SG RQ EVNT KNOWN " ,
    "PkgASgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 706,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgASgRqEvntKnownChc ,
    mgMsgRegExpPkgASgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgASgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgASgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgASgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgASgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgASgRqEvntDescChcElmnt ,
    mgMsgDefPkgASgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgASgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG A SG RQ EVNT DESC " ,
    "PkgASgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 707,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgASgRqEvntDescChc ,
    mgMsgRegExpPkgASgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgASgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgASgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgASgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgASgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgASgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG A SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 708,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgASgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_ANNC_SERVER */




#ifdef  GCP_PKG_MGCP_ATM

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgAtmRqEvSymBrrPathSetup1Enum =
{
    (Data *)"sc" ,
    MGT_MGCP_PKG_ATM_RQ_EV_SYM_BRR_PATH_SETUP1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmRqEvSymBrrPathSetup1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG ATM RQ EV SYM BRR PATH SETUP1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 709,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgAtmRqEvSymBrrPathSetup1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgAtmRqEvSymBrrPathSetup2Enum =
{
    (Data *)"sf" ,
    MGT_MGCP_PKG_ATM_RQ_EV_SYM_BRR_PATH_SETUP2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmRqEvSymBrrPathSetup2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG ATM RQ EV SYM BRR PATH SETUP2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 710,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgAtmRqEvSymBrrPathSetup2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgAtmRqEvSymUsedCodecChngdEnum =
{
    (Data *)"uc" ,
    MGT_MGCP_PKG_ATM_RQ_EV_SYM_USED_CODEC_CHNGD
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmRqEvSymUsedCodecChngdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG ATM RQ EV SYM USED CODEC CHNGD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 711,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgAtmRqEvSymUsedCodecChngdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgAtmRqEvSymPcktznPeriodEnum =
{
    (Data *)"ptime" ,
    MGT_MGCP_PKG_ATM_RQ_EV_SYM_PCKTZN_PERIOD
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmRqEvSymPcktznPeriodEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG ATM RQ EV SYM PCKTZN PERIOD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 712,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgAtmRqEvSymPcktznPeriodEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgAtmRqEvSymProfElmntEnum =
{
    (Data *)"pftrans" ,
    MGT_MGCP_PKG_ATM_RQ_EV_SYM_PROF_ELMNT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmRqEvSymProfElmntEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG ATM RQ EV SYM PROF ELMNT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 713,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgAtmRqEvSymProfElmntEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgAtmRqEvSymCellLossEnum =
{
    (Data *)"cle" ,
    MGT_MGCP_PKG_ATM_RQ_EV_SYM_CELL_LOSS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmRqEvSymCellLossEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG ATM RQ EV SYM CELL LOSS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 714,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgAtmRqEvSymCellLossEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgAtmRqEvSymPcktLossThresEnum =
{
    (Data *)"pl" ,
    MGT_MGCP_PKG_ATM_RQ_EV_SYM_PCKT_LOSS_THRES
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmRqEvSymPcktLossThresEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG ATM RQ EV SYM PCKT LOSS THRES ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 715,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgAtmRqEvSymPcktLossThresEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgAtmRqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_ATM_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG ATM RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 716,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgAtmRqEvSymOperFailEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgAtmRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgAtmRqEvSymBrrPathSetup1EnumDef ,
&mgMsgDefPkgAtmRqEvSymBrrPathSetup2EnumDef ,
&mgMsgDefPkgAtmRqEvSymUsedCodecChngdEnumDef ,
&mgMsgDefPkgAtmRqEvSymPcktznPeriodEnumDef ,
&mgMsgDefPkgAtmRqEvSymProfElmntEnumDef ,
&mgMsgDefPkgAtmRqEvSymCellLossEnumDef ,
&mgMsgDefPkgAtmRqEvSymPcktLossThresEnumDef ,
&mgMsgDefPkgAtmRqEvSymOperFailEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgAtmRqEvEvntKnownChc =
{
    8 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgAtmRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG ATM RQ EV EVNT KNOWN " ,
    "PkgAtmRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 717,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgAtmRqEvEvntKnownChc ,
    mgMsgRegExpPkgAtmRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgAtmRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgAtmRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgAtmRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgAtmRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgAtmRqEvEvntDescChcElmnt ,
    mgMsgDefPkgAtmRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG ATM RQ EV EVNT DESC " ,
    "PkgAtmRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 718,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgAtmRqEvEvntDescChc ,
    mgMsgRegExpPkgAtmRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgAtmRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgAtmRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgAtmRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgAtmRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG ATM RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 719,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgAtmRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgAtmSgRqSymEnableCASEnum =
{
    (Data *)"ec" ,
    MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_C_A_S
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmSgRqSymEnableCASEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG ATM SG RQ SYM ENABLE C A S ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 720,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgAtmSgRqSymEnableCASEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgAtmSgRqSymEnableDTMFToneEnum =
{
    (Data *)"etd" ,
    MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_D_T_M_F_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmSgRqSymEnableDTMFToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG ATM SG RQ SYM ENABLE D T M F TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 721,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgAtmSgRqSymEnableDTMFToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgAtmSgRqSymEnableMFToneEnum =
{
    (Data *)"etm" ,
    MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmSgRqSymEnableMFToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG ATM SG RQ SYM ENABLE M F TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 722,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgAtmSgRqSymEnableMFToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgAtmSgRqSymEnableMFR1ToneEnum =
{
    (Data *)"etr1" ,
    MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_R1_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmSgRqSymEnableMFR1ToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG ATM SG RQ SYM ENABLE M F R1 TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 723,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgAtmSgRqSymEnableMFR1ToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgAtmSgRqSymEnableMFR2ToneEnum =
{
    (Data *)"etr2" ,
    MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_R2_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmSgRqSymEnableMFR2ToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG ATM SG RQ SYM ENABLE M F R2 TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 724,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgAtmSgRqSymEnableMFR2ToneEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgAtmSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgAtmSgRqSymEnableCASEnumDef ,
&mgMsgDefPkgAtmSgRqSymEnableDTMFToneEnumDef ,
&mgMsgDefPkgAtmSgRqSymEnableMFToneEnumDef ,
&mgMsgDefPkgAtmSgRqSymEnableMFR1ToneEnumDef ,
&mgMsgDefPkgAtmSgRqSymEnableMFR2ToneEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgAtmSgRqEvntKnownChc =
{
    5 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgAtmSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG ATM SG RQ EVNT KNOWN " ,
    "PkgAtmSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 725,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgAtmSgRqEvntKnownChc ,
    mgMsgRegExpPkgAtmSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgAtmSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgAtmSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgAtmSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgAtmSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgAtmSgRqEvntDescChcElmnt ,
    mgMsgDefPkgAtmSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG ATM SG RQ EVNT DESC " ,
    "PkgAtmSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 726,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgAtmSgRqEvntDescChc ,
    mgMsgRegExpPkgAtmSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgAtmSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgAtmSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgAtmSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgAtmSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG ATM SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 727,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgAtmSgRqEvntNameSeq ,
    NULLP
};





#ifdef GCP_2705BIS

PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameConnTypeEnum =
{
    (Data *)"ct" ,
    MGT_MGCP_CO_PKG_ATM_CONN_TYPE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameConnTypeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME CONN TYPE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 728,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameConnTypeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameVcBrrTypeEnum =
{
    (Data *)"vc" ,
    MGT_MGCP_CO_PKG_ATM_VC_BRR_TYPE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameVcBrrTypeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME VC BRR TYPE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 729,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameVcBrrTypeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameEnablePathSetUpEnum =
{
    (Data *)"se" ,
    MGT_MGCP_CO_PKG_ATM_ENABLE_PATH_SET_UP
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameEnablePathSetUpEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ENABLE PATH SET UP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 730,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameEnablePathSetUpEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameConnElmntIdEnum =
{
    (Data *)"ci" ,
    MGT_MGCP_CO_PKG_ATM_CONN_ELMNT_ID
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameConnElmntIdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME CONN ELMNT ID ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 731,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameConnElmntIdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameAppliEnum =
{
    (Data *)"aalApp" ,
    MGT_MGCP_CO_PKG_ATM_APPLI
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameAppliEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME APPLI ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 732,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameAppliEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameSubChnlCntEnum =
{
    (Data *)"sbc" ,
    MGT_MGCP_CO_PKG_ATM_SUB_CHNL_CNT
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameSubChnlCntEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME SUB CHNL CNT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 733,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameSubChnlCntEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNamePartFillEnum =
{
    (Data *)"pf" ,
    MGT_MGCP_CO_PKG_ATM_PART_FILL
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNamePartFillEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME PART FILL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 734,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNamePartFillEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameClkRecTypeEnum =
{
    (Data *)"crt" ,
    MGT_MGCP_CO_PKG_ATM_CLK_REC_TYPE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameClkRecTypeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME CLK REC TYPE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 735,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameClkRecTypeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameFecEnableEnum =
{
    (Data *)"fe" ,
    MGT_MGCP_CO_PKG_ATM_FEC_ENABLE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameFecEnableEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME FEC ENABLE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 736,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameFecEnableEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameProfLstTypeEnum =
{
    (Data *)"pfl" ,
    MGT_MGCP_CO_PKG_ATM_PROF_LST_TYPE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameProfLstTypeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME PROF LST TYPE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 737,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameProfLstTypeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameSimplCpsEnum =
{
    (Data *)"smplCPS" ,
    MGT_MGCP_CO_PKG_ATM_SIMPL_CPS
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameSimplCpsEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME SIMPL CPS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 738,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameSimplCpsEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameCombUseTmrEnum =
{
    (Data *)"tmcu" ,
    MGT_MGCP_CO_PKG_ATM_COMB_USE_TMR
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameCombUseTmrEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME COMB USE TMR ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 739,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameCombUseTmrEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameSrvcAccessPtEnum =
{
    (Data *)"aalsap" ,
    MGT_MGCP_CO_PKG_ATM_SRVC_ACCESS_PT
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameSrvcAccessPtEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME SRVC ACCESS PT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 740,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameSrvcAccessPtEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameCktModeEnum =
{
    (Data *)"cktmd" ,
    MGT_MGCP_CO_PKG_ATM_CKT_MODE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameCktModeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME CKT MODE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 741,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameCktModeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameFrameModEnableEnum =
{
    (Data *)"frmd" ,
    MGT_MGCP_CO_PKG_ATM_FRAME_MOD_ENABLE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameFrameModEnableEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME FRAME MOD ENABLE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 742,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameFrameModEnableEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameGenerPcmSetngEnum =
{
    (Data *)"genpcm" ,
    MGT_MGCP_CO_PKG_ATM_GENER_PCM_SETNG
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameGenerPcmSetngEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME GENER PCM SETNG ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 743,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameGenerPcmSetngEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameTxErrDetectEnum =
{
    (Data *)"ted" ,
    MGT_MGCP_CO_PKG_ATM_TX_ERR_DETECT
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameTxErrDetectEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME TX ERR DETECT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 744,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameTxErrDetectEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameSsarReassemTmrEnum =
{
    (Data *)"rastimer" ,
    MGT_MGCP_CO_PKG_ATM_SSAR_REASSEM_TMR
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameSsarReassemTmrEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME SSAR REASSEM TMR ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 745,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameSsarReassemTmrEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameVoiceCodecSelecEnum =
{
    (Data *)"vsel" ,
    MGT_MGCP_CO_PKG_ATM_VOICE_CODEC_SELEC
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameVoiceCodecSelecEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME VOICE CODEC SELEC ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 746,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameVoiceCodecSelecEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameDataCodecSelecEnum =
{
    (Data *)"dsel" ,
    MGT_MGCP_CO_PKG_ATM_DATA_CODEC_SELEC
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameDataCodecSelecEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME DATA CODEC SELEC ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 747,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameDataCodecSelecEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameFaxCodecSelecEnum =
{
    (Data *)"fsel" ,
    MGT_MGCP_CO_PKG_ATM_FAX_CODEC_SELEC
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameFaxCodecSelecEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME FAX CODEC SELEC ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 748,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameFaxCodecSelecEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameCodecCfgEnum =
{
    (Data *)"ccnf" ,
    MGT_MGCP_CO_PKG_ATM_CODEC_CFG
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameCodecCfgEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME CODEC CFG ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 749,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameCodecCfgEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameIsupUsrInfoEnum =
{
    (Data *)"usi" ,
    MGT_MGCP_CO_PKG_ATM_ISUP_USR_INFO
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameIsupUsrInfoEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ISUP USR INFO ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 750,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameIsupUsrInfoEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameAtmTransfCapabEnum =
{
    (Data *)"atc" ,
    MGT_MGCP_CO_PKG_ATM_ATM_TRANSF_CAPAB
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameAtmTransfCapabEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ATM TRANSF CAPAB ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 751,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameAtmTransfCapabEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameAtcSubTypeEnum =
{
    (Data *)"sbt" ,
    MGT_MGCP_CO_PKG_ATM_ATC_SUB_TYPE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameAtcSubTypeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ATC SUB TYPE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 752,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameAtcSubTypeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameQosClsEnum =
{
    (Data *)"qos" ,
    MGT_MGCP_CO_PKG_ATM_QOS_CLS
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameQosClsEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME QOS CLS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 753,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameQosClsEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameBroadBndConnOriBrrClsEnum =
{
    (Data *)"bcob" ,
    MGT_MGCP_CO_PKG_ATM_BROAD_BND_CONN_ORI_BRR_CLS
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameBroadBndConnOriBrrClsEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME BROAD BND CONN ORI BRR CLS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 754,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameBroadBndConnOriBrrClsEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameEtETmgRqdEnum =
{
    (Data *)"eetim" ,
    MGT_MGCP_CO_PKG_ATM_ET_E_TMG_RQD
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameEtETmgRqdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ET E TMG RQD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 755,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameEtETmgRqdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameSuscepToClipEnum =
{
    (Data *)"stc" ,
    MGT_MGCP_CO_PKG_ATM_SUSCEP_TO_CLIP
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameSuscepToClipEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME SUSCEP TO CLIP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 756,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameSuscepToClipEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameUsrPlnConnCfgEnum =
{
    (Data *)"upcc" ,
    MGT_MGCP_CO_PKG_ATM_USR_PLN_CONN_CFG
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameUsrPlnConnCfgEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME USR PLN CONN CFG ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 757,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameUsrPlnConnCfgEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameAtmQosParmsForwrdEnum =
{
    (Data *)"aqf" ,
    MGT_MGCP_CO_PKG_ATM_ATM_QOS_PARMS_FORWRD
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameAtmQosParmsForwrdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ATM QOS PARMS FORWRD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 758,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameAtmQosParmsForwrdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameAtmQosParmsBckwrdEnum =
{
    (Data *)"aqb" ,
    MGT_MGCP_CO_PKG_ATM_ATM_QOS_PARMS_BCKWRD
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameAtmQosParmsBckwrdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ATM QOS PARMS BCKWRD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 759,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameAtmQosParmsBckwrdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescForwrdClpIndEnum =
{
    (Data *)"adf0+1" ,
    MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_FORWRD_CLP_IND
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescForwrdClpIndEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ATM TRF DESC FORWRD CLP IND ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 760,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescForwrdClpIndEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescForwrdClpZeroEnum =
{
    (Data *)"adf0" ,
    MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_FORWRD_CLP_ZERO
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescForwrdClpZeroEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ATM TRF DESC FORWRD CLP ZERO ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 761,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescForwrdClpZeroEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescBckwrdClpIndEnum =
{
    (Data *)"adb0+1" ,
    MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_BCKWRD_CLP_IND
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescBckwrdClpIndEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ATM TRF DESC BCKWRD CLP IND ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 762,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescBckwrdClpIndEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescBckwrdClpZeroEnum =
{
    (Data *)"adb" ,
    MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_BCKWRD_CLP_ZERO
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescBckwrdClpZeroEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ATM TRF DESC BCKWRD CLP ZERO ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 763,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescBckwrdClpZeroEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameAbrParmsForwrdEnum =
{
    (Data *)"abrf" ,
    MGT_MGCP_CO_PKG_ATM_ABR_PARMS_FORWRD
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameAbrParmsForwrdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ABR PARMS FORWRD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 764,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameAbrParmsForwrdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameAbrParmsBckwrdEnum =
{
    (Data *)"abrb" ,
    MGT_MGCP_CO_PKG_ATM_ABR_PARMS_BCKWRD
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameAbrParmsBckwrdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ABR PARMS BCKWRD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 765,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameAbrParmsBckwrdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameAbrConnSetupParmsEnum =
{
    (Data *)"abrSetup" ,
    MGT_MGCP_CO_PKG_ATM_ABR_CONN_SETUP_PARMS
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameAbrConnSetupParmsEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME ABR CONN SETUP PARMS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 766,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameAbrConnSetupParmsEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameStructSizeEnum =
{
    (Data *)"str" ,
    MGT_MGCP_CO_PKG_ATM_STRUCT_SIZE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameStructSizeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME STRUCT SIZE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 767,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameStructSizeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameCbrRateEnum =
{
    (Data *)"cbrRate" ,
    MGT_MGCP_CO_PKG_ATM_CBR_RATE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameCbrRateEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME CBR RATE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 768,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameCbrRateEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameForMaxCpcsSduSizeEnum =
{
    (Data *)"fcpcs" ,
    MGT_MGCP_CO_PKG_ATM_FOR_MAX_CPCS_SDU_SIZE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameForMaxCpcsSduSizeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME FOR MAX CPCS SDU SIZE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 769,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameForMaxCpcsSduSizeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameBckMaxCpcsSduSizeEnum =
{
    (Data *)"bcpcs" ,
    MGT_MGCP_CO_PKG_ATM_BCK_MAX_CPCS_SDU_SIZE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameBckMaxCpcsSduSizeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME BCK MAX CPCS SDU SIZE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 770,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameBckMaxCpcsSduSizeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameForMaxAal2CpsSduSizeEnum =
{
    (Data *)"fSDUrate" ,
    MGT_MGCP_CO_PKG_ATM_FOR_MAX_AAL2_CPS_SDU_SIZE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameForMaxAal2CpsSduSizeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME FOR MAX AAL2 CPS SDU SIZE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 771,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameForMaxAal2CpsSduSizeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameBckMaxAal2CpsSduSizeEnum =
{
    (Data *)"bSDUrate" ,
    MGT_MGCP_CO_PKG_ATM_BCK_MAX_AAL2_CPS_SDU_SIZE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameBckMaxAal2CpsSduSizeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME BCK MAX AAL2 CPS SDU SIZE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 772,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameBckMaxAal2CpsSduSizeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameForMaxFrameBlkSizeEnum =
{
    (Data *)"ffrm" ,
    MGT_MGCP_CO_PKG_ATM_FOR_MAX_FRAME_BLK_SIZE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameForMaxFrameBlkSizeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME FOR MAX FRAME BLK SIZE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 773,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameForMaxFrameBlkSizeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameBckMaxFrameBlkSizeEnum =
{
    (Data *)"bfrm" ,
    MGT_MGCP_CO_PKG_ATM_BCK_MAX_FRAME_BLK_SIZE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameBckMaxFrameBlkSizeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME BCK MAX FRAME BLK SIZE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 774,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameBckMaxFrameBlkSizeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameForMaxSssarSduSizeEnum =
{
    (Data *)"fsssar" ,
    MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSSAR_SDU_SIZE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameForMaxSssarSduSizeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME FOR MAX SSSAR SDU SIZE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 775,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameForMaxSssarSduSizeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameBckMaxSssarSduSizeEnum =
{
    (Data *)"bsssar" ,
    MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSSAR_SDU_SIZE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameBckMaxSssarSduSizeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME BCK MAX SSSAR SDU SIZE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 776,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameBckMaxSssarSduSizeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameForMaxSscopSduSizeEnum =
{
    (Data *)"fsscopsdu" ,
    MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSCOP_SDU_SIZE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameForMaxSscopSduSizeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME FOR MAX SSCOP SDU SIZE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 777,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameForMaxSscopSduSizeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameBckMaxSscopSduSizeEnum =
{
    (Data *)"bsscopsdu" ,
    MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSCOP_SDU_SIZE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameBckMaxSscopSduSizeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME BCK MAX SSCOP SDU SIZE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 778,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameBckMaxSscopSduSizeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameForMaxSscopUuSizeEnum =
{
    (Data *)"fsscopuu" ,
    MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSCOP_UU_SIZE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameForMaxSscopUuSizeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME FOR MAX SSCOP UU SIZE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 779,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameForMaxSscopUuSizeEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgAtmExtnNameBckMaxSscopUuSizeEnum =
{
    (Data *)"bsscopuu" ,
    MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSCOP_UU_SIZE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameBckMaxSscopUuSizeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME BCK MAX SSCOP UU SIZE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 780,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameBckMaxSscopUuSizeEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefConnOptPkgAtmExtnNameTreeChcEnum[] =
{
NULLP ,
&mgMsgDefConnOptPkgAtmExtnNameConnTypeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameVcBrrTypeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameEnablePathSetUpEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameConnElmntIdEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameAppliEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameSubChnlCntEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNamePartFillEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameClkRecTypeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameFecEnableEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameProfLstTypeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameSimplCpsEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameCombUseTmrEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameSrvcAccessPtEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameCktModeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameFrameModEnableEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameGenerPcmSetngEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameTxErrDetectEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameSsarReassemTmrEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameVoiceCodecSelecEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameDataCodecSelecEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameFaxCodecSelecEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameCodecCfgEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameIsupUsrInfoEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameAtmTransfCapabEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameAtcSubTypeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameQosClsEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameBroadBndConnOriBrrClsEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameEtETmgRqdEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameSuscepToClipEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameUsrPlnConnCfgEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameAtmQosParmsForwrdEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameAtmQosParmsBckwrdEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescForwrdClpIndEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescForwrdClpZeroEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescBckwrdClpIndEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameAtmTrfDescBckwrdClpZeroEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameAbrParmsForwrdEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameAbrParmsBckwrdEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameAbrConnSetupParmsEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameStructSizeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameCbrRateEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameForMaxCpcsSduSizeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameBckMaxCpcsSduSizeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameForMaxAal2CpsSduSizeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameBckMaxAal2CpsSduSizeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameForMaxFrameBlkSizeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameBckMaxFrameBlkSizeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameForMaxSssarSduSizeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameBckMaxSssarSduSizeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameForMaxSscopSduSizeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameBckMaxSscopSduSizeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameForMaxSscopUuSizeEnumDef ,
&mgMsgDefConnOptPkgAtmExtnNameBckMaxSscopUuSizeEnumDef ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefConnOptPkgAtmExtnNameTreeChcElmnt[] =
{
    &mgMsgDefConnOptPkgExtnName ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefConnOptPkgAtmExtnNameTreeChc =
{
    54 ,
    0 ,
    NULLP ,
    mgMsgDefConnOptPkgAtmExtnNameTreeChcElmnt ,
    mgMsgDefConnOptPkgAtmExtnNameTreeChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgAtmExtnNameTree =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN OPT PKG ATM EXTN NAME TREE " ,
    "ConnOptPkgAtmExtnName" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 781,
    sizeof(MgMgcpName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefConnOptPkgAtmExtnNameTreeChc ,
    mgMsgRegExpConnOptPkgAtmExtnName
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgAtmConnOptNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefConnOptPkgAtmExtnNameTree
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgAtmConnOptNameSeq =
{
    3 ,
    mgMsgDefPkgAtmConnOptNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgAtmConnOptName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG ATM CONN OPT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 782,
    sizeof(MgPkgName) + sizeof(MgMgcpName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgAtmConnOptNameSeq ,
    NULLP
};

#endif  /* GCP_2705BIS */

#endif  /* GCP_PKG_MGCP_ATM */





#ifdef  GCP_PKG_MGCP_DTMF_DLPL_BASPBX

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBLRqEvSymOffhookEnum =
{
    (Data *)"hd" ,
    MGT_MGCP_PKG_B_L_RQ_EV_SYM_OFFHOOK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLRqEvSymOffhookEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B L RQ EV SYM OFFHOOK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 783,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBLRqEvSymOffhookEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBLRqEvSymFlashHookEnum =
{
    (Data *)"hf" ,
    MGT_MGCP_PKG_B_L_RQ_EV_SYM_FLASH_HOOK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLRqEvSymFlashHookEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B L RQ EV SYM FLASH HOOK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 784,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBLRqEvSymFlashHookEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBLRqEvSymOnhookEnum =
{
    (Data *)"hu" ,
    MGT_MGCP_PKG_B_L_RQ_EV_SYM_ONHOOK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLRqEvSymOnhookEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B L RQ EV SYM ONHOOK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 785,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBLRqEvSymOnhookEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBLRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_B_L_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B L RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 786,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBLRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBLRqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_B_L_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B L RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 787,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBLRqEvSymOperFailEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBLRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgBLRqEvSymOffhookEnumDef ,
&mgMsgDefPkgBLRqEvSymFlashHookEnumDef ,
&mgMsgDefPkgBLRqEvSymOnhookEnumDef ,
&mgMsgDefPkgBLRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgBLRqEvSymOperFailEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgBLRqEvEvntKnownChc =
{
    5 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgBLRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B L RQ EV EVNT KNOWN " ,
    "PkgBLRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 788,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgBLRqEvEvntKnownChc ,
    mgMsgRegExpPkgBLRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgBLRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBLRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgBLRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgBLRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgBLRqEvEvntDescChcElmnt ,
    mgMsgDefPkgBLRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B L RQ EV EVNT DESC " ,
    "PkgBLRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 789,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgBLRqEvEvntDescChc ,
    mgMsgRegExpPkgBLRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBLRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgBLRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgBLRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgBLRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B L RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 790,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgBLRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBLSgRqSymBusyToneEnum =
{
    (Data *)"bz" ,
    MGT_MGCP_PKG_B_L_SG_RQ_SYM_BUSY_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLSgRqSymBusyToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B L SG RQ SYM BUSY TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 791,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBLSgRqSymBusyToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBLSgRqSymDialToneEnum =
{
    (Data *)"dl" ,
    MGT_MGCP_PKG_B_L_SG_RQ_SYM_DIAL_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLSgRqSymDialToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B L SG RQ SYM DIAL TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 792,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBLSgRqSymDialToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBLSgRqSymReleaseEnum =
{
    (Data *)"rel" ,
    MGT_MGCP_PKG_B_L_SG_RQ_SYM_RELEASE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLSgRqSymReleaseEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B L SG RQ SYM RELEASE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 793,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBLSgRqSymReleaseEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBLSgRqSymRingingEnum =
{
    (Data *)"rg" ,
    MGT_MGCP_PKG_B_L_SG_RQ_SYM_RINGING
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLSgRqSymRingingEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B L SG RQ SYM RINGING ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 794,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBLSgRqSymRingingEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBLSgRqSymReorderToneEnum =
{
    (Data *)"ro" ,
    MGT_MGCP_PKG_B_L_SG_RQ_SYM_REORDER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLSgRqSymReorderToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B L SG RQ SYM REORDER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 795,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBLSgRqSymReorderToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBLSgRqSymRingbackToneEnum =
{
    (Data *)"rt" ,
    MGT_MGCP_PKG_B_L_SG_RQ_SYM_RINGBACK_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLSgRqSymRingbackToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B L SG RQ SYM RINGBACK TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 796,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBLSgRqSymRingbackToneEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBLSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgBLSgRqSymBusyToneEnumDef ,
&mgMsgDefPkgBLSgRqSymDialToneEnumDef ,
&mgMsgDefPkgBLSgRqSymReleaseEnumDef ,
&mgMsgDefPkgBLSgRqSymRingingEnumDef ,
&mgMsgDefPkgBLSgRqSymReorderToneEnumDef ,
&mgMsgDefPkgBLSgRqSymRingbackToneEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgBLSgRqEvntKnownChc =
{
    6 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgBLSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B L SG RQ EVNT KNOWN " ,
    "PkgBLSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 797,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgBLSgRqEvntKnownChc ,
    mgMsgRegExpPkgBLSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgBLSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBLSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgBLSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgBLSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgBLSgRqEvntDescChcElmnt ,
    mgMsgDefPkgBLSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B L SG RQ EVNT DESC " ,
    "PkgBLSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 798,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgBLSgRqEvntDescChc ,
    mgMsgRegExpPkgBLSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBLSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgBLSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgBLSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgBLSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBLSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B L SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 799,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgBLSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_DTMF_DLPL_BASPBX */




#ifdef  GCP_PKG_MGCP_CNTRY_SPEC_TONE

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_C_S_T_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 800,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTRqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_C_S_T_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 801,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTRqEvSymOperFailEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgCSTRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgCSTRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgCSTRqEvSymOperFailEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgCSTRqEvEvntKnownChc =
{
    2 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgCSTRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG C S T RQ EV EVNT KNOWN " ,
    "PkgCSTRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 802,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgCSTRqEvEvntKnownChc ,
    mgMsgRegExpPkgCSTRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgCSTRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgCSTRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgCSTRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgCSTRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgCSTRqEvEvntDescChcElmnt ,
    mgMsgDefPkgCSTRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG C S T RQ EV EVNT DESC " ,
    "PkgCSTRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 803,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgCSTRqEvEvntDescChc ,
    mgMsgRegExpPkgCSTRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgCSTRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgCSTRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgCSTRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgCSTRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG C S T RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 804,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgCSTRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymAcceptanceToneEnum =
{
    (Data *)"ac" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ACCEPTANCE_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymAcceptanceToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM ACCEPTANCE TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 805,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymAcceptanceToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymOtherBusyTones2Enum =
{
    (Data *)"bz2" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_BUSY_TONES2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymOtherBusyTones2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM OTHER BUSY TONES2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 806,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymOtherBusyTones2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymOtherBusyTones3Enum =
{
    (Data *)"bz3" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_BUSY_TONES3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymOtherBusyTones3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM OTHER BUSY TONES3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 807,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymOtherBusyTones3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymCnfrmnToneIIEnum =
{
    (Data *)"cf2" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_CNFRMN_TONE_I_I
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymCnfrmnToneIIEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM CNFRMN TONE I I ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 808,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymCnfrmnToneIIEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymOtherCongesTones2Enum =
{
    (Data *)"cg2" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_CONGES_TONES2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymOtherCongesTones2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM OTHER CONGES TONES2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 809,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymOtherCongesTones2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymOtherCongesTones3Enum =
{
    (Data *)"cg3" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_CONGES_TONES3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymOtherCongesTones3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM OTHER CONGES TONES3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 810,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymOtherCongesTones3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymOtherDialTones2Enum =
{
    (Data *)"dl2" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_DIAL_TONES2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymOtherDialTones2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM OTHER DIAL TONES2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 811,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymOtherDialTones2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymOtherDialTones3Enum =
{
    (Data *)"dl3" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_DIAL_TONES3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymOtherDialTones3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM OTHER DIAL TONES3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 812,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymOtherDialTones3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymSecondDialTones1Enum =
{
    (Data *)"sd1" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymSecondDialTones1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM SECOND DIAL TONES1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 813,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymSecondDialTones1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymSecondDialTones2Enum =
{
    (Data *)"sd2" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymSecondDialTones2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM SECOND DIAL TONES2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 814,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymSecondDialTones2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymSecondDialTones3Enum =
{
    (Data *)"sd3" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymSecondDialTones3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM SECOND DIAL TONES3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 815,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymSecondDialTones3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymExecOverRideToneEnum =
{
    (Data *)"eo" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_EXEC_OVER_RIDE_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymExecOverRideToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM EXEC OVER RIDE TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 816,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymExecOverRideToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymEndOf3PartyServEnum =
{
    (Data *)"es" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_END_OF3_PARTY_SERV
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymEndOf3PartyServEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM END OF3 PARTY SERV ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 817,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymEndOf3PartyServEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymFacilitiesToneEnum =
{
    (Data *)"fc" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_FACILITIES_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymFacilitiesToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM FACILITIES TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 818,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymFacilitiesToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymLineLockoutEnum =
{
    (Data *)"ll" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_LINE_LOCKOUT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymLineLockoutEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM LINE LOCKOUT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 819,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymLineLockoutEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymNumUnobtainableIIEnum =
{
    (Data *)"nu2" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_NUM_UNOBTAINABLE_I_I
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymNumUnobtainableIIEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM NUM UNOBTAINABLE I I ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 820,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymNumUnobtainableIIEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymOfferingToneEnum =
{
    (Data *)"or" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OFFERING_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymOfferingToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM OFFERING TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 821,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymOfferingToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymPayphoneRecog2Enum =
{
    (Data *)"pr2" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymPayphoneRecog2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM PAYPHONE RECOG2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 822,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymPayphoneRecog2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymPayphoneRecog3Enum =
{
    (Data *)"pr3" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymPayphoneRecog3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM PAYPHONE RECOG3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 823,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymPayphoneRecog3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymPayphoneRecog4Enum =
{
    (Data *)"pr4" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG4
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymPayphoneRecog4EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM PAYPHONE RECOG4 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 824,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymPayphoneRecog4Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymQueueToneEnum =
{
    (Data *)"qu" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_QUEUE_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymQueueToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM QUEUE TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 825,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymQueueToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymRefusalToneEnum =
{
    (Data *)"rf" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_REFUSAL_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymRefusalToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM REFUSAL TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 826,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymRefusalToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymRouteTone1Enum =
{
    (Data *)"ru1" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ROUTE_TONE1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymRouteTone1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM ROUTE TONE1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 827,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymRouteTone1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymRouteTone2Enum =
{
    (Data *)"ru2" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ROUTE_TONE2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymRouteTone2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM ROUTE TONE2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 828,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymRouteTone2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymRingingTone2Enum =
{
    (Data *)"rt2" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymRingingTone2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM RINGING TONE2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 829,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymRingingTone2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymRingingTone3Enum =
{
    (Data *)"rt3" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymRingingTone3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM RINGING TONE3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 830,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymRingingTone3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymRingingTone4Enum =
{
    (Data *)"rt4" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE4
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymRingingTone4EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM RINGING TONE4 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 831,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymRingingTone4Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymSrvcActivtdToneEnum =
{
    (Data *)"sa" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SRVC_ACTIVTD_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymSrvcActivtdToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM SRVC ACTIVTD TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 832,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymSrvcActivtdToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymValidToneEnum =
{
    (Data *)"va" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_VALID_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymValidToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM VALID TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 833,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymValidToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymWaitingTone1Enum =
{
    (Data *)"wa1" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymWaitingTone1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM WAITING TONE1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 834,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymWaitingTone1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymWaitingTone2Enum =
{
    (Data *)"wa2" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymWaitingTone2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM WAITING TONE2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 835,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymWaitingTone2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymWaitingTone3Enum =
{
    (Data *)"wa3" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymWaitingTone3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM WAITING TONE3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 836,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymWaitingTone3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymWarningEndOrPeriodEnum =
{
    (Data *)"we" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_END_OR_PERIOD
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymWarningEndOrPeriodEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM WARNING END OR PERIOD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 837,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymWarningEndOrPeriodEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymWarningPIPToneEnum =
{
    (Data *)"wp" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_P_I_P_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymWarningPIPToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM WARNING P I P TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 838,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymWarningPIPToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymWarningToneOper1Enum =
{
    (Data *)"wr1" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_TONE_OPER1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymWarningToneOper1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM WARNING TONE OPER1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 839,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymWarningToneOper1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgCSTSgRqSymWarningToneOper2Enum =
{
    (Data *)"wr2" ,
    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_TONE_OPER2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqSymWarningToneOper2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ SYM WARNING TONE OPER2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 840,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqSymWarningToneOper2Enum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgCSTSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgCSTSgRqSymAcceptanceToneEnumDef ,
&mgMsgDefPkgCSTSgRqSymOtherBusyTones2EnumDef ,
&mgMsgDefPkgCSTSgRqSymOtherBusyTones3EnumDef ,
&mgMsgDefPkgCSTSgRqSymCnfrmnToneIIEnumDef ,
&mgMsgDefPkgCSTSgRqSymOtherCongesTones2EnumDef ,
&mgMsgDefPkgCSTSgRqSymOtherCongesTones3EnumDef ,
&mgMsgDefPkgCSTSgRqSymOtherDialTones2EnumDef ,
&mgMsgDefPkgCSTSgRqSymOtherDialTones3EnumDef ,
&mgMsgDefPkgCSTSgRqSymSecondDialTones1EnumDef ,
&mgMsgDefPkgCSTSgRqSymSecondDialTones2EnumDef ,
&mgMsgDefPkgCSTSgRqSymSecondDialTones3EnumDef ,
&mgMsgDefPkgCSTSgRqSymExecOverRideToneEnumDef ,
&mgMsgDefPkgCSTSgRqSymEndOf3PartyServEnumDef ,
&mgMsgDefPkgCSTSgRqSymFacilitiesToneEnumDef ,
&mgMsgDefPkgCSTSgRqSymLineLockoutEnumDef ,
&mgMsgDefPkgCSTSgRqSymNumUnobtainableIIEnumDef ,
&mgMsgDefPkgCSTSgRqSymOfferingToneEnumDef ,
&mgMsgDefPkgCSTSgRqSymPayphoneRecog2EnumDef ,
&mgMsgDefPkgCSTSgRqSymPayphoneRecog3EnumDef ,
&mgMsgDefPkgCSTSgRqSymPayphoneRecog4EnumDef ,
&mgMsgDefPkgCSTSgRqSymQueueToneEnumDef ,
&mgMsgDefPkgCSTSgRqSymRefusalToneEnumDef ,
&mgMsgDefPkgCSTSgRqSymRouteTone1EnumDef ,
&mgMsgDefPkgCSTSgRqSymRouteTone2EnumDef ,
&mgMsgDefPkgCSTSgRqSymRingingTone2EnumDef ,
&mgMsgDefPkgCSTSgRqSymRingingTone3EnumDef ,
&mgMsgDefPkgCSTSgRqSymRingingTone4EnumDef ,
&mgMsgDefPkgCSTSgRqSymSrvcActivtdToneEnumDef ,
&mgMsgDefPkgCSTSgRqSymValidToneEnumDef ,
&mgMsgDefPkgCSTSgRqSymWaitingTone1EnumDef ,
&mgMsgDefPkgCSTSgRqSymWaitingTone2EnumDef ,
&mgMsgDefPkgCSTSgRqSymWaitingTone3EnumDef ,
&mgMsgDefPkgCSTSgRqSymWarningEndOrPeriodEnumDef ,
&mgMsgDefPkgCSTSgRqSymWarningPIPToneEnumDef ,
&mgMsgDefPkgCSTSgRqSymWarningToneOper1EnumDef ,
&mgMsgDefPkgCSTSgRqSymWarningToneOper2EnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgCSTSgRqEvntKnownChc =
{
    36 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgCSTSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ EVNT KNOWN " ,
    "PkgCSTSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 841,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgCSTSgRqEvntKnownChc ,
    mgMsgRegExpPkgCSTSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgCSTSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgCSTSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgCSTSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgCSTSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgCSTSgRqEvntDescChcElmnt ,
    mgMsgDefPkgCSTSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ EVNT DESC " ,
    "PkgCSTSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 842,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgCSTSgRqEvntDescChc ,
    mgMsgRegExpPkgCSTSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgCSTSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgCSTSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgCSTSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgCSTSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgCSTSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG C S T SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 843,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgCSTSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_CNTRY_SPEC_TONE */




#ifdef  GCP_PKG_MGCP_DTMF

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmf0Enum =
{
    (Data *)"0" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF0
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmf0EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF0 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 844,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmf0Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmf1Enum =
{
    (Data *)"1" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmf1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 845,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmf1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmf2Enum =
{
    (Data *)"2" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmf2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 846,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmf2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmf3Enum =
{
    (Data *)"3" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmf3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 847,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmf3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmf4Enum =
{
    (Data *)"4" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF4
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmf4EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF4 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 848,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmf4Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmf5Enum =
{
    (Data *)"5" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF5
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmf5EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF5 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 849,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmf5Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmf6Enum =
{
    (Data *)"6" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF6
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmf6EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF6 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 850,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmf6Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmf7Enum =
{
    (Data *)"7" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF7
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmf7EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF7 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 851,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmf7Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmf8Enum =
{
    (Data *)"8" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF8
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmf8EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF8 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 852,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmf8Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmf9Enum =
{
    (Data *)"9" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF9
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmf9EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF9 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 853,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmf9Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmfPoundEnum =
{
    (Data *)"#" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_POUND
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmfPoundEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF POUND ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 854,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmfPoundEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmfStarEnum =
{
    (Data *)"*" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_STAR
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmfStarEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF STAR ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 855,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmfStarEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmfAEnum =
{
    (Data *)"A" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_A
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmfAEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF A ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 856,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmfAEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmfBEnum =
{
    (Data *)"B" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_B
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmfBEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF B ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 857,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmfBEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmfCEnum =
{
    (Data *)"C" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_C
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmfCEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF C ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 858,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmfCEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmfDEnum =
{
    (Data *)"D" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_D
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmfDEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF D ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 859,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmfDEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymLongDurIndEnum =
{
    (Data *)"L" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_LONG_DUR_IND
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymLongDurIndEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM LONG DUR IND ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 860,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymLongDurIndEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymDtmfToneDurEnum =
{
    (Data *)"DD" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_TONE_DUR
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymDtmfToneDurEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM DTMF TONE DUR ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 861,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymDtmfToneDurEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymWildcardMatchEnum =
{
    (Data *)"X" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_WILDCARD_MATCH
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymWildcardMatchEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM WILDCARD MATCH ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 862,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymWildcardMatchEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 863,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 864,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymOperFailEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDRqEvSymInterdgtTmrEnum =
{
    (Data *)"T" ,
    MGT_MGCP_PKG_D_RQ_EV_SYM_INTERDGT_TMR
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvSymInterdgtTmrEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D RQ EV SYM INTERDGT TMR ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 865,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvSymInterdgtTmrEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgDRqEvSymDtmf0EnumDef ,
&mgMsgDefPkgDRqEvSymDtmf1EnumDef ,
&mgMsgDefPkgDRqEvSymDtmf2EnumDef ,
&mgMsgDefPkgDRqEvSymDtmf3EnumDef ,
&mgMsgDefPkgDRqEvSymDtmf4EnumDef ,
&mgMsgDefPkgDRqEvSymDtmf5EnumDef ,
&mgMsgDefPkgDRqEvSymDtmf6EnumDef ,
&mgMsgDefPkgDRqEvSymDtmf7EnumDef ,
&mgMsgDefPkgDRqEvSymDtmf8EnumDef ,
&mgMsgDefPkgDRqEvSymDtmf9EnumDef ,
&mgMsgDefPkgDRqEvSymDtmfPoundEnumDef ,
&mgMsgDefPkgDRqEvSymDtmfStarEnumDef ,
&mgMsgDefPkgDRqEvSymDtmfAEnumDef ,
&mgMsgDefPkgDRqEvSymDtmfBEnumDef ,
&mgMsgDefPkgDRqEvSymDtmfCEnumDef ,
&mgMsgDefPkgDRqEvSymDtmfDEnumDef ,
&mgMsgDefPkgDRqEvSymLongDurIndEnumDef ,
&mgMsgDefPkgDRqEvSymDtmfToneDurEnumDef ,
&mgMsgDefPkgDRqEvSymWildcardMatchEnumDef ,
&mgMsgDefPkgDRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgDRqEvSymOperFailEnumDef ,
&mgMsgDefPkgDRqEvSymInterdgtTmrEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgDRqEvEvntKnownChc =
{
    22 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgDRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D RQ EV EVNT KNOWN " ,
    "PkgDRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 866,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgDRqEvEvntKnownChc ,
    mgMsgRegExpPkgDRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgDRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgDRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgDRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgDRqEvEvntDescChcElmnt ,
    mgMsgDefPkgDRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D RQ EV EVNT DESC " ,
    "PkgDRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 867,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgDRqEvEvntDescChc ,
    mgMsgRegExpPkgDRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgDRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgDRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgDRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 868,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgDRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmf0Enum =
{
    (Data *)"0" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF0
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmf0EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF0 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 869,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmf0Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmf1Enum =
{
    (Data *)"1" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmf1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 870,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmf1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmf2Enum =
{
    (Data *)"2" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmf2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 871,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmf2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmf3Enum =
{
    (Data *)"3" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmf3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 872,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmf3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmf4Enum =
{
    (Data *)"4" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF4
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmf4EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF4 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 873,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmf4Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmf5Enum =
{
    (Data *)"5" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF5
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmf5EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF5 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 874,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmf5Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmf6Enum =
{
    (Data *)"6" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF6
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmf6EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF6 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 875,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmf6Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmf7Enum =
{
    (Data *)"7" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF7
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmf7EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF7 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 876,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmf7Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmf8Enum =
{
    (Data *)"8" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF8
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmf8EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF8 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 877,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmf8Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmf9Enum =
{
    (Data *)"9" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF9
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmf9EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF9 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 878,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmf9Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmfPoundEnum =
{
    (Data *)"#" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_POUND
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmfPoundEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF POUND ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 879,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmfPoundEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmfStarEnum =
{
    (Data *)"*" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_STAR
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmfStarEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF STAR ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 880,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmfStarEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmfAEnum =
{
    (Data *)"A" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_A
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmfAEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF A ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 881,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmfAEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmfBEnum =
{
    (Data *)"B" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_B
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmfBEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF B ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 882,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmfBEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmfCEnum =
{
    (Data *)"C" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_C
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmfCEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF C ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 883,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmfCEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmfDEnum =
{
    (Data *)"D" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_D
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmfDEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF D ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 884,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmfDEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmfToneDurEnum =
{
    (Data *)"DD" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_TONE_DUR
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmfToneDurEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF TONE DUR ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 885,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmfToneDurEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymDtmfOoSigEnum =
{
    (Data *)"DO" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_OO_SIG
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymDtmfOoSigEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM DTMF OO SIG ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 886,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymDtmfOoSigEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDSgRqSymInterdgtTmrEnum =
{
    (Data *)"T" ,
    MGT_MGCP_PKG_D_SG_RQ_SYM_INTERDGT_TMR
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqSymInterdgtTmrEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D SG RQ SYM INTERDGT TMR ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1048 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqSymInterdgtTmrEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgDSgRqSymDtmf0EnumDef ,
&mgMsgDefPkgDSgRqSymDtmf1EnumDef ,
&mgMsgDefPkgDSgRqSymDtmf2EnumDef ,
&mgMsgDefPkgDSgRqSymDtmf3EnumDef ,
&mgMsgDefPkgDSgRqSymDtmf4EnumDef ,
&mgMsgDefPkgDSgRqSymDtmf5EnumDef ,
&mgMsgDefPkgDSgRqSymDtmf6EnumDef ,
&mgMsgDefPkgDSgRqSymDtmf7EnumDef ,
&mgMsgDefPkgDSgRqSymDtmf8EnumDef ,
&mgMsgDefPkgDSgRqSymDtmf9EnumDef ,
&mgMsgDefPkgDSgRqSymDtmfPoundEnumDef ,
&mgMsgDefPkgDSgRqSymDtmfStarEnumDef ,
&mgMsgDefPkgDSgRqSymDtmfAEnumDef ,
&mgMsgDefPkgDSgRqSymDtmfBEnumDef ,
&mgMsgDefPkgDSgRqSymDtmfCEnumDef ,
&mgMsgDefPkgDSgRqSymDtmfDEnumDef ,
&mgMsgDefPkgDSgRqSymDtmfToneDurEnumDef ,
&mgMsgDefPkgDSgRqSymDtmfOoSigEnumDef ,
&mgMsgDefPkgDSgRqSymInterdgtTmrEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgDSgRqEvntKnownChc =
{
    19 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgDSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D SG RQ EVNT KNOWN " ,
    "PkgDSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 887,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgDSgRqEvntKnownChc ,
    mgMsgRegExpPkgDSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgDSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgDSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgDSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgDSgRqEvntDescChcElmnt ,
    mgMsgDefPkgDSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D SG RQ EVNT DESC " ,
    "PkgDSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 888,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgDSgRqEvntDescChc ,
    mgMsgRegExpPkgDSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgDSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgDSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgDSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 889,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgDSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_DTMF */




#ifdef  GCP_PKG_MGCP_FXO_LSG_ANALOG

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDORqEvSymCallerIdEnum =
{
    (Data *)"ci" ,
    MGT_MGCP_PKG_D_O_RQ_EV_SYM_CALLER_ID
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDORqEvSymCallerIdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D O RQ EV SYM CALLER ID ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 890,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDORqEvSymCallerIdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDORqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_D_O_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDORqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D O RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 891,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDORqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDORqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_D_O_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDORqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D O RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 892,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDORqEvSymOperFailEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDORqEvSymReleaseCallEnum =
{
    (Data *)"rel" ,
    MGT_MGCP_PKG_D_O_RQ_EV_SYM_RELEASE_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDORqEvSymReleaseCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D O RQ EV SYM RELEASE CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 893,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDORqEvSymReleaseCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDORqEvSymRingingEnum =
{
    (Data *)"rg" ,
    MGT_MGCP_PKG_D_O_RQ_EV_SYM_RINGING
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDORqEvSymRingingEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D O RQ EV SYM RINGING ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 894,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDORqEvSymRingingEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDORqEvSymReleaseCompltEnum =
{
    (Data *)"rlc" ,
    MGT_MGCP_PKG_D_O_RQ_EV_SYM_RELEASE_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDORqEvSymReleaseCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D O RQ EV SYM RELEASE COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 895,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDORqEvSymReleaseCompltEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDORqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgDORqEvSymCallerIdEnumDef ,
&mgMsgDefPkgDORqEvSymOperCompltEnumDef ,
&mgMsgDefPkgDORqEvSymOperFailEnumDef ,
&mgMsgDefPkgDORqEvSymReleaseCallEnumDef ,
&mgMsgDefPkgDORqEvSymRingingEnumDef ,
&mgMsgDefPkgDORqEvSymReleaseCompltEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgDORqEvEvntKnownChc =
{
    6 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgDORqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDORqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D O RQ EV EVNT KNOWN " ,
    "PkgDORqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 896,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgDORqEvEvntKnownChc ,
    mgMsgRegExpPkgDORqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgDORqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDORqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgDORqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgDORqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgDORqEvEvntDescChcElmnt ,
    mgMsgDefPkgDORqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDORqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D O RQ EV EVNT DESC " ,
    "PkgDORqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 897,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgDORqEvEvntDescChc ,
    mgMsgRegExpPkgDORqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDORqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgDORqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgDORqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgDORqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDORqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D O RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 898,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgDORqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDOSgRqSymOffhookEnum =
{
    (Data *)"hd" ,
    MGT_MGCP_PKG_D_O_SG_RQ_SYM_OFFHOOK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDOSgRqSymOffhookEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D O SG RQ SYM OFFHOOK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 899,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDOSgRqSymOffhookEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDOSgRqSymHookFlashEnum =
{
    (Data *)"hf" ,
    MGT_MGCP_PKG_D_O_SG_RQ_SYM_HOOK_FLASH
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDOSgRqSymHookFlashEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D O SG RQ SYM HOOK FLASH ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 900,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDOSgRqSymHookFlashEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDOSgRqSymOnhookEnum =
{
    (Data *)"hu" ,
    MGT_MGCP_PKG_D_O_SG_RQ_SYM_ONHOOK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDOSgRqSymOnhookEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D O SG RQ SYM ONHOOK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 901,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDOSgRqSymOnhookEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDOSgRqSymCallSetupEnum =
{
    (Data *)"sup" ,
    MGT_MGCP_PKG_D_O_SG_RQ_SYM_CALL_SETUP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDOSgRqSymCallSetupEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D O SG RQ SYM CALL SETUP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 902,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDOSgRqSymCallSetupEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDOSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgDOSgRqSymOffhookEnumDef ,
&mgMsgDefPkgDOSgRqSymHookFlashEnumDef ,
&mgMsgDefPkgDOSgRqSymOnhookEnumDef ,
&mgMsgDefPkgDOSgRqSymCallSetupEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgDOSgRqEvntKnownChc =
{
    4 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgDOSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDOSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D O SG RQ EVNT KNOWN " ,
    "PkgDOSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 903,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgDOSgRqEvntKnownChc ,
    mgMsgRegExpPkgDOSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgDOSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDOSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgDOSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgDOSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgDOSgRqEvntDescChcElmnt ,
    mgMsgDefPkgDOSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDOSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D O SG RQ EVNT DESC " ,
    "PkgDOSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 904,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgDOSgRqEvntDescChc ,
    mgMsgRegExpPkgDOSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDOSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgDOSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgDOSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgDOSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDOSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D O SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 905,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgDOSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_FXO_LSG_ANALOG */




#ifdef  GCP_PKG_MGCP_DTMF_DIAL_PULSE

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTRqEvSymCallAnswerEnum =
{
    (Data *)"ans" ,
    MGT_MGCP_PKG_D_T_RQ_EV_SYM_CALL_ANSWER
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTRqEvSymCallAnswerEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T RQ EV SYM CALL ANSWER ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 906,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTRqEvSymCallAnswerEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTRqEvSymBlockEnum =
{
    (Data *)"bl" ,
    MGT_MGCP_PKG_D_T_RQ_EV_SYM_BLOCK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTRqEvSymBlockEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T RQ EV SYM BLOCK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 907,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTRqEvSymBlockEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_D_T_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 908,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTRqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_D_T_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 909,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTRqEvSymOperFailEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTRqEvSymReleaseCallEnum =
{
    (Data *)"rel" ,
    MGT_MGCP_PKG_D_T_RQ_EV_SYM_RELEASE_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTRqEvSymReleaseCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T RQ EV SYM RELEASE CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 910,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTRqEvSymReleaseCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTRqEvSymResumeCallEnum =
{
    (Data *)"res" ,
    MGT_MGCP_PKG_D_T_RQ_EV_SYM_RESUME_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTRqEvSymResumeCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T RQ EV SYM RESUME CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 911,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTRqEvSymResumeCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTRqEvSymReleaseCompltEnum =
{
    (Data *)"rlc" ,
    MGT_MGCP_PKG_D_T_RQ_EV_SYM_RELEASE_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTRqEvSymReleaseCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T RQ EV SYM RELEASE COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 912,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTRqEvSymReleaseCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTRqEvSymCallSetupEnum =
{
    (Data *)"sup" ,
    MGT_MGCP_PKG_D_T_RQ_EV_SYM_CALL_SETUP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTRqEvSymCallSetupEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T RQ EV SYM CALL SETUP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 913,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTRqEvSymCallSetupEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTRqEvSymSuspendCallEnum =
{
    (Data *)"sus" ,
    MGT_MGCP_PKG_D_T_RQ_EV_SYM_SUSPEND_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTRqEvSymSuspendCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T RQ EV SYM SUSPEND CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 914,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTRqEvSymSuspendCallEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDTRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgDTRqEvSymCallAnswerEnumDef ,
&mgMsgDefPkgDTRqEvSymBlockEnumDef ,
&mgMsgDefPkgDTRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgDTRqEvSymOperFailEnumDef ,
&mgMsgDefPkgDTRqEvSymReleaseCallEnumDef ,
&mgMsgDefPkgDTRqEvSymResumeCallEnumDef ,
&mgMsgDefPkgDTRqEvSymReleaseCompltEnumDef ,
&mgMsgDefPkgDTRqEvSymCallSetupEnumDef ,
&mgMsgDefPkgDTRqEvSymSuspendCallEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgDTRqEvEvntKnownChc =
{
    9 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgDTRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D T RQ EV EVNT KNOWN " ,
    "PkgDTRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 915,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgDTRqEvEvntKnownChc ,
    mgMsgRegExpPkgDTRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgDTRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDTRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgDTRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgDTRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgDTRqEvEvntDescChcElmnt ,
    mgMsgDefPkgDTRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D T RQ EV EVNT DESC " ,
    "PkgDTRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 916,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgDTRqEvEvntDescChc ,
    mgMsgRegExpPkgDTRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDTRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgDTRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgDTRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgDTRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D T RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 917,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgDTRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTSgRqSymCallAnswerEnum =
{
    (Data *)"ans" ,
    MGT_MGCP_PKG_D_T_SG_RQ_SYM_CALL_ANSWER
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqSymCallAnswerEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T SG RQ SYM CALL ANSWER ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 918,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTSgRqSymCallAnswerEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTSgRqSymBlockEnum =
{
    (Data *)"bl" ,
    MGT_MGCP_PKG_D_T_SG_RQ_SYM_BLOCK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqSymBlockEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T SG RQ SYM BLOCK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 919,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTSgRqSymBlockEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTSgRqSymBusyToneEnum =
{
    (Data *)"bz" ,
    MGT_MGCP_PKG_D_T_SG_RQ_SYM_BUSY_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqSymBusyToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T SG RQ SYM BUSY TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 920,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTSgRqSymBusyToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTSgRqSymDialToneEnum =
{
    (Data *)"dl" ,
    MGT_MGCP_PKG_D_T_SG_RQ_SYM_DIAL_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqSymDialToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T SG RQ SYM DIAL TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 921,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTSgRqSymDialToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTSgRqSymReleaseCallEnum =
{
    (Data *)"rel" ,
    MGT_MGCP_PKG_D_T_SG_RQ_SYM_RELEASE_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqSymReleaseCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T SG RQ SYM RELEASE CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 922,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTSgRqSymReleaseCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTSgRqSymResumeCallEnum =
{
    (Data *)"res" ,
    MGT_MGCP_PKG_D_T_SG_RQ_SYM_RESUME_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqSymResumeCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T SG RQ SYM RESUME CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 923,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTSgRqSymResumeCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTSgRqSymReleaseCompltEnum =
{
    (Data *)"rlc" ,
    MGT_MGCP_PKG_D_T_SG_RQ_SYM_RELEASE_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqSymReleaseCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T SG RQ SYM RELEASE COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 924,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTSgRqSymReleaseCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTSgRqSymReorderToneEnum =
{
    (Data *)"ro" ,
    MGT_MGCP_PKG_D_T_SG_RQ_SYM_REORDER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqSymReorderToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T SG RQ SYM REORDER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 925,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTSgRqSymReorderToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTSgRqSymRingbackToneEnum =
{
    (Data *)"rt" ,
    MGT_MGCP_PKG_D_T_SG_RQ_SYM_RINGBACK_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqSymRingbackToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T SG RQ SYM RINGBACK TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 926,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTSgRqSymRingbackToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTSgRqSymCallSetupEnum =
{
    (Data *)"sup" ,
    MGT_MGCP_PKG_D_T_SG_RQ_SYM_CALL_SETUP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqSymCallSetupEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T SG RQ SYM CALL SETUP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 927,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTSgRqSymCallSetupEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgDTSgRqSymSuspendCallEnum =
{
    (Data *)"sus" ,
    MGT_MGCP_PKG_D_T_SG_RQ_SYM_SUSPEND_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqSymSuspendCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG D T SG RQ SYM SUSPEND CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 928,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgDTSgRqSymSuspendCallEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDTSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgDTSgRqSymCallAnswerEnumDef ,
&mgMsgDefPkgDTSgRqSymBlockEnumDef ,
&mgMsgDefPkgDTSgRqSymBusyToneEnumDef ,
&mgMsgDefPkgDTSgRqSymDialToneEnumDef ,
&mgMsgDefPkgDTSgRqSymReleaseCallEnumDef ,
&mgMsgDefPkgDTSgRqSymResumeCallEnumDef ,
&mgMsgDefPkgDTSgRqSymReleaseCompltEnumDef ,
&mgMsgDefPkgDTSgRqSymReorderToneEnumDef ,
&mgMsgDefPkgDTSgRqSymRingbackToneEnumDef ,
&mgMsgDefPkgDTSgRqSymCallSetupEnumDef ,
&mgMsgDefPkgDTSgRqSymSuspendCallEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgDTSgRqEvntKnownChc =
{
    11 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgDTSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D T SG RQ EVNT KNOWN " ,
    "PkgDTSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 929,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgDTSgRqEvntKnownChc ,
    mgMsgRegExpPkgDTSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgDTSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDTSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgDTSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgDTSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgDTSgRqEvntDescChcElmnt ,
    mgMsgDefPkgDTSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D T SG RQ EVNT DESC " ,
    "PkgDTSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 930,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgDTSgRqEvntDescChc ,
    mgMsgRegExpPkgDTSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgDTSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgDTSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgDTSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgDTSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgDTSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG D T SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 931,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgDTSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_DTMF_DIAL_PULSE */




#ifdef  GCP_PKG_MGCP_GENERIC_MEDIA

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGRqEvSymFaxToneDetectEnum =
{
    (Data *)"ft" ,
    MGT_MGCP_PKG_G_RQ_EV_SYM_FAX_TONE_DETECT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGRqEvSymFaxToneDetectEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G RQ EV SYM FAX TONE DETECT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 932,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGRqEvSymFaxToneDetectEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGRqEvSymLongDurConnEnum =
{
    (Data *)"ld" ,
    MGT_MGCP_PKG_G_RQ_EV_SYM_LONG_DUR_CONN
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGRqEvSymLongDurConnEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G RQ EV SYM LONG DUR CONN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 933,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGRqEvSymLongDurConnEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGRqEvSymModemDetectEnum =
{
    (Data *)"mt" ,
    MGT_MGCP_PKG_G_RQ_EV_SYM_MODEM_DETECT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGRqEvSymModemDetectEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G RQ EV SYM MODEM DETECT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 934,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGRqEvSymModemDetectEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_G_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 935,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGRqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_G_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 936,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGRqEvSymOperFailEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGRqEvSymRingbackToneEnum =
{
    (Data *)"rt" ,
    MGT_MGCP_PKG_G_RQ_EV_SYM_RINGBACK_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGRqEvSymRingbackToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G RQ EV SYM RINGBACK TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 937,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGRqEvSymRingbackToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGRqEvSymPatternDetectEnum =
{
    (Data *)"pat" ,
    MGT_MGCP_PKG_G_RQ_EV_SYM_PATTERN_DETECT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGRqEvSymPatternDetectEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G RQ EV SYM PATTERN DETECT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 938,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGRqEvSymPatternDetectEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgGRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgGRqEvSymFaxToneDetectEnumDef ,
&mgMsgDefPkgGRqEvSymLongDurConnEnumDef ,
&mgMsgDefPkgGRqEvSymModemDetectEnumDef ,
&mgMsgDefPkgGRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgGRqEvSymOperFailEnumDef ,
&mgMsgDefPkgGRqEvSymRingbackToneEnumDef ,
&mgMsgDefPkgGRqEvSymPatternDetectEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgGRqEvEvntKnownChc =
{
    7 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgGRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG G RQ EV EVNT KNOWN " ,
    "PkgGRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 939,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgGRqEvEvntKnownChc ,
    mgMsgRegExpPkgGRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgGRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgGRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgGRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgGRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgGRqEvEvntDescChcElmnt ,
    mgMsgDefPkgGRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG G RQ EV EVNT DESC " ,
    "PkgGRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 940,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgGRqEvEvntDescChc ,
    mgMsgRegExpPkgGRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgGRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgGRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgGRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgGRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG G RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 941,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgGRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGSgRqSymConfirmToneEnum =
{
    (Data *)"cf" ,
    MGT_MGCP_PKG_G_SG_RQ_SYM_CONFIRM_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGSgRqSymConfirmToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G SG RQ SYM CONFIRM TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 942,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGSgRqSymConfirmToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGSgRqSymCongestionToneEnum =
{
    (Data *)"cg" ,
    MGT_MGCP_PKG_G_SG_RQ_SYM_CONGESTION_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGSgRqSymCongestionToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G SG RQ SYM CONGESTION TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 943,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGSgRqSymCongestionToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGSgRqSymInterceptToneEnum =
{
    (Data *)"it" ,
    MGT_MGCP_PKG_G_SG_RQ_SYM_INTERCEPT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGSgRqSymInterceptToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G SG RQ SYM INTERCEPT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 944,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGSgRqSymInterceptToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGSgRqSymPreemptionToneEnum =
{
    (Data *)"pt" ,
    MGT_MGCP_PKG_G_SG_RQ_SYM_PREEMPTION_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGSgRqSymPreemptionToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G SG RQ SYM PREEMPTION TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 945,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGSgRqSymPreemptionToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGSgRqSymRingbackToneEnum =
{
    (Data *)"rt" ,
    MGT_MGCP_PKG_G_SG_RQ_SYM_RINGBACK_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGSgRqSymRingbackToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G SG RQ SYM RINGBACK TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 946,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGSgRqSymRingbackToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGSgRqSymRingbackEnum =
{
    (Data *)"rbk" ,
    MGT_MGCP_PKG_G_SG_RQ_SYM_RINGBACK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGSgRqSymRingbackEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G SG RQ SYM RINGBACK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 947,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGSgRqSymRingbackEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgGSgRqSymPatternDetectEnum =
{
    (Data *)"pat" ,
    MGT_MGCP_PKG_G_SG_RQ_SYM_PATTERN_DETECT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGSgRqSymPatternDetectEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG G SG RQ SYM PATTERN DETECT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 948,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgGSgRqSymPatternDetectEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgGSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgGSgRqSymConfirmToneEnumDef ,
&mgMsgDefPkgGSgRqSymCongestionToneEnumDef ,
&mgMsgDefPkgGSgRqSymInterceptToneEnumDef ,
&mgMsgDefPkgGSgRqSymPreemptionToneEnumDef ,
&mgMsgDefPkgGSgRqSymRingbackToneEnumDef ,
&mgMsgDefPkgGSgRqSymRingbackEnumDef ,
&mgMsgDefPkgGSgRqSymPatternDetectEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgGSgRqEvntKnownChc =
{
    7 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgGSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG G SG RQ EVNT KNOWN " ,
    "PkgGSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 949,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgGSgRqEvntKnownChc ,
    mgMsgRegExpPkgGSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgGSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgGSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgGSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgGSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgGSgRqEvntDescChcElmnt ,
    mgMsgDefPkgGSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG G SG RQ EVNT DESC " ,
    "PkgGSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 950,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgGSgRqEvntDescChc ,
    mgMsgRegExpPkgGSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgGSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgGSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgGSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgGSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgGSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG G SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 951,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgGSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_GENERIC_MEDIA */




#ifdef  GCP_PKG_MGCP_HANDSET_EMUL

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymAdsiDisplayEnum =
{
    (Data *)"adsi" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_ADSI_DISPLAY
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymAdsiDisplayEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM ADSI DISPLAY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 952,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymAdsiDisplayEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymAnswerToneEnum =
{
    (Data *)"aw" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_ANSWER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymAnswerToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM ANSWER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 953,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymAnswerToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymBusyToneEnum =
{
    (Data *)"bz" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_BUSY_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymBusyToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM BUSY TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 954,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymBusyToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymCallerIdEnum =
{
    (Data *)"ci" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_CALLER_ID
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymCallerIdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM CALLER ID ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 955,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymCallerIdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymDialToneEnum =
{
    (Data *)"dl" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_DIAL_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymDialToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM DIAL TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 956,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymDialToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymErrorToneEnum =
{
    (Data *)"e" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_ERROR_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymErrorToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM ERROR TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 957,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymErrorToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymOffHookTransEnum =
{
    (Data *)"hd" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_OFF_HOOK_TRANS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymOffHookTransEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM OFF HOOK TRANS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 958,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymOffHookTransEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymOnHookTransEnum =
{
    (Data *)"hu" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_ON_HOOK_TRANS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymOnHookTransEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM ON HOOK TRANS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 959,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymOnHookTransEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymFlashHookEnum =
{
    (Data *)"hf" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_FLASH_HOOK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymFlashHookEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM FLASH HOOK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 960,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymFlashHookEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymToneOnHoldEnum =
{
    (Data *)"ht" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_TONE_ON_HOLD
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymToneOnHoldEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM TONE ON HOLD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 961,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymToneOnHoldEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymMsgWaitngIndEnum =
{
    (Data *)"mwi" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_MSG_WAITNG_IND
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymMsgWaitngIndEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM MSG WAITNG IND ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 962,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymMsgWaitngIndEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 963,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymOffHookWarningToneEnum =
{
    (Data *)"ot" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_OFF_HOOK_WARNING_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymOffHookWarningToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM OFF HOOK WARNING TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 964,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymOffHookWarningToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymReportFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_REPORT_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymReportFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM REPORT FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 965,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymReportFailEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymRingingEnum =
{
    (Data *)"rg" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_RINGING
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymRingingEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM RINGING ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 966,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymRingingEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymDistinctiveRinging0Enum =
{
    (Data *)"r0" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING0
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymDistinctiveRinging0EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM DISTINCTIVE RINGING0 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 967,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymDistinctiveRinging0Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymDistinctiveRinging1Enum =
{
    (Data *)"r1" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymDistinctiveRinging1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM DISTINCTIVE RINGING1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 968,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymDistinctiveRinging1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymDistinctiveRinging2Enum =
{
    (Data *)"r2" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymDistinctiveRinging2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM DISTINCTIVE RINGING2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 969,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymDistinctiveRinging2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymDistinctiveRinging3Enum =
{
    (Data *)"r3" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymDistinctiveRinging3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM DISTINCTIVE RINGING3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 970,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymDistinctiveRinging3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymDistinctiveRinging4Enum =
{
    (Data *)"r4" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING4
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymDistinctiveRinging4EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM DISTINCTIVE RINGING4 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 971,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymDistinctiveRinging4Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymDistinctiveRinging5Enum =
{
    (Data *)"r5" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING5
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymDistinctiveRinging5EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM DISTINCTIVE RINGING5 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 972,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymDistinctiveRinging5Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymDistinctiveRinging6Enum =
{
    (Data *)"r6" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING6
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymDistinctiveRinging6EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM DISTINCTIVE RINGING6 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 973,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymDistinctiveRinging6Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymDistinctiveRinging7Enum =
{
    (Data *)"r7" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING7
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymDistinctiveRinging7EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM DISTINCTIVE RINGING7 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 974,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymDistinctiveRinging7Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymReorderToneEnum =
{
    (Data *)"ro" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_REORDER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymReorderToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM REORDER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 975,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymReorderToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymRingsplashEnum =
{
    (Data *)"rs" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_RINGSPLASH
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymRingsplashEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM RINGSPLASH ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 976,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymRingsplashEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymStutterDialtoneEnum =
{
    (Data *)"sl" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_STUTTER_DIALTONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymStutterDialtoneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM STUTTER DIALTONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 977,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymStutterDialtoneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymSitToneEnum =
{
    (Data *)"sit" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_SIT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymSitToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM SIT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 978,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymSitToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymAlertingToneEnum =
{
    (Data *)"v" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_ALERTING_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymAlertingToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM ALERTING TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 979,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymAlertingToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymVisMsgWaitngIndEnum =
{
    (Data *)"vmwi" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_VIS_MSG_WAITNG_IND
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymVisMsgWaitngIndEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM VIS MSG WAITNG IND ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 980,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymVisMsgWaitngIndEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymCallWaitngToneEnum =
{
    (Data *)"wt" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_CALL_WAITNG_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymCallWaitngToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM CALL WAITNG TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 981,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymCallWaitngToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymRecorderWarningToneEnum =
{
    (Data *)"y" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_RECORDER_WARNING_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymRecorderWarningToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM RECORDER WARNING TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 982,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymRecorderWarningToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymCallingCardServToneEnum =
{
    (Data *)"z" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_CALLING_CARD_SERV_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymCallingCardServToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM CALLING CARD SERV TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 983,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymCallingCardServToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymPromptToneEnum =
{
    (Data *)"p" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_PROMPT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymPromptToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM PROMPT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 984,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymPromptToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymNetworkBusyEnum =
{
    (Data *)"nbz" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_NETWORK_BUSY
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymNetworkBusyEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM NETWORK BUSY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 985,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymNetworkBusyEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymDistinctTonePatternEnum =
{
    (Data *)"s" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCT_TONE_PATTERN
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymDistinctTonePatternEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM DISTINCT TONE PATTERN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 986,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymDistinctTonePatternEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymLineSideAnswerSupEnum =
{
    (Data *)"lsa" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_LINE_SIDE_ANSWER_SUP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymLineSideAnswerSupEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM LINE SIDE ANSWER SUP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1034 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymLineSideAnswerSupEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymNetworkDisConnEnum =
{
    (Data *)"osi" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_NETWORK_DIS_CONN
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymNetworkDisConnEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM NETWORK DIS CONN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1035 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymNetworkDisConnEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymAlternativeCall1Enum =
{
    (Data *)"wt1" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymAlternativeCall1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM ALTERNATIVE CALL1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1036 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymAlternativeCall1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymAlternativeCall2Enum =
{
    (Data *)"wt2" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymAlternativeCall2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM ALTERNATIVE CALL2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1037 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymAlternativeCall2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymAlternativeCall3Enum =
{
    (Data *)"wt3" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymAlternativeCall3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM ALTERNATIVE CALL3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1038 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymAlternativeCall3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHRqEvSymAlternativeCall4Enum =
{
    (Data *)"wt4" ,
    MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL4
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvSymAlternativeCall4EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H RQ EV SYM ALTERNATIVE CALL4 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1039 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvSymAlternativeCall4Enum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgHRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgHRqEvSymAdsiDisplayEnumDef ,
&mgMsgDefPkgHRqEvSymAnswerToneEnumDef ,
&mgMsgDefPkgHRqEvSymBusyToneEnumDef ,
&mgMsgDefPkgHRqEvSymCallerIdEnumDef ,
&mgMsgDefPkgHRqEvSymDialToneEnumDef ,
&mgMsgDefPkgHRqEvSymErrorToneEnumDef ,
&mgMsgDefPkgHRqEvSymOffHookTransEnumDef ,
&mgMsgDefPkgHRqEvSymOnHookTransEnumDef ,
&mgMsgDefPkgHRqEvSymFlashHookEnumDef ,
&mgMsgDefPkgHRqEvSymToneOnHoldEnumDef ,
&mgMsgDefPkgHRqEvSymMsgWaitngIndEnumDef ,
&mgMsgDefPkgHRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgHRqEvSymOffHookWarningToneEnumDef ,
&mgMsgDefPkgHRqEvSymReportFailEnumDef ,
&mgMsgDefPkgHRqEvSymRingingEnumDef ,
&mgMsgDefPkgHRqEvSymDistinctiveRinging0EnumDef ,
&mgMsgDefPkgHRqEvSymDistinctiveRinging1EnumDef ,
&mgMsgDefPkgHRqEvSymDistinctiveRinging2EnumDef ,
&mgMsgDefPkgHRqEvSymDistinctiveRinging3EnumDef ,
&mgMsgDefPkgHRqEvSymDistinctiveRinging4EnumDef ,
&mgMsgDefPkgHRqEvSymDistinctiveRinging5EnumDef ,
&mgMsgDefPkgHRqEvSymDistinctiveRinging6EnumDef ,
&mgMsgDefPkgHRqEvSymDistinctiveRinging7EnumDef ,
&mgMsgDefPkgHRqEvSymReorderToneEnumDef ,
&mgMsgDefPkgHRqEvSymRingsplashEnumDef ,
&mgMsgDefPkgHRqEvSymStutterDialtoneEnumDef ,
&mgMsgDefPkgHRqEvSymSitToneEnumDef ,
&mgMsgDefPkgHRqEvSymAlertingToneEnumDef ,
&mgMsgDefPkgHRqEvSymVisMsgWaitngIndEnumDef ,
&mgMsgDefPkgHRqEvSymCallWaitngToneEnumDef ,
&mgMsgDefPkgHRqEvSymRecorderWarningToneEnumDef ,
&mgMsgDefPkgHRqEvSymCallingCardServToneEnumDef ,
&mgMsgDefPkgHRqEvSymPromptToneEnumDef ,
&mgMsgDefPkgHRqEvSymNetworkBusyEnumDef ,
&mgMsgDefPkgHRqEvSymDistinctTonePatternEnumDef ,
&mgMsgDefPkgHRqEvSymLineSideAnswerSupEnumDef ,
&mgMsgDefPkgHRqEvSymNetworkDisConnEnumDef ,
&mgMsgDefPkgHRqEvSymAlternativeCall1EnumDef ,
&mgMsgDefPkgHRqEvSymAlternativeCall2EnumDef ,
&mgMsgDefPkgHRqEvSymAlternativeCall3EnumDef ,
&mgMsgDefPkgHRqEvSymAlternativeCall4EnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgHRqEvEvntKnownChc =
{
    41 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgHRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG H RQ EV EVNT KNOWN " ,
    "PkgHRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 987,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgHRqEvEvntKnownChc ,
    mgMsgRegExpPkgHRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgHRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgHRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgHRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgHRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgHRqEvEvntDescChcElmnt ,
    mgMsgDefPkgHRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG H RQ EV EVNT DESC " ,
    "PkgHRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 988,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgHRqEvEvntDescChc ,
    mgMsgRegExpPkgHRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgHRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgHRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgHRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgHRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG H RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 989,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgHRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymAdsiDisplayEnum =
{
    (Data *)"adsi" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_ADSI_DISPLAY
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymAdsiDisplayEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM ADSI DISPLAY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 990,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymAdsiDisplayEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymAnswerToneEnum =
{
    (Data *)"aw" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_ANSWER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymAnswerToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM ANSWER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 991,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymAnswerToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymBusyToneEnum =
{
    (Data *)"bz" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_BUSY_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymBusyToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM BUSY TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 992,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymBusyToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymCallerIdEnum =
{
    (Data *)"ci" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_CALLER_ID
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymCallerIdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM CALLER ID ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 993,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymCallerIdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymDialToneEnum =
{
    (Data *)"dl" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_DIAL_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymDialToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM DIAL TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 994,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymDialToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymErrorToneEnum =
{
    (Data *)"e" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_ERROR_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymErrorToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM ERROR TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 995,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymErrorToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymOffHookTransEnum =
{
    (Data *)"hd" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_OFF_HOOK_TRANS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymOffHookTransEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM OFF HOOK TRANS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 996,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymOffHookTransEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymOnHookTransEnum =
{
    (Data *)"hu" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_ON_HOOK_TRANS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymOnHookTransEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM ON HOOK TRANS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 997,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymOnHookTransEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymFlashHookEnum =
{
    (Data *)"hf" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_FLASH_HOOK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymFlashHookEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM FLASH HOOK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 998,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymFlashHookEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymToneOnHoldEnum =
{
    (Data *)"ht" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_TONE_ON_HOLD
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymToneOnHoldEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM TONE ON HOLD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 999,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymToneOnHoldEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymMsgWaitngIndEnum =
{
    (Data *)"mwi" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_MSG_WAITNG_IND
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymMsgWaitngIndEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM MSG WAITNG IND ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1000,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymMsgWaitngIndEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymOffHookWarningToneEnum =
{
    (Data *)"ot" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_OFF_HOOK_WARNING_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymOffHookWarningToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM OFF HOOK WARNING TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1001,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymOffHookWarningToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymRingingEnum =
{
    (Data *)"rg" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_RINGING
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymRingingEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM RINGING ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1002,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymRingingEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymDistinctiveRinging0Enum =
{
    (Data *)"r0" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING0
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymDistinctiveRinging0EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM DISTINCTIVE RINGING0 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1003,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymDistinctiveRinging0Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymDistinctiveRinging1Enum =
{
    (Data *)"r1" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymDistinctiveRinging1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM DISTINCTIVE RINGING1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1004,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymDistinctiveRinging1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymDistinctiveRinging2Enum =
{
    (Data *)"r2" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymDistinctiveRinging2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM DISTINCTIVE RINGING2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1005,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymDistinctiveRinging2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymDistinctiveRinging3Enum =
{
    (Data *)"r3" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymDistinctiveRinging3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM DISTINCTIVE RINGING3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1006,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymDistinctiveRinging3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymDistinctiveRinging4Enum =
{
    (Data *)"r4" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING4
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymDistinctiveRinging4EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM DISTINCTIVE RINGING4 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1007,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymDistinctiveRinging4Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymDistinctiveRinging5Enum =
{
    (Data *)"r5" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING5
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymDistinctiveRinging5EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM DISTINCTIVE RINGING5 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1008,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymDistinctiveRinging5Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymDistinctiveRinging6Enum =
{
    (Data *)"r6" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING6
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymDistinctiveRinging6EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM DISTINCTIVE RINGING6 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1009,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymDistinctiveRinging6Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymDistinctiveRinging7Enum =
{
    (Data *)"r7" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING7
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymDistinctiveRinging7EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM DISTINCTIVE RINGING7 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1010,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymDistinctiveRinging7Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymReorderToneEnum =
{
    (Data *)"ro" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_REORDER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymReorderToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM REORDER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1011,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymReorderToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymRingsplashEnum =
{
    (Data *)"rs" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_RINGSPLASH
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymRingsplashEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM RINGSPLASH ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1012,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymRingsplashEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymStutterDialtoneEnum =
{
    (Data *)"sl" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_STUTTER_DIALTONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymStutterDialtoneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM STUTTER DIALTONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1013,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymStutterDialtoneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymSitToneEnum =
{
    (Data *)"sit" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_SIT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymSitToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM SIT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1014,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymSitToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymAlertingToneEnum =
{
    (Data *)"v" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_ALERTING_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymAlertingToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM ALERTING TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1015,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymAlertingToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymVisMsgWaitngIndEnum =
{
    (Data *)"vmwi" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_VIS_MSG_WAITNG_IND
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymVisMsgWaitngIndEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM VIS MSG WAITNG IND ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1016,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymVisMsgWaitngIndEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymCallWaitngToneEnum =
{
    (Data *)"wt" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_CALL_WAITNG_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymCallWaitngToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM CALL WAITNG TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1017,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymCallWaitngToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymRecorderWarningToneEnum =
{
    (Data *)"y" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_RECORDER_WARNING_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymRecorderWarningToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM RECORDER WARNING TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1018,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymRecorderWarningToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymCallingCardServToneEnum =
{
    (Data *)"z" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_CALLING_CARD_SERV_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymCallingCardServToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM CALLING CARD SERV TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1019,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymCallingCardServToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymPromptToneEnum =
{
    (Data *)"p" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_PROMPT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymPromptToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM PROMPT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1020,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymPromptToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymNetworkBusyEnum =
{
    (Data *)"nbz" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_NETWORK_BUSY
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymNetworkBusyEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM NETWORK BUSY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1021,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymNetworkBusyEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymDistinctTonePatternEnum =
{
    (Data *)"s" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCT_TONE_PATTERN
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymDistinctTonePatternEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM DISTINCT TONE PATTERN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1022,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymDistinctTonePatternEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymLineSideAnswerSupEnum =
{
    (Data *)"lsa" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_LINE_SIDE_ANSWER_SUP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymLineSideAnswerSupEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM LINE SIDE ANSWER SUP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1082 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymLineSideAnswerSupEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymNetworkDisConnEnum =
{
    (Data *)"osi" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_NETWORK_DIS_CONN
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymNetworkDisConnEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM NETWORK DIS CONN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1083 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymNetworkDisConnEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymAlternativeCall1Enum =
{
    (Data *)"wt1" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymAlternativeCall1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM ALTERNATIVE CALL1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1084 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymAlternativeCall1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymAlternativeCall2Enum =
{
    (Data *)"wt2" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymAlternativeCall2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM ALTERNATIVE CALL2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1085 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymAlternativeCall2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymAlternativeCall3Enum =
{
    (Data *)"wt3" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymAlternativeCall3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM ALTERNATIVE CALL3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1086 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymAlternativeCall3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgHSgRqSymAlternativeCall4Enum =
{
    (Data *)"wt4" ,
    MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL4
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqSymAlternativeCall4EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG H SG RQ SYM ALTERNATIVE CALL4 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1087 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqSymAlternativeCall4Enum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgHSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgHSgRqSymAdsiDisplayEnumDef ,
&mgMsgDefPkgHSgRqSymAnswerToneEnumDef ,
&mgMsgDefPkgHSgRqSymBusyToneEnumDef ,
&mgMsgDefPkgHSgRqSymCallerIdEnumDef ,
&mgMsgDefPkgHSgRqSymDialToneEnumDef ,
&mgMsgDefPkgHSgRqSymErrorToneEnumDef ,
&mgMsgDefPkgHSgRqSymOffHookTransEnumDef ,
&mgMsgDefPkgHSgRqSymOnHookTransEnumDef ,
&mgMsgDefPkgHSgRqSymFlashHookEnumDef ,
&mgMsgDefPkgHSgRqSymToneOnHoldEnumDef ,
&mgMsgDefPkgHSgRqSymMsgWaitngIndEnumDef ,
&mgMsgDefPkgHSgRqSymOffHookWarningToneEnumDef ,
&mgMsgDefPkgHSgRqSymRingingEnumDef ,
&mgMsgDefPkgHSgRqSymDistinctiveRinging0EnumDef ,
&mgMsgDefPkgHSgRqSymDistinctiveRinging1EnumDef ,
&mgMsgDefPkgHSgRqSymDistinctiveRinging2EnumDef ,
&mgMsgDefPkgHSgRqSymDistinctiveRinging3EnumDef ,
&mgMsgDefPkgHSgRqSymDistinctiveRinging4EnumDef ,
&mgMsgDefPkgHSgRqSymDistinctiveRinging5EnumDef ,
&mgMsgDefPkgHSgRqSymDistinctiveRinging6EnumDef ,
&mgMsgDefPkgHSgRqSymDistinctiveRinging7EnumDef ,
&mgMsgDefPkgHSgRqSymReorderToneEnumDef ,
&mgMsgDefPkgHSgRqSymRingsplashEnumDef ,
&mgMsgDefPkgHSgRqSymStutterDialtoneEnumDef ,
&mgMsgDefPkgHSgRqSymSitToneEnumDef ,
&mgMsgDefPkgHSgRqSymAlertingToneEnumDef ,
&mgMsgDefPkgHSgRqSymVisMsgWaitngIndEnumDef ,
&mgMsgDefPkgHSgRqSymCallWaitngToneEnumDef ,
&mgMsgDefPkgHSgRqSymRecorderWarningToneEnumDef ,
&mgMsgDefPkgHSgRqSymCallingCardServToneEnumDef ,
&mgMsgDefPkgHSgRqSymPromptToneEnumDef ,
&mgMsgDefPkgHSgRqSymNetworkBusyEnumDef ,
&mgMsgDefPkgHSgRqSymDistinctTonePatternEnumDef ,
&mgMsgDefPkgHSgRqSymLineSideAnswerSupEnumDef ,
&mgMsgDefPkgHSgRqSymNetworkDisConnEnumDef ,
&mgMsgDefPkgHSgRqSymAlternativeCall1EnumDef ,
&mgMsgDefPkgHSgRqSymAlternativeCall2EnumDef ,
&mgMsgDefPkgHSgRqSymAlternativeCall3EnumDef ,
&mgMsgDefPkgHSgRqSymAlternativeCall4EnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgHSgRqEvntKnownChc =
{
    39 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgHSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG H SG RQ EVNT KNOWN " ,
    "PkgHSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1023,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgHSgRqEvntKnownChc ,
    mgMsgRegExpPkgHSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgHSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgHSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgHSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgHSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgHSgRqEvntDescChcElmnt ,
    mgMsgDefPkgHSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG H SG RQ EVNT DESC " ,
    "PkgHSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1024,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgHSgRqEvntDescChc ,
    mgMsgRegExpPkgHSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgHSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgHSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgHSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgHSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgHSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG H SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1025,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgHSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_HANDSET_EMUL */




#ifdef  GCP_PKG_MGCP_LINE

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLRqEvSymAnswerToneEnum =
{
    (Data *)"aw" ,
    MGT_MGCP_PKG_L_RQ_EV_SYM_ANSWER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLRqEvSymAnswerToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L RQ EV SYM ANSWER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1026,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLRqEvSymAnswerToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLRqEvSymErrorToneEnum =
{
    (Data *)"e" ,
    MGT_MGCP_PKG_L_RQ_EV_SYM_ERROR_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLRqEvSymErrorToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L RQ EV SYM ERROR TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1027,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLRqEvSymErrorToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLRqEvSymOffHookTransEnum =
{
    (Data *)"hd" ,
    MGT_MGCP_PKG_L_RQ_EV_SYM_OFF_HOOK_TRANS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLRqEvSymOffHookTransEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L RQ EV SYM OFF HOOK TRANS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1028,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLRqEvSymOffHookTransEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLRqEvSymOnHookTransEnum =
{
    (Data *)"hu" ,
    MGT_MGCP_PKG_L_RQ_EV_SYM_ON_HOOK_TRANS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLRqEvSymOnHookTransEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L RQ EV SYM ON HOOK TRANS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1029,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLRqEvSymOnHookTransEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLRqEvSymFlashHookEnum =
{
    (Data *)"hf" ,
    MGT_MGCP_PKG_L_RQ_EV_SYM_FLASH_HOOK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLRqEvSymFlashHookEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L RQ EV SYM FLASH HOOK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1030,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLRqEvSymFlashHookEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_L_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1031,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLRqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_L_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1032,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLRqEvSymOperFailEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLRqEvSymPromptToneEnum =
{
    (Data *)"p" ,
    MGT_MGCP_PKG_L_RQ_EV_SYM_PROMPT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLRqEvSymPromptToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L RQ EV SYM PROMPT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1033,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLRqEvSymPromptToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLRqEvSymNetworkBusyEnum =
{
    (Data *)"nbz" ,
    MGT_MGCP_PKG_L_RQ_EV_SYM_NETWORK_BUSY
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLRqEvSymNetworkBusyEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L RQ EV SYM NETWORK BUSY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1034,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLRqEvSymNetworkBusyEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLRqEvSymDistinctTonePatternEnum =
{
    (Data *)"s" ,
    MGT_MGCP_PKG_L_RQ_EV_SYM_DISTINCT_TONE_PATTERN
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLRqEvSymDistinctTonePatternEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L RQ EV SYM DISTINCT TONE PATTERN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1035,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLRqEvSymDistinctTonePatternEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgLRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgLRqEvSymAnswerToneEnumDef ,
&mgMsgDefPkgLRqEvSymErrorToneEnumDef ,
&mgMsgDefPkgLRqEvSymOffHookTransEnumDef ,
&mgMsgDefPkgLRqEvSymOnHookTransEnumDef ,
&mgMsgDefPkgLRqEvSymFlashHookEnumDef ,
&mgMsgDefPkgLRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgLRqEvSymOperFailEnumDef ,
&mgMsgDefPkgLRqEvSymPromptToneEnumDef ,
&mgMsgDefPkgLRqEvSymNetworkBusyEnumDef ,
&mgMsgDefPkgLRqEvSymDistinctTonePatternEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgLRqEvEvntKnownChc =
{
    10 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgLRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG L RQ EV EVNT KNOWN " ,
    "PkgLRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1036,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgLRqEvEvntKnownChc ,
    mgMsgRegExpPkgLRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgLRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgLRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgLRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgLRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgLRqEvEvntDescChcElmnt ,
    mgMsgDefPkgLRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG L RQ EV EVNT DESC " ,
    "PkgLRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1037,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgLRqEvEvntDescChc ,
    mgMsgRegExpPkgLRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgLRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgLRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgLRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgLRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG L RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1038,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgLRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymAdsiDisplayEnum =
{
    (Data *)"adsi" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_ADSI_DISPLAY
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymAdsiDisplayEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM ADSI DISPLAY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  999 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymAdsiDisplayEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymAnswerToneEnum =
{
    (Data *)"aw" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_ANSWER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymAnswerToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM ANSWER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1000 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymAnswerToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymBusyToneEnum =
{
    (Data *)"bz" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_BUSY_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymBusyToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM BUSY TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1001 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymBusyToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymCallerIdEnum =
{
    (Data *)"ci" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_CALLER_ID
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymCallerIdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM CALLER ID ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1002 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymCallerIdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymDialToneEnum =
{
    (Data *)"dl" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_DIAL_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymDialToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM DIAL TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1003 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymDialToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymErrorToneEnum =
{
    (Data *)"e" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_ERROR_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymErrorToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM ERROR TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1004 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymErrorToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymOnHoldToneEnum =
{
    (Data *)"ht" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_ON_HOLD_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymOnHoldToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM ON HOLD TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1005 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymOnHoldToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymLineSideAnswerSupEnum =
{
    (Data *)"lsa" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_LINE_SIDE_ANSWER_SUP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymLineSideAnswerSupEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM LINE SIDE ANSWER SUP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1006 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymLineSideAnswerSupEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymMsgWaitngIndEnum =
{
    (Data *)"mwi" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_MSG_WAITNG_IND
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymMsgWaitngIndEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM MSG WAITNG IND ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1007 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymMsgWaitngIndEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymNetworkDisConnEnum =
{
    (Data *)"osi" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_NETWORK_DIS_CONN
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymNetworkDisConnEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM NETWORK DIS CONN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1027 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymNetworkDisConnEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymOffHookWarningToneEnum =
{
    (Data *)"ot" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_OFF_HOOK_WARNING_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymOffHookWarningToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM OFF HOOK WARNING TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1009 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymOffHookWarningToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymRingingEnum =
{
    (Data *)"rg" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_RINGING
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymRingingEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM RINGING ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1010 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymRingingEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymDistinctiveRinging0Enum =
{
    (Data *)"r0" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING0
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymDistinctiveRinging0EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM DISTINCTIVE RINGING0 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1011 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymDistinctiveRinging0Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymDistinctiveRinging1Enum =
{
    (Data *)"r1" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymDistinctiveRinging1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM DISTINCTIVE RINGING1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1012 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymDistinctiveRinging1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymDistinctiveRinging2Enum =
{
    (Data *)"r2" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymDistinctiveRinging2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM DISTINCTIVE RINGING2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1013 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymDistinctiveRinging2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymDistinctiveRinging3Enum =
{
    (Data *)"r3" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymDistinctiveRinging3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM DISTINCTIVE RINGING3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1014 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymDistinctiveRinging3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymDistinctiveRinging4Enum =
{
    (Data *)"r4" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING4
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymDistinctiveRinging4EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM DISTINCTIVE RINGING4 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1015 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymDistinctiveRinging4Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymDistinctiveRinging5Enum =
{
    (Data *)"r5" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING5
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymDistinctiveRinging5EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM DISTINCTIVE RINGING5 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1016 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymDistinctiveRinging5Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymDistinctiveRinging6Enum =
{
    (Data *)"r6" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING6
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymDistinctiveRinging6EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM DISTINCTIVE RINGING6 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1017 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymDistinctiveRinging6Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymDistinctiveRinging7Enum =
{
    (Data *)"r7" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING7
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymDistinctiveRinging7EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM DISTINCTIVE RINGING7 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1018 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymDistinctiveRinging7Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymReorderToneEnum =
{
    (Data *)"ro" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_REORDER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymReorderToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM REORDER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1019 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymReorderToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymRingsplashEnum =
{
    (Data *)"rs" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_RINGSPLASH
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymRingsplashEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM RINGSPLASH ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1020 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymRingsplashEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymSpecialInfoToneEnum =
{
    (Data *)"sit" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_SPECIAL_INFO_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymSpecialInfoToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM SPECIAL INFO TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1021 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymSpecialInfoToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymStutterDialtoneEnum =
{
    (Data *)"sl" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_STUTTER_DIALTONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymStutterDialtoneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM STUTTER DIALTONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1022 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymStutterDialtoneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymAlertingToneEnum =
{
    (Data *)"v" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_ALERTING_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymAlertingToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM ALERTING TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1023 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymAlertingToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymVisualMsgEnum =
{
    (Data *)"vmwi" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_VISUAL_MSG
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymVisualMsgEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM VISUAL MSG ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1024 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymVisualMsgEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymCallWaitngToneEnum =
{
    (Data *)"wt" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_CALL_WAITNG_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymCallWaitngToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM CALL WAITNG TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1025 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymCallWaitngToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymAlternativeCall1Enum =
{
    (Data *)"wt1" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymAlternativeCall1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM ALTERNATIVE CALL1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1026 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymAlternativeCall1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymAlternativeCall2Enum =
{
    (Data *)"wt2" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymAlternativeCall2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM ALTERNATIVE CALL2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1027 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymAlternativeCall2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymAlternativeCall3Enum =
{
    (Data *)"wt3" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymAlternativeCall3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM ALTERNATIVE CALL3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1028 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymAlternativeCall3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymAlternativeCall4Enum =
{
    (Data *)"wt4" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL4
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymAlternativeCall4EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM ALTERNATIVE CALL4 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1029 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymAlternativeCall4Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymRecorderWarningToneEnum =
{
    (Data *)"y" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_RECORDER_WARNING_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymRecorderWarningToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM RECORDER WARNING TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1030 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymRecorderWarningToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymCallingCardServiceToneEnum =
{
    (Data *)"z" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_CALLING_CARD_SERVICE_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymCallingCardServiceToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM CALLING CARD SERVICE TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1031 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymCallingCardServiceToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymPromptToneEnum =
{
    (Data *)"p" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_PROMPT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymPromptToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM PROMPT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1032 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymPromptToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymNetworkBusyEnum =
{
    (Data *)"nbz" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_NETWORK_BUSY
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymNetworkBusyEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM NETWORK BUSY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1033 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymNetworkBusyEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgLSgRqSymDistinctTonePatternEnum =
{
    (Data *)"s" ,
    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCT_TONE_PATTERN
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqSymDistinctTonePatternEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG L SG RQ SYM DISTINCT TONE PATTERN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1034 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqSymDistinctTonePatternEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgLSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgLSgRqSymAdsiDisplayEnumDef ,
&mgMsgDefPkgLSgRqSymAnswerToneEnumDef ,
&mgMsgDefPkgLSgRqSymBusyToneEnumDef ,
&mgMsgDefPkgLSgRqSymCallerIdEnumDef ,
&mgMsgDefPkgLSgRqSymDialToneEnumDef ,
&mgMsgDefPkgLSgRqSymErrorToneEnumDef ,
&mgMsgDefPkgLSgRqSymOnHoldToneEnumDef ,
&mgMsgDefPkgLSgRqSymLineSideAnswerSupEnumDef ,
&mgMsgDefPkgLSgRqSymMsgWaitngIndEnumDef ,
&mgMsgDefPkgLSgRqSymNetworkDisConnEnumDef ,
&mgMsgDefPkgLSgRqSymOffHookWarningToneEnumDef ,
&mgMsgDefPkgLSgRqSymRingingEnumDef ,
&mgMsgDefPkgLSgRqSymDistinctiveRinging0EnumDef ,
&mgMsgDefPkgLSgRqSymDistinctiveRinging1EnumDef ,
&mgMsgDefPkgLSgRqSymDistinctiveRinging2EnumDef ,
&mgMsgDefPkgLSgRqSymDistinctiveRinging3EnumDef ,
&mgMsgDefPkgLSgRqSymDistinctiveRinging4EnumDef ,
&mgMsgDefPkgLSgRqSymDistinctiveRinging5EnumDef ,
&mgMsgDefPkgLSgRqSymDistinctiveRinging6EnumDef ,
&mgMsgDefPkgLSgRqSymDistinctiveRinging7EnumDef ,
&mgMsgDefPkgLSgRqSymReorderToneEnumDef ,
&mgMsgDefPkgLSgRqSymRingsplashEnumDef ,
&mgMsgDefPkgLSgRqSymSpecialInfoToneEnumDef ,
&mgMsgDefPkgLSgRqSymStutterDialtoneEnumDef ,
&mgMsgDefPkgLSgRqSymAlertingToneEnumDef ,
&mgMsgDefPkgLSgRqSymVisualMsgEnumDef ,
&mgMsgDefPkgLSgRqSymCallWaitngToneEnumDef ,
&mgMsgDefPkgLSgRqSymAlternativeCall1EnumDef ,
&mgMsgDefPkgLSgRqSymAlternativeCall2EnumDef ,
&mgMsgDefPkgLSgRqSymAlternativeCall3EnumDef ,
&mgMsgDefPkgLSgRqSymAlternativeCall4EnumDef ,
&mgMsgDefPkgLSgRqSymRecorderWarningToneEnumDef ,
&mgMsgDefPkgLSgRqSymCallingCardServiceToneEnumDef ,
&mgMsgDefPkgLSgRqSymPromptToneEnumDef ,
&mgMsgDefPkgLSgRqSymNetworkBusyEnumDef ,
&mgMsgDefPkgLSgRqSymDistinctTonePatternEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgLSgRqEvntKnownChc =
{
    36 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgLSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG L SG RQ EVNT KNOWN " ,
    "PkgLSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1035 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgLSgRqEvntKnownChc ,
    mgMsgRegExpPkgLSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgLSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgLSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgLSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgLSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgLSgRqEvntDescChcElmnt ,
    mgMsgDefPkgLSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG L SG RQ EVNT DESC " ,
    "PkgLSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1042 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgLSgRqEvntDescChc ,
    mgMsgRegExpPkgLSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgLSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgLSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgLSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgLSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgLSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG L SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1043 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgLSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_LINE */




#ifdef  GCP_PKG_MGCP_NAM_MF_GRP_DE

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDRqEvSymCallAnswerEnum =
{
    (Data *)"ans" ,
    MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_ANSWER
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvSymCallAnswerEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D RQ EV SYM CALL ANSWER ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1039,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDRqEvSymCallAnswerEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDRqEvSymAckWinkEnum =
{
    (Data *)"awk" ,
    MGT_MGCP_PKG_M_D_RQ_EV_SYM_ACK_WINK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvSymAckWinkEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D RQ EV SYM ACK WINK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1040,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDRqEvSymAckWinkEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDRqEvSymCallBlockEnum =
{
    (Data *)"bl" ,
    MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_BLOCK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvSymCallBlockEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D RQ EV SYM CALL BLOCK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1041,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDRqEvSymCallBlockEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDRqEvSymInfoDgtsEnum =
{
    (Data *)"inf" ,
    MGT_MGCP_PKG_M_D_RQ_EV_SYM_INFO_DGTS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvSymInfoDgtsEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D RQ EV SYM INFO DGTS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1042,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDRqEvSymInfoDgtsEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_M_D_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1043,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDRqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_M_D_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1044,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDRqEvSymOperFailEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDRqEvSymReleaseCallEnum =
{
    (Data *)"rel" ,
    MGT_MGCP_PKG_M_D_RQ_EV_SYM_RELEASE_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvSymReleaseCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D RQ EV SYM RELEASE CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1045,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDRqEvSymReleaseCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDRqEvSymResumeCallEnum =
{
    (Data *)"res" ,
    MGT_MGCP_PKG_M_D_RQ_EV_SYM_RESUME_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvSymResumeCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D RQ EV SYM RESUME CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1046,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDRqEvSymResumeCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDRqEvSymReleaseCompltEnum =
{
    (Data *)"rlc" ,
    MGT_MGCP_PKG_M_D_RQ_EV_SYM_RELEASE_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvSymReleaseCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D RQ EV SYM RELEASE COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1047,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDRqEvSymReleaseCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDRqEvSymCallSetupEnum =
{
    (Data *)"sup" ,
    MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_SETUP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvSymCallSetupEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D RQ EV SYM CALL SETUP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1048,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDRqEvSymCallSetupEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDRqEvSymSuspendCallEnum =
{
    (Data *)"sus" ,
    MGT_MGCP_PKG_M_D_RQ_EV_SYM_SUSPEND_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvSymSuspendCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D RQ EV SYM SUSPEND CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1049,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDRqEvSymSuspendCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDRqEvSymStartWinkEnum =
{
    (Data *)"swk" ,
    MGT_MGCP_PKG_M_D_RQ_EV_SYM_START_WINK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvSymStartWinkEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D RQ EV SYM START WINK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1050,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDRqEvSymStartWinkEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMDRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgMDRqEvSymCallAnswerEnumDef ,
&mgMsgDefPkgMDRqEvSymAckWinkEnumDef ,
&mgMsgDefPkgMDRqEvSymCallBlockEnumDef ,
&mgMsgDefPkgMDRqEvSymInfoDgtsEnumDef ,
&mgMsgDefPkgMDRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgMDRqEvSymOperFailEnumDef ,
&mgMsgDefPkgMDRqEvSymReleaseCallEnumDef ,
&mgMsgDefPkgMDRqEvSymResumeCallEnumDef ,
&mgMsgDefPkgMDRqEvSymReleaseCompltEnumDef ,
&mgMsgDefPkgMDRqEvSymCallSetupEnumDef ,
&mgMsgDefPkgMDRqEvSymSuspendCallEnumDef ,
&mgMsgDefPkgMDRqEvSymStartWinkEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgMDRqEvEvntKnownChc =
{
    12 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgMDRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M D RQ EV EVNT KNOWN " ,
    "PkgMDRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1051,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgMDRqEvEvntKnownChc ,
    mgMsgRegExpPkgMDRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgMDRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMDRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgMDRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgMDRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgMDRqEvEvntDescChcElmnt ,
    mgMsgDefPkgMDRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M D RQ EV EVNT DESC " ,
    "PkgMDRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1052,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgMDRqEvEvntDescChc ,
    mgMsgRegExpPkgMDRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMDRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgMDRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgMDRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgMDRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M D RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1053,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgMDRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDSgRqSymCallAnswerEnum =
{
    (Data *)"ans" ,
    MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_ANSWER
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqSymCallAnswerEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D SG RQ SYM CALL ANSWER ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1054,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqSymCallAnswerEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDSgRqSymAckWinkEnum =
{
    (Data *)"awk" ,
    MGT_MGCP_PKG_M_D_SG_RQ_SYM_ACK_WINK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqSymAckWinkEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D SG RQ SYM ACK WINK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1055,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqSymAckWinkEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDSgRqSymCallBlockEnum =
{
    (Data *)"bl" ,
    MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_BLOCK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqSymCallBlockEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D SG RQ SYM CALL BLOCK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1056,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqSymCallBlockEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDSgRqSymBusyToneEnum =
{
    (Data *)"bz" ,
    MGT_MGCP_PKG_M_D_SG_RQ_SYM_BUSY_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqSymBusyToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D SG RQ SYM BUSY TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1057,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqSymBusyToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDSgRqSymContinueWinkEnum =
{
    (Data *)"cwk" ,
    MGT_MGCP_PKG_M_D_SG_RQ_SYM_CONTINUE_WINK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqSymContinueWinkEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D SG RQ SYM CONTINUE WINK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1058,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqSymContinueWinkEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDSgRqSymInfoDgtsEnum =
{
    (Data *)"inf" ,
    MGT_MGCP_PKG_M_D_SG_RQ_SYM_INFO_DGTS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqSymInfoDgtsEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D SG RQ SYM INFO DGTS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1059,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqSymInfoDgtsEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDSgRqSymReleaseCallEnum =
{
    (Data *)"rel" ,
    MGT_MGCP_PKG_M_D_SG_RQ_SYM_RELEASE_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqSymReleaseCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D SG RQ SYM RELEASE CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1060,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqSymReleaseCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDSgRqSymResumeCallEnum =
{
    (Data *)"res" ,
    MGT_MGCP_PKG_M_D_SG_RQ_SYM_RESUME_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqSymResumeCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D SG RQ SYM RESUME CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1061,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqSymResumeCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDSgRqSymReleaseCompleteEnum =
{
    (Data *)"rlc" ,
    MGT_MGCP_PKG_M_D_SG_RQ_SYM_RELEASE_COMPLETE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqSymReleaseCompleteEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D SG RQ SYM RELEASE COMPLETE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1062,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqSymReleaseCompleteEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDSgRqSymReorderToneEnum =
{
    (Data *)"ro" ,
    MGT_MGCP_PKG_M_D_SG_RQ_SYM_REORDER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqSymReorderToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D SG RQ SYM REORDER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1063,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqSymReorderToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDSgRqSymRingbackToneEnum =
{
    (Data *)"rt" ,
    MGT_MGCP_PKG_M_D_SG_RQ_SYM_RINGBACK_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqSymRingbackToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D SG RQ SYM RINGBACK TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1064,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqSymRingbackToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDSgRqSymCallSetupEnum =
{
    (Data *)"sup" ,
    MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_SETUP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqSymCallSetupEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D SG RQ SYM CALL SETUP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1065,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqSymCallSetupEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMDSgRqSymSuspendCallEnum =
{
    (Data *)"sus" ,
    MGT_MGCP_PKG_M_D_SG_RQ_SYM_SUSPEND_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqSymSuspendCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M D SG RQ SYM SUSPEND CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1066,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqSymSuspendCallEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMDSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgMDSgRqSymCallAnswerEnumDef ,
&mgMsgDefPkgMDSgRqSymAckWinkEnumDef ,
&mgMsgDefPkgMDSgRqSymCallBlockEnumDef ,
&mgMsgDefPkgMDSgRqSymBusyToneEnumDef ,
&mgMsgDefPkgMDSgRqSymContinueWinkEnumDef ,
&mgMsgDefPkgMDSgRqSymInfoDgtsEnumDef ,
&mgMsgDefPkgMDSgRqSymReleaseCallEnumDef ,
&mgMsgDefPkgMDSgRqSymResumeCallEnumDef ,
&mgMsgDefPkgMDSgRqSymReleaseCompleteEnumDef ,
&mgMsgDefPkgMDSgRqSymReorderToneEnumDef ,
&mgMsgDefPkgMDSgRqSymRingbackToneEnumDef ,
&mgMsgDefPkgMDSgRqSymCallSetupEnumDef ,
&mgMsgDefPkgMDSgRqSymSuspendCallEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgMDSgRqEvntKnownChc =
{
    13 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgMDSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M D SG RQ EVNT KNOWN " ,
    "PkgMDSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1067,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgMDSgRqEvntKnownChc ,
    mgMsgRegExpPkgMDSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgMDSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMDSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgMDSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgMDSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgMDSgRqEvntDescChcElmnt ,
    mgMsgDefPkgMDSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M D SG RQ EVNT DESC " ,
    "PkgMDSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1068,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgMDSgRqEvntDescChc ,
    mgMsgRegExpPkgMDSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMDSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgMDSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgMDSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgMDSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMDSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M D SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1069,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgMDSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_NAM_MF_GRP_DE */




#ifdef  GCP_PKG_MGCP_FGD_OP_SR_SIGOUT

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMORqEvSymCallAnswerEnum =
{
    (Data *)"ans" ,
    MGT_MGCP_PKG_M_O_RQ_EV_SYM_CALL_ANSWER
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMORqEvSymCallAnswerEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O RQ EV SYM CALL ANSWER ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1070,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMORqEvSymCallAnswerEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMORqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMORqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1071,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMORqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMORqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMORqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1072,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMORqEvSymOperFailEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMORqEvSymOperRingbackEnum =
{
    (Data *)"orbk" ,
    MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_RINGBACK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMORqEvSymOperRingbackEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O RQ EV SYM OPER RINGBACK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1073,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMORqEvSymOperRingbackEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMORqEvSymReverseMakeBusyEnum =
{
    (Data *)"rbz" ,
    MGT_MGCP_PKG_M_O_RQ_EV_SYM_REVERSE_MAKE_BUSY
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMORqEvSymReverseMakeBusyEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O RQ EV SYM REVERSE MAKE BUSY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1074,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMORqEvSymReverseMakeBusyEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMORqEvSymReleaseCallEnum =
{
    (Data *)"rel" ,
    MGT_MGCP_PKG_M_O_RQ_EV_SYM_RELEASE_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMORqEvSymReleaseCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O RQ EV SYM RELEASE CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1075,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMORqEvSymReleaseCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMORqEvSymReleaseCompleteEnum =
{
    (Data *)"rlc" ,
    MGT_MGCP_PKG_M_O_RQ_EV_SYM_RELEASE_COMPLETE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMORqEvSymReleaseCompleteEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O RQ EV SYM RELEASE COMPLETE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1076,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMORqEvSymReleaseCompleteEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMORqEvSymStartWinkEnum =
{
    (Data *)"swk" ,
    MGT_MGCP_PKG_M_O_RQ_EV_SYM_START_WINK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMORqEvSymStartWinkEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O RQ EV SYM START WINK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1077,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMORqEvSymStartWinkEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMORqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgMORqEvSymCallAnswerEnumDef ,
&mgMsgDefPkgMORqEvSymOperCompltEnumDef ,
&mgMsgDefPkgMORqEvSymOperFailEnumDef ,
&mgMsgDefPkgMORqEvSymOperRingbackEnumDef ,
&mgMsgDefPkgMORqEvSymReverseMakeBusyEnumDef ,
&mgMsgDefPkgMORqEvSymReleaseCallEnumDef ,
&mgMsgDefPkgMORqEvSymReleaseCompleteEnumDef ,
&mgMsgDefPkgMORqEvSymStartWinkEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgMORqEvEvntKnownChc =
{
    8 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgMORqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMORqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M O RQ EV EVNT KNOWN " ,
    "PkgMORqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1078,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgMORqEvEvntKnownChc ,
    mgMsgRegExpPkgMORqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgMORqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMORqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgMORqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgMORqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgMORqEvEvntDescChcElmnt ,
    mgMsgDefPkgMORqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMORqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M O RQ EV EVNT DESC " ,
    "PkgMORqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1079,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgMORqEvEvntDescChc ,
    mgMsgRegExpPkgMORqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMORqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgMORqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgMORqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgMORqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMORqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M O RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1080,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgMORqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMOSgRqSymOperRecallEnum =
{
    (Data *)"rcl" ,
    MGT_MGCP_PKG_M_O_SG_RQ_SYM_OPER_RECALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMOSgRqSymOperRecallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O SG RQ SYM OPER RECALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1081,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMOSgRqSymOperRecallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMOSgRqSymReleaseCallEnum =
{
    (Data *)"rel" ,
    MGT_MGCP_PKG_M_O_SG_RQ_SYM_RELEASE_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMOSgRqSymReleaseCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O SG RQ SYM RELEASE CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1082,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMOSgRqSymReleaseCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMOSgRqSymResumeCallEnum =
{
    (Data *)"res" ,
    MGT_MGCP_PKG_M_O_SG_RQ_SYM_RESUME_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMOSgRqSymResumeCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O SG RQ SYM RESUME CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1083,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMOSgRqSymResumeCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMOSgRqSymReleaseCompleteEnum =
{
    (Data *)"rlc" ,
    MGT_MGCP_PKG_M_O_SG_RQ_SYM_RELEASE_COMPLETE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMOSgRqSymReleaseCompleteEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O SG RQ SYM RELEASE COMPLETE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1084,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMOSgRqSymReleaseCompleteEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMOSgRqSymCallSetupEnum =
{
    (Data *)"sup" ,
    MGT_MGCP_PKG_M_O_SG_RQ_SYM_CALL_SETUP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMOSgRqSymCallSetupEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O SG RQ SYM CALL SETUP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1085,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMOSgRqSymCallSetupEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMOSgRqSymSuspendCallEnum =
{
    (Data *)"sus" ,
    MGT_MGCP_PKG_M_O_SG_RQ_SYM_SUSPEND_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMOSgRqSymSuspendCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M O SG RQ SYM SUSPEND CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1086,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMOSgRqSymSuspendCallEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMOSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgMOSgRqSymOperRecallEnumDef ,
&mgMsgDefPkgMOSgRqSymReleaseCallEnumDef ,
&mgMsgDefPkgMOSgRqSymResumeCallEnumDef ,
&mgMsgDefPkgMOSgRqSymReleaseCompleteEnumDef ,
&mgMsgDefPkgMOSgRqSymCallSetupEnumDef ,
&mgMsgDefPkgMOSgRqSymSuspendCallEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgMOSgRqEvntKnownChc =
{
    6 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgMOSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMOSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M O SG RQ EVNT KNOWN " ,
    "PkgMOSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1087,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgMOSgRqEvntKnownChc ,
    mgMsgRegExpPkgMOSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgMOSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMOSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgMOSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgMOSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgMOSgRqEvntDescChcElmnt ,
    mgMsgDefPkgMOSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMOSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M O SG RQ EVNT DESC " ,
    "PkgMOSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1088,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgMOSgRqEvntDescChc ,
    mgMsgRegExpPkgMOSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMOSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgMOSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgMOSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgMOSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMOSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M O SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1089,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgMOSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_FGD_OP_SR_SIGOUT */



#ifdef  GCP_PKG_MGCP_MF_WINKSTART

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSRqEvSymCallAnswerEnum =
{
    (Data *)"ans" ,
    MGT_MGCP_PKG_M_S_RQ_EV_SYM_CALL_ANSWER
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSRqEvSymCallAnswerEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S RQ EV SYM CALL ANSWER ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1090,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSRqEvSymCallAnswerEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSRqEvSymBlockEnum =
{
    (Data *)"bl" ,
    MGT_MGCP_PKG_M_S_RQ_EV_SYM_BLOCK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSRqEvSymBlockEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S RQ EV SYM BLOCK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1091,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSRqEvSymBlockEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSRqEvSymInfoDgtsEnum =
{
    (Data *)"inf" ,
    MGT_MGCP_PKG_M_S_RQ_EV_SYM_INFO_DGTS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSRqEvSymInfoDgtsEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S RQ EV SYM INFO DGTS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1092,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSRqEvSymInfoDgtsEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_M_S_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1093,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSRqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_M_S_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1094,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSRqEvSymOperFailEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSRqEvSymReleaseCallEnum =
{
    (Data *)"rel" ,
    MGT_MGCP_PKG_M_S_RQ_EV_SYM_RELEASE_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSRqEvSymReleaseCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S RQ EV SYM RELEASE CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1095,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSRqEvSymReleaseCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSRqEvSymResumeCallEnum =
{
    (Data *)"res" ,
    MGT_MGCP_PKG_M_S_RQ_EV_SYM_RESUME_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSRqEvSymResumeCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S RQ EV SYM RESUME CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1096,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSRqEvSymResumeCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSRqEvSymReleaseCompleteEnum =
{
    (Data *)"rlc" ,
    MGT_MGCP_PKG_M_S_RQ_EV_SYM_RELEASE_COMPLETE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSRqEvSymReleaseCompleteEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S RQ EV SYM RELEASE COMPLETE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1097,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSRqEvSymReleaseCompleteEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSRqEvSymCallSetupEnum =
{
    (Data *)"sup" ,
    MGT_MGCP_PKG_M_S_RQ_EV_SYM_CALL_SETUP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSRqEvSymCallSetupEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S RQ EV SYM CALL SETUP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1098,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSRqEvSymCallSetupEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSRqEvSymSuspendCallEnum =
{
    (Data *)"sus" ,
    MGT_MGCP_PKG_M_S_RQ_EV_SYM_SUSPEND_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSRqEvSymSuspendCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S RQ EV SYM SUSPEND CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1099,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSRqEvSymSuspendCallEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMSRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgMSRqEvSymCallAnswerEnumDef ,
&mgMsgDefPkgMSRqEvSymBlockEnumDef ,
&mgMsgDefPkgMSRqEvSymInfoDgtsEnumDef ,
&mgMsgDefPkgMSRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgMSRqEvSymOperFailEnumDef ,
&mgMsgDefPkgMSRqEvSymReleaseCallEnumDef ,
&mgMsgDefPkgMSRqEvSymResumeCallEnumDef ,
&mgMsgDefPkgMSRqEvSymReleaseCompleteEnumDef ,
&mgMsgDefPkgMSRqEvSymCallSetupEnumDef ,
&mgMsgDefPkgMSRqEvSymSuspendCallEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgMSRqEvEvntKnownChc =
{
    10 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgMSRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M S RQ EV EVNT KNOWN " ,
    "PkgMSRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1100,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgMSRqEvEvntKnownChc ,
    mgMsgRegExpPkgMSRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgMSRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMSRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgMSRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgMSRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgMSRqEvEvntDescChcElmnt ,
    mgMsgDefPkgMSRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M S RQ EV EVNT DESC " ,
    "PkgMSRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1101,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgMSRqEvEvntDescChc ,
    mgMsgRegExpPkgMSRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMSRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgMSRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgMSRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgMSRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M S RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1102,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgMSRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSSgRqSymCallAnswerEnum =
{
    (Data *)"ans" ,
    MGT_MGCP_PKG_M_S_SG_RQ_SYM_CALL_ANSWER
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSSgRqSymCallAnswerEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S SG RQ SYM CALL ANSWER ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1103,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSSgRqSymCallAnswerEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSSgRqSymBlockEnum =
{
    (Data *)"bl" ,
    MGT_MGCP_PKG_M_S_SG_RQ_SYM_BLOCK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSSgRqSymBlockEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S SG RQ SYM BLOCK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1104,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSSgRqSymBlockEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSSgRqSymBusyToneEnum =
{
    (Data *)"bz" ,
    MGT_MGCP_PKG_M_S_SG_RQ_SYM_BUSY_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSSgRqSymBusyToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S SG RQ SYM BUSY TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1105,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSSgRqSymBusyToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSSgRqSymReleaseCallEnum =
{
    (Data *)"rel" ,
    MGT_MGCP_PKG_M_S_SG_RQ_SYM_RELEASE_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSSgRqSymReleaseCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S SG RQ SYM RELEASE CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1106,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSSgRqSymReleaseCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSSgRqSymResumeCallEnum =
{
    (Data *)"res" ,
    MGT_MGCP_PKG_M_S_SG_RQ_SYM_RESUME_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSSgRqSymResumeCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S SG RQ SYM RESUME CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1107,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSSgRqSymResumeCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSSgRqSymReleaseCompleteEnum =
{
    (Data *)"rlc" ,
    MGT_MGCP_PKG_M_S_SG_RQ_SYM_RELEASE_COMPLETE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSSgRqSymReleaseCompleteEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S SG RQ SYM RELEASE COMPLETE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1108,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSSgRqSymReleaseCompleteEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSSgRqSymReorderToneEnum =
{
    (Data *)"ro" ,
    MGT_MGCP_PKG_M_S_SG_RQ_SYM_REORDER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSSgRqSymReorderToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S SG RQ SYM REORDER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1109,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSSgRqSymReorderToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSSgRqSymRingbackToneEnum =
{
    (Data *)"rt" ,
    MGT_MGCP_PKG_M_S_SG_RQ_SYM_RINGBACK_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSSgRqSymRingbackToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S SG RQ SYM RINGBACK TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1110,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSSgRqSymRingbackToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSSgRqSymCallSetupEnum =
{
    (Data *)"sup" ,
    MGT_MGCP_PKG_M_S_SG_RQ_SYM_CALL_SETUP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSSgRqSymCallSetupEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S SG RQ SYM CALL SETUP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1111,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSSgRqSymCallSetupEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSSgRqSymSuspendCallEnum =
{
    (Data *)"sus" ,
    MGT_MGCP_PKG_M_S_SG_RQ_SYM_SUSPEND_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSSgRqSymSuspendCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M S SG RQ SYM SUSPEND CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1112,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSSgRqSymSuspendCallEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMSSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgMSSgRqSymCallAnswerEnumDef ,
&mgMsgDefPkgMSSgRqSymBlockEnumDef ,
&mgMsgDefPkgMSSgRqSymBusyToneEnumDef ,
&mgMsgDefPkgMSSgRqSymReleaseCallEnumDef ,
&mgMsgDefPkgMSSgRqSymResumeCallEnumDef ,
&mgMsgDefPkgMSSgRqSymReleaseCompleteEnumDef ,
&mgMsgDefPkgMSSgRqSymReorderToneEnumDef ,
&mgMsgDefPkgMSSgRqSymRingbackToneEnumDef ,
&mgMsgDefPkgMSSgRqSymCallSetupEnumDef ,
&mgMsgDefPkgMSSgRqSymSuspendCallEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgMSSgRqEvntKnownChc =
{
    10 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgMSSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M S SG RQ EVNT KNOWN " ,
    "PkgMSSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1113,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgMSSgRqEvntKnownChc ,
    mgMsgRegExpPkgMSSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgMSSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMSSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgMSSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgMSSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgMSSgRqEvntDescChcElmnt ,
    mgMsgDefPkgMSSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M S SG RQ EVNT DESC " ,
    "PkgMSSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1114,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgMSSgRqEvntDescChc ,
    mgMsgRegExpPkgMSSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMSSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgMSSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgMSSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgMSSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M S SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1115,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgMSSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_MF_WINKSTART */




#ifdef  GCP_PKG_MGCP_RTP

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRRqEvSymIcmpUnreachableEnum =
{
    (Data *)"iu" ,
    MGT_MGCP_PKG_R_RQ_EV_SYM_ICMP_UNREACHABLE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvSymIcmpUnreachableEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R RQ EV SYM ICMP UNREACHABLE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1116,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRRqEvSymIcmpUnreachableEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRRqEvSymRtpOrRtcpTimeoutEnum =
{
    (Data *)"rto" ,
    MGT_MGCP_PKG_R_RQ_EV_SYM_RTP_OR_RTCP_TIMEOUT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvSymRtpOrRtcpTimeoutEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R RQ EV SYM RTP OR RTCP TIMEOUT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1117,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRRqEvSymRtpOrRtcpTimeoutEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRRqEvSymUsedCodecChngdEnum =
{
    (Data *)"uc" ,
    MGT_MGCP_PKG_R_RQ_EV_SYM_USED_CODEC_CHNGD
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvSymUsedCodecChngdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R RQ EV SYM USED CODEC CHNGD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1118,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRRqEvSymUsedCodecChngdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRRqEvSymSamplRateChngdEnum =
{
    (Data *)"sr" ,
    MGT_MGCP_PKG_R_RQ_EV_SYM_SAMPL_RATE_CHNGD
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvSymSamplRateChngdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R RQ EV SYM SAMPL RATE CHNGD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1119,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRRqEvSymSamplRateChngdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRRqEvSymJitterBuffSizeChngdEnum =
{
    (Data *)"ji" ,
    MGT_MGCP_PKG_R_RQ_EV_SYM_JITTER_BUFF_SIZE_CHNGD
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvSymJitterBuffSizeChngdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R RQ EV SYM JITTER BUFF SIZE CHNGD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1120,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRRqEvSymJitterBuffSizeChngdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRRqEvSymPcktLossExceededEnum =
{
    (Data *)"pl" ,
    MGT_MGCP_PKG_R_RQ_EV_SYM_PCKT_LOSS_EXCEEDED
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvSymPcktLossExceededEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R RQ EV SYM PCKT LOSS EXCEEDED ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1121,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRRqEvSymPcktLossExceededEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRRqEvSymQualityAlertEnum =
{
    (Data *)"qa" ,
    MGT_MGCP_PKG_R_RQ_EV_SYM_QUALITY_ALERT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvSymQualityAlertEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R RQ EV SYM QUALITY ALERT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1122,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRRqEvSymQualityAlertEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRRqEvSymContinuityToneEnum =
{
    (Data *)"co1" ,
    MGT_MGCP_PKG_R_RQ_EV_SYM_CONTINUITY_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvSymContinuityToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R RQ EV SYM CONTINUITY TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1123,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRRqEvSymContinuityToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRRqEvSymContinuityTestEnum =
{
    (Data *)"co2" ,
    MGT_MGCP_PKG_R_RQ_EV_SYM_CONTINUITY_TEST
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvSymContinuityTestEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R RQ EV SYM CONTINUITY TEST ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1124,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRRqEvSymContinuityTestEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_R_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1125,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRRqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_R_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1126,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRRqEvSymOperFailEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRRqEvSymMediaStartEnum =
{
    (Data *)"ma" ,
    MGT_MGCP_PKG_R_RQ_EV_SYM_MEDIA_START
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvSymMediaStartEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R RQ EV SYM MEDIA START ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1010 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRRqEvSymMediaStartEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgRRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgRRqEvSymIcmpUnreachableEnumDef ,
&mgMsgDefPkgRRqEvSymRtpOrRtcpTimeoutEnumDef ,
&mgMsgDefPkgRRqEvSymUsedCodecChngdEnumDef ,
&mgMsgDefPkgRRqEvSymSamplRateChngdEnumDef ,
&mgMsgDefPkgRRqEvSymJitterBuffSizeChngdEnumDef ,
&mgMsgDefPkgRRqEvSymPcktLossExceededEnumDef ,
&mgMsgDefPkgRRqEvSymQualityAlertEnumDef ,
&mgMsgDefPkgRRqEvSymContinuityToneEnumDef ,
&mgMsgDefPkgRRqEvSymContinuityTestEnumDef ,
&mgMsgDefPkgRRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgRRqEvSymOperFailEnumDef ,
&mgMsgDefPkgRRqEvSymMediaStartEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgRRqEvEvntKnownChc =
{
    12 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgRRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG R RQ EV EVNT KNOWN " ,
    "PkgRRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1127,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgRRqEvEvntKnownChc ,
    mgMsgRegExpPkgRRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgRRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgRRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgRRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgRRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgRRqEvEvntDescChcElmnt ,
    mgMsgDefPkgRRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG R RQ EV EVNT DESC " ,
    "PkgRRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1128,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgRRqEvEvntDescChc ,
    mgMsgRegExpPkgRRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgRRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgRRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgRRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgRRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG R RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1129,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgRRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRSgRqSymContinuityToneEnum =
{
    (Data *)"co1" ,
    MGT_MGCP_PKG_R_SG_RQ_SYM_CONTINUITY_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRSgRqSymContinuityToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R SG RQ SYM CONTINUITY TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1130,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRSgRqSymContinuityToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRSgRqSymContinuityTestEnum =
{
    (Data *)"co2" ,
    MGT_MGCP_PKG_R_SG_RQ_SYM_CONTINUITY_TEST
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRSgRqSymContinuityTestEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R SG RQ SYM CONTINUITY TEST ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1131,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRSgRqSymContinuityTestEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgRSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgRSgRqSymContinuityToneEnumDef ,
&mgMsgDefPkgRSgRqSymContinuityTestEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgRSgRqEvntKnownChc =
{
    2 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgRSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG R SG RQ EVNT KNOWN " ,
    "PkgRSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1132,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgRSgRqEvntKnownChc ,
    mgMsgRegExpPkgRSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgRSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgRSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgRSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgRSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgRSgRqEvntDescChcElmnt ,
    mgMsgDefPkgRSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG R SG RQ EVNT DESC " ,
    "PkgRSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1133,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgRSgRqEvntDescChc ,
    mgMsgRegExpPkgRSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgRSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgRSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgRSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgRSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG R SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1134,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgRSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_RTP */




#ifdef  GCP_PKG_MGCP_RES_RESERV

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRESRqEvSymResourceLostEnum =
{
    (Data *)"rl" ,
    MGT_MGCP_PKG_R_E_S_RQ_EV_SYM_RESOURCE_LOST
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRESRqEvSymResourceLostEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R E S RQ EV SYM RESOURCE LOST ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1135,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRESRqEvSymResourceLostEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgRESRqEvSymResourceErrorEnum =
{
    (Data *)"re" ,
    MGT_MGCP_PKG_R_E_S_RQ_EV_SYM_RESOURCE_ERROR
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRESRqEvSymResourceErrorEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG R E S RQ EV SYM RESOURCE ERROR ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1000 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgRESRqEvSymResourceErrorEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgRESRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgRESRqEvSymResourceLostEnumDef ,
&mgMsgDefPkgRESRqEvSymResourceErrorEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgRESRqEvEvntKnownChc =
{
    2 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgRESRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRESRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG R E S RQ EV EVNT KNOWN " ,
    "PkgRESRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1136,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgRESRqEvEvntKnownChc ,
    mgMsgRegExpPkgRESRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgRESRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgRESRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgRESRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgRESRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgRESRqEvEvntDescChcElmnt ,
    mgMsgDefPkgRESRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRESRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG R E S RQ EV EVNT DESC " ,
    "PkgRESRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1137,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgRESRqEvEvntDescChc ,
    mgMsgRegExpPkgRESRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgRESRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgRESRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgRESRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgRESRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgRESRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG R E S RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1138,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgRESRqEvEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_RES_RESERV */




#ifdef  GCP_PKG_MGCP_SCRIPT

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgScriptRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG SCRIPT RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1139,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgScriptRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgScriptRqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG SCRIPT RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1140,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgScriptRqEvSymOperFailEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgScriptRqEvSymIntermediateResEnum =
{
    (Data *)"ir" ,
    MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_INTERMEDIATE_RES
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptRqEvSymIntermediateResEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG SCRIPT RQ EV SYM INTERMEDIATE RES ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1001 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgScriptRqEvSymIntermediateResEnum ,
    NULLP
};


PUBLIC CmAbnfElmDef  *mgMsgDefPkgScriptRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgScriptRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgScriptRqEvSymOperFailEnumDef ,
&mgMsgDefPkgScriptRqEvSymIntermediateResEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgScriptRqEvEvntKnownChc =
{
    3 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgScriptRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG SCRIPT RQ EV EVNT KNOWN " ,
    "PkgScriptRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1141,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgScriptRqEvEvntKnownChc ,
    mgMsgRegExpPkgScriptRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgScriptRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgScriptRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgScriptRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgScriptRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgScriptRqEvEvntDescChcElmnt ,
    mgMsgDefPkgScriptRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG SCRIPT RQ EV EVNT DESC " ,
    "PkgScriptRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1142,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgScriptRqEvEvntDescChc ,
    mgMsgRegExpPkgScriptRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgScriptRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgScriptRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgScriptRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgScriptRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG SCRIPT RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1143,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgScriptRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgScriptSgRqSymLoadAndRunJavaScriptEnum =
{
    (Data *)"java" ,
    MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_JAVA_SCRIPT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptSgRqSymLoadAndRunJavaScriptEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG SCRIPT SG RQ SYM LOAD AND RUN JAVA SCRIPT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1144,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgScriptSgRqSymLoadAndRunJavaScriptEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgScriptSgRqSymLoadAndRunPerlScriptEnum =
{
    (Data *)"perl" ,
    MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_PERL_SCRIPT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptSgRqSymLoadAndRunPerlScriptEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG SCRIPT SG RQ SYM LOAD AND RUN PERL SCRIPT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1145,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgScriptSgRqSymLoadAndRunPerlScriptEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgScriptSgRqSymLoadAndRunTCLScriptEnum =
{
    (Data *)"tcl" ,
    MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_T_C_L_SCRIPT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptSgRqSymLoadAndRunTCLScriptEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG SCRIPT SG RQ SYM LOAD AND RUN T C L SCRIPT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1146,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgScriptSgRqSymLoadAndRunTCLScriptEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgScriptSgRqSymLoadAndRunXMLScriptEnum =
{
    (Data *)"xml" ,
    MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_X_M_L_SCRIPT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptSgRqSymLoadAndRunXMLScriptEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG SCRIPT SG RQ SYM LOAD AND RUN X M L SCRIPT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1147,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgScriptSgRqSymLoadAndRunXMLScriptEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgScriptSgRqSymLoadAndRunVXMLDocEnum =
{
    (Data *)"vxml" ,
    MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_V_X_M_L_DOC
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptSgRqSymLoadAndRunVXMLDocEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG SCRIPT SG RQ SYM LOAD AND RUN V X M L DOC ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1148,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgScriptSgRqSymLoadAndRunVXMLDocEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgScriptSgRqSymIntermediateResEnum =
{
    (Data *)"ir" ,
    MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_INTERMEDIATE_RES
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptSgRqSymIntermediateResEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG SCRIPT SG RQ SYM INTERMEDIATE RES ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1016 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgScriptSgRqSymIntermediateResEnum ,
    NULLP
};


PUBLIC CmAbnfElmDef  *mgMsgDefPkgScriptSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgScriptSgRqSymLoadAndRunJavaScriptEnumDef ,
&mgMsgDefPkgScriptSgRqSymLoadAndRunPerlScriptEnumDef ,
&mgMsgDefPkgScriptSgRqSymLoadAndRunTCLScriptEnumDef ,
&mgMsgDefPkgScriptSgRqSymLoadAndRunXMLScriptEnumDef ,
&mgMsgDefPkgScriptSgRqSymLoadAndRunVXMLDocEnumDef ,
&mgMsgDefPkgScriptSgRqSymIntermediateResEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgScriptSgRqEvntKnownChc =
{
    6 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgScriptSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG SCRIPT SG RQ EVNT KNOWN " ,
    "PkgScriptSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1149,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgScriptSgRqEvntKnownChc ,
    mgMsgRegExpPkgScriptSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgScriptSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgScriptSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgScriptSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgScriptSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgScriptSgRqEvntDescChcElmnt ,
    mgMsgDefPkgScriptSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG SCRIPT SG RQ EVNT DESC " ,
    "PkgScriptSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1150,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgScriptSgRqEvntDescChc ,
    mgMsgRegExpPkgScriptSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgScriptSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgScriptSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgScriptSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgScriptSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgScriptSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG SCRIPT SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1151,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgScriptSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_SCRIPT */




#ifdef  GCP_PKG_MGCP_SIGLST

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSLRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_S_L_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSLRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S L RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1152,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSLRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSLRqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_S_L_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSLRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S L RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1153,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSLRqEvSymOperFailEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSLRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgSLRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgSLRqEvSymOperFailEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgSLRqEvEvntKnownChc =
{
    2 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgSLRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSLRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S L RQ EV EVNT KNOWN " ,
    "PkgSLRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1154,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgSLRqEvEvntKnownChc ,
    mgMsgRegExpPkgSLRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgSLRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSLRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgSLRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgSLRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgSLRqEvEvntDescChcElmnt ,
    mgMsgDefPkgSLRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSLRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S L RQ EV EVNT DESC " ,
    "PkgSLRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1155,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgSLRqEvEvntDescChc ,
    mgMsgRegExpPkgSLRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSLRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgSLRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgSLRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgSLRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSLRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S L RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1156,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgSLRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSLSgRqSymSigLstEnum =
{
    (Data *)"s" ,
    MGT_MGCP_PKG_S_L_SG_RQ_SYM_SIG_LST
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSLSgRqSymSigLstEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S L SG RQ SYM SIG LST ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1157,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSLSgRqSymSigLstEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSLSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgSLSgRqSymSigLstEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgSLSgRqEvntKnownChc =
{
    1 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgSLSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSLSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S L SG RQ EVNT KNOWN " ,
    "PkgSLSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1158,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgSLSgRqEvntKnownChc ,
    mgMsgRegExpPkgSLSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgSLSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSLSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgSLSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgSLSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgSLSgRqEvntDescChcElmnt ,
    mgMsgDefPkgSLSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSLSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S L SG RQ EVNT DESC " ,
    "PkgSLSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1159,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgSLSgRqEvntDescChc ,
    mgMsgRegExpPkgSLSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSLSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgSLSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgSLSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgSLSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSLSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S L SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1160,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgSLSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_SIGLST */




#ifdef  GCP_PKG_MGCP_SUPPL_SRVS_TONE

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSSTRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_S_S_T_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S S T RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1161,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSSTRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSSTRqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_S_S_T_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S S T RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1162,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSSTRqEvSymOperFailEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSSTRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgSSTRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgSSTRqEvSymOperFailEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgSSTRqEvEvntKnownChc =
{
    2 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgSSTRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S S T RQ EV EVNT KNOWN " ,
    "PkgSSTRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1163,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgSSTRqEvEvntKnownChc ,
    mgMsgRegExpPkgSSTRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgSSTRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSSTRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgSSTRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgSSTRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgSSTRqEvEvntDescChcElmnt ,
    mgMsgDefPkgSSTRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S S T RQ EV EVNT DESC " ,
    "PkgSSTRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1164,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgSSTRqEvEvntDescChc ,
    mgMsgRegExpPkgSSTRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSSTRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgSSTRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgSSTRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgSSTRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S S T RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1165,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgSSTRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSSTSgRqSymConferenceDepartEnum =
{
    (Data *)"cd" ,
    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CONFERENCE_DEPART
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTSgRqSymConferenceDepartEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S S T SG RQ SYM CONFERENCE DEPART ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1166,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSSTSgRqSymConferenceDepartEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSSTSgRqSymConferenceJoinEnum =
{
    (Data *)"cj" ,
    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CONFERENCE_JOIN
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTSgRqSymConferenceJoinEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S S T SG RQ SYM CONFERENCE JOIN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1167,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSSTSgRqSymConferenceJoinEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSSTSgRqSymComfortToneEnum =
{
    (Data *)"cm" ,
    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_COMFORT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTSgRqSymComfortToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S S T SG RQ SYM COMFORT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1168,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSSTSgRqSymComfortToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSSTSgRqSymCallerWaitingToneEnum =
{
    (Data *)"cw" ,
    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CALLER_WAITING_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTSgRqSymCallerWaitingToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S S T SG RQ SYM CALLER WAITING TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1169,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSSTSgRqSymCallerWaitingToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSSTSgRqSymNegativeIndEnum =
{
    (Data *)"ni" ,
    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_NEGATIVE_IND
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTSgRqSymNegativeIndEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S S T SG RQ SYM NEGATIVE IND ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1170,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSSTSgRqSymNegativeIndEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSSTSgRqSymNumberUnobtainableEnum =
{
    (Data *)"nu" ,
    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_NUMBER_UNOBTAINABLE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTSgRqSymNumberUnobtainableEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S S T SG RQ SYM NUMBER UNOBTAINABLE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1171,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSSTSgRqSymNumberUnobtainableEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSSTSgRqSymPayphoneRecogEnum =
{
    (Data *)"pr" ,
    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_PAYPHONE_RECOG
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTSgRqSymPayphoneRecogEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S S T SG RQ SYM PAYPHONE RECOG ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1172,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSSTSgRqSymPayphoneRecogEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSSTSgRqSymPayToneEnum =
{
    (Data *)"pt" ,
    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_PAY_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTSgRqSymPayToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S S T SG RQ SYM PAY TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1173,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSSTSgRqSymPayToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSSTSgRqSymOnHoldToneEnum =
{
    (Data *)"ht" ,
    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_ON_HOLD_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTSgRqSymOnHoldToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S S T SG RQ SYM ON HOLD TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1018 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSSTSgRqSymOnHoldToneEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSSTSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgSSTSgRqSymConferenceDepartEnumDef ,
&mgMsgDefPkgSSTSgRqSymConferenceJoinEnumDef ,
&mgMsgDefPkgSSTSgRqSymComfortToneEnumDef ,
&mgMsgDefPkgSSTSgRqSymCallerWaitingToneEnumDef ,
&mgMsgDefPkgSSTSgRqSymNegativeIndEnumDef ,
&mgMsgDefPkgSSTSgRqSymNumberUnobtainableEnumDef ,
&mgMsgDefPkgSSTSgRqSymPayphoneRecogEnumDef ,
&mgMsgDefPkgSSTSgRqSymPayToneEnumDef ,
&mgMsgDefPkgSSTSgRqSymOnHoldToneEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgSSTSgRqEvntKnownChc =
{
    9 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgSSTSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S S T SG RQ EVNT KNOWN " ,
    "PkgSSTSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1174,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgSSTSgRqEvntKnownChc ,
    mgMsgRegExpPkgSSTSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgSSTSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSSTSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgSSTSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgSSTSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgSSTSgRqEvntDescChcElmnt ,
    mgMsgDefPkgSSTSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S S T SG RQ EVNT DESC " ,
    "PkgSSTSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1175,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgSSTSgRqEvntDescChc ,
    mgMsgRegExpPkgSSTSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSSTSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgSSTSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgSSTSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgSSTSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSTSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S S T SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1176,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgSSTSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_SUPPL_SRVS_TONE */




#ifdef  GCP_PKG_MGCP_TRUNK

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTRqEvSymContinuityToneEnum =
{
    (Data *)"co1" ,
    MGT_MGCP_PKG_T_RQ_EV_SYM_CONTINUITY_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvSymContinuityToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T RQ EV SYM CONTINUITY TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1177,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvSymContinuityToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTRqEvSymContinuityTestEnum =
{
    (Data *)"co2" ,
    MGT_MGCP_PKG_T_RQ_EV_SYM_CONTINUITY_TEST
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvSymContinuityTestEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T RQ EV SYM CONTINUITY TEST ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1178,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvSymContinuityTestEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTRqEvSymNewMilliwattToneEnum =
{
    (Data *)"nm" ,
    MGT_MGCP_PKG_T_RQ_EV_SYM_NEW_MILLIWATT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvSymNewMilliwattToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T RQ EV SYM NEW MILLIWATT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1179,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvSymNewMilliwattToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTRqEvSymNewestMilliwattToneEnum =
{
    (Data *)"mm" ,
    MGT_MGCP_PKG_T_RQ_EV_SYM_NEWEST_MILLIWATT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvSymNewestMilliwattToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T RQ EV SYM NEWEST MILLIWATT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1180,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvSymNewestMilliwattToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTRqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_T_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1181,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTRqEvSymReportFailureEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_T_RQ_EV_SYM_REPORT_FAILURE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvSymReportFailureEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T RQ EV SYM REPORT FAILURE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1182,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvSymReportFailureEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTRqEvSymOldMilliwattToneEnum =
{
    (Data *)"om" ,
    MGT_MGCP_PKG_T_RQ_EV_SYM_OLD_MILLIWATT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvSymOldMilliwattToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T RQ EV SYM OLD MILLIWATT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1183,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvSymOldMilliwattToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTRqEvSymReorderToneEnum =
{
    (Data *)"ro" ,
    MGT_MGCP_PKG_T_RQ_EV_SYM_REORDER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvSymReorderToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T RQ EV SYM REORDER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1184,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvSymReorderToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTRqEvSymSpecialInfoToneEnum =
{
    (Data *)"sit" ,
    MGT_MGCP_PKG_T_RQ_EV_SYM_SPECIAL_INFO_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvSymSpecialInfoToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T RQ EV SYM SPECIAL INFO TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1185,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvSymSpecialInfoToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTRqEvSymTestLineEnum =
{
    (Data *)"tl" ,
    MGT_MGCP_PKG_T_RQ_EV_SYM_TEST_LINE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvSymTestLineEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T RQ EV SYM TEST LINE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1186,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvSymTestLineEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTRqEvSymTestPatternEnum =
{
    (Data *)"tp" ,
    MGT_MGCP_PKG_T_RQ_EV_SYM_TEST_PATTERN
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvSymTestPatternEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T RQ EV SYM TEST PATTERN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1187,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvSymTestPatternEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTRqEvSymNoCircuitEnum =
{
    (Data *)"zz" ,
    MGT_MGCP_PKG_T_RQ_EV_SYM_NO_CIRCUIT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvSymNoCircuitEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T RQ EV SYM NO CIRCUIT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1188,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvSymNoCircuitEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTRqEvSymAnswerSupervisEnum =
{
    (Data *)"as" ,
    MGT_MGCP_PKG_T_RQ_EV_SYM_ANSWER_SUPERVIS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvSymAnswerSupervisEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T RQ EV SYM ANSWER SUPERVIS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1189,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvSymAnswerSupervisEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgTRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgTRqEvSymContinuityToneEnumDef ,
&mgMsgDefPkgTRqEvSymContinuityTestEnumDef ,
&mgMsgDefPkgTRqEvSymNewMilliwattToneEnumDef ,
&mgMsgDefPkgTRqEvSymNewestMilliwattToneEnumDef ,
&mgMsgDefPkgTRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgTRqEvSymReportFailureEnumDef ,
&mgMsgDefPkgTRqEvSymOldMilliwattToneEnumDef ,
&mgMsgDefPkgTRqEvSymReorderToneEnumDef ,
&mgMsgDefPkgTRqEvSymSpecialInfoToneEnumDef ,
&mgMsgDefPkgTRqEvSymTestLineEnumDef ,
&mgMsgDefPkgTRqEvSymTestPatternEnumDef ,
&mgMsgDefPkgTRqEvSymNoCircuitEnumDef ,
&mgMsgDefPkgTRqEvSymAnswerSupervisEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgTRqEvEvntKnownChc =
{
    13 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgTRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG T RQ EV EVNT KNOWN " ,
    "PkgTRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1190,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgTRqEvEvntKnownChc ,
    mgMsgRegExpPkgTRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgTRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgTRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgTRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgTRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgTRqEvEvntDescChcElmnt ,
    mgMsgDefPkgTRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG T RQ EV EVNT DESC " ,
    "PkgTRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1191,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgTRqEvEvntDescChc ,
    mgMsgRegExpPkgTRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgTRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgTRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgTRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgTRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG T RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1192,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgTRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymContinuityToneEnum =
{
    (Data *)"co1" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymContinuityToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM CONTINUITY TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1193,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymContinuityToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymContinuityTestEnum =
{
    (Data *)"co2" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TEST
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymContinuityTestEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM CONTINUITY TEST ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1194,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymContinuityTestEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymLoopbackEnum =
{
    (Data *)"lb" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_LOOPBACK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymLoopbackEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM LOOPBACK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1195,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymLoopbackEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymNewMilliwattToneEnum =
{
    (Data *)"nm" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_NEW_MILLIWATT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymNewMilliwattToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM NEW MILLIWATT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1196,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymNewMilliwattToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymNewestMilliwattToneEnum =
{
    (Data *)"mm" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_NEWEST_MILLIWATT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymNewestMilliwattToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM NEWEST MILLIWATT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1197,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymNewestMilliwattToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymOldMilliwattToneEnum =
{
    (Data *)"om" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_OLD_MILLIWATT_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymOldMilliwattToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM OLD MILLIWATT TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1198,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymOldMilliwattToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymQuietTerminationEnum =
{
    (Data *)"qt" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_QUIET_TERMINATION
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymQuietTerminationEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM QUIET TERMINATION ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1199,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymQuietTerminationEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymReorderToneEnum =
{
    (Data *)"ro" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_REORDER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymReorderToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM REORDER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1200,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymReorderToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymSpecialInfoToneEnum =
{
    (Data *)"sit" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_SPECIAL_INFO_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymSpecialInfoToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM SPECIAL INFO TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1201,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymSpecialInfoToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymTestLineEnum =
{
    (Data *)"tl" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_TEST_LINE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymTestLineEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM TEST LINE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1202,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymTestLineEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymTestPatternEnum =
{
    (Data *)"tp" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_TEST_PATTERN
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymTestPatternEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM TEST PATTERN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1203,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymTestPatternEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymNoCircuitEnum =
{
    (Data *)"zz" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_NO_CIRCUIT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymNoCircuitEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM NO CIRCUIT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1204,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymNoCircuitEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymAnswerSupervisEnum =
{
    (Data *)"as" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_ANSWER_SUPERVIS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymAnswerSupervisEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM ANSWER SUPERVIS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1205,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymAnswerSupervisEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymBlockingEnum =
{
    (Data *)"bl" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_BLOCKING
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymBlockingEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM BLOCKING ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1206,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymBlockingEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymBusyEnum =
{
    (Data *)"bz" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_BUSY
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymBusyEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM BUSY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1035 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymBusyEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymContinuityTrspdrEnum =
{
    (Data *)"ct" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TRSPDR
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymContinuityTrspdrEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM CONTINUITY TRSPDR ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1036 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymContinuityTrspdrEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgTSgRqSymPermSigToneEnum =
{
    (Data *)"pst" ,
    MGT_MGCP_PKG_T_SG_RQ_SYM_PERM_SIG_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqSymPermSigToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG T SG RQ SYM PERM SIG TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1037 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqSymPermSigToneEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgTSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgTSgRqSymContinuityToneEnumDef ,
&mgMsgDefPkgTSgRqSymContinuityTestEnumDef ,
&mgMsgDefPkgTSgRqSymLoopbackEnumDef ,
&mgMsgDefPkgTSgRqSymNewMilliwattToneEnumDef ,
&mgMsgDefPkgTSgRqSymNewestMilliwattToneEnumDef ,
&mgMsgDefPkgTSgRqSymOldMilliwattToneEnumDef ,
&mgMsgDefPkgTSgRqSymQuietTerminationEnumDef ,
&mgMsgDefPkgTSgRqSymReorderToneEnumDef ,
&mgMsgDefPkgTSgRqSymSpecialInfoToneEnumDef ,
&mgMsgDefPkgTSgRqSymTestLineEnumDef ,
&mgMsgDefPkgTSgRqSymTestPatternEnumDef ,
&mgMsgDefPkgTSgRqSymNoCircuitEnumDef ,
&mgMsgDefPkgTSgRqSymAnswerSupervisEnumDef ,
&mgMsgDefPkgTSgRqSymBlockingEnumDef ,
&mgMsgDefPkgTSgRqSymBusyEnumDef ,
&mgMsgDefPkgTSgRqSymContinuityTrspdrEnumDef ,
&mgMsgDefPkgTSgRqSymPermSigToneEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgTSgRqEvntKnownChc =
{
    17 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgTSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG T SG RQ EVNT KNOWN " ,
    "PkgTSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1207,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgTSgRqEvntKnownChc ,
    mgMsgRegExpPkgTSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgTSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgTSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgTSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgTSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgTSgRqEvntDescChcElmnt ,
    mgMsgDefPkgTSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG T SG RQ EVNT DESC " ,
    "PkgTSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1208,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgTSgRqEvntDescChc ,
    mgMsgRegExpPkgTSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgTSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgTSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgTSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgTSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgTSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG T SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1209,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgTSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_TRUNK */





/*
   The following packages have been moved from 1.2 implementation to
   the package tree implementation -
        IT   Isup Trunk
        M    MF
        MT   MF Terminating
        NAS  NAS Basic
        S    ADSI
   The following packages are new -
        NAO  NAS Data
        FXR  Mgcp Fax
*/





#ifdef  GCP_PKG_MGCP_FAX

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgFXRRqEvSymGwCntrldFaxEnum =
{
    (Data *)"gwfax" ,
    MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_GW_CNTRLD_FAX
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgFXRRqEvSymGwCntrldFaxEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG F X R RQ EV SYM GW CNTRLD FAX ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  999 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgFXRRqEvSymGwCntrldFaxEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgFXRRqEvSymNoSpFaxHndlngEnum =
{
    (Data *)"nopfax" ,
    MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_NO_SP_FAX_HNDLNG
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgFXRRqEvSymNoSpFaxHndlngEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG F X R RQ EV SYM NO SP FAX HNDLNG ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1000 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgFXRRqEvSymNoSpFaxHndlngEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgFXRRqEvSymT38FaxRelayEnum =
{
    (Data *)"t38" ,
    MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_T38_FAX_RELAY
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgFXRRqEvSymT38FaxRelayEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG F X R RQ EV SYM T38 FAX RELAY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1001 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgFXRRqEvSymT38FaxRelayEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgFXRRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgFXRRqEvSymGwCntrldFaxEnumDef ,
&mgMsgDefPkgFXRRqEvSymNoSpFaxHndlngEnumDef ,
&mgMsgDefPkgFXRRqEvSymT38FaxRelayEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgFXRRqEvEvntKnownChc =
{
    3 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgFXRRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgFXRRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG F X R RQ EV EVNT KNOWN " ,
    "PkgFXRRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1002 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgFXRRqEvEvntKnownChc ,
    mgMsgRegExpPkgFXRRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgFXRRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgFXRRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgFXRRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgFXRRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgFXRRqEvEvntDescChcElmnt ,
    mgMsgDefPkgFXRRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgFXRRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG F X R RQ EV EVNT DESC " ,
    "PkgFXRRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1009 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgFXRRqEvEvntDescChc ,
    mgMsgRegExpPkgFXRRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgFXRRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgFXRRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgFXRRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgFXRRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgFXRRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG F X R RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1010 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgFXRRqEvEvntNameSeq ,
    NULLP
};




#ifdef GCP_2705BIS

PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgFXRExtnNameFaxHndlngEnum =
{
    (Data *)"fx" ,
    MGT_MGCP_CO_PKG_F_X_R_FAX_HNDLNG
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgFXRExtnNameFaxHndlngEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG F X R EXTN NAME FAX HNDLNG ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1011 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgFXRExtnNameFaxHndlngEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefConnOptPkgFXRExtnNameTreeChcEnum[] =
{
NULLP ,
&mgMsgDefConnOptPkgFXRExtnNameFaxHndlngEnumDef ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefConnOptPkgFXRExtnNameTreeChcElmnt[] =
{
    &mgMsgDefConnOptPkgExtnName ,
    NULLP ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefConnOptPkgFXRExtnNameTreeChc =
{
    2 ,
    0 ,
    NULLP ,
    mgMsgDefConnOptPkgFXRExtnNameTreeChcElmnt ,
    mgMsgDefConnOptPkgFXRExtnNameTreeChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgFXRExtnNameTree =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN OPT PKG F X R EXTN NAME TREE " ,
    "ConnOptPkgFXRExtnName" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1012 ,
    sizeof(MgMgcpName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefConnOptPkgFXRExtnNameTreeChc ,
    mgMsgRegExpConnOptPkgFXRExtnName
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgFXRConnOptNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefConnOptPkgFXRExtnNameTree
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgFXRConnOptNameSeq =
{
    3 ,
    mgMsgDefPkgFXRConnOptNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgFXRConnOptName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG F X R CONN OPT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1013 ,
    sizeof(MgPkgName) + sizeof(MgMgcpName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgFXRConnOptNameSeq ,
    NULLP
};

#endif



#ifdef GCP_2705BIS

PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnParPkgExtnNamePkgFXRCPNameNumFaxPgsSentEnum =
{
    (Data *)"PGS" ,
    MGT_MGCP_CP_PKG_PKG_F_X_R_NUM_FAX_PGS_SENT
};

PUBLIC CmAbnfElmDef  mgMsgDefConnParPkgExtnNamePkgFXRCPNameNumFaxPgsSentEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN PAR PKG EXTN NAME PKG F X R C P NAME NUM FAX PGS SENT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1014 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnParPkgExtnNamePkgFXRCPNameNumFaxPgsSentEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnParPkgExtnNamePkgFXRCPNameNumFaxPgsRcvdEnum =
{
    (Data *)"PGR" ,
    MGT_MGCP_CP_PKG_PKG_F_X_R_NUM_FAX_PGS_RCVD
};

PUBLIC CmAbnfElmDef  mgMsgDefConnParPkgExtnNamePkgFXRCPNameNumFaxPgsRcvdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN PAR PKG EXTN NAME PKG F X R C P NAME NUM FAX PGS RCVD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1015 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnParPkgExtnNamePkgFXRCPNameNumFaxPgsRcvdEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefConnParPkgExtnNamePkgFXRCPNameChcEnum[] =
{
NULLP ,
&mgMsgDefConnParPkgExtnNamePkgFXRCPNameNumFaxPgsSentEnumDef ,
&mgMsgDefConnParPkgExtnNamePkgFXRCPNameNumFaxPgsRcvdEnumDef ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefConnParPkgExtnNamePkgFXRCPNameChcElmnt[] =
{
    &mgMsgDefConnParCPName ,
    NULLP ,
    NULLP ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefConnParPkgExtnNamePkgFXRCPNameChc =
{
    3 ,
    0 ,
    NULLP ,
    mgMsgDefConnParPkgExtnNamePkgFXRCPNameChcElmnt ,
    mgMsgDefConnParPkgExtnNamePkgFXRCPNameChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefConnParPkgExtnNamePkgFXRCPName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN PAR PKG EXTN NAME PKG F X R C P NAME " ,
    "CPPkgFXRCPNames" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1016 ,
    sizeof(MgPkgCPName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefConnParPkgExtnNamePkgFXRCPNameChc ,
    mgMsgRegExpCPPkgFXRCPNames
};

PUBLIC CmAbnfElmDef  *mgMsgDefConnParPkgExtnNamePkgFXRSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefConnParPkgExtnNamePkgFXRCPName
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefConnParPkgExtnNamePkgFXRSeq =
{
    3 ,
    mgMsgDefConnParPkgExtnNamePkgFXRSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefConnParPkgExtnNamePkgFXR =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN PAR PKG EXTN NAME PKG F X R " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1017 ,
    sizeof(MgPkgCPXNm) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefConnParPkgExtnNamePkgFXRSeq ,
    NULLP
};

#endif   /* GCP_2705BIS */

#endif   /* GCP_PKG_MGCP_FAX */




#ifdef  GCP_PKG_MGCP_ISUP_TRUNK

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgITRqEvSymContinuityTone1Enum =
{
    (Data *)"Co1" ,
    MGT_MGCP_PKG_I_T_RQ_EV_SYM_CONTINUITY_TONE1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITRqEvSymContinuityTone1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG I T RQ EV SYM CONTINUITY TONE1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  999 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgITRqEvSymContinuityTone1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgITRqEvSymContinuityTone2Enum =
{
    (Data *)"co2" ,
    MGT_MGCP_PKG_I_T_RQ_EV_SYM_CONTINUITY_TONE2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITRqEvSymContinuityTone2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG I T RQ EV SYM CONTINUITY TONE2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1000 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgITRqEvSymContinuityTone2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgITRqEvSymFaxToneEnum =
{
    (Data *)"Ft" ,
    MGT_MGCP_PKG_I_T_RQ_EV_SYM_FAX_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITRqEvSymFaxToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG I T RQ EV SYM FAX TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1001 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgITRqEvSymFaxToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgITRqEvSymLongDurConnEnum =
{
    (Data *)"ld" ,
    MGT_MGCP_PKG_I_T_RQ_EV_SYM_LONG_DUR_CONN
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITRqEvSymLongDurConnEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG I T RQ EV SYM LONG DUR CONN ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1002 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgITRqEvSymLongDurConnEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgITRqEvSymMediaStartEnum =
{
    (Data *)"Ma" ,
    MGT_MGCP_PKG_I_T_RQ_EV_SYM_MEDIA_START
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITRqEvSymMediaStartEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG I T RQ EV SYM MEDIA START ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1003 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgITRqEvSymMediaStartEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgITRqEvSymModemToneEnum =
{
    (Data *)"Mt" ,
    MGT_MGCP_PKG_I_T_RQ_EV_SYM_MODEM_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITRqEvSymModemToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG I T RQ EV SYM MODEM TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1004 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgITRqEvSymModemToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgITRqEvSymOperCompltEnum =
{
    (Data *)"Oc" ,
    MGT_MGCP_PKG_I_T_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG I T RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1005 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgITRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgITRqEvSymOperFailEnum =
{
    (Data *)"Of" ,
    MGT_MGCP_PKG_I_T_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG I T RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1006 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgITRqEvSymOperFailEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgITRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgITRqEvSymContinuityTone1EnumDef ,
&mgMsgDefPkgITRqEvSymContinuityTone2EnumDef ,
&mgMsgDefPkgITRqEvSymFaxToneEnumDef ,
&mgMsgDefPkgITRqEvSymLongDurConnEnumDef ,
&mgMsgDefPkgITRqEvSymMediaStartEnumDef ,
&mgMsgDefPkgITRqEvSymModemToneEnumDef ,
&mgMsgDefPkgITRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgITRqEvSymOperFailEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgITRqEvEvntKnownChc =
{
    8 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgITRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG I T RQ EV EVNT KNOWN " ,
    "PkgITRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1007 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgITRqEvEvntKnownChc ,
    mgMsgRegExpPkgITRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgITRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgITRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgITRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgITRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgITRqEvEvntDescChcElmnt ,
    mgMsgDefPkgITRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG I T RQ EV EVNT DESC " ,
    "PkgITRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1014 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgITRqEvEvntDescChc ,
    mgMsgRegExpPkgITRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgITRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgITRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgITRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgITRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG I T RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1015 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgITRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgITSgRqSymContinuityTone1Enum =
{
    (Data *)"Co1" ,
    MGT_MGCP_PKG_I_T_SG_RQ_SYM_CONTINUITY_TONE1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITSgRqSymContinuityTone1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG I T SG RQ SYM CONTINUITY TONE1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1016 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgITSgRqSymContinuityTone1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgITSgRqSymContinuityTone2Enum =
{
    (Data *)"co2" ,
    MGT_MGCP_PKG_I_T_SG_RQ_SYM_CONTINUITY_TONE2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITSgRqSymContinuityTone2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG I T SG RQ SYM CONTINUITY TONE2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1017 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgITSgRqSymContinuityTone2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgITSgRqSymReorderToneEnum =
{
    (Data *)"Ro" ,
    MGT_MGCP_PKG_I_T_SG_RQ_SYM_REORDER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITSgRqSymReorderToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG I T SG RQ SYM REORDER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1018 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgITSgRqSymReorderToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgITSgRqSymRingbackToneEnum =
{
    (Data *)"Rt" ,
    MGT_MGCP_PKG_I_T_SG_RQ_SYM_RINGBACK_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITSgRqSymRingbackToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG I T SG RQ SYM RINGBACK TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1019 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgITSgRqSymRingbackToneEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgITSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgITSgRqSymContinuityTone1EnumDef ,
&mgMsgDefPkgITSgRqSymContinuityTone2EnumDef ,
&mgMsgDefPkgITSgRqSymReorderToneEnumDef ,
&mgMsgDefPkgITSgRqSymRingbackToneEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgITSgRqEvntKnownChc =
{
    4 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgITSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG I T SG RQ EVNT KNOWN " ,
    "PkgITSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1020 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgITSgRqEvntKnownChc ,
    mgMsgRegExpPkgITSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgITSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgITSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgITSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgITSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgITSgRqEvntDescChcElmnt ,
    mgMsgDefPkgITSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG I T SG RQ EVNT DESC " ,
    "PkgITSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1027 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgITSgRqEvntDescChc ,
    mgMsgRegExpPkgITSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgITSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgITSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgITSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgITSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgITSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG I T SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1028 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgITSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_ISUP_TRUNK */




#ifdef  GCP_PKG_MGCP_MF

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMf0Enum =
{
    (Data *)"0" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF0
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMf0EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF0 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  999 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMf0Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMf1Enum =
{
    (Data *)"1" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMf1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1000 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMf1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMf2Enum =
{
    (Data *)"2" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMf2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1001 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMf2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMf3Enum =
{
    (Data *)"3" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMf3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1002 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMf3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMf4Enum =
{
    (Data *)"4" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF4
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMf4EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF4 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1003 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMf4Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMf5Enum =
{
    (Data *)"5" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF5
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMf5EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF5 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1004 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMf5Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMf6Enum =
{
    (Data *)"6" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF6
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMf6EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF6 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1005 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMf6Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMf7Enum =
{
    (Data *)"7" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF7
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMf7EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF7 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1006 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMf7Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMf8Enum =
{
    (Data *)"8" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF8
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMf8EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF8 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1007 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMf8Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMf9Enum =
{
    (Data *)"9" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF9
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMf9EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF9 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1008 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMf9Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymWildCardMatchEnum =
{
    (Data *)"X" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_WILD_CARD_MATCH
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymWildCardMatchEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM WILD CARD MATCH ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1009 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymWildCardMatchEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymInterdigTmrEnum =
{
    (Data *)"T" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_INTERDIG_TMR
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymInterdigTmrEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM INTERDIG TMR ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1010 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymInterdigTmrEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMfK0OrKpEnum =
{
    (Data *)"K0" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K0_OR_KP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMfK0OrKpEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF K0 OR KP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1011 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMfK0OrKpEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMfK1Enum =
{
    (Data *)"K1" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMfK1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF K1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1012 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMfK1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMfK2Enum =
{
    (Data *)"K2" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMfK2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF K2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1013 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMfK2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMfS0OrStEnum =
{
    (Data *)"S0" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S0_OR_ST
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMfS0OrStEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF S0 OR ST ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1014 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMfS0OrStEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMfS1Enum =
{
    (Data *)"S1" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMfS1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF S1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1015 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMfS1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMfS2Enum =
{
    (Data *)"S2" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMfS2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF S2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1016 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMfS2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymMfS3Enum =
{
    (Data *)"S3" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymMfS3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM MF S3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1017 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymMfS3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymWinkEnum =
{
    (Data *)"wk" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_WINK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymWinkEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM WINK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1018 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymWinkEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymWinkOffEnum =
{
    (Data *)"wko" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_WINK_OFF
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymWinkOffEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM WINK OFF ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1019 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymWinkOffEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymIncomingSeizureEnum =
{
    (Data *)"is" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_INCOMING_SEIZURE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymIncomingSeizureEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM INCOMING SEIZURE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1020 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymIncomingSeizureEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymRetSeizureEnum =
{
    (Data *)"rs" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_RET_SEIZURE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymRetSeizureEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM RET SEIZURE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1021 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymRetSeizureEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymUnseizeCktEnum =
{
    (Data *)"us" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_UNSEIZE_CKT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymUnseizeCktEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM UNSEIZE CKT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1022 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymUnseizeCktEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMRqEvSymRptFailureEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_M_RQ_EV_SYM_RPT_FAILURE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvSymRptFailureEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M RQ EV SYM RPT FAILURE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1023 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvSymRptFailureEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgMRqEvSymMf0EnumDef ,
&mgMsgDefPkgMRqEvSymMf1EnumDef ,
&mgMsgDefPkgMRqEvSymMf2EnumDef ,
&mgMsgDefPkgMRqEvSymMf3EnumDef ,
&mgMsgDefPkgMRqEvSymMf4EnumDef ,
&mgMsgDefPkgMRqEvSymMf5EnumDef ,
&mgMsgDefPkgMRqEvSymMf6EnumDef ,
&mgMsgDefPkgMRqEvSymMf7EnumDef ,
&mgMsgDefPkgMRqEvSymMf8EnumDef ,
&mgMsgDefPkgMRqEvSymMf9EnumDef ,
&mgMsgDefPkgMRqEvSymWildCardMatchEnumDef ,
&mgMsgDefPkgMRqEvSymInterdigTmrEnumDef ,
&mgMsgDefPkgMRqEvSymMfK0OrKpEnumDef ,
&mgMsgDefPkgMRqEvSymMfK1EnumDef ,
&mgMsgDefPkgMRqEvSymMfK2EnumDef ,
&mgMsgDefPkgMRqEvSymMfS0OrStEnumDef ,
&mgMsgDefPkgMRqEvSymMfS1EnumDef ,
&mgMsgDefPkgMRqEvSymMfS2EnumDef ,
&mgMsgDefPkgMRqEvSymMfS3EnumDef ,
&mgMsgDefPkgMRqEvSymWinkEnumDef ,
&mgMsgDefPkgMRqEvSymWinkOffEnumDef ,
&mgMsgDefPkgMRqEvSymIncomingSeizureEnumDef ,
&mgMsgDefPkgMRqEvSymRetSeizureEnumDef ,
&mgMsgDefPkgMRqEvSymUnseizeCktEnumDef ,
&mgMsgDefPkgMRqEvSymRptFailureEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgMRqEvEvntKnownChc =
{
    25 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgMRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M RQ EV EVNT KNOWN " ,
    "PkgMRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1024 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgMRqEvEvntKnownChc ,
    mgMsgRegExpPkgMRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgMRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgMRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgMRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgMRqEvEvntDescChcElmnt ,
    mgMsgDefPkgMRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M RQ EV EVNT DESC " ,
    "PkgMRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1031 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgMRqEvEvntDescChc ,
    mgMsgRegExpPkgMRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgMRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgMRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgMRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1032 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgMRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMf0Enum =
{
    (Data *)"0" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF0
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMf0EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF0 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1033 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMf0Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMf1Enum =
{
    (Data *)"1" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMf1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1034 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMf1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMf2Enum =
{
    (Data *)"2" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMf2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1035 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMf2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMf3Enum =
{
    (Data *)"3" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMf3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1036 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMf3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMf4Enum =
{
    (Data *)"4" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF4
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMf4EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF4 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1037 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMf4Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMf5Enum =
{
    (Data *)"5" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF5
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMf5EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF5 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1038 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMf5Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMf6Enum =
{
    (Data *)"6" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF6
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMf6EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF6 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1039 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMf6Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMf7Enum =
{
    (Data *)"7" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF7
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMf7EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF7 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1040 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMf7Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMf8Enum =
{
    (Data *)"8" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF8
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMf8EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF8 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1041 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMf8Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMf9Enum =
{
    (Data *)"9" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF9
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMf9EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF9 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1042 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMf9Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymInterdigTmrEnum =
{
    (Data *)"T" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_INTERDIG_TMR
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymInterdigTmrEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM INTERDIG TMR ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1043 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymInterdigTmrEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMfK0OrKpEnum =
{
    (Data *)"K0" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K0_OR_KP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMfK0OrKpEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF K0 OR KP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1044 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMfK0OrKpEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMfK1Enum =
{
    (Data *)"K1" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMfK1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF K1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1045 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMfK1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMfK2Enum =
{
    (Data *)"K2" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMfK2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF K2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1046 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMfK2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMfS0OrStEnum =
{
    (Data *)"S0" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S0_OR_ST
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMfS0OrStEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF S0 OR ST ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1047 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMfS0OrStEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMfS1Enum =
{
    (Data *)"S1" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMfS1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF S1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1048 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMfS1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMfS2Enum =
{
    (Data *)"S2" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMfS2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF S2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1049 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMfS2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymMfS3Enum =
{
    (Data *)"S3" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymMfS3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM MF S3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1050 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymMfS3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymWinkEnum =
{
    (Data *)"wk" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_WINK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymWinkEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM WINK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1051 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymWinkEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymWinkOffEnum =
{
    (Data *)"wko" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_WINK_OFF
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymWinkOffEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM WINK OFF ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1052 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymWinkOffEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymIncomingSeizureEnum =
{
    (Data *)"is" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_INCOMING_SEIZURE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymIncomingSeizureEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM INCOMING SEIZURE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1053 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymIncomingSeizureEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymRetSeizureEnum =
{
    (Data *)"rs" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_RET_SEIZURE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymRetSeizureEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM RET SEIZURE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1054 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymRetSeizureEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMSgRqSymUnseizeCktEnum =
{
    (Data *)"us" ,
    MGT_MGCP_PKG_M_SG_RQ_SYM_UNSEIZE_CKT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqSymUnseizeCktEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M SG RQ SYM UNSEIZE CKT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1055 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqSymUnseizeCktEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgMSgRqSymMf0EnumDef ,
&mgMsgDefPkgMSgRqSymMf1EnumDef ,
&mgMsgDefPkgMSgRqSymMf2EnumDef ,
&mgMsgDefPkgMSgRqSymMf3EnumDef ,
&mgMsgDefPkgMSgRqSymMf4EnumDef ,
&mgMsgDefPkgMSgRqSymMf5EnumDef ,
&mgMsgDefPkgMSgRqSymMf6EnumDef ,
&mgMsgDefPkgMSgRqSymMf7EnumDef ,
&mgMsgDefPkgMSgRqSymMf8EnumDef ,
&mgMsgDefPkgMSgRqSymMf9EnumDef ,
&mgMsgDefPkgMSgRqSymInterdigTmrEnumDef ,
&mgMsgDefPkgMSgRqSymMfK0OrKpEnumDef ,
&mgMsgDefPkgMSgRqSymMfK1EnumDef ,
&mgMsgDefPkgMSgRqSymMfK2EnumDef ,
&mgMsgDefPkgMSgRqSymMfS0OrStEnumDef ,
&mgMsgDefPkgMSgRqSymMfS1EnumDef ,
&mgMsgDefPkgMSgRqSymMfS2EnumDef ,
&mgMsgDefPkgMSgRqSymMfS3EnumDef ,
&mgMsgDefPkgMSgRqSymWinkEnumDef ,
&mgMsgDefPkgMSgRqSymWinkOffEnumDef ,
&mgMsgDefPkgMSgRqSymIncomingSeizureEnumDef ,
&mgMsgDefPkgMSgRqSymRetSeizureEnumDef ,
&mgMsgDefPkgMSgRqSymUnseizeCktEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgMSgRqEvntKnownChc =
{
    23 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgMSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M SG RQ EVNT KNOWN " ,
    "PkgMSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1056 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgMSgRqEvntKnownChc ,
    mgMsgRegExpPkgMSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgMSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgMSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgMSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgMSgRqEvntDescChcElmnt ,
    mgMsgDefPkgMSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M SG RQ EVNT DESC " ,
    "PkgMSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1063 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgMSgRqEvntDescChc ,
    mgMsgRegExpPkgMSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgMSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgMSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgMSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1064 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgMSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_MF */




#ifdef  GCP_PKG_MGCP_MF_TERM_PROTO

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTRqEvSymInfoDgtsEnum =
{
    (Data *)"Inf" ,
    MGT_MGCP_PKG_M_T_RQ_EV_SYM_INFO_DGTS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTRqEvSymInfoDgtsEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T RQ EV SYM INFO DGTS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  999 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTRqEvSymInfoDgtsEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTRqEvSymOperCompltEnum =
{
    (Data *)"Oc" ,
    MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTRqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1000 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTRqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTRqEvSymOperFailEnum =
{
    (Data *)"Of" ,
    MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTRqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1001 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTRqEvSymOperFailEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTRqEvSymOperIntrptEnum =
{
    (Data *)"Oi" ,
    MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_INTRPT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTRqEvSymOperIntrptEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T RQ EV SYM OPER INTRPT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1002 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTRqEvSymOperIntrptEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTRqEvSymReleaseCallEnum =
{
    (Data *)"Rel" ,
    MGT_MGCP_PKG_M_T_RQ_EV_SYM_RELEASE_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTRqEvSymReleaseCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T RQ EV SYM RELEASE CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1003 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTRqEvSymReleaseCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTRqEvSymReleaseCompleteEnum =
{
    (Data *)"Rlc" ,
    MGT_MGCP_PKG_M_T_RQ_EV_SYM_RELEASE_COMPLETE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTRqEvSymReleaseCompleteEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T RQ EV SYM RELEASE COMPLETE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1004 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTRqEvSymReleaseCompleteEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTRqEvSymCallSetupEnum =
{
    (Data *)"Sup" ,
    MGT_MGCP_PKG_M_T_RQ_EV_SYM_CALL_SETUP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTRqEvSymCallSetupEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T RQ EV SYM CALL SETUP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1005 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTRqEvSymCallSetupEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMTRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgMTRqEvSymInfoDgtsEnumDef ,
&mgMsgDefPkgMTRqEvSymOperCompltEnumDef ,
&mgMsgDefPkgMTRqEvSymOperFailEnumDef ,
&mgMsgDefPkgMTRqEvSymOperIntrptEnumDef ,
&mgMsgDefPkgMTRqEvSymReleaseCallEnumDef ,
&mgMsgDefPkgMTRqEvSymReleaseCompleteEnumDef ,
&mgMsgDefPkgMTRqEvSymCallSetupEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgMTRqEvEvntKnownChc =
{
    7 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgMTRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M T RQ EV EVNT KNOWN " ,
    "PkgMTRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1006 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgMTRqEvEvntKnownChc ,
    mgMsgRegExpPkgMTRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgMTRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMTRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgMTRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgMTRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgMTRqEvEvntDescChcElmnt ,
    mgMsgDefPkgMTRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M T RQ EV EVNT DESC " ,
    "PkgMTRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1013 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgMTRqEvEvntDescChc ,
    mgMsgRegExpPkgMTRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMTRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgMTRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgMTRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgMTRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M T RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1014 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgMTRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTSgRqSymCallAnswerEnum =
{
    (Data *)"Ans" ,
    MGT_MGCP_PKG_M_T_SG_RQ_SYM_CALL_ANSWER
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTSgRqSymCallAnswerEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T SG RQ SYM CALL ANSWER ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1015 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTSgRqSymCallAnswerEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTSgRqSymBusyToneEnum =
{
    (Data *)"Bz" ,
    MGT_MGCP_PKG_M_T_SG_RQ_SYM_BUSY_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTSgRqSymBusyToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T SG RQ SYM BUSY TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1016 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTSgRqSymBusyToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTSgRqSymHookFlashEnum =
{
    (Data *)"Hf" ,
    MGT_MGCP_PKG_M_T_SG_RQ_SYM_HOOK_FLASH
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTSgRqSymHookFlashEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T SG RQ SYM HOOK FLASH ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1017 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTSgRqSymHookFlashEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTSgRqSymPermSigToneEnum =
{
    (Data *)"Pst" ,
    MGT_MGCP_PKG_M_T_SG_RQ_SYM_PERM_SIG_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTSgRqSymPermSigToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T SG RQ SYM PERM SIG TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1018 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTSgRqSymPermSigToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTSgRqSymReleaseCallEnum =
{
    (Data *)"Rel" ,
    MGT_MGCP_PKG_M_T_SG_RQ_SYM_RELEASE_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTSgRqSymReleaseCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T SG RQ SYM RELEASE CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1019 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTSgRqSymReleaseCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTSgRqSymResumeCallEnum =
{
    (Data *)"Res" ,
    MGT_MGCP_PKG_M_T_SG_RQ_SYM_RESUME_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTSgRqSymResumeCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T SG RQ SYM RESUME CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1020 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTSgRqSymResumeCallEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTSgRqSymReleaseCompleteEnum =
{
    (Data *)"Rlc" ,
    MGT_MGCP_PKG_M_T_SG_RQ_SYM_RELEASE_COMPLETE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTSgRqSymReleaseCompleteEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T SG RQ SYM RELEASE COMPLETE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1021 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTSgRqSymReleaseCompleteEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTSgRqSymReorderToneEnum =
{
    (Data *)"Ro" ,
    MGT_MGCP_PKG_M_T_SG_RQ_SYM_REORDER_TONE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTSgRqSymReorderToneEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T SG RQ SYM REORDER TONE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1022 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTSgRqSymReorderToneEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgMTSgRqSymSuspendCallEnum =
{
    (Data *)"Sus" ,
    MGT_MGCP_PKG_M_T_SG_RQ_SYM_SUSPEND_CALL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTSgRqSymSuspendCallEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG M T SG RQ SYM SUSPEND CALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1023 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgMTSgRqSymSuspendCallEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMTSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgMTSgRqSymCallAnswerEnumDef ,
&mgMsgDefPkgMTSgRqSymBusyToneEnumDef ,
&mgMsgDefPkgMTSgRqSymHookFlashEnumDef ,
&mgMsgDefPkgMTSgRqSymPermSigToneEnumDef ,
&mgMsgDefPkgMTSgRqSymReleaseCallEnumDef ,
&mgMsgDefPkgMTSgRqSymResumeCallEnumDef ,
&mgMsgDefPkgMTSgRqSymReleaseCompleteEnumDef ,
&mgMsgDefPkgMTSgRqSymReorderToneEnumDef ,
&mgMsgDefPkgMTSgRqSymSuspendCallEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgMTSgRqEvntKnownChc =
{
    9 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgMTSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M T SG RQ EVNT KNOWN " ,
    "PkgMTSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1024 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgMTSgRqEvntKnownChc ,
    mgMsgRegExpPkgMTSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgMTSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMTSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgMTSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgMTSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgMTSgRqEvntDescChcElmnt ,
    mgMsgDefPkgMTSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M T SG RQ EVNT DESC " ,
    "PkgMTSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1031 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgMTSgRqEvntDescChc ,
    mgMsgRegExpPkgMTSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgMTSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgMTSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgMTSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgMTSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgMTSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG M T SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1032 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgMTSgRqEvntNameSeq ,
    NULLP
};

#endif  /* GCP_PKG_MGCP_MF_TERM_PROTO */




#ifdef  GCP_PKG_MGCP_NAS_DATAOUT

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgNAORqEvSymOutCallReqEnum =
{
    (Data *)"rq" ,
    MGT_MGCP_PKG_N_A_O_RQ_EV_SYM_OUT_CALL_REQ
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNAORqEvSymOutCallReqEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG N A O RQ EV SYM OUT CALL REQ ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  999 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgNAORqEvSymOutCallReqEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgNAORqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgNAORqEvSymOutCallReqEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgNAORqEvEvntKnownChc =
{
    1 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgNAORqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNAORqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG N A O RQ EV EVNT KNOWN " ,
    "PkgNAORqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1000 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgNAORqEvEvntKnownChc ,
    mgMsgRegExpPkgNAORqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgNAORqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgNAORqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgNAORqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgNAORqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgNAORqEvEvntDescChcElmnt ,
    mgMsgDefPkgNAORqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNAORqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG N A O RQ EV EVNT DESC " ,
    "PkgNAORqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1007 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgNAORqEvEvntDescChc ,
    mgMsgRegExpPkgNAORqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgNAORqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgNAORqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgNAORqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgNAORqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNAORqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG N A O RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1008 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgNAORqEvEvntNameSeq ,
    NULLP
};




#ifdef GCP_2705BIS

PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgNAOExtnNameDataUsrHndlEnum =
{
    (Data *)"duh" ,
    MGT_MGCP_CO_PKG_N_A_O_DATA_USR_HNDL
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgNAOExtnNameDataUsrHndlEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG N A O EXTN NAME DATA USR HNDL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1009 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgNAOExtnNameDataUsrHndlEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefConnOptPkgNAOExtnNameTreeChcEnum[] =
{
NULLP ,
&mgMsgDefConnOptPkgNAOExtnNameDataUsrHndlEnumDef ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefConnOptPkgNAOExtnNameTreeChcElmnt[] =
{
    &mgMsgDefConnOptPkgExtnName ,
    NULLP ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefConnOptPkgNAOExtnNameTreeChc =
{
    2 ,
    0 ,
    NULLP ,
    mgMsgDefConnOptPkgNAOExtnNameTreeChcElmnt ,
    mgMsgDefConnOptPkgNAOExtnNameTreeChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgNAOExtnNameTree =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN OPT PKG N A O EXTN NAME TREE " ,
    "ConnOptPkgNAOExtnName" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1010 ,
    sizeof(MgMgcpName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefConnOptPkgNAOExtnNameTreeChc ,
    mgMsgRegExpConnOptPkgNAOExtnName
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgNAOConnOptNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefConnOptPkgNAOExtnNameTree
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgNAOConnOptNameSeq =
{
    3 ,
    mgMsgDefPkgNAOConnOptNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNAOConnOptName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG N A O CONN OPT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1011 ,
    sizeof(MgPkgName) + sizeof(MgMgcpName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgNAOConnOptNameSeq ,
    NULLP
};

#endif  /* GCP_2705BIS */

#endif  /* GCP_PKG_MGCP_NAS_DATAOUT */




#ifdef  GCP_PKG_MGCP_BASIC_NAS

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgNASRqEvSymAuthSuccdEnum =
{
    (Data *)"au" ,
    MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_AUTH_SUCCD
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNASRqEvSymAuthSuccdEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG N A S RQ EV SYM AUTH SUCCD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  999 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgNASRqEvSymAuthSuccdEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgNASRqEvSymAuthDeniedEnum =
{
    (Data *)"ax" ,
    MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_AUTH_DENIED
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNASRqEvSymAuthDeniedEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG N A S RQ EV SYM AUTH DENIED ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1000 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgNASRqEvSymAuthDeniedEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgNASRqEvSymCallReqEnum =
{
    (Data *)"crq" ,
    MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_CALL_REQ
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNASRqEvSymCallReqEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG N A S RQ EV SYM CALL REQ ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1001 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgNASRqEvSymCallReqEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgNASRqEvSymNasFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_NAS_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNASRqEvSymNasFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG N A S RQ EV SYM NAS FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1002 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgNASRqEvSymNasFailEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgNASRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgNASRqEvSymAuthSuccdEnumDef ,
&mgMsgDefPkgNASRqEvSymAuthDeniedEnumDef ,
&mgMsgDefPkgNASRqEvSymCallReqEnumDef ,
&mgMsgDefPkgNASRqEvSymNasFailEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgNASRqEvEvntKnownChc =
{
    4 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgNASRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNASRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG N A S RQ EV EVNT KNOWN " ,
    "PkgNASRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1003 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgNASRqEvEvntKnownChc ,
    mgMsgRegExpPkgNASRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgNASRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgNASRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgNASRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgNASRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgNASRqEvEvntDescChcElmnt ,
    mgMsgDefPkgNASRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNASRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG N A S RQ EV EVNT DESC " ,
    "PkgNASRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1010 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgNASRqEvEvntDescChc ,
    mgMsgRegExpPkgNASRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgNASRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgNASRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgNASRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgNASRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNASRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG N A S RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1011 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgNASRqEvEvntNameSeq ,
    NULLP
};





#ifdef GCP_2705BIS

PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgNASExtnNameCalldPartyNumEnum =
{
    (Data *)"cdn" ,
    MGT_MGCP_CO_PKG_N_A_S_CALLD_PARTY_NUM
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgNASExtnNameCalldPartyNumEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG N A S EXTN NAME CALLD PARTY NUM ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1012 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgNASExtnNameCalldPartyNumEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgNASExtnNameCallngPartyNumEnum =
{
    (Data *)"cgn" ,
    MGT_MGCP_CO_PKG_N_A_S_CALLNG_PARTY_NUM
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgNASExtnNameCallngPartyNumEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG N A S EXTN NAME CALLNG PARTY NUM ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1013 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgNASExtnNameCallngPartyNumEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnOptPkgNASExtnNameBrrTypeEnum =
{
    (Data *)"bt" ,
    MGT_MGCP_CO_PKG_N_A_S_BRR_TYPE
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgNASExtnNameBrrTypeEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN OPT PKG N A S EXTN NAME BRR TYPE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1014 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnOptPkgNASExtnNameBrrTypeEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefConnOptPkgNASExtnNameTreeChcEnum[] =
{
NULLP ,
&mgMsgDefConnOptPkgNASExtnNameCalldPartyNumEnumDef ,
&mgMsgDefConnOptPkgNASExtnNameCallngPartyNumEnumDef ,
&mgMsgDefConnOptPkgNASExtnNameBrrTypeEnumDef ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefConnOptPkgNASExtnNameTreeChcElmnt[] =
{
    &mgMsgDefConnOptPkgExtnName ,
    NULLP ,
    NULLP ,
    NULLP ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefConnOptPkgNASExtnNameTreeChc =
{
    4 ,
    0 ,
    NULLP ,
    mgMsgDefConnOptPkgNASExtnNameTreeChcElmnt ,
    mgMsgDefConnOptPkgNASExtnNameTreeChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefConnOptPkgNASExtnNameTree =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN OPT PKG N A S EXTN NAME TREE " ,
    "ConnOptPkgNASExtnName" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1015 ,
    sizeof(MgMgcpName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefConnOptPkgNASExtnNameTreeChc ,
    mgMsgRegExpConnOptPkgNASExtnName
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgNASConnOptNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefConnOptPkgNASExtnNameTree
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgNASConnOptNameSeq =
{
    3 ,
    mgMsgDefPkgNASConnOptNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgNASConnOptName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG N A S CONN OPT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1016 ,
    sizeof(MgPkgName) + sizeof(MgMgcpName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgNASConnOptNameSeq ,
    NULLP
};

#endif




#ifdef GCP_2705BIS

PUBLIC CmAbnfElmTypeEnum  mgMsgDefConnModExtnValPkgNASValDataEnum =
{
    (Data *)"data" ,
    MGT_MGCP_CM_PKG_N_A_S_VAL_DATA
};

PUBLIC CmAbnfElmDef  mgMsgDefConnModExtnValPkgNASValDataEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: CONN MOD EXTN VAL PKG N A S VAL DATA ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1017 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefConnModExtnValPkgNASValDataEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefConnModExtnValPkgNASTreeChcEnum[] =
{
NULLP ,
&mgMsgDefConnModExtnValPkgNASValDataEnumDef ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefConnModExtnValPkgNASTreeChcElmnt[] =
{
    &mgMsgDefConnModExtnVal ,
    NULLP ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefConnModExtnValPkgNASTreeChc =
{
    2 ,
    0 ,
    NULLP ,
    mgMsgDefConnModExtnValPkgNASTreeChcElmnt ,
    mgMsgDefConnModExtnValPkgNASTreeChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefConnModExtnValPkgNASTree =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN MOD EXTN VAL PKG N A S TREE " ,
    "ConnModValsPkgNAS" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1018 ,
    sizeof(MgConnModVal) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefConnModExtnValPkgNASTreeChc ,
    mgMsgRegExpConnModValsPkgNAS
};

PUBLIC CmAbnfElmDef  *mgMsgDefConnModeExtnPkgNASSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefConnModExtnValPkgNASTree
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefConnModeExtnPkgNASSeq =
{
    3 ,
    mgMsgDefConnModeExtnPkgNASSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefConnModeExtnPkgNAS =
{
#ifdef  CM_ABNF_DBG
    "MGCP: CONN MODE EXTN PKG N A S " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1019 ,
    sizeof(MgConnModeX) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefConnModeExtnPkgNASSeq ,
    NULLP
};

#endif  /* GCP_2705BIS */

#endif  /* GCP_PKG_MGCP_BASIC_NAS */




#ifdef  GCP_PKG_MGCP_ADSI

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgSSgRqSymAdsiDisplayEnum =
{
    (Data *)"adsi" ,
    MGT_MGCP_PKG_S_SG_RQ_SYM_ADSI_DISPLAY
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSgRqSymAdsiDisplayEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG S SG RQ SYM ADSI DISPLAY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  999 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgSSgRqSymAdsiDisplayEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgSSgRqSymAdsiDisplayEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgSSgRqEvntKnownChc =
{
    1 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgSSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S SG RQ EVNT KNOWN " ,
    "PkgSSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1000 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgSSgRqEvntKnownChc ,
    mgMsgRegExpPkgSSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgSSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgSSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgSSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgSSgRqEvntDescChcElmnt ,
    mgMsgDefPkgSSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S SG RQ EVNT DESC " ,
    "PkgSSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1007 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgSSgRqEvntDescChc ,
    mgMsgRegExpPkgSSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgSSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgSSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgSSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgSSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgSSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG S SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1008 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgSSgRqEvntNameSeq ,
    NULLP
};

#endif /* GCP_PKG_MGCP_ADSI */

/* addition of new packages -
   Audio server packages - BAU & AAU
 */

#ifdef GCP_PKG_MGCP_AU_SRVR

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBAURqEvSymOperCompltEnum =
{
    (Data *)"oc" ,
    MGT_MGCP_PKG_B_A_U_RQ_EV_SYM_OPER_COMPLT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBAURqEvSymOperCompltEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B A U RQ EV SYM OPER COMPLT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  999 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBAURqEvSymOperCompltEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBAURqEvSymOperFailEnum =
{
    (Data *)"of" ,
    MGT_MGCP_PKG_B_A_U_RQ_EV_SYM_OPER_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBAURqEvSymOperFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B A U RQ EV SYM OPER FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1000 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBAURqEvSymOperFailEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBAURqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgBAURqEvSymOperCompltEnumDef ,
&mgMsgDefPkgBAURqEvSymOperFailEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgBAURqEvEvntKnownChc =
{
    2 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgBAURqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBAURqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B A U RQ EV EVNT KNOWN " ,
    "PkgBAURqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1001 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgBAURqEvEvntKnownChc ,
    mgMsgRegExpPkgBAURqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgBAURqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBAURqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgBAURqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgBAURqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgBAURqEvEvntDescChcElmnt ,
    mgMsgDefPkgBAURqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBAURqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B A U RQ EV EVNT DESC " ,
    "PkgBAURqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1008 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgBAURqEvEvntDescChc ,
    mgMsgRegExpPkgBAURqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBAURqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgBAURqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgBAURqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgBAURqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBAURqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B A U RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1009 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgBAURqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBAUSgRqSymMngAudioEnum =
{
    (Data *)"ma" ,
    MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_MNG_AUDIO
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBAUSgRqSymMngAudioEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B A U SG RQ SYM MNG AUDIO ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1010 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBAUSgRqSymMngAudioEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBAUSgRqSymPlayAnncEnum =
{
    (Data *)"pa" ,
    MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_ANNC
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBAUSgRqSymPlayAnncEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B A U SG RQ SYM PLAY ANNC ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1011 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBAUSgRqSymPlayAnncEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBAUSgRqSymPlayCollectEnum =
{
    (Data *)"pc" ,
    MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_COLLECT
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBAUSgRqSymPlayCollectEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B A U SG RQ SYM PLAY COLLECT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1012 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBAUSgRqSymPlayCollectEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBAUSgRqSymPlayRecordEnum =
{
    (Data *)"pr" ,
    MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_RECORD
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBAUSgRqSymPlayRecordEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B A U SG RQ SYM PLAY RECORD ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1013 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBAUSgRqSymPlayRecordEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBAUSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgBAUSgRqSymMngAudioEnumDef ,
&mgMsgDefPkgBAUSgRqSymPlayAnncEnumDef ,
&mgMsgDefPkgBAUSgRqSymPlayCollectEnumDef ,
&mgMsgDefPkgBAUSgRqSymPlayRecordEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgBAUSgRqEvntKnownChc =
{
    4 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgBAUSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBAUSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B A U SG RQ EVNT KNOWN " ,
    "PkgBAUSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1014 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgBAUSgRqEvntKnownChc ,
    mgMsgRegExpPkgBAUSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgBAUSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBAUSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgBAUSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgBAUSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgBAUSgRqEvntDescChcElmnt ,
    mgMsgDefPkgBAUSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBAUSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B A U SG RQ EVNT DESC " ,
    "PkgBAUSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1021 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgBAUSgRqEvntDescChc ,
    mgMsgRegExpPkgBAUSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBAUSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgBAUSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgBAUSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgBAUSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBAUSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B A U SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1022 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgBAUSgRqEvntNameSeq ,
    NULLP
};

#endif /* GCP_PKG_MGCP_AU_SRVR */

/*
 * [TEL]: Adding for Display XML Package
 */
#ifdef GCP_PKG_MGCP_DISPLAY_XML

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgXMLRqEvSymXmlDataEnum =
{
    (Data *)"xml" ,
    MGT_MGCP_PKG_X_M_L_RQ_EV_SYM_XML_DATA
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgXMLRqEvSymXmlDataEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG X M L RQ EV SYM XML DATA ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  999 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgXMLRqEvSymXmlDataEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgXMLRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgXMLRqEvSymXmlDataEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgXMLRqEvEvntKnownChc =
{
    1 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgXMLRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgXMLRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG X M L RQ EV EVNT KNOWN " ,
    "PkgXMLRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1000 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgXMLRqEvEvntKnownChc ,
    mgMsgRegExpPkgXMLRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgXMLRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgXMLRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgXMLRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgXMLRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgXMLRqEvEvntDescChcElmnt ,
    mgMsgDefPkgXMLRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgXMLRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG X M L RQ EV EVNT DESC " ,
    "PkgXMLRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1007 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgXMLRqEvEvntDescChc ,
    mgMsgRegExpPkgXMLRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgXMLRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgXMLRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgXMLRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgXMLRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgXMLRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG X M L RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1008 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgXMLRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgXMLSgRqSymXmlDataEnum =
{
    (Data *)"xml" ,
    MGT_MGCP_PKG_X_M_L_SG_RQ_SYM_XML_DATA
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgXMLSgRqSymXmlDataEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG X M L SG RQ SYM XML DATA ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1009 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgXMLSgRqSymXmlDataEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgXMLSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgXMLSgRqSymXmlDataEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgXMLSgRqEvntKnownChc =
{
    1 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgXMLSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgXMLSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG X M L SG RQ EVNT KNOWN " ,
    "PkgXMLSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1010 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgXMLSgRqEvntKnownChc ,
    mgMsgRegExpPkgXMLSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgXMLSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgXMLSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgXMLSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgXMLSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgXMLSgRqEvntDescChcElmnt ,
    mgMsgDefPkgXMLSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgXMLSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG X M L SG RQ EVNT DESC " ,
    "PkgXMLSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1017 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgXMLSgRqEvntDescChc ,
    mgMsgRegExpPkgXMLSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgXMLSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgXMLSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgXMLSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgXMLSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgXMLSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG X M L SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1018 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgXMLSgRqEvntNameSeq ,
    NULLP
};

#endif /* GCP_PKG_MGCP_DISPLAY_XML */

/*
 * [TEL]: Adding for Feature Key Package
 */
#ifdef GCP_PKG_MGCP_FEATURE_KEY

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey1Enum =
{
    (Data *)"fk1" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY1
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey1EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY1 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  999 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey1Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey2Enum =
{
    (Data *)"fk2" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY2
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey2EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY2 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1000 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey2Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey3Enum =
{
    (Data *)"fk3" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY3
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey3EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY3 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1001 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey3Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey4Enum =
{
    (Data *)"fk4" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY4
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey4EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY4 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1002 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey4Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey5Enum =
{
    (Data *)"fk5" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY5
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey5EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY5 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1003 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey5Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey6Enum =
{
    (Data *)"fk6" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY6
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey6EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY6 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1004 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey6Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey7Enum =
{
    (Data *)"fk7" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY7
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey7EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY7 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1005 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey7Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey8Enum =
{
    (Data *)"fk8" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY8
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey8EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY8 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1006 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey8Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey9Enum =
{
    (Data *)"fk9" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY9
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey9EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY9 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1007 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey9Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey10Enum =
{
    (Data *)"fk10" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY10
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey10EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY10 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1008 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey10Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey11Enum =
{
    (Data *)"fk11" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY11
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey11EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY11 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1009 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey11Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey12Enum =
{
    (Data *)"fk12" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY12
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey12EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY12 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1010 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey12Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey13Enum =
{
    (Data *)"fk13" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY13
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey13EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY13 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1011 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey13Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey14Enum =
{
    (Data *)"fk14" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY14
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey14EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY14 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1012 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey14Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey15Enum =
{
    (Data *)"fk15" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY15
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey15EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY15 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1013 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey15Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey16Enum =
{
    (Data *)"fk16" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY16
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey16EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY16 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1014 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey16Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey17Enum =
{
    (Data *)"fk17" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY17
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey17EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY17 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1015 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey17Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey18Enum =
{
    (Data *)"fk18" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY18
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey18EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY18 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1016 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey18Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey19Enum =
{
    (Data *)"fk19" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY19
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey19EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY19 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1017 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey19Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey20Enum =
{
    (Data *)"fk20" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY20
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey20EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY20 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1018 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey20Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey21Enum =
{
    (Data *)"fk21" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY21
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey21EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY21 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1019 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey21Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey22Enum =
{
    (Data *)"fk22" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY22
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey22EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY22 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1020 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey22Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey23Enum =
{
    (Data *)"fk23" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY23
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey23EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY23 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1021 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey23Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey24Enum =
{
    (Data *)"fk24" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY24
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey24EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY24 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1022 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey24Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey25Enum =
{
    (Data *)"fk25" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY25
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey25EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY25 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1023 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey25Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey26Enum =
{
    (Data *)"fk26" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY26
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey26EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY26 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1024 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey26Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey27Enum =
{
    (Data *)"fk27" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY27
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey27EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY27 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1025 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey27Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey28Enum =
{
    (Data *)"fk28" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY28
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey28EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY28 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1026 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey28Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey29Enum =
{
    (Data *)"fk29" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY29
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey29EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY29 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1027 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey29Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey30Enum =
{
    (Data *)"fk30" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY30
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey30EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY30 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1028 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey30Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey31Enum =
{
    (Data *)"fk31" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY31
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey31EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY31 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1029 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey31Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey32Enum =
{
    (Data *)"fk32" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY32
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey32EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY32 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1030 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey32Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey33Enum =
{
    (Data *)"fk33" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY33
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey33EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY33 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1031 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey33Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey34Enum =
{
    (Data *)"fk34" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY34
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey34EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY34 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1032 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey34Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey35Enum =
{
    (Data *)"fk35" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY35
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey35EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY35 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1033 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey35Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey36Enum =
{
    (Data *)"fk36" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY36
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey36EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY36 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1034 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey36Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey37Enum =
{
    (Data *)"fk37" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY37
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey37EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY37 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1035 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey37Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey38Enum =
{
    (Data *)"fk38" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY38
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey38EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY38 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1036 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey38Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey39Enum =
{
    (Data *)"fk39" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY39
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey39EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY39 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1037 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey39Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey40Enum =
{
    (Data *)"fk40" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY40
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey40EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY40 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1038 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey40Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey41Enum =
{
    (Data *)"fk41" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY41
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey41EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY41 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1039 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey41Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey42Enum =
{
    (Data *)"fk42" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY42
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey42EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY42 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1040 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey42Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey43Enum =
{
    (Data *)"fk43" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY43
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey43EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY43 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1041 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey43Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey44Enum =
{
    (Data *)"fk44" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY44
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey44EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY44 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1042 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey44Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey45Enum =
{
    (Data *)"fk45" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY45
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey45EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY45 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1043 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey45Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey46Enum =
{
    (Data *)"fk46" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY46
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey46EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY46 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1044 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey46Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey47Enum =
{
    (Data *)"fk47" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY47
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey47EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY47 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1045 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey47Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey48Enum =
{
    (Data *)"fk48" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY48
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey48EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY48 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1046 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey48Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey49Enum =
{
    (Data *)"fk49" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY49
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey49EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY49 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1047 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey49Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey50Enum =
{
    (Data *)"fk50" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY50
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey50EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY50 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1048 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey50Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey51Enum =
{
    (Data *)"fk51" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY51
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey51EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY51 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1049 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey51Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey52Enum =
{
    (Data *)"fk52" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY52
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey52EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY52 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1050 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey52Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey53Enum =
{
    (Data *)"fk53" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY53
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey53EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY53 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1051 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey53Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey54Enum =
{
    (Data *)"fk54" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY54
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey54EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY54 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1052 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey54Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey55Enum =
{
    (Data *)"fk55" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY55
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey55EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY55 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1053 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey55Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey56Enum =
{
    (Data *)"fk56" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY56
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey56EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY56 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1054 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey56Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey57Enum =
{
    (Data *)"fk57" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY57
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey57EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY57 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1055 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey57Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey58Enum =
{
    (Data *)"fk58" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY58
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey58EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY58 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1056 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey58Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey59Enum =
{
    (Data *)"fk59" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY59
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey59EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY59 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1057 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey59Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey60Enum =
{
    (Data *)"fk60" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY60
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey60EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY60 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1058 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey60Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey61Enum =
{
    (Data *)"fk61" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY61
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey61EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY61 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1059 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey61Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey62Enum =
{
    (Data *)"fk62" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY62
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey62EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY62 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1060 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey62Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey63Enum =
{
    (Data *)"fk63" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY63
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey63EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY63 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1061 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey63Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey64Enum =
{
    (Data *)"fk64" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY64
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey64EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY64 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1062 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey64Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey65Enum =
{
    (Data *)"fk65" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY65
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey65EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY65 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1063 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey65Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey66Enum =
{
    (Data *)"fk66" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY66
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey66EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY66 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1064 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey66Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey67Enum =
{
    (Data *)"fk67" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY67
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey67EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY67 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1065 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey67Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey68Enum =
{
    (Data *)"fk68" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY68
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey68EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY68 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1066 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey68Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey69Enum =
{
    (Data *)"fk69" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY69
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey69EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY69 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1067 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey69Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey70Enum =
{
    (Data *)"fk70" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY70
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey70EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY70 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1068 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey70Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey71Enum =
{
    (Data *)"fk71" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY71
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey71EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY71 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1069 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey71Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey72Enum =
{
    (Data *)"fk72" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY72
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey72EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY72 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1070 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey72Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey73Enum =
{
    (Data *)"fk73" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY73
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey73EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY73 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1071 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey73Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey74Enum =
{
    (Data *)"fk74" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY74
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey74EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY74 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1072 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey74Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey75Enum =
{
    (Data *)"fk75" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY75
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey75EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY75 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1073 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey75Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey76Enum =
{
    (Data *)"fk76" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY76
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey76EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY76 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1074 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey76Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey77Enum =
{
    (Data *)"fk77" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY77
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey77EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY77 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1075 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey77Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey78Enum =
{
    (Data *)"fk78" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY78
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey78EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY78 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1076 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey78Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey79Enum =
{
    (Data *)"fk79" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY79
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey79EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY79 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1077 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey79Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey80Enum =
{
    (Data *)"fk80" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY80
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey80EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY80 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1078 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey80Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey81Enum =
{
    (Data *)"fk81" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY81
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey81EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY81 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1079 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey81Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey82Enum =
{
    (Data *)"fk82" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY82
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey82EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY82 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1080 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey82Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey83Enum =
{
    (Data *)"fk83" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY83
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey83EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY83 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1081 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey83Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey84Enum =
{
    (Data *)"fk84" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY84
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey84EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY84 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1082 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey84Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey85Enum =
{
    (Data *)"fk85" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY85
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey85EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY85 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1083 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey85Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey86Enum =
{
    (Data *)"fk86" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY86
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey86EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY86 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1084 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey86Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey87Enum =
{
    (Data *)"fk87" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY87
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey87EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY87 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1085 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey87Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey88Enum =
{
    (Data *)"fk88" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY88
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey88EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY88 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1086 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey88Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey89Enum =
{
    (Data *)"fk89" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY89
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey89EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY89 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1087 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey89Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey90Enum =
{
    (Data *)"fk90" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY90
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey90EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY90 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1088 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey90Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey91Enum =
{
    (Data *)"fk91" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY91
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey91EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY91 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1089 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey91Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey92Enum =
{
    (Data *)"fk92" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY92
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey92EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY92 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1090 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey92Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey93Enum =
{
    (Data *)"fk93" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY93
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey93EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY93 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1091 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey93Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey94Enum =
{
    (Data *)"fk94" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY94
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey94EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY94 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1092 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey94Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey95Enum =
{
    (Data *)"fk95" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY95
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey95EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY95 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1093 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey95Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey96Enum =
{
    (Data *)"fk96" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY96
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey96EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY96 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1094 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey96Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey97Enum =
{
    (Data *)"fk97" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY97
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey97EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY97 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1095 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey97Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey98Enum =
{
    (Data *)"fk98" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY98
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey98EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY98 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1096 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey98Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYRqEvSymFeatureKey99Enum =
{
    (Data *)"fk99" ,
    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY99
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvSymFeatureKey99EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV SYM FEATURE KEY99 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1097 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvSymFeatureKey99Enum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgKYRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgKYRqEvSymFeatureKey1EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey2EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey3EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey4EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey5EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey6EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey7EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey8EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey9EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey10EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey11EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey12EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey13EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey14EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey15EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey16EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey17EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey18EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey19EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey20EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey21EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey22EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey23EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey24EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey25EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey26EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey27EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey28EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey29EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey30EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey31EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey32EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey33EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey34EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey35EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey36EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey37EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey38EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey39EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey40EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey41EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey42EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey43EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey44EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey45EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey46EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey47EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey48EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey49EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey50EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey51EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey52EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey53EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey54EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey55EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey56EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey57EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey58EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey59EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey60EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey61EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey62EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey63EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey64EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey65EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey66EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey67EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey68EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey69EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey70EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey71EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey72EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey73EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey74EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey75EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey76EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey77EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey78EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey79EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey80EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey81EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey82EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey83EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey84EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey85EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey86EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey87EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey88EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey89EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey90EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey91EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey92EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey93EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey94EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey95EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey96EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey97EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey98EnumDef ,
&mgMsgDefPkgKYRqEvSymFeatureKey99EnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgKYRqEvEvntKnownChc =
{
    99 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgKYRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV EVNT KNOWN " ,
    "PkgKYRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1098 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgKYRqEvEvntKnownChc ,
    mgMsgRegExpPkgKYRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgKYRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgKYRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgKYRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgKYRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgKYRqEvEvntDescChcElmnt ,
    mgMsgDefPkgKYRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV EVNT DESC " ,
    "PkgKYRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1105 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgKYRqEvEvntDescChc ,
    mgMsgRegExpPkgKYRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgKYRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgKYRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgKYRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgKYRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG K Y RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1106 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgKYRqEvEvntNameSeq ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYSgRqSymKeyStateEnum =
{
    (Data *)"ks" ,
    MGT_MGCP_PKG_K_Y_SG_RQ_SYM_KEY_STATE
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYSgRqSymKeyStateEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y SG RQ SYM KEY STATE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1107 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYSgRqSymKeyStateEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgKYSgRqSymSetLabelEnum =
{
    (Data *)"ls" ,
    MGT_MGCP_PKG_K_Y_SG_RQ_SYM_SET_LABEL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYSgRqSymSetLabelEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG K Y SG RQ SYM SET LABEL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1108 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgKYSgRqSymSetLabelEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgKYSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgKYSgRqSymKeyStateEnumDef ,
&mgMsgDefPkgKYSgRqSymSetLabelEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgKYSgRqEvntKnownChc =
{
    2 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgKYSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG K Y SG RQ EVNT KNOWN " ,
    "PkgKYSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1109 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgKYSgRqEvntKnownChc ,
    mgMsgRegExpPkgKYSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgKYSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgKYSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgKYSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgKYSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgKYSgRqEvntDescChcElmnt ,
    mgMsgDefPkgKYSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG K Y SG RQ EVNT DESC " ,
    "PkgKYSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1116 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgKYSgRqEvntDescChc ,
    mgMsgRegExpPkgKYSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgKYSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgKYSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgKYSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgKYSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgKYSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG K Y SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1117 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgKYSgRqEvntNameSeq ,
    NULLP
};

#endif /* GCP_PKG_MGCP_FEATURE_KEY */

/*
 * [TEL]: Adding for Business Phone Package
 */
#ifdef GCP_PKG_MGCP_BUS_PHONE

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBPSgRqSymFrcOffHkEnum =
{
    (Data *)"hd" ,
    MGT_MGCP_PKG_B_P_SG_RQ_SYM_FRC_OFF_HK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBPSgRqSymFrcOffHkEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B P SG RQ SYM FRC OFF HK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  999 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBPSgRqSymFrcOffHkEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBPSgRqSymFrcOnHkEnum =
{
    (Data *)"hu" ,
    MGT_MGCP_PKG_B_P_SG_RQ_SYM_FRC_ON_HK
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBPSgRqSymFrcOnHkEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B P SG RQ SYM FRC ON HK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1000 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBPSgRqSymFrcOnHkEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBPSgRqSymBeepEnum =
{
    (Data *)"beep" ,
    MGT_MGCP_PKG_B_P_SG_RQ_SYM_BEEP
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBPSgRqSymBeepEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B P SG RQ SYM BEEP ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1001 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBPSgRqSymBeepEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBPSgRqEvntKnownChcEnum[] =
{
&mgMsgDefPkgBPSgRqSymFrcOffHkEnumDef ,
&mgMsgDefPkgBPSgRqSymFrcOnHkEnumDef ,
&mgMsgDefPkgBPSgRqSymBeepEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgBPSgRqEvntKnownChc =
{
    3 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgBPSgRqEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBPSgRqEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B P SG RQ EVNT KNOWN " ,
    "PkgBPSgRqSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1002 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgBPSgRqEvntKnownChc ,
    mgMsgRegExpPkgBPSgRqSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgBPSgRqEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBPSgRqEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgBPSgRqEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgBPSgRqEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgBPSgRqEvntDescChcElmnt ,
    mgMsgDefPkgBPSgRqEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBPSgRqEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B P SG RQ EVNT DESC " ,
    "PkgBPSgRqSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1009 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgBPSgRqEvntDescChc ,
    mgMsgRegExpPkgBPSgRqSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBPSgRqEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgBPSgRqEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgBPSgRqEvntNameSeq =
{
    3 ,
    mgMsgDefPkgBPSgRqEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBPSgRqEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B P SG RQ EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1010 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgBPSgRqEvntNameSeq ,
    NULLP
};

#endif /* GCP_PKG_MGCP_BUS_PHONE */

/*
 * [TEL]: Adding for Base Package
 */
#ifdef GCP_2705BIS
#ifdef GCP_PKG_MGCP_BASE

PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBRqEvSymEmRqntFailEnum =
{
    (Data *)"enf" ,
    MGT_MGCP_PKG_B_RQ_EV_SYM_EM_RQNT_FAIL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBRqEvSymEmRqntFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B RQ EV SYM EM RQNT FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  999 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBRqEvSymEmRqntFailEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBRqEvSymObsEvtsFulEnum =
{
    (Data *)"oef" ,
    MGT_MGCP_PKG_B_RQ_EV_SYM_OBS_EVTS_FUL
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBRqEvSymObsEvtsFulEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B RQ EV SYM OBS EVTS FUL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1000 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBRqEvSymObsEvtsFulEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeU16Enum  mgMsgDefPkgBRqEvSymQrtinBufOfEnum =
{
    (Data *)"qbo" ,
    MGT_MGCP_PKG_B_RQ_EV_SYM_QRTIN_BUF_OF
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBRqEvSymQrtinBufOfEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B RQ EV SYM QRTIN BUF OF ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1001 ,
    sizeof (TknU16) ,
    0 ,
    CM_ABNF_TYPE_ENUM_U16 ,
    (U8 *) &mgMsgDefPkgBRqEvSymQrtinBufOfEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBRqEvEvntKnownChcEnum[] =
{
&mgMsgDefPkgBRqEvSymEmRqntFailEnumDef ,
&mgMsgDefPkgBRqEvSymObsEvtsFulEnumDef ,
&mgMsgDefPkgBRqEvSymQrtinBufOfEnumDef ,

};

PUBLIC CmAbnfElmTypeU16Choice  mgMsgDefPkgBRqEvEvntKnownChc =
{
    3 ,
    0 ,
    NULLP ,
    NULLP ,
    mgMsgDefPkgBRqEvEvntKnownChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBRqEvEvntKnown =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B RQ EV EVNT KNOWN " ,
    "PkgBRqEvSymVal" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1002 ,
    sizeof(TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE_U16 ,
    (U8 *) &mgMsgDefPkgBRqEvEvntKnownChc ,
    mgMsgRegExpPkgBRqEvSymVal
};




PUBLIC CmAbnfElmDef  *mgMsgDefPkgBRqEvEvntDescChcEnum[] =
{
NULLP ,
&mgMsgDefEvntEvntIdStr ,
&mgMsgDefEvntAllStr ,
&mgMsgDefEvntRangeStr ,
&mgMsgDefEvntKnownStr ,
&mgMsgDefEvntDtmfStarStr ,
&mgMsgDefEvntDtmfPoundStr ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBRqEvEvntDescChcElmnt[] =
{
    NULLP ,
    &mgMsgDefEvntEvntId ,
    &mgMsgDefEvntAll ,
    &mgMsgDefEvntRange ,
    &mgMsgDefPkgBRqEvEvntKnown ,
    &mgMsgDefEvntDtmf ,
    &mgMsgDefEvntDtmf ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgBRqEvEvntDescChc =
{
    7 ,
    0 ,
    NULLP ,
    mgMsgDefPkgBRqEvEvntDescChcElmnt ,
    mgMsgDefPkgBRqEvEvntDescChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBRqEvEvntDesc =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B RQ EV EVNT DESC " ,
    "PkgBRqEvSymType" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1009 ,
    sizeof(MgEventDesc) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgBRqEvEvntDescChc ,
    mgMsgRegExpPkgBRqEvSymType
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBRqEvEvntNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgBRqEvEvntDesc
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgBRqEvEvntNameSeq =
{
    3 ,
    mgMsgDefPkgBRqEvEvntNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBRqEvEvntName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B RQ EV EVNT NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1010 ,
    sizeof(MgPkgName) + sizeof(MgEventDesc) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgBRqEvEvntNameSeq ,
    NULLP
};






PUBLIC CmAbnfElmTypeEnum  mgMsgDefPkgBEpPstEvtsEnum =
{
    (Data *)"PR" ,
    MGT_MGCP_PKG_B_EP_PST_EVTS
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBEpPstEvtsEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B EP PST EVTS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1011 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefPkgBEpPstEvtsEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  mgMsgDefPkgBEpNotFnStEnum =
{
    (Data *)"NS" ,
    MGT_MGCP_PKG_B_EP_NOT_FN_ST
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBEpNotFnStEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: PKG B EP NOT FN ST ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE  +  1012 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &mgMsgDefPkgBEpNotFnStEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBExtnParamNameTreeChcEnum[] =
{
NULLP ,
&mgMsgDefPkgBEpPstEvtsEnumDef ,
&mgMsgDefPkgBEpNotFnStEnumDef ,

};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBExtnParamNameTreeChcElmnt[] =
{
    &mgMsgDefPkgExtnParamName ,
    NULLP ,
    NULLP ,
};

PUBLIC CmAbnfElmTypeChoice  mgMsgDefPkgBExtnParamNameTreeChc =
{
    3 ,
    0 ,
    NULLP ,
    mgMsgDefPkgBExtnParamNameTreeChcElmnt ,
    mgMsgDefPkgBExtnParamNameTreeChcEnum
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBExtnParamNameTree =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B EXTN PARAM NAME TREE " ,
    "ExtnParamPkgB" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1013 ,
    sizeof(MgMgcpName) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &mgMsgDefPkgBExtnParamNameTreeChc ,
    mgMsgRegExpExtnParamPkgB
};

PUBLIC CmAbnfElmDef  *mgMsgDefPkgBExtnParamExtnNameSeqElmnts[] =
{
    &mgMsgDefPkgNameString ,
    &cmMsgDefMetaSlash ,
    &mgMsgDefPkgBExtnParamNameTree
};

PUBLIC CmAbnfElmTypeSeq  mgMsgDefPkgBExtnParamExtnNameSeq =
{
    3 ,
    mgMsgDefPkgBExtnParamExtnNameSeqElmnts
};

PUBLIC CmAbnfElmDef  mgMsgDefPkgBExtnParamExtnName =
{
#ifdef  CM_ABNF_DBG
    "MGCP: PKG B EXTN PARAM EXTN NAME " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_MG_BASE + 1014 ,
    sizeof(MgMgcpPkgSpcExtnParam) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &mgMsgDefPkgBExtnParamExtnNameSeq ,
    NULLP
};

#endif /* GCP_PKG_MGCP_BASE */
#endif /*GCP_2705BIS */
/*
 * [TEL]: End of addition of new packages
 */

#endif  /* GCP_VER_1_3 */

#endif /* GCP_MGCP */




/********************************************************************30**

         End of file:     mgcp_pdb.c@@/main/mgcp_rel_1.5_mnt/2 - Wed Apr 27 15:07:34 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      ra   1. GCP 1.3 release
/main/1    mg003.103  ra   1. Addition of support for Packet Cable Audio
                              Server packges - BAU & AAU under compilation
                              flag GCP_PKG_MGCP_AU_SRVR.
/main/2      ---       TEL 1. Added package support database  
                              for the following MGCP packages.
                              1. Base package. 
                              2. Business phone package. 
                              3. Feature Key package. 
                              4. Display XML package. 
/main/2      ---      ka   1. Changes for Release v 1.4
/main/3      ---      pk   1. GCP 1.5 release
            mg002.105 ps   1. Removed patch reference for 1.3 and 1.4             
*********************************************************************91*/
