/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
 
     Name:     GCP - Co-ordinator Module
 
     Type:     C source file
  
     Desc:     C Source Code for Co-ordinator Module
 
     File:     mg_cord.c
  
     Sid:      mp_cord.c@@/main/mgcp_rel_1.5_mnt/13 - Tue Jun  7 13:04:51 2005
  
     Prg:      bbk
  
*********************************************************************21*/
 
/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*
*/
 
/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*    
*   
*
*/

 
/*
 * The core of MGC product is implemented in following files:
 *
 *    mg_dns.c      DNS Interaction functions 
 *    mg_tmr.c      Timer Management/Maintenance functions
 *    mg_tpt.c      Transport Layer Interaction functions
 *    mg_trans.c    Transaction Management functions
 *    mg_cord.c     Co-ordinator Module functions
 *    mg_ui.c       MGCP Upper Interface Functions
 *    mg_mi.c       MGCP Layer Management Interface
 *    mg_li.c       MGCP Lower Layer (TUCL) Interface
 *    cm_tenc.c     Common Text Based Encode Engine for MGCP messages
 *    cm_tdec.c     Common Text Based Decode Engine for MGCP messages
 */

/* header include files (.h) */
#include "envopt.h"        /* Environment options */  
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */

#ifdef MG

#include "gen.h"           /* General layer */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common Timer Library */
#include "cm_hash.h"       /* Hash library */
#include "cm_llist.h"      /* Doubly Linked List library */
#include "cm_inet.h"       /* Common Sockets Library */
#include "cm_tpt.h"        /* Common Transport Defines */
#include "cm_tkns.h"       /* Common Tokens Defines */
#include "cm_sdp.h"        /* Session Description Protocol Defines */
#include "cm_mblk.h"       /* Common Memory Manager Defines */
#include "cm_abnf.h"       /* Common ABNF  Defines */
#include "cm_dns.h"        /* common DNS library */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.h"      /* SS7 common Defines */
#include "snt.h"         /* MTP3 Interface Defines */
#endif   /* GCP_PROV_MTP3 */

#include "mgt.h"           /* MGT Interface Defines */
#include "lmg.h"           /* MGCP Layer Management */
#include "mg_err.h"        /* MGCP Error Codes */
#include "mg.h"            /* MGCP Defines */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer */
#include "ssi.x"           /* System services */
#include "cm5.x"           /* Common Timer Library */
#include "cm_hash.x"       /* Hash library */
#include "cm_llist.x"      /* Doubly Linked List library */
#include "cm_inet.x"       /* Common Sockets Library */
#include "cm_tpt.x"        /* Common Transport Definitions */
#include "cm_tkns.x"       /* Common Tokens Defines */
#include "cm_lib.x"        /* Common library functions */
#include "cm_sdp.x"        /* Session Description Protocol Defines */
#include "cm_mblk.x"       /* Common Memory Manager Defines */
#include "cm_abnf.x"       /* Common ABNF  Defines */
#include "cm_dns.x"        /* common dns library */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.x"      /* SS7 common structure */
#include "snt.x"         /* MTP3 Interface structure */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.x"           /* MGT Interface Structures */
#include "lmg.x"           /* MGCP Layer Management */
#include "mg.x"            /* MGCP Data Structures */
#include "mg_db.x"         /* MGCP ABNF Datbase */
#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */

#ifdef GCP_MGCO
#include "mgco_db.x"       /* MEGACO ABNF Database */
#endif /* GCP_MGCO */

#ifdef GCP_ASN
#include "mgasnwrp.h"
#endif


/* local defines, if any */

/* local typedefs, if any */
 
/* local externs, if any */

/* forward references */
/*mg002.105: extern moved from mg.x for g++ compilation issue*/

EXTERN S16 mgAllocEventMem ARGS((
       Ptr       *memPtr,
       Size      memSize
    ));
       
EXTERN S16 mgFreeEventMem ARGS((
       Ptr       memPtr
    ));

/* public variable declaration */
#ifdef GCP_MGCO
/* 
 * Forward declaration required for mgSendTxnRspAck
 */
EXTERN    CmAbnfElmDef   mgMgcoAuthHdrMsgDef;
EXTERN    CmAbnfElmDef   mgMgcoMsgBodyDef;
#endif /* GCP_MGCO */

#ifdef GCP_CH
EXTERN PUBLIC MgtMgcoCmdInd mgUiMgtMgcoCmdIndMt[];
EXTERN  PUBLIC MgtMgcoUpdCtxtInd mgUiMgtMgcoUpdCtxtIndMt [];
EXTERN PUBLIC MgtMgcoTxnStaInd mgUiMgtMgcoTxnStaIndMt[];
#endif /* GCP_CH */

/* private variable declaration */


/******************************************************************************/
/*                      Forward Declarations                                  */
/******************************************************************************/

#ifdef GCP_MGCO
#ifdef GCP_VER_1_5
#ifdef GCP_CH

PRIVATE S16 mgChPrcMgcoTxnInd  ARGS((
   MgMgcoMsg          *mgcoMsg,       /* Megaco Message     */
   MgPeerCb           *peer,          /* Peer Control Block */
   S16                *err            /* Error code to be filled if any */
));

PRIVATE S16 mgChComposeTransReq ARGS((
   MgMgcoChTransReq   *txnReq,        /* CH Transation Req  */
   MgPeerCb           *peer           /* Peer Control Block */
));

/*mg002.105: Removed compilation warning*/
PRIVATE S16 mgChSendUpdCntxt ARGS((
   MgMgcoChTransIndRsp *trIndRsp,      /* Trans Ind-Rsp      */
   U16                 actionId,       /* Action Id          */
   MgPeerCb            *peer,          /* Peer Control    cb */
   S16                 *err,           /* Error              */
   U8                  primType        /* Primitive Type     */
));


PRIVATE S16 mgChFillAuthHdr  ARGS((
Bool                 fill,
MgMgcoAuthHdr        *auth,
U32                  secIdx,
U32                  seqNum,
U8                   *authData,
U8                   aLen
));
 
PRIVATE S16 mgChComposeTransRsp ARGS((
   MgMgcoChTransIndRsp   *txnRsp,        /* CH Transation Rsp  */
   MgPeerCb           *peer           /* Peer Control Block */
));


PRIVATE S16 mgChFillVersion ARGS((
Bool                 fill,
MgMgcoVersion        *version,
U8                   verNo
)); 

PRIVATE S16 mgChSendNextCmd ARGS(( 
   MgMgcoChTransIndRsp *trIndRsp,      /* Trans Ind-Rsp      */
   MgMgcoChAxnIndRsp   *axnIndRsp,     /* Action Ind Rsp     */
   MgMgcoTransId       transId,        /* Transaction Id     */
   U32                  peerVal        /* Peer Control    cb */
));

PRIVATE S16 mgChHndlRspTimeOut ARGS((
   U32     transId,           /* Trans Id   */
   U32     peerId             /* Peer  Id   */
));
 
PRIVATE S16 mgChChkPeer  ARGS((
   TknU32     peerId          /* peerId     */
));
PRIVATE S16 mgChChkResp ARGS((
   MgMgcoCmdReply *cmdReply         /* Cmd Rsp      */
));
PRIVATE S16 mgChSendNextCmd ARGS(( 
   MgMgcoChTransIndRsp *trIndRsp,      /* Trans Ind-Rsp      */
   MgMgcoChAxnIndRsp   *axnIndRsp,     /* Action Ind Rsp     */
   MgMgcoTransId       transId,        /* Transaction Id     */
   U32                  peerVal        /* Peer Control    cb */
));

/*   mg004.105: GCP_ALLOW_LIMIT_CFG - This is introduced
 *   to configured the limits for GCP message
 *   components exceeding which will be rejected */
#ifdef GCP_ALLOW_LIMIT_CFG
PRIVATE S16 mgChValidateTxnInd ARGS((
         MgMgcoMsg          *msg,           /* Megaco Message     */
         MgPeerCb           *peer,          /* Peer Control Block */
         S16                *err            /* error code         */
));
#endif /* GCP_ALLOW_LIMIT_CFG  */

#endif /*CH*/
 
#endif /*Version*/
#endif/*GCP_MGCO*/

#ifdef GCP_MGCP
#ifdef GCP_VER_1_3

#ifdef GCP_2705BIS
PRIVATE S16 mgMgcpCompRspAckRsp ARGS((
        MgSSAPCb           *ssap,              /* SSAP Control Block */
        MgTransId          transId,            /* Transaction Id */
        MgPeerCb           *peer,              /* Peer Control Block */
        Buffer             *mBuf               /* Message Buffer */
));
#endif

PRIVATE S16 mgMgcpFillRspAck ARGS((
        MgRspAck        **ack,         /* response acknowledgement parameter*/
        MgMgcpMsg       *msg,          /* MGCP Message */
        U8              cnt            /* no of Rsp Ack*/
      ));
#ifdef GCP_2705BIS
PRIVATE S16 mgMgcpSendRspAckRsp ARGS((
        MgPeerCb           *peer,            /* Peer */
        MgTransId          transId           /* Transaction Identifier */
   ));
#endif
#endif
#ifdef CM_ABNF_MT_LIB
PRIVATE S16 mgMgcpMTPrcEachTxnReq ARGS((
       Bool               ssapTxSrvr,      /* SSAP owns Local Tx Socket ? */
       Bool               *delPeer,        /* Delete Peer */
       MgPeerCb           *peer,           /* Peer Control Block */
       MgSSAPCb           *ssap,           /* SSAP Control Block */
       MgMgcpTxn          *txn,            /* Transaction to be Transmitted */
       MgMgcpTxn          **failedTxn,     /* Rejected Transactions */
       CmTptAddr          *tptAddr,        /* Destination Tx Addr */
       MgTptSrvr          *srvr,           /* Local Socket for Transmission */
       MgTSAPCb           *tsap            /* TSAP CB */
));
#else
PRIVATE S16 mgMgcpPrcEachTxnReq ARGS((
        Bool            ssapTxSrvr,    /* SSAP owns Local Tx Socket ? */
        Bool            *delPeer,      /* Delete Peer */
        MgPeerCb        *peer,         /* Peer Control Block */
        MgSSAPCb        *ssap,         /* SSAP Control Block */
        MgMgcpTxn       *txn,          /* Transaction to be Transmitted */
        MgMgcpTxn       **failedTxn,   /* Rejected Transactions */
        CmTptAddr       *tptAddr,      /* Destination Tx Addr */
        MgTptSrvr       *srvr,         /* Local Socket for Transmission */
        MgTSAPCb        *tsap          /* TSAP CB */
      ));

#endif /* CM_ABNF_MT_LIB */
PRIVATE S16 mgMgcpInitialTxnReqChks ARGS((
        MgMgcpTxn       *txn,          /* Transaction */
        MgPeerCb        **peer,        /* Peer Control Block */
        MgTSAPCb        *tsap,         /* TSAP Control Block */
        MgSSAPCb        *ssap,         /* SSAP Control Block */
        MgTptSrvr       **srvr,        /* Transport Server */
        CmTptAddr       *addr,         /* Remote Address */
        Bool            *ssapSrvr      /* SSAP Server Used for Tx ? */
      ));


PRIVATE S16 mgMgcpPrcRspInTxnReq ARGS((
        Bool            *delPeer,      /* Delete Peer */
        MgPeerCb        *peer,         /* Peer Control Block */
        MgMgcpMsg       *msg,          /* MGCP Message */
        CmTptAddr       *responseAddr, /* Remote Address */
        MgRxTransIdEnt  **rxCb,        /* Transaction Control Block */
        U32             *mgtError,     /* MGT Interface Error Code */
        Buffer          *mBuf          /* Message Buffer */
      ));

PRIVATE MgMgcpParam * mgMgcpFindParamTypeInMsg ARGS((
        U8              paramType,     /* Parameter Type */
        MgMgcpMsg       *msg           /* MGCP Message */
      ));

PRIVATE S16 mgMgcpPrcDecodedTxn ARGS((
        S16             *errAction,    /* Action to take on error */
        U32             *rspCode,      /* Response Code */
        MgMgcpTxn       *txn,          /* MGCP Transaction */
        MgPeerCb        **peerCtlBlk,  /* Peer */
        MgTptSrvr       *srvr,         /* Listener Control Block */
        CmTptAddr       *tptAddr,      /* Source Transport Address */
        U16             msgIdx,        /* MsgIndex , to be processed */
        MgTSAPCb        *tsap          /* TSAP CB */
      ));

PRIVATE Void mgMgcpFindAndActOnRspAck ARGS((
        MgPeerCb        *peer,         /* Peer Control Block */
        MgMgcpCmd       *cmd           /* MGCP Command */
      ));

PRIVATE S16 mgMgcpVerifyCmdParms ARGS((
        U32             variant,       /* Protocol Variant */
        MgMgcpMsg       *msg,          /* MGCP Message */
        U32             *rspCode       /* Response Code */
      ));

PRIVATE S16 mgMgcpVerifyRspParms ARGS((
        MgMgcpMsg       *msg,          /* MGCP Message */
        U8              msgType,       /* Message Type */
        Bool            chkRspParam,   /* Check Response Parameter */
        U32             variant        /* Protocol Variant */
      ));

PRIVATE S16 mgMgcpPrcRcvdCmd ARGS((
        S16             *errAction,    /* Action to be taken on Error */
        U32             *rspCode,      /* Response Code */
        Bool            *chkNtfyEnt,   /* Check Notified Entity */
        MgMgcpMsg       *msg,          /* MGCP Message */
        MgPeerCb        **peerCtlBlk,  /* Peer Control Block */     
        MgTptSrvr       *srvr,         /* Listener Control Block */
        CmTptAddr       *tptAddr,      /* Source Transport Address */
        U32             variant,       /* variant */
        MgTSAPCb        *tsap          /* TSAP Control block */
      ));

PRIVATE S16 mgMgcpPrcRcvdRsp ARGS((
        S16             *errAction,    /* Action to be taken on Error */
        U32             *rspCode,      /* Response Code */
        Bool            *chkNtfyEnt,   /* Check Notified Entity */
        MgMgcpMsg       *msg,          /* MGCP Message */
        MgPeerCb        *peer,         /* Peer Control Block */     
        MgTptSrvr       *srvr,         /* Listener Control Block */
        U32             variant,       /* variant */
        MgTSAPCb        *tsap          /* TSAP Control block */
      ));


#ifdef GCP_MGC

PRIVATE S16 mgMgcpChkForNewPeerInRSIP ARGS((
        U8              method,        /* RSIP Method */
        MgPeerCb        **peerCtlBlk,  /* Peer Control Block */     
        CmTptAddr       *srcTptAddr,   /* Source Transport Address */
        MgEPName        *endPt,        /* End Point Name */
        MgDName         *dname,        /* Domain Name */
        Bool            *newPeer       /* New Peer or not ? */
      ));

PRIVATE MgPeerCb * mgMgcpLearnNewPeerFromRSIP ARGS((
        MgSSAPCb           *ssap,              /* SSAP Control Block */
        MgTSAPCb           *tsap,              /* TSAP Control Block */
        CmTptAddr          *srcTptAddr,        /* Source Transport Address */
        MgDName            *dname,             /* Domain Name */
        MgTptSrvr          *srvr,              /* Transport Server */
        U32                variant             /* RSIP Command */
      ));

#endif /* GCP_MGC */

#endif /* GCP_MGCP */


#ifdef GCP_MGCO

/* 
 * New function added for sending rspAck on receipt of immAck TRUE 
 */
#ifdef    GCP_PROV_SCTP
PRIVATE S16 mgSendTxnRspAck ARGS((

        MgPeerCb           *peer,      /* Peer Control Block */
        MgAssocCb          *assoc,     /* Server for transmission */
        MgTptSrvr          *srvr,      /* Server for transmission */
        MgTransId          trId        /* Transaction ID for rspAck */
       ));
#else     /* GCP_PROV_SCTP */
PRIVATE S16 mgSendTxnRspAck ARGS((

        MgPeerCb           *peer,      /* Peer Control Block */
        MgTptSrvr          *srvr,      /* Server for transmission */
        MgTransId          trId        /* Transaction ID for rspAck */
       ));
#endif    /* GCP_PROV_SCTP */


#ifdef CM_ABNF_MT_LIB

#ifdef    GCP_PROV_SCTP
PRIVATE S16 mgPrcMTMgcoTxn ARGS((
        MgSSAPCb    *ssap,             /* SSAP Control Block */
        MgMgcoMsg   *mgcomsg,          /* Transaction */
        MgMgcoTxn   *mgcoTxn,          /* Transaction */
        MgPeerCb    *peer,             /* Peer Control Block */
        MgTptSrvr   *srvr,             /* Transport Server */
        MgMgcoMsg   **errMsg,          /* Error Message */
        Buffer      *mBuf,             /* Message buffer */            
        Buffer      *hdrMBuf,          /* Header Buffer */
        Bool        *msgSend,          /* Message present in mBuf */
        U8          source,            /* Initiated by user/ internal */
        MgAssocCb   *assoc,            /* Association control block */
        TknU32      ctxId              /* Context-Id */
      ));
#else     /* GCP_PROV_SCTP */
PRIVATE S16 mgPrcMTMgcoTxn ARGS((
        MgSSAPCb    *ssap,             /* SSAP Control Block */
        MgMgcoMsg   *mgcomsg,          /* Transaction */
        MgMgcoTxn   *mgcoTxn,          /* Transaction */
        MgPeerCb    *peer,             /* Peer Control Block */
        MgTptSrvr   *srvr,             /* Transport Server */
        MgMgcoMsg   **errMsg,          /* Error Message */
        Buffer      *mBuf,             /* Message buffer */            
        Buffer      *hdrMBuf,          /* Header Buffer */
        Bool        *msgSend,          /* Message present in mBuf */
        U8          source             /* Initiated by user/ internal */
      ));
#endif    /* GCP_PROV_SCTP */

#else    /* CM_ABNF_MT_LIB */


#ifdef    GCP_PROV_SCTP
PRIVATE S16 mgPrcMgcoTxn ARGS((
        MgSSAPCb    *ssap,             /* SSAP Control Block */
        MgMgcoMsg   *mgcoMsg,          /* Transaction */
        MgPeerCb    *peer,             /* Peer Control Block */
        MgAssocCb   *assoc,            /* Association CB */
        TknU32      ctxId,             /* Context-ID */
        MgTptSrvr   *srvr,             /* Transport Server */
        MgMgcoMsg   **errMsg,          /* Error Message */
        Buffer      **mBufPtr,         /* changed to Msg buf ptr */
        Buffer      *hdrMBuf,          /* Header Buffer */
        Bool        *msgSend,          /* Message present in mBuf */
        U8          source,            /* Initiated by user/ internal */
        MsgLen      *crntLen,          /* added current len of buf */
        U32         txnIdx
      ));
#else     /* GCP_PROV_SCTP */
PRIVATE S16 mgPrcMgcoTxn ARGS((
        MgSSAPCb    *ssap,             /* SSAP Control Block */
        MgMgcoMsg   *mgcoMsg,          /* Transaction */
        MgPeerCb    *peer,             /* Peer Control Block */
        MgTptSrvr   *srvr,             /* Transport Server */
        MgMgcoMsg   **errMsg,          /* Error Message */
        Buffer      **mBufPtr,         /* changed to Msg buf ptr */
        Buffer      *hdrMBuf,          /* Header Buffer */
        Bool        *msgSend,          /* Message present in mBuf */
        U8          source,            /* Initiated by user/ internal */
        MsgLen      *crntLen,          /* added current len of buf */
        U32         txnIdx
        ));
#endif    /* GCP_PROV_SCTP */


#endif /* CM_ABNF_MT_LIB */


PRIVATE U8  mgPrcMgcoErrDesc ARGS((
        MgSSAPCb    *ssap,             /* SSAP Control Block */
        MgTSAPCb    *tsap,             /* TSAP Control Block */
        MgPeerCb    *peer,             /* Peer Control Block */
        Buffer      *mBuf,             /* Message buffer */ 
        MgMgcoMsg   *mgcoMsg,           /* Error Message */
        U32         protVar
     ));


PRIVATE Bool mgChkForSrvcChgRsp ARGS((
        MgPeerCb    *peer,             /* Peer Control Block */
        MgMgcoTxn   *mgcoTxn           /* Transaction */
     ));

PRIVATE S16 mgValidateMgcoMsg ARGS((
        MgPeerCb        *peer,         /* Peer Control Block */
        MgMgcoMsg       *msg,          /* Megaco Message */
        MgTSAPCb        *tsap          /* TSAP Control block */
      ));

PRIVATE S16 mgVerifySvcChgRsp ARGS((
        MgMgcoTxn       *mgcoTxn,      /* Megaco Transaction */
        Bool            chkTermId      /* Check Termination Id */
      ));

PRIVATE S16 mgFillSvcChgInfo ARGS((
        U8              svcChgType,    /* Service Change Method */
        MgMgcoTxn       *mgcoTxn,      /* Megaco Transaction */
        MgSvcChgInfo    *svcChgInfo    /* Service Change Information */
      ));

PRIVATE MgPeerCb *  mgFindPeerForTxnReq ARGS((
        MgSSAPCb        *ssap,         /* SSAP Control Block */
        MgMgcoMsg       *mgcoMsg,      /* Megaco Msg */
        U8              source         /* Initiated by user/ internal */
      ));


#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
PRIVATE S16 mgPrcMgcoMsg ARGS((
        MgMgcoMsg        *mgcoMsg,     /* Incoming Megaco Message */
        MgcoTptInfo      *mgcoTptInfo, /* Megaco Transport Information */
        MgTSAPCb         *tsap,        /* TSAP CB */
        MgTptSrvr        *srvr,        /* Listener Control Block */
        CmTptAddr        *srcAddr,     /* Source Transport Address */
        S16              *errAction,   /* Action to be taken on error */
        S16              *rspCode,     /* Error Response Code */
        MgPeerCb         **peerPtr,    /* pointer to peer control blk */
        MgMgcoMsg        **errMsg      /* Error Message */
      ));
#else     /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
PRIVATE S16 mgPrcMgcoMsg ARGS((
        MgMgcoMsg        *mgcoMsg,     /* Incoming Megaco Message */
        MgTSAPCb         *tsap,        /* TSAP CB */
        MgTptSrvr        *srvr,        /* Listener Control Block */
        CmTptAddr        *srcAddr,     /* Source Transport Address */
        S16              *errAction,   /* Action to be taken on error */
        S16              *rspCode,     /* Error Response Code */
        MgPeerCb         **peerPtr,    /* pointer to peer control blk */
        MgMgcoMsg        **errMsg      /* Error Message */
      ));
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */


PRIVATE S16 mgChkIncSvcChgReq ARGS((
        MgMgcoTxn       *mgcoTxn,      /* Megaco Txn */
        MgSvcChgInfo    *svcChgInfo    /* Service Change Information */
      ));

PRIVATE S16 mgChkIncSvcChgRsp ARGS((
        MgMgcoTxn       *mgcoTxn,      /* Megaco Txn */
        MgSvcChgInfo    *svcChgInfo    /* Service Change Information */
      ));

#ifdef GCP_MGC
PRIVATE S16  mgChkPeerType ARGS((
        MgPeerCb        *peer          /* peer control block */
      )); 
#endif /* GCP_MGC */

PRIVATE S16 mgChkPeerState ARGS((
        MgPeerCb        *peer          /* peer control block */
      ));

/* mg008.105: Passing one more parameter peer control block */
PRIVATE S16 mgFillErrMsg ARGS((
        MgMgcoMsg        **errMsg,      /* Error Message */
        MgMgcoTxn        *mgcoTxn,      /* Megaco Transaction*/
        MgPeerCb           *peer        /* Peer Control block */
      ));

PRIVATE S16 mgValidatePeer ARGS((
        MgPeerCb         *peer,         /* Peer Control Block */
        Bool             *chkdPeerType, /* Peer type Check Completed or not */
        Bool             *peerStateChkd /*Peer State Check Completed or not */
      ));
#ifdef GCP_VER_1_5

#ifdef GCP_PKG_MGCO_ROOT
PRIVATE S16 mgGetProvRspTmrVal ARGS ((MgMgcoTxn *mgcoTxn, MgPeerCb *peer));

#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */
 
#endif /*GCP_VER_1_5*/

#endif /* GCP_MGCO */


/******************************************************************************/
/*                      Co-ordinator Module Functions                         */
/******************************************************************************/


PRIVATE S16 mgRmvEmptyTxn ARGS((
        Ptr              mgcoMsg,      /* MEGACO message */
        U32              protocol      /* protocol */
      ));


#ifdef GCP_MGCP

/******************************************************************************/
/*                      MGCP Specific Functions                               */
/******************************************************************************/

/******************************************************************************/
/*                      Upper Interface Functions                             */
/******************************************************************************/


/*
*
*       Fun:   mgPrcMgcpTxnReq
*
*       Desc:  This function processes the transaction received from MGCP
*              service user
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or an acknowledgement 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgPrcMgcpTxnReq
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgcpTxn          *txn,               /* Transaction */
MgPeerCb           *peerCb             /* peer control block */
)
#else
PUBLIC S16 mgPrcMgcpTxnReq (ssap, txn, peerCb)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgcpTxn          *txn;               /* Transaction */
MgPeerCb           *peerCb;            /* peer control block */
#endif
{
   Bool            ssapTxSrvr;         /* Used SSAP Srvr for Tx ? */
   Bool            delPeer;            /* Delete Peer */
   CmTptAddr       xmitAddr;           /* Remote Address For Tx of Command */
   MgPeerCb        *peer;              /* Peer Control Block */
   MgTptSrvr       *srvr;              /* Transport Server */
   MgTSAPCb        *tsap;              /* TSAP Control Block */
   MgMgcpTxn       *discardTxn;        /* Structure for discarded messages */
   S16             ret;                /* returned value */

   TRC2(mgPrcMgcpTxnReq);

   /* Initialise variables */
   delPeer    = FALSE;

   /* Initialise pointers */
   srvr       = NULLP;


   if (peerCb != NULLP)
      tsap       = peerCb->tsap;
   else
      tsap       = NULLP;


   peer = peerCb;

   /* Perform Initial Error Checks */
   if ((ret = mgMgcpInitialTxnReqChks(txn, &peer, tsap, ssap, &srvr, &xmitAddr,
                                 &ssapTxSrvr)) == RFAILED)
   {
#ifdef ZG
      /* Send update messages */
      zgUpdPeer();
#endif /* ZG */
      RETVALUE(RFAILED);
   }

   /*
    *   At this point, peer has to be valid;
    *   Otherwise, mgMgcpInitialTxnReqChks would have
    *   returned failure;
    */
   if (tsap == NULLP)
      tsap       = peer->tsap;


#ifdef ZG_DFTHA
   /* If returned value is ROKDNA..this means..reverse update was generated to
    * master txn was queued. This will be processed  once state update 
    * from master will be received */
   else if(ret == ROKDNA)
   {
      mgQueueRvUpdTxnReq(txn, &peer->usrTxnQ, tsap->rvNode,
                         LMG_PROTOCOL_MGCP, ssap->ssapCfg.sSAPId);
      RETVALUE(ROK);
   }
#endif /* ZG_DFTHA */

   /*
    * Process each transaction sent by the user; The transaction could be
    * a command or a response; 
    */
#ifdef CM_ABNF_MT_LIB
   if ((ret = mgMgcpMTPrcEachTxnReq(ssapTxSrvr, &delPeer, peer, ssap, 
         txn, &discardTxn, &xmitAddr, srvr, tsap)) == RFAILED)
#else
   if ((ret = mgMgcpPrcEachTxnReq(ssapTxSrvr, &delPeer, peer, ssap, 
         txn, &discardTxn, &xmitAddr, srvr, tsap)) == RFAILED)
#endif /* CM_ABNF_MT_LIB */
   {
#ifdef ZG
      /* Send update messages */
      zgUpdPeer();
#endif /* ZG */
      RETVALUE(RFAILED);
   }
   else if(ret == ROKDNA)
   {
      /* just return; This is the case when txn is queued and reverse update is
       * generated..Queued txn will be processed once state update is rcvd from
       * master */
#ifdef ZG
      /* Send update messages */
      zgUpdPeer();
#endif /* ZG */
      RETVALUE(ROK);
   }

   /* Check if any transaction was transmitted */
   if ((discardTxn != NULLP) && discardTxn->numMsg > MG_NONE)
   {
      /* No transaction to be transmitted */
      mgHandleMgcpTxnReqErr(ssap, discardTxn, MG_IGNORE);
#ifndef CM_ABNF_MT_LIB
      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
#endif /* CM_ABNF_MT_LIB */
#ifdef ZG
      /* Send update messages */
      zgUpdPeer();
#endif /* ZG */
      RETVALUE(RFAILED);
   }

   /* In case ..Encoder/Decoder is multi threaded..we shouldn't delete peer
    * here..Peer will be deleted once all the encode confirm is received for
    * ED */
#ifndef CM_ABNF_MT_LIB
   /* Remove peer control block if required */
   if (delPeer == TRUE)
   {
#ifdef ZG_DFTHA
      /* only master should delete peer */
      if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
      {
         mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED, LMG_CAUSE_RSIP_NAK, FALSE);
      }
#ifdef ZG_DFTHA
      else
      {
             /* send reverse update to delete peer */
         ZgRvUpdInfo   updInfo;

         MG_FILL_RVUPD_DEL_PEER(updInfo, peer, LMG_EVENT_PEER_REMOVED,
                                LMG_CAUSE_RSIP_NAK,FALSE);

         /* Generate Reverse Update */
         zgReverseUpd(&updInfo, peer->accessInfo.peerId, MG_QUEUE_NONE,
                      tsap->tsapCfg.tSAPId);
      }
#endif /* ZG_DFTHA */
      
   }

   /* Incase Mutithreaded Encoder/Decoder lib is defined..don't free event
    * structure else free it*/
   MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
#endif /* ! CM_ABNF_MT_LIB */

#ifdef ZG
   /* Send update messages */
   zgUpdPeer();
#endif /* ZG */
   RETVALUE(ROK);

} /* end of mgPrcMgcpTxnReq() */





/*
*
*       Fun:   mgMgcpInitialTxnReqChks
*
*       Desc:  This function performs initial error checking for processing
*              transaction request from the service user
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE S16 mgMgcpInitialTxnReqChks
(
MgMgcpTxn          *txn,               /* Transaction */
MgPeerCb           **peer,             /* Peer Control Block */
MgTSAPCb           *tsap,              /* TSAP Control Block */
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgTptSrvr          **srvr,             /* Transport Server */
CmTptAddr          *addr,              /* Remote Address */
Bool               *ssapSrvr           /* SSAP Server Used for Tx ? */
)
#else
PRIVATE S16 mgMgcpInitialTxnReqChks(txn, peer, tsap, ssap, srvr, addr, ssapSrvr)
MgMgcpTxn          *txn;               /* Transaction */
MgPeerCb           **peer;             /* Peer Control Block */
MgTSAPCb           *tsap;              /* TSAP Control Block */
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgTptSrvr          **srvr;             /* Transport Server */
CmTptAddr          *addr;              /* Remote Address */
Bool               *ssapSrvr;          /* SSAP Server Used for Tx ? */
#endif
{
   MgPeerInfo      *peerInfo;          /* Destination Peer Information */
   MgPeerCb        *peerCb;            /* Peer Control Block */
   MgMgcpMsg       *msg;

   TRC2(mgMgcpInitialTxnReqChks)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Error Checks */
   if (txn->numMsg == MG_NONE)
   {
      /* Free the transaction structure received */
      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* Initialise variables */
   *ssapSrvr = FALSE;
   peerCb    = *peer;

   /* Search for the Peer */
   peerInfo = &(txn->mgLclInfo);

   if((peerCb) == NULLP)
      peerCb = mgLocatePeer(peerInfo, ssap);

   if ((peerCb == NULLP) || (peerCb->ssap != ssap))
   {
      /* 
       * Inform User that transactions have been discarded with reason as no
       * gateway was found
       */
      mgHandleMgcpTxnReqErr(ssap, txn, MGT_ERR_INVALID_PEER);
      RETVALUE(RFAILED);
   }


   if (tsap == NULLP)
      tsap = peerCb->tsap;



   /* 
    * If Service User has specified an IP Address and/or a port, send it to that
    * specific IP Address and/or port for a Command. Response is always sent to 
    * the source transport address from which command was received
    */
   MG_GET_REMOTE_ADDR_FOR_TX(addr, peerInfo, peerCb);

   *peer = peerCb;
#ifdef GCP_MGC
   if (mgCb.genCfg.entType == LMG_ENT_GC)
   {
      if (peerCb->state != LMG_PEER_STATE_REGISTER &&
          peerCb->state != LMG_PEER_STATE_ACTIVE)
      {
         U8        mgtError;

         if (peerCb->state == LMG_PEER_STATE_RESOLVING)
            mgtError = MGT_ERR_NOT_REGISTERED;
         else
            mgtError = MGT_ERR_PEER_DISCONNECTED;

         mgHandleMgcpTxnReqErr(ssap, txn, mgtError);
         RETVALUE(RFAILED);
      }

      if (peerCb->state == LMG_PEER_STATE_REGISTER) 
      {
        msg = txn->mgcpMsg[0];

        /*
         *   In REGISTER state, only outgoing responses
         *   are allowed.
         */
        if (msg->msgType.val != MGT_MSG_RSP)
        {
          mgHandleMgcpTxnReqErr(ssap, txn, MGT_ERR_NOT_REGISTERED);
          RETVALUE(RFAILED);
        }
      }
   }
#endif /* GCP _MGC */

#ifdef GCP_MG
   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
      /*
       * GCP Layer is MG side and has not registered with the MGC in question
       * If GCP layer is configured to initiate registration, stop the 
       * restart avalanche timer, and send RSIP to the MGC. Else assume 
       * Service User has initiated this transaction request as RSIP
       * for registration and follow it up in later processing of each 
       * command. See mgMgcpPrcCmdInTxnReq() for details
       *
       * However If this is DFTHA Environment..then only master should initiate
       * registration procedure..so check if Master lies on the same copy..if no
       * then enqueue the Txn and send reverse update for sending RSIP command
       * to peer.
       */
      /* Send a RSIP only if this is not a ntfyEntPeer */
      if ( (ssap->ssapCfg.initReg == TRUE) && 
           (TRUE != peerCb->mgcpInfo.ntfyEntPeer) )
      {
         if (peerCb->state == LMG_PEER_STATE_RESOLVING ||
             peerCb->state == LMG_PEER_STATE_AWAIT_REG) 
         {
            U8        idx;                /* Timer Index */
            idx = (MG_RST_AVLNCH_TMR - MG_PEER_TMR_BASE);

            if (peerCb->mntInfo.tmr[idx].tmrEvnt == MG_RST_AVLNCH_TMR)
            {
#ifdef ZG_DFTHA
                  /* check if this master */
               if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
               {
                  mgStopTmr(MG_RST_AVLNCH_TMR, (PTR) peerCb, 
                           &(peerCb->mntInfo.tmr[idx]));
                  if ((mgMgcpSendRSIP(peerCb, MGT_PARAM_RSTRT_RSTRT)) != ROK)
                  {
                     mgHandleMgcpTxnReqErr(ssap, txn, MGT_ERR_RSRC_UNAVAIL);
                     RETVALUE(RFAILED);
                  }
               }
#ifdef ZG_DFTHA
               else
               {
                  /* fill information for reverse update */
                  ZgRvUpdInfo    updInfo;
                  
                  MG_FILL_RVUPD_REGCMD_INT(updInfo,
                     (peerCb->accessInfo.peerId), MGT_PARAM_RSTRT_RSTRT, 
                     MGT_NONE, ZG_RVUPD_SVCCHG_CMD_INT );
                  /* all PLDF fn to send this reverse upadate */
                  tsap->rvNode = 
                     (MgRvUpdQNode *)zgReverseUpd(&updInfo, 
                                                peerCb->accessInfo.peerId, 
                                                MG_QUEUE_OUTTXNQ,
                                                tsap->tsapCfg.tSAPId);
                  RETVALUE(ROKDNA);
               }
#endif  /* ZG_DFTHA */
            }
         }
      }

      if (peerCb->state == LMG_PEER_STATE_DISCONNECTED) 
      {
         /* 
          * Implies association with peer was previously lost. First message
          * after that should be RSIP - Verify That
          */
         msg = txn->mgcpMsg[0];

         if (msg->msgType.val != MGT_MSG_RSIP)
         {
            mgHandleMgcpTxnReqErr(ssap, txn, MGT_ERR_PEER_DISCONNECTED);
            RETVALUE(RFAILED);
         }
         else
         {
            /* Update peerCb State */
#ifdef ZG_DFTHA
            if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
            {
               peerCb->state = LMG_PEER_STATE_REGISTER;
#ifdef ZG
               /* send update to peer */
               zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peerCb, CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_MOD);
#endif /* ZG */
            }
#ifdef ZG_DFTHA
            /* generate reverse update */
            else
            {
               /* Fill required info */
               ZgRvUpdInfo    updInfo;
               updInfo.action = ZG_RVUPD_RSIP_CMD_USR;
               updInfo.u.rCmdU = (*peer)->accessInfo.peerId;
               /* call fn to send this reverse update */
               tsap->rvNode = 
                   (MgRvUpdQNode *)zgReverseUpd(&updInfo, 
                                                (*peer)->accessInfo.peerId,
                                                MG_PEER_OUTTXNQ,
                                                tsap->tsapCfg.tSAPId);
               RETVALUE(ROKDNA);
            }
#endif /* ZG_DFTHA */
            
         }
      }
   }
#endif /* GCP_MG */

   /* Obtain a socket for subsequent transmissions */
   if ((*srvr = mgMgcpGetSrvrForTx(ssap, tsap, ssapSrvr)) == NULLP)
   {
      mgHandleMgcpTxnReqErr(ssap, txn, MGT_ERR_RSRC_UNAVAIL);
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of mgMgcpInitialTxnReqChks() */


/*
*
*       Fun:   mgMgcpPrcCmdInTxnReq
*
*       Desc:  This function processes the command to be sent out to the
*              peer entity in the network. The command has come to GCP layer
*              as a transaction request from the service user
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgMgcpPrcCmdInTxnReq
(
MgPeerCb           *peer,              /* Peer Control Block */
MgMgcpMsg          *msg,               /* MGCP Message */
CmTptAddr          *remoteAddr,        /* Remote Address */
MgTptSrvr          *srvr,              /* Transport Server */
MgTxTransIdEnt     **txCb,             /* Transaction Control Block */
U32                *mgtError,          /* MGT Interface Error Code */
Void               *mBuf,              /* Message Buffer */
Bool               *immTx,             /* Transmit Immediately */
MgTSAPCb           *tsap               /* TSAP Control Block */
)
#else
PUBLIC S16 mgMgcpPrcCmdInTxnReq(peer, msg, remoteAddr, srvr, txCb, mgtError,
                                 mBuf, immTx, tsap)
MgPeerCb           *peer;              /* Peer Control Block */
MgMgcpMsg          *msg;               /* MGCP Message */
CmTptAddr          *remoteAddr;        /* Remote Address */
MgTptSrvr          *srvr;              /* Transport Server */
MgTxTransIdEnt     **txCb;             /* Transaction Control Block */
U32                *mgtError;          /* MGT Interface Error Code */
Void               *mBuf;              /* Message Buffer */
Bool               *immTx;             /* Transmit Immediately */
MgTSAPCb           *tsap;              /* TSAP Control Block */
#endif
{
   U8              msgType;            /* Message Type */
#ifndef CM_ABNF_MT_LIB
   MgTransId       transId;            /* Transaction Id */
   Bool            unUsed;             /* Unused Variable */
#endif /* CM_ABNF_MT_LIB */

#ifdef GCP_MG
   U8              method;
#endif /* GCP_MG */

   TRC2(mgMgcpPrcCmdInTxnReq)

   *txCb   = NULLP;
   msgType = msg->msgType.val;

   /* 
    * Check if we have resources to process this transaction 
    * This check is done only for outgoing transactions as that
    * is where we allocate resources in our layer...for outgoing
    * response no resource in our layer is allocated
    */
   if (mgAdmitTxn(peer->ssap, tsap) != ROK)
   {
      *mgtError = MGT_ERR_RSRC_UNAVAIL;
      RETVALUE(RFAILED);
   }

   if (msgType != MGT_MSG_NONSTD) 
   {
      /* 
       * Added a new param to this function. The param value will
       * be reset outside to MGT_ERR_INVALID_PARMS if the function returns
       * error 
       */
      if ((mgMgcpVerifyCmdParms(peer->mntInfo.variant, msg, mgtError)) != ROK)
      {
         *mgtError = MGT_ERR_INVALID_PARMS;
         RETVALUE(RFAILED);
      }

#ifndef CM_ABNF_MT_LIB
      transId = msg->t.epcfCmd.cmdLine.trId.val;
#endif /* CM_ABNF_MT_LIB */
   }
#ifndef CM_ABNF_MT_LIB
   else
      transId = msg->t.nonStdCmd.cmd.cmdLine.trId.val;
#endif /* CM_ABNF_MT_LIB */

   *immTx = FALSE;

#ifdef GCP_MG
   /* Do these checks for RSIP only if this is not a ntfyEntPeer */
   if ( ((mgCb.genCfg.entType == LMG_ENT_GW) &&
         (TRUE != peer->mgcpInfo.ntfyEntPeer)) &&
         ((peer->state == LMG_PEER_STATE_AWAIT_REG) ||
          (peer->state == LMG_PEER_STATE_RESOLVING)) )
   {
      /* 
       * GCP Layer is MG and not registered with MGC (peer); 
       * Coming Here implies GCP layer is not configured to follow Restart 
       * Avalanche Procedure and Service User has to initiate RSIP for 
       * registration. Enforce that the message being processed is RSIP
       * See mgMgcpInitialTxnReqChks() for details
       */
      if (msgType == MGT_MSG_RSIP)
      {
         /*
          * Enforce that the first message from the SU is a RSIP restart or RSIP
          * disconnected.
          */
         MgMgcpParam   *param = NULLP;
         /* look for the presence of restartMethod */
         param = mgMgcpFindParamTypeInMsg(MGT_PARAM_RSTRT_METHOD, msg);

#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
         method = param->t.rstrtMethod.stdOrXten.val;
#else
         method = param->t.rstrtMethod.val;
#endif /* GCP_VER_1_3 */
         if( (MGT_PARAM_RSTRT_RSTRT == method) || 
             (MGT_PARAM_RSTRT_DISC == method) )
         {
         /* Update peer state if required .*/
            if (peer->state == LMG_PEER_STATE_AWAIT_REG)
            {
#ifdef ZG_DFTHA  
               if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
               {
                  peer->state = LMG_PEER_STATE_REGISTER;

                  /*
                   * Since this service Change message is being
                   *             sent by the service user set usrKnows to TRUE.
                   */
                  peer->mntInfo.usrKnows = TRUE;

#ifdef ZG
                  /* send update to peer */
                  zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_MOD);
#endif /* ZG */
               }
#ifdef ZG_DFTHA
               /* Send reverse uodate to master..and send this message 
                * to peer..don't queue this message */ 
               else
               {
                  /* Fill required info */
                  ZgRvUpdInfo    updInfo;
                  updInfo.action = ZG_RVUPD_RSIP_CMD_USR;
                  updInfo.u.rCmdU = peer->accessInfo.peerId;
                  /* call fn to send this reverse update */
                  tsap->rvNode = 
                      (MgRvUpdQNode *)zgReverseUpd(&updInfo, 
                                                   (peer->accessInfo.peerId), 
                                                   MG_PEER_OUTTXNQ,
                                                   tsap->tsapCfg.tSAPId);
                  RETVALUE(ROKDNA);
               }
#endif /* ZG_DFTHA */
            }
         }
         else
         {
            *mgtError = MGT_ERR_NOT_REGISTERED;
            RETVALUE(RFAILED);
         }
         /* For Resolving State, Queue the message */
      }
      else    /* - Addition of if condition */
      if (peer->ssap->ssapCfg.initReg != TRUE) 
      {
         *mgtError = MGT_ERR_NOT_REGISTERED;
         RETVALUE(RFAILED);
      }
   }
#endif /* GCP_MG */

#ifndef CM_ABNF_MT_LIB
   /*
    * If notified entity is present in possible commands, we need to 
    * copy the remote address where commands needs to be transmitted. Also
    * This command needs to be transmitted immediately
    */
   
   if (msgType == MGT_MSG_RQNT || msgType == MGT_MSG_NTFY ||
       msgType == MGT_MSG_DLCX)
   {
       mgMgcpCopyNotifyEntityForTx(immTx, msg, peer, srvr, remoteAddr);
   }

   if ((*txCb = mgPrcOutGoingTxn(transId, msgType, MG_NONE, *immTx, remoteAddr, 
                                 peer->ssap, peer,
#ifdef    GCP_PROV_SCTP
                                 peer->assocCb, 
#endif    /* GCP_PROV_SCTP */
                                 srvr, 
                                 (Void *)mBuf, &unUsed)) == NULLP)
   {
      *mgtError = MGT_ERR_RSRC_UNAVAIL;
      RETVALUE(RFAILED);
   }
#endif /* CM_ABNF_MT_LIB */
   RETVALUE(ROK);

} /* end of mgMgcpPrcCmdInTxnReq() */

/*
*
*       Fun:   mgMgcpPrcRspInTxnReq
*
*       Desc:  This function processes the response to be sent out to the
*              peer entity in the network. The response has come to GCP layer
*              as a transaction request from the service user
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcpPrcRspInTxnReq
(
Bool               *delPeer,           /* Delete Peer */
MgPeerCb           *peer,              /* Peer Control Block */
MgMgcpMsg          *msg,               /* MGCP Message */
CmTptAddr          *responseAddr,      /* Remote Address */
MgRxTransIdEnt     **rxCb,             /* Transaction Control Block */
U32                *mgtError,          /* MGT Interface Error Code */
Buffer             *mBuf               /* Message Buffer */
)
#else
PRIVATE S16 mgMgcpPrcRspInTxnReq(delPeer, peer, msg, responseAddr, 
                                 rxCb, mgtError, mBuf)
Bool               *delPeer;           /* Delete Peer */
MgPeerCb           *peer;              /* Peer Control Block */
MgMgcpMsg          *msg;               /* MGCP Message */
CmTptAddr          *responseAddr;      /* Remote Address */
MgRxTransIdEnt     **rxCb;             /* Transaction Control Block */
U32                *mgtError;          /* MGT Interface Error Code */
Buffer             *mBuf;              /* Message Buffer */
#endif
{
   MgTransId       transId;            /* Transaction Id */
   Bool            rspType;            /* Response Type */
   Bool            immAck;             /* Immediate Ack - Not Used */
   MgMgcpRsp       *response;          /* MGCP Response Message */

   TRC2(mgMgcpPrcRspInTxnReq)

   /* Initialise */
   response = &(msg->t.mgcpRsp);
   transId  = response->trId.val;
   /* Sending a response & MG:- Peer state should be active */
   if(mgCb.genCfg.entType == LMG_ENT_GW)
   {
       if(peer->state != LMG_PEER_STATE_ACTIVE)
       {
          *mgtError = MGT_ERR_NOT_REGISTERED;
          RETVALUE(RFAILED);
       }
   }

   if (response->rspCode.val >= MGT_MGCP_RSP_CODE_PROVISIONAL && 
       response->rspCode.val < MGT_MGCP_RSP_CODE_OK)
   {
      rspType = MG_RESPONSE_PROV;
   }
   else
   {
      rspType = MG_RESPONSE;
   }

   if ((*rxCb = mgPrcOutGoingAck(LMG_PROTOCOL_MGCP, rspType, transId, peer,
                                mBuf, &immAck, FALSE)) == NULLP)
   {
      *mgtError = MGT_ERR_RSRC_UNAVAIL;
      RETVALUE(RFAILED);
   }
#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
   /* if immAck is TRUE (it will be true ..if prov rsp was sent previously)  
    * then we can add empty response Ack parameter to the
    * response if GCP layer is allowed to do so*/
   /* mg002.105: rspAckEnb is now reconfigurable */
   if ((immAck == TRUE) && (mgCb.genCfg.reCfg.rspAckEnb &
                            LMG_EMBD_EMPTY_RSPACK_MGCP))
   {
      /* Call fn to fill empty response ack parameter */
      mgMgcpFillRspAck(NULLP,msg,0);
      /* 
       * Now start the retx timer; GCP layer expects Response Acknowledgement
       * Response from Peer. Not required for NCS/TGCP. Take care of that
       */ 
      if(peer->mntInfo.variant == LMG_VER_PROF_MGCP_RFC2705_1_0)
      {
         if((*rxCb)->tmr[MG_RETX_RSP_TMR - MG_INTXN_TMR_BASE].tmrEvnt 
            == TMR_NONE)
         {
            mgStartTmr (MG_RETX_RSP_TMR,
               (peer->mntInfo.rto/mgCb.genCfg.timeRes), (PTR)(*rxCb), 
               &((*rxCb)->tmr[MG_RETX_RSP_TMR - MG_INTXN_TMR_BASE]));
         }
         SGetSysTime(&((*rxCb)->timeStamp));        
      }
   }
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */
   
   /* 
    * If this is a response to RSIP , then there are two cases:
    * 1. If Response Code to RSIP is failure...remove the peer control block 
    * 2. If Response Code is ok and Peer was registering, update state
    * 3. If Response code is provisional response, dont do anything.
    */
   if ((*rxCb)->msgType == MGT_MSG_RSIP && *delPeer == FALSE)
   {
      {

         if(response->rspCode.val != MGT_MGCP_RSP_CODE_PROVISIONAL)
         {
            if (response->rspCode.val != MGT_MGCP_RSP_CODE_OK)
            {
               peer->mntInfo.usrKnows = FALSE;
               *delPeer = TRUE;
            }
            else
            if (peer->state == LMG_PEER_STATE_REGISTER)
            {
#ifdef ZG_DFTHA
               /* only master should delete peer..or modify state of peer..
                  * so if Master doesn't lie on the same copy..then send reverse
                  * update to Master */
               if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
               {
                  peer->state = LMG_PEER_STATE_ACTIVE;
#ifdef ZG
               /* send update to peer */
               zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_MOD);
#endif /* ZG */
               }
#ifdef ZG_DFTHA
               /* send reverse update to Master copy ..don't queue the txn..
                  * txn will be sent to peer */
               else
               {
                  ZgRvUpdInfo   updInfo;

                  cmMemset((U8*)&updInfo, 0, sizeof(ZgRvUpdInfo));
                  /* Fill reverse update information */
                  updInfo.action  = ZG_RVUPD_RSIP_RSP_USR;
                  updInfo.u.rRspU.peerId = peer->accessInfo.peerId;
                  updInfo.u.rRspU.rspCode =response->rspCode.val;
                  /* call pldf fn to senf reverse update to Master */
                  zgReverseUpd(&updInfo, (peer->accessInfo.peerId),
                               MG_QUEUE_NONE, peer->tsap->tsapCfg.tSAPId);
               }
#endif /* ZG_DFTHA */
            } /* Response = OK */
         } /* provisional response */
      }
   }

   /* Verify that the response message has valid parameters */
   if (rspType == MG_RESPONSE)
   {
      if ((mgMgcpVerifyRspParms(msg, (*rxCb)->msgType, (*rxCb)->chkRspParam,
                                peer->mntInfo.variant)) != ROK)
      {
         *mgtError = MGT_ERR_INVALID_PARMS;
         RETVALUE(RFAILED);
      }
   }

   /* 
    * Everything is fine with response....copy the remote Address where
    * response needs to be sent
    */
   cmMemcpy((U8 *)responseAddr, (CONSTANT U8 *)&((*rxCb)->tptAddr), 
            sizeof(CmTptAddr));

   RETVALUE(ROK);
 
} /* end of mgMgcpPrcRspInTxnReq() */

/*
*
*       Fun:   mgMgcpXmitTxnReq
*
*       Desc:  This function is used for piggybacking the buffers and 
*              transmitting the buffer as appropriate
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgMgcpXmitTxnReq
(
Bool               immTx,              /* Transmit Immediately */
U8                 msgType,            /* Message Type */
MsgLen             *crntPduLen,        /* Current PDU Length */
MgPeerCb           *peer,              /* Peer Control Block */
CmTptAddr          *xmitAddr,          /* Remote Address */
Buffer             *mBuf,              /* Encoded Message Buffer */
Buffer             **concatMbuf,       /* PiggyBacked Message Buffer */
U32                *mgtError,          /* Error */
#ifdef GCP_VER_1_3
MgTptSrvr          *srvr,              /* Local Socket for Tx */
MgTxBufInfo        **txBufInfo,        /* Transmitted buffer information */
Bool               xmit,               /* Whether to transmit message */
MgTSAPCb           *tsap               /* TSAP Control Block */
#else
MgTptSrvr          *srvr,             /* Local Socket for Tx */
MgTSAPCb           *tsap               /* TSAP Control Block */
#endif /* GCP_VER_1_3 */
)
#else
#ifdef GCP_VER_1_3
PUBLIC S16 mgMgcpXmitTxnReq(immTx, msgType, crntPduLen, peer, xmitAddr, 
                            mBuf, concatMbuf, mgtError, srvr,
                            txBufInfo,xmit, tsap)
Bool               immTx;              /* Transmit Immediately */
U8                 msgType;            /* Message Type */
MsgLen             *crntPduLen;        /* Current PDU Length */
MgPeerCb           *peer;              /* Peer Control Block */
CmTptAddr          *xmitAddr;          /* Remote Address */
Buffer             *mBuf;              /* Encoded Message Buffer */
Buffer             **concatMbuf;       /* PiggyBacked Message Buffer */
U32                *mgtError;          /* Error */
MgTptSrvr          *srvr;              /* Local Socket for Tx */
MgTxBufInfo        **txBufInfo;        /* Transmitted buffer information */
Bool               xmit;               /* Whether to transmit message */
MgTSAPCb           *tsap;              /* TSAP Control Block */
#else
PUBLIC S16 mgMgcpXmitTxnReq(immTx, msgType, crntPduLen, peer, xmitAddr, 
                             mBuf, concatMbuf, mgtError, srvr, tsap)
Bool               immTx;              /* Transmit Immediately */
U8                 msgType;            /* Message Type */
MsgLen             *crntPduLen;        /* Current PDU Length */
MgPeerCb           *peer;              /* Peer Control Block */
CmTptAddr          *xmitAddr;          /* Remote Address */
Buffer             *mBuf;              /* Encoded Message Buffer */
Buffer             **concatMbuf;       /* PiggyBacked Message Buffer */
U32                *mgtError;          /* Error */
MgTptSrvr          *srvr;              /* Local Socket for Tx */
MgTSAPCb           *tsap;              /* TSAP Control Block */
#endif /* GCP_VER_1_3 */
#endif
{
   MsgLen          msgLen;             /* Current mBuf Length */
   Buffer          *newMbuf;           /* Copy of mBuf to for concatenation */

   TRC2(mgMgcpXmitTxnReq)

   *mgtError   = 0;
   newMbuf     = NULLP;

   /*
    * Since we need to keep encoded buffer copy stored for retransmission
    * cases, increment the reference count for the buffer so that on 
    * transmission even when TUCL has freed buffer, we retain a copy
    */
   if ((SAddMsgRef (mBuf, tsap->tsapCfg.memId.region, 
                    tsap->tsapCfg.memId.pool, &(newMbuf))) != ROK)
   {
      *mgtError = LCM_EVENT_DMEM_ALLOC_FAIL;
      RETVALUE(RFAILED);
   }

   /* 
    * If buffer has to be transmitted immediately i.e. it is a response or
    * a command to be sent to be a specific IP Address
    */

   if (immTx == TRUE)
   {
      MG_UPD_MGCP_PEER_TX_STS(msgType, peer->peerSts);

#ifdef    GCP_PROV_SCTP
      MG_TRANSMIT_PDU(peer, peer->assocCb, NULLP, FALSE, srvr,
                      xmitAddr, newMbuf);
#else     /* GCP_PROV_SCTP */
      MG_TRANSMIT_PDU(peer, srvr, xmitAddr, newMbuf);
#endif    /* GCP_PROV_SCTP */

      RETVALUE(ROK);
   }

   /*
    * Coming Here implies piggybacking can be done. The PDU size should not
    * be more than the specified MTU size including UDP header; Default is
    * 1500
    */
   if ((SFndLenMsg(newMbuf, &msgLen)) != ROK)
      RETVALUE(RFAILED);

   /* Check if PDU Size is less than UDP PDU size required */
   if ((*crntPduLen + msgLen) > peer->mntInfo.mtuSize)
   {
      /* 
       * If we piggyback, we will exceed MTU size..so transmit the so
       * far piggybacked buffer
       */
      if (*concatMbuf == NULLP)
      {
#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
         if ((SAddMsgRef (newMbuf, tsap->tsapCfg.memId.region, 
                 tsap->tsapCfg.memId.pool, &((*txBufInfo)->mBuf))) != ROK)
         {
            *mgtError = LCM_EVENT_DMEM_ALLOC_FAIL;
            RETVALUE(RFAILED);
         }
         *txBufInfo = NULLP;
#endif /* GCP_VER_1_3 */
#endif /* GCP_2705BIS */
         /* First buffer itself exceeds MTU size..transmit it */
         MG_UPD_MGCP_PEER_TX_STS(msgType, peer->peerSts);

#ifdef    GCP_PROV_SCTP
         MG_TRANSMIT_PDU(peer, peer->assocCb, NULLP, FALSE, srvr,
                         xmitAddr, newMbuf);
#else     /* GCP_PROV_SCTP */
         MG_TRANSMIT_PDU(peer, srvr, xmitAddr, newMbuf);
#endif    /* GCP_PROV_SCTP */

         /* Reinitialise crntPduLen */
         *crntPduLen = MG_UDP_HDR_LEN;
         RETVALUE(ROK);
      }
      else
      {
#ifdef GCP_2705BIS
         /* Only if xmit is true.. transmit message..if xmit is not TRUE ( means
          * txCb is queued )..still we need to do piggybacking */
         if(xmit == TRUE)
         {
            if ((SAddMsgRef (*concatMbuf, tsap->tsapCfg.memId.region, 
                tsap->tsapCfg.memId.pool, &((*txBufInfo)->mBuf))) != ROK)
            {
               *mgtError = LCM_EVENT_DMEM_ALLOC_FAIL;
               RETVALUE(RFAILED);
            }
            *txBufInfo = NULLP;
         }
         else
         {
            /* No need to free *concatMbuf */
            (*txBufInfo)->mBuf = *concatMbuf;
            *concatMbuf = NULLP;
         }
         if(xmit == TRUE)
#endif
         {
            /* 
            * Transmit the previous piggybacked buffer and keep current buffer 
            * for piggybacking with crntPduLen adjusted appropriately
            */
#ifdef    GCP_PROV_SCTP
            MG_TRANSMIT_PDU(peer, peer->assocCb, NULLP, FALSE,
                            srvr, xmitAddr, *concatMbuf);
#else     /* GCP_PROV_SCTP */
            MG_TRANSMIT_PDU(peer, srvr, xmitAddr, *concatMbuf);
#endif    /* GCP_PROV_SCTP */

         }
         *concatMbuf = newMbuf;
         *crntPduLen = msgLen + MG_UDP_HDR_LEN;
         MG_UPD_MGCP_PEER_TX_STS(msgType, peer->peerSts);
         RETVALUE(ROK);
      }
   }

   /* Coming here implies, current buffer for piggybacked */
   if (*concatMbuf == NULLP)
   {
      /* First buffer */
      MG_UPD_MGCP_PEER_TX_STS(msgType, peer->peerSts);
      *concatMbuf  = newMbuf;
      *crntPduLen += msgLen;
   }
   else
   {
      Data     msgSeparator[2] = {'.', '\n'};

      /* Add a message separator between buffers */
      if ((SAddPstMsgMult(msgSeparator, MG_MGCP_MSG_SEPARATOR_SZ,
                          *concatMbuf)) != ROK)
      {
         RETVALUE(RFAILED);
      }

      /* Increment crntPduLen by separator length */
      *crntPduLen += MG_MSG_SEPARATOR_LEN;

      /* Concatenate newMbuf with concatenated buffer */
      if ((SCatMsg((*concatMbuf), newMbuf, M1M2)) != ROK)
         RETVALUE(RFAILED);

      /* Update Statistics and crntPduLen */
      MG_UPD_MGCP_PEER_TX_STS(msgType, peer->peerSts);
      *crntPduLen += msgLen;

      /* Free the newMbuf */
      mgPutMsg(newMbuf);
   }

   RETVALUE(ROK);
 
} /* end of mgMgcpXmitTxnReq() */

/*
*
*       Fun:   mgMgcpVerifyCmdParms
*
*       Desc:  This function checks parameter combination of MGCP Command
*
*       Ret:   ROK     - SUCCESS
*              RFAILED - FAILED
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/

/*
 * Added a new parameter rspCode for function mgMgcpVerifyCmdParms
 */
#ifdef ANSI
PRIVATE S16 mgMgcpVerifyCmdParms
(
U32                variant,            /* Protocol Variant */
MgMgcpMsg          *msg,               /* MGCP Message */
U32                *rspCode            /* Error code */
)
#else
PRIVATE S16 mgMgcpVerifyCmdParms(variant, msg, rspCode)
U32                variant;            /* Protocol Variant */
MgMgcpMsg          *msg;               /* MGCP Message */
U32                *rspCode;           /* Error code */
#endif
{
   U16             loopIdx;            /* Loop Index */
   U16             numParam;           /* Number of Parameters */
   U16             numMandatory;       /* Number of Mandatory Parameters */
   U8              msgType;            /* Message Type */
   U8              paramType;          /* Parameter Type */
   U8              variantIdx;         /* Variant Index */
   Bool            rqstdEvntPrsnt;     /* Requested Event is present ? */
   Bool            reqIdPrsnt;         /* Request Identifier is present ? */
   Bool            chkMandatory;       /* Check Mandatory Parameters */
   MgMgcpParam     *param;             /* MGCP Parameters */
   MgMgcpCmd       *cmd;               /* Command */

   TRC2(mgMgcpVerifyCmdParms)

   msgType = msg->msgType.val;

   /* Command to be picked from union should be based on msgType */
   if (msgType == MGT_MSG_NONSTD)
      cmd  = &(msg->t.nonStdCmd.cmd);
   else
      cmd  = &(msg->t.epcfCmd);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Do checking of the flags first */
   if ((msg->msgType.pres == NOTPRSNT) || 
       (cmd->pres.pres == NOTPRSNT)) 
   {
      /* Initilize error response code. */
      *rspCode = MGT_MGCP_RSP_CODE_PROT_ERROR;
      MGLOGERROR(ERRCLS_INT_PAR, EMG031, 0,
               "[MGCP] mgMgcpVerifyCmdParms: Improper Message Flags \n");
      RETVALUE(RFAILED);
   }

   /* Verify if MGCP Command Line is alright */
   if ((cmd->cmdLine.pres.pres == NOTPRSNT) ||
       (cmd->cmdLine.trId.pres == NOTPRSNT) ||
       (cmd->cmdLine.trId.val == 0) ||
       (cmd->cmdLine.epName.pres.pres == NOTPRSNT) ||
       (cmd->cmdLine.epName.lclName.pres == NOTPRSNT) ||
       (cmd->cmdLine.epName.domainName.pres == NOTPRSNT))
   { 
      /* Initilize error response code. */
      *rspCode = MGT_MGCP_RSP_CODE_PROT_ERROR;
      MGLOGERROR(ERRCLS_INT_PAR, EMG032, 0,
               "[MGCP] mgMgcpVerifyCmdParms: Improper Command Line \n");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR) */

   if ((cmd->cmdLine.mgcpVer.pres.pres == NOTPRSNT)  ||
       (cmd->cmdLine.mgcpVer.major.pres == NOTPRSNT) ||
       (cmd->cmdLine.mgcpVer.minor.pres == NOTPRSNT) ||
       (cmd->cmdLine.mgcpVer.major.val != 1) ||
       (cmd->cmdLine.mgcpVer.minor.val != 0))
   {
      /* Initilize error response code. */
      *rspCode = MGT_MGCP_RSP_CODE_PROT_VER_ERROR;
      MGLOGERROR(ERRCLS_INT_PAR, EMG033, 0,
               "[MGCP] mgMgcpVerifyCmdParms: Incorrect Version\n");
      RETVALUE(RFAILED);
   }

   if (msgType == MGT_MSG_NONSTD)
      RETVALUE(ROK);

   /* Initialise */
   numParam       = cmd->params.numParam.val;
   rqstdEvntPrsnt = FALSE;
   reqIdPrsnt     = FALSE;

   /*
    * Rather than subtracting the variant to obtain index, use if
    * conditions.
    */
   if(LMG_VER_PROF_MGCP_RFC2705_1_0 == variant)
      variantIdx = MG_RFC2705_PROF_IDX;
   else if (LMG_VER_PROF_MGCP_NCS_1_0 == variant)
      variantIdx = MG_NCS_PROF_IDX;
   else if (LMG_VER_PROF_MGCP_TGCP_1_0 == variant)
      variantIdx = MG_TGCP_PROF_IDX;
   else
      RETVALUE(RFAILED);

   numMandatory   = mgNmbMandPerCmd[variantIdx][msgType];

   if (numMandatory > MG_NONE)
      chkMandatory = TRUE;       /* Check Mandatory Parameters */
   else
      chkMandatory = FALSE;      /* Don't Check */
      
   /* Go through each parameter and validate it */
   for (loopIdx = 0; loopIdx < numParam; loopIdx++)
   {
      param = (cmd->params.param[loopIdx]);

      if (param == NULLP)
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
          MGLOGERROR(ERRCLS_INT_PAR, EMG034, 0,
                     "[MGCP] mgMgcpVerifyCmdParms: NULL Param Pointer \n");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         /* Initilize error response code. */
         *rspCode = MGT_MGCP_RSP_CODE_PROT_ERROR;
          RETVALUE(RFAILED);
      }

      paramType = param->paramType.val;

      switch(mgCmdDb[variantIdx][msgType][paramType])
      {
         case MG_FORBIDDEN_PARM:
         {
            if (param->paramType.pres != NOTPRSNT)
            {
               /* Initilize error response code. */
               *rspCode = MGT_MGCP_RSP_CODE_PROT_ERROR;
               RETVALUE(RFAILED);
            }
         }
         break;

         case MG_MANDATORY_PARM:
         {
            if (param->paramType.pres == NOTPRSNT)
            {
               /* Initilize error response code. */
               *rspCode = MGT_MGCP_RSP_CODE_PROT_ERROR;
               RETVALUE(RFAILED);
            }

            /* Decrement the numMandatory count...*/
            numMandatory--;

         }
         break;

         case MG_OPTIONAL_PARM:
         {
            /* Note the presence of Requested Events */
            if (param->paramType.pres != NOTPRSNT &&
                paramType == MGT_PARAM_RQSTD_EVENT)
            {
               rqstdEvntPrsnt = TRUE;
            }
         }
         break;

         case MG_CONDITIONAL_PARM:
         {
            /* Note the presence of Request Identifier */
            if (param->paramType.pres != NOTPRSNT &&
                paramType == MGT_PARAM_RQSTID)
            {
               reqIdPrsnt = TRUE;
            }
         }
         break;

         default:
         {

#if (ERRCLASS & ERRCLS_DEBUG)
            MGLOGERROR(ERRCLS_DEBUG, EMG035, 0,
                      "[MGCP] mgMgcpVerifyCmdParms: Unknown Parameter \n");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

            /* Initilize error response code. */
            *rspCode = MGT_MGCP_RSP_CODE_PROT_ERROR;
            RETVALUE(RFAILED);
         }

      } /* end of switch */

   } /* end of for loop */


   /* Check if all mandatory parameters were found */
   if ((chkMandatory == TRUE) && (numMandatory != MG_NONE))
   {
      /* Initilize error response code. */
      *rspCode = MGT_MGCP_RSP_CODE_PROT_ERROR;
      RETVALUE(RFAILED);         /* Mandatory parameter missing */
   }

   /*
    * Presence of Requested  Event in CRCX, MDCX or DLCX indicates embedded
    * RQNT for which Request Identifier should be mandatorily present
    */
   if (msgType == MGT_MSG_CRCX || msgType == MGT_MSG_MDCX ||
       msgType == MGT_MSG_DLCX)
   {
      if (rqstdEvntPrsnt == TRUE && reqIdPrsnt == FALSE)
      {
         /* Initilize error response code. */
         *rspCode = MGT_MGCP_RSP_CODE_PROT_ERROR;
         RETVALUE(RFAILED);
      }
   }

   /* Check for SDP Information - it is forbidden for all except CRCX/MDCX */
   if (((msgType !=  MGT_MSG_CRCX) && (msgType != MGT_MSG_MDCX)))
   {
      if (cmd->sdpInfo.numComp.pres != NOTPRSNT ||
          cmd->sdpInfo.numComp.val  != MG_NONE)
      {
         /* Initilize error response code. */
         *rspCode = MGT_MGCP_RSP_CODE_PROT_ERROR;
         RETVALUE(RFAILED);
      }
   }
   
   /* SDP Parameter validation is done by encode/decode engine */

   RETVALUE(ROK);

} /* end of mgMgcpVerifyCmdParms() */

/*
*
*       Fun:   mgMgcpVerifyRspParms
*
*       Desc:  This function checks parameter combination of MGCP 
*              Acknowledgement
*
*       Ret:   ROK     - SUCCESS
*              RFAILED - FAILED
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE S16 mgMgcpVerifyRspParms
(
MgMgcpMsg          *msg,               /* MGCP Message */
U8                 msgType,            /* Message Type */
Bool               chkRspParam,        /* Check Response Parameter */
U32                variant             /* Protocol Variant */
)
#else
PRIVATE S16 mgMgcpVerifyRspParms(msg, msgType, chkRspParam, variant)
MgMgcpMsg          *msg;               /* MGCP Message */
U8                 msgType;            /* Message Type */
Bool               chkRspParam;        /* Check Response Parameter */
U32                variant;            /* Protocol Variant */
#endif
{
   U16             loopIdx;            /* Loop Index */
   U16             numParam;           /* Number of Parameters */
   U8              paramType;          /* Parameter Type */
   Bool            connIdPrsnt;        /* Connection Id is present ? */
   U8              variantIdx;         /* Variant Index */
   MgMgcpParam     *param;             /* MGCP Parameters */
   MgMgcpRsp       *rsp;               /* Command */
   Bool            connParamPrsnt;     /* Connection Parameters Present */

   TRC2(mgMgcpVerifyRspParms)

   rsp = &(msg->t.mgcpRsp);

   /* Do checking of the flags first */
   if ((msg->msgType.pres == NOTPRSNT) || (rsp->pres.pres == NOTPRSNT)||
       (rsp->trId.pres == NOTPRSNT) || (rsp->rspCode.pres == NOTPRSNT))
   {
      RETVALUE(RFAILED);
   }

   if ((msgType == MGT_MSG_NONSTD)
#ifdef GCP_PKG_MGCP_BASE
                ||
       (msgType == MGT_MSG_MESG)
#endif /* GCP_PKG_MGCP_BASE */
      )
      RETVALUE(ROK);

   if (rsp->params.numParam.pres != NOTPRSNT)
   {
      numParam      = rsp->params.numParam.val;
   }
   else
   {
      numParam = 0;
   }
      
   /* Initialise variables */
   connIdPrsnt    = FALSE;
   connParamPrsnt = FALSE;

   /* Use LMG_VER_PROF_MGCP_RFC2705_1_0 as base variant */
   variantIdx     = (U8) (variant - LMG_VER_PROF_MGCP_RFC2705_1_0);

   /* Validate each of the parameters present */
   for (loopIdx = 0; loopIdx < numParam; loopIdx++)
   {
      param = (rsp->params.param[loopIdx]);

#if (ERRCLASS & ERRCLS_INT_PAR)
      if (param == NULLP)
      {
          MGLOGERROR(ERRCLS_INT_PAR, EMG036, 0,
                     "[MGCP] mgMgcpVerifyRspParms: NULL Param Pointer \n");
          RETVALUE(RFAILED);
      }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      paramType = param->paramType.val;

      switch(mgRspDb[variantIdx][msgType][paramType])
      {
         case MG_FORBIDDEN_PARM:
         {
            if (param->paramType.pres != NOTPRSNT)
               RETVALUE(RFAILED);
         }
         break;

         case MG_MANDATORY_PARM:
         {
            if (param->paramType.pres == NOTPRSNT)
               RETVALUE(RFAILED);
         }
         break;

         case MG_OPTIONAL_PARM:
         {
            /* skip */
         }
         break;

         case MG_CONDITIONAL_PARM:
         {
            /* Note the presence of Connection Id */
            if (param->paramType.pres != NOTPRSNT &&
                paramType == MGT_PARAM_CONNID)
            {
               connIdPrsnt = TRUE;
            }
            /* Check for ConnParams */
            else
            if (param->paramType.pres != NOTPRSNT &&
                paramType == MGT_PARAM_CONN_PARAM)
            {
               connParamPrsnt = TRUE;
            }

         }
         break;

         default:
         {

#if (ERRCLASS & ERRCLS_DEBUG)
            MGLOGERROR(ERRCLS_DEBUG, EMG037, 0,
                      "[MGCP] mgMgcpVerifyRspParms: Unknown Parameter \n");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

            RETVALUE(RFAILED);
         }

      } /* end of switch */

   } /* end of for loop */

   /*
    * If message type was CRCX and Response Code is success then ConnId is 
    * mandatory...verify that
    */


   if (msgType == MGT_MSG_CRCX)
   {
      if ((rsp->rspCode.val == MGT_MGCP_RSP_CODE_OK) && (connIdPrsnt != TRUE))
      {
         RETVALUE(RFAILED);
      }

      /*
       * For CRCX response, SDP parameters are not required for data 
       * connections; hence don't make any mandatory presence checking of SDP
       */
   }

   /* 
    * For DLCX Response from MG, Conn Params should
    * be mandatorily present if connection Id was present in DLCX
    */
   /*
    * Check for connectionParams in DLCX response only for a positive response
    */
   if (MGT_MGCP_RSP_CODE_OK == rsp->rspCode.val) 
   {
      if (msgType == MGT_MSG_DLCX && chkRspParam == TRUE)
      {
         /* 
          * Currently there is check only for transmission of response ..so
          * if we are MG side..check connParam have been filled
          */
         if (connParamPrsnt == FALSE)
            RETVALUE(RFAILED);
      }
   }

   /* SDP Information is forbidden for all except CRCX, MDCX, AUCX */
   if ((msgType != MGT_MSG_CRCX) && (msgType != MGT_MSG_MDCX) &&
       (msgType != MGT_MSG_AUCX))
   {
      if (rsp->sdpInfo.numComp.pres != NOTPRSNT)
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of mgMgcpVerifyRspParms() */


/*
*
*       Fun:   mgMgcpCopyNotifyEntityForTx
*
*       Desc:  This function fills notified entity in a message if needed
*              also if the message is ntfy sets the destination addr for xmit
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC Void mgMgcpCopyNotifyEntityForTx
(
Bool               *ntfyIsIpAddr,      /* Notified Entity is IP Address */
MgMgcpMsg          *msg,               /* MGCP Message */
MgPeerCb           *peer,              /* peer for this request */
MgTptSrvr          *lstnrCb,           /* Listener Control Block */
CmTptAddr          *remAddr            /* destination address to send ntfy */
)
#else
PUBLIC Void mgMgcpCopyNotifyEntityForTx(ntfyIsIpAddr, msg, peer, lstnrCb, remAddr)
Bool               *ntfyIsIpAddr;      /* Notified Entity is IP Address */
MgMgcpMsg          *msg;               /* MGCP Message */
MgPeerCb           *peer;              /* peer for this request */
MgTptSrvr          *lstnrCb;           /* Listener Control Block */
CmTptAddr          *remAddr;           /* destination address to send ntfy */
#endif
{
   MgMgcpParam     *param;             /* MGCP Parameters */

   TRC2(mgMgcpCopyNotifyEntityForTx)

   param         = NULLP;
   *ntfyIsIpAddr = FALSE;

   /* look for the presence of notified entity */
   param = mgMgcpFindParamTypeInMsg(MGT_PARAM_NTFIED_ENT, msg);

   /* 
    * If notified entity is not specified by the Service User we shouldn't 
    * fill notified entity as anything as we may end up overwriting the 
    * previously specified actual notfied entity for the endpoint in the MG
    */
   if (param == NULLP)       
   {
      /* Notified entity is not specified by Service users */
      RETVOID;  
   }

   /*
    * if we are MG side, only then we need to send NTFY and DLCX to notified
    * entity, else return
    */
   if (mgCb.genCfg.entType == LMG_ENT_GC)
      RETVOID;

   /* 
    * if we are sending the ntfy message set the remoteAddr to notified entity
    */
   if((msg->msgType.val == MGT_MSG_NTFY) || (msg->msgType.val == MGT_MSG_DLCX))
   {
      CmNetAddr    ipAddr;
      U8           *domainName = param->t.ntfiedEnt.domainName.val;

      /*
       * Fill the port number if specified; else pick default 
       */
      if(param->t.ntfiedEnt.port.pres == PRSNT_NODEF)
      {
         /* copy IPV4/IPV6 port */
         MG_FILL_TPTADDR_PORT(remAddr, param->t.ntfiedEnt.port.val);
      }
      else
      if((param->t.ntfiedEnt.port.pres == NOTPRSNT) && 
         (remAddr->type == CM_TPTADDR_NOTPRSNT))
      {
         /* copy IPV4/IPV6 port */
         MG_FILL_TPTADDR_PORT(remAddr,peer->accessInfo.remotePort);
      }

      /*
       * If domain name is "name" get the IP Address
       */
      if (param->t.ntfiedEnt.domainName.pres == PRSNT_NODEF)
      {
         if (domainName[0] != '#' && domainName[0] != '[')
         {
            MgDName   dname;
            MgPeerCb  *ntfyEnt = NULLP;

            ntfyEnt = mgRslvDomainNameStr(param->t.ntfiedEnt.domainName.len,
                                          domainName, &dname);
            if (ntfyEnt != NULLP)
            {
               /* copy IPV4/IPV6 structure */
               MG_FILL_TPTADDR_FRM_NETADDR(remAddr, 
                       &(ntfyEnt->accessInfo.peerAddrTbl.netAddr[0]));
            }
         }
         else
         {
            if ((mgGetIpAddrFromDomainNameStr(param->t.ntfiedEnt.domainName.len,
                             domainName, &ipAddr, LMG_PROTOCOL_MGCP)) == ROK)
            {
               *ntfyIsIpAddr = TRUE;
               /* copy IPV4/IPV6 structure */
               MG_FILL_TPTADDR_FRM_NETADDR(remAddr, &ipAddr);
            }
         }
      }
   }

   RETVOID;

} /* end of mgMgcpCopyNotifyEntityForTx () */


/*
*
*       Fun:   mgMgcpFindParamTypeInMsg
*
*       Desc:  This function locates Specified Parameter in a message
*
*       Ret:   Pointer to MgMgcpParam - SUCCESS; NULLP - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE MgMgcpParam * mgMgcpFindParamTypeInMsg
(
U8                 paramType,          /* Parameter Type */
MgMgcpMsg          *msg                /* MGCP Message to be checked */
)
#else
PRIVATE MgMgcpParam * mgMgcpFindParamTypeInMsg (paramType, msg)
U8                 paramType;          /* Parameter Type */
MgMgcpMsg          *msg;               /* MGCP Message to be checked */
#endif
{
   U16             loopIdx;            /* Loop Index */
   MgMgcpParam     *param;             /* MGCP Parameters */
   MgMgcpParamSet  *paramSet;          /* MGCP Parameters */

   TRC2(mgMgcpFindParamTypeInMsg)

   paramSet = NULLP;
   param    = NULLP;

   switch(msg->msgType.val)
   {
      case MGT_MSG_NONSTD:
      case MGT_MSG_EPCF:
      case MGT_MSG_CRCX:
      case MGT_MSG_MDCX:
      case MGT_MSG_DLCX:
      case MGT_MSG_RQNT:
      case MGT_MSG_NTFY:
      case MGT_MSG_AUEP:
      case MGT_MSG_AUCX:
      case MGT_MSG_RSIP:
      {
         paramSet = &(msg->t.crcxCmd.params);
         break;
      }

      case MGT_MSG_RSP:
      {
         paramSet = &(msg->t.mgcpRsp.params);
         break;
      }

      default:
         RETVALUE(NULLP);
   }

   if (paramSet->numParam.pres != NOTPRSNT)
   {
      for (loopIdx = 0; loopIdx < paramSet->numParam.val; loopIdx++)
      {
         param = (paramSet->param[loopIdx]);

         if (param->paramType.val != paramType)
         {
            param = NULLP;
            continue;
         }
         else
           break;
      }
   }

   RETVALUE(param);

} /* end of mgMgcpFindParamTypeInMsg () */


/******************************************************************************/
/*                      Lower Interface Functions                             */
/******************************************************************************/

/*
*
*       Fun:   mgDecodeMgcpTxn
*
*       Desc:  This function decodes the message buffer received from network.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or an acknowledgement or
*              acknowledgements for acknoledgements transmitted
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgDecodeMgcpTxn
(
MgMgcpTxn          *txn,               /* MGCP Txn */
Buffer             *mBuf,              /* Message Buffer */
CmTptAddr          *srcAddr,           /* source address */
Bool               *genStaInd,         /* whether to generate status ind */
MgTSAPCb           *tsap               /* TSAP Control Block */
)
#else
PUBLIC S16 mgDecodeMgcpTxn(txn, mBuf, srcAddr, genStaInd, tsap)
MgMgcpTxn          *txn;               /* MGCP Txn */
Buffer             *mBuf;              /* Message Buffer */
CmTptAddr          *srcAddr;           /* source address */
Bool               *genStaInd;         /* whether to generate status ind */
MgTSAPCb           *tsap;              /* TSAP Control Block */
#endif
{
   MsgLen          numDecBytes;        /* Number of decoded bytes */
   CmAbnfErr       err;                /* Error */
   CmAbnfDecOff    offset;             /* DBUF offset information */
   S16             ret;                /* return value */
   MsgLen          msgLen;             /* message length */
   MgMgcpMsg       *mgcpMsg;


   TRC2(mgDecodeMgcpTxn)

   /*
    * Decoding Engine decodes messages one by one. So, at the end of a message
    * decoding engine returns control to us and we have the responsibility
    * of removing message separator and summoning decode engine for rest of the
    * mBuf decoding. Also in the event of error in decoding, it is our 
    * responsibility to remove bytes from message till message separator is
    * reached and handover mBuf to decode engine with read pointer at beginning
    * of next message
    */

   /* Initialize the decode control point */
   cmMemset((U8 *)&offset, (U8)0, (PTR)sizeof(CmAbnfDecOff));


   ret = ROK;

   /* While buffer has more than message separator, decode */
   while ((MG_GET_MSGLEN(mBuf, msgLen)) > MG_MIN_MSGLEN)
   {
      /* allocate memory for the message here */
      if(ROK != mgAllocEventMem((Ptr *)&(txn->mgcpMsg[txn->numMsg]), 
                          sizeof(MgMgcpMsg))) 
      {
         *genStaInd = TRUE;
         break;
      }

      /* Store the message pointer */
      mgcpMsg = txn->mgcpMsg[txn->numMsg];

      if ((cmAbnfDecPduMsg(CM_ABNF_PROT_MGCP_RFC2705,
                           &mgcpMsg->memCp, (U8 *)&(mgcpMsg->msgType), mBuf, 
                           &mgMsgDef, &numDecBytes, &offset, &err)) != ROK)
      {
         if (mgcpMsg->msgType.pres == PRSNT_NODEF &&
             mgcpMsg->msgType.val != MGT_MSG_RSP)
         {
            MgTransId       trId;
            /* Get transaction id */
            MG_MGCP_GET_TRANSID(mgcpMsg, trId);
            mgMgcpSendErrorResponse(srcAddr, trId, 
                                    MGT_MGCP_RSP_CODE_PROT_ERROR, 
                                    (U8 *)"Decoding of the Command Failed",
                                    tsap);
         }
          

         /*
          * free the SDP Tkn Buf
          */
#ifdef CM_SDP_OPAQUE
         mgMgcpFreeAllTkBfs(mgcpMsg);
#endif /* CM_SDP_OPAQUE */

         /* Free the message that was produced error */
         mgFreeEventMem((Ptr) &mgcpMsg->memCp);
      }
      else
         txn->numMsg++;

      if ((mgRemoveBytesTillSeparator(&numDecBytes, &offset)) == ROKDNA)
        break;
   } /* end of while */
   RETVALUE(ret);
} /* mgDecodeMgcpTxn*/

/*
*
*       Fun:   mgPrcMgcpTxnInd
*
*       Desc:  This function decodes the message buffer received from network
*              and processes the transactions received and indicater to user
*              the received transactions
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or an acknowledgement or
*              acknowledgements for acknoledgements transmitted
*
*              For consistency purposes, AssocCb is being passed to this
*              function. AssocCb will ofcourse be NULLP since MGCP does
*              not use SCTP. However, this defines the basic framework for
*              future SCTP support.
*
*       File:  mg_cord.c
*
*/


#ifdef ANSI
PUBLIC S16 mgPrcMgcpTxnInd
(
MgTSAPCb           *tsap,              /* TSAP Control Block */
MgTptSrvr          *srvr,              /* Listener Control Block */
CmTptAddr          *srcAddr,           /* Source Transport Address */
Buffer             *mBuf,              /* Message Buffer */
MgMgcpTxn          *txn,               /* MGCP txn */    
MgPeerCb           *peerCb             /* peer control block */
)
#else
PUBLIC S16 mgPrcMgcpTxnInd (tsap, srvr, srcAddr, mBuf, txn, peerCb)
MgTSAPCb           *tsap;              /* TSAP Control Block */
MgTptSrvr          *srvr;              /* Listener Control Block */
CmTptAddr          *srcAddr;           /* Source Transport Address */
Buffer             *mBuf;              /* Message Buffer */
MgMgcpTxn          *txn;               /* MGCP txn */    
MgPeerCb           *peerCb;            /* peer control block */
#endif
{
   S16             ret;                /* Return Value */
   S16             errAction;          /* Action to be taken on error */
   Bool            genStaInd;          /* Generate Status Indication */
   Bool            genTrcInd;          /* Generate Trace Indication */
   Bool            regOk;              /* Registration Ok */
   MgMgcpTxn       *txnForUsr;         /* Received Transaction */
   MgMgcpMsg       *mgcpMsg;           /* MGCP Message */
   MgPeerCb        *peer;              /* Peer Control Block */
   U32             rspCode;            /* Action */
   U32             variant;            /* Variant Information */
   U16             loopIdx;            /* loopIndex */
#ifdef ZG_DFTHA
   CmFthaRsetId    rsetId;             /* resource set id */
   U32             transId;            /* Transaction Identifier */
#endif /* ZG_DFTHA */
   U8              encodingScheme;

   TRC2(mgPrcMgcpTxnInd)

   /* Initialise variables */
   mgcpMsg   = NULLP;
   genStaInd = FALSE;
   genTrcInd = TRUE;
   regOk     = FALSE;
   errAction = MGT_NONE;

   peer = peerCb;

   (void)encodingScheme;
   if(txn == NULLP)
   {
      /* Allocate a transaction structure to be passed to user */
      if(ROK != mgAllocEventMem((Ptr *)&txnForUsr, sizeof(MgMgcpTxn))) 
      {
         /* Discard Transaction */
         mgPutMsg(mBuf);
         RETVALUE(RFAILED);
      }
      txnForUsr->numMsg = 0;
   }
   else
      txnForUsr = txn;


   rspCode = MG_NONE;

   /* Now decode txn , if mBuf is not NULLP then we have to decode it*/
   if(mBuf != NULLP)
   {
#ifdef CM_ABNF_MT_LIB
      U32    prot;       /* protocol variant */
      prot = CM_ABNF_PROT_MGCP_RFC2705; 
      /* send Decode request to ED instances */
      encodingScheme = LMG_ENCODE_TXT;/*MAH_TODO initing to txt */
      if(srvr)
         encodingScheme = srvr->encodingScheme;
      ret = mgSndDecPduMsgReq(encodingScheme ,srvr->suConnId,
                              prot,
                              mBuf,
                              srcAddr,
                              txnForUsr,
                              tsap
#ifdef    GCP_PROV_SCTP
                              ,NULLP
#endif    /* GCP_PROV_SCTP */
                              );
      RETVALUE(ret);
#else /* CM_ABNF_MT_LIB */
      ret = mgDecodeMgcpTxn(txnForUsr, mBuf, srcAddr, &genStaInd, tsap);
      if(ret != ROK)
      {
         mgPutMsg(mBuf);
         MG_FREE_MGCP_EVNT_MEM(txnForUsr, TRUE);
         RETVALUE(RFAILED);
      }
#endif  /*CM_ABNF_MT_LIB */
   }
      
   if (mBuf != NULLP)
   {
      mgPutMsg(mBuf);
   }

   /* Now process each Txn one by one */
   for(loopIdx = 0;loopIdx < txnForUsr->numMsg; loopIdx++)
   {
      /* Store the message pointer */
      mgcpMsg = txnForUsr->mgcpMsg[loopIdx];
#ifdef ZG_DFTHA
      /* Check if this transaction is meant for this non critical resource set 
       * if yes, then process it else call PLDF function to route this message 
       * to proper copy */
      MG_MGCP_GET_TRANSID(mgcpMsg, transId);
      if(!zgChkNCRsetStatus(transId, LMG_PROTOCOL_MGCP,
            peer, (mgcpMsg->msgType.val), MG_TRANS_TYPE_RX, 
            srvr->suRsetId, NULLP, 0))
      {
         U32   peerId;
         peerId = MG_INVALID_PEERID;
         if(peer != NULLP)
            peerId = peer->accessInfo.peerId;
         zgPldfSendGcpMsg(srvr->suConnId,srcAddr, loopIdx,
                          (PTR)txnForUsr, peerId, tsap->tsapCfg.tSAPId);
         /* no need of freeing this mgcpMsg as this will be freed in PSF while
          * packing the txn */
         txnForUsr->mgcpMsg[loopIdx] = NULLP;
         continue;
      }  
      /* 
       * Call PSF fn to obatin rset id ..and pass that in txn..which will be
       * bounced back by service user 
       */ 
      rsetId = zgObtainRsetId(srvr->suRsetId, (PTR)txn, loopIdx);
      mgcpMsg->rsetId = rsetId;
#endif /* ZG_DFTHA */

      if ((ret = mgMgcpPrcDecodedTxn (&errAction, &rspCode, txnForUsr, &peer, 
                                 srvr, srcAddr, loopIdx, tsap)) == ROK)
      {
         if (rspCode == MG_REGISTER_RSP_OK)
         {
            /* 
             * Free the message pointer; We don't need to convey the response
             * to RSIP generated by us to the Service User
             */ 
            rspCode = MG_NONE;
            regOk   = TRUE;
            variant = peer->mntInfo.variant;

            /*
             * free the SDP Tkn Buf
             */
#ifdef CM_SDP_OPAQUE
            mgMgcpFreeAllTkBfs(mgcpMsg);
#endif /* CM_SDP_OPAQUE */

            mgFreeEventMem((Ptr) &mgcpMsg->memCp);
            txnForUsr->mgcpMsg[loopIdx] = NULLP;
         }

      } 
      else if(ret == RFAILED)
      {
         if (errAction == MG_DELETE_PEER_PASS_TXN)
            break;
         /*
          *   IF RESOURCE UNAVAILABLE - SEND ERROR RESPONSE
          */
         if (rspCode != MG_NONE)
         {

            if (mgcpMsg->msgType.pres == PRSNT_NODEF &&
                  mgcpMsg->msgType.val != MGT_MSG_RSP)
            {
               MgTransId       trId;
               MG_MGCP_GET_TRANSID(mgcpMsg,trId);
               mgMgcpSendErrorResponse(srcAddr, trId, rspCode, 
                                       (U8 *)"Decoding of the Command Failed",
                                       tsap);
            }

            /* Update response code */
            rspCode = MG_NONE;
         }


         /*
          * free the SDP Tkn Buf
          */
#ifdef CM_SDP_OPAQUE
         mgMgcpFreeAllTkBfs(mgcpMsg);
#endif /* CM_SDP_OPAQUE */

         /* Free the message that was produced error */
         mgFreeEventMem((Ptr) &mgcpMsg->memCp);
         txnForUsr->mgcpMsg[loopIdx] = NULLP;

         if (errAction == MG_DISCARD_TXN)
               break;
      }
#ifdef ZG_DFTHA
      else if(ret == ROKDNA)
      {
         /* This is the case when reverse update was generated to MAster copy
            * now queue the txn */
         MgMgcpTxn     *newTxn;  /* new transaction */
         MgRvUpdQNode  *queue;  /* Queue where txn will be queued */
         U16            cnt;     /* counter */

         /* Allocate memory for this new txn */
         ret = mgAllocEventMem( (Ptr *)&(newTxn), sizeof(MgMgcpTxn));
         /* copy content of old txn to new txn */
         MG_MGCP_COPY_EVNT_STRUCT(txnForUsr, newTxn);
         newTxn->numMsg = 0;
         /* Copy all the remaining txn into newtxn */
         for(cnt=loopIdx; cnt < txnForUsr->numMsg; cnt ++)
         {
            newTxn->mgcpMsg[cnt-loopIdx] = txnForUsr->mgcpMsg[cnt];
            newTxn->numMsg++;
            txnForUsr->mgcpMsg[cnt] = NULLP;
         }
         /* if peer is unknown then put Tsap reverse upd queue else put 
         * this in to link list "peerTxnQ" (present in peerCb) */
         if(peer == NULLP)
            queue = &(tsap->rvUpdQ);
         else
            queue = &(peer->peerTxnQ);

         mgQueueRvUpdTxnInd(newTxn, queue, tsap->rvNode,
                            LMG_PROTOCOL_MGCP, srcAddr, srvr);
        /* Since all the txn following this message has been queued so break
          * from this for loop */
         break;
      }
#endif /* ZG_DFTHA */
   } /* end of for loop */


   if (regOk == TRUE)
   {
      /* 
       * Implies GCP layer initiated registration request is successfully done 
       * so inform Service User
       */
      mgGenUserStaInd(peer, peer->ssap, MGT_STATUS_MGCP_VER, (Ptr)&variant);
   }

   /* Now remove empty txns..some of the txn while processing..might have been
    * sent to some other copy ( via PLDF)..so  adjust those */
   if ((ret = mgRmvEmptyTxn((Ptr)txnForUsr, LMG_PROTOCOL_MGCP))== RFAILED)
   {
      MG_FREE_MGCP_EVNT_MEM(txnForUsr, TRUE);
#ifdef ZG 
      zgUpdPeer();
#ifdef ZG_DFTHA
      /* In case of DFTHA .. there may be some reverse update generated to
       * master. Txn will be sent to user after receiving updtae from Master. 
       * In this case message is queued and mgcpMsg may not contain txns.*/
      ret = ROK;
#endif /* ZG_DFTHA */
#endif /* ZG */
      RETVALUE(ret);
   }

   if (txnForUsr->numMsg > MG_NONE)
   {
      peer->mntInfo.usrKnows = TRUE;

      /* Copy Local Peer Information */
      /* Use the MGCP specific macro */
      MG_COPY_PEERINFO_INTO_MGCPTXN(txnForUsr->mgLclInfo, peer);

      /* Pass the transactions to the service user */
      MgUiMgtMgcpTxnInd (&(peer->ssap->suPst), peer->ssap->suId, txnForUsr);
   }
   else
   {
      /* free the txn */
      MG_FREE_MGCP_EVNT_MEM(txnForUsr, TRUE);
   }

   if (rspCode == MG_REGISTER_SENT)
   {
      /* 
       * Implies new RSIP was sent...remove all transactions associated
       * with this MGC
       */
      mgRemoveAllTxn(MGT_ERR_REGISTER_FAILED, peer);
   }

   if (genStaInd == TRUE)
   {
      MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_SMEM_ALLOC_FAIL,
                             mgCb.init.region, mgCb.init.pool);
   }

   /* If peer assoc needs to be removed, do it now */
   if (errAction == MG_DELETE_PEER_PASS_TXN)
   {
      /* Only master should delete peer */ 
#ifdef ZG_DFTHA
      if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
         mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED, LMG_CAUSE_RSIP_NAK, FALSE);
#ifdef ZG_DFTHA
      else
      {
         /* send reverse update to delete peer */
         ZgRvUpdInfo   updInfo;
         MG_FILL_RVUPD_DEL_PEER(updInfo,peer,LMG_EVENT_PEER_REMOVED,
            LMG_CAUSE_RSIP_NAK,FALSE);
         zgReverseUpd(&updInfo, peer->accessInfo.peerId, MG_QUEUE_NONE,
                      tsap->tsapCfg.tSAPId);
      }
#endif /* ZG_DFTHA */
   }
#ifdef ZG
   zgUpdPeer();
#endif /* ZG */

   RETVALUE(ROK);

} /* end of mgPrcMgcpTxnInd () */

/*
*
*       Fun:   mgMgcpPrcDecodedTxn
*
*       Desc:  This function processes the transactions received from network
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or an acknowledgement or
*              acknowledgements for acknoledgements transmitted
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE S16 mgMgcpPrcDecodedTxn 
(
S16                *errAction,         /* Action to take on error */
U32                *rspCode,           /* Response Code */
MgMgcpTxn          *txn,               /* MGCP Transaction Structure */
MgPeerCb           **peerCtlBlk,       /* Peer */
MgTptSrvr          *srvr,              /* Listener Control Block */
CmTptAddr          *tptAddr,           /* Source Transport Address */
U16                msgIdx,             /* MsgIndex , to be processed */
MgTSAPCb           *tsap               /* TSAP Control Block */
)
#else
PRIVATE S16 mgMgcpPrcDecodedTxn (errAction, rspCode, txn, peerCtlBlk, srvr, 
                                 tptAddr, msgIdx, tsap)
S16                *errAction;         /* Action to take on error */
U32                *rspCode;           /* Response Code */
MgMgcpTxn          *txn;               /* MGCP Transaction Structure */
MgPeerCb           **peerCtlBlk;       /* Peer */
MgTptSrvr          *srvr;              /* Listener Control Block */
CmTptAddr          *tptAddr;           /* Source Transport Address */
U16                msgIdx;             /* MsgIndex , to be processed */
MgTSAPCb           *tsap;              /* TSAP Control Block */
#endif
{
   Bool            chkNtfyEnt;         /* Check Notified Entity */
   S16             ret;                /* Return Value */
   U32             variant;            /* Variant Information */
   MgMgcpMsg       *msg;               /* MGCP Message */
   MgMgcpCmdLine   *cmdLine;           /* MGCP Command Line */

   TRC2(mgMgcpPrcDecodedTxn)

   msg  = txn->mgcpMsg[msgIdx];
   ret  = ROK;
   variant = 0;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (msg == NULLP)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG038, 0,
                "[MGCP] mgMgcpPrcDecodedTxn(): Null Msg Pointer\n");
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   /* 
    * Based on the message type..take action. Note that through decoding
    * engine interfaces escape function, duplicate detection is already over
    */
   MG_VERIFY_RX_MGCP_MSG_ENT_RELATION(msg->msgType.val, 
                                       mgCb.genCfg.entType, chkNtfyEnt);

   /* Initialise variables */
   msg->dupInfo.pres = NOTPRSNT;

   if (msg->msgType.val != MGT_MSG_RSP)
   {
      if (msg->msgType.val == MGT_MSG_NONSTD)
      {
         cmdLine = &(msg->t.nonStdCmd.cmd.cmdLine);
      }
      else
      {
         cmdLine = &(msg->t.epcfCmd.cmdLine);
      }

      if (cmdLine->mgcpVer.profName.pres == PRSNT_NODEF)
      {
         MG_MGCP_FIND_VARIANT(cmdLine->mgcpVer.profName.val, 
                              cmdLine->mgcpVer.profName.len, variant);
      }
      else
      {
         variant = LMG_VER_PROF_MGCP_RFC2705_1_0;
      }
      /* Find out peer based on endpoint name */
      if(*peerCtlBlk == NULLP)
      {
          MgIpAddrEnt   *addrEnt = NULLP;
          /* 
           * Using source IP Address locate peer. If peer not found using IP address, 
           * use domain name recd in endPoint ID 
           */
          mgFindIpAddrLst(tptAddr->type, &(tptAddr->u.ipv4TptAddr.address),
                          &(tptAddr->u.ipv6TptAddr.ipv6NetAddr), MG_HASH_SEQNMB_DEF,
                          &addrEnt);
          if (addrEnt != NULLP)
          {
             *peerCtlBlk = addrEnt->peer;
          }
          else
          {
             *peerCtlBlk = (MgPeerCb *)mgFindPeerFrmDmn(
                                      cmdLine->epName.domainName.val,
                                      cmdLine->epName.domainName.len);
          }
      }
   }

   switch (msg->msgType.val)
   {
#ifdef GCP_MGC
      case MGT_MSG_RSIP:
      {
         ret = mgPrcRSIPCmd (errAction, rspCode, variant, msg, 
                        peerCtlBlk, srvr, tptAddr, tsap);
         RETVALUE(ret);
      }   
      break;
#endif /* GCP_MGC */

      case MGT_MSG_NONSTD:
      case MGT_MSG_EPCF:
      case MGT_MSG_CRCX:
      case MGT_MSG_MDCX:
      case MGT_MSG_DLCX:
      case MGT_MSG_RQNT:
      case MGT_MSG_NTFY:
      case MGT_MSG_AUEP:
      case MGT_MSG_AUCX:

#ifdef GCP_PKG_MGCP_BASE
      case MGT_MSG_MESG:
#endif /* GCP_PKG_MGCP_BASE */
      {
         /* 
          * If by any chance in data buffer being processed has piggy backed
          * messages, and we already have encountered that MG has been 
          * redirected and MG has sent out RSIP for registration with new MGC
          * don't process the other commands, just discard
          */
         if (*rspCode == MG_REGISTER_SENT)
         {
            *errAction = MG_DISCARD_TXN;
            *rspCode   = MGT_MGCP_RSP_CODE_REDIRECT_TO_NEW_CA;
            RETVALUE(RFAILED);
         }

         if ((mgMgcpVerifyCmdParms(variant, msg, rspCode)) != ROK)
         {
            /* 
             * Deleted the setting of rspCode over here as it is
             * now being set inside mgMgcpVerifyCmdParms
             */
            /* 
             * Don't discard transaction as we can have response piggybacked
             * which can be used to relieve congestion
             */
            RETVALUE(RFAILED);
         }

         ret = mgMgcpPrcRcvdCmd(errAction, rspCode, &chkNtfyEnt, msg,
                                peerCtlBlk, srvr, tptAddr, variant, tsap);
      }
      break;

      case MGT_MSG_RSP:
      {
         MgIpAddrEnt   *addrEnt = NULLP;

         if (*peerCtlBlk == NULLP)
         {
            /* Using source IP Address locate peer */
            mgFindIpAddrLst(tptAddr->type, &(tptAddr->u.ipv4TptAddr.address),
                            &(tptAddr->u.ipv6TptAddr.ipv6NetAddr), 
                            MG_HASH_SEQNMB_DEF, &addrEnt);
            if (addrEnt != NULLP)
            {
               *peerCtlBlk = addrEnt->peer;
            }
            else
            {
               RETVALUE(RFAILED);
            }
         }

         /* If Association to peer was lost - discard */
         if ((*peerCtlBlk)->state == LMG_PEER_STATE_DISCONNECTED)
         {
            *errAction = MG_DISCARD_TXN;
            RETVALUE(RFAILED);
         }

#ifdef GCP_MG
         variant = (*peerCtlBlk)->ssap->ssapCfg.mgcpVersion;
#endif /* GCP_MG */
         RETVALUE(mgMgcpPrcRcvdRsp(errAction, rspCode, &chkNtfyEnt, msg, 
                                   *peerCtlBlk, srvr, variant, tsap)); 
      }
      break;

      default:
      {
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ret);

} /* end of mgMgcpPrcDecodedTxn () */


/*
*
*       Fun:   mgMgcpPrcRcvdCmd
*
*       Desc:  This function process the Command received from the network
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: This function also takes care of the presence of a new notified
*              entity. A new notified entity implies a new Domain Name as per
*              RFC 821
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcpPrcRcvdCmd
(
S16                *errAction,         /* Action to be taken on Error */
U32                *rspCode,           /* Response Code */
Bool               *chkNtfyEnt,        /* Check Notified Entity */
MgMgcpMsg          *msg,               /* MGCP Message */
MgPeerCb           **peerCtlBlk,       /* Peer Control Block */     
MgTptSrvr          *srvr,              /* Listener Control Block */
CmTptAddr          *tptAddr,           /* Source Transport Address */
U32                variant,            /* variant */
MgTSAPCb           *tsap               /* TSAP control block */
)
#else
PRIVATE S16 mgMgcpPrcRcvdCmd(errAction, rspCode, chkNtfyEnt, msg, peerCtlBlk, 
                             srvr, tptAddr, variant, tsap)
S16                *errAction;         /* Action to take on error */
U32                *rspCode;           /* Response Code */
Bool               *chkNtfyEnt;        /* Check Notified Entity */
MgMgcpMsg          *msg;               /* MGCP Message Structure */
MgPeerCb           **peerCtlBlk;       /* Peer */
MgTptSrvr          *srvr;              /* Listener Control Block */
CmTptAddr          *tptAddr;           /* Source Transport Address */
U32                variant;            /* variant */
MgTSAPCb           *tsap;              /* TSAP control block */
#endif
{
   MgTransId       transId;            /* Transaction Identifier */
   Bool            chkRspParam;        /* Check Service User Response Params */
   MgPeerCb        *peer;              /* Peer Control Block */
   MgMgcpCmd       *cmd;               /* MGCP Command */
   MgIpAddrEnt     *addrEnt;           /* IP Address Entry */
   MgRxTransIdEnt  *rxCb;              /* Incoming Transaction Control Block */

   TRC2(mgMgcpPrcRcvdCmd)

   /* Command Structure from union should be picked based on msgType */
   if (msg->msgType.val == MGT_MSG_NONSTD)
   {
      cmd = &(msg->t.nonStdCmd.cmd);
   }
   else
   {
      cmd = &(msg->t.epcfCmd);
   }
   
   transId = cmd->cmdLine.trId.val;

   peer = *peerCtlBlk;

   if (peer == NULLP)
   {
      addrEnt = NULLP;
      mgFindIpAddrLst(tptAddr->type, &(tptAddr->u.ipv4TptAddr.address),
                      &(tptAddr->u.ipv6TptAddr.ipv6NetAddr), 
                      MG_HASH_SEQNMB_DEF, &addrEnt);
      if (addrEnt == NULLP)
      {
         *errAction = MG_DISCARD_TXN;
         *rspCode   = MGT_MGCP_RSP_CODE_PROT_ERROR;
         RETVALUE(RFAILED);
      }

      /* Initialise peer control block */
      peer = addrEnt->peer;
      *peerCtlBlk = peer;

      /*
       *   Initialize the tsap field of peer
       */
      peer->tsap = tsap;
   }

   /*
    *   If peer still has a NULLP tsap, initialize it;
    *   This might happen when the MGC receives a NTFY from
    *   a new MG;
    */
   if (peer->tsap == NULLP)
      peer->tsap = tsap;

   /*
    * If Peer is in disconnected state - i.e. Association was lost discard the
    * command (See call to MG_MGCP_LOST_ASSOCIATION macro)
    */
   if (peer->state == LMG_PEER_STATE_DISCONNECTED)
   {
      *errAction = MG_DISCARD_TXN;
      *rspCode   = MGT_MGCP_RSP_CODE_PROT_ERROR;
      RETVALUE(RFAILED);
   }

   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
      /*
       * On a MG side, we should either be registered or in the process of
       * registration to accept commands. In the "process of registration" case 
       * needs to be considered for the fact that over UDP we can receive 
       * messages from network out of order and hence response to registration 
       * has got delayed
       */
      if (peer->state != LMG_PEER_STATE_REGISTER &&
          peer->state != LMG_PEER_STATE_ACTIVE)
      {
         *errAction = MG_DISCARD_TXN;
         *rspCode   = MGT_MGCP_RSP_CODE_PROT_ERROR;
         RETVALUE(RFAILED);
      }
   }
   else
   {
      /* 
       * On MGC side, for a configured MG, we need to consider out of order
       * delivery and hence accept command in Awaited Registration state for
       * configured peers only
       */
      if (((peer->mntInfo.byCfg != TRUE) && 
           (peer->state == LMG_PEER_STATE_AWAIT_REG)) &&
           peer->state != LMG_PEER_STATE_REGISTER &&
           peer->state != LMG_PEER_STATE_ACTIVE)
      {
         *errAction = MG_DISCARD_TXN;
         *rspCode   = MGT_MGCP_RSP_CODE_PROT_ERROR;
         RETVALUE(RFAILED);
      }
   }

   /* Update Statistics */
   MG_UPD_MGCP_PEER_RX_STS((msg->msgType.val), peer->peerSts, MG_NONE);

   /* Check if we have resources to allocate in our layer */
   if (mgAdmitTxn(peer->ssap, peer->tsap) != ROK)
   {
      /* 
       * Don't discard transaction as we can have response piggybacked
       * which can be used to relieve congestion
       */
      *rspCode    = MGT_MGCP_RSP_CODE_PROT_ERROR;
      RETVALUE(RFAILED);
   }

   chkRspParam = FALSE;

#ifdef GCP_MG
   if ((mgCb.genCfg.entType == LMG_ENT_GW) &&
       (msg->msgType.val == MGT_MSG_DLCX))
   {
      /* 
       * MG is receiving a DLCX; If connection Id is present; Service
       * User is required to fill Connection Parameters
       */
      if ((mgMgcpFindParamTypeInMsg(MGT_PARAM_CONNID, msg)) != NULLP)
         chkRspParam = TRUE;
   }
#endif /* GCP_MG */

   if ((rxCb = mgPrcIncomingTxn(peer, tptAddr, transId, &(msg->dupInfo.pres),
                                chkRspParam,
#ifdef    GCP_PROV_SCTP
                                NULLP,
#endif    /* GCP_PROV_SCTP */
                                srvr, msg->msgType.val,
                                MG_NONE)) == NULLP)
   {     
      /* 
       * Don't discard transaction as we can have response piggybacked
       * which can be used to relieve congestion; so don't mark errAction
       * as discard transaction
       */
      if (msg->dupInfo.pres == PRSNT_NODEF)
        *rspCode    = MG_NONE;
      else
        *rspCode    = MGT_MGCP_RSP_CODE_PROT_ERROR;
      RETVALUE(RFAILED);
   }

   /* 
    * If the message received is not a retransmission, then do check for the
    * presence of notified entity if required and process responseAck if present
    */
   if (msg->dupInfo.pres != PRSNT_NODEF)
   {
#ifdef GCP_MG
      /*
       * Coming Here Implies it is not a retransmission; check if new
       * need to look for notified entity
       */
      if (*chkNtfyEnt == TRUE)
      {
         MgNtfiedEnt        *ntfiedEnt;         /* MGCP notified entity */
         MgPeerCb           *newPeer;
         MgMgcpParam        *param;             /* MGCP parameter */

         if((param = mgMgcpFindParamTypeInMsg(MGT_PARAM_NTFIED_ENT, msg)) 
               == NULLP)
            ntfiedEnt = NULLP;
         else
            ntfiedEnt = &(param->t.ntfiedEnt);

         newPeer = NULLP;

         if(NULLP != ntfiedEnt)
         {
#ifdef ZG_DFTHA
            /* only master should process this process this */
            if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
            {
               if ((mgMgcpChkAndPrcNtfiedEntity(ntfiedEnt, peer, &newPeer, 
                     variant)) == RFAILED)
               {
                  *rspCode    = MGT_MGCP_RSP_CODE_PROT_ERROR;
                  mgDeAllocRxTransIdEnt(peer, rxCb, FALSE);
                  RETVALUE(RFAILED);
               }
            }
#ifdef ZG_DFTHA
            /* generate reverse update */
            else
            {
               ZgRvUpdInfo  updInfo;
               MG_FILL_RVUPD_NTFIEDENT(updInfo,peer,variant,ntfiedEnt);
               zgReverseUpd(&updInfo, peer->accessInfo.peerId,
                            MG_QUEUE_NONE, tsap->tsapCfg.tSAPId);
            }
#endif /* ZG_DFTHA */
         }
      }

#endif /* GCP_MG */

      /* If Response Ack Parameter is present...act on it */
      mgMgcpFindAndActOnRspAck(peer, cmd);
   } 
   
   RETVALUE(ROK); 

} /* end of mgMgcpPrcRcvdCmd() */


/*
*
*       Fun:   mgMgcpFindAndActOnRspAck
*
*       Desc:  This function searches for Response Acknowledgement attribute
*              in a command and process it
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE Void mgMgcpFindAndActOnRspAck
(
MgPeerCb           *peer,              /* Peer Control Block */
MgMgcpCmd          *cmd                /* MGCP Command */
)
#else
PRIVATE Void mgMgcpFindAndActOnRspAck (peer, cmd)
MgPeerCb           *peer;              /* Peer Control Block */
MgMgcpCmd          *cmd;               /* MGCP Command */
#endif
{
   U16             loopIdx;            /* Loop Index */
   U16             numParam;           /* Loop Index */
   MgTransId       maxCnt;             /* Maximum Count */
   MgTransId       count;              /* counter */
   MgMgcpParam     *param;             /* MGCP Parameters */
   MgRspAckSet     *rspAckSet;         /* Response Ack Set */
   MgRspAck        *rspAck;            /* Response Ack */

   TRC2(mgMgcpFindAndActOnRspAck)

   param    = NULLP;
   numParam = cmd->params.numParam.val;

   for (loopIdx = 0; loopIdx < numParam; loopIdx++)
   {
      param = (cmd->params.param[loopIdx]);

      if (param->paramType.val != MGT_PARAM_RSPACK)
      {
         param = NULLP;
         continue;
      }
      else 
         break;
   }

   /* If not found - return */
   if (param == NULLP)
      RETVOID;

   /* Process the Response Ack Received */
   rspAckSet = &(param->t.rspAckSet);

   if (rspAckSet->numComp.pres == NOTPRSNT)
      RETVOID;

   numParam = rspAckSet->numComp.val;

   for (loopIdx = 0; loopIdx < numParam; loopIdx++)
   {
      rspAck = (rspAckSet->rspAck[loopIdx]);

      if (rspAck->pres.pres == NOTPRSNT || rspAck->lowBnd.pres == NOTPRSNT)
         continue;

      if (rspAck->upperBnd.pres == NOTPRSNT)
         maxCnt = rspAck->lowBnd.val;
      else
         maxCnt = rspAck->upperBnd.val;

      for (count = rspAck->lowBnd.val; count <= maxCnt; count++)
      {
#ifdef ZG_DFTHA
         /* In DFTHA ..if the resource set for this txnId exist on this copy
          * then only process it..else call PLDF fn to route this response ack
          * to appropriate copy */ 
         if(zgChkNCRsetStatus(count, LMG_PROTOCOL_MGCP,
            peer, MG_MGCP_MSG_RSPACK, MG_TRANS_TYPE_RX, 
            MG_INVALID_LSTNRID, NULLP, 0))
#endif /* ZG_DFTHA */
            mgPrcRcvdResponseAck(peer, count);
#ifdef ZG_DFTHA
         else
            zgPldfSendRspAck(count,LMG_PROTOCOL_MGCP, peer->accessInfo.peerId);
#endif /* ZG_DFTHA */
      }
   }

   RETVOID;

} /* end of mgMgcpFindAndActOnRspAck () */


/*
*
*       Fun:   mgMgcpPrcRcvdRsp
*
*       Desc:  This function processes the response received for the command
*              previously transmitted
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: The function looks for the presence of the new call agent and
*               takes appropriate action accordingly
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcpPrcRcvdRsp
(
S16                *errAction,         /* Action to be taken on Error */
U32                *rspCode,           /* Response Code */
Bool               *chkNtfyEnt,        /* Check Notified Entity */
MgMgcpMsg          *msg,               /* MGCP Message */
MgPeerCb           *peer,              /* Peer Control Block */     
MgTptSrvr          *srvr,              /* Listener Control Block */
U32                variant,            /* variant */
MgTSAPCb           *tsap               /* TSAP control block */
)
#else
PRIVATE S16 mgMgcpPrcRcvdRsp(errAction, rspCode, chkNtfyEnt, msg, peer, srvr,
                             variant, tsap)
S16                *errAction;         /* Action to be taken on Error */
U32                *rspCode;           /* Response Code */
Bool               *chkNtfyEnt;        /* Check Notified Entity */
MgMgcpMsg          *msg;               /* MGCP Message */
MgPeerCb           *peer;              /* Peer Control Block */     
MgTptSrvr          *srvr;              /* Listener Control Block */
U32                variant;            /* variant */
MgTSAPCb           *tsap;              /* TSAP control block */
#endif
{
   U8              cmdType;            /* Message Type */
   U8              rspType;            /* Response Type */
   S16             ret;                /* Return Value */
   MgTransId       transId;            /* Transaction Identifier */
   MgMgcpRsp       *rsp;               /* Response */
   MgTxTransIdEnt  *txCb;              /* transaction cb */
   Bool            emptyRspAck;        /* Whether response contains empty
                                          response Ack parameter */
   Bool            rspAckSentOut;		/* the Response Ack sent out or not */

   TRC2(mgMgcpPrcRcvdRsp)

   /* Initialise variables */
   rsp     = &(msg->t.mgcpRsp);
   transId = rsp->trId.val;

   txCb = NULLP;

   cmdType = MGT_MSG_NONE;

   emptyRspAck = FALSE;
   rspAckSentOut = FALSE;

   if (rsp->rspCode.val >= MGT_MGCP_RSP_CODE_PROVISIONAL && 
       rsp->rspCode.val < MGT_MGCP_RSP_CODE_OK)
   {
     rspType = MG_RESPONSE_PROV;
   }
   else
   if (rsp->rspCode.val >= MGT_MGCP_RSP_CODE_OK &&
       rsp->rspCode.val <= MGT_MGCP_RSP_CODE_OK_RANGE)
   {
     rspType = MG_RESPONSE_OK;
   }
   else
   if (rsp->rspCode.val > MGT_MGCP_RSP_CODE_OK_RANGE)
     rspType = MG_RESPONSE_ERR;

   /* Locate the transaction control block */
   if ((cmHashListFind(&(peer->outTransLst), (U8 *)&transId, 
                       MG_TRANSID_LEN, MG_HASH_SEQNMB_DEF, 
                       (PTR *) &txCb)) == ROK)
   {
      cmdType  = txCb->msgType;
   }
   else
      txCb = NULLP;

#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
   /* Check if this Response Ack Reponse..if yes then stop final response 
    * timer..and process this response ack response */ 
   if(rsp->rspCode.val == MGT_MGCP_RSP_CODE_RSP_ACK_RSP)
   {
      MgRxTransIdEnt     *rxCb;
      rxCb = NULLP;
      /* Locate the transaction control block */
      if ((cmHashListFind(&(peer->inTransLst), (U8 *)&transId, 
                        MG_TRANSID_LEN, MG_HASH_SEQNMB_DEF, 
                        (PTR *) &rxCb)) == ROK)
      {
          if(rxCb->tmr[MG_RETX_RSP_TMR - MG_INTXN_TMR_BASE].tmrEvnt
             == MG_RETX_RSP_TMR)
          {
             mgStopTmr(MG_RETX_RSP_TMR , (PTR)rxCb, 
                      &(rxCb->tmr[MG_RETX_RSP_TMR - MG_INTXN_TMR_BASE]));
          }
          mgPrcRcvdResponseAck(peer, transId);
      }
      RETVALUE(ROK);
   }

   /* Check if response contains empty response Ack parameter; If yes then send
    * Response Acknowledge Response */
   if(rspType == MG_RESPONSE_OK)
   {
      U8             i;
      MgMgcpParam   *param;

      /* mg002.105: If GCP layer is enabled to send immediate response Ack,
       *            then send it out without enqueuing the transaction ID */
      if (mgCb.genCfg.reCfg.rspAckEnb & LMG_EMBD_IMM_RSPACK_MGCP)
      {
         rspAckSentOut = TRUE;

         /* Send Response Acknowledge Response immediately */
         mgMgcpSendRspAckRsp(peer,transId);
      }
      /* else send the rspAck iff empty K: is present in the final rsp */
      else
      {
      for(i=0;i<rsp->params.numParam.val;i++)
      {
         param = rsp->params.param[i]; 
         if((param->paramType.val == MGT_PARAM_RSPACK) &&
            (param->t.rspAckSet.numComp.val == 0))
         {
            emptyRspAck = TRUE;
            /* Send Response Acknowledge Response */
            mgMgcpSendRspAckRsp(peer,transId);
            break;
         }
      }
   }
   }
   /* Check if response is not provisional response..then increment rcvdRsp
    * count */
   if(rspType != MG_RESPONSE_PROV)
   {
      if(txCb)
      {
         txCb->u.txBufInfo->rcvdRspCnt++;
      }
   }
#endif  /* GCP_2705BIS */

   /* If GCP layer is enabled to send response Ack then enqueue the transaction
    * id into list, and start a timer ( 30 Sec ). Response Ack will be sent once
    * layer gets commands from service user within 30 Sec. If command is not
    * rcved within this time period then stored txnId will be removed from the
    * list, after timeer expiry */
   /* mg002.105: Make sure rspAckRsp is not sent twice */
   if ((mgCb.genCfg.reCfg.rspAckEnb & LMG_EMBD_RSPACK_MGCP) &&
       (emptyRspAck == FALSE) &&
       (rspType != MG_RESPONSE_PROV) &&
       (rspAckSentOut == FALSE))
   {
      MgTxnAckList    *node;
      node = (MgTxnAckList *)mgMalloc(sizeof(MgTxnAckList));
      node->info.trId = transId;
      node->info.peer = peer;
      MG_ADD_LIST_INC_ORDER((&(peer->txnAckQ)),node);
      /* Now start a timer of 30 sec */
      cmInitTimers(&(node->info.tmr),MG_DEFAULT_MAXTMR);
      mgStartTmr(MG_30SEC_ACK_TMR, peer->ssap->ssapCfg.reCfg.atMostOnceTmr.val, 
                   (PTR)node,&(node->info.tmr));
   }
#endif  /* GCP_VER_1_3 */

   ret = ROK;

#ifdef GCP_MG
   if (mgCb.genCfg.entType == LMG_ENT_GW)  
   {
      if(cmdType == MGT_MSG_RSIP)
      {
         MgMgcpParam        *param;             /* MGCP parameter */
         MgNtfiedEnt        *ntfiedEnt;         /* MGCP notified entity */

         if((param = mgMgcpFindParamTypeInMsg(MGT_PARAM_NTFIED_ENT, msg)) 
            == NULLP)
         {
            ntfiedEnt = NULLP;
         }
         else
         {
            ntfiedEnt = &(param->t.ntfiedEnt);
         }
         if(txCb->suConnId != srvr->suConnId)
         {
            RETVALUE(RFAILED);
         }
         ret = mgMgcpPrcRSIPResponse(errAction, rspCode, peer, 
                                     rspType, ntfiedEnt, variant, transId);
         if(ret != ROKDNA)
         {
            if ((mgPrcIncomingAck(&txCb, &cmdType, srvr, peer, 
                   transId, rspType)) != ROK)
            {
               RETVALUE(RFAILED);
            }
         }
#ifdef ZG_DFTHA
         if (ret == ROKDNA)
         {
            /* This copy is not master */
            ZgRvUpdInfo   updInfo;
            MG_FILL_RVUPD_RSIPRSP_PEER(updInfo,peer,rspType,variant,ntfiedEnt,\
               transId);
            /* call PLDF fn to send revserse update for this RSIP response */
            tsap->rvNode = 
                (MgRvUpdQNode *)zgReverseUpd(&updInfo, 
                                             peer->accessInfo.peerId,
                                             MG_PEER_INTXNQ,
                                             tsap->tsapCfg.tSAPId);
            /* return OK..not done..this txn will be queued in calling fn */
            RETVALUE(ROKDNA);
         }
#endif /* ZG_DFTHA */
#ifdef ZG
#ifdef ZG_DFTHA
         /* only if we are master, we shall generate rumtime upadate for peer */
         if(zgChkCRsetStatus() == TRUE)
#endif /* ZG_DFTHA */
         {
            /* Send run time update to standby */
            zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
               CMPFTHA_ACTN_MOD);
         }
#endif /* ZG */
      }
      else
      {
         if ((mgPrcIncomingAck(&txCb, &cmdType, srvr, peer, transId, rspType)) 
            != ROK)
         {
            RETVALUE(RFAILED);
         }
      }
   }
#endif /* GCP_MG */
#ifdef GCP_MGC
   if (mgCb.genCfg.entType == LMG_ENT_GC)  
   {
      if ((mgPrcIncomingAck(&txCb, &cmdType, srvr, peer, transId, rspType)) 
                                                                      != ROK)
      {
         RETVALUE(RFAILED);
      }
   }
#endif /* GCP_MGC */
#ifdef ZG
   zgUpdPeer();
#endif /* ZG */

   RETVALUE(ret);

} /* end of mgMgcpPrcRcvdRsp() */


#ifdef GCP_VER_1_3
/*
*
*       Fun:   mgMgcpFillRspAck
*
*       Desc:  This function fills the response Ack parameter into Mgcp message.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcpFillRspAck
(
MgRspAck           **ack,              /* Response Acknowledgement parameter */
MgMgcpMsg          *msg,               /* MGCP Message */
U8                 noOfAck             /* no of Rsp Ack */
)
#else
PRIVATE S16 mgMgcpFillRspAck(ack, msg, noOfAck)
MgRspAck           **ack;              /* Response Acknowledgement parameter */
MgMgcpMsg          *msg;               /* MGCP Message */
U8                 noOfAck;            /* no of Rsp Ack */
#endif
{
   MgMgcpParamSet     *params;          /* Parameter Set */
   MgMgcpParam        **param;          /* Parameter array */
   U8                 cnt;              /* Counter */
   U8                 noOfParam;        /* no. of parameter */ 
   U8                 nthParam;         /* nthParam is the response Ack
   parameter*/
   Bool               fillEmptyAck;     /* Whether to fill empty response Ack*/
   Bool               rspAckPrsnt;      /* Whether RspAck is already present*/

   TRC2(mgMgcpFillRspAck)

   /* Initialise variables */
   fillEmptyAck = FALSE;
   rspAckPrsnt  = FALSE;

   if(msg->msgType.val == MGT_MSG_RSP)
      params = &msg->t.mgcpRsp.params;
   else if(msg->msgType.val == MGT_MSG_NONSTD)
      params = &msg->t.nonStdCmd.cmd.params;
   else
      params = &msg->t.epcfCmd.params;
   
   /* Whether to fill empty response Ack parameter */
   if(ack == NULLP && noOfAck == 0)
      fillEmptyAck = TRUE;
      
   /* Findout if already Response ack parameter is present */ 
   for(cnt =0;cnt < params->numParam.val;cnt++)
      if(params->param[cnt]->paramType.val == MGT_PARAM_RSPACK)
      {
         rspAckPrsnt = TRUE;
         /* nthParam is the response Ack parameter */
         nthParam = cnt;  
         break;
      }
   if(rspAckPrsnt)
   {
      if(!fillEmptyAck)
      {
         MgRspAckSet    *rspAckSet;        /* Response Ack Set*/
         MgRspAckSet    *rspAckSetBkp;     /* backup for rspAckSet */

         noOfParam = params->param[nthParam]->t.rspAckSet.numComp.val + noOfAck;

         rspAckSet = &params->param[nthParam]->t.rspAckSet;
         rspAckSetBkp = rspAckSet;
         rspAckSet->numComp.pres = PRSNT_NODEF;
         rspAckSet->numComp.val = noOfParam;
         /* Get memory and then copy each response ack parameter from the passed
          * argument */
         if(cmGetMem(&(msg->memCp),(noOfParam * (Size)sizeof(MgRspAck *)), 
                     (Ptr *)&(rspAckSet->rspAck)) != ROK)
         {
            RETVALUE(RFAILED);
         }
         /* Now copy all the response ack parameter*/
         for(cnt=0;cnt<noOfParam;cnt++)
            if(cnt < rspAckSetBkp->numComp.val) 
               rspAckSet->rspAck[cnt] = rspAckSetBkp->rspAck[cnt];
            else
               rspAckSet->rspAck[cnt] = ack[cnt];
             
      }
   }
   else
   {
      /* Now here we have to add a new parameter into the parameter list sent by
       * service user. So first get memory for all the parametrs and copy the
       * old parametrs value and then free old memory*/
         noOfParam = params->numParam.val + 1;
         if(cmGetMem(&(msg->memCp),(noOfParam * (Size)sizeof(MgMgcpParam *)), 
                     (Ptr *)&(param)) != ROK)
         {
            RETVALUE(RFAILED);
         }
         if(cmGetMem(&(msg->memCp),(Size)sizeof(MgMgcpParam), 
                        (Ptr *)&(param[noOfParam -1])) != ROK)
         {
            RETVALUE(RFAILED);
         }
         for(cnt=0;cnt<noOfParam-1;cnt++)
            param[cnt] = params->param[cnt];
         params->param = param;
         params->numParam.pres = PRSNT_NODEF;
         params->numParam.val = noOfParam;
         param[noOfParam - 1]->paramType.pres = PRSNT_NODEF;
         param[noOfParam - 1]->paramType.val =MGT_PARAM_RSPACK;

      if(fillEmptyAck)
      {
         param[noOfParam - 1]->t.rspAckSet.numComp.pres = PRSNT_NODEF;
         param[noOfParam - 1]->t.rspAckSet.numComp.val = 0;
      }
      else
      {
         MgRspAckSet    *rspAckSet;
         rspAckSet = &param[noOfParam -1]->t.rspAckSet;
         rspAckSet->numComp.pres = PRSNT_NODEF;
         rspAckSet->numComp.val = noOfAck;
         /* Get memory and then copy each response ack parameter from the passed
          * argument */
         if(cmGetMem(&(msg->memCp),(noOfAck * (Size)sizeof(MgRspAck *)), 
                     (Ptr *)&(rspAckSet->rspAck)) != ROK)
         {
            RETVALUE(RFAILED);
         }
         for(cnt=0;cnt<noOfAck;cnt++)
            rspAckSet->rspAck[cnt] = ack[cnt];
      }
   }
   
   RETVALUE(ROK);

} /* end of mgMgcpFillRspAck() */
#endif

/*
*
*       Fun:   mgMgcpSendErrorResponse
*
*       Desc:  This function sends a response with an error code
*
*       Ret:   None
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC Void mgMgcpSendErrorResponse
(
CmTptAddr          *srcAddr,           /* Source Transport Address */
MgTransId          trId,               /* MGCP TransAction ID */
U32                rspCode,            /* Error Response Code */
U8                 *rspStr,            /* Response String */
MgTSAPCb           *tsap               /* TSAP Control Block */
)
#else
PUBLIC Void mgMgcpSendErrorResponse (srcAddr, trId, rspCode, rspStr, tsap)
CmTptAddr          *srcAddr;           /* Source Transport Address */
MgTransId          trId;               /* MGCP TransAction ID */
U32                rspCode;            /* Error Response Code */
U8                 *rspStr;            /* Response String */
MgTSAPCb           *tsap;              /* TSAP Control Block */
#endif
{
   Mem             sMem;               /* Memory Region and Pool */
   U16             len;                /* Length */
   Bool            ssapSrvr;           /* SSAP Server Used for Tx */
   MgMgcpTxn       *txn;               /* MGCP Transaction */
   MgMgcpMsg       *msg;               /* MGCP Message */
   MgMgcpRsp       *rsp;               /* Response */
   MgTptSrvr       *srvr;              /* Transport Server */
   Buffer          *mBuf;              /* Message Buffer */
   CmAbnfErr       err;                /* Encoding ABNF error structure */

   TRC2(mgMgcpSendErrorResponse)

   /* Initialise variables */
   srvr        = NULLP;
   len         = 0;
   sMem.region = mgCb.init.region;
   sMem.pool   = mgCb.init.pool;

   if ((srvr = mgMgcpGetSrvrForTx(NULLP, tsap, &ssapSrvr)) == NULLP)
      RETVOID;

   if (mgGetMsg(tsap->tsapCfg.memId.region, 
                tsap->tsapCfg.memId.pool, &(mBuf)) != ROK)
   {
      /* Send Status Indication to the layer manager */
      MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL, 
                             tsap->tsapCfg.memId.region, 
                             tsap->tsapCfg.memId.pool);
      RETVOID;
   }

   /* Allocate Event Structure Memory */
   if(ROK != mgAllocEventMem( (Ptr *)&(txn), sizeof(MgMgcpTxn)) )
   {
      mgPutMsg(mBuf);
      RETVOID;
   }

   txn->numMsg = 0;

   if(ROK != mgAllocEventMem( (Ptr *)&(txn->mgcpMsg[0]), sizeof(MgMgcpMsg)) )
   {
      mgPutMsg(mBuf);
      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
      RETVOID;
   }
   else
      txn->numMsg = 1;

   /* Fill Information in the event structure */
   msg   = txn->mgcpMsg[0];
   rsp   = &(msg->t.mgcpRsp);

   msg->msgType.pres = PRSNT_NODEF;
   msg->msgType.val  = MGT_MSG_RSP;

   rsp->pres.pres    = PRSNT_NODEF;
   rsp->rspCode.pres = PRSNT_NODEF;
   rsp->rspCode.val  = rspCode;
   rsp->trId.pres    = PRSNT_NODEF;
   rsp->trId.val     = trId;

   if (rspStr != NULLP)
   {
      /* Obtain memory for response string */
      len = cmStrlen((CONSTANT U8 *)rspStr);
      if (len > 0)
      {
         rsp->rspStr.pres  = PRSNT_NODEF;
         if ((cmGetMem(&(msg->memCp), len, (Ptr *)&(rsp->rspStr.val))) != ROK)
         {
            mgPutMsg(mBuf);
            MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
            RETVOID;
         }

         cmMemcpy((U8 *)rsp->rspStr.val, (CONSTANT U8 *)rspStr, len);
 
 
         /* Value of the response string length is now set */
         rsp->rspStr.len = len;
 
      }
   }
   /* Encode the RESPONSE */
   if ((cmAbnfEncPduMsg(LMG_VER_PROF_MGCP_RFC2705_1_0, 
                        (U8 *)&(msg->msgType), mBuf, &mgMsgDef,
                        &(tsap->tsapCfg.memId), &err)) != ROK)
   {
      /* mg003.105: Add - Added sanity check */
      if (mBuf != NULLP)
         mgPutMsg(mBuf);
      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
      RETVOID;
   }

   /* Free the event structure memory */
   MG_FREE_MGCP_EVNT_MEM(txn, TRUE);

   /* Transmit the buffer */
   mgSrvDatReq(srvr, srcAddr, mBuf);
   RETVOID;

} /* mgMgcpSendErrorResponse() */


/*
*
*       Fun:   mgMgcpSendPrvsnlResponse
*
*       Desc:  This function sends a provisional response for the 
*              transaction received. This function is called either when 
*              timer has expired or when we receive a retransmission
*              of a command and provisional timer is not running
*
*       Ret:   None
*
*       Notes: Provisional Response are not generated for NCS and TGCP
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC Void mgMgcpSendPrvsnlResponse
(
MgRxTransIdEnt     *rxCb               /* Transaction Control Block */
)
#else
PUBLIC Void mgMgcpSendPrvsnlResponse (rxCb)
MgRxTransIdEnt     *rxCb;              /* Transaction Control Block */
#endif
{
   U8              idx;                /* Index */
   Mem             sMem;               /* Memory region and pool */
   Bool            ssapSrvr;           /* SSAP Server Used for Tx */
   CmAbnfErr       err;                /* Encoding ABNF error structure */
   MgPeerCb        *peer;              /* Peer Control Block */
   MgMgcpTxn       *txn;               /* MGCP Transaction */
   MgMgcpMsg       *msg;               /* MGCP Message */
   MgMgcpRsp       *rsp;               /* Response */
   MgTptSrvr       *srvr;              /* Transport Server */
   Buffer          *mBuf;              /* Message Buffer */
   Buffer          *newMbuf;           /* Message Buffer */

   TRC2(mgMgcpSendPrvsnlResponse)

   /* Initialise variables */
   peer        = rxCb->peer;
   sMem.region = mgCb.init.region;
   sMem.pool   = mgCb.init.pool;

   /* Ensure peer is in proper state */
   if (peer->state != LMG_PEER_STATE_ACTIVE &&
       peer->state != LMG_PEER_STATE_REGISTER)
   {
      RETVOID;
   }

   /* 
    * GCP layer doesn't sent Provisional Response for NCS/TGCP
    */
   if (peer->mntInfo.variant != LMG_VER_PROF_MGCP_RFC2705_1_0)
      RETVOID;

   /* Obtain a Server for Transmission */
   if ((srvr = mgMgcpGetSrvrForTx(peer->ssap, peer->tsap,
                                  &ssapSrvr)) == NULLP)
   {
      RETVOID;
   }

   if (rxCb->state == MG_INTXN_PROVRSP_SENT && rxCb->mBuf != NULLP)
   {
      /* We have a provisional response stored...use that */
      mBuf = rxCb->mBuf;
   }
   else
   {
      /* Get an mBuf for creating Provisional Response */
      if (mgGetMsg(peer->tsap->tsapCfg.memId.region, 
                   peer->tsap->tsapCfg.memId.pool, &(mBuf)) != ROK)
      {
         /* Send Status Indication to the layer manager */
         MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL, 
                              peer->tsap->tsapCfg.memId.region, 
                              peer->tsap->tsapCfg.memId.pool);
         RETVOID;
      }

      /* Allocate Event Structure Memory */
      if(ROK != mgAllocEventMem( (Ptr *)&(txn), sizeof(MgMgcpTxn)) )
      {
         mgPutMsg(mBuf);
         RETVOID;
      }
     
      txn->numMsg = 0;
     
      if(ROK != mgAllocEventMem( (Ptr *)&(txn->mgcpMsg[0]), sizeof(MgMgcpMsg)) )
      {
         mgPutMsg(mBuf);
         MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
         RETVOID;
      }
      else
         txn->numMsg = 1;
     
      /* Fill Information in the event structure */
      msg   = txn->mgcpMsg[0];
      rsp   = &(msg->t.mgcpRsp);
      
      msg->msgType.pres = PRSNT_NODEF;
      msg->msgType.val  = MGT_MSG_RSP;
     
      rsp->pres.pres    = PRSNT_NODEF;
      rsp->rspCode.pres = PRSNT_NODEF;
      rsp->rspCode.val  = MGT_MGCP_RSP_CODE_PROVISIONAL;
      rsp->trId.pres    = PRSNT_NODEF;
      rsp->trId.val     = rxCb->transId;
      /* Encode the Provisional Response */
      if ((cmAbnfEncPduMsg(LMG_VER_PROF_MGCP_RFC2705_1_0, 
                          (U8 *)&(msg->msgType), mBuf, &mgMsgDef,
                           &(peer->tsap->tsapCfg.memId), &err)) != ROK)
      {
         /* mg003.105: Add - Added sanity check */
         if (mBuf != NULLP)
           mgPutMsg(mBuf);
         MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
         RETVOID;
      }
      /* Free the event structure memory */
      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);

      rxCb->mBuf       = mBuf;
      rxCb->state      = MG_INTXN_PROVRSP_SENT;
      rxCb->rspStatus  = MG_RESPONSE_PROV;
   }

   /* Add message Reference */
   if ((SAddMsgRef (mBuf, peer->tsap->tsapCfg.memId.region, 
                    peer->tsap->tsapCfg.memId.pool, &(newMbuf))) != ROK)
   {
      if (peer->ssap->ssapCfg.reCfg.provRspTmr.enb != TRUE)
      {
        if (rxCb->mBuf != NULLP)
          mgPutMsg(rxCb->mBuf);
        
        rxCb->mBuf       = NULLP;
        rxCb->state      = MG_INTXN_TXN_RCVD;
        rxCb->rspStatus  = MG_NONE;
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
        zgRtUpd(ZG_CBTYPE_TXN_RX,(Ptr)rxCb,CMPFTHA_UPDTYPE_NORMAL,CMPFTHA_ACTN_MOD);
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */
      }

      RETVOID;
   }

   /*
    * If GCP layer is configured to send provisional response, start the 
    * timer to do so for the transaction
    */
   idx = MG_PROVRSP_TMR - MG_INTXN_TMR_BASE;

   /* If timer is still enabled start it again. else reset rxcb buffer */
   if (peer->ssap->ssapCfg.reCfg.provRspTmr.enb == TRUE)
   {
      mgStartTmr(MG_PROVRSP_TMR, peer->ssap->ssapCfg.reCfg.provRspTmr.val,
                 (PTR)rxCb, &(rxCb->tmr[idx]));      
   }
   else
   {
      /*
       * Coming here implies that SSAP has been reconfigured with provisional
       * response as disabled, implying that GCP will no longer generate
       * provisional responses and if a retransmission is received, it will
       * be passed to Service User and he may choose to send provisional 
       * responses
       */
      rxCb->mBuf = NULLP;
      mgPutMsg(mBuf);

      /* Reset rxCb States */
      rxCb->state      = MG_INTXN_TXN_RCVD;
      rxCb->rspStatus  = MG_NONE;
   }

#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
   zgRtUpd(ZG_CBTYPE_TXN_RX,(Ptr)rxCb,CMPFTHA_UPDTYPE_NORMAL,CMPFTHA_ACTN_MOD);
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */
   /* Transmit the buffer */
   mgSrvDatReq(srvr, &(rxCb->tptAddr), newMbuf);

   RETVOID;

} /* end of mgMgcpSendPrvsnlResponse() */


/*
*
*       Fun:   mgMgcpGetSrvrForTx
*
*       Desc:  This function obtains a UDP Server for Transmission from 
*              appropriate list
*
*       Ret:   Pointer to MgTptSrvr   - SUCCESS
*              NULLP                  - FAILED
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC MgTptSrvr *mgMgcpGetSrvrForTx
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgTSAPCb           *tsap,              /* TSAP Control Block */
Bool               *ssapSrvr           /* SSAP Server Chosen or not */
)
#else
PUBLIC MgTptSrvr *mgMgcpGetSrvrForTx(ssap, tsap, ssapSrvr)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgTSAPCb           *tsap;              /* TSAP Control Block */
Bool               *ssapSrvr;          /* SSAP Server Chosen or not */
#endif
{
   TRC2(mgMgcpGetSrvrForTx)

   *ssapSrvr = FALSE;

#ifdef GCP_MG
   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
      if (ssap != NULLP && ssap->nxtUseMgcpSrvr != NULLP &&
           ssap->nxtUseMgcpSrvr->state == LMG_LSTNR_STATE_CONNECTED)
      {
         *ssapSrvr = TRUE;
         RETVALUE(ssap->nxtUseMgcpSrvr);
      }
   }
#endif /* GCP_MG */

   if (tsap != NULLP && tsap->nxtUseMgcpSrvr != NULLP && 
         tsap->nxtUseMgcpSrvr->state == LMG_LSTNR_STATE_CONNECTED)
      RETVALUE(tsap->nxtUseMgcpSrvr);
   
   RETVALUE(NULLP);

} /* end of mgMgcpGetSrvrForTx() */

/*
*
*       Fun:   mgMgcpUpdateNxtUseSrvrForTx
*
*       Desc:  This function is called once a command has been transmitted and
*              next use UDP server needs to be updated for round-robin use
*              of UDP Servers
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC Void mgMgcpUpdateNxtUseSrvrForTx
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgTSAPCb           *tsap,              /* TSAP Control Block */
Bool               ssapSrvr            /* SSAP Server Chosen or not */
)
#else
PUBLIC Void mgMgcpUpdateNxtUseSrvrForTx(ssap, tsap, ssapSrvr)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgTSAPCb           *tsap;              /* TSAP Control Block */
Bool               ssapSrvr;           /* SSAP Server Chosen or not */
#endif
{
   TRC2(mgMgcpUpdateNxtUseSrvrForTx)

   if (ssapSrvr == FALSE && tsap != NULLP)
   {
      tsap->nxtUseMgcpSrvr = mgGetLstnrForTx(NULLP, tsap,
                                             LMG_PROTOCOL_MGCP);
      RETVOID;
   }
#ifdef GCP_MG
   else
   if (ssap != NULLP && ssapSrvr == TRUE)
   {
      ssap->nxtUseMgcpSrvr = mgGetLstnrForTx(ssap, tsap,
                                             LMG_PROTOCOL_MGCP);
   }
#endif /* GCP_MG */
   else
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG039, 0,
               "[MGCP] mgMgcpUpdateNxtUseSrvrForTx: Improper Parameters \n");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
   }

   RETVOID;

} /* end of mgMgcpUpdateNxtUseSrvrForTx() */

#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
/*
*
*       Fun:   mgMgcpSendRspAckRsp
*
*       Desc:  This function composes and sends Response Ack Response to peer.
*              sent is a device level registration
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcpSendRspAckRsp
(
MgPeerCb           *peer,            /* Peer */
MgTransId          transId           /* Transaction Identifier */
)
#else
PRIVATE S16 mgMgcpSendRspAckRsp(peer,transId)
MgPeerCb           *peer;            /* Peer */
MgTransId          transId;             /* Transaction Identifier */
#endif
{
   Mem             sMem;               /* Memory Region and Pool */
   CmTptAddr       remoteAddr;         /* Remote Address */
   Bool            ssapTxSrvr;         /* SSAP Server Used for Transmission */
   Buffer          *mBuf;              /* Message Buffer */
   MgSSAPCb        *ssap;              /* SSAP Control Block */
   MgTptSrvr       *srvr;              /* Transport Server */
   S16             ret;                /* Return Value */

   TRC2(mgMgcpSendRspAckRsp)

   sMem.region = mgCb.init.region;
   sMem.pool   = mgCb.init.pool;
   ssap        = peer->ssap;


   /* Obtain a server for transmission */
   srvr = NULLP;

   if ((srvr = mgMgcpGetSrvrForTx(ssap, peer->tsap, &ssapTxSrvr)) == NULLP)
   {
      RETVALUE(RFAILED);
   }

   /* Get message buffer */
   if (mgGetMsg(peer->tsap->tsapCfg.memId.region,
                peer->tsap->tsapCfg.memId.pool, 
                &(mBuf)) != ROK)
   {
      MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL, 
                             peer->tsap->tsapCfg.memId.region,
                             peer->tsap->tsapCfg.memId.pool);
      RETVALUE(RFAILED);
   }
   /* Compose an Response Acknowledgement Response buffer */
   if (((ret = mgMgcpCompRspAckRsp(ssap, transId, peer, mBuf))) == RFAILED)
   {
      mgPutMsg(mBuf);
      RETVALUE(RFAILED);
   }
   else if(ret == ROKDNA)
   {
      RETVALUE(ROK);
   }
      
      

   remoteAddr.type = CM_TPTADDR_NOTPRSNT;

   /* Update for Round-Robin use of sockets */
   mgMgcpUpdateNxtUseSrvrForTx(ssap, peer->tsap, ssapTxSrvr);

   /* Update Statistics; Transmit the mBuf */
   MG_UPD_MGCP_PEER_TX_STS(MGT_MSG_RSP_ACK_RSP, peer->peerSts);

#ifdef    GCP_PROV_SCTP
   MG_TRANSMIT_PDU(peer, peer->assocCb, NULLP, FALSE, srvr,
                   &(remoteAddr), mBuf);
#else     /* GCP_PROV_SCTP */
   MG_TRANSMIT_PDU(peer, srvr, &(remoteAddr), mBuf);
#endif    /* GCP_PROV_SCTP */

   RETVALUE(ROK);

} /* end of mgMgcpSendRspAckRsp() */


/*
*
*       Fun:   mgMgcpCompRspAckRsp
*
*       Desc:  This function composes ResponseAckResponse.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcpCompRspAckRsp
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgTransId          transId,            /* Transaction Id */
MgPeerCb           *peer,              /* Peer Control Block */
Buffer             *mBuf               /* Message Buffer */
)
#else
PRIVATE S16 mgMgcpCompRspAckRsp (ssap, transId, peer, mBuf)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgTransId          transId;            /* Transaction Id */
MgPeerCb           *peer;              /* Peer Control Block */
Buffer             *mBuf;              /* Message Buffer */
#endif
{
   CmAbnfErr       err;                /* Encoding ABNF error structure */
   Mem             sMem;               /* Memory Region and Pool */
   U16             len;                /* Length */
   S16             ret;                /* Return Value */
   MgMgcpTxn       *txn;               /* MGCP Transaction Request */
   MgMgcpMsg       *msg;               /* MGCP Message */
   MgMgcpRsp       *rsp;               /* MGCP Response */

   TRC2(mgMgcpCompRspAckRsp)

   /* Initialise */
   sMem.region = mgCb.init.region;
   sMem.pool   = mgCb.init.pool;

   if(ROK != mgAllocEventMem( (Ptr *)&(txn), sizeof(MgMgcpTxn)) )
   {
      RETVALUE(RFAILED);
   }

   txn->numMsg = 0;

   if(ROK != mgAllocEventMem( (Ptr *)&(txn->mgcpMsg[0]), sizeof(MgMgcpMsg)) )
   {
      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
      RETVALUE(RFAILED);
   }
   else
      txn->numMsg = 1;

   /* Fill Information in the event structure */
   msg     = txn->mgcpMsg[0];
   rsp    = &(msg->t.mgcpRsp);

   msg->msgType.pres = PRSNT_NODEF;
   msg->msgType.val  = MGT_MSG_RSP;

   /* Initialise Transaction Id */
   rsp->pres.pres         = PRSNT_NODEF;
   rsp->rspCode.pres      = PRSNT_NODEF;
   rsp->rspCode.val       = MGT_MGCP_RSP_CODE_RSP_ACK_RSP;
   rsp->trId.pres         = PRSNT_NODEF;
   rsp->trId.val          = transId;
   /* Obtain memory for response string */
   len = cmStrlen((CONSTANT U8 *)"Response Acknowledgement Response");
   if (len > 0)
   {
      rsp->rspStr.pres  = PRSNT_NODEF;
      if ((cmGetMem(&(msg->memCp), len, (Ptr *)&(rsp->rspStr.val))) != ROK)
      {
         mgPutMsg(mBuf);
         MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
         RETVALUE(RFAILED);
      }

      cmMemcpy((U8 *)rsp->rspStr.val, 
         (CONSTANT U8 *)"Response Acknowledgement Response", len);
  
         /* Value of the response string length is now set */
         rsp->rspStr.len = len;
 
   }
   /* Encode the RSIP */
   ret = cmAbnfEncPduMsg(LMG_VER_PROF_MGCP_RFC2705_1_0,
                        (U8 *)&(msg->msgType), mBuf, &mgMsgDef, 
                        &(peer->tsap->tsapCfg.memId), &err);

   MG_FREE_MGCP_EVNT_MEM(txn, TRUE);

   RETVALUE(ret);

} /* end of mgMgcpCompRspAckRsp() */

#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */

#ifdef GCP_MGC

/******************************************************************************/
/*                   MGCP - MGC Specific Functions                            */
/******************************************************************************/

/*
*
*       Fun:   mgPrcRSIPCmd
*
*       Desc:  This function process the RSIP Cmd received from Network, does
*       parameter validation.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRSIPCmd
(
S16                *errAction,         /* Action to be taken on Error */
U32                *rspCode,           /* Response Code */
U32                variant,            /* variant of protocol */
MgMgcpMsg          *msg,               /* MGCP Msg */
MgPeerCb           **peerCtlBlk,       /* Peer Control Block */     
MgTptSrvr          *srvr,              /* Listener Control Block */
CmTptAddr          *tptAddr,           /* Source Transport Address */
MgTSAPCb           *tsap               /* TSAP Control Block */
)
#else
PUBLIC S16 mgPrcRSIPCmd (errAction, rspCode, variant, msg, peerCtlBlk,
                         srvr, tptAddr, tsap)
S16                *errAction;         /* Action to be taken on Error */
U32                *rspCode;           /* Response Code */
U32                variant;            /* variant of protocol */
MgMgcpMsg          *msg;               /* MGCP Msg */
MgPeerCb           **peerCtlBlk;       /* Peer Control Block */     
MgTptSrvr          *srvr;              /* Listener Control Block */
CmTptAddr          *tptAddr;           /* Source Transport Address */
MgTSAPCb           *tsap;              /* TSAP Control Block */
#endif
{
   Bool          newPeer;    /* newPeer ?? */
   MgTransId     trId;       /* Transaction Id */
   MgEPName      *endPt;     /* End Point Name */
   U8            method;     /* Restart Method */
   MgMgcpCmd     *rsip;      /* RSIP Command */
   S16           ret;        /* return value */
   MgRxTransIdEnt  *rxCb;    /* Incoming Transaction Control Block */


   TRC2(mgPrcRSIPCmd)


   /* Verify RSIP Parameters */
   if ((mgMgcpVerifyCmdParms(variant, msg, rspCode)) != ROK)
   {
      RETVALUE(RFAILED);
   }

   method = MG_NONE;

   rsip = &(msg->t.rsipCmd);

   endPt = &(rsip->cmdLine.epName);
   /* Find out the restart method */
   if (rsip->params.numParam.pres == TRUE)
      MG_FIND_RSIP_METHOD(rsip, rsip->params.numParam.val, method);

   if((ret = mgProcessRSIP (errAction, rspCode, variant, method,
                            endPt, peerCtlBlk, srvr, tptAddr,
                            &newPeer, tsap)) == ROK)
   {
      MG_MGCP_GET_TRANSID(msg, trId);
      
      rxCb = mgPrcIncomingTxn((*peerCtlBlk),tptAddr,trId,&(msg->dupInfo.pres),
                              newPeer,
#ifdef    GCP_PROV_SCTP
                              NULLP,
#endif    /* GCP_PROV_SCTP */
                              srvr, MGT_MSG_RSIP, method);
      if (rxCb == NULLP)
      {
         /* Discard the transaction if it was a new Peer */
         if (newPeer == TRUE)
         {
#ifdef ZG_DFTHA
            if(zgChkCRsetStatus())
#endif /* ZG_DFTHA */
            {
               mgDeletePeer((*peerCtlBlk), MG_IGNORE, MG_IGNORE, TRUE);
            }
#ifdef ZG_DFTHA
            else
            { 
               /* send reverse update to delete peer */
               ZgRvUpdInfo   updInfo;
               MG_FILL_RVUPD_DEL_PEER(updInfo,((*peerCtlBlk)), MG_IGNORE, MG_IGNORE,
                  TRUE);
               zgReverseUpd(&updInfo, (*peerCtlBlk)->accessInfo.peerId,
                            MG_QUEUE_NONE, tsap->tsapCfg.tSAPId);
            }
#endif /* ZG_DFTHA */
            *errAction = MG_DISCARD_TXN;
         }
         if (msg->dupInfo.pres == PRSNT_NODEF)
            *rspCode    = MG_NONE;
         else
            *rspCode    = MGT_MGCP_RSP_CODE_PROT_ERROR;

         RETVALUE(RFAILED);

      }

      /* If Response Acknowledgement is present...act on it */
      if (msg->dupInfo.pres == NOTPRSNT)
      {
         /* Process Response Acknowledgement Attribute */
         mgMgcpFindAndActOnRspAck((*peerCtlBlk), rsip);

         if (newPeer == TRUE)
         {
            /* Update the next SSAP Id */
            MG_UPDATE_NXTUSE_MGCP_SSAPID();

            MG_ISSUE_MGCPPEER_STAIND((*peerCtlBlk), LCM_CATEGORY_PROTOCOL, 
                        LMG_EVENT_PEER_ENABLED, LMG_CAUSE_RSIP_ACCEPTED);
         }
      }
   }
#ifdef ZG_DFTHA
   else if(ret == ROKDNA)
   {
      /* In Case of DFTHA Environ..only master should process RSIP message..
       * If this is not master copy then generate reverse update and return. 
       * Calling function will queue txn */
      if(!((zgChkCRsetStatus()) == TRUE))
      {
         ZgRvUpdInfo    updInfo;
         U32            peerId;
         MG_MGCP_GET_TRANSID(msg, trId);
         /* Send srvr->suRsetId as suConnId to Master,  since it also has 
            rSet emebedded into it by LDF.  */
         MG_FILL_RVUPD_RSIPCMD_PEER(updInfo,(*peerCtlBlk),(srvr->suRsetId),
               variant, method, trId, endPt, tptAddr);
         if(*peerCtlBlk == NULLP)
            peerId = MG_INVALID_PEERID;
         else
            peerId = (*peerCtlBlk)->accessInfo.peerId;
         if(peerId == MG_INVALID_PEERID)   
         {
            tsap->rvNode = 
                 (MgRvUpdQNode *)zgReverseUpd(&updInfo, peerId,
                                              MG_TSAP_TXNQ,
                                              tsap->tsapCfg.tSAPId);
         }
         else
         {
            tsap->rvNode = 
                 (MgRvUpdQNode *)zgReverseUpd(&updInfo, peerId,
                                              MG_PEER_INTXNQ,
                                              tsap->tsapCfg.tSAPId);
         }
         RETVALUE(ROKDNA);
      }
   }
#endif /* ZG_DFTHA */

   RETVALUE(ret);

} /* end of mgPrcRSIPCmd() */

/*
*
*       Fun:   mgProcessRSIP
*
*       Desc:  This function process the RSIP received from Network
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PUBLIC S16 mgProcessRSIP
(
S16                *errAction,         /* Action to be taken on Error */
U32                *rspCode,           /* Response Code */
U32                variant,            /* variant of protocol */
U8                 method,             /* Restart Method */
MgEPName           *endPt,             /* EndPoint Name */
MgPeerCb           **peerCtlBlk,       /* Peer Control Block */     
MgTptSrvr          *srvr,              /* Listener Control Block */
CmTptAddr          *srcTptAddr,        /* Source Transport Address */
Bool               *newPeer,           /* newPeer ?? */
MgTSAPCb           *tsap               /* TSAP Control Block */
)
#else
PUBLIC S16 mgProcessRSIP (errAction, rspCode, variant, method, endPt,
                          peerCtlBlk, srvr, srcTptAddr, newPeer, tsap)
S16                *errAction;         /* Action to be taken on Error */
U32                *rspCode;           /* Response Code */
U32                variant;            /* variant of protocol */
U8                 method;             /* Restart Method */
MgEPName           *endPt;             /* EndPoint Name */
MgPeerCb           **peerCtlBlk;       /* Peer Control Block */     
MgTptSrvr          *srvr;              /* Listener Control Block */
CmTptAddr          *srcTptAddr;        /* Source Transport Address */
Bool               *newPeer;           /* newPeer ?? */
MgTSAPCb           *tsap;              /* TSAP Control Block */
#endif
{
   MgSSAPCb        *ssap;              /* SSAP Control Block */
   MgPeerCb        *peer;              /* Peer Control Block */
   MgDName         dname;              /* Domain Name */
   Bool            chkRspParam;        /* Check Response Parameters */
   MgNetAddrTbl    addrTbl;           /* Network Addresses of the Peer */

   TRC2(mgProcessRSIP)

   peer        = *peerCtlBlk;
   *newPeer     = FALSE;
   chkRspParam = FALSE;


   if (peer == NULLP)
   {
#ifdef ZG_DFTHA
      if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
      {
         /* Locate Peer from the domain name specified in command */
         dname.namePres.pres = NOTPRSNT;
         peer = mgRslvDomainNameStr(endPt->domainName.len, 
            endPt->domainName.val, &dname);

         if (peer == NULLP)
         {
            if ((mgMgcpChkForNewPeerInRSIP (method, peerCtlBlk, srcTptAddr, 
                 endPt, &dname, newPeer)) != ROK)
            {
               *errAction = MG_DISCARD_TXN;
               *rspCode   = MGT_MGCP_RSP_CODE_PROT_ERROR;
               RETVALUE(RFAILED);
            }
            else
            {
               peer = *peerCtlBlk;
            }

            if (*newPeer == TRUE)
            {
               /* RSIP Response from Service User needs to be checked */
               chkRspParam = TRUE;

               /* 
               * We assume that RSIP was received on a default listener...if 
               * round robin for this listener is disabled i.e. it is attached 
               * to an SSAP then give the RSIP on that SSAP else use round-robin
               * methodology to obtain an SSAP
               */
               if (srvr->t.ssap == NULLP)
                  ssap = (mgCb.sSAPLst[mgCb.nxtMgcpSsapId]);
               else
                  ssap = srvr->t.ssap;

               /* learn the new MG */
               peer = mgMgcpLearnNewPeerFromRSIP(ssap, tsap, srcTptAddr, &dname,
                                                 srvr, variant);
               if (peer == NULLP)
               {
                  *errAction = MG_DISCARD_TXN;
                  *rspCode   = MGT_MGCP_RSP_CODE_PROT_ERROR;
                  RETVALUE(RFAILED);
               }

               /* Store the peer pointer for return to calling function */
               *peerCtlBlk = peer;
#ifdef GCP_VER_1_3
               /* If this is new peer resolve it */
               if (peer->accessInfo.namePres)
               {
                  if ((mgCb.dnsTsap != MG_INVALID_TSAP_ID) &&
                      (mgCb.tSAPLst[mgCb.dnsTsap]) &&
                      (mgCb.tSAPLst[mgCb.dnsTsap]->tsapCfg.reCfg.\
                       dnsCfg.dnsAccess != LMG_DNS_DISABLED))
                  {
                     /* need to resolve */
                     mgSendDnsRslvReq(peer, peer->accessInfo.name);
                  }
               }
#endif /* GCP_VER_1_3 */
            }
            
            /* If peer still not found */
            if (peer == NULLP)
            {
               *errAction = MG_DISCARD_TXN;
               *rspCode   = MGT_MGCP_RSP_CODE_PROT_ERROR;
               RETVALUE(RFAILED);
            }

            /*
             *   Initialize the tsap field of peer
             */
            peer->tsap = tsap;
         } /* If peer not found from domain name */
         else
         {
            /* Store the peer pointer for return to calling function */
            *peerCtlBlk = peer;

            /*
             *   Initialize the tsap field of peer
             */
            peer->tsap = tsap;

         }

         if (peer->state == LMG_PEER_STATE_AWAIT_REG)
            peer->state = LMG_PEER_STATE_REGISTER;
      } /* end of if for Master */
#ifdef ZG_DFTHA
      else
         RETVALUE(ROKDNA);
#endif /* ZG_DFTHA */
   } /* if peer is NULLP */
   else
   {
      /* For configured peer, learn variant if not known */
#ifdef GCP_MGC
      if (mgCb.genCfg.entType == LMG_ENT_GC)
      {
         /*
          *   Initialize the tsap field of peer
          */
         peer->tsap = tsap;

         if (peer->mntInfo.variant == MG_NONE)
         {
#ifdef ZG_DFTHA 
            if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
            {
               peer->mntInfo.variant = variant;

#ifdef ZG
               zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC,
                   CMPFTHA_ACTN_MOD);
#endif /* ZG */
            }
#ifdef ZG_DFTHA
            else
               RETVALUE(ROKDNA);
#endif /* ZG_DFTHA */
         }
      }
#endif /* GCP_MGC */
      /*
       * Check if Association with the peer was previously lost due to 
       * Retransmission Algorithm expiry; If yes, then accept the RSIP 
       * only if MG is sending the Restart either with method as "restart" 
       * to register or method as disconnected; Else discard it
       */
      if (peer->state == LMG_PEER_STATE_DISCONNECTED)
      {
         if ((endPt->lclName.pres != NOTPRSNT) && 
             ((method == MGT_PARAM_RSTRT_RSTRT) ||
              (method == MGT_PARAM_RSTRT_DISC)))
         {
            /* RSIP Response from Service User needs to be checked */
            chkRspParam = TRUE;
#ifdef ZG_DFTHA 
            if(((zgChkCRsetStatus()) == TRUE))
            {
#endif /* ZG_DFTHA */
               peer->state = LMG_PEER_STATE_REGISTER;

               /*
                *   Initialize the tsap field of peer
                */
               peer->tsap = tsap;

#ifdef ZG
               zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC,
                   CMPFTHA_ACTN_MOD);
               zgUpdPeer();
#endif /* ZG */
#ifdef ZG_DFTHA 
            }
            else
               RETVALUE(ROKDNA);
#endif /* ZG_DFTHA */
            
         }
         else
         {
            *errAction = MG_DISCARD_TXN;
            *rspCode   = MGT_MGCP_RSP_CODE_PROT_ERROR;
            RETVALUE(RFAILED);
         }
      }
      else if ( (peer->state == LMG_PEER_STATE_AWAIT_REG) ||
                (peer->state == LMG_PEER_STATE_NULL) )
      {
         /* RSIP Response from Service User needs to be checked */
         chkRspParam = TRUE;
#ifdef ZG_DFTHA
         if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
         {
           peer->state = LMG_PEER_STATE_REGISTER;

           /*
            *   Initialize the tsap field of peer
            */
           peer->tsap = tsap;

           /* Learn IP addr if not available */
           if(peer->accessInfo.peerAddrTbl.count == 0)
           {
              addrTbl.count = 1;
              /* IPV4/IPV6 changes, copy NetAddress */
              MG_FILL_NETADDR_FRM_TPTADDR(&(addrTbl.netAddr[0]),
                                          srcTptAddr);
              if ((mgUpdatePeerIpAddr(peer, &addrTbl)) != ROK)
              {
                 RETVALUE(RFAILED);
              }
           }
#ifdef ZG
            zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD);
            zgUpdPeer();
#endif /* ZG */
         }
#ifdef ZG_DFTHA
         else
            RETVALUE(ROKDNA);
#endif /* ZG_DFTHA */
      }
   }

   /* Update Statistics */
   MG_UPD_MGCP_PEER_RX_STS((MGT_MSG_RSIP), peer->peerSts, MG_NONE);

   if (*newPeer != TRUE)
   {
      /* Check if we have resources to allocate in our layer */
      if (mgAdmitTxn(peer->ssap, tsap) != ROK)
      {
         *rspCode   = MGT_MGCP_RSP_CODE_PROT_ERROR;
         RETVALUE(RFAILED);
      }
   }
   else
   {
      *peerCtlBlk = peer;
#ifdef ZG
      if(zgChkCRsetStatus())
      {
         /* Only master should generate update */
         zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_ADD);
         zgUpdPeer();
      }
#endif /* ZG */
   }

   /*
    * Set Bool *newPeer = TRUE, if chkRspParam is TRUE. This check over here
    * will ensure that the newPeer is set even if the peer was aviable, but
    * RSIP response needs to be checked for in outgoing path. For peer not
    * avialble, this has already been set earlier.
    */
   if(chkRspParam == TRUE)
      *newPeer = TRUE;

   RETVALUE(ROK);

} /* end of mgProcessRSIP() */





/*
*
*       Fun:   mgMgcpChkForNewPeerInRSIP
*
*       Desc:  This function is called while processing received RSIP from 
*              the network and looks for the presence of a new Peer or learns
*              domain name if required
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Invoked from mgMgcpProcessRSIP
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcpChkForNewPeerInRSIP
(
U8                 method,             /* RSIP Method */
MgPeerCb           **peerCtlBlk,       /* Peer Control Block */     
CmTptAddr          *srcTptAddr,        /* Source Transport Address */
MgEPName           *endPt,             /* End Point Name */
MgDName            *dname,             /* Domain Name */
Bool               *newPeer            /* New Peer or not ? */
)
#else
PRIVATE S16 mgMgcpChkForNewPeerInRSIP (method, peerCtlBlk, srcTptAddr, 
                                       endPt, dname, newPeer)
U8                 method;             /* RSIP Method */
MgPeerCb           **peerCtlBlk;       /* Peer Control Block */     
CmTptAddr          *srcTptAddr;        /* Source Transport Address */
MgEPName           *endPt;             /* End Point Name */
MgDName            *dname;             /* Domain Name */
Bool               *newPeer;           /* New Peer or not ? */
#endif
{
   MgPeerCb        *peer;              /* Peer Control Block */
   MgIpAddrEnt     *ipAddrEnt;         /* IP Address Entry */

   TRC2(mgMgcpChkForNewPeerInRSIP)

   /* Initialise */
   *peerCtlBlk = NULLP;
   peer        = NULLP;
   *newPeer    = FALSE;

   /* search for the peer using IP Address received from UDP */
   ipAddrEnt = NULLP;
   mgFindIpAddrLst(srcTptAddr->type, &(srcTptAddr->u.ipv4TptAddr.address),
                   &(srcTptAddr->u.ipv6TptAddr.ipv6NetAddr), 
                   MG_HASH_SEQNMB_DEF, &ipAddrEnt);

   if (ipAddrEnt != NULLP)
   {
      /* 
       * Modify the type of nameLen to U16 as endPt->domainName.len is U16.
       */
      U16   nameLen =  endPt->domainName.len;

      peer = ipAddrEnt->peer;

      if (dname->namePres.pres == PRSNT_NODEF)
      {
        /* Update the database with peer name */
        cmMemcpy((U8 *)peer->accessInfo.name, (CONSTANT U8 *)dname->name,
                 nameLen);
        
        if ((cmHashListInsert (&(mgCb.peerNameLst), (PTR) peer, 
                               peer->accessInfo.name, nameLen)) != ROK)
        {
          peer->accessInfo.name[0] = '\0';
          RETVALUE(RFAILED);
        }
        else
          peer->accessInfo.namePres = TRUE;
      }

      *peerCtlBlk = peer;
   }
   else
   {
      /* 
       * It is a new peer entity not known to MGC as yet
       * Registration can be taken as  method as "restart" 
       */
      if ((endPt->lclName.pres != NOTPRSNT) && 
          (method == MGT_PARAM_RSTRT_RSTRT))
      {
         /* "*" for Registration not required */
         *newPeer = TRUE;
      }
      else
      {
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);

} /* end of mgMgcpChkForNewPeerInRSIP() */




/*
*
*       Fun:   mgMgcpLearnNewPeerFromRSIP
*
*       Desc:  This function to learn new peer from the RSIP. The new peer 
*              information will be added to GCP database
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Invoked from mgMgcpProcessRSIP
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PRIVATE MgPeerCb * mgMgcpLearnNewPeerFromRSIP
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgTSAPCb           *tsap,              /* TSAP Control Block */
CmTptAddr          *srcTptAddr,        /* Source Transport Address */
MgDName            *dname,             /* Domain Name */
MgTptSrvr          *srvr,              /* Transport Server */
U32                variant             /* RSIP Command */
)
#else
PRIVATE MgPeerCb * mgMgcpLearnNewPeerFromRSIP (ssap, tsap, srcTptAddr, dname, srvr,
                                               variant)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgTSAPCb           *tsap;              /* TSAP Control Block */
CmTptAddr          *srcTptAddr;        /* Source Transport Address */
MgDName            *dname;             /* Domain Name */
MgTptSrvr          *srvr;              /* Transport Server */
U32                variant;            /* RSIP Command */
#endif
{
   U16             addrCount;          /* Address count */
   MgPeerInitInfo  init;               /* Peer Initialisation Information */
   MgPeerCb        *peer;              /* Peer Control Block */

   /* Initialise */
   addrCount = 0;
   peer      = NULLP;
   cmMemset((U8 *)&(init), 0 , sizeof(MgPeerInitInfo));

   /* Check if we have resources to allocate in our layer */
   if (mgAdmitTxn(ssap, tsap) != ROK)
      RETVALUE(NULLP);

   if (dname->namePres.pres == PRSNT_NODEF)
   {
      /* Copy Domain Name */
      cmMemcpy((U8 *)init.name,(CONSTANT U8 *)dname->name, CM_DNS_DNAME_LEN);
   }
   else
   {
      /* learn the address received as part of endpoint name */
      if (((dname->netAddr.type ==  CM_NETADDR_IPV4) &&
           (cmMemcmp((U8 *)&(srcTptAddr->u.ipv4TptAddr.address),
                     (CONSTANT U8 *) &(dname->netAddr.u.ipv4NetAddr),
                     sizeof(CmIpv4NetAddr)) != 0)) ||
          ((dname->netAddr.type ==  CM_NETADDR_IPV6) &&
           (cmMemcmp((U8 *)&(srcTptAddr->u.ipv6TptAddr.ipv6NetAddr),
                     (CONSTANT U8 *) &(dname->netAddr.u.ipv6NetAddr),
                     sizeof(CmIpv6NetAddr)) != 0)))

      {
         cmMemcpy((U8 *)&(init.addrTbl.netAddr[addrCount++]), 
                  (CONSTANT U8 *) &(dname->netAddr), sizeof(CmNetAddr));
      }
   }

   init.addrTbl.netAddr[addrCount].type = srcTptAddr->type;
   /* learn address from source address of RSIP */
   /* IPV4/IPV6 changes, copy NetAddress */
   MG_FILL_NETADDR_FRM_TPTADDR(&(init.addrTbl.netAddr[addrCount]),
                               srcTptAddr);
   addrCount++;
   init.addrTbl.count = addrCount;

   init.variant = variant;


   init.mgcpInfo.suspThold   = tsap->tsapCfg.reCfg.defSuspThold;
   init.mgcpInfo.disconThold = tsap->tsapCfg.reCfg.defDisConThold;
   init.transportType        = LMG_TPT_UDP;
   init.protocolType         = LMG_PROTOCOL_MGCP;
   init.byCfg                = FALSE;
   init.remotePort           = LMG_INVALID_PEER_PORT;
   init.ttl                  = tsap->ttl;
   init.trcLen               = MG_DEFAULT_TRC_LEN;
   init.mtuSize              = MG_MAX_UDP_MTU_SIZE;
#ifdef ZG
   init.peerId = MG_INVALID_PEERID;
   init.mtdPeerId = MG_INVALID_PEERID;
#ifdef ZG_DFTHA
   init.suConnId = srvr->suRsetId;
#endif /* ZG_DFTHA */
#endif /* ZG */

   if (ssap->ssapCfg.reCfg.initRetxTmr.enb == TRUE)
   {
      init.initRtt = ssap->ssapCfg.reCfg.initRetxTmr.val;
   }
   else
      init.initRtt = (MG_INIT_RTT_VALUE * mgCb.genCfg.timeRes);

   /* Allocate a new Peer Control Block */
   if ((peer = mgAllocPeerCb(ssap, &init)) == NULLP)
      RETVALUE(NULLP);

   /*
    *   Initialize the tsap field of peer
    */
   peer->tsap = tsap;

   /* 
    * Update peer state to register and wait for positive response from 
    * Service User to make it active
    */
   peer->state = LMG_PEER_STATE_REGISTER;

#ifdef ZG
   /* Do add mapping and send runtime update to standby/shadows */
   ZG_INIT_RSETID_IN_MAPCB(&(peer->mapCb));
   zgAddMapping(ZG_CBTYPE_PEER,(Ptr)peer);
#endif /* ZG */

   RETVALUE(peer);

} /* end of mgMgcpLearnNewPeerFromRSIP() */

#endif /* GCP_MGC */


#ifdef GCP_MG

/******************************************************************************/
/*                    MGCP - MG Specific Functions                            */
/******************************************************************************/

/*
*
*       Fun:   mgMgcpPrcRSIPResponse
*
*       Desc:  This function processes the response received for the RSIP
*              command previously transmitted
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: The function looks for the presence of the new call agent and
*              takes appropriate action accordingly
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PUBLIC S16 mgMgcpPrcRSIPResponse
(
S16                *errAction,         /* Action to be taken on Error */
U32                *action,            /* Action Taken */
MgPeerCb           *peer,              /* Peer Control Block */
U32                rspCode,            /* Response Code */
MgNtfiedEnt        *ntfiedEnt,         /* MGCP notified entity */
U32                variant,            /* variant */ 
MgTransId          trId                /* transaction id */
)
#else
PUBLIC S16 mgMgcpPrcRSIPResponse(errAction, action, peer, rspCode, ntfiedEnt, variant, trId)
S16                *errAction;         /* Action to be taken on Error */
U32                *action;            /* Action Taken */
MgPeerCb           *peer;              /* Peer Control Block */
U32                rspCode;            /* Response Code */
MgNtfiedEnt        *ntfiedEnt;         /* MGCP notified entity */
U32                variant;            /* variant */ 
MgTransId          trId;               /* transaction id  */
#endif
{
   MgPeerCb        *newPeer;           /* New Peer Control Block */
#ifdef ZG_DFTHA
   S16             ret;                /* return value */
#endif /* ZG_DFTHA */

   TRC2(mgMgcpPrcRSIPResponse)

   newPeer = NULLP;

   /* RSIP Response can have notified entity; learn it */
#ifdef ZG_DFTHA
   ret = mgMgcpChkAndPrcNtfiedEntity(ntfiedEnt, peer, &newPeer, variant);

   if(ret == ROKDNA)
   {
      /* Send reverse update for notofied entity parameter..but don't queue the
       * message */
      ZgRvUpdInfo  updInfo;
      MG_FILL_RVUPD_NTFIEDENT(updInfo,peer,variant,ntfiedEnt);
      zgReverseUpd(&updInfo, peer->accessInfo.peerId, MG_QUEUE_NONE,
                   peer->tsap->tsapCfg.tSAPId);
   }
#else
   mgMgcpChkAndPrcNtfiedEntity(ntfiedEnt, peer, &newPeer, variant); 
#endif /* ZG_DFTHA */

   if (peer->state == LMG_PEER_STATE_REGISTER)
   {
      if (rspCode == MG_RESPONSE_OK)
      {
#ifdef ZG_DFTHA
         /* only master should modify state of peer */
         if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
         {
            peer->state = LMG_PEER_STATE_ACTIVE;
         
            /*
            * If GCP layer generated RSIP for registration, then the 
            * transaction response shouldn't be communicated to the 
            * Service User. Else if user generated RSIP, indicate the response
            * to the user
            */
            if (peer->ssap->ssapCfg.initReg == TRUE)
            {
               /*
                * Compare with the transactionId of the received message, rather
                * than comparing with MG_INVALID_TRANSID. Whenever the stack
                * generates RSIP, it stores the trId in peer->regReqTxnId.
                * Compare it with this trId
                */
               if (peer->regReqTxnId == trId)
               {
                  /* GCP layer generated RSIP */
                  peer->regReqTxnId  = MG_INVALID_TRANSID;
                  *errAction         = MG_DISCARD_TXN;
                  *action            = MG_REGISTER_RSP_OK;
               }
               
               RETVALUE(ROK);
            }
         } 
#ifdef ZG_DFTHA
         else
         {
            RETVALUE(ROKDNA);
         }
#endif /* ZG_DFTHA */
      }
      else if(rspCode == MG_RESPONSE_ERR)
         /* If response is negative i.e RSIP failed */
      {
         if (peer->ssap->ssapCfg.initReg == TRUE)
         {
#ifdef ZG_DFTHA
            if(zgChkCRsetStatus() == TRUE)
#endif /* ZG_DFTHA */
            {
               /* 
               * If we have generated RSIP; don't indicate it to the
               * Service User
               */
               /*
                * Compare with the transactionId of the received message, rather
                * than comparing with MG_INVALID_TRANSID. Whenever the stack
                * generates RSIP, it stores the trId in peer->regReqTxnId.
                * Compare it with this trId
                */
               if (peer->regReqTxnId == trId)
               {
                  /* GCP Layer generated RSIP */
                  peer->regReqTxnId  = MG_INVALID_TRANSID;
                  *errAction         = MG_DISCARD_TXN;
                  *action            = MG_REGISTER_SENT;
               }

               /*
               * If RSIP had been sent to Register MG (device) with the MGC and
               * the response to RSIP is negative and a new notified entity is
               * present then we should try to contact the new MGC if we are
               * configured to send RSIPs for registration
               */
               if (newPeer != NULLP)
               {         
                  /* 
                  * If we are still under registration process and we initiated
                  * RSIP, we need to send RSIP to new Call Agent
                  */
                  mgMgcpSendRSIP(newPeer, MGT_PARAM_RSTRT_RSTRT);
               }
               RETVALUE(RFAILED);
            }
#ifdef ZG_DFTHA
            else
            {
               RETVALUE(ROKDNA);
            }
#endif /* ZG_DFTHA */
         }
         else
         {
            /* 
            * If user initiated the RSIP, the response should be sent to the
            * user. We should also remove peer assoc in this case 
            */
            /*
               * Delete the peer in case of a negative RSIP response only if 
               * this flag is defined. If this flag is not defined, just
               * indicate the received transaction to SU.
               */
#ifndef GCP_USER_RETX_CNTRL
            *errAction         = MG_DELETE_PEER_PASS_TXN;
#endif /* GCP_USER_RETX_CNTRL */
            *action            = MG_NONE;
         }          
      } /* if rspCode not ok */
   }
   RETVALUE(ROK);

} /* end of mgMgcpPrcRSIPResponse() */


/*
*
*       Fun:   mgMgcpSendRSIP
*
*       Desc:  This function composes and sends RSIP to a specified MGC.The RSIP
*              sent is a device level registration
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PUBLIC S16 mgMgcpSendRSIP
(
MgPeerCb           *callAgent,          /* Call Agent */
U8                 mthd                 /* restart method */
)
#else
PUBLIC S16 mgMgcpSendRSIP(callAgent, mthd)
MgPeerCb           *callAgent;         /* Call Agent */
U8                 mthd;               /* restart method */
#endif
{
   U8              oldState;           /* Previous State of the peer */
   Mem             sMem;               /* Memory Region and Pool */
   MgTransId       transId;            /* Transaction Identifier */
   CmTptAddr       remoteAddr;         /* Remote Address */
   Bool            unUsedVar;          /* Unused Variable */
   Bool            ssapTxSrvr;         /* SSAP Server Used for Transmission */
   Buffer          *mBuf;              /* Message Buffer */
   S16             ret;                /* Return Value */
   Buffer          *txMbuf;            /* Message Buffer for Transmission */
   MgSSAPCb        *ssap;              /* SSAP Control Block */
   MgTptSrvr       *srvr;              /* Transport Server */
   MgTxTransIdEnt  *txCb;              /* Command Transaction Control Block */
#ifdef GCP_VER_1_3
   MgTxBufInfo     *txBufInfo;         /* Transmitted buffer info */
#endif /* GCP_VER_1_3 */

   TRC2(mgMgcpSendRSIP)

   sMem.region = mgCb.init.region;
   sMem.pool   = mgCb.init.pool;
   oldState    = callAgent->state;
   ssap        = callAgent->ssap;
#ifdef GCP_VER_1_3
   txBufInfo   = NULLP;
#endif /* GCP_VER_1_3 */

   /*
    * If callAgent is in resolving state, compose the rsip and queue; else
    * we can transmit
    */
   if ((oldState != LMG_PEER_STATE_RESOLVING) &&
       (oldState != LMG_PEER_STATE_AWAIT_REG)) 
   {
      /* Invalid State */
      RETVALUE(RFAILED);
   }

   /* Obtain a server for transmission */
   srvr = NULLP;

   if ((srvr = mgMgcpGetSrvrForTx(ssap, callAgent->tsap, &ssapTxSrvr)) == NULLP)
   {
      RETVALUE(RFAILED);
   }

   /* 
    * Update the state to Register if we will be able to transmit
    * RSIP
    */
   if (oldState != LMG_PEER_STATE_RESOLVING)
      callAgent->state = LMG_PEER_STATE_REGISTER;

   if (mgGetMsg(callAgent->tsap->tsapCfg.memId.region,
                callAgent->tsap->tsapCfg.memId.pool, 
                &(mBuf)) != ROK)
   {
      if (oldState  != LMG_PEER_STATE_RESOLVING)
      {
         callAgent->state = LMG_PEER_STATE_AWAIT_REG;
      }
#ifdef ZG
      /* send update to peer */
      zgRtUpd(ZG_CBTYPE_PEER, (Ptr)callAgent, CMPFTHA_UPDTYPE_SYNC,
         CMPFTHA_ACTN_MOD);
#endif /* ZG */
      /* Use the MGCP specific macro */
      MG_ISSUE_MGCPPEER_STAIND(callAgent, LCM_CATEGORY_RESOURCE, 
                           LCM_EVENT_DMEM_ALLOC_FAIL,
                           LMG_CAUSE_SEND_REGISTER);

      RETVALUE(RFAILED);
   }

   /* Obtain Transaction Id for use */
   MG_OBTAIN_TRANSID(ssap, &transId, LMG_PROTOCOL_MGCP);

   /* Compose an RSIP buffer */
   if ((ret = 
         mgMgcpComposeRSIP(ssap, transId, mthd, (U8 *)MG_DEVICE_REG_EPNAME,
                          mBuf, callAgent)) == RFAILED)
   {
      if (oldState  != LMG_PEER_STATE_RESOLVING)
         callAgent->state = LMG_PEER_STATE_AWAIT_REG;

#ifdef ZG
      /* send update to peer */
      zgRtUpd(ZG_CBTYPE_PEER, (Ptr)callAgent, CMPFTHA_UPDTYPE_SYNC,
         CMPFTHA_ACTN_MOD);
#endif /* ZG */
      mgPutMsg(mBuf);
      RETVALUE(RFAILED);
   }

   remoteAddr.type = CM_TPTADDR_NOTPRSNT;
#ifdef GCP_2705BIS
   if((txBufInfo = (MgTxBufInfo *)mgMalloc(sizeof(MgTxBufInfo))) ==
           NULLP)
   {
      MG_ISSUE_MGCPPEER_STAIND(callAgent, LCM_CATEGORY_RESOURCE, 
                           LCM_EVENT_DMEM_ALLOC_FAIL,
                           LMG_CAUSE_SEND_REGISTER);
   }
   txBufInfo->mBuf = mBuf;
   txBufInfo->expctdRspCnt = 1;
   txBufInfo->rcvdRspCnt =0;
   txBufInfo->retxCnt = 0;

   if ((txCb = mgPrcOutGoingTxn(transId, MGT_MSG_RSIP, MG_NONE, FALSE, 
                               &remoteAddr, ssap, callAgent,
#ifdef    GCP_PROV_SCTP
                               NULLP,
#endif    /* GCP_PROV_SCTP */
                               srvr, 
                               (Void *)txBufInfo, &unUsedVar)) == NULLP)
#else
   if ((txCb = mgPrcOutGoingTxn(transId, MGT_MSG_RSIP, MG_NONE, FALSE, 
                                &remoteAddr, ssap, callAgent, 
#ifdef    GCP_PROV_SCTP
                               NULLP,
#endif    /* GCP_PROV_SCTP */
                               srvr, 
                               (Void *)mBuf, &unUsedVar)) == NULLP)
#endif
   {
      if (oldState  != LMG_PEER_STATE_RESOLVING)
         callAgent->state = LMG_PEER_STATE_AWAIT_REG;

#ifdef ZG
      /* send update to peer */
      zgRtUpd(ZG_CBTYPE_PEER, (Ptr)callAgent, CMPFTHA_UPDTYPE_SYNC,
         CMPFTHA_ACTN_MOD);
#endif /* ZG */
      /* Free message buffer */
      mgPutMsg(mBuf);

      /* Inform Layer Manager */
      /* Use the MGCP specific macro */
      MG_ISSUE_MGCPPEER_STAIND(callAgent, LCM_CATEGORY_RESOURCE, 
                           LCM_EVENT_SMEM_ALLOC_FAIL,
                           LMG_CAUSE_SEND_REGISTER);
      RETVALUE(RFAILED);
   }

   /* Store the transaction Id of registration request */
   callAgent->regReqTxnId = transId;

#ifdef ZG
      /* send update to peer */
   zgRtUpd(ZG_CBTYPE_PEER, (Ptr)callAgent, CMPFTHA_UPDTYPE_SYNC,
      CMPFTHA_ACTN_MOD);
#endif /* ZG */
   /* If mBuf can't be transmitted now, return */
   if (callAgent->state != LMG_PEER_STATE_REGISTER)
      RETVALUE(ROK);

   /* 
    * Since TUCL will free the message buffer after transmission and GCP needs
    * buffer for retransmission, increment the reference count for the mBuf
    */
   if ((SAddMsgRef (mBuf, callAgent->tsap->tsapCfg.memId.region, 
                    callAgent->tsap->tsapCfg.memId.pool, &(txMbuf))) != ROK)
   {
      if (oldState  != LMG_PEER_STATE_RESOLVING)
         callAgent->state = LMG_PEER_STATE_AWAIT_REG;

      mgPutMsg(mBuf);

#ifdef ZG
      /* send update to peer */
      zgRtUpd(ZG_CBTYPE_PEER, (Ptr)callAgent, CMPFTHA_UPDTYPE_SYNC,
         CMPFTHA_ACTN_MOD);
#endif /* ZG */
      /* Use the MGCP specific macro */
      MG_ISSUE_MGCPPEER_STAIND(callAgent, LCM_CATEGORY_RESOURCE, 
                           LCM_EVENT_DMEM_ALLOC_FAIL,
                           LMG_CAUSE_SEND_REGISTER);
      RETVALUE(RFAILED);
   }

   /* Update for Round-Robin use of sockets */
   mgMgcpUpdateNxtUseSrvrForTx(ssap, callAgent->tsap, ssapTxSrvr);

   /* Update Statistics; Transmit the mBuf */
   MG_UPD_MGCP_PEER_TX_STS(MGT_MSG_RSIP, callAgent->peerSts);

#ifdef    GCP_PROV_SCTP
   MG_TRANSMIT_PDU(callAgent, callAgent->assocCb, NULLP, FALSE,
                   srvr, &(remoteAddr), txMbuf);
#else     /* GCP_PROV_SCTP */
   MG_TRANSMIT_PDU(callAgent, srvr, &(remoteAddr), txMbuf);
#endif    /* GCP_PROV_SCTP */

   RETVALUE(ROK);

} /* end of mgMgcpSendRSIP() */


/*
*
*       Fun:   mgMgcpComposeRSIP
*
*       Desc:  This function composes RSIP to a specified MGC. The RSIP
*              composed is a device level registration
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PUBLIC S16 mgMgcpComposeRSIP
(
MgSSAPCb           *ssap,              /* SSAP control block */
MgTransId          transId,            /* Transaction Id */
U8                 mthd,               /* Method */
U8                 *lclName,           /* Local Name */
Buffer             *mBuf,              /* Message Buffer */
MgPeerCb           *peer               /* peer control block */
)
#else
PUBLIC S16 mgMgcpComposeRSIP (ssap, transId, mthd, lclName, mBuf, peer)
MgSSAPCb           *ssap;              /* SSAP control block */
MgTransId          transId;            /* Transaction Id */
U8                 mthd;               /* Method */
U8                 *lclName;           /* Local Name */
Buffer             *mBuf;              /* Message Buffer */
MgPeerCb           *peer;              /* peer control block */
#endif
{
   CmAbnfErr       err;                /* Encoding ABNF error structure */
   Mem             sMem;               /* Memory Region and Pool */
   U16             len;                /* Length */
   S16             ret;                /* Return Value */
   CmNetAddr       *netAddr;           /* Net Address */
   MgMgcpTxn       *txn;               /* MGCP Transaction Request */
   MgMgcpMsg       *msg;               /* MGCP Message */
   MgMgcpCmd       *rsip;              /* RSIP Command */
   MgMgcpCmdLine   *cmdLine;           /* MGCP Command Line */
   MgEPName        *epName;            /* Endpoint Name */
   U8              *profile;           /* Supported Profile */
   MgMgcpParam     *param;             /* MGCP Parameter */
   U8              s[MG_DNAME_FRMT2_LEN]; /* Array for[a.b.c.d] format */

   TRC2(mgMgcpComposeRSIP)

   /* Initialise */
   sMem.region = mgCb.init.region;
   sMem.pool   = mgCb.init.pool;

   if(ROK != mgAllocEventMem( (Ptr *)&(txn), sizeof(MgMgcpTxn)) )
   {
      RETVALUE(RFAILED);
   }

   txn->numMsg = 0;

   if(ROK != mgAllocEventMem( (Ptr *)&(txn->mgcpMsg[0]), sizeof(MgMgcpMsg)) )
   {
      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
      RETVALUE(RFAILED);
   }
   else
      txn->numMsg = 1;

   /* Fill Information in the event structure */
   msg     = txn->mgcpMsg[0];
   rsip    = &(msg->t.rsipCmd);
   cmdLine = &(rsip->cmdLine);

   msg->msgType.pres = PRSNT_NODEF;
   msg->msgType.val  = MGT_MSG_RSIP;

   /* Initialise Transaction Id */
   rsip->pres.pres         = PRSNT_NODEF;
   rsip->cmdLine.pres.pres = PRSNT_NODEF;
   rsip->cmdLine.trId.pres = PRSNT_NODEF;
   rsip->cmdLine.trId.val  = transId;

   /* Initialise endpoint name information */
   epName               = &(rsip->cmdLine.epName);
   epName->pres.pres    = PRSNT_NODEF;
   epName->lclName.pres = PRSNT_NODEF;
   len  = cmStrlen((CONSTANT U8 *)lclName);

   if ((cmGetMem(&(msg->memCp), len, (Ptr *)&(epName->lclName.val))) != ROK)
   {
      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
      RETVALUE(RFAILED);
   }

   /* Send RSIP for all endpoints */
   cmMemcpy(epName->lclName.val, (CONSTANT U8 *)lclName, len);
   epName->lclName.len    = len;

   /* Initialise domain name in a suitable format */
   if (ssap->ssapCfg.userInfo.dname.namePres.pres == PRSNT_NODEF)
   {
      /* domain name is in www.trillium.com format */
      len = cmStrlen(ssap->ssapCfg.userInfo.dname.name);
   }
   else
   {
      netAddr = &(ssap->ssapCfg.userInfo.dname.netAddr);

      if (((netAddr->type == CM_NETADDR_IPV4) && 
           (netAddr->u.ipv4NetAddr != 0)) ||
          (netAddr->type == CM_NETADDR_IPV6))
      {
         /*
          * "len" should not be typecasted to U8 as change of size leads to a
          * junk value.
          */
         /* Fill domain name in [a.b.c.d] format */
         mgConvertIpAddrToAscii(netAddr, &(s[0]), 
                                (U8)MG_DNAME_FRMT2_LEN, &len,
                                LMG_PROTOCOL_MGCP);
      }
      else
      {
         MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
         RETVALUE(RFAILED);
      }
   }

   /* Initialise domain name */
   epName->domainName.pres = PRSNT_NODEF;
   epName->domainName.len = len;
   if ((cmGetMem(&(msg->memCp), len, (Ptr *)&(epName->domainName.val))) != ROK)
   {
      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
      RETVALUE(RFAILED);
   }

   if (ssap->ssapCfg.userInfo.dname.namePres.pres == PRSNT_NODEF)
   {
      cmMemcpy(epName->domainName.val, 
               (CONSTANT U8 *)ssap->ssapCfg.userInfo.dname.name, len);
   }
   else
   {
      cmMemcpy(epName->domainName.val, (CONSTANT U8 *)s, len);
   }

   /* Initialise MGCP Version */
   cmdLine->mgcpVer.pres.pres   = PRSNT_NODEF;
   cmdLine->mgcpVer.major.pres  = PRSNT_NODEF;
   cmdLine->mgcpVer.minor.pres  = PRSNT_NODEF;

   /* Initialise profile to NULLP */
   profile = NULLP;
   len     = 0;
   switch (ssap->ssapCfg.mgcpVersion)
   {
      case LMG_VER_PROF_MGCP_RFC2705_1_0:
        len =0;
        break;

      case LMG_VER_PROF_MGCP_TGCP_1_0:
        {
          profile = (U8 *)"TGCP 1.0";
          len = cmStrlen(profile);
        }
        break;
      case LMG_VER_PROF_MGCP_NCS_1_0:
        {
          profile = (U8 *)"NCS 1.0";
          len = cmStrlen(profile);
        }
        break;
      default:
        {
          MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
          RETVALUE(RFAILED);
        }
   }
    
   cmdLine->mgcpVer.major.val = 1;
   cmdLine->mgcpVer.minor.val = 0;


   if (len > 0)
   {
      cmdLine->mgcpVer.profName.pres = PRSNT_NODEF;
      if ((cmGetMem(&(msg->memCp), len, 
                    (Ptr *)&(cmdLine->mgcpVer.profName.val))) != ROK)
      {
         MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
         RETVALUE(RFAILED);
      }

      /* Initialise profile name */
      cmdLine->mgcpVer.profName.len = len;
      cmMemcpy(cmdLine->mgcpVer.profName.val, (CONSTANT U8 *)profile, len);
   }

   /* Add Restart Method as Restart */
   rsip->params.numParam.pres = PRSNT_NODEF;
   rsip->params.numParam.val  = 1;

   if((cmGetMem(&(msg->memCp), (rsip->params.numParam.val * sizeof(Ptr)), 
               (Ptr *)&(rsip->params.param))) != ROK)
   {
      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
      RETVALUE(RFAILED);
   }

   if ((cmGetMem(&msg->memCp, sizeof(MgMgcpParam), 
              (Ptr *)&(rsip->params.param[0]))) != ROK)
   {
      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
      RETVALUE(RFAILED);
   }

   param = rsip->params.param[0];
   param->paramType.pres     = PRSNT_NODEF;
   param->paramType.val      = MGT_PARAM_RSTRT_METHOD;
#if (defined (GCP_VER_1_3) && defined (GCP_2705BIS))
   param->t.rstrtMethod.stdOrXten.pres = PRSNT_NODEF;
   param->t.rstrtMethod.stdOrXten.val  = mthd; /* MGT_PARAM_RSTRT_RSTRT; */
#else
   param->t.rstrtMethod.pres = PRSNT_NODEF;
   param->t.rstrtMethod.val  = mthd; /* MGT_PARAM_RSTRT_RSTRT; */
#endif /* GCP_VER_1_3 */
   /* Encode the RSIP */
   ret = cmAbnfEncPduMsg(ssap->ssapCfg.mgcpVersion,
                        (U8 *)&(msg->msgType), mBuf, &mgMsgDef, 
                        &(peer->tsap->tsapCfg.memId), &err);

   MG_FREE_MGCP_EVNT_MEM(txn, TRUE);

   RETVALUE(ret);

} /* end of mgMgcpComposeRSIP() */





/*
*
*       Fun:   mgMgcpChkAndPrcNtfiedEntity
*
*       Desc:  This function is called only on a gateway side and checks for the
*              presence of a new Call Agent in the notified entity parameter. 
*              If notified entity indicates new call agent, add that to the
*              GCP layer peer lists and inform Layer Manager
*
*       Ret:   ROK     - SUCCESS
*              RFAILED - FAILED
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgMgcpChkAndPrcNtfiedEntity
(
MgNtfiedEnt        *ntfiedEnt,         /* MGCP notified entity */
MgPeerCb           *peer,              /* peer for this request */
MgPeerCb           **newPeer,          /* New Peer */
U32                variant             /* protocol variant */
)
#else
PUBLIC S16 mgMgcpChkAndPrcNtfiedEntity(ntfiedEnt, peer, newPeer, variant)
MgNtfiedEnt        *ntfiedEnt;         /* MGCP notified entity */
MgPeerCb           *peer;              /* peer for this request */
MgPeerCb           **newPeer;          /* New Peer */
U32                variant;            /* protocol variant */
#endif
{
   U16             addrCount;          /* Address Count */
   MgDName         dname;              /* Domain Name */
   MgPeerInitInfo  init;               /* Peer Initialisation Information */
   MgPeerInfo      alarmInfo;          /* Alarm Information for LM */
   MgSSAPCb        *ssap;              /* SSAP Information */
   MgPeerCb        *newCA;             /* New Call Agent */

   TRC2(mgMgcpChkAndPrcNtfiedEntity)

   cmMemset((U8*)&alarmInfo, 0, sizeof(MgPeerInfo));
#if (ERRCLASS & ERRCLS_DEBUG)
   if (peer == NULLP || newPeer == NULLP)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG040, 0,
                "[MGCP] mgMgcpChkAndPrcNtfiedEntity(): Null Pointer\n");         
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
   if(ntfiedEnt == NULLP)
      RETVALUE(ROK);
   /* This function should only be called for a Gateway Side */
   if (mgCb.genCfg.entType == LMG_ENT_GC)
      RETVALUE(RFAILED);

   /* Initialise variables */
   *newPeer = NULLP;
   newCA    = NULLP;
   cmMemset((U8 *)&(dname), 0 , sizeof(MgDName));
   cmMemset((U8 *)&(init), 0 , sizeof(MgPeerInitInfo));
   cmMemset((U8 *)&(alarmInfo), 0 , sizeof(MgPeerInfo));

   /* 
    * From the notified entity parameter, check if it is a new Call Agent
    */
   if (ntfiedEnt->domainName.pres == NOTPRSNT)
   {
      /* Implies just port information is present...so return */
      RETVALUE(ROK); 
   }

   newCA = mgRslvDomainNameStr(ntfiedEnt->domainName.len, 
                               ntfiedEnt->domainName.val, &dname);

   /* If Call Agent is already known, return ROK */
   if (newCA != NULLP)
   {
      if (newCA->ssap != peer->ssap)
      {
         MgPeerInfo      info;

         /* 
          * Discovered an already existing MGC for a different SSAP. Since
          * we don't support virtual MG; Inform LM but don't add it
          */
         info.pres.pres = PRSNT_NODEF;
         info.id.pres   = PRSNT_NODEF;
         info.id.val    = MG_INVALID_PEERID;

         if (dname.namePres.pres == PRSNT_NODEF)
         {
            info.dname.namePres.pres = PRSNT_NODEF;
            cmMemcpy((U8 *)info.dname.name, 
                     (CONSTANT U8 *)newCA->accessInfo.name, CM_DNS_DNAME_LEN);
         }
         else
            info.dname.namePres.pres = NOTPRSNT;

         if (newCA->accessInfo.peerAddrTbl.count > 0)
         {
            cmMemcpy((U8 *)&(info.dname.netAddr), 
                    (CONSTANT U8 *)&(newCA->accessInfo.peerAddrTbl.netAddr[0]), 
                    sizeof(CmNetAddr));
         }
         else
            info.dname.netAddr.type = CM_NETADDR_NOTPRSNT;

         info.port.pres = NOTPRSNT;

         mgGenStaInd (STSSAP, LCM_CATEGORY_PROTOCOL, LMG_EVENT_REJECT_DUPMGC, 
                      LMG_CAUSE_NEW_NTFY_ENTITY, LMG_ALARMINFO_PEER, 
                      (Ptr)&info, sizeof(MgPeerInfo), LMG_ALARMINFO_INVSAPID);

         RETVALUE(RFAILED);
      }
#ifdef ZG_DFTHA
      if(zgChkCRsetStatus())
#endif /* ZG_DFTHA */
      {
         /* Mark this as a notified entity peer & update the state to
         * ACTIVE if IP address is available */
         newCA->mgcpInfo.ntfyEntPeer = TRUE;
         if (newCA->accessInfo.peerAddrTbl.count > 0)
         {
            newCA->state = LMG_PEER_STATE_ACTIVE;
         }
#ifdef ZG
         /* send update for peer */
         zgRtUpd(ZG_CBTYPE_PEER, (Ptr) newCA, CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
#endif /* ZG */
      }
#ifdef ZG_DFTHA
      /* return ROKDNA in case of NonCritical..reverse update will generated in
       * calling fn */
      else
      {
         if(newCA->mgcpInfo.ntfyEntPeer == FALSE ||  
            ((newCA->accessInfo.peerAddrTbl.count > 0) && 
            (newCA->state != LMG_PEER_STATE_ACTIVE)))
         {
            RETVALUE(ROKDNA);
         }
      }
      
#endif /* ZG_DFTHA */

      RETVALUE(ROK);
   }
   else
   {
#ifdef ZG_DFTHA
      /* Now new peer entity is NULLP ..so we are going to create new peer..So
       * check if this is Master copy ..if not then return ROKDNA */
      if(!((zgChkCRsetStatus()) == TRUE))
         RETVALUE(ROKDNA);
#endif /* ZG_DFTHA */
   }
   /* Note :: Only master will execute code below this */
   /* Learn New Peer Information */
   ssap      = peer->ssap;
   addrCount = 0;

   if (dname.namePres.pres == PRSNT_NODEF)
   {
      /* Copy Domain Name */
      cmMemcpy((U8 *)init.name, (CONSTANT U8 *) dname.name,
               CM_DNS_DNAME_LEN);
      cmMemcpy((U8 *)alarmInfo.dname.name, (CONSTANT U8 *)dname.name, 
               CM_DNS_DNAME_LEN);
   }
   else
   {
      init.name[0] = '\0';

      /* Copy Address Information */
      if ((dname.netAddr.type == CM_NETADDR_IPV4) ||
          (dname.netAddr.type == CM_NETADDR_IPV6))
      {
         cmMemcpy((U8 *)&(init.addrTbl.netAddr[addrCount++]),
                  (CONSTANT U8 *) &(dname.netAddr),
                  sizeof(CmNetAddr)); 
         init.addrTbl.count = addrCount;
      }
      else
         RETVALUE(ROK);
   }


   init.variant = variant;

   init.mgcpInfo.suspThold   = peer->tsap->tsapCfg.reCfg.defSuspThold;
   init.mgcpInfo.disconThold = peer->tsap->tsapCfg.reCfg.defDisConThold;
   init.transportType        = LMG_TPT_UDP;
   init.protocolType         = LMG_PROTOCOL_MGCP;
   init.remotePort           = LMG_INVALID_PEER_PORT;
   init.ttl                  = peer->tsap->ttl;
   init.trcLen               = MG_DEFAULT_TRC_LEN;
   init.mtuSize              = MG_MAX_UDP_MTU_SIZE;
   init.byCfg                = FALSE;
#ifdef ZG
   init.peerId = MG_INVALID_PEERID;
   init.mtdPeerId = MG_INVALID_PEERID;
#ifdef ZG_DFTHA
   init.suConnId = MG_INVALID_LSTNRID;
#endif /* ZG_DFTHA */
#endif /* ZG */

   if (ssap->ssapCfg.reCfg.initRetxTmr.enb == TRUE)
   {
      init.initRtt = ssap->ssapCfg.reCfg.initRetxTmr.val;
   }
   else
      init.initRtt = (MG_INIT_RTT_VALUE * mgCb.genCfg.timeRes);

   /* Prepare Alarm Information for LM */
   alarmInfo.pres.pres = PRSNT_NODEF;
   alarmInfo.id.pres   = PRSNT_NODEF;
   alarmInfo.id.val    = MG_INVALID_PEERID;

   if (((dname.netAddr.type == CM_NETADDR_IPV4) &&
        (dname.netAddr.u.ipv4NetAddr != 0)) ||
       (dname.netAddr.type == CM_NETADDR_IPV6))
   {
      cmMemcpy((U8 *)&(alarmInfo.dname.netAddr), 
               (CONSTANT U8 *)&(init.addrTbl.netAddr[0]), 
               sizeof(CmNetAddr));
   }
   else
      alarmInfo.dname.netAddr.type = CM_NETADDR_NOTPRSNT;

   alarmInfo.port.pres = NOTPRSNT;


   if ((newCA = mgAllocPeerCb(ssap, &init)) == NULLP)
   {
      /* 
       * Generate Status Indication Informing LM that new Notified Entity
       * couldn't be added
       */
      mgGenStaInd (STSSAP, LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL, 
                   LMG_CAUSE_NEW_NTFY_ENTITY, LMG_ALARMINFO_PEER, 
                   (Ptr)&alarmInfo, sizeof(MgPeerInfo), LMG_ALARMINFO_INVSAPID);
      RETVALUE(RFAILED);
   }


   /*
    *  Initialize the tsap field of the new peer
    */

   newCA->tsap = peer->tsap;


   /* 
    * Send Status Indication to the Layer Manager informing about the
    * discovery of the new peer
    */
#ifdef GCP_MGC
   /* Update the next SSAP Id */
   MG_UPDATE_NXTUSE_MGCP_SSAPID();
#endif /* GCP_MGC */

   /* Update Alarm Information */
   alarmInfo.port.pres = PRSNT_NODEF;
   alarmInfo.port.val  = newCA->accessInfo.remotePort;
#ifdef GCP_USE_PEERID
   alarmInfo.id.val  = newCA->accessInfo.peerId;
#endif /* MG_USE_PEERID */

   /* Update variable for calling function */
   *newPeer = newCA;

   /* Inform Layer Manager that Peer was accepted via RSIP */
   mgGenStaInd (STSSAP, LCM_CATEGORY_PROTOCOL, LMG_EVENT_PEER_DISCOVERED, 
                LMG_CAUSE_NEW_NTFY_ENTITY, LMG_ALARMINFO_PEER, (Ptr)&alarmInfo, 
                sizeof(MgPeerInfo), newCA->ssap->suId);

   if (newCA->accessInfo.peerAddrTbl.count > 0)
   {
     /* Mark this as a notified entity peer & update the state to
      * ACTIVE so that the RSIP is not reqd as the first message */
     newCA->mgcpInfo.ntfyEntPeer = TRUE;
     newCA->state = LMG_PEER_STATE_ACTIVE;
#ifdef ZG
      /* Do addmapping and send run time update to standby/shadows */
      ZG_INIT_RSETID_IN_MAPCB(&((*newPeer)->mapCb));
      zgAddMapping(ZG_CBTYPE_PEER,(Ptr)(*newPeer));
      zgRtUpd(ZG_CBTYPE_PEER,(Ptr)(*newPeer),CMPFTHA_UPDTYPE_SYNC,
         CMPFTHA_ACTN_ADD);
#endif /* ZG */
      RETVALUE(ROK);
   }
   /* Send Resolve to DNS for the peer , if required */
   else if (newCA->accessInfo.namePres == TRUE)
   {
      if ((MG_INVALID_TSAP_ID != mgCb.dnsTsap) &&
          (mgCb.tSAPLst[mgCb.dnsTsap]) &&
          (mgCb.tSAPLst[mgCb.dnsTsap]->dnsInfo.dnsState == MG_DNS_STATE_UP) &&
          (mgCb.tSAPLst[mgCb.dnsTsap]->tsapCfg.reCfg.dnsCfg.dnsAccess
               != LMG_DNS_DISABLED))
      {
         /* Mark this as a notified entity peer */
         newCA->mgcpInfo.ntfyEntPeer = TRUE;
         newCA->state = LMG_PEER_STATE_RESOLVING;
#ifdef ZG
         /* Do addmapping and send run time update to standby/shadows */
         ZG_INIT_RSETID_IN_MAPCB(&((*newPeer)->mapCb));
         zgAddMapping(ZG_CBTYPE_PEER,(Ptr)(*newPeer));
         zgRtUpd(ZG_CBTYPE_PEER,(Ptr)(*newPeer),CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_ADD);
#endif /* ZG */
         mgSendDnsRslvReq(newCA, newCA->accessInfo.name);
      }
      else
      {
         mgDeletePeer(newCA, LMG_EVENT_NEWNTFY_DELETED, LMG_CAUSE_DNS_DISABLED,
                      TRUE);
         /* make newPeer == NULLP */
         *newPeer = NULLP;
         RETVALUE(ROK);
      }
   }

   RETVALUE(ROK);

} /* end of mgMgcpChkAndPrcNtfiedEntity () */

#endif /* GCP_MG */





/*
*
*       Fun:   mgRemoveBytesTillSeparator
*
*       Desc:  This function is called when decoding engine 
*              encounters an error while decoding the buffer. 
*              This function removes the bytes of the message 
*              for which error happened till the begining of the 
*              next message
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_util.c
*
*/

#ifdef ANSI
PUBLIC S16 mgRemoveBytesTillSeparator
(
MsgLen             *numDecBytes,        /* Number of decoded bytes */
CmAbnfDecOff       *offset              /* Decoder offset in the buffer */
)
#else
PUBLIC S16 mgRemoveBytesTillSeparator (numDecBytes, offset)
MsgLen             *numDecBytes;        /* Number of decoded bytes */
CmAbnfDecOff       *offset;             /* Decoder offset in the buffer */
#endif
{
   Bool            foundDot;           /* Found Message Separator */
   S16             ch;                 /* Character */

   TRC2(mgRemoveBytesTillSeparator)

   foundDot=FALSE;

   if((ch = cmAbnfGetChar(offset)) == -1)
      RETVALUE(ROKDNA);
   
   do
   {
      if((U8)ch == '.')     /* Ascii Value of dot */
      {
         foundDot = TRUE;
         continue;
      }

      if(foundDot == TRUE)
      {
         if((U8)ch == '\n')
         {
            /* got separator; adjust the buffer to the next char */
            ch = cmAbnfGetNxtChar(offset,numDecBytes);
            RETVALUE(ROK);
         }

      }

   }while ((ch = cmAbnfGetNxtChar(offset,numDecBytes)) != -1);

   RETVALUE(ROKDNA);
} /* end of mgRemoveBytesTillSeparator () */


#endif /* GCP_MGCP */





/********************************************************************/
/*                         MEGACO Specific Functions                */
/********************************************************************/
#ifdef GCP_MGCO


/********************************************************************/
/*                     Upper Interface Functions                    */
/********************************************************************/

/********************************************************************/
/*                 MEGACO Transaction Request Process Module        */
/********************************************************************/

/*
*
*       Fun:   mgPrcMgcoTxnReq
*
*       Desc:  This function processes the MEGACO transaction received
*              service user
*
*       Ret:   ROK - SUCCESS;
*              RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or response to
*              a command.
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgPrcMgcoTxnReq
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgcoMsg          *mgcoMsg,           /* Transaction */
MgPeerCb           *peerCb,            /* Peer control block */
U8                 source              /* Initiated by user/ internal */
)
#else
PUBLIC S16 mgPrcMgcoTxnReq(ssap, mgcoMsg, peerCb, source)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgcoMsg          *mgcoMsg;           /* Transaction */
MgPeerCb           *peerCb;            /* Peer control block */
U8                 source;             /* Initiated by user/ internal */
#endif
{
   S16             ret;                /* Return Value */
   U16             loopIdx;            /* Loop Index */
   Bool            msgSend;            /* Send Message */
   MgMgcoMsg       *errMsg;            /* Error Message */
   MgMgcoTxn       *mgcoTxn;           /* Megaco Transaction */
   MgPeerCb        *peer;              /* Peer Control Block */
   MgTptSrvr       *srvr;              /* Transport Server */
   U16             numMsg;             /* Number of messages */
   Buffer          *mBuf;              /* Message Buffer */
   Buffer          *hdrMBuf;           /* Buffer for Message Header */
   CmTptAddr       remoteAddr;         /* Remote Address for Sending Commands*/
   /* moved tsap initialization from the MT_LIB flag */
   MgTSAPCb        *tsap;              /* TSAP Control Block */
#ifndef CM_ABNF_MT_LIB
   Bool            tcpConnInit;        /* TCP connection initiation */
   MsgLen          crntLen;            /* added current length of buffer */
#endif

#ifdef    GCP_PROV_SCTP
   TknU32          ctxId;              /* context Id */
#endif    /* GCP_PROV_SCTP */

   U32              protVar;



   TRC2(mgPrcMgcoTxnReq)



   /* Initialise variables */

#ifndef CM_ABNF_MT_LIB
   tcpConnInit = FALSE;
#endif
   errMsg  = NULLP;
   mgcoTxn = NULLP;
   peer    = NULLP;
   srvr    = NULLP;
   mBuf    = NULLP;
   hdrMBuf = NULLP;
   msgSend = FALSE;
   remoteAddr.type = CM_TPTADDR_NOTPRSNT;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (mgcoMsg->body.type.pres == NOTPRSNT)
   {
      MG_FREE_MGCO_EVNT_MEM(mgcoMsg, TRUE);
      RETVALUE(RFAILED);
   }

   if (mgcoMsg->body.type.val !=  MGT_ERRDESC)
   {
      if ((mgcoMsg->body.u.tl.num.pres == NOTPRSNT) ||
          (mgcoMsg->body.u.tl.num.val == MG_NONE))
      {
         /* Free the transaction structure received */
         MG_FREE_MGCO_EVNT_MEM(mgcoMsg, TRUE);
         RETVALUE(RFAILED);
      }
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   if((peer = peerCb ) == NULLP)
   {
      /* LOCATE PEER */   
      if ((peer = mgFindPeerForTxnReq(ssap, mgcoMsg, source)) == NULLP)
      {
         RETVALUE(RFAILED);
      }
   } /* end of if for peer */

#ifdef GCP_VER_1_5
   if (mgcoMsg->ver.val == 2)
   {
      protVar = CM_ABNF_PROT_MEGACO_H248_V2;   
   } 
   else 
#endif /* GCP_VER_1_5 */
   {
      protVar = CM_ABNF_PROT_MEGACO_H248;   
   }


   /*
    *   find tsap from assocCb for SCTP as transport;
    *   What to do if assoc has NOT been allocated yet?
    *   This case when the assoc has not yet been allocated
    *   can happen only on the MG side. On the MGC side,
    *   an outgoing msg can only be sent once the association
    *   has been established since the MG initiates the service
    *   change to register with the MGC.
    *   For this case on the MG side, find out the ssap linked
    *   to this peer. From the ssap, find out the tsap linked
    *   to this ssap. Voila, we have the tsap in all the cases!!!
    */


   /*
    *   new handling -
    *
    *      peer <-> tsap mapping will always be there :-
    *
    *      MGC side:-> This is established on getting the
    *                  SrvcChng msg from the MG on a TSAP
    *      MG side:->  This is established at the time of
    *                  the peer configuration
    */

   /* mg008.105: In case of MGC if association not done this value 
                  will be null */
   tsap = peer->tsap;

#ifdef GCP_MGC
   if (mgCb.genCfg.entType == LMG_ENT_GC)
   {   
      if (tsap == NULLP)
      {
         mgHandleMgcoTxnReqErr(ssap, mgcoMsg, MGT_ERR_NOT_REGISTERED,
                                 source);
         RETVALUE(RFAILED);
      }
   } /* if MGC */
#endif /* GCP_MGC */


   /* Process Message */
#ifdef CM_ABNF_MT_LIB
   if (mgcoMsg->body.type.val != MGT_ERRDESC)
   {
      mBuf = NULLP;
      hdrMBuf = NULLP;
   }
   /*
    * now getting header mBuf and making a header
    *            mBuf if the msg has an errorDesc in msgBody. 
    */
   else
   {
      /* Get mBuf to transmit & Header buffer */
      ret = mgGetMgcoMsgBuf(&mBuf,
                            tsap,
                            &hdrMBuf,
                            mgcoMsg
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
                            ,peer->mgcoInfo.encodingScheme
#endif /* GCP_VER_1_5 & GCP_ASN */
                            ,protVar);

      if (ret != MGT_NONE)
      {
         MG_CLEAR_MEM(mBuf, hdrMBuf);      
         if (ret == MGT_ERR_RSRC_UNAVAIL)
         {
            MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                   tsap->tsapCfg.memId.region,
                                   tsap->tsapCfg.memId.pool);
         }
         mgHandleMgcoTxnReqErr(ssap, mgcoMsg, (U8)ret, source);
         RETVALUE(RFAILED);
      }
   }
#else
   /* Get mBuf to transmit & Header buffer */
   ret = mgGetMgcoMsgBuf(&mBuf,
                         tsap,
                         &hdrMBuf,
                         mgcoMsg
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
                         ,peer->mgcoInfo.encodingScheme
#endif /* GCP_VER_1_5 & GCP_ASN */ 
                         ,protVar);

   if (ret != MGT_NONE)
   {
      MG_CLEAR_MEM(mBuf, hdrMBuf);      
      if (ret == MGT_ERR_RSRC_UNAVAIL)
      {
         MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                tsap->tsapCfg.memId.region,
                                tsap->tsapCfg.memId.pool);
      }
      mgHandleMgcoTxnReqErr(ssap, mgcoMsg, (U8)ret, source);
      RETVALUE(RFAILED);
   }
#endif /* CM_ABNF_MT_LIB */

   if (mgcoMsg->body.type.val ==  MGT_ERRDESC)
   {
     ret = mgPrcMgcoErrDesc(ssap,
                            tsap,
                            peer,
                            mBuf,
                            mgcoMsg,
                            protVar
                            );
     if (ret != MGT_NONE)
     {
        MG_CLEAR_MEM(mBuf, hdrMBuf);      
        mgHandleMgcoTxnReqErr(ssap, mgcoMsg, (U8)ret, source);
        RETVALUE(RFAILED);
     }
     RETVALUE(ROK);
   }

   /* If message is not Error Descriptor */

   /* Check if msg is valid for given peer state */
   if ((ret = mgValidateMgcoMsg(peer, mgcoMsg, tsap)) == RFAILED)
   {
      MG_CLEAR_MEM(mBuf, hdrMBuf);      
      /* mg005.105: If stack is in lock state, send status indication to user 
         with error code MGT_ERR_LOCK_STATE */

/* paul modifyed for NEC feedback */
#ifdef GCP_MGCO
#ifdef GCP_MG
      if(ssap->lockUnlock)
      {   
         mgHandleMgcoTxnReqErr(ssap, mgcoMsg, MGT_ERR_LOCK_STATE, source);
      }
      else
#endif  /* GCP_MG */
#endif  /* GCP_MGCO */
         mgHandleMgcoTxnReqErr(ssap, mgcoMsg, MGT_ERR_INVALID_MSG, source);

#ifdef ZG
      /* Send update message to standby */
      zgUpdPeer();
#endif /* ZG */
      RETVALUE(RFAILED);
   }
#ifdef ZG
   /* ret is ROKDNA, So txnReq is queued and will be processed afterwards so
    * just return ROK */ 
   else if(ret == ROKDNA)
   {
      MG_CLEAR_MEM(mBuf, hdrMBuf);      
      /* Send update message to standby */
      zgUpdPeer();
      RETVALUE(ROK);
   }
#endif /* ZG */




   /* Get Server on which the message is to be sent */

   /*
    *   If transport is -
    *
    *   1) TCP  : the connection may not have been initiated
    *   2) SCTP : the association request may not have been sent
    *             if peer->assocCb is still NULLP.
    *   3) MTP3: It should have preconfigured point code of Peer in peerCb 
    *
    *   Initiate the TCP connection/SCTP association.
    *   However, if peer->assocCb has been allocated, then this
    *   implies that the assocation request has been sent and this
    *   MgcoTxnReq has been initiated by the GCP user in the transient
    *   time between the association request and the association cfm.
    *   In such cases, the MgcoTxnReq should be queued. A duplicate
    *   association request should NOT be initiated.
    *
    */

   if (((srvr = mgGetSendSrvr(ssap, peer)) == NULLP)
#ifdef GCP_PROV_SCTP
       || ((peer->accessInfo.transportType == LMG_TPT_SCTP) &&
           (peer->assocCb == NULLP))
#endif /* GCP_PROV_SCTP */
#ifdef   GCP_PROV_MTP3
       && (peer->accessInfo.transportType != LMG_TPT_MTP3)
#endif   /* GCP_PROV_MTP3 */       
      )

   {
     /* 
      * If transport is TCP the connection may not have been initaited yet(in
      * some peer states). It will be done later 
      */
     if (peer->accessInfo.transportType == LMG_TPT_UDP)
     {
        MG_CLEAR_MEM(mBuf, hdrMBuf);      
        mgHandleMgcoTxnReqErr(ssap, mgcoMsg, MGT_ERR_RSRC_UNAVAIL, source);
        RETVALUE(RFAILED);
     }
#ifndef CM_ABNF_MT_LIB
     else
        tcpConnInit = TRUE;
#endif
   }




#ifdef    GCP_PROV_SCTP
   /*
    * call the following function to find out the context Id
    * used by the first transaction in the MEGACO message
    */
   mgExtractCtxIdFrmMsg(mgcoMsg, &ctxId);
#endif    /* GCP_PROV_SCTP */



   
   /* initialise the crntLen (addition) */
   /* added flag protection below. */
#ifndef CM_ABNF_MT_LIB
   SFndLenMsg(hdrMBuf, &crntLen);
#endif

   /* Process Each Transaction */
   numMsg = mgcoMsg->body.u.tl.num.val;
   for (loopIdx = 0; loopIdx < numMsg; loopIdx++)
   {
     /* Get Transaction */
     mgcoTxn = mgcoMsg->body.u.tl.txns[loopIdx];

#ifdef GCP_VER_1_5
     ret= mgVerifyVersion(mgcoTxn ,peer->ssap);
#endif /* GCP_VER_1_5 */

#ifdef CM_ABNF_MT_LIB
     mgPrcMTMgcoTxn(ssap, mgcoMsg, mgcoTxn, peer, srvr, &errMsg,
                    mBuf, hdrMBuf,
                    &msgSend, source
#ifdef    GCP_PROV_SCTP
                    ,peer->assocCb,
                    ctxId
#endif    /* GCP_PROV_SCTP */
                   );       

     mgcoMsg->body.u.tl.txns[loopIdx] = NULLP;
     mgcoMsg->body.u.tl.num.val--;
#else /* CM_ABNF_MT_LIB */

     /*
      * passing address of crntLen & mBuf to
      *             mgPrcMgcoTxn (additional argument added)
      */
/*TODO_MAH */
     if (RFAILED ==  mgPrcMgcoTxn(ssap, mgcoMsg, peer,
#ifdef    GCP_PROV_SCTP
                  peer->assocCb,
                  ctxId,
#endif    /* GCP_PROV_SCTP */
                  srvr, &errMsg,
                  &mBuf, hdrMBuf, &msgSend, source, &crntLen, loopIdx))
     {
/*TODO_MAH */
        mgHandleMgcoTxnReqErr(ssap, mgcoMsg,MGT_ERR_INVALID_MSG, source);
        RETVALUE(RFAILED);
     }


#endif /* CM_ABNF_MT_LIB */
   } /* For each transaction */


   /* 
    * If all transactions in the message had errors then donot send out 
    * message 
    */
   if ((errMsg != NULLP) && 
       (errMsg->body.u.tl.num.val == mgcoMsg->body.u.tl.num.val) &&
       (msgSend == TRUE))
     msgSend = FALSE;


   /* 
    * Addition; If the MSG size exceeds the MTU size drop the 
    * message; And Inform the User */
   if(errMsg != NULLP)
   {
     /* If the Error is due to MSG Size exceeding configured MTU size drop
      * the message */
     U8 indx;
     for (indx = 0; indx < errMsg->body.u.tl.num.val;indx++)
     {
        MgMgcoTxn *tmpTxn;
        tmpTxn = errMsg->body.u.tl.txns[indx];
        if ((tmpTxn->mgLclErr.errType.pres == PRSNT_NODEF)
             && (tmpTxn->mgLclErr.errType.val == MGT_ERR_MSG_LENGTH))
        {
           msgSend = FALSE;
           break;
        }
        else
          continue;
     }
   }


#ifndef CM_ABNF_MT_LIB
   /* Incase of multithreaded library..TCP connection will be established once
    * Encode confirm is received.
    * 
    * In case of tight couple mode, it is possible that if
    * some message is sent towards HI layer, HI can respond back
    * with DiscInd which shall result in peer state being changed to
    * AWAIT_REG and connection should not be initiated here 
    *
    * On the MG side, if it is the first message, the TCP 
    * connection is to be initiated before  sending the message 
    */
#ifdef ZG_DFTHA
   if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG */
   {
      if ((mgCb.genCfg.entType == LMG_ENT_GW) &&
         (peer->state == LMG_PEER_STATE_AWAIT_REG) &&
         (tcpConnInit == TRUE))
      {
         if (peer->accessInfo.transportType == LMG_TPT_TCP)
         {
            srvr = NULLP;
            MG_INIT_TCP_CONN(peer, srvr); 
            if (srvr  == NULLP)
            {
               MG_CLEAR_MEM(mBuf, hdrMBuf);      
               mgHandleMgcoTxnReqErr(ssap, mgcoMsg,
                                     MGT_ERR_RSRC_UNAVAIL, source);
#ifdef ZG
               /* Send update message to standby */
               zgUpdPeer();
#endif /* ZG */
               RETVALUE(RFAILED);
            }
         }
#ifdef    GCP_PROV_SCTP
         else if (peer->accessInfo.transportType == LMG_TPT_SCTP)
         {
            S16      ret1;

            /*
             * Since this is a user initiated request, set the app flag;
             * However, this flag need NOT be set in the Assoc Request
             * made from mp_peer.c funtions since those Assoc Reqs are
             * stack generated;
             */

            peer->accessInfo.peerflg |= MG_USER_INITIATED_REG;

            MG_INIT_SCTP_ASSOC(peer,ret1);

            if (ret1 != ROK)
            {
               MG_CLEAR_MEM(mBuf, hdrMBuf);      
               mgHandleMgcoTxnReqErr(ssap, mgcoMsg,
                                     MGT_ERR_RSRC_UNAVAIL, source);
#ifdef ZG
               /* Send update message to standby */
               zgUpdPeer();
#endif /* ZG */
               RETVALUE(RFAILED);
            }
         }
#endif    /* GCP_PROV_SCTP */
      }
   }
#endif /* !CM_ABNF_MT_LIB */
   
   /* If msgSend is TRUE, there are transactions in the mBuf ...So transmit */
   if (msgSend == TRUE)   /* Tranmission Possible */
   {

      mgTransmitMgcoMsg(peer,
#ifdef    GCP_PROV_SCTP
                        peer->assocCb,
                        ctxId,
#endif    /* GCP_PROV_SCTP */
                        srvr,
                        &remoteAddr,
                        mBuf,
                        NULLP);

   }
   else
   {
      if (mBuf != NULLP)
         mgPutMsg(mBuf);
   }
   
   /* If there are any errors report it to the user */
   if (errMsg != NULLP)
   {
     /* Copy Gateway information */
     cmMemcpy((U8 *)&(errMsg->lcl),
              (CONSTANT U8 *)&(mgcoMsg->lcl), sizeof(MgPeerInfo));
     mgHandleMgcoTxnReqErr(ssap, errMsg, MG_IGNORE, source);
   }

   /* Free the transaction structure received */
   MG_FREE_MGCO_EVNT_MEM(mgcoMsg, TRUE);

   if (hdrMBuf != NULLP)
      mgPutMsg(hdrMBuf);
   
#ifdef ZG
   /* Send update message to standby */
   zgUpdPeer();
#endif /* ZG */
   RETVALUE(ROK);

} /* end of mgPrcMgcoTxnReq () */


/*
*       Fun:   mgPrcMgcoErrDesc
*
*       Desc: Encodes and transmits a MEGACO message which contains only
*             an error descriptor. 
*
*       Ret:   ROK - SUCCESS;
*              RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE U8  mgPrcMgcoErrDesc
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgTSAPCb           *tsap,              /* TSAP Control Block */
MgPeerCb           *peer,              /* Peer Control Block */
Buffer             *mBuf,              /* Message buffer */ 
MgMgcoMsg          *mgcoMsg,           /* Error Message */
U32                protVar
)
#else
PRIVATE U8  mgPrcMgcoErrDesc(ssap, tsap, peer, mBuf, mgcoMsg, protVar)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgTSAPCb           *tsap;              /* TSAP Control Block */
MgPeerCb           *peer;              /* Peer Control Block */
Buffer             *mBuf;              /* Message buffer */ 
MgMgcoMsg          *mgcoMsg;           /* Error Message */
U32                protVar;
#endif 

{
   MgTptSrvr       *srvr;              /* Transport Server */
   Buffer          *tmpTxnBuf;         /* Temporary Transaction Buffer */
   CmAbnfErr       err;                /* Encode Error Structure */
   CmTptAddr       remoteAddr;         /* Remote Address for Sending Commands */

#ifdef    GCP_PROV_SCTP
   TknU32          ctxId;              /* Integer type of Context-ID */
#endif    /* GCP_PROV_SCTP */


   TRC2(mgPrcMgcoErrDesc)


   remoteAddr.type = CM_TPTADDR_NOTPRSNT;

   /* Locate Transport Server for Message */
   if (
#ifdef    GCP_PROV_MTP3
       (peer->accessInfo.transportType != LMG_TPT_MTP3) &&
#endif    /* GCP_PROV_MTP3 */
#ifdef    GCP_PROV_SCTP
       (peer->accessInfo.transportType != LMG_TPT_SCTP) &&
#endif /* GCP_PROV_SCTP */
       ((srvr = mgGetSendSrvr(ssap, peer)) == NULLP))
   {
      /* removed mBuf deallocation macro from here since mBuf is
       * being freed in the calling function in case of failure */
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }

   /* Get Buffer to store txn information */
   if (mgGetMsg(tsap->tsapCfg.memId.region, tsap->tsapCfg.memId.pool,
               &tmpTxnBuf) != ROK)
   {
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }



#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
   if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_TXT)
   {
#endif 
      /* Encode Buffer & Transmit */
      if ((cmAbnfEncPduMsg(protVar, 
                           (U8 *)&(mgcoMsg->body.u.err),
                           tmpTxnBuf, &mgMgcoErrDescDef, 
                           &(tsap->tsapCfg.memId), &err)) != ROK)
      {
         /* deallocate tmpTxnBuf in case of failure */
           /* mg003.105: Add - Added sanity check */
		   if (tmpTxnBuf != NULLP)
            mgPutMsg(tmpTxnBuf);
         RETVALUE(MGT_ERR_INVALID_ERR_DESC);
      }
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
   }
   else if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
   {
       /* Encode Buffer & Transmit */
        /* Need to fix in the apropriate params once proto type is ready  */
      if ((mgEncPduMsg(protVar, 
                        (U8 *)mgcoMsg, 0,
                        tmpTxnBuf, MGED_ERRDESC,
                        &(tsap->tsapCfg.memId), &err)) != ROK)
      {
            /* mg003.105: Add - Added sanity check */
		    if (tmpTxnBuf != NULLP)
            mgPutMsg(tmpTxnBuf);
          RETVALUE(MGT_ERR_INVALID_ERR_DESC);
      }
   } 
   else
   {
      /* Encoding type not defined properly */
        /* mg003.105: Add - Added sanity check */
		if (tmpTxnBuf != NULLP)
         mgPutMsg(tmpTxnBuf);
      RETVALUE(MGT_ERR_INVALID_ERR_DESC);
   }

#endif
 

   
   
   /* Concat transaction to the mBuf to be transmitted */
   if ((SCatMsg(mBuf, tmpTxnBuf, M1M2)) != ROK)
   {
      /* deallocate tmpTxnBuf in case of failure */
      /* mg003.105: Add - Added sanity check */
	  if (tmpTxnBuf != NULLP)
        mgPutMsg(tmpTxnBuf);
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }

   /* mg003.105: Add - Added sanity check */ 
   if (tmpTxnBuf != NULLP)
      mgPutMsg(tmpTxnBuf);
#ifdef GCP_ASN
   /* last minute prep */
   if (peer->mgcoInfo.encodingScheme  == LMG_ENCODE_BIN)
   {
      if (mgPrepSend(protVar , mBuf, (CmMemListCp *)(mgcoMsg)) != ROK)
      {
         RETVALUE(MGT_ERR_INVALID_ERR_DESC);
      }
   }
#endif
   peer->peerSts.numErrors++;

   /* Transmit the message */
#ifdef    GCP_PROV_SCTP

   /*
    *   Context-ID is absent in this message since
    *   this message has an error descriptor in msgBody
    */

   /*mg002.105: Removed compilation warning*/
   ctxId.pres = NOTPRSNT;
   ctxId.val = 0;

   mgTransmitMgcoMsg(peer, peer->assocCb, ctxId,
                     srvr, &remoteAddr, mBuf, NULLP);
#else     /* GCP_PROV_SCTP */
   mgTransmitMgcoMsg(peer, srvr, &remoteAddr, mBuf, NULLP);
#endif    /* GCP_PROV_SCTP */


   RETVALUE(MGT_NONE);

} /* End of mgPrcMgcoErrDesc */


/*
*       Fun:   mgChkForSrvcChgRsp
*
*       Desc:  Checks if the message received from the service user is a
*              response to a previously received service change.
*
*       Ret:   TRUE: Transaction is a service change.
*              FALSE: Transaction is not a service change.
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE Bool mgChkForSrvcChgRsp
(
MgPeerCb           *peer,              /* Peer Control Block */
MgMgcoTxn          *mgcoTxn            /* Transaction */
)
#else
PRIVATE Bool mgChkForSrvcChgRsp(peer,mgcoTxn)
MgPeerCb           *peer;              /* Peer Control Block */
MgMgcoTxn          *mgcoTxn;           /* Transaction */
#endif 
{
#ifdef GCP_MG
   S16             ret;
#endif /* GCP_MG */

   TRC2(mgChkForSrvcChgRsp)

   /* 
    * If it is a service change response the peer info needs to
    * get updated . This chk is valid only on the MGC side
    */
#ifdef GCP_MGC
   if (mgCb.genCfg.entType == LMG_ENT_GC)
   {
      if (((peer->state == LMG_PEER_STATE_REGISTER)||
           (peer->state == LMG_PEER_STATE_FAILOVER)) &&
          ((mgVerifySvcChgRsp(mgcoTxn, FALSE)) == ROK))
      {
         RETVALUE(TRUE);
      }
      else
         RETVALUE(FALSE);
   }
   else
#endif 
#ifdef GCP_MG
   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
          
      /* 
       * On the Gateway side if peer is under handoff and if service
       * user is responding to a handoff service change message, we 
       * have to initiate a service change message to the new MGC 
       */
      if (peer->state == LMG_PEER_STATE_UNDR_HNDOFF)
      {
         if ((ret = mgVerifySvcChgRsp(mgcoTxn, FALSE)) == ROK)
         {
            RETVALUE(TRUE);
         }
      }
   }
#endif /* GCP_MG */      

   RETVALUE(FALSE);

} /* End of mgChkForSrvcChgRsp */


/*
*
*       Fun:  mgGetMgcoMsgBuf
*
*       Desc: This function allocates memory for the message to be 
*             transmitted and for the header. It also encodes the header of 
*             megaco message in hdrMbufPtr and appends it to the message 
*             buffer  mBufPtr.
*
*       Ret:  MGT_NONE                   -     SUCCESS 
*             MGT_ERR_RSRC_UNAVAIL       -     Resource Unavailable
*             MGT_ERR_INVALID_HDR_PARMS  -     Invalid Header Information
*
*       Notes:
*
*       File:  mg_cord.c
*
*/


#ifdef ANSI

PUBLIC U8  mgGetMgcoMsgBuf
(
Buffer             **mBufPtr,          /* Message buffer pointer */
MgTSAPCb           *tsap,              /* TSAP CB */
Buffer             **hdrMBufPtr,       /* Header Buffer pointer */
MgMgcoMsg          *msg                /* MEGACO message */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
,U8                encodingScheme    /* Encoding Scheme */
#endif /* GCP_VER_1_5 GCP_ASN */
,U32                protVar              /* version support */
)

#else /* ANSI */

PUBLIC U8  mgGetMgcoMsgBuf(mBufPtr, tsap, hdrMBufPtr, msg
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                           ,encodingScheme
#endif /* GCP_VER_1_5 GCP_ASN */
                           ,protVar)
Buffer             **mBufPtr;          /* Message buffer pointer */
MgTSAPCb           *tsap;              /* TSAP CB */
Buffer             **hdrMBufPtr;       /* Header Buffer pointer */
MgMgcoMsg          *msg;               /* MEGACO message */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
U8                 encodingScheme;    /* Encoding Scheme */
#endif /* GCP_VER_1_5 GCP_ASN */
U32                protVar;              /* version support */

#endif /* ANSI */
{
   Buffer          *tmpHdrBuf;         /* Temporary Buffer for Header */
   CmAbnfErr       err;                /* Encode Error Structure */

   TRC2(mgGetMgcoMsgBuf)

   /* Get Buffer for transmission of message */
   if (mgGetMsg(tsap->tsapCfg.memId.region, tsap->tsapCfg.memId.pool,
              mBufPtr) != ROK)
   {
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }


   /* Get Buffer to store header information */
   if (mgGetMsg(tsap->tsapCfg.memId.region, tsap->tsapCfg.memId.pool,
              hdrMBufPtr) != ROK)
   {
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }

    
   /* Encode MGCO Header */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 

   if (encodingScheme == LMG_ENCODE_TXT)
   {
#endif /* GCP_VER_1_5 GCP_ASN */
      if ((cmAbnfEncPduMsg(protVar , (U8 *)&(msg->ver),
                           *hdrMBufPtr, &mgMgcoMsgHdrDef, &(tsap->tsapCfg.memId),
                           &err)) != ROK)
      {
         RETVALUE(MGT_ERR_INVALID_HDR_PARMS);
      }
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
   }
   else if (encodingScheme == LMG_ENCODE_BIN)
   {
      /* Encode Buffer & Transmit */
      /* Need to fix in the apropriate params once proto type is ready  */
      if ((mgEncPduMsg(protVar, (U8 *)msg, 0,
                       *hdrMBufPtr, MGED_HDR_ENC, &(tsap->tsapCfg.memId),
                       &err)) != ROK)
         
      {
         RETVALUE(MGT_ERR_INVALID_HDR_PARMS);
      }
   }
   else
   {
      /* Encoding type not defined properly */
      RETVALUE(MGT_ERR_INVALID_HDR_PARMS);
   }
#endif /* GCP_VER_1_5 GCP_ASN */


   /* 
   * Copy header into a temp field because SCatMsg clears the 
   *  concatenated buffer contents 
   */
   if ((SCpyMsgMsg((*hdrMBufPtr), tsap->tsapCfg.memId.region, 
                  tsap->tsapCfg.memId.pool, &(tmpHdrBuf))) != ROK)
   {
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }

   /* Concat Header to the mBuf to be transmitted */
   if ((SCatMsg(*(mBufPtr), tmpHdrBuf, M1M2)) != ROK)
   {
      /* mg003.105: Add - Added sanity check */
      if (tmpHdrBuf != NULLP)
         mgPutMsg(tmpHdrBuf);
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }
   /* mg003.105: Add - Added sanity check */
   if (tmpHdrBuf != NULLP)
      mgPutMsg(tmpHdrBuf);

   RETVALUE(MGT_NONE);

} /* end of mgGetMgcoMsgBuf() */






/*
*
*       Fun:   mgFillMgcoMsgBuf
*
*       Desc:  Gets buffer for each transaction, encodes transaction and 
*              attaches it to the message to be transmitted.
*
*       Ret:   MGT_NONE                       - Success
*              MGT_ERR_INVALID_PARMS          - Encode of transaction failed
*              MG_PDU_SZ_EXCEDED              - Message Exceeded MTU size
*              MG_MSG_SZ_EXCEDED              - Encoded Message Exceeded MTU size
*              MGT_ERR_RSRC_UNAVAIL           - Resouce Failure
*
*       Notes:
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgFillMgcoMsgBuf 
(
Buffer             *mBuf,              /* Message buffer */            
Buffer             *hdrMBuf,           /* Header Buffer */
Buffer             *txnMBuf,           /* Transaction buffer pointer */
MgMgcoMsg          *mgcoMsg,           /* MEGACO msg  */
U32                txnIdx,             /* Index of transaction in the msg */
Bool               *txnSend,           /* Txn is ready for transmission/not */
MsgLen             *crntPduLen,        /* Current length of the msg buffer */
MgTSAPCb           *tsap,              /* TSAP CB */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
U8                 encodingScheme,      /* Encoding scheme */
#endif
MgPeerCb           *peer              /* Peer Control Block */
)/*MAH_TODO Added encoding scheme to the prototype , because
   some times peer is null , This will lead to a dump */
#else
PUBLIC S16 mgFillMgcoMsgBuf(mBuf, hdrMBuf, txnMBuf, mgcoMsg,txnIdx, 
                             txnSend, crntPduLen, tsap,
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
                             encodingScheme ,
#endif
                             peer)
Buffer             *mBuf;              /* Message buffer */     
Buffer             *hdrMBuf;           /* Header Buffer */
Buffer             *txnMBuf;           /* Transaction buffer pointer */
MgMgcoMsg          *mgcoMsg;           /* MEGACO msg  */
U32                txnIdx;             /* Index of transaction in the msg */
Bool               *txnSend;           /* Txn is ready for transmission/ not */
MsgLen             *crntPduLen;        /* Current length of the msg buffer */
MgTSAPCb           *tsap;              /* TSAP CB */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
U8                 encodingScheme;     /* Encoding scheme */
#endif
MgPeerCb           *peer;              /* Peer Control Block */
#endif

{
   Buffer          *tmpHdrBuf;         /* Temorary Header Buffer */
   Buffer          *tmpTxnBuf;         /* Temporary Transaction Buffer */
   CmAbnfErr       err;                /* Encode Error Structure */
   MsgLen          msgLen;             /* Transaction Length */
   MsgLen          hdrLen;             /* Header Length */
   Bool            lenErr;             /* Error in Length */ 
   MgMgcoTxn*      mgcoTxn;            /* MEGACO txn */
   S16             ret;                /* Return Value */
   U32             protVar;



   TRC2(mgFillMgcoMsgBuf)




   lenErr = FALSE;

   mgcoTxn = mgcoMsg->body.u.tl.txns[txnIdx];


#ifdef GCP_VER_1_5
   protVar = mgcoMsg->ver.val;
   if (mgcoMsg->ver.val == 2)
   {
     protVar = CM_ABNF_PROT_MEGACO_H248_V2 /* MAH_TODO */;
   }
   else
#endif /* GCP_VER_1_5 */
   {
     protVar = CM_ABNF_PROT_MEGACO_H248;
   }


   if (mgcoTxn == NULLP)
      RETVALUE(ROK);
   /*MAH_TODO*/
   /* Encode Transaction */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 

   if (encodingScheme == LMG_ENCODE_TXT)
   {

#endif /* GCP_VER_1_5 GCP_ASN */
      if ((cmAbnfEncPduMsg(protVar , 
                           (U8 *)(&(mgcoTxn->type)), txnMBuf, 
                           &mgMgcoTxnDef, &(tsap->tsapCfg.memId), &err)) != ROK)
      {
         RETVALUE(MGT_ERR_INVALID_PARMS);
      }
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
   }
  
   else if (encodingScheme == LMG_ENCODE_BIN)
   {
       /* Encode Buffer & Transmit */
       /* Need to fix in the apropriate params once proto type is ready  */
       if ((mgEncPduMsg(protVar , (U8 *)mgcoMsg, txnIdx, txnMBuf, 
            MGED_TXN_ENC, &(tsap->tsapCfg.memId), &err)) != ROK)
       {
           RETVALUE(MGT_ERR_INVALID_PARMS);
       }
   }
   else
   {
       /* Encoding type not defined properly */
       RETVALUE(MGT_ERR_INVALID_PARMS);
   }

#endif /* GCP_VER_1_5 GCP_ASN */


   /* If the Rsp Msg size is > MTU size then return Error */
   if((*txnSend == TRUE) && (mgcoTxn->type.val == MGT_TXNREPLY))
                              
   {
      ret = ROK;
         /*
         * 1. Find the length of the Txn Response.
         * 2. Compare the Txn length to the configured Max MTU size. 
         * 3. If the length is greater than configured size then DROP 
         * 4. Inform the service user about the Error and Transaction Id.
         * 5. Error Code to be used is MGT_ERR_MSG_LENGTH.
         */
      MG_CHK_MTU_SIZE(txnMBuf, msgLen, peer, ret);

      if (ret != ROK)
         RETVALUE(ret);
      
      /* mg003.105: Updating the mBuf with txnMBuf in reply */
      /* Copy Transaction into a Buffer */
      if ((SCpyMsgMsg(txnMBuf, tsap->tsapCfg.memId.region, 
                     tsap->tsapCfg.memId.pool, &(tmpTxnBuf))) != ROK)
      {
         RETVALUE(MGT_ERR_RSRC_UNAVAIL);
      }
         
      /* Concat transaction to the mBuf to be transmitted */
      if ((SCatMsg(mBuf, tmpTxnBuf, M1M2)) != ROK)
      {
         /* mg003.105: Add - Added sanity check */
         if (tmpTxnBuf != NULLP)
            mgPutMsg(tmpTxnBuf);
         RETVALUE(MGT_ERR_RSRC_UNAVAIL);
      }

      /* mg003.105: Add - Added sanity check */
      if (tmpTxnBuf != NULLP)
         mgPutMsg(tmpTxnBuf);

   }



   /* 
    * Only transactions to be sent are to be appended to mBuf other 
    * are to be queued 
    */
   if ((*txnSend == TRUE) && (mgcoTxn->type.val == MGT_TXNREQ))
   {

      /* 
       * If it is a transaction chk if transaction size + crnt msg size
       * exceeds the allowed MTU size. If yes the transaction will have to be
       * put into a new message 
       */
      SFndLenMsg(txnMBuf, &msgLen);
      
      if ((peer) && (*crntPduLen + msgLen) > peer->mntInfo.mtuSize)
      {
         SFndLenMsg(hdrMBuf, &hdrLen);
         
         /* 
          * If there is no transaction in the mBuf yet it menas that the first 
          * transaction to be filled itself is bigger than MTU size. In such
          * a case we need to transmit it anyway 
          */
         if (*crntPduLen == hdrLen)
         {
            lenErr= TRUE;
         }
         else
            RETVALUE(MG_PDU_SZ_EXCEDED);
      }
      else
         *crntPduLen += msgLen;
      
      /* Copy Transaction into a Buffer */
      if ((SCpyMsgMsg(txnMBuf, tsap->tsapCfg.memId.region, 
                     tsap->tsapCfg.memId.pool, &(tmpTxnBuf))) != ROK)
      {
         RETVALUE(MGT_ERR_RSRC_UNAVAIL);
      }
         
      /* Concat transaction to the mBuf to be transmitted */
      if ((SCatMsg(mBuf, tmpTxnBuf, M1M2)) != ROK)
      {
         /* mg003.105: Add - Added sanity check */
         if (tmpTxnBuf != NULLP)
           mgPutMsg(tmpTxnBuf);
         RETVALUE(MGT_ERR_RSRC_UNAVAIL);
      }

      /* mg003.105: Add - Added sanity check */
      if (tmpTxnBuf != NULLP)
        mgPutMsg(tmpTxnBuf);
   }
  

   /* 
    * Attach Header to txnBuf 
    * Copy header into a temp field because SCatMsg clears the 
    * concatenated buffer contents 
    */

   if ((SCpyMsgMsg(hdrMBuf, tsap->tsapCfg.memId.region,
                   tsap->tsapCfg.memId.pool,
                   &(tmpHdrBuf))) != ROK)
   {
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }
  
  
   /* Concat Header to txn buffer to store in the transaction control block */
   if ((SCatMsg(txnMBuf, tmpHdrBuf, M2M1)) != ROK)
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
  
   /* mg003.105: Add - Added sanity check */
   if (tmpHdrBuf != NULLP)
      mgPutMsg(tmpHdrBuf);
 
   /* 
    * When lenErr flag is TRUE it implies that the first transaction to be 
    *  attached to the mBuf itself exceeds the max MTU size. In such a case we
    *  still send the message with the mBuf. So perempt it from getting sent in
    *  next mBuf also we need to set the txnSend flag to FALSE 
    */
   if (lenErr ==  TRUE)
   {
      *txnSend = FALSE;
      RETVALUE(MG_PDU_SZ_EXCEDED);
   }

#ifdef GCP_ASN
   /* mg003.105: Updating the mBuf with txnMBuf in reply */
   /* last minute prep */
   if (encodingScheme == LMG_ENCODE_BIN)
   {
      if ((*txnSend == TRUE) && ((mgcoTxn->type.val == MGT_TXNREQ) || 
               (mgcoTxn->type.val == MGT_TXNREPLY)))
      {
         if (mgPrepSend(protVar , mBuf, (CmMemListCp *)(mgcoMsg)) != ROK)
         {
            RETVALUE(MGT_ERR_INVALID_PARMS);
         }
      }
      if (mgPrepSend(protVar , txnMBuf, (CmMemListCp *)(mgcoMsg)) != ROK)
      {
         RETVALUE(MGT_ERR_INVALID_PARMS);
      }
   }
#endif
   RETVALUE(MGT_NONE);

} /* End of mgFillMgcoMsgBuf() */


/*
*
*       Fun:   mgValidateMgcoMsg
*
*       Desc:  This function checks MEGACO Txn received from user
*              is compatible with the peer state.
*
*       Ret:   ROK     - SUCCESS
*              RFAILED - FAILED
*              ROKDNA  - When message is queued and will be processed once state
*              update will be received from master.
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE S16 mgValidateMgcoMsg
(
MgPeerCb           *peer,              /* Peer Control Block */
MgMgcoMsg          *mgcoMsg,           /* Megaco Message */
MgTSAPCb           *tsap               /* TSAP Control block */
)
#else
PRIVATE S16 mgValidateMgcoMsg(peer, mgcoMsg, tsap)
MgPeerCb           *peer;              /* Peer Control Block */
MgMgcoMsg          *mgcoMsg;           /* Megaco Message */
MgTSAPCb           *tsap;              /* TSAP Control block */
#endif
{
   MgMgcoTxn       *mgcoTxn;           /* Megaco Transactions */
   /* mg003.105: added temparory reason field */
   U8                 *reason;         /* reason */

#ifdef GCP_MG
   MgSvcChgInfo    svcChgInfo;         /* Service Change Information */
   U8              method;             /* Service Change Method */
   S16             ret;                /* Return Value */
#endif /* GCP_MG */

   TRC2(mgValidateMgcoMsg)
  
   mgcoTxn = *(mgcoMsg->body.u.tl.txns);
    
   switch (peer->state)
   {
      case LMG_PEER_STATE_NULL:
         RETVALUE(RFAILED);

      case LMG_PEER_STATE_RESOLVING:
      case LMG_PEER_STATE_AWAIT_REG:
      case LMG_PEER_STATE_DISCONNECTED:
      {
#ifdef GCP_MGC
         if (mgCb.genCfg.entType == LMG_ENT_GC)
         {
           RETVALUE(RFAILED);
         }
#endif /* GCP_MGC */
#ifdef GCP_MG
         if (mgCb.genCfg.entType == LMG_ENT_GW)
         {
           /* On the MG side an outgoing registration message needs to be 
              processed differently. So chk if message is a registration 
              message */
            if (peer->state == LMG_PEER_STATE_AWAIT_REG)
            {
               method = MGT_NONE;
            }
            else 
            {
               method = MGT_SVCCHGMETH_RESTART;
            }
#ifdef GCP_VER_1_5
            /*  Made modificiations for version check locally */
            /* ret= mgVerifyVersion(mgcoTxn ,peer->ssap); */
               /* if (ret != ROK) */
                 /* RETVALUE(RFAILED);             */

#endif
#ifdef GCP_VER_1_5            
            /*  Made modificiations for version check locally */
            ret= mgVerifyVersion(mgcoTxn ,peer->ssap);
               if ((peer->ssap->ssapCfg.initReg != TRUE) && (ret !=ROK))
               /*if (ret != ROK)*/
                 RETVALUE(RFAILED);            

#endif
            /* Check if message is service change */
            ret=mgVerifySvcChg(mgcoTxn, &method);

            /* If return is ROK , verify the servive change method for 
               await reg */
            if ((ret == ROK) && (peer->state == LMG_PEER_STATE_AWAIT_REG))
            {
              if ((method != MGT_SVCCHGMETH_RESTART) &&
                  (method != MGT_SVCCHGMETH_DISCON))
              {
                ret = RFAILED;
              }
            }

            /* Check if message is service change */
            if (ret != ROK)
            {
               /* mg005.105: Check if Stack in lock state, do not process any messages */
/* paul modifyed for NEC feedback */
#ifdef GCP_MGCO
#ifdef GCP_MG
               if(peer->ssap->lockUnlock == TRUE)
                 RETVALUE(RFAILED);
#endif  /* GCP_MG */
#endif  /* GCP_MGCO */
                  
              /* The first transaction on the MG side is always expected to
                 be a service change for registration. If this is not the case 
                 we need to check if our layer was supposed to initaite 
                 registration process. If yes, we send out the service 
                 change message. If not an error is returned to the service 
                 user telling that the expected message was a service change */

               if (peer->ssap->ssapCfg.initReg == TRUE)
               {
                 /* Obtain the service change method to see if peer
                  * got disconnected */
                 MG_OBTAIN_SVCCHG_METHOD(method, peer);
#ifdef ZG_DFTHA
                 /* service change msg shall always be sent from master as it
                  * requires state update for peer*/
                  if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
                  {
                    /* If peer got disconnected, send method as
                     * DISCONNECTED */
                     /* mg003.105: Modify - if method is restart then reason is cold boot
                                            if method is disconnection then reason is fail */
                     if (method == MGT_SVCCHGMETH_RESTART)
                        reason = (U8*)MG_SCRSN_COLD_BOOT;
                     else
                        if (method == MGT_SVCCHGMETH_DISCON)
                           reason = (U8*)MG_SCRSN_MG_IMPN_FAIL;
                           
                     mgSendSrvcChng(peer, method, reason,
                                NULLP, (S32) MGT_NONE, NULLP);
                  }
#ifdef ZG_DFTHA
                  /* If this is not critical resource set then it should
                   * generate reverse update to master for sending service chg
                   * message and queue this txns */
                  else
                  {
                     /* Call PLDF function to send reverse update for sending
                      * service change internally */
                     ZgRvUpdInfo      updInfo;

                    /* If peer got disconnected, fill method as
                     * DISCONNECTED */
                     MG_FILL_RVUPD_REGCMD_INT(updInfo, \
                     (peer->accessInfo.peerId), method, \
                     MGT_NONE, ZG_RVUPD_SVCCHG_CMD_INT );
                    
                     tsap->rvNode = 
                         (MgRvUpdQNode *)zgReverseUpd(&updInfo,
                                                      peer->accessInfo.peerId,
                                                      MG_PEER_OUTTXNQ,
                                                      tsap->tsapCfg.tSAPId);
                    /* Now queue this message , this will be processed once
                     * state update is received from master . Queue this in to 
                     * link list "peerTxnQ" (present in peerCb) */
                     mgQueueRvUpdTxnReq(mgcoMsg, &peer->usrTxnQ,
                                        tsap->rvNode, LMG_PROTOCOL_MGCO,
                                        peer->ssap->ssapCfg.sSAPId);
                     RETVALUE(ROKDNA);
                  }
#endif /* ZG_DFTHA */
                  
               }
               else
                 RETVALUE(RFAILED);
            }
            else
            {
      
              /* If message is service change, process the message */
               mgFillSvcChgInfo(MG_SRVC_CHG_REQ, mgcoTxn, &svcChgInfo);
               ret  = mgPrcUserSrvcChng(peer, &svcChgInfo);
#ifdef ZG_DFTHA
               /* if ret is ROKDNA ..this means this is not Master copy so it
                * should generate reverse update for service change command from
                * user and queue this message */
               if(ret  == ROKDNA)
               {
                  ZgRvUpdInfo        updInfo; /* revrse update structure */
                    
                  updInfo.action =  ZG_RVUPD_SVCCHG_CMD_USR;
                  updInfo.u.sCmdU = peer->accessInfo.peerId;
                  /* Call PLDF fn to send reverse update */
                  tsap->rvNode = 
                      (MgRvUpdQNode *)zgReverseUpd(&updInfo, 
                                                   (peer->accessInfo.peerId), 
                                                   MG_PEER_OUTTXNQ,
                                                   tsap->tsapCfg.tSAPId);
                  /* Now queue the txns */
                  mgQueueRvUpdTxnReq(mgcoMsg, &peer->usrTxnQ,
                                     tsap->rvNode, LMG_PROTOCOL_MGCO,
                                     peer->ssap->ssapCfg.sSAPId);
               }
               else   
#endif /* ZG_DFTHA */
                     if(ret == ROK)
                     {
                        /*
                         * Since this service Change message
                         *             is being sent by the service user
                         *              set usrKnows to TRUE.
                         */
                        peer->mntInfo.usrKnows = TRUE;
                     }
                     else
                     {
                        RETVALUE(ret);
                     }
            }            
         }
#endif /* GCP_MG */
      }
      break;

      case LMG_PEER_STATE_REGISTER:
      case LMG_PEER_STATE_CONNECT:
      {
#ifdef GCP_MGC
         if (mgCb.genCfg.entType == LMG_ENT_GC)
         {
            if (mgcoTxn->type.val != MGT_TXNPEND && 
                mgcoTxn->type.val != MGT_TXNREPLY)
            {
               RETVALUE(RFAILED);
            }
         } 
#endif /* GCP_MGC */
#ifdef GCP_MG
         if (mgCb.genCfg.entType == LMG_ENT_GW)
         {
           if (mgcoTxn->type.val != MGT_TXNREQ)
             RETVALUE(RFAILED);
         }
#endif /* GCP_MG */
      }
      break;
   }

   RETVALUE(ROK);

} /* end of mgValidateMgcoMsg() */






/*
*
*       Fun:   mgVerifySvcChg
*
*       Desc:  This function checks if message is svcchg and if all 
*              the necessary parameters in service change are present.
*
*       Ret:   ROK     - SUCCESS
*              RFAILED - FAILED
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgVerifySvcChg
(
MgMgcoTxn          *mgcoTxn,           /* Megaco Transaction */
U8                 *method             /* Service Change Method */
)
#else
PUBLIC S16 mgVerifySvcChg(mgcoTxn, method)
MgMgcoTxn          *mgcoTxn;           /* Megaco Transaction */
U8                 *method;            /* Service Change Method */
#endif
{
   MgMgcoTxnReq     *mgcoTxnReq;        /* Megaco Transaction Request */
   MgMgcoActionReq  *action;            /* Action */
   MgMgcoCommandReq *cmdReq;            /* Command Request */

   TRC2(mgVerifySvcChg)

   if (mgcoTxn->type.val == MGT_TXNREQ)
   {   
      mgcoTxnReq = &mgcoTxn->u.req; 

#if (ERRCLASS & ERRCLS_INT_PAR)
      if ((mgcoTxnReq->pres.pres == NOTPRSNT) || 
          (mgcoTxnReq->al.num.pres == NOTPRSNT) ||
          (mgcoTxnReq->al.num.val == MGT_NONE))
      {
         RETVALUE(RFAILED);
      }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */


      if ((action = ((mgcoTxnReq->al.actns)[0])) == NULLP)
        RETVALUE(RFAILED);


#if (ERRCLASS & ERRCLS_INT_PAR)
      if ((action->pres.pres == NOTPRSNT) ||
          (action->cl.num.pres == NOTPRSNT) ||
          (action->cl.num.val == MGT_NONE))
      {
        RETVALUE(RFAILED);
      }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      if ((cmdReq = ((action->cl.cmds)[0])) == NULLP)
        RETVALUE(RFAILED);


#if (ERRCLASS & ERRCLS_INT_PAR)
      if ((cmdReq->pres.pres == NOTPRSNT) ||
          (cmdReq->cmd.type.pres == NOTPRSNT) ||
          (cmdReq->cmd.u.svc.pres.pres == NOTPRSNT))
      {
         RETVALUE(RFAILED);
      }

      if (((cmdReq->cmd.u.svc.parm.pres.pres == NOTPRSNT) ||
           (cmdReq->cmd.u.svc.parm.meth.pres.pres == NOTPRSNT)) ||
           ((cmdReq->cmd.u.svc.parm.meth.type.pres == NOTPRSNT)))
      {
         RETVALUE(RFAILED);
      }

#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      if (cmdReq->cmd.type.val != MGT_SVCCHG)
      {
         RETVALUE(RFAILED);
      }

      if (*method != MGT_SVCCHGMETH_HANDOFF)
      {    
        if ((cmdReq->cmd.u.svc.termId.type.pres == NOTPRSNT)||
            (cmdReq->cmd.u.svc.termId.type.val != MGT_TERMID_ROOT))
        {
          RETVALUE(RFAILED);
        }
      }

      if (*method != MGT_NONE)
      {
        if (cmdReq->cmd.u.svc.parm.meth.type.val != *method)
          RETVALUE(RFAILED);
      }
      else
        *method = cmdReq->cmd.u.svc.parm.meth.type.val;
   }
   else
      RETVALUE(RFAILED);

   RETVALUE(ROK);

} /* end of mgVerifySvcChg() */






/*
*
*       Fun:   mgVerifySvcChgRsp
*
*       Desc:  This function checks if message is svcchg response 
*
*       Ret:   ROK     - SUCCESS
*              RFAILED - FAILED
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE S16 mgVerifySvcChgRsp
(
MgMgcoTxn          *mgcoTxn,            /* Megaco Transaction */
Bool               chkTermId            /* Validate term id / not */
)
#else
PRIVATE S16 mgVerifySvcChgRsp(mgcoTxn,chkTermId)
MgMgcoTxn          *mgcoTxn;           /* Megaco Transaction */
Bool               chkTermId;          /* Validate term id / not */
#endif
{

   MgMgcoTxnReply    *mgcoTxnReply;    /* Megaco Transaction Reply */
   MgMgcoActnReply   *actionReply;     /* Action Reply */
   MgMgcoCxtCmdReply *rsp;             /* Context Reply */
   MgMgcoCmdReply    *reply;           /* Command Reply */

   TRC2(mgVerifySvcChgRsp)

   if (mgcoTxn->type.val == MGT_TXNREPLY)
   { 
      mgcoTxnReply = &mgcoTxn->u.reply;

#if (ERRCLASS & ERRCLS_INT_PAR)
      if ((mgcoTxnReply->pres.pres == NOTPRSNT) ||
          (mgcoTxnReply->type.pres == NOTPRSNT) ||
          (mgcoTxnReply->u.arl.num.pres == NOTPRSNT)||
          (mgcoTxnReply->u.arl.num.val == MGT_NONE))
      {
        RETVALUE(RFAILED);
      }

#endif /* (ERRCLASS & ERRCLS_INT_PAR) */


      if (mgcoTxnReply->type.val != MGT_ACTIONREPLY)  
        RETVALUE(RFAILED);

      if ((actionReply = ((mgcoTxnReply->u.arl.repl)[0])) == NULLP)
        RETVALUE(RFAILED);
      

#ifdef MGT_GCP_VER_1_4

#if (ERRCLASS & ERRCLS_INT_PAR)      
      if ((actionReply->pres.pres == NOTPRSNT) ||
          (actionReply->repErrSet.pres.pres == NOTPRSNT))
      {
        RETVALUE(RFAILED);
      }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      if (actionReply->repErrSet.reply.pres.pres == NOTPRSNT)
      {
        RETVALUE(RFAILED);
      }

      if ((rsp = &actionReply->repErrSet.reply) == NULLP)
        RETVALUE(RFAILED);


#else /* MGT_GCP_VER_1_4 */

#if (ERRCLASS & ERRCLS_INT_PAR)      
      if ((actionReply->pres.pres == NOTPRSNT) ||
          (actionReply->type.pres == NOTPRSNT))
      {
        RETVALUE(RFAILED);
      }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      if (actionReply->type.val != MGT_CXTCMDREPLY)
      {
        RETVALUE(RFAILED);
      }

      if ((rsp = &actionReply->u.reply) == NULLP)
        RETVALUE(RFAILED);

#endif /* MGT_GCP_VER_1_4 */


      
#if (ERRCLASS & ERRCLS_INT_PAR)
      if ((rsp->cl.num.pres == NOTPRSNT) || 
          (rsp->cl.num.val == MGT_NONE))
      {
        RETVALUE(RFAILED);
      }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */



      if ((reply = ((rsp->cl.repl)[0])) == NULLP)
        RETVALUE(RFAILED);


#if (ERRCLASS & ERRCLS_INT_PAR)        
      if (reply->type.pres == NOTPRSNT)
        RETVALUE(RFAILED);
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      if (reply->type.val != MGT_SVCCHG)
        RETVALUE(RFAILED);

#if (ERRCLASS & ERRCLS_INT_PAR)   
      if (reply->u.svc.pres.pres == NOTPRSNT)  
      {
        RETVALUE(RFAILED);
      }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
           
      
      if (chkTermId == TRUE)
      {
        if ((reply->u.svc.termId.type.pres == NOTPRSNT) ||
            (reply->u.svc.termId.type.val != MGT_TERMID_ROOT))
        {
          RETVALUE(RFAILED);
        }
      }

   }/* if transaction Response */   
   else
     RETVALUE(RFAILED);

   RETVALUE(ROK);

} /* end of mgVerifySvcChgRsp() */







/*
*
*       Fun:   mgFillSvcChgInfo
*
*       Desc:  This function fills the svc chng info strcuture with
*              information from the txn structure.
*
*       Ret:   ROK     - SUCCESS
*              RFAILED - FAILED
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE S16 mgFillSvcChgInfo
(
U8                 svcChgType,         /* Service Change Type */
MgMgcoTxn          *mgcoTxn,           /* Megaco Transaction */
MgSvcChgInfo       *svcChgInfo         /* Service Change Information */
)
#else
PRIVATE S16 mgFillSvcChgInfo(svcChgType, mgcoTxn, svcChgInfo)
U8                 svcChgType;         /* Service Change Type */
MgMgcoTxn          *mgcoTxn;           /* Megaco Transaction */
MgSvcChgInfo       *svcChgInfo;        /* Service Change Information */
#endif
{
   MgMgcoTxnReq     *mgcoTxnReq;       /* Megaco Transaction Request */
   MgMgcoActionReq  *action;           /* Action Request */
   MgMgcoCommandReq *cmdReq;           /* Command Request */
   MgMgcoTxnReply   *mgcoTxnReply;     /* Transaction Reply */
   MgMgcoActnReply  *actionRsp;        /* Action Response */
   MgMgcoCmdReply   *cmdReply;         /* Command Reply */
  
   TRC2(mgFillSvcChgInfo)
 
   if (svcChgType == MG_SRVC_CHG_REQ)
   {
      mgcoTxnReq = &mgcoTxn->u.req; 
      action = ((mgcoTxnReq->al.actns)[0]);
      cmdReq = ((action->cl.cmds)[0]);
      svcChgInfo->u.svcChgReq = &(cmdReq->cmd.u.svc);
      svcChgInfo->srvcChgType = MG_SRVC_CHG_REQ;

   }
   else
   if (svcChgType == MG_SRVC_CHG_REPLY)
   {
      mgcoTxnReply = &mgcoTxn->u.reply;
      actionRsp = ((mgcoTxnReply->u.arl.repl)[0]);
#ifdef MGT_GCP_VER_1_4
      cmdReply = ((actionRsp->repErrSet.reply.cl.repl)[0]);
#else /* MGT_GCP_VER_1_4 */
      cmdReply = ((actionRsp->u.reply.cl.repl)[0]);
#endif /* MGT_GCP_VER_1_4 */
      svcChgInfo->u.svcChgReply = &(cmdReply->u.svc);
      svcChgInfo->srvcChgType = MG_SRVC_CHG_REPLY;
   }

   RETVALUE(ROK);

} /* end of mgFillSvcChgInfo() */



/******************************************************************************/
/*                      MEGACO Incoming Message Processing                    */
/******************************************************************************/



/*
*
*       Fun:   mgMgcoDecodeTxnInd
*
*       Desc:  This function decodes the Megaco message buffer received from network
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or an acknowledgement or
*              acknowledgements for acknoledgements transmitted
*
*       File:  mg_cord.c
*
*/
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))

#ifdef ANSI
PUBLIC S16 mgMgcoDecodeTxnInd
(
MgMgcoMsg          *mgcoMsg,           /* Megaco Message */
Buffer             **mBuf,             /* Message Buffer */
Bool               *useAh,             /* Authentication header avialable ??*/
CmTptAddr          *srcAddr,           /* source address */
MgTSAPCb           *tsap,              /* TSAP control block */
MgcoTptInfo        *mgcoTptInfo,       /* Megaco Transport Information */
MgTptSrvr          *srvr               /* server control block */
)
#else
PUBLIC S16 mgMgcoDecodeTxnInd(mgcoMsg, mBuf, useAh, srcAddr, tsap, mgcoTptInfo, srvr)
MgMgcoMsg          *mgcoMsg;           /* Megaco Message */
Buffer             **mBuf;             /* Message Buffer */
Bool               *useAh;             /* Authentication header avialable ??*/
CmTptAddr          *srcAddr;           /* source address */
MgTSAPCb           *tsap;              /* TSAP control block */
MgcoTptInfo        *mgcoTptInfo;       /* Megaco Transport Information */
MgTptSrvr          *srvr;              /* server control block */
#endif

#else     /* GCP_PROV_SCTP || GCP_PROV_MTP3 */

#ifdef ANSI
PUBLIC S16 mgMgcoDecodeTxnInd
(
MgMgcoMsg          *mgcoMsg,           /* Megaco Message */
Buffer             **mBuf,              /* Message Buffer */
Bool               *useAh,              /* Authentication header avialable ??*/
CmTptAddr          *srcAddr,           /* source address */
MgTSAPCb           *tsap,              /* TSAP control block */
MgTptSrvr          *srvr               /* server control block */
)
#else
PUBLIC S16 mgMgcoDecodeTxnInd(mgcoMsg, mBuf, useAh, srcAddr, tsap, srvr)
MgMgcoMsg          *mgcoMsg;           /* Megaco Message */
Buffer             **mBuf;              /* Message Buffer */
Bool               *useAh;             /* Authentication header avialable ??*/
CmTptAddr          *srcAddr;           /* source address */
MgTSAPCb           *tsap;              /* TSAP control block */
MgTptSrvr          *srvr;              /* server control block */
#endif

#endif    /* GCP_PROV_SCTP */
{
   MsgLen          numDecBytes;        /* Number of decoded bytes */
   CmAbnfErr       err;                /* Error */
   CmAbnfDecOff    offset;             /* DBUF offset information */
   Buffer          *newMBuf;           /* Buffer for AH Header */
   MgMgcoMsg       *errMsg;            /* error message */
#ifdef GCP_VER_1_3
   S16             msgLen;             /* Transaction Length */
#endif /* GCP_VER_1_3 */
#if (defined(GCP_USE_AH) || defined (GCP_VER_1_3))
   S16             ret;                /* Return Value */
#endif /* GCP_USE_AH || GCP_VER_1_3 */

#ifdef GCP_VER_1_5
#ifdef GCP_ASN
   U8            encScheme;            /* Encoding Scheme */
#endif
#endif /* GCP_VER_1_5 */

   U32           protVar;              /* version support */
/* 
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
   S16            flag;
#endif *//* GCP_VER_1_5 GCP_ASN  */
#ifdef GCP_PROV_MTP3
   Bool           mtpFlag;
   Bool           encPresent;
   Bool           ToFindEncodingScheme;
#endif
   /* mg004.105: [MG] bug fix for not sending two error replies */
   Bool           errFlag = FALSE;
   TRC2(mgMgcoDecodeTxnInd)

   /* Initialise variables */
   errMsg    = NULLP;
   newMBuf   = NULLP;
   *useAh    = FALSE;

#ifdef GCP_PROV_MTP3
   mtpFlag   = FALSE;
   encPresent= FALSE;
   ToFindEncodingScheme = TRUE;
   
#endif
   cmMemset ((U8 *)&offset, (U8)0, sizeof(CmAbnfDecOff));

#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
   /* (void)flag; */
      /*
      * Invoke the wrapper function here 
      */
   
#if (defined (GCP_PROV_MTP3) || defined (GCP_PROV_SCTP))
    if (mgcoTptInfo !=NULLP)
    {
#ifdef GCP_PROV_MTP3    
      if (mgcoTptInfo->tptType == LMG_TPT_MTP3)
      {
        if (mgcoTptInfo->u.mgMtpInfo.mtpPeer !=NULLP)
        {
          encScheme = mgcoTptInfo->u.mgMtpInfo.mtpPeer->mgcoInfo.encodingScheme;
          encPresent = TRUE;
        
        }
        else
        {
        
          /*First encode using ABNF 
           * if this succeeds encoding scheme is text
           * if ABNF fails decode using binary
           * if binary fails it is an error
           * We need to pass the encoding scheme through mgcoTptInfo
           * to the place where we create the new peer .  
           */
          /*For MTP3 Transport Keep the encoding scheme as text first*/
          encScheme = LMG_ENCODE_TXT;
        }
      
      }
#endif

#ifdef GCP_PROV_SCTP
       /* In SCTP case we are assuming the encodingScheme will be */
       /* previously configured in tsap->endpCb */
       if (mgcoTptInfo->tptType == LMG_TPT_SCTP)
       {
          if (tsap != NULLP)
          {
             encScheme = tsap->endpCb.encodingScheme;
             mgcoTptInfo->encodingScheme = encScheme;
          }
       }
#endif /* GCP_PROV_SCTP */
    }
#endif /* GCP_PROV_SCTP || GCP_PROV_MTP3 */

   if(srvr)
     encScheme = srvr->encodingScheme;

   if (encScheme  == LMG_ENCODE_TXT)
   {
#endif
      /* Decode AH header if present This will be decoded using version one*/
      /* mg003.105: Add - Check if message is null return failure */
      if (*mBuf == NULLP)
         ret = RFAILED;
      else   
         ret = cmAbnfDecPduMsg(CM_ABNF_PROT_MEGACO_H248, 
                           (CmMemListCp *)&mgcoMsg->memCp,
                           (U8 *)&(mgcoMsg->ah), (*mBuf), &mgMgcoAuthHdrDef,
                            &numDecBytes, &offset, &err);
#ifdef GCP_PROV_MTP3      
      if ((mgcoTptInfo !=NULLP) && (mgcoTptInfo->tptType == LMG_TPT_MTP3))
      {
         if ((ret !=ROK )&& !encPresent)
         {
            mtpFlag = TRUE;

         }else
         {
            if (mgcoMsg->ah.pres.pres != NOTPRSNT)
            {
               mgcoTptInfo->encodingScheme = LMG_ENCODE_TXT;
               ToFindEncodingScheme = FALSE;
            }
            else 
            {  
               mtpFlag = TRUE;
               ToFindEncodingScheme = TRUE;
            }
         } 
      }
#endif    

#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
   }
   else if (encScheme == LMG_ENCODE_BIN)
   {
      /* Invoke the binary function here */
      /* mg003.105: Add - Check if message is null return failure */
      if (*mBuf == NULLP)
         ret = RFAILED;
      else   
         ret =mgDecPduMsg(CM_ABNF_PROT_MEGACO_H248, 
                        (U8 *)mgcoMsg, 0, (*mBuf), MGED_AUTHHDR,
                        &numDecBytes, &offset, &err);
       /* mg004.105: Added unauthorized mid checking */
#ifdef GCP_PROV_MTP3      
      if ((mgcoTptInfo !=NULLP) && (mgcoTptInfo->tptType == LMG_TPT_MTP3))
      {
         if ((ret !=ROK )&& !encPresent)
         {
            mtpFlag = TRUE;

         }else
         {
            if (mgcoMsg->ah.pres.pres != NOTPRSNT)
            {
               mgcoTptInfo->encodingScheme = LMG_ENCODE_BIN;
               ToFindEncodingScheme = FALSE;
            }
            else 
            {  
               mtpFlag = TRUE;
               ToFindEncodingScheme = TRUE;
            }
         } 
      }
#endif    

   }
   else
      ret = RFAILED;
#endif /* (defined (GCP_VER_1_5) && defined(GCP_ASN) */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
#ifdef GCP_PROV_MTP3
if ((mgcoTptInfo !=NULLP) && (mgcoTptInfo->tptType == LMG_TPT_MTP3))
{
   if (!encPresent)
   {  
      if (mtpFlag)
      {
         /*Comming here means , In the case of MTP3 Text Decoding failed
          * and Now we are trying to try with ASN
          */

         ret =mgDecPduMsg(CM_ABNF_PROT_MEGACO_H248, 
               (U8 *)mgcoMsg, 0, (*mBuf), MGED_AUTHHDR,
               &numDecBytes, &offset, &err);
         if ((ret== ROK) && (mgcoMsg->ah.pres.pres != NOTPRSNT))
         {
            ToFindEncodingScheme = FALSE;
            mgcoTptInfo->encodingScheme = LMG_ENCODE_BIN;
         }else 
            ToFindEncodingScheme = TRUE;


      }
   }
}
#endif /* (defined (GCP_VER_1_5) && defined(GCP_ASN) */
#endif   
#ifdef GCP_PROV_MTP3
   if (0)
#else
   if (ret != ROK)
#endif
   {
      /* added new param under flag */
#ifdef GCP_VER_1_3
      
      mgMgcoSendErrRsp(tsap,
#if    (defined(GCP_PROV_SCTP)  ||  defined(GCP_PROV_MTP3))
                       mgcoTptInfo,
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
                       srvr, 
                       srcAddr,
                       MGT_MGCO_RSP_CODE_BAD_REQ,
                       errMsg,
                       MGT_TXNID_NULL);
      
      
#else
      mgMgcoSendErrRsp(srvr,
                       srcAddr,
                       MGT_MGCO_RSP_CODE_BAD_REQ,
                       errMsg);
#endif /* GCP_VER_1_3 */
      /* Free the message that was produced error */
      RETVALUE(RFAILED);
   }
#ifdef GCP_PROV_MTP3
   encPresent = FALSE;
   mtpFlag    = FALSE;
#endif
   /* If AH header was present, remove it from the message */
   if (numDecBytes > 0)
   {
      /* AH header was present . Remove AH header from MBUF */
      SSegMsg((*mBuf), (MsgLen)(numDecBytes - 1), &newMBuf);
      /* mg003.105: Add - Added sanity check */
      if ((*mBuf) != NULLP)
        mgPutMsg((*mBuf));
#ifdef GCP_USE_AH
#ifdef GCP_MGC
      if (mgCb.genCfg.entType == LMG_ENT_GC)
      {
        *useAh = TRUE;
      }
#endif /* GCP_MGC */
      ret = mgValidateAH(&(mgcoMsg->ah), newMBuf);
     
      if (ret != ROK)
      {
         /* Free the message that was produced error */
         /* mg003.105: Add - Added sanity check */
         if (newMBuf != NULLP)
            mgPutMsg(newMBuf);
         /* added new param under flag */
#ifdef GCP_VER_1_3

         mgMgcoSendErrRsp(tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                          mgcoTptInfo,
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
                          srvr,
                          srcAddr,
                          MGT_MGCO_RSP_CODE_BAD_REQ,
                          errMsg,
                          MGT_TXNID_NULL);

#else
         mgMgcoSendErrRsp(srvr,
                          srcAddr,
                          MGT_MGCO_RSP_CODE_BAD_REQ,
                          errMsg);   
#endif /* GCP_VER_1_3 */
         RETVALUE(RFAILED);
      }
#endif /* GCP_USE_AH */
   }
   else
   {
      newMBuf = *mBuf;
   }

#ifdef GCP_VER_1_3
   mgcoMsg->pres.pres = PRSNT_NODEF;
   cmMemset ((U8 *)&offset, (U8)0, sizeof(CmAbnfDecOff));
   /* Decode MGCO message Header again the message header will be decoded in version one*/
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
   if (encScheme == LMG_ENCODE_TXT)
   {
#endif 
      /* mg003.105: Add - Check if message is null return failure */
      if (newMBuf == NULLP)
         ret = RFAILED;
      else   
         ret = cmAbnfDecPduMsg(CM_ABNF_PROT_MEGACO_H248, 
                            (CmMemListCp *)&mgcoMsg->memCp,
                            (U8 *)&(mgcoMsg->ver), newMBuf, &mgMgcoMsgHdrDef,
                            &numDecBytes, &offset, &err);
#ifdef GCP_PROV_MTP3      
         if ((mgcoTptInfo !=NULLP) && (mgcoTptInfo->tptType == LMG_TPT_MTP3))
         {      
            if (ToFindEncodingScheme)
            {  
               if ((ret !=ROK )&& !encPresent)
               {
                  mtpFlag = TRUE;

               }else
               {
                  mgcoTptInfo->encodingScheme = LMG_ENCODE_TXT;
                  mtpFlag= FALSE;
               }
            }
         }
#endif 
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
   }
   else if (encScheme == LMG_ENCODE_BIN)
   {
      /* mg003.105: Add - Check if message is null return failure */
      if (newMBuf == NULLP)
         ret = RFAILED;
      else   
      /* Invoke the binary function here */
         ret = mgDecPduMsg(CM_ABNF_PROT_MEGACO_H248, 
              (U8 *)mgcoMsg, 0, newMBuf, MGED_HDR_DEC,
              &numDecBytes, &offset, &err);
         /* mg004.105: Added unauthorized mid checking */
#ifdef GCP_PROV_MTP3      
         if ((mgcoTptInfo !=NULLP) && (mgcoTptInfo->tptType == LMG_TPT_MTP3))
         {      
            if (ToFindEncodingScheme)
            {  
               if ((ret !=ROK )&& !encPresent)
               {
                  mtpFlag = TRUE;

               }else
               {
                  mgcoTptInfo->encodingScheme = LMG_ENCODE_BIN;
                  mtpFlag= FALSE;
               }
            }
         }
#endif 

   }
   else
      ret = RFAILED;
#endif
#if (defined (GCP_VER_1_5) && defined(GCP_ASN) && defined (GCP_PROV_MTP3))
if ((mgcoTptInfo !=NULLP) && (mgcoTptInfo->tptType == LMG_TPT_MTP3))
{
   if (ToFindEncodingScheme)
   {  
      if(!encPresent)
      {  
         if (mtpFlag) 
         {
            /*Comming here means , In the case of MTP3 Text Decoding failed
             * and Now we are trying to try with ASN
             */

            ret = mgDecPduMsg(CM_ABNF_PROT_MEGACO_H248, 
                  (U8 *)mgcoMsg, 0, newMBuf, MGED_HDR_DEC,
                  &numDecBytes, &offset, &err);
            if (ret == ROK)
            {
               mgcoTptInfo->encodingScheme = LMG_ENCODE_BIN;
               encScheme = LMG_ENCODE_BIN;
            }  
         }
      }
   }
}
#endif 
      if ((ret != ROK) || (numDecBytes == 0))
      {
         /* mg007.105: added code to retrieve error statistics */
         MG_UPD_MGCO_PEER_ERROR_STS(MGT_MGCO_RSP_CODE_BAD_REQ, FALSE, NULLP, mgcoMsg);

         /* added new param */
         mgMgcoSendErrRsp(tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                       mgcoTptInfo,
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
                          srvr,
                          srcAddr,
                          MGT_MGCO_RSP_CODE_BAD_REQ,
                          errMsg,
                          MGT_TXNID_NULL);
         RETVALUE(RFAILED);
      }
      else
      {
         SSegMsg(newMBuf, (MsgLen)(numDecBytes - 1), mBuf);
         /* mg003.105: Add - Added sanity check */
         if (newMBuf != NULLP)
            mgPutMsg(newMBuf);       
      }

#ifdef GCP_VER_1_5

  /*
   * Get the version from first level decoding .
   * Pass the version parameter down .
   * Note: Need to see any protocol related procedure  to the above fact .
   * IF the message is a service change one .It will be encoded as a Version 1 message.
   * At this stage , we know the value of  mgcoMsg->ver.val .This will give the idea of the
   * version of the protocol  
   */
      /*  Removed if 0 here */

   if (mgcoMsg->ver.val == 2)
   {  
      protVar = CM_ABNF_PROT_MEGACO_H248_V2; 
   }   
   else 
   {  
       protVar = CM_ABNF_PROT_MEGACO_H248;
   }

#endif /* GCP_VER_1_5 */





   cmMemset ((U8 *)&offset, (U8)0, sizeof(CmAbnfDecOff));

#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
   if (encScheme == LMG_ENCODE_TXT)
   {
#endif 

      /* Decode MGCO message Body From  here pass the correct version*/
      /* mg003.105: Add - Check if message is null return failure */
      if (*mBuf == NULLP)
         ret = RFAILED;
      else   
         ret = cmAbnfDecPduMsg(
                            protVar,      
                            (CmMemListCp *)&mgcoMsg->memCp,
                            (U8 *)&(mgcoMsg->body), (*mBuf), &mgMgcoMsgBodyDef,
                            &numDecBytes, &offset, &err);
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
   }
   else if (encScheme == LMG_ENCODE_BIN)
   {
      /* mg003.105: Add - Check if message is null return failure */
      if (*mBuf == NULLP)
         ret = RFAILED;
      else   
         /* Invoke the binary function here */
         ret = mgDecPduMsg(protVar, (U8 *)mgcoMsg, 0, (*mBuf), MGED_BODY,\
          &numDecBytes, &offset, &err);

   }
   else
      ret = RFAILED;
#endif

   if ((ret != ROK)||(numDecBytes == 0))
   {
      /* mg007.105: added code to retrieve error statistics */
      MG_UPD_MGCO_PEER_ERROR_STS(MGT_MGCO_RSP_CODE_BAD_REQ, FALSE, NULLP, mgcoMsg);

      /* Free allocated resources */
      /* added new param */
      mgMgcoSendErrRsp(tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                        mgcoTptInfo,
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3*/
                       srvr,
                       srcAddr,
                       MGT_MGCO_RSP_CODE_BAD_REQ,
                       errMsg,
                       MGT_TXNID_NULL);
      RETVALUE(RFAILED);
   }
   else
   {
      newMBuf = *mBuf;
   }

   /* added support for errorDescriptor in messageBody */
   if ((mgcoMsg->body.type.pres == PRSNT_NODEF) &&
       (mgcoMsg->body.type.val  == MGT_ERRDESC))
            RETVALUE(ROK);


   mgcoMsg->body.u.tl.num.pres = PRSNT_NODEF;
   mgcoMsg->body.u.tl.num.val = 0;

   /* While buffer has some valid data or there is some decode error..
    * decode */
   while( (NULLP != newMBuf) && 
          ((MG_GET_MSGLEN(newMBuf, msgLen)) > MG_MIN_MSGLEN) )
   {
      MgMgcoTxn     *mgcoTxn;
      /* allocate memory for the message here */
      ret = mgAllocEventMem( 
                (Ptr *)&(mgcoMsg->body.u.tl.txns[mgcoMsg->body.u.tl.num.val]), 
                sizeof(MgMgcoTxn));
      if(ret != ROK)
      {
         break;
      }

      mgcoTxn = mgcoMsg->body.u.tl.txns[mgcoMsg->body.u.tl.num.val];


      /* Decode MGCO message Body*/
      cmMemset ((U8 *)&offset, (U8)0, sizeof(CmAbnfDecOff));

#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
      if (encScheme == LMG_ENCODE_TXT)
      {
#endif        
         /* mg003.105: Add - Check if message is null return failure */
         if (newMBuf == NULLP)
            ret = RFAILED;
         else   
            ret = cmAbnfDecPduMsg(protVar , 
                               (CmMemListCp *)&mgcoTxn->memCp,
                               (U8 *)&(mgcoTxn->type), newMBuf, &mgMgcoTxnDef,
                               &numDecBytes, &offset, &err);
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
      }
      else if (encScheme == LMG_ENCODE_BIN)
      {
         /* Invoke the binary function here */
         /* mg003.105: Add - Check if message is null return failure */
         if (newMBuf == NULLP)
            ret = RFAILED;
         else   
            ret =  mgDecPduMsg(protVar , 
            (U8 *)mgcoMsg, mgcoMsg->body.u.tl.num.val,
                        newMBuf, MGED_TXN_DEC,
                      &numDecBytes, &offset, &err);
      }
      else
         ret = RFAILED;
#endif /* (defined (GCP_VER_1_5) && defined(GCP_ASN)) */

      if ((ret != ROK) ||(numDecBytes == 0))
      {
         /* mg005.105: Reject unknow packages with MGT_MGCO_RSP_CODE_PACKAGE_UNSUPP error code */
         /* mg007.105: Corrected the error code */
#if   (defined(MGT_UNKNOWN_PKG_REJ) && defined(GCP_ASN))
         if(err.code != MGT_MGCO_RSP_CODE_PACKAGE_UNSUPP)
            err.code = MGT_MGCO_RSP_CODE_BAD_REQ;
#else
            err.code = MGT_MGCO_RSP_CODE_BAD_REQ;
#endif
         /*
          * If the incoming msg whose decoding failed was a transaction
          * request, then send the error response with EITHER, 1) the same
          * transaction id as in the transaction request if transaction id
          * could be parsed and decoded successfully OR, 2) transaction id
          * as 0 if it could not be parsed. Otherwise, if the incoming msg
          * was a transaction reply, transaction pending or a transaction
          * response ack, do NOT send any error response.
          */
         
         /* send error response to peer and process the decoded txns */
         if ((mgcoMsg->body.u.tl.txns[mgcoMsg->body.u.tl.num.val]->type.pres
              == PRSNT_NODEF)
             &&
             (mgcoMsg->body.u.tl.txns[mgcoMsg->body.u.tl.num.val]->type.val
              == MGT_TXNREQ))
         {
            if ((mgcoMsg->body.u.tl.txns[mgcoMsg->body.u.tl.num.val]->u.req\
                 .pres.pres == PRSNT_NODEF) &&
                (mgcoMsg->body.u.tl.txns[mgcoMsg->body.u.tl.num.val]->u.req\
                 .transId.pres == PRSNT_NODEF))
            {
               mgMgcoSendErrRsp(tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                                mgcoTptInfo,
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
                                srvr,
                                srcAddr,
                                err.code,
                                errMsg,
                                mgcoMsg->body.u.tl.txns[mgcoMsg->body\
                                                        .u.tl.num.val]->u.req.transId.val);
            }
            else
            {
               mgMgcoSendErrRsp(tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                               mgcoTptInfo ,
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
                                srvr,
                                srcAddr,
                                err.code,
                                errMsg,
                                MGT_TXNID_NULL);
            }
            /* mg004.105: [MG] bug fix for not sending two error replies */
            errFlag = TRUE;

            /* mg007.105: added code to retrieve error statistics */
            MG_UPD_MGCO_PEER_ERROR_STS(MGT_MGCO_RSP_CODE_BAD_REQ, FALSE, NULLP, mgcoMsg);
            
         }
         
         /* Free allocated resources */
         /* Free last txn */
         /*
          * added GCP_VER_1_3 flag for evnt struct freeing
          */
#ifdef GCP_VER_1_3
#ifdef GCP_CH
         mgChFreeCmds(mgcoMsg, mgcoMsg->body.u.tl.num.val);
#endif /* GCP_CH  */
         mgFreeEventMem((Ptr)mgcoTxn);
#endif /* GCP_VER_1_3 */
         mgcoMsg->body.u.tl.txns[mgcoMsg->body.u.tl.num.val] = NULLP;
         break; 
      }
      else
      {
         MsgLen   len = 0;
         
         /* added range check */
         if ((mgcoMsg->body.u.tl.num.val + 1) > MGT_MAX_TXNS)
         {
#ifdef DEBUGP
            MGDBGP (DBGMASK_LI,(mgCb.init.prntBuf,"\nError - Limit Reached!\n"
                                "Please increase the value of MGT_MAX_TXNS\n"));
#endif /* DEBUGP */
            RETVALUE(RFAILED);
         }
         
         ret = SFndLenMsg(newMBuf, &len);
         if(ret == RFAILED)
         {
            /* Free resources */
            RETVALUE(ret);
         }
         if( len == numDecBytes )
         {
            mgcoMsg->body.u.tl.num.val++;
            break;
         }
         SSegMsg(newMBuf, (MsgLen)(numDecBytes-1), mBuf);
         /* mg003.105: Add - Added sanity check */
         if (newMBuf != NULLP)
           mgPutMsg(newMBuf);
         newMBuf = *mBuf;
         mgcoMsg->body.u.tl.num.val++;
      }
      
   }  /* end of while */

   *mBuf = newMBuf;
#else
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
   if (encScheme == LMG_ENCODE_TXT)
   {
#endif
   /* Decode MGCO message */
      /* mg003.105: Add - Check if message is null return failure */
      if (newMBuf == NULLP)
         ret = RFAILED;
      else   
         ret = cmAbnfDecPduMsg(protVar , 
                        (CmMemListCp *)&mgcoMsg->memCp,
                         (U8 *)&(mgcoMsg->ver), newMBuf, &mgMgcoMsgDef,
                         &numDecBytes, &offset, &err);

#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
   }
   else if (encScheme == LMG_ENCODE_BIN)
   {
      /* mg003.105: Add - Check if message is null return failure */
      if (newMBuf == NULLP)
         ret = RFAILED;
      else   
      /* Invoke the binary function here */
         ret = mgDecPduMsg(protVar , 
                         (U8 *)mgcoMsg, 0, newMBuf, MGED_MEGACO,
                         &numDecBytes, &offset, &err);

   }
   else
      ret = RFAILED;

#endif /* (defined (GCP_VER_1_5) && defined(GCP_ASN)) */

   if (ret != ROK)
   {
      /* Free allocated resources */
      /* mg003.105: Add - Added sanity check */
      if (newMBuf != NULLP)
         mgPutMsg(newMBuf);
      
      /* mg007.105: added code to retrieve error statistics */
      MG_UPD_MGCO_PEER_ERROR_STS(MGT_MGCO_RSP_CODE_BAD_REQ, FALSE, NULLP, mgcoMsg);
      mgMgcoSendErrRsp(srvr, srcAddr, MGT_MGCO_RSP_CODE_BAD_REQ, errMsg);   
      RETVALUE(RFAILED);
   }
   *mBuf = newMBuf;
#endif /* GCP_VER_1_3 */

   /* mg004.105: [MG] bug fix for not sending two error replies */
   if (errFlag == FALSE)
      RETVALUE(ROK);
   else
      RETVALUE(RFAILED);

} /* mgMgcoDecodeTxnInd */

/*
*
*       Fun:   mgPrcMgcoTxnInd
*
*       Desc:  This function decodes the message buffer received from network
*              and processes the transactions and indicates 
*              the received transactions to the user
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or an acknowledgement or
*              acknowledgements for acknoledgements transmitted
*
*       File:  mg_cord.c
*
*/

#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))

#ifdef ANSI
PUBLIC S16 mgPrcMgcoTxnInd
(
MgcoTptInfo        *mgcoTptInfo,        /* Megaco Transport Information */
MgTSAPCb           *tsap,              /* TSAP Control Block */
MgTptSrvr          *srvr,              /* Listener Control Block */
CmTptAddr          *srcAddr,           /* Source Transport Address */
Buffer             *mBuf,              /* Message Buffer */
MgMgcoMsg          *mgcoMsg,           /* MEGACO Message */
MgPeerCb           *peer               /* peer control block */ 
)
#else
PUBLIC S16 mgPrcMgcoTxnInd (mgcoTptInfo, tsap, srvr, srcAddr, mBuf, mgcoMsg, peer)
MgcoTptInfo        *mgcoTptInfo;        /* Megaco Transport Information */
MgTSAPCb           *tsap;              /* TSAP Control Block */
MgTptSrvr          *srvr;              /* Listener Control Block */
CmTptAddr          *srcAddr;           /* Source Transport Address */
Buffer             *mBuf;              /* Message Buffer */
MgMgcoMsg          *mgcoMsg;           /* MEGACO Message */
MgPeerCb           *peer;              /* peer control block */ 
#endif

#else     /* GCP_PROV_SCTP || GCP_PROV_MTP3 */

#ifdef ANSI
PUBLIC S16 mgPrcMgcoTxnInd
(
MgTSAPCb           *tsap,              /* TSAP Control Block */
MgTptSrvr          *srvr,              /* Listener Control Block */
CmTptAddr          *srcAddr,           /* Source Transport Address */
Buffer             *mBuf,              /* Message Buffer */
MgMgcoMsg          *mgcoMsg,           /* MEGACO Message */
MgPeerCb           *peer               /* peer control block */ 
)
#else
PUBLIC S16 mgPrcMgcoTxnInd (tsap, srvr, srcAddr, mBuf, mgcoMsg, peer)
MgTSAPCb           *tsap;              /* TSAP Control Block */
MgTptSrvr          *srvr;              /* Listener Control Block */
CmTptAddr          *srcAddr;           /* Source Transport Address */
Buffer             *mBuf;              /* Message Buffer */
MgMgcoMsg          *mgcoMsg;           /* MEGACO Message */
MgPeerCb           *peer;              /* peer control block */ 
#endif

#endif    /* GCP_PROV_SCTP */
{
   S16             ret;                /* Return Value */
   S16             errAction;          /* Action to be taken on error */
   S16             rspCode;            /* Action to be taken on error */
   MgMgcoMsg       *errMsg;            /* Err Message to be sent to peer */
   Bool            useAh;              /* AH header to be used/ not */
#ifdef GCP_CH
   S16             err;   
#endif /* GCP_CH  */
   TRC2(mgPrcMgcoTxnInd)

   /*
    *   Initialise variables
    */
   errMsg    = NULLP;
   errAction = MGT_NONE;
   useAh     = FALSE;
   ret       = ROK;



   /*
    * Allocate a transaction structure to be passed to user
    */
   if(mgcoMsg == NULLP)
   {
      ret = mgAllocEventMem((Ptr *)&mgcoMsg, sizeof(MgMgcoMsg)); 
      if (ret != ROK)
      {
         /* Discard Transaction */
         /* mg003.105: Add - Added sanity check */
         if (mBuf != NULLP)
            mgPutMsg(mBuf);
         RETVALUE(RFAILED);
      }
      /* initialize no. of message */
      mgcoMsg->body.u.tl.num.val = 0;
   }


   /*
    * Generate Trace Indication
    */
   mgGenTrcInd(tsap, MG_NONE, LMG_TRC_EVENT_MGCORX, peer, mBuf);


   /*
    * Now decode Megaco message
    */
#ifdef CM_ABNF_MT_LIB
   if(mBuf != NULLP)
   {
      UConnId      suConnId;
      U8 encodingScheme = LMG_ENCODE_TXT /*Default text MAH_TODO */;

      if (NULLP == srvr)
      {
         suConnId = NULLP;
#ifdef GCP_PROV_SCTP         
         if(mgcoTptInfo->assocCb) /*MAH_TODO*/
          encodingScheme = mgcoTptInfo->assocCb->peer->mgcoInfo.encodingScheme;
#endif           
      }  
      else
      {
         suConnId = srvr->suConnId; /*MAH_TODO */
         encodingScheme = srvr->encodingScheme;
      }  
      
      if(mgSndDecPduMsgReq(encodingScheme, suConnId,
                           CM_ABNF_PROT_MEGACO_H248,
                           mBuf,
                           srcAddr,
                           mgcoMsg,
                           tsap
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                           , mgcoTptInfo
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
                           ) != ROK)
      {
         /* Free memory */
         MG_FREE_MGCO_EVNT_MEM(mgcoMsg, TRUE);
         RETVALUE(RFAILED);
      }
      else
        RETVALUE(ROK);
   }
#else /* CM_ABNF_MT_LIB */

   if((mBuf != NULLP) && 
       (mgMgcoDecodeTxnInd(mgcoMsg, (&mBuf),
                           &useAh, srcAddr,
                           tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                           mgcoTptInfo,
#endif    /* GCP_PROV_SCTP || GCP_PROC_MTP3 */
                           srvr
                           ) != ROK))

   {
      /* mg003.105: Add - Added sanity check */
      if (mBuf != NULLP)
         mgPutMsg(mBuf);       
      /* Free memory */
      MG_FREE_MGCO_EVNT_MEM(mgcoMsg, TRUE);
      RETVALUE(RFAILED);
   }

#endif /* CM_ABNF_MT_LIB */


   if(mBuf)
   {
      mgPutMsg(mBuf);       
   }


   /*
    *   Process the decoded message
    */
   ret = mgPrcMgcoMsg(mgcoMsg,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                       mgcoTptInfo,
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
                      tsap,
                      srvr,
                      srcAddr,
                      &errAction,
                      &rspCode,
                      &peer,
                      &errMsg);


   /* If message processing failed send err message to the peer from which
      the message was received. */
   if (ret == RFAILED)
   {
      if (errAction == MG_DISCARD_MSG)
      {
         /* now generating unauthorized error response also */
         if ((rspCode ==  MG_NONE) ||
             (rspCode == MGT_MGCO_RSP_CODE_UNAUTHORIZED) ||
             (rspCode == MGT_MGCO_RSP_CODE_NOT_READY) ||
             (rspCode == MGT_MGCO_RSP_CODE_REQRCVD_BEFORE_REGCMPLT) ||
             (rspCode == MGT_MGCO_RSP_CODE_PROT_ERROR) ||
             (rspCode == MGT_MGCO_RSP_CODE_VERSION_UNSUPP))
         {
            /*
             *            If message is to be discarded and an error
             *            response is to be sent, we shall use the first
             *            transaction to determine the transactionId, if
             *            available.
             *            An error response has to be generated only for
             *            transaction requests.
             */
            U32 transId = MGT_TXNID_NULL;  /* initialize the txnId to 0 */

            if ((mgcoMsg->body.type.pres == PRSNT_NODEF) &&
                (mgcoMsg->body.type.val == MGT_TXN) &&
                (mgcoMsg->body.u.tl.num.pres == PRSNT_NODEF) &&
                (mgcoMsg->body.u.tl.txns) &&
                (mgcoMsg->body.u.tl.txns[0]) &&
                (mgcoMsg->body.u.tl.txns[0]->type.pres == PRSNT_NODEF) &&
                (mgcoMsg->body.u.tl.txns[0]->type.val == MGT_TXNREQ) &&
                (mgcoMsg->body.u.tl.txns[0]->u.req.pres.pres == PRSNT_NODEF) &&
                (mgcoMsg->body.u.tl.txns[0]->u.req.transId.pres == PRSNT_NODEF)
               )
            {
               transId = mgcoMsg->body.u.tl.txns[0]->u.req.transId.val;
            }

            if (rspCode == MG_NONE)
               rspCode = MGT_MGCO_RSP_CODE_PROT_ERROR;

            /* mg007.105: added code to retrieve error statistics */
            MG_UPD_MGCO_PEER_ERROR_STS(rspCode, TRUE, peer, mgcoMsg);
            /* added new param under flag */
#ifdef GCP_VER_1_3

            mgMgcoSendErrRsp(tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                             mgcoTptInfo,
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
                             srvr,
                             srcAddr, rspCode,
                             errMsg, transId);

#else  /* GCP_VER_1_3 */
            mgMgcoSendErrRsp(srvr, srcAddr, rspCode, errMsg);
#endif /* GCP_VER_1_3 */
         }

         if ((peer != NULLP) && (useAh == TRUE))
           peer->mgcoInfo.useAHScheme = TRUE;

         MG_FREE_MGCO_EVNT_MEM(errMsg, TRUE);
         MG_FREE_MGCO_EVNT_MEM(mgcoMsg, TRUE);
#ifdef ZG
         /* Send update message to standby */
         zgUpdPeer();
#endif /* ZG */
         RETVALUE(RFAILED);
      }
   }

   /* If AH acheme needs to be used in future set flag in peer cb */
   if ((peer != NULLP) && (useAh == TRUE))
     peer->mgcoInfo.useAHScheme = TRUE;

   /* 
    * Transactions which were found erroneous during processing need
    * to be discarded from the message sent to the service user 
    */
   if ((ret = mgRmvEmptyTxn((Ptr) mgcoMsg,LMG_PROTOCOL_MGCO))== RFAILED)
   {
      MG_FREE_MGCO_EVNT_MEM(mgcoMsg, TRUE);
#ifdef ZG
      zgUpdPeer();
#endif /* ZG */
#ifdef ZG_DFTHA
      /* In case of DFTHA .. there may be some reverse update generated and txn
       * will be sent to user after receiving updtae from Master. In this case
       * message is queued and mgcoMsg may not contain txns.*/
      RETVALUE(ROK);
#else
      RETVALUE(RFAILED);
#endif /* ZG_DFTHA */
   }

   /* Use the MGCO specific macro */
   MG_COPY_PEERINFO_INTO_MGCOMSG(mgcoMsg->lcl, peer);

   peer->mntInfo.usrKnows = TRUE;

#if (defined(GCP_CH) && defined(GCP_VER_1_5))
 
/*   mg004.105: GCP_ALLOW_LIMIT_CFG - This is introduced
 *   to configured the limits for GCP message
 *   components exceeding which will be rejected */
#ifdef GCP_ALLOW_LIMIT_CFG
       /* Check for the limits against the limits */ 
      if (mgChValidateTxnInd (mgcoMsg, peer, &err) != ROK)
      {
         U32 transId = MGT_TXNID_NULL;  /* initialize the txnId to 0 */

         if ((mgcoMsg->body.type.pres == PRSNT_NODEF) &&
               (mgcoMsg->body.type.val == MGT_TXN) &&
               (mgcoMsg->body.u.tl.num.pres == PRSNT_NODEF) &&
               (mgcoMsg->body.u.tl.txns) &&
               (mgcoMsg->body.u.tl.txns[0]) &&
               (mgcoMsg->body.u.tl.txns[0]->type.pres == PRSNT_NODEF) &&
               (mgcoMsg->body.u.tl.txns[0]->type.val == MGT_TXNREQ) &&
               (mgcoMsg->body.u.tl.txns[0]->u.req.pres.pres == PRSNT_NODEF) &&
               (mgcoMsg->body.u.tl.txns[0]->u.req.transId.pres == PRSNT_NODEF)
            )
         {
            transId = mgcoMsg->body.u.tl.txns[0]->u.req.transId.val;
         }


         if (err == MGT_CH_ERR_NONE)
            rspCode = MGT_MGCO_RSP_CODE_PROT_ERROR;
         else
            rspCode = err;

         /* mg007.105: added code to retrieve error statistics */
         MG_UPD_MGCO_PEER_ERROR_STS(rspCode, TRUE, peer, mgcoMsg);

         /* mg013.103: added new param under flag */
#ifdef GCP_VER_1_3

         mgMgcoSendErrRsp(tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
               mgcoTptInfo,
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
               srvr,
               srcAddr, rspCode,
               errMsg, transId);

#else  /* GCP_VER_1_3 */
         mgMgcoSendErrRsp(srvr, srcAddr, rspCode, errMsg);
#endif /* GCP_VER_1_3 */

      } 

#endif /* GCP_ALLOW_LIMIT_CFG  */
 
   /* Compiled with CH module let CH process the Txn Indication         */
   /* TODO:10/27/04:10:16   Enable CH processing of transaction */
   /* if chEnabled flag is true in ssap  */
 
   /* mgChPrcMgcoTxnInd (mgcoMsg, peer, &err);  */
   if (peer->ssap->ssapCfg.chEnabled == TRUE) 
      mgChPrcMgcoTxnInd (mgcoMsg, peer, &err); 
   else
      MgUiMgtMgcoTxnInd (&(peer->ssap->suPst), peer->ssap->suId, mgcoMsg);
      
#else
   /* Send Indication to user */
   MgUiMgtMgcoTxnInd (&(peer->ssap->suPst), peer->ssap->suId, mgcoMsg);
#endif /* GCP_CH && GCP_VER_1_5 */ 

   /* 
    * If some error was found during processing of the message 
    * which called for removing peer association after passing 
    * the message to the user, the removal of association is done 
    * in the following function 
    */
   if ((errAction == MG_DELETE_PEER_PASS_TXN) ||
         (errAction == MG_VER_UNSUPP))
   {
#ifdef ZG_DFTHA
      /* Only master should delete peer */
      if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
      {
         peer->mntInfo.usrKnows = FALSE;
         mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED, 
                   LMG_CAUSE_SRVCCHNG_FAILED, FALSE);
         if(errAction == MG_VER_UNSUPP)
            peer->state = LMG_PEER_STATE_VER_UNSUPP;
      }
#ifdef ZG_DFTHA
      else
      {
         /* send reverse update to delete peer */
         ZgRvUpdInfo   updInfo;
         MG_FILL_RVUPD_DEL_PEER(updInfo,peer,LMG_EVENT_PEER_REMOVED,
            LMG_CAUSE_SRVCCHNG_FAILED,FALSE);

         tsap->rvNode = 
              (MgRvUpdQNode *)zgReverseUpd(&updInfo, peer->accessInfo.peerId,
                                           MG_QUEUE_NONE, tsap->tsapCfg.tSAPId);
      }
#endif /* ZG_DFTHA */
   }

   MG_FREE_MGCO_EVNT_MEM(errMsg, TRUE);
#ifdef ZG
   /* Send update message to standby */
   zgUpdPeer();
#endif /* ZG */
   
   RETVALUE(ROK);

} /* end of mgPrcMgcoTxnInd () */




/*
*
*       Fun:   mgPrcMgcoMsg
*
*       Desc:  Processes the Decoded MEGACO message 
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or an acknowledgement or
*              acknowledgements for acknoledgements transmitted
*
*       File:  mg_cord.c
*
*/

#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))

#ifdef ANSI
PRIVATE S16 mgPrcMgcoMsg
(
MgMgcoMsg        *mgcoMsg,     /* Incoming Megaco Message */
MgcoTptInfo      *mgcoTptInfo,        /* Megaco Transport Information */
MgTSAPCb         *tsap,        /* TSAP Control Block */
MgTptSrvr        *srvr,        /* Listener Control Block */
CmTptAddr        *srcAddr,     /* Source Transport Address */
S16              *errAction,   /* Action to be taken on error */
S16              *rspCode,     /* Error Response Code */
MgPeerCb         **peerPtr,    /* pointer to peer control blk */
MgMgcoMsg        **errMsg      /* Error Message */
)
#else
PRIVATE S16 mgPrcMgcoMsg(mgcoMsg, mgcoTptInfo, tsap, srvr, srcAddr, errAction,
                         rspCode, peerPtr, errMsg)
MgMgcoMsg        *mgcoMsg;     /* Incoming Megaco Message */
MgcoTptInfo      *mgcoTptInfo; /* Megaco Transport Information */
MgTSAPCb         *tsap;        /* TSAP Control Block */
MgTptSrvr        *srvr;        /* Listener Control Block */
CmTptAddr        *srcAddr;     /* Source Transport Address */
S16              *errAction;   /* Action to be taken on error */
S16              *rspCode;     /* Error Response Code */
MgPeerCb         **peerPtr;    /* pointer to peer control blk */
MgMgcoMsg        **errMsg;     /* Error Message */
#endif

#else     /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */

#ifdef ANSI
PRIVATE S16 mgPrcMgcoMsg
(
MgMgcoMsg        *mgcoMsg,     /* Incoming Megaco Message */
MgTSAPCb         *tsap,        /* TSAP Control Block */
MgTptSrvr        *srvr,        /* Listener Control Block */
CmTptAddr        *srcAddr,     /* Source Transport Address */
S16              *errAction,   /* Action to be taken on error */
S16              *rspCode,     /* Error Response Code */
MgPeerCb         **peerPtr,    /* pointer to peer control blk */
MgMgcoMsg        **errMsg      /* Error Message */
)
#else
PRIVATE S16 mgPrcMgcoMsg(mgcoMsg, tsap, srvr, srcAddr, errAction,
                         rspCode,peerPtr, errMsg)
MgMgcoMsg        *mgcoMsg;     /* Incoming Megaco Message */
MgTSAPCb         *tsap;        /* TSAP Control Block */
MgTptSrvr        *srvr;        /* Listener Control Block */
CmTptAddr        *srcAddr;     /* Source Transport Address */
S16              *errAction;   /* Action to be taken on error */
S16              *rspCode;     /* Error Response Code */
MgPeerCb         **peerPtr;    /* pointer to peer control blk */
MgMgcoMsg        **errMsg;     /* Error Message */
#endif

#endif    /* GCP_PROV_SCTP */
{
   MgSvcChgInfo   svcChgInfo;      /* Service Change Inforamtion Structure */
   Bool           validPeerState;  /* Peer state validated / not */
   Bool           peerTypeChkDone; /* Peer type (active/standby) chk done/not */
   MgPeerCb       *peer;           /* Peer Control Block */
   U16            loopIdx;         /* Counter */
   MgMgcoTxn      *mgcoTxn;        /* MEGACo transaction */
   MgTransId      transId;         /* Transaction Identifier */
   S16            ret;             /* Return Value */
   MgRxTransIdEnt *rxCb;           /* Response Transaction Control Block */
   U32            i;               /* Counters */
   U32            j;               /* Counters */
   U8             rspType;         /* Response Type */
   Bool           sendUpd;         /* send update */
#ifdef ZG_DFTHA
   U16            cnt;             /* Counters */
#endif /* ZG_DFTHA */
#ifdef   GCP_PROV_SCTP    
   MgAssocCb       *assoc = NULLP; /* Association Control Block as passed in mgcoTptInfo */
#endif   /* GCP_PROV_SCTP */
#ifdef   GCP_PROV_MTP3
   Dpc             peerDpc = NULLD;     /* Peer DPC as passed in MgcoTptInfo */
#endif   /* GCP_PROV_MTP3 */   
#ifdef GCP_VER_1_5 
#ifdef GCP_PKG_MGCO_ROOT 
   MgTxTransIdEnt *tmpTxCb;        /* Temp Tx Block */  
   Bool            limitExceeded;      /* Pending Limit Exceeded /not */          
#endif
#endif 

#ifdef GCP_CH
   MgMgcoInd      chInd;
#endif /* GCP_CH  */

   TRC2(mgPrcMgcoMsg)


   /*
    * Initialize Variable
    */
   validPeerState  = FALSE;
   peer            = *peerPtr;
   peerTypeChkDone = FALSE;
   sendUpd         = FALSE;
   cmMemset((U8 *)&svcChgInfo, 0, sizeof(MgSvcChgInfo));

#ifdef GCP_VER_1_5
#ifdef GCP_PKG_MGCO_ROOT
   limitExceeded = FALSE;
   tmpTxCb       = NULLP;
#endif
#endif

    /* 
    * Code added to pass multiple trasport parameter and then make each 
    * transport available in an
    * local copy of its transport variable 
    */
#if   (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
   if(mgcoTptInfo != NULLP)
   {
#ifdef   GCP_PROV_SCTP   
      if(mgcoTptInfo->tptType == LMG_TPT_SCTP)
         assoc = mgcoTptInfo->u.assocCb;
#endif   /* GCP_PROV_SCTP */         
#ifdef   GCP_PROV_MTP3      
      if (mgcoTptInfo->tptType == LMG_TPT_MTP3) 
         peerDpc  = mgcoTptInfo->u.mgMtpInfo.clgAddr;
#endif   /* GCP_PROV_MTP3 */         
    }     
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
 
    
#if (ERRCLASS & ERRCLS_DEBUG)
   if (mgcoMsg == NULLP)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG041, 0,
                 "mgPrcMgcoMsg (): Null Msg Pointer\n");
      *errAction = MG_DISCARD_MSG;
      *rspCode   = MGT_MGCO_RSP_CODE_PROT_ERROR;  /* added */
      RETVALUE(RFAILED);
   }

   if (mgcoMsg->body.type.pres == NOTPRSNT)
   {
      *errAction = MG_DISCARD_MSG;
      *rspCode   = MGT_MGCO_RSP_CODE_PROT_ERROR;  /* added */
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */



   /* Find Peer */
   if(            /* Do Not remove this statement */
#ifdef    GCP_PROV_MTP3
      (peerDpc) ||
#endif    /* GCP_PROV_MTP3 */
   
#ifdef    GCP_PROV_SCTP
  /*
   *   the handling for the case when the transport
   *   is SCTP or TCP is similar
   */

      (assoc) ||

#endif    /* GCP_PROV_SCTP */

   ((srvr) && (srvr->srvrType == MG_TCP_CLIENT_CONNECTION)))
   {


#ifdef    GCP_PROV_SCTP

      if (assoc)
         peer = assoc->peer;
      else
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3
         if ((mgcoTptInfo !=NULLP) && (mgcoTptInfo->tptType == LMG_TPT_MTP3)
               && peerDpc)
         peer = mgcoTptInfo->u.mgMtpInfo.mtpPeer;
       else  
#endif    /* GCP_PROV_MTP3 */       

         peer = srvr->t.peer;




      *peerPtr = peer;

      /* 
       * Check to see if this peerCb is in MID based list. If not, 
       * then insert it in MID based list and remove it from IP addr based
       * list 
       */
      if (LMG_ENT_GW == mgCb.genCfg.entType)
      {
#ifdef GCP_MG
         MgPeerCb   *tmpPeer;
         if(PRSNT_NODEF != peer->accessInfo.mid.pres)
         {
            CmTptAddr addr;


            /* copy IPV4/IPV6 structure */
            MG_FILL_TPTADDR_FRM_NETADDR(&addr,
                                        &(peer->accessInfo.\
                                          peerAddrTbl.netAddr[0]));

            tmpPeer = mgGetAndAdjstPeerInLst(&mgcoMsg->mid, &addr, NULLP, 
                                             (MgSSAPCb *)peer->ssap, &sendUpd);
            /* [VJ]: This will always pass when sendUpd=TRUE, as then NULLP
             * is returned. */

            /*
             *             check added for tmpPeer;
             *             tmpPeer can be NULLP e.g. if the received message
             *             has a different mid and a different source address
             *             than the configured values;
             *             MGCs have to be configured at the MG side;
             *             they can NOT be discovered;
             *             Send an error response - unauthorized (402);
             */

            if ((tmpPeer == NULLP) ||
                (peer != tmpPeer))
            {
               /*
                *   Since this a TCP connection/SCTP association, coming
                *   here means that the MGC with which we established the
                *   transport connection has changed its address or mid.
                *   Nevertheless, it is still the same MGC with which we
                *   established the connection. We have to return an error
                *   to the MGC depending on the state of the MGC which
                *   occording to us is still peer (pointed to by the srvr
                *   or the assoc).
                */
               *errAction = MG_DISCARD_MSG;

               switch (peer->state)
               {
                  /* if we haven't sent out the SrvChg send err 502 Not Ready */
                  case LMG_PEER_STATE_AWAIT_REG:
                  case LMG_PEER_STATE_RESOLVING:
                     *rspCode = MGT_MGCO_RSP_CODE_NOT_READY;
                     break;

                  /*
                   * if registration has not been completed yet with the MGC,
                   * send err 505 Request received before service change
                   * reply has been received
                   */
                  case LMG_PEER_STATE_REGISTER:
                     *rspCode = MGT_MGCO_RSP_CODE_REQRCVD_BEFORE_REGCMPLT;
                     break;

                  /* any other state send err - unauthorized */
                  default:
                     *rspCode = MGT_MGCO_RSP_CODE_UNAUTHORIZED;
                     break;
               }

               RETVALUE(RFAILED);
            }

         }

         /* mg004.105: Added unauthorized mid checking */
         tmpPeer = mgGetPeer(&mgcoMsg->mid, srcAddr, NULLP, 
                          (MgSSAPCb *)peer->ssap, &sendUpd);

         /*
          *             check added for peer;
          *             peer can be NULLP e.g. if the received message
          *             has a different mid and a different source address
          *             than the configured values;
          *             MGCs have to be configured at the MG side;
          *             they can NOT be discovered;
          *             Send an error response - unauthorized (402);
          */

         if (tmpPeer == NULLP)
         {
            MG_GET_IP_FROM_IPPORT(tmpPeer, mgcoMsg, srcAddr, 
                               NULLP, sendUpd); 

            if (tmpPeer == NULLP)
            {
               *errAction = MG_DISCARD_MSG;
               *rspCode   = MGT_MGCO_RSP_CODE_UNAUTHORIZED;
               RETVALUE(RFAILED);
            }
         }

         
#endif /* GCP_MG */
      }
      else   /* entType is MGC */
      {
         /* 
          * If this is a MGC, and peer is still NULL, check if there is
          * a configured peer available 
          */

         if (peer == NULLP)
         {
            if ((peer = mgGetPeer(&mgcoMsg->mid, srcAddr, NULLP , NULLP,
                                  &sendUpd)) != NULLP)
            {
               *peerPtr = peer;
            }
         }
      }
   }
   else
   {
      if (mgCb.genCfg.entType == LMG_ENT_GC)
      {
         peer = mgGetPeer(&mgcoMsg->mid, srcAddr, NULLP , NULLP,
                          &sendUpd);
      }
#ifdef GCP_MG
      else 
      {
         peer = mgGetPeer(&mgcoMsg->mid, srcAddr, NULLP, 
                          (MgSSAPCb *)srvr->t.ssap, &sendUpd);

         /*
          *             check added for peer;
          *             peer can be NULLP e.g. if the received message
          *             has a different mid and a different source address
          *             than the configured values;
          *             MGCs have to be configured at the MG side;
          *             they can NOT be discovered;
          *             Send an error response - unauthorized (402);
          */

         if (peer == NULLP)
         {

            MG_GET_IP_FROM_IPPORT(peer, mgcoMsg, srcAddr,
                        (MgSSAPCb *)srvr->t.ssap, sendUpd); 

            if (peer == NULLP)
            {
               *errAction = MG_DISCARD_MSG;
               *rspCode   = MGT_MGCO_RSP_CODE_UNAUTHORIZED;
               RETVALUE(RFAILED);
            }
         }
      }
#endif /* GCP_MG */
      *peerPtr = peer;
      if(NULLP != peer)
      {
         /* Use the MGCO specific macro */
         MG_COPY_PEERINFO_INTO_MGCOMSG(mgcoMsg->lcl, peer);
      }
   }


#ifdef GCP_MG
#ifdef ZG_DFTHA
   if (sendUpd == TRUE)
   {
      /* coming here implies ..peer exist in Mid list as well in Ip/Dmn address
      * list.. send reverse update to adjust peer */
      ZgRvUpdInfo          updInfo;     /* reverse update info */
      U32                  peerId;      /* peer id */
      MgMgcoMsg            *newMsg;     /* megaco message */
      MgRvUpdQNode         *queue;      /* queue where msg will be queued */
      
      /* [VJ]: With sendUpd=TRUE, peer will always be NULLP. No need for 
       * this check * */
      /* Fill all the relevant information which should go into reverse
      * update */
      peerId = MG_INVALID_PEERID;
      MG_FILL_GET_AND_ADJST_PEER(updInfo, &mgcoMsg->mid, srcAddr, 
         srvr->suConnId);
      /* Call fn to send reverse upadte */
      /* If peer is unknown then queue in into Tsap reverse update Q */

      queue = &(tsap->rvUpdQ);
      tsap->rvNode = 
            (MgRvUpdQNode *)zgReverseUpd(&updInfo, peerId, MG_TSAP_TXNQ,
                                         tsap->tsapCfg.tSAPId); 

      ret = mgAllocEventMem((Ptr *)&newMsg, sizeof(MgMgcoMsg)); 
      /* copy content of old message to new message */ 
      MG_MGCO_COPY_EVNT_STRUCT(mgcoMsg, newMsg);
      newMsg->body.u.tl.num.val = 0;
      for(cnt = 0; cnt< mgcoMsg->body.u.tl.num.val;cnt++)
      {
         newMsg->body.u.tl.num.pres = PRSNT_NODEF;
         newMsg->body.u.tl.txns[cnt] = 
            mgcoMsg->body.u.tl.txns[cnt];
         newMsg->body.u.tl.num.val++;
         mgcoMsg->body.u.tl.txns[cnt] = NULLP;
      }
      mgQueueRvUpdTxnInd(newMsg, queue, tsap->rvNode, LMG_PROTOCOL_MGCO,
                         srcAddr, srvr);
      RETVALUE(ROKDNA);
   }
#endif /* ZG_DFTHA */
#endif /* GCP_MG */


   /* Add check for non null peer */
   /* If the message is an error descriptor */
   if ((mgcoMsg->body.type.val == MGT_ERRDESC) && (peer != NULLP))
   {
      /* Check if per is in valid state */
      ret = mgValidatePeer(peer, &peerTypeChkDone, &validPeerState);
      /* mg007.105: There shouldn't be response to a response or Error
       * Descriptor in the message level */
      /*
      if (ret != ROK)
      {
         *errAction = MG_DISCARD_MSG;
         *rspCode   = MGT_MGCO_RSP_CODE_PROT_ERROR; 
         RETVALUE(RFAILED);
      } 
      */
   
      if (ret == ROK)
         peer->peerSts.numErrors++;

      RETVALUE(ROK);
   }

   /* If there are no transactions then discard message */
   if ((mgcoMsg->body.u.tl.num.pres == NOTPRSNT) ||
      (mgcoMsg->body.u.tl.num.val == 0))
   {
      *errAction = MG_DISCARD_MSG;
      *rspCode   = MGT_MGCO_RSP_CODE_PROT_ERROR;  /* added */
      RETVALUE(RFAILED);
   }


   /* For Each Transaction */
   for (loopIdx = 0; loopIdx < mgcoMsg->body.u.tl.num.val; loopIdx++)
   
   {
      *rspCode = MG_NONE;
      mgcoTxn = mgcoMsg->body.u.tl.txns[loopIdx];
      MG_GET_TRANSID(mgcoTxn, transId);
#ifdef ZG_DFTHA
      /* Check if this transaction is meant for this non critical resource 
       * set if yes, then process it else call PLDF function to route this 
       * message to proper copy; for TxnRsp Ack just process it*/
      if(mgcoTxn->type.val != MGT_TXNRSPACK)
      {
         if(!zgChkNCRsetStatus(transId, LMG_PROTOCOL_MGCO,
               peer, (mgcoTxn->type.val), MG_TRANS_TYPE_RX, 
               srvr->suRsetId, (PTR)mgcoMsg, loopIdx))
         {
            U32   peerId;
            peerId = MG_INVALID_PEERID;
            if(peer != NULLP)
               peerId = peer->accessInfo.peerId;
            zgPldfSendGcpMsg(srvr->suConnId,srcAddr, loopIdx, 
                             (PTR)mgcoMsg, peerId, tsap->tsapCfg.tSAPId);
            /* no need of freeing mgcoTxn as this will be freed in PSF */
            *(mgcoMsg->body.u.tl.txns + loopIdx) = NULLP;
            continue;
         }  
      }
      /* Call PSF fn to obatin rset id ..and pass that in txn..which will be
       * bounced back by service user */
      
      mgcoTxn->rsetId = zgObtainRsetId(srvr->suRsetId, (PTR)mgcoMsg, loopIdx);
#endif /* ZG_DFTHA */
         
      /* chk if message is a service change request */
      ret = mgChkIncSvcChgReq(mgcoTxn, &svcChgInfo);


      /*   if service change message process the message;
       *
       *   tsap needs to be passed to the following function;
       *   peer->tsap will be initialized to tsap in this function;
       */
      if (ret == ROK)
      {
         ret = mgProcessSrvcChng(errAction,
                                 rspCode,
                                 &(mgcoMsg->mid), 
                                 &(mgcoMsg->ver),
                                 &svcChgInfo,
                                 &peer, 
                                 tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                                 mgcoTptInfo,
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
                                 srvr,
                                 srcAddr,
                                 transId,
                                 TRUE, mgcoTxn);
         if (ret == RFAILED)
         {
            /* If transaction is wrong, discard it */
            /* mg007.105: added code to retrieve error statistics */
            MG_UPD_MGCO_PEER_ERROR_STS((*rspCode), TRUE, peer, NULLP);

            if (*errAction == MG_DISCARD_TXN)
            {
               /* mg008.105: Passing one more parameter peer control block */
               mgFillErrMsg(errMsg,  mgcoTxn, peer);
               
#ifdef GCP_VER_1_3

               mgMgcoSendErrRsp(tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                                mgcoTptInfo,
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
                                srvr,
                                srcAddr, MGT_MGCO_RSP_CODE_RSRC_ERROR,
                                *errMsg, transId);

#else  /* GCP_VER_1_3 */
               mgMgcoSendErrRsp(srvr, srcAddr, 
                              MGT_MGCO_RSP_CODE_RSRC_ERROR,
                              errMsg);
#endif /* GCP_VER_1_3 */


               /*
                * free the SDP Tkn Buf
                */
#ifdef CM_SDP_OPAQUE
               mgMgcoFreeAllTkBfs((mgcoMsg->body.u.tl.txns[loopIdx]));
#endif /* CM_SDP_OPAQUE */

               /*
                * added GCP_VER_1_3 flag for evnt struct freeing
                */
#ifdef GCP_VER_1_3
#ifdef GCP_CH
               mgChFreeCmds(mgcoMsg, loopIdx);
#endif /* GCP_CH  */
               mgFreeEventMem((Ptr) (*(mgcoMsg->body.u.tl.txns + loopIdx)));
#endif /* GCP_VER_1_3 */
               *(mgcoMsg->body.u.tl.txns + loopIdx) = NULLP;
               continue;
            }
            /* If message is incorrect discard the entire message */
            else if (*errAction == MG_DISCARD_MSG)
            {
               /* Processing of service change resulted in error */
               /* send service change reply */
               mgSendSrvcChngReply(peer,
                                   *rspCode,
                                   tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                                   mgcoTptInfo,
#endif    /* GCP_PROV_SCTP | GCP_PROV_MTP3 */
                                   srvr,
                                   srcAddr,
                                   mgcoMsg, 
                                   transId);
               /*
                *             since we have already sent an error msg
                *             in the above function mark *rspCode as
                *             prot_err so that a second error response
                *             is not sent in mgPrcMgcoTxnInd.
                */
               *rspCode = MGT_MGCO_RSP_CODE_BAD_REQ;
            }
            RETVALUE(RFAILED);
         }      

#ifdef ZG_DFTHA
         if(ret == ROKDNA)
         {
            /* if this is non critical rSet then it should generate reverse 
             * update to Master and queue this message 
             */
            ZgRvUpdInfo          updInfo;   /* reverse update info */
            MgMgcoMsg            *newMsg;   /* new message */
            U32                  peerId;    /* peer id */
            MgRvUpdQNode         *queue;    /* queue where msg will be queued */
            
            /* Fill all the relevant information which should go into reverse
            * update */
            cmMemset(((U8*)(&updInfo)), 0, sizeof(ZgRvUpdInfo));
            if(peer == NULLP)
            {
               peerId = MG_INVALID_PEERID;
            }
            else
            {
               peerId = peer->accessInfo.peerId;
            }
            /* Send srvr->suRsetId as suConnId to Master,  since it also has 
               rSet emebedded into it by LDF.  */
            MG_FILL_RVUPD_SVCCMD_PEER(updInfo, peer, (srvr->suRsetId),
               (&(mgcoMsg->mid)), (&(mgcoMsg->ver)),transId, 
               (&svcChgInfo),srcAddr);
            /* Call fn to send reverse upadte */
            if(peerId == MG_INVALID_PEERID)
            {
               /* If peer is unknown then queue in into Tsap reverse update Q */
               queue = &(tsap->rvUpdQ);
               tsap->rvNode = 
                    (MgRvUpdQNode *)zgReverseUpd(&updInfo, peerId, 
                                                 MG_TSAP_TXNQ,
                                                 tsap->tsapCfg.tSAPId); 
            }
            else
            {
               queue = &(peer->peerTxnQ);
               tsap->rvNode = 
                    (MgRvUpdQNode *)zgReverseUpd(&updInfo, peerId,
                                                 MG_PEER_INTXNQ,
                                                 tsap->tsapCfg.tSAPId);
            }

            /* Now queue the txn which generated reverse update. To insure 
             * inorder delivery queue all the txn which is after this service
             * change cmd*/

            ret = mgAllocEventMem((Ptr *)&newMsg, sizeof(MgMgcoMsg)); 
            /* copy header part */ 
            MG_MGCO_COPY_EVNT_STRUCT(mgcoMsg, newMsg);
            newMsg->body.u.tl.num.val = 0;
            for(cnt = loopIdx;cnt< mgcoMsg->body.u.tl.num.val;cnt++)
            {
               newMsg->body.u.tl.num.pres = PRSNT_NODEF;
               newMsg->body.u.tl.txns[cnt-loopIdx] = 
                  mgcoMsg->body.u.tl.txns[cnt];
               newMsg->body.u.tl.num.val++;
               mgcoMsg->body.u.tl.txns[cnt] = NULLP;
            }
            mgQueueRvUpdTxnInd(newMsg, queue, tsap->rvNode,
                              LMG_PROTOCOL_MGCO, srcAddr, srvr);

            RETVALUE(ROK);
         }
#endif /* ZG_DFTHA */
         *peerPtr = peer;
         continue;

      } /* end of if for service chg msg */
      

      /* Validate Peer State */
      if (peer == NULLP) 
      {
         *errAction = MG_DISCARD_MSG;
         *rspCode   = MGT_MGCO_RSP_CODE_PROT_ERROR;  /* added */
         RETVALUE(RFAILED);
      }    


      /*
       *   From this point onwards, peer as well as peer->tsap
       *   are guaranteed to be valid courtesy the check above
       */
      

      /* chk if message is a service change response */
      if (loopIdx == 0)
      {      
         ret = mgChkIncSvcChgRsp(mgcoTxn, &svcChgInfo);
         
         /* If yes, process response i.e make appropriate peer state transitions 
         etc.*/
         if (ret == ROK)
         {
            U8              msgInfo;
            MgTxTransIdEnt  *txCb; 
            txCb = NULLP;

            /* Locate the transaction Control Block */
            if ((cmHashListFind(&(peer->outTransLst), (U8 *)&transId, 
                       MG_TRANSID_LEN, MG_HASH_SEQNMB_DEF, 
                       (PTR *) &txCb)) != ROK)
            {

               /* Added for freeing the unwanted transaction */
               /* *errAction = MG_DISCARD_TXN; */
               /* RETVALUE(RFAILED); */

               /* which doesn't contain valid transaction Id in the peer*/
#ifdef CM_SDP_OPAQUE
               mgMgcoFreeAllTkBfs((mgcoMsg->body.u.tl.txns[loopIdx]));
#endif /* CM_SDP_OPAQUE */

               /*
                * added GCP_VER_1_3 flag for evnt struct freeing
                */
#ifdef GCP_VER_1_3
               mgFreeEventMem((Ptr) (*(mgcoMsg->body.u.tl.txns + loopIdx)));
#endif /* GCP_VER_1_3 */
               *(mgcoMsg->body.u.tl.txns + loopIdx) = NULLP;
               continue;

               /* changes end                                 */
            }


            /* Ensure that the txn is received on the same transport addres as
             * the command was sent from */

            if ((srvr) && (txCb->suConnId != srvr->suConnId))
            {
               *errAction = MG_DISCARD_TXN;
               RETVALUE(RFAILED);
            }

            msgInfo = txCb->msgInfo;


            ret = mgProcessSrvcChngReply(errAction, &(mgcoMsg->ver), 
                                         &svcChgInfo, peer,
#ifdef    GCP_PROV_SCTP
                                         assoc,
#endif    /* GCP_PROV_SCTP */
                                         srvr, srcAddr,
                                         msgInfo,(txCb->transId),
                                         TRUE, &txCb);


            if(ret == RFAILED)
            {
               /* If message is incorrect, abort the processing */
               if (*errAction != MG_DISCARD_TXN)
               {
                  if (*errAction == MG_DISCARD_MSG)
                  {
                     *rspCode   = MGT_MGCO_RSP_CODE_PROT_ERROR;
                  }
                  RETVALUE(RFAILED);
               }
               /* If transactin is incorrect, remove it from the message */

               /*
                * free the SDP Tkn Buf
                */
#ifdef CM_SDP_OPAQUE
               mgMgcoFreeAllTkBfs((mgcoMsg->body.u.tl.txns[loopIdx]));
#endif /* CM_SDP_OPAQUE */

               /*
                * added GCP_VER_1_3 flag for evnt struct freeing
                */
#ifdef GCP_VER_1_3
#ifdef GCP_CH
               mgChFreeCmds(mgcoMsg, loopIdx);
#endif /* GCP_CH  */
               mgFreeEventMem((Ptr) (*(mgcoMsg->body.u.tl.txns + loopIdx)));
#endif /* GCP_VER_1_3 */
               *(mgcoMsg->body.u.tl.txns + loopIdx) = NULLP;
               continue;
            }      
            else if(ret == ROK)
            {
#ifdef GCP_VER_1_3
               /* check if immAck is set in reply..or we are enabled to send
                  * response ack always */
               /* mg002.105: rspAckEnb is now reconfigurable */
               if (((PRSNT_NODEF == mgcoTxn->u.reply.immAck.pres) && 
                     (TRUE != mgCb.genCfg.indicateRetx)) ||
                     (mgCb.genCfg.reCfg.rspAckEnb & LMG_SEND_RSPACK_MGCO))
#else  
               if ((PRSNT_NODEF == mgcoTxn->u.reply.immAck.pres) && 
                     (TRUE != mgCb.genCfg.indicateRetx))
#endif /* GCP_VER_1_3 */
               {
                  /*
                   *   as this point assoc is guaranteed to be valid;
                   *   ServiceChange handling is done above
                   */
                  ret = mgSendTxnRspAck(peer,
#ifdef    GCP_PROV_SCTP
                                        assoc,
#endif    /* GCP_PROV_SCTP */
                                        srvr,
                                        transId);
               }
               continue;
            }/* ROKDNA */ 

#ifdef ZG_DFTHA
            else if(ret == ROKDNA)
            {
               MgMgcoMsg            *newMsg;
               /* Now queue the txn which generated reverse update. 
                  * To insure inorder delivery queue all the txn which is 
                  * after this service change reply*/

               ret = mgAllocEventMem((Ptr *)&newMsg, sizeof(MgMgcoMsg)); 
               /* copy content of message */
               MG_MGCO_COPY_EVNT_STRUCT(mgcoMsg, newMsg);
               newMsg->body.u.tl.num.val = 0;
               for(i=loopIdx;i< mgcoMsg->body.u.tl.num.val;i++)
               {
                  newMsg->body.u.tl.num.pres = PRSNT_NODEF;
                  newMsg->body.u.tl.txns[i] = 
                     mgcoMsg->body.u.tl.txns[loopIdx];
                  newMsg->body.u.tl.num.val++;
                  mgcoMsg->body.u.tl.txns[loopIdx] = NULLP;
               }

               /* Call func to queue this message into peerTxnQ. */
               mgQueueRvUpdTxnInd(newMsg, &peer->peerTxnQ, tsap->rvNode,
                                  LMG_PROTOCOL_MGCO, srcAddr, srvr);
               RETVALUE(ROK);              /* Now queue the message */
            }
#endif /* ZG_DFTHA */
         }
         /* mg004.105: Added version negotiation */
#ifdef GCP_MG
         else
         {
            /*-- Bugfix: Message with incorrect version rejected --*/
            if ((mgCb.genCfg.entType == LMG_ENT_GW) &&
                (peer != NULLP) && (peer->state == LMG_PEER_STATE_ACTIVE) &&
                (mgcoMsg->ver.pres != NOTPRSNT) && 
                (mgcoMsg->ver.val != peer->mgcoInfo.negotiatedVersion))
            {
               *errAction = MG_DISCARD_MSG;
               *rspCode   = MGT_MGCO_RSP_CODE_VERSION_UNSUPP;
               RETVALUE(RFAILED);
            }
         }
#endif /* MG */
      }
         
      /* Validate Peer state & type */
      if (((mgCb.genCfg.entType == LMG_ENT_GC) &&
            (peerTypeChkDone == FALSE)) || 
            (validPeerState == FALSE))  
      {
         if((mgcoTxn->type.val == MGT_TXNPEND) && 
            (peer->state == LMG_PEER_STATE_REGISTER))
         {
            /* do nothing */
         }
         else
         {
            if ((ret = mgValidatePeer(peer, &peerTypeChkDone, 
                                    &validPeerState)) != ROK)
            {
               *errAction = MG_DISCARD_MSG;

               /*
                *             if its a gateway, send an error response
                *             with error code - 402 unauthorized since.
                *             the MGC peer is not the currently active one.
                *             Generate an error response iff it is a
                *             transaction request.
                */

#ifdef GCP_MG
               if ((mgCb.genCfg.entType == LMG_ENT_GW) &&
                   (mgcoTxn) && (mgcoTxn->type.pres == PRSNT_NODEF) &&
                   (mgcoTxn->type.val == MGT_TXNREQ) )
               {
                  /*
                   *   This msg is a non SrvChg (Cmd or Rsp) msg from a
                   *   known peer. The peer state is invalid. Generate
                   *   the error response based on the peer state.
                   */

                  switch (peer->state)
                  {
                     /* if we haven't sent out the SrvChg send err 502 Not Ready */
                     case LMG_PEER_STATE_AWAIT_REG:
                     case LMG_PEER_STATE_RESOLVING:
                        *rspCode = MGT_MGCO_RSP_CODE_NOT_READY;
                        break;

                     /*
                      * if registration has not been completed yet with the MGC,
                      * send err 505 Request received before service change
                      * reply has been received
                      */
                     case LMG_PEER_STATE_REGISTER:
                        *rspCode = MGT_MGCO_RSP_CODE_REQRCVD_BEFORE_REGCMPLT;
                        break;

                     /* If the registration is failed due to version negotiation */   
                     case LMG_PEER_STATE_VER_UNSUPP:
                        *rspCode = MGT_MGCO_RSP_CODE_VERSION_UNSUPP;
                        break;

                     /* any other state send err - unauthorized */
                     default:
                        *rspCode = MGT_MGCO_RSP_CODE_UNAUTHORIZED;
                        break;
                  }

               }
               else
#endif /* GCP_MG */
                  *rspCode   = MGT_MGCO_RSP_CODE_PROT_ERROR;

               RETVALUE(RFAILED);
            }  
         }
      }

      /* If transactin is incorrect, remove it from the message */
      if (mgcoTxn->type.pres == NOTPRSNT)
      {

         /*
          * free the SDP Tkn Buf
          */
#ifdef CM_SDP_OPAQUE
         mgMgcoFreeAllTkBfs((mgcoMsg->body.u.tl.txns[loopIdx]));
#endif /* CM_SDP_OPAQUE */

         /*
          * added GCP_VER_1_3 flag for evnt struct freeing
          */
#ifdef GCP_VER_1_3
#ifdef GCP_CH
         mgChFreeCmds(mgcoMsg, loopIdx);
#endif /* GCP_CH  */
         mgFreeEventMem((Ptr) (*(mgcoMsg->body.u.tl.txns + loopIdx)));
#endif /* GCP_VER_1_3 */
         *(mgcoMsg->body.u.tl.txns + loopIdx) = NULLP;
         continue;
      }

      MG_GET_TRANSID(mgcoTxn, transId);


      /* Process transaction */
      switch (mgcoTxn->type.val)
      {
         case MGT_TXNREQ:
         {            

            rxCb = mgPrcIncomingTxn(peer, srcAddr, transId, 
                                    &(mgcoTxn->dupInfo.pres), FALSE,
#ifdef    GCP_PROV_SCTP
                                    assoc,
#endif    /* GCP_PROV_SCTP */
                                    srvr, 
                                    mgcoTxn->type.val, MG_NONE);

            /*
             *  We know that this is a txn request .
             * Commands can be a part of only a request
             * Also the properties xxxPending limits can be a part
             * of Modify command . For persistency we need to move this
             * to the rxCb.This can be retrieved from mgSendTxnPend message
             * Further this property has to be a part of peer ControlBlock.
             * From peer control block  we need to copy to rxCb.This is because 
             * peerCb will be valid accross txns and RxcB is valid for that 
             * particular txn .
             */
            
            /*
             * First copy the values from Txn to peer if the
             * Command is Modify.The following function will copy the
             * values in pending limit to peer.limit 
             */
#ifdef GCP_MG            
#if (defined (GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT)) 
            if ( (mgGetPendingLimit(mgcoTxn, peer) != RFAILED) &&
                    peer->limit.pres.pres == PRSNT_NODEF)
            {
           
            }
         if (peer->limit.pres.pres == PRSNT_NODEF)
         {	   
			   /* added sanity check */
               if(rxCb != NULLP)
                cmMemcpy ( (U8 *) &(rxCb->limit), (U8 *) &(peer->limit), 
                                 sizeof (MgMgcoPendingLimit)); 
         }

           /* Updating the peer with the values of 
            *  provRsptmr
            */
            mgGetProvRspTmrVal(mgcoTxn, peer);

#endif /*GCP_VER_1_5 GCP_PKG_MGCO_ROOT */           
#endif /*GCP_MG */           

            MG_UPD_MGCO_PEER_RX_STS(MGT_TXNREQ, peer->peerSts);

            if (rxCb == NULLP)
            {      

               /*
                * free the SDP Tkn Buf
                */
#ifdef CM_SDP_OPAQUE
               mgMgcoFreeAllTkBfs((mgcoMsg->body.u.tl.txns[loopIdx]));
#endif /* CM_SDP_OPAQUE */

               /*
                * added GCP_VER_1_3 flag for evnt struct freeing
                */
#ifdef GCP_VER_1_3
#ifdef GCP_CH
               mgChFreeCmds(mgcoMsg, loopIdx);
#endif /* GCP_CH  */
               mgFreeEventMem((Ptr) (*(mgcoMsg->body.u.tl.txns + loopIdx)));
#endif /* GCP_VER_1_3 */
               *(mgcoMsg->body.u.tl.txns + loopIdx) = NULLP;
               continue;
            } 
         }
         break;

         case MGT_TXNREPLY:
            rspType = MG_RESPONSE;

         case MGT_TXNPEND:
         {
            /* mg008.105:  these variables are never used */
            if (mgcoTxn->type.val == MGT_TXNPEND)
               rspType = MG_RESPONSE_PROV;

            /*
             * Needs to handle the Pending limit 
             * This is the place where we handle incomming 
             * txn pending response so we need to check the 
             * number here
             * Please go inside the mgPrcIncomingAck ().The 
             * location of this code can be changed after the
             * review and discussion. 
             * we are trying to do fetch on the oougoing hashlist
             * If we get an OK we need to check the pending limits
             * To be clarified ..  If we do a fetch , whether we
             * need to release it .????????
             */
            /*  Changed logic */
#if (defined(GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))
             cmHashListFind(&(peer->outTransLst), (U8 *)&transId, 
                           MG_TRANSID_LEN, MG_HASH_SEQNMB_DEF, 
                           (PTR *) &tmpTxCb);

            if(tmpTxCb) /*If we succeeds Fetch*/
            {
               if(tmpTxCb->limit.pres.pres != NOTPRSNT) 
               {
#ifdef GCP_MGC   
                  if (mgCb.genCfg.entType == LMG_ENT_GC)
                  {
                     if(tmpTxCb->limit.mgOriginatedPendingLimit)
                     {       
                        tmpTxCb->limit.mgOriginatedPendingLimit--;
                     }                  
                     else
                        limitExceeded = TRUE;
                  }
#endif /* GCP_MGC */          
#ifdef GCP_MG   
                  if (mgCb.genCfg.entType == LMG_ENT_GW)
                  {
                     if(tmpTxCb->limit.mgcOriginatedPendingLimit)
                     {       
                        tmpTxCb->limit.mgcOriginatedPendingLimit--;
                     }                  
                     else
                        limitExceeded = TRUE;
                  }
#endif /* GCP_MG */ 
                  if (limitExceeded == TRUE)
                  {   
#ifdef GCP_CH
                     /* Check if ssap is enabled for CH  */
                     if ((peer != NULLP) && 
                         (peer->ssap != NULLP) && 
                         (peer->ssap->ssapCfg.chEnabled == TRUE)) 
                     {
                        /* Send Limit Exceeded to the user */ 
                        cmMemset((U8 *) &chInd, 0, sizeof(MgMgcoInd)); 
                        chInd.transId.pres = PRSNT_NODEF;
                        chInd.transId.val = tmpTxCb->transId;
                        CH_SET_IND_ERRDESC(chInd, MGT_CH_ERR_PEND_LIMIT_EXCEEDED);
                        CH_CP_IND_PEERID(chInd, peer->accessInfo.peerId);
                        /* Send Transaction Pending to user */
                        mgChSendPrim ((Ptr)&chInd, peer, NULLP, CH_PRIM_TYPE_IND); 
                     }
#endif /* GCP_CH  */
                     mgAbortTxTrans(peer,tmpTxCb,MGT_ERR_INVALID_TRANS);
                     RETVALUE (RFAILED); /* Need to check whether this is correct */
                  }
               }
            }/*If fetch succeeds */

        /*
         * In case of a response or a pending message we need to 
         * stop the Mg/MgcProvisionalResponseTimer specified in the root
         * package
         */
         if (tmpTxCb)
           if(tmpTxCb->provRspRtTmr.tmrEvnt != TMR_NONE)   
              mgStopTmr(MG_PROV_RSP_ROOT_TMR,(PTR)tmpTxCb,&(tmpTxCb->provRspRtTmr));

#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */

            /* mg008.105:  the tmpTxCb that has gotten should be used */
            ret = mgPrcIncomingAck(&tmpTxCb, NULLP, srvr, peer, transId, rspType);
            
            if (ret!= ROK)
            {

               /*
                * free the SDP Tkn Buf
                */
#ifdef CM_SDP_OPAQUE
               mgMgcoFreeAllTkBfs((mgcoMsg->body.u.tl.txns[loopIdx]));
#endif /* CM_SDP_OPAQUE */

               /*
                * added GCP_VER_1_3 flag for evnt struct freeing
                */
#ifdef GCP_VER_1_3
#ifdef GCP_CH
               mgChFreeCmds(mgcoMsg, loopIdx);
#endif /* GCP_CH  */
               mgFreeEventMem((Ptr) (*(mgcoMsg->body.u.tl.txns + loopIdx)));
#endif /* GCP_VER_1_3 */
               *(mgcoMsg->body.u.tl.txns + loopIdx) = NULLP;
               continue;
            }
         }
         break;

         case MGT_TXNRSPACK:
         { 
            if ((mgcoTxn->u.rspAck.num.pres == NOTPRSNT) ||
                (mgcoTxn->u.rspAck.num.val == MG_NONE))
            {

               /*
                * free the SDP Tkn Buf
                */
#ifdef CM_SDP_OPAQUE
               mgMgcoFreeAllTkBfs((mgcoMsg->body.u.tl.txns[loopIdx]));
#endif /* CM_SDP_OPAQUE */

               /*
                * added GCP_VER_1_3 flag for evnt struct freeing
                */
#ifdef GCP_VER_1_3
#ifdef GCP_CH
               mgChFreeCmds(mgcoMsg, loopIdx);
#endif /* GCP_CH  */
               mgFreeEventMem((Ptr) (*(mgcoMsg->body.u.tl.txns + loopIdx)));
#endif /* GCP_VER_1_3 */
               *(mgcoMsg->body.u.tl.txns +loopIdx) = NULLP;
               mgcoTxn = NULLP;
               continue;
            }
               
            for (i=0; i< mgcoTxn->u.rspAck.num.val; i++)
            {
               if (mgcoTxn->u.rspAck.acks[0]->pres.pres == NOTPRSNT)
               continue;
               
               if (mgcoTxn->u.rspAck.acks[0]->last.pres == NOTPRSNT)
                  mgcoTxn->u.rspAck.acks[0]->last.val = 
                     mgcoTxn->u.rspAck.acks[0]->first.val;
               
           /*
            * change; Call func for all values from first
            * to last - 1.
            * Since j is of type U32, the for loop is run for one value
            * less than last.val to take care of case when last.val has
            * the value 0xffffffff to prevent wraparound and infinite loops.
            * If the type of j could have been U64, we could have removed
            * the func call statement after the for loop but not all
            * systems support U64. So this was not done.
            */
               for (j= mgcoTxn->u.rspAck.acks[0]->first.val; 
                    j < mgcoTxn->u.rspAck.acks[0]->last.val; j++)
               {
#ifdef ZG_DFTHA
                  /* If this is valid resource to handle this RspAck then only it
                  * should handle this else it should call PDLF function to route
                  * this RspAck to appropriate resource set */
                  if(zgChkNCRsetStatus(j, LMG_PROTOCOL_MGCO,
                        peer, (mgcoTxn->type.val), MG_TRANS_TYPE_RX, 
                        MG_INVALID_LSTNRID, NULLP, 0))
                  {
                     mgPrcRcvdResponseAck(peer, j);
                  }
                  else
                  {
                     zgPldfSendRspAck(j, LMG_PROTOCOL_MGCO,
                         peer->accessInfo.peerId);
                  }
#else
                  mgPrcRcvdResponseAck(peer, j);
#endif /* ZG_DFTHA */
               }

           /* 
            * In case last is absent then the for loop is not executed
            * and since last has been assigned the same value as first
            * the func call is made only once - desired behaviour.
            */
#ifdef ZG_DFTHA
                  /* If this is valid resource to handle this RspAck then only it
                  * should handle this else it should call PDLF function to route
                  * this RspAck to appropriate resource set */
                  if(zgChkNCRsetStatus(mgcoTxn->u.rspAck.acks[0]->last.val,
                                       LMG_PROTOCOL_MGCO, peer,
                                       (mgcoTxn->type.val), MG_TRANS_TYPE_RX, 
                                       MG_INVALID_LSTNRID, NULLP, 0))
                  {
                     mgPrcRcvdResponseAck(peer, mgcoTxn->u.rspAck.acks[0]->last.val);
                  }
                  else
                  {
                     zgPldfSendRspAck(mgcoTxn->u.rspAck.acks[0]->last.val,
                                      LMG_PROTOCOL_MGCO, peer->accessInfo.peerId);
                  }
#else
                  mgPrcRcvdResponseAck(peer, mgcoTxn->u.rspAck.acks[0]->last.val);
#endif /* ZG_DFTHA */

            }
         }
         break;
         default:

         /*
          * free the SDP Tkn Buf
          */
#ifdef CM_SDP_OPAQUE
         mgMgcoFreeAllTkBfs((mgcoMsg->body.u.tl.txns[loopIdx]));
#endif /* CM_SDP_OPAQUE */

         /*
          * added GCP_VER_1_3 flag for evnt struct freeing
          */
#ifdef GCP_VER_1_3
#ifdef GCP_CH
         mgChFreeCmds(mgcoMsg, loopIdx);
#endif /* GCP_CH  */
         mgFreeEventMem((Ptr) (*(mgcoMsg->body.u.tl.txns + loopIdx)));
#endif /* GCP_VER_1_3 */
         *(mgcoMsg->body.u.tl.txns +loopIdx) = NULLP;
         continue;
      } /* End of switch */
      if (MGT_TXNREPLY == mgcoTxn->type.val)
      {
         /* mg002.105: rspAckEnb is now reconfigurable */
#ifdef GCP_VER_1_3
         if (((PRSNT_NODEF == mgcoTxn->u.reply.immAck.pres) && 
               (TRUE != mgCb.genCfg.indicateRetx))||
               (mgCb.genCfg.reCfg.rspAckEnb & LMG_SEND_RSPACK_MGCO))
#else  
         if ((PRSNT_NODEF == mgcoTxn->u.reply.immAck.pres) && 
               (TRUE != mgCb.genCfg.indicateRetx))
#endif /* GCP_VER_1_3 */
         {
            /*
             *   as this point assoc is guaranteed to be valid;
             *   ServiceChange handling is done above
             */

            ret = mgSendTxnRspAck(peer,
#ifdef    GCP_PROV_SCTP
                                  assoc,
#endif    /* GCP_PROV_SCTP */
                                  srvr, transId);
         }
      }
   } /* End of for loop */
  
  RETVALUE(ROK);
} /* End of mgPrcMgcoMsg */




/*
*
*       Fun:   mgValidatePeer
*
*       Desc:  Validate Peer state i.e if message is valid for a 
*              particular peer state. For MGC validate peer type
*              active / standby to take care of redundant MG cfg.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE S16 mgValidatePeer
(
MgPeerCb           *peer,              /* Peer Control Block */
Bool               *peerTypeChkDone,   /* Peer type Check Completed / not */
Bool               *validPeerState     /* Peer State Check Completed / not */
)
#else
PRIVATE S16 mgValidatePeer(peer, peerTypeChkDone,validPeerState)
MgPeerCb           *peer;              /* Peer Control Block */
Bool               *peerTypeChkDone;   /* Peer type Check Completed / not */
Bool               *validPeerState;    /* Peer State Check Completed / not */
#endif
{
  S16              ret;                /* Return Value */

   TRC2(mgValidatePeer)
  
#ifdef GCP_MGC
   if ((mgCb.genCfg.entType == LMG_ENT_GC) &&
      (*peerTypeChkDone == FALSE))
   {    
      /* 
       * Check if peer from which the txn was received is the standby side.
       * If yes, interchange active & standby 
       */
      if ((ret = mgChkPeerType(peer)) != ROK)
         RETVALUE(RFAILED);
      *peerTypeChkDone = TRUE;
   }
#endif /* GCP_MGC */

  if (*validPeerState == FALSE)
  {
    /* Check if the peer is in a valid state to receive the message */
    ret = mgChkPeerState(peer);

    if (ret != ROK)
      RETVALUE(RFAILED);

    *validPeerState = TRUE;        
  }
  
  RETVALUE(ROK);

} /* End of mgValidatePeer */


/*
*
*       Fun:   mgChkIncSvcChgReq
*
*       Desc:  Check Incoming message to see if the first transaction 
*              in the message is a service change. If it is, special 
*              processing would need to be done.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE S16 mgChkIncSvcChgReq
(
MgMgcoTxn          *mgcoTxn,           /* MEGACO transaction */
MgSvcChgInfo       *svcChgInfo         /* Service Change Information */
)
#else
PRIVATE S16 mgChkIncSvcChgReq(mgcoTxn, svcChgInfo)
MgMgcoTxn          *mgcoTxn;           /* MEGACo transaction */
MgSvcChgInfo       *svcChgInfo;        /* Service Change Information */
#endif
{
   S16             ret;            /* Return Value */ 
   U8              method;         /* Service Change Method */

   /* 
    * On the MGC side we need to do special processing for a
    * service change message sent for registration. The
    * registration service change will always be the first 
    * txn in the message. So check for  this and jump into
    * function to complete special processing for the service
    * change 
    */
   
#ifdef GCP_MGC
   if (mgCb.genCfg.entType == LMG_ENT_GC)
   {
      method = MGT_NONE;
      ret = mgVerifySvcChg(mgcoTxn, &method);

      if ((ret == ROK) &&
          ((method != MGT_SVCCHGMETH_RESTART) &&
           (method != MGT_SVCCHGMETH_DISCON) &&
           (method != MGT_SVCCHGMETH_FAILOVER) &&
           (method != MGT_SVCCHGMETH_HANDOFF)))
      {
         ret = RFAILED;
      }
      else if (ret != ROK)
      {
         method = MGT_SVCCHGMETH_HANDOFF;
         ret = mgVerifySvcChg(mgcoTxn,&method);
      }
   } /* if MGC */
#endif /* GCP_MGC */


#ifdef GCP_MG

    /* 
     * If it is the MG side special processing is needed for a service
     * change response which comes in response to a previous registration
     * message 
     */

    if (mgCb.genCfg.entType == LMG_ENT_GW)
    {
       method = MGT_SVCCHGMETH_HANDOFF;
       ret = mgVerifySvcChg(mgcoTxn,&method);
    }
#endif /* GCP_MG */

    /* If message is service change */
    if (ret == ROK)
    {
       mgFillSvcChgInfo(MG_SRVC_CHG_REQ, mgcoTxn, svcChgInfo);
    }      

    RETVALUE(ret);

} /* End of mgChkIncSvcChgReq */


/*
*
*       Fun:   mgChkIncSvcChgRsp
*
*       Desc:  Check if the first transaction in a message is a service
*              change response.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE S16 mgChkIncSvcChgRsp
(
MgMgcoTxn          *mgcoTxn,           /* MEGACO transaction */
MgSvcChgInfo       *svcChgInfo         /* Service Change Information */
)
#else
PRIVATE S16 mgChkIncSvcChgRsp(mgcoTxn, svcChgInfo)
MgMgcoTxn          *mgcoTxn;           /* MEGACO transaction */
MgSvcChgInfo       *svcChgInfo;        /* Service Change Information */
#endif
{
   S16             ret;            /* return Value */
 
   TRC2(mgChkIncSvcChgRsp)

   /* Check if thefirts txn in the message is a service change response */
   ret = mgVerifySvcChgRsp(mgcoTxn, FALSE);
   
   /* If yes, fill service change info to be passed to the service change 
      processing function */      
   if (ret == ROK)
   {
      mgFillSvcChgInfo(MG_SRVC_CHG_REPLY, mgcoTxn, svcChgInfo);
   }

   RETVALUE(ret);

} /* End of mgChkIncSvcChgRsp */


/*
*
*       Fun:   mgChkPeerState
*
*       Desc:  This function checks peer is in a state to receive messages.
*              This check is only for message(txns) other than service change
*              (registration) messages. Registration messages are processed
*              separately.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE S16 mgChkPeerState
(
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PRIVATE S16 mgChkPeerState(peer)
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
   TRC2(mgChkPeerState)

   switch (peer->state)
   {
      case LMG_PEER_STATE_NULL:
      case LMG_PEER_STATE_RESOLVING:
      case LMG_PEER_STATE_AWAIT_REG:
      case LMG_PEER_STATE_CONNECT:
      case LMG_PEER_STATE_DISCONNECTED:
         RETVALUE(RFAILED);
      case LMG_PEER_STATE_REGISTER:
      {
#ifdef GCP_MGC
         if (mgCb.genCfg.entType == LMG_ENT_GC)            
            break;
#endif /* GCP_MGC */

         RETVALUE(RFAILED);
      }

      case LMG_PEER_STATE_UNDR_HNDOFF:
      {
#ifdef GCP_MG
         if (mgCb.genCfg.entType == LMG_ENT_GW)
            break;
#endif /* GCP_MG */
         RETVALUE(RFAILED);
      }

      case LMG_PEER_STATE_ACTIVE:
         break;

      default:
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* End of mgChkPeerState */


/* mg008.105: Passing one more parameter peer control block */
/*
*
*       Fun:   mgFillErrMsg
*
*       Desc:  Fill error message to send to peer . The error message
*              contains  responses to all the failed commands to be sent  
*              to the peer.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE S16 mgFillErrMsg
(
MgMgcoMsg          **errMsg,           /* Error Message */
MgMgcoTxn          *mgcoTxn,           /* Megaco Transaction*/
MgPeerCb           *peer               /* Peer Control block */
)
#else
PRIVATE S16 mgFillErrMsg(errMsg,  mgcoTxn, peer)
MgMgcoMsg          **errMsg;           /* Error Message */
MgMgcoTxn          *mgcoTxn;           /* Megaco Transaction*/
MgPeerCb           *peer;              /* Peer Control block */
#endif
{
   S16             ret;                /* return Value */
   U16             indx;               /* Counter */
   MgTransId       transId;            /* Transaction Id */

   TRC2(mgFillErrMsg)
  
   if (mgcoTxn != NULLP)
   {
      /* 
       * If error message has not been initialized yet (first error encountered).
       * Initialize the message 
       */
      if (*errMsg == NULLP)
      {
         ret = mgAllocEventMem((Ptr *)errMsg, sizeof(MgMgcoMsg)); 

         if (ret != ROK)
            RETVALUE(ret);
         else
            (*errMsg)->pres.pres = PRSNT_NODEF;

         (*errMsg)->ah.pres.pres = NOTPRSNT;
         (*errMsg)->ver.pres = PRSNT_NODEF;

         /* Use default version no if peer not available. */
         /*
          */
         if (NULLP != peer)
         {
            (*errMsg)->ver.val = peer->mgcoInfo.negotiatedVersion;
         }
   
         (*errMsg)->lcl.pres.pres = NOTPRSNT; 
         (*errMsg)->body.type.pres = PRSNT_NODEF;
         (*errMsg)->body.type.val = MGT_TXN;
         (*errMsg)->body.u.tl.num.pres = PRSNT_NODEF;
/* assign 1 to num.val */
         (*errMsg)->body.u.tl.num.val = 1;
      }
      else
         (*errMsg)->body.u.tl.num.val++;

      /* Fill Error Information in the Error Mesage */
      indx = (*errMsg)->body.u.tl.num.val - 1;

      MG_GET_TRANSID(mgcoTxn, transId);

      /*
       * added GCP_VER_1_3 flag and some code in the #else part
       */
#ifdef GCP_VER_1_3
      ret = mgAllocEventMem( (Ptr *)&(((*errMsg)->body.u.tl.txns)[indx]), 
                        sizeof(MgMgcoTxn) );
      if (ret != ROK)
      {
         (*errMsg)->body.u.tl.num.val--;
         MG_FREE_MGCO_EVNT_MEM((*errMsg), TRUE);
         RETVALUE(ret);
      }
#else
      MGGETMEM( (Ptr *)&((*errMsg)->body.u.tl.txns), sizeof(Ptr),
              &((*errMsg)->memCp), ret);
      if(ROK == ret)
      {
         MGGETMEM( (Ptr *)&(((*errMsg)->body.u.tl.txns)[indx]), 
                sizeof(MgMgcoTxn), &((*errMsg)->memCp), ret);
      }
      if(ROK != ret)
      {
         (*errMsg)->body.u.tl.num.val--;
         MG_FREE_MGCO_EVNT_MEM((*errMsg), TRUE);
         RETVALUE(ret);
      }
#endif /* GCP_VER_1_3 */

      ((*errMsg)->body.u.tl.txns)[indx]->type.pres = PRSNT_NODEF;
      ((*errMsg)->body.u.tl.txns)[indx]->type.val = MGT_TXNREPLY;
      ((*errMsg)->body.u.tl.txns)[indx]->u.reply.pres.pres = PRSNT_NODEF;
      ((*errMsg)->body.u.tl.txns)[indx]->u.reply.transId.pres = PRSNT_NODEF;
      ((*errMsg)->body.u.tl.txns)[indx]->u.reply.transId.val = transId;
      ((*errMsg)->body.u.tl.txns)[indx]->u.reply.type.pres = PRSNT_NODEF;
      ((*errMsg)->body.u.tl.txns)[indx]->u.reply.type.val = MGT_ERRDESC;
      ((*errMsg)->body.u.tl.txns)[indx]->u.reply.u.err.pres.pres = PRSNT_NODEF;
      ((*errMsg)->body.u.tl.txns)[indx]->u.reply.u.err.code.pres= PRSNT_NODEF;
      ((*errMsg)->body.u.tl.txns)[indx]->u.reply.u.err.code.val=
      MGT_MGCO_RSP_CODE_RSRC_ERROR;
   }
  
   RETVALUE(ROK);

} /* End of mgFillErrMsg */


/* added extra parameter trId under GCP_VER_1_3 flag */
/*
*
*       Fun:   mgMgcoSendErrRsp
*
*       Desc:  Send Error Response message to the peer. The error
*              response is sent for each incoming command for which
*              an error was encountered in processing.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoSendErrRsp
(
MgTSAPCb           *tsap,              /* TSAP CB */
#if ((defined (GCP_PROV_SCTP) || defined (GCP_PROV_MTP3)) && defined (GCP_VER_1_3))
MgcoTptInfo       *mgcoTptInfo, /* Megaco Transport Information */
#endif    /* (GCP_PROV_SCTP || GCP_PROV_MTP3) && GCP_VER_1_3 */
MgTptSrvr          *srvr,              /* Server Info */
CmTptAddr          *srcAddr,           /* Source Transport Address */
S16                rspCode,            /* Error Response Code */
MgMgcoMsg          *errMsg             /* Error Message */
#ifdef GCP_VER_1_3
,U32               trId                /* TransactionId */
#endif /* GCP_VER_1_3 */
)
#else
PUBLIC S16 mgMgcoSendErrRsp(tsap,
#if ((defined (GCP_PROV_SCTP) || defined (GCP_PROV_MTP3)) && defined (GCP_VER_1_3))
                            mgcoTptInfo,
#endif    /* (GCP_PROV_SCTP || GCP_PROV_MTP3) && GCP_VER_1_3 */
                            srvr, srcAddr, rspCode, errMsg
#ifdef GCP_VER_1_3
                            , trId
#endif /* GCP_VER_1_3 */
                           )
MgTSAPCb           *tsap;              /* TSAP CB */
#if ((defined (GCP_PROV_SCTP) || defined (GCP_PROV_MTP3)) && defined (GCP_VER_1_3))
MgcoTptInfo      *mgcoTptInfo; /* Megaco Transport Information */
#endif    /* (GCP_PROV_SCTP || GCP_PROV_MTP3) && GCP_VER_1_3 */
MgTptSrvr          *srvr;              /* Server Info */
CmTptAddr          *srcAddr;           /* Source Transport Address */
S16                rspCode;            /* Error Response Code */
MgMgcoMsg          *errMsg;            /* Error Message */
#ifdef GCP_VER_1_3
U32                trId;               /* TransactionId */
#endif /* GCP_VER_1_3 */
#endif
{
  MgSSAPCb         *ssap;              /* SSAP control Block */
  MgMgcoMsg        *msg;               /* MEGACo message */
  S16              ret;                /* Return Value */
  MgTptSrvr        *newSrvr;           /* Server Info */
  Buffer           *mBuf;              /* Message Buffer */
  Buffer           *hdrMBuf;           /* Buffer for Message Header */
  Buffer           *tmpTxnBuf;         /* Temp Buffer */
  CmAbnfErr        err;                /* ABNF Encoding Error */
  /*
   * PeerCb pointer required to obtain the version number information.
   */
  MgPeerCb         *peer;              /* Peer Control block */

#ifdef    GCP_PROV_SCTP
  TknU32           ctxId;              /* Integer type of Context-ID     */
  Bool             unorder;            /* SCTP - unordered delivery flag */
#endif    /* GCP_PROV_SCTP */
  /*MAH__TODO*/
  U8               encodingScheme;
  U32              protVar;
#ifdef   GCP_PROV_SCTP   
  MgAssocCb       *assoc = NULLP;     /* Association Control Block as passed in mgcoTptInfo */
#endif   /* GCP_PROV_SCTP */
#ifdef   GCP_PROV_MTP3
   Dpc             peerDpc = NULLD;     /* Peer DPC as passed in MgcoTptInfo */
#endif   /* GCP_PROV_MTP3 */




  TRC2(mgMgcoSendErrRsp)

  newSrvr = NULLP;
  mBuf    = NULLP;
  hdrMBuf = NULLP;

  /*
   * Obtain the peer pointer and ssap poiter to be used later in this function
   * Then obtain self info  from the SSAP 
   */
  peer    = NULLP;
  ssap    = NULLP;
   /* 
    * Code added to pass multiple trasport parameter and then make each 
    * transport available in an
    * local copy of its transport variable 
    */
#if   (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
   if(mgcoTptInfo != NULLP)
   {
#ifdef   GCP_PROV_SCTP      
      if(mgcoTptInfo->tptType == LMG_TPT_SCTP)
         assoc = mgcoTptInfo->u.assocCb;
#endif   /* GCP_PROV_SCTP */
#ifdef  GCP_PROV_MTP3         
      if  (mgcoTptInfo->tptType == LMG_TPT_MTP3) 
         peerDpc  = mgcoTptInfo->u.mgMtpInfo.clgAddr;
         
#endif   /* GCP_PROV_MTP3 */    
   }        /* Do Not Remove This Brace */
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */


#ifdef    GCP_PROV_MTP3
   if ((mgcoTptInfo !=NULLP) && (mgcoTptInfo->tptType == LMG_TPT_MTP3)
         && peerDpc) 
  {
      peer = mgcoTptInfo->u.mgMtpInfo.mtpPeer;
      if(peer != NULLP)
      ssap = peer->ssap;
  }
  else
#endif   /* GCP_PROV_MTP3 */  
#ifdef    GCP_PROV_SCTP
  if (assoc)
  {
      peer = assoc->peer;
      ssap = peer->ssap;
  } 
  else  /* don't remove this comment */
#endif    /* GCP_PROV_SCTP */
  if (MG_TCP_CLIENT_CONNECTION == srvr->srvrType)
  {
      peer = srvr->t.peer;
      ssap = peer->ssap;
  }
  else  /* UDP connection */
  {
     ssap = srvr->t.ssap;
     /* 
      * Peer cant be found since MID of peer is not available. Use 
      * default version no. Delete the call to mgGetPeer. 
      */
  }

  if(NULLP == ssap)
     RETVALUE(RFAILED);
#if (defined GCP_PROV_SCTP)|| (defined GCP_PROV_MTP3)
  if(mgcoTptInfo)
  {
   encodingScheme = mgcoTptInfo->encodingScheme;
  } 
#endif

   /*MAH_TODO*/
   if(srvr)
     encodingScheme = srvr->encodingScheme;
   /* If no error message has been created yet create it now */
   if (errMsg == NULLP)
   {
      ret = mgAllocEventMem((Ptr *)&msg, sizeof(MgMgcoMsg)); 
      
      if (ret != ROK)
         RETVALUE(ret);
      else   /* Initilized pres field of mgcoMsg */
         msg->pres.pres = PRSNT_NODEF;
      
      /*
       * Add filling of mandatory parameters in the error message being
       * filled, so that the encoding of error message dos not fail.
       */
      msg->pres.pres = PRSNT_NODEF;
      msg->ah.pres.pres = NOTPRSNT;
      msg->ver.pres = PRSNT_NODEF;

      /* Use default version no if peer not available. */
      /*
       */
      if (NULLP == peer)
      {
         msg->ver.val = ssap->ssapCfg.maxMgcoVersion;
      }
      else
      {
         msg->ver.val = peer->mgcoInfo.negotiatedVersion;
         
      }
       /*
       ** Here we are checking for the maximum version .If version is 2 we support 
        *V2.else v2.Because there are the only two versions supported currently by the stack
        */
#ifdef GCP_VER_1_5
      if (msg->ver.val == 2)
      {
        protVar      = CM_ABNF_PROT_MEGACO_H248_V2;
      } 
      else
#endif /* GCP_VER_1_5 */
      {
        protVar      = CM_ABNF_PROT_MEGACO_H248;
      }

      msg->lcl.pres.pres = NOTPRSNT;

#ifdef    GCP_PROV_SCTP
      /* by default send msg with high priority */
      msg->unorder = FALSE;
#endif    /* GCP_PROV_SCTP */

      msg->body.type.pres = PRSNT_NODEF;
#ifdef GCP_VER_1_3
      /* send error descriptor in tranaction reply. Fill transaction id as NULL
      * */
      msg->body.type.val = MGT_TXN;
      msg->body.u.tl.num.pres = PRSNT_NODEF;
      msg->body.u.tl.num.val = 1;
      if(RFAILED == mgAllocEventMem((Ptr *) &(msg->body.u.tl.txns[0]), 
                        sizeof(MgMgcoTxn )))
      {
         MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
         RETVALUE(RFAILED);
      }
      msg->body.u.tl.txns[0]->type.pres = PRSNT_NODEF;
      msg->body.u.tl.txns[0]->type.val = MGT_TXNREPLY;
      msg->body.u.tl.txns[0]->u.reply.pres.pres = PRSNT_NODEF;
      msg->body.u.tl.txns[0]->u.reply.transId.pres = PRSNT_NODEF;
      /* using trId rather than simply MGT_TXNID_NULL */
      msg->body.u.tl.txns[0]->u.reply.transId.val = trId;
      msg->body.u.tl.txns[0]->u.reply.immAck.pres = NOTPRSNT;
      msg->body.u.tl.txns[0]->u.reply.type.pres = PRSNT_NODEF;
      msg->body.u.tl.txns[0]->u.reply.type.val = MGT_ERRDESC;
      msg->body.u.tl.txns[0]->u.reply.u.err.pres.pres = PRSNT_NODEF;
      msg->body.u.tl.txns[0]->u.reply.u.err.code.pres = PRSNT_NODEF;
      msg->body.u.tl.txns[0]->u.reply.u.err.code.val = rspCode;
#else
      msg->body.type.val = MGT_ERRDESC;
      msg->body.u.err.pres.pres = PRSNT_NODEF;
      msg->body.u.err.code.pres = PRSNT_NODEF;
      msg->body.u.err.code.val = rspCode;    
#endif /* GCP_VER_1_3 */
   }
   /* Else, error message already allocated so get old message */
   else
   {
      msg = errMsg;
   }      

   /* Deleted call to mgCnvrtPeerInfoToMId() */
   /* Fill MID info in message to be sent out*/
   MG_FILL_MID_IN_MSG(msg->mid, ssap->ssapCfg.userInfo.mid, ret, &(msg->memCp));
   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
      RETVALUE(ret);
   }

   /* Get Server For Transmission of Error Descriptor */
   if ((srvr) && (srvr->srvrType == MG_TCP_CLIENT_CONNECTION))
   {
      newSrvr = srvr;
   }
   else
   {
#ifdef GCP_MG
      if (mgCb.genCfg.entType == LMG_ENT_GW)
      {
         if ((newSrvr = ssap->nxtUseMgcoSrvr) != NULLP)
         {
            ssap->nxtUseMgcoSrvr = mgGetLstnrForTx(ssap, tsap,
                                                   LMG_PROTOCOL_MGCO);
         }
      }
#endif /* GCP_MG */

      if (newSrvr == NULLP)
      {
        if ((srvr) && (newSrvr = tsap->nxtUseMgcoSrvr) != NULLP)
             tsap->nxtUseMgcoSrvr = 
                           mgGetLstnrForTx(NULLP, tsap,
                                           LMG_PROTOCOL_MGCO);
      } /* if srvr is NULLP */
  } 

   /* If no server is found abort attempt */
   if(            /* Do not Remove this statement */
#ifdef   GCP_PROV_MTP3
   (peerDpc == NULLD) && 
#endif   /* GCP_PROV_MTP3 */   
#ifdef    GCP_PROV_SCTP
   (assoc == NULLP) && 
#endif    /* GCP_PROV_SCTP */
   (newSrvr == NULLP))
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
      RETVALUE(RFAILED);
   }
   /* Changed code */
   /* Encode Transaction; Get mBuf to transmit & Header buffer */
   ret = mgGetMgcoMsgBuf(&mBuf, tsap, &hdrMBuf, msg
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
                         ,encodingScheme                 
#endif
                         ,protVar
                         );
   if (ret != MGT_NONE)
   {
      MG_CLEAR_MEM(mBuf, hdrMBuf);      
      if (ret == MGT_ERR_RSRC_UNAVAIL)
      {

         MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                tsap->tsapCfg.memId.region,
                                tsap->tsapCfg.memId.pool);

      }
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
      RETVALUE(RFAILED);
   }

   /* Get Buffer to store txn information */
   if (mgGetMsg(tsap->tsapCfg.memId.region, 
                tsap->tsapCfg.memId.pool,
                &tmpTxnBuf) != ROK)
   {
      MG_CLEAR_MEM(mBuf, hdrMBuf);      
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
      RETVALUE(RFAILED);
   }
   

#ifdef    GCP_PROV_SCTP
   /*
    * call the following function to find out the context Id
    * used by the first transaction in the MEGACO message
    */
   mgExtractCtxIdFrmMsg(msg, &ctxId);
   unorder = msg->unorder;
#endif    /* GCP_PROV_SCTP */

   /*  Using peer scheme instead of server scheme */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
   if (encodingScheme == LMG_ENCODE_TXT)
   {
#endif
#ifdef GCP_VER_1_3
      /* Encode Buffer & Transmit */
      ret = cmAbnfEncPduMsg(protVar,(U8 *)&(msg->body.u.tl.txns[0]->type),
                           tmpTxnBuf, &mgMgcoTxnDef, 
                           &(tsap->tsapCfg.memId),
                            &err);
#else
  /* Encode Buffer & Transmit */
      ret = cmAbnfEncPduMsg(protVar, (U8 *)&(msg->body.u.err),
                            tmpTxnBuf, &mgMgcoErrDescDef, 
                            &(tsap->tsapCfg.memId),
                            &err);
#endif 
   
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 

   }
   else if (encodingScheme  == LMG_ENCODE_BIN)
   {

#ifdef GCP_VER_1_3
   /* Encode Buffer & Transmit */
   ret = mgEncPduMsg(protVar , (U8 *)msg, 0,
                        tmpTxnBuf, MGED_TXN_ENC, 
                        &(tsap->tsapCfg.memId),
                        &err);
#else

   ret = mgEncPduMsg(protVar, (U8 *)msg, 0,
                        tmpTxnBuf, MGED_ERRDESC, 
                        &(tsap->tsapCfg.memId),
                        &err);
   
   
#endif  /* GCP_VER_1_3 */

   }
   else
      ret = RFAILED;
#endif /* GCP_VER_1_5 GCP_ASN */

   if (ret != ROK)
   {
      /* mg003.105: Add - Added sanity check */
      if (tmpTxnBuf != NULLP)
         mgPutMsg(tmpTxnBuf);
      MG_CLEAR_MEM(mBuf, hdrMBuf); 
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
      RETVALUE(RFAILED);
   }

   /* Concat transaction to the mBuf to be transmitted */
   if ((SCatMsg(mBuf, tmpTxnBuf, M1M2)) != ROK)
   {
      MG_CLEAR_MEM(mBuf, hdrMBuf);
      if (tmpTxnBuf != NULLP)
        mgPutMsg(tmpTxnBuf);
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
      RETVALUE(RFAILED);
   }
 
   
   if (tmpTxnBuf != NULLP)
      mgPutMsg(tmpTxnBuf);
   if (hdrMBuf != NULLP)
      mgPutMsg(hdrMBuf);
#ifdef GCP_ASN
   /* last minute prep *//*MAH_TODO*/
   if (encodingScheme == LMG_ENCODE_BIN)
   {
      if (mgPrepSend(protVar, mBuf, (CmMemListCp *)(msg)) != ROK)
      {
         MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
         RETVALUE(RFAILED);
      }
   }
#endif
   if(errMsg == NULLP)
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);

#ifdef    GCP_PROV_MTP3
   /*
    * Donot confuse with called address as Destination point code
    * as it is opc in our case since these field are significant when we 
    * receive incoming Txn Ind from MTP3 so called address is our point code
    * in that situation
   */
   if((peerDpc) && (peer->tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3))
      mgMtpDatReq(mgcoTptInfo->u.mgMtpInfo.mtpPeer,peerDpc,
                 mgcoTptInfo->u.mgMtpInfo.cldAddr,peer->tsap,mBuf);
    else
#endif    /* GCP_PROV_MTP3 */



   /* Transmit the buffer */
   if (newSrvr)
      mgSrvDatReq(newSrvr, srcAddr, mBuf);

#ifdef    GCP_PROV_SCTP
   else
   {
      CmNetAddr  tmpNetAddr;
      SctStrmId  strm;


      MG_MGCO_GET_STRMID_FRM_CTXID(strm, (&ctxId), assoc);

      tmpNetAddr.type = CM_NETADDR_NOTPRSNT;

      MgLiSctDatReq(&(assoc->tsap->spPst), assoc->tsap->tsapCfg.spId,
                    assoc->spAssocId, &tmpNetAddr, strm,
                    unorder, FALSE, 0, SCT_PROTID_H248, mBuf);
   }
#endif    /* GCP_PROV_SCTP */
    
   RETVALUE(ROK);
   
} /* End of mgMgcoSendErrRsp */



/*
*
*       Fun:   mgSendMgcoTxnPend
*
*       Desc:  Send out a transaction pending message to the peer 
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16  mgSendMgcoTxnPend
(
MgRxTransIdEnt     *rxCb               /* Queued Acknowledgement */
)
#else
PUBLIC S16 mgSendMgcoTxnPend(rxCb)
MgRxTransIdEnt     *rxCb;              /* Queued Acknowledgement */
#endif
{
   S16             ret;                /* Return Value */
   U8              idx;                /* Index */
   MgMgcoMsg       *msg;               /* Transaction Pending Message */
   MgMgcoMsg       *errMsg;
   MgPeerCb        *peer;              /* Peer Control Block */
   MgMgcoTxn       *mgcoTxn;           /* MEGACO Txn */
   MgTptSrvr       *srvr;              /* Local Socket for Transmission */
   Buffer          *mBuf;              /* Message Buffer */
   Buffer          *newMbuf;           /* Message Buffer */
   Buffer          *hdrMBuf;           /* Header Message Buffer */
   MgTSAPCb        *tsap;              /* TSAP Control Block */
   CmAbnfErr       err;                /* Encode Error Structure */
   U32             protVar;
#ifdef GCP_VER_1_5
   /*mg002.105: Removed compilation warning*/
   Bool            flag = FALSE;       /* Boolean Flag */
#ifdef GCP_CH
   MgMgcoInd       chInd;              /* CH Indication                      */
   /* [UG] */
   MgMgcoChCb             *chCb = &(mgCb.chCb);   /* CH Control BLock   */
   MgMgcoChPeerCmdCtl     *peerCmdCtl = NULLP;    /* Peer Cmd Control   */
   MgMgcoChTransIndRsp    *trIndRsp = NULLP;      /* Trans Ind Rsp      */ 
   MgMgcoChAxnIndRsp      *axnIndRsp = NULLP;     /* Action Ind Rsp     */
   MgMgcoTransId          transId;        /* Transaction Id     */
   Bool                   optPres = FALSE;         /* option flag       */
#endif
#ifdef GCP_PKG_MGCO_ROOT
   Bool            limitExceeded;      /* Pending Limit Exceeded /not */
#endif
#endif
#if (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))   
MgcoTptInfo      mgcoTptInfo; /* Megaco Transport Information */
#endif   /* GCP_PROV_MTP3 || GCP_PROV_SCTP */


   TRC2(mgSendMgcoTxnPend)
   peer = rxCb->peer;

#ifdef GCP_PROV_SCTP   
   if (peer->accessInfo.transportType == LMG_TPT_SCTP)
   {/* Copy the Trasport Inforamtion in a Structure to be passed to function */
     mgcoTptInfo.tptType   = LMG_TPT_SCTP;
     mgcoTptInfo.u.assocCb = peer->assocCb;
   }
#endif /* GCP_PROV_SCTP */
#ifdef GCP_PROV_MTP3   
   if (peer->accessInfo.transportType == LMG_TPT_MTP3)
   {
     /* Copy all MTP information in a structure and pass it to TxnInd
       * function 
       */
     mgcoTptInfo.tptType               = LMG_TPT_MTP3;
     mgcoTptInfo.u.mgMtpInfo.mtpPeer   = peer;
     mgcoTptInfo.u.mgMtpInfo.clgAddr   = peer->mgcoMtpCb.peerDpc;
     mgcoTptInfo.u.mgMtpInfo.cldAddr   = peer->ssap->ssapCfg.userInfo.selfPc.val; /*This should be our Address */
   }
#endif /* GCP_PROV_MTP3 */

   srvr = NULLP;
   mBuf = NULLP;
   hdrMBuf = NULLP;
   errMsg = NULLP;

#ifdef GCP_VER_1_5
#ifdef GCP_CH
   cmMemset((U8 *)&chInd, 0, sizeof(MgMgcoInd)); 
#endif
#ifdef GCP_PKG_MGCO_ROOT
   limitExceeded = FALSE;
#endif
#endif

   /* taking the negotiated version from the peer */
#ifdef GCP_VER_1_5
   if (peer->mgcoInfo.negotiatedVersion == 2)
   {
     protVar = CM_ABNF_PROT_MEGACO_H248_V2;
   } 
   else
#endif /* GCP_VER_1_5 */
   {
     protVar = CM_ABNF_PROT_MEGACO_H248;
   } 
     
     
   tsap = peer->tsap;                  /* peer should be valid */

   /* Get Server on which the message is to be sent */
   if (
#ifdef    GCP_PROV_MTP3
       (NULLD == peer->mgcoMtpCb.peerDpc) &&
#endif   /* GCP_PROV_MTP3 */
#ifdef    GCP_PROV_SCTP
       (NULLP == peer->assocCb) &&
#endif    /* GCP_PROV_SCTP */
       ((srvr = mgGetSendSrvr(peer->ssap, peer)) == NULLP))
   {
      RETVALUE(RFAILED);
   }
      /* Processing of txn pending at sending side for txn pending */
      /*  Logic was incorrect changed it */
  
#if (defined (GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT)) 
      if(rxCb->limit.pres.pres) /*whether to change to a simple one */
      {
#ifdef GCP_MGC
         if (mgCb.genCfg.entType == LMG_ENT_GC)
         {
            if (rxCb->limit.mgcOriginatedPendingLimit)
            {
               rxCb->limit.mgcOriginatedPendingLimit--;
            }
            else
               limitExceeded = TRUE;
         }
#endif

#ifdef MG
         if (mgCb.genCfg.entType == LMG_ENT_GW)
         {

            if (rxCb->limit.mgOriginatedPendingLimit)
            {     
               rxCb->limit.mgOriginatedPendingLimit--;
            }
            else
               limitExceeded = TRUE;
         }

#endif     
         if (limitExceeded == TRUE)
         {
       /*
        * Now you reached here .This means the number of pending
         limits have crossed .Now,
         1)Send an error response 
         3)Stop the timer
         4)CleanUp rxCb
        */
   
      
      /*Sending an Error response */

#ifdef GCP_CH
            /* Check if ssap is enabled for CH  */
            if ((peer != NULLP) && 
                  (peer->ssap != NULLP) && 
                  (peer->ssap->ssapCfg.chEnabled == TRUE)) 
            {
               /* Send Response time out to the user */ 
               /* cmMemset((U8 *) &chInd, 0, sizeof(MgMgcoInd));  */
               /* chInd.transId.pres = PRSNT_NODEF; */
               /* chInd.transId.val = rxCb->transId; */
               /* CH_SET_IND_ERRDESC(chInd, MGT_CH_ERR_CMD_RSP_TMD_OUT); */
               /* CH_CP_IND_PEERID(chInd, peer->accessInfo.peerId); */
               /* Send Transaction Pending to user */
               /* mgChSendPrim ((Ptr)&chInd, peer, NULLP, CH_PRIM_TYPE_IND);  */
               mgChHndlRspTimeOut(rxCb->transId,peer->accessInfo.peerId);
               RETVALUE(ROK);
            }
#endif /* GCP_CH  */
            
      /* mg007.105: added code to retrieve error statistics */
      MG_UPD_MGCO_PEER_ERROR_STS(MGT_MGCO_RSP_CODE_TXNPENDING_EXCEEDED, TRUE, peer, NULLP);

#ifdef GCP_VER_1_3
      
      mgMgcoSendErrRsp(tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                       & mgcoTptInfo,
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
                       srvr, 
                       &rxCb->tptAddr,
                       MGT_MGCO_RSP_CODE_TXNPENDING_EXCEEDED,
                       errMsg,
                       rxCb->transId);
#else
      mgMgcoSendErrRsp(srvr,
                       &rxCb->tptAddr,
                       MGT_MGCO_RSP_CODE_TXNPENDING_EXCEEDED,
                       errMsg);
#endif /* GCP_VER_1_3 */
      /*Cleaning up the rxCb */
      mgDeAllocRxTransIdEnt(peer, rxCb, TRUE);

#ifdef GCP_VER_1_5            
            flag = TRUE;
#endif
            RETVALUE(ROK);
         } /* Limit Exceeded */
      }
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */


   if ((rxCb->mBuf != NULLP) && (rxCb->rspStatus == MG_RESPONSE_PROV))
   {
      mBuf = rxCb->mBuf;
   }
   else
   {
      ret = mgAllocEventMem((Ptr *)&msg, sizeof(MgMgcoMsg)); 

      if (ret != ROK)
         RETVALUE(ret);
      else   /* Initilized pres field of mgcoMsg */
         msg->pres.pres = PRSNT_NODEF;

      msg->ver.pres = PRSNT_NODEF;
      msg->ver.val = peer->mgcoInfo.negotiatedVersion;

      MG_FILL_MID_IN_MSG(msg->mid, peer->ssap->ssapCfg.userInfo.mid, 
                 ret, &(msg->memCp));
      if (ret != ROK)
      {
         MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
         RETVALUE(ret);
      }
      
      msg->body.type.pres = PRSNT_NODEF;
      msg->body.type.val = MGT_TXN;
      msg->body.u.tl.num.pres = PRSNT_NODEF;
      msg->body.u.tl.num.val = 1;
      
#ifdef GCP_VER_1_3   
      mgcoTxn = msg->body.u.tl.txns[0];
      if(ROK != mgAllocEventMem((Ptr *)&mgcoTxn, sizeof(MgMgcoTxn)))
      {
         mgFreeEventMem(msg);
         RETVALUE(RFAILED);
      }
      msg->body.u.tl.txns[0] = mgcoTxn;
#else
      MGGETMEM((Ptr *)&(msg->body.u.tl.txns), sizeof(Ptr), (Ptr)msg, ret);
      if (ret != ROK)
      {
         MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
         RETVALUE(ret);
      }
      MGGETMEM((Ptr *)&(msg->body.u.tl.txns[0]), sizeof(MgMgcoTxn), 
               (Ptr)msg, ret);
      if (ret != ROK)
      {
         MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
         RETVALUE(ret);
      }
      mgcoTxn  = ((msg->body.u.tl.txns)[0]);
#endif /* GCP_VER_1_3 */
      
      mgcoTxn->type.pres           = PRSNT_NODEF;
      mgcoTxn->type.val            = MGT_TXNPEND;
      mgcoTxn->u.pend.pres.pres    = PRSNT_NODEF;
      mgcoTxn->u.pend.transId.pres = PRSNT_NODEF;
      mgcoTxn->u.pend.transId.val  = rxCb->transId;

      /* Get Buffer to store header information */
      if (mgGetMsg(tsap->tsapCfg.memId.region, tsap->tsapCfg.memId.pool,
                  &hdrMBuf) != ROK)
      {
         MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
         RETVALUE(RFAILED);
      }


#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 

   if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_TXT)
   {
#endif /* GCP_VER_1_5 GCP_ASN */
 
      /* Encode MGCO Header */
      ret = cmAbnfEncPduMsg(protVar , (U8 *)&(msg->ver),
                           hdrMBuf, &mgMgcoMsgHdrDef, 
                           &(tsap->tsapCfg.memId),
                            &err);
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
   }
   else if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
   {
       /* Encode Buffer & Transmit */
       /* Need to fix in the apropriate params once proto type is ready  */
      ret = mgEncPduMsg(protVar , (U8 *)msg, 0,
                        hdrMBuf, MGED_HDR_ENC, 
                        &(tsap->tsapCfg.memId),
                        &err);

   }
   else
      ret = RFAILED;
#endif

   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
      if (hdrMBuf != NULLP)
         mgPutMsg(hdrMBuf);
      RETVALUE(RFAILED);
   }

   if (mgGetMsg(tsap->tsapCfg.memId.region, 
                tsap->tsapCfg.memId.pool,
                &(mBuf)) != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
      if (hdrMBuf != NULLP)
         mgPutMsg(hdrMBuf);
      RETVALUE(RFAILED);
   }

#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 

   if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_TXT)
   {

#endif /* GCP_VER_1_5 GCP_ASN */
      /* Encode Transaction */
      ret = cmAbnfEncPduMsg(protVar , (U8 *)&(mgcoTxn->type), mBuf, 
                           &mgMgcoTxnDef,&(tsap->tsapCfg.memId) , 
                            &err);

#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
   }
   else if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
   {
       /* Encode Buffer & Transmit */
       /* Need to fix in the apropriate params once proto type is ready  */
      ret =mgEncPduMsg(protVar , (U8 *)msg, 0, mBuf, 
                           MGED_TXN_ENC,&(tsap->tsapCfg.memId) , 
                           &err);
   }
   else
      ret = RFAILED;
#endif

      if (ret != ROK)
      {
         MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
         if (hdrMBuf != NULLP)
            mgPutMsg(hdrMBuf);
         if (mBuf != NULLP)
            mgPutMsg(mBuf);
         RETVALUE(RFAILED);
      }
   
      /* 
       * Concat Header to txn buffer to store in the transaction 
       * control block 
       */
      if ((SCatMsg(mBuf, hdrMBuf, M2M1)) != ROK)
      {
         MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
         if (hdrMBuf != NULLP)
            mgPutMsg(hdrMBuf);
         if (mBuf != NULLP)
            mgPutMsg(mBuf);
         RETVALUE(MGT_ERR_RSRC_UNAVAIL);
      }

#ifdef GCP_ASN
      /* last minute prep */
   if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
   {
      if (mgPrepSend(protVar , mBuf, (CmMemListCp *)(msg)) != ROK)
      {
         MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
         if (hdrMBuf != NULLP)
            mgPutMsg(hdrMBuf);
         if (mBuf != NULLP)
            mgPutMsg(mBuf);
         RETVALUE(RFAILED);
      }
   }
#endif
      rxCb->mBuf       = mBuf;
      rxCb->state      = MG_INTXN_PROVRSP_SENT;
      rxCb->rspStatus  = MG_RESPONSE_PROV;

      /* Free Allocated Resources */
      if (hdrMBuf != NULLP)
         mgPutMsg(hdrMBuf);
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
   }


   /* Add message Reference */
   if ((SAddMsgRef (mBuf, tsap->tsapCfg.memId.region, 
                    tsap->tsapCfg.memId.pool, &(newMbuf))) != ROK)
   {
      if (peer->ssap->ssapCfg.reCfg.provRspTmr.enb != TRUE)
      {
         if (rxCb->mBuf != NULLP)
            mgPutMsg(rxCb->mBuf);

         rxCb->mBuf       = NULLP;
         rxCb->state      = MG_INTXN_TXN_RCVD;
         rxCb->rspStatus  = MG_NONE;
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
         zgRtUpd(ZG_CBTYPE_TXN_RX,(Ptr)rxCb,CMPFTHA_UPDTYPE_NORMAL,CMPFTHA_ACTN_MOD);
#endif /* ZG */
#endif /* ZG_TXN_LVL_UPD */
      }

      RETVALUE(RFAILED);
   }

   idx = MG_PROVRSP_TMR - MG_INTXN_TMR_BASE;

   /* If timer is still enabled start it again */
   if (peer->ssap->ssapCfg.reCfg.provRspTmr.enb == TRUE)
   {
      mgStartTmr(MG_PROVRSP_TMR, peer->ssap->ssapCfg.reCfg.provRspTmr.val,
                (PTR)rxCb, &(rxCb->tmr[idx]));
   }
   else
   {
      /*
       * Coming here implies that SSAP has been reconfigured with provisional
       * response as disabled, implying that GCP will no longer generate
       * provisional responses and if a retransmission is received, it will
       * be passed to Service User and he may choose to send provisional 
       * responses
       */
      rxCb->mBuf = NULLP;
      if (mBuf != NULLP)
         mgPutMsg(mBuf);

      /* Reset rxCb States as if we have just received txn from peer */
#ifdef GCP_VER_1_5            
     if(TRUE == flag)
      {         
        rxCb->state      =MG_INTXN_RSP_SENT;
      }
      else
      {         
#endif
        rxCb->state      = MG_INTXN_TXN_RCVD;
#ifdef GCP_VER_1_5
      }   
#endif
 
      rxCb->rspStatus  = MG_NONE;
   }
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
   zgRtUpd(ZG_CBTYPE_TXN_RX,(Ptr)rxCb,CMPFTHA_UPDTYPE_NORMAL,CMPFTHA_ACTN_MOD);
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */

   /* Transmit the buffer */
#ifdef    GCP_PROV_MTP3
   /*
    * Donot confuse with called address as Destination point code
    * as it is opc in our case since these field are significant when we 
    * receive incoming Txn Ind from MTP3 so called address is our point code
    * in that situation
   */
   if((peer->mgcoMtpCb.peerDpc) && (tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3))
      mgMtpDatReq(peer, NULLD, NULLD, tsap, newMbuf);
                 
    else
#endif    /* GCP_PROV_MTP3 */


#ifdef    GCP_PROV_SCTP
   if (peer->assocCb)
   {
      TknU32      ctxId;
      SctStrmId   strm;

      /*mg002.105: Removed compilation warning*/
      ctxId.pres = NOTPRSNT;      /* Context-ID is ABSENT in transPend */
      ctxId.val    = 0;

      MG_MGCO_GET_STRMID_FRM_CTXID(strm,(&ctxId),peer->assocCb);

      /*
       * Use unordered delivery for sending Pending msg so
       * that there is a greater chance of its timely delivery
       */
      MG_TRANSMIT_PDU(peer, peer->assocCb, strm, TRUE, srvr,
                      &(rxCb->tptAddr), newMbuf);
   }
   else   /* do NOT delete this comment */
#endif    /* GCP_PROV_SCTP */
      mgSrvDatReq(srvr, &(rxCb->tptAddr), newMbuf);

#if (defined(GCP_CH) && defined(GCP_VER_1_5))
 
   if (peer->ssap->ssapCfg.chEnabled == TRUE) 
   {
      /* mg002.105: Adding for Optional command handling */
      /* Peer Cmd List is already initialised in mgInit function  */
      /* if ((cmHashListFind(&(chCb->peerCmdCtlLst), (U8 *)&chCmdRsp->peerId.val,  */
                            /* MG_CH_PEERID_LEN, MG_HASH_SEQNMB_DEF,  */
                            /* (PTR *)&peerCmdCtl)) == ROK)  */
      if ((cmHashListFind(&(chCb->peerCmdCtlLst), (U8 *)&peer->accessInfo.peerId, 
                            MG_CH_PEERID_LEN, MG_HASH_SEQNMB_DEF, 
                            (PTR *)&peerCmdCtl)) == ROK) 
      {
         /* Peer Found, Check for Trans IndRsp List */
         if ((cmHashListFind(&(peerCmdCtl->transIndRspLst), (U8 *)&rxCb->transId, MG_TRANSID_LEN,
                          MG_HASH_SEQNMB_DEF, (PTR *)&trIndRsp)) == ROK)
         {
            axnIndRsp = trIndRsp->axnIndRsp[trIndRsp->curActionId];
            /* 14th March -Geetha : Only if the action has commands */
            if (axnIndRsp->cmdIndInfo != NULLP)
            {
               if (axnIndRsp->cmdIndInfo[axnIndRsp->curCmdIndId]->opt.pres == PRSNT_NODEF)
               {
                  optPres = TRUE;
               }
            }
         }
      }

      if (TRUE == optPres)
      {
         if ((trIndRsp->curActionId != trIndRsp->numOfIndRspAxns -1) ||
              (axnIndRsp->curCmdIndId != axnIndRsp->numOfCmdInds - 1))
         {
            /* Some command indications need to be sent */
            transId.pres = PRSNT_NODEF;
            transId.val = rxCb->transId;
            mgChSendNextCmd (trIndRsp, axnIndRsp, transId, peer->accessInfo.peerId);
         }
      } 
/* mg002.105: End of additions for optional command handling */

      else {
      /* Send Txn Pending Indication to user */
      cmMemset((U8 *) &chInd, 0, sizeof(MgMgcoInd)); 
      chInd.transId.pres = PRSNT_NODEF;
      chInd.transId.val = rxCb->transId;
      CH_SET_IND_TXN_PEND(chInd);
      CH_CP_IND_PEERID(chInd, peer->accessInfo.peerId);
      /* Send Transaction Pending to user */
      mgChSendPrim ((Ptr)&chInd, peer, NULLP, CH_PRIM_TYPE_IND); 
      }
   }
#endif /* GCP_CH && GCP_VER_1_5 */ 
   RETVALUE(ROK);
} /* End of mgSendMgcoTxnPend */



/* 
 * This function is invoked only in MEGACO path. Put it in appropriate flag.
 * No need for checks of protocol type inside this function. Removed those
 * checks.
 */
/*
*
*       Fun:   mgFindPeerForTxnReq
*
*       Desc:  Find peer to be used for transaction Request from service 
*              user.
*
*       Ret:   ROK - SUCCESS;
*              RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC MgPeerCb *  mgFindPeerForTxnReq
(
MgSSAPCb           *ssap,              /* SSAP control block */ 
MgMgcoMsg          *mgcoMsg,           /* MEGACO Message */
U8                 source              /* Initiated by user/ internal */
)
#else
PUBLIC MgPeerCb *  mgFindPeerForTxnReq(ssap, mgcoMsg, source)
MgSSAPCb           *ssap;              /* SSAP control block */ 
MgMgcoMsg          *mgcoMsg;           /* MEGACO Message */
U8                 source;             /* Initiated by user/ internal */
#endif
{
   MgPeerCb        *peer;              /* Peer Control Block */

#ifdef GCP_MGC
   MgPeerCb        *newPeer;           /* active peer control blk, if
                                        * peer specified is standby 
                                        */
#endif /* GCP_MGC */

#ifdef GCP_MG
   MgPeerCb        *peerFromUser;      /* Peer from peerInfo sent by the user */
#ifdef ZG
   Bool            genUpd = FALSE;
#endif /* ZG */
#endif /* GCP_MG */

   TRC2(mgFindPeerForTxnReq)

   peer = NULLP;

   /* 
    * If on the gateway side try to access the ssap crntMgc. 
    *  If not found get the first peer from the ssap list which should
    *  be the primary MGC. Also ensure that the user has specified the 
    *  primary MGC in the incoming req. If not return error to the user 
    */
#ifdef GCP_MG
   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
      peer = ssap->crntMgc;

      if (peer == NULLP)
      {
         if (mgcoMsg->body.type.val ==  MGT_ERRDESC)
         {
            mgHandleMgcoTxnReqErr(ssap, mgcoMsg, MGT_ERR_INVALID_PEER,
                                 source);
            RETVALUE(NULLP);
         }
#ifdef ZG_DFTHA
/* Only Master will update crntMgc value */
         if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
         {
            mgSelectPeer(&(peer), ssap);
               
            if (peer == NULLP)
            {
               mgHandleMgcoTxnReqErr(ssap, mgcoMsg, MGT_ERR_INVALID_PEER, 
                                    source);
               RETVALUE(NULLP);
            }

            ssap->crntMgc = peer;
#ifdef ZG
            genUpd = TRUE;
#endif /* ZG */
         }
#ifdef ZG_DFTHA
         /* There shouldn't be case where ssap->crntMgc should be NULL */
         else
         {
               mgHandleMgcoTxnReqErr(ssap, mgcoMsg, MGT_ERR_INVALID_PEER, 
                                    source);
               RETVALUE(NULLP);
         }
#endif /* ZG_DFTHA */
      }
      
      /* 
       * Cross check if peer info sent by the user matches the primary MGC. If
       * not return error to user 
       */
      if (mgcoMsg->lcl.pres.pres != NOTPRSNT) 
      {
         peerFromUser = mgLocatePeer(&mgcoMsg->lcl, ssap);
         if ((peerFromUser == NULLP) || (peer != peerFromUser))
         {
            mgHandleMgcoTxnReqErr(ssap, mgcoMsg, MGT_ERR_INVALID_PEER, 
                                 source);
            RETVALUE(NULLP);
         }
      }
#ifdef ZG
      if(TRUE == genUpd)
      {
         /* send update for crnt Mgc */
         zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
               CMPFTHA_ACTN_MOD);
         zgUpdPeer();
      }
#endif /* ZG */
   } /* if MG */
#endif /* GCP_MG */ 

  /* 
   * On the MGC side, locate peer from the peerInfo provided by the
   * service user. If the service user has specified a standby peer
   * change peer to active one 
   */
#ifdef GCP_MGC
   if (mgCb.genCfg.entType == LMG_ENT_GC)
   {
      /* If MGC locate peer from local Info */
      if ((peer = mgLocatePeer(&mgcoMsg->lcl, ssap)) == NULLP)
      {
         /*
          * Inform User that transactions have been discarded with 
          * reason as no gateway was found 
          */
         mgHandleMgcoTxnReqErr(ssap, mgcoMsg, MGT_ERR_INVALID_PEER, 
                                 source);
         RETVALUE(NULLP);
      }

      if (peer->state == LMG_PEER_STATE_ACTIVE)
      {
         if (peer->mgcoInfo.peerType == MG_STANDBY)
         {
            if (peer->mgcoInfo.t.matedMG != NULLP)
            {
               newPeer = peer->mgcoInfo.t.matedMG;

               if (newPeer->state != LMG_PEER_STATE_ACTIVE)
                  RETVALUE(NULLP);
               else
                  peer = newPeer;
            }
            else
               RETVALUE(NULLP);
         }
      }
   } /* if MGC */
#endif /* GCP_MGC */

  RETVALUE(peer);

} /* End of mgFindPeerForTxnReq */

#ifdef GCP_MGC
/*
*
*       Fun:   mgChkPeerType
*
*       Desc:  Checks if peer from which a message was received is the
*              standby peer. If yes, it assumes that the previously
*              active peer is down and makes the standby peer active.
*              If the active peer is made stanby or vice versa the
*              layer manager is informed thru a status indication.
*
*       Ret:   ROK - SUCCESS;
*              RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE S16  mgChkPeerType
(
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PRIVATE S16 mgChkPeerType(peer)
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
   MgPeerCb        *activePeer;        /* Peer Control Block */
   MgPeerCntrl     matedPairInfo;      /* Mated Pair Information */

   /* 
    * If peer is active, then message was received from the expected peer,
    * so return 
    */
   if (peer->mgcoInfo.peerType != MG_STANDBY)
      RETVALUE(ROK);

   if (peer->mgcoInfo.t.matedMG == NULLP)
      RETVALUE(RFAILED);

   /* 
    * If Message was received from stanby, move all transactions from 
    * active to the standby and make the standby the active peer 
    */
   peer->mgcoInfo.peerType = MG_ACTIVE;

   activePeer = peer->mgcoInfo.t.matedMG;

   activePeer->mgcoInfo.peerType = MG_STANDBY;

   mgMoveAllTxn(activePeer, peer, MG_INTERNAL);

   activePeer->state = LMG_PEER_STATE_AWAIT_REG;

   /* Indicate shift between active and standby to layer manager */
   /* Use the MGCO specific macro */
   MG_COPY_PEERINFO_INTO_MGCOMSG(matedPairInfo.activePeer, peer);

   MG_COPY_PEERINFO_INTO_MGCOMSG(matedPairInfo.u.standbyPeer, activePeer);

   mgGenStaInd(STGCPENT, LCM_CATEGORY_PROTOCOL, 
               LMG_EVENT_MATED_PEER_SWITCHOVER,
               LMG_CAUSE_UNKNOWN, LMG_ALARMINFO_MATED_PEER,
               (Ptr)&matedPairInfo, sizeof(MgPeerCntrl), LMG_ALARMINFO_INVSAPID);

   RETVALUE(ROK);

} /* End of mgChkPeerType */

#endif /* GCP_MGC */





/*
*
*       Fun:   mgTransmitSrvcChng
*
*       Desc:  Transmits service chnage message to the peer.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: This function is used when the initReg flag is configured
*              to be TRUE i.e. the layer need to initiate the registration 
*              procedure.
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgTransmitSrvcChng 
(
MgPeerCb           *peer,              /* Peer Control Block */
Buffer             *mBuf,              /* Message buffer */            
MgMgcoMsg          *msg,               /* MEGACO message */
Bool               txnSend             /* Txn to be transmitted / queued */
)
#else
PUBLIC S16 mgTransmitSrvcChng(peer, mBuf, msg, txnSend)
MgPeerCb           *peer;              /* Peer Control Block */
Buffer             *mBuf;              /* Message buffer */     
MgMgcoMsg          *msg;               /* MEGACO message */
Bool               txnSend;            /* Txn to be transmitted / queued */
#endif

{
   CmTptAddr       remAddr;            /* Remote Address */
   Buffer          *hdrMBuf;           /* Header Buffer */
   Buffer          *txnMBuf;           /* Transaction buffer */
   Buffer          *tmpBuf;            /* Temporary Buffer */
   Buffer          *tmpHdrMBuf;        /* Temporary Buffer */
   CmAbnfErr       err;                /* ABNF Encoding Error */
   S16             ret;                /* Return Value */
   MsgLen          tmpLen;             /* length */
   MgTptSrvr       *srvr;              /* Server for transmission */

#ifdef    GCP_PROV_SCTP
   TknU32          ctxId;              /* Integer type of Context-ID */
#endif    /* GCP_PROV_SCTP */



   TRC2(mgTransmitSrvcChng)



   tmpLen =0;
   hdrMBuf = NULLP;
   txnMBuf = NULLP;
   tmpHdrMBuf = NULLP;


   /* Get Buffer to store header information */
   if (mgGetMsg(peer->tsap->tsapCfg.memId.region,
                peer->tsap->tsapCfg.memId.pool,
                &hdrMBuf) != ROK)
   {
      MG_CLEAR_MEM(NULLP, hdrMBuf);
      RETVALUE(RFAILED);
   }
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 

   if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_TXT)
   {

#endif /* GCP_VER_1_5 GCP_ASN */
      /* Encode MGCO Header */
      if ((cmAbnfEncPduMsg(CM_ABNF_PROT_MEGACO_H248, (U8 *)&(msg->ver),
                           hdrMBuf, &mgMgcoMsgHdrDef,
                           &(peer->tsap->tsapCfg.memId),
                           &err)) != ROK)
      {
         MG_CLEAR_MEM(NULLP, hdrMBuf); 
         RETVALUE(RFAILED);
      }
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
   }
   else if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
   {
       /* Encode Buffer & Transmit */
       /* Need to fix in the apropriate params once proto type is ready  */
        if ((mgEncPduMsg(CM_ABNF_PROT_MEGACO_H248, (U8 *)msg, 0,
                        hdrMBuf, MGED_HDR_ENC,
                        &(peer->tsap->tsapCfg.memId),
                        &err)) != ROK)

       {
           MG_CLEAR_MEM(NULLP, hdrMBuf); 
           RETVALUE(RFAILED);
       }
   }
   else
   {
       /* Encoding type not defined properly */
       MG_CLEAR_MEM(NULLP, hdrMBuf); 
       RETVALUE(RFAILED);
   }

#endif /* GCP_VER_1_5 GCP_ASN */

   /* Get Buffer for the transaction */
   if (mgGetMsg(peer->tsap->tsapCfg.memId.region,
                peer->tsap->tsapCfg.memId.pool,
                &(txnMBuf)) != ROK)
   {
      MG_CLEAR_MEM(NULLP, hdrMBuf); 
      RETVALUE(RFAILED);
   }

   if (txnSend == TRUE)
   {
      /* 
       * Copy header into a temp field because SCatMsg clears the 
       *  concatenated buffer contents 
       */
      if ((SCpyMsgMsg(hdrMBuf, peer->tsap->tsapCfg.memId.region, 
                      peer->tsap->tsapCfg.memId.pool,
                      &(tmpHdrMBuf))) != ROK)
      {
         MG_CLEAR_MEM(NULLP, hdrMBuf);
         RETVALUE(MGT_ERR_RSRC_UNAVAIL);
      }
   

      /* Concat Header to the mBuf to be transmitted */
      if ((SCatMsg(mBuf, tmpHdrMBuf, M1M2)) != ROK)
      {
         MG_CLEAR_MEM(NULLP, hdrMBuf); 
         RETVALUE(RFAILED);
      }
   }


   if ((ret= mgFillMgcoMsgBuf(mBuf,hdrMBuf, txnMBuf, msg, 0,
                              &txnSend,&tmpLen, peer->tsap,
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
                              peer->mgcoInfo.encodingScheme,
#endif
                              peer)) != MGT_NONE)
   {
      MG_CLEAR_MEM(NULLP, hdrMBuf);
      if (txnMBuf != NULLP)
         mgPutMsg(txnMBuf);
      RETVALUE(RFAILED);
   }
   
   remAddr.type = CM_TPTADDR_NOTPRSNT;

   /* If transaction needs to be sent immeediately */
   if (txnSend == TRUE)
   {
      /* Find server for message transmission */
         if(
#ifdef   GCP_PROV_MTP3 
         (peer->accessInfo.transportType != LMG_TPT_MTP3) &&
#endif   /* GCP_PROV_MTP3  */     

#ifdef    GCP_PROV_SCTP
        (peer->accessInfo.transportType != LMG_TPT_SCTP) &&
#endif /* GCP_PROV_SCTP */

         ((srvr = mgGetSendSrvr(peer->ssap, peer)) == NULLP))

         {
            MG_CLEAR_MEM(NULLP, hdrMBuf); 
            if (txnMBuf != NULLP)
               mgPutMsg(txnMBuf);
            RETVALUE(RFAILED);
         }

      /* Add reference to message because TUCL releases the buffer */
      if ((SAddMsgRef (mBuf, peer->tsap->tsapCfg.memId.region, 
                       peer->tsap->tsapCfg.memId.pool,
                       &(tmpBuf))) != ROK)
      {
         MG_CLEAR_MEM(NULLP, hdrMBuf); 
         if (txnMBuf != NULLP)
            mgPutMsg(txnMBuf);
         RETVALUE(RFAILED);
      }



#ifdef    GCP_PROV_SCTP
      /*
       * call the following function to find out the context Id
       * used by the first transaction in the MEGACO message
       */
      mgExtractCtxIdFrmMsg(msg, &ctxId);
#endif    /* GCP_PROV_SCTP */


      /* Transmit the message */
      if ((ret = mgTransmitMgcoMsg(peer,
#ifdef    GCP_PROV_SCTP
                                   peer->assocCb,
                                   ctxId,
#endif    /* GCP_PROV_SCTP */
                                   srvr, &remAddr, tmpBuf, msg)) 
         != MGT_NONE)
      {
         MG_CLEAR_MEM(NULLP, hdrMBuf);
         if (txnMBuf != NULLP)
            mgPutMsg(txnMBuf);
         RETVALUE(RFAILED);
      }
   }
   else
   {
      /* 
       * If transaction is to be queued.  Copy contents of transaction
       * into mBuf since mBuf is what is stored in txCb 
       */
      if ((SCatMsg(mBuf, txnMBuf, M1M2)) != ROK)
      {
         MG_CLEAR_MEM(NULLP, hdrMBuf);
         if (txnMBuf != NULLP)
            mgPutMsg(txnMBuf);
         RETVALUE(RFAILED);
      }
   }

   /* 
    * mBuf is not released because it needs to be stored 
    * for retransmission 
    */
   MG_CLEAR_MEM(NULLP, hdrMBuf);

   if (txnMBuf != NULLP)
      mgPutMsg(txnMBuf);

   if (tmpHdrMBuf != NULLP)
      mgPutMsg(tmpHdrMBuf);

   RETVALUE(ROK);

} /* End of mgTransmitSrvcChng */


/*
*
*       Fun:   mgTransmitSrvcChngReply
*
*       Desc:  Transmits Service Change Reply
*
*       Ret:   ROK
*              RFAILED
*
*       Notes:
*
*       File:  mg_cord.c
*
*/

#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))

#ifdef ANSI
PUBLIC S16 mgTransmitSrvcChngReply
(
Buffer             *mBuf,              /* Message buffer */            
MgMgcoMsg          *msg,               /* Message to be sent */
MgTSAPCb           *tsap,              /* TSAP CB */
MgcoTptInfo        *mgcoTptInfo,       /* Megaco Transport Information */
MgTptSrvr          *srvr,              /* Server for transmission */
CmTptAddr          *tptAddr            /* Transport Address */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
,U8                encodingScheme      /* encoding Scheme */
#endif /* GCP_VER_1_5 GCP_ASN */
)
#else
PUBLIC S16 mgTransmitSrvcChngReply(mBuf, msg, tsap, mgcoTptInfo, srvr, tptAddr
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                                   ,encodingScheme
#endif
                                   )
Buffer             *mBuf;              /* Message buffer */            
MgMgcoMsg          *msg;               /* Message to be sent */
MgTSAPCb           *tsap;              /* TSAP CB */
MgcoTptInfo        *mgcoTptInfo;       /* Megaco Transport Information */
MgTptSrvr          *srvr;              /* Server for transmission */
CmTptAddr          *tptAddr;           /* Transport Address */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
U8                encodingScheme;      /* encoding Scheme */
#endif /* GCP_VER_1_5 GCP_ASN */
#endif

#else     /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */

#ifdef ANSI
PUBLIC S16 mgTransmitSrvcChngReply
(
Buffer             *mBuf,              /* Message buffer */            
MgMgcoMsg          *msg,               /* Message to be sent */
MgTSAPCb           *tsap,              /* TSAP CB */
MgTptSrvr          *srvr,              /* Server for transmission */
CmTptAddr          *tptAddr            /* Transport Address */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
,U8                encodingScheme      /* encoding Scheme */
#endif /* GCP_VER_1_5 GCP_ASN */
)
#else
PUBLIC S16 mgTransmitSrvcChngReply(mBuf, msg, tsap, srvr, tptAddr
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                                   ,encodingScheme
#endif
                                   )
Buffer             *mBuf;              /* Message buffer */            
MgMgcoMsg          *msg;               /* Message to be sent */
MgTSAPCb           *tsap;              /* TSAP CB */
MgTptSrvr          *srvr;              /* Server for transmission */
CmTptAddr          *tptAddr;           /* Transport Address */
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
U8                encodingScheme;      /* encoding Scheme */
#endif /* GCP_VER_1_5 GCP_ASN */

#endif

#endif    /* GCP_PROV_SCTP */
{
   Buffer          *tmpHdrBuf;         /* Temorary Header Buffer */
   Buffer          *hdrMBuf;           /* Header Buffer */
   Buffer          *txnMBuf;           /* Transaction Buffer */
   CmAbnfErr       err;                /* ABNF Encoding Error */
   S16             ret;                /* Return Value */
   MsgLen          tmpLen;             /* Message length */
   Bool            txnSend;            /* Transaction to be sent/not */

#ifdef    GCP_PROV_SCTP
   TknU32          ctxId;              /* Context-ID */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_SCTP 
   MgAssocCb       *assoc = NULLP;  /* Association Control Block as passed in mgcoTptInfo */
#endif   /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
   Dpc             peerDpc = NULLD;     /* Peer DPC as passed in MgcoTptInfo */
#endif   /* GCP_PROV_SCTP */




   TRC2(mgTransmitSrvcChngReply)


   tmpLen     = 0;
   hdrMBuf    = NULLP;
   txnMBuf    = NULLP;
   txnSend    = TRUE;

   /* 
    * Code added to pass multiple trasport parameter and then make each 
    * transport parameter available in an
    * local copy of its transport variable 
    */
#if   (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
   if(mgcoTptInfo != NULLP)
   {
#ifdef   GCP_PROV_SCTP      
      if(mgcoTptInfo->tptType == LMG_TPT_SCTP)
         assoc = mgcoTptInfo->u.assocCb;
#endif   /* GCP_PROV_SCTP */         
#ifdef   GCP_PROV_MTP3
      if (mgcoTptInfo->tptType == LMG_TPT_MTP3) 
         peerDpc  = mgcoTptInfo->u.mgMtpInfo.clgAddr;
#endif   /* GCP_PROV_MTP3 */         
    }     
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
 


#ifdef    GCP_PROV_SCTP
   /*
    * call the following function to find out the context Id
    * used by the first transaction in the MEGACO message
    */
   mgExtractCtxIdFrmMsg(msg, &ctxId);

#endif    /* GCP_PROV_SCTP */




   /* Get Buffer to store header information */
   if (mgGetMsg(tsap->tsapCfg.memId.region, tsap->tsapCfg.memId.pool,
               &hdrMBuf) != ROK)
   {
      MG_CLEAR_MEM(NULLP, hdrMBuf);
      RETVALUE(RFAILED);
   }

#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
   if (encodingScheme == LMG_ENCODE_TXT)
   {
#endif /* GCP_VER_1_5 GCP_ASN */
      /* Encode MGCO Header */
      if ((cmAbnfEncPduMsg(CM_ABNF_PROT_MEGACO_H248, (U8 *)&(msg->ver),
                           hdrMBuf, &mgMgcoMsgHdrDef, &(tsap->tsapCfg.memId),
                           &err)) != ROK)
      {
         MG_CLEAR_MEM(NULLP, hdrMBuf); 
         RETVALUE(RFAILED);
      }
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 

   }
   else if (encodingScheme == LMG_ENCODE_BIN)
   {
       /* Encode Buffer & Transmit */
        /* Need to fix in the apropriate params once proto type is ready  */
      if ((mgEncPduMsg(CM_ABNF_PROT_MEGACO_H248, (U8 *)msg, 0,
                        hdrMBuf, MGED_HDR_ENC, &(tsap->tsapCfg.memId),
                        &err)) != ROK)
      {
         MG_CLEAR_MEM(NULLP, hdrMBuf); 
         RETVALUE(RFAILED);
      }
   }
   else
   {
      /* Encoding type not defined properly */
      MG_CLEAR_MEM(NULLP, hdrMBuf); 
      RETVALUE(RFAILED);
   }

#endif /* GCP_VER_1_5 GCP_ASN */

   /* Get Buffer for Transaction */
   if (mgGetMsg(tsap->tsapCfg.memId.region, tsap->tsapCfg.memId.pool,
               &(txnMBuf)) != ROK)
   {
      MG_CLEAR_MEM(NULLP, hdrMBuf); 
      RETVALUE(RFAILED);
   }

   /* mg008.105: In mgTransmitSrvcChngReply mBuf is not containing the header information */
   if ((SCpyMsgMsg(hdrMBuf, tsap->tsapCfg.memId.region,
                   tsap->tsapCfg.memId.pool,
                   &(tmpHdrBuf))) != ROK)
   {
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }
  
  
   /* Concat Header to txn buffer to store in the transaction control block */
   if ((SCatMsg(mBuf, tmpHdrBuf, M2M1)) != ROK)
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
  
   /* mg003.105: Add - Added sanity check */
   if (tmpHdrBuf != NULLP)
      mgPutMsg(tmpHdrBuf);

   /* Encode Transaction */
   /*MAH_TODO Needs to pass encoding scheme */
   if ((ret= mgFillMgcoMsgBuf(mBuf,hdrMBuf, txnMBuf, msg, 0,
                              &txnSend, &tmpLen, tsap, 
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
                              encodingScheme ,
#endif
                              NULLP)) != MGT_NONE)
   {
      MG_CLEAR_MEM(NULLP, hdrMBuf);
      if (txnMBuf != NULLP)
         mgPutMsg(txnMBuf);
      RETVALUE(RFAILED);
   }

   /* Copy contents of txnMbuf to mBuf because mBuf will be stored in rxCb */
/*   if ((SCatMsg(mBuf, txnMBuf, M1M2)) != ROK)
   {
      MG_CLEAR_MEM(NULLP, hdrMBuf);
      if (txnMBuf != NULLP)
         mgPutMsg(txnMBuf);
      RETVALUE(RFAILED);
   }*/
#ifdef    GCP_PROV_MTP3
   /*
    * Donot confuse with called address as Destination point code
    * as it is opc in our case since these field are significant when we 
    * receive incoming Txn Ind from MTP3 so called address is our point code
    * in that situation
   */
   if((peerDpc) && (tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3))
      mgMtpDatReq(NULLP, peerDpc,
                 mgcoTptInfo->u.mgMtpInfo.cldAddr,tsap,mBuf);
    else
#endif    /* GCP_PROV_MTP3 */

#ifdef    GCP_PROV_SCTP
   if (assoc)
   {
      CmNetAddr  tmpNetAddr;
      SctStrmId  strm;



      MG_MGCO_GET_STRMID_FRM_CTXID(strm,(&ctxId),assoc);

      tmpNetAddr.type = CM_NETADDR_NOTPRSNT;

      MgLiSctDatReq(&(assoc->tsap->spPst), assoc->tsap->tsapCfg.spId,
                    assoc->spAssocId, &tmpNetAddr, strm,
                    msg->unorder, FALSE, 0, SCT_PROTID_H248, mBuf);

   }
   else   /* do NOT remove this comment */
#endif    /* GCP_PROV_SCTP */
      mgSrvDatReq(srvr, tptAddr, mBuf);

   MG_CLEAR_MEM(NULLP, hdrMBuf);
   if (txnMBuf != NULLP)
      mgPutMsg(txnMBuf);

   RETVALUE(ROK);

} /* End of mgTransmitSrvcChngReply */


/*
*
*       Fun:   mgTransmitMgcoMsg
*
*       Desc:  Transmits MEGACO message initiated by the service user
*
*       Ret:   MGT_NONE
*
*       Notes: On the MG side it is ensured that messages are transmitted 
*              only if the user is the active MG (in a redundant pair cfg).
*
*              On the MGC side all messages are transmitted to both active 
*              and standby peers in case of a redundant peer cfg.
*
*       File:  mg_cord.c
*
*/

#ifdef    GCP_PROV_SCTP

#ifdef ANSI
PUBLIC S16 mgTransmitMgcoMsg 
(
MgPeerCb           *peer,              /* Peer Control Block */ 
MgAssocCb          *assoc,             /* Association CB */
TknU32             ctxId,              /* Context-ID */
MgTptSrvr          *srvr,              /* Server for Transmission */
CmTptAddr          *remAddr,           /* Remote Address */
Buffer             *mBuf,              /* Buffer to be transmitted */
MgMgcoMsg          *msg                /* Megaco message sent by the user */
)
#else
PUBLIC S16 mgTransmitMgcoMsg(peer, assoc, ctxId, srvr, remAddr, mBuf, msg)
MgPeerCb           *peer;              /* Peer Control Block */ 
MgAssocCb          *assoc;             /* Association CB */
TknU32             ctxId;              /* Context-ID */
MgTptSrvr          *srvr;              /* Server for Transmission */
CmTptAddr          *remAddr;           /* Remote Address */
Buffer             *mBuf;              /* Buffer to be transmitted */
MgMgcoMsg          *msg;               /* Megaco message sent by the user */
#endif

#else     /* GCP_PROV_SCTP */

#ifdef ANSI
PUBLIC S16 mgTransmitMgcoMsg 
(
MgPeerCb           *peer,              /* Peer Control Block */ 
MgTptSrvr          *srvr,              /* Server for Transmission */
CmTptAddr          *remAddr,           /* Remote Address */
Buffer             *mBuf,              /* Buffer to be transmitted */
MgMgcoMsg          *msg                /* Megaco message sent by the user */
)
#else
PUBLIC S16 mgTransmitMgcoMsg(peer, srvr, remAddr, mBuf, msg)
MgPeerCb           *peer;              /* Peer Control Block */ 
MgTptSrvr          *srvr;              /* Server for Transmission */
CmTptAddr          *remAddr;           /* Remote Address */
Buffer             *mBuf;              /* Buffer to be transmitted */
MgMgcoMsg          *msg;               /* Megaco message sent by the user */
#endif

#endif    /* GCP_PROV_SCTP */
{
#ifdef GCP_MGC
   MgPeerCb        *standbyPeer;       /* Peer control Block */
   Buffer          *dupMBuf;           /* Duplicate buffer */
   MgTptSrvr       *newSrvr;           /* Server Control Block */
#endif /* GCP_MGC */

#if (defined(GCP_MG) || defined(GCP_USE_AH))
   S16             ret;                /* return Value */
#endif /* defined(GCP_MG) || defined(GCP_USE_AH) */

#ifdef GCP_MG
   MgMgcoTxn       *mgcoTxn;           /* Megaco Transaction */
   U8              method;             /* Service Change Method */
#endif /* GCP_MG */


#ifdef    GCP_PROV_SCTP
   MgAssocCb        *sbyAssoc;         /* Association CB for the standby MG */
   SctStrmId        strm;              /* Stream-ID to be used for out Txn  */
   Bool             unorder;           /* SCTP - ordered/unordered delivery */
#endif    /* GCP_PROV_SCTP */




   TRC2(mgTransmitMgcoMsg)




#ifdef GCP_MGC
   standbyPeer = NULLP;
   dupMBuf     = NULLP;
#endif /* GCP_MGC */



#ifdef    GCP_PROV_SCTP

   if (msg)
      unorder = msg->unorder;
   else
      unorder = FALSE;        /* assume ordered delivery */

#endif    /* GCP_PROV_SCTP */


#ifdef GCP_USE_AH
   if (peer->mgcoInfo.useAHScheme == TRUE)
   {
      ret = mgAttachAH(srvr,
                       remAddr,
                       peer,
#ifdef    GCP_PROV_SCTP
                       assoc,
#endif    /* GCP_PROV_SCTP */
                       mBuf);
      if (ret != ROK)
      {
         if (mBuf != NULLP)
            mgPutMsg(mBuf);
         RETVALUE(MGT_NONE);
      }
   }
#endif /* GCP_USE_AH */

  /* 
   * On the MG side we will only transmit messages from  the active side 
   * in a mated pair cfg unless it is a service change message with method 
   * Restart/Disconnected
   */
#ifdef GCP_MG
   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
      if ((peer->ssap->mgType == MG_NONE) ||
         (peer->ssap->mgType == MG_ACTIVE))
      {
#ifdef    GCP_PROV_SCTP
         MG_MGCO_GET_STRMID_FRM_CTXID(strm,(&ctxId),assoc);

         MG_TRANSMIT_PDU(peer,
                         assoc,
                         strm,
                         unorder,
                         srvr,
                         remAddr,
                         mBuf);

#else     /* GCP_PROV_SCTP */
         MG_TRANSMIT_PDU(peer,
                         srvr,
                         remAddr,
                         mBuf);
#endif    /* GCP_PROV_SCTP */
      }
      else 
      if (peer->ssap->mgType == MG_STANDBY)
      {
         if (msg != NULLP)
         {
            mgcoTxn = *(msg->body.u.tl.txns + 0);

            method = MGT_NONE;

            if ((ret=mgVerifySvcChg(mgcoTxn,&method)) == ROK)
            {
               if ((method != MGT_SVCCHGMETH_RESTART) || 
                  (method !=MGT_SVCCHGMETH_DISCON))
               ret = RFAILED;
            }

            /* 
             * if service change with restart/ discon method then transmit 
             * message to peer 
             */
            if (ret == ROK)
            {
#ifdef    GCP_PROV_SCTP
               MG_MGCO_GET_STRMID_FRM_CTXID(strm,(&ctxId),assoc);

               MG_TRANSMIT_PDU(peer,
                               assoc,
                               strm,
                               unorder,
                               srvr,
                               remAddr,
                               mBuf);
#else     /* GCP_PROV_SCTP */
               MG_TRANSMIT_PDU(peer,
                               srvr,
                               remAddr,
                               mBuf);
#endif    /* GCP_PROV_SCTP */
            } 
            else
            {   
               if (mBuf != NULLP)
                  mgPutMsg(mBuf);
            }
         } /* If service change message */
         else
         {   
            if (mBuf != NULLP)
               mgPutMsg(mBuf);
         }
      } /* if standby */

      RETVALUE(MGT_NONE);
   }
#endif /* GCP_MG */


  /* 
   * On MGC side if the peer belongs to a mated pair. The message needs to be
   * sent out to both the peers  i.e. active & standby 
   */
#ifdef GCP_MGC
   if (mgCb.genCfg.entType == LMG_ENT_GC)
   {
      newSrvr = NULLP;   /*  add newSrvr <-> sbyAssoc, sbyStrm handling */
      dupMBuf = NULLP;
#ifdef    GCP_PROV_SCTP
      sbyAssoc = NULLP;
#endif    /* GCP_PROV_SCTP */


      if (peer->mgcoInfo.peerType == MG_ACTIVE)
      {
         standbyPeer = peer->mgcoInfo.t.matedMG;           
      }
      else
      {
         standbyPeer = NULLP;
      }
      
      if ((standbyPeer != NULLP) && 
         (standbyPeer->state == LMG_PEER_STATE_ACTIVE))
      {

         /* Make a copy of buffer to be transmitted to standby */
         if ((SCpyMsgMsg(mBuf, peer->tsap->tsapCfg.memId.region, 
                         peer->tsap->tsapCfg.memId.pool, &(dupMBuf))) != ROK)
         {
            RETVALUE(MGT_ERR_RSRC_UNAVAIL);
         }

         remAddr->type = CM_TPTADDR_NOTPRSNT;

#ifdef    GCP_PROV_SCTP
         if (standbyPeer->accessInfo.transportType == LMG_TPT_SCTP)
         {
            /*
             *   since this is a MGC, the standby MG would have
             *   already established an association with this MGC
             */
            sbyAssoc = standbyPeer->assocCb;
         }
         else   /* do NOT delete this comment */
#endif    /* GCP_PROV_SCTP */
         if (standbyPeer->accessInfo.transportType == LMG_TPT_TCP)
         {
            newSrvr = standbyPeer->mgcoInfo.nxtUseConn;
         }
         else
         /* mg002.105: Add additional check*/   
         if(standbyPeer->accessInfo.transportType != LMG_TPT_MTP3)   
         {
            
            /* mg002.105: Add additional check*/   
            if (srvr->transportType != LMG_TPT_UDP)
            {
               /* 
               * Server type passed to this function is a TCP Connection
               * where as standby peer uses UDP; So obtain a UDP Server
               * for transmission
               */
               newSrvr = mgGetSendSrvr(standbyPeer->ssap, standbyPeer);

               /* mg002.105: Add additional check*/   
               if (newSrvr == NULLP)

               {
                  SPutMsg(dupMBuf);
                  RETVALUE(MGT_ERR_RSRC_UNAVAIL);
               }
            }
            else
            {
               /* Else use the UDP Server passed */
               newSrvr = srvr;
            }
         }
      }


      /* Transmit to Active Peer */
#ifdef    GCP_PROV_SCTP
      MG_MGCO_GET_STRMID_FRM_CTXID(strm,(&ctxId),assoc);

      MG_TRANSMIT_PDU(peer,
                      assoc,
                      strm,
                      unorder,
                      srvr,
                      remAddr,
                      mBuf);
#else     /* GCP_PROV_SCTP */
      MG_TRANSMIT_PDU(peer,
                      srvr,
                      remAddr,
                      mBuf);
#endif    /* GCP_PROV_SCTP */


      /* If server is ok, transmit to standby peer */
      if (
#ifdef    GCP_PROV_MTP3
      ((standbyPeer) && (standbyPeer->accessInfo.transportType == LMG_TPT_MTP3)) || 
#endif    /* GCP_PROV_MTP3 */

#ifdef    GCP_PROV_SCTP 
      ((newSrvr != NULLP) || (sbyAssoc != NULLP)) || 
         
#endif     /* GCP_PROV_SCTP */
        (newSrvr != NULLP))
      {

#ifdef    GCP_PROV_SCTP
         SctStrmId      sbyStrm;
#endif    /* GCP_PROV_SCTP */

         /* 
          * Re-initialize remAddr->type so that the correct IP
          * address is filled inside the macro 
          */
         remAddr->type = CM_TPTADDR_NOTPRSNT;

#ifdef    GCP_PROV_SCTP
         MG_MGCO_GET_STRMID_FRM_CTXID(sbyStrm,(&ctxId),sbyAssoc);

         MG_TRANSMIT_PDU(standbyPeer,
                         sbyAssoc,
                         sbyStrm,
                         unorder,
                         newSrvr,
                         remAddr,
                         dupMBuf);
#else     /* GCP_PROV_SCTP */
         MG_TRANSMIT_PDU(standbyPeer,
                         newSrvr,
                         remAddr,
                         dupMBuf);
#endif    /* GCP_PROV_SCTP */

         dupMBuf = NULLP;
      }

      RETVALUE(MGT_NONE);
   }
#endif /* GCP_MGC */

   RETVALUE(MGT_NONE);

} /* End of mgTransmitMgcoMsg */




#ifdef GCP_USE_AH
/*
*
*       Fun:   mgAttachAH
*
*       Desc:  Function creates and encodes the ah security header and 
*              attaches it to the message.
*              This is done only if AH security scheme has been implemented 
*              configured.
*
*       Ret:   ROK - Success; RFAILED - FAILED:
*
*       Notes:
*
*       File:  mg_cord.c
*
*/

#ifdef    GCP_PROV_SCTP

#ifdef ANSI
PUBLIC S16 mgAttachAH
(
MgTptSrvr          *srvr,              /* Server Cb */
CmTptAddr          *remAddr,           /* Remote Address */
MgPeerCb           *peer,              /* Peer Cb */
MgAssocCb          *assoc,             /* Association Cb */
Buffer             *mBuf               /* Outgoing Buffer */
)
#else
PUBLIC S16 mgAttachAH(srvr, remAddr, peer, assoc, mBuf)
MgTptSrvr          *srvr;              /* Server Cb */
CmTptAddr          *remAddr;           /* Remote Address */
MgPeerCb           *peer;              /* Peer Cb */
MgAssocCb          *assoc;             /* Association Cb */
Buffer             *mBuf;              /* Outgoing Buffer */
#endif

#else     /* GCP_PROV_SCTP */

#ifdef ANSI
PUBLIC S16 mgAttachAH
(
MgTptSrvr          *srvr,              /* Server Cb */
CmTptAddr          *remAddr,           /* Remote Address */
MgPeerCb           *peer,              /* Peer Cb */
Buffer             *mBuf               /* Outgoing Buffer */
)
#else
PUBLIC S16 mgAttachAH(srvr, remAddr, peer, mBuf)
MgTptSrvr          *srvr;              /* Server Cb */
CmTptAddr          *remAddr;           /* Remote Address */
MgPeerCb           *peer;              /* Peer Cb */
Buffer             *mBuf;              /* Outgoing Buffer */
#endif

#endif    /* GCP_PROV_SCTP */
{
   MgMgcoAuthHdr   *ah;                /* AH structure */
   Buffer          *ahBuf;             /* AH Buffer */
   CmAbnfErr       err;                /* ABNF Encoding Error */
   S16             ret;                /* Return Value */

   TRC2(mgAttachAH)

   ret = mgCreateAH(ah, mBuf, remAddr, &srvr->tptAddr);
   
   if (ret != ROK)
      RETVALUE(RFAILED);


   /* Get Buffer to store Auth header information */
   if (mgGetMsg(peer->tsap->tsapCfg.memId.region,
                peer->tsap->tsapCfg.memId.pool,
                  &ahBuf) != ROK)
      RETVALUE(RFAILED);

#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 

   if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_TXT)
   {

#endif /* GCP_VER_1_5 GCP_ASN */
      /* Encode MGCO AH Buffer */
      if ((cmAbnfEncPduMsg(CM_ABNF_PROT_MEGACO_H248, (U8 *)&(ah),
                           ahBuf, &mgMgcoAuthHdrDef, 
                           &(peer->tsap->tsapCfg.memId), &err)) != ROK)
      {
         if (ahBuf != NULLP)
            mgPutMsg(ahBuf); 
         RETVALUE(RFAILED);
      }
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 

   }
   else if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
   {
       /* Encode Buffer & Transmit */
       /* Need to fix in the apropriate params once proto type is ready  */
         if ((mgEncPduMsg(CM_ABNF_PROT_MEGACO_H248, (U8 *)msg, 0,
                        ahBuf, MGED_AUTHHDR, 
                        &(peer->tsap->tsapCfg.memId), &err)) != ROK)
       {
           if (ahBuf != NULLP)
              mgPutMsg(ahBuf); 
           RETVALUE(RFAILED);
       }
   }
   else
   {
       /* Encoding type not defined properly */
       if (ahBuf != NULLP)
         mgPutMsg(ahBuf); 
       RETVALUE(RFAILED);
   }

#endif /* GCP_VER_1_5 GCP_ASN */   
 
   if ((SCatMsg(mBuf, ahBuf, M2M1)) != ROK)
   {
      if (ahBuf != NULLP)
         mgPutMsg(ahBuf);
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* End of mgAttachAH */

#endif /* GCP_USE_AH */



/*
*
*       Fun:   mgFillNewMgcoBuf
*
*       Desc:  This function allocates a new mBuf for transmitting a message 
*              and attaches the header and txn (if necessary) to the mBuf. 
*              Function is used when the Mbuf previously being used to
*              transmit the message exceeds MTU size. 
*  
*
*       Ret:    MGT_NONE             - Success;
*               MGT_ERR_RSRC_UNAVAIL - Resource Unavailable
*
*       Notes:
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgFillNewMgcoBuf 
(
Buffer             **mBufPtr,          /* Message buffer */            
Buffer             *hdrMBuf,           /* Header Buffer */
Buffer             *txnMBuf,           /* Transaction buffer pointer */
MsgLen             *crntPduLen,        /* Current Length of PDU */
Bool               txnSend,            /* Transaction to be appended/ not */ 
MgTSAPCb           *tsap               /* TSAP control block */
)
#else
PUBLIC S16 mgFillNewMgcoBuf(mBufPtr, hdrMBuf, txnMBuf, crntPduLen,
                            txnSend, tsap)
Buffer             **mBufPtr;          /* Message buffer */     
Buffer             *hdrMBuf;           /* Header Buffer */
Buffer             *txnMBuf;           /* Transaction buffer pointer */
MsgLen             *crntPduLen;        /* Current Length of PDU */
Bool               txnSend;            /* Transaction to be appended/ not */
MgTSAPCb           *tsap;              /* TSAP control block */
#endif
{
   Buffer          *tmpTxnBuf;         /* Temorary Header Buffer */
   Buffer          *tmpHdrBuf;         /* Temorary Header Buffer */


   TRC2(mgFillNewMgcoBuf)


   *crntPduLen = 0;

   /* Get Buffer to store Msg to be transmitted */
   if (mgGetMsg(tsap->tsapCfg.memId.region, tsap->tsapCfg.memId.pool,
               mBufPtr) != ROK)
   {
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }

   /* SGetMsg for tmpHdrBuf removed from here, since 
    * SCpyMsgMsg allocates the buffer for the destination */
   
   /* 
    * Copy header into a temp field because SCatMsg clears the 
    * concatenated buffer contents 
    */
   if ((SCpyMsgMsg(hdrMBuf, tsap->tsapCfg.memId.region,
                   tsap->tsapCfg.memId.pool, &(tmpHdrBuf))) != ROK)
   {
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }
  

   /* Concat Header  to the mBuf to be transmitted */
   if ((SCatMsg(*(mBufPtr), tmpHdrBuf, M1M2)) != ROK)
   {
      /* deallocate tmpHdrBuf in case of failure */
      SPutMsg(tmpHdrBuf);
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }

   /* deallocate tmpHdrBuf here since it would be allocated again
    * in the next SCpyMsgMsg call */
   SPutMsg(tmpHdrBuf);

   /* 
    * If the curent transaction to be processed has not already been attached to 
    * the previous mBuf i.e. txnSend = TRUE, attach it to the newmBuf. 
    * If it has been skip this txn.The transaction would have 
    * been filled into the old buffer if it was the first txn and its size
    * exceeded the MTU size
    */

   if (txnSend == TRUE)
   {
      /* Copy Transaction into a temp Buffer */
      if ((SCpyMsgMsg(txnMBuf, tsap->tsapCfg.memId.region, 
                     tsap->tsapCfg.memId.pool, &(tmpTxnBuf))) != ROK)
      {
         RETVALUE(MGT_ERR_RSRC_UNAVAIL);
      }
   
      /* Concat transaction to the mBuf to be transmitted */
      if ((SCatMsg(*(mBufPtr), tmpTxnBuf, M1M2)) != ROK)
      {
         /* deallocate tmpTxnBuf in case of failure */
         SPutMsg(tmpTxnBuf);
         RETVALUE(MGT_ERR_RSRC_UNAVAIL);
      }

      /* deallocate tmpTxnBuf here since it is no longer required
       * */
      SPutMsg(tmpTxnBuf);


      /* Copy header into a temp field because SCatMsg clears the 
         concatenated buffer contents */
      if ((SCpyMsgMsg(hdrMBuf, tsap->tsapCfg.memId.region, 
                      tsap->tsapCfg.memId.pool, &(tmpHdrBuf))) != ROK)
      {
         RETVALUE(MGT_ERR_RSRC_UNAVAIL);
      }
   

      /* Concat Header to txn buffer to store in the txn control block */
      if ((SCatMsg(txnMBuf, tmpHdrBuf, M2M1)) != ROK)
      {
         /* deallocate tmpHdrBuf in case of failure */
         SPutMsg(tmpHdrBuf);
         RETVALUE(MGT_ERR_RSRC_UNAVAIL);
      }
      /* deallocate tmpHdrBuf here since it is no longer required
       * */
      SPutMsg(tmpHdrBuf);
   }  
   
   SFndLenMsg(*mBufPtr, crntPduLen);
      
   /* removed tmpTxnBuf deallocation from here - buffer freed just
    * after SCatMsg */

   RETVALUE(MGT_NONE);

} /* end of mgFillNewMgcoBuf() */



#endif /* GCP_MGCO */


/******************************************************************************/
/*                      DNS Library Interface                               */
/******************************************************************************/


#ifdef CM_DNS_LIB 

/*
*
*       Fun:   mgInitDnsCb
*
*       Desc:  This function sends a request to DNS for resolving a domain name
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgInitDnsCb
(
CmDnsCb            *dnsCb,             /* DNS Control Block */
U16                reqIdLstSz,         /* Request Id List Size */
Mem                *sMem,              /* Static Memory region and pool */
CmTptAddr          *dnsTptAddr,        /* Transport Address of DNS */
MgTSAPCb           *tsap               /* TSAP control block */
)
#else
PUBLIC S16 mgInitDnsCb (dnsCb, reqIdLstSz, sMem, dnsTptAddr, tsap)
CmDnsCb            *dnsCb;             /* DNS Control Block */
U16                reqIdLstSz;         /* Request Id List Size */
Mem                *sMem;              /* Static Memory region and pool */
CmTptAddr          *dnsTptAddr;        /* Transport Address of DNS */
MgTSAPCb           *tsap;              /* TSAP control block */
#endif
{
   S16             ret;                /* Return Value */
   CmDnsDbgInfo    dbgInfo;            /* Debug Information for the layer */
   EntityId        tapaEnt;            /* Tapa Entity Id */
   USRTXFUNC       txFunc;             /* Transmission function */
   USRRXFUNC       rxFunc;             /* Receive function */

   TRC2(mgInitDnsCb)

   if (dnsCb == NULLP || 
       tsap->tsapCfg.reCfg.dnsCfg.dnsAccess != LMG_DNS_USE_DNSLIB)
      RETVALUE(RFAILED);

   /* Initalise variable for DNS Interface */

   tapaEnt.ent  = mgCb.init.ent;
   tapaEnt.inst = mgCb.init.inst;
   txFunc       = mgSndRslvReqToDns;
   rxFunc       = mgRcvDnsResponse;

#ifdef DEBUGP
   dbgInfo.layerName = layerName;
   dbgInfo.prntBuf   = dnsPrntBuf;
   dbgInfo.dbgMask   = 0; /* No dbgMask for DNS for now */
#else
   cmMemset((U8 *)&dbgInfo, 0, sizeof(CmDnsDbgInfo));
#endif /* DEBUGP */
   
   /* Initialize DNS control Block */
   ret = cmDnsInitDnsCb(dnsCb, &dbgInfo, dnsTptAddr, txFunc, rxFunc, sMem,
                        ENTMG,  &tapaEnt, reqIdLstSz);
   RETVALUE(ret);

} /* end of mgInitDnsCb */





/*
*
*       Fun:   mgRcvDnsResponse
*
*       Desc:  This function processes receipt of DNS Response. It is 
*              registered with DNS library as a receive function
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgRcvDnsResponse
(
Ptr                usrEntry,           /* User Entry - Peer */
CmDnsResponse      *dnsRsp             /* DNS Response Fetched */
)
#else
PUBLIC S16 mgRcvDnsResponse (usrEntry, dnsRsp)
Ptr                usrEntry;           /* User Entry - Peer */
CmDnsResponse      *dnsRsp;            /* DNS Response Fetched */
#endif
{
   U16             loopIdx;            /* Loop Index */
   U16             port;               /* Port Number */
   U32             ttl;                /* TTL */
   MgNetAddrTbl    addrTbl;            /* Address Table */
   CmNetAddr       *netAddr;           /* Address */
   MgPeerCb        *peer;              /* Peer Control Block */
   CmDns1035RR     *ansRcrd;           /* Answer Record */



   TRC2(mgRcvDnsResponse)


   cmMemset ((U8 *)&addrTbl, 0, sizeof(MgNetAddrTbl));
   port = MG_DEFAULT_MG_PORT;
   ttl  = MG_DEFAULT_TTL_VALUE;
   peer = (MgPeerCb *) usrEntry;


   if (peer == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG042, 0,
                "[MGCP] mgRcvDnsResponse(): Null Peer Pointer\n");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }



   /* Get TTL values */
#ifdef GCP_MGCP    
   if (peer->mgcpInfo.ttl != 0)
     ttl = peer->mgcpInfo.ttl;
   else
     ttl = peer->tsap->ttl;
#endif /* GCP_MGCP */

   /* Copy Address obtained from DNS into addr table */
   for (loopIdx = 0; loopIdx < dnsRsp->header.anCount; loopIdx++)
   {
      /* 
       * Do a explicit typecast of dnsRsp-type to U8 to avoid warnings.
       */
      ansRcrd = &(dnsRsp->ans[loopIdx].rsrcRcrd);
      netAddr = &(addrTbl.netAddr[loopIdx]);

      addrTbl.count++;

      if (CM_DNS_QTYPE_A == (U8)(ansRcrd->type))
      {
         netAddr->type = CM_NETADDR_IPV4;
         netAddr->u.ipv4NetAddr = ansRcrd->rdata.ipAddress;
      }
      else
      {
#ifdef IPV6_SUPPORTED
         netAddr->type = CM_NETADDR_IPV6;
         cmMemcpy((U8 *)&(netAddr->u.ipv6NetAddr), 
                  (CONSTANT U8 *)&(ansRcrd->rdata.ipv6Address[0]),
                  MG_IPV6_ADDRLEN);
#endif /* IPV6_SUPPORTED */
      }

      if (loopIdx >= CM_INET_IPV6ADDR_SIZE)
         break;
   }

   /* Process the Resolution response */
   mgRcvDnsRslvCfm (peer, &addrTbl, port, ttl);

   RETVALUE(ROK);

} /* end of mgRcvDnsResponse () */

#endif /* CM_DNS_LIB */




/*
*
*       Fun:   mgSendDnsRslvReq
*
*       Desc:  This function sends a request to DNS for resolving a domain name
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: This function calls upon common DNS library to resolve if it can
*              be used; else it uses cmGetHostByName()
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgSendDnsRslvReq
(
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
U8                 *hostName           /* Domain Name to be resolved */
)
#else
PUBLIC S16 mgSendDnsRslvReq (peer, hostName)
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
U8                 *hostName;          /* Domain Name to be resolved */
#endif

{
   S16             ret;                /* Return Value */
   U8              idx;                /* Timer Index */
   MgTSAPCb        *tsap;              /* TSAP Control Block */
   U32             ttl;                /* Time to Live Value */
   U8              resType;            /* Resolution Request to be done? */
   CmInetIpAddrArr ipAddrTbl;          /* Address Table */

#ifdef CM_DNS_LIB 
   MgDnsInfo       *dnsInfo;           /* DNS Information */
   CmDnsQueryInfo  dnsQuery;           /* Query Structure */
   MgDnsTxFuncParam reqParam;          /* DNS Request Parameters */
#endif /* CM_DNS_LIB */


   TRC2(mgSendDnsRslvReq)


   /* Stop TTL time if running */
   idx = MG_TTL_TMR - MG_PEER_TMR_BASE;
   if (peer->mntInfo.tmr[idx].tmrEvnt == MG_TTL_TMR)
      mgStopTmr(MG_TTL_TMR, (PTR)peer, &(peer->mntInfo.tmr[idx]));


   /*
    *   The following tsap is for communicating with the DNS
    *   whereas the peer->tsap is the TSAP related to the peer
    */

   tsap    = mgCb.tSAPLst[mgCb.dnsTsap];   /*  add checks? */

   resType = 0;
   cmMemset((U8 *) &(ipAddrTbl), 0, sizeof(CmInetIpAddrArr));

   if ((mgCb.genCfg.resOrder == LMG_RES_IPV4) || 
       (mgCb.genCfg.resOrder ==LMG_RES_IPV4_IPV6))
   {
      resType = CM_INET_IPV4ADDR_TYPE;
#ifdef CM_DNS_LIB 
      dnsQuery.qType    = CM_DNS_QTYPE_A;
#endif /* CM_DNS_LIB */
   }
   else
   {
#ifdef IPV6_SUPPORTED
      /* Resolution order is IPV6 first and possibly IPV4 later */
      resType = CM_INET_IPV6ADDR_TYPE;
#ifdef CM_DNS_LIB 
      dnsQuery.qType    = CM_DNS_QTYPE_AAAA;
#endif /* CM_DNS_LIB */
#endif /* IPV6_SUPPORTED */
   }

   /*
    * If this is first resolution request for peer; do it as per
    * resolution order
    */
   if (peer->mntInfo.resOrder == MG_NONE)
   {
      peer->mntInfo.resOrder = resType;
      ipAddrTbl.type = resType;
   }
   else
   if ((peer->mntInfo.resOrder == LMG_RES_IPV4) &&
         (mgCb.genCfg.resOrder == LMG_RES_IPV4_IPV6))
   {
#ifdef IPV6_SUPPORTED
      peer->mntInfo.resOrder = LMG_RES_IPV6;
      ipAddrTbl.type         = CM_INET_IPV6ADDR_TYPE;
#ifdef CM_DNS_LIB 
      dnsQuery.qType         = CM_DNS_QTYPE_AAAA;
#endif /* CM_DNS_LIB */
#endif /* IPV6_SUPPORTED */
   }
   else
   if ((peer->mntInfo.resOrder == LMG_RES_IPV6) &&
         (mgCb.genCfg.resOrder == LMG_RES_IPV6_IPV4))
   {
      peer->mntInfo.resOrder = LMG_RES_IPV4;
      ipAddrTbl.type         = CM_INET_IPV4ADDR_TYPE;
#ifdef CM_DNS_LIB 
      dnsQuery.qType         = CM_DNS_QTYPE_A;
#endif /* CM_DNS_LIB */
   }
#if (ERRCLASS & ERRCLS_DEBUG)
   else
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG043, 0,
                  "[MGCP] mgSendDnsRslvReq: Invalid Order\n");
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */


   /* If DNS is not active, return */
   if (tsap->dnsInfo.dnsState != MG_DNS_STATE_UP)
   {
      peer->mntInfo.resOrder = MG_NONE;
      RETVALUE(RFAILED);
   }
   
       
   /* If INET is to be used */
   if (tsap->tsapCfg.reCfg.dnsCfg.dnsAccess != LMG_DNS_USE_DNSLIB)
   {
      U16              portNum;        /* Port Number */
      MgNetAddrTbl     addrTbl;        /* Mg specific addr table */

      addrTbl.count   = 0;

      /* Use cmGetHostByName to get list of addresses*/
      ret = cmInetGetIpNodeByName ((S8 *)hostName, &ipAddrTbl);

      /* Convert Data structure from CmInetIpAddrAddr to MgNetAddrTbl */
      mgCnvrtAddrTbl(&ipAddrTbl, &addrTbl);

      /* Call the DNS Receive Function */
      portNum = ((mgCb.genCfg.entType == LMG_ENT_GC) ? 
                  MG_DEFAULT_MG_PORT:MG_DEFAULT_MGC_PORT);

      ttl = 0;

#ifdef GCP_MGCP
      if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
      {
        if (peer->mgcpInfo.ttl != 0)
          ttl = peer->mgcpInfo.ttl;
        else
          ttl = peer->tsap->ttl;
      }
#endif /* GCP_MGCP */

      mgRcvDnsRslvCfm(peer, &addrTbl, portNum, ttl);

      RETVALUE (ret);
   }

#ifdef CM_DNS_LIB 
   /* if DNS library is to be used */
   dnsInfo = &(tsap->dnsInfo);

   if (dnsInfo->dnsCb == NULLP || 
       dnsInfo->dnsCb->state != CM_DNS_CB_OK2USE)
   {
      peer->mntInfo.resOrder = MG_NONE;
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG044, 0,
                   "[MGCP] mgSendDnsRslvReq():DNS Control Block in error \n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }

   /* Fill information for DNS query */
   dnsQuery.qclass   = CM_DNS_QCLASS_IN;
   dnsQuery.service  = CM_DNS_NONE;
   dnsQuery.protocol = CM_DNS_PROTOCOL_UDP;

   /* 
    * Add explicit typecast to remove warnings.
    */
   dnsQuery.qNameLen = (U8)(cmStrlen(peer->accessInfo.name));
   cmMemcpy((U8 *)dnsQuery.qName, (U8 *)peer->accessInfo.name, 
            cmStrlen(peer->accessInfo.name));



   /* Fill Parameters to be used in mgSndRslvReqToDns() */
   reqParam.srvr = dnsInfo->dnsLstnr;
   reqParam.peer  = peer;


   /* Call upon common DNS Library to resolve */
   if ((cmDnsGenRslvReq(dnsInfo->dnsCb, (Ptr)&(reqParam),
                            &dnsQuery, (Ptr) peer, &(peer->dnsReqId),
                            &(tsap->tsapCfg.memId))) != ROK)
   {
      peer->mntInfo.resOrder = MG_NONE;
      RETVALUE(RFAILED);
   }
   else
   {
      RETVALUE(ROK);
   }
#else
   RETVALUE(ROK);
#endif /* CM_DNS_LIB */


} /* mgSendDnsRslvReq () */


/******************************************************************************/
/*                     Upper Interface Coordinating Function                  */
/******************************************************************************/


/*
*
*       Fun:   mgRmvPeerAssoc
*
*       Desc:  This function processes the MEGACO transaction received
*              service user
*
*       Ret:   MGT_NONE              - Peer Association Removed
*              MGT_ERR_INVALID_PEER  - Peer Not Found
*
*       Notes: Transaction could be a new command or response to
*              a command.
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgRmvPeerAssoc
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgtCntrl         *cntrl              /* cntrl block */
)
#else
PUBLIC S16 mgRmvPeerAssoc(ssap, cntrl)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgtCntrl         *cntrl;             /* cntrl block */
#endif
{
   MgPeerCb        *peer;              /* Peer Control Block */

#ifdef GCP_MGCO
#ifdef GCP_MG
   U8              state;              /* peer state */    
   U8              protocol;           /* protocol type of peer */
   MgPeerCb        *newPeer;           /* New Peer Control Block */
   CmLList         *node;              /* Linked List Node */
   S16             ret;                /* Return Value */
   SpId            sapId;              /* SSAP Id */
   U8              method;             /* new local variable */
#endif /* GCP_MG */
#endif /* GCP_MGCO */

   TRC2(mgRmvPeerAssoc);

   /* Locate Peer */
   if ((peer = mgLocatePeer(&cntrl->peerInfo, ssap)) == NULLP)
   {
     RETVALUE(MGT_ERR_INVALID_PEER);
   }
  
   if (ssap->suId != peer->ssap->suId)
   {
     RETVALUE(MGT_ERR_INVALID_PEER);
   }

#ifdef GCP_MGCO
#ifdef GCP_MG
   state = peer->state; 
   protocol = peer->mntInfo.protocolType;
#endif /* GCP_MG */
#endif /* GCP_MGCO */

   if (cntrl->u.dura > 0)
   {
     /* 
      * if duration is not 0, start the delete peer timer for the given
      * duration 
      */
     mgStartTmr(MG_DEL_PEER_TMR, (cntrl->u.dura), (PTR)peer,
                &(peer->mntInfo.tmr[MG_DEL_PEER_TMR - MG_PEER_TMR_BASE]));
#ifdef ZG
     peer->delPeerTmr = TRUE;
     zgRtUpd(ZG_CBTYPE_PEER, (Ptr)(peer), CMPFTHA_UPDTYPE_SYNC, 
        CMPFTHA_ACTN_MOD);
#endif /* ZG */
     RETVALUE(MGT_NONE);
   }
   else if(cntrl->u.dura == 0)
   {
      /* 
       * If duration given by the user is 0 it menas peer needs to be deleted
       * immediately 
       */
      mgDeletePeer (peer, LMG_EVENT_PEER_REMOVED, 
                   LMG_CAUSE_USER_DEL_PEER, FALSE);

      /* 
       * On the MG side for MEGACO if we are removing association with
       * MGC we need to try and re-establish connection with one of
       * the secondary MGCs on the list 
       */
#ifdef GCP_MGCO
#ifdef GCP_MG
      if ((protocol == LMG_PROTOCOL_MGCO) &&
         (mgCb.genCfg.entType == LMG_ENT_GW) &&
         (ssap->crntMgc == peer))
      {
         newPeer = NULLP;

         /* We need to try other peer in the list */
         if (state == LMG_PEER_STATE_ACTIVE)
         {         
            CM_LLIST_FIRST_NODE(&(ssap->peerLst), node);
            if (peer != (MgPeerCb *)node->node)
               ssap->crntMgc = NULLP;
         }

         /* Select a new peer */
         mgSelectPeer(&(newPeer), ssap);
         if (newPeer != NULLP)
         {
            /* Valid peer is found */
            /* Initiate service change on the new peer */
            if (state != LMG_PEER_STATE_ACTIVE)
            {
               /* If the peer MGC is being contacted again after
                * disconnection, send method as DISCONNECTED **/
               MG_OBTAIN_SVCCHG_METHOD(method, newPeer);

               /*
                *  Changed the ServiceChange reasone code in the service change
                *  message , when the request is send to a secondary  MGC 
                */
               ret = mgSendSrvcChng(newPeer, method,
                                    MG_SCRSN_COLD_BOOT, NULLP,
                                    LMG_INVALID_PEER_PORT,
                                    NULLP);
            }
            else
            {
               ret = mgSendSrvcChng(newPeer, MGT_SVCCHGMETH_FAILOVER,
                                    MG_SCRSN_MGC_IMPN_FAIL, NULLP,
                                    LMG_INVALID_PEER_PORT,
                                    NULLP);
            }
         }

         /* 
         * If no MGCs are available in the list then indicate to the layer
         * manager 
         */
         if ((newPeer == NULLP) || (ret != ROK))
         {
            /* No more MGCs available Should inform LM */
            sapId = ssap->ssapCfg.sSAPId;

			if (ssap->alarmIndSent == FALSE)  /*add "if" by cdw on 2006.9.28*/
				{
            		/* Send Status Indication to the layer manager */
            		mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                        		LMG_EVENT_ALL_MGC_FAILED, LCM_CAUSE_UNKNOWN, 
                        		LMG_ALARMINFO_SAP, (Ptr)&(sapId), sizeof(SpId), 
                        		LMG_ALARMINFO_INVSAPID);
					ssap->alarmIndSent=TRUE;   /*add this line by cdw*/
				}
            ssap->crntMgc = NULLP;
            /* assign crntMgc to the first node in the peerList */
            mgSelectPeer(&(ssap->crntMgc), ssap);
            RETVALUE(MGT_NONE);
         }
         ssap->crntMgc = newPeer;
#ifdef ZG
         /* send SSAP update */
         zgRtUpd(ZG_CBTYPE_SSAP, (Ptr)ssap, CMPFTHA_UPDTYPE_SYNC, 
                                                       CMPFTHA_ACTN_MOD);
#endif /* ZG */
      }
#endif /* GCP_MG */
#endif /* GCP_MGCO */
   }

   RETVALUE(MGT_NONE);

} /* end of mgRmvPeerAssoc() */


/*
*
*       Fun:   mgCancelRmvAssoc
*
*       Desc:  Function stops a earlier remove peer association primitive, if
*              possible.
*
*       Ret:   MGT_NONE                - Requesed action completed successfully
*              MGT_ERR_INVALID_PEER    - Peer Not Found
*              MGT_ERR_PEER_ASSOC_RMVD - Peer association removed already
*           
*
*       Notes: Function stops the delete peer timer started earlier
*              if still running, i.e the peer has not been deleted yet, 
*              If timer is not running, peer has already been deleted so
*              it return error.
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgCancelRmvAssoc
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgtCntrl         *cntrl              /* cntrl block */
)
#else
PUBLIC S16 mgCancelRmvAssoc(ssap, cntrl)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgtCntrl         *cntrl;             /* cntrl block */
#endif
{
   U16             idx;                /* Index */
   MgPeerCb        *peer;              /* Peer Control Block */

   TRC2(mgCancelRmvAssoc)

   /* Locate peer */
   if ((peer = mgLocatePeer(&cntrl->peerInfo, ssap)) == NULLP)
   {
      RETVALUE(MGT_ERR_INVALID_PEER);
   }
  
   if (ssap->suId != peer->ssap->suId)
   {
      RETVALUE(MGT_ERR_INVALID_PEER);
   }

   /* If Timer is running , stop timer */
   idx = MG_DEL_PEER_TMR - MG_PEER_TMR_BASE;

   if (peer->mntInfo.tmr[idx].tmrEvnt != TMR_NONE) 
   {
      mgStopTmr(MG_DEL_PEER_TMR, (PTR)peer, &(peer->mntInfo.tmr[idx]));
#ifdef ZG
      peer->delPeerTmr = FALSE;
      zgRtUpd(ZG_CBTYPE_PEER, (Ptr)(peer), CMPFTHA_UPDTYPE_SYNC,
         CMPFTHA_ACTN_MOD);
#endif /* ZG */
   }
   else
     RETVALUE(MGT_ERR_PEER_ASSOC_RMVD);

   RETVALUE(MGT_NONE);
 
} /* End of mgCancelRmvAssoc */



/*
*
*       Fun:   mgRmvPeerTrans
*
*       Desc:  This function removes transaction(s) specified by the user,
*              from a particular peer
*
*       Ret:   ROK - SUCCESS;
*              RFAILED - FAILURE
*
*       Notes:
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgRmvPeerTrans
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgtCntrl         *cntrl              /* cntrl block */
)
#else
PUBLIC S16 mgRmvPeerTrans(ssap, cntrl)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgtCntrl         *cntrl;             /* cntrl block */
#endif
{
   U32             loopIdx;            /* Loop Index */
   S16             ret;                /* return Value */
   MgTxTransIdEnt  *txCb;              /* Outgoing Transaction Control Block */
   MgRxTransIdEnt  *rxCb;              /* Incoming Transaction Control Block */
   MgPeerCb        *peer;              /* Peer Control Block */
   MgTransInfo     *transInfo;         /* TransInfo */
#ifdef ZG_DFTHA
   ZgProcUpdInfo   updInfo;            /* update info */
#endif /* ZG_DFTHA */

   TRC2(mgRmvPeerTrans);

   ret = MGT_NONE;

   if ((peer = mgLocatePeer(&cntrl->peerInfo, ssap)) == NULLP)
   {
     RETVALUE(MGT_ERR_INVALID_PEER);
   }

   transInfo = &(cntrl->u.transInfo);

   switch (transInfo->transType)
   {
      case MGT_SINGLE_TRANS:
      {
         transInfo->lastTransId.pres = PRSNT_NODEF;
         transInfo->lastTransId.val  = transInfo->firstTransId.val;

         /* Fall Through into RANGE Processing */
      }

      case MGT_RANGE_TRANS:
      {
         if (transInfo->lastTransId.pres == NOTPRSNT)
            RETVALUE(MGT_ERR_INVALID_TRANS);

         /* Search for transaction on peer lists and delete it */
         for (loopIdx = transInfo->firstTransId.val;
              loopIdx <= transInfo->lastTransId.val; loopIdx ++)
         {
            /* Search for peer in incoming txn list */
            if (transInfo->transDir == MGT_INCOMING_TXN)
            {
               if ((cmHashListFind(&(peer->inTransLst), (U8 *)&loopIdx,
                                 MG_TRANSID_LEN, MG_HASH_SEQNMB_DEF,
                                 (PTR *)&rxCb)) == ROK)
               {
                  mgAbortRxTrans(peer, rxCb, MG_IGNORE);
               }
               else
                  ret = MGT_ERR_INVALID_TRANS;
            }
            else
            if (transInfo->transDir == MGT_OUTGOING_TXN)
            {
               if ((cmHashListFind(&(peer->outTransLst), (U8 *)&loopIdx,
                                  MG_TRANSID_LEN,MG_HASH_SEQNMB_DEF,
                                  (PTR *)&txCb)) == ROK)
               {
                  mgAbortTxTrans(peer, txCb, MG_IGNORE);
               }
               else
                  ret = MGT_ERR_INVALID_TRANS;
            }
         }
#ifdef ZG_DFTHA
         /* Now generate RtUpd ..all the shadows will remove there txns */
         updInfo.procType = ZG_PROCTYPE_RMV_TRANS;
         updInfo.u.cntrlTrans.peerId = peer->accessInfo.peerId;
         updInfo.u.cntrlTrans.newPeerId = MG_INVALID_PEERID;
         updInfo.u.cntrlTrans.info = (*transInfo);
         zgRtProcUpd(&updInfo, CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);
#endif /* ZG_DFTHA */
         /* 
            * If it is single transaction case, return from here to preserve
            * the value of "ret" in case of failure
            */
         if (transInfo->transType == MGT_SINGLE_TRANS)
            RETVALUE(ret);
      }
      break;

      case MGT_ALL_TRANS:      
      {
         /* Remove all Transaction for this peer */
         mgRemoveAllTxn(MG_IGNORE, peer);
#ifdef ZG
         peer->removeAllTxns = TRUE;
         /* Send update for peer */
         zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
#endif /* ZG */
      }
      break;
   }

   RETVALUE(MGT_NONE);

} /* end of mgRmvPeerTrans() */



/*
*
*       Fun:   mgMovePeer
*
*       Desc:  Function moves a peer from control of one SSAP to  another
*
*       Ret:   ROK - SUCCESS;
*              RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMovePeer
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgtCntrl         *cntrl              /* cntrl block */
)
#else
PUBLIC S16 mgMovePeer(ssap, cntrl)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgtCntrl         *cntrl;             /* cntrl block */
#endif
{
   MgPeerCb        *peer;              /* Peer Control Block */
#ifdef ZG
   ZgProcUpdInfo   updInfo;            /* update info */
#endif /* ZG */

   TRC2(mgMovePeer);

   /*
    * Since mgMovePeer is a MGC side function, we can safely pass ssap as
    * NULLP inside mgLocatePeer.
    */

   /* Locate Peer */
   if ((peer = mgLocatePeer(&cntrl->peerInfo, NULLP)) == NULLP)
   {
     RETVALUE(MGT_ERR_INVALID_PEER);
   }
  
   /* Delete peer from original ssap list */
   cmLListDelFrm(&(peer->ssap->peerLst), &(peer->ssapPeerLstNode));

   /* Add peer to new SSAP's peer list */
   cmLListAdd2Tail (&(ssap->peerLst), &(peer->ssapPeerLstNode));
   peer->ssap = ssap;
#ifdef ZG
   /* Now send update to all shadows..shadows will do same processing 
    * Note -> This is required in case of pure FT also*/
   updInfo.procType = ZG_PROCTYPE_MOVE_PEER;
   updInfo.u.movePeer.peerId = peer->accessInfo.peerId;
   updInfo.u.movePeer.newSpId = ssap->ssapCfg.sSAPId;
   zgRtProcUpd(&updInfo, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
   
   RETVALUE(MGT_NONE);

} /* end of mgMovePeer() */




/*
*
*       Fun:   mgMoveTrans
*
*       Desc:  Move transactions from one peer to another 
*
*       Ret:   MGT_NONE             - Success
*              MGT_ERR_INVALID_PEER - Peer not located
*
*
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMoveTrans
(
MgMgtCntrl         *cntrl,            /* cntrl block */
MgSSAPCb           *ssap              /* SSAP of old peer */
)
#else
PUBLIC S16 mgMoveTrans(cntrl, ssap)
MgMgtCntrl         *cntrl;             /* cntrl block */
MgSSAPCb           *ssap;              /* SSAP of old peer */
#endif
{
   S16             ret;                /* Return Value */
   U16             loopIdx;            /* Loop Index */
   MgPeerCb        *peer;              /* Peer Control Block */
   MgPeerCb        *newPeer;           /* New peer Control Block */
   MgTransInfo     *transInfo;         /* Transaction Information */
#ifdef ZG_DFTHA
   ZgProcUpdInfo   updInfo;            /* update info */
#endif /* ZG_DFTHA */

   TRC2(mgMoveTrans)

   ret       = MGT_NONE;
   transInfo = &(cntrl->u.moveTransInfo.transInfo);
   peer      = NULLP;
   newPeer   = NULLP;

   /* Locate  peer from which txns are supposed to be moved*/
   if ((peer = mgLocatePeer(&cntrl->peerInfo, ssap)) == NULLP)
   {
     RETVALUE(MGT_ERR_INVALID_PEER);
   }

   /* locate peer to which txns are supposed to be moved */
   if ((newPeer = mgLocatePeer(&cntrl->u.moveTransInfo.newPeer, ssap)) == NULLP)
   {
     RETVALUE(MGT_ERR_INVALID_PEER);
   }

   /* Find and move txn(s) */
   switch (transInfo->transType)
   {
      case MGT_SINGLE_TRANS:
      {
         ret = mgFindAndMoveTrans(peer, newPeer, transInfo->firstTransId.val,
                                  transInfo->transDir);
      }
      break;

      case MGT_RANGE_TRANS:
      {
         if (cntrl->u.moveTransInfo.transInfo.lastTransId.pres == NOTPRSNT)
            RETVALUE(MGT_ERR_INVALID_TRANS);

         for (loopIdx = cntrl->u.transInfo.firstTransId.val;
              loopIdx <= cntrl->u.transInfo.lastTransId.val; loopIdx ++)
         {
            mgFindAndMoveTrans(peer, newPeer, loopIdx, transInfo->transDir);
         }
      }
      break;

      case MGT_ALL_TRANS:
      {
         mgMoveAllTxn(peer, newPeer, MG_USER);
      }
      break;
   }
#ifdef ZG_DFTHA
   /* Send runtime update to all shadows to move all txns */
   updInfo.procType = ZG_PROCTYPE_MOVE_TRANS;
   updInfo.u.cntrlTrans.peerId = peer->accessInfo.peerId;
   updInfo.u.cntrlTrans.newPeerId = newPeer->accessInfo.peerId;
   updInfo.u.cntrlTrans.info = (*transInfo);
   updInfo.u.cntrlTrans.source = MG_USER;
   zgRtProcUpd(&updInfo, (U8)CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);
#endif /* ZG_DFTHA */

   RETVALUE(ret);

} /* end of mgMoveTrans() */



/*
*
*       Fun:   mgFindAndMoveTrans
*
*       Desc:  Move the specified transactions(based on txn id) from
*              one peer list to another
*
*       Ret:   MGT_NONE               - Success
*              MGT_ERR_INVALID_TRANS  - Specified txn not found
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgFindAndMoveTrans
(
MgPeerCb           *peer,              /* Old peer cb */
MgPeerCb           *newPeer,           /* Peer where txns are to be moved */
MgTransId          transId,            /* Transaction id */
U8                 transDir            /* Transaction Direction */
)
#else
PUBLIC S16 mgFindAndMoveTrans(peer, newPeer, transId, transDir)
MgPeerCb           *peer;              /* Old peer cb */
MgPeerCb           *newPeer;           /* Peer where txns are to be moved */
MgTransId          transId;            /* Transaction id */
U8                 transDir;           /* Transaction Direction */
#endif
{
   MgTxTransIdEnt  *txCb;              /* Pending Transactions */
   MgRxTransIdEnt  *rxCb;              /* Pending Transaction */
   S16             ret;                /* return Value */

   TRC2(mgFindAndMoveTrans)

   ret = MGT_NONE;

   if (transDir == MGT_INCOMING_TXN)
   {
      /* Search for txn in incoming txn list,if found move it to the new peer */
      if ((cmHashListFind(&(peer->inTransLst), (U8 *)&transId, MG_TRANSID_LEN,
                        MG_HASH_SEQNMB_DEF, (PTR *)&rxCb)) == ROK)
      {
         ret = mgMoveInTxn(peer, newPeer, rxCb, MGT_SINGLE_TRANS);
      }
      else
      {
         RETVALUE(MGT_ERR_INVALID_TRANS);
      }

   } /* if incoming txn */
   else 
   if (transDir == MGT_OUTGOING_TXN)
   {
      /* Search for txn in outgoing txn list,if found move it to the new peer */
      if ((cmHashListFind(&(peer->outTransLst), (U8 *)&transId, MG_TRANSID_LEN,
                          MG_HASH_SEQNMB_DEF, (PTR *)&txCb)) == ROK)
      {
         ret = mgMoveOutTxn(peer, newPeer, txCb, MG_USER, MGT_SINGLE_TRANS);
      }
      else
         RETVALUE(MGT_ERR_INVALID_TRANS);
   } 
   else
      ret = MGT_ERR_INVALID_TRANS;

   RETVALUE(ret);

} /* end of mgFindAndMoveTrans() */



/*
*
*       Fun:   mgMoveInTxn
*
*       Desc:  Move incoming txn from old peer to new peer
*
*       Ret:   MGT_NONE               - Success
*              MGT_ERR_RSRC_UNAVAIL   - Hash List Insertion Failed.
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgMoveInTxn
(
MgPeerCb           *oldPeer,           /* Old Peer */
MgPeerCb           *newPeer,           /* destination Peer */
MgRxTransIdEnt     *inTxnCb,           /* Incoming Txn Control Block */
U8                 transType           /* Single Transaction / All trans */
)
#else
PUBLIC S16 mgMoveInTxn(oldPeer, newPeer, inTxnCb, transType)
MgPeerCb           *oldPeer;           /* Old Peer */
MgPeerCb           *newPeer;           /* destination Peer */
MgRxTransIdEnt     *inTxnCb;           /* Incoming Txn Control Block */
U8                 transType;          /* Single Transaction / All trans */
#endif
{

   S16             ret;                /* return Value */

   TRC2(mgMoveInTxn)

   ret = MGT_NONE;
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
   /* Send update del inTxnCb to stand by and del mapping in active */
   zgRtUpd(ZG_CBTYPE_TXN_RX,(Ptr)inTxnCb,CMPFTHA_UPDTYPE_NORMAL,CMPFTHA_ACTN_DEL);
#endif /* ZG_TXN_LVL_UPD */
   zgDelMapping(ZG_CBTYPE_TXN_RX, (Ptr)inTxnCb);
#endif /* ZG */
   cmHashListDelete(&(oldPeer->inTransLst), (PTR) inTxnCb);                 
                  
   /* Insert txn into new peers hashlist */
   if ((cmHashListInsert (&(newPeer->inTransLst), (PTR) inTxnCb,            
                           (U8 *)&(inTxnCb->transId), MG_TRANSID_LEN)) != ROK) 
   {                                                                          
      /* if unable to insert, abort txn and inform the user */
      if (inTxnCb->mBuf != NULLP)                                             
         mgPutMsg(inTxnCb->mBuf);                                               
                                                                              
      MG_STOP_INTXN_TMRS(inTxnCb);                                            

      mgIndicateAbortTxnToUsr(MGT_ERR_RSRC_UNAVAIL, inTxnCb->transId,         
                              oldPeer);                                       

      mgDeAlloc((Data *)inTxnCb, sizeof(MgRxTransIdEnt));

      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }                                                                          
   else                                                                       
   {
      /* If txn was inserted in the new peers list, update txn parameters */
      inTxnCb->peer = newPeer;
      MG_FILL_TPTADDR_FRM_NETADDR(&(inTxnCb->tptAddr),
                                  &(newPeer->accessInfo.peerAddrTbl.netAddr[0]));

      MG_FILL_TPTADDR_PORT(&(inTxnCb->tptAddr), newPeer->accessInfo.remotePort);

#ifdef GCP_MGCO
      if ((newPeer->mntInfo.protocolType == LMG_PROTOCOL_MGCO) &&
         (newPeer->accessInfo.transportType == LMG_TPT_TCP))                
      {                                                                        
         inTxnCb->suConnId = newPeer->mgcoInfo.nxtUseConn->suConnId;         
      }         
#endif /* GCP_MGCO */

#ifdef ZG
      ZG_INIT_RSETID_IN_MAPCB(&(inTxnCb->mapCb));
      zgAddMapping(ZG_CBTYPE_TXN_RX,(Ptr)inTxnCb);
#ifdef ZG_TXN_LVL_UPD
      zgRtUpd(ZG_CBTYPE_TXN_RX,(Ptr)inTxnCb,
         CMPFTHA_UPDTYPE_NORMAL,CMPFTHA_ACTN_ADD);
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */
   } 

   /* If txn is queued move it to the new peers queue */
   if ((inTxnCb->state == MG_INTXN_RSP_QUEUED) && 
      (transType != MGT_ALL_TRANS))
   {
      ret = mgMoveTransFromQ(inTxnCb->transId, oldPeer, newPeer, 
                             MGT_SINGLE_TRANS);

      if (ret != MGT_NONE)
      {      
         inTxnCb->state = MG_NONE;
         mgAbortRxTrans(oldPeer, inTxnCb,MGT_ERR_INVALID_TRANS);
         RETVALUE(MGT_ERR_INVALID_TRANS);
      }
   }

   RETVALUE(ret);

} /* End of  mgMoveInTxn */


/*
*
*       Fun:   mgMoveOutTxn
*
*       Desc:  Move outgoing txn from old peer to new peer. 
*              
*
*       Ret:   MGT_NONE               - Success
*              MGT_ERR_RSRC_UNAVAIL   - Hash List Insertion Failed.
*
*       Notes: If move is an internal operation, donot reset the retx cnt
*              else reset it.
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgMoveOutTxn
(
MgPeerCb           *oldPeer,           /* Old Peer */
MgPeerCb           *newPeer,           /* destination Peer */
MgTxTransIdEnt     *outTxnCb,          /* Outgoing Txn Control Block */
U8                 source,             /* Initiated by user/ internal */
U8                 transType          /* Single Transaction / All trans */
)
#else
PUBLIC S16 mgMoveOutTxn(oldPeer, newPeer, outTxnCb, source, transType)
MgPeerCb           *oldPeer;           /* Old Peer */
MgPeerCb           *newPeer;           /* destination Peer */
MgTxTransIdEnt     *outTxnCb;          /* Outgoing Txn Control Block */
U8                 source;             /* Initiated by user/ internal */
U8                 transType;          /* Single Transaction / All trans */
#endif
{
   S16             ret;                /* return Value */
   CmTptAddr       remoteAddr;         /* Remote Address */
   MgTptSrvr       *srvr;              /* Transport Server */
   Bool            snd;

   TRC2(mgMoveOutTxn)

   ret = MGT_NONE;
   snd = FALSE;

   /* initialise remoteAddr to zero */
   cmMemset((U8 *)&remoteAddr,0,sizeof(CmTptAddr));

   /* Delete from hash list */                                           
   cmHashListDelete(&(oldPeer->outTransLst), (PTR) outTxnCb);          

   /* Insert into new peers outgoing list */
   if ((cmHashListInsert (&(newPeer->outTransLst), (PTR) outTxnCb,     
                           (U8 *)&(outTxnCb->transId),                   
                           MG_TRANSID_LEN)) != ROK)                       
   {
      /* if insertion fails, abort txn and inform user */
      mgAbortTxTrans(oldPeer, outTxnCb,MGT_ERR_RSRC_UNAVAIL);
      RETVALUE(MGT_ERR_RSRC_UNAVAIL);
   }                                                                     
   else
   {                                    
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
      /* Send update del outTxnCb to stand by and del mapping in active */
      zgRtUpd(ZG_CBTYPE_TXN_TX,(Ptr)outTxnCb,
         CMPFTHA_UPDTYPE_NORMAL,CMPFTHA_ACTN_DEL);
#endif /* ZG_TXN_LVL_UPD */
      zgDelMapping(ZG_CBTYPE_TXN_TX, (Ptr)outTxnCb);
#endif /* ZG */
      /* if insertion is successful update txn params */
      outTxnCb->peer = newPeer;    
      
      /* 
       * if move was initiated by the user reset retx counter. &
       * retransmit if necessary 
       */
      if (source == MG_USER)
      {
         outTxnCb->retxCnt = 0;
         outTxnCb->retxOnIpAddr = FALSE;
         outTxnCb->everRetxed   = FALSE;
         outTxnCb->addrTbl.count = 1;
         
         /* 
          * newPeer should always have the accessInfo.peerAddr. No
          * need to get it from peerInfo. Deleted the code which obtains this
          * address from peerInfo.
          */
         if(newPeer->accessInfo.peerAddrTbl.count > MG_NONE)
         {
            CmNetAddr *netAddr = &(newPeer->accessInfo.peerAddrTbl.netAddr[0]);

            outTxnCb->remotePort = newPeer->accessInfo.remotePort;
            cmMemcpy((U8 *)&(outTxnCb->addrTbl.netAddr[0]), 
                     (CONSTANT U8 *)netAddr, sizeof(CmNetAddr));
         }
         else
            RETVALUE(MGT_ERR_RSRC_UNAVAIL);

         if(LMG_PROTOCOL_MGCP == newPeer->mntInfo.protocolType)
         {
#ifdef GCP_MGCP
         /* if peer is active retransmit else queue */
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
            if ((newPeer->state == LMG_PEER_STATE_ACTIVE) &&
                (outTxnCb->u.txBufInfo->mBuf != NULLP))
#else
            if ((newPeer->state == LMG_PEER_STATE_ACTIVE) &&
                (outTxnCb->u.mBuf != NULLP))
#endif /* GCP_VER_1_3 && GCP_2705BIS */
            {
               snd = TRUE;
            }
#endif /* GCP_MGCP */
         }
         else
         {
#ifdef GCP_MGCO 
            if ((newPeer->state == LMG_PEER_STATE_ACTIVE) &&
                (outTxnCb->u.mBuf != NULLP))
            {
               snd = TRUE;
            }
#endif /* GCP_MGCO */
         }

         if(TRUE == snd)   
         {
#ifdef ZG
            ZG_INIT_RSETID_IN_MAPCB(&(outTxnCb->mapCb));
            zgAddMapping(ZG_CBTYPE_TXN_TX,(Ptr)outTxnCb);
#ifdef ZG_TXN_LVL_UPD
            zgRtUpd(ZG_CBTYPE_TXN_TX,(Ptr)outTxnCb,
               CMPFTHA_UPDTYPE_NORMAL,CMPFTHA_ACTN_ADD);
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */

            
   
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
            if ((newPeer->accessInfo.transportType != LMG_TPT_SCTP) &&
               (newPeer->accessInfo.transportType != LMG_TPT_MTP3))
#endif /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
           
            {
               srvr = mgGetSendSrvr(newPeer->ssap, newPeer);
            
               if (srvr == NULLP)
               {
                  mgAbortTxTrans(newPeer, outTxnCb,MGT_ERR_RSRC_UNAVAIL);
                  RETVALUE(MGT_ERR_RSRC_UNAVAIL);
               }
            }

            if(outTxnCb->retxTmr.tmrEvnt != TMR_NONE)                          
               mgStopTmr (MG_RETX_TMR, (PTR) outTxnCb, &(outTxnCb->retxTmr));  
            
            outTxnCb->state = MG_OUTTXN_TXN_SENT;
            SGetSysTime(&(outTxnCb->timeStamp));   

            mgStartTmr (MG_RETX_TMR,(newPeer->mntInfo.rto/mgCb.genCfg.timeRes), 
                        (PTR) outTxnCb, &(outTxnCb->retxTmr));

            if(LMG_PROTOCOL_MGCP == newPeer->mntInfo.protocolType)
            {
#ifdef GCP_MGCP
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))

#ifdef    GCP_PROV_SCTP
               MG_TRANSMIT_PDU(newPeer, newPeer->assocCb, NULLP, FALSE,
                               srvr, &remoteAddr, 
                               outTxnCb->u.txBufInfo->mBuf);
#else     /* GCP_PROV_SCTP */
               MG_TRANSMIT_PDU(newPeer, srvr, &remoteAddr, 
                               outTxnCb->u.txBufInfo->mBuf);
#endif    /* GCP_PROV_SCTP */

#else

#endif /* GCP_VER_1_3 && GCP_2705BIS */
#endif /* GCP_MGCP */
            }
            else
            {
#ifdef GCP_MGCO

#ifdef    GCP_PROV_SCTP
               /*  Pass assoc & strm below */
               MG_TRANSMIT_PDU(newPeer, newPeer->assocCb, NULLP, FALSE, srvr,
                               &remoteAddr, outTxnCb->u.mBuf);
#else     /* GCP_PROV_SCTP */
               MG_TRANSMIT_PDU(newPeer, srvr, &remoteAddr, outTxnCb->u.mBuf);
#endif    /* GCP_PROV_SCTP */

#endif
            }
         }
         else
         {
            /* Queue Txn */
            outTxnCb->state = MG_OUTTXN_TXN_QUEUED; 
            outTxnCb->lnkLstNode.node = (PTR)outTxnCb;
            cmLListAdd2Tail(&(newPeer->transQ), &(outTxnCb->lnkLstNode));
#ifdef ZG
            ZG_INIT_RSETID_IN_MAPCB(&(outTxnCb->mapCb));
            zgAddMapping(ZG_CBTYPE_TXN_TX,(Ptr)outTxnCb);
#ifdef ZG_TXN_LVL_UPD
            zgRtUpd(ZG_CBTYPE_TXN_TX,(Ptr)outTxnCb,
               CMPFTHA_UPDTYPE_NORMAL,CMPFTHA_ACTN_ADD);
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */
         }

         RETVALUE(MGT_NONE);
      } /* if user initiated move */                                
#ifdef ZG
            ZG_INIT_RSETID_IN_MAPCB(&(outTxnCb->mapCb));
            zgAddMapping(ZG_CBTYPE_TXN_TX,(Ptr)outTxnCb);
#ifdef ZG_TXN_LVL_UPD
            zgRtUpd(ZG_CBTYPE_TXN_TX,(Ptr)outTxnCb,
               CMPFTHA_UPDTYPE_NORMAL,CMPFTHA_ACTN_ADD);
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */
   }

   /* if txn is queued move it from old peer's queue to new peer's queue */
   if ((outTxnCb->state == MG_OUTTXN_TXN_QUEUED) &&
      (transType != MGT_ALL_TRANS))
   {
      ret = mgMoveTransFromQ(outTxnCb->transId, oldPeer, 
                           newPeer, MGT_SINGLE_TRANS);
      
      if (ret !=MGT_NONE)
      {      
         outTxnCb->state = MG_NONE;
         mgAbortTxTrans(oldPeer, outTxnCb,MGT_ERR_INVALID_TRANS);
         RETVALUE(MGT_ERR_INVALID_TRANS);
      }
   }

   RETVALUE(ret);

} /* end of mgMoveOutTxn */



/*
*
*       Fun:   mgAuditPeerTxn
*
*       Desc:  Audit all the transactions present on a peer 
*
*       Ret:   MGT_NONE               : Audit completed
*              MGT_ERR_INVALID_PEER   : Peer not found
*
*       Notes: Transaction could be a new command or response to
*              a command.
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAuditPeerTxn
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgtAudit         *audit              /* audit block */
)
#else
PUBLIC S16 mgAuditPeerTxn(ssap, audit)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgtAudit         *audit;             /* audit block */
#endif
{
   MgPeerCb        *peer;              /* Peer Control Block */
   S16             ret;                /* Return Value */
   U16             i;                  /* Temporary Variable */
   U16             numTxn;             /* Number of Transactions */
   MgTxTransIdEnt  *txCb;              /* Outgoing Transaction Control Block */
   MgRxTransIdEnt  *rxCb;              /* Incoming Transaction Control Block */
#ifdef ZG_DFTHA
   ZgProcUpdInfo   updInfo;               /* update info */
#endif /* ZG_DFTHA */

   TRC2(mgAuditPeerTxn)

   /* Locate Peer */
   if ((peer = mgLocatePeer(&audit->peerInfo, ssap)) == NULLP)
     RETVALUE(MGT_ERR_INVALID_PEER);

   /* Initialise variables */
   i       = 0;
   ret     = MGT_NONE;
   numTxn  = 0;
   txCb    = NULLP;
   rxCb    = NULLP;

   if(peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
   {
#ifdef GCP_MGCP
      MG_COPY_PEERINFO_INTO_MGCPTXN(audit->peerInfo, peer);
#endif
   }
   else
   {
#ifdef GCP_MGCO
      MG_COPY_PEERINFO_INTO_MGCOMSG(audit->peerInfo, peer);
#endif
   }

   /* Initialise Variables for Audit Confirm */
   audit->auditInfo.moreTxn  = FALSE;

#ifdef ZG_DFTHA
   if(((zgChkCRsetStatus()) == TRUE))
   {
      /* send update to all shadows in blocking mode. all shadows will send 
       * audit cfm with moreTxn as True (always)..once Ack is rcvd from all 
       * shadows then Master will send audit cfm ..it will set moreTxn false 
       * if no more txn is there */
      updInfo.procType = ZG_PROCTYPE_AUDIT_REQ;
      updInfo.u.auditReq.peerId = peer->accessInfo.peerId;
      updInfo.u.auditReq.spId   = ssap->ssapCfg.sSAPId;
      zgRtProcUpd(&updInfo, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
      zgUpdPeer();
   }
#endif /* ZG_DFTHA */
   /* 
    * Get Incoming Transaction Information  & fill into audit structure
    * to be sent to the user
    */
   while ((cmHashListGetNext(&(peer->inTransLst), (PTR) rxCb,
                           (PTR *)&rxCb)) == ROK)
   {
#ifdef ZG
      if ((rxCb != NULLP) && (zgChkTxnRsetState(rxCb->mapCb.rsetId)))
#endif /* ZG */
      {
         numTxn++;

         audit->auditInfo.transStatus[i].transId     = rxCb->transId;
         audit->auditInfo.transStatus[i].transStatus = rxCb->state;
         audit->auditInfo.transStatus[i].transDir    = MGT_INCOMING_TXN;

         i++;

         /* 
          * if the max number of txn which can be sent in a audit cfm primitive
          * is reached send the cfm, reset the audit cfm structure and continue
          * with the audit process 
          */
         if (i == MGT_MAX_TXN)
         {
            audit->auditInfo.numTxn  = i;
            audit->auditInfo.moreTxn = TRUE;
            MgUiMgtAuditCfm(&ssap->suPst,ssap->suId, audit, ret);
            i=0;
         }
      } /* if rxCb not NULL */
   }

   /* Get Outgoing Transaction Information */
   while ((cmHashListGetNext(&(peer->outTransLst), (PTR) txCb,
                           (PTR *)&txCb)) == ROK)
   {
#ifdef ZG_DFTHA
      if ((txCb != NULLP) && (zgChkTxnRsetState(txCb->mapCb.rsetId)))
#endif /* ZG_DFTHA */
      {
         numTxn++;
         audit->auditInfo.transStatus[i].transId     = txCb->transId;
         audit->auditInfo.transStatus[i].transStatus = txCb->state;
         audit->auditInfo.transStatus[i].transDir    = MGT_OUTGOING_TXN;
    
         i++;

         /* 
          * if the max number of txn which can be sent in a audit cfm primitive
          * is reached send the cfm, reset the audit cfm structure and continue
          *  with the audit process 
          */

         if (i == MGT_MAX_TXN)
         {
            audit->auditInfo.numTxn  = i;
            audit->auditInfo.moreTxn = TRUE;
            MgUiMgtAuditCfm(&ssap->suPst,ssap->suId,audit, ret);
            i=0;
         }
      } /* if txCb not NULL */
   }

   /* mg008.105: even if no txn returned send   */
   /* Even no txn is returned send AuditCfm */
   
   /* if (numTxn == 0)
   {
     RETVALUE(MGT_NONE);
   } */

   if ((numTxn == 0) || ((i != 0) &&(i < MGT_MAX_TXN)))
   {
      audit->auditInfo.numTxn = i;
      audit->auditInfo.moreTxn = FALSE;
#ifdef ZG_DFTHA
      /* Shadows should always set moreTxn to True */
      if(!((zgChkCRsetStatus()) == TRUE))
      {
         audit->auditInfo.moreTxn = TRUE;
      }
#endif /* ZG_DFTHA */
      MgUiMgtAuditCfm(&ssap->suPst,ssap->suId,audit, ret);
   }

   RETVALUE(ret);

} /* end of mgAuditPeerTxn() */



/*
*
*       Fun:   mgResetRTO
*
*       Desc:  Reset Rto for a particular peer
*
*       Ret:   MGT_NONE             - Success
*              MGT_ERR_INVALID_PEER - Peer not located
*
*
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgResetRTO
(
MgPeerInfo         *peerInfo,          /* Peer Information */
MgSSAPCb           *ssap               /* Associated SAP */
)
#else
PUBLIC S16 mgResetRTO(peerInfo, ssap)
MgPeerInfo         *peerInfo;          /* Peer Information */
MgSSAPCb           *ssap;              /* Associated SAP */
#endif
{
   MgPeerCb        *peer;              /* Peer Control Block */
   U32             initRtt;            /* Retransmission timer seed */
#ifdef ZG
   ZgProcUpdInfo   updInfo;            /* update info */
#endif /* ZG */

   TRC2(mgResetRTO)

   /* Locate  peer from which txns are supposed to be moved*/
   if ((peer = mgLocatePeer(peerInfo, ssap)) == NULLP)
   {
     RETVALUE(MGT_ERR_INVALID_PEER);
   }

   /* 
    * If seed is present for retx timer use that else user #define
    * value 
    */
   if (ssap->ssapCfg.reCfg.initRetxTmr.enb == TRUE)
   {
     initRtt = ssap->ssapCfg.reCfg.initRetxTmr.val;
   }
   else
     initRtt = (MG_INIT_RTT_VALUE * mgCb.genCfg.timeRes);

   /* Set the peer RTO to a value as if peer has just been configured */
   MG_SET_PEER_INIT_RTO (initRtt, peer);

#ifdef ZG
   /* send runtime update for peer ..this is also required in pure FT case*/
   updInfo.procType = ZG_PROCTYPE_RESET_RTO;
   updInfo.u.resetRto.peerId = peer->accessInfo.peerId;
   zgRtProcUpd(&updInfo, (U8)CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);
#endif /* ZG */

   RETVALUE(MGT_NONE);

} /* End of mgResetRTO */




/*
*
*       Fun:   mgGetSendSrvr
*
*       Desc:  Get server for transmitting messages sent from the user 
*
*       Ret:   server pointer
*
*       Notes: 
*
*       File: 
*
*/

#ifdef ANSI
PUBLIC MgTptSrvr * mgGetSendSrvr
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PUBLIC MgTptSrvr * mgGetSendSrvr(ssap, peer)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
   MgTptSrvr        *srvr;             /* Transport Server */
   MgTSAPCb         *tsap;             /* TSAP Control Block */

   TRC2(mgGetSendSrvr)

   tsap = peer->tsap;
   srvr = NULLP;

#ifdef GCP_MGCO
  if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
  {
   /* If transport used is TCP */
   if (peer->accessInfo.transportType == LMG_TPT_TCP)
   {
     /* Get new connection */
      if ((srvr = peer->mgcoInfo.nxtUseConn) == NULLP)
      {
         RETVALUE(NULLP);
      }
      
      /* update next connection to be used (round robin) */
      peer->mgcoInfo.nxtUseConn = mgGetNxtUseConnForTx(peer);
   }      
  }
#endif /* GCP_MGCO */


   if (peer->accessInfo.transportType == LMG_TPT_UDP)
   {
#ifdef GCP_MG
      if (mgCb.genCfg.entType == LMG_ENT_GW)
      {
        /* On the MG side , first check for UDP servers on the SSAP. */
#ifdef GCP_MGCO
        if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
        {
          /* get next udp server to be used */
          if ((srvr = ssap->nxtUseMgcoSrvr) != NULLP)
          {
            /* update next server to be used (round robin) */
            ssap->nxtUseMgcoSrvr = mgGetLstnrForTx(ssap, tsap,
                                                   LMG_PROTOCOL_MGCO);
          }
        }
#endif /* GCP_MGCO */


#ifdef GCP_MGCP
        if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
        {
          /* get next udp server to be used */
          if ((srvr = ssap->nxtUseMgcpSrvr) != NULLP)
          {
            /* update next server to be used (round robin) */
            ssap->nxtUseMgcpSrvr = mgGetLstnrForTx(ssap, tsap,
                                                   LMG_PROTOCOL_MGCP);
          }
        }
#endif /* GCP_MGCP */

      } /* if gateway */
#endif /* GCP_MG */


      /* If server not found on SSAp, look for it on TSAP */
      if (srvr == NULLP)
      {
#ifdef GCP_MGCO
        if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
        {
          if ((srvr = tsap->nxtUseMgcoSrvr) != NULLP)
            tsap->nxtUseMgcoSrvr = mgGetLstnrForTx(NULLP, tsap,
                                                   LMG_PROTOCOL_MGCO);

        }
#endif /* GCP_MGCO */
        
#ifdef GCP_MGCP
        if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
        {
          if ((srvr = tsap->nxtUseMgcpSrvr) == NULLP)
            tsap->nxtUseMgcpSrvr = mgGetLstnrForTx(NULLP, tsap,
                                                   LMG_PROTOCOL_MGCP);
        }
#endif /* GCP_MGCP */
      } /* if srvr is NULLP */

   } /* If UDP */ 

   RETVALUE(srvr);

} /* end of mgGetSendSrvr() */


/*
*
*      Fun:    mgRetransmitMessage
*
*      Desc:   This function is invoked when retransmission of a command needs 
*              to be done
*
*       Ret:   None
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC Void mgRetransmitMessage
(
MgTptSrvr          *tptSrvr,           /* Transport Server to be used */
MgTSAPCb           *tsap,              /* TSAP Control Block */
MgPeerCb           *peer,              /* Pointer to Peer Control Block */
MgTxTransIdEnt     *txCb               /* Transaction Control Block */
)
#else
PUBLIC Void mgRetransmitMessage (tptSrvr, tsap, peer, txCb)
MgTptSrvr          *tptSrvr;           /* Transport Server to be used */
MgTSAPCb           *tsap;              /* TSAP Control Block */
MgPeerCb           *peer;              /* Pointer to Peer Control Block */
MgTxTransIdEnt     *txCb;              /* Transaction Control Block */
#endif
{
   U16             idx;                /* Index */
   Buffer          *mBuf;              /* Buffer to transmit */
   CmTptAddr       tptAddr;            /* transport address */

   TRC2(mgRetransmitMessage)

   idx          = txCb->addrTbl.count;

   /* Mark the transaction as retransmitted */
   txCb->everRetxed = TRUE;

   /* Copy the IPV4/IPV4 Address of the gateway */
   MG_FILL_TPTADDR_FRM_NETADDR(&(tptAddr),
                               &(txCb->addrTbl.netAddr[idx-1]));

   /*  Remote Port should be what is present in txCb */
   MG_FILL_TPTADDR_PORT(&tptAddr, txCb->remotePort);

   /* Increment Retransmission count */
   if(txCb->retxCnt != 0)
   {
      /* Update RTO */
     if (peer->mntInfo.rtoCap == FALSE)
     {
       /* 
        * AAD for the peer should not be updated for retransmissions since 
        * the acknowledgement delay for a retransmitted command cannot be 
        * calculated deterministically. The ack may have been sent in response
        * to the first time transmission or the retransmission.
        * The retransmission timer should be calculated by doubling the value
        * of AAD for the transaction to be retransmitted. 
        */
       /* Removed the piece of code for status indication generation for
        * RTO_CAP. The indication will only be sent if peer RTO exceeds tMAX 
        */
       MG_UPDATE_RTO_PARMS_ON_RETX(txCb->aad, peer->mntInfo.adev, 
                                   txCb->rto, tsap->tsapCfg.reCfg.tMax);

     }
   }

   /* 
    * Start the retransmission timer. RTO is in ticks. convert to multiples of 
    * timeRes 
    */
   /* Start timer based on RTO for the transaction since this is a
    * retransmission case. Do not use the RTO value for the peer */
   mgStartTmr (MG_RETX_TMR, (txCb->rto/mgCb.genCfg.timeRes), 
               (PTR) txCb, &(txCb->retxTmr));

#ifdef GCP_MGCP
   /* If TTL time is not running and DNS Is up; start TTL Timer */
   idx = MG_TTL_TMR - MG_PEER_TMR_BASE;

   if ((peer != NULLP) && (mgCb.dnsTsap != MG_INVALID_TSAP_ID) &&
       (mgCb.tSAPLst[mgCb.dnsTsap]) &&
       (mgCb.tSAPLst[mgCb.dnsTsap]->tsapCfg.reCfg.dnsCfg.dnsAccess
              != LMG_DNS_DISABLED) &&
       (peer->mntInfo.tmr[idx].tmrEvnt == TMR_NONE))
   {
      mgStartTmr(MG_TTL_TMR, peer->mgcpInfo.ttl, (PTR)peer, 
                 &(peer->mntInfo.tmr[idx]));
   }

#endif /* GCP_MGCP */



#ifdef GCP_MGCP

   if ((tptSrvr) &&
       (tptSrvr->protocol == LMG_PROTOCOL_MGCP))
   {
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
      /* If for piggybacked message , no response has been rcved and already
      * retransmission was done previously by some other txCb, then return */
      if(txCb->u.txBufInfo->rcvdRspCnt == 0 && 
            txCb->u.txBufInfo->retxCnt > txCb->retxCnt)
      {
         RETVOID;
      }
      if ((SAddMsgRef (txCb->u.txBufInfo->mBuf, tsap->tsapCfg.memId.region, 
                     tsap->tsapCfg.memId.pool, &(mBuf))) == ROK)
#else
      if ((SAddMsgRef (txCb->u.mBuf, tsap->tsapCfg.memId.region, 
                     tsap->tsapCfg.memId.pool, &(mBuf))) == ROK)
#endif /* GCP_MGCP && GCP_VER_1_3 && GCP_2705BIS */
      {
         /* Update Statistics */
         MG_UPD_MGCP_PEER_TX_STS(txCb->msgType, peer->peerSts);

         /* Retransmit the transaction */
         mgSrvDatReq(tptSrvr, &tptAddr, mBuf);
      }
   }

#endif /* GCP_MGCP */



#ifdef GCP_MGCO

   if ((tptSrvr) &&
       (tptSrvr->protocol == LMG_PROTOCOL_MGCO))
   {
      if ((SAddMsgRef (txCb->u.mBuf, tsap->tsapCfg.memId.region, 
                     tsap->tsapCfg.memId.pool, &(mBuf))) == ROK)
      {
         /* Update Statistics */
         MG_UPD_MGCO_PEER_TX_STS(txCb->msgType, peer->peerSts);
		 /* Update Retransmiting Statistics ,add by cdw on 2006.9.26*/
		 MG_UPD_MGCO_PEER_RETX_STS(txCb->msgType, peer->peerSts);
		 /* Retransmit the transaction */
         mgSrvDatReq(tptSrvr, &tptAddr, mBuf);
      }
   }
#ifdef    GCP_PROV_SCTP
   else if (peer->assocCb)
   {
      if ((SAddMsgRef (txCb->u.mBuf, tsap->tsapCfg.memId.region, 
                     tsap->tsapCfg.memId.pool, &(mBuf))) == ROK)
      {
         SctStrmId      strm;
         TknU32         ctxId;

         /*
          *   Since we do NOT have the original MgcoMsg event
          *   structure, we shall use the round-robin mechanism
          *   to retransmit the msg. To re-create the MgcoMsg
          *   would either require us to re-decode the mBuf OR
          *   store the context-ID in the TxCb. The first option
          *   is time inefficient whereas the second option
          *   should not be followed since the reason this msg
          *   has to be retransmitted could be that the stream
          *   on which the original msg was sent is down. Using
          *   another stream should help us get around such
          *   problems.
          *
          *   Similary, to have a better chance at this retransimission,
          *   we shall use unordered high priority delivery. This
          *   should make timely delivery more probable.
          */
         /*mg002.105: Removed compilation warning*/
         ctxId.pres = NOTPRSNT;
         ctxId.val    = 0;

         MG_MGCO_GET_STRMID_FRM_CTXID(strm,(&ctxId),peer->assocCb);

         MG_UPD_MGCO_PEER_TX_STS(txCb->msgType, peer->peerSts);

         MG_TRANSMIT_PDU(peer, peer->assocCb, strm, TRUE, tptSrvr,
                         &tptAddr, mBuf);
      }
   }
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
   else if((peer->mgcoMtpCb.peerDpc) && (tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3))
   {
         if ((SAddMsgRef (txCb->u.mBuf, tsap->tsapCfg.memId.region, 
                     tsap->tsapCfg.memId.pool, &(mBuf))) == ROK)
      {
         /* Update Statistics */
         MG_UPD_MGCO_PEER_TX_STS(txCb->msgType, peer->peerSts);
         /* Retransmit the transaction */
         mgMtpDatReq(peer, NULLD, NULLD, tsap, mBuf);
      }

   }
#endif   /* GCP_PROV_MTP3 */

#endif /* GCP_MGCO */


   RETVOID;

} /* end of mgRetransmitMessage() */


/*
*
*       Fun:   mgRmvEmptyTxn
*
*       Desc:  Remove All Erroneous transactions from the message to
*              be sent up to the service user 
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: 
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PRIVATE S16 mgRmvEmptyTxn
(
Ptr                msg,            /* MEGACO/MGCP message */
U32                protocol        /* protocol */
)
#else
PRIVATE S16 mgRmvEmptyTxn(msg, protocol)
Ptr                msg;            /* MEGACO/MGCP message */
U32                protocol;       /* protocol */
#endif
{
#ifdef GCP_MGCO
   MgMgcoMsg       *mgcoMsg;   /* Megaco Msg */
#endif /* GCP_MGCO */
#ifdef GCP_MGCP
   MgMgcpTxn       *mgcpTxn;   /* Mgcp Msg */
#endif /* GCP_MGCP */
   U16             i;  /* counter */
   U16             j;  /* counter */

   TRC2(mgRmvEmptyTxn)

#ifdef GCP_MGCO
   if(protocol == LMG_PROTOCOL_MGCO)
      mgcoMsg = (MgMgcoMsg *)msg;
#endif /* GCP_MGCO */
#ifdef GCP_MGCP
   if(protocol == LMG_PROTOCOL_MGCP)
      mgcpTxn = (MgMgcpTxn *)msg;
#endif /* GCP_MGCP */
   
   if(protocol == LMG_PROTOCOL_MGCO)
   {
#ifdef GCP_MGCO
      U16     numMsg;
      numMsg = mgcoMsg->body.u.tl.num.val;
      /* Remove the txn to be discarded from the message */
      for (i= numMsg; i>0; i--)
      {
         if (mgcoMsg->body.u.tl.txns[i-1] == NULLP)
         {
            for (j=0; j < (mgcoMsg->body.u.tl.num.val-i); j++)
            {
               mgcoMsg->body.u.tl.txns[i+j -1] = mgcoMsg->body.u.tl.txns[i+j];
            }
#ifdef GCP_VER_1_3
            /* Now free txn as it has seperate memory control block*/
 
            /* Corrected the indexing which caused the leak  */
            mgcoMsg->body.u.tl.txns[i+j -1] = NULLP;
 
#endif /* GCP_VER_1_3 */
            mgcoMsg->body.u.tl.num.val--;
         }
      } /* for all messages */
      /* If No transactions left in message, return RFAILED */
      if (mgcoMsg->body.u.tl.num.val == 0)
         RETVALUE(RFAILED);
#endif /* GCP_MGCO */
   }
   else
   {
#ifdef GCP_MGCP
      U16     numMsg;
      numMsg = mgcpTxn->numMsg;
      /* Remove the txn to be discarded from the message */
      for (i=numMsg; i>0; i--)
      {
         if ((mgcpTxn->mgcpMsg[i-1]) == NULLP)
         {
            for (j=0; j < (mgcpTxn->numMsg-i); j++)
            {
                mgcpTxn->mgcpMsg[i+j - 1] = mgcpTxn->mgcpMsg[i+j];
            }
#ifdef GCP_VER_1_3
            /* Now free txn as it has seperate memory control block*/
 
            /* Corrected the indexing which caused the leak  */
            mgcpTxn->mgcpMsg[i+j -1] = NULLP;
 
#endif /* GCP_VER_1_3 */
            mgcpTxn->numMsg--;
         }
      }
      /* If No transactions left in message, return RFAILED */
      if (mgcpTxn->numMsg == 0)
         RETVALUE(RFAILED);
#endif /* GCP_MGCP */
   }
   RETVALUE(ROK);
} /* End of mgRmvEmptyTxn */



#ifdef GCP_MGCO
/*
 * A function to prepare and send a txnRspAck whenever a
 * tranaction reply is received with immAck flag enabled.
 */

/*
*
*       Fun:    mgSendTxnRspAck
*
*       Desc:   This function composes a transaction response ack and sends it
*       to peer
*
*       Ret:   S16
*
*       Notes: None 
*
*       File:   mg_cord.c
*/
#ifdef    GCP_PROV_SCTP

#ifdef ANSI
PRIVATE S16 mgSendTxnRspAck
(
MgPeerCb           *peer,              /* Peer Control Block */
MgAssocCb          *assoc,             /* Association CB */
MgTptSrvr          *srvr,              /* Server for transmission */
MgTransId          trId                /* Transaction ID for rspAck */
)
#else
PRIVATE S16 mgSendTxnRspAck(peer, assoc, srvr, trId )
MgPeerCb           *peer;              /* Peer Control Block */
MgAssocCb          *assoc;             /* Association CB */
MgTptSrvr          *srvr;              /* Server for transmission */
MgTransId          trId;               /* Transaction ID for rspAck */
#endif

#else     /* GCP_PROV_SCTP */

#ifdef ANSI
PRIVATE S16 mgSendTxnRspAck
(
MgPeerCb           *peer,              /* Peer Control Block */
MgTptSrvr          *srvr,              /* Server for transmission */
MgTransId          trId                /* Transaction ID for rspAck */
)
#else
PRIVATE S16 mgSendTxnRspAck(peer, srvr, trId )
MgPeerCb           *peer;              /* Peer Control Block */
MgTptSrvr          *srvr;              /* Server for transmission */
MgTransId          trId;               /* Transaction ID for rspAck */
#endif

#endif    /* GCP_PROV_SCTP */
{
   MgMgcoMsg             *msg;         /* Megaco Message */
   MgMgcoTxn             *mgcoTxn;     /* Megaco Transaction */
   MgMgcoTxnRspAck       *rspAck;
   MgMgcoTxnAck          *ack;
   Buffer                *mBuf;        /* Message buffer */
   MgSSAPCb              *ssap;        /* SSAP Control Block */
   CmTptAddr             remAddr;      /* Remote Address */
   CmAbnfErr             err;          /* ABNF Encoding Error */
   S16                   ret;          /* Return Value */

#ifdef    GCP_PROV_SCTP
   TknU32                ctxId;        /* Integer type of Context-ID */
#endif    /* GCP_PROV_SCTP */
   U32                    protVar;

   TRC2(mgSendTxnRspAck)


   ssap = peer->ssap;


   mBuf = NULLP;

   /* Compose Transaction response ack message */
   ret = mgAllocEventMem((Ptr *)&msg, sizeof(MgMgcoMsg)); 
   if (ret != ROK)
     RETVALUE(ret);
   else   /* Initilized pres field of mgcoMsg */
     msg->pres.pres = PRSNT_NODEF;

   msg->pres.pres = PRSNT_NODEF;
   msg->ah.pres.pres = NOTPRSNT;
   msg->ver.pres = PRSNT_NODEF;

   msg->ver.val = peer->mgcoInfo.negotiatedVersion;

#ifdef GCP_VER_1_5
   if (msg->ver.val == 2)
   {
     protVar = CM_ABNF_PROT_MEGACO_H248_V2;
   }
   else
#endif /* GCP_VER_1_5 */
   {
     protVar = CM_ABNF_PROT_MEGACO_H248;
   }  

   /* Fill msg mid */
   MG_FILL_MID_IN_MSG(msg->mid, ssap->ssapCfg.userInfo.mid, ret, &(msg->memCp));
   if (ret != ROK)
   {
      mgFreeEventMem(msg);
      RETVALUE(ret);
   }
   msg->lcl.pres.pres = NOTPRSNT;
   msg->body.type.pres = PRSNT_NODEF;
   msg->body.type.val  = MGT_TXN;
   msg->body.u.tl.num.pres = PRSNT_NODEF; 
   msg->body.u.tl.num.val = 1;

#ifdef GCP_VER_1_3
   mgcoTxn = msg->body.u.tl.txns[0];
   if(ROK != mgAllocEventMem((Ptr *)&mgcoTxn, sizeof(MgMgcoTxn)))
   {
      mgFreeEventMem(msg);
      RETVALUE(RFAILED);
   }
   msg->body.u.tl.txns[0] = mgcoTxn;
#else
   MGGETMEM((Ptr *)&(msg->body.u.tl.txns), sizeof(Ptr), 
                                     (Ptr)(&(msg->memCp)), ret);
   if (ret != ROK)
   {
      mgFreeEventMem(msg);
      RETVALUE(ret);
   }
   MGGETMEM((Ptr *)&(msg->body.u.tl.txns[0]), sizeof(MgMgcoTxn), 
                       (Ptr)(&(msg->memCp)), ret);
   if (ret != ROK)
   {
      mgFreeEventMem(msg);
      RETVALUE(ret);
   }
   mgcoTxn = msg->body.u.tl.txns[0];
#endif /* GCP_VER_1_3 */

   mgcoTxn->type.pres = PRSNT_NODEF;    
   mgcoTxn->type.val = MGT_TXNRSPACK;

   rspAck = &(mgcoTxn->u.rspAck);
   rspAck->num.pres = PRSNT_NODEF;
   rspAck->num.val = 1;
   MGGETMEM((Ptr *)&(rspAck->acks), sizeof(Ptr), (Ptr)(&(msg->memCp)), ret);
   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
      RETVALUE(ret);
   }
   MGGETMEM((Ptr *)&(rspAck->acks[0]), sizeof(MgMgcoTxnAck), 
               (Ptr)(&(msg->memCp)), ret);
   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
      RETVALUE(ret);
   }
   ack = rspAck->acks[0];
   ack->pres.pres = PRSNT_NODEF;
   ack->first.pres = PRSNT_NODEF;
   ack->first.val = trId;
   ack->last.pres = PRSNT_NODEF;
   ack->last.val = trId;

   /* Resp Ack has been filled. Now encode it */
   /* Get Buffer for encoded transaction */
   if (mgGetMsg(peer->tsap->tsapCfg.memId.region,
                peer->tsap->tsapCfg.memId.pool,
                &mBuf) != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
      RETVALUE(RFAILED);
   }

#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 

   if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_TXT)
   {

#endif /* GCP_VER_1_5 GCP_ASN */
      /* Encode message */
      if ((cmAbnfEncPduMsg(protVar, (U8 *)&(msg->pres),
                           mBuf, &mgMgcoAuthHdrMsgDef,
                           &(peer->tsap->tsapCfg.memId),
                           &err)) != ROK)
      {
         MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
         MG_CLEAR_MEM(NULLP, mBuf); 
         RETVALUE(MGT_ERR_INVALID_PARMS);
      }
      
      /* Encode Transaction body */
      if ((cmAbnfEncPduMsg(protVar, 
                           (U8 *)(&(mgcoTxn->type)), mBuf, 
                           &mgMgcoTxnDef,
                           &(peer->tsap->tsapCfg.memId) , &err)) != ROK)
      {
         RETVALUE(MGT_ERR_INVALID_PARMS);
      }
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 

   }
   else if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
   {
       /* Encode Buffer & Transmit */
       /* Need to fix in the apropriate params once proto type is ready  */
       if ((mgEncPduMsg(protVar, (U8 *)msg, 0,
                        mBuf, MGED_HDR_ENC,
                        &(peer->tsap->tsapCfg.memId),
                        &err)) != ROK)
       {
           MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
           MG_CLEAR_MEM(NULLP, mBuf); 
           RETVALUE(MGT_ERR_INVALID_PARMS);
       }

       if ((mgEncPduMsg(protVar, (U8 *)msg, 0, mBuf, 
                        MGED_TXN_ENC,
                        &(peer->tsap->tsapCfg.memId) , &err)) != ROK)
       {
          RETVALUE(MGT_ERR_INVALID_PARMS);
       }
   }

   else
   {
       /* Encoding type not defined properly */
       MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
       MG_CLEAR_MEM(NULLP, mBuf); 
       RETVALUE(MGT_ERR_INVALID_PARMS);
   }
#endif

#ifdef GCP_ASN
   if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
   {  
    /* MAH_TODO last minute prep */
    if (mgPrepSend(protVar, mBuf, (CmMemListCp *)(msg)) != ROK)
    {
        RETVALUE(MGT_ERR_INVALID_PARMS);
    }
   }
#endif
   /* Rsp Ack has been encoded. Now send it across */ 
   /* Find server for message transmission */
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
   if ((peer->accessInfo.transportType != LMG_TPT_SCTP) && 
      (peer->accessInfo.transportType != LMG_TPT_MTP3))
   {
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
      if (NULLP == srvr)
         srvr = mgGetSendSrvr(peer->ssap, peer);
      if (NULLP == srvr)
      {
         MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
         if (mBuf != NULLP)
            mgPutMsg(mBuf);
         RETVALUE(RFAILED);
      }
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
   }
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */


   /* 
    * Set the remAddr.type as notPresent, and the macro SEND_PDU will get the
    * address from the peer and transmit itself. No need to save a copy of
    * mBuf, as we do not require to save it for any retx
    */
   remAddr.type = CM_TPTADDR_NOTPRSNT;


#ifdef    GCP_PROV_SCTP
   /* Context-ID is absent in transactionResponseAck */
   ctxId.pres = NOTPRSNT;
#endif    /* GCP_PROV_SCTP */


   /* Transmit the message */
   if ((ret = mgTransmitMgcoMsg(peer,
#ifdef    GCP_PROV_SCTP
                                assoc,
                                ctxId,
#endif    /* GCP_PROV_SCTP */
                                srvr,
                                &remAddr,
                                mBuf,
                                msg)) != MGT_NONE)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
      MG_CLEAR_MEM(NULLP, mBuf); 
      RETVALUE(RFAILED);
   }

   MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
   RETVALUE(ret);
} /* end of mgSendTxnRspAck () */

#ifdef ZG
#ifdef GCP_MG
/*
*
*       Fun:   mgRecovrConn
*
*       Desc:  This function takes the recovery action when new service provider
*       comes up .Typically when service 
*       provider fails , then layer manager may issue control req to preserve 
*       resourses (servers..connections ) and once new Service provider 
*       comes up..GCP layer will try to acquire same resources..which will 
*       bring GCP layer to same state as it was.
*       
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC S16 mgRecovrConn
(
MgTSAPCb           *tsapCb            /* TSAP Control Block */
)
#else
PUBLIC S16 mgRecovrConn(tsapCb)
MgTSAPCb           *tsapCb;            /* TSAP Control Block */  
#endif
{
   S16             ret;                /* Return Value */
   U16             i;
   MgPeerCb        *peer;
   MgSSAPCb        *ssap;

   TRC2(mgRecovrConn)
   /* for all the peers if transport is TCP ..reestablish TCP connection */  
   for(i = 0; i< mgCb.genCfg.maxSSaps; i++)
   {
      ssap = mgCb.sSAPLst[i];
      if(ssap != NULLP)
      {
         peer = ssap->crntMgc;
         if(peer == NULLP)
            mgSelectPeer(&peer, ssap);
         if(peer == NULLP)
            RETVALUE(RFAILED);
         else if(peer->accessInfo.transportType == LMG_TPT_TCP)
         {
            /* If Peer's transport type is TCP then reestablish TCP connection
             * with peer */
            CmTptAddr remAddr;
            MgTptSrvr *conn;
            MgSrvrInitInfo  info;

            /* Initialize server init info */
            info.transportType = LMG_TPT_TCP;
            info.srvrType      = MG_TCP_CLIENT_CONNECTION;
            info.encodingScheme = peer->mgcoInfo.encodingScheme;
#ifdef ZG
            info.suConnId = MG_INVALID_LSTNRID;
            info.peerId = peer->accessInfo.peerId;
#endif /* ZG */
            /* Initiate connection request to remote server */
            MG_FILL_TPTADDR_FRM_NETADDR(&remAddr,
                             &(peer->accessInfo.peerAddrTbl.netAddr[0]));

            MG_FILL_TPTADDR_PORT(&remAddr, peer->accessInfo.remotePort);

            ret = mgAllocSrvrCb(&info, &remAddr, NULLP, ssap, peer, 
                                 (Ptr *)&conn, tsapCb);
            if (ret != ROK)
            {
               RETVALUE(ret);
            }
            
            peer->state = LMG_PEER_STATE_CONNECT;
            /* send runtime update */

            zgRtUpd(ZG_CBTYPE_TPTSRVR,(Ptr)conn,CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_ADD);
            /* Send connection req */
            mgSrvConReq(conn, &(tsapCb->tsapCfg.reCfg.tptParam),
                        tsapCb, &remAddr);    
            ssap->crntMgc = peer;
            /* Send update for peer and ssap */
            zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_MOD);
            zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_MOD);
         }
      }
   }
   RETVALUE(ROK);

} /* end of mgRecovrConn() */

#endif /* GCP_MG */
#endif /* ZG */
#endif /* GCP_MGCO */

#ifdef GCP_MG
#ifdef ZG
/*
*
*       Fun:   mgSendRegReq
*
*       Desc:  This function sends registration req to peers.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgSendRegReq
(
MgTptSrvr          *srvr,           /* srvr*/
MgTSAPCb           *tsap            /* TSAP Control block */
)
#else
PUBLIC S16 mgSendRegReq(srvr, tsap)
MgTptSrvr          *srvr;            /* srvr*/
MgTSAPCb           *tsap;           /* TSAP Control block */
#endif
{
   U16             ret;                /* Return Value */
   MgPeerCb        *peer;              /* peer cb */

   TRC2(mgSendRegReq)

   ret = ROK;
#ifdef GCP_MG
   /* send service change if changeOver flag is true */
   if(tsap->tsapCfg.reCfg.changeOver == TRUE)
   {
      tsap->tsapCfg.reCfg.changeOver = FALSE;
      if(srvr->transportType == LMG_TPT_TCP)
      {
#ifdef GCP_MGCO
         ret = mgSendSrvcChng(srvr->t.peer,MGT_SVCCHGMETH_DISCON,
                              MG_SCRSN_MG_IMPN_FAIL, srvr,
                              LMG_INVALID_PEER_PORT,
                              NULLP);
#endif /* GCP_MGCO */
      }
      else
      {
         /* If changeOver flag is TRUE; send service change/RSIP since this 
          * is the first server opent after service provider has come up. */
         U16         cntr;
#ifdef GCP_MGCP
         for(cntr =0;cntr < mgCb.genCfg.maxSSaps; cntr++)
         {
            CmLList     *node;
            MgSSAPCb    *ssap;

            /* for all the peers inside SSAP send RSIP message. */
            ssap = mgCb.sSAPLst[cntr];
           
            if(ssap != NULLP)
            {
               if (ssap->ssapCfg.protocol != 
                   LMG_PROTOCOL_MGCP)
               {
                  continue;
               } /* if, protocol type doesn't match skip */
               CM_LLIST_FIRST_NODE(&(ssap->peerLst), node);
               while(node != NULLP)
               {
                  /* If peer is in await Reg state then send RSIP command with
                   * method as disconnected */
                  if (((MgPeerCb *)node->node)->state == 
                        LMG_PEER_STATE_AWAIT_REG)
                  {
                     peer = (MgPeerCb *)(node->node);
                     ret = mgMgcpSendRSIP(peer, MGT_PARAM_RSTRT_DISC);
                     if(ret != ROK)
                        break;
                  }
                  node = node->next; 
               }
               if(ret != ROK)
                  break;
            }
         }
#endif /* GCP_MGCP */
#ifdef GCP_MGCO
#ifdef GCP_MG
         /* for all the peers send service change message with method as
          * disconnected */
         for(cntr =0;cntr < mgCb.genCfg.maxSSaps; cntr++)
         {
            if(mgCb.sSAPLst[cntr] != NULLP)
            {
               if (mgCb.sSAPLst[cntr]->ssapCfg.protocol != 
                   LMG_PROTOCOL_MGCO)
               {
                  continue;
               } /* if, protocol type doesn't match skip */
               peer = mgCb.sSAPLst[cntr]->crntMgc;
               if(peer == NULLP)
               {
                  mgSelectPeer(&peer, mgCb.sSAPLst[cntr]);
               }
               if( (peer == NULLP) || 
                   (ret = mgSendSrvcChng(peer,MGT_SVCCHGMETH_DISCON, 
                              MG_SCRSN_MG_IMPN_FAIL,srvr,LMG_INVALID_PEER_PORT,
                              NULLP)) != ROK)
               {
                  break;
               }
            }
         }
#endif /* GCP_MG */
#endif /* GCP_MGCO */ 
      }
      /* generate status indication to LM indiacting status of TUCL recovery
       * procedure */
      if(ret == ROK)
      {
         mgGenStaInd (STSSAP, LCM_CATEGORY_PROTOCOL, 
            LMG_EVENT_TSAP_RECVRY_SUCCESS, LMG_CAUSE_UNKNOWN, 
            LMG_ALARMINFO_NONE, (Ptr)NULLP, 0, LMG_ALARMINFO_INVSAPID);
         /* Send status ind to service user */
         mgGenUserStaInd(NULLP,NULLP, MGT_STATUS_SAP_RECVRY_SUCCESS ,
            NULLP);
      }
      else
      {
         mgGenStaInd (STSSAP, LCM_CATEGORY_PROTOCOL, 
            LMG_EVENT_TSAP_RECVRY_FAILED, LMG_CAUSE_TPT_FAILURE, 
            LMG_ALARMINFO_NONE, (Ptr)NULLP, 0, LMG_ALARMINFO_INVSAPID);
         /* Send status ind to service user */
         mgGenUserStaInd(NULLP,NULLP, MGT_STATUS_SAP_RECVRY_FAILED,
            NULLP);
      }
   }
#endif /* GCP_MG */
   RETVALUE(ret);

} /* end of mgSendRegReq () */
#endif /* GCP_MG */
#endif /* ZG */


#ifdef CM_ABNF_MT_LIB

#ifdef GCP_MGCP
/*
*
*       Fun:   mgMgcpMTPrcEachTxnReq
*
*       Desc:  This function processes all the transactions one by one. This
*       function is called if Multithreaded Encoder/Decoder Lib is enabled. 
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or an acknowledgement 
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcpMTPrcEachTxnReq
(
Bool               ssapTxSrvr,         /* SSAP owns Local Tx Socket ? */
Bool               *delPeer,           /* Delete Peer */
MgPeerCb           *peer,              /* Peer Control Block */
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgcpTxn          *txn,               /* Transaction to be Transmitted */
MgMgcpTxn          **failedTxn,        /* Rejected Transactions */
CmTptAddr          *tptAddr,           /* Destination Tx Addr */
MgTptSrvr          *srvr,              /* Local Socket for Transmission */
MgTSAPCb           *tsap               /* TSAP Control Block */
)
#else
PRIVATE S16 mgMgcpMTPrcEachTxnReq(ssapTxSrvr, delPeer, peer, ssap, txn, failedTxn,
                                tptAddr, srvr)
Bool               ssapTxSrvr;         /* SSAP owns Local Tx Socket ? */
Bool               *delPeer;           /* Delete Peer */
MgPeerCb           *peer;              /* Peer Control Block */
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgcpTxn          *txn;               /* Transaction to be Transmitted */
MgMgcpTxn          **failedTxn;        /* Rejected Transactions */
CmTptAddr          *tptAddr;           /* Destination Tx Addr */
MgTptSrvr          *srvr;              /* Local Socket for Transmission */
MgTSAPCb           *tsap;              /* TSAP Control Block */
#endif
{
   Bool            immTx;              /* Transmit Immediately */
   Bool            dontPrcCmd;         /* Don't process rest of command */
   Bool            xmit;               /* Is it possible to Xmit */
   Bool            dumpTxn;            /* Dump Transaction in case of error */
   U16             numMsg;             /* Number of messages */
   U16             loopIdx;            /* Loop Index */
   S16             ret;                /* Return Value */
   U32             event;              /* Usta Event */
   U32             mgtError;           /* MGT Interface Error */
   MsgLen          crntPduLen;         /* Current PDU Length */
#ifndef CM_ABNF_MT_LIB
   CmAbnfErr       err;                /* ABNF Encoding Error */
#endif /* ! CM_ABNF_MT_LIB */
   CmTptAddr       responseAddr;       /* Remote Address For Tx of Response */
   CmTptAddr       *transmitAddr;      /* Remote Address to Tx to */
   MgMgcpTxn       *discardTxn;        /* Structure for discarded messages */
   MgTxTransIdEnt  *txCb;              /* Command Transaction Control Block */
   MgRxTransIdEnt  *rxCb;              /* Response Transaction Control Block */
   MgMgcpMsg       *msg;               /* MGCP Message */
   Buffer          *mBuf;              /* Message Buffer */
   Buffer          *concatMbuf;        /* PiggyBacked Buffer */
   MgTxBufInfo     *txBufInfo;         /* Transmitted buffer information*/
   MgTransId       transId;            /* Transaction Id */

#ifdef    GCP_PROV_SCTP
   TknU32          ctxId;              /* Context-Id: MEGACO only */
#endif    /* GCP_PROV_SCTP */
   U8            encodingScheme;

   TRC2(mgMgcpMTPrcEachTxnReq)


   /* Initialise variables */
   xmit         = FALSE;
   discardTxn   = NULLP;
   transmitAddr = NULLP;
   concatMbuf   = NULLP;
   txBufInfo    = NULLP;

#ifdef    GCP_PROV_SCTP
   ctxId.pres   = NOTPRSNT;            /* Context-Id: MEGACO only -
                                        *    Mark as absent         */
   ctxId.val    = 0;
#endif    /* GCP_PROV_SCTP */


   /*
    * For Piggybacking, UDP header + message separator needs to be added as
    * length, so initialise crntPduLen accordingly
    */
   crntPduLen = MG_UDP_HDR_LEN;   

   /*
    * All commands should be dumped in case of error, response shouldn't be 
    * dumped after a point; See dumpTxn = FALSE case below
    */
   dumpTxn    = TRUE; 

   /* Process each transaction from the user */
   numMsg = txn->numMsg;
   dontPrcCmd = FALSE;
   mgtError = 0;
   event    = 0;
   for (loopIdx = 0; loopIdx < numMsg; loopIdx++)
   {
      /* Initialise variables used inside the loop */

      Bool     crtTxCb;   /* whether to process command */
      immTx    = FALSE;
      txCb     = NULLP;
      rxCb     = NULLP;
      mBuf     = NULLP;

      /* Obtain message pointer */
      if ((msg = txn->mgcpMsg[loopIdx]) == NULLP)
         continue;

      crtTxCb = TRUE;

#ifdef ZG_DFTHA
      /* If this msg is cmd and it's transId/Rset doesn't lie on this 
       * Copy (Node/Processor ) then don't create txCb for this cmd.
       */

      if(msg->msgType.val != MGT_MSG_RSP)
      {
         MG_MGCP_GET_TRANSID(msg, transId);
         if(!zgChkNCRsetStatus(transId, LMG_PROTOCOL_MGCP,
            peer, (msg->msgType.val), MG_TRANS_TYPE_TX, 
            srvr->suRsetId, NULLP, 0))
         {
            /* make crtTxCb False , also call PLDF fn to send this piggybacked
             * txn to appropriate copy */
            crtTxCb = FALSE;
            zgPldfSendPiggyBkdMsg(ssap->ssapCfg.sSAPId, peer->accessInfo.peerId,
               txn,loopIdx);
         }
      }
      
#endif /* ZG_DFTHA */

      /* Verify is message is in conformance with local entity */
      MG_VERIFY_TX_MGCP_MSG_ENT_RELATION(msg->msgType.val,
                                         mgCb.genCfg.entType, ret);
      if (ret != ROK)
      {
         mgtError = MGT_ERR_INVALID_MSG;
         goto TXNREQ_ERROR_PROCESSING;
      }
     
      mBuf = NULLP;   
      if (msg->msgType.val == MGT_MSG_RSP)
      {
         /* Process the Outgoing Response */
         if ((mgMgcpPrcRspInTxnReq(delPeer, peer, msg, &responseAddr, &rxCb,
                                   &mgtError, mBuf)) != ROK)
         {
            goto TXNREQ_ERROR_PROCESSING;
         }

         /* Mark the response for immediate transmission */
         immTx = TRUE;

         /* Mark the address to be used for Transmission */
         transmitAddr = &(responseAddr);
      }
      else if(crtTxCb == TRUE)
      {
         if(dontPrcCmd == TRUE)
         {
            /* Send same MGT error which was for previous command */
            goto TXNREQ_ERROR_PROCESSING;
         }
         /* we are here..this means..this is command and also txCb needs to be
          * created ..since crtTxCb is true. crtTxCb as False implies that this
          * command was sent through PLDF to appropriate copy. */ 
#ifdef  GCP_2705BIS
        txBufInfo = NULLP;
        if ((ret = mgMgcpPrcCmdInTxnReq(peer, msg, tptAddr, srvr, 
               &txCb, &mgtError, (Void *)txBufInfo, &immTx, tsap)) == RFAILED)
#else  /* GCP_2705BIS */
         if ((ret = mgMgcpPrcCmdInTxnReq(peer, msg, tptAddr, srvr, 
               &txCb, &mgtError, (Void *)mBuf, &immTx, tsap)) == RFAILED)
#endif /* GCP_2705BIS */
         {
            if (mgtError == MGT_ERR_RSRC_UNAVAIL)
               event    = LCM_EVENT_SMEM_ALLOC_FAIL;
            goto TXNREQ_ERROR_PROCESSING;
         }
#ifdef ZG_DFTHA
         else if(ret == ROKDNA)
         {
            /* Now txn should be queued here..this will be processed once state
             * update will be received from master */
            mgQueueRvUpdTxnReq(txn, &peer->usrTxnQ, mgCb.tsapCb.rvNode,
                               LMG_PROTOCOL_MGCP, ssap->ssapCfg.sSAPId);
            RETVALUE(ROKDNA);
         }
#endif /* ZG_DFTHA */

#ifdef GCP_VER_1_3
         /* Check if any response to be acked for this peer..if yes then
          * construct response ack parameter and add into command */
         /* mg002.105: rspAckEnb is now reconfigurable */
         if(mgCb.genCfg.reCfg.rspAckEnb & LMG_EMBD_RSPACK_MGCP) 
         {
            /* Now go through peer->txnAckQ list, and form response ack
             * parameter*/
            MgTxnAckList   *node;
            MgTxnAckList   *prv;
            U8              cnt;
            node = peer->txnAckQ.next;
            cnt = 0;
            /* Look into list..corresponding to each node for one response ack
             * parameter */
            while((peer->txnAckQ.next))
            {
               MgRspAck   *ack[MGT_MAX_RSP_ACK];
               MgTransId   trId;
               MgTransId   oldTrId;
               /* Store trId */
               oldTrId = node->info.trId;
               trId = oldTrId;
               /* Get memory for response ack */
               if((cmGetMem(&(msg->memCp), sizeof(MgRspAck), (Ptr *)&(ack[cnt]))) != ROK)
               {
                  mgtError = MGT_ERR_RSRC_UNAVAIL;
                  event    = LCM_EVENT_DMEM_ALLOC_FAIL;
                  /* mgMgcpFillRspAck(ack,msg,cnt); */
                  goto TXNREQ_ERROR_PROCESSING;
               }
               /* Stop the timer, since we rcved command from SU */
               if(node->info.tmr.tmrEvnt == MG_30SEC_ACK_TMR)
                  mgStopTmr(node->info.tmr.tmrEvnt,(PTR)node,&(node->info.tmr));
               /* check if txnAck range can be formed */
               prv = node;
               while((node->next != NULLP)&&(node->next->info.trId == trId + 1))
               {
                  if(node->next->info.tmr.tmrEvnt == MG_30SEC_ACK_TMR)
                     mgStopTmr(node->next->info.tmr.tmrEvnt,(PTR)node->next,
                     &(node->next->info.tmr));
                  prv = node->next;
                  trId = node->next->info.trId;
                  /* Free node */
                  mgDeAlloc((Data *)node,sizeof(MgTxnAckList));
                  node = prv;
               }
               /* fill the parameters */
               ack[cnt]->pres.pres = PRSNT_NODEF;
               ack[cnt]->lowBnd.pres = PRSNT_NODEF;
               ack[cnt]->lowBnd.val = trId;
               ack[cnt]->upperBnd.pres = PRSNT_NODEF;
               ack[cnt]->upperBnd.val = node->info.trId;
               /* check if lower and upper bound is same ..then make upperBnd
                * not present */
               if(ack[cnt]->upperBnd.val == ack[cnt]->lowBnd.val)
               {
                  ack[cnt]->upperBnd.pres = NOTPRSNT;
               }

               peer->txnAckQ.next = node->next;
               /* Free node */
               mgDeAlloc((Data *)node,sizeof(MgTxnAckList));
               cnt++;
               /* if list is empty or..we have allready reached max no of Ack to
                * be sent with one command , then add these parameters into
                * command and send it. If any more ACks are pending then it will
                * be sent with next command. */ 
               if((peer->txnAckQ.next == NULLP)||(cnt == MGT_MAX_RSP_ACK))
               {
                  mgMgcpFillRspAck(ack,msg,cnt);
                  break;
               }
            }
         }
#endif

         /* Mark the address to be used for Transmission */
         transmitAddr = tptAddr;
      }


      /* Error Processing Label */
TXNREQ_ERROR_PROCESSING:

      if (mgtError > 0)
      {
         if (msg->msgType.val == MGT_MSG_NONSTD) 
           transId = msg->t.nonStdCmd.cmd.cmdLine.trId.val;
         else if (msg->msgType.val == MGT_MSG_RSP)
           transId = msg->t.mgcpRsp.trId.val;
         else
           transId = msg->t.epcfCmd.cmdLine.trId.val;

         if (dumpTxn == TRUE)
         {
            /* we are here..means one of command in piggybacked txn
             * generated error so we  shouldnot process rest of command 
             * either. Only if it response should be processed */
            dontPrcCmd = TRUE;
            
            MG_ALLOC_DISCARD_TXN_STRUCT(txn, discardTxn, ret, ssap);
            MG_COLLECT_DISCARDED_TXN(discardTxn, msg, mgtError, transId);
            MG_FREE_RSRCS_ON_TXNREQ_ERROR(mBuf, txn, loopIdx, txCb, rxCb);
         }
         else
            dumpTxn = TRUE;   /* Reset the flag */

         if (event > 0)
         {
            if (event == LCM_EVENT_DMEM_ALLOC_FAIL)
            {
               MG_GEN_RSRC_CATEG_ALRM(STTSAP, event, tsap->tsapCfg.memId.region,
                                      tsap->tsapCfg.memId.pool);
            }
            else
            if (event == LCM_EVENT_SMEM_ALLOC_FAIL)
            {
               MG_GEN_RSRC_CATEG_ALRM(STSSAP, event, mgCb.init.region, 
                                      mgCb.init.pool);
            }
         }
         continue;

      } /* end of if (err == TRUE) */

   } /* end of for (loopIdx) */

   txn->numMsg = numMsg;
   ret = mgRmvEmptyTxn((Ptr)txn, LMG_PROTOCOL_MGCP);
   
   /* send encode request to ED Instance */
   encodingScheme = LMG_ENCODE_TXT;/*MAH_TODO Initing to txt */
   if(srvr) /*MAH_TODO*/
    encodingScheme = srvr->encodingScheme;
   if(ret == ROK)
   {
      mgSndEncPduMsgReq(encodingScheme ,peer->mntInfo.variant, peer->accessInfo.peerId,
                        MG_USER, peer->ssap->ssapCfg.sSAPId,
                        NULLP, txn, *delPeer, tsap
#ifdef    GCP_PROV_SCTP
                        ,NULLP, ctxId
#endif    /* GCP_PROV_SCTP */
                       );
   }

   if(ret != ROK)
   {
#ifdef CM_ABNF_MT_LIB
      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
#endif /* CM_ABNF_MT_LIB */
   }

   /* Return the rejected transactions if any */
   *failedTxn = discardTxn;

   RETVALUE(ROK);

} /* end of mgMgcpMTPrcEachTxnReq() */

#endif /* GCP_MGCP */
#ifdef GCP_MGCO
/*
*       Fun:   mgPrcMTMgcoTxn
*
*       Desc:  Process Each transaction in the MEGACO message received
*              from the user ( if Encoder/Decoder lib is multithreaded )
*
*       Ret:   ROK - SUCCESS;
*              RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/

#ifdef    GCP_PROV_SCTP

#ifdef ANSI
PRIVATE S16 mgPrcMTMgcoTxn
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgcoMsg          *mgcoMsg,           /* message */
MgMgcoTxn          *mgcoTxn,           /* Transaction */
MgPeerCb           *peer,              /* Peer Control Block */
MgTptSrvr          *srvr,              /* Transport Server */
MgMgcoMsg          **errMsg,           /* Error Message */
Buffer             *mBuf,              /* Message buffer */            
Buffer             *hdrMBuf,           /* Header Buffer */
Bool               *msgSend,           /* Message present in mBuf */
U8                 source,             /* Initiated by user/ internal */
MgAssocCb          *assoc,             /* Association Control Block */
TknU32             ctxId               /* Context-Id */
)
#else
PRIVATE S16 mgPrcMTMgcoTxn(ssap, mgcoMsg, mgcoTxn, peer, srvr, errMsg,
                           mBuf, hdrMBuf, msgSend, source, assoc, ctxId)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgcoMsg          *mgcoMsg;           /* message */
MgMgcoTxn          *mgcoTxn;           /* Transaction */
MgPeerCb           *peer;              /* Peer Control Block */
MgTptSrvr          *srvr;              /* Transport Server */
MgMgcoMsg          **errMsg;           /* Error Message */
Buffer             *mBuf;              /* Message buffer */            
Buffer             *hdrMBuf;           /* Header Buffer */
Bool               *msgSend;           /* Message present in mBuf */
U8                 source;             /* Initiated by user/ internal */
MgAssocCb          *assoc;             /* Association Control Block */
TknU32             ctxId;              /* Context-Id */
#endif 

#else     /* GCP_PROV_SCTP */

#ifdef ANSI
PRIVATE S16 mgPrcMTMgcoTxn
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgcoMsg          *mgcoMsg,           /* message */
MgMgcoTxn          *mgcoTxn,           /* Transaction */
MgPeerCb           *peer,              /* Peer Control Block */
MgTptSrvr          *srvr,              /* Transport Server */
MgMgcoMsg          **errMsg,           /* Error Message */
Buffer             *mBuf,              /* Message buffer */            
Buffer             *hdrMBuf,           /* Header Buffer */
Bool               *msgSend,           /* Message present in mBuf */
U8                 source              /* Initiated by user/ internal */
)
#else
PRIVATE S16 mgPrcMTMgcoTxn(ssap, mgcoMsg, mgcoTxn, peer, srvr, errMsg,
                           mBuf, hdrMBuf, msgSend, source)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgcoMsg          *mgcoMsg;           /* message */
MgMgcoTxn          *mgcoTxn;           /* Transaction */
MgPeerCb           *peer;              /* Peer Control Block */
MgTptSrvr          *srvr;              /* Transport Server */
MgMgcoMsg          **errMsg;           /* Error Message */
Buffer             *mBuf;              /* Message buffer */            
Buffer             *hdrMBuf;           /* Header Buffer */
Bool               *msgSend;           /* Message present in mBuf */
U8                 source;             /* Initiated by user/ internal */
#endif 

#endif    /* GCP_PROV_SCTP */
{
   MgTSAPCb        *tsap;              /* TSAP */
   MgTransId       transId;            /* Transaction Identifier */
   U8              ackType;            /* Acknowledgement Type */
   MgTxTransIdEnt  *txCb;              /* Outgoing Transaction Control Block */
   MgRxTransIdEnt  *rxCb;              /* Incoming Transaction Control Block */
   Buffer          *txnMBuf;           /* Buffer for encoded transaction */
   CmTptAddr       rspRemAddr;         /* Remote Address for Response */
   CmTptAddr       remoteAddr;         /* Remote Address for SendingCommands */
   MgSvcChgInfo    svcChgInfo;         /* Service Change Information */   
   Bool            svcChgRsp;          /* Service Change Response/not */
   S16             ret;                /* Return Value */
   Bool            immAck;             /* Immediate Ack field to be set/ not */
   MgMgcoMsg       *newMsg;            /* new message */
   U32             protVar;
   
   TRC2(mgPrcMTMgcoTxn)

   if (mgcoTxn == NULLP)
      RETVALUE(ROK);
         
   /* Initialize Variables */
   tsap      = peer->tsap;
   txnMBuf   = NULLP;
   txCb      = NULLP;
   rxCb      = NULLP;
   ackType   = MG_NONE;
   immAck    = FALSE;

   remoteAddr.type = CM_TPTADDR_NOTPRSNT;
   rspRemAddr.type = CM_TPTADDR_NOTPRSNT;

   /* Get Transaction Id from the Event Structure */
   MG_GET_TRANSID(mgcoTxn, transId);

   txnMBuf = NULLP;

   switch (mgcoTxn->type.val)
   {
      case MGT_TXNREQ:
      {
         /* If txn is a Transaction request */
         if (mgcoTxn->u.req.pres.pres == NOTPRSNT)
            RETVALUE(ROK);
            
         /*
          * Check if we have resources to process this transaction
          * This check is done only for outgoing transactions as that
          * is where we allocate resources in our layer...for outgoing
          * response no resource in our layer is allocated
          */
         if (mgAdmitTxn(ssap, tsap) != ROK)
         {
            MG_FILL_MGCO_ERR_MSG(errMsg,MGT_ERR_RSRC_UNAVAIL, \
                                 txnMBuf, rxCb, txCb, transId);

            /*
             * free the SDP Tkn Buf
             */
#ifdef CM_SDP_OPAQUE
            mgMgcoFreeAllTkBfs(mgcoTxn);
#endif /* CM_SDP_OPAQUE */

            /* free txn */
            /*
             * added GCP_VER_1_3 flag for evnt struct freeing
             */
#ifdef GCP_VER_1_3
#ifdef GCP_CH
            for (loopIdx = 0; loopIdx < mgcoMsg->body.u.tl.num.val;
                 loopIdx++)
            {
               if (mgcoTxn == mgcoMsg->body.u.tl.txns[loopIdx])
                  mgChFreeCmds(mgcoMsg, loopIdx);
            }
#endif /* GCP_CH  */
            mgFreeEventMem(mgcoTxn);
#endif /* GCP_VER_1_3 */
            mgcoTxn = NULLP;
            RETVALUE(ROK);
         }
      }
      break;
            
      /* If message is a provisional response */
      case MGT_TXNPEND:
      {
         if (mgcoTxn->u.pend.pres.pres == NOTPRSNT)
            RETVALUE(ROK);

         ackType = MG_RESPONSE_PROV;

         /* Fall Through */             
      }

      /* If message is a Reply to a previously received transaction */
      case MGT_TXNREPLY:
      {
         if (mgcoTxn->type.val == MGT_TXNREPLY) 
         {
            if (mgcoTxn->u.reply.pres.pres == NOTPRSNT)
               RETVALUE(ROK);

            ackType = MG_RESPONSE;
         }


         /*
          * Check if it is a response to service change message 
          */
         svcChgRsp = FALSE;
         if (mgcoTxn->type.val == MGT_TXNREPLY)
         {
            /* Don't do this for provisional responses */
            svcChgRsp = mgChkForSrvcChgRsp(peer, mgcoTxn);
         }
         
         /* Process te outgoing response */
         if ((rxCb = mgPrcOutGoingAck(LMG_PROTOCOL_MGCO, ackType, transId,
                                      peer, txnMBuf, &immAck,
                                      svcChgRsp)) == NULLP)
         {
            MG_FILL_MGCO_ERR_MSG(errMsg, MGT_ERR_INVALID_TRANS, \
                                 txnMBuf, rxCb, txCb, transId);

            /*
             * free the SDP Tkn Buf
             */
#ifdef CM_SDP_OPAQUE
            mgMgcoFreeAllTkBfs(mgcoTxn);
#endif /* CM_SDP_OPAQUE */

            /* free txn */
            /*
             * added GCP_VER_1_3 flag for evnt struct freeing
             */
#ifdef GCP_VER_1_3
#ifdef GCP_CH
            for (loopIdx = 0; loopIdx < mgcoMsg->body.u.tl.num.val;
                 loopIdx++)
            {
               if (mgcoTxn == mgcoMsg->body.u.tl.txns[loopIdx])
                  mgChFreeCmds(mgcoMsg, loopIdx);
            }
#endif /* GCP_CH  */

            mgFreeEventMem(mgcoTxn);
#endif /* GCP_VER_1_3 */
            mgcoTxn = NULLP;
            RETVALUE(ROK);
         }

         /* Store the remote address for transmission */
         cmMemcpy((U8 *)&(rspRemAddr), (CONSTANT U8 *)&(rxCb->tptAddr),
                  sizeof(CmTptAddr));

         /* If provisional response */
         if (mgcoTxn->type.val != MGT_TXNREPLY)
            break;


         if (immAck == TRUE)
            MG_SET_IMMACK_FLAG(mgcoTxn);

         /* 
          * If message is a service change rsponse additional processing would be
          * necessary. So we need to chk for service change response. 
          */
         if (svcChgRsp == TRUE)
         {
            mgFillSvcChgInfo(MG_SRVC_CHG_REPLY, mgcoTxn, &svcChgInfo);
            mgPrcUserRegRsp(peer, rxCb,(Ptr)&svcChgInfo);
         }
      }
      break;
    
      case MGT_TXNRSPACK:
      {
         if (mgcoTxn->u.req.pres.pres == NOTPRSNT)
            RETVALUE(ROK);
      }
      break;
    
   } /* end switch */

   ret = mgAllocEventMem((Ptr *)&newMsg, sizeof(MgMgcoMsg)); 
   /* copy content of message */
   MG_MGCO_COPY_EVNT_STRUCT(mgcoMsg, newMsg);
   newMsg->body.u.tl.num.pres = PRSNT_NODEF;
   newMsg->body.u.tl.num.val = 1;
   newMsg->body.u.tl.txns[0] = mgcoTxn;

#ifdef GCP_VER_1_5
   if (newMsg->ver.val == 2)
   {
    protVar = CM_ABNF_PROT_MEGACO_H248_V2;
   }  
   else
#endif /* GCP_VER_1_5 */
   {
    protVar = CM_ABNF_PROT_MEGACO_H248;
   }

   ret = mgSndEncPduMsgReq(peer->mgcoInfo.encodingScheme ,protVar, peer->accessInfo.peerId, 
                           MG_USER, peer->ssap->ssapCfg.sSAPId,
                           NULLP, newMsg, FALSE, peer->tsap
#ifdef    GCP_PROV_SCTP
                           ,assoc,
                           ctxId
#endif    /* GCP_PROV_SCTP */
                           );
   RETVALUE(ret);

} /* End of mgPrcMTMgcoTxn */
#endif /* GCP_MGCO */
#else
#ifdef GCP_MGCP
/*
*
*       Fun:   mgMgcpPrcEachTxnReq
*
*       Desc:  This function processes all the transactions one by one.
*              The transactions are received from Service User
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or an acknowledgement 
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcpPrcEachTxnReq
(
Bool               ssapTxSrvr,         /* SSAP owns Local Tx Socket ? */
Bool               *delPeer,           /* Delete Peer */
MgPeerCb           *peer,              /* Peer Control Block */
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgcpTxn          *txn,               /* Transaction to be Transmitted */
MgMgcpTxn          **failedTxn,        /* Rejected Transactions */
CmTptAddr          *tptAddr,           /* Destination Tx Addr */
MgTptSrvr          *srvr,              /* Local Socket for Transmission */
MgTSAPCb           *tsap               /* TSAP Control Block */
)
#else
PRIVATE S16 mgMgcpPrcEachTxnReq(ssapTxSrvr, delPeer, peer, ssap, txn, failedTxn,
                                tptAddr, srvr, tsap)
Bool               ssapTxSrvr;         /* SSAP owns Local Tx Socket ? */
Bool               *delPeer;           /* Delete Peer */
MgPeerCb           *peer;              /* Peer Control Block */
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgcpTxn          *txn;               /* Transaction to be Transmitted */
MgMgcpTxn          **failedTxn;        /* Rejected Transactions */
CmTptAddr          *tptAddr;           /* Destination Tx Addr */
MgTptSrvr          *srvr;              /* Local Socket for Transmission */
MgTSAPCb           *tsap;              /* TSAP Control Block */
#endif
{
   Bool            immTx;              /* Transmit Immediately */
   Bool            dontPrcCmd;         /* Don't process rest of command */
   Bool            xmit;               /* Is it possible to Xmit */
   Bool            dumpTxn;            /* Dump Transaction in case of error */
   U16             numMsg;             /* Number of messages */
   U16             loopIdx;            /* Loop Index */
   S16             ret;                /* Return Value */
   U16             event;              /* Usta Event */
   U32             mgtError;           /* MGT Interface Error */
   MsgLen          crntPduLen;         /* Current PDU Length */
   CmAbnfErr       err;                /* ABNF Encoding Error */
   CmTptAddr       responseAddr;       /* Remote Address For Tx of Response */
   CmTptAddr       *transmitAddr;      /* Remote Address to Tx to */
   MgMgcpTxn       *discardTxn;        /* Structure for discarded messages */
   MgTxTransIdEnt  *txCb;              /* Command Transaction Control Block */
   MgRxTransIdEnt  *rxCb;              /* Response Transaction Control Block */
   MgMgcpMsg       *msg;               /* MGCP Message */
   Buffer          *mBuf;              /* Message Buffer */
   Buffer          *concatMbuf;        /* PiggyBacked Buffer */
#ifdef GCP_VER_1_3
   MgTxBufInfo     *txBufInfo;         /* Transmitted buffer information*/
#endif /* GCP_VER_1_3 */
   MgTransId       transId;            /* Transaction Id */
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
   Bool            genRtUpd = FALSE;
   MgTxTransIdEnt  *txCbArray[MGT_MAX_MSG];
   U32             count = 0;
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */
   MsgLen          bufLen;;            /* Current Buffer Length */


   TRC2(mgMgcpPrcEachTxnReq)

   /* Initialise variables */
   xmit         = FALSE;
   discardTxn   = NULLP;
   transmitAddr = NULLP;
   concatMbuf   = NULLP;
#ifdef GCP_VER_1_3
   txBufInfo    = NULLP;
#endif /* GCP_VER_1_3 */
   

   /*
    * For Piggybacking, UDP header + message separator needs to be added as
    * length, so initialise crntPduLen accordingly
    */
   crntPduLen = MG_UDP_HDR_LEN;   

   /*
    * All commands should be dumped in case of error, response shouldn't be 
    * dumped after a point; See dumpTxn = FALSE case below
    */
   dumpTxn    = TRUE; 

   /* Process each transaction from the user */
   numMsg = txn->numMsg;
   dontPrcCmd = FALSE;
   event    = 0;
   mgtError = 0;
   for (loopIdx = 0; loopIdx < numMsg; loopIdx++)
   {
      /* Initialise variables used inside the loop */

      Bool     crtTxCb;   /* whether to process command */
      immTx    = FALSE;
      txCb     = NULLP;
      rxCb     = NULLP;
      mBuf     = NULLP;

      /* Obtain message pointer */
      if ((msg = txn->mgcpMsg[loopIdx]) == NULLP)
         continue;

      crtTxCb = TRUE;

#ifdef ZG_DFTHA
      /* If this msg is cmd and it's transId/Rset doesn't lie on this 
       * Copy (Node/Processor ) then don't create txCb for this cmd.
       */
      if(msg->msgType.val != MGT_MSG_RSP)
      {
         MG_MGCP_GET_TRANSID(msg, transId);
         if(!zgChkNCRsetStatus(transId, LMG_PROTOCOL_MGCP, 
            peer, (msg->msgType.val), MG_TRANS_TYPE_TX, 
            srvr->suRsetId, NULLP, 0))
         {
            /* make crtTxCb False , also call PLDF fn to send this piggybacked
             * txn to appropriate copy */
            crtTxCb = FALSE;
            zgPldfSendPiggyBkdMsg(ssap->ssapCfg.sSAPId,peer->accessInfo.peerId,
               txn,loopIdx);
         }
      }
#endif /* ZG_DFTHA */

      /* Verify is message is in conformance with local entity */
      MG_VERIFY_TX_MGCP_MSG_ENT_RELATION(msg->msgType.val,
                                         mgCb.genCfg.entType, ret);
      if (ret != ROK)
      {
         mgtError = MGT_ERR_INVALID_MSG;
         goto TXNREQ_ERROR_PROCESSING;
      }
     
      if (mgGetMsg(tsap->tsapCfg.memId.region, tsap->tsapCfg.memId.pool,
                  &(mBuf)) != ROK)
      {
         mgtError = MGT_ERR_RSRC_UNAVAIL;
         event    = LCM_EVENT_DMEM_ALLOC_FAIL;
         goto TXNREQ_ERROR_PROCESSING;
      }

      if (msg->msgType.val == MGT_MSG_RSP)
      {
         /* Process the Outgoing Response */
         if ((mgMgcpPrcRspInTxnReq(delPeer, peer, msg, &responseAddr, &rxCb,
                                   &mgtError, mBuf)) != ROK)
         {
            goto TXNREQ_ERROR_PROCESSING;
         }
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
         /* 
          * Since this is a response, a modify run time upd needs to be
          * generated. As mBuf is a part of rtUpd, send after encoding hasbeen
          * done 
          */
         genRtUpd = TRUE;
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */

         /* Mark the response for immediate transmission */
         immTx = TRUE;

         /* Mark the address to be used for Transmission */
         transmitAddr = &(responseAddr);
      }
      else if(crtTxCb == TRUE)
      {
         if(dontPrcCmd == TRUE)
         {
            /* send same MGT_ERROR and EVENT as that of previous wrong command
             * */
            goto TXNREQ_ERROR_PROCESSING;
         }
         /* we are here..this means..this is command and also txCb needs to be
          * created ..since crtTxCb is true. crtTxCb as False implies that this
          * command was sent through PLDF to appropriate copy. */ 
#ifdef  GCP_2705BIS
         /* If this first txn (cmd ) in the message , then get memory for 
          * txBufInfo. */
         if(txBufInfo == NULLP)
         {
            if((txBufInfo = (MgTxBufInfo *)mgMalloc(sizeof(MgTxBufInfo))) ==
               NULLP)
            {
               mgtError = MGT_ERR_RSRC_UNAVAIL;
               event = LCM_EVENT_SMEM_ALLOC_FAIL;
               goto TXNREQ_ERROR_PROCESSING;
            }
            else
            {
               txBufInfo->mBuf = NULLP;
               txBufInfo->expctdRspCnt = 0;
               txBufInfo->rcvdRspCnt =0;
               txBufInfo->retxCnt = 0;
            }
         }
         txBufInfo->expctdRspCnt++;
         /* Process the Received Command */
         if ((ret = mgMgcpPrcCmdInTxnReq(peer, msg, tptAddr, srvr, 
               &txCb, &mgtError, (Void *)txBufInfo, &immTx, tsap)) == RFAILED)
#else  /* GCP_2705BIS */
         if ((ret = mgMgcpPrcCmdInTxnReq(peer, msg, tptAddr, srvr, 
               &txCb, &mgtError, (Void *)mBuf, &immTx, tsap)) == RFAILED)
#endif /* GCP_2705BIS */
         {
            if (mgtError == MGT_ERR_RSRC_UNAVAIL)
               event    = LCM_EVENT_SMEM_ALLOC_FAIL;
            goto TXNREQ_ERROR_PROCESSING;
         }
#ifdef ZG_DFTHA
         else if(ret == ROKDNA)
         {
            /* Now txn should be queued here..this will be processed once state
             * update will be received from master */
            mgQueueRvUpdTxnReq(txn, &peer->usrTxnQ, tsap->rvNode,
                               LMG_PROTOCOL_MGCP, ssap->ssapCfg.sSAPId);
            /* Free resources; don't free txn as txn is queued */
            if (mBuf != NULLP)
               mgPutMsg(mBuf);
#ifdef GCP_2705BIS
            if(txBufInfo)
               mgDeAlloc((Data *)txBufInfo, sizeof(MgTxBufInfo));
#endif /* GCP_2705BIS */

            RETVALUE(ROKDNA);
         }
#endif /* ZG_DFTHA */

#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
        txCbArray[count] = NULLP;
        if(NULLP != txCb)
        {
           txCbArray[count] = txCb;
           count++;
        }
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */

#ifdef GCP_VER_1_3
         /* Check if any response to be acked for this peer..if yes then
          * construct response ack parameter and add into command */
         /* mg002.105: rspAckEnb is now reconfigurable */
         if(mgCb.genCfg.reCfg.rspAckEnb & LMG_EMBD_RSPACK_MGCP) 
         {
            /* Now go through peer->txnAckQ list, and form response ack
             * parameter*/
            MgTxnAckList   *node;
            MgTxnAckList   *prv;
            U8              cnt;
            node = peer->txnAckQ.next;
            cnt = 0;
            /* Look into list..corresponding to each node for one response ack
             * parameter */
            while((peer->txnAckQ.next))
            {
               MgRspAck   *ack[MGT_MAX_RSP_ACK];
               MgTransId   trId;
               MgTransId   oldTrId;
               /* Store trId */
               oldTrId = node->info.trId;
               trId = oldTrId;
               /* Get memory for response ack */
               if((cmGetMem(&(msg->memCp), sizeof(MgRspAck), 
                     (Ptr *)&(ack[cnt]))) != ROK)
               {
                  mgtError = MGT_ERR_RSRC_UNAVAIL;
                  event    = LCM_EVENT_DMEM_ALLOC_FAIL;
                  /* mgMgcpFillRspAck(ack,msg,cnt); */
                  goto TXNREQ_ERROR_PROCESSING;
               }
               /* Stop the timer, since we rcved command from SU */
               if(node->info.tmr.tmrEvnt == MG_30SEC_ACK_TMR)
                  mgStopTmr(node->info.tmr.tmrEvnt,(PTR)node,&(node->info.tmr));
               /* check if txnAck range can be formed */
               prv = node;
               while((node->next != NULLP)&&(node->next->info.trId == trId + 1))
               {
                  if(node->next->info.tmr.tmrEvnt == MG_30SEC_ACK_TMR)
                     mgStopTmr(node->next->info.tmr.tmrEvnt,(PTR)node->next,
                     &(node->next->info.tmr));
                  prv = node->next;
                  trId = node->next->info.trId;
                  /* Free node */
                  mgDeAlloc((Data *)node,sizeof(MgTxnAckList));
                  node = prv;
               }
               /* fill the parameters */
               ack[cnt]->pres.pres = PRSNT_NODEF;
               ack[cnt]->lowBnd.pres = PRSNT_NODEF;
               ack[cnt]->lowBnd.val = oldTrId;
               ack[cnt]->upperBnd.pres = PRSNT_NODEF;
               ack[cnt]->upperBnd.val = node->info.trId;
               /* check if lower and upper bound is same ..then make upperBnd
                * not present */
               if(ack[cnt]->upperBnd.val == ack[cnt]->lowBnd.val)
               {
                  ack[cnt]->upperBnd.pres = NOTPRSNT;
               }

               peer->txnAckQ.next = node->next;
               /* Free node */
               mgDeAlloc((Data *)node,sizeof(MgTxnAckList));
               cnt++;
               /* if list is empty or..we have allready reached max no of Ack to
                * be sent with one command , then add these parameters into
                * command and send it. If any more ACks are pending then it will
                * be sent with next command. */ 
               if((peer->txnAckQ.next == NULLP)||(cnt == MGT_MAX_RSP_ACK))
               {
                  mgMgcpFillRspAck(ack,msg,cnt);
                  break;
               }
            }
         }
#endif
         /* Mark the address to be used for Transmission */
         transmitAddr = tptAddr;
      }

      /* Encode the message for transmission */
      if ((cmAbnfEncPduMsg(peer->mntInfo.variant,
                           (U8 *)(&msg->msgType), mBuf, &mgMsgDef, 
                           &(tsap->tsapCfg.memId), &err)) != ROK)
      {
         mgtError = MGT_ERR_INVALID_PARMS;
         goto TXNREQ_ERROR_PROCESSING;
      }

      /*
       * Addition; If Encoded Transaction Exceeds MTU Size
       * Indicate Error to the User
       */
      ret = ROK;
      MG_CHK_MTU_SIZE(mBuf, bufLen, peer, ret);
      if (ret != ROK)
      {
         mgtError = MGT_ERR_MSG_LENGTH;
         event = MG_NONE;
         goto TXNREQ_ERROR_PROCESSING;
      }


#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
      if(genRtUpd == TRUE)
      {
         zgRtUpd(ZG_CBTYPE_TXN_RX, (Ptr)rxCb, CMPFTHA_UPDTYPE_NORMAL,
                       CMPFTHA_ACTN_MOD);
         zgUpdPeer();
      }
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */

      /*
       * Further processing should be done only if buffer can be transmitted
       * else encoded buffer by now should already be queued appropriately and
       * will be transmitted at some later point of time due to appropriate
       * trigger
       */
      if (xmit == FALSE)
      {
         if ( ((peer->state == LMG_PEER_STATE_ACTIVE) || 
              (peer->state == LMG_PEER_STATE_REGISTER)))
         {        
            xmit = TRUE;
         }
      }

#if (!(defined(GCP_VER_1_3) && defined(GCP_2705BIS))) 
     /* If txCb is going to be queued..then xmit will be false..so in fn
      * mgMgcpXmitTxnReq transmit message only if xmit is true ( for
      * command) responses will be transmitted if immTx is TRUE. This fn
      * concatnates encoded mBuf into concatMbuf */
      if (xmit == TRUE)
#endif /* GCP_VER_1_3 */
      {
         /*
          * After this point, we just need to transmit the buffer; If an
          * error is encountered; it is going to be a memory shortage error
          * At this point, we shouldn't deleted rxCb as it has queued response
          * which can be used if we receive retransmission; txCb should be 
          * deleted as we couldn't transmit command
          */
         if (rxCb != NULLP)
            dumpTxn = FALSE;
            
#ifdef GCP_VER_1_3
         if ((mgMgcpXmitTxnReq(immTx, msg->msgType.val, &crntPduLen, peer, 
                               transmitAddr, mBuf, &concatMbuf, 
                               &mgtError, srvr, &txBufInfo, xmit, tsap)) != ROK)
#else
         if ((mgMgcpXmitTxnReq(immTx, msg->msgType.val, &crntPduLen, peer, 
                               transmitAddr, mBuf, &concatMbuf, 
                               &mgtError, srvr, tsap)) != ROK)
#endif /* GCP_VER_1_3 */
         {
            if (mgtError == MGT_ERR_RSRC_UNAVAIL)
               event = LCM_EVENT_DMEM_ALLOC_FAIL;

            goto TXNREQ_ERROR_PROCESSING;
         }
         /*
          * Since Transport Servers are being used in a round-robin fashion
          * Update the next server to be used for a transaction request. DO
          * this only if the immTx flag was TRUE. For concat buffer, this
          * would be done later.
          */
         if(TRUE == immTx)
         {
            mgMgcpUpdateNxtUseSrvrForTx(ssap, tsap, ssapTxSrvr);
         }
         /* If 30 sec timer is not enabled. 
            Remove transaction after transmission */
         if ((rxCb != NULLP) && 
             (msg->t.mgcpRsp.rspCode.val == MGT_MGCP_RSP_CODE_OK) &&
             (rxCb->tmr[MG_30SEC_TMR - MG_INTXN_TMR_BASE].tmrEvnt == TMR_NONE))
         {
           /* Free resources associated with transaction */
           mgDeAllocRxTransIdEnt(rxCb->peer, rxCb, TRUE);
         }
      }

      /* Error Processing Label */
TXNREQ_ERROR_PROCESSING:

      if (mgtError > 0)
      {
#ifdef GCP_2705BIS
         if(txBufInfo)
            mgDeAlloc( (Data *)(txBufInfo), sizeof(MgTxBufInfo));
#endif /* GCP_2705BIS */
         if (msg->msgType.val == MGT_MSG_NONSTD) 
           transId = msg->t.nonStdCmd.cmd.cmdLine.trId.val;
         else if (msg->msgType.val == MGT_MSG_RSP)
           transId = msg->t.mgcpRsp.trId.val;
         else
           transId = msg->t.epcfCmd.cmdLine.trId.val;

         if (dumpTxn == TRUE)
         {
            /* we are here..means one of command in piggybacked txn
             * generated error so we  shouldnot process rest of command 
             * either. Only if it response should be processed */
            dontPrcCmd = TRUE;
            
            MG_ALLOC_DISCARD_TXN_STRUCT(txn, discardTxn, ret, ssap);
            MG_COLLECT_DISCARDED_TXN(discardTxn, msg, mgtError, transId);
            MG_FREE_RSRCS_ON_TXNREQ_ERROR(mBuf, txn, loopIdx, txCb, rxCb);
            
         }
         else
            dumpTxn = TRUE;   /* Reset the flag */

         if (event > 0)
         {
            if (event == LCM_EVENT_DMEM_ALLOC_FAIL)
            {
               MG_GEN_RSRC_CATEG_ALRM(STTSAP, event, tsap->tsapCfg.memId.region,
                                      tsap->tsapCfg.memId.pool);
            }
            else
            if (event == LCM_EVENT_SMEM_ALLOC_FAIL)
            {
               MG_GEN_RSRC_CATEG_ALRM(STSSAP, event, mgCb.init.region, 
                                      mgCb.init.pool);
            }
         }
         continue;

      } /* end of if (err == TRUE) */
#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
      /* If this message is command then free mBuf */
      if((msg->msgType.val) != MGT_MSG_RSP) 
      {   
         if (mBuf != NULLP)
            mgPutMsg(mBuf);
      }   
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */
   } /* end of for (loopIdx) */

#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
/* Update tranmitted buffer information */
      if(concatMbuf != NULLP)
      {
         /* Get a refrence of concatMbuf into mBuf..as concatBuf will be freed
          * in service provider while transmitting the buffer */
         if ((SAddMsgRef (concatMbuf, tsap->tsapCfg.memId.region, 
                    tsap->tsapCfg.memId.pool, &(mBuf))) != ROK)
         {
            MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
             mgCb.init.region, mgCb.init.pool);
            RETVALUE(RFAILED);
         }
         txBufInfo->mBuf = mBuf;
      }
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */
   /* 
    * After this for loop, each txCb->mBuf or txBufInfo->mBuf will have 
    * required encoded message. Generate RtUpd for all txCbs so that standby
    * also has the same txBufInfo 
    */
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
   {
      U32    idx;
      idx = 0;
      for(idx=0; idx<count; idx++)
      {
         if(txCbArray[idx] != NULLP)
         {
            zgRtUpd(ZG_CBTYPE_TXN_TX, (Ptr)txCbArray[idx], 
                      CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);
         }
      }
      zgUpdPeer();
   }
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */

   if (concatMbuf != NULLP)
   {
      /* we have a piggybacked buffer for transmission */
#ifdef    GCP_PROV_SCTP
      MG_TRANSMIT_PDU(peer, peer->assocCb, NULLP, FALSE, srvr,
                      tptAddr, concatMbuf);
#else     /* GCP_PROV_SCTP */
      MG_TRANSMIT_PDU(peer, srvr, tptAddr, concatMbuf);
#endif    /* GCP_PROV_SCTP */

      /*
       * Since Transport Servers are being used in a round-robin fashion
       * Update the next server to be used for a transaction request
       */
      mgMgcpUpdateNxtUseSrvrForTx(ssap, tsap, ssapTxSrvr);
   }

   /* Return the rejected transactions if any */
   *failedTxn = discardTxn;

   RETVALUE(ROK);

} /* end of mgMgcpPrcEachTxnReq() */
#endif /* GCP_MGCP */
#ifdef GCP_MGCO

/*
*       Fun:   mgPrcMgcoTxn
*
*       Desc:  Process Each transaction in the MEGACO message received
*              from the user
*
*       Ret:   ROK - SUCCESS;
*              RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/
#ifdef    GCP_PROV_SCTP

#ifdef ANSI
PRIVATE S16 mgPrcMgcoTxn
(
MgSSAPCb           *ssap,           /* SSAP Control Block */
MgMgcoMsg          *mgcoMsg,        /* Transaction */
MgPeerCb           *peer,           /* Peer Control Block */
MgAssocCb          *assoc,          /* Association Control Block */
TknU32             ctxId,           /* Context-ID */
MgTptSrvr          *srvr,           /* Transport Server */
MgMgcoMsg          **errMsg,        /* Error Message */
Buffer             **mBufPtr,       /* Message buffer double ptr */
Buffer             *hdrMBuf,        /* Header Buffer */
Bool               *msgSend,        /* Message present in mBuf */
U8                 source,          /* Initiated by user/ internal */
MsgLen             *crntLen,         /* current length of buffer */
U32                txnIdx           /* Index of transaction in the message */
)
#else
PRIVATE S16 mgPrcMgcoTxn(ssap, mgcoMsg, peer, assoc, ctxId, srvr, errMsg,
                         mBufPtr, hdrMBuf, msgSend, source, crntLen, txnIdx)
MgSSAPCb           *ssap;           /* SSAP Control Block */
MgMgcoMsg          *mgcoMsg;        /* Transaction */
MgPeerCb           *peer;           /* Peer Control Block */
MgAssocCb          *assoc;          /* Association Control Block */
TknU32             ctxId;           /* Context-ID */
MgTptSrvr          *srvr;           /* Transport Server */
MgMgcoMsg          **errMsg;        /* Error Message */
Buffer             **mBufPtr;       /* Message buffer */
Buffer             *hdrMBuf;        /* Header Buffer */
Bool               *msgSend;        /* Message present in mBuf */
U8                 source;          /* Initiated by user/ internal */
MsgLen             *crntLen;        /* current length of buffer */
U32                txnIdx;          /* Index of transaction in the message */
#endif 

#else     /* GCP_PROV_SCTP */

#ifdef ANSI
PRIVATE S16 mgPrcMgcoTxn
(
MgSSAPCb           *ssap,           /* SSAP Control Block */
MgMgcoMsg          *mgcoMsg,        /* Transaction */
MgPeerCb           *peer,           /* Peer Control Block */
MgTptSrvr          *srvr,           /* Transport Server */
MgMgcoMsg          **errMsg,        /* Error Message */
Buffer             **mBufPtr,       /* Msg buffer double ptr */
Buffer             *hdrMBuf,        /* Header Buffer */
Bool               *msgSend,        /* Message present in mBuf */
U8                 source,          /* Initiated by user/ internal */
MsgLen             *crntLen,         /* current buffer length */
U32                txnIdx           /* Index of transaction in the message */
)
#else
PRIVATE S16 mgPrcMgcoTxn(ssap, mgcoMsg, peer, srvr, errMsg, mBufPtr, hdrMBuf,
                         msgSend, source, crntLen, txnIdx)
MgSSAPCb           *ssap;           /* SSAP Control Block */
MgMgcoMsg          *mgcoMsg;        /* Transaction */
MgPeerCb           *peer;           /* Peer Control Block */
MgTptSrvr          *srvr;           /* Transport Server */
MgMgcoMsg          **errMsg;        /* Error Message */
Buffer             **mBufPtr;       /* Message buffer */
Buffer             *hdrMBuf;        /* Header Buffer */
Bool               *msgSend;        /* Message present in mBuf */
U8                 source;          /* Initiated by user/ internal */
MsgLen             *crntLen;        /* current length of buffer */
U32                txnIdx;           /* Index of transaction in the message */
#endif 

#endif    /* GCP_PROV_SCTP */
{
   MgTransId       transId;            /* Transaction Identifier */
   Bool            txnSend;            /* Send transaction /not */
   U8              ackType;            /* Acknowledgement Type */
   MgTxTransIdEnt  *txCb;              /* Outgoing Transaction Control Block */
   MgRxTransIdEnt  *rxCb;              /* Incoming Transaction Control Block */
   Buffer          *txnMBuf;           /* Buffer for encoded transaction */
   CmTptAddr       rspRemAddr;         /* Remote Address for Response */
   CmTptAddr       remoteAddr;         /* Remote Address for SendingCommands */
   MgSvcChgInfo    svcChgInfo;         /* Service Change Information */   
   Bool            svcChgRsp;          /* Service Change Response/not */
   S16             ret;                /* Return Value */
   Bool            immAck;             /* Immediate Ack field to be set/ not */
   Buffer          *tmpTxnBuf;         /* Buffer to transmit */
   MgMgcoTxn       *mgcoTxn;           /* MEGACO Transaction */

/* mg002.105: Changes to test exceed maximum PDU size */
#if (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))   
   MgcoTptInfo      mgcoTptInfo; /* Megaco Transport Information */
#endif   /* GCP_PROV_MTP3 || GCP_PROV_SCTP */
   

   TRC2(mgPrcMgcoTxn)

   if (mgcoMsg == NULLP)
      RETVALUE(ROK);

   mgcoTxn = mgcoMsg->body.u.tl.txns[txnIdx];

   if (mgcoTxn == NULLP)
      RETVALUE(ROK);


   if (mgcoTxn == NULLP)
      RETVALUE(ROK);
         
   /* Initialize Variables */


   txnMBuf   = NULLP;
   tmpTxnBuf = NULLP;
   txCb      = NULLP;
   rxCb      = NULLP;
   ackType   = MG_NONE;
   immAck    = FALSE;

   remoteAddr.type = CM_TPTADDR_NOTPRSNT;
   rspRemAddr.type = CM_TPTADDR_NOTPRSNT;

   /* Get Transaction Id from the Event Structure */
   MG_GET_TRANSID(mgcoTxn, transId);

/* mg002.105: Changes to test exceed maximum PDU size */
#ifdef GCP_PROV_SCTP   
   if (peer->accessInfo.transportType == LMG_TPT_SCTP)
   {/* Copy the Trasport Inforamtion in a Structure to be passed to function */
     mgcoTptInfo.tptType   = LMG_TPT_SCTP;
     mgcoTptInfo.u.assocCb = peer->assocCb;
   }
#endif /* GCP_PROV_SCTP */
#ifdef GCP_PROV_MTP3   
   if (peer->accessInfo.transportType == LMG_TPT_MTP3)
   {
     /* Copy all MTP information in a structure and pass it to TxnInd
       * function 
       */
     mgcoTptInfo.tptType               = LMG_TPT_MTP3;
     mgcoTptInfo.u.mgMtpInfo.mtpPeer   = peer;
     mgcoTptInfo.u.mgMtpInfo.clgAddr   = peer->mgcoMtpCb.peerDpc;
     mgcoTptInfo.u.mgMtpInfo.cldAddr   = peer->ssap->ssapCfg.userInfo.selfPc.val; /*This should be our Address */
   }
#endif /* GCP_PROV_MTP3 */

   

   /* Get Buffer to store encoded transaction */
   if (mgGetMsg(peer->tsap->tsapCfg.memId.region,
                peer->tsap->tsapCfg.memId.pool,
                &(txnMBuf)) != ROK)
   {
      /* Error Recovery */
      MG_FILL_MGCO_ERR_MSG(errMsg, MGT_ERR_RSRC_UNAVAIL, \
                           txnMBuf, rxCb, txCb, transId);
      MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                             peer->tsap->tsapCfg.memId.region,
                             peer->tsap->tsapCfg.memId.pool);
      RETVALUE(ROK);
   }

   switch (mgcoTxn->type.val)
   {
      case MGT_TXNREQ:
      {
         /* If txn is a Transaction request */
         if (mgcoTxn->u.req.pres.pres == NOTPRSNT)
            RETVALUE(ROK);
            
         /*
          * Check if we have resources to process this transaction
          * This check is done only for outgoing transactions as that
          * is where we allocate resources in our layer...for outgoing
          * response no resource in our layer is allocated
          */
         if (mgAdmitTxn(ssap, peer->tsap) != ROK)
         {
            MG_FILL_MGCO_ERR_MSG(errMsg,MGT_ERR_RSRC_UNAVAIL, 
                                 txnMBuf, rxCb, txCb, transId);
            RETVALUE(ROK);
         }

         txnSend = FALSE;

         /* 
          * Fill the Pending limit to the peer
          */
#if (defined (GCP_VER_1_5) && defined(GCP_MGC))        
         /* Transaction request from the User, Check for limits if */
         /* present  and fill in peer Block */
         mgGetPendingLimit(mgcoTxn, peer);

         /*Get the provisional response timer values */
         mgGetProvRspTmrVal(mgcoTxn,peer);

#endif /* GCP_VER_1_5 GCP_MGC */   


         /* 
          * Process Outgoing Transaction. This function starts transaction
          * timers if necessary or it queues the message (depending on peer
          * state)
          */
         if ((txCb = mgPrcOutGoingTxn(transId, mgcoTxn->type.val,
                                      MG_NONE, FALSE,
                                      &remoteAddr, ssap, peer, 
#ifdef    GCP_PROV_SCTP
                                      assoc,
#endif    /* GCP_PROV_SCTP */
                                      srvr,
                                      (Void *)txnMBuf,
                                      &txnSend)) == NULLP)
         {
            MG_FILL_MGCO_ERR_MSG(errMsg, MGT_ERR_RSRC_UNAVAIL, 
                                 txnMBuf, rxCb, txCb, transId);
            MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_SMEM_ALLOC_FAIL,
                                 mgCb.init.region, mgCb.init.pool);
            RETVALUE(ROK);
         }

         /* 
          * If txnSend is true  the transaction is ready to be transmitted. In
          * such a case the transaction needs to be appended to the mBuf which 
          * is to be transmitted. Once all the processing is done there needs 
          * to be marker to indicate that there valid transactions in the mBuf 
          * and that the mBuf needs to be transmitted. 
          * The msgSend flag is used to indicate this. 
          */
         if (txnSend == TRUE)
            *msgSend = TRUE;
      }
      break;
            
      /* If message is a provisional response */
      case MGT_TXNPEND:
      {
         if (mgcoTxn->u.pend.pres.pres == NOTPRSNT)
         RETVALUE(ROK);

         ackType = MG_RESPONSE_PROV;

         /* Fall Through */             
      }

      /* If message is a Reply to a previously received transaction */
      case MGT_TXNREPLY:
      {
         if (mgcoTxn->type.val == MGT_TXNREPLY) 
         {
            if (mgcoTxn->u.reply.pres.pres == NOTPRSNT)
               RETVALUE(ROK);

            ackType = MG_RESPONSE;
         }


         /*
          * Check if it is a response to service change message 
          */

         svcChgRsp = FALSE;
         if (mgcoTxn->type.val == MGT_TXNREPLY)
         {
            /* Don't do this for provisional responses */
            svcChgRsp = mgChkForSrvcChgRsp(peer, mgcoTxn);
         }
         
         /* Process te outgoing response */
         if ((rxCb = mgPrcOutGoingAck(LMG_PROTOCOL_MGCO, ackType, transId,
                                      peer, txnMBuf, &immAck,
                                      svcChgRsp)) == NULLP)
         {
            MG_FILL_MGCO_ERR_MSG(errMsg, MGT_ERR_INVALID_TRANS, 
                                 txnMBuf, rxCb, txCb, transId);
            RETVALUE(ROK);
         }
         /* Store the remote address for transmission */
         cmMemcpy((U8 *)&(rspRemAddr), (CONSTANT U8 *)&(rxCb->tptAddr),
                  sizeof(CmTptAddr));

         /* Mark the message for encoding */
         txnSend = TRUE;

         /* If provisional response */
         if (mgcoTxn->type.val != MGT_TXNREPLY)
            break;


         if (immAck == TRUE)
            MG_SET_IMMACK_FLAG(mgcoTxn);

         /* 
          * If message is a service change rsponse additional
          * processing would be * necessary.
          * So we need to chk for service change response. 
          */
         if (svcChgRsp == TRUE)
         {
            mgFillSvcChgInfo(MG_SRVC_CHG_REPLY, mgcoTxn, &svcChgInfo);
            if (RFAILED == mgPrcUserRegRsp(peer, rxCb,
                                           (Ptr)&svcChgInfo))
              RETVALUE(RFAILED);
              
         }
      }
      break;
    
      case MGT_TXNRSPACK:
      {
         if (mgcoTxn->u.req.pres.pres == NOTPRSNT)
            RETVALUE(ROK);

         txnSend = TRUE;
      }
      break;
    
   } /* end switch */


   /* Encode Buffer  */
   if ((ret= mgFillMgcoMsgBuf(*mBufPtr,hdrMBuf, txnMBuf, mgcoMsg, txnIdx, &txnSend, 
                              crntLen, peer->tsap,
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
                              peer->mgcoInfo.encodingScheme,
#endif
                              peer)) != MGT_NONE)
   {
      /*
       * Addition
       * If the encode transaction exceeds configured MTU Size; 
       * return Error to User
       */

      if (ret == MG_MSG_SZ_EXCEDED)
      {
         /* mg002.105: Changes to test exceed maximum PDU size */
         MgMgcoTxn*      errTxn; /* MEGACO txn */
         
         MG_FILL_MGCO_ERR_MSG(errMsg, MGT_ERR_MSG_LENGTH, 
                              txnMBuf, rxCb, txCb, transId);
         errTxn = mgcoMsg->body.u.tl.txns[txnIdx];
         
         if((txnSend == TRUE) && (errTxn->type.val == MGT_TXNREPLY))
         {

            /* mg007.105: added code to retrieve error statistics */
            MG_UPD_MGCO_PEER_ERROR_STS(MGT_MGCO_RSP_CODE_PDU_SIZE_EXCEED, TRUE, peer, mgcoMsg);
#ifdef GCP_VER_1_3
      
            mgMgcoSendErrRsp(peer->tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                       & mgcoTptInfo,
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
                       srvr, 
                       &rxCb->tptAddr,
                       MGT_MGCO_RSP_CODE_PDU_SIZE_EXCEED,
                       NULLP,
                       transId);
#else
            mgMgcoSendErrRsp(srvr,
                       &rxCb->tptAddr,
                       MGT_MGCO_RSP_CODE_PDU_SIZE_EXCEED,
                       errMsg);
#endif /* GCP_VER_1_3 */
         }   
         RETVALUE(ret);
      }

      /* 
       * If message has reached max possible length transmit the message and
       * allocate a new mBuf for the remaining transactions 
       */
      if (ret == MG_PDU_SZ_EXCEDED)
      {
         MG_UPD_MGCO_PEER_TX_STS(mgcoTxn->type.val, peer->peerSts);
         /* now passing *mBufPtr */


         mgTransmitMgcoMsg(peer,
#ifdef    GCP_PROV_SCTP
                           assoc,
                           ctxId,
#endif    /* GCP_PROV_SCTP */
                           srvr,
                           &rspRemAddr, *mBufPtr, NULLP);


         rspRemAddr.type = CM_TPTADDR_NOTPRSNT;
         /*
          * Allocate new mBuf for remaining txns
          * if condition added to prevent retransmission of 
          *             the buffer; Mark *mBufPtr as it has been transmitted
          */
         *mBufPtr = NULLP;

         if (txnSend == TRUE)
         {
            ret = mgFillNewMgcoBuf(mBufPtr, hdrMBuf, txnMBuf,
                                   crntLen, txnSend, peer->tsap);
            /*
             * If above function fails, mark msgSend as FALSE.
             *             In such error cases, the deallocation of
             *             *mBufPtr is done in mgPrcMgcoTxnReq while the
             *             deallocation of the other temporary buffers
             *             is done in the above function itself.
             */
            if (ret == MGT_ERR_RSRC_UNAVAIL)
            {
               *msgSend = FALSE;
            }
            RETVALUE(ret);
         }
         else
         {
            /*
             * Since we have already sent the single transaction with
             * hdr, there is no need to send it again
             */
            *msgSend = FALSE;
            RETVALUE(MGT_NONE);
         }
      }

      if (ret == MGT_ERR_RSRC_UNAVAIL)
      {
         MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                 peer->tsap->tsapCfg.memId.region,
                                 peer->tsap->tsapCfg.memId.pool);
      }

      MG_FILL_MGCO_ERR_MSG(errMsg, (U8)ret, txnMBuf, rxCb, txCb, transId);
      RETVALUE(ROK);
   }

#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
   if(rxCb != NULLP)
   {
      zgRtUpd(ZG_CBTYPE_TXN_RX, (Ptr)rxCb, CMPFTHA_UPDTYPE_NORMAL,
                       CMPFTHA_ACTN_MOD);
   }
   if(txCb != NULLP)
   {
      zgRtUpd(ZG_CBTYPE_TXN_TX, (Ptr)txCb, CMPFTHA_UPDTYPE_NORMAL,
                       CMPFTHA_ACTN_MOD);
   }
   zgUpdPeer();
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */

   MG_UPD_MGCO_PEER_TX_STS(mgcoTxn->type.val, peer->peerSts);

   /* 
    * If it is response it needs to be sent to the address from which the
    * req was received. It doesnot need to be attached to the MBuf 
    */
   if (mgcoTxn->type.val != MGT_TXNREQ)
   {    
      /* Create a copy of buffer as TUCL frees it */
      if (mgcoTxn->type.val == MGT_TXNRSPACK)
      {
         tmpTxnBuf = txnMBuf;
      }
      else
      if ((SAddMsgRef (txnMBuf, peer->tsap->tsapCfg.memId.region, 
                     peer->tsap->tsapCfg.memId.pool, &(tmpTxnBuf))) != ROK)
      {
         MG_FILL_MGCO_ERR_MSG(errMsg, MGT_ERR_RSRC_UNAVAIL, 
                              txnMBuf, rxCb, txCb, transId);
         RETVALUE(ROK);
      }      
      
      /* If 30 sec tmr is not enabled. Remove transaction after transmission */
      if ((mgcoTxn->type.val == MGT_TXNREPLY) && (rxCb != NULLP) && 
         (rxCb->tmr[MG_30SEC_TMR - MG_INTXN_TMR_BASE].tmrEvnt == TMR_NONE))
      {
         /* Free resources associated with transaction */
         mgDeAllocRxTransIdEnt(rxCb->peer, rxCb, TRUE);
      }

      /* Transmit the Response */


      mgTransmitMgcoMsg(peer,
#ifdef    GCP_PROV_SCTP
                        assoc,
                        ctxId,
#endif    /* GCP_PROV_SCTP */
                        srvr,
                        &rspRemAddr, tmpTxnBuf, NULLP);

      /* To ensure that for any subsequent commands, the TPT address is copied
       * from that stored in peerCb */
       
      rspRemAddr.type = CM_TPTADDR_NOTPRSNT;

     RETVALUE(ROK);
   }     
   RETVALUE(ROK);

} /* End of mgPrcMgcoTxn */
#endif /* GCP_MGCO */
#endif /*  CM_ABNF_MT_LIB */

 
#ifdef GCP_MGCO
#ifdef GCP_VER_1_5

#ifdef GCP_PKG_MGCO_ROOT
/*
*       Fun:  mgGetPendingLimit 
*
*       Desc:  This function fills the limit values from the message to
*              the appropriate peer block
*
*       Ret:   ROK - SUCCESS;
*              RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgGetPendingLimit
(
   MgMgcoTxn          *mgcoTxn,        /* Transaction */
   MgPeerCb           *peer            /* Peer Control Block */
)
#else
PUBLIC S16 mgGetPendingLimit(mgcoTxn, peer)
   MgMgcoTxn          *mgcoTxn;        /* Transaction        */
   MgPeerCb           *peer;           /* Peer Control Block */
#endif 
{
   U16                  numOfAxns = 0;        /* Number of action requests    */
   U16                  numOfCmds = 0;        /* Number of command requests   */
   U16                  numOfDescs = 0;       /* Number of Amm Descriptors    */
   U16                  numOfTermStateParm = 0;  /* Number of locCtl Descriptors */
   MgMgcoAmmDesc        *desc = NULLP;        /* Amm Descriptor               */
   U16                  numOfMedDesc = 0;     /* Number of Media Descriptors  */
   U16                  axnCounter = 0;       /* Counter for Axns             */
   U16                  descCounter = 0;      /* Counter for descriptors      */
   U16                  medDescCounter = 0;   /* Counter for media descriptors*/
   U16                  termStateParmCounter = 0;/* Counter for LocCtl           */
                                              /* descriptors                  */
   U16                  cmdCounter = 0;       /* Counter for cmds             */
   MgMgcoActionReq      *tempActns = NULLP;   /* temporary action             */ 
   MgMgcoMediaPar       *medParm = NULLP;     /* Media Property               */
   MgMgcoCommandReq     *cmdReq;              /* Command Request              */
   MgMgcoTermStateParm  *termStateParm = NULLP;  /* Local Ctrl Parameter         */
   U8                    flag = RFAILED;      /* Return Flag                  */


   /* Checking whether it is Transaction Request and if 
    * action present inside it  */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((mgcoTxn->type.pres == NOTPRSNT) || 
       (mgcoTxn->type.val != MGT_TXNREQ) ||
       (mgcoTxn->u.req.pres.pres == NOTPRSNT) ||
       (mgcoTxn->u.req.al.num.pres == NOTPRSNT) ||
       (mgcoTxn->u.req.al.num.val == MGT_NONE))

   {
      RETVALUE(RFAILED);
   } /* if */
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* No. of Actions  */
   numOfAxns = mgcoTxn->u.req.al.num.val;

   /* Browse the Txn Request for actions with NULL context ID  */
   for(axnCounter = 0;axnCounter < numOfAxns; axnCounter++)
   {
      if ((tempActns = ((mgcoTxn->u.req.al.actns)[axnCounter])) == NULLP)       
         RETVALUE(RFAILED);
      if ( (tempActns->cxtId.type.pres != NOTPRSNT) &&
          (tempActns->cxtId.type.val == MGT_CXTID_NULL) && 
          (tempActns->pres.pres != NOTPRSNT) &&
          (tempActns->cl.num.pres != NOTPRSNT) &&
          ((numOfCmds = tempActns->cl.num.val) != 0) ) 

      {
        /* Actions present with commands  */
        for(cmdCounter = 0; cmdCounter < numOfCmds; cmdCounter++)
        {
            if ((cmdReq = ((tempActns->cl.cmds)[cmdCounter])) 
                    == NULLP)
                RETVALUE(RFAILED);
            /* Check for modify command which actualy posses the root properties */
            else if ( (cmdReq->cmd.type.val == MGT_MODIFY) &&
                      (cmdReq->cmd.u.mod.termId.type.pres != NOTPRSNT) &&
                      (cmdReq->cmd.u.mod.termId.type.val == MGT_TERMID_ROOT) &&
                      (cmdReq->cmd.u.mod.dl.num.pres != NOTPRSNT) &&
                      ((numOfDescs = cmdReq->cmd.u.mod.dl.num.val) != 0 ) )
            {
               /* Modify command present with Root termination */
               for (descCounter = 0; descCounter < numOfDescs; descCounter++)
               {
                  if ((desc = ((cmdReq->cmd.u.mod.dl.descs)[descCounter])) == NULLP)
                     RETVALUE(RFAILED);
                  /* Check for media descriptor */
                  else if ((desc->type.pres != NOTPRSNT) &&
                           (desc->type.pres == MGT_MEDIADESC) &&
                           (desc->u.media.num.pres != NOTPRSNT) &&
                           ((numOfMedDesc = desc->u.media.num.val) != 0) ) 
                  {
                     for (medDescCounter = 0; medDescCounter < numOfMedDesc;
                                              medDescCounter ++)
                     {
                        if ((medParm = ((desc->u.media.parms)[medDescCounter])) == NULLP)
                           RETVALUE(RFAILED);
                        else if ((medParm->type.pres != NOTPRSNT) &&
                                 (medParm->type.val == MGT_MEDIAPAR_TERMST) &&
                                 (medParm->u.tstate.numComp.pres != NOTPRSNT) &&
                                 ((numOfTermStateParm = 
                                      medParm->u.tstate.numComp.val) != 0) )
                        {
                           /* media parameter present with termination state */
                           for (termStateParmCounter = 0; 
                                termStateParmCounter < numOfTermStateParm; 
                                termStateParmCounter++)
                           {
                              if ((termStateParm = 
                                 ((medParm->u.tstate.trmStPar)
                                  [termStateParmCounter])) == NULLP)
                                 RETVALUE(RFAILED); 
                              else if ((termStateParm->type.pres != NOTPRSNT) &&
                                       (termStateParm->type.val == 
                                            MGT_TERMST_PROPLST) && 
                                       (termStateParm->u.parm.pkg.pres == PRSNT_NODEF) && 
                                       (termStateParm->u.parm.pkg.val == MGT_PKG_ROOT) &&
                                       (termStateParm->u.parm.name.name.type.pres == PRSNT_NODEF) &&
                                       (termStateParm->u.parm.name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
                                       (termStateParm->u.parm.name.name.u.val.pres == PRSNT_NODEF)) 
                              {
                                 /* Local Control Parameter with ROOT Package */
                                 if (termStateParm->u.parm.name.name.u.val.val == 
                                         MGT_PKG_ROOT_PROP_MGORIGPENDLIMIT)
                                 {
                                    peer->limit.pres.pres = PRSNT_NODEF;
                                    peer->limit.mgOriginatedPendingLimit = 
                                         termStateParm->u.parm.val.u.eq.u.decInt.val;
                                    flag = ROK;
#ifdef ZG
                                    /* mg008.105: Changes corresponding to PSF */
                                    /* send update to peer */
                                    zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, 
                                             CMPFTHA_UPDTYPE_SYNC,
                                             CMPFTHA_ACTN_MOD);
#endif /* ZG */
                                    
                                 } /* if MGT_PKG_ROOT_PROP_MGORIGPENDLIMIT */
                                 else if(termStateParm->u.parm.name.name.u.val.val ==
                                         MGT_PKG_ROOT_PROP_MGCORIGPENDLIMIT)
                                 {
                                    peer->limit.pres.pres = PRSNT_NODEF;
                                    peer->limit.mgcOriginatedPendingLimit =
                                         termStateParm->u.parm.val.u.eq.u.decInt.val;
                                    flag = ROK;
#ifdef ZG
                                    /* mg008.105: Changes corresponding to PSF */
                                    /* send update to peer */
                                    zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, 
                                             CMPFTHA_UPDTYPE_SYNC,
                                             CMPFTHA_ACTN_MOD);
#endif /* ZG */
                                 } /* else if MGT_PKG_ROOT_PROP_MGCORIGPENDLIMIT */
                              } /* else if termStateParm propParm */
                           } /* for termStateParmCounter */
                        } /* else if medParm->type- locCtl */
                     } /* for medDescCounter */
                  } /* else if ((desc->type - media */
               } /* for descCounter */
            } /* else if cmdReq->cmd.type - Modify Check */
        } /* for-cmdCounter */
     } /* if tempActns */
   } /* for - axnCounter */
   RETVALUE(flag);
} /* mgGetPendingLimit */


#ifdef ANSI
PRIVATE S16 mgGetProvRspTmrVal
(
MgMgcoTxn          *mgcoTxn,        /* Transaction */
MgPeerCb           *peer            /* Peer Control Block */
)
#else
PRIVATE S16 mgGetProvRspTmrVal(mgcoTxn, peer)
MgMgcoTxn          *mgcoTxn;        /* Transaction        */
MgPeerCb           *peer;           /* Peer Control Block */
#endif 
{
   U16                  numOfAxns = 0;        /* Number of action requests    */
   U16                  numOfCmds = 0;        /* Number of command requests   */
   U16                  numOfDescs = 0;       /* Number of Amm Descriptors    */
   U16                  numOfTermStateParm = 0;  /* Number of locCtl Descriptors */
   MgMgcoAmmDesc        *desc = NULLP;        /* Amm Descriptor               */
   U16                  numOfMedDesc = 0;     /* Number of Media Descriptors  */
   U16                  axnCounter = 0;       /* Counter for Axns             */
   U16                  descCounter = 0;      /* Counter for descriptors      */
   U16                  medDescCounter = 0;   /* Counter for media descriptors*/
   U16                  termStateParmCounter = 0;/* Counter for LocCtl           */
                                              /* descriptors                  */
   U16                  cmdCounter = 0;       /* Counter for cmds             */
   MgMgcoActionReq      *tempActns = NULLP;   /* temporary action             */ 
   MgMgcoMediaPar       *medParm = NULLP;     /* Media Property               */
   MgMgcoCommandReq     *cmdReq;              /* Command Request              */
   MgMgcoTermStateParm  *termStateParm = NULLP;  /* Local Ctrl Parameter         */
   U8                    flag = RFAILED;      /* Return Flag                  */


   /* Checking whether it is Transaction Request and if 
    * action present inside it  */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((mgcoTxn->type.pres == NOTPRSNT) || 
       (mgcoTxn->type.val != MGT_TXNREQ) ||
       (mgcoTxn->u.req.pres.pres == NOTPRSNT) ||
       (mgcoTxn->u.req.al.num.pres == NOTPRSNT) ||
       (mgcoTxn->u.req.al.num.val == MGT_NONE))

   {
      RETVALUE(RFAILED);
   } /* if */
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* No. of Actions  */
   numOfAxns = mgcoTxn->u.req.al.num.val;

   /* Browse the Txn Request for actions with NULL context ID  */
   for(axnCounter = 0;axnCounter < numOfAxns; axnCounter++)
   {
      if ((tempActns = ((mgcoTxn->u.req.al.actns)[axnCounter])) == NULLP)       
         RETVALUE(RFAILED);
      if ( (tempActns->cxtId.type.pres != NOTPRSNT) &&
          (tempActns->cxtId.type.val == MGT_CXTID_NULL) && 
          (tempActns->pres.pres != NOTPRSNT) &&
          (tempActns->cl.num.pres != NOTPRSNT) &&
          ((numOfCmds = tempActns->cl.num.val) != 0) ) 

      {
        /* Actions present with commands  */
        for(cmdCounter = 0; cmdCounter < numOfCmds; cmdCounter++)
        {
            if ((cmdReq = ((tempActns->cl.cmds)[cmdCounter])) 
                    == NULLP)
                RETVALUE(RFAILED);
            /* Check for modify command which actualy posses the root properties */
            else if ( (cmdReq->cmd.type.val == MGT_MODIFY) &&
                      (cmdReq->cmd.u.mod.termId.type.pres != NOTPRSNT) &&
                      (cmdReq->cmd.u.mod.termId.type.val == MGT_TERMID_ROOT) &&
                      (cmdReq->cmd.u.mod.dl.num.pres != NOTPRSNT) &&
                      ((numOfDescs = cmdReq->cmd.u.mod.dl.num.val) != 0 ) )
            {
               /* Modify command present with Root termination */
               for (descCounter = 0; descCounter < numOfDescs; descCounter++)
               {
                  if ((desc = ((cmdReq->cmd.u.mod.dl.descs)[descCounter])) == NULLP)
                     RETVALUE(RFAILED);
                  /* Check for media descriptor */
                  else if ((desc->type.pres != NOTPRSNT) &&
                           (desc->type.pres == MGT_MEDIADESC) &&
                           (desc->u.media.num.pres != NOTPRSNT) &&
                           ((numOfMedDesc = desc->u.media.num.val) != 0) ) 
                  {
                     for (medDescCounter = 0; medDescCounter < numOfMedDesc;
                                              medDescCounter ++)
                     {
                        if ((medParm = ((desc->u.media.parms)[medDescCounter])) == NULLP)
                           RETVALUE(RFAILED);
                        else if ((medParm->type.pres != NOTPRSNT) &&
                                 (medParm->type.val == MGT_MEDIAPAR_TERMST) &&
                                 (medParm->u.tstate.numComp.pres != NOTPRSNT) &&
                                 ((numOfTermStateParm = 
                                      medParm->u.tstate.numComp.val) != 0) )
                        {
                           /* media parameter present with termination state */
                           for (termStateParmCounter = 0; 
                                termStateParmCounter < numOfTermStateParm; 
                                termStateParmCounter++)
                           {
                              if ((termStateParm = 
                                 ((medParm->u.tstate.trmStPar)
                                  [termStateParmCounter])) == NULLP)
                                 RETVALUE(RFAILED); 
                              else if ((termStateParm->type.pres != NOTPRSNT) &&
                                       (termStateParm->type.val == 
                                            MGT_TERMST_PROPLST) && 
                                       (termStateParm->u.parm.pkg.pres == PRSNT_NODEF) && 
                                       (termStateParm->u.parm.pkg.val == MGT_PKG_ROOT) &&
                                       (termStateParm->u.parm.name.name.type.pres == PRSNT_NODEF) &&
                                       (termStateParm->u.parm.name.name.type.val == MGT_GEN_TYPE_KNOWN) &&
                                       (termStateParm->u.parm.name.name.u.val.pres == PRSNT_NODEF)) 
                              {
                                 /* MGT_PKG_ROOT_PROP_MGPROVRSPTMRVAL */
                                 if (termStateParm->u.parm.name.name.u.val.val == 
                                         MGT_PKG_ROOT_PROP_MGPROVRSPTMRVAL)
                                 {
                                    peer->provTmr.pres.pres = PRSNT_NODEF;
                                    peer->provTmr.mgProvRespTmrVal = 
                                         termStateParm->u.parm.val.u.eq.u.decInt.val;
                                    flag = ROK;
#ifdef ZG
                                    /* mg008.105: Changes corresponding to PSF */
                                    /* send update to peer */
                                    zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, 
                                             CMPFTHA_UPDTYPE_SYNC,
                                             CMPFTHA_ACTN_MOD);
#endif /* ZG */
                                 } /* if MGT_PKG_ROOT_PROP_MGCPROVRSPTMRVAL */
                                 else if(termStateParm->u.parm.name.name.u.val.val ==
                                         MGT_PKG_ROOT_PROP_MGCPROVRSPTMRVAL)
                                 {
                                    peer->provTmr.pres.pres = PRSNT_NODEF;
                                    peer->provTmr.mgcProvRspTmrVal =
                                         termStateParm->u.parm.val.u.eq.u.decInt.val;
                                    flag = ROK;
#ifdef ZG
                                    /* mg008.105: Changes corresponding to PSF */
                                    /* send update to peer */
                                    zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, 
                                             CMPFTHA_UPDTYPE_SYNC,
                                             CMPFTHA_ACTN_MOD);
#endif /* ZG */
                                    
                                 } /* else if MGT_PKG_ROOT_PROP_MGCPROVRSPTMRVAL */
                              } /* else if termStateParm propParm */
                           } /* for termStateParmCounter */
                        } /* else if medParm->type- locCtl */
                     } /* for medDescCounter */
                  } /* else if ((desc->type - media */
               } /* for descCounter */
            } /* else if cmdReq->cmd.type - Modify Check */
        } /* for-cmdCounter */
     } /* if tempActns */
   } /* for - axnCounter */
   RETVALUE(flag);
}


#endif /* GCP_PKG_MGCO_ROOT */
 


#ifdef GCP_CH

/*
 *       Fun:   mgChPrcMgcoInd 
 *
 *       Desc:  This CH function processes the CH megaco indication from the 
 *              user. 
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PUBLIC S16 mgChPrcMgcoInd
(
MgMgcoInd          *chInd,         /* CH Command Response */
MgSSAPCb           *sSap           /* session SAP cb      */
)
#else
PUBLIC S16 mgChPrcMgcoInd(chInd, sSap)
MgMgcoInd          *chInd;         /* CH Command Response */
MgSSAPCb           *sSap;          /* session SAP cb      */
#endif 
{
   MgMgcoMsg              *msg;     
   MgMgcoChCb             *chCb = &(mgCb.chCb);   /* CH Control BLock    */
   MgMgcoChPeerCmdCtl     *peerCmdCtl = NULLP;    /* Peer Cmd Control    */
   MgMgcoTransId          transId;                /* Transaction Id      */
   MgMgcoContextId        cntxtId;                /* Context Id          */
   MgMgcoChTransIndRsp    *trIndRsp = NULLP;      /* Trans Ind Rsp       */ 
   MgPeerCb               *peer = NULLP;          /* Peer Block          */
   MgMgcoChAxnIndRsp      *axnIndRsp = NULLP;     /* Action Ind Rsp      */
   MgMgcoTxnReply         *tr = NULLP;            /* Transaction Request */
   MgMgcoActnReply        *ar = NULLP;            /* Action Request      */
   Size                   size;
   S16                    ret;                    /* Return value   */
   /*mg002.105: Removed compilation warning*/
   U32                    idx=0;                  /* Loop Index     */
   CmLList                *pCmdNode;              /* List Node      */
   CmLList                *pCxtNode;              /* List Node      */
   U16                    cmdIdx;                 /* Command Index  */
   U16                    ctxIdx;                 /* Command Index  */
   MgMgcoChCmdResp        *chCmdRsp;              /* CH Command Rsp */
   MgMgcoChCntxtProp      *chCnxt;                /* CH context     */
   MgMgcoCxtCmdReply      *reply;                 /* Command Reply  */
   U32                    tlCnt;
   U8                     *val;

   TRC3(mgChPrcMgcoInd)

   /* mg002.105: Adding error ids for txn and context id not found */ 
   if (chInd->transId.pres == NOTPRSNT)
   {
      mgChHandleMgcoPrcIndErr(sSap, chInd,
                              MGT_CH_ERR_TXNID_NOT_FOUND, MG_USER);
      mgFreeEventMem((Ptr) chInd);
      RETVALUE(RFAILED);
   }

   /* mg002.105: Context ID check not required here */
   /* Check for peerId if present in Peer control block */
   if (mgChChkPeer (chInd->peerId) == RFAILED)
   {
      mgChHandleMgcoPrcIndErr (sSap, chInd, MGT_CH_ERR_PEER_NOT_FOUND, MG_USER);
      mgFreeEventMem((Ptr) chInd);
      RETVALUE(RFAILED);
   }

   CH_GET_PEER_FRM_PEERID(chInd->peerId.val, peer);

   cmMemcpy((U8 *)&(transId), (U8 *)&(chInd->transId), 
              sizeof (MgMgcoTransId));

   /* Peer Cmd List is already initialised in mgInit function  */
   if ((cmHashListFind(&(chCb->peerCmdCtlLst), (U8 *)&chInd->peerId.val, 
                         MG_CH_PEERID_LEN, MG_HASH_SEQNMB_DEF, 
                         (PTR *)&peerCmdCtl)) != ROK) 
   {
      mgChHandleMgcoPrcIndErr(sSap, chInd, MGT_CH_ERR_PEER_NOT_FOUND, MG_USER);
      mgFreeEventMem((Ptr) chInd);
      RETVALUE(RFAILED);
   }

   /* Peer Found, Check for Trans IndRsp List */
   if ((cmHashListFind(&(peerCmdCtl->transIndRspLst), (U8 *)&transId.val,
                       MG_TRANSID_LEN,
                       MG_HASH_SEQNMB_DEF, (PTR *)&trIndRsp)) != ROK)
   {
      mgChHandleMgcoPrcIndErr(sSap, chInd, MGT_CH_ERR_PEER_NOT_FOUND, MG_USER);
      mgFreeEventMem((Ptr) chInd);
      RETVALUE(RFAILED);
   }

   if(ROK != mgAllocEventMem((Ptr *)&msg, sizeof(MgMgcoMsg)) )
   {
      mgFreeEventMem((Ptr) chInd);
      RETVALUE(RFAILED);
   }

   /* Pres field in MgMgcoMsg in filled */
   msg->pres.pres = PRSNT_NODEF;
   msg->lcl.pres.pres = PRSNT_NODEF;
   msg->lcl.id.pres = PRSNT_NODEF;
   msg->lcl.id.val = peer->accessInfo.peerId;
   /* Copy mid from peer  */
   MG_CH_GETMEM((val),peer->accessInfo.mid.len,&(msg->memCp));
   MG_CH_INIT_TKNSTROSXL(&(msg->mid), 
                        val, peer->accessInfo.mid.len)
   cmMemcpy((U8*)(val),(U8*)(peer->accessInfo.mid.val),
            peer->accessInfo.mid.len);

   /* Some acceptance functions are directly called need to check out */
   /* whether this is possible or to be worked for an alternative */
   /* Auth header is not filled */
   ret = mgChFillAuthHdr(FALSE,&(msg->ah),0,0,NULLP,0);

   /* Code Review Patch: Fill protocol version as negotiated version */
   ret = mgChFillVersion(TRUE,&(msg->ver), peer->mgcoInfo.negotiatedVersion);

   /* Fill Message body. Only 1 transaction reply present */
   MG_CH_INIT_TOKEN_VALUE(&(msg->body.type),MGT_TXN);
   /* Will be sending one transaction at a time */
   MG_CH_INIT_TOKEN_VALUE(&(msg->body.u.tl.num),1);

   size = ((msg->body.u.tl.num.val) * (sizeof(MgMgcoTxn*)));
   /* Allocate memory based on transaction */
#ifndef GCP_VER_1_3
   MG_CH_GETMEM((msg->body.u.tl.txns),size,&(msg->memCp) );
#endif /* GCP_VER_1_3 */
#ifdef GCP_VER_1_3
   MG_ALLOC_EVNT_MEM(msg->body.u.tl.txns[idx],
         ret, sizeof(MgMgcoTxn));
#else
   MG_CH_GETMEM((msg->body.u.tl.txns[idx]),
         sizeof(MgMgcoTxn),&(msg->memCp));
#endif
   MG_CH_INIT_TOKEN_VALUE(&(msg->body.u.tl.txns[idx]->type),MGT_TXNREPLY);
   tr = &(msg->body.u.tl.txns[idx]->u.reply);
   tr->pres.pres = PRSNT_NODEF;
   /* Copy Transaction Id  */
   MG_CH_COPY_STRUCT(&(tr->transId), &(transId), sizeof(MgMgcoTransId))


   if (chInd->cntxtId.type.pres == NOTPRSNT)
   {
      /* Error reply on transaction */
      MG_CH_INIT_TOKEN_VALUE(&(tr->type), MGT_ERRDESC)
      MG_CH_COPY_STRUCT(&(tr->u.err), &(chInd->err), sizeof(MgMgcoErrDesc));
      if (chInd->err.text.pres != NOTPRSNT)
      {
         /* Error String present, allocate memory for the error string */
         /* from memcp */
         MG_CH_GETMEM((val),chInd->err.text.len,&(msg->memCp));
         MG_CH_INIT_TKNSTROSXL(&(tr->u.err.text), 
                                 val, chInd->err.text.len)
         cmMemcpy((U8*)(val),(U8*)(chInd->err.text.val),chInd->err.text.len);
      }

      /* mg003.105:ChDelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */


#ifdef ZG
      /* del the mapping and send RT upd to standby/shadows */
      mgChDelMappingTxnIndRspAndChilds(trIndRsp);
      /* zgDelMapping(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(trIndRsp)); */
#ifdef ZG_CH_LVL_UPD
      zgRtUpd(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(trIndRsp), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_DEL);
      /* Send update messages */
      zgUpdPeer();
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

      mgChCleanupTransIndRsp(&trIndRsp);

      /* Process Transaction */
      ret = mgPrcMgcoTxnReq(peer->ssap, msg, NULLP, MG_USER);
      mgFreeEventMem((Ptr) chInd);
      RETVALUE(ret);
   }

   /* Possibily Error Action Reply Compose the transaction ind-rsp */
   /* with the action error reply                                  */

   /* Before composing check whether any command responses are sent by the */
   /* user even though it is not theoriticaly correct, if present delete   */
   /* the previously received command responses since a new error action   */
   /* reply is being composed */
   
   cmMemcpy ((U8 *)&(cntxtId), (U8*) &(chInd->cntxtId), 
              sizeof(MgMgcoContextId));

      /* Code Review Patch : Removed five repeated lines of code */ 
   /* Handling only transaction response    */
   /* Set action reply */
   MG_CH_INIT_TOKEN_VALUE(&(tr->type), MGT_ACTIONREPLY)
   /* Allocate memory based on actions */
#ifndef GCP_VER_1_3
   /* Note current action Id holds number of actions */
   /* Action Id starts from 0 hence incrementing by 1 */
   size = ((trIndRsp->curActionId +1) * (sizeof(MgMgcoActnReply*)));
   /* Need to check whether the allocation is correct */
   MG_CH_GETMEM((tr->arl.repl),size,&(msg->memCp) );
   MG_CH_INIT_TOKEN_VALUE((tr->arl.num),(trIndRsp->curActionId +1));
#else

   size = ((trIndRsp->curActionId +1) * (sizeof(MgMgcoActnReply*)));
   /* Need to check whether the allocation is correct */
   MG_CH_GETMEM((tr->u.arl.repl),size,&(msg->memCp) );
   MG_CH_INIT_TOKEN_VALUE(&(tr->u.arl.num),(trIndRsp->curActionId +1));
#endif /* GCP_VER_1_3 */
   for (idx =0; idx < trIndRsp->curActionId + 1;
                idx++)
   {
 
      MG_CH_GETMEM(tr->u.arl.repl[idx],
             sizeof(MgMgcoActnReply),&(msg->memCp));
      ar = tr->u.arl.repl[idx];
      /* Fill present value  */
      ar->pres.pres = PRSNT_NODEF;
      axnIndRsp = (MgMgcoChAxnIndRsp *) trIndRsp->axnIndRsp[idx];
      MG_CH_COPY_STRUCT(&(ar->cxtId), &(axnIndRsp->cntxtId), 
                        sizeof(MgMgcoContextId))
      if (idx == trIndRsp->curActionId )
      {	 
		 /* mg003.105: Bug fixes */
         if ((trIndRsp->type.val == CH_AXN_TYPE_BOTH) ||
             (trIndRsp->type.val == CH_AXN_TYPE_ONLY_CMDS)) 
         {
            pCmdNode = axnIndRsp->respLst.first;
            for (cmdIdx = 0; cmdIdx < axnIndRsp->respLst.count;
                  cmdIdx++)
            {
               /* Free the collected response  */
               chCmdRsp = (MgMgcoChCmdResp *)pCmdNode->node;
               mgFreeEventMem((Ptr)chCmdRsp->cmdResp);
               pCmdNode = pCmdNode->next;
            }
         }

         /* Current Action and error reply has come for this */
         /* Compose error action reply and send transaction  */
         /* response                                         */
#ifdef MGT_GCP_VER_1_4
         ar->repErrSet.pres.pres = PRSNT_NODEF;
         MG_CH_COPY_STRUCT(&(ar->repErrSet.err), &(chInd->err), 
                           sizeof(MgMgcoErrDesc));
         if (chInd->err.text.pres != NOTPRSNT)
         {
            /* Error String present, allocate memory for the error string */
            /* from memcp */
            MG_CH_GETMEM((val),chInd->err.text.len,&(msg->memCp));
            MG_CH_INIT_TKNSTROSXL(&(ar->repErrSet.err.text), 
                  val, chInd->err.text.len)
            cmMemcpy((U8*)(val),(U8*)(chInd->err.text.val),chInd->err.text.len);
         }
#else 
         MG_CH_INIT_TOKEN_VALUE(&(ar->type), MGT_ERRDESC)
         MG_CH_COPY_STRUCT(&(ar->u.err), &(chInd->err), 
                           sizeof(MgMgcoErrDesc));
         if (chInd->err.text.pres != NOTPRSNT)
         {
            /* Error String present, allocate memory for the error string */
            /* from memcp */
            MG_CH_GETMEM((val),chInd->err.text.len,&(msg->memCp));
            MG_CH_INIT_TKNSTROSXL(&(ar->u.err.text), 
                              val, chInd->err.text.len)
            cmMemcpy((U8*)(val),(U8*)(chInd->err.text.val),chInd->err.text.len);
         }
#endif

      /* mg003.105:ChDelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
         /* del the mapping and send RT upd to standby/shadows */
         mgChDelMappingTxnIndRspAndChilds(trIndRsp);
         /* zgDelMapping(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(trIndRsp)); */
#ifdef ZG_CH_LVL_UPD
         zgRtUpd(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(trIndRsp), CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_DEL);
         /* Send update messages */
         zgUpdPeer();
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

         mgChCleanupTransIndRsp(&trIndRsp);

         /* Process Transaction */
         ret = mgPrcMgcoTxnReq(peer->ssap, msg, NULLP, MG_USER);
         mgFreeEventMem((Ptr) chInd);
         RETVALUE(ret);
      }

      /* Check whether commands are present */
      if ((trIndRsp->type.val == CH_AXN_TYPE_BOTH) ||
         (trIndRsp->type.val == CH_AXN_TYPE_ONLY_CMDS)) 
      { 
         /* Allocate memory for command response */
         size = ((axnIndRsp->respLst.count) * (sizeof(MgMgcoCmdReply*)));
#ifdef MGT_GCP_VER_1_4
         reply = &(ar->repErrSet.reply);
#else
         reply = &(ar->u.reply);
#endif
         /* Don't Allocate as this is static array  */
         /* MG_CH_GETMEM((reply->cl.repl),size,&(msg->memCp) ); */
 
         pCmdNode = axnIndRsp->respLst.first;
#ifdef MGT_GCP_VER_1_4
         ar->repErrSet.pres.pres = PRSNT_NODEF;
         ar->repErrSet.reply.pres.pres = PRSNT_NODEF;
#endif
         MG_CH_INIT_TOKEN_VALUE(&(reply->cl.num), axnIndRsp->respLst.count)
         MG_CH_COPY_STRUCT(&(ar->cxtId),&(axnIndRsp->cntxtId),
                              sizeof(MgMgcoContextId))
         for (cmdIdx = 0; cmdIdx < axnIndRsp->respLst.count;
               cmdIdx++)
         {
              chCmdRsp = (MgMgcoChCmdResp *)pCmdNode->node;
              /* Don't Allocate memory we are using the MU pointer */
              reply->cl.repl[cmdIdx] = chCmdRsp->cmdResp; 
              pCmdNode = pCmdNode->next;
          }
      } 

      /* Check whether context update is present  */
      if ((trIndRsp->type.val == CH_AXN_TYPE_BOTH) ||
         (trIndRsp->type.val == CH_AXN_TYPE_ONLY_CNTXT)) 
      { 
#ifdef MGT_GCP_VER_1_4
         reply = &(ar->repErrSet.reply);
#else
         reply = &(ar->u.reply);
#endif

         /* Context Update is present, check whether anything is present */
         /* this action                                                  */
         pCxtNode = trIndRsp->userCntxtLst.first;
         for (ctxIdx = 0; ctxIdx < trIndRsp->userCntxtLst.count;
              ctxIdx++)
         {
            chCnxt = (MgMgcoChCntxtProp *) (pCxtNode->node);
            if (chCnxt->actionId == idx)
            {
               /* Copy the topology descriptors if present  */
               if (chCnxt->cxtProps.tl.num.pres != NOTPRSNT)
               {
                  /* Context Update present for this action */
                  MG_CH_COPY_STRUCT(&(reply->cxt),(&(chCnxt->cxtProps)),
                                   sizeof(MgMgcoContextProps))
 
                  MG_CH_GETMEM(reply->cxt.tl.descs,
                        (chCnxt->cxtProps.tl.num.val *
                         sizeof(MgMgcoTopoDesc*)),&(msg->memCp));

                  for (tlCnt = 0; tlCnt < chCnxt->cxtProps.tl.num.val;
                        tlCnt++)
                  {
                     MG_CH_GETMEM(reply->cxt.tl.descs[tlCnt],
                           sizeof(MgMgcoTopoDesc),&(msg->memCp));
                     MG_CH_COPY_STRUCT(reply->cxt.tl.descs[tlCnt],
                           chCnxt->cxtProps.tl.descs[tlCnt],
                           sizeof(MgMgcoTopoDesc))
                     /* Check if termId is other and pathname present for */
                     /* "to" and "from" */
                     /* From */
                     if((reply->cxt.tl.descs[tlCnt]->from.type.pres
                                != NOTPRSNT) &&
                        (reply->cxt.tl.descs[tlCnt]->from.type.val
                                == MGT_TERMID_OTHER))
                     {
                        if((reply->cxt.tl.descs[tlCnt]->from.name.pres.pres
                                   != NOTPRSNT) &&
                           (reply->cxt.tl.descs[tlCnt]->from.name.lcl.pres
                                   != NOTPRSNT))
                        {
                           /* Lcl */
                           MG_CH_GETMEM(
                              reply->cxt.tl.descs[tlCnt]->from.name.lcl.val,
                              reply->cxt.tl.descs[tlCnt]->from.name.lcl.len,
                              &(msg->memCp));
                           MG_CH_COPY_STRUCT(
                              reply->cxt.tl.descs[tlCnt]->from.name.lcl.val,
                              chCnxt->cxtProps.tl.descs[tlCnt]->from.name.lcl.val,
                              reply->cxt.tl.descs[tlCnt]->from.name.lcl.len)
                        }

                        if((reply->cxt.tl.descs[tlCnt]->from.name.pres.pres
                                   != NOTPRSNT) &&
                           (reply->cxt.tl.descs[tlCnt]->from.name.dom.pres
                                   != NOTPRSNT))
                        {
                           /* dom */
                           MG_CH_GETMEM(
                              reply->cxt.tl.descs[tlCnt]->from.name.dom.val,
                              reply->cxt.tl.descs[tlCnt]->from.name.dom.len,
                              &(msg->memCp));
                           MG_CH_COPY_STRUCT(
                              reply->cxt.tl.descs[tlCnt]->from.name.dom.val,
                              chCnxt->cxtProps.tl.descs[tlCnt]->from.name.dom.val,
                              reply->cxt.tl.descs[tlCnt]->from.name.dom.len)
                        }

                     }

                     /* To */
                     if((reply->cxt.tl.descs[tlCnt]->to.type.pres != NOTPRSNT)
                                              &&
                        (reply->cxt.tl.descs[tlCnt]->to.type.val
                                == MGT_TERMID_OTHER))
                     {
                        if((reply->cxt.tl.descs[tlCnt]->to.name.pres.pres
                                   != NOTPRSNT) &&
                           (reply->cxt.tl.descs[tlCnt]->to.name.lcl.pres
                                   != NOTPRSNT))
                        {
                           /* Lcl */
                           MG_CH_GETMEM(
                              reply->cxt.tl.descs[tlCnt]->to.name.lcl.val,
                              reply->cxt.tl.descs[tlCnt]->to.name.lcl.len,
                              &(msg->memCp));
                           MG_CH_COPY_STRUCT(
                              reply->cxt.tl.descs[tlCnt]->to.name.lcl.val,
                              chCnxt->cxtProps.tl.descs[tlCnt]->to.name.lcl.val,
                              reply->cxt.tl.descs[tlCnt]->to.name.lcl.len)
                        }

                        if((reply->cxt.tl.descs[tlCnt]->to.name.pres.pres
                                   != NOTPRSNT) &&
                           (reply->cxt.tl.descs[tlCnt]->to.name.dom.pres
                                   != NOTPRSNT))
                        {
                           /* dom */
                           MG_CH_GETMEM(
                              reply->cxt.tl.descs[tlCnt]->to.name.dom.val,
                              reply->cxt.tl.descs[tlCnt]->to.name.dom.len,
                              &(msg->memCp));
                           MG_CH_COPY_STRUCT(
                              reply->cxt.tl.descs[tlCnt]->to.name.dom.val,
                              chCnxt->cxtProps.tl.descs[tlCnt]->to.name.dom.val,
                              reply->cxt.tl.descs[tlCnt]->to.name.dom.len)
                        }

                     }
                  } 
               }
               break;
            } 
            pCxtNode = pCxtNode->next;
         } /* for ctxIdx */

      }
   } /* For ActionId */
 
   /* Free the memory allocated for the indication and response in CH */
   /* Structure  */
 
#ifdef ZG
   /* Send update messages */
   zgUpdPeer();
#endif /* ZG */

   mgFreeEventMem((Ptr) chInd);
   RETVALUE(RFAILED);
} /* mgChPrcMgcoInd */
 

/*
 *       Fun:   mgChPrcCmdRsp 
 *
 *       Desc:  This CH function processes the command response from the user. 
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PUBLIC S16 mgChPrcCmdRsp 
(
MgMgcoCommand        *chCmdRsp,      /* CH Command Response */
MgSSAPCb             *sSap           /* session SAP cb      */
)
#else
PUBLIC S16 mgChPrcCmdRsp (chCmdRsp, sSap)
MgMgcoCommand        *chCmdRsp;      /* CH Command Response */
MgSSAPCb             *sSap;          /* session SAP cb      */
#endif 
{
   MgMgcoChCb             *chCb = &(mgCb.chCb);   /* CH Control BLock   */
   MgMgcoChPeerCmdCtl     *peerCmdCtl = NULLP;    /* Peer Cmd Control   */
   MgMgcoTransId          transId;                /* Transaction Id     */
   MgMgcoContextId        cntxtId;                /* Context Id         */
   MgMgcoChTransIndRsp    *trIndRsp = NULLP;      /* Trans Ind Rsp      */ 
   MgMgcoChCmdResp        *cmdRsp;            /* CH Command Ind     */
   MgPeerCb               *peer = NULLP;          /* Peer Block         */
   MgMgcoChAxnIndRsp      *axnIndRsp = NULLP;     /* Action Ind Rsp     */
   /* mg008.105: Changes corresponding to wildcard context id */
   MgMgcoChAxnIndRsp      *axnIndWildCardRsp = NULLP;     /* Action Ind Rsp     */

   TRC3(mgChPrcCmdRsp)
 
   /* mg005.105: Check if Stack in lock state, do not process any messages */
/* paul modifyed for NEC feedback */
#ifdef GCP_MGCO
#ifdef GCP_MG
   if(sSap->lockUnlock == TRUE)
   {   
      mgChHandleMgcoCmdReqErr(sSap, chCmdRsp, MGT_ERR_LOCK_STATE, MG_USER);
      mgFreeEventMem((Ptr) chCmdRsp->u.mgCmdRsp[CH_NULL_INDEX]);
      RETVALUE(RFAILED);
   }
#endif  /* GCP_MG */
#endif  /* GCP_MGCO */

   /* mg002.105: Adding error ids for txn and context id not found */ 
   if (chCmdRsp->transId.pres == NOTPRSNT)
   {
      mgChHandleMgcoCmdReqErr(sSap, chCmdRsp, MGT_CH_ERR_TXNID_NOT_FOUND_IN_CMD, MG_USER);
      /* mg002.105: Changed to the correct pointer */
      mgFreeEventMem((Ptr) chCmdRsp->u.mgCmdRsp[CH_NULL_INDEX]);
      /* mgFreeEventMem((Ptr) chCmdRsp); */
      RETVALUE(RFAILED);
   }
   if (chCmdRsp->contextId.type.pres == NOTPRSNT)
   {
      mgChHandleMgcoCmdReqErr(sSap, chCmdRsp, MGT_CH_ERR_CNTXTID_NOT_FOUND_IN_CMD, MG_USER);
      /* mg002.105: Changed to the correct pointer */
      mgFreeEventMem((Ptr) chCmdRsp->u.mgCmdRsp[CH_NULL_INDEX]);
      /* mgFreeEventMem((Ptr) chCmdRsp); */
      RETVALUE(RFAILED);
   }
   if (chCmdRsp->cmdStatus.val == CH_CMD_STATUS_NONE)
   {
      mgChHandleMgcoCmdReqErr(sSap, chCmdRsp, MGT_CH_ERR_CMD_STATUS_NONE, MG_USER);
      /* mg002.105: Changed to the correct pointer */
      mgFreeEventMem((Ptr) chCmdRsp->u.mgCmdRsp[CH_NULL_INDEX]);
      /* mgFreeEventMem((Ptr) chCmdRsp); */
      RETVALUE(RFAILED);
   }

   cmMemcpy ((U8 *) &(transId), (U8 *)&(chCmdRsp->transId), 
              sizeof (MgMgcoTransId));
   cmMemcpy ((U8 *)&(cntxtId), (U8*) &(chCmdRsp->contextId), 
              sizeof(MgMgcoContextId));
 

   /* Check for peerId if present in Peer control block */
   if (mgChChkPeer (chCmdRsp->peerId) == RFAILED)
   {
      mgChHandleMgcoCmdReqErr(sSap, chCmdRsp, MGT_CH_ERR_PEER_NOT_FOUND, MG_USER);
      /* mg002.105: Changed to the correct pointer */
      mgFreeEventMem((Ptr) chCmdRsp->u.mgCmdRsp[CH_NULL_INDEX]);
      RETVALUE(RFAILED);
   }

   CH_GET_PEER_FRM_PEERID(chCmdRsp->peerId.val,peer)
   /* Peer Id is valid */
   /* Peer Cmd List is already initialised in mgInit function  */
   if ((cmHashListFind(&(chCb->peerCmdCtlLst), (U8 *)&chCmdRsp->peerId.val, 
                         MG_CH_PEERID_LEN, MG_HASH_SEQNMB_DEF, 
                         (PTR *)&peerCmdCtl)) != ROK) 
   {
      mgChHandleMgcoCmdReqErr(sSap, chCmdRsp, MGT_CH_ERR_PEER_NOT_FOUND, MG_USER);
      /* mg002.105: Changed to the correct pointer */
      mgFreeEventMem((Ptr) chCmdRsp->u.mgCmdRsp[CH_NULL_INDEX]);
      RETVALUE(RFAILED);
   }

   /* Peer Found, Check for Trans IndRsp List */
   if ((cmHashListFind(&(peerCmdCtl->transIndRspLst), (U8 *)&transId.val,
                       MG_TRANSID_LEN,
                       MG_HASH_SEQNMB_DEF, (PTR *)&trIndRsp)) != ROK)
   {
      mgChHandleMgcoCmdReqErr(sSap, chCmdRsp, MGT_CH_ERR_TXNID_NOT_FOUND, MG_USER);
      /* mg002.105: Changed to the correct pointer */
      mgFreeEventMem((Ptr) chCmdRsp->u.mgCmdRsp[CH_NULL_INDEX]);
      RETVALUE(RFAILED);
   }

   /* Transaction Indication-response Node Located */
   /* Get the action indication-response from the node */
   axnIndRsp = trIndRsp->axnIndRsp[trIndRsp->curActionId];

   /* mg008.105: action is wildcarded and AnxIndRspCb is not created then create
    * Cotrol Block */
   if(trIndRsp->axnIndRsp[trIndRsp->curActionId]->wildCardPres)
   {
      axnIndWildCardRsp = axnIndRsp->axnIndWildCardRsp[axnIndRsp->curWildActionId];

      if(axnIndRsp->axnIndWildCardRsp[axnIndRsp->curWildActionId] == NULLP)
      {
         if (RFAILED == mgChAllocateWildCardAxnIndRspCb(trIndRsp, &axnIndWildCardRsp,
                           chCmdRsp->contextId, CH_AXN_TYPE_ONLY_CMDS,
                           CH_AXN_TYPE_ONLY_CMDS, axnIndRsp->curWildActionId,
                           NULLD))
         {
            mgChHandleMgcoCmdReqErr(sSap, chCmdRsp, MGT_ERR_RSRC_UNAVAIL, MG_USER);
            mgFreeEventMem((Ptr) chCmdRsp->u.mgCmdRsp[CH_NULL_INDEX]);
            RETVALUE(RFAILED);
         }
         axnIndRsp->axnIndWildCardRsp[axnIndRsp->curWildActionId] = axnIndWildCardRsp;
      }
   }

   /* Assuming resp List would have been initialised */
   /* Concatenate the response list with the received response */
   if (RFAILED == mgChAllocateCmdRspCb(axnIndRsp, &cmdRsp,
                                       chCmdRsp->u.mgCmdRsp[0]))
   {
      mgChHandleMgcoCmdReqErr(sSap, chCmdRsp, MGT_ERR_RSRC_UNAVAIL, MG_USER);
      /* mg002.105: Changed to the correct pointer */
      mgFreeEventMem((Ptr) chCmdRsp->u.mgCmdRsp[CH_NULL_INDEX]);
      RETVALUE(RFAILED);
   }

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
   /* add the mapping and send RT upd to standby/shadows */
   ZG_INIT_RSETID_IN_MAPCB(&((cmdRsp)->mapCb));
   zgAddMapping(ZG_CBTYPE_CH_OUT_CMDRSP, (Ptr)(cmdRsp));
#ifdef ZG_CH_LVL_UPD
   zgRtUpd(ZG_CBTYPE_CH_OUT_CMDRSP, (Ptr)(cmdRsp), CMPFTHA_UPDTYPE_SYNC,
           CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */


   /* 
    * mg002.105: Check for error in response. 
    * If err present then compose the response and send to peer
    */
	/* mg003.105: Bug fixes */
    if (!axnIndRsp->cmdIndInfo[axnIndRsp->curCmdIndId]->opt.pres)
    {
    if (ROK != mgChChkResp (cmdRsp->cmdResp))
    {
       CH_GET_PEER_FRM_PEERID(chCmdRsp->peerId.val, peer);
       /* mg003.105: Bug fixes */
       cmMemcpy ((U8 *) &(axnIndRsp->cntxtId), (U8 *) &(chCmdRsp->contextId),
                sizeof(MgMgcoContextId));
       mgChComposeTransRsp(trIndRsp, peer);
       RETVALUE(ROK);
    }
    }
    /* Check for the last response i.e ,last indication for last action */
    if ((trIndRsp->curActionId == trIndRsp->numOfIndRspAxns -1) &&
        (chCmdRsp->cmdStatus.val == CH_CMD_STATUS_END_OF_RSP) &&
        (axnIndRsp->curCmdIndId == axnIndRsp->numOfCmdInds - 1))
    {
       /* All command responses are received */
       CH_GET_PEER_FRM_PEERID(chCmdRsp->peerId.val, peer);	   
       /* mg003.105: Bug fixes */
       cmMemcpy ((U8 *) &(axnIndRsp->cntxtId), (U8 *) &(chCmdRsp->contextId), 
                sizeof(MgMgcoContextId)); 
       mgChComposeTransRsp(trIndRsp, peer);
    }
    else if (chCmdRsp->cmdStatus.val == CH_CMD_STATUS_END_OF_RSP)
    {
       /* mg002.105: Copy the context Id from the last reply */
       /* axnIndRsp->cntxtId =  chCmdRsp->cntxtId; */
       cmMemcpy ((U8 *) &(axnIndRsp->cntxtId), (U8 *) &(chCmdRsp->contextId), 
                sizeof(MgMgcoContextId)); 
       mgChSendNextCmd (trIndRsp, axnIndRsp, transId, chCmdRsp->peerId.val);
    } /* Last response for the indication sent */
    else if(chCmdRsp->cmdStatus.val == CH_CMD_STATUS_END_OF_AXN)
    {
      /* mg008.105: Changes corresponding to wildcard context id */
      if(axnIndRsp->wildCardPres)
      {
         axnIndRsp = trIndRsp->axnIndRsp[trIndRsp->curActionId];
         axnIndRsp->curWildActionId++;
         axnIndRsp->numOfWildCardRspAxns++;
         if(mgChGrowMem((Ptr* )&(axnIndRsp->axnIndWildCardRsp), axnIndRsp->curWildActionId + 1, axnIndRsp->curWildActionId, sizeof(MgMgcoChAxnIndRsp* )) != ROK)
         {
            mgChHandleMgcoCmdReqErr(sSap, chCmdRsp, MGT_ERR_RSRC_UNAVAIL, MG_USER);
         }
      }
      else
      {
         mgChHandleMgcoCmdReqErr(sSap, chCmdRsp, MGT_CH_ERR_CMD_STATUS_NONE, MG_USER);
         mgFreeEventMem((Ptr) chCmdRsp->u.mgCmdRsp[CH_NULL_INDEX]);
         /* mgFreeEventMem((Ptr) chCmdRsp); */
         RETVALUE(RFAILED);
      }
    }/* Last Command in the action if wildcard is present */
    else
    {
       /* Some more responses expected do not send any indication and wait */
       /* for the last response */
    }


#ifdef ZG
   /* Send update messages */
   zgUpdPeer();
#endif /* ZG */


   RETVALUE(ROK);
} /* mgChPrcCmdRsp */
 


/*
*       Fun: mgChChkResp
*
*       Desc:  This CH function checks whether the response given by user has errors
*
*       Ret:   ROK - SUCCESS;
*              RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PRIVATE S16 mgChChkResp 
(
   MgMgcoCmdReply *cmdReply         /* Cmd Rsp      */
) 
#else
PRIVATE S16 mgChChkResp (cmdReply)
   MgMgcoCmdReply *cmdReply;           /* Cmd Rsp      */
#endif
{
   U8                  type;              /* Type of Rsp    */
   MgMgcoErrDesc       *err = NULLP;      /* error desc     */
   S16                 ret = ROK;         /* return value   */

   if (cmdReply->type.pres == PRSNT_NODEF)
      type = cmdReply->type.val;
   switch (type)
   {
      /* Intentional fall through to make use of ammsreply */
      case MGT_MODIFY:
         if (cmdReply->u.mod.audit.num.pres == PRSNT_NODEF)
            if (cmdReply->u.mod.audit.parms[0]->type.val == MGT_ERRDESC)
               err = &(cmdReply->u.mod.audit.parms[0]->u.err);
         break;
              
      case MGT_MOVE:                 
         if (cmdReply->u.move.audit.num.pres == PRSNT_NODEF)
            if (cmdReply->u.move.audit.parms[0]->type.val == MGT_ERRDESC)
               err = &(cmdReply->u.move.audit.parms[0]->u.err);
         break;
              
      case MGT_ADD:
         if (cmdReply->u.add.audit.num.pres == PRSNT_NODEF)
            if (cmdReply->u.add.audit.parms[0]->type.val == MGT_ERRDESC)
               err = &(cmdReply->u.add.audit.parms[0]->u.err);
         break;
              
      case MGT_SUB:                  
         if (cmdReply->u.sub.audit.num.pres == PRSNT_NODEF)
            if (cmdReply->u.sub.audit.parms[0]->type.val == MGT_ERRDESC)
               err = &(cmdReply->u.sub.audit.parms[0]->u.err);
         break;
              
      case MGT_AUDITCAP:                  
         err = &(cmdReply->u.acap.u.err);
         break;
              
      case MGT_AUDITVAL:                  
         if (cmdReply->u.aval.type.val == MGT_ERRDESC)
            err = &(cmdReply->u.aval.u.err);
         break;
              
      case MGT_NTFY:                  
         err = &(cmdReply->u.ntfy.err);
         break;
              
      case MGT_SVCCHG:                  
         if (cmdReply->u.svc.res.type.val == MGT_ERRDESC)
            err = &(cmdReply->u.svc.res.u.err);
         break;
   } 
   
   if (err != NULLP)
      if (err->pres.pres == PRSNT_NODEF)
         /* only if err code is present */
         /* if (err->code.pres == PRSNT_NODEF) */
            ret = RFAILED;
   RETVALUE(ret);
}

/*
*       Fun: mgChSendNextCmd 
*
*       Desc:  This CH function sends the next command to the user
*
*       Ret:   ROK - SUCCESS;
*              RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PRIVATE S16 mgChSendNextCmd 
(
   MgMgcoChTransIndRsp *trIndRsp,      /* Trans Ind-Rsp      */
   MgMgcoChAxnIndRsp   *axnIndRsp,     /* Action Ind Rsp     */
   MgMgcoTransId       transId,        /* Transaction Id     */
   U32                 peerVal           /* Peer Control    cb */
)
#else
PRIVATE S16 mgChSendNextCmd (trIndRsp, axnIndRsp, transId, peerVal)
   MgMgcoChTransIndRsp *trIndRsp;      /* trans Ind-Rsp      */
   MgMgcoChAxnIndRsp   *axnIndRsp;     /* Action Ind Rsp     */
   MgMgcoTransId       transId;        /* Transaction Id     */
   U32                 peerVal;        /* Peer Control    cb */

#endif 

{
   MgMgcoCommand           chCmdInd;              /* CH Command Ind     */
   MgMgcoCommandReq        *cmdInd = NULLP;       /* Command Indication */
   S16                     err; 
   S16                     axnLoopIdx =0;         /* Loop Counter       */
   Bool                    cmdPresent=FALSE;      /* Cmd Flag           */
   MgPeerCb                *peer = NULLP;         /* Peer Block         */
   
   CH_GET_PEER_FRM_PEERID(peerVal, peer); 
       /* Check for last command indication */
   if (axnIndRsp->curCmdIndId != axnIndRsp->numOfCmdInds -1)
   {
       /* command indication pending in this action */
       /* Copy transactionId */
       CH_CP_TRANSID(chCmdInd, transId) 
       /* Copy contextId */
       CH_CP_CONTEXTID(chCmdInd, axnIndRsp->cntxtId) 
       /* Copy Peer Id  */
       MG_CH_INIT_TOKEN_VALUE(&(chCmdInd.peerId), peerVal)
       CH_CP_CMDTYPE(chCmdInd, CH_CMD_TYPE_IND)
       /* Increment the current command indication Id in this action  */
       axnIndRsp->curCmdIndId++;

#ifdef ZG
#ifdef ZG_CH_LVL_UPD
       zgRtUpd(ZG_CBTYPE_CH_AXN_INDRSP, (Ptr)(axnIndRsp), CMPFTHA_UPDTYPE_SYNC,
               CMPFTHA_ACTN_MOD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */


       cmdInd = axnIndRsp->cmdInds[axnIndRsp->curCmdIndId];
 
       chCmdInd.u.mgCmdInd[0] = cmdInd;   
 
       if (axnIndRsp->curCmdIndId == axnIndRsp->numOfCmdInds -1)  
          if (trIndRsp->curActionId == trIndRsp->numOfIndRspAxns -1)
           /* Last command indication  */
             CH_SET_CMDSTATUS(chCmdInd, CH_CMD_STATUS_END_OF_TXN)
          else
             CH_SET_CMDSTATUS(chCmdInd, CH_CMD_STATUS_END_OF_AXN)
          else
             CH_SET_CMDSTATUS(chCmdInd, CH_CMD_STATUS_PENDING)
        mgChSendPrim ((Ptr)&chCmdInd, peer, &err, CH_PRIM_TYPE_CMD);
/* mg002.105: */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
             /* Del the mapping and send RT upd to standby/shadows */
             /* ZG_INIT_RSETID_IN_MAPCB(&((axnIndRsp->cmdIndInfo[cmdLoopIdx])\ */
                                       /* ->mapCb)); */
             zgDelMapping(ZG_CBTYPE_CH_INC_CMDREQ,
                         (Ptr)(axnIndRsp->cmdIndInfo[axnIndRsp->curCmdIndId - 1]));
#ifdef ZG_CH_LVL_UPD
             zgRtUpd(ZG_CBTYPE_CH_INC_CMDREQ,
                     (Ptr)(axnIndRsp->cmdIndInfo[axnIndRsp->curCmdIndId - 1]),
                     CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */
   }
   else if(trIndRsp->curActionId != trIndRsp->numOfIndRspAxns -1) 
   {
      /* Last command indication in this action but some more actions */
      axnLoopIdx = trIndRsp->curActionId+1;  
      {
         axnIndRsp = trIndRsp->axnIndRsp[trIndRsp->curActionId+1];   
         if ((axnIndRsp->type.val == CH_AXN_TYPE_BOTH) ||
             (axnIndRsp->type.val == CH_AXN_TYPE_ONLY_CNTXT))
         {
            /* Send Update Context to User */
            mgChSendUpdCntxt(trIndRsp, axnLoopIdx, peer, &err, CH_PRIM_TYPE_IND);
         }
         if ((axnIndRsp->type.val == CH_AXN_TYPE_BOTH) ||
             (axnIndRsp->type.val == CH_AXN_TYPE_ONLY_CMDS))
         {
            /* Commands present for this action */
             cmdPresent = TRUE;
         }
      }
          /* mg002.105: Check added */
      if (cmdPresent == TRUE) 
      {
        /* Got a new axnIndRsp node to send command indication */
        axnIndRsp->curCmdIndId = CH_FIRST_CMD_IND_ID;   
        /* Copy transactionId */
        CH_CP_TRANSID(chCmdInd, transId) 
        /* Copy contextId */
        CH_CP_CONTEXTID(chCmdInd, axnIndRsp->cntxtId) 
          /* Copy Peer Id  */
          MG_CH_INIT_TOKEN_VALUE(&(chCmdInd.peerId), peerVal)
          /* Set command type */
          CH_CP_CMDTYPE(chCmdInd, CH_CMD_TYPE_IND)
          /* Set the first indication id  */
          cmdInd = axnIndRsp->cmdInds[CH_FIRST_CMD_IND_ID];
          /* Copy the command to the indication primitive */
 
          /* MG_CH_COPY_STRUCT(&(chCmdInd.u.mgCmdInd), */
                            /* (cmdInd), sizeof(MgMgcoCommandReq)) */
          chCmdInd.u.mgCmdInd[0] = cmdInd;
 
          if (axnIndRsp->curCmdIndId != axnIndRsp->numOfCmdInds -1)
             /* Commands Pending */
             CH_SET_CMDSTATUS(chCmdInd, CH_CMD_STATUS_PENDING)
          /* mg002.105: This should be for the action Id that is being sent. So trIndRsp->curActionId+1 */
          /* else if (trIndRsp->curActionId < trIndRsp->numOfIndRspAxns -1) */
          else if (trIndRsp->curActionId+1 < trIndRsp->numOfIndRspAxns -1)
             CH_SET_CMDSTATUS(chCmdInd, CH_CMD_STATUS_END_OF_AXN)
          else
             CH_SET_CMDSTATUS(chCmdInd, CH_CMD_STATUS_END_OF_TXN)
          mgChSendPrim ((Ptr)&chCmdInd, peer, &err, CH_PRIM_TYPE_CMD);
/* mg002.105: */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
             /* Del the mapping and send RT upd to standby/shadows */
             /* ZG_INIT_RSETID_IN_MAPCB(&((axnIndRsp->cmdIndInfo[cmdLoopIdx])\ */
                                       /* ->mapCb)); */
             zgDelMapping(ZG_CBTYPE_CH_INC_CMDREQ,
                         (Ptr)(axnIndRsp->cmdIndInfo[axnIndRsp->curCmdIndId]));
#ifdef ZG_CH_LVL_UPD
             zgRtUpd(ZG_CBTYPE_CH_INC_CMDREQ,
                     (Ptr)(axnIndRsp->cmdIndInfo[axnIndRsp->curCmdIndId]),
                     CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */
          trIndRsp->curActionId = axnLoopIdx;
       }
          
    }
 
#ifdef ZG
   /* Send update messages */
   zgUpdPeer();
#endif /* ZG */

   RETVALUE(ROK);
}
 
/*
 *       Fun: mgChSendUpdCntxt 
 *
 *       Desc:  This CH function sends an update Context primitive to the user 
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
/*mg002.105: Removed compilation warning*/
#ifdef ANSI
PRIVATE S16 mgChSendUpdCntxt 
(
MgMgcoChTransIndRsp *trIndRsp,      /* Trans Ind-Rsp      */
U16                 actionId,       /* Action Id          */
MgPeerCb            *peer,          /* Peer Control block */
S16                 *err,           /* Error              */
U8                  primType        /* Primitive Type     */
)
#else
PRIVATE S16 mgChSendUpdCntxt (trIndRsp,actionId,peer,err,primType)
MgMgcoChTransIndRsp *trIndRsp;      /* trans Ind-Rsp      */
U16                 actionId;       /* Action Id          */
MgPeerCb            *peer;          /* Peer Control block */
S16                 *err;           /* Error              */
U8                  primType;       /* Primitive Type     */
#endif 
{
   CmLList              *pNode = NULLP;        /* List Node            */
   MgMgcoChAxnIndRsp    *chAxnIndRsp = NULLP;  /* Action Ind Rsp Node  */
   /*mg002.105: Removed compilation warning*/
   U16                   ctxLoopIdx;           /* Cntx Loop Index      */
   MgMgcoChCntxtProp    *chCntxt = NULLP;      /* CH Context Prop      */
   MgMgcoUpdateCntxt     cntxtUpd;             /* Primitive to be sent */
   S16                   ret;                  /* return value         */

   TRC3(mgChSendUpdCntxt)

   chAxnIndRsp = trIndRsp->axnIndRsp[actionId]; 

   pNode = trIndRsp->chCntxtLst.first;
 
   for (ctxLoopIdx = 0;ctxLoopIdx < trIndRsp->chCntxtLst.count;
           ctxLoopIdx++)
   {
       chCntxt = (MgMgcoChCntxtProp *)(pNode->node); 
       /*mg002.105: Removed compilation warning*/
       if (chCntxt->actionId == (U32)actionId) 
       {
           break;
       }
       pNode = pNode->next;
   }

   CH_CP_CNTXTUPD_TRANSID(cntxtUpd, trIndRsp->transId)
   CH_CP_CNTXTUPD_CONTEXTID(cntxtUpd, chCntxt->cxtId)
   MG_CH_INIT_TOKEN_VALUE(&(cntxtUpd.peerId),peer->accessInfo.peerId)
   /* Check whether atleast a command indication is present */
   /* other than this context update */


   if(chAxnIndRsp->numOfCmdInds > CH_MIN_CMDS_IN_AXN - 1) 
   {
      /* commands pending for this action */
      CH_SET_CNTXTUPD_CMDSTATUS(cntxtUpd, CH_CMD_STATUS_PENDING) 
   }
   /*mg002.105: Removed compilation warning*/
   else if (actionId < (U16)(trIndRsp->numOfIndRspAxns - 1))
   {
      /* No more commands in this action, but some More actions  */
      CH_SET_CNTXTUPD_CMDSTATUS(cntxtUpd, CH_CMD_STATUS_END_OF_AXN) 
      /* mg002.105: This needs to be there */ 
      /* Increment the action Id */
      trIndRsp->curActionId++;

#ifdef ZG
#ifdef ZG_CH_LVL_UPD
      zgRtUpd(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(trIndRsp), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_MOD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

   }
   else
   {
      /* No more actions and commands */
      CH_SET_CNTXTUPD_CMDSTATUS(cntxtUpd, CH_CMD_STATUS_END_OF_TXN) 
      /* mg002.105: Increment the action Id here also */
      trIndRsp->curActionId++;

#ifdef ZG
#ifdef ZG_CH_LVL_UPD
      zgRtUpd(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(trIndRsp), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_MOD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

   }
   /* Copy the context Props and audit */
   CH_CP_CNTXTUPD_PROP(cntxtUpd,chCntxt)
   ret = mgChSendPrim ((Ptr)&cntxtUpd, peer, err, CH_PRIM_TYPE_UPD_CNTXT);
/* mg002.105: */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
          /* Del the mapping and send RT upd to standby/shadows */
          /* ZG_INIT_RSETID_IN_MAPCB(&((chCntxt)->mapCb)); */
          zgDelMapping(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCntxt));
#ifdef ZG_CH_LVL_UPD
          zgRtUpd(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCntxt), CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

 
#ifdef ZG
   /* Send update messages */
   zgUpdPeer();
#endif /* ZG */

   /* *err = MGT_CH_ERR_NONE; */
   RETVALUE(ret);
} /* mgChSendUpdCntxt */


/*
 *       Fun:  mgChPrcCmdReq   
 *
 *       Desc:  This CH function processes the command request from the user 
 *              and composes a transaction with the received commands.
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PUBLIC S16 mgChPrcCmdReq
(
MgMgcoCommand        *chCmdReq,      /* CH Command Request */
MgSSAPCb             *sSap           /* session SAP cb     */
)
#else
PUBLIC S16 mgChPrcCmdReq (chCmdReq, sSap)
MgMgcoCommand        *chCmdReq;      /* CH Command Request */
MgSSAPCb             *sSap;          /* session SAP cb     */
#endif 
{
   MgPeerCb               *peer = NULLP;          /* Peer Control Block */
   MgMgcoChPeerCmdCtl     *peerCmdCtl = NULLP;    /* Peer Cmd Control   */
   MgMgcoChTransReq       *transReq = NULLP;      /* Trans Request Node */
   MgMgcoTransId          transId;                /* Transaction Id     */
   MgMgcoContextId        cntxtId;                /* Context Id         */
   U32                    peerId;                 /* Peer Identifier    */
   MgMgcoChAxnReq         *axnReq = NULLP;        /* Action req         */
   U32                    axnloopCnt;             /* Action req loop cnt*/
   MgMgcoChCmdReq         *cmdReqNode = NULLP;    /* Cmd Req Node       */
   Bool                   peerCmdCtlAlloc = FALSE;/* Peer Ctl Allocated?*/ 
   Bool                   transReqAlloc = FALSE;  /* TransReq Allocated?*/ 
   Bool                   axnReqAlloc = FALSE;    /* Axn Req Allocated? */ 
   Bool                   cmdReqAlloc = FALSE;    /* Cmd Req Allocated? */ 
   
    

   TRC3(mgChPrcCmdReq)

   /* mg005.105: Check if Stack in lock state, do not process any messages */
/* paul modifyed for NEC feedback */
#ifdef GCP_MGCO
#ifdef GCP_MG
   if(sSap->lockUnlock == TRUE)
   {   
      mgChHandleMgcoCmdReqErr(sSap, chCmdReq, MGT_ERR_LOCK_STATE, MG_USER);
      mgFreeEventMem((Ptr) chCmdReq->u.mgCmdReq[CH_NULL_INDEX]);
      RETVALUE(RFAILED);
   }
#endif  /* GCP_MG */
#endif  /* GCP_MGCO */

   /* mg002.105: Adding error ids for txn and context id not found */ 
   if (chCmdReq->transId.pres == NOTPRSNT)
   {
      mgChHandleMgcoCmdReqErr(sSap, chCmdReq, MGT_CH_ERR_TXNID_NOT_FOUND_IN_CMD, MG_USER);
      /* mg002.105: Need to free this pointer */
      mgFreeEventMem((Ptr) chCmdReq->u.mgCmdReq[CH_NULL_INDEX]);
      RETVALUE(RFAILED);
   }
   if (chCmdReq->contextId.type.pres == NOTPRSNT)
   {
      mgChHandleMgcoCmdReqErr(sSap, chCmdReq, MGT_CH_ERR_CNTXTID_NOT_FOUND_IN_CMD, MG_USER);
      /* mg002.105: Need to free this pointer */
      mgFreeEventMem((Ptr) chCmdReq->u.mgCmdReq[CH_NULL_INDEX]);
      RETVALUE(RFAILED);
   }

   cmMemcpy((U8 *)&(transId), (U8 *)&(chCmdReq->transId), 
              sizeof (MgMgcoTransId));
   cmMemcpy((U8 *)&(cntxtId), (U8*) &(chCmdReq->contextId), 
              sizeof(MgMgcoContextId));
 

   /* Check for peerId if present in Peer control block */
   if (mgChChkPeer (chCmdReq->peerId) == RFAILED)
   {
      mgChHandleMgcoCmdReqErr(sSap, chCmdReq, MGT_CH_ERR_PEER_NOT_FOUND, MG_USER);
      /* mg002.105: Need to free this pointer */
      mgFreeEventMem((Ptr) chCmdReq->u.mgCmdReq[CH_NULL_INDEX]);
      RETVALUE(RFAILED);
   }

   peerId = chCmdReq->peerId.val;
   CH_GET_PEER_FRM_PEERID(chCmdReq->peerId.val, peer);
 
   /* Peer Id is valid */
   /* Peer Cmd List is already initialised in mgInit function  */
   if ((cmHashListFind(&(mgCb.chCb.peerCmdCtlLst), (U8 *)&chCmdReq->peerId.val, 
                         MG_CH_PEERID_LEN, MG_HASH_SEQNMB_DEF, 
                         (PTR *)&peerCmdCtl)) != ROK) 
   {
      /* Node not found, may be this is the first command request comming  */
      /* for the peer,Create an entry for the peer */

      if (RFAILED == mgChAllocatePeerCb(chCmdReq->peerId.val, &peerCmdCtl))
      {
         mgChHandleMgcoCmdReqErr(sSap, chCmdReq,
                                 MGT_ERR_RSRC_UNAVAIL, MG_USER);
         /* [UG]: Need to free this pointer */
         mgFreeEventMem((Ptr) chCmdReq->u.mgCmdReq[CH_NULL_INDEX]);
         RETVALUE(RFAILED);
      }

      peerCmdCtlAlloc = TRUE;

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
      /* add the mapping and send RT upd to standby/shadows */
      ZG_INIT_RSETID_IN_MAPCB(&((peerCmdCtl)->mapCb));
      zgAddMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
      zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */


      /* Create a TransReq Node */
      if (RFAILED == mgChAllocateTxnReqCb(peerCmdCtl, chCmdReq->transId,
                                          &transReq))
      {
         /* generate RT upd for deleting the peer */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
         zgDelMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
         zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_DEL);
         /* Send update messages */
         zgUpdPeer();
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

         /* Delete the block from the list */
         cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR)peerCmdCtl); 

         mgChHandleMgcoCmdReqErr(sSap, chCmdReq, MGT_ERR_RSRC_UNAVAIL, MG_USER);
         /* [UG]: Need to free this pointer */
         mgFreeEventMem((Ptr) chCmdReq->u.mgCmdReq[CH_NULL_INDEX]);
         mgDeAlloc((Data *) peerCmdCtl, sizeof(peerCmdCtl));
         RETVALUE(RFAILED);
      }

      transReqAlloc = TRUE;

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */


#ifdef ZG
      /* add the mapping and send RT upd to standby/shadows */
      ZG_INIT_RSETID_IN_MAPCB(&((transReq)->mapCb));
      zgAddMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq));
#ifdef ZG_CH_LVL_UPD
      zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

 
      /* Create a Axn Request Node */
      if (RFAILED == mgChAllocateAxnReqCb(transReq, CH_FIRST_AXN_ID,
                                          &axnReq, cntxtId))
      {

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
         /* the RT upd for deleting the peer will delete the txn also */
         zgDelMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq));
         /* generate RT upd for deleting the peer */
         zgDelMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
         zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_DEL);

         zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_DEL);

         /* Send update messages */
         zgUpdPeer();
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

         /* Delete the block from the list */
         cmHashListDelete(&(peerCmdCtl->transReqLst), (PTR)transReq); 

         /* Delete the block from the list */
         cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR)peerCmdCtl); 

         mgChHandleMgcoCmdReqErr(sSap, chCmdReq, MGT_ERR_RSRC_UNAVAIL, MG_USER);
         /* [UG]: Need to free this pointer */
         mgFreeEventMem((Ptr) chCmdReq->u.mgCmdReq[CH_NULL_INDEX]);
         mgDeAlloc((Data *) transReq, sizeof(MgMgcoChTransReq));
         mgDeAlloc((Data *) peerCmdCtl, sizeof(peerCmdCtl));
         RETVALUE(RFAILED);
      }

      axnReqAlloc = TRUE;

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
      /* add the mapping and send RT upd to standby/shadows */
      ZG_INIT_RSETID_IN_MAPCB(&((axnReq)->mapCb));
      zgAddMapping(ZG_CBTYPE_CH_AXN_REQ, (Ptr)(axnReq));
#ifdef ZG_CH_LVL_UPD
      zgRtUpd(ZG_CBTYPE_CH_AXN_REQ, (Ptr)(axnReq), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */


   } /* No Peer List */ 
   else
   /* Peer List Present */
   {
       /* Check if the trans Id is already present in the trans req List */
       if ((cmHashListFind(&(peerCmdCtl->transReqLst), (U8 *)&transId.val,
                           MG_TRANSID_LEN, MG_HASH_SEQNMB_DEF,
                           (PTR *)&transReq)) != ROK)
       {
           /* TransReq List will be initialised when received the */
           /* first command for the peer,Create a TransREq Node */
           if (RFAILED == mgChAllocateTxnReqCb(peerCmdCtl, chCmdReq->transId,
                                               &transReq))
           {
              mgChHandleMgcoCmdReqErr(sSap, chCmdReq,
                                      MGT_ERR_RSRC_UNAVAIL, MG_USER);
              /* [UG]: Need to free this pointer */
              mgFreeEventMem((Ptr) chCmdReq->u.mgCmdReq[CH_NULL_INDEX]);
              RETVALUE(RFAILED);
           }

           transReqAlloc = TRUE;

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
           /* add the mapping and send RT upd to standby/shadows */
           ZG_INIT_RSETID_IN_MAPCB(&((transReq)->mapCb));
           zgAddMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq));
#ifdef ZG_CH_LVL_UPD
           zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
                   CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

           /* Create a Axn Request Node */
           if (RFAILED == mgChAllocateAxnReqCb(transReq, CH_FIRST_AXN_ID,
                                               &axnReq, cntxtId))
           {
               mgChHandleMgcoCmdReqErr(sSap, chCmdReq,
                                       MGT_ERR_RSRC_UNAVAIL, MG_USER);
               /* [UG]: Need to free this pointer */
               mgFreeEventMem((Ptr) chCmdReq->u.mgCmdReq[CH_NULL_INDEX]);

               /* generate RT upd for deleting the txn */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
               zgDelMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq));
#ifdef ZG_CH_LVL_UPD
               zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
                       CMPFTHA_ACTN_DEL);
               /* Send update messages */
               zgUpdPeer();
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

               /* Delete the block from the list */
               cmHashListDelete(&(peerCmdCtl->transReqLst), (PTR)transReq); 

               mgDeAlloc((Data *) transReq, sizeof(MgMgcoChTransReq));
               RETVALUE(RFAILED);
           }

           axnReqAlloc = TRUE;

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
           /* add the mapping and send RT upd to standby/shadows */
           ZG_INIT_RSETID_IN_MAPCB(&((axnReq)->mapCb));
           zgAddMapping(ZG_CBTYPE_CH_AXN_REQ, (Ptr)(axnReq));
#ifdef ZG_CH_LVL_UPD
           zgRtUpd(ZG_CBTYPE_CH_AXN_REQ, (Ptr)(axnReq), CMPFTHA_UPDTYPE_SYNC,
                   CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

       } /* No Trans Req Node */
       else
       /* Transaction Request Node present */
       {
           Bool    flag = FALSE;
           CmLList *listNode;

           if (transReq->axnReqLst.first == NULLP)
           {
/* [UG]: May not be an error Condition, the txn list might have been created for context alone */
               flag = FALSE;
           }
           else
           {
              /* Check if Action request is present */
              listNode = transReq->axnReqLst.first;
              for (axnloopCnt =0; axnloopCnt <transReq->axnReqLst.count;
                   axnloopCnt++)
              {
                 axnReq = (MgMgcoChAxnReq *)(listNode->node);
                 if (axnReq->actionId == transReq->curActionId)
                 {
                    flag = TRUE;                
                    break;
                 }
                 listNode = listNode->next;
              }
           }

           if (flag == FALSE)
           {
              /* New ActionReq,Create a Axn Request Node */
              if (RFAILED == mgChAllocateAxnReqCb(transReq,
                                                  transReq->curActionId,
                                                  &axnReq, cntxtId))
              {
                  mgChHandleMgcoCmdReqErr(sSap, chCmdReq,
                                          MGT_ERR_RSRC_UNAVAIL, MG_USER);
                  /* [UG]: Need to free this pointer */
                  mgFreeEventMem((Ptr) chCmdReq->u.mgCmdReq[CH_NULL_INDEX]);
                  RETVALUE(RFAILED);
              }

              axnReqAlloc = TRUE;

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
              /* add the mapping and send RT upd to standby/shadows */
              ZG_INIT_RSETID_IN_MAPCB(&((axnReq)->mapCb));
              zgAddMapping(ZG_CBTYPE_CH_AXN_REQ, (Ptr)(axnReq));
#ifdef ZG_CH_LVL_UPD
              zgRtUpd(ZG_CBTYPE_CH_AXN_REQ, (Ptr)(axnReq), CMPFTHA_UPDTYPE_SYNC,
                      CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

           }
       } /* Transaction Request Node present */
   } /* Peer List Present */

   /* Found a proper actionReq Node */
   if ((axnReq->actionId == CH_FIRST_AXN_ID) &&
            (axnReqAlloc == TRUE))
   {
      /* First action received for this transaction, need to init the command
       * list,Initialise the command request list in the AxnReq Node */
      cmLListInit (&(axnReq->cmdReqLst));
 
      /* Start a Timer and make an entry in transReq Block */
      /* If already started dont start again */
#ifdef GCP_MG
      /*mg002.105: Added additional check*/
      if (mgCb.genCfg.entType == LMG_ENT_GW)
      {
         mgStartTmr(CH_CMD_REQ_TMR, mgCb.genCfg.maxMgCmdTimeOut.val, 
                    (PTR)transReq,&(transReq->tmr));
      }
#else
      if (mgCb.genCfg.entType == LMG_ENT_GC)
      {
         mgStartTmr(CH_CMD_REQ_TMR, mgCb.genCfg.maxMgcCmdTimeOut.val, 
                    (PTR)transReq,&(transReq->tmr));
      }
#endif
   } /* If CH_FIRST_AXN_ID && AxnReq ALLOC */
 

   /* Create a Cmd Request Node */
   if (RFAILED == mgChAllocateOutCmdReqCb(transReq, axnReq, &cmdReqNode,
                                          chCmdReq->u.mgCmdReq[0]))
   {
       mgChHandleMgcoCmdReqErr(sSap, chCmdReq, MGT_ERR_RSRC_UNAVAIL, MG_USER);
       /* [UG]: Need to free this pointer */
       mgFreeEventMem((Ptr) chCmdReq->u.mgCmdReq[CH_NULL_INDEX]);

       if (axnReqAlloc == TRUE) 
       {
           /* generate RT upd for deleting the axn */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
           zgDelMapping(ZG_CBTYPE_CH_AXN_REQ, (Ptr)(axnReq));
#ifdef ZG_CH_LVL_UPD
           zgRtUpd(ZG_CBTYPE_CH_AXN_REQ, (Ptr)(axnReq), CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

           /* now remove the block from the list */
           cmLListDelFrm (&(transReq->axnReqLst), &(axnReq->node));

           mgDeAlloc((Data *) axnReq, sizeof(MgMgcoChAxnReq));
       }

       if (transReqAlloc == TRUE)
       {
           /* generate RT upd for deleting the txn */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
           zgDelMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq));
#ifdef ZG_CH_LVL_UPD
           zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
                   CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

           /* Delete the block from the list */
           cmHashListDelete(&(peerCmdCtl->transReqLst), (PTR)transReq); 

           mgDeAlloc((Data *) transReq, sizeof(MgMgcoChTransReq));
       }

       if (peerCmdCtlAlloc == TRUE)
       {
           /* generate RT upd for deleting the peer */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
           zgDelMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
           zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
                   CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

           /* Delete the block from the list */
           cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR)peerCmdCtl); 

           mgDeAlloc((Data *) peerCmdCtl, sizeof(peerCmdCtl));
       }
 
#ifdef ZG
       /* Send update messages */
       zgUpdPeer();
#endif /* ZG */

       RETVALUE(RFAILED);
   }

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
   /* add the mapping and send RT upd to standby/shadows */
   ZG_INIT_RSETID_IN_MAPCB(&((cmdReqNode)->mapCb));
   zgAddMapping(ZG_CBTYPE_CH_OUT_CMDREQ, (Ptr)(cmdReqNode));
#ifdef ZG_CH_LVL_UPD
   zgRtUpd(ZG_CBTYPE_CH_OUT_CMDREQ, (Ptr)(cmdReqNode), CMPFTHA_UPDTYPE_SYNC,
           CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */


   cmdReqAlloc= TRUE;


   /* Now Process the commands received */
   switch (chCmdReq->cmdStatus.val)
   {
      case CH_CMD_STATUS_PENDING:
         /* Commands are pending for this action req.
          * Not Altering the currActionId as we are expecting
          * some more commands */
         break;
      case CH_CMD_STATUS_END_OF_AXN:
         /* No more Commands this action, but some more actions pending  */
         /* When action Id is not found in the list, will be created new */
         transReq->curActionId++; 

#ifdef ZG
#ifdef ZG_CH_LVL_UPD
         zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_MOD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

         break;

      case CH_CMD_STATUS_END_OF_TXN:
         /* No more actions/commands, compose transaction and send */
         mgChComposeTransReq (transReq, peer);
         break;

      default:
         mgChHandleMgcoCmdReqErr(sSap, chCmdReq, MGT_ERR_RSRC_UNAVAIL, MG_USER);
         /* [UG]: Need to free this pointer */
         mgFreeEventMem((Ptr) chCmdReq->u.mgCmdReq[CH_NULL_INDEX]);

         if (cmdReqAlloc == TRUE) 
         {
            /* generate RT upd for deleting the cmd */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
            zgDelMapping(ZG_CBTYPE_CH_OUT_CMDREQ, (Ptr)(cmdReqNode));
#ifdef ZG_CH_LVL_UPD
            zgRtUpd(ZG_CBTYPE_CH_OUT_CMDREQ, (Ptr)(cmdReqNode), CMPFTHA_UPDTYPE_SYNC,
                    CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

            /* remove from the linked list */
            cmLListDelFrm (&(axnReq->cmdReqLst), &(cmdReqNode->node));

            mgDeAlloc((Data *) cmdReqNode, sizeof(MgMgcoChCmdReq));
         }

         if (axnReqAlloc == TRUE) 
         {
            /* generate RT upd for deleting the axn */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
            zgDelMapping(ZG_CBTYPE_CH_AXN_REQ, (Ptr)(axnReq));
#ifdef ZG_CH_LVL_UPD
            zgRtUpd(ZG_CBTYPE_CH_AXN_REQ, (Ptr)(axnReq), CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

            /* now remove the block from the list */
            cmLListDelFrm (&(transReq->axnReqLst), &(axnReq->node));

            mgDeAlloc((Data *) axnReq, sizeof(MgMgcoChAxnReq));
         }

         if (transReqAlloc == TRUE)
         {
            /* generate RT upd for deleting the txn */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
            zgDelMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq));
#ifdef ZG_CH_LVL_UPD
            zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
                    CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

            /* Delete the block from the list */
            cmHashListDelete(&(peerCmdCtl->transReqLst), (PTR)transReq); 

            mgDeAlloc((Data *) transReq, sizeof(MgMgcoChTransReq));
         }

         if (peerCmdCtlAlloc == TRUE)
         {
            /* generate RT upd for deleting the peer */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
            zgDelMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
            zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
                    CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

            /* Delete the block from the list */
            cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR)peerCmdCtl); 

            mgDeAlloc((Data *) peerCmdCtl, sizeof(peerCmdCtl));
         }
 
#ifdef ZG
         /* Send update messages */
         zgUpdPeer();
#endif /* ZG */

         RETVALUE(RFAILED);
   } /* switch - chCmdReq->cmdStatus */

 
#ifdef ZG
   /* Send update messages */
   zgUpdPeer();
#endif /* ZG */

   RETVALUE(ROK);
}/* mgChPrcCmdReq */


/*
 *       Fun:   mgChPrcCmdReqTmrExpiry 
 *
 *       Desc:  This CH function handles the request  timeout for a  
 *              transaction and sends request  timeout to the user
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PUBLIC S16 mgChPrcCmdReqTmrExpiry 
(
MgMgcoChTransReq  *trReq   
)
#else
PUBLIC S16 mgChPrcCmdReqTmrExpiry(trReq)
MgMgcoChTransReq  *trReq;
#endif 
{
   MgMgcoInd  chInd;      /* Ch Indication to user */
   MgPeerCb    *peer;
   S16         err;

   TRC3(mgChPrcCmdReqTmrExpiry)

   cmMemset((U8 *) &chInd, 0, sizeof(MgMgcoInd)); 
 
   /* Send request timed out indication to user */
   CH_CP_IND_TRANSID(chInd,trReq->transId)
   CH_CP_IND_PEERID(chInd,trReq->peerId)
   CH_SET_IND_ERRDESC(chInd,MGT_CH_ERR_CMD_REQ_TMD_OUT)
 
   CH_GET_PEER_FRM_PEERID(trReq->peerId, peer);

      /* mg003.105:ChDelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
   /* del the mapping and send RT upd to standby/shadows */
   mgChDelMappingTxnReqAndChilds(trReq);
   /* zgDelMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(trReq)); */
#ifdef ZG_CH_LVL_UPD
   zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(trReq), CMPFTHA_UPDTYPE_SYNC,
           CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

   /* Cleanup the memory allocated for the transaction request */
   mgChCleanupTransReq (&trReq, TRUE); 

   /* Send Response timed out to user */
   mgChSendPrim ((Ptr)&chInd, peer, &err, CH_PRIM_TYPE_IND); 
   
 
#ifdef ZG
   /* Send update messages */
   zgUpdPeer();
#endif /* ZG */

   RETVALUE(ROK);
} /* mgChPrcCmdReqTmrExpiry  */


/*
 *       Fun:   mgChCleanupTransIndRsp
 *
 *       Desc:  This CH function cleans up the transaction indication-response
 *              node.
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PUBLIC S16 mgChCleanupTransIndRsp
(
MgMgcoChTransIndRsp **transIndRsp
)
#else
PUBLIC S16 mgChCleanupTransIndRsp (transIndRsp)
MgMgcoChTransIndRsp **transIndRsp;
#endif 
{
   S16               axnIdx;                    /* Command Loop Index */   
   S16               ctxIdx;                    /* Context Loop Index */   
   S16               wildAxnIdx;                    /* Command Loop Index */   
   S16               cmdIdx;                    /* Command Loop Index */   
   CmLList           *pNode = NULLP;            /* List Node          */
   CmLList           *pCmdNode = NULLP;         /* Cmd List Node      */
   CmLList           *pTemp = NULLP;            /* List Node          */
   MgMgcoChAxnIndRsp *chAxn = NULLP;            /* Axn Ind-Rsp        */
   MgMgcoChAxnIndRsp *wildChAxn = NULLP;            /* Axn Ind-Rsp        */
   MgMgcoChCmdResp   *chCmd = NULLP;            /* Command Response   */
   MgMgcoChCntxtProp *chCntxt = NULLP;          /* Context Prop       */   
   U32               count;                     /* Count              */         
   U32               cmdCount;                  /* Cmd Count          */         
   MgMgcoChTransIndRsp *trRsp = *transIndRsp;   /* Transaction Rsp    */
   MgMgcoChPeerCmdCtl *peerCmdCtl;              /* Peer Command Ctrl  */
   U16                tlCnt;  
   U16                cmdLoopIdx;  

   

   TRC3(mgChCleanupTransIndRsp)

   /* Stop the timer if running  */
   /* First free the command list nodes and context prop nodes  */
   /* if present */
   if ( (trRsp->type.val == CH_AXN_TYPE_ONLY_CMDS) ||
        (trRsp->type.val == CH_AXN_TYPE_BOTH)) 
   {
      /* Commands nodes present */

      /*mg002.105: free the cmdResp event structs which are not sent */
      if (trRsp->numOfIndRspAxns >= trRsp->curActionId)
      {
         /* mg002.105: Removed compilation warning */
         for (axnIdx = trRsp->curActionId; axnIdx < (S16)trRsp->numOfIndRspAxns; axnIdx++)
         {
            chAxn = (MgMgcoChAxnIndRsp *)trRsp->axnIndRsp[axnIdx];
            cmdLoopIdx = ((axnIdx == trRsp->curActionId) ? chAxn->curCmdIndId + 1 : 0); 
            while (cmdLoopIdx < chAxn->numOfCmdInds)
            {
               if (chAxn->cmdInds[cmdLoopIdx])
                  mgFreeEventMem((Ptr)chAxn->cmdInds[cmdLoopIdx]);
               cmdLoopIdx++;
            }
         }
      }
      /* Free all the action respose nodes */
      /* mg002.105: Removed compilation warning */
      for (axnIdx = 0; axnIdx < (S16)trRsp->numOfIndRspAxns; axnIdx++)
      {
         chAxn = (MgMgcoChAxnIndRsp *)trRsp->axnIndRsp[axnIdx];
         /* mg008.105: Handling for wild card context */
         if(chAxn->wildCardPres == TRUE)
         {
            for (wildAxnIdx = 0; wildAxnIdx < chAxn->numOfWildCardRspAxns; wildAxnIdx++)
            {
               wildChAxn = chAxn->axnIndWildCardRsp[wildAxnIdx];
               if (wildChAxn != NULLP)
               {
                  pCmdNode = wildChAxn->respLst.first;
                  cmdCount = wildChAxn->respLst.count;
                  /* free the resp list as there will not be any cmdInd list for wild card rsp */
                  for (cmdIdx = 0; cmdIdx < (S16)cmdCount; cmdIdx++)
                  {
                     chCmd = (MgMgcoChCmdResp *)pCmdNode->node;
                     pTemp = pCmdNode->next;
                     cmLListDelFrm (&(chAxn->respLst), pCmdNode);
                     mgDeAlloc ((Data *) chCmd, sizeof(MgMgcoChCmdResp));
                     pCmdNode = pTemp;
                  }
                  /* Free the action request node */
                  mgDeAlloc ((Data *) wildChAxn, sizeof(MgMgcoChAxnIndRsp));
               }
            }
            mgDeAlloc ((Data *) chAxn->axnIndWildCardRsp, sizeof(MgMgcoChAxnIndRsp *));
         }
         /* [UG]: Need to free the command reply nodes */
         pCmdNode = chAxn->respLst.first;
         cmdCount = chAxn->respLst.count;
         for (cmdIdx = 0; cmdIdx < (S16)cmdCount; cmdIdx++)
         {
            chCmd = (MgMgcoChCmdResp *)pCmdNode->node;
            pTemp = pCmdNode->next;
            cmLListDelFrm (&(chAxn->respLst), pCmdNode);
            mgDeAlloc ((Data *) chCmd, sizeof(MgMgcoChCmdResp));
            pCmdNode = pTemp;
         }
         for (cmdLoopIdx = 0; cmdLoopIdx < chAxn->numOfCmdInds; cmdLoopIdx++)
         {
            /* mg003.105: Bug fixes */
            if(chAxn->cmdIndInfo[cmdLoopIdx] != NULLP)
            {
               /* mg008.105: Changes corresponding to wildcard context id */
               if ((chAxn->cmdIndInfo[cmdLoopIdx]->termId.type.val
                            == MGT_TERMID_OTHER) &&
                     (chAxn->cmdIndInfo[cmdLoopIdx]->termId.name.pres.pres
                            != NOTPRSNT))
               {
                  /* De-Allocate for the pathname for lcl */
                  if(chAxn->cmdIndInfo[cmdLoopIdx]->termId.name.lcl.pres
                            != NOTPRSNT) 
                  {
                     mgDeAlloc((Data *)(chAxn->cmdIndInfo[cmdLoopIdx]->termId\
                              .name.lcl.val),
                           chAxn->cmdIndInfo[cmdLoopIdx]->termId\
                           .name.lcl.len);
                  }
                  if(chAxn->cmdIndInfo[cmdLoopIdx]->termId.name.dom.pres
                            != NOTPRSNT) 
                  {
                     mgDeAlloc((Data *)(chAxn->cmdIndInfo[cmdLoopIdx]->termId\
                              .name.dom.val),
                           chAxn->cmdIndInfo[cmdLoopIdx]->termId\
                           .name.dom.len);
                  }
               }
#ifdef GCP_ASN
               if (((chAxn->cmdIndInfo[cmdLoopIdx]->termId.type.val
                            == MGT_TERMID_ALL) ||
                            (chAxn->cmdIndInfo[cmdLoopIdx]->termId.type.val
                            == MGT_TERMID_CHOOSE))&&
                    (chAxn->cmdIndInfo[cmdLoopIdx]->termId.name.pres.pres
                            != NOTPRSNT) &&
                    (chAxn->cmdIndInfo[cmdLoopIdx]->termId.name.lcl.pres
                            != NOTPRSNT)) 
               {
                  mgDeAlloc((Data *)(chAxn->cmdIndInfo[cmdLoopIdx]->termId\
                           .name.lcl.val),
                        chAxn->cmdIndInfo[cmdLoopIdx]->termId\
                        .name.lcl.len);
               }

               if ((chAxn->cmdIndInfo[cmdLoopIdx]->termId.wildcard.num.pres
                            != NOTPRSNT)&&
                   (chAxn->cmdIndInfo[cmdLoopIdx]->termId.wildcard.num.val
                            != 0) &&
                   (chAxn->cmdIndInfo[cmdLoopIdx]->termId.wildcard.wildcard
                            != NULLP)) 
               {
                  U16   ix, nmbr;

                  nmbr = chAxn->cmdIndInfo[cmdLoopIdx]->termId.wildcard.num.val;

                  for (ix=0; ix < nmbr; ++ix)
                  {
                     mgDeAlloc((Data *) ((chAxn->cmdIndInfo[cmdLoopIdx]->
                                          termId.wildcard.wildcard[ix])),
                                          sizeof(MgMgcoWildcardField));
                  }

                  mgDeAlloc((Data *) ((chAxn->cmdIndInfo[cmdLoopIdx]->termId.wildcard.wildcard)), 
                                      (nmbr * sizeof(MgMgcoWildcardField *)));
               }

#endif /* GCP_ASN */
               /* [UG]: Free the Command info also */
               mgDeAlloc ((Data *) chAxn->cmdIndInfo[cmdLoopIdx], sizeof(MgMgcoCmdIndInfo ));
            }
            continue;
         }
         if ((chAxn->type.val == CH_AXN_TYPE_ONLY_CMDS) ||
            (chAxn->type.val == CH_AXN_TYPE_BOTH)) 
         {
            mgDeAlloc ((Data *) chAxn->cmdIndInfo, (chAxn->numOfCmdInds * sizeof(MgMgcoCmdIndInfo *)));
            /* [UG]: Free the Command ind also */
            mgDeAlloc ((Data *) chAxn->cmdInds, (chAxn->numOfCmdInds * sizeof(MgMgcoCommandReq *)));
            /* Free the action request node */
         }

         /* Free the action request node */
         mgDeAlloc ((Data *) chAxn, sizeof(MgMgcoChAxnIndRsp));
      }
      mgDeAlloc ((Data *) trRsp->axnIndRsp, sizeof(MgMgcoChAxnIndRsp *));
   } /* Commands request present */
 
   if ((trRsp->type.val == CH_AXN_TYPE_ONLY_CNTXT) ||
        (trRsp->type.val == CH_AXN_TYPE_BOTH))
   {
      /* Free all the action respose nodes */
      if (trRsp->type.val == CH_AXN_TYPE_ONLY_CNTXT)
      {
         for (axnIdx = 0; axnIdx < (S16)trRsp->numOfIndRspAxns; axnIdx++)
         {
            chAxn = (MgMgcoChAxnIndRsp *)trRsp->axnIndRsp[axnIdx];
            /* Free the action request node */
            mgDeAlloc ((Data *) chAxn, (sizeof(MgMgcoChAxnIndRsp)));
         }
         mgDeAlloc ((Data *) trRsp->axnIndRsp, (trRsp->numOfIndRspAxns * sizeof(MgMgcoChAxnIndRsp *)));
      }

      /* Free the Context List */
      mgChFreeChCntxtLstInTransIndRspCb(trRsp);

      /* User Context Prop nodes present */
      pNode = trRsp->userCntxtLst.first;
      count = trRsp->userCntxtLst.count;
      for (ctxIdx = 0; ctxIdx < (S16)count; ctxIdx++)
      {
         chCntxt = (MgMgcoChCntxtProp *)pNode->node;
         pTemp = pNode->next;
         /* Free the context prop node */
         cmLListDelFrm (&(trRsp->userCntxtLst), pNode);
         if ((chCntxt->cxtProps.pres.pres != NOTPRSNT) &&
               (chCntxt->cxtProps.tl.num.pres != NOTPRSNT))
         {
            for (tlCnt = 0; tlCnt < chCntxt->cxtProps.tl.num.val;
                  tlCnt++)
            {
               if ((chCntxt->cxtProps.tl.descs[tlCnt]->from.type.val
                             == MGT_TERMID_OTHER) &&
                     (chCntxt->cxtProps.tl.descs[tlCnt]->from.name.pres.pres
                             != NOTPRSNT))
               {
                  /* De-Allocate for the pathname for lcl */
                  if(chCntxt->cxtProps.tl.descs[tlCnt]->from.name.lcl.pres
                             != NOTPRSNT) 
                  {
                     mgDeAlloc((Data *)(chCntxt->cxtProps.tl.descs[tlCnt]\
                              ->from.name.lcl.val),
                              chCntxt->cxtProps.tl.descs[tlCnt]\
                              ->from.name.lcl.len);
                  }
                  /* [UG]: De-Allocate for the pathname for lcl - to */
                  if(chCntxt->cxtProps.tl.descs[tlCnt]->to.name.lcl.pres
                            != NOTPRSNT) 
                  {
                     mgDeAlloc((Data *)(chCntxt->cxtProps.tl.descs[tlCnt]\
                              ->to.name.lcl.val),
                              chCntxt->cxtProps.tl.descs[tlCnt]\
                              ->to.name.lcl.len);
                  }
                  /* De-Allocate for the pathname for dom */
                  if(chCntxt->cxtProps.tl.descs[tlCnt]->from.name.dom.pres
                             != NOTPRSNT) 
                  {
                     mgDeAlloc((Data *)(chCntxt->cxtProps.tl.descs[tlCnt]\
                              ->from.name.dom.val),
                              chCntxt->cxtProps.tl.descs[tlCnt]\
                              ->from.name.dom.len);
                  }
                  /* [UG]: De-Allocate for the pathname for dom - to */
                  if(chCntxt->cxtProps.tl.descs[tlCnt]->to.name.dom.pres 
                             != NOTPRSNT) 
                  {
                     mgDeAlloc((Data *)(chCntxt->cxtProps.tl.descs[tlCnt]\
                              ->to.name.dom.val),
                              chCntxt->cxtProps.tl.descs[tlCnt]\
                              ->to.name.dom.len);
                  }
               }
               mgDeAlloc ((Data *) chCntxt->cxtProps.tl.descs[tlCnt], 
                     sizeof(MgMgcoTopoDesc));
            }
            mgDeAlloc ((Data *) chCntxt->cxtProps.tl.descs, 
                  chCntxt->cxtProps.tl.num.val *  sizeof(MgMgcoTopoDesc *));
         }
         mgDeAlloc ((Data *) chCntxt, sizeof(MgMgcoChCntxtProp));
         pNode = pTemp;
      }
   } /* Context Prop present */

   /* Free the transaction request node */
   if ((cmHashListFind(&(mgCb.chCb.peerCmdCtlLst), (U8 *)&trRsp->peerId, 
                         MG_CH_PEERID_LEN, MG_HASH_SEQNMB_DEF, 
                         (PTR *)&peerCmdCtl)) == ROK) 
   {
      cmHashListDelete(&(peerCmdCtl->transIndRspLst), (PTR)trRsp); 
   }  
   else
   {
      /* Delete the transaction response node from the list */
      mgDeAlloc ((Data *) trRsp, sizeof(MgMgcoChTransIndRsp));
      RETVALUE(RFAILED);
   }
 

   /* Delete the transaction response node from the list */
   mgDeAlloc ((Data *) trRsp, sizeof(MgMgcoChTransIndRsp));

   RETVALUE(ROK);
} /* mgChCleanupTransIndRsp */


/*
 *       Fun:   mgChCleanupTransReq
 *
 *       Desc:  This CH function cleans up the transaction request node
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
/* mg002.105: Added freeCmds as 2nd parameter in mgChCleanupTransReq*/
#ifdef ANSI
PUBLIC S16 mgChCleanupTransReq 
(
MgMgcoChTransReq  **transReq,
U32               freeCmds
)
#else
PUBLIC S16 mgChCleanupTransReq (transReq, freeCmds)
MgMgcoChTransReq  **transReq;
U32               freeCmds;
#endif 
{
   S16               axnIdx;                    /* Command Loop Index */   
   S16               ctxIdx;                    /* Context Loop Index */   
   S16               cmdIdx;                    /* Command Loop Index */   
   CmLList           *pNode = NULLP;            /* List Node          */
   CmLList           *pCmdNode = NULLP;         /* Cmd List Node      */
   CmLList           *pTemp = NULLP;            /* List Node          */
   MgMgcoChAxnReq    *chAxn = NULLP;            /* Axn Request        */
   MgMgcoChCmdReq    *chCmd = NULLP;            /* Command Request    */
   MgMgcoCommandReq  *chCmdReq = NULLP;            /* Command Request    */
   MgMgcoChCntxtProp *chCntxt = NULLP;          /* Context Prop       */   
   U32               count;                     /* Count              */         
   U32               cmdCount;                  /* Cmd Count          */         
   MgMgcoChTransReq  *trReq = *transReq;        /* Transaction Req    */
   MgMgcoChPeerCmdCtl *peerCmdCtl;              /* Peer Command Ctrl  */
   U16                 tlCnt;

   

   TRC3(mgChCleanupTransReq)
 
   /* Stop the Timer if running */
   if(trReq->tmr.tmrEvnt != TMR_NONE)                          
      mgStopTmr (CH_CMD_REQ_TMR, (PTR) trReq, &(trReq->tmr));  
 
   /* First free the command list nodes and context prop nodes  */
   /* if present */
   if ((trReq->type.val == CH_AXN_TYPE_ONLY_CMDS) ||
       (trReq->type.val == CH_AXN_TYPE_BOTH)) 
   {
      /* Commands nodes present */
      pNode = trReq->axnReqLst.first;
      count = trReq->axnReqLst.count;
      /* Free all the action request nodes */
      /* mg002.105: Removed compilation warning */
      for (axnIdx = 0; axnIdx < (S16)count; axnIdx++)
      {
         /* Free the commands present in this action !!! */
         /* Free the action request node */
         chAxn = (MgMgcoChAxnReq *)pNode->node;
         /* [UG]: Need to free the command request nodes */
         pCmdNode = chAxn->cmdReqLst.first;
         cmdCount = chAxn->cmdReqLst.count;
         /* mg002.105: Removed compilation warning */
         for (cmdIdx = 0; cmdIdx < (S16)cmdCount; cmdIdx++)
         {
            chCmd = (MgMgcoChCmdReq *)pCmdNode->node;
            if (freeCmds == TRUE)
            { 
               chCmdReq = (MgMgcoCommandReq *)chCmd->cmdReq;
               mgFreeEventMem (chCmdReq);
            }
            pTemp = pCmdNode->next;
            cmLListDelFrm (&(chAxn->cmdReqLst), pCmdNode);
            mgDeAlloc ((Data *) chCmd, sizeof(MgMgcoChCmdReq));
            pCmdNode = pTemp;
         }
         pTemp = pNode->next;
         cmLListDelFrm (&(trReq->axnReqLst), pNode);
         mgDeAlloc ((Data *) chAxn, sizeof(MgMgcoChAxnReq));
         pNode = pTemp;
      }

   } /* Commands request present */

   if ( (trReq->type.val == CH_AXN_TYPE_ONLY_CNTXT) ||
        (trReq->type.val == CH_AXN_TYPE_BOTH)) 
   {
      /* Context Prop nodes present */
      pNode = trReq->contextPropLst.first;
      count = trReq->contextPropLst.count;
      /* mg002.105: Removed compilation warning */
      for (ctxIdx = 0; ctxIdx < (S16)count; ctxIdx++)
      {
         chCntxt = (MgMgcoChCntxtProp *)pNode->node;
         /* Free the context prop node */
         pTemp = pNode->next;
         cmLListDelFrm (&(trReq->contextPropLst), pNode);
         if ((chCntxt->cxtProps.pres.pres != NOTPRSNT) &&
               (chCntxt->cxtProps.tl.num.pres != NOTPRSNT))
         {
            for (tlCnt = 0; tlCnt < chCntxt->cxtProps.tl.num.val;
                  tlCnt++)
            {
               if ((chCntxt->cxtProps.tl.descs[tlCnt]->from.type.val
                             == MGT_TERMID_OTHER) &&
                     (chCntxt->cxtProps.tl.descs[tlCnt]->from.name.pres.pres
                             != NOTPRSNT))
               {
                  /* De-Allocate for the pathname for lcl */
                  if(chCntxt->cxtProps.tl.descs[tlCnt]->from.name.lcl.pres
                             != NOTPRSNT) 
                  {
                     mgDeAlloc((Data *)(chCntxt->cxtProps.tl.descs[tlCnt]\
                              ->from.name.lcl.val),
                           chCntxt->cxtProps.tl.descs[tlCnt]\
                           ->from.name.lcl.len);
                  }
                  /* De-Allocate for the pathname for dom */
                  if(chCntxt->cxtProps.tl.descs[tlCnt]->from.name.dom.pres
                             != NOTPRSNT) 
                  {
                     mgDeAlloc((Data *)(chCntxt->cxtProps.tl.descs[tlCnt]\
                              ->from.name.dom.val),
                           chCntxt->cxtProps.tl.descs[tlCnt]\
                           ->from.name.dom.len);
                  }
               }

               if ((chCntxt->cxtProps.tl.descs[tlCnt]->to.type.val
                             == MGT_TERMID_OTHER) &&
                     (chCntxt->cxtProps.tl.descs[tlCnt]->to.name.pres.pres
                             != NOTPRSNT))
               {
                  /* De-Allocate for the pathname for lcl */
                  if(chCntxt->cxtProps.tl.descs[tlCnt]->to.name.lcl.pres
                             != NOTPRSNT) 
                  {
                     mgDeAlloc((Data *)(chCntxt->cxtProps.tl.descs[tlCnt]\
                              ->to.name.lcl.val),
                           chCntxt->cxtProps.tl.descs[tlCnt]\
                           ->to.name.lcl.len);
                  }
                  /* De-Allocate for the pathname for dom */
                  if(chCntxt->cxtProps.tl.descs[tlCnt]->to.name.dom.pres
                             != NOTPRSNT) 
                  {
                     mgDeAlloc((Data *)(chCntxt->cxtProps.tl.descs[tlCnt]\
                              ->to.name.dom.val),
                           chCntxt->cxtProps.tl.descs[tlCnt]\
                           ->to.name.dom.len);
                  }
               }

               mgDeAlloc ((Data *) chCntxt->cxtProps.tl.descs[tlCnt], 
                     sizeof(MgMgcoTopoDesc));
            }
            mgDeAlloc ((Data *) chCntxt->cxtProps.tl.descs, 
                       chCntxt->cxtProps.tl.num.val * sizeof(MgMgcoTopoDesc *));
         }

         mgDeAlloc ((Data *) chCntxt, sizeof(MgMgcoChCntxtProp));
         pNode = pTemp;
      }
   } /* Context Prop present */

   if ((cmHashListFind(&(mgCb.chCb.peerCmdCtlLst), (U8 *)&trReq->peerId, 
                         MG_CH_PEERID_LEN, MG_HASH_SEQNMB_DEF, 
                         (PTR *)&peerCmdCtl)) == ROK) 
   {
      /* Delete the transaction request node from the list */
      cmHashListDelete(&(peerCmdCtl->transReqLst), (PTR)trReq); 

      /* [UG]: Free the node after freeing in the list */
      /* Free the transaction request node */
      mgDeAlloc ((Data *) trReq, sizeof(MgMgcoChTransReq));
   }  
   else
   {
      /* [UG]: Free the transReq as it can be present only for context update */
      if (trReq->type.val == CH_AXN_TYPE_ONLY_CNTXT)
         /* Free the transaction request node */
         mgDeAlloc ((Data *) trReq, sizeof(MgMgcoChTransReq));
      else
         RETVALUE(RFAILED);
   }
 
   RETVALUE(ROK);
} /* mgChCleanupTransReq */



/*
 *       Fun:   mgChHndlRspTimeOut 
 *
 *       Desc:  This CH function handles the response timeout for a  
 *              transaction and sends response timeout to the user
 *              and error transaction response to peer.
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PRIVATE S16 mgChHndlRspTimeOut 
(
U32     transId,           /* Trans Id   */
U32     peerId             /* Peer  Id   */
)
#else
PRIVATE S16 mgChHndlRspTimeOut (transId, peerId)
U32     transId;           /* Trans Id   */
U32     peerId;            /* Peer  Id   */
#endif 
{
   MgMgcoInd       chInd;         /* CH Indication      */
   MgMgcoChPeerCmdCtl     *peerCmdCtl = NULLP;    /* Peer Cmd Control   */
   MgMgcoChCb             *chCb = &(mgCb.chCb);   /* CH Control BLock   */
   MgMgcoChTransIndRsp   *txnRsp;        /* CH Transation Rsp  */
   MgMgcoMsg          *msg;     
   U16                idx = 0;        /* Loop Index         */
   U16                cmdIdx = 0;     /* Loop Index         */
   U16                ctxIdx = 0;     /* Loop Index         */
   S16                ret = ROK;      /* return value       */
   MgMgcoTxnReply       *tr = NULLP;    /* Transaction Request*/
   MgMgcoActnReply    *ar = NULLP;    /* Action Request     */
   Size                  size;
   CmLList            *pNode     = NULLP;
   CmLList            *pCmdNode  = NULLP;
   CmLList            *pCxtNode  = NULLP;
   MgMgcoChAxnIndRsp     *chAxnIndRsp  = NULLP; /* CH Axn Request */
   MgMgcoChCntxtProp  *chCnxt    = NULLP; /* CH Context Prop*/
   MgPeerCb           *peer = NULLP;      /* Peer Block     */
   MgMgcoAuditReply   *audReply  = NULLP; /* Audit Reply    */
   MgMgcoNtfyReply    *ntfyReply = NULLP; /* Notify Reply   */
   MgMgcoSvcChgReply   *svcReply = NULLP; /* Svc Change Rep */
   MgMgcoChCmdResp     *chCmdRsp = NULLP; /* Ch command resp*/
   U16                 validRspCount=0;   /* Valid response */   
   U8                  type;              /* Type of Req    */
   MgMgcoErrDesc       *err = NULLP;      /* error desc     */
   MgMgcoCxtCmdReply    *reply=NULLP;     /* Reply          */
   TknU32               peerIdTemp;       /* Temp peerId    */
   MgMgcoAudRetParm  *audRet;
   MgMgcoAmmsReply   *ammsreply;
   CmdId            curCmdIndId;    
   U8                 *val;
   MgMgcoTermId       *pTermId;
   Bool               wildPres = FALSE;

   TRC3(mgChHndlRspTimeOut) 

   peerIdTemp.pres = PRSNT_NODEF;
   peerIdTemp.val = peerId;
 
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
   cmMemset((U8 *)&chInd, 0, sizeof(MgMgcoInd)); 
#endif /* GCP_CH && GCP_VER_1_5 */ 

   /* Check if peer command control is present for the peer Id   */
   if (mgChChkPeer (peerIdTemp) == RFAILED)
   {
      RETVALUE(RFAILED);
   }

   CH_GET_PEER_FRM_PEERID(peerId, peer); 

   /* Peer Id is valid */
   /* Peer Cmd List is already initialised in mgInit function  */
   if ((cmHashListFind(&(chCb->peerCmdCtlLst), (U8 *)&peerId, 
                         MG_CH_PEERID_LEN, MG_HASH_SEQNMB_DEF, 
                         (PTR *)&peerCmdCtl)) != ROK) 
   {
      /* Peer not present */
      RETVALUE(RFAILED);
   }

   /* Peer Found, Check for Trans IndRsp List */
   if ((cmHashListFind(&(peerCmdCtl->transIndRspLst), (U8 *)&transId,
                       MG_TRANSID_LEN,
                       MG_HASH_SEQNMB_DEF, (PTR *)&txnRsp)) != ROK)
   {
      /* Transaction not present */
      RETVALUE(RFAILED);
   }

   /* Send response timed out indication to user */
   chInd.transId.pres = PRSNT_NODEF;
   chInd.transId.val = transId;
   CH_CP_IND_PEERID(chInd,peerId)
   /* mg003.105: Changed error code from rsp timeout to pending limit exceed */   
   CH_SET_IND_ERRDESC(chInd,MGT_CH_ERR_PEND_LIMIT_EXCEEDED)
   /* Send Response timed out to user */
   mgChSendPrim ((Ptr)&chInd, peer, NULLP, CH_PRIM_TYPE_IND); 

   /* Compose transaction  */
   if(ROK != mgAllocEventMem((Ptr *)&msg, sizeof(MgMgcoMsg)) )
   {
      RETVALUE(RFAILED);
   }

   /* Pres field in MgMgcoMsg in filled */
   msg->pres.pres = PRSNT_NODEF;
   msg->lcl.pres.pres = PRSNT_NODEF;
   msg->lcl.id.pres = PRSNT_NODEF;
   msg->lcl.id.val = peer->accessInfo.peerId;
   /* Copy mid from peer  */
   MG_CH_GETMEM((val),peer->accessInfo.mid.len,&(msg->memCp));
   MG_CH_INIT_TKNSTROSXL(&(msg->mid), 
                        val, peer->accessInfo.mid.len)
   cmMemcpy((U8*)(val), (U8*)(peer->accessInfo.mid.val),
            peer->accessInfo.mid.len);
   /* cmMemcpy ((U8 *) &(msg->mid), (U8 *) &(peer->accessInfo.mid), */
              /* sizeof(TknStrOSXL)); */
  
   /* Some acceptance functions are directly called need to check out */
   /* whether this is possible or to be worked for an alternative */
   /* Auth header is not filled */
   ret = mgChFillAuthHdr(FALSE,&(msg->ah),0,0,NULLP,0);

   /* Code Review Patch: Fill protocol version as negotiated version */
   ret = mgChFillVersion(TRUE,&(msg->ver), peer->mgcoInfo.negotiatedVersion);
  
    /* Fill Message body. Only 1 transaction reply present */
   MG_CH_INIT_TOKEN_VALUE(&(msg->body.type),MGT_TXN);
   /* Will be sending one transaction at a time */
   MG_CH_INIT_TOKEN_VALUE(&(msg->body.u.tl.num),1);
  
    /* Allocate memory based on transaction */
#ifndef GCP_VER_1_3
   size = ((msg->body.u.tl.num.val) * (sizeof(MgMgcoTxn*)));
   MG_CH_GETMEM((msg->body.u.tl.txns),size,&(msg->memCp) );
#endif /* GCP_VER_1_3 */
#ifdef GCP_VER_1_3
   MG_ALLOC_EVNT_MEM(msg->body.u.tl.txns[idx],
                        ret, sizeof(MgMgcoTxn));
#else
   MG_CH_GETMEM((msg->body.u.tl.txns[idx]),
                sizeof(MgMgcoTxn),&(msg->memCp));
#endif
   
   /* Handling only transaction response  */
   MG_CH_INIT_TOKEN_VALUE(&(msg->body.u.tl.txns[idx]->type),MGT_TXNREPLY);
   tr = &(msg->body.u.tl.txns[idx]->u.reply);
   tr->pres.pres = PRSNT_NODEF;
   /* Copy Transaction Id  */
   MG_CH_COPY_STRUCT(&(tr->transId), &(txnRsp->transId), sizeof(MgMgcoTransId))
   /* Set action reply */
   MG_CH_INIT_TOKEN_VALUE(&(tr->type), MGT_ACTIONREPLY)
   /* Allocate memory based on actions */
   /* Note current action Id holds number of actions */
   /* Action Id starts from 0 hence incrementing by 1 */
   size = ((txnRsp->curActionId +1) * (sizeof(MgMgcoActnReply*)));
   /* Need to check whether the allocation is correct */
   MG_CH_GETMEM((tr->u.arl.repl),size,&(msg->memCp) );
   MG_CH_INIT_TOKEN_VALUE(&(tr->u.arl.num),(txnRsp->curActionId +1));

   for (idx =0; idx < txnRsp->curActionId +1;
                idx++)
   {
      /* [UG]: ValidRspCount to be made to zero for each action*/
      validRspCount = 0;

      MG_CH_GETMEM(tr->u.arl.repl[idx],
             sizeof(MgMgcoActnReply),&(msg->memCp));
      ar = tr->u.arl.repl[idx];
      /* Fill present value  */
      ar->pres.pres = PRSNT_NODEF;
      chAxnIndRsp = (MgMgcoChAxnIndRsp *) txnRsp->axnIndRsp[idx];
      MG_CH_COPY_STRUCT(&(ar->cxtId), &(chAxnIndRsp->cntxtId), 
                        sizeof(MgMgcoContextId))

      /* Check whether commands are present */
      if ((chAxnIndRsp->type.val == CH_AXN_TYPE_BOTH) ||
          (chAxnIndRsp->type.val == CH_AXN_TYPE_ONLY_CMDS)) 
      { 
            /* Calculate the valid response count */
            pCmdNode = chAxnIndRsp->respLst.first;
            for (cmdIdx = 0; cmdIdx < chAxnIndRsp->respLst.count;
                 cmdIdx++)
            {
               chCmdRsp = (MgMgcoChCmdResp *) pCmdNode->node;
               if (chCmdRsp->cmdIndId <= chAxnIndRsp->curCmdIndId)
                  /* Got some response already */
                  validRspCount++;
               /* [UG]: Adding for wildcard support */
               if ((chCmdRsp->cmdIndId == chAxnIndRsp->curCmdIndId) && 
                   (chAxnIndRsp->actionId == txnRsp->curActionId))
               {
                  if (chAxnIndRsp->cmdIndInfo[chAxnIndRsp->curCmdIndId]->wild.pres == PRSNT_NODEF)
                  {
                     wildPres = TRUE;
                     break;
                  }
               }
 
               pCmdNode = pCmdNode->next;
            } /* for */
            if ((validRspCount == 0) ||
                ((chCmdRsp != NULLP)&& 
                 (chCmdRsp->cmdIndId != chAxnIndRsp->curCmdIndId)))
                  /* NO response got or some response missing we need */
                  /* to form one */
                  validRspCount++;
#ifdef MGT_GCP_VER_1_4
         reply = &(ar->repErrSet.reply);
#else
         reply = &(ar->u.reply);
#endif
#ifdef MGT_GCP_VER_1_4
         ar->repErrSet.pres.pres = PRSNT_NODEF;
         ar->repErrSet.reply.pres.pres = PRSNT_NODEF;
#else
         MG_CH_INIT_TOKEN_VALUE(&(ar->type),MGT_CXTCMDREPLY);
#endif
         reply->pres.pres = PRSNT_NODEF;
         MG_CH_INIT_TOKEN_VALUE(&(reply->cl.num), 
                                (validRspCount))
 
         /* Don't allocate as this is now static array  */
         /* MG_CH_GETMEM((reply->cl.repl),size,&(msg->memCp) ); */
 
         pCmdNode = chAxnIndRsp->respLst.first;
          
         for (cmdIdx = 0; cmdIdx < (validRspCount); cmdIdx++)
         {
            if (pCmdNode != NULLP)
               chCmdRsp = (MgMgcoChCmdResp *) pCmdNode->node;
            /* Copy the command structure from CH to Event structure */
            /* If no single response received then we have to atleast */
            /* send a error response to peer */
            /* Compose error command response */
            /* [UG]: Adding for Wildcard support */
            if ((cmdIdx == validRspCount -1) ||
               ((cmdIdx == chAxnIndRsp->curCmdIndId) && (wildPres == TRUE))) 
            {
               /* Last response */
               /* [UG]: Adding for Wildcard support */
               if ((pCmdNode == NULLP) || 
               ((cmdIdx == chAxnIndRsp->curCmdIndId) && (wildPres == TRUE))) 
               {
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                  U16   ix, nmbr;
#endif /* GCP_VER_1_5 && GCP_ASN */
                  /* Compose all the responses received except the */
                  /* outstanding  */
                  MG_ALLOC_EVNT_MEM(reply->cl.repl[cmdIdx],
                        ret, sizeof(MgMgcoCmdReply));
                  reply->cl.repl[cmdIdx]->pres.pres = PRSNT_NODEF;
                  curCmdIndId = chAxnIndRsp->curCmdIndId;
                  /* Possibily first response not received  or */
                  /* no single response received for an indication */
                  /* locate the type of the reply requrred from */
                  /* the indication which we have sent  */
                  type = chAxnIndRsp->cmdIndInfo[curCmdIndId]->type; 
                  /* MG_CH_COPY_STRUCT( */
                  /* &(reply->cl.repl[cmdIdx]->wild), */
                  /* &( chAxnIndRsp->cmdInds[curCmdIndId]->wild), */
                  /* sizeof(TknPres)) */
                  /* Don't set this value */
                  /* MG_CH_INIT_TOKEN_VALUE( */
                  /* &(reply->cl.repl[cmdIdx]->wild), */
                  /* type) */
                  curCmdIndId = chAxnIndRsp->curCmdIndId;    
                  MG_CH_INIT_TOKEN_VALUE(&(reply->cl.repl[cmdIdx]->type),
                        type);

                  switch(type)
                  {
                     /* Intentional fall through to make use of ammsreply */
                     case MGT_MODIFY:               
                     case MGT_MOVE:                 
                     case MGT_ADD:
                     case MGT_SUB:                  
                        if(type == MGT_ADD)
                        {
                           ammsreply = 
                              &(reply->cl.repl[cmdIdx]->u.add);
                           MG_CH_COPY_STRUCT(
                              &(reply->cl.repl[cmdIdx]->u.add.termId),
                                 &(chAxnIndRsp->cmdIndInfo[cmdIdx]->termId),
                                sizeof(MgMgcoTermId))
                           /* mg005.105: Copy the wildcard in chAxnIndRsp->cmdIndInfo*/
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                           if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
                           {   
                              /* copy the wildcard contents also */
                              nmbr = chAxnIndRsp->cmdIndInfo[cmdIdx]->\
                                        termId.wildcard.num.val;
                              if( nmbr > 0)
                              {   
                                 MG_CH_GETMEM((reply->cl.repl[cmdIdx]->u.add.termId.\
                                            wildcard.wildcard),
                                            nmbr * sizeof(MgMgcoWildcardField *),
                                            &(msg->memCp));
                                 for (ix=0; ix < nmbr; ++ix)
                                 {
                                    MG_CH_GETMEM((reply->cl.repl[cmdIdx]->u.add.termId.\
                                               wildcard.wildcard[ix]),
                                              sizeof(MgMgcoWildcardField),
                                              &(msg->memCp));
                                    MG_CH_COPY_STRUCT((reply->cl.repl[cmdIdx]->u.add.termId.\
                                                     wildcard.wildcard[ix]),
                                                   (chAxnIndRsp->cmdIndInfo[cmdIdx]->termId.\
                                                      wildcard.wildcard[ix]),
                                                   sizeof(MgMgcoWildcardField))
                                 }
                              }   
                           }   
#endif /* GCP_VER_1_5 && GCP_ASN */
                           pTermId = &(reply->cl.repl[cmdIdx]->u.add.termId);
                        }
                        else if(type == MGT_MODIFY)
                        {
                           ammsreply = 
                              &(reply->cl.repl[cmdIdx]->u.mod);
                           MG_CH_COPY_STRUCT(
                                 &(reply->cl.repl[cmdIdx]->u.mod.termId),
                                 &(chAxnIndRsp->cmdIndInfo[cmdIdx]->termId),
                                 sizeof(MgMgcoTermId))
                           /* mg005.105: Copy the wildcard in chAxnIndRsp->cmdIndInfo*/
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                           if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
                           {   
                              /* copy the wildcard contents also */
                              nmbr = chAxnIndRsp->cmdIndInfo[cmdIdx]->\
                                        termId.wildcard.num.val;
                              if( nmbr > 0)
                              {   
                                 MG_CH_GETMEM((reply->cl.repl[cmdIdx]->u.mod.termId.\
                                            wildcard.wildcard),
                                            nmbr * sizeof(MgMgcoWildcardField *),
                                            &(msg->memCp));
                                 for (ix=0; ix < nmbr; ++ix)
                                 {
                                    MG_CH_GETMEM((reply->cl.repl[cmdIdx]->u.mod.termId.\
                                               wildcard.wildcard[ix]),
                                              sizeof(MgMgcoWildcardField),
                                              &(msg->memCp));
                                    MG_CH_COPY_STRUCT((reply->cl.repl[cmdIdx]->u.mod.termId.\
                                                     wildcard.wildcard[ix]),
                                                   (chAxnIndRsp->cmdIndInfo[cmdIdx]->termId.\
                                                      wildcard.wildcard[ix]),
                                                   sizeof(MgMgcoWildcardField))
                                 }
                              }   
                           }   
#endif /* GCP_VER_1_5 && GCP_ASN */
                           pTermId = &(reply->cl.repl[cmdIdx]->u.mod.termId);
                        }
                        else if(type == MGT_MOVE)
                        {
                           ammsreply = 
                              &(reply->cl.repl[cmdIdx]->u.move);
                           MG_CH_COPY_STRUCT(
                                 &(reply->cl.repl[cmdIdx]->u.move.termId),
                                 &(chAxnIndRsp->cmdIndInfo[cmdIdx]->termId),
                                 sizeof(MgMgcoTermId))
                           /* mg005.105: Copy the wildcard in chAxnIndRsp->cmdIndInfo*/
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                           if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
                           {   
                              /* copy the wildcard contents also */
                              nmbr = chAxnIndRsp->cmdIndInfo[cmdIdx]->\
                                        termId.wildcard.num.val;
                              if( nmbr > 0)
                              {   
                                 MG_CH_GETMEM((reply->cl.repl[cmdIdx]->u.move.termId.\
                                            wildcard.wildcard),
                                            nmbr * sizeof(MgMgcoWildcardField *),
                                            &(msg->memCp));
                                 for (ix=0; ix < nmbr; ++ix)
                                 {
                                    MG_CH_GETMEM((reply->cl.repl[cmdIdx]->u.move.termId.\
                                               wildcard.wildcard[ix]),
                                              sizeof(MgMgcoWildcardField),
                                              &(msg->memCp));
                                    MG_CH_COPY_STRUCT((reply->cl.repl[cmdIdx]->u.move.termId.\
                                                     wildcard.wildcard[ix]),
                                                   (chAxnIndRsp->cmdIndInfo[cmdIdx]->termId.\
                                                      wildcard.wildcard[ix]),
                                                   sizeof(MgMgcoWildcardField))
                                 }
                              }   
                           }   
#endif /* GCP_VER_1_5 && GCP_ASN */
                           pTermId = &(reply->cl.repl[cmdIdx]->u.move.termId);
                        }
                        else if(type == MGT_SUB)
                        {
                           ammsreply = 
                              &(reply->cl.repl[cmdIdx]->u.sub);
                           MG_CH_COPY_STRUCT(
                                 &(reply->cl.repl[cmdIdx]->u.sub.termId),
                                 &(chAxnIndRsp->cmdIndInfo[cmdIdx]->termId),
                                 sizeof(MgMgcoTermId))
                           /* mg005.105: Copy the wildcard in chAxnIndRsp->cmdIndInfo*/
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                           if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
                           {   
                              /* copy the wildcard contents also */
                              nmbr = chAxnIndRsp->cmdIndInfo[cmdIdx]->\
                                        termId.wildcard.num.val;
                              if( nmbr > 0)
                              {   
                                 MG_CH_GETMEM((reply->cl.repl[cmdIdx]->u.sub.termId.\
                                            wildcard.wildcard),
                                            nmbr * sizeof(MgMgcoWildcardField *),
                                            &(msg->memCp));
                                 for (ix=0; ix < nmbr; ++ix)
                                 {
                                    MG_CH_GETMEM((reply->cl.repl[cmdIdx]->u.sub.termId.\
                                               wildcard.wildcard[ix]),
                                              sizeof(MgMgcoWildcardField),
                                              &(msg->memCp));
                                    MG_CH_COPY_STRUCT((reply->cl.repl[cmdIdx]->u.sub.termId.\
                                                     wildcard.wildcard[ix]),
                                                   (chAxnIndRsp->cmdIndInfo[cmdIdx]->termId.\
                                                      wildcard.wildcard[ix]),
                                                   sizeof(MgMgcoWildcardField))
                                 }
                              }   
                           }   
#endif /* GCP_VER_1_5 && GCP_ASN */
                           pTermId = &(reply->cl.repl[cmdIdx]->u.sub.termId);
                        }

                        /* Assuming all the other values are preserved  */
                        /* filling only the error descriptor */
                        ammsreply->pres.pres = PRSNT_NODEF;
                        MG_CH_INIT_TOKEN_VALUE(&(ammsreply->audit.num), 1)
                           size = (sizeof(MgMgcoAudRetParm*));
                        MG_CH_GETMEM((ammsreply->audit.parms),size,
                              &(reply->cl.repl[cmdIdx]->memCp) );
                        size = (sizeof(MgMgcoAudRetParm));
                        /* Only one error descriptor */
                        MG_CH_GETMEM((ammsreply->audit.parms[0]),
                              size,&(reply->cl.repl[cmdIdx]->memCp));
                        audRet = ammsreply->audit.parms[0]; 
                        MG_CH_INIT_TOKEN_VALUE(&(audRet->type), 
                              MGT_ERRDESC)
                           err = &(audRet->u.err); 
                        /* error text need to be copied */
                        break;

                     case MGT_AUDITCAP:             
                     case MGT_AUDITVAL:             
                        if(type == MGT_AUDITCAP)
                        {
                           audReply = 
                              &(reply->cl.repl[cmdIdx]->u.acap);
                        }
                        if(type == MGT_AUDITVAL)
                        {
                           audReply = 
                              &(reply->cl.repl[cmdIdx]->u.aval);
                        }
                        MG_CH_INIT_TOKEN_VALUE(&(audReply->type), MGT_ERRDESC)
                           err = &(audReply->u.err); 
                        break;
                     case MGT_NTFY:                 

                        MG_CH_COPY_STRUCT(
                              &(reply->cl.repl[cmdIdx]->u.ntfy.termId),
                              &(chAxnIndRsp->cmdIndInfo[cmdIdx]->termId),
                              sizeof(MgMgcoTermId))
                        /* mg005.105: Copy the wildcard in chAxnIndRsp->cmdIndInfo*/
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                        if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
                        {   
                           /* copy the wildcard contents also */
                           nmbr = chAxnIndRsp->cmdIndInfo[cmdIdx]->\
                                     termId.wildcard.num.val;
                           if( nmbr > 0)
                           {   
                              MG_CH_GETMEM((reply->cl.repl[cmdIdx]->u.ntfy.termId.\
                                         wildcard.wildcard),
                                         nmbr * sizeof(MgMgcoWildcardField *),
                                         &(msg->memCp));
                              for (ix=0; ix < nmbr; ++ix)
                              {
                                 MG_CH_GETMEM((reply->cl.repl[cmdIdx]->u.ntfy.termId.\
                                            wildcard.wildcard[ix]),
                                           sizeof(MgMgcoWildcardField),
                                           &(msg->memCp));
                                 MG_CH_COPY_STRUCT((reply->cl.repl[cmdIdx]->u.ntfy.termId.\
                                                  wildcard.wildcard[ix]),
                                                (chAxnIndRsp->cmdIndInfo[cmdIdx]->termId.\
                                                   wildcard.wildcard[ix]),
                                                sizeof(MgMgcoWildcardField))
                              }
                           }   
                        }   
#endif /* GCP_VER_1_5 && GCP_ASN */
                        ntfyReply = &(reply->cl.repl[cmdIdx]->u.ntfy);
                        err = &(ntfyReply->err); 
                        pTermId = &(reply->cl.repl[cmdIdx]->u.ntfy.termId);

                        break;

                     case MGT_SVCCHG:               
                        svcReply = 
                           &(reply->cl.repl[cmdIdx]->u.svc);

                        MG_CH_COPY_STRUCT(
                              &(reply->cl.repl[cmdIdx]->u.svc.termId),
                              &(chAxnIndRsp->cmdIndInfo[cmdIdx]->termId),
                              sizeof(MgMgcoTermId))
                           /* mg005.105: Copy the wildcard in chAxnIndRsp->cmdIndInfo*/
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                        if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
                        {   
                           /* copy the wildcard contents also */
                           nmbr = chAxnIndRsp->cmdIndInfo[cmdIdx]->\
                                     termId.wildcard.num.val;
                           if( nmbr > 0)
                           {   
                              MG_CH_GETMEM((reply->cl.repl[cmdIdx]->u.svc.termId.\
                                         wildcard.wildcard),
                                         nmbr * sizeof(MgMgcoWildcardField *),
                                         &(msg->memCp));
                              for (ix=0; ix < nmbr; ++ix)
                              {
                                 MG_CH_GETMEM((reply->cl.repl[cmdIdx]->u.svc.termId.\
                                            wildcard.wildcard[ix]),
                                           sizeof(MgMgcoWildcardField),
                                           &(msg->memCp));
                                 MG_CH_COPY_STRUCT((reply->cl.repl[cmdIdx]->u.svc.termId.\
                                                  wildcard.wildcard[ix]),
                                                (chAxnIndRsp->cmdIndInfo[cmdIdx]->termId.\
                                                   wildcard.wildcard[ix]),
                                                sizeof(MgMgcoWildcardField))
                              }
                           }   
                        }   
#endif /* GCP_VER_1_5 && GCP_ASN */
                        MG_CH_INIT_TOKEN_VALUE(&(svcReply->res.type), MGT_ERRDESC)
                        err = &(svcReply->res.u.err); 
                        pTermId = &(reply->cl.repl[cmdIdx]->u.svc.termId);
                        break;

                  } /* switch */

                  err->pres.pres = PRSNT_NODEF;
                  MG_CH_INIT_TOKEN_VALUE(&(err->code),
                        MGT_MGCO_RSP_CODE_TXNPENDING_EXCEEDED)

                  MG_CH_COPY_STRUCT(pTermId, &chAxnIndRsp->cmdIndInfo\
                                                 [curCmdIndId]->termId,
                                       sizeof(MgMgcoTermId))

                  /* Copy the pathname in termId if present by allocating */
                  if((pTermId->type.val == MGT_TERMID_OTHER) &&
                        (pTermId->name.pres.pres != NOTPRSNT) &&
                        (pTermId->name.lcl.pres != NOTPRSNT) ) 
                  {
                     MG_CH_GETMEM(pTermId->name.lcl.val,
                           pTermId->name.lcl.len,
                           &reply->cl.repl[cmdIdx]->memCp)

                     MG_CH_COPY_STRUCT(pTermId->name.lcl.val,
                              chAxnIndRsp->cmdIndInfo[curCmdIndId]-> \
                              termId.name.lcl.val,
                              pTermId->name.lcl.len)
                        /* Copy the pathname in termId if
                         * present by allocating */

                  }
                  if((pTermId->type.val == MGT_TERMID_OTHER) &&
                        (pTermId->name.pres.pres != NOTPRSNT) &&
                        (pTermId->name.dom.pres != NOTPRSNT) ) 
                  {
                     MG_CH_GETMEM(pTermId->name.dom.val,
                           pTermId->name.dom.len,
                           &reply->cl.repl[cmdIdx]->memCp)

                     MG_CH_COPY_STRUCT(pTermId->name.dom.val,
                              chAxnIndRsp->cmdIndInfo[curCmdIndId]-> \
                              termId.name.dom.val,
                              pTermId->name.dom.len)

                  }
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                  if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
                  {                  
                     if (((pTermId->type.val == MGT_TERMID_ALL) || 
                         (pTermId->type.val == MGT_TERMID_CHOOSE)) &&
                         (pTermId->name.pres.pres != NOTPRSNT))
                     {
                        if(pTermId->name.lcl.pres != NOTPRSNT) 
                        {
                           MG_CH_GETMEM(pTermId->name.lcl.val,
                                 pTermId->name.lcl.len,
                                 &reply->cl.repl[cmdIdx]->memCp)

                           MG_CH_COPY_STRUCT(pTermId->name.lcl.val,
                                 chAxnIndRsp->cmdIndInfo[curCmdIndId]-> \
                                 termId.name.lcl.val,
                                 pTermId->name.lcl.len)
                              /* Copy the pathname in termId if
                               * present by allocating */
                        }
                        if(pTermId->name.dom.pres != NOTPRSNT) 
                        {
                           MG_CH_GETMEM(pTermId->name.dom.val,
                              pTermId->name.dom.len,
                              &reply->cl.repl[cmdIdx]->memCp)

                           MG_CH_COPY_STRUCT(pTermId->name.dom.val,
                                 chAxnIndRsp->cmdIndInfo[curCmdIndId]-> \
                                 termId.name.dom.val,
                                 pTermId->name.dom.len)
                        }
                     }

                     /* copy the wildcard contents also */
                     nmbr = chAxnIndRsp->cmdIndInfo[cmdIdx]->\
                               termId.wildcard.num.val;
                     if( nmbr > 0)
                     {          
                        MG_CH_GETMEM(pTermId->wildcard.wildcard,
                                      nmbr * sizeof(MgMgcoWildcardField *),
                                      &(msg->memCp));
                        for (ix=0; ix < nmbr; ++ix)
                        {
                           MG_CH_GETMEM(pTermId->wildcard.wildcard[ix],
                                        sizeof(MgMgcoWildcardField),
                                        &(msg->memCp));
                           MG_CH_COPY_STRUCT(pTermId->wildcard.wildcard[ix],
                                             (chAxnIndRsp->cmdIndInfo[cmdIdx]->termId.\
                                                wildcard.wildcard[ix]),
                                             sizeof(MgMgcoWildcardField))
                        }
                     }   
                  }   
#endif /* GCP_VER_1_5 && GCP_ASN */
               }
               else
               {   
                  reply->cl.repl[cmdIdx] = chCmdRsp->cmdResp;
               }
            } 
            else
            {   
               reply->cl.repl[cmdIdx] = chCmdRsp->cmdResp;
            }
            if (pCmdNode != NULLP)
               pCmdNode = pCmdNode->next;
          } /* for cmdIdx  */
      } /* Commands */ 
      /* Check whether context update is present  */
      if ((chAxnIndRsp->type.val == CH_AXN_TYPE_BOTH) ||
         (chAxnIndRsp->type.val == CH_AXN_TYPE_ONLY_CNTXT)) 
      { 
         /* Context Update is present, check whether anything is present */
         /* this action                                                  */
         Bool   found = FALSE;
 
#ifdef MGT_GCP_VER_1_4
         reply = &(ar->repErrSet.reply);
#else
         reply = &(ar->u.reply);
#endif

         pCxtNode = txnRsp->userCntxtLst.first;
         for (ctxIdx = 0; ctxIdx < txnRsp->userCntxtLst.count;
              ctxIdx++)
         {
            chCnxt = (MgMgcoChCntxtProp *) (pCxtNode->node);
            if (chCnxt->actionId == idx)
            {
               /* Context Update present for this action */
               MG_CH_COPY_STRUCT((&(reply->cxt)), (&(chCnxt->cxtProps)),
                                  sizeof(MgMgcoContextProps))
               found = TRUE;
               break;
            } 
            pCxtNode = pCxtNode->next;
         } /* for ctxIdx */
         /* [UG]: Code added for sending timeout response for cntxt update */
         /* Check the cntxtlst from transaction id */
         if (found == FALSE)
         {
            pCxtNode = txnRsp->chCntxtLst.first;
            for (ctxIdx = 0; ctxIdx < txnRsp->chCntxtLst.count;
                 ctxIdx++)
            {
               chCnxt = (MgMgcoChCntxtProp *) (pCxtNode->node);
               if (chCnxt->actionId == idx)
               {
#ifdef MGT_GCP_VER_1_4
                  ar->repErrSet.pres.pres = PRSNT_NODEF;
                  /* Copy the error descriptor */
                  ar->repErrSet.err.pres.pres = PRSNT_NODEF;
                  MG_CH_INIT_TOKEN_VALUE(&(ar->repErrSet.err.code),
                        MGT_MGCO_RSP_CODE_TXNPENDING_EXCEEDED)
#else /* MGT_GCP_VER_1_4 */
                  /*  Set the type to error in the reply */
                  MG_CH_INIT_TOKEN_VALUE(&(ar->type), MGT_ERRDESC)
                  /* Copy the error descriptor */
                  ar->u.err.pres.pres = PRSNT_NODEF; 
                  MG_CH_INIT_TOKEN_VALUE(&(ar->u.err.code),
                        MGT_MGCO_RSP_CODE_TXNPENDING_EXCEEDED)
#endif /* MGT_GCP_VER_1_4 */
                  break;
               } 
               pCxtNode = pCxtNode->next;
            } /* for ctxIdx */
         }

      }
      if (pNode != NULLP)
         pNode = pNode->next; 
   } /* For ActionId */

      /* mg003.105:ChDelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */
 
#ifdef ZG
   /* del the mapping and send RT upd to standby/shadows */
   mgChDelMappingTxnIndRspAndChilds(txnRsp);
   /* zgDelMapping(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(txnRsp)); */
#ifdef ZG_CH_LVL_UPD
   zgRtUpd(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(txnRsp), CMPFTHA_UPDTYPE_SYNC,
           CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

   mgChCleanupTransIndRsp(&txnRsp);

   /* Process Transaction */                                                    
   ret = mgPrcMgcoTxnReq(peer->ssap, msg, NULLP, MG_USER);    
 
#ifdef ZG
   /* Send update messages */
   zgUpdPeer();
#endif /* ZG */

   RETVALUE(ret);
} /* mgChHndlRspTimeOut */


/*
 *       Fun:  mgChChkPeer    
 *
 *       Desc:  This CH function checks whether peer is present for the   r 
 *              specified peer Id
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PRIVATE S16 mgChChkPeer
(
TknU32     peerId          /* peerId     */
)
#else
PRIVATE S16 mgChChkPeer (peerId)
TknU32     peerId;         /* peerId     */
#endif 
{
   U32  Id;
   MgPeerCb *peer;

   TRC3(mgChChkPeer)

   if (peerId.pres != NOTPRSNT)
   {
      if (peerId.val != MG_INVALID_PEERID)
      {
         Id = (peerId.val & MG_PEERID_MASK);
         /* Implies gateway Id is present */
         if (Id < mgCb.genCfg.maxPeer)
         {
            CH_GET_PEER_FRM_PEERID(peerId.val, peer);

            if (peer != NULLP)
               RETVALUE(ROK);
         }
      }
   }

   RETVALUE(RFAILED);
 
} /* mgChChkPeer */


/*
 *       Fun:  mgChPrcCntxtUpd
 *
 *       Desc:  This CH function processes the context update from the user 
 *              and updates the transaction structure of CH, and triggers 
 *              the request for sending if encountered END_OF_TXN
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PUBLIC S16 mgChPrcCntxtUpd
(
MgMgcoUpdateCntxt   *chUpdCntxt, /* CH Context Update  */
MgSSAPCb            *sSap        /* session SAP cb     */
)
#else
PUBLIC S16 mgChPrcCntxtUpd (chUpdCntxt,sSap)
MgMgcoUpdateCntxt   *chUpdCntxt; /* CH Context Update  */
MgSSAPCb            *sSap;       /* session SAP cb     */
#endif 
{
   MgPeerCb               *peer = NULLP;          /* Peer Control Block */
   MgMgcoChPeerCmdCtl     *peerCmdCtl = NULLP;    /* Peer Cmd Control   */
   MgMgcoChTransReq       *transReq = NULLP;      /* Trans Request Node */
   MgMgcoChTransIndRsp    *transIndRsp = NULLP;   /* Trans IndRsp  Node */
   MgMgcoTransId          transId;                /* Transaction Id     */
   MgMgcoContextId        cntxtId;                /* Context Id         */
   U32                    cntxtLoopCount;             /* Action req loop cnt*/
   Bool                   peerCmdCtlAlloc = FALSE;/* Peer Ctl Allocated?*/
   Bool                   transReqAlloc = FALSE;  /* TransReq Allocated?*/
   Bool                   cnxtAlloc = FALSE;    /* Axn Req Allocated? */
   U8                     type = CM_CMD_TYPE_NONE;/* Axn Req or Resp    */
   MgMgcoChCntxtProp      *chCnxt = NULLP;        /* Ch Context Prop    */
   MgMgcoChActionId       axnId;
   /* mg008.105: Handling for wild card context */
   MgMgcoChAxnIndRsp      *axnIndRsp = NULLP;     /* Action Ind Rsp     */
   MgMgcoChAxnIndRsp      *axnIndWildCardRsp = NULLP;     /* Action Ind Rsp     */
 
   TRC3(mgChPrcCntxtUpd)

   /* [UG]: Adding error ids for txn and context id not found */ 
   if (chUpdCntxt->transId.pres == NOTPRSNT)
   {
      mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt, MGT_CH_ERR_TXNID_NOT_FOUND_IN_CNTXT, MG_USER);
      mgFreeEventMem((Ptr) chUpdCntxt);
      RETVALUE(RFAILED);
   }
   if (chUpdCntxt->contextId.type.pres == NOTPRSNT)
   {
      mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt, MGT_CH_ERR_CNTXTID_NOT_FOUND_IN_CNTXT, MG_USER);
 
      mgFreeEventMem((Ptr) chUpdCntxt);
      RETVALUE(RFAILED);
   }

   cmMemcpy((U8 *)&(transId), (U8 *)&(chUpdCntxt->transId), 
              sizeof (MgMgcoTransId));
   cmMemcpy((U8 *)&(cntxtId), (U8 *)&(chUpdCntxt->contextId), 
              sizeof(MgMgcoContextId));

   /* Check for peerId if present in Peer control block */
   if (mgChChkPeer(chUpdCntxt->peerId) == RFAILED)
   {
      mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt,
                                MGT_CH_ERR_PEER_NOT_FOUND, MG_USER);
      mgFreeEventMem((Ptr) chUpdCntxt);
      RETVALUE(RFAILED);
   }
   /* Peer Id is valid */
 
   CH_GET_PEER_FRM_PEERID(chUpdCntxt->peerId.val, peer);
   /* Peer Cmd List is already initialised in mgInit function  */
   if ((cmHashListFind(&(mgCb.chCb.peerCmdCtlLst),
                        (U8 *)&chUpdCntxt->peerId.val, 
                        MG_CH_PEERID_LEN, MG_HASH_SEQNMB_DEF, 
                        (PTR *)&peerCmdCtl)) != ROK) 
   {
      /* Node not found, may be this is the first command request comming  */
      /* for the peer,Create an entry for the peer */

      if (RFAILED == mgChAllocatePeerCb(chUpdCntxt->peerId.val, &peerCmdCtl))
      {
      /* Code Review Patch : Free the event structure , no need to generate another response as it will
       * require memory which we are already short of */ 
         /* mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt, 
                                   MGT_ERR_RSRC_UNAVAIL, MG_USER); */
         mgFreeEventMem((Ptr)chUpdCntxt);
         RETVALUE(RFAILED);
      }

      peerCmdCtlAlloc = TRUE;

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
      /* add the mapping and send RT upd to standby/shadows */
      ZG_INIT_RSETID_IN_MAPCB(&((peerCmdCtl)->mapCb));
      zgAddMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
      zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */


      /* Note since no peer was present this context update is only for */
      /* command request */
 
      /* Create a TransREq Node */
      if (RFAILED == mgChAllocateTxnReqCb(peerCmdCtl, chUpdCntxt->transId,
                                          &transReq))
      {
         mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt, 
                                   MGT_ERR_RSRC_UNAVAIL, MG_USER);
         mgFreeEventMem((Ptr)chUpdCntxt);

         /* generate RT upd for deleting the peer */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
         zgDelMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
         zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_DEL);
         /* Send update messages */
         zgUpdPeer();
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

         /* Delete the block from the list */
         cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR)peerCmdCtl); 

         mgDeAlloc((Data *) peerCmdCtl, sizeof(peerCmdCtl));
         RETVALUE(RFAILED);
      }

      transReqAlloc = TRUE;

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
      /* add the mapping and send RT upd to standby/shadows */
      ZG_INIT_RSETID_IN_MAPCB(&((transReq)->mapCb));
      zgAddMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq));
#ifdef ZG_CH_LVL_UPD
      zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */


      axnId = CH_FIRST_AXN_ID;
 
      /*
       * Since the peer could not be found, this means that this is the
       * first outgoing cntxt req for this peer. This cntxt primitive can
       * NOT be for an outgoing rsp since in that case, we would have
       * found the peer (created when the incoming msg came).
       */
      type = CH_CMD_TYPE_REQ;

      /* Create a Context Prop Node */
      cnxtAlloc = TRUE;
   } /* No peer */
   else
   /* Peer List Present */
   {
       /* Check if the trans Id is already present in the trans ind rsp List */
       if ((cmHashListFind(&(peerCmdCtl->transIndRspLst), (U8 *)&transId.val, 
                           MG_TRANSID_LEN, MG_HASH_SEQNMB_DEF, 
                           (PTR *)&transIndRsp)) == ROK)
       {
           /* Transaction Ind-Rsp Node present */
           Bool    flag = FALSE;
 
           CmLList *listNode;
 
           /* trans Id in  transIndRsp List */
           type = CH_CMD_TYPE_RSP;

           listNode = transIndRsp->userCntxtLst.first;
           for (cntxtLoopCount =0; 
                cntxtLoopCount <transIndRsp->userCntxtLst.count; 
                cntxtLoopCount++)
           {
              chCnxt = (MgMgcoChCntxtProp *)(listNode->node);
              if ((chCnxt->actionId == transIndRsp->curActionId) && (transIndRsp->axnIndRsp[transIndRsp->curActionId]->wildCardPres == NOTPRSNT))
              {
                 flag = TRUE;                
                 break;
              }
              listNode = listNode->next;
           }

           if (flag == FALSE)
           {
              axnId = transIndRsp->curActionId;
 
              /* New Context Update,Create a Context Update Node */
              cnxtAlloc = TRUE;
              /* New User Context Update,Create a Context Update Node */
           }
        
       } /* trans Id in  transIndRsp List */
       /* Check if it is present in trans request List */
       else if ((cmHashListFind(&(peerCmdCtl->transReqLst), (U8 *)&transId.val,
                           MG_TRANSID_LEN, MG_HASH_SEQNMB_DEF,
                           (PTR *)&transReq)) == ROK)
       {
           /* Transaction Request Node present */
           Bool    flag = FALSE;
           CmLList *listNode;
 
           type = CH_CMD_TYPE_REQ;

           /* Check if Action request is present */
           listNode = transReq->contextPropLst.first;
           for (cntxtLoopCount =0; 
                cntxtLoopCount <transReq->contextPropLst.count; 
                cntxtLoopCount++)
           {
              chCnxt = (MgMgcoChCntxtProp *)(listNode->node);
              if (chCnxt->actionId == transReq->curActionId)
              {
                 axnId = transReq->curActionId;
                 flag = TRUE;                
                 break;
              }
              listNode = listNode->next;
           }

           if (flag == FALSE)
           {
              axnId = transReq->curActionId;
 
              /* New Context Update,Create a Context Update Node */
              cnxtAlloc = TRUE;
           }
       } /* Transaction Request Node present */
       else
       /* If not in both the lists create trans request node */
       {
           /* Since not in both the list may be first context update request */
           /* Allocate Transaction Req Node */
           type = CH_CMD_TYPE_REQ;

           /* Create a TransReq Node */
           if (RFAILED == mgChAllocateTxnReqCb(peerCmdCtl, chUpdCntxt->transId,
                                               &transReq))
           {
              mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt, 
                                        MGT_ERR_RSRC_UNAVAIL, MG_USER);
              mgFreeEventMem((Ptr)chUpdCntxt);
              RETVALUE(RFAILED);
           }

           transReqAlloc = TRUE;

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
           /* add the mapping and send RT upd to standby/shadows */
           ZG_INIT_RSETID_IN_MAPCB(&((transReq)->mapCb));
           zgAddMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq));
#ifdef ZG_CH_LVL_UPD
           zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
                   CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */


           axnId = CH_FIRST_AXN_ID;
 
           /* Create a Update context Node */
           cnxtAlloc = TRUE;
       } /* Trans Id not in both the lists */
   }

   if (type == CH_CMD_TYPE_REQ)
   {
      if (RFAILED == mgChAllocateCntxtReqCb(MG_CH_TXN_REQ, NULLP, transReq,
                                            axnId, cntxtId, &chCnxt,
                                            &(chUpdCntxt->contextProp.cxtProps),
                                            &(chUpdCntxt->contextProp.\
                                              cxtAudit)))
      {
         mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt,
                                   MGT_ERR_RSRC_UNAVAIL, MG_USER);
         mgFreeEventMem((Ptr) chUpdCntxt);

         if (transReqAlloc == TRUE)
         {
            /* generate RT upd for deleting the txn */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
            zgDelMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq));
#ifdef ZG_CH_LVL_UPD
            zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
                    CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

            /* Delete the block from the list */
            cmHashListDelete(&(peerCmdCtl->transReqLst), (PTR)transReq); 

            mgDeAlloc((Data *)transReq, sizeof(MgMgcoChTransReq));
         }

         if (peerCmdCtlAlloc == TRUE)
         {
            /* generate RT upd for deleting the peer */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
            zgDelMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
            zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
                    CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

            /* Delete the block from the list */
            cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR)peerCmdCtl); 

            mgDeAlloc((Data *)peerCmdCtl, sizeof(peerCmdCtl));
         }

 
#ifdef ZG
         /* Send update messages */
         zgUpdPeer();
#endif /* ZG */

         RETVALUE(RFAILED);
      }

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
      /* add the mapping and send RT upd to standby/shadows */
      ZG_INIT_RSETID_IN_MAPCB(&((chCnxt)->mapCb));
      zgAddMapping(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCnxt));
#ifdef ZG_CH_LVL_UPD
      zgRtUpd(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCnxt), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */


      /* Start a Timer and make an entry in transReq Block */
      /* If already started dont start again */

      /* Now Process the commands received */
      if (transReq->type.val == (U8)CH_AXN_TYPE_NONE)
      {
         transReq->type.val = (U8)CH_AXN_TYPE_ONLY_CNTXT;
      }
      else if (transReq->type.val == (U8)CH_AXN_TYPE_ONLY_CMDS)
      {
         transReq->type.val = (U8) CH_AXN_TYPE_BOTH;
      }


      switch (chUpdCntxt->status.val)
      {
         case CH_CMD_STATUS_PENDING:
            /* Commands are pending for this action req.
             * Not Altering the currActionId as we are expecting
             * some more commands */
            break;
         case CH_CMD_STATUS_END_OF_AXN:
            /* No more Commands for this action, but some more actions pending
             * When action Id is not found in the list, will be created new */
            transReq->curActionId++; 

#ifdef ZG
#ifdef ZG_CH_LVL_UPD
            zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
                    CMPFTHA_ACTN_MOD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

            break;

         case CH_CMD_STATUS_END_OF_TXN:
            /* No more actions/commands, compose transaction and send */
            mgChComposeTransReq (transReq, peer);
            break;

         default:
            mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt, 
                  MGT_ERR_RSRC_UNAVAIL, MG_USER);

            mgFreeEventMem((Ptr) chUpdCntxt);

            if (cnxtAlloc == TRUE) 
            {
               /* generate RT upd for deleting the cntxt */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
               zgDelMapping(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCnxt));
#ifdef ZG_CH_LVL_UPD
               zgRtUpd(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCnxt), CMPFTHA_UPDTYPE_SYNC,
                       CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

               /* remove from the linked list */
               if (MG_CH_TXN_REQ == chCnxt->txnType)
                  cmLListDelFrm (&(transReq->contextPropLst), &(chCnxt->node));
               else if (MG_CH_TXN_INDRSP_USR == chCnxt->txnType)
                  cmLListDelFrm (&(transIndRsp->userCntxtLst), &(chCnxt->node));
               else if (MG_CH_TXN_INDRSP_PEER == chCnxt->txnType)
                  cmLListDelFrm (&(transIndRsp->chCntxtLst), &(chCnxt->node));

               mgDeAlloc((Data *) chCnxt, sizeof(MgMgcoChCntxtProp));
            }

            if (transReqAlloc == TRUE)
            {
               /* generate RT upd for deleting the txn */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
               zgDelMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq));
#ifdef ZG_CH_LVL_UPD
               zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
                       CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

               /* Delete the block from the list */
               cmHashListDelete(&(peerCmdCtl->transReqLst), (PTR)transReq); 

               mgDeAlloc((Data *) transReq, sizeof(MgMgcoChTransReq));
            }

            if (peerCmdCtlAlloc == TRUE)
            {
               /* generate RT upd for deleting the peer */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
               zgDelMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
               zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
                       CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

               /* Delete the block from the list */
               cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR)peerCmdCtl); 

               mgDeAlloc((Data *) peerCmdCtl, sizeof(peerCmdCtl));
            }
 
#ifdef ZG
            /* Send update messages */
            zgUpdPeer();
#endif /* ZG */

            RETVALUE(RFAILED);
      } /* switch - chUpdCntxt->cmdStatus */

   }
   else if (type == CH_CMD_TYPE_RSP)
   {
      if (RFAILED == mgChAllocateCntxtRspCb(transIndRsp, axnId, cntxtId,
                                            &chCnxt,
                                            &(chUpdCntxt->contextProp.cxtProps),
                                            &(chUpdCntxt->contextProp.\
                                              cxtAudit)))
      {
         mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt,
                                   MGT_ERR_RSRC_UNAVAIL, MG_USER);
         mgFreeEventMem((Ptr) chUpdCntxt);

         /*
          *   following is not needed -
          *   mgDeAlloc((Data *)transIndRsp, sizeof(MgMgcoChTransIndRsp));
          */

         if (peerCmdCtlAlloc == TRUE)
         {
            /* generate RT upd for deleting the peer */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
            zgDelMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
            zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
                    CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

            /* Delete the block from the list */
            cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR)peerCmdCtl); 

            mgDeAlloc((Data *)peerCmdCtl, sizeof(peerCmdCtl));
         }
 
#ifdef ZG
         /* Send update messages */
         zgUpdPeer();
#endif /* ZG */

         RETVALUE(RFAILED);
      }

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
      /* add the mapping and send RT upd to standby/shadows */
      ZG_INIT_RSETID_IN_MAPCB(&((chCnxt)->mapCb));
      zgAddMapping(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCnxt));
#ifdef ZG_CH_LVL_UPD
      zgRtUpd(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCnxt), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */


      switch (chUpdCntxt->status.val)
      {
         /* mg008.105: Handling for wild card context */
         case CH_CMD_STATUS_END_OF_AXN:
            if (transIndRsp->axnIndRsp[transIndRsp->curActionId]->wildCardPres == TRUE)
            {
               axnIndRsp = transIndRsp->axnIndRsp[transIndRsp->curActionId];
               if (RFAILED == mgChAllocateWildCardAxnIndRspCb(transIndRsp, &axnIndWildCardRsp,
                              chUpdCntxt->contextId, CH_AXN_TYPE_ONLY_CNTXT,
                              CH_AXN_TYPE_ONLY_CNTXT, axnIndRsp->curWildActionId,
                              NULLD))
               {
                  mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt,
                        MGT_ERR_RSRC_UNAVAIL, MG_USER);
                  mgFreeEventMem((Ptr) chUpdCntxt);

                  RETVALUE(RFAILED);

               }
               axnIndRsp->axnIndWildCardRsp[axnIndRsp->curWildActionId] = axnIndWildCardRsp;
               axnIndRsp->axnIndWildCardRsp[axnIndRsp->curWildActionId]->type.val = CH_AXN_TYPE_ONLY_CNTXT;
               axnIndRsp->curWildActionId++;
               axnIndRsp->numOfWildCardRspAxns++;
               if(mgChGrowMem((Ptr* )&(axnIndRsp->axnIndWildCardRsp), axnIndRsp->curWildActionId + 1, axnIndRsp->curWildActionId, sizeof(MgMgcoChAxnIndRsp* )) != ROK)
               {
                  mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt, MGT_ERR_RSRC_UNAVAIL, MG_USER);
               }
            }
            else
            {
               mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt,
                                   MGT_CH_ERR_CMD_STATUS_NONE, MG_USER);
               mgFreeEventMem((Ptr) chUpdCntxt);
               RETVALUE(RFAILED);
            }
            break;

         case CH_CMD_STATUS_PENDING:
            /* Commands are pending for this action req */
            /* Not Altering the currActionId as we are expecting
             * some more commands */
            /* mg008.105: Handling for wild card context */
            if (transIndRsp->axnIndRsp[transIndRsp->curActionId]->wildCardPres == TRUE)
            {
               axnIndRsp = transIndRsp->axnIndRsp[transIndRsp->curActionId];

               if (RFAILED == mgChAllocateWildCardAxnIndRspCb(transIndRsp, &axnIndWildCardRsp,
                              chUpdCntxt->contextId, CH_AXN_TYPE_BOTH ,
                              CH_AXN_TYPE_BOTH, axnIndRsp->curWildActionId,
                              NULLD))
               {
                  mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt,
                        MGT_ERR_RSRC_UNAVAIL, MG_USER);
                  mgFreeEventMem((Ptr) chUpdCntxt);

                  RETVALUE(RFAILED);

               }
               axnIndRsp->axnIndWildCardRsp[axnIndRsp->curWildActionId] = axnIndWildCardRsp;
            }
            break;
         case CH_CMD_STATUS_END_OF_RSP:
            /* No more Commands for this action, but some more actions
             * pending  */
            /* When action Id is not found in the list, will be created new */
            if (transIndRsp->numOfIndRspAxns == transIndRsp->curActionId +1)
               mgChComposeTransRsp (transIndRsp, peer);
            else
            {
               /* transIndRsp->curActionId++; */
               /* Last command indication in this action but some more actions */
               S16                     axnLoopIdx = transIndRsp->curActionId +1;/* Loop Counter       */
               Bool                    cmdPresent=FALSE;      /* Cmd Flag           */
               MgMgcoCommand            chCmdInd;               /* CH Command Ind     */

               axnIndRsp = NULLP;     /* Action Ind Rsp     */
               axnIndRsp = transIndRsp->axnIndRsp[transIndRsp->curActionId +1];   
               if ((axnIndRsp->type.val == CH_AXN_TYPE_BOTH) ||
                  (axnIndRsp->type.val == CH_AXN_TYPE_ONLY_CNTXT))
               {
                   /* Send Update Context to User */
                  mgChSendUpdCntxt(transIndRsp, axnLoopIdx, peer, NULLP, CH_PRIM_TYPE_IND);
               }
               if ((axnIndRsp->type.val == CH_AXN_TYPE_BOTH) ||
                    (axnIndRsp->type.val == CH_AXN_TYPE_ONLY_CMDS))
               {
                  /* Commands present for this action */
                  cmdPresent = TRUE;
               }
               if (cmdPresent == TRUE)
               {
                  /* Got a new axnIndRsp node to send command indication */
                  axnIndRsp->curCmdIndId = CH_FIRST_CMD_IND_ID;   
                  /* Copy transactionId */
                  CH_CP_TRANSID(chCmdInd, transId) 
                  /* Copy contextId */
                  CH_CP_CONTEXTID(chCmdInd, axnIndRsp->cntxtId) 
                  /* Copy Peer Id  */
                  MG_CH_INIT_TOKEN_VALUE(&(chCmdInd.peerId), transIndRsp->peerId)
                  /* Set command type */
                  CH_CP_CMDTYPE(chCmdInd, CH_CMD_TYPE_IND)
                  /* Set the first indication id  */
                  /* Copy the command to the indication primitive */
 
                  chCmdInd.u.mgCmdInd[0] = axnIndRsp->cmdInds[CH_FIRST_CMD_IND_ID];
 
                  if (axnIndRsp->curCmdIndId != axnIndRsp->numOfCmdInds -1)
                     /* Commands Pending */
                     CH_SET_CMDSTATUS(chCmdInd, CH_CMD_STATUS_PENDING)
                  /* [UG]: This should be for the action Id that is being sent. So trIndRsp->curActionId+1 */
                  /* else if (transIndRsp->curActionId < transIndRsp->numOfIndRspAxns -1) */
                  else if (transIndRsp->curActionId+1 < transIndRsp->numOfIndRspAxns -1)
                     CH_SET_CMDSTATUS(chCmdInd, CH_CMD_STATUS_END_OF_AXN)
                  else
                     CH_SET_CMDSTATUS(chCmdInd, CH_CMD_STATUS_END_OF_TXN)
                  mgChSendPrim ((Ptr)&chCmdInd, peer, NULLP, CH_PRIM_TYPE_CMD);
                  transIndRsp->curActionId = axnLoopIdx;
               }
            }
            break;

         default:
            mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt, 
                  MGT_ERR_RSRC_UNAVAIL, MG_USER);

            mgFreeEventMem((Ptr) chUpdCntxt);

            if (cnxtAlloc == TRUE) 
            {
               /* generate RT upd for deleting the cntxt */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
               zgDelMapping(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCnxt));
#ifdef ZG_CH_LVL_UPD
               zgRtUpd(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCnxt), CMPFTHA_UPDTYPE_SYNC,
                       CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

               /* remove from the linked list */
               if (MG_CH_TXN_REQ == chCnxt->txnType)
                  cmLListDelFrm (&(transReq->contextPropLst), &(chCnxt->node));
               else if (MG_CH_TXN_INDRSP_USR == chCnxt->txnType)
                  cmLListDelFrm (&(transIndRsp->userCntxtLst), &(chCnxt->node));
               else if (MG_CH_TXN_INDRSP_PEER == chCnxt->txnType)
                  cmLListDelFrm (&(transIndRsp->chCntxtLst), &(chCnxt->node));

               mgDeAlloc((Data *) chCnxt, sizeof(MgMgcoChCntxtProp));
            }

            if (transReqAlloc == TRUE)
            {
               /* generate RT upd for deleting the txn */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
               zgDelMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq));
#ifdef ZG_CH_LVL_UPD
               zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
                       CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

               /* Delete the block from the list */
               cmHashListDelete(&(peerCmdCtl->transReqLst), (PTR)transReq); 

               mgDeAlloc((Data *) transReq, sizeof(MgMgcoChTransReq));
            }

            if (peerCmdCtlAlloc == TRUE)
            {
               /* generate RT upd for deleting the peer */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
               zgDelMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
               zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
                       CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

               /* Delete the block from the list */
               cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR)peerCmdCtl); 

               mgDeAlloc((Data *) peerCmdCtl, sizeof(peerCmdCtl));
            }
 
#ifdef ZG
            /* Send update messages */
            zgUpdPeer();
#endif /* ZG */

            RETVALUE(RFAILED);
      } /* switch - chUpdCntxt->cmdStatus */
   } /* end of elseif */
   else
   {
       /* Error CMD_TYPE_NONE */
       mgChHandleMgcoCntxtUpdErr(sSap, chUpdCntxt, MGT_CH_ERR_NONE, MG_USER);

       mgFreeEventMem((Ptr) chUpdCntxt);

       if (cnxtAlloc == TRUE)
       {
           /* generate RT upd for deleting the cntxt */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
           zgDelMapping(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCnxt));
#ifdef ZG_CH_LVL_UPD
           zgRtUpd(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCnxt), CMPFTHA_UPDTYPE_SYNC,
                   CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

           /* remove from the linked list */
           if (MG_CH_TXN_REQ == chCnxt->txnType)
              cmLListDelFrm (&(transReq->contextPropLst), &(chCnxt->node));
           else if (MG_CH_TXN_INDRSP_USR == chCnxt->txnType)
              cmLListDelFrm (&(transIndRsp->userCntxtLst), &(chCnxt->node));
           else if (MG_CH_TXN_INDRSP_PEER == chCnxt->txnType)
              cmLListDelFrm (&(transIndRsp->chCntxtLst), &(chCnxt->node));

           mgDeAlloc((Data *) chCnxt, sizeof(MgMgcoChCntxtProp));
       }

       if (transReqAlloc == TRUE)
       {
           /* generate RT upd for deleting the txn */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
           zgDelMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq));
#ifdef ZG_CH_LVL_UPD
           zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(transReq), CMPFTHA_UPDTYPE_SYNC,
                   CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

           /* Delete the block from the list */
           cmHashListDelete(&(peerCmdCtl->transReqLst), (PTR)transReq); 

           mgDeAlloc((Data *) transReq, sizeof(MgMgcoChTransReq));
       }

       if (peerCmdCtlAlloc == TRUE)
       {
           /* generate RT upd for deleting the peer */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
           zgDelMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
           zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
                   CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

           /* Delete the block from the list */
           cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR)peerCmdCtl); 

           mgDeAlloc((Data *) peerCmdCtl, sizeof(peerCmdCtl));
       }
 
#ifdef ZG
       /* Send update messages */
       zgUpdPeer();
#endif /* ZG */

       RETVALUE(RFAILED);
   }

 
#ifdef ZG
   /* Send update messages */
   zgUpdPeer();
#endif /* ZG */

   mgFreeEventMem((Ptr) chUpdCntxt);
   RETVALUE(ROK);
} /* mgChPrcCntxtUpd */


/*
 *       Fun:  mgChComposeTransRsp
 *
 *       Desc:  This CH function composes transaction response
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PRIVATE S16 mgChComposeTransRsp
(
MgMgcoChTransIndRsp   *txnRsp,        /* CH Transation Rsp  */
MgPeerCb              *peer           /* Peer Control Block */
)
#else
PRIVATE S16 mgChComposeTransRsp (txnRsp, peer)
MgMgcoChTransIndRsp   *txnRsp;        /* CH Transation Rsp  */
MgPeerCb              *peer;          /* Peer Control Block */
#endif 
{
   MgMgcoMsg          *msg;     
   U16                idx = 0;        /* Loop Index         */
   U16                axnCount = 0;        /* Loop Index         */
   U16                idxWild = 0;        /* Loop Index         */
   U16                replyIdx = 0;   /* Loop Index         */
   U16                cmdIdx = 0;     /* Loop Index         */
   U16                ctxIdx = 0;     /* Loop Index         */
   S16                ret = ROK;      /* return value       */
   MgMgcoTxnReply       *tr = NULLP;    /* Transaction Request*/
   MgMgcoActnReply    *ar = NULLP;    /* Action Request     */
   Size                  size;
   CmLList            *pCmdNode  = NULLP;
   CmLList            *pCxtNode  = NULLP;
   MgMgcoChAxnIndRsp     *chAxnIndRsp  = NULLP; /* CH Axn Request */
   MgMgcoChAxnIndRsp     *axnIndWildCardRsp  = NULLP; /* CH Axn Wild Card Request */
   MgMgcoChCntxtProp  *chCnxt    = NULLP; /* CH Context Prop*/
   MgMgcoChCmdResp     *chCmdRsp = NULLP; /* Ch command resp*/
   MgMgcoCxtCmdReply    *reply = NULLP;           /* Context reply + cmd replies */
   U8                 *val;
   U16                tlCnt;

   TRC3(mgChComposeTransRsp);
 
   if(ROK != mgAllocEventMem((Ptr *)&msg, sizeof(MgMgcoMsg)) )
   {
      RETVALUE(RFAILED);
   }

   /* Pres field in MgMgcoMsg in filled */
   msg->pres.pres = PRSNT_NODEF;
   msg->lcl.pres.pres = PRSNT_NODEF;
   msg->lcl.id.pres = PRSNT_NODEF;
   msg->lcl.id.val = peer->accessInfo.peerId;
 
   /* Copy mid from ssap*/
   MG_CH_GETMEM((val),peer->ssap->ssapCfg.userInfo.mid.len,&(msg->memCp));
   MG_CH_INIT_TKNSTROSXL(&(msg->mid),
                        val, peer->ssap->ssapCfg.userInfo.mid.len)
   cmMemcpy((U8*)(val),(U8*)(peer->ssap->ssapCfg.userInfo.mid.val),
                             peer->ssap->ssapCfg.userInfo.mid.len);

   /* cmMemcpy ((U8 *) &(msg->mid), (U8 *) &(peer->accessInfo.mid), */
              /* sizeof(TknStrOSXL)); */
  
   /* Some acceptance functions are directly called need to check out */
   /* whether this is possible or to be worked for an alternative */
   /* Auth header is not filled */
   ret = mgChFillAuthHdr(FALSE,&(msg->ah),0,0,NULLP,0);

   /* Code Review Patch: Fill protocol version as negotiated version */
   ret = mgChFillVersion(TRUE,&(msg->ver), peer->mgcoInfo.negotiatedVersion);
  
    /* Fill Message body. Only 1 transaction reply present */
   MG_CH_INIT_TOKEN_VALUE(&(msg->body.type),MGT_TXN);
   /* Will be sending one transaction at a time */
   MG_CH_INIT_TOKEN_VALUE(&(msg->body.u.tl.num),1);
  
    /* Allocate memory based on transaction */
#ifndef GCP_VER_1_3
   size = ((msg->body.u.tl.num.val) * (sizeof(MgMgcoTxn*)));
   MG_CH_GETMEM((msg->body.u.tl.txns),size,&(msg->memCp) );
#endif /* GCP_VER_1_3 */
#ifdef GCP_VER_1_3
   MG_ALLOC_EVNT_MEM(msg->body.u.tl.txns[idx],
                        ret, sizeof(MgMgcoTxn));
#else
   MG_CH_GETMEM((msg->body.u.tl.txns[idx]),
                sizeof(MgMgcoTxn),&(msg->memCp));
#endif
   
   /* Handling only transaction reply */
   MG_CH_INIT_TOKEN_VALUE(&(msg->body.u.tl.txns[idx]->type),MGT_TXNREPLY);
   tr = &(msg->body.u.tl.txns[idx]->u.reply);
   tr->pres.pres = PRSNT_NODEF;
   /* Copy Transaction Id  */
   MG_CH_COPY_STRUCT(&(tr->transId), &(txnRsp->transId), sizeof(MgMgcoTransId))
   /* Set action reply */
   MG_CH_INIT_TOKEN_VALUE(&(tr->type), MGT_ACTIONREPLY)
   /* Allocate memory based on actions */
   axnCount = txnRsp->curActionId + 1;
   for(idx=0; idx<txnRsp->curActionId+1;idx++)
   {
      if(txnRsp->axnIndRsp[idx]->wildCardPres)
         axnCount = axnCount + txnRsp->axnIndRsp[idx]->curWildActionId;
   }
   
   size = (axnCount * (sizeof(MgMgcoActnReply*)));

   MG_CH_GETMEM((tr->u.arl.repl),size,&(msg->memCp) );
 
   MG_CH_INIT_TOKEN_VALUE(&(tr->u.arl.num),axnCount);

   for (idx =0, replyIdx =0; idx < txnRsp->curActionId +1;
                idx++,replyIdx++)
   {
      /* [UG]: For optional cmd handling - if the action has no valid response */ 
      chAxnIndRsp = (MgMgcoChAxnIndRsp *) txnRsp->axnIndRsp[idx];

      if(chAxnIndRsp->wildCardPres != TRUE)
      {
         if (chAxnIndRsp->respLst.count == 0 && 
             chAxnIndRsp->type.val != CH_AXN_TYPE_ONLY_CNTXT)
         {
            replyIdx--;

            /* [UG]: For optional cmd handling - Overwrite the number for invalid actions */ 
            MG_CH_INIT_TOKEN_VALUE(&(tr->u.arl.num),(tr->u.arl.num.val-1));
            continue;
         }

         MG_CH_GETMEM(tr->u.arl.repl[replyIdx],
                sizeof(MgMgcoActnReply),&(msg->memCp));
         ar = tr->u.arl.repl[replyIdx];
         cmMemset((U8 *)(ar), 0, sizeof(MgMgcoActnReply));
         /* Fill present value  */
         ar->pres.pres = PRSNT_NODEF;
         /* chAxnIndRsp = (MgMgcoChAxnIndRsp *) txnRsp->axnIndRsp[idx]; */
         MG_CH_COPY_STRUCT(&(ar->cxtId), &(chAxnIndRsp->cntxtId), 
                           sizeof(MgMgcoContextId))

         /* Check whether commands are present */
         if ((txnRsp->type.val == CH_AXN_TYPE_BOTH) ||
            (txnRsp->type.val == CH_AXN_TYPE_ONLY_CMDS)) 
         {
#ifdef MGT_GCP_VER_1_4
            reply = &(ar->repErrSet.reply);
#else
            reply = &(ar->u.reply);
#endif

            /* Allocate memory for command response */
            size = ((chAxnIndRsp->respLst.count) * (sizeof(MgMgcoCmdReply*)));
 
            /* Not required since it is a static array  */
            /* MG_CH_GETMEM((reply->cl.repl),size,&(msg->memCp) ); */
 
            pCmdNode = chAxnIndRsp->respLst.first;
#ifdef MGT_GCP_VER_1_4
            ar->repErrSet.pres.pres = PRSNT_NODEF;
            /* Set no error action reply */
            ar->repErrSet.err.pres.pres = NOTPRSNT;
#else
            /* Set no error action reply */
            MG_CH_INIT_TOKEN_VALUE(&(ar->type), MGT_CXTCMDREPLY)
#endif
            reply->pres.pres = PRSNT_NODEF;
            /* [UG]: Check whether this particular action has commands */
            if (chAxnIndRsp->respLst.count != 0) 
            MG_CH_INIT_TOKEN_VALUE(&(reply->cl.num), chAxnIndRsp->respLst.count)
            for (cmdIdx = 0; cmdIdx < chAxnIndRsp->respLst.count;
                  cmdIdx++)
             {
                 /* No need to allocate since we are using the MU command */
                 /* Copy the command structure from CH to Event structure */
                 chCmdRsp = (MgMgcoChCmdResp *) pCmdNode->node;
 
                 /* MG_CH_COPY_STRUCT((reply->cl.repl[cmdIdx]),  */
                                   /* ((MgMgcoCmdReply *)&(chCmdRsp->cmdResp)),  */
                                     /* sizeof(MgMgcoCmdReply)) */
                 reply->cl.repl[cmdIdx] = chCmdRsp->cmdResp;
 
                 pCmdNode = pCmdNode->next;
             }
         }

         /* Check whether context update is present  */
         if ((txnRsp->type.val == CH_AXN_TYPE_BOTH) ||
            (txnRsp->type.val == CH_AXN_TYPE_ONLY_CNTXT)) 
         {
            /* [UG]: reply is not set, segmentation fault, so adding this code */
#ifdef MGT_GCP_VER_1_4
            reply = &(ar->repErrSet.reply);
#else
            reply = &(ar->u.reply);
#endif
            /* [UG]: Initialise these fields also */ 
#ifdef MGT_GCP_VER_1_4
            ar->repErrSet.pres.pres = PRSNT_NODEF;
            /* Set no error action reply */
            ar->repErrSet.err.pres.pres = NOTPRSNT;
#else
            /* Set no error action reply */
            MG_CH_INIT_TOKEN_VALUE(&(ar->type), MGT_CXTCMDREPLY)
#endif   
            reply->pres.pres = PRSNT_NODEF;
            /* Context Update is present, check whether anything is present */
            /* this action                                                  */
            pCxtNode = txnRsp->userCntxtLst.first;
            for (ctxIdx = 0; ctxIdx < txnRsp->userCntxtLst.count;
                 ctxIdx++)
            {
               chCnxt = (MgMgcoChCntxtProp *) (pCxtNode->node);
               if (chCnxt->actionId == idx)
               {
                  /* Copy the topology descriptors if present  */
                  if (chCnxt->cxtProps.tl.num.pres != NOTPRSNT)
                  {
                     /* Context Update present for this action */
                     MG_CH_COPY_STRUCT(&(reply->cxt),(&(chCnxt->cxtProps)),
                        sizeof(MgMgcoContextProps))
 
                     MG_CH_GETMEM(reply->cxt.tl.descs,
                           (chCnxt->cxtProps.tl.num.val *
                            sizeof(MgMgcoTopoDesc*)),&(msg->memCp));

                     for (tlCnt = 0; tlCnt < chCnxt->cxtProps.tl.num.val;
                           tlCnt++)
                     {
                        MG_CH_GETMEM(reply->cxt.tl.descs[tlCnt],
                              sizeof(MgMgcoTopoDesc),&(msg->memCp));
                        MG_CH_COPY_STRUCT(reply->cxt.tl.descs[tlCnt],
                              chCnxt->cxtProps.tl.descs[tlCnt],
                              sizeof(MgMgcoTopoDesc))
                        /* Check if termId is other and pathname present for */
                        /* "to" and "from" */
                        /* From */
                        if((reply->cxt.tl.descs[tlCnt]->from.type.pres
                                   != NOTPRSNT) &&
                           (reply->cxt.tl.descs[tlCnt]->from.type.val
                                   == MGT_TERMID_OTHER))
                        {
                           if((reply->cxt.tl.descs[tlCnt]->from.name.pres.pres
                                    != NOTPRSNT) &&
                              (reply->cxt.tl.descs[tlCnt]->from.name.lcl.pres
                                    != NOTPRSNT))
                           {
                              /* Lcl */
                              MG_CH_GETMEM(
                                 reply->cxt.tl.descs[tlCnt]->from.name.lcl.val,
                                 reply->cxt.tl.descs[tlCnt]->from.name.lcl.len,
                                 &(msg->memCp));
                              MG_CH_COPY_STRUCT(
                                 reply->cxt.tl.descs[tlCnt]->from.name.lcl.val,
                                 chCnxt->cxtProps.tl.descs[tlCnt]->from.name.lcl.val,
                                 reply->cxt.tl.descs[tlCnt]->from.name.lcl.len)
                           }
                            if((reply->cxt.tl.descs[tlCnt]->from.name.pres.pres
                                       != NOTPRSNT) &&
                              (reply->cxt.tl.descs[tlCnt]->from.name.dom.pres
                                       != NOTPRSNT))
                           {
                              /* dom */
                              MG_CH_GETMEM(
                                 reply->cxt.tl.descs[tlCnt]->from.name.dom.val,
                                 reply->cxt.tl.descs[tlCnt]->from.name.dom.len,
                                 &(msg->memCp));
                              MG_CH_COPY_STRUCT(
                                 reply->cxt.tl.descs[tlCnt]->from.name.dom.val,
                                 chCnxt->cxtProps.tl.descs[tlCnt]->from.name.dom.val,
                                 reply->cxt.tl.descs[tlCnt]->from.name.dom.len)
                           }

                        }
                        /* To */
                        if((reply->cxt.tl.descs[tlCnt]->to.type.pres != NOTPRSNT)
                                          &&
                           (reply->cxt.tl.descs[tlCnt]->to.type.val
                                     == MGT_TERMID_OTHER))
                        {
                           if ((reply->cxt.tl.descs[tlCnt]->to.name.pres.pres
                                       != NOTPRSNT) &&
                               (reply->cxt.tl.descs[tlCnt]->to.name.lcl.pres
                                       != NOTPRSNT))
                           {
                              /* Lcl */
                              MG_CH_GETMEM(
                                 reply->cxt.tl.descs[tlCnt]->to.name.lcl.val,
                                 reply->cxt.tl.descs[tlCnt]->to.name.lcl.len,
                                 &(msg->memCp));
                              MG_CH_COPY_STRUCT(
                                 reply->cxt.tl.descs[tlCnt]->to.name.lcl.val,
                                 chCnxt->cxtProps.tl.descs[tlCnt]->to.name.lcl.val,
                                 reply->cxt.tl.descs[tlCnt]->to.name.lcl.len)
                           }
                            if ((reply->cxt.tl.descs[tlCnt]->to.name.pres.pres
                                        != NOTPRSNT) &&
                                (reply->cxt.tl.descs[tlCnt]->to.name.dom.pres
                                        != NOTPRSNT))
                           {
                              /* dom */
                              MG_CH_GETMEM(
                                 reply->cxt.tl.descs[tlCnt]->to.name.dom.val,
                                 reply->cxt.tl.descs[tlCnt]->to.name.dom.len,
                                 &(msg->memCp));
                              MG_CH_COPY_STRUCT(
                                 reply->cxt.tl.descs[tlCnt]->to.name.dom.val,
                                 chCnxt->cxtProps.tl.descs[tlCnt]->to.name.dom.val,
                                 reply->cxt.tl.descs[tlCnt]->to.name.dom.len)
                           }

                        }
                     } 
                  }
                     break;
               }
               pCxtNode = pCxtNode->next;
            } /* for ctxIdx */
         }
      }
      else
      {
         if (chAxnIndRsp->axnIndWildCardRsp[chAxnIndRsp->curWildActionId]->respLst.count == 0 && 
             chAxnIndRsp->axnIndWildCardRsp[chAxnIndRsp->curWildActionId]->type.val != CH_AXN_TYPE_ONLY_CNTXT)
         {
            replyIdx--;

            /* [UG]: For optional cmd handling - Overwrite the number for invalid actions */ 
            MG_CH_INIT_TOKEN_VALUE(&(tr->u.arl.num),(tr->u.arl.num.val-1));
            continue;
         }

         for (idxWild =0; idxWild < chAxnIndRsp->curWildActionId + 1;
               idxWild++,replyIdx++)
         {
            axnIndWildCardRsp = chAxnIndRsp->axnIndWildCardRsp[idxWild];
            MG_CH_GETMEM(tr->u.arl.repl[replyIdx],
                  sizeof(MgMgcoActnReply),&(msg->memCp));
            ar = tr->u.arl.repl[replyIdx];
            cmMemset((U8 *)(ar), 0, sizeof(MgMgcoActnReply));
            /* Fill present value  */
            ar->pres.pres = PRSNT_NODEF;
            /* chAxnIndRsp = (MgMgcoChAxnIndRsp *) txnRsp->axnIndRsp[idx]; */
            MG_CH_COPY_STRUCT(&(ar->cxtId), &(axnIndWildCardRsp->cntxtId), 
                  sizeof(MgMgcoContextId))

               /* Check whether commands are present */
            if ((axnIndWildCardRsp->type.val == CH_AXN_TYPE_BOTH) ||
                  (axnIndWildCardRsp->type.val == CH_AXN_TYPE_ONLY_CMDS)) 
            {
#ifdef MGT_GCP_VER_1_4
               reply = &(ar->repErrSet.reply);
#else
               reply = &(ar->u.reply);
#endif

               /* Allocate memory for command response */
               size = ((axnIndWildCardRsp->respLst.count) * (sizeof(MgMgcoCmdReply*)));

               /* Not required since it is a static array  */
               /* MG_CH_GETMEM((reply->cl.repl),size,&(msg->memCp) ); */

               pCmdNode = axnIndWildCardRsp->respLst.first;
#ifdef MGT_GCP_VER_1_4
               ar->repErrSet.pres.pres = PRSNT_NODEF;
               /* Set no error action reply */
               ar->repErrSet.err.pres.pres = NOTPRSNT;
#else
               /* Set no error action reply */
               MG_CH_INIT_TOKEN_VALUE(&(ar->type), MGT_CXTCMDREPLY)
#endif
                  reply->pres.pres = PRSNT_NODEF;
               /* [UG]: Check whether this particular action has commands */
               if (axnIndWildCardRsp->respLst.count != 0) 
                  MG_CH_INIT_TOKEN_VALUE(&(reply->cl.num), axnIndWildCardRsp->respLst.count)
               for (cmdIdx = 0; cmdIdx < axnIndWildCardRsp->respLst.count;
                     cmdIdx++)
               {
                  /* No need to allocate since we are using the MU command */
                  /* Copy the command structure from CH to Event structure */
                  chCmdRsp = (MgMgcoChCmdResp *) pCmdNode->node;

                  /* MG_CH_COPY_STRUCT((reply->cl.repl[cmdIdx]),  */
                  /* ((MgMgcoCmdReply *)&(chCmdRsp->cmdResp)),  */
                  /* sizeof(MgMgcoCmdReply)) */
                  reply->cl.repl[cmdIdx] = chCmdRsp->cmdResp;

                  pCmdNode = pCmdNode->next;
               }
            }

            /* Check whether context update is present  */
            if ((axnIndWildCardRsp->type.val == CH_AXN_TYPE_BOTH) ||
                  (axnIndWildCardRsp->type.val == CH_AXN_TYPE_ONLY_CNTXT)) 
            {
               /* [UG]: reply is not set, segmentation fault, so adding this code */
#ifdef MGT_GCP_VER_1_4
               reply = &(ar->repErrSet.reply);
#else
               reply = &(ar->u.reply);
#endif
               /* [UG]: Initialise these fields also */ 
#ifdef MGT_GCP_VER_1_4
               ar->repErrSet.pres.pres = PRSNT_NODEF;
               /* Set no error action reply */
               ar->repErrSet.err.pres.pres = NOTPRSNT;
#else
               /* Set no error action reply */
               MG_CH_INIT_TOKEN_VALUE(&(ar->type), MGT_CXTCMDREPLY)
#endif
                  reply->pres.pres = PRSNT_NODEF;
               /* Context Update is present, check whether anything is present */
               /* this action                                                  */
               pCxtNode = txnRsp->userCntxtLst.first;
               for (ctxIdx = 0; ctxIdx < txnRsp->userCntxtLst.count;
                     ctxIdx++)
               {
                  chCnxt = (MgMgcoChCntxtProp *) (pCxtNode->node);
                  if ((chCnxt->actionId == idx) && (chCnxt->wildActionId == idxWild))
                  {
                     /* Copy the topology descriptors if present  */
                     if (chCnxt->cxtProps.tl.num.pres != NOTPRSNT)
                     {
                        /* Context Update present for this action */
                        MG_CH_COPY_STRUCT(&(reply->cxt),(&(chCnxt->cxtProps)),
                              sizeof(MgMgcoContextProps))

                           MG_CH_GETMEM(reply->cxt.tl.descs,
                                 (chCnxt->cxtProps.tl.num.val *
                                  sizeof(MgMgcoTopoDesc*)),&(msg->memCp));

                        for (tlCnt = 0; tlCnt < chCnxt->cxtProps.tl.num.val;
                              tlCnt++)
                        {
                           MG_CH_GETMEM(reply->cxt.tl.descs[tlCnt],
                                 sizeof(MgMgcoTopoDesc),&(msg->memCp));
                           MG_CH_COPY_STRUCT(reply->cxt.tl.descs[tlCnt],
                                 chCnxt->cxtProps.tl.descs[tlCnt],
                                 sizeof(MgMgcoTopoDesc))
                              /* Check if termId is other and pathname present for */
                              /* "to" and "from" */
                              /* From */
                              if((reply->cxt.tl.descs[tlCnt]->from.type.pres
                                       != NOTPRSNT) &&
                                    (reply->cxt.tl.descs[tlCnt]->from.type.val
                                     == MGT_TERMID_OTHER))
                              {
                                 if((reply->cxt.tl.descs[tlCnt]->from.name.pres.pres
                                          != NOTPRSNT) &&
                                       (reply->cxt.tl.descs[tlCnt]->from.name.lcl.pres
                                        != NOTPRSNT))
                                 {
                                    /* Lcl */
                                    MG_CH_GETMEM(
                                          reply->cxt.tl.descs[tlCnt]->from.name.lcl.val,
                                          reply->cxt.tl.descs[tlCnt]->from.name.lcl.len,
                                          &(msg->memCp));
                                    MG_CH_COPY_STRUCT(
                                          reply->cxt.tl.descs[tlCnt]->from.name.lcl.val,
                                          chCnxt->cxtProps.tl.descs[tlCnt]->from.name.lcl.val,
                                          reply->cxt.tl.descs[tlCnt]->from.name.lcl.len)
                                 }
                                 if((reply->cxt.tl.descs[tlCnt]->from.name.pres.pres
                                          != NOTPRSNT) &&
                                       (reply->cxt.tl.descs[tlCnt]->from.name.dom.pres
                                        != NOTPRSNT))
                                 {
                                    /* dom */
                                    MG_CH_GETMEM(
                                          reply->cxt.tl.descs[tlCnt]->from.name.dom.val,
                                          reply->cxt.tl.descs[tlCnt]->from.name.dom.len,
                                          &(msg->memCp));
                                    MG_CH_COPY_STRUCT(
                                          reply->cxt.tl.descs[tlCnt]->from.name.dom.val,
                                          chCnxt->cxtProps.tl.descs[tlCnt]->from.name.dom.val,
                                          reply->cxt.tl.descs[tlCnt]->from.name.dom.len)
                                 }

                              }
                           /* To */
                           if((reply->cxt.tl.descs[tlCnt]->to.type.pres != NOTPRSNT)
                                 &&
                                 (reply->cxt.tl.descs[tlCnt]->to.type.val
                                  == MGT_TERMID_OTHER))
                           {
                              if ((reply->cxt.tl.descs[tlCnt]->to.name.pres.pres
                                       != NOTPRSNT) &&
                                    (reply->cxt.tl.descs[tlCnt]->to.name.lcl.pres
                                     != NOTPRSNT))
                              {
                                 /* Lcl */
                                 MG_CH_GETMEM(
                                       reply->cxt.tl.descs[tlCnt]->to.name.lcl.val,
                                       reply->cxt.tl.descs[tlCnt]->to.name.lcl.len,
                                       &(msg->memCp));
                                 MG_CH_COPY_STRUCT(
                                       reply->cxt.tl.descs[tlCnt]->to.name.lcl.val,
                                       chCnxt->cxtProps.tl.descs[tlCnt]->to.name.lcl.val,
                                       reply->cxt.tl.descs[tlCnt]->to.name.lcl.len)
                              }
                              if ((reply->cxt.tl.descs[tlCnt]->to.name.pres.pres
                                       != NOTPRSNT) &&
                                    (reply->cxt.tl.descs[tlCnt]->to.name.dom.pres
                                     != NOTPRSNT))
                              {
                                 /* dom */
                                 MG_CH_GETMEM(
                                       reply->cxt.tl.descs[tlCnt]->to.name.dom.val,
                                       reply->cxt.tl.descs[tlCnt]->to.name.dom.len,
                                       &(msg->memCp));
                                 MG_CH_COPY_STRUCT(
                                       reply->cxt.tl.descs[tlCnt]->to.name.dom.val,
                                       chCnxt->cxtProps.tl.descs[tlCnt]->to.name.dom.val,
                                       reply->cxt.tl.descs[tlCnt]->to.name.dom.len)
                              }

                           }
                        } 
                     }
                     break;
                  } 
                  pCxtNode = pCxtNode->next;
               } /* for ctxIdx */
            }
         }
      }
   } /* For ActionId */

      /* mg003.105:ChDelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
   /* del the mapping and send RT upd to standby/shadows */
   mgChDelMappingTxnIndRspAndChilds(txnRsp);
   /* zgDelMapping(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(txnRsp)); */
#ifdef ZG_CH_LVL_UPD
   zgRtUpd(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(txnRsp), CMPFTHA_UPDTYPE_SYNC,
           CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

   mgChCleanupTransIndRsp(&txnRsp);
 
   /* Free the memory allocated for the indication and response in CH */
   /* Structure  */
  /* Process Transaction */                                                    
   ret = mgPrcMgcoTxnReq(peer->ssap, msg, NULLP, MG_USER);    

 
#ifdef ZG
   /* Send update messages */
   zgUpdPeer();
#endif /* ZG */

   RETVALUE(ret);
} /* mgChComposeTransRsp */


/*
 *       Fun:  mgChComposeTransReq
 *
 *       Desc:  This CH function composes transaction request 
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PRIVATE S16 mgChComposeTransReq
(
MgMgcoChTransReq   *txnReq,        /* CH Transation Req  */
MgPeerCb           *peer           /* Peer Control Block */
)
#else
PRIVATE S16 mgChComposeTransReq (txnReq, peer)
MgMgcoChTransReq   *txnReq;        /* CH Transation Req  */
MgPeerCb           *peer;          /* Peer Control Block */
#endif 
{
   MgMgcoMsg          *msg;     
   U16                idx = 0;        /* Loop Index         */
   U16                cmdIdx = 0;     /* Loop Index         */
   U16                ctxIdx = 0;     /* Loop Index         */
   S16                ret = ROK;      /* return value       */
   MgMgcoTxnReq       *tr = NULLP;    /* Transaction Request*/
   MgMgcoActionReq    *ar = NULLP;    /* Action Request     */
   Size                  size;
   CmLList            *pNode     = NULLP;
   CmLList            *pCmdNode  = NULLP;
   CmLList            *pCxtNode  = NULLP;
   MgMgcoChAxnReq     *chAxnReq  = NULLP; /* CH Axn Request */
   MgMgcoChCmdReq     *chCmdReq  = NULLP; /* CH Cmd Request */
   MgMgcoChCntxtProp  *chCnxt    = NULLP; /* CH Context Prop*/
   MgMgcoCommandReq   *cmdReq    = NULLP; /* CH Command Req */
   U8                 *val;
   /* mg003.105: Bug fixes */
   CmMemListCp        *tmpMemCp  = NULLP; 
   U8                 method;         /* Service Change Method */

   TRC3(mgChComposeTransReq);
 
   if(ROK != mgAllocEventMem((Ptr *)&msg, sizeof(MgMgcoMsg)) )
   {
      RETVALUE(RFAILED);
   }

   /* Pres field in MgMgcoMsg in filled */
   msg->pres.pres = PRSNT_NODEF;
   msg->lcl.pres.pres = PRSNT_NODEF;
   msg->lcl.id.pres = PRSNT_NODEF;
   msg->lcl.id.val = peer->accessInfo.peerId;
   /* Copy mid from ssap*/
   MG_CH_GETMEM((val),peer->ssap->ssapCfg.userInfo.mid.len,&(msg->memCp));
   MG_CH_INIT_TKNSTROSXL(&(msg->mid),
                        val, peer->ssap->ssapCfg.userInfo.mid.len)
   cmMemcpy((U8*)(val),(U8*)(peer->ssap->ssapCfg.userInfo.mid.val),
                             peer->ssap->ssapCfg.userInfo.mid.len);

   /* cmMemcpy ((U8 *) &(msg->mid), (U8 *) &(peer->accessInfo.mid), */
              /* (peer->accessInfo.mid.len)); */
  
   /* Some acceptance functions are directly called need to check out */
   /* whether this is possible or to be worked for an alternative */
   /* Auth header is not filled */
   ret = mgChFillAuthHdr(FALSE,&(msg->ah),0,0,NULLP,0);

   /* Code Review Patch: Fill protocol version as negotiated version */
   ret = mgChFillVersion(TRUE,&(msg->ver), peer->mgcoInfo.negotiatedVersion);
  
    /* Fill Message body. Only 1 transaction reply present */
   MG_CH_INIT_TOKEN_VALUE(&(msg->body.type),MGT_TXN);
   /* Will be sending one transaction at a time */
   MG_CH_INIT_TOKEN_VALUE(&(msg->body.u.tl.num),1);
  
    /* Allocate memory based on transaction */
#ifndef GCP_VER_1_3
   size = ((msg->body.u.tl.num.val) * (sizeof(MgMgcoTxn*)));
   MG_CH_GETMEM((msg->body.u.tl.txns),size,&(msg->memCp) );
#endif /* GCP_VER_1_3 */
/* mg003.105: Bug fixes */
#ifdef GCP_VER_1_3
   MG_ALLOC_EVNT_MEM(msg->body.u.tl.txns[idx],
                        ret, sizeof(MgMgcoTxn));
   tmpMemCp = &(msg->body.u.tl.txns[idx]->memCp); 
#else
   MG_CH_GETMEM((msg->body.u.tl.txns[idx]),
                sizeof(MgMgcoTxn),&(msg->memCp));
   tmpMemCp = &(msg->memCp); 
#endif
   
   /* Handling only transaction request  */
   MG_CH_INIT_TOKEN_VALUE(&(msg->body.u.tl.txns[idx]->type),MGT_TXNREQ);
   tr = &(msg->body.u.tl.txns[idx]->u.req);
   tr->pres.pres = PRSNT_NODEF;
   /* Copy Transaction Id  */
   MG_CH_COPY_STRUCT(&(tr->transId), &(txnReq->transId), sizeof(MgMgcoTransId))
   /* Allocate memory based on actions */
   size = ((txnReq->curActionId +1) * (sizeof(MgMgcoActionReq*)));
   MG_CH_GETMEM((tr->al.actns),size,&(msg->memCp) );
   MG_CH_INIT_TOKEN_VALUE(&(tr->al.num),(txnReq->curActionId +1));
   /* pNode = txnReq->axnReqLst.first; */

   for (idx =0; idx < txnReq->curActionId +1;
                idx++)
   {
 
      /* No need to allocate for cmds pointer since it is a static array */
      MG_CH_GETMEM(tr->al.actns[idx],
                   sizeof(MgMgcoActionReq),&(msg->memCp));
          
      ar = tr->al.actns[idx];
      /* Fill present value  */
      ar->pres.pres = PRSNT_NODEF;

      /* Check whether commands are present */
      if ((txnReq->type.val == CH_AXN_TYPE_BOTH) ||
          (txnReq->type.val == CH_AXN_TYPE_ONLY_CMDS)) 
      {
          MgMgcoChAxnReq     *chTmpAxnReq  = NULLP; /* CH Axn Request */
          pNode = txnReq->axnReqLst.first;
          while (pNode != NULLP)
          {
              chTmpAxnReq = (MgMgcoChAxnReq *) pNode->node;
              if (chTmpAxnReq->actionId == idx)
                 break;
              pNode = pNode->next; 
          }
          if (pNode != NULLP)
          {
             chAxnReq = (MgMgcoChAxnReq *) pNode->node;
             MG_CH_COPY_STRUCT(&(ar->cxtId), &(chAxnReq->cntxtId), sizeof(MgMgcoContextId))
             /* Allocate memory for command requests */
             /* size = ((chAxnReq->cmdReqLst.count) * (sizeof(MgMgcoChCmdReq*))); */
             size = ((chAxnReq->cmdReqLst.count) * (sizeof(MgMgcoCommandReq *)));

             pCmdNode = chAxnReq->cmdReqLst.first;
             MG_CH_INIT_TOKEN_VALUE(&(ar->cl.num), chAxnReq->cmdReqLst.count)

             for (cmdIdx = 0; cmdIdx < chAxnReq->cmdReqLst.count;
                  cmdIdx++)
             {
                /* No need to allocate we are using MU's command */
                /* Copy the command structure from CH to Event structure */
                chCmdReq = (MgMgcoChCmdReq *)(pCmdNode->node);
                cmdReq = (chCmdReq->cmdReq);
 
                ar->cl.cmds[cmdIdx] = cmdReq; 
 
                pCmdNode = pCmdNode->next;
             }
          }
      }

      /* Check whether context update is present  */
      if ((txnReq->type.val == CH_AXN_TYPE_BOTH) ||
          (txnReq->type.val == CH_AXN_TYPE_ONLY_CNTXT))
      { 
         /* Context Update is present, check whether anything is present */
         /* this action                                                  */
         pCxtNode = txnReq->contextPropLst.first;
         for (ctxIdx = 0; ctxIdx < txnReq->contextPropLst.count;
              ctxIdx++)
         {
            chCnxt = (MgMgcoChCntxtProp *) (pCxtNode->node);
            if (chCnxt->actionId == idx)
            {
               /* Context Update present for this action */
             /*   MG_CH_COPY_STRUCT((&(ar->cxtProps)), (&(chCnxt->cxtProps)),
                                  sizeof(MgMgcoContextProps)) */
               /* 
                * Copy the CxtProps from TxnMemCp as derived when it was allocated 
                */	
               /* mg003.105: Bug fixes */

               mgUtlCpyMgMgcoContextProps((&(ar->cxtProps)), (&(chCnxt->cxtProps)), 
                                          tmpMemCp);
               MG_CH_COPY_STRUCT((&(ar->cxtAud)), (&(chCnxt->cxtAud)),
                                  sizeof(MgMgcoContextAudit))
               MG_CH_COPY_STRUCT(&(ar->cxtId), &(chCnxt->cxtId), 
                                 sizeof(MgMgcoContextId))
               break;
            } 
            pCxtNode = pCxtNode->next;
         } /* for ctxIdx */

      }
      /* pNode = pNode->next; */ 
   } /* For ActionId */
 
      /* mg003.105:ChDelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
   /* del the mapping and send RT upd to standby/shadows */
   mgChDelMappingTxnReqAndChilds(txnReq);
   /* zgDelMapping(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(txnReq)); */
#ifdef ZG_CH_LVL_UPD
   zgRtUpd(ZG_CBTYPE_CH_TXN_REQ, (Ptr)(txnReq), CMPFTHA_UPDTYPE_SYNC,
           CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

   /* Free the memory allocated for the request in CH Structure  */
   mgChCleanupTransReq(&txnReq, FALSE); 

   /* mg008.105: if message is service change message send msg version as 1 */
   /* chk if message is a service change request */
   
#ifdef GCP_MG
   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
      method = MGT_NONE;
      ret = mgVerifySvcChg(msg->body.u.tl.txns[0], &method);

      if ((ret == ROK) &&
          ((method == MGT_SVCCHGMETH_RESTART) ||
           (method == MGT_SVCCHGMETH_DISCON) ||
           (method == MGT_SVCCHGMETH_FAILOVER) ||
           (method == MGT_SVCCHGMETH_HANDOFF)))
      {
         if(msg->ver.pres == PRSNT_NODEF)
            msg->ver.val = 1;
      }
   } /* if MG */
#endif /* GCP_MG */

   /* Process Transaction */                                                    
   ret = mgPrcMgcoTxnReq(peer->ssap, msg, NULLP, MG_USER);    

 
#ifdef ZG
   /* Send update messages */
   zgUpdPeer();
#endif /* ZG */

   RETVALUE(ret);
   
} /* mgChComposeTransReq */


/*
 *       Fun:  mgChPrcMgcoTxnInd 
 *
 *       Desc:  This CH function processes the Transaction indication 
 *              message and calls approporiate CH command indication/
 *              confirmation for further processing.
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PRIVATE S16 mgChPrcMgcoTxnInd
(
MgMgcoMsg          *mgcoMsg,       /* Megaco Message     */
MgPeerCb           *peer,          /* Peer Control Block */
S16                *err            /* Error code to be filled if any */
)
#else
PRIVATE S16 mgChPrcMgcoTxnInd (mgcoMsg, peer, err)
MgMgcoMsg          *mgcoMsg;       /* Megaco Message     */
MgPeerCb           *peer;          /* Peer Control Block */
S16                *err;           /* Error code to be filled if any */
#endif 
{
   S16                loopIdx;        /* Loop Id for Txn                */
   MgMgcoTxn          *txn;           /* Megaco Transaction             */
   MgMgcoInd          ind;            /* Mgco Indication                */ 
   
 
   TRC3(mgChPrcMgcoTxnInd) 
 
   cmMemset ((U8 *)&ind, 0, sizeof(MgMgcoInd));
 
   /* Check for validity of the message */
   if ((mgcoMsg == NULLP) ||
       (mgcoMsg->pres.pres != PRSNT_NODEF) ||
       (mgcoMsg->body.type.pres != PRSNT_NODEF))
   {
      *err = MGT_CH_ERR_INV_MSG; 
      RETVALUE (RFAILED);
   }

   /* Check whether megaco message with error or transaction */
   if (mgcoMsg->body.type.val == MGT_TXN)
   {
      /* Handle Transaction */
      CH_CHK_NOTPRSNT(mgcoMsg->body.u.tl.num.pres, err, MGT_CH_ERR_TL_NUM_NOTPRSNT)  
      for (loopIdx = 0; loopIdx < mgcoMsg->body.u.tl.num.val; loopIdx++)
      {
         txn = mgcoMsg->body.u.tl.txns[loopIdx]; 
         CH_CHK_NOTPRSNT(txn->type.pres, err, MGT_CH_ERR_TXN_TYPE_NOTPRSNT)  
         switch (txn->type.val)
         {
            case MGT_TXNREQ:
               mgChPrcTxnInd (txn, peer, err); 
               break;
            case MGT_TXNREPLY:
               mgChPrcTxnCfm (txn, peer, err); 
               break;
            /* The following type should not be present */
            case MGT_TXNLOCAL_ERR:
               /* mgChPrcTxnlocErr (txn, peer, err);  */
               break;
            case MGT_TXNPEND:
               /* Fill MGT primitive error using the MgtInd
                * Primitive which is used by CH */
               CH_CP_IND_TRANSID(ind, txn->u.pend.transId)
               CH_SET_IND_TXN_PEND(ind)
               break;
 
            /* The following type need not be handled  */
            case MGT_TXNRSPACK:
               /* mgChPrcTxnRspAck (txn, peer, err);  */
               break;
         }/* swtich */
      }
   }
   else if (mgcoMsg->body.type.val == MGT_ERRDESC)
   {
      /* Handle Message error */
      /* Do nothing or to be defined */
     /* mgChPrcMsgError(txn, peer); */
   }
   else
   {
      /* Error with message body type */
      *err = MGT_CH_ERR_INV_MSG;
      RETVALUE (RFAILED);
   }

   *err = MGT_CH_ERR_NONE;
   /* [UG]: Adding for freeing memory  - txn & msg*/
   CH_FREE_MGCOMSG_WITH_TXN(mgcoMsg)
   RETVALUE(RFAILED);
 
} /* mgChPrcMgcoTxnInd */


/*
 *       Fun:  mgChPrcMgcoTxnCfm 
 *
 *       Desc:  This CH function processes the Transaction reply from 
 *              the peer.
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PUBLIC S16 mgChPrcTxnCfm 
(
MgMgcoTxn          *txnInd,       /* Megaco Message     */
MgPeerCb           *peer,         /* Peer Control Block */
S16                *err           /* error code         */
)
#else
PUBLIC S16 mgChPrcTxnCfm (txnInd, peer, err)
MgMgcoTxn          *txnInd;        /* Megaco Message     */
MgPeerCb           *peer;          /* Peer Control Block */
S16                *err;           /* error code         */
#endif 
{
   MgMgcoTxnReply      *reply = &(txnInd->u.reply);/* Transaction reply    */
   MgMgcoCommand         chCmd;                      /* CH Command Primitive */ 
   MgMgcoUpdateCntxt cntxtUpd;                   /* Context Update Prim  */ 
   S16                 cmdLoopIdx;                 /* Command Loop Index   */
   S16                 axnLoopIdx;                 /* Action  Loop Index   */
   MgMgcoActnReply     *axnReply;                  /* Action Reply         */  
   MgMgcoCmdReply      *cmdReply;                  /* Command Reoly        */
   MgMgcoInd    chInd;                      /* CH Indication        */
   MgMgcoCxtCmdReply    *cmdRepl;           /* Context reply + cmd replies */
   MgMgcoErrDesc        *errDesc;           /* Error Descriptor            */
   U8                   *val;
   S16                   ret;
  
   TRC2(mgChPrcTxnCfm);    
   
   CH_CHK_NOTPRSNT(reply->pres.pres, err, MGT_CH_ERR_INV_MSG)
   CH_CHK_NOTPRSNT(reply->type.pres, err, MGT_CH_ERR_INV_MSG)
 
   cmMemset((U8 *)&chCmd, 0, sizeof(chCmd));
   cmMemset((U8 *)&cntxtUpd, 0, sizeof(cntxtUpd));
   cmMemset((U8 *)&chInd, 0, sizeof(MgMgcoInd));
    
   /* Copy the transaction Id  to the Cmd primitive */
   /* Copy the transaction Id  */
   CH_CP_TRANSID(chCmd, reply->transId)
   MG_CH_INIT_TOKEN_VALUE(&(chCmd.peerId), peer->accessInfo.peerId)
   CH_CP_CMDTYPE(chCmd, CH_CMD_TYPE_CFM)
 
 
   switch (reply->type.val)
   {
      case MGT_ERRDESC:
         /* Handle txn reply error */
         CH_CP_IND_TRANSID(chInd,reply->transId) 
         CH_CP_IND_ERRDESC(chInd,reply->u.err) 
         if (reply->u.err.text.pres != NOTPRSNT)
         {
            /* Error String present, allocate memory for the error string */
            /* from memcp */
            MG_ALLOC_EVNT_MEM(chInd,ret,sizeof(MgMgcoInd));
            MG_CH_GETMEM((val),reply->u.err.text.len,&(chInd.memCp));
            MG_CH_INIT_TKNSTROSXL(&(chInd.err.text), 
                  val, chInd.err.text.len)
            cmMemcpy((U8*)(val),(U8*)(chInd.err.text.val),chInd.err.text.len);
         }
         /* Send Transaction Reply Error */
         mgChSendPrim ((Ptr)&chInd, peer, err, CH_PRIM_TYPE_IND);
         break;
    
     case MGT_ACTIONREPLY:
        /* Handle Action reply */
        CH_CHK_NOTPRSNT (reply->u.arl.num.pres, err, MGT_CH_ERR_INV_MSG)

        for (axnLoopIdx =0; axnLoopIdx < reply->u.arl.num.val; axnLoopIdx++)
        {
           axnReply =  reply->u.arl.repl[axnLoopIdx];
           CH_CHK_NOTPRSNT(axnReply->pres.pres, err, MGT_CH_ERR_INV_MSG)
           CH_CP_CONTEXTID(chCmd, axnReply->cxtId)
 
#ifdef MGT_GCP_VER_1_4
            errDesc = &(axnReply->repErrSet.err); 
            cmdRepl = &(axnReply->repErrSet.reply);
#else
            /* Should we need to check error on type */
            errDesc = &(axnReply->u.err); 
            cmdRepl = &(axnReply->u.reply);
#endif
#ifdef MGT_GCP_VER_1_4
           CH_CHK_NOTPRSNT(axnReply->repErrSet.pres.pres, err, MGT_CH_ERR_INV_MSG)
           if (errDesc->pres.pres != NOTPRSNT) 
#else
           if((axnReply->type.pres == PRSNT_NODEF) && 
             (axnReply->type.val == MGT_ERRDESC)) 
#endif
           {
              /* Process Axn Reply, Send Axn Reply with error */
              /* Handle txn reply error */
              CH_CP_IND_TRANSID(chInd,reply->transId) 
              MG_CH_INIT_TOKEN_VALUE(&chInd.peerId, peer->accessInfo.peerId)
              CH_CP_IND_CNTXTID(chInd,axnReply->cxtId)
              /* [UG]: This macro will not work here since we are passing the pointer */
              /* CH_CP_IND_ERRDESC(chInd,errDesc)  */
              cmMemcpy ((U8 *) &(chInd.err), (U8 *)errDesc, sizeof(MgMgcoErrDesc)); 
              if (errDesc->text.pres != NOTPRSNT)
              {
                 /* Error String present, allocate memory for
                  * the error string from memcp */
                 MG_ALLOC_EVNT_MEM(chInd,ret,sizeof(MgMgcoInd))
                 MG_CH_GETMEM((val),errDesc->text.len,&(chInd.memCp));
                 MG_CH_INIT_TKNSTROSXL(&(chInd.err.text), 
                       val, chInd.err.text.len)
                 cmMemcpy((U8*)(val),(U8*)(chInd.err.text.val),
                          chInd.err.text.len);
              }

              /* Send Transaction Reply Error */
              mgChSendPrim((Ptr)&chInd, peer, err, CH_PRIM_TYPE_IND);
              break;
           }

           if (cmdRepl->pres.pres != NOTPRSNT)
           {
             /* Axn Replies */
             if (cmdRepl->cxt.pres.pres != NOTPRSNT)
             {
                /* mg008.105: ContextUpdate has seperate memory Control point */
                MG_ALLOC_EVNT_MEM(cntxtUpd,ret,sizeof(MgMgcoUpdateCntxt))
                 
                /* Context Prop present, Process Cntxt Update        */
                /* If no cmd replies and no other commands send this */
                /* with END_OF_TXN, if some more actions END_OF_AXN  */
                CH_CP_CNTXTUPD_TRANSID(cntxtUpd, reply->transId)
                CH_CP_CNTXTUPD_CONTEXTID(cntxtUpd, axnReply->cxtId)
                MG_CH_INIT_TOKEN_VALUE(&cntxtUpd.peerId,
                                       peer->accessInfo.peerId)
                /* Check any command replies */
                if (cmdRepl->cl.num.pres == NOTPRSNT) 
                   /* No command reply list for this action */
                   if (axnLoopIdx == reply->u.arl.num.val -1 )
                      /* No actions pending, only cntxt update */
                      CH_SET_CNTXTUPD_CMDSTATUS(cntxtUpd, 
                                                CH_CMD_STATUS_END_OF_TXN)
                   else
                      /* no commands pending, but some more axns */
                      CH_SET_CNTXTUPD_CMDSTATUS(cntxtUpd,
                                                CH_CMD_STATUS_END_OF_AXN)
                else
                     /* commands pending */
                   CH_SET_CNTXTUPD_CMDSTATUS(cntxtUpd, CH_CMD_STATUS_PENDING)
                /* Since this function is only for processing txn */
                /* confirmation, audit desc is not expected */
                cntxtUpd.contextProp.pres.pres = PRSNT_NODEF;
                if (mgUtlCpyMgMgcoContextProps(&(cntxtUpd.contextProp.cxtProps),
                                               &(cmdRepl->cxt), 
                                               &(cntxtUpd.memCp)) != ROK)
                {
                   mgFreeEventMem((Ptr)&cntxtUpd);
                   RETVALUE(RFAILED);
                }
 
                /* Send Context Update */
                mgChSendPrim((Ptr)&cntxtUpd, peer, err,
                             CH_PRIM_TYPE_UPD_CNTXT);
             }
             if (cmdRepl->cl.num.pres != NOTPRSNT)
             {
                /* Process Cmd Replies */
                CH_CHK_NOTPRSNT(cmdRepl->cl.num.pres, \
                                err, MGT_CH_ERR_INV_MSG)
                for (cmdLoopIdx = 0; 
                     cmdLoopIdx <(cmdRepl->cl.num.val);
                     cmdLoopIdx++)
                {
                   cmdReply = cmdRepl->cl.repl[cmdLoopIdx];
                   CH_CP_CFMCMDREPLY(chCmd, cmdReply)
                   if (cmdLoopIdx == (cmdRepl->cl.num.val) - 1)
                      if (axnLoopIdx ==  reply->u.arl.num.val - 1)  
                         /* Last Command in this TXN */
                         CH_SET_CMDSTATUS(chCmd, CH_CMD_STATUS_END_OF_TXN)
                      else
                         /* Last Command in this AXN */
                         CH_SET_CMDSTATUS(chCmd, CH_CMD_STATUS_END_OF_AXN)
                   else
                      /* Commands Pending */
                      CH_SET_CMDSTATUS(chCmd, CH_CMD_STATUS_PENDING)
                   /* Send Command Confirm primitive Primitive */
                   mgChSendPrim ((Ptr)&chCmd, peer, err, CH_PRIM_TYPE_CMD);      
                }
             }
           }
        } /* for axn */
        break;
      default:
         *err = MGT_CH_ERR_INV_MSG;
         RETVALUE(RFAILED);
         break;  
   } /* swtich */

   *err = MGT_CH_ERR_NONE;
   RETVALUE(ROK);
} /* mgChPrcTxnCfm */ 
 

/*       Fun:  mgChSendPrim
 *
 *       Desc:  This CH function send the CH primitive to the service  
 *              by calling appropriate functions.
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PUBLIC S16 mgChSendPrim
(
Ptr                ptr,           /* CH primitive struct*/
MgPeerCb           *peer,         /* Peer Control Block */
S16                *err,          /* error code         */
U8                 primType       /* Primitive type     */
)
#else
PUBLIC S16 mgChSendPrim(ptr, peer, err, primType)
Ptr                ptr;           /* CH primitive struct*/
MgPeerCb           *peer;         /* Peer Control Block */
S16                *err;          /* error code         */
U8                 primType;      /* Primitive type     */
#endif 
{
   MgMgcoCommand      *mgCmd;        /* megaco command      */
   MgMgcoUpdateCntxt  *mgCntxt;      /* Context Update      */
   MgMgcoUpdateCntxt  *mgTmpCntxt;   /* Context Update      */
   MgMgcoInd          *mgInd;        /* CH Indication       */
   MgMgcoInd          *mgTmpInd;     /* CH Indication       */
    /* mg007.105: sel is useless */
   S16                ret;           /* return value        */
   U16                tlCnt;        
   CmMemListCp       tmpCp;
 
   TRC3(mgChSendPrim)
   
    /* mg007.105: sel is useless */

   switch(primType)
   {
      case CH_PRIM_TYPE_CMD:
         mgCmd = (MgMgcoCommand *) ptr;

    /* mg007.105: calling MgUiMgtMgcoCmdInd instead of mgUiMgtMgcoCmdxxxMt */
         ret = MgUiMgtMgcoCmdInd(&(peer->ssap->suPst), peer->ssap->suId, mgCmd);

         break;
 
      case CH_PRIM_TYPE_UPD_CNTXT:
         mgTmpCntxt = (MgMgcoUpdateCntxt *) ptr;
 
         MG_ALLOC_EVNT_MEM(mgCntxt,ret,sizeof(MgMgcoUpdateCntxt));
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
         /* Retain the memcp values  */
         MG_CH_COPY_STRUCT(&tmpCp,&mgCntxt->memCp,sizeof(CmMemListCp))
         /* This overwrites the value of memCp hence taking a copy of it  */
         MG_CH_COPY_STRUCT(mgCntxt,mgTmpCntxt,sizeof(MgMgcoUpdateCntxt))
 
         MG_CH_COPY_STRUCT(&mgCntxt->memCp,&tmpCp,sizeof(CmMemListCp))

         /* Copy the topology descriptors if present  */
         if (mgTmpCntxt->contextProp.cxtProps.tl.num.pres != NOTPRSNT)
         {
            MG_CH_GETMEM(mgCntxt->contextProp.cxtProps.tl.descs,
                  (mgTmpCntxt->contextProp.cxtProps.tl.num.val *
                  sizeof(MgMgcoTopoDesc*)),&mgCntxt->memCp);

            for (tlCnt = 0; tlCnt < mgCntxt->contextProp.cxtProps.tl.num.val;
                 tlCnt++)
            {
               MG_CH_GETMEM(mgCntxt->contextProp.cxtProps.tl.descs[tlCnt],
                     sizeof(MgMgcoTopoDesc),&mgCntxt->memCp);
               MG_CH_COPY_STRUCT(mgCntxt->contextProp.cxtProps.tl.descs[tlCnt],
                     mgTmpCntxt->contextProp.cxtProps.tl.descs[tlCnt],
                     sizeof(MgMgcoTopoDesc))
            } 
         }

    /* mg007.105: calling MgUiMgtMgcoUpdCtxtInd instead of mgUiMgtMgcoUpdCtxtIndMt */
         ret = MgUiMgtMgcoUpdCtxtInd(&(peer->ssap->suPst), peer->ssap->suId, mgCntxt);
 
         break;
      case CH_PRIM_TYPE_IND:
         mgTmpInd = (MgMgcoInd *)ptr;
 
         MG_ALLOC_EVNT_MEM(mgInd ,ret,sizeof(MgMgcoInd));
 
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
 
         /* Retain the memcp values  */
         MG_CH_COPY_STRUCT(&tmpCp,&mgInd->memCp,sizeof(CmMemListCp))
         /* Allocate for event structure and send */
         MG_CH_COPY_STRUCT(mgInd,mgTmpInd,sizeof(MgMgcoInd));
 
         MG_CH_COPY_STRUCT(&mgInd->memCp,&tmpCp,sizeof(CmMemListCp))
 
    /* mg007.105: calling MgUiMgtMgcoTxnStaInd instead of mgUiMgtMgcoTxnStaIndMt */
         ret = MgUiMgtMgcoTxnStaInd(&(peer->ssap->suPst), peer->ssap->suId, mgInd);
 
         break;
      default:
         RETVALUE(RFAILED);

   } /* switch */

   RETVALUE(ret);

} /* mgChSendPrim */


/*       Fun:  mgChPrcMgcoTxnInd 
 *
 *       Desc:  This CH function processes the Transaction request from
 *              the peer.              
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PUBLIC S16 mgChPrcTxnInd 
(
MgMgcoTxn          *txnInd,        /* Megaco Message     */
MgPeerCb           *peer,          /* Peer Control Block */
S16                *err            /* error code         */
)
#else
PUBLIC S16 mgChPrcTxnInd (txnInd, peer, err)
MgMgcoTxn          *txnInd;        /* Megaco Message     */
MgPeerCb           *peer;          /* Peer Control Block */
S16                *err;           /* error code         */
#endif 
{
   MgMgcoTxnReq        *req   = &(txnInd->u.req);  /* Transaction req      */
   MgMgcoChCb          *chCb = &(mgCb.chCb);    /* CH Control BLock      */
   MgMgcoCommand         chCmd;                      /* CH Command Primitive */ 
   MgMgcoUpdateCntxt cntxtUpd;                   /* Context Update Prim  */ 
   MgMgcoChPeerCmdCtl  *peerCmdCtl = NULLP;        /* Peer Command Control */
   S16                 cmdLoopIdx;                 /* Command Loop Index   */
   S16                 axnLoopIdx;                 /* Action  Loop Index   */
   S16                 ctxLoopIdx;                 /* context  Loop Index  */
   MgMgcoActionReq     *axnReq;                    /* Action Req           */  
   MgMgcoCommandReq    *cmdInd=NULLP;              /* Command Indication   */
   MgMgcoCommandReq    **ppCmdInd=NULLP;           /* Pointer Command Ind  */
   MgMgcoChTransIndRsp *trIndRsp = NULLP;          /* CH Trans IndRsp      */
   Bool                 peerCmdCtlAlloc=FALSE;     /* Peer Cmt Alloc Flag  */ 
   Bool                 cmdIndRspAlloc1 = FALSE;   /* Cmnd IndRsp AllocFlag*/ 
   Bool                 axnIndRspAlloc2 = FALSE;   /* Axn  IndRsp AllocFlag*/ 
   MgMgcoTransId        transId;                   /* Transaction Id       */
   MgMgcoChAxnIndRsp    *axnIndRsp = NULLP;        /* Action Ind Rsp       */
   MgMgcoChAxnIndRsp    **ppAxnIndRsp = NULLP;     /* Pointer Action IndRsp*/
   MgMgcoChCntxtProp    *chCntxt = NULLP;          /* CH Context Info      */
   U32                  numOfIndRspAxns;           /* No of actions        */  
   U16                  idx;                       /* Index                */
   CmLList              *pNode;                    /* List Node            */
   MgMgcoTermId         termId;                    /* Termination Id       */
   U16                  toFreeCnt;
 
 
   TRC2 (mgChPrcTxnInd);    
   
   CH_CHK_NOTPRSNT(req->pres.pres, err, MGT_CH_ERR_INV_MSG)                       
 
   cmMemset((U8 *)&chCmd, 0, sizeof (chCmd));
   cmMemset((U8 *)&cntxtUpd, 0, sizeof (cntxtUpd));
   cmMemset((U8 *)&termId, 0, sizeof (MgMgcoTermId));
  
   MG_CH_COPY_STRUCT(&transId, &(req->transId), sizeof (MgMgcoTransId))

   /* Check if the peerId is present in PeerCmd Ctl */
   if ((cmHashListFind(&(chCb->peerCmdCtlLst), (U8 *)&peer->accessInfo.peerId, 
                         MG_CH_PEERID_LEN, MG_HASH_SEQNMB_DEF, 
                         (PTR *)&peerCmdCtl)) != ROK) 
   {
      /* Node not found, may be this is the first command request comming  */
      /* for the peer,Create an entry for the peer */

      if (RFAILED == mgChAllocatePeerCb(peer->accessInfo.peerId, &peerCmdCtl))
      {
         mgChHandleMgcoPrcTxnIndErr(peer->ssap, txnInd,
                                    MGT_ERR_RSRC_UNAVAIL, MG_USER);
         RETVALUE(RFAILED);
      }

      peerCmdCtlAlloc = TRUE;

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
      /* add the mapping and send RT upd to standby/shadows */
      ZG_INIT_RSETID_IN_MAPCB(&((peerCmdCtl)->mapCb));
      zgAddMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
      zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */


   } /* Peer Not present */
   else if ((cmHashListFind(&(peerCmdCtl->transIndRspLst), (U8 *)&transId.val, 
                         MG_TRANSID_LEN, MG_HASH_SEQNMB_DEF, 
                         (PTR *)&trIndRsp)) == ROK) 
   /* Peer present */
   {
      /* Error TransId already present */
      RETVALUE(RFAILED);
   }



   /* Fill the num of actions  */
   if (req->al.num.pres == PRSNT_NODEF)
   {
      numOfIndRspAxns = req->al.num.val;
   }
   else
   {
      mgChHandleMgcoPrcTxnIndErr(peer->ssap, txnInd,
                                 MGT_ERR_RSRC_UNAVAIL, MG_USER);
      if (peerCmdCtlAlloc == TRUE)
      {
          /* generate RT upd for deleting the peer */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
          zgDelMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
          zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_DEL);
          /* Send update messages */
          zgUpdPeer();
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

          /* Delete the block from the list */
          cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR)peerCmdCtl); 

          mgDeAlloc((Data *) peerCmdCtl, sizeof(peerCmdCtl));
      }
      RETVALUE(RFAILED);
   }   

   /* Create a Trans Ind Rsp Node */
   if (RFAILED == mgChAllocateTxnIndRspCb(peerCmdCtl, transId, &trIndRsp,
                                          req->al.num.val))
   {
       mgChHandleMgcoPrcTxnIndErr(peer->ssap, txnInd,
                                  MGT_ERR_RSRC_UNAVAIL, MG_USER);
       if (peerCmdCtlAlloc == TRUE)
       {
           /* generate RT upd for deleting the peer */

      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
           zgDelMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
           zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
                   CMPFTHA_ACTN_DEL);
           /* Send update messages */
           zgUpdPeer();
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

           /* Delete the block from the list */
           cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR)peerCmdCtl); 

           mgDeAlloc((Data *) peerCmdCtl, sizeof(peerCmdCtl));
       }

       RETVALUE(RFAILED);
   }

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
   /* add the mapping and send RT upd to standby/shadows */
   ZG_INIT_RSETID_IN_MAPCB(&((trIndRsp)->mapCb));
   zgAddMapping(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(trIndRsp));
#ifdef ZG_CH_LVL_UPD
   zgRtUpd(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(trIndRsp), CMPFTHA_UPDTYPE_SYNC,
           CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */


   ppAxnIndRsp = trIndRsp->axnIndRsp;

   for (axnLoopIdx = 0; axnLoopIdx < (S16)numOfIndRspAxns;
                        axnLoopIdx++)
   {
      U8                axnType = CH_AXN_TYPE_NONE;
      U8                txnType = CH_AXN_TYPE_NONE;

      cmdIndRspAlloc1 = axnIndRspAlloc2 = FALSE;


      axnReq = req->al.actns[axnLoopIdx];

      if (axnReq->pres.pres != PRSNT_NODEF)
      {
         goto ALLOC_ERR;
      }

      /* Check for the command req and context info presence and update the */
      /* type in transindrsp accordingly */
      if ( (axnReq->cl.num.pres == PRSNT_NODEF) &&
          ((axnReq->cxtProps.pres.pres == PRSNT_NODEF) ||
           (axnReq->cxtAud.pres.pres == PRSNT_NODEF))) 
      {
         /* Update the type in Trans Ind Rsp node */
         txnType =  CH_AXN_TYPE_BOTH;

         /* Update the type in the AxnIndRsp Node */
         axnType =  CH_AXN_TYPE_BOTH;
      }
      else if (axnReq->cl.num.pres == PRSNT_NODEF) 
      {
         /* Update the type in the AxnIndRsp Node */
         axnType = CH_AXN_TYPE_ONLY_CMDS;

         /* Update the type in Trans Ind Rsp node */
         if((trIndRsp->type.val == CH_AXN_TYPE_ONLY_CNTXT)||
               (trIndRsp->type.val == CH_AXN_TYPE_BOTH))
            txnType = CH_AXN_TYPE_BOTH;
         else if((trIndRsp->type.val == CH_AXN_TYPE_NONE) ||
               (trIndRsp->type.val == CH_AXN_TYPE_ONLY_CMDS))
            txnType = CH_AXN_TYPE_ONLY_CMDS;
      }
      else if ((axnReq->cxtProps.pres.pres == PRSNT_NODEF) ||
            (axnReq->cxtAud.pres.pres == PRSNT_NODEF))
      {
         /* Update the type in the AxnIndRsp Node */
         axnType = CH_AXN_TYPE_ONLY_CNTXT;

         /* Update the type in Trans Ind Rsp node */
         if ((trIndRsp->type.val == CH_AXN_TYPE_ONLY_CMDS) ||
               (trIndRsp->type.val == CH_AXN_TYPE_BOTH))
            txnType = CH_AXN_TYPE_BOTH;
         else if((trIndRsp->type.val == CH_AXN_TYPE_NONE) ||
               (trIndRsp->type.val == CH_AXN_TYPE_ONLY_CNTXT))
            txnType = CH_AXN_TYPE_ONLY_CNTXT;
      }
      else
      {
         goto ALLOC_ERR;
      }   
   


      if (RFAILED == mgChAllocateAxnIndRspCb(trIndRsp, &axnIndRsp,
                                             axnReq->cxtId, axnType,
                                             txnType, axnLoopIdx,
                                             axnReq->cl.num.val))
      {
         goto ALLOC_ERR;
      }   

      /* the following var indicates that axnIndRsp has been allocated
       * in the above func */
      axnIndRspAlloc2 = TRUE; 

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
      /* add the mapping and send RT upd to standby/shadows */
      ZG_INIT_RSETID_IN_MAPCB(&((axnIndRsp)->mapCb));
      zgAddMapping(ZG_CBTYPE_CH_AXN_INDRSP, (Ptr)(axnIndRsp));
#ifdef ZG_CH_LVL_UPD
      zgRtUpd(ZG_CBTYPE_CH_AXN_INDRSP, (Ptr)(axnIndRsp), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */



      /* Initialise context List if context prop or audit present    */
      if ((axnIndRsp->type.val == CH_AXN_TYPE_ONLY_CNTXT) ||
          (axnIndRsp->type.val == CH_AXN_TYPE_BOTH))
      {
          if (RFAILED == mgChAllocateCntxtReqCb(MG_CH_TXN_INDRSP_PEER, trIndRsp,
                                                NULLP, axnLoopIdx,
                                                axnReq->cxtId, &chCntxt,
                                                &(axnReq->cxtProps),
                                                &(axnReq->cxtAud)))
          {
              goto ALLOC_ERR;
          }

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
          /* add the mapping and send RT upd to standby/shadows */
          ZG_INIT_RSETID_IN_MAPCB(&((chCntxt)->mapCb));
          zgAddMapping(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCntxt));
#ifdef ZG_CH_LVL_UPD
          zgRtUpd(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCntxt), CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

      }

      /* Check for the command requests       */
      if ((axnIndRsp->type.val == CH_AXN_TYPE_ONLY_CMDS) ||
          (axnIndRsp->type.val == CH_AXN_TYPE_BOTH))
      {
          /* Command requests present */
          cmdIndRspAlloc1 = TRUE;
 
          /* Process Commands in commands List */
          for (cmdLoopIdx = 0; cmdLoopIdx < axnReq->cl.num.val;
               cmdLoopIdx++)
          {
             cmMemset((U8 *)&termId, 0, sizeof(MgMgcoTermId));
             cmdInd = axnReq->cl.cmds[cmdLoopIdx];

             switch(cmdInd->cmd.type.val)
             {
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                U16   ix, nmbr;
#endif /* GCP_VER_1_5 && GCP_ASN */

                case MGT_MODIFY:               
                      MG_CH_COPY_STRUCT(
                            &(termId),
                            &(cmdInd->cmd.u.mod.termId),
                            sizeof(MgMgcoTermId))
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                      if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
                      {   
                        /* copy the wildcard contents also */
                        nmbr = cmdInd->cmd.u.mod.termId.wildcard.num.val;
                        if(nmbr > 0)
                        {   
                           MG_CH_GETMEM((termId.wildcard.wildcard),
                                      nmbr * sizeof(MgMgcoWildcardField *),
                                      &(cmdInd->memCp));
                           for (ix=0; ix < nmbr; ++ix)
                           {
                              MG_CH_GETMEM((termId.wildcard.wildcard[ix]),
                                        sizeof(MgMgcoWildcardField),
                                        &(cmdInd->memCp));
                              MG_CH_COPY_STRUCT((termId.wildcard.wildcard[ix]),
                                             (cmdInd->cmd.u.mod.termId.\
                                                wildcard.wildcard[ix]),
                                             sizeof(MgMgcoWildcardField))
                           }
                        }  
                      }   
#endif /* GCP_VER_1_5 && GCP_ASN */
                    break;
                case MGT_MOVE:                 
                      MG_CH_COPY_STRUCT(
                            &(termId),
                            &(cmdInd->cmd.u.move.termId),
                            sizeof(MgMgcoTermId))
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                      if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
                      {   
                        /* copy the wildcard contents also */
                        nmbr = cmdInd->cmd.u.move.termId.wildcard.num.val;
                        if(nmbr > 0)
                        {   
                           MG_CH_GETMEM((termId.wildcard.wildcard),
                                      nmbr * sizeof(MgMgcoWildcardField *),
                                      &(cmdInd->memCp));
                           for (ix=0; ix < nmbr; ++ix)
                           {
                              MG_CH_GETMEM((termId.wildcard.wildcard[ix]),
                                        sizeof(MgMgcoWildcardField),
                                        &(cmdInd->memCp));
                              MG_CH_COPY_STRUCT((termId.wildcard.wildcard[ix]),
                                             (cmdInd->cmd.u.move.termId.\
                                                wildcard.wildcard[ix]),
                                             sizeof(MgMgcoWildcardField))
                           }
                        }  
                      }   
#endif /* GCP_VER_1_5 && GCP_ASN */
                    break;
                case MGT_ADD:
                      MG_CH_COPY_STRUCT(
                            &(termId),
                            &(cmdInd->cmd.u.add.termId),
                            sizeof(MgMgcoTermId))
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                      if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
                      {   
                        /* copy the wildcard contents also */
                        nmbr = cmdInd->cmd.u.add.termId.wildcard.num.val;
                        if(nmbr > 0)
                        {   
                           MG_CH_GETMEM((termId.wildcard.wildcard),
                                      nmbr * sizeof(MgMgcoWildcardField *),
                                      &(cmdInd->memCp));
                           for (ix=0; ix < nmbr; ++ix)
                           {
                              MG_CH_GETMEM((termId.wildcard.wildcard[ix]),
                                        sizeof(MgMgcoWildcardField),
                                        &(cmdInd->memCp));
                              MG_CH_COPY_STRUCT((termId.wildcard.wildcard[ix]),
                                             (cmdInd->cmd.u.add.termId.\
                                                wildcard.wildcard[ix]),
                                             sizeof(MgMgcoWildcardField))
                           }
                        }  
                      }   
#endif /* GCP_VER_1_5 && GCP_ASN */
                   break; 
                case MGT_SUB:                  
                      MG_CH_COPY_STRUCT(
                         &(termId),
                         &(cmdInd->cmd.u.sub.termId),
                         sizeof(MgMgcoTermId))
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                      if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
                      {   
                        /* copy the wildcard contents also */
                        nmbr = cmdInd->cmd.u.sub.termId.wildcard.num.val;
                        if(nmbr > 0)
                        {   
                           MG_CH_GETMEM((termId.wildcard.wildcard),
                                      nmbr * sizeof(MgMgcoWildcardField *),
                                      &(cmdInd->memCp));
                           for (ix=0; ix < nmbr; ++ix)
                           {
                              MG_CH_GETMEM((termId.wildcard.wildcard[ix]),
                                        sizeof(MgMgcoWildcardField),
                                        &(cmdInd->memCp));
                              MG_CH_COPY_STRUCT((termId.wildcard.wildcard[ix]),
                                             (cmdInd->cmd.u.sub.termId.\
                                                wildcard.wildcard[ix]),
                                             sizeof(MgMgcoWildcardField))
                           }
                        }  
                      }   
#endif /* GCP_VER_1_5 && GCP_ASN */
                   break;
 
                case MGT_SVCCHG:               
                      MG_CH_COPY_STRUCT(
                            &(termId),
                            &(cmdInd->cmd.u.svc.termId),
                            sizeof(MgMgcoTermId))
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                      if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
                      {   
                        /* copy the wildcard contents also */
                        nmbr = cmdInd->cmd.u.svc.termId.wildcard.num.val;
                        if(nmbr > 0)
                        {   
                           MG_CH_GETMEM((termId.wildcard.wildcard),
                                      nmbr * sizeof(MgMgcoWildcardField *),
                                      &(cmdInd->memCp));
                           for (ix=0; ix < nmbr; ++ix)
                           {
                              MG_CH_GETMEM((termId.wildcard.wildcard[ix]),
                                        sizeof(MgMgcoWildcardField),
                                        &(cmdInd->memCp));
                              MG_CH_COPY_STRUCT((termId.wildcard.wildcard[ix]),
                                             (cmdInd->cmd.u.svc.termId.\
                                                wildcard.wildcard[ix]),
                                             sizeof(MgMgcoWildcardField))
                           }
                        }  
                      }   
#endif /* GCP_VER_1_5 && GCP_ASN */
                    break;
 
                case MGT_NTFY:               
                      MG_CH_COPY_STRUCT(
                            &(termId),
                            &(cmdInd->cmd.u.ntfy.termId),
                            sizeof(MgMgcoTermId))
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                      if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
                      {   
                        /* copy the wildcard contents also */
                        nmbr = cmdInd->cmd.u.ntfy.termId.wildcard.num.val;
                        if(nmbr > 0)
                        {   
                           MG_CH_GETMEM((termId.wildcard.wildcard),
                                      nmbr * sizeof(MgMgcoWildcardField *),
                                      &(cmdInd->memCp));
                           for (ix=0; ix < nmbr; ++ix)
                           {
                              MG_CH_GETMEM((termId.wildcard.wildcard[ix]),
                                        sizeof(MgMgcoWildcardField),
                                        &(cmdInd->memCp));
                              MG_CH_COPY_STRUCT((termId.wildcard.wildcard[ix]),
                                             (cmdInd->cmd.u.ntfy.termId.\
                                                wildcard.wildcard[ix]),
                                             sizeof(MgMgcoWildcardField))
                           }
                        }  
                      }   
#endif /* GCP_VER_1_5 && GCP_ASN */
                    break;
 
             }

             if (RFAILED ==
                   mgChAllocateIncCmdReqCb(axnIndRsp, cmdLoopIdx,
                                           &termId,
                                           axnReq->cl.cmds[cmdLoopIdx]->\
                                           cmd.type.val,
                                           axnReq->cl.cmds[cmdLoopIdx]
#if (defined (GCP_VER_1_5) && defined(GCP_ASN))
                                           ,peer->mgcoInfo.encodingScheme                   
#endif /* GCP_VER_1_5 && GCP_ASN */                   
                                          ))
             {
                goto ALLOC_ERR;
             }

      /* mg003.105:AddMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
             /* add the mapping and send RT upd to standby/shadows */
             ZG_INIT_RSETID_IN_MAPCB(&((axnIndRsp->cmdIndInfo[cmdLoopIdx])\
                                       ->mapCb));
             zgAddMapping(ZG_CBTYPE_CH_INC_CMDREQ,
                         (Ptr)(axnIndRsp->cmdIndInfo[cmdLoopIdx]));
#ifdef ZG_CH_LVL_UPD
             zgRtUpd(ZG_CBTYPE_CH_INC_CMDREQ,
                     (Ptr)(axnIndRsp->cmdIndInfo[cmdLoopIdx]),
                     CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_ADD);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

          }/* for cmdLoopIdx */
      } /* Commands Processing */ 
   } /* for axnLoopIdx */
 
   /* In the first action send the context update (if present) */
   /* and the first command indication */

   axnIndRsp = ppAxnIndRsp[CH_FIRST_AXN_ID];
    /* Check if context is present for the first action  */
   if ((axnIndRsp->type.val == CH_AXN_TYPE_ONLY_CNTXT) ||
       (axnIndRsp->type.val == CH_AXN_TYPE_BOTH))
   {
      pNode = trIndRsp->chCntxtLst.first;

      for (ctxLoopIdx = 0;ctxLoopIdx < (S16)trIndRsp->chCntxtLst.count;
           ctxLoopIdx++)
      {
         chCntxt = (MgMgcoChCntxtProp *)pNode->node; 
         if (chCntxt->actionId == CH_FIRST_AXN_ID) 
         {
            break;
         }
         pNode = pNode->next;
      }

      CH_CP_CNTXTUPD_TRANSID(cntxtUpd, transId)
      CH_CP_CNTXTUPD_CONTEXTID(cntxtUpd, chCntxt->cxtId)
      CH_CP_CNTXTUPD_PEERID(cntxtUpd, peer->accessInfo.peerId)

      if(axnIndRsp->numOfCmdInds > CH_MIN_CMDS_IN_AXN -1) 
          /* commands pending for this action */
          CH_SET_CNTXTUPD_CMDSTATUS(cntxtUpd, CH_CMD_STATUS_PENDING) 
      else if (numOfIndRspAxns > CH_MIN_AXNS_IN_TXN)
         /* More actions  */
         CH_SET_CNTXTUPD_CMDSTATUS(cntxtUpd, CH_CMD_STATUS_END_OF_AXN) 
      else
         /* No more actions  */
         CH_SET_CNTXTUPD_CMDSTATUS(cntxtUpd, CH_CMD_STATUS_END_OF_TXN) 
       /* Copy the context Props and audit */
       CH_CP_CNTXTUPD_PROP(cntxtUpd,chCntxt)
       mgChSendPrim ((Ptr)&cntxtUpd, peer, err, CH_PRIM_TYPE_UPD_CNTXT);
/* [UG]: */
      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */

#ifdef ZG
          /* Del the mapping and send RT upd to standby/shadows */
          /* ZG_INIT_RSETID_IN_MAPCB(&((chCntxt)->mapCb)); */
          zgDelMapping(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCntxt));
#ifdef ZG_CH_LVL_UPD
          zgRtUpd(ZG_CBTYPE_CH_CNTXT, (Ptr)(chCntxt), CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */
   } /* Send Context */
 
   axnIndRsp = ppAxnIndRsp[CH_FIRST_AXN_ID];
   /* Update the current action Id */
   axnIndRsp->curCmdIndId = CH_FIRST_CMD_IND_ID;

   if ( (axnIndRsp->type.val == CH_AXN_TYPE_ONLY_CMDS) ||
        (axnIndRsp->type.val == CH_AXN_TYPE_BOTH) )
   {
       /* Copy Transaction Id  */
       CH_CP_TRANSID(chCmd,transId)
       /* Copy context Id */
       CH_CP_CONTEXTID(chCmd, axnIndRsp->cntxtId)
       MG_CH_INIT_TOKEN_VALUE(&(chCmd.peerId), peer->accessInfo.peerId)
       if((axnIndRsp->numOfCmdInds > CH_MIN_CMDS_IN_AXN))
          /* Actions pending or context update present */
          CH_SET_CMDSTATUS(chCmd, CH_CMD_STATUS_PENDING) 
       else if (numOfIndRspAxns > CH_MIN_AXNS_IN_TXN)
          /* More actions  */
          CH_SET_CMDSTATUS(chCmd, CH_CMD_STATUS_END_OF_AXN) 
       else
          /* No more actions  */
          CH_SET_CMDSTATUS(chCmd, CH_CMD_STATUS_END_OF_TXN) 
       /* Set command type as indication */
       CH_CP_CMDTYPE(chCmd,CH_CMD_TYPE_IND)
       /* Copy the command req into command primitive */
       ppCmdInd = axnIndRsp->cmdInds;
       cmdInd = ppCmdInd[CH_FIRST_CMD_IND_ID];
 
       /* MG_CH_COPY_STRUCT(&(chCmd.u.mgCmdInd), (cmdInd), sizeof(MgMgcoCommandReq)) */
       chCmd.u.mgCmdInd[0] = cmdInd; 
 
       mgChSendPrim ((Ptr)&chCmd, peer, err, CH_PRIM_TYPE_CMD);
       /* mg006.105: we already calling zgDelMapping in mgChPrcCmdRsp, so no
        * nedd to call zgDelMapping at this place */
   } /* Send Commands */

 
#ifdef ZG
   /* Send update messages */
   zgUpdPeer();
#endif /* ZG */

   *err = MGT_CH_ERR_NONE;
   RETVALUE(ROK);



ALLOC_ERR:

   /* RT updates for cmds, cntxts & axns are not generated since the del upd
    * for the txn will clean everything within the txn */

   mgChHandleMgcoPrcTxnIndErr(peer->ssap, txnInd,
                              MGT_ERR_RSRC_UNAVAIL, MG_USER);

   /* the cmd array is freed within the mgChFreeAxnIndRspCb func */
   /* free the current axn (axnLoopIdx) */
   if (axnIndRspAlloc2 == TRUE)
   {
      /* Free all commands before the current command for the current axn.
       * The current command (cmdLoopIdx) could not be allocated */
      if (TRUE == cmdIndRspAlloc1)
      {
         for (toFreeCnt = 0; toFreeCnt < cmdLoopIdx; ++toFreeCnt)
         {
            /* No need to delete mapping for cmdRsps since these have not
             * been generated by the user */
#ifdef ZG
            zgDelMapping(ZG_CBTYPE_CH_INC_CMDREQ, (Ptr)(trIndRsp->axnIndRsp\
                            [axnLoopIdx]->cmdIndInfo[toFreeCnt]));
#endif /* ZG */
            mgChFreeIncCmdReqCb(trIndRsp->axnIndRsp[axnLoopIdx], toFreeCnt);
         }
      }

#ifdef ZG
       zgDelMapping(ZG_CBTYPE_CH_AXN_INDRSP, (Ptr)(trIndRsp->\
                                             axnIndRsp[axnLoopIdx]));
#endif /* ZG */
       mgChFreeAxnIndRspCb(trIndRsp->axnIndRsp[axnLoopIdx]);
   }

   /* free all axns before the current axn (axnLoopIdx) */
   for (toFreeCnt = 0; toFreeCnt < axnLoopIdx; ++toFreeCnt)
   {

      /* free all the commands in this axn */
      for (idx = 0; idx < trIndRsp->axnIndRsp[toFreeCnt]->numOfCmdInds;
           idx++)
      {
#ifdef ZG
          zgDelMapping(ZG_CBTYPE_CH_INC_CMDREQ, (Ptr)(trIndRsp->axnIndRsp\
                          [toFreeCnt]->cmdIndInfo[idx]));
#endif /* ZG */
          mgChFreeIncCmdReqCb(trIndRsp->axnIndRsp[toFreeCnt], idx);
      }

#ifdef ZG
       zgDelMapping(ZG_CBTYPE_CH_AXN_INDRSP, (Ptr)(trIndRsp->\
                                             axnIndRsp[toFreeCnt]));
#endif /* ZG */
      mgChFreeAxnIndRspCb(trIndRsp->axnIndRsp[toFreeCnt]);
   }

   /* the following func frees the chCntxtLst from the trIndRsp
    * since this list was allocated above */
   mgChFreeChCntxtLstInTransIndRspCb(trIndRsp);


   /* generate RT upd for deleting the txn */
      /* mg003.105:ChDelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */
#ifdef ZG
   mgChDelMappingTxnIndRspAndChilds(trIndRsp);
   /* zgDelMapping(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(trIndRsp)); */
#ifdef ZG_CH_LVL_UPD
   zgRtUpd(ZG_CBTYPE_CH_TXN_INDRSP, (Ptr)(trIndRsp), CMPFTHA_UPDTYPE_SYNC,
           CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

   mgChFreeTxnIndRspCb(trIndRsp);


   if (peerCmdCtlAlloc == TRUE)
   {
       /* generate RT upd for deleting the peer */
      /* mg003.105:DelMapping function is moved out from CH_LVL_UPD flag
       * as in case of Controlled switchover when this flag is disabled 
       * then also we want to update RsetCb list of all CB on any RSET */
#ifdef ZG
       zgDelMapping(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl));
#ifdef ZG_CH_LVL_UPD
       zgRtUpd(ZG_CBTYPE_CH_PEER, (Ptr)(peerCmdCtl), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_DEL);
#endif /* ZG_CH_LVL_UPD */
#endif /* ZG */

       /* Delete the block from the list */
       cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR)peerCmdCtl); 

       mgDeAlloc((Data *) peerCmdCtl, sizeof(peerCmdCtl));
   }
 

#ifdef ZG
   /* Send update messages */
   zgUpdPeer();
#endif /* ZG */


   mgFreeEventMem((Ptr)txnInd);

   RETVALUE(RFAILED);

} /* mgChPrcTxnInd */


/*
 *
 *       Fun:   mgChHandleMgcoPrcTxnIndErr
 *
 *       Desc:  This function reports rejection of a MGCO Indication primitive
 *              to Service user.
 *
 *       Ret:   None
 *
 *       Notes: None
 *
 *       File:  mg_util.c
 *
 */

#ifdef ANSI
PUBLIC Void mgChHandleMgcoPrcTxnIndErr
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgMgcoTxn          *mgtxn,             /* Megaco Message     */
U8                 mgtError,           /* Error to be reported */
U8                 source              /* Initiated by user/ internal */
)
#else
PUBLIC Void mgChHandleMgcoPrcTxnIndErr(ssap, mgtxn, mgtError, source)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgMgcoTxn          *mgtxn;             /* Megaco Message     */
U8                 mgtError;           /* Error to be reported */
U8                 source;             /* Initiated by user/ internal */
#endif
{
   MgMgcoInd       ind;                /* CH Error Ind   */
   
   TRC3(mgChHandleMgcoPrcTxnIndErr);

   /*mg008.105 Added the functionality to mgChHandleMgcoPrcTxnIndErr */
   /* If message was internally generated by GCP then dont send
      err indication to the user */
   if (source == MG_INTERNAL)
     RETVOID;
   
   cmMemset( (U8 *) &ind, 0, sizeof(MgMgcoInd) );
   
   if (mgtError != MG_IGNORE)
   {
      /* Fill MGT primitive error using the MgtInd Primitive which is  */
      /* used by CH */
      CH_CP_IND_TRANSID(ind, mgtxn->u.req.transId)
      CH_SET_IND_ERRDESC(ind, mgtError)
   } /* end of if (mgtError != MG_IGNORE) */

   /* Indicate Error to user */
   (*mgUiMgtMgcoTxnStaIndMt[(ssap->suPst.selector)]) (&(ssap->suPst), ssap->suId, &ind);

   RETVOID;
   
} /* mgChHandleMgcoPrcTxnIndErr  */


/*
 *
 *       Fun:   mgChFillAuthHdr
 *
 *       Desc:  If "fill" is TRUE, Auth header needs to be filled, else it is 
 *              not reqd. If fill=FALSE, secIdx, seqNum, authData * aLen are 
 *              irelevant, and not used.
 *
 *       Ret:   void
 *
 *       Notes: <NONE>
 *
 *       File:  mg_msg.c
 *
 */

#ifdef ANSI
PRIVATE S16 mgChFillAuthHdr
(
Bool                 fill,
MgMgcoAuthHdr        *auth,
U32                  secIdx,
U32                  seqNum,
U8                   *authData,
U8                   aLen
)
#else
PRIVATE S16 mgChFillAuthHdr(fill,auth,secIdx,seqNum,authData,aLen)
Bool                 fill;
MgMgcoAuthHdr        *auth;
U32                  secIdx;
U32                  seqNum;
U8                   *authData;
U8                   aLen;
#endif
{

   TRC3(mgChFillAuthHdr);

   if (TRUE != fill)
   {
       /* Auth header not present */
       auth->pres.pres = NOTPRSNT;

       /* No auth data */
       MG_CH_INIT_TKNSTR(&(auth->aData),NULLP,0);
   }
   else
   {
       /* Auth header present. check val */
       MG_CH_INIT_TOKEN_VALUE(&(auth->pres),1);

       /* Set the security param index */
       MG_CH_INIT_TOKEN_VALUE(&(auth->spi),secIdx);

       /* Set the sequence number */
       MG_CH_INIT_TOKEN_VALUE(&(auth->sn),seqNum);

       /* Initialize to auth data provided */
       MG_CH_INIT_TKNSTR(&(auth->aData),authData,aLen);
   }

   RETVALUE(ROK);
}


/*
 *
 *       Fun:   mgChFillVersion
 *
 *       Desc:  If "fill" is TRUE, version needs to be filled,
 *              else it is ignored
 *
 *       Ret:   void
 *
 *       Notes: <NONE>
 *
 *       File:  mg_msg.c
 *
 */

#ifdef ANSI
PRIVATE S16 mgChFillVersion
(
Bool                 fill,
MgMgcoVersion        *version,
U8                   verNo
)
#else
PRIVATE S16 mgChFillVersion(fill,version,verNo)
Bool                 fill;
MgMgcoVersion        *version;
U8                   verNo;
#endif
{
   TRC3(mgChFillVersion);

   if(TRUE != fill)
   {
       /* Version info not present */
       version->pres = NOTPRSNT;
       version->val = 0;
   }
   else
   {
       MG_CH_INIT_TOKEN_VALUE(version,verNo);
   }

   RETVALUE(ROK);
}


/*mg008.105: ccpu00068479, Remove function  mgChFillMgcoCommand as it is not being used at all */

/*
 *      FUN:   mgChFreeCmds
 *
 *      Desc: THis function frees the commands present in transaction 
 *
 *      Ret:   void
 *
 *      Notes: None
 *
 *      File:  mg_act5.c
 *
 *
 */
#ifdef ANSI
PUBLIC S16 mgChFreeCmds
(
MgMgcoMsg         *txn,
U16                txnCnt
)
#else
PUBLIC S16 mgChFreeCmds (txn,txnCnt)
MgMgcoMsg         *txn;
U16                txnCnt;
#endif /* ANSI */
{
   
   /* Block for freeing the command req memcp                */
   {
      MgMgcoTxn            *trans = (txn)->body.u.tl.txns[txnCnt];
      U16                  numOfAxns =0;         
      U16                  numOfCmds =0;         
      U16                  axnCnt =0;
      U16                  cmdCnt =0;
      MgMgcoActionReq      *axn;
      MgMgcoCommandReq     *cmd;

      if ( (trans->type.val == MGT_TXNREQ) &&
            (trans->u.req.al.num.pres != NOTPRSNT))
      {
         numOfAxns = trans->u.req.al.num.val;
         for (axnCnt = 0; axnCnt < numOfAxns; axnCnt++)
         {
            axn = trans->u.req.al.actns[axnCnt];
            if ((axn->pres.pres != NOTPRSNT) &&
                  (axn->cl.num.pres != NOTPRSNT))
            {
               numOfCmds = axn->cl.num.val;
               for (cmdCnt = 0; cmdCnt < numOfCmds; cmdCnt++)
               {
                  cmd = axn->cl.cmds[cmdCnt];
                  mgFreeEventMem((Ptr)(cmd));
               } /* Cmd Loop */
            }
         } /* axnLoop */ 
      }

   }
   /* Block for freeing the command reply memcp                */
   {
      MgMgcoTxn            *trans = (txn)->body.u.tl.txns[txnCnt];
      U16                  numOfAxns =0;         
      U16                  numOfCmds =0;         
      U16                  axnCnt =0;
      U16                  cmdCnt =0;
      MgMgcoActnReply      *axn;
      MgMgcoCmdReply       *cmd;
      MgMgcoCxtCmdReply    *reply = NULLP;           /* Context reply + cmd replies */


      if ( (trans->type.val == MGT_TXNREPLY) &&
            (trans->u.reply.type.val == MGT_ACTIONREPLY)&&
            (trans->u.reply.u.arl.num.pres != NOTPRSNT))
      {
         numOfAxns = trans->u.reply.u.arl.num.val;
         for (axnCnt = 0; axnCnt < numOfAxns; axnCnt++)
         {
            axn = trans->u.reply.u.arl.repl[axnCnt];
#ifdef MGT_GCP_VER_1_4
            if ((axn->pres.pres != NOTPRSNT) &&
                  (axn->repErrSet.pres.pres != NOTPRSNT)) 
            {
               reply = &axn->repErrSet.reply;
            }
#else
            if ((axn->pres.pres != NOTPRSNT) && 
                  (axn->type.val == MGT_CXTCMDREPLY))
            {
               reply = &axn->u.reply;
            }
#endif /*MGT_GCP_VER_1_4 */
            /* [UG]: Adding reply!=NULLP check for error cases */ 
            if ((reply != NULLP) &&
                  (reply->pres.pres != NOTPRSNT) &&
                  (reply->cl.num.pres != NOTPRSNT))
            {
               numOfCmds = reply->cl.num.val;
               for (cmdCnt = 0; cmdCnt < numOfCmds; cmdCnt++)
               {
                  cmd = reply->cl.repl[cmdCnt];
                  mgFreeEventMem((Ptr)(cmd));
               } /* Cmd Loop */
            }
         } /* axnLoop */ 
      }


   }
   RETVALUE(ROK);
} /* mgAccFreeCmds */

/*
*
*       Fun:   mgChCmdFillDefPeerId 
*
*       Desc:  This function fills the default peerId in command
*
*       Ret:   void
*
*       Notes: <NONE>
*
*       File:  mp_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgChCmdFillDefPeerId 
(
MgMgcoCommand      *chCmd,
MgSSAPCb          *sSap
)
#else
PUBLIC S16 mgChCmdFillDefPeerId(chCmd,sSap)
/* mg003.105: Changes for NON-ANSI compilation */
MgMgcoCommand     *chCmd;
MgSSAPCb          *sSap;
#endif /* ANSI */
{

   MgPeerCb    *peer;

   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
      peer = sSap->crntMgc;

      if (peer == NULLP)
      {
         mgSelectPeer(&(peer), sSap);
         if (peer == NULLP)
         {
            mgChHandleMgcoCmdReqErr(sSap, chCmd, MGT_CH_ERR_PEER_NOT_FOUND, MG_USER);
            mgFreeEventMem((Ptr) chCmd->u.mgCmdReq[CH_NULL_INDEX]);
            /* mg005.105: Fix for the mgChCmdFillDefPeerId */
            RETVALUE(RFAILED);
         }
         sSap->crntMgc = peer;
      }
      chCmd->peerId.pres = PRSNT_NODEF;
      chCmd->peerId.val = peer->accessInfo.peerId;
   }
   RETVALUE(ROK);
 
} /* mgChCmdFillDefPeerId */
 
/*
*
*       Fun:   mgChCxtFillDefPeerId 
*
*       Desc:  This function fills the default peerId in update context 
*
*       Ret:   void
*
*       Notes: <NONE>
*
*       File:  mp_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgChCxtFillDefPeerId 
(
MgMgcoUpdateCntxt *chCxt,
MgSSAPCb          *sSap
)
#else
PUBLIC S16 mgChCxtFillDefPeerId(chCxt,sSap)
/* mg003.105: Changes for NON-ANSI compilation */
MgMgcoUpdateCntxt *chCxt;
MgSSAPCb          *sSap;
#endif /* ANSI */
{

   MgPeerCb    *peer;

   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
      peer = sSap->crntMgc;

      if (peer == NULLP)
      {
         mgSelectPeer(&(peer), sSap);
         if (peer == NULLP)
         {
            mgChHandleMgcoCntxtUpdErr(sSap, chCxt, MGT_CH_ERR_PEER_NOT_FOUND, 
                                    MG_USER);
            mgFreeEventMem((Ptr) chCxt);
            RETVALUE(ROK);
         }
         sSap->crntMgc = peer;
      }
      chCxt->peerId.pres = PRSNT_NODEF;
      chCxt->peerId.val = peer->accessInfo.peerId;
   }
   RETVALUE(ROK);
 
} /* mgChCxtFillDefPeerId */
 
 
/*
*
*       Fun:   mgChErrReqFillDefPeerId 
*
*       Desc:  This function fills the default peerId in error request 
*
*       Ret:   void
*
*       Notes: <NONE>
*
*       File:  mp_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgChErrReqFillDefPeerId 
(
MgMgcoInd         *chInd,
MgSSAPCb          *sSap
)
#else
PUBLIC S16 mgChErrReqFillDefPeerId(chInd,sSap)
/* mg003.105: Changes for NON-ANSI compilation */
MgMgcoInd         *chInd;
MgSSAPCb          *sSap;
#endif /* ANSI */
{

   MgPeerCb    *peer;

   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
      peer = sSap->crntMgc;

      if (peer == NULLP)
      {
         mgSelectPeer(&(peer), sSap);
         if (peer == NULLP)
         {
            mgChHandleMgcoPrcIndErr(sSap, chInd, MGT_CH_ERR_PEER_NOT_FOUND, 
                                    MG_USER);
            mgFreeEventMem((Ptr) chInd);
            RETVALUE(ROK);
         }
         sSap->crntMgc = peer;
      }
      chInd->peerId.pres = PRSNT_NODEF;
      chInd->peerId.val = peer->accessInfo.peerId;
   }
   RETVALUE(ROK);
 
} /* mgChErrReqFillDefPeerId */



/*   mg004.105: GCP_ALLOW_LIMIT_CFG - This is introduced
 *   to configured the limits for GCP message
 *   components exceeding which will be rejected */
 
#ifdef GCP_ALLOW_LIMIT_CFG
 
/*       Fun:  mgChValidateTxnInd
 *
 *       Desc:  This CH function processes the Transaction request from
 *              the peer and validates as per the Limit Cfg.              
 *
 *       Ret:   ROK - SUCCESS;
 *              RFAILED - FAILURE
 *
 *       Notes: 
 *
 *       File:  mg_cord.c
 *
 */
#ifdef ANSI
PRIVATE S16 mgChValidateTxnInd 
(
MgMgcoMsg          *msg,           /* Megaco Message     */
MgPeerCb           *peer,          /* Peer Control Block */
S16                *err            /* error code         */
)
#else
PRIVATE S16 mgChValidateTxnInd (msg, peer, err)
MgMgcoMsg          *msg;           /* Megaco Message     */
MgPeerCb           *peer;          /* Peer Control Block */
S16                *err;           /* error code         */
#endif 
{
   MgMgcoTxnReq        *req;                        /* Transaction req      */
   MgMgcoActionReq     *axnReq;                    /* Action Req           */  
   U16                 txnCnt;
   U16                 axnCnt;

   TRC2(mgChValidateTxnInd)
   req = NULLP;
   axnReq = NULLP;

   if ((msg == NULLP) || (msg->body.type.pres != PRSNT_NODEF) ||
       (peer == NULLP) || (peer->ssap == NULLP))
   { 
      *err = MGT_CH_ERR_INV_MSG;
      RETVALUE (RFAILED);
   }
 
   if ((msg->body.type.val != MGT_TXN) || 
       (msg->body.u.tl.num.pres == NOTPRSNT) || 
       (msg->body.u.tl.num.val == 0)) 
   {
      /* Not interested */
      *err = MGT_CH_ERR_NONE;
      RETVALUE (ROK);
   }
    
   /* Check for limits if it is configured            */
   /* Check for the no. of transactions against the configured value */
   if ((peer->ssap->ssapCfg.maxNoOfTxnsPerMsg.pres == PRSNT_NODEF) && 
       (msg->body.u.tl.num.val > 
             peer->ssap->ssapCfg.maxNoOfTxnsPerMsg.val))
   {
      *err = MGT_MGCO_RSP_CODE_BAD_REQ; 
      RETVALUE (RFAILED);
   } 

   for (txnCnt = 0; txnCnt < msg->body.u.tl.num.val; txnCnt++)
   {  
      /* Check for not txn req and continue */
      if ((msg->body.u.tl.txns[txnCnt]->type.pres == PRSNT_NODEF) && 
            (msg->body.u.tl.txns[txnCnt]->type.val != MGT_TXNREQ))
      {
         continue;
      }
      else
      {
         req = &msg->body.u.tl.txns[txnCnt]->u.req;
         /* Check for number of actions against the configured value */
         if ((req->pres.pres == PRSNT_NODEF) &&
             (req->al.num.pres == PRSNT_NODEF) &&
             (peer->ssap->ssapCfg.maxNoOfActnsPerTxn.pres == PRSNT_NODEF) &&
             (req->al.num.val > peer->ssap->ssapCfg.maxNoOfActnsPerTxn.val))         
         {
            *err = MGT_MGCO_RSP_CODE_BAD_REQ; 
            RETVALUE (RFAILED);
         } 
         else
         {
            for (axnCnt = 0; axnCnt < req->al.num.val; axnCnt ++)
            {
               axnReq = req->al.actns[axnCnt];
               if (axnReq->pres.pres == NOTPRSNT)
                  continue;
               if ((axnReq->cl.num.pres == PRSNT_NODEF) &&
                   (peer->ssap->ssapCfg.maxNoOfCmdsPerActn.pres 
                           == PRSNT_NODEF) &&
                   (axnReq->cl.num.val > 
                      peer->ssap->ssapCfg.maxNoOfCmdsPerActn.val))         
               {
                  *err = MGT_MGCO_RSP_CODE_BAD_REQ; 
                  RETVALUE (RFAILED);
               } 
            }
         }
      }
   }

   *err = MGT_CH_ERR_NONE; 
   RETVALUE (ROK);

} /* mgChValidateTxnInd */

#endif /* GCP_ALLOW_LIMIT_CFG  */
 
#endif /* GCP_CH */



/*
*       Fun:  mgVerifyVersion
*
*       Desc:  This function decodes the message in ASN format.
*
*       Ret:   ROK - SUCCESS;
*              RFAILED - FAILURE
*
*       Notes: 
*
*       File:  mg_cord.c
*/
#ifdef ANSI
PUBLIC S16 mgVerifyVersion
(
MgMgcoTxn *mgcoTxn ,
MgSSAPCb   *ssap
)
#else
PUBLIC S16 mgVerifyVersion(mgcoTxn,ssap)
MgMgcoTxn *mgcoTxn;
MgSSAPCb   *ssap;
#endif /* ANSI */
{
   MgMgcoTxnReq     *mgcoTxnReq;        /* Megaco Transaction Request */
   MgMgcoActionReq  *action;            /* Action */
   MgMgcoCommandReq *cmdReq;            /* Command Request */

   TRC2(mgVerifyVersion)
   
   if (mgcoTxn->type.val == MGT_TXNREQ)
   {   
      mgcoTxnReq = &mgcoTxn->u.req; 

#if (ERRCLASS & ERRCLS_INT_PAR)
      if ((mgcoTxnReq->pres.pres == NOTPRSNT) || 
          (mgcoTxnReq->al.num.pres == NOTPRSNT) ||
          (mgcoTxnReq->al.num.val == MGT_NONE))
      {
         RETVALUE(RFAILED);
      }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */


      if ((action = ((mgcoTxnReq->al.actns)[0])) == NULLP)
        RETVALUE(RFAILED);


#if (ERRCLASS & ERRCLS_INT_PAR)
      if ((action->pres.pres == NOTPRSNT) ||
          (action->cl.num.pres == NOTPRSNT) ||
          (action->cl.num.val == MGT_NONE))
      {
        RETVALUE(RFAILED);
      }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      if ((cmdReq = ((action->cl.cmds)[0])) == NULLP)
        RETVALUE(RFAILED);


#if (ERRCLASS & ERRCLS_INT_PAR)
      if ((cmdReq->pres.pres == NOTPRSNT) ||
          (cmdReq->cmd.type.pres == NOTPRSNT) ||
          (cmdReq->cmd.u.svc.pres.pres == NOTPRSNT))
      {
         RETVALUE(RFAILED);
      }

      if (((cmdReq->cmd.u.svc.parm.pres.pres == NOTPRSNT) ||
           (cmdReq->cmd.u.svc.parm.meth.pres.pres == NOTPRSNT)) ||
           ((cmdReq->cmd.u.svc.parm.meth.type.pres == NOTPRSNT)))
      {
         RETVALUE(RFAILED);
      }

#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      if (cmdReq->cmd.u.svc.parm.ver.pres != NOTPRSNT)
      {
         if ((ssap->ssapCfg.minMgcoVersion > cmdReq->cmd.u.svc.parm.ver.val)  || \
           ( cmdReq->cmd.u.svc.parm.ver.val >  (ssap->ssapCfg.maxMgcoVersion) ))
          RETVALUE(RFAILED);
         else
          RETVALUE(ROK);
      
      }
   }
   else
      RETVALUE(RFAILED);

   RETVALUE(ROK);
}  



#endif /* GCP_VER_1_5 */
#endif /* GCP_MGCO */

#ifdef ZG
#ifdef GCP_PROV_SCTP
#ifdef GCP_MGCO
/*
*
*       Fun:   mgRecovrEndp
*
*       Desc:  This function takes the recovery action when new service provider
*       comes up .Typically when service 
*       provider fails , then layer manager may issue control req to preserve 
*       resourses (endpoints & association ) and once new Service provider 
*       comes up..GCP layer will try to acquire same resources..which will 
*       bring GCP layer to same state as it was.
*       
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgRecovrEndp
(
MgTSAPCb           *tsap            /* TSAP Control Block */
)
#else
PUBLIC S16 mgRecovrEndp(tsap)
MgTSAPCb           *tsap;            /* TSAP Control Block */  
#endif
{
   S16             ret=ROK;                /* Return Value */
   MgPeerCb        *peer;
   MgSSAPCb        *ssap;
   U32             i;

      TRC2(mgRecovrEndp)
#ifdef GCP_MG
   if(mgCb.genCfg.entType == LMG_ENT_GW)
   {
      for(i = 0; i< mgCb.genCfg.maxSSaps; i++)
      {
         ssap = mgCb.sSAPLst[i];
         if(ssap != NULLP)
         {
            peer = ssap->crntMgc;
            if(peer == NULLP)
               mgSelectPeer(&peer, ssap);
            if(peer == NULLP)
               RETVALUE(RFAILED);
            else if(peer->accessInfo.transportType == LMG_TPT_SCTP)
               /*    ssap = tsap->ssap;
                     if(ssap != NULLP)

                     peer = ssap->crntMgc;
                     if(peer == NULLP)
                     mgSelectPeer(&peer, ssap);
                     if(peer == NULLP)
                     RETVALUE(RFAILED); 
                     else if((peer->accessInfo.transportType == LMG_TPT_SCTP) &&
                     (tsap->tsapCfg.reCfg.changeOver == TRUE)) */

            { 
               /* Reset the Change Over Flag */
               tsap->tsapCfg.reCfg.changeOver = FALSE;
               ret = mgSendSrvcChng(peer,MGT_SVCCHGMETH_DISCON,
                     MG_SCRSN_MG_IMPN_FAIL, NULLP,
                     LMG_INVALID_PEER_PORT,
                     NULLP);

               ssap->crntMgc = peer;
               /* Send update for peer and ssap */
               zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_MOD);
               zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_MOD);

               /* generate status indication to LM indiacting status of SCTP recovery
                * procedure */
               if(ret == ROK)
               {
                  mgGenStaInd (STSSAP, LCM_CATEGORY_PROTOCOL, 
                        LMG_EVENT_TSAP_RECVRY_SUCCESS, LMG_CAUSE_UNKNOWN, 
                        LMG_ALARMINFO_NONE, (Ptr)NULLP, 0, LMG_ALARMINFO_INVSAPID);
                  /* Send status ind to service user */
                  mgGenUserStaInd(NULLP,NULLP, MGT_STATUS_SAP_RECVRY_SUCCESS ,
                        NULLP);
               }
               else
               {
                  mgGenStaInd (STSSAP, LCM_CATEGORY_PROTOCOL, 
                        LMG_EVENT_TSAP_RECVRY_FAILED, LMG_CAUSE_TPT_FAILURE, 
                        LMG_ALARMINFO_NONE, (Ptr)NULLP, 0, LMG_ALARMINFO_INVSAPID);
                  /* Send status ind to service user */
                  mgGenUserStaInd(NULLP,NULLP, MGT_STATUS_SAP_RECVRY_FAILED,
                        NULLP);
               }
            }
         }
         continue;
      }

   }/* EntTYPE==GW */

#endif /* GCP_MG */
#ifdef GCP_MGC
   if(mgCb.genCfg.entType == LMG_ENT_GC)
   {
      /* Reset the Fail Over Flag as OpenEndpCfm has received i.e
         that SCTP is UP */
      tsap->tsapCfg.reCfg.changeOver = FALSE;

      /* generate status indication to LM indiacting status of SCTP recovery
       * procedure */
      mgGenStaInd (STSSAP, LCM_CATEGORY_PROTOCOL, 
            LMG_EVENT_TSAP_RECVRY_SUCCESS, LMG_CAUSE_UNKNOWN, 
            LMG_ALARMINFO_NONE, (Ptr)NULLP, 0, LMG_ALARMINFO_INVSAPID);
      /* Send status ind to service user */
      mgGenUserStaInd(NULLP,NULLP, MGT_STATUS_SAP_RECVRY_SUCCESS ,
            NULLP);
   }
#endif /* GCP_MGC */
      
   RETVALUE(ret);

} /* end of mgRecovrEndp() */

#endif /* GCP_MGCO */
#endif /* GCP_PROV_SCTP */
#endif /* ZG */

#endif /* MG */









/********************************************************************30**
 
        End of file:     mp_cord.c@@/main/mgcp_rel_1.5_mnt/13 - Tue Jun  7 13:04:51 2005
*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bbk  1. Initial release.
1.2          ---      bbk  1. cmHashListFind in ipAddrLst had peer as final
                              argument instead of ipAddrEnt. Fixed that
1.2+        mg001.101 bbk  1. For DLCX Response from an MG, connection 
                              parameters are mandatory..added check for it
            mg002.101  pk  2. Modified argument list for call to function
                              cmDnsInitDnsCb.
                           3. Modified argument list for call to function
                              cmDnsGenRslvReq.
                           4. Modified argument list for mgRcvDnsResponse.
                           5. Modified copying of response address into 
                              addTbl structure in function mgRcvDnsResponse
                           6. Added code to copy domain name into the
                              query in function mgSendDnsRslvReq.
            mg002.101 bbk  1. Removed wrong comment before encoding PDU
                           2. Added code to ensure that outgoing PDU is not
                              more than 1500 bytes in size (including UDP Hdr)
            mg003.101 bbk  1. Changed arguments to mgPrcOutGoingAck
                           2. Fixed mgLocatePeerFromTxn to fetch peer when
                              peerId isn't present
            mg005.101 bbb  1. Command Structure from MgMgcpMsg should be picked
                              from the union based on msgType
                           2. Response to commands should be transmitted to source
                              transport address
                           3. On receiving a command from the network, the Call agent
                              can use endpoint name or source IP address. However, 
                              gateways should use source IP Address to find a peer.
            mg006.101 bbk  1. In mgRslvDomainNameStr() memset the stack 
                              variable used for storing IP Address to 0
            mg007.101 bbk  1. Added support for peerId being U32 under
                               GCP_ENHNC_1_2 compile time flag
                           2. For sending out Notify, if port number is
                              not specified by the user, copy the peer
                              port number.
                           3. For RSIP, removed expectation that a gateway
                              will always register with "*" as local name
                              for the endpoint
                           4. Added conveying IP Address information to 
                              layer manager through unsolicited status
                              indication
           mg008.101  bbk  1. Added check to ensure that transactions for
                              a peer are not spread across SSAPs
                           2. In process RSIP, removed null terminating domain
                              name string as it will corrupt stack
                           3. Made changes to mgFillNotifyEntity function to stop
                              filling notify entity in order to avoid overwriting
                              notfied entity
                           4. Split mgRslvDomainNameStr() into two functions
            mg009.101 bbk  1. Enhanced mgFindNtfyEntInMsg() function to 
                              search for any specified parameter in a message. 
                              Renamed the function as mgMgcpFindParamTypeInMsg()
                           2. Added integrity checks for command types transmitte
                              or received with respect to the local entity 
                              represented
                           3. Added support for discovery of a new Call Agent 
                              on the MG side. Main function for the purpose is
                              mgMgcpChkAndPrcNtfiedEntity()
                           4. Changed function name for mgFillNotifyEntity() to 
                              mgCopyNotifyEntityForTx()
                           5. For CRCX response, SDP parameter can be missing for
                              data connections. So removed check for SDP paramete
                              presence
                           6. For Incoming DLCX, added support for checking 
                              outgoing response for Connection Parameters only
                              if DLCX was from MGC with ConnId present
/main/3      ----       pk   1. Added  MEGACO support.
                           2. Added Notified Entity support for MGCP
                           3. Modularized existing MGCP functions.
             mg002.102  vj 1. Added support for sending a txnRespAck whenever 
                              a txnReply is received with immAck flag enabled.
             mg003.102  vj 1. Modified mgMgcoSendErrRsp so that the error message
                              is sent successfully if a message with syntax error
                              is received.
             mg006.102 bbk 1. If peer->state is resolving and initReg is FALSE,
                              then we need to queue the transaction sent by SU 
                              in GCP. Made change for that to happen
                           2. Modified mgVerifyRspParms so that the checking 
                              for connParams in DLCX response is done only when 
                              the response code is 200 ok.
                           3. Modified mgPrcMgcoMsg to check for immAck flag 
                              in every transaction received in the message.
                           4. Modified variable type(nameLen from U8 to U16) in 
                              mgMgcpChkForNewPeerInRSIP to make sure that 
                              truncation does not happen.
                           5. Explicit typecasting done in mgRcvDnsResponse 
                              and mgSendDnsRslvReq to remove warnings.
            mg007.102  vj  1. While invoking mgConvertIpAddrToAscii, changed parameter 
                              type from U8* to U16*. Size should not change.
                           2. Add for processing of immAck flag in case response is a 
                              service change reply.
            mg008.102  vj  1. In mgMgcpPrcRSIPResponse(), delete the peer only 
                              when GCP_USER_RETX_CNTRL is not defined. If this 
                              flag is defined, simply indicate the received 
                              transaction to SU.
                           2. In mgMgcpPrcRSIPResponse(), for initReg=TRUE, 
                              compare the transId with the trId saved within 
                              the peerCb, when the RSIP was generated by the 
                              stack.
                           3. In mgMgcpPrcCmdInTxnReq, enforce that the first 
                              message received from SU, if initReg=FALSE, is a 
                              RSIP with method as restart or disconnected.
                           4. In mgRmvEmptyTxn, deleted the call to 
                              MG_FREE_MGCO_EVNT_MEM.
                           5. In mgMgcpPrcEachTxnReq, added a call to 
                              mgMgcpUpdateNxtUseSrvrForTx whenever a txn is 
                              sent. This makes sure that the next use server 
                              is updated properly.
           mg010.102  vj   1. In function mgMgcpVerifyCmdParms, added a new 
                              param rspCode, so that different error codes may 
                              be differentiated.
           mg011.102    vj 1. Modified mgMgcoSendErrRsp, mgSendMgcoTxnPend & 
                              mgSendTxnRspAck functions, to set "mid" from 
                              configured MID.
                           2. In case of MGCP MG, for a notified entity peer, 
                              removed the restriction that the first message 
                              from the SU should be a RSIP.
                           3. Since the macros MG_ISSUE_PEER_STAIND and 
                              MG_COPY_PEERINFO_INTO_TXN have been broken into 
                              MGCP & MGCO specific macros, converted the calls 
                              to each specific macro.
                           4. In mgPrcMgcoTxnReq, the value of source is never 
                              MG_INTERNAL. Removed the dead code corresponding 
                              to it.
                           5. Invoked MG_FILL_MID_IN_MSG to fill MID in stack 
                              generated messages. This macro obtains the MID 
                              from the configured MID in SSAP. Deleted the call
                              to mgCnvrtPeerInfoToMId.
/main/4      ---      ra   1. GCP 1.3 release
             mg004.103 rg  1. Removed redundant deallocation macro from
                              function mgPrcMgcoErrDesc
                           2. Deallocate transaction buffer in function
                              mgPrcMgcoErrDesc in failure cases.
                           3. Modified the algorithm for calculation of RTO
                              in case of retransmitted transactions.
                       ra  4. Correct the variable wrap around problem by
                              modifying the for loop.
          mg005.103   ra   1. Now passing pointer to pointer to mBuf in
                              function mgPrcMgcoTxn() and additionally
                              passing pointer to the crntLen to it.
                           2. Moved the def of stack var crntLen from
                              mgPrcMgcoTxn() to mgPrcMgcoTxnReq().
                           3. Initialised crntLen by the length of message
                              header in mgPrcMgcoTxnReq() before passing
                              it to mgPrcMgcoTxn().
                           4. Now calling mgFillNewMgcoBuf() only if a
                              buffer is to be transmitted.
                           5. Setting peer->mntInfo.usrKnows as TRUE
                              in case the service user is sending RSIP
                              or serviceChange.
          mg010.103   rg   1. Added check for method before sending a Service
                              Change message.
          mg011.103    ra  1. Corrected an error. num.val in errMsg is
                              now being assigned a value of 1 instead of 0.
                           2. Wherever the following code is present -
                              *(mgcoMsg->body.u.tl.txns + loopIdx) = NULLP;
                              freed SDP Tkn Bufs before executing the above
                              statement by calling mgMgcoFreeAllTkBfs().
                           3. Wherever the following code is present -
                              cmFreeMem((Ptr) &mgcpMsg->memCp);
                              freed SDP Tkn Bufs before executing the above
                              statement by calling mgMgcpFreeAllTkBfs().
                           4. Added a NULL pointer check in processing of
                              Megaco Transaction Request
                           5. For MGCP/Megaco, if Response Message Size is > 
                              than the configured mtu size for the peer, an 
                              error is returned to the Service User with ERR 
                              Type as MGT_ERR_MSG_LENGTH
                           6. For Megaco, now freeing mgcoTxn event structure
                              under the flag GCP_VER_1_3 because the memCp is
                              defined only under the flag GCP_VER_1_3.
          mg013.103    ra  1. added support for errorDesc within message
                              body if the GCP_VER_1_3 flag is defined.
                           2. added range check for the maximum number of
                              transactions in a MEGACO msg. If this check
                              fails then a debug message is printed.
          mg014.103    ra  1. Initialized rspCode variable at several places.
          mg015.103    ra  1. Now checking if peer is NULLP in received MEGACO
                              msg on the MG side and if so it implies that
                              the peer is unknown to us. Therefore we should
                              reply with an error response - unauthorized (402).
                              We should also reply with an error response -
                              unauthorized (402) when we receive a command
                              from a configured secondary, tertirary, ... MGC.
                              Only the primary MGC is supposed to contact us.
/main/5      ---       ka     Changes for Release v 1.4
          mg003.104    ka  1. Corrected the portion of processing the Service
                              change reply when contains invalid[non existing]
                              transaction ID. Instead of filling error action
                              and returning failure, the transaction is freed
                              and continued for further transactions.
                       ka  2. Corrected memory leak in mgRmvEmptyTxn while 
                              removing the empty transaction.
                       ka  3. Corrected the service change reason(code value)
                              for resending the service change message to a
                              secondary MGC
          mg004.104    ka  1. Value of the response string length is set now
          mg005.104    ra  1. FTHA related changes.
/main/6      ---      pk   1. GCP 1.5 release
         mg002.105    ra  1. Made rspAckEnb a reconfigurable parameter.
                            2. Added support to send rspAckRsp immediately
                               if rspAckEnb says so.
                           3. Removed patch reference for 1.3 and 1.4
                           4. Removed compilation warnings
                           5. Extern moved from mg.x for g++ compilation issue
                           6. Changes for Command Handler
                           7. Changes to test exceed maximum PDU size
         mg003.105    dp   1. DelMapping function is moved out from CH_LVL_UPD
                              flag as in case of Controlled switchover when this
                              flag is disabled then also we want to update 
                              RsetCb list of all CB on any RSET 
                           2. AddMapping function is moved out from CH_LVL_UPD
                              flag as in case of Controlled switchover when this
                              flag is disabled then also we want to update 
                              RsetCb list of all CB on any RSET 
                     ps    3. Bug fixes 
                     gk    4. Updating the mBuf with txnMBuf 
                     ps    5. Changed error code from rsp timeout to pending limit exceed    
                     ps    6. Check if message is null return failure 
                           7. Added sanity check
                           8. Added temparory reason field
                           9. If method is restart then reason is cold boot
                              If method is disconnection then reason is fail
         mg004.105   gk    1. GCP_ALLOW_LIMIT_CFG - This is introduced
                              to configured the limits for GCP message
                              components exceeding which will be rejected
                           2. Added version negotiation 
                           3. Added unauthorized mid checking
                           4. Bug fix for not sending two error replies 
         mg005.105   gk    1. Fix for the mgChCmdFillDefPeerId
                           2. Reject unknow packages with 
                              MGT_MGCO_RSP_CODE_PACKAGE_UNSUPP error code
         mg006.105   gk    1. we already calling zgDelMapping in mgChPrcCmdRsp, so no
                              nedd to call zgDelMapping at this place
         mg007.105   gk    1. Corrected the error code 
                           2. There shouldn't be response to a response or Error
                              Descriptor in the message level
         mg008.105   gk    1. In case of MGC if association not done this value 
                              will be null
                           2. Remove function  mgChFillMgcoCommand as it is not
                              being used at all
                           3. Added the functionality to mgChHandleMgcoPrcTxnIndErr
                           4. if message is service change message send msg version as 1
                           5. Passing one more parameter peer control block
                           6. In mgTransmitSrvcChngReply mBuf is not containing
                              the header information
                           7. Handling for wild card context
                           8. ContextUpdate has seperate memory Control point
*********************************************************************91*/
