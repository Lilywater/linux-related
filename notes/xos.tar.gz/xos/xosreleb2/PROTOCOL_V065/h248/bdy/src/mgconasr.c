/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Megaco NAS RegExp file

     Type:     C source file

     Desc:     regular expressions for Megaco NAS packages

     File:     mgconasr.c

     Sid:      mgconasr.c@@/main/4 - Wed Mar 30 07:56:26 2005

     Prg:      nct

*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#ifdef GCP_MGCO

#ifdef GCP_PKG_MGCO_NAS_SUPPORT

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_mblk.h"       /* common event memory management */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_inet.h"       /* Inet header file */
#include "cm_tpt.h"        /* Transport  header file */
#include "cm_sdp.h"
#include "cm_dns.h"
#ifdef ZG
#include "cm_ftha.h"
#include "cm_psfft.h"
#endif /* ZG */
#include "mgt.h"

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_lib.x"        /* common library file */
#include "cm_inet.x"       /* Inet header file */
#include "cm_tpt.x"        /* Transport  header file */
#include "cm_sdp.x"
#ifdef ZG
#include "cm_ftha.x"
#include "cm_psfft.x"
#endif /* ZG */
#include "cm_abndb.x"
#include "cm_sdpdb.x"
#include "mgt.x"
#include "mgco_db.x"
#include "mgconasd.x"

/*
*
*       Fun:   mgMgcoRegExpEvtNameNas
*
*       Desc:  Description for the regular expression EvtNameNas
*                nasfail   = [Nn][Aa][Ss][Ff][Aa][Ii][Ll];
*                nasrel    = [Nn][Aa][Ss][Rr][Ee][Ll];
*              
*                nasfail   {return(MGT_PKG_NAS_EVT_NASFAIL);}
*                nasrel    {return(MGT_PKG_NAS_EVT_NASREL);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtNameNas
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtNameNas(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtNameNas)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy7;
   case 'R':   case 'r':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy12;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NAS_EVT_NASFAIL;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NAS_EVT_NASREL;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtNameNas */

/*
*
*       Fun:   mgMgcoRegExpEvtNameNasCtl
*
*       Desc:  Description for the regular expression EvtNameNasCtl
*                callreq   = [Cc][Aa][Ll][Ll][Rr][Ee][Qq];
*              
*                callreq   {return(MGT_PKG_NASCTL_EVT_CALLREQ);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtNameNasCtl
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtNameNasCtl(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtNameNasCtl)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Q':   case 'q':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASCTL_EVT_CALLREQ;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtNameNasCtl */

/*
*
*       Fun:   mgMgcoRegExpEvtNameNasIn
*
*       Desc:  Description for the regular expression EvtNameNasIn
*                nasfail   = [Nn][Aa][Ss][Ff][Aa][Ii][Ll];
*                nasrel    = [Nn][Aa][Ss][Rr][Ee][Ll];
*                authres   = [Aa][Uu][Tt][Hh][Rr][Ee][Ss];
*              
*                nasfail   {return(MGT_PKG_NAS_EVT_NASFAIL);}
*                nasrel    {return(MGT_PKG_NAS_EVT_NASREL);}
*                authres   {return(MGT_PKG_NASIN_EVT_AUTHRES);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtNameNasIn
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtNameNasIn(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtNameNasIn)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy4;
   case 'N':   case 'n':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy12;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASIN_EVT_AUTHRES;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy15;
   case 'R':   case 'r':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy20;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NAS_EVT_NASFAIL;
      goto yyReturn;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy21;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NAS_EVT_NASREL;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtNameNasIn */

/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherNasCtlCallReqPar
*
*       Desc:  Description for the regular expression ObsEvtOtherNasCtlCallReqPar
*                dialnum  = [Dd][Ii][Aa][Ll][Nn][Uu][Mm];
*                handle   = [Hh][Aa][Nn][Dd][Ll][Ee];
*              
*                dialnum   {return(MGT_PKG_NASCTL_EVT_CALLREQ_DIALNUM);}
*                handle    {return(MGT_PKG_NASCTL_EVT_CALLREQ_HANDLE);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasCtlCallReqPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasCtlCallReqPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherNasCtlCallReqPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy3;
   case 'H':   case 'h':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy11;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASCTL_EVT_CALLREQ_HANDLE;
      goto yyReturn;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASCTL_EVT_CALLREQ_DIALNUM;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherNasCtlCallReqPar */

/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherNasCtlCallReqType
*
*       Desc:  Description for the regular expression ObsEvtOtherNasCtlCallReqType
*                dialnum  = [Dd][Ii][Aa][Ll][Nn][Uu][Mm];
*                handle   = [Hh][Aa][Nn][Dd][Ll][Ee];
*              
*                known  = dialnum | handle;
*                all    = "*";
*                unk    = [A-Za-z0-9]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unk    {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasCtlCallReqType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasCtlCallReqType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherNasCtlCallReqType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':   case 'E':
   case 'F':
   case 'G':   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':   case 'e':
   case 'f':
   case 'g':   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'D':   case 'd':   goto yy5;
   case 'H':   case 'h':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy16;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy10;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy11;
   default:   goto yy9;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy12;
   default:   goto yy9;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy13;
   default:   goto yy9;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy14;
   default:   goto yy9;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy15;
   }
yy15:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy17;
   default:   goto yy9;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy18;
   default:   goto yy9;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy19;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy20;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy14;
   default:   goto yy9;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherNasCtlCallReqType */

/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherNasFailPar
*
*       Desc:  Description for the regular expression ObsEvtOtherNasFailPar
*                ec  = [Ee][Cc];
*              
*                ec  {return(MGT_PKG_NAS_EVT_NASFAIL_EC);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasFailPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasFailPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherNasFailPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NAS_EVT_NASFAIL_EC;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherNasFailPar */

/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherNasFailType
*
*       Desc:  Description for the regular expression ObsEvtOtherNasFailType
*                known  = [Ee][Cc];
*                all    = "*";
*                unk    = [A-Za-z0-9]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unk    {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasFailType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasFailType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherNasFailType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'E':   case 'e':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy9;
   default:   goto yy8;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy6;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy10;
   }
yy10:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherNasFailType */

/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherNasInAuthResPar
*
*       Desc:  Description for the regular expression ObsEvtOtherNasInAuthResPar
*                res       = [Rr][Ee][Ss];
*                dialnum   = [Dd][Ii][Aa][Ll][Nn][Uu][Mm];
*              
*                res       {return(MGT_PKG_NASIN_EVT_AUTHRES_RES);}
*                dialnum   {return(MGT_PKG_NASIN_EVT_AUTHRES_DIALNUM);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasInAuthResPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasInAuthResPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherNasInAuthResPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy4;
   case 'R':   case 'r':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy12;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASIN_EVT_AUTHRES_DIALNUM;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASIN_EVT_AUTHRES_RES;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherNasInAuthResPar */

/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherNasInAuthResType
*
*       Desc:  Description for the regular expression ObsEvtOtherNasInAuthResType
*                known  = [Rr][Ee][Ss] | [Dd][Ii][Aa][Ll][Nn][Uu][Mm];
*                all    = "*";
*                unk    = [A-Za-z0-9]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unk    {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasInAuthResType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasInAuthResType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherNasInAuthResType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'D':   case 'd':   goto yy7;
   case 'R':   case 'r':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy17;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy10;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy11;
   default:   goto yy9;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy12;
   default:   goto yy9;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy13;
   default:   goto yy9;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy14;
   default:   goto yy9;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy15;
   default:   goto yy9;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy16;
   }
yy16:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy15;
   default:   goto yy9;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherNasInAuthResType */

/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherNasRelPar
*
*       Desc:  Description for the regular expression ObsEvtOtherNasRelPar
*                reason = [Rr][Ee][Aa][Ss][Oo][Nn];
*              
*                reason {return(MGT_PKG_NAS_EVT_NASREL_REASON);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasRelPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasRelPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherNasRelPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NAS_EVT_NASREL_REASON;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherNasRelPar */

/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherNasRelType
*
*       Desc:  Description for the regular expression ObsEvtOtherNasRelType
*                reason = [Rr][Ee][Aa][Ss][Oo][Nn];
*                known  = reason;
*                all    = "*";
*                unk    = [A-Za-z0-9]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unk    {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasRelType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherNasRelType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherNasRelType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'R':   case 'r':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy9;
   default:   goto yy8;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy6;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy10;
   default:   goto yy8;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy11;
   default:   goto yy8;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy12;
   default:   goto yy8;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy13;
   default:   goto yy8;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy14;
   }
yy14:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherNasRelType */

/*
*
*       Fun:   mgMgcoRegExpPkgNasCtlEvtType
*
*       Desc:  Description for the regular expression PkgNasCtlEvtType
*                callreq   = [Cc][Aa][Ll][Ll][Rr][Ee][Qq];
*              
*                known     =  callreq;
*                all       =  "*";
*                unknown   =  [A-Za-z0-9]+;
*              
*                all       {return(MGT_GEN_TYPE_ALL);}
*                known     {return(MGT_GEN_TYPE_KNOWN);}
*                unknown   {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgNasCtlEvtType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgNasCtlEvtType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgNasCtlEvtType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'C':   case 'c':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy9;
   default:   goto yy8;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy6;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy10;
   default:   goto yy8;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy11;
   default:   goto yy8;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy12;
   default:   goto yy8;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy13;
   default:   goto yy8;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Q':   case 'q':   goto yy14;
   default:   goto yy8;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy15;
   }
yy15:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgNasCtlEvtType */

/*
*
*       Fun:   mgMgcoRegExpPkgNasEvtType
*
*       Desc:  Description for the regular expression PkgNasEvtType
*                nasfail   = [Nn][Aa][Ss][Ff][Aa][Ii][Ll];
*                nasrel    = [Nn][Aa][Ss][Rr][Ee][Ll];
*              
*                known     =  nasfail | nasrel;
*                all       =  "*";
*                unknown   =  [A-Za-z0-9]+;
*              
*                all       {return(MGT_GEN_TYPE_ALL);}
*                known     {return(MGT_GEN_TYPE_KNOWN);}
*                unknown   {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgNasEvtType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgNasEvtType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgNasEvtType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'N':   case 'n':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy9;
   default:   goto yy8;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy6;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy10;
   default:   goto yy8;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy11;
   case 'R':   case 'r':   goto yy12;
   default:   goto yy8;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy16;
   default:   goto yy8;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy13;
   default:   goto yy8;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy14;
   default:   goto yy8;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy15;
   }
yy15:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy17;
   default:   goto yy8;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy14;
   default:   goto yy8;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgNasEvtType */

/*
*
*       Fun:   mgMgcoRegExpPkgNasInEvtType
*
*       Desc:  Description for the regular expression PkgNasInEvtType
*                nasfail   = [Nn][Aa][Ss][Ff][Aa][Ii][Ll];
*                nasrel    = [Nn][Aa][Ss][Rr][Ee][Ll];
*                authres   = [Aa][Uu][Tt][Hh][Rr][Ee][Ss];
*              
*                known     =  nasfail | nasrel | authres;
*                all       =  "*";
*                unknown   =  [A-Za-z0-9]+;
*              
*                all       {return(MGT_GEN_TYPE_ALL);}
*                known     {return(MGT_GEN_TYPE_KNOWN);}
*                unknown   {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgNasInEvtType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgNasInEvtType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgNasInEvtType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'A':   case 'a':   goto yy7;
   case 'N':   case 'n':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy17;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy10;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy11;
   default:   goto yy9;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy12;
   default:   goto yy9;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy13;
   default:   goto yy9;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy14;
   default:   goto yy9;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy15;
   default:   goto yy9;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy16;
   }
yy16:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy18;
   default:   goto yy9;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy19;
   case 'R':   case 'r':   goto yy20;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy22;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy21;
   default:   goto yy9;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy15;
   default:   goto yy9;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy23;
   default:   goto yy9;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy15;
   default:   goto yy9;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgNasInEvtType */

/*
*
*       Fun:   mgMgcoRegExpPropParmNas
*
*       Desc:  Description for the regular expression PropParmNas
*                sessid   = [Ss][Ee][Ss][Ss][Ii][Dd];
*                conntyp  = [Cc][Oo][Nn][Nn][Tt][Yy][Pp];
*              
*                sessid    {return(MGT_PKG_NAS_PROP_SESSID);}
*                conntyp   {return(MGT_PKG_NAS_PROP_CONNTYP);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPropParmNas
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPropParmNas(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPropParmNas)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy4;
   case 'S':   case 's':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy12;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NAS_PROP_CONNTYP;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NAS_PROP_SESSID;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPropParmNas */

/*
*
*       Fun:   mgMgcoRegExpPropParmNasIn
*
*       Desc:  Description for the regular expression PropParmNasIn
*                sessid   = [Ss][Ee][Ss][Ss][Ii][Dd];
*                conntyp  = [Cc][Oo][Nn][Nn][Tt][Yy][Pp];
*                clgstat  = [Cc][Ll][Gg][Ss][Tt][Aa][Tt];
*                clgnum   = [Cc][Ll][Gg][Nn][Uu][Mm];
*                cldnum   = [Cc][Ll][Dd][Nn][Uu][Mm];
*              
*                sessid    {return(MGT_PKG_NAS_PROP_SESSID);}
*                conntyp   {return(MGT_PKG_NAS_PROP_CONNTYP);}
*                clgstat   {return(MGT_PKG_NASIN_PROP_CLGSTAT);}
*                clgnum    {return(MGT_PKG_NASIN_PROP_CLGNUM);}
*                cldnum    {return(MGT_PKG_NASIN_PROP_CLDNUM);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPropParmNasIn
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPropParmNasIn(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPropParmNasIn)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy4;
   case 'S':   case 's':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy28;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy5;
   case 'O':   case 'o':   goto yy6;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy14;
   case 'G':   case 'g':   goto yy13;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NAS_PROP_CONNTYP;
      goto yyReturn;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy19;
   case 'S':   case 's':   goto yy20;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASIN_PROP_CLDNUM;
      goto yyReturn;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy25;
   default:   goto yyErr;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy21;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy22;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASIN_PROP_CLGSTAT;
      goto yyReturn;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy26;
   default:   goto yyErr;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASIN_PROP_CLGNUM;
      goto yyReturn;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy29;
   default:   goto yyErr;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy30;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy31;
   default:   goto yyErr;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy32;
   default:   goto yyErr;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NAS_PROP_SESSID;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPropParmNasIn */

/*
*
*       Fun:   mgMgcoRegExpPropParmNasOut
*
*       Desc:  Description for the regular expression PropParmNasOut
*                sessid   = [Ss][Ee][Ss][Ss][Ii][Dd];
*                conntyp  = [Cc][Oo][Nn][Nn][Tt][Yy][Pp];
*                dialnum  = [Dd][Ii][Aa][Ll][Nn][Uu][Mm];
*                handle   = [Hh][Aa][Nn][Dd][Ll][Ee];
*              
*                sessid    {return(MGT_PKG_NAS_PROP_SESSID);}
*                conntyp   {return(MGT_PKG_NAS_PROP_CONNTYP);}
*                dialnum   {return(MGT_PKG_NASOUT_PROP_DIALNUM);}
*                handle    {return(MGT_PKG_NASOUT_PROP_HANDLE);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPropParmNasOut
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPropParmNasOut(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPropParmNasOut)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy4;
   case 'D':   case 'd':   goto yy5;
   case 'H':   case 'h':   goto yy6;
   case 'S':   case 's':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy27;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy20;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy13;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASOUT_PROP_HANDLE;
      goto yyReturn;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASOUT_PROP_DIALNUM;
      goto yyReturn;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy21;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy22;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy24;
   default:   goto yyErr;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy25;
   default:   goto yyErr;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NAS_PROP_CONNTYP;
      goto yyReturn;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy28;
   default:   goto yyErr;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy29;
   default:   goto yyErr;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy30;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy31;
   default:   goto yyErr;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NAS_PROP_SESSID;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPropParmNasOut */

/*
*
*       Fun:   mgMgcoRegExpPropParmNasRoot
*
*       Desc:  Description for the regular expression PropParmNasRoot
*                nampat          = [Nn][Aa][Mm][Pp][Aa][Tt];
*                ctlnam          = [Cc][Tt][Ll][Nn][Aa][Mm];
*                avalmodems      = [Aa][Vv][Aa][Ll][Mm][Oo][Dd][Ee][Mm][Ss];
*                nasaddtime      = [Nn][Aa][Ss][Aa][Dd][Dd][Tt][Ii][Mm][Ee];
*              
*                nampat          {return(MGT_PKG_NASROOT_PROP_NAMPAT);}
*                ctlnam          {return(MGT_PKG_NASROOT_PROP_CTLNAM);}
*                avalmodems      {return(MGT_PKG_NASROOT_PROP_AVALMODEMS);}
*                nasaddtime      {return(MGT_PKG_NASROOT_PROP_NASADDTIME);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPropParmNasRoot
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPropParmNasRoot(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPropParmNasRoot)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy5;
   case 'C':   case 'c':   goto yy4;
   case 'N':   case 'n':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy22;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy16;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASROOT_PROP_AVALMODEMS;
      goto yyReturn;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy19;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy20;
   default:   goto yyErr;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASROOT_PROP_CTLNAM;
      goto yyReturn;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy23;
   case 'S':   case 's':   goto yy24;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy33;
   default:   goto yyErr;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy25;
   default:   goto yyErr;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy26;
   default:   goto yyErr;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy27;
   default:   goto yyErr;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy28;
   default:   goto yyErr;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy29;
   default:   goto yyErr;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy30;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy31;
   default:   goto yyErr;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASROOT_PROP_NASADDTIME;
      goto yyReturn;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy34;
   default:   goto yyErr;
   }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy35;
   default:   goto yyErr;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NASROOT_PROP_NAMPAT;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPropParmNasRoot */

/*
*
*       Fun:   mgMgcoRegExpPkgNasInPropType
*
*       Desc:  Description for the regular expression PkgNasInPropType
*                sessid   = [Ss][Ee][Ss][Ss][Ii][Dd];
*                conntyp  = [Cc][Oo][Nn][Nn][Tt][Yy][Pp];
*                clgstat  = [Cc][Ll][Gg][Ss][Tt][Aa][Tt];
*                clgnum   = [Cc][Ll][Gg][Nn][Uu][Mm];
*                cldnum   = [Cc][Ll][Dd][Nn][Uu][Mm];
*              
*               known = sessid | conntyp | clgstat | clgnum | cldnum;
*               all   = "*";
*               unk   = [0-9A-Za-z]+;
*              
*               all     {return(MGT_GEN_TYPE_ALL);}
*               known   {return(MGT_GEN_TYPE_KNOWN);}
*               unk     {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgNasInPropType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgNasInPropType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgNasInPropType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'C':   case 'c':   goto yy7;
   case 'S':   case 's':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy27;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy10;
   case 'O':   case 'o':   goto yy11;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy19;
   case 'G':   case 'g':   goto yy18;
   default:   goto yy9;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy12;
   default:   goto yy9;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy13;
   default:   goto yy9;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy14;
   default:   goto yy9;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy15;
   default:   goto yy9;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy16;
   default:   goto yy9;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy17;
   }
yy17:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy22;
   case 'S':   case 's':   goto yy23;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy20;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy21;
   default:   goto yy9;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy16;
   default:   goto yy9;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy26;
   default:   goto yy9;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy24;
   default:   goto yy9;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy25;
   default:   goto yy9;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy16;
   default:   goto yy9;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy16;
   default:   goto yy9;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy28;
   default:   goto yy9;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy29;
   default:   goto yy9;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy30;
   default:   goto yy9;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy16;
   default:   goto yy9;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgNasInPropType */

/*
*
*       Fun:   mgMgcoRegExpPkgNasOutPropType
*
*       Desc:  Description for the regular expression PkgNasOutPropType
*                sessid   = [Ss][Ee][Ss][Ss][Ii][Dd];
*                conntyp  = [Cc][Oo][Nn][Nn][Tt][Yy][Pp];
*                dialnum  = [Dd][Ii][Aa][Ll][Nn][Uu][Mm];
*                handle   = [Hh][Aa][Nn][Dd][Ll][Ee];
*              
*               known = sessid | conntyp | dialnum | handle;
*               all   = "*";
*               unk   = [0-9A-Za-z]+;
*              
*               all     {return(MGT_GEN_TYPE_ALL);}
*               known   {return(MGT_GEN_TYPE_KNOWN);}
*               unk     {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgNasOutPropType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgNasOutPropType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgNasOutPropType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':   case 'E':
   case 'F':
   case 'G':   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':   case 'e':
   case 'f':
   case 'g':   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   case 'C':   case 'c':   goto yy7;
   case 'D':   case 'd':   goto yy8;
   case 'H':   case 'h':   goto yy9;
   case 'S':   case 's':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy28;
   default:   goto yy11;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy23;
   default:   goto yy11;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy18;
   default:   goto yy11;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy12;
   default:   goto yy11;
   }
yy10:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy11:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   default:   goto yy6;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy13;
   default:   goto yy11;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy14;
   default:   goto yy11;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy15;
   default:   goto yy11;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy16;
   default:   goto yy11;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   default:   goto yy17;
   }
yy17:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy19;
   default:   goto yy11;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy20;
   default:   goto yy11;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy21;
   default:   goto yy11;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy22;
   default:   goto yy11;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy16;
   default:   goto yy11;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy24;
   default:   goto yy11;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy25;
   default:   goto yy11;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy26;
   default:   goto yy11;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy27;
   default:   goto yy11;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy16;
   default:   goto yy11;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy29;
   default:   goto yy11;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy30;
   default:   goto yy11;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy31;
   default:   goto yy11;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy16;
   default:   goto yy11;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgNasOutPropType */

/*
*
*       Fun:   mgMgcoRegExpPkgNasPropType
*
*       Desc:  Description for the regular expression PkgNasPropType
*                sessid   = [Ss][Ee][Ss][Ss][Ii][Dd];
*                conntyp  = [Cc][Oo][Nn][Nn][Tt][Yy][Pp];
*              
*               known = sessid | conntyp;
*               all   = "*";
*               unk   = [0-9A-Za-z]+;
*              
*               all     {return(MGT_GEN_TYPE_ALL);}
*               known   {return(MGT_GEN_TYPE_KNOWN);}
*               unk     {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgNasPropType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgNasPropType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgNasPropType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'C':   case 'c':   goto yy7;
   case 'S':   case 's':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy17;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy10;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy11;
   default:   goto yy9;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy12;
   default:   goto yy9;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy13;
   default:   goto yy9;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy14;
   default:   goto yy9;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy15;
   default:   goto yy9;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy16;
   }
yy16:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy18;
   default:   goto yy9;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy19;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy20;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy15;
   default:   goto yy9;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgNasPropType */

/*
*
*       Fun:   mgMgcoRegExpPkgNasRootPropType
*
*       Desc:  Description for the regular expression PkgNasRootPropType
*                nampat          = [Nn][Aa][Mm][Pp][Aa][Tt];
*                ctlnam          = [Cc][Tt][Ll][Nn][Aa][Mm];
*                avalmodems      = [Aa][Vv][Aa][Ll][Mm][Oo][Dd][Ee][Mm][Ss];
*                nasaddtime      = [Nn][Aa][Ss][Aa][Dd][Dd][Tt][Ii][Mm][Ee];
*              
*               known = nampat | ctlnam | avalmodems | nasaddtime;
*               all   = "*";
*               unk   = [0-9A-Za-z]+;
*              
*               all     {return(MGT_GEN_TYPE_ALL);}
*               known   {return(MGT_GEN_TYPE_KNOWN);}
*               unk     {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgconasr.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgNasRootPropType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgNasRootPropType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgNasRootPropType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   case 'A':   case 'a':   goto yy8;
   case 'C':   case 'c':   goto yy7;
   case 'N':   case 'n':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy25;
   default:   goto yy10;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy21;
   default:   goto yy10;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy11;
   default:   goto yy10;
   }
yy9:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy10:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yy6;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy12;
   default:   goto yy10;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy13;
   default:   goto yy10;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy14;
   default:   goto yy10;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy15;
   default:   goto yy10;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy16;
   default:   goto yy10;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy17;
   default:   goto yy10;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy18;
   default:   goto yy10;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy19;
   default:   goto yy10;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yy20;
   }
yy20:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy22;
   default:   goto yy10;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy23;
   default:   goto yy10;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy24;
   default:   goto yy10;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy19;
   default:   goto yy10;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy26;
   case 'S':   case 's':   goto yy27;
   default:   goto yy10;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy34;
   default:   goto yy10;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy28;
   default:   goto yy10;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy29;
   default:   goto yy10;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy30;
   default:   goto yy10;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy31;
   default:   goto yy10;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy32;
   default:   goto yy10;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy33;
   default:   goto yy10;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy19;
   default:   goto yy10;
   }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy35;
   default:   goto yy10;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy19;
   default:   goto yy10;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgNasRootPropType */

#endif /* GCP_PKG_MGCO_NAS_SUPPORT */

#endif /* GCP_MGCO */

/********************************************************************30**

         End of file:     mgconasr.c@@/main/4 - Wed Mar 30 07:56:26 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      nct  1. Initial version
/main/2      ---      ra   1. GCP 1.3 release
/main/2    mg003.103  ra   1. Changed ALL function definations to return S16
                              instead of S8. Changed the type of yyret type
                              variables to S16.
/main/3      ---      ka   1. Changes for Release v 1.4                              
/main/4      ---      pk   1. GCP 1.5 release
*********************************************************************91*/
