/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     GCP - Management Interface Module.

     Type:     C source file

     Desc:     C source code for MGCP layer layer management
               primitives supplied by TRILLIUM

     File:     mg_mi.c

     Sid:      mp_mi.c@@/main/mgcp_rel_1.5_mnt/6 - Tue Jun  7 16:29:44 2005

     Prg:      rrp

*********************************************************************21*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "cm5.h"           /* common timers */
#include "cm_hash.h"       /* common hash list */
#include "cm_inet.h"       /* common INET */
#include "cm_llist.h"      /* common linked list */
#include "cm_mblk.h"       /* memory management */
#include "cm_tkns.h"       /* common tokens */
#include "cm_tpt.h"        /* common transport defines */
#include "hit.h"           /* HI layer */
#include "cm_sdp.h"        /* SDP related constants */
#include "cm_dns.h"        /* common DNS library */
#include "cm_abnf.h"       /* Common ABNF Encode/Decode Library */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include  "cm_ss7.h"       /* Common SS7 Defines */
#include  "snt.h"          /* MTP3 Interface Defines */
#endif   /* GCP_PROV_MTP3 */



#include "mgt.h"           /* MGT defines */
#include "lmg.h"           /* MG layer management defines */
#include "mg.h"            /* MG layer defines */
#include "mg_err.h"        /* MG error defines */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */

#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_inet.x"       /* common INET */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_tpt.x"        /* common transport types */
#include "hit.x"           /* HI layer */
#include "cm_sdp.x"        /* SDP related types */
#include "cm_dns.x"        /* common dns library */
#include "cm_abnf.x"       /* Common ABNF Encode/Decode Library */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3 
#include  "cm_ss7.x"       /* Common SS7 Structure */
#include  "snt.x"          /* MTP3 Interface Structure */
#endif    /* GCP_PROV_MTP3 */



#include "mgt.x"           /* MGT types */
#include "lmg.x"           /* MG layer management types */
#include "mg.x"            /* MG layer types */
#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */




/******************************************************************************/
/*                   Forward References                                       */
/******************************************************************************/


PRIVATE U16 mgCfgGen ARGS ((
        MgGenCfg        *cfg           /* General Configuration Structure */
      ));

PRIVATE U16 mgAllocSsapLst ARGS ((
        MgGenCfg        *cfg           /* General Configuration Structure */
      ));


PRIVATE U16 mgAllocTsapLst ARGS ((
        MgGenCfg        *cfg           /* General Configuration Structure */
      ));


#ifdef GCP_USE_PEERID
PRIVATE U16 mgAllocPeerLst ARGS((
        MgGenCfg        *cfg           /* General Configuration Structure */
      ));
#endif /* GCP_USE_PEERID */

PRIVATE U16 mgCfgTsap ARGS ((
        MgTSAPCfg       *cfg           /* TSAP Configuration Structure */
      ));

PRIVATE U16 mgAllocSrvrLst ARGS((
        MgTSAPCfg        *cfg,          /* General Configuration Structure */
        MgTSAPCb         *tsap          /* TSAP CB */
      ));

PRIVATE U16 mgCfgSsap ARGS ((
        MgSSAPCfg       *cfg           /* SSAP Configuration Structure */
      ));

PRIVATE U16 mgCfgGcpEnt ARGS ((
        MgGcpEntCfg     *cfg           /* Peer Configuration Structure */
      ));

PRIVATE U16 mgFillPeerInitInfo ARGS ((
        MgPeerCfg       *peerCfg,      /* Peer Configuration Structure */
        MgPeerInitInfo  *peerInitInfo  /* Peer Initialisation Structure */
      ));

PRIVATE U16 mgCfgTptServer ARGS ((
        MgTptSrvrCfg    *cfg           /* Transport Server Config Structure */
      ));


#ifdef    GCP_PROV_SCTP
PRIVATE U16 mgEndpCfg      ARGS ((
        MgEndpLstCfg    *cfg           /* end pont Config function */
      ));
#endif    /* GCP_PROV_SCTP */


PRIVATE U16  mgCntrlGen ARGS ((
        MgCntrl         *cntrl         /* Control Request Structure */
      ));

PRIVATE U16 mgCntrlTsap ARGS ((
        MgCntrl         *cntrl,        /* TSAP Control Request Structure */
        MgTSAPCb        *tsap          /* TSAP Control block pointer     */
      ));

PRIVATE U16 mgCntrlSsap ARGS ((
        MgCntrl         *cntrl         /* SSAP Control Request Structure */
      ));

PRIVATE U16 mgCntrlGrpSsap ARGS ((
        MgCntrl         *cntrl         /* SSAP Group ControlRequest Structure */
      ));



PRIVATE U16 mgCntrlGrpTsap ARGS ((
        MgCntrl         *cntrl         /* TSAP Group ControlRequest Structure */
      ));



PRIVATE U16 mgCntrlPeer ARGS ((
        MgCntrl         *cntrl         /* Peer Control Request Structure */
      ));

PRIVATE U16 mgCntrlTptServer ARGS ((
        MgCntrl         *cntrl         /* Transport Server Cntrl Req */
      ));


#ifdef    GCP_PROV_SCTP
/* following new function defined for SCTP support */

PRIVATE U16 mgCntrlEndp      ARGS ((
        MgCntrl         *cntrl         /* End point Cntrl Req */
      ));

PRIVATE U16 mgGetSctpEpSta ARGS((
   MgSctpEpSta        *mgSctpEpSta
   ));

#endif    /* GCP_PROV_SCTP */


PRIVATE U16 mgCntrlAllSaps   ARGS((
        MgCntrl            *cntrl      /* Control Structure */
      ));

PRIVATE U16 mgSetPeerSts ARGS((
        MgPeerEntSts    *peerEntSts,   /* Peer Statistics Structure */
        Action          action         /* Action */
      ));

PRIVATE U16 mgGetTsapSta ARGS ((
        MgTSAPSta       *tSAPSta,      /* TSAP Status */
        MgTSAPCb        *tsap          /* TSAP CB ptr */
      ));

PRIVATE U16 mgGetSsapSta ARGS((
        MgMngmt         *sta,          /* Management Status Structure */
        Pst             *post          /* Post Structure */
      ));

PRIVATE U16 mgGetPeerSta ARGS((
        MgPeerSta       *peerSta       /* Peer Status Structure */
      ));

PRIVATE U16 mgGetTptSrvrSta ARGS((
        MgTptSrvSta     *tptSrvrSta    /* Transport Server Status */
      ));

PRIVATE U16 mgResolvePeer ARGS ((
        MgPeerCb        *peer         /* Peer Control Block */
      ));

PRIVATE U16 mgCntrlTsapTrc ARGS ((
        MgTrcCntrl      *trcCntrl,     /* Trace Control */
        U16             action,        /* Action */
        MgTSAPCb        *tsap          /* TSAP Cb pointer */
      ));

PRIVATE U16 mgDisableTsap ARGS ((
        MgTSAPCb        *tsapCb,       /* TSAP Control Block */
        U16             action         /* Action */
      ));

PRIVATE U16 mgRemTsapSrvrs ARGS((
        MgTSAPCb        *tsapCb,       /* TSAP Control Block */
        Bool            delSrvr        /* Delete Servers ? */
      ));

PRIVATE U16 mgDeleteTsap ARGS((
        MgTSAPCb        *tsapCb        /* TSAP Control Block */
      ));

PRIVATE U16 mgEnableTsap ARGS ((
        MgTSAPCb        *tsapCb,       /* TSAP Control Block */
        U16             action         /* Action */
      ));

PUBLIC  U16 mgEnableSsap ARGS ((
        MgSSAPCb        *ssap          /* SSAP Control Block */
      ));

PRIVATE U16 mgUbndDisSsap ARGS ((
        MgSSAPCb        *ssap          /* SSAP Control Block */
      ));

PRIVATE U16 mgDeleteSsap  ARGS((
        MgSSAPCb        *ssap          /* SSAP Control Block */
      ));

/* mg004.105: Changed prototype from MgTptCntrl to CmTptAddr */
PRIVATE MgTptSrvr * mgFindTptSrvr ARGS((
        CmTptAddr          *srvrAddr
      ));


#ifdef CM_DNS_LIB
PRIVATE U16 mgSetTsapSts  ARGS((
        MgTSAPSts       *tsapSts,      /* TSAP Statistics Structure */
        MgTSAPSts       *stsReq,       /* TSAP Statistics Structure */
        Action          action         /* action to be done */
      ));

PRIVATE S16 mgSetUpDns ARGS((
        MgTSAPCb           *tsap,      /* TSAP Control Block */
        Bool               byCfg       /* Thru configuration/Cntrl? */
      ));
#endif /* CM_DNS_LIB */


#ifdef GCP_MG
#ifdef GCP_MGCO
PRIVATE U16 mgCntrlMG ARGS((
        MgCntrl         *cntrl         /* Media Gateway Control Request */
      ));
#endif /* GCP_MGCO */

#endif /* GCP_MG */

#ifdef GCP_MGCO
#ifdef GCP_MGC
PRIVATE U16  mgCntrlMGC ARGS ((
        MgCntrl         *cntrl         /* MGC Control Request */
      ));
#endif /* GCP_MGC */
#endif /* GCP_MGCO */


/*****************************************************************************/
/*                    MGCP Specific Functions                                */
/*****************************************************************************/

#ifdef GCP_MGCP
PRIVATE U16 mgGetMgcpSrvrType ARGS((
        MgSrvrInitInfo  *srvrInitInfo, /* Server Initialisation Info */
        MgSrvrCfg       *srvrCfg       /* Server Configuration Structure */
      ));
#endif /* GCP_MGCP */

/*****************************************************************************/
/*                    MEGACO Specific Functions                              */
/*****************************************************************************/

#ifdef GCP_MGCO

PRIVATE U16 mgGetMgcoSrvrType  ARGS ((
        MgSrvrInitInfo  *srvrInitInfo, /* Server Initialisation Info */
        MgSrvrCfg       *srvrCfg       /* Server Configuration Structure */
      ));

#ifdef GCP_MGC

#ifdef ZG
PRIVATE U16 mgCfgMtdGcpEnt ARGS((
        MgMtdGcpEntCfg        *cfg             /* Peer Configuration Structure */
      ));
#endif /* ZG */
#endif /* GCP_MGC */

#endif /*GCP_MGCO */

/* external functions */
PUBLIC S16  mgGetSId  ARGS ((
       SystemId         *sId           /* System Identifier */
      ));

#ifdef MG_FTHA
PRIVATE Void mgSendShCfm ARGS((
        U16                status,     /* confirm status */
        U16                reason,     /* failure reason */
        Pst                *srcPst,    /* incoming Pst */
        ShtCntrlReqEvnt    *req,       /* system agent control request */
        ShtCntrlCfmEvnt    *cfm        /* system agent control confirm */
      ));
#endif /* MG_FTHA */

/*****************************************************************************/
/*                    RUG Specific Functions                                */
/*****************************************************************************/

#ifdef MG_RUG

#ifdef GCP_MGCO
PRIVATE Void mgSetDefMgcoCfgVal ARGS(( 
        MgMngmt            *cfg                /* configuration structure */
        ));
PRIVATE Void mgSetDefMgcoCntrlVal ARGS((  
        MgMngmt            *cntrl                /* control structure */
        ));
#endif /* GCP_MGCO */

#ifdef GCP_MGCP 
PRIVATE Void mgSetDefMgcpCfgVal ARGS(( 
        MgMngmt            *cfg                /* configuration structure */
        ));
PRIVATE Void mgSetDefMgcpCntrlVal ARGS(( 
        MgMngmt            *cntrl                /* control structure */
        ));
#endif /* GCP_MGCP */

#endif /* MG_RUG */



/******************************************************************************/
/*                               MACROS                                       */
/******************************************************************************/

#ifdef MG_RUG
#define MG_FREE_RUG_VERINFO                                               \
{                                                                         \
   Size   rugMem;                                                         \
                                                                          \
   rugMem = (mgCb.genCfg.maxSSaps + 1);                                   \
   mgDeAlloc((Data *)(mgCb.verInfo.intfInfo), rugMem);                    \
}
#endif /* MG_RUG */

/* mg002.105: TCR 21 - GCP - Adding the macros according to TCR 21: 2.1.2.1 */
#define MG_MI_VALIDATE_TSAP_ACTION(s, i, a, r)                            \
{                                                                         \
   if (i >= mgCb.genCfg.maxTSaps)                                         \
   {                                                                      \
      MGLOGERROR(ERRCLS_INT_PAR, EMG163, (ErrVal)0, "Invalid TSAP ID.");  \
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);                               \
   }                                                                      \
   else s = *(mgCb.tSAPLst + i);                                          \
   if (s == NULLP)                                                        \
   {                                                                      \
      MGLOGERROR(ERRCLS_INT_PAR, EMG163, (ErrVal)0, "Invalid TSAP ID.");  \
      if (a == ADEL)                                                      \
      {                                                                   \
         RETVALUE(LCM_REASON_NOT_APPL);                                   \
      }                                                                   \
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);                               \
   }                                                                      \
}

#define MG_MI_VALIDATE_SSAP_ACTION(s, i, a, r)                            \
{                                                                         \
   if (i >= mgCb.genCfg.maxSSaps)                                         \
   {                                                                      \
      MGLOGERROR(ERRCLS_INT_PAR, EMG163, (ErrVal)0, "Invalid SSAP ID.");  \
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);                               \
   }                                                                      \
   else s = *(mgCb.sSAPLst + i);                                          \
   if (s == NULLP)                                                        \
   {                                                                      \
      MGLOGERROR(ERRCLS_INT_PAR, EMG163, (ErrVal)0, "Invalid SSAP ID.");  \
      if (a == ADEL)                                                      \
      {                                                                   \
         RETVALUE(LCM_REASON_NOT_APPL);                                   \
      }                                                                   \
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);                               \
   }                                                                      \
}

#define MG_MI_VALIDATE_SSAP(s, i, r)                                      \
{                                                                         \
   if (i >= mgCb.genCfg.maxSSaps) s = NULLP;                              \
   else s = *(mgCb.sSAPLst + i);                                          \
   if (s == NULLP)                                                        \
   {                                                                      \
      MGLOGERROR(ERRCLS_INT_PAR, EMG163, (ErrVal)0, "Invalid SSAP ID.");  \
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);                               \
   }                                                                      \
}

#ifdef ZG
#ifdef    GCP_PROV_MTP3
#ifdef    GCP_PROV_SCTP

/* start timer should return S16 to handle error */
#define MG_MI_ISSUE_BNDREQ(tsapCb)                                        \
{                                                                         \
    Pst      userPst;                                                     \
    cmMemcpy((U8 *)&userPst, (U8 *)&tsapCb->spPst, sizeof(Pst));          \
    userPst.srcProcId = CMFTHA_RES_RSETID;                                \
    if (tsapCb->tsapCfg.bndTmrCfg.enb == TRUE)                            \
    {                                                                     \
       (Void) mgStartTmr (MG_BNDREQ_TMR, tsapCb->tsapCfg.bndTmrCfg.val,   \
                          (PTR) tsapCb, &tsapCb->bndTmr);                 \
    }                                                                     \
                                                                          \
    if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_TUCL)                   \
          (Void) MgLiHitBndReq (&userPst, tsapCb->tsapCfg.tSAPId,   \
                                tsapCb->tsapCfg.spId);                    \
    else if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_MTP3)              \
          (Void) MgLiSntBndReq (&userPst, tsapCb->tsapCfg.tSAPId,   \
                                tsapCb->tsapCfg.spId,tsapCb->sInfo);      \
    else                                                                  \
          (Void) MgLiSctBndReq (&userPst, tsapCb->tsapCfg.tSAPId,   \
                                tsapCb->tsapCfg.spId);                    \
}                                                                         \

#else  /* SCTP */

/* start timer should return S16 to handle error */
#define MG_MI_ISSUE_BNDREQ(tsapCb)                                        \
{                                                                         \
    Pst      userPst;                                                     \
    cmMemcpy((U8 *)&userPst, (U8 *)&tsapCb->spPst, sizeof(Pst));          \
    userPst.srcProcId = CMFTHA_RES_RSETID;                                \
    if (tsapCb->tsapCfg.bndTmrCfg.enb == TRUE)                            \
    {                                                                     \
       (Void) mgStartTmr (MG_BNDREQ_TMR, tsapCb->tsapCfg.bndTmrCfg.val,   \
                          (PTR) tsapCb, &tsapCb->bndTmr);                 \
    }                                                                     \
   if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_MTP3)                    \
          (Void) MgLiSntBndReq (&userPst, tsapCb->tsapCfg.tSAPId,   \
                                tsapCb->tsapCfg.spId,tsapCb->sInfo);      \
   else                                                                   \
                                                                          \
    (Void) MgLiHitBndReq (&userPst, tsapCb->tsapCfg.tSAPId,         \
                          tsapCb->tsapCfg.spId);                          \
}

#endif    /* GCP_PROV_SCTP */
#else     /* GCP_PROV_MTP3 */


#ifdef    GCP_PROV_SCTP

/* start timer should return S16 to handle error */
#define MG_MI_ISSUE_BNDREQ(tsapCb)                                        \
{                                                                         \
    Pst      userPst;                                                     \
    cmMemcpy((U8 *)&userPst, (U8 *)&tsapCb->spPst, sizeof(Pst));          \
    userPst.srcProcId = CMFTHA_RES_RSETID;                                \
    if (tsapCb->tsapCfg.bndTmrCfg.enb == TRUE)                            \
    {                                                                     \
       (Void) mgStartTmr (MG_BNDREQ_TMR, tsapCb->tsapCfg.bndTmrCfg.val,   \
                          (PTR) tsapCb, &tsapCb->bndTmr);                 \
    }                                                                     \
                                                                          \
    if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_TUCL)                   \
          (Void) MgLiHitBndReq (&userPst, tsapCb->tsapCfg.tSAPId,   \
                                tsapCb->tsapCfg.spId);                    \
    else                                                                  \
          (Void) MgLiSctBndReq (&userPst, tsapCb->tsapCfg.tSAPId,   \
                                tsapCb->tsapCfg.spId);                    \
}

#else

/* start timer should return S16 to handle error */
#define MG_MI_ISSUE_BNDREQ(tsapCb)                                        \
{                                                                         \
    Pst      userPst;                                                     \
    cmMemcpy((U8 *)&userPst, (U8 *)&tsapCb->spPst, sizeof(Pst));          \
    userPst.srcProcId = CMFTHA_RES_RSETID;                                \
    if (tsapCb->tsapCfg.bndTmrCfg.enb == TRUE)                            \
    {                                                                     \
       (Void) mgStartTmr (MG_BNDREQ_TMR, tsapCb->tsapCfg.bndTmrCfg.val,   \
                          (PTR) tsapCb, &tsapCb->bndTmr);                 \
    }                                                                     \
                                                                          \
    (Void) MgLiHitBndReq (&userPst, tsapCb->tsapCfg.tSAPId,         \
                          tsapCb->tsapCfg.spId);                          \
}

#endif    /* GCP_PROV_SCTP */
#endif    /* GCP_PROV_MTP3 */

#else /* ZG */
#ifdef    GCP_PROV_MTP3
#ifdef    GCP_PROV_SCTP

/* start timer should return S16 to handle error */
#define MG_MI_ISSUE_BNDREQ(tsapCb)                                        \
{                                                                         \
    if (tsapCb->tsapCfg.bndTmrCfg.enb == TRUE)                            \
    {                                                                     \
       (Void) mgStartTmr (MG_BNDREQ_TMR, tsapCb->tsapCfg.bndTmrCfg.val,   \
                          (PTR) tsapCb, &tsapCb->bndTmr);                 \
    }                                                                     \
                                                                          \
    if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_TUCL)                   \
          (Void) MgLiHitBndReq (&tsapCb->spPst, tsapCb->tsapCfg.tSAPId,   \
                                tsapCb->tsapCfg.spId);                    \
    else if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_MTP3)              \
          (Void) MgLiSntBndReq (&tsapCb->spPst, tsapCb->tsapCfg.tSAPId,   \
                                tsapCb->tsapCfg.spId,tsapCb->sInfo);      \
    else                                                                  \
          (Void) MgLiSctBndReq (&tsapCb->spPst, tsapCb->tsapCfg.tSAPId,   \
                                tsapCb->tsapCfg.spId);                    \
}                                                                         \

#else  /* SCTP */

/* start timer should return S16 to handle error */
#define MG_MI_ISSUE_BNDREQ(tsapCb)                                        \
{                                                                         \
    if (tsapCb->tsapCfg.bndTmrCfg.enb == TRUE)                            \
    {                                                                     \
       (Void) mgStartTmr (MG_BNDREQ_TMR, tsapCb->tsapCfg.bndTmrCfg.val,   \
                          (PTR) tsapCb, &tsapCb->bndTmr);                 \
    }                                                                     \
   if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_MTP3)                    \
          (Void) MgLiSntBndReq (&tsapCb->spPst, tsapCb->tsapCfg.tSAPId,   \
                                tsapCb->tsapCfg.spId,tsapCb->sInfo);      \
   else                                                                   \
                                                                          \
    (Void) MgLiHitBndReq (&tsapCb->spPst, tsapCb->tsapCfg.tSAPId,         \
                          tsapCb->tsapCfg.spId);                          \
}

#endif    /* GCP_PROV_SCTP */
#else     /* GCP_PROV_MTP3 */


#ifdef    GCP_PROV_SCTP

/* start timer should return S16 to handle error */
#define MG_MI_ISSUE_BNDREQ(tsapCb)                                        \
{                                                                         \
    if (tsapCb->tsapCfg.bndTmrCfg.enb == TRUE)                            \
    {                                                                     \
       (Void) mgStartTmr (MG_BNDREQ_TMR, tsapCb->tsapCfg.bndTmrCfg.val,   \
                          (PTR) tsapCb, &tsapCb->bndTmr);                 \
    }                                                                     \
                                                                          \
    if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_TUCL)                   \
          (Void) MgLiHitBndReq (&tsapCb->spPst, tsapCb->tsapCfg.tSAPId,   \
                                tsapCb->tsapCfg.spId);                    \
    else                                                                  \
          (Void) MgLiSctBndReq (&tsapCb->spPst, tsapCb->tsapCfg.tSAPId,   \
                                tsapCb->tsapCfg.spId);                    \
}

#else

/* start timer should return S16 to handle error */
#define MG_MI_ISSUE_BNDREQ(tsapCb)                                        \
{                                                                         \
    if (tsapCb->tsapCfg.bndTmrCfg.enb == TRUE)                            \
    {                                                                     \
       (Void) mgStartTmr (MG_BNDREQ_TMR, tsapCb->tsapCfg.bndTmrCfg.val,   \
                          (PTR) tsapCb, &tsapCb->bndTmr);                 \
    }                                                                     \
                                                                          \
    (Void) MgLiHitBndReq (&tsapCb->spPst, tsapCb->tsapCfg.tSAPId,         \
                          tsapCb->tsapCfg.spId);                          \
}

#endif    /* GCP_PROV_SCTP */
#endif    /* GCP_PROV_MTP3 */

#endif /* ZG */


#define MG_MI_MAX_TXN_SIZE                                                \
   ((sizeof(MgTxTransIdEnt) > sizeof(MgRxTransIdEnt)) ?                   \
   sizeof(MgTxTransIdEnt) : sizeof(MgRxTransIdEnt))


#define MG_MI_RET_CFG_ERR(_reason)                                        \
{                                                                         \
   /* Deinitialise cm_inet library */                                     \
   cmInetDeInit();                                                        \
   SPutSMem(mgCb.init.region, mgCb.init.pool);                            \
   RETVALUE(_reason);                                                     \
}


#ifdef    GCP_PROV_SCTP
#define MG_REM_ALLOC_SSAP_MEM                                             \
{                                                                         \
   mgDeAlloc((Data *)mgCb.sSAPLst,                                        \
              (mgCb.genCfg.maxSSaps * sizeof(MgSSAPCb *)));               \
                                                                          \
   mgDeAlloc((Data *)mgCb.tSAPLst,                                        \
              (mgCb.genCfg.maxTSaps * sizeof(MgTSAPCb *)));               \
                                                                          \
   mgDeinitIpAddrLst();                                                   \
   cmHashListDeinit(&(mgCb.peerNameLst));                                 \
   MG_MI_RET_CFG_ERR(LCM_REASON_MEM_NOAVAIL);                             \
}
#else
#define MG_REM_ALLOC_SSAP_MEM                                             \
{                                                                         \
   mgDeAlloc((Data *)mgCb.sSAPLst,                                        \
              (mgCb.genCfg.maxSSaps * sizeof(MgSSAPCb *)));               \
                                                                          \
   mgDeinitIpAddrLst();                                                   \
   cmHashListDeinit(&(mgCb.peerNameLst));                                 \
   MG_MI_RET_CFG_ERR(LCM_REASON_MEM_NOAVAIL);                             \
}
#endif    /* GCP_PROV_SCTP */


#ifdef GCP_USE_PEERID
#define MG_REM_PEERLST_MEM(numPeers)                                      \
{                                                                         \
   U16 j;                                                                 \
                                                                          \
   for (j=0; j < numPeers;j++)                                            \
   {                                                                      \
      if(mgCb.peerLst[j] != NULLP)                                        \
      {                                                                   \
         mgDeAlloc((Data *)mgCb.peerLst[j],sizeof(MgPeerLst));            \
      }                                                                   \
   }                                                                      \
                                                                          \
   mgDeAlloc((Data *)mgCb.peerLst,                                        \
             (mgCb.genCfg.maxSSaps * sizeof(MgPeerLst *)));               \
}
#else
#define   MG_REM_PEERLST_MEM(numPeers)
#endif
 
#define MG_REM_ALLOC_PEER_MEM(numPeers)                                   \
{                                                                         \
   MG_REM_PEERLST_MEM(numPeers);                                          \
   MG_REM_ALLOC_SSAP_MEM;                                                 \
}


/* In the 2nd mgDeAlloc() call in the following macro,
 *             changed mgCb.genCfg.maxPeer to mgCb.genCfg.maxServers.
 *             Also, we should just deAlloc server mem related to
 *             this tsap ONLY. Therefore, we just need to pass
 *             the tsap to this macro.
 */

#define MG_REM_ALLOC_SRVR_MEM(_tsap,numServers)                           \
{                                                                         \
   U16 _j;                                                                \
                                                                          \
   for (_j=0; _j < numServers;_j++)                                       \
   {                                                                      \
      if ((_tsap)->lstnrLst[_j] != NULLP)                                 \
      {                                                                   \
         mgDeAlloc((Data *)(_tsap)->lstnrLst[_j], sizeof(MgLstnrLst));    \
      }                                                                   \
   }                                                                      \
                                                                          \
   mgDeAlloc((Data *)(_tsap)->lstnrLst,                                   \
             (mgCb.genCfg.maxServers * sizeof(MgLstnrLst *)));            \
                                                                          \
   RETVALUE(LCM_REASON_MEM_NOAVAIL);                                      \
}



#define MG_MI_CHK_INIT_REG(action, sapId)                                 \
{                                                                         \
   MgSSAPCb *ssap;                                                        \
                                                                          \
   if (action == AENA)                                                    \
   {                                                                      \
      MG_MI_VALIDATE_SSAP(ssap, sapId, ret);                              \
      if ((ssap != NULLP) && ((ssap->state == LMG_SAP_BND_ENB) ||         \
          (ssap->state == LMG_SAP_UBND_ENB)))                             \
      {                                                                   \
         mgCheckEnbSsap(ssap);                                            \
      }                                                                   \
   }                                                                      \
}

/******************************************************************************/
/*                   Management Primitives                                    */
/******************************************************************************/


/******************************************************************************/
/*                   Configuration Request Primitive                          */
/******************************************************************************/
/*
*
*       Fun:   Configuration Request
*
*       Desc:  This function is used by the Layer Management to
*              configure the layer. The MG layer responds with a
*              Configuration Confirm to the layer manager.
*
*       Ret:   ROK
*
*       Notes: Configuration must be performed in the following 
*              sequence:
*              1) General configuration (STGEN).
*              2) Transport sap configuration (STTSAP).
*              3) Service sap configuration (STSSAP).
*              4) GCP peer entity configuration (STGCPENT).
*              5) Transport Server configuration. (STSERVER).
*
*       File:    mg_mi.c
*
*/
#ifdef ANSI
PUBLIC S16 MgMiLmgCfgReq
(
Pst                *post,              /* post structure */
MgMngmt            *cfg                /* configuration structure */
)
#else
PUBLIC S16 MgMiLmgCfgReq(post, cfg)
Pst                *post;              /* post structure */
MgMngmt            *cfg;               /* configuration structure */
#endif
{
   S16             ret;                /* return value */
   U16             reason;             /* result reason */

   TRC3(MgMiLmgCfgReq);

   ret = LCM_PRIM_OK;

#ifdef MG_RUG
   
   /* RUG Support - Fill default values for configuration */

#ifdef GCP_MGCP
   /* 
    * If binary is compiled with MGCP flag but MGCP values are not specified
    * fill in the default MGCP values for configuration
    */
   if (!(cfg->t.cfg.bitVector & LMG_GCP_MGCP_BIT))
   {
      mgSetDefMgcpCfgVal(cfg);
   }
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
   /* 
    * If binary is compiled with MGCO flag but MGCO values are not specified
    * fill in the default MGCO values for configuration
    */
   if (!(cfg->t.cfg.bitVector & LMG_GCP_MGCO_BIT))
   {
      mgSetDefMgcoCfgVal(cfg);
   }
#endif /* GCP_MGCO */

#endif /* MG_RUG */

   switch(cfg->hdr.elmId.elmnt)
   {
      case STGEN:
         reason = mgCfgGen(&cfg->t.cfg.c.genCfg);
         break;

      case STTSAP:
         reason = mgCfgTsap(&cfg->t.cfg.c.tSAPCfg);
         break;

      case STSSAP:
         reason = mgCfgSsap(&cfg->t.cfg.c.sSAPCfg);
         break;

#ifndef ZG
      /* Peer configuration should be done through Control req if ZG 
       * is defined*/
      case STGCPENT:
         reason = mgCfgGcpEnt(&cfg->t.cfg.c.mgGcpEntCfg);
         break;

      /* Server configuration should be done through Control Req if ZG is
       * defined */
      case STSERVER:
         reason = mgCfgTptServer(&cfg->t.cfg.c.tptSrvrCfg);
         break;
#endif /* ZG */


#ifdef    GCP_PROV_SCTP
      case STSCTPENDP:
         reason = mgEndpCfg(&cfg->t.cfg.c.endpCfg);
         break;
#endif    /* GCP_PROV_SCTP */

      default:
         ret = LCM_PRIM_NOK;
         reason = LCM_REASON_INVALID_ELMNT;

#if (ERRCLASS & ERRCLS_INT_PAR)
         MGLOGERROR(ERRCLS_INT_PAR, EMG164, (ErrVal)cfg->hdr.elmId.elmnt,
                     "Invalid element.");
#endif
         break;
   }

   if (reason != LCM_REASON_NOT_APPL)
     ret =  LCM_PRIM_NOK;

   /* send confirm */
   mgSendLmCfm(TCFG, ret, reason, post, cfg);

   RETVALUE(ROK);

} /* end of MgMiLmgCfgReq() */


/******************************************************************************/
/*                   Statistics Request Primitive                             */
/******************************************************************************/

/*
*
*       Fun:   Statistics Request
*
*       Desc:  This primitive is used by the Layer Manager to solicit 
*              statistics information. The statistics are returned
*              in the  MgMiLmgStsCfm primitive. 

*              The statistics counters ra initialized to zero if so
*              specified by the action field.
*              The possible values for "action" are:
*
*                 ZEROSTS:  zero statistics counters
*                 NOZEROSTS:don't zero statistics counters
*
*       Ret:   ROK 
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC S16 MgMiLmgStsReq
(
Pst                *post,              /* post structure */
Action             action,             /* action to be done */
MgMngmt            *sts                /* statistics structure */
)
#else
PUBLIC S16 MgMiLmgStsReq(post, action, sts)
Pst                *post;              /* post structure */
Action             action;             /* action to be done */
MgMngmt            *sts;               /* statistics structure */
#endif
{
   S16             ret;                /* return value */
   U16             reason;             /* result reason */

    TRC3(MgMiLmgStsReq);

    /* initialize result and reason */
    reason = LCM_REASON_NOT_APPL;
    ret = LCM_PRIM_OK;


    /* update the date and time */
    (Void)SGetDateTime(&sts->t.sts.dt);
    
    /*General configuration must be done first */
    if (mgCb.init.cfgDone == FALSE)
    {
#if (ERRCLASS & ERRCLS_INT_PAR)
        MGLOGERROR(ERRCLS_INT_PAR, EMG165, (ErrVal)sts->hdr.elmId.elmnt,
                   " General Cfg Not Done");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
        
        /* send confirm */
        mgSendLmCfm(TSTS,  LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE, 
                    post, sts);
        RETVALUE(ROK);
    }


    switch(sts->hdr.elmId.elmnt)
    {
      case STTSAP:
        {           
#ifdef CM_DNS_LIB

          /*
           *   Check the validity of tsapId and the validity of
           *   the TSAP pointed to by the tsapId before proceeding
           */
          /* mg002.105: Removed compilation warning */
          /* mg008.105: tSAPId must be less than mgCb.genCfg.maxTSaps */
          if ((sts->t.sts.s.mgTSAPSts.tSapId < 0) ||
              (sts->t.sts.s.mgTSAPSts.tSapId >= (S16)mgCb.genCfg.maxTSaps) ||
              (mgCb.tSAPLst[sts->t.sts.s.mgTSAPSts.tSapId] == NULLP) ||
              (mgCb.tSAPLst[sts->t.sts.s.mgTSAPSts.tSapId]->cfgDone == FALSE))
          {
#if (ERRCLASS & ERRCLS_INT_PAR)
                    MGLOGERROR(ERRCLS_INT_PAR, EMG166,
                               (ErrVal)sts->hdr.elmId.elmnt,
                               "Invalid TsapId/Tsap cfg not done.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */  

                    /* send confirm */
                    mgSendLmCfm(TSTS,  LCM_PRIM_NOK,
                                LMG_REASON_TSAPCFG_NOT_DONE, 
                                post, sts);

                    RETVALUE(ROK);
          }

          reason = mgSetTsapSts(&sts->t.sts.s.mgTSAPSts, 
                                &mgCb.tSAPLst[sts->t.sts.s.mgTSAPSts.tSapId]\
                                 ->sts, action);

#endif /* CM_DNS_LIB */

        }
        break;
        
      case STGCPENT:
      {
#ifdef MG_RUG
#ifdef GCP_MGCO
         /* 
         * If binary is compiled with MGCO flag but MGCO values are not specified
         * fill in the default MGCO values for mid
         */
         if (!(sts->t.sts.bitVector & LMG_GCP_MGCO_BIT))
         {
            sts->t.sts.s.mgPeerEntSts.peerInfo.mid.pres = NOTPRSNT;
         }
#endif /* GCP_MGCO */
#endif /* MG_RUG */
        reason = mgSetPeerSts(&(sts->t.sts.s.mgPeerEntSts), action);
      }
      break;
         
      default:
        reason = LCM_REASON_INVALID_ELMNT;
#if (ERRCLASS & ERRCLS_INT_PAR)
        MGLOGERROR(ERRCLS_INT_PAR, EMG167, (ErrVal)sts->hdr.elmId.elmnt,
                   "Invalid element.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
        break;
    }

   if (reason != LCM_REASON_NOT_APPL)
     ret = LCM_PRIM_NOK;

#ifdef MG_RUG
   /* Set the bit vector information */
#ifdef GCP_MGCP
   LMG_SET_BITVECTOR_BIT(sts->t.sts.bitVector, LMG_GCP_MGCP_BIT);
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
   LMG_SET_BITVECTOR_BIT(sts->t.sts.bitVector, LMG_GCP_MGCO_BIT);
#endif /* GCP_MGCO */
#endif /* MG_RUG */

   /* send confirm */
   mgSendLmCfm(TSTS, ret, reason, post, sts);

   RETVALUE(ROK);

} /* end of MgMiLmgStsReq() */



/******************************************************************************/
/*                   Status  Request Primitive                                */
/******************************************************************************/

/*
*
*       Fun:   Status Request
*
*       Desc:  This primitive is used by the Layer Manager to solicit
*              status information. The information is returned via the
*              MgMiLmgStaCfm primitive.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC S16 MgMiLmgStaReq
(
Pst                *post,              /* post structure */              
MgMngmt            *sta                /* status structure */
)
#else
PUBLIC S16 MgMiLmgStaReq(post, sta)
Pst                *post;              /* post structure */              
MgMngmt            *sta;               /* status structure */
#endif
{
   S16             ret;                /* result */
   U16             reason;             /* result reason */

   TRC3(MgMiLmgStaReq);

   /* initialize result and reason */
   reason = LCM_REASON_NOT_APPL;
   ret = LCM_PRIM_OK;

   /* update the date and time */
   (Void)SGetDateTime(&sta->t.ssta.dt);

   /* General configuration must be done first */
   if (mgCb.init.cfgDone == FALSE)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
     MGLOGERROR(ERRCLS_INT_PAR, EMG168, (ErrVal)sta->hdr.elmId.elmnt,
                "Invalid element.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
     
     /* send confirm */
     mgSendLmCfm(TSSTA,  LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE, post, sta);
     RETVALUE(ROK);
   }


   switch(sta->hdr.elmId.elmnt)
   {
      case STSID:
         (Void)mgGetSId(&sta->t.ssta.s.systemId);
         break;

      case STTSAP:

          /*
           *   Check the validity of tsapId and the validity of
           *   the TSAP pointed to by the tsapId before proceeding
           */
         /* mg002.105: Removed compilation warning */
         /* mg008.105: tSAPId must be less than mgCb.genCfg.maxTSaps */
         if ((sta->t.ssta.s.mgTSAPSta.tSapId < 0) ||
             (sta->t.ssta.s.mgTSAPSta.tSapId >= (S16)mgCb.genCfg.maxTSaps) ||
             (mgCb.tSAPLst[sta->t.ssta.s.mgTSAPSta.tSapId] == NULLP) ||
             (mgCb.tSAPLst[sta->t.ssta.s.mgTSAPSta.tSapId]->cfgDone == FALSE))
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
                    MGLOGERROR(ERRCLS_INT_PAR, EMG169,
                               (ErrVal)sta->hdr.elmId.elmnt,
                               "Invalid TsapId/Tsap cfg not done.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */  

                    /* send confirm */
                    mgSendLmCfm(TSSTA,  LCM_PRIM_NOK,
                                LMG_REASON_TSAPCFG_NOT_DONE, 
                                post, sta);

                    RETVALUE(ROK);
         }


         reason = mgGetTsapSta(&sta->t.ssta.s.mgTSAPSta,
                              mgCb.tSAPLst[sta->t.ssta.s.mgTSAPSta.tSapId]);
        break;

      case STSSAP:
        reason = mgGetSsapSta(sta, post);
        break;

      case STGCPENT:
      {
#ifdef MG_RUG
#ifdef GCP_MGCO
         /* 
         * If binary is compiled with MGCO flag but MGCO values are not specified
         * fill in the default MGCO values for mid
         */
         if (!(sta->t.ssta.bitVector & LMG_GCP_MGCO_BIT))
         {
            sta->t.ssta.s.mgPeerSta.mid.pres = NOTPRSNT;
         }
#endif /* GCP_MGCO */
#endif /* MG_RUG */
        reason = mgGetPeerSta(&sta->t.ssta.s.mgPeerSta);
      }
      break;

      case STSERVER:
         reason = mgGetTptSrvrSta(&sta->t.ssta.s.mgTptSrvSta);
         break; 


#ifdef    GCP_PROV_SCTP
      case STSCTPENDP:
         reason = mgGetSctpEpSta(&sta->t.ssta.s.mgSctpEpSta);
         break; 
#endif /* GCP_PROV_SCTP */


      default:
         reason = LCM_REASON_INVALID_ELMNT;
#if (ERRCLASS & ERRCLS_INT_PAR)
         MGLOGERROR(ERRCLS_INT_PAR, EMG170, (ErrVal)sta->hdr.elmId.elmnt,
                     "Invalid element.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         break;
   }

#ifdef MG_RUG

#ifdef GCP_MGCP 
   LMG_SET_BITVECTOR_BIT(sta->t.ssta.bitVector, LMG_GCP_MGCP_BIT);
#endif /* GCP_MGCP */

#ifdef GCP_MGCO 
   LMG_SET_BITVECTOR_BIT(sta->t.ssta.bitVector, LMG_GCP_MGCO_BIT);
#endif /* GCP_MGCO */

#endif /* MG_RUG */

   if (reason != LCM_REASON_NOT_APPL)
     ret = LCM_PRIM_NOK;

   /* send confirm */
   mgSendLmCfm(TSSTA, ret, reason, post, sta);

   RETVALUE(ROK);

} /* end of MgMiLmgStaReq() */


/******************************************************************************/
/*                   Control Request Primitive                                */
/******************************************************************************/


/*
*
*       Fun:   Control Request
*
*       Desc:  This primitive is used to control the specified element.
*              It can be used to enable or disable trace and alarm
*              (unsolicited status) generation. It can also be used
*              to delete a SAP or a group of SAPs. The control request
*              is also used for debug printing control.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC S16 MgMiLmgCntrlReq
(
Pst                *post,              /* post structure */              
MgMngmt            *cntrl              /* pointer to control structure */
)
#else
PUBLIC S16 MgMiLmgCntrlReq(post, cntrl)
Pst                *post;              /* post structure */              
MgMngmt            *cntrl;             /* pointer to control structure */
#endif
{
   S16             ret;                /* return value */
   U16             reason;             /* result reason */
#ifdef ZG
   Bool            invCntrlReq;        /* Whether control req is valid */
#endif /* ZG_DFTHA */

/* not needed anymore
 * #ifdef    GCP_PROV_SCTP
 *    U32             numTsaps;
 * #endif
 */


   TRC3(MgMiLmgCntrlReq);


   /* initialize result and reason */
   reason = LCM_REASON_NOT_APPL;
   ret = LCM_PRIM_OK;

   /* update the date and time */
   (Void)SGetDateTime(&cntrl->t.cntrl.dt);

#ifdef ZG
   /* only debug/trace enable/disable or shutdown are allowed on a standby */
   invCntrlReq = FALSE;
   if (!((zgChkCRsetStatus()) == TRUE))  
   {
      if ( (cntrl->t.cntrl.action != ASHUTDOWN) &&
           (cntrl->t.cntrl.action != AENA) && 
           (cntrl->t.cntrl.action != ADISIMM) )
      {
         invCntrlReq = TRUE;
      }
      if ( ((cntrl->t.cntrl.action == AENA) || 
            (cntrl->t.cntrl.action == ADISIMM)) &&
             ((cntrl->t.cntrl.subAction != SADBG) && 
              (cntrl->t.cntrl.subAction != SATRC)) )
      {
         invCntrlReq = TRUE;
      }
   }
   if (invCntrlReq)
   {
      mgSendLmCfm(TCNTRL, LCM_PRIM_NOK, LCM_REASON_INVALID_STATE, post,cntrl);
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG171, (ErrVal)cntrl->hdr.elmId.elmnt,
               "MgMiLmgCntrlReq Invalid resource state");
#endif
      RETVALUE(ROK);
   }
#endif /* ZG_DFTHA */

   /*General configuration must be done first */
   if (mgCb.init.cfgDone == FALSE)
   {
      /*mg002.105: TCR 21 - GCP - For repeated shutdown request */
      if (cntrl->t.cntrl.action == ASHUTDOWN)
      { 
         mgSendLmCfm(TCNTRL, LCM_PRIM_OK, LCM_REASON_NOT_APPL, 
                     post,cntrl);
         RETVALUE(ROK);
      }
     /* send confirm */
     mgSendLmCfm(TCNTRL, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE, 
        post,cntrl);
#if (ERRCLASS & ERRCLS_INT_PAR)
     MGLOGERROR(ERRCLS_INT_PAR, EMG172, (ErrVal)cntrl->hdr.elmId.elmnt,
                "Invalid element.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
     RETVALUE(ROK);
   }


   /*
    *   if cntrl action is NOT shutdown then -
    *   go through the list of all the TSAPs;
    *   return failure if any of them has not been configured;
    *
    *   Followed check for all the TSAPs is NOT needed
    *          since specific functions check the relevant TSAPs
    */

/*
 * #ifdef    GCP_PROV_SCTP
 * 
 * 
 *    if (cntrl->t.cntrl.action != ASHUTDOWN)
 *       for (numTsaps=0; numTsaps < mgCb.genCfg.maxTSaps; ++numTsaps)
 *       {
 *          if(!((mgCb.tSAPLst[numTsaps]) &&
 *               (mgCb.tSAPLst[numTsaps]->cfgDone == TRUE)))
 *          {
 * 
 * #if (ERRCLASS & ERRCLS_INT_PAR)
 *                   MGLOGERROR(ERRCLS_INT_PAR, EMG173, (ErrVal)MG_NONE,
 *                               "Tsap cfg not done.");
 * #endif
 * 
 *                   RETVALUE(LMG_REASON_TSAPCFG_NOT_DONE);
 *          }
 *       }
 * 
 * #else
*/



#ifdef MG_RUG
   
   /* RUG Support - Fill default values for control request */

#ifdef GCP_MGCP
   /* 
    * If binary is compiled with MGCP flag but MGCP values are not specified
    * fill in the default MGCP values for control request
    */
   if (!(cntrl->t.cntrl.bitVector & LMG_GCP_MGCP_BIT))
   {
      mgSetDefMgcpCntrlVal(cntrl);
   }
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
   /* 
    * If binary is compiled with MGCO flag but MGCO values are not specified
    * fill in the default MGCO values for control request
    */
   if (!(cntrl->t.cntrl.bitVector & LMG_GCP_MGCO_BIT))
   {
      mgSetDefMgcoCntrlVal(cntrl);
   }
#endif /* GCP_MGCO */

#endif /* MG_RUG */
   
   switch(cntrl->hdr.elmId.elmnt)
   {
      case STGEN:
      {
#ifdef CM_ABNF_MT_LIB
         /* Check if we need to delay shutdown...(incase some Enc/Dec Cfms
          * are pending ) */
         if((cntrl->t.cntrl.action == ASHUTDOWN) && (mgCb.genCfg.noEDInst > 0))
         {
            if(MG_ENCDEC_CFM_IS_PENDING) 
            {
               mgCb.shutDwnCfm.dfrdCfm = TRUE;
               cmMemcpy((U8 *)&mgCb.shutDwnCfm.dfrdHdr, (U8 *)(&cntrl->hdr),
                  sizeof(Header));
               /* Copy src pst structure */
               cmMemcpy((U8 *)&mgCb.shutDwnCfm.dfrdPst, (U8 *)post,sizeof(Pst));
               /* send confirm */
               mgSendLmCfm(TCNTRL, LCM_PRIM_OK_NDONE, reason, post, cntrl);
               RETVALUE(ROK);
            }
         }
#endif /* CM_ABNF_MT_LIB */
         reason = mgCntrlGen(&cntrl->t.cntrl);
         break;
      }

      case STGRTSAP:
         reason = mgCntrlGrpTsap(&cntrl->t.cntrl);
         break;
      case STTSAP:
         /*
          *   MgCntrl.spId should have the TSAP Id
          */
        /*chendh reason = mgCntrlTsap(&cntrl->t.cntrl,
                              mgCb.tSAPLst[cntrl->t.cntrl.spId]
                             );*/
         		reason = mgCntrlTsap(&cntrl->t.cntrl,
                              NULLP);
         break;
    
      case STSSAP:
         reason = mgCntrlSsap(&cntrl->t.cntrl);
         break;

      case STGRSSAP:
         reason = mgCntrlGrpSsap(&cntrl->t.cntrl);
         break;
  
      case STGCPENT:
         reason = mgCntrlPeer(&cntrl->t.cntrl);
         break;

      case STSERVER:  
         reason = mgCntrlTptServer(&cntrl->t.cntrl);
         break;

      case STALLSAP:
         reason = mgCntrlAllSaps(&cntrl->t.cntrl);
         break;

#ifdef ZG
      /* In case of Distributed environment configuration of GCP entity is done
       * through control req */ 
      case STGCPENTCFG:
         reason = mgCfgGcpEnt(&cntrl->t.cntrl.s.mgGcpEntCfg);
         break;

      case STGCPSRVRCFG:
         reason = mgCfgTptServer(&cntrl->t.cntrl.s.tptSrvrCfg);
         break;

#ifdef GCP_MGCO
#ifdef GCP_MGC
      /* mated pair configuration */
      case STMTDGCPENTCFG:
         reason = mgCfgMtdGcpEnt(&cntrl->t.cntrl.s.mtdGcpEntCfg);
         break;
      
#endif /* GCP_MGC */ 
#endif /* GCP_MGCO */ 

#endif /* ZG */

#ifdef GCP_MGCO
#ifdef GCP_MG
      case STGCPMG:
         reason = mgCntrlMG(&cntrl->t.cntrl);
         break;
#endif /* GCP_MG */

#ifdef GCP_MGC
      case STGCPMGC:
         reason = mgCntrlMGC(&cntrl->t.cntrl);
         break;
#endif /* GCP_MGC */
#endif /* GCP_MGCO */



#ifdef    GCP_PROV_SCTP
      case STSCTPENDP:
         reason = mgCntrlEndp(&cntrl->t.cntrl);
         break;
#endif    /* GCP_PROV_SCTP */


      default:
         reason = LCM_REASON_INVALID_ELMNT;
         ret = LCM_PRIM_NOK;
#if (ERRCLASS & ERRCLS_INT_PAR)
         MGLOGERROR(ERRCLS_INT_PAR, EMG174, (ErrVal)cntrl->hdr.elmId.elmnt,
                     "Invalid element.");
#endif
         break;
   }

   if (reason != LCM_REASON_NOT_APPL)
     ret = LCM_PRIM_NOK;

   /* send confirm */
   mgSendLmCfm(TCNTRL, ret, reason, post, cntrl);

   /* 
    * If Control Request was to enable SSAP Chk if we need to 
    * start registration on MG side 
    */
   if ((reason == LCM_REASON_NOT_APPL) && (cntrl->hdr.elmId.elmnt == STSSAP))
   {
      MG_MI_CHK_INIT_REG(cntrl->t.cntrl.action, cntrl->t.cntrl.spId);
   }

   RETVALUE(ROK);

} /* end of MgMiLmgCntrlReq() */


/******************************************************************************/
/*                  Indication Generation Functions                           */
/******************************************************************************/


/*
*
*       Fun:   mgGenStaInd
*
*       Desc:  This function is used to send unsolicited Status
*              Indications to the Layer Manager
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC Void mgGenStaInd
(
Elmnt              elmnt,              /* ALARM element */
U16                category,           /* ALARM category */
U16                event,              /* ALARM event */
U16                cause,              /* ALARM cause */
U8                 alarmType,          /* Alarm Type */
Ptr                alarmInfo,          /* additional alarm info */
Size               alarmInfoSize,      /* size of alarm information */
SuId               sapId               /* SU id */
)
#else
PUBLIC Void mgGenStaInd(elmnt, category, event, cause, alarmType,
                        alarmInfo, alarmInfoSize, sapId)
Elmnt              elmnt;              /* ALARM element */
U16                category;           /* ALARM category */
U16                event;              /* ALARM event */
U16                cause;              /* ALARM cause */
U8                 alarmType;          /* Alarm Type */
Ptr                alarmInfo;          /* additional alarm info */
Size               alarmInfoSize;      /* size of alarm information */
SuId               sapId;              /* SU id */
#endif
{
   MgMngmt         sm;                 /* management structure */

   TRC2(mgGenStaInd);

#if (ERRCLASS & ERRCLS_DEBUG)
   /* have to have general configuration done first */
   if (mgCb.init.cfgDone == FALSE)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG175, (ErrVal)0,
           "Status Indication requested; general configuration not done.");
      RETVOID;
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   /* if we're not generating unsolicited status indications, do nothing */
   if (mgCb.init.usta == FALSE)
   {
      RETVOID;
   }
 
   /* zero out the management structure */
   cmMemset((U8 *)&sm, 0, sizeof(MgMngmt));
 
   /* fill in the element */
   sm.hdr.elmId.elmnt = elmnt;

   /* fill in the category, event and cause */
   sm.t.usta.alarm.category = category;
   sm.t.usta.alarm.event = event;
   sm.t.usta.alarm.cause = cause;
 
   /* update the date and time */
   (Void)SGetDateTime(&sm.t.usta.alarm.dt);

   sm.t.usta.alarmInfo.type = alarmType;

#ifdef GCP_VER_1_3
   sm.t.usta.alarmInfo.sapId = sapId;
#endif /* GCP_VER_1_3 */

   /* fill in the alarm specific information */
   if(alarmInfo != NULLP)
      cmMemcpy((U8 *)&sm.t.usta.alarmInfo.u, (U8 *)alarmInfo, alarmInfoSize);
 
   (Void)MgMiLmgStaInd(&(mgCb.init.lmPst), &sm);
 
   RETVOID;

} /* end of mgGenStaInd() */




/*
*
*       Fun:   mgGenTrcInd
*
*       Desc:  This function is used to send Trace Indications to
*              the Layer Manager.
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC Void mgGenTrcInd
(
MgTSAPCb           *tsap,              /* TSAP control block */
SpId               sapId,              /* SAP ID */
U16                evnt,               /* trace event */
MgPeerCb           *peer,              /* MGCP entity pointer */
Buffer             *mBuf               /* message being traced */
)
#else
PUBLIC Void mgGenTrcInd(tsap, sapId, evnt, peer, mBuf)
MgTSAPCb           *tsap;              /* TSAP control block */
SpId               sapId;              /* SAP ID */
U16                evnt;               /* trace event */
MgPeerCb           *peer;              /* MGCP entity pointer */
Buffer             *mBuf;              /* message being traced */
#endif
{
   S16             i;                  /* temporary */
   S16             ret;                /* temporary */
   Data            d;                  /* temporary */
   MgMngmt         sm;                 /* management structure */
   Buffer          *trcBuf;            /* buffer to trace */
   MsgLen          ml;                 /* passed message buffer length */
   MsgLen          trcLen;             /* Length of Trace */
        
   TRC2(mgGenTrcInd);

#if (ERRCLASS & ERRCLS_DEBUG)
   /* have to have general configuration done first */
   if (mgCb.init.cfgDone == FALSE)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG176, (ErrVal)0,
           "Trace Indication requested; general configuration not done.");
      RETVOID;
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   /* verify that we do trace */
   if (peer == NULLP)
   {

     /*
      *    This is the only change
      *   that is syntactically valid. Any other style wud resuly
      *   in compilation errors - BTW, GVIM editor recognises that
      *   error (it shows in the color highlighting)
      */


     trcLen = tsap->trcLen;
   }
   else
     trcLen = peer->mntInfo.trcLen;

   if (trcLen <= 0)
   {
      RETVOID;
   }

   /* zero out the management structure */
   cmMemset((U8 *)&sm, 0, sizeof(MgMngmt));

   /* Fill in the SAP ID, the entity ID and the event */
   sm.t.trc.sapId = sapId;
   sm.t.trc.evnt = evnt;

   /* 
    * Allocate a new message and copy the number of bytes from the source
    * message that we are required to trace.
    */
   if (mgGetMsg(mgCb.init.lmPst.region, mgCb.init.lmPst.pool, &trcBuf) != ROK)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      MGLOGERROR(ERRCLS_ADD_RES, EMG177, (ErrVal)0, "mgGetMsg() failed.");
#endif /* (ERRCLASS & ERRCLS_ADD_RES) */
      RETVOID;
   }


   if (peer == NULLP)
   {
     sm.hdr.elmId.elmnt = STTSAP;
     sm.t.trc.peerInfo.pres.pres = NOTPRSNT;
   }
   else
   {
     sm.hdr.elmId.elmnt = STGCPENT;
     sm.t.trc.peerInfo.pres.pres = PRSNT_NODEF;

      /* Use existing MGCP/MGCO specific macros */
#ifdef GCP_MGCP
      if(LMG_PROTOCOL_MGCP == peer->mntInfo.protocolType)
      {
         MG_COPY_PEERINFO_INTO_MGCPTXN(sm.t.trc.peerInfo, peer);
      }
#endif /* GCP_MGCP */
#ifdef GCP_MGCO 
      if(LMG_PROTOCOL_MGCO == peer->mntInfo.protocolType)
      {
         MG_COPY_PEERINFO_INTO_MGCOMSG(sm.t.trc.peerInfo, peer);
      }
#endif /* GCP_MGCO */
   }

   (Void)SFndLenMsg(mBuf, &ml);
   if (trcLen > 0  &&  trcLen < ml)
   {
      ml =trcLen;
   }

   for (i = 0;  i < ml;  i++)
   {
      (Void)SExamMsg(&d, mBuf, (MsgLen)i);
      ret = SAddPstMsg(d, trcBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
      {
         (Void)mgPutMsg(mBuf);
         (Void)mgPutMsg(trcBuf);
         MGLOGERROR(ERRCLS_ADD_RES, EMG178, (ErrVal)0, "SAddPstMsg() failed.");
         RETVOID;
      }
#endif /* (ERRCLASS & ERRCLS_ADD_RES) */
   }

   /* update the date and time */
   (Void)SGetDateTime(&sm.t.trc.dt);

   (Void)MgMiLmgTrcInd(&(mgCb.init.lmPst), &sm, trcBuf);

   RETVOID;

} /* end of mgGenTrcInd() */




/******************************************************************************/
/*                   Management Interface Support Functions                   */
/******************************************************************************/


/******************************************************************************/
/*                   Layer Manager Confirm  Function                          */
/******************************************************************************/

/*
*
*       Fun:   mgSendLmCfm
*
*       Desc:  This function sends various confirm primitives to the
*              Layer Manager
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC Void mgSendLmCfm
(
U8                 cfmType,            /* confirm type */
U16                status,             /* confirm status */
U16                reason,             /* failure reason */
Pst                *srcPst,            /* incoming Pst */
MgMngmt            *cfm                /* management structure */
)
#else
PUBLIC Void mgSendLmCfm(cfmType, status, reason, srcPst, cfm)
U8                 cfmType;            /* confirm type */
U16                status;             /* confirm status */
U16                reason;             /* failure reason */
Pst                *srcPst;            /* incoming Pst */
MgMngmt            *cfm;               /* management structure */
#endif
{
   Pst             cfmPst;             /* Pst structure for confimation */

   TRC2(mgSendLmCfm);

   /* set the result */
   cfm->cfm.status = status;
   cfm->cfm.reason = reason;

   /* fill up the Pst structure for comfirm */
   cfmPst.srcEnt    = mgCb.init.ent;
   cfmPst.srcInst   = mgCb.init.inst;
   cfmPst.srcProcId = mgCb.init.procId;
   cfmPst.dstEnt    = srcPst->srcEnt;
   cfmPst.dstInst   = srcPst->srcInst;
   cfmPst.dstProcId = srcPst->srcProcId;

   cfmPst.selector  = cfm->hdr.response.selector;
   cfmPst.prior     = cfm->hdr.response.prior;
   cfmPst.route     = cfm->hdr.response.route;
   cfmPst.region    = cfm->hdr.response.mem.region;
   cfmPst.pool      = cfm->hdr.response.mem.pool;

   /* Rolling upgrade */
#ifdef MG_RUG
   /* Generate reply using same version as the one used to form the
    * request by the LM
    */
   cfmPst.intfVer = srcPst->intfVer;
#endif /* MG_RUG */
 
   switch(cfmType)
   {
      case TCFG:
         /* send configuration confirm */
         (Void)MgMiLmgCfgCfm(&cfmPst, cfm);
         break;

      case TSTS:
         /* send Statistics confirm */
         (Void)MgMiLmgStsCfm(&cfmPst, cfm);
         break;

      case TCNTRL:
         /* send control confirm */
         (Void)MgMiLmgCntrlCfm(&cfmPst, cfm);
         break;
 
      case TSSTA:
         /* send solicited status confirm */
         (Void)MgMiLmgStaCfm(&cfmPst, cfm);
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         MGLOGERROR(ERRCLS_DEBUG, EMG179, (ErrVal)cfmType,
                    "mgSendLmCfm() unknown primitive type.");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         break;
   }

   RETVOID;

} /* end of mgSendLmCfm() */


/******************************************************************************/
/*                   Configuration Request Support Functions                  */
/******************************************************************************/


/******************************************************************************/
/*                   General Configuration Support Functions                  */
/******************************************************************************/
/*
*
*       Fun:   mgCfgGen
*
*       Desc:  This function performs general configuration of MGCP
*              Control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failed
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCfgGen
(
MgGenCfg           *cfg                /* general configuration structure */
)
#else
PRIVATE U16 mgCfgGen (cfg)
MgGenCfg           *cfg;               /* general configuration structure */
#endif
{
   Size            sMemSize;           /* amount of static memory required */
#ifdef MG_RUG
   Size            rugMemSz;           /* Memory Required for RUG */
#endif /* MG_RUG */
   U16             ret;                /* return values */
   S16             retVal;             /* Return Value */
   Bool            dupFlag;            /* Isduplicate allowed in Hsh list/not*/

   TRC2(mgCfgGen);

   ret = LCM_REASON_NOT_APPL;
   dupFlag = FALSE;  

#ifdef ZG
   if(TRUE != zgGenCfgDone())
      RETVALUE(LMG_REASON_PSFCFG_NOT_DONE);
#endif /* ZG */

   /* mg002.105: rspAckEnb is now reconfigurable */
   if (mgCb.init.cfgDone)
   {
      mgCb.genCfg.reCfg.rspAckEnb = cfg->reCfg.rspAckEnb;
      RETVALUE(LCM_REASON_NOT_APPL);
   }

   if(((cfg->resThUpper <= 0) || (cfg->resThUpper > 10) || 
       (cfg->resThLower <= 0) || (cfg->resThLower > 10)) ||
       (cfg->resThUpper < cfg->resThLower))
   {
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);
   }
     
   if ((cmInetInit()) != ROK)
      RETVALUE(LMG_REASON_INET_INIT_FAILED);

   /* copy the general configuration structure */
   cmMemcpy((U8 *)&mgCb.genCfg, (U8 *)cfg, sizeof(MgGenCfg));

   /* mg003.105: Changes for MG/MGC default Pending Limit */
#if (defined(GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))   
   if(cfg->limit.pres.pres != PRSNT_NODEF)
   {
     mgCb.genCfg.limit.pres.pres = PRSNT_NODEF;
     mgCb.genCfg.limit.mgOriginatedPendingLimit = 
                           LMG_MG_ORIGINATED_PENDING_LIMIT;
     mgCb.genCfg.limit.mgcOriginatedPendingLimit = 
                           LMG_MGC_ORIGINATED_PENDING_LIMIT;
   }
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */   

   /* Initialize the DNS TSAP Id to -1 */
   mgCb.dnsTsap = MG_INVALID_TSAP_ID;


   /* compute the required static memory */
   sMemSize = ((cfg->maxSSaps * sizeof(MgSSAPCb)) +
               (cfg->maxSSaps * sizeof(MgSSAPCb *)) +
               (cfg->maxTSaps * sizeof(MgTSAPCb)) +
               (cfg->maxTSaps * sizeof(MgTSAPCb *)) +
#ifdef GCP_USE_PEERID
               (cfg->maxPeer * sizeof(MgPeerLst)) +
               (cfg->maxPeer * sizeof(MgPeerLst *)) +
#endif
               (cfg->maxPeer * sizeof(MgPeerCb)) + 
               ((cfg->maxPeer * LMG_MAX_NET_ADDR) * sizeof(MgIpAddrEnt) * 2) +
               (cfg->maxTxn * MG_MI_MAX_TXN_SIZE)+
               (cfg->numBlks * cfg->maxBlkSize) +
               (cfg->maxTSaps * cfg->maxServers * sizeof(MgLstnrLst)) +
               (cfg->maxTSaps * cfg->maxServers * sizeof(MgLstnrLst *)) +
               (cfg->maxTSaps * cfg->maxServers * sizeof(MgTptSrvr))+
               (cfg->maxTSaps * cfg->maxConn * sizeof(MgTptSrvr)) +
               (sizeof(CmListEnt) * cfg->numBinsTxnIdHl * CM_HASH_BINSIZE) +
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
               /* (sizeof(CmListEnt) * cfg->numBinsPeerCmdHl* CM_HASH_BINSIZE) + */
               /* (sizeof(CmListEnt) * cfg->numBinsTransReqHl* CM_HASH_BINSIZE) + */
               /* (sizeof(CmListEnt) * cfg->numBinsTransIndRspCmdHl* CM_HASH_BINSIZE) + */
#endif /* GCP_CH && GCP_VER_1_5 */ 
 
               (sizeof(CmListEnt) * cfg->numBinsNameHl * CM_HASH_BINSIZE));
               
#ifdef CM_DNS_LIB
               sMemSize += (sizeof(CmDnsCb));
               sMemSize += (sizeof(CmDnsReqIdLst *) * MG_DNS_RQST_LST_SZ);
               sMemSize += (sizeof(CmDnsReqIdLst) * MG_DNS_RQST_LST_SZ);
#endif /* CM_DNS_LIB */

#ifdef MG_RUG
   /* Add Memory for Version Information for Number of SSAPS and One TSAP */
   rugMemSz = ((cfg->maxSSaps + 1) * (sizeof(ShtVerInfo)));
   sMemSize += rugMemSz;
#endif /* MG_RUG */

   /* reserve static memory */
   if ((retVal = SGetSMem(mgCb.init.region, sMemSize, &mgCb.init.pool)) != ROK)
      RETVALUE(LCM_REASON_MEM_NOAVAIL);

#ifdef GCP_MGCO
   dupFlag = TRUE;
#endif /* GCP_MGCO */
   
   /* initialize global hash list */
   if ((retVal = mgInitIpAddrLst(dupFlag)) != ROK)
   {
      MG_MI_RET_CFG_ERR(LCM_REASON_INVALID_PAR_VAL);
   }


   if ((retVal = cmHashListInit(&(mgCb.peerNameLst), mgCb.genCfg.numBinsNameHl,
                                0, dupFlag, MG_PEERNAME_HASH_FUNC,
                                mgCb.init.region, mgCb.init.pool)) != ROK)
   {
      mgDeinitIpAddrLst();
      MG_MI_RET_CFG_ERR(LCM_REASON_MEM_NOAVAIL);
   }
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
   {
      U16   idx;

      /* Intialise the peer command Control Hash list  */
      idx = (U16)(((PTR) &(((MgMgcoChPeerCmdCtl *) 0)->peerEnt)));
      if(ROK != cmHashListInit(&(mgCb.chCb.peerCmdCtlLst), mgCb.genCfg.numBinsPeerCmdHl,
               idx, FALSE, MG_CH_PEERID_HASH_FUNC, mgCb.init.region,
               mgCb.init.pool))
        {
     /* mg007.105: ccpu00066366, previously allocated memory must be freed in error scenarios */
              cmHashListDeinit(&(mgCb.peerNameLst));
              mgDeinitIpAddrLst();
              MG_MI_RET_CFG_ERR(LCM_REASON_MEM_NOAVAIL);
        }
   }
    
#endif /* GCP_CH && GCP_VER_1_5 */ 

   if ((ret = mgAllocSsapLst(cfg)) != LCM_REASON_NOT_APPL)
     RETVALUE(ret);


   if ((ret = mgAllocTsapLst(cfg)) != LCM_REASON_NOT_APPL)
     RETVALUE(ret);


#ifdef GCP_USE_PEERID
   mgCb.freePeerIdx = MG_INVALID_PEERID;
   mgCb.lastFreePeerIdx = MG_INVALID_PEERID;

   if ((ret = mgAllocPeerLst(cfg)) != LCM_REASON_NOT_APPL)
      RETVALUE(ret);
#endif /* GCP_USE_PEERID */

   /* copy and update the Pst structure for the layer management interface */
   cmMemcpy((U8 *)&mgCb.init.lmPst, (U8 *)&cfg->lmPst, sizeof(Pst));
   mgCb.init.lmPst.srcProcId = mgCb.init.procId;
   mgCb.init.lmPst.srcEnt    = mgCb.init.ent;
   mgCb.init.lmPst.srcInst   = mgCb.init.inst;
   mgCb.init.lmPst.event     = EVTNONE;

#ifdef MG_RUG

   mgCb.init.lmPst.intfVer   = cfg->lmPst.intfVer;

   /* Allocate Memory for Version Information Storage */
   if ((mgCb.verInfo.intfInfo = (ShtVerInfo *)mgMalloc(rugMemSz)) == NULLP)
   {
      MG_REM_ALLOC_PEER_MEM(cfg->maxPeer);
      /* the above Macro will return LCM_REASON_MEM_NOAVAI */
   }

   mgCb.verInfo.numIntfInfo = 0;

#ifdef ZG
   /* Do add mapping for Version Information */
   ZG_INIT_RSETID_IN_MAPCB(&(mgCb.verInfo.mapCb));
   zgAddMapping(ZG_CBTYPE_VERINFO, (Ptr)&mgCb.verInfo);
#endif /* ZG */

#endif /* MG_RUG */   

   /* register MG timers */
   if ((ret = SRegTmr(mgCb.init.ent, mgCb.init.inst, 
                      (S16)cfg->timeRes, mgActvTmr)) != ROK)
   {
#ifdef MG_RUG
      MG_FREE_RUG_VERINFO;
#endif /* MG_RUG */
      MG_REM_ALLOC_PEER_MEM(cfg->maxPeer);
   }
     
#ifdef GCP_MGCP
   if ((ret = SRegTmr(mgCb.init.ent, mgCb.init.inst, 
                     (S16)cfg->timeResTTL, mgActvTmrTTL)) != ROK)
   {
      SDeregTmr(mgCb.init.ent, mgCb.init.inst, (S16)mgCb.genCfg.timeRes, 
                mgActvTmr);
#ifdef MG_RUG
      MG_FREE_RUG_VERINFO;
#endif /* MG_RUG */
      MG_REM_ALLOC_PEER_MEM(cfg->maxPeer);
   }
#endif /* GCP_MGCP */



#ifdef GCP_MGC
#ifdef GCP_MGCP 
   mgCb.nxtMgcpSsapId = -1;
#endif /* GCP_MGCP */

#ifdef GCP_MGCO 
   mgCb.nxtMgcoSsapId = -1;
#endif /* GCP_MGCP */
#endif /* GCP_MGC */

   mgCb.curNumPeer = 0;
    
   /* general configuration is done */
   mgCb.init.cfgDone = TRUE;
#ifdef DEBUGP
   mgCb.init.dbgMask = 0x00000000; /*chendh add*/
#endif /*DEBUGP*/
#ifdef CM_ABNF_MT_LIB
   /* Initialize Encoder/Decoder related variables */
   mgCb.lastEDInst = mgCb.genCfg.firstInst + mgCb.genCfg.noEDInst;
   mgCb.nxtEDInst =  mgCb.genCfg.firstInst;
   /* Initialize post structure for ED */
   mgCb.edPst.dstProcId = mgCb.init.procId;
   mgCb.edPst.srcProcId = mgCb.init.procId;
   mgCb.edPst.dstEnt = mgCb.init.ent;
   mgCb.edPst.srcEnt = mgCb.init.ent;
   mgCb.edPst.dstInst = mgCb.genCfg.firstInst;
   mgCb.edPst.srcInst = mgCb.init.inst;
   mgCb.edPst.region =  mgCb.init.region;
   mgCb.edPst.pool =  mgCb.init.pool;
   /* initialize ED running counter */
   mgCb.decCntr = 0;
   mgCb.encCntr = 0;
   /* initialize store list */
   mgCb.encList.nodeIndx = 0;
   mgCb.encList.next = NULLP;
   mgCb.encList.info = NULLP;
   mgCb.decList.nodeIndx = 0;
   mgCb.decList.next = NULLP;
   mgCb.decList.info = NULLP;
   /* Initialize defferd cfm structure */
   mgCb.shutDwnCfm.dfrdCfm = FALSE;
   cmMemset((U8 *)&mgCb.shutDwnCfm.dfrdPst, 0, sizeof(Pst));
   cmMemset((U8 *)&mgCb.shutDwnCfm.dfrdHdr, 0, sizeof(Header));
   /* call function to create multiple ED instances */

   ret = 
      mgCreatEDInst(mgCb.genCfg.noEDInst, mgCb.genCfg.firstInst, mgCb.init.ent);
   if(ret != ROK)
   {
     /* mg007.105: ccpu00066366, previously allocated memory must be freed in error scenarios */
#ifdef MG_RUG
      MG_FREE_RUG_VERINFO;
#endif /* MG_RUG */
      MG_REM_PEERLST_MEM(cfg->maxPeer);  
      mgDeAlloc((Data *)mgCb.sSAPLst, (mgCb.genCfg.maxSSaps * sizeof(MgSSAPCb *))); 
      mgDeAlloc((Data *)mgCb.tSAPLst, (mgCb.genCfg.maxTSaps * sizeof(MgTSAPCb *)));
      mgDeinitIpAddrLst();
      cmHashListDeinit(&(mgCb.peerNameLst));
      MG_MI_RET_CFG_ERR(LCM_REASON_INVALID_PAR_VAL);
   }
#endif /* CM_ABNF_MT_LIB */
#ifdef ZG
   /* Do add mapping for mgCb and TsapCb */
   ZG_INIT_RSETID_IN_MAPCB(&(mgCb.mapCb));
   zgAddMapping(ZG_CBTYPE_GCP, (Ptr)&(mgCb));
#endif /* ZG */

   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgCfgGen() */


/*
*
*       Fun:   mgAllocSsapLst
*
*       Desc:  This function performs general configuration of MGCP
*              Control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failed
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgAllocSsapLst
(
MgGenCfg           *cfg                /* general configuration structure */
)
#else
PRIVATE U16 mgAllocSsapLst(cfg)
MgGenCfg           *cfg;               /* general configuration structure */
#endif
{
   S16             ret;                /* return value */
   U16             i;                  /* temporary variable */
   Size            memSize;            /* Memory Size to be allocated */
  
   TRC2(mgAllocSsapLst)

   ret     = LCM_REASON_NOT_APPL;
   memSize = (cfg->maxSSaps * sizeof(MgSSAPCb *));
  
   if ((mgCb.sSAPLst = (MgSSAPCb **)mgMalloc(memSize)) == NULLP)
   {
      mgDeinitIpAddrLst();
      cmHashListDeinit(&(mgCb.peerNameLst));
      MG_MI_RET_CFG_ERR(LCM_REASON_MEM_NOAVAIL);
   }

   for (i = 0;  i < cfg->maxSSaps;  i++)
   {
      *(mgCb.sSAPLst + i) = NULLP;
   }

   RETVALUE(ret);

} /* end of mgAllocSsapLst() */




/*
*
*       Fun:   mgAllocTsapLst
*
*       Desc:  This function allocates and initializes the list of
*              TSAPs in mgCb.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failed
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgAllocTsapLst
(
MgGenCfg           *cfg                /* general configuration structure */
)
#else
PRIVATE U16 mgAllocTsapLst(cfg)
MgGenCfg           *cfg;               /* general configuration structure */
#endif
{
   S16             ret;                /* return value */
   U32             i;                  /* temporary variable */
   Size            memSize;            /* Memory Size to be allocated */
  
   TRC2(mgAllocTsapLst)

   ret     = LCM_REASON_NOT_APPL;

    /* mg007.105: ccpu00066363, cfg->maxTSaps can't be more than LMG_MAX_DEF_TSAPS  */
   if ( LMG_MAX_DEF_TSAPS < cfg->maxTSaps )
    {
      MG_REM_PEERLST_MEM(cfg->maxPeer);

      mgDeAlloc((Data *)mgCb.sSAPLst,
                 (mgCb.genCfg.maxSSaps * sizeof(MgSSAPCb *)));

      mgDeinitIpAddrLst();
      cmHashListDeinit(&(mgCb.peerNameLst));
      MG_MI_RET_CFG_ERR(LCM_REASON_INVALID_PAR_VAL);
    }
   
   memSize = (cfg->maxTSaps * sizeof(MgTSAPCb *));
  
   if ((mgCb.tSAPLst = (MgTSAPCb **)mgMalloc(memSize)) == NULLP)
   {
      MG_REM_PEERLST_MEM(cfg->maxPeer);

      mgDeAlloc((Data *)mgCb.sSAPLst,
                 (mgCb.genCfg.maxSSaps * sizeof(MgSSAPCb *)));

      mgDeinitIpAddrLst();
      cmHashListDeinit(&(mgCb.peerNameLst));
      MG_MI_RET_CFG_ERR(LCM_REASON_MEM_NOAVAIL);
   }

   for (i = 0;  i < cfg->maxTSaps;  i++)
   {
      *(mgCb.tSAPLst + i) = NULLP;
   }

   RETVALUE(ret);

} /* end of mgAllocTsapLst() */





#ifdef GCP_USE_PEERID
/*
*
*       Fun:   mgAllocPeerLst
*
*       Desc:  This function performs general configuration of MGCP
*              Control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failed
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgAllocPeerLst
(
MgGenCfg           *cfg                /* general configuration structure */
)
#else
PRIVATE U16 mgAllocPeerLst(cfg)
MgGenCfg           *cfg;               /* general configuration structure */
#endif
{
   S16             ret;                /* return value */
   Size            memSize;            /* memory size to be allocated */
   U16             i;                  /* temporary variable */

   TRC2(mgAllocPeerLst)

   ret     = LCM_REASON_NOT_APPL;
   memSize = (cfg->maxPeer * sizeof(MgPeerLst *));
  
   /* allocate space for the peer entity list and zero it */
   if ((mgCb.peerLst = (MgPeerLst **)mgMalloc(memSize)) == NULLP)
   {
     MG_REM_ALLOC_SSAP_MEM;
   }

   for(i = 0; i < cfg->maxPeer; i++)
      *(mgCb.peerLst + i) = NULLP;

   /* need to allocate space for each entry */
   memSize = sizeof(MgPeerLst);
   for (i = 0; i < cfg->maxPeer; i++)
   {
      if ((mgCb.peerLst[i] = (MgPeerLst *)mgMalloc(memSize)) == NULLP)
      {
         MG_REM_ALLOC_PEER_MEM(i);
      }
   }

   MG_INIT_PEERID_LST(cfg->maxPeer);

   RETVALUE(ret);

} /* end of mgAllocPeerLst() */
#endif /* GCP_USE_PEERID */


/******************************************************************************/
/*                   TSAP Configuration Support Functions                     */
/******************************************************************************/

/*
*
*       Fun:   mgCfgTsap
*
*       Desc:  This function configures the MGCP layer TSAP.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCfgTsap
(
MgTSAPCfg          *cfg                /* TSAP configuration structure */
)
#else
PRIVATE U16 mgCfgTsap(cfg)
MgTSAPCfg          *cfg;               /* TSAP configuration structure */
#endif
{
   S16             ret;                /* Return Value */
   MgTSAPCb        *tsap;              /* TSAP Control Block */
   U16             idx;                /* Index/offset */
#ifdef MG_RUG
   MgIntVerInfo    *verInfo;           /* Version Information */
   Bool            found;              /* flag to indicate if version info
                                        *  is in the stored version structure 
                                        */
   U16             indx;
#endif /* MG_RUG */
#ifdef   GCP_PROV_MTP3
   U16              offset;
#endif   /* GCP_PROV_MTP3 */   

   TRC2(mgCfgTSap);


   /* have to have general configuration done first */
   if (mgCb.init.cfgDone == FALSE)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
     MGLOGERROR(ERRCLS_INT_PAR, EMG180, (ErrVal)MG_NONE,
                " General Cfg Not Done");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */    
      RETVALUE(LCM_REASON_GENCFG_NOT_DONE);
   }



   /*
    *   With multiple TSAPs, only one TSAP is allowed to
    *   interface with TUCL;
    *   added protection check for that;
    *   multiple TUCL TSAPs are now allowed;
    *          But only one TUCL TSAP should interface with DNS;
    */

   /*
    *   check if tSAPId present in cfg is valid
    */

   /* mg008.105: tSAPId must be less than mgCb.genCfg.maxTSaps */
   if (cfg->tSAPId >= (S16)mgCb.genCfg.maxTSaps)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
           MGLOGERROR(ERRCLS_INT_PAR, EMG181, (ErrVal)MG_NONE,
                      "Invalid tSAPId");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */    

            RETVALUE(LCM_REASON_INVALID_PAR_VAL);
   }

   tsap = mgCb.tSAPLst[cfg->tSAPId];

   /*
    *   check if the provider type of this TSAP is TUCL
    *   NO other TSAP has been configured for TUCL
    *    modify following to just check for DNS
    */

   if ((tsap) && (cfg->provType == LMG_PROV_TYPE_TUCL) &&
       (cfg->reCfg.dnsCfg.dnsAccess != LMG_DNS_DISABLED))
   {
      /* mg002.105: Removed compilation warning */
      S16 numTsaps;
      Bool alreadyExists = FALSE;

      /* mg002.105: Removed compilation warning */
      for (numTsaps=0; numTsaps < (S16)mgCb.genCfg.maxTSaps; ++numTsaps)
      {
         if ((mgCb.tSAPLst[numTsaps]) &&
             (mgCb.tSAPLst[numTsaps]->cfgDone == TRUE) &&
             (mgCb.tSAPLst[numTsaps]->tsapCfg.provType == LMG_PROV_TYPE_TUCL) &&
             ((tsap->dnsInfo.dnsState == MG_DNS_STATE_UP) ||
              (tsap->dnsInfo.dnsLstnr != NULLP)))
         {
            /* since DNS is reconfigurable, the same TSAP cfg could
             * be issued more than once for the same TSAP;
             * Therefore check, if this TSAP cfg is for the first
             * time or not - this check is already done in the big if
             * above while the if below checks if the TSAP ids match
             */
            if (numTsaps != cfg->tSAPId)
               alreadyExists = TRUE;
            break;
         }
      }

      if (alreadyExists == TRUE)
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
              MGLOGERROR(ERRCLS_INT_PAR, EMG182, (ErrVal)MG_NONE,
                         "TSAP for DNS is already configured");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */    
               RETVALUE(LCM_REASON_INVALID_PAR_VAL);
      }
      else
      /*
       *   This is a valid TSAP cfg for TUCL.
       *   Hence store this TUCL TSAP Id in mgCb.
       */
      {
         mgCb.dnsTsap = cfg->tSAPId;
      }
   }

   /* check if first time configuration */
   if (tsap == NULLP)
   {
      /* allocate the TSAP */
      if ((tsap = mgCb.tSAPLst[cfg->tSAPId] = 
               (MgTSAPCb *)mgMalloc(sizeof(MgTSAPCb))) == NULLP)
      {
         RETVALUE(LCM_REASON_MEM_NOAVAIL);
      }

      /* copy the configuration */
      cmMemcpy((U8 *)&tsap->tsapCfg, (U8 *)cfg, sizeof(MgTSAPCfg));

      /* store IDs and initialize state */
      tsap->state = LMG_SAP_UBND_DIS;

#ifdef MG_DIS_SAP
      tsap->contEnt = ENTSM;  /* stack manager controlling entity */
#else
      tsap->contEnt = ENTNC;  /* unknown controlling entity */
#endif /* MG_DIS_SAP */

      /* initialize free index */
      tsap->nxtFreeIdx = 0;
      tsap->nxtConnIdx = mgCb.genCfg.maxServers;
      tsap->connIdxWrapArnd = FALSE;
      

      tsap->resCong = FALSE; 
      tsap->trcLen = 1024;/*chendh MG_DEFAULT_TRC_LEN;*/

      /* initialize the bind retry count and the bind timer */
      tsap->bndRetxCnt = LMG_BND_RETRY_CNT;

      cmInitTimers(&tsap->bndTmr, 1);

      /* Reset TSAP Statistics */
      cmMemset((U8 *)&(tsap->sts), 0, sizeof(MgTSAPSts));

      /* set up TSAP Pst structure */
      tsap->spPst.prior = cfg->dstPrior;
      tsap->spPst.route = cfg->dstRoute;
      tsap->spPst.selector = cfg->dstSel;
      tsap->spPst.region = cfg->memId.region;
      tsap->spPst.pool = cfg->memId.pool;
      tsap->spPst.dstProcId = cfg->dstProcId;
      tsap->spPst.dstEnt = cfg->dstEnt;
      tsap->spPst.dstInst = cfg->dstInst;
      tsap->spPst.srcProcId = mgCb.init.procId;
      tsap->spPst.srcEnt = mgCb.init.ent;
      tsap->spPst.srcInst = mgCb.init.inst;
      tsap->spPst.event = EVTNONE;

      /* initialize tpt server  hash list */
      idx = (U16)(((PTR) &(((MgTptSrvr *) 0)->hlEnt)));
      if ((ret = cmHashListInit(&(tsap->tptSrvrLstCp), 
                                mgCb.genCfg.numBinsTptSrvrHl,
                                idx,  FALSE, MG_TPTSRVR_HASH_FUNC, 
                                mgCb.init.region,
                                mgCb.init.pool)) != ROK)
      {
         RETVALUE(LCM_REASON_MEM_NOAVAIL);
      }

      /* initialize server linked list */
#ifdef GCP_MGCP      
      cmLListInit(&tsap->mgcpUDPSrvrLst.srvrLstCp);
      tsap->nxtUseMgcpSrvr = NULLP;
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
      cmLListInit(&tsap->mgcoUDPSrvrLst.srvrLstCp);
      tsap->nxtUseMgcoSrvr = NULLP;

#ifdef GCP_MGC
      cmLListInit(&tsap->tcpSrvrInfo.srvrLstCp);
      tsap->tcpSrvrInfo.nxtSrvr2Use = NULLP;
#endif /* GCP_MGC */

#endif /* GCP_MGCO */



      /* servers are now allocated only for TUCL TSAPs;
       * take care of proper de-allocation too
       */
      if (tsap->tsapCfg.provType == LMG_PROV_TYPE_TUCL)
      {
         /* Initialize Server List */
         if ((ret = mgAllocSrvrLst(cfg,tsap)) != LCM_REASON_NOT_APPL)
         {
            cmHashListDeinit(&(tsap->tptSrvrLstCp));
            /* Reset TSAP structure*/
            cmMemset((U8 *)(tsap), 0, sizeof(MgTSAPCb));
            RETVALUE(ret);
         }
      }
      /* init DNS information only if it is the begining cfg*/
      tsap->dnsInfo.dnsState = MG_DNS_STATE_DOWN;      



#ifdef    GCP_PROV_SCTP

      if (tsap->tsapCfg.provType == LMG_PROV_TYPE_SCTP)
      {
         S16   retVal;

         /*
          *   initialize SCTP related fields in tsap
          */

         tsap->endpCfgDone = FALSE;

         cmMemset((U8 *)&(tsap->endpCb), 0, sizeof(MgEndpCb));

         tsap->nxtSuAssocId = 0;

         tsap->assocIdWrpd = FALSE;

         if ((retVal = cmHashListInit(&(tsap->endpCb.assocCp),
                                      (U16)tsap->tsapCfg.numBinsAssocHl,
                                      0, FALSE, CM_HASH_KEYTYPE_DEF,
                                      mgCb.init.region, mgCb.init.pool))
               != ROK)
         {
            RETVALUE(LCM_REASON_MEM_NOAVAIL);
         }

         cmLListInit(&tsap->termAssocsCp);
      }

#endif    /* GCP_PROV_SCTP */
#ifdef   GCP_PROV_MTP3
     if (tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3)
      {
         S16   retVal;
         Bool  dupFlg=TRUE;

         /*
          * if GCP layer is working as MGC then no duplicate entry should be 
          * there in DPC based hash list but if GCP layer is working as MG
          * then for each VMG there can be same MGC .so duplicate entry can
          * be there in DPC list 
          */

#ifdef   GCP_MGC
         if(mgCb.genCfg.entType == LMG_ENT_GC)
            dupFlg = FALSE;
#endif   /* GCP_MGC */            

         /*
          *   initialize MTP3 related fields in tsap
          */
         tsap->sInfo = ((tsap->tsapCfg.mgMtpNwCfg.subService << 6)| MGCO_SI);

         tsap->mtpRstStart = FALSE;

         /* initialize tpt server  hash list */
         /* mg002.105: Removed compilation warning */
         offset = (U16)(((PTR) &(((MgPeerCb *) 0)->mgcoMtpHlEnt)));
         if ((retVal = cmHashListInit(&(tsap->mgcoMtpHlCp),
                               (U16)tsap->tsapCfg.mgMtpNwCfg.maxBinsMgcoMtpHl,
                               offset, dupFlg, CM_HASH_KEYTYPE_DEF,
                               mgCb.init.region, mgCb.init.pool)) != ROK)
         {
            RETVALUE(LCM_REASON_MEM_NOAVAIL);
         }
      /* mg004.105: Initialize restart end timer */
      cmInitTimers(&tsap->rstEndTmr, 1);
      }
#endif   /* GCP_PROV_MTP3 */

   }

   /* copy reconfiguration structure */
   cmMemcpy((U8 *)&tsap->tsapCfg.reCfg, (U8 *)&cfg->reCfg,sizeof(MgTSAPReCfg));

#ifdef ZG
   /* 
    * If Tsap was already configured and changeOver flag is true..this means new
    * service provider has come up..so update post structure 
    */
   if (tsap->cfgDone)
   {
      if(cfg->reCfg.changeOver == TRUE)
      {
         /* set up TSAP Pst structure */
         tsap->spPst.prior = cfg->reCfg.dstPst.prior;
         tsap->spPst.route = cfg->reCfg.dstPst.route;
         tsap->spPst.selector = cfg->reCfg.dstPst.selector;
         tsap->spPst.region = cfg->reCfg.dstPst.region;
         tsap->spPst.pool = cfg->reCfg.dstPst.pool;
         tsap->spPst.dstProcId = cfg->reCfg.dstPst.dstProcId;
         tsap->spPst.dstEnt = cfg->reCfg.dstPst.dstEnt;
         tsap->spPst.dstInst = cfg->reCfg.dstPst.dstInst;
         tsap->tsapCfg.spId = cfg->reCfg.spId;
      }
   }
#endif /* ZG */

#ifdef MG_RUG
   tsap->remIntfValid = FALSE;

   if (cfg->remIntfValid == TRUE)
   {
      tsap->remIntfValid = TRUE;
      tsap->spPst.intfVer = cfg->remIntfVer;
   }

   /* 
    * if the remote ver is not configured by LM, check if we already have
    * the needed information stored in the version structure.
    */
   verInfo = &(mgCb.verInfo);

   if (tsap->remIntfValid == FALSE)
   {
      found = FALSE;

      for (indx = 0; indx < verInfo->numIntfInfo && found == FALSE; indx++)
      {
         if (verInfo->intfInfo[indx].intf.intfId == HITIF)
         {
            switch (verInfo->intfInfo[indx].grpType)
            {
               case SHT_GRPTYPE_ALL:
               {
                  if ((verInfo->intfInfo[indx].dstProcId == cfg->dstProcId) &&
                      (verInfo->intfInfo[indx].dstEnt.ent == cfg->dstEnt) &&
                      (verInfo->intfInfo[indx].dstEnt.inst == cfg->dstInst))
                  {
                     found = TRUE;
                  }
               }
               break;
                  
               case SHT_GRPTYPE_ENT:
               {
                  if ((verInfo->intfInfo[indx].dstEnt.ent == cfg->dstEnt) &&
                      (verInfo->intfInfo[indx].dstEnt.inst == cfg->dstInst))
                  {
                     found = TRUE;
                  }
               }
               break;

               default:
                  /* not possible */
                  break;
            }
         }
      }

      if (found == TRUE)
      {
         tsap->spPst.intfVer = verInfo->intfInfo[indx-1].intf.intfVer;
         tsap->remIntfValid = TRUE;
      }
   }
#endif /* MG_RUG */

   /* DNS setup procedure */
#ifdef CM_DNS_LIB


   if ((tsap->tsapCfg.provType == LMG_PROV_TYPE_TUCL) &&
       (cfg->reCfg.dnsCfg.dnsAccess == LMG_DNS_USE_DNSLIB))
   {
      if ((ret = mgSetUpDns(tsap, TRUE)) != LCM_REASON_NOT_APPL)
         RETVALUE(ret);
   }
#endif /* CM_DNS_LIB */



   if ((tsap->tsapCfg.provType == LMG_PROV_TYPE_TUCL) &&
       (cfg->reCfg.dnsCfg.dnsAccess == LMG_DNS_USE_INET))
      tsap->dnsInfo.dnsState = MG_DNS_STATE_UP;


#ifdef GCP_MGCP
   if (cfg->reCfg.dnsCfg.dnsAccess != LMG_DNS_DISABLED)
   {
     tsap->ttl = cfg->reCfg.dnsCfg.ttl;
   }
#endif /* GCP_MGCP */


#ifdef    ZG
	/* mg002.105: Only need to call zgAddMapping() for the first configuration */
	if (tsap->cfgDone != TRUE)
	{
   ZG_INIT_RSETID_IN_MAPCB(&(tsap->mapCb));
   /* Do add mapping for tsap */
   zgAddMapping(ZG_CBTYPE_TSAP, (Ptr)tsap);

   if ((mgCb.dnsTsap != MG_INVALID_TSAP_ID) &&
       (tsap->tsapCfg.tSAPId == mgCb.dnsTsap))
   {
      ZG_INIT_RSETID_IN_MAPCB(&(tsap->dnsInfo.mapCb));
      zgAddMapping(ZG_CBTYPE_DNS, (Ptr)&(tsap->dnsInfo));
   }
	}
#endif /* ZG */

   /* Set tsap cfg flag */
   if (tsap->cfgDone != TRUE)
     tsap->cfgDone = TRUE;

   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgCfgTsap() */


/*
*
*       Fun:   mgAllocSrvrLst
*
*       Desc:  This function performs general configuration of MGCP
*              Control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failed
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgAllocSrvrLst
(
MgTSAPCfg           *cfg,               /* general configuration structure */
MgTSAPCb            *tsap               /* TSAP control block pointer      */
)
#else
PRIVATE U16 mgAllocSrvrLst(cfg, tsap)
MgTSAPCfg           *cfg;               /* general configuration structure */
MgTSAPCb            *tsap;              /* TSAP control block pointer      */
#endif
{
   S16             ret;                /* return value */
   U16             idx;                  /* temporary variable */
   Size            memSize;            /* memory size to be allocated */

   TRC2(mgAllocSrvrLst)

   ret     = LCM_REASON_NOT_APPL;
   memSize = (mgCb.genCfg.maxServers * sizeof(MgLstnrLst *));

  
   /* 
    * allocate space for the suconnId based UDP listener control block list
    * and zero it 
    */
   if ((tsap->lstnrLst = (MgLstnrLst **)mgMalloc(memSize)) == NULLP)
   {
      RETVALUE(LCM_REASON_MEM_NOAVAIL);
   }

   /* need to allocate space for each entry */
   memSize = sizeof(MgLstnrLst);
   for(idx = 0; idx < mgCb.genCfg.maxServers; idx++)
   {
      *(tsap->lstnrLst + idx) = NULLP;

      if ((tsap->lstnrLst[idx] = (MgLstnrLst *)mgMalloc(memSize)) == NULLP)
      {
         MG_REM_ALLOC_SRVR_MEM(tsap,idx);      /* added tsap */
      }
   }
  
   /* initialize the listener id list */
   MG_INIT_LSTNRID_LST(mgCb.genCfg.maxServers,tsap);

   RETVALUE(ret);

} /* end of mgAllocSrvrLst() */


/*  The above func & the corresponding deAlloc func
 *        should be called ONLY if the TSAP is not for SCTP
 */





#ifdef CM_DNS_LIB

/*
*
*       Fun:   mgSetUpDns
*
*       Desc:  This function allocates DNS Control Block and Server. And if
*              required opens a UDP socket for sending Queries to DNS later
*
*       Ret:   LCM_REASON_MEM_NOAVAIL   - Failed
*              ROK                      - Successful
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE S16 mgSetUpDns
(
MgTSAPCb           *tsap,             /* TSAP Control Block */
Bool               byCfg
)
#else
PRIVATE S16 mgSetUpDns (tsap, byCfg)
MgTSAPCb           *tsap;              /* TSAP Control Block */
Bool               byCfg;
#endif
{
   CmTptAddr       tptAddr;            /* Transport Address */
   Mem             mem;                /* Memory Region and Pool */
   Bool            allocSrvr;          /* Allocated Transport Server */
   MgSrvrInitInfo  initInfo;           /* Initialisation Information */
   TRC2(mgSetUpDns)

   MG_INIT_ADDR_ANY(tptAddr);

   /* Allocate Server for contacting DNS */
   if (tsap->dnsInfo.dnsLstnr == NULLP)
   {
      initInfo.transportType = LMG_TPT_UDP;
      initInfo.encodingScheme = LMG_NONE;
      initInfo.srvrType = LMG_NONE;
#ifdef ZG
      initInfo.suConnId = MG_INVALID_LSTNRID;
      initInfo.peerId = MG_INVALID_PEERID;
#endif /* ZG */

      if ((mgAllocSrvrCb(&initInfo, &tptAddr, NULLP, NULLP, NULLP, 
                         (Ptr*)&tsap->dnsInfo.dnsLstnr, tsap)) != ROK)
      {
         RETVALUE(LCM_REASON_MEM_NOAVAIL);
      }

      /* Store the tsap info in the DNS listener */
      tsap->dnsInfo.dnsLstnr->tsap = tsap;

      allocSrvr = TRUE;
   }
   else
   {
      allocSrvr = FALSE;
   }

   /* Allocate DNS Control Block */
   if (tsap->dnsInfo.dnsCb == NULLP)
   {
      tsap->dnsInfo.dnsCb = (CmDnsCb *)mgMalloc(sizeof(CmDnsCb));

      if (tsap->dnsInfo.dnsCb == NULLP)
      {
         mgDeAlloc((Data *)tsap->dnsInfo.dnsLstnr, sizeof(MgTptSrvr));
         tsap->dnsInfo.dnsLstnr = NULLP;
         RETVALUE(LCM_REASON_MEM_NOAVAIL);
      }

      MG_GET_MEM_ID(mem);

      /* Initialise DNS Control Block for Later use */
      if ((mgInitDnsCb(tsap->dnsInfo.dnsCb, (U16)MG_DNS_RQST_LST_SZ, &mem, 
                       &(tsap->tsapCfg.reCfg.dnsCfg.dnsAddr),
                       tsap)) == RFAILED)
      {
         mgDeAlloc((Data *)tsap->dnsInfo.dnsLstnr, sizeof(MgTptSrvr));
         mgDeAlloc((Data *)tsap->dnsInfo.dnsCb, sizeof(CmDnsCb));
         tsap->dnsInfo.dnsLstnr = NULLP;
         tsap->dnsInfo.dnsCb = NULLP;
         RETVALUE(LCM_REASON_MEM_NOAVAIL);
      }
   }

   /* Open the DNS Server if required */
#ifdef ZG_DFTHA
   if ((zgChkCRsetStatus()) == TRUE) 
#endif /* ZG_DFTHA */
   {
      if (tsap->state == LMG_SAP_BND_ENB && allocSrvr == TRUE)
      {
         MG_ENA_DNS_LSTNR(tsap, &(tsap->tsapCfg.reCfg.tptParam));
      }
   }

#ifdef ZG
   if(allocSrvr == TRUE)
   {
      ZG_INIT_RSETID_IN_MAPCB(&(tsap->dnsInfo.dnsLstnr->mapCb));
      zgAddMapping(ZG_CBTYPE_TPTSRVR,(Ptr)tsap->dnsInfo.dnsLstnr);
   }
   if(byCfg == FALSE)
   {
      if(allocSrvr == TRUE) 
      {
         zgRtUpd(ZG_CBTYPE_TPTSRVR,(Ptr)tsap->dnsInfo.dnsLstnr,
             CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_ADD);  
      }
      else
      {
         zgRtUpd(ZG_CBTYPE_TPTSRVR,(Ptr)tsap->dnsInfo.dnsLstnr,
             CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);  
      }
   }
#endif /* ZG */
      
   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgSetUpDns() */

#endif /* CM_DNS_LIB */


/******************************************************************************/
/*                   SSAP Configuration Support Functions                     */
/******************************************************************************/
/*
*
*       Fun:   mgCfgSsap
*
*       Desc:  This function configures an SSAP in MGCP layer.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCfgSsap
(
MgSSAPCfg          *cfg                /* SSAP configuration structure */
)
#else
PRIVATE U16 mgCfgSsap(cfg)
MgSSAPCfg          *cfg;               /* SSAP configuration structure */
#endif
{
   MgSSAPCb        *ssap;             /* ssap pointer */

/* 
 *
 * #ifdef    GCP_PROV_SCTP
 *    U32             numTsaps;
 * #endif
 */


   TRC2(mgCfgSsap);

   
   /* have to have general configuration done first */
   if (mgCb.init.cfgDone == FALSE)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG183, (ErrVal)MG_NONE,
                " General Cfg Not Done");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      RETVALUE(LCM_REASON_GENCFG_NOT_DONE);
   }



   /*
    *   go through the list of all the TSAPs;
    *   return failure if any of them has not been configured;
    *
    *    Following check for all the TSAPs is not really
    *          needed
    */

/*
 * #ifdef    GCP_PROV_SCTP
 * 
 *    for (numTsaps=0; numTsaps < mgCb.genCfg.maxTSaps; ++numTsaps)
 *    {
 *       if(!((mgCb.tSAPLst[numTsaps]) &&
 *            (mgCb.tSAPLst[numTsaps]->cfgDone == TRUE)))
 *       {
 * 
 * #if (ERRCLASS & ERRCLS_INT_PAR)
 *                MGLOGERROR(ERRCLS_INT_PAR, EMG184, (ErrVal)MG_NONE,
 *                            "Tsap cfg not done.");
 * #endif
 * 
 *                RETVALUE(LMG_REASON_TSAPCFG_NOT_DONE);
 *       }
 *    }
 * 
 * #else
*/


   /* get out the pointer to the SSAP from the SSAP list */
   if (cfg->sSAPId >= mgCb.genCfg.maxSSaps)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG185, (ErrVal)cfg->sSAPId,
                  "Invalid SSAP ID.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);
   }
   
   ssap = *(mgCb.sSAPLst + cfg->sSAPId);

   /* first time configuration */
   if (ssap == NULLP)
   {

#ifdef GCP_MG
      if (cfg->mwdTimer == 0)
      {
         RETVALUE(LCM_REASON_INVALID_PAR_VAL);
      }
#endif /* GCP_MG */

      /* allocate the SSAP and put it in the SSAP list */
      if ((ssap = (MgSSAPCb *)mgMalloc(sizeof(MgSSAPCb))) == NULLP)
      {
         RETVALUE(LCM_REASON_MEM_NOAVAIL);
      }

       /* copy the configuration information into the SSAP */
      cmMemcpy((U8 *)&ssap->ssapCfg, (U8 *)cfg, sizeof(MgSSAPCfg));

      /* store ID and other SSAP information, and the configuration */
      ssap->suId = 0;
      ssap->state = LMG_SAP_UBND_DIS;
      ssap->resCong = FALSE;
      ssap->numPeerRslvd = 0;
      ssap->enbIndSent = FALSE;

#ifdef GCP_MGCO
      ssap->numTcpLosses = 0;
#endif /* GCP_MGCO */

#ifdef GCP_MG
#ifdef GCP_MGCO
      cmLListInit(&ssap->mgcoUDPSrvrLst.srvrLstCp);
      ssap->nxtUseMgcoSrvr = NULLP;
#endif /* GCP_MGCO */

#ifdef GCP_MGCP
      cmLListInit(&ssap->mgcpUDPSrvrLst.srvrLstCp);
      ssap->nxtUseMgcpSrvr = NULLP;
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
      ssap->crntMgc = NULLP;
      ssap->mgType = MG_NONE;  
      /* initialize lock/unlock flag */
      ssap->lockUnlock = FALSE;
#endif /* GCP_MGCO */
#endif /* GCP_MG */

      /*
       * The MGC GCP stack can also initiate txns on its own e.g.
       * a service change Handoff to a MG (as a result of Control MGC)
       */
      ssap->nxtTransId = ssap->ssapCfg.startTxnNum;
      
      ssap->suPst.prior = cfg->prior;
      ssap->suPst.route = cfg->route;
      ssap->suPst.selector = cfg->sel;
      ssap->suPst.region = cfg->memId.region;
      ssap->suPst.pool = cfg->memId.pool;
      ssap->suPst.dstProcId = PROCIDNC;
      ssap->suPst.dstEnt = ENTNC;
      ssap->suPst.dstInst = INSTNC;
      ssap->suPst.srcProcId = mgCb.init.procId;
      ssap->suPst.srcEnt = mgCb.init.ent;
      ssap->suPst.srcInst = mgCb.init.inst;
      ssap->suPst.event = EVTNONE;

	  ssap->alarmIndSent = FALSE;		/* added by cdw on 2006.9.28 */

#ifdef MG_RUG
      ssap->suPst.dstProcId = cfg->dstProcId;
#endif /* MG_RUG */

      /* Inititalize peerLst and lstnrList */
      cmLListInit(&ssap->peerLst);

#ifdef ZG
      ZG_INIT_RSETID_IN_MAPCB(&(ssap->mapCb));
      /* Do add mapping for ssap */
      zgAddMapping(ZG_CBTYPE_SSAP, (Ptr)ssap);
#endif /* ZG */

      /* place the SSAP in the SSAP list */
      *(mgCb.sSAPLst + cfg->sSAPId) = ssap;      

#ifdef MG_RUG
      ssap->remIntfValid = FALSE;

      if (cfg->remIntfValid == TRUE)
      {
         ssap->remIntfValid = TRUE;
         ssap->suPst.intfVer = cfg->remIntfVer;
         /* Mark version controlling entity as Layer Manager for 
          * SSAP if version configuration is done by the LM
          */
         ssap->verContEnt = ENTSM; /* version controller is SM */
      }
      else
         ssap->verContEnt = ENTNC; /* version controller unknown */
#endif /* MG_RUG */
   }
   else   /* reconfiguration */
   {
#ifdef GCP_USE_PEERID
      MgPeerCb    *peer;
      U32         idx = 0;

      /* Reset the retx timer value if it has been changed in all peers */
      if(mgCb.peerLst != NULLP)
      {
         peer = mgCb.peerLst[idx]->peer;
         while(peer != NULLP)
         {
           if(cfg->reCfg.initRetxTmr.enb != TRUE)
              break;
           if(ssap->ssapCfg.reCfg.initRetxTmr.val != cfg->reCfg.initRetxTmr.val)
           {
               MG_SET_PEER_INIT_RTO (cfg->reCfg.initRetxTmr.val, peer);
           }
           idx++;
           peer = mgCb.peerLst[idx]->peer;
         }
      }
      /* copy only the recfg information */
      cmMemcpy((U8 *)&ssap->ssapCfg.reCfg, (U8 *)&cfg->reCfg, 
               sizeof(MgSSAPReCfg));

#ifdef MG_RUG
      if (cfg->remIntfValid == TRUE)
      {
         ssap->remIntfValid = TRUE;
         ssap->suPst.intfVer = cfg->remIntfVer;
      }
#endif /* MG_RUG */
#endif /* GCP_USE_PEERID */
   }

   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgCfgSsap() */



/******************************************************************************/
/*                  Peer Entity  Configuration Support Functions              */
/******************************************************************************/

/*
*
*       Fun:   mgCfgGcpEnt
*
*       Desc:  This function configures an MGCP peer entity.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCfgGcpEnt
(
MgGcpEntCfg        *cfg                /* Peer Configuration Structure */
)
#else
PRIVATE U16 mgCfgGcpEnt(cfg)
MgGcpEntCfg        *cfg;               /* Peer Configuration Structure */
#endif
{
   U16             i;                  /* Temporary variable */
   U16             cause;              /* Usta Cause */
   Bool            resolve;            /* Resolve Peer or not */
   MgPeerInitInfo  peerInitInfo;       /* Peer Initialisation Information */
   MgSSAPCb        *ssap;              /* SSAP Control Block */
   MgPeerCfg       *peerCfg;           /* Peer Configuration Information */
   MgPeerCb        *peer;              /* Peer Control Block */

/* 
 *
 * #ifdef    GCP_PROV_SCTP
 *    U32             numTsaps;
 * #endif
 */

   TRC2(mgCfgGcpEnt)


   peer = NULLP;
   ssap = NULLP;

   /* have to have general configuration done first */
   if (mgCb.init.cfgDone == FALSE)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG186, (ErrVal)MG_NONE,
                  "Gen cfg not done.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      RETVALUE(LCM_REASON_GENCFG_NOT_DONE);
   }





   /*
    *   go through the list of all the TSAPs;
    *   return failure if any of them has not been configured;
    *
    *    Following check for all the TSAPs is not needed;
    *          the TSAP for peerCfg->tsapId is checked further
    *          down the code and is sufficient
    */

/*
 * #ifdef    GCP_PROV_SCTP
 * 
 *    for (numTsaps=0; numTsaps < mgCb.genCfg.maxTSaps; ++numTsaps)
 *    {
 *       if(!((mgCb.tSAPLst[numTsaps]) &&
 *            (mgCb.tSAPLst[numTsaps]->cfgDone == TRUE)))
 *       {
 * 
 * #if (ERRCLASS & ERRCLS_INT_PAR)
 *                MGLOGERROR(ERRCLS_INT_PAR, EMG187, (ErrVal)MG_NONE,
 *                            "Tsap cfg not done.");
 * #endif
 * 
 *                RETVALUE(LMG_REASON_TSAPCFG_NOT_DONE);
 *       }
 *    }
 * 
 * 
 * #else
*/


/* #ifdef GCP_USE_PEERID */
   if ((mgCb.curNumPeer + cfg->numPeer) > mgCb.genCfg.maxPeer)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG188, (ErrVal)cfg->numPeer,
                  "Number of peer entries exceeded the maximum");
#endif  /* (ERRCLASS & ERRCLS_INT_PAR) */
      RETVALUE(LCM_REASON_EXCEED_CONF_VAL);
   }
/* #endif */ /* GCP_USE_PEERID */

  /*  
   *  go through the list of peers. if SSAP associated with
   *  the peer will be enabled in future we do not resolve 
   *  the peer now. If the SSAP has been enabled and active
   *  in our layer the peer config must be a dynamic addition
   *  which should be resolved now.
   *  We do not allow dynamic addition if we are in the process
   *  of activating the SSAP
   */
      
   resolve = FALSE;

   for(i=0; i < cfg->numPeer; i++)
   {

      peerCfg = &cfg->peerCfg[i];

      /* mg004.105: Added check on ssaps in peerCfg */      
      if ((peerCfg->sSAPId >= mgCb.genCfg.maxSSaps) ||
          (peerCfg->sSAPId < 0))
      {
         mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                     LMG_EVENT_PEER_CFG_FAIL,
                     LMG_CAUSE_INVALID_SSAP, LMG_ALARMINFO_PEER,
                     (Ptr)&(peerCfg->sSAPId), sizeof(SpId), 
                     LMG_ALARMINFO_INVSAPID);
        continue;
      }

      ssap = *(mgCb.sSAPLst + peerCfg->sSAPId);

      if (ssap == NULLP)
      {
        mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                    LMG_EVENT_PEER_CFG_FAIL,
                    LMG_CAUSE_INVALID_SSAP, LMG_ALARMINFO_PEER,
                    (Ptr)&(peerCfg->sSAPId), sizeof(SpId), 
                    LMG_ALARMINFO_INVSAPID);
        continue;
      }

      if((ssap->state == LMG_SAP_BND_ENB) || 
         (ssap->state == LMG_SAP_UBND_ENB))
      {
         if(ssap->enbIndSent == TRUE)
            resolve = TRUE;
         else
         {
           mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                       LMG_EVENT_PEER_CFG_FAIL,
                       LMG_CAUSE_SSAP_INACTIVE, LMG_ALARMINFO_PEER,
                       (Ptr)&(peerCfg->sSAPId), sizeof(SpId),
                       LMG_ALARMINFO_INVSAPID);
           continue;
         }
      }
      else
      {
         /* 
          * If ssap is not enabled the peer will get resolved when the
          * ssap is enabled. Therefore there is no need to resolve it 
          */
         resolve = FALSE;
      }

      
#ifdef GCP_MGCO 
      if(LMG_PROTOCOL_MGCO == ssap->ssapCfg.protocol)
      {
         if( (NULLP == peerCfg->mid.val) ||
             (0 == peerCfg->mid.len) ||
             (PRSNT_NODEF != peerCfg->mid.pres) )
         {
            mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                        LMG_EVENT_PEER_CFG_FAIL,
                        LMG_CAUSE_INVALID_PARMS, LMG_ALARMINFO_PEER,
                        (Ptr)&(peerCfg->sSAPId), sizeof(SpId),
                        LMG_ALARMINFO_INVSAPID);
            continue;
         }
      }
#endif
      
      /* Initialize the peerinfo structure */
      mgFillPeerInitInfo(peerCfg, &peerInitInfo);

      /*
       * allocate, initialize peer. selects peerId. inits various lists and 
       * timers 
       */
      peer = mgAllocPeerCb (ssap,&peerInitInfo);

      if (peer == NULLP)
      {
         mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL,
                       LMG_EVENT_PEER_CFG_FAIL,
                       LMG_CAUSE_RSRC_UNAVAIL, LMG_ALARMINFO_PEER,
                       NULLP, 0, LMG_ALARMINFO_INVSAPID);
         continue;
      }



#ifdef    GCP_MG
      if (mgCb.genCfg.entType == LMG_ENT_GW)
      {

         /*
          *   Link peer and tsap on the MG side;
          *   On the MGC side, this linkage is established
          *   on receiving the service change message
          *    New param tsap Id needed in MgPeerCfg
          */
         /* mg002.105: Removed compilation warning */
         if ((peerCfg->tsapId >= (SuId)0) &&
             (peerCfg->tsapId < (S16)mgCb.genCfg.maxTSaps) &&
             (mgCb.tSAPLst[peerCfg->tsapId]) &&
             (mgCb.tSAPLst[peerCfg->tsapId]->cfgDone == TRUE))
         {
            peer->tsap = mgCb.tSAPLst[peerCfg->tsapId];
         }
         else
         {
#ifdef GCP_MGCO
            /*
             *   Fill cause in the following macro
             */
            MG_ISSUE_MGCOPEER_STAIND(peer, LCM_CATEGORY_INTERNAL, 
                                     LMG_EVENT_PEER_CFG_FAIL, cause);
#endif /* GCP_MGCO */
            mgDeletePeer(peer, MG_IGNORE, MG_IGNORE, TRUE);
            continue;
         }

      }
#endif    /* GCP_MG */



      if (resolve == TRUE)
      {
         if ((cause = mgResolvePeer(peer)) != LCM_REASON_NOT_APPL)
         {
            /* Use existing MGCP/MGCO specific macros */
            if (LMG_PROTOCOL_MGCO == peer->mntInfo.protocolType) 
            {
#ifdef GCP_MGCO
               MG_ISSUE_MGCOPEER_STAIND(peer, LCM_CATEGORY_INTERNAL, 
                                 LMG_EVENT_PEER_CFG_FAIL, cause);
#endif /* GCP_MGCO */
            }
            else
            {
#ifdef GCP_MGCP 
               MG_ISSUE_MGCPPEER_STAIND(peer, LCM_CATEGORY_INTERNAL, 
                                 LMG_EVENT_PEER_CFG_FAIL, cause);
#endif /* GCP_MGCP */
            }
            mgDeletePeer(peer, MG_IGNORE, MG_IGNORE, TRUE);
            continue;
         }
      }
#ifdef ZG
      ZG_INIT_RSETID_IN_MAPCB(&(peer->mapCb));
      zgAddMapping(ZG_CBTYPE_PEER,(Ptr)peer);
      /* Generate update for peer */
      zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_ADD);
      zgUpdPeer();
#endif /* ZG */

   }/* for each peer in the table */

   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgCfgGcpEnt() */

#ifdef ZG
#ifdef GCP_MGCO
#ifdef GCP_MGC
/*
*
*       Fun:   mgCfgMtdGcpEnt
*
*       Desc:  This function configures an  peer entity in mated pair cfg.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCfgMtdGcpEnt
(
MgMtdGcpEntCfg        *cfg             /* Peer Configuration Structure */
)
#else
PRIVATE U16 mgCfgMtdGcpEnt(cfg)
MgMtdGcpEntCfg        *cfg;            /* Peer Configuration Structure */
#endif
{
   U16             cause;              /* Usta Cause */
   Bool            resolveAct;         /* Resolve Peer or not */
   Bool            resolveStd;         /* Resolve Peer or not */
   Bool            actPeerExist;       /* Active Peer already exists ? */
   MgPeerInitInfo  peerInitInfo;       /* Peer Initialisation Information */
   MgSSAPCb        *ssapAct;           /* SSAP Control Block */
   MgSSAPCb        *ssapStd;           /* SSAP Control Block */
   MgPeerCfg       *actPeerCfg;        /* Peer Configuration Information */
   MgPeerCfg       *stdPeerCfg;        /* Peer Configuration Information */
   MgPeerCb        *actPeer;           /* Active Peer Control Block */
   MgPeerCb        *stdPeer;           /* Standby Peer Control Block */

   TRC2(mgCfgMtdGcpEnt)

   actPeer = NULLP;
   stdPeer = NULLP;

   /* have to have general configuration done first */
   if (mgCb.init.cfgDone == FALSE)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG189, (ErrVal)MG_NONE,
                  "Gen cfg not done.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      RETVALUE(LCM_REASON_GENCFG_NOT_DONE);
   }



   /*
    *   go through the list of all the TSAPs;
    *   return failure if any of them has not been configured;
    *
    *    checking all the TSAPs is not required;
    *          checking just the peer->tsapId TSAPs is sufficient
    */

/*
 * #ifdef    GCP_PROV_SCTP
 * 
 *    for (numTsaps=0; numTsaps < mgCb.genCfg.maxTSaps; ++numTsaps)
 *    {
 *       if(!((mgCb.tSAPLst[numTsaps]) &&
 *            (mgCb.tSAPLst[numTsaps]->cfgDone == TRUE)))
 *       {
 * 
 * #if (ERRCLASS & ERRCLS_INT_PAR)
 *                MGLOGERROR(ERRCLS_INT_PAR, EMG190, (ErrVal)MG_NONE,
 *                            "Tsap cfg not done.");
 * #endif
 * 
 *                RETVALUE(LMG_REASON_TSAPCFG_NOT_DONE);
 *       }
 *    }
 * 
 * #else
*/



  /*  
   *  For mated peer configuration there will be  only two peer , 
   *  one active and one standby. Here active peer may exist..but standBy peer
   *  should not exist. so first check whether active already exists..if yes
   *  then just configure standby, if it doesn't exist then first configure 
   *  active MG then standby. if SSAP associated with the peer will be enabled
   *  in future we do not resolve the peer now. If the SSAP has been 
   *  enabled and active in our layer the peer config must be a dynamic 
   *  addition which should be resolved now.We do not allow dynamic addition 
   *  if we are in the process of activating the SSAP.
   */
      
   resolveAct = FALSE;
   resolveStd = FALSE;
   actPeerExist = FALSE;
   

   actPeerCfg = &cfg->actPeerCfg;
   stdPeerCfg = &cfg->stdPeerCfg;
   /* get MID string for active peer..and check if it exists */
   if((actPeerCfg->mid.pres == PRSNT_NODEF) 
         && (NULLP != actPeerCfg->mid.val))
   {
      cmHashListFind(&(mgCb.peerNameLst), (U8 *)(actPeerCfg->mid.val),
         actPeerCfg->mid.len, MG_HASH_SEQNMB_DEF, (PTR *) &actPeer);
   }
   if(actPeer != NULLP)
   {
      actPeerExist = TRUE;
   }
   
   ssapAct = *(mgCb.sSAPLst + actPeerCfg->sSAPId);
   ssapStd = *(mgCb.sSAPLst + stdPeerCfg->sSAPId);

   /* mg004.105: Added check on ssaps in peerCfg */      
   /*  Added SSAP range check */
   if ((actPeerCfg->sSAPId >= mgCb.genCfg.maxSSaps) ||
       (actPeerCfg->sSAPId < 0))
   {
       mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                  LMG_EVENT_MTDPEER_CFG_FAIL,
                  LMG_CAUSE_INVALID_SSAP, LMG_ALARMINFO_PEER,
                  (Ptr)&(actPeerCfg->sSAPId), sizeof(SpId), 
                  LMG_ALARMINFO_INVSAPID);
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);
   }

   /*  Added SSAP range check */
   if ((stdPeerCfg->sSAPId >= mgCb.genCfg.maxSSaps) ||
       (stdPeerCfg->sSAPId < 0))
   {
     mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                  LMG_EVENT_MTDPEER_CFG_FAIL,
                  LMG_CAUSE_INVALID_SSAP, LMG_ALARMINFO_PEER,
                  (Ptr)&(stdPeerCfg->sSAPId), sizeof(SpId), 
                  LMG_ALARMINFO_INVSAPID);
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);
   }


   if (ssapAct == NULLP)
   {
      mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                  LMG_EVENT_MTDPEER_CFG_FAIL,
                  LMG_CAUSE_INVALID_SSAP, LMG_ALARMINFO_PEER,
                  (Ptr)&(actPeerCfg->sSAPId), sizeof(SpId), 
                  LMG_ALARMINFO_INVSAPID);
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);
   }
   if (ssapStd == NULLP)
   {
      mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                  LMG_EVENT_MTDPEER_CFG_FAIL,
                  LMG_CAUSE_INVALID_SSAP, LMG_ALARMINFO_PEER,
                  (Ptr)&(stdPeerCfg->sSAPId), sizeof(SpId), 
                  LMG_ALARMINFO_INVSAPID);
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);
   }
   /* If active peer doesn't exist , then only resolve it */
   if((actPeerExist == FALSE) && ((ssapAct->state == LMG_SAP_BND_ENB) || 
      (ssapAct->state == LMG_SAP_UBND_ENB)))
   {
      if(ssapAct->enbIndSent == TRUE)
      {
         resolveAct = TRUE;
      }
      else
      {
         mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                     LMG_EVENT_MTDPEER_CFG_FAIL,
                     LMG_CAUSE_SSAP_INACTIVE, LMG_ALARMINFO_PEER,
                     (Ptr)&(actPeerCfg->sSAPId), sizeof(SpId), 
                     LMG_ALARMINFO_INVSAPID);
         RETVALUE(LCM_REASON_INVALID_STATE);
      }
   }
   else
   {
      /* 
         * If ssap is not enabled the peer will get resolved when the
         * ssap is enabled. Therefore there is no need to resolve it 
         */
      resolveAct = FALSE;
   }

   if((ssapStd->state == LMG_SAP_BND_ENB) || 
      (ssapStd->state == LMG_SAP_UBND_ENB))
   {
      if(ssapStd->enbIndSent == TRUE)
      {
         resolveStd = TRUE;
      }
      else
      {
         mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                     LMG_EVENT_MTDPEER_CFG_FAIL,
                     LMG_CAUSE_SSAP_INACTIVE, LMG_ALARMINFO_PEER,
                     (Ptr)&(stdPeerCfg->sSAPId), sizeof(SpId), 
                     LMG_ALARMINFO_INVSAPID);
         RETVALUE(LCM_REASON_INVALID_STATE);
      }
   }
   else
   {
      /* 
         * If ssap is not enabled the peer will get resolved when the
         * ssap is enabled. Therefore there is no need to resolve it 
         */
      resolveStd = FALSE;
   }


   if((NULLP == actPeerCfg->mid.val) || (0 == actPeerCfg->mid.len) || 
      (PRSNT_NODEF != actPeerCfg->mid.pres)) 
      
   {
      mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                  LMG_EVENT_MTDPEER_CFG_FAIL,
                  LMG_CAUSE_INVALID_PARMS, LMG_ALARMINFO_PEER,
                  (Ptr)&(actPeerCfg->sSAPId), sizeof(SpId), 
                  LMG_ALARMINFO_INVSAPID);
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);
   }

   if((NULLP == stdPeerCfg->mid.val) || (0 == stdPeerCfg->mid.len) ||
      (PRSNT_NODEF != stdPeerCfg->mid.pres))
   {
      mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                  LMG_EVENT_MTDPEER_CFG_FAIL,
                  LMG_CAUSE_INVALID_PARMS, LMG_ALARMINFO_PEER,
                  (Ptr)&(stdPeerCfg->sSAPId), sizeof(SpId), 
                  LMG_ALARMINFO_INVSAPID);
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);
   }
   if(actPeerExist == FALSE)
   {
      /* Initialize the peerinfo structure */
      mgFillPeerInitInfo(actPeerCfg, &peerInitInfo);
      peerInitInfo.mtdPeerId = MG_INVALID_PEERID;

      /*
         * allocate, initialize peer. selects peerId. inits various lists and 
         * timers 
         */
      actPeer = mgAllocPeerCb (ssapAct, &peerInitInfo);

      if (actPeer == NULLP)
      {
         mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                        LMG_EVENT_MTDPEER_CFG_FAIL,
                        LMG_CAUSE_RSRC_UNAVAIL, LMG_ALARMINFO_PEER,
                        NULLP, 0, LMG_ALARMINFO_INVSAPID);
         RETVALUE(LCM_REASON_MEM_NOAVAIL);
      }

#ifdef    GCP_MG
      if (mgCb.genCfg.entType == LMG_ENT_GW)
      {

         /*
          *   Link actPeer and tsap on the MG side;
          */
         /* mg002.105: Removed compilation warning */
         if ((actPeerCfg->tsapId >= (SuId)0) &&
             (actPeerCfg->tsapId < (S16)mgCb.genCfg.maxTSaps) &&
             (mgCb.tSAPLst[actPeerCfg->tsapId]) &&
             (mgCb.tSAPLst[actPeerCfg->tsapId]->cfgDone == TRUE))
         {
            actPeer->tsap = mgCb.tSAPLst[actPeerCfg->tsapId];
         }
         else
         {
            /*  Change cause value below */
            mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL,
                        LMG_EVENT_MTDPEER_CFG_FAIL,
                        LMG_CAUSE_RSRC_UNAVAIL, LMG_ALARMINFO_PEER,
                        NULLP, 0, LMG_ALARMINFO_INVSAPID);

            if(actPeerExist == FALSE)
            {
               /* Delete active peer only if it was created now */
               mgDeletePeer(actPeer, MG_IGNORE, MG_IGNORE, TRUE);
            }
            RETVALUE(LCM_REASON_MEM_NOAVAIL);
         }

      }
#endif    /* GCP_MG */


   }

   /* Initialize the peerinfo structure */
   mgFillPeerInitInfo(stdPeerCfg, &peerInitInfo);
   peerInitInfo.mtdPeerId = actPeer->accessInfo.peerId;

   /*
      * allocate, initialize peer. selects peerId. inits various lists and 
      * timers 
      */
   stdPeer = mgAllocPeerCb (ssapStd, &peerInitInfo);

   if (stdPeer == NULLP)
   {
      mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, LMG_EVENT_MTDPEER_CFG_FAIL,
                     LMG_CAUSE_RSRC_UNAVAIL, LMG_ALARMINFO_PEER,
                     NULLP, 0, LMG_ALARMINFO_INVSAPID);
      if(actPeerExist == FALSE)
      {
         /* Delete active peer only if it was created now */
         mgDeletePeer(actPeer, MG_IGNORE, MG_IGNORE, TRUE);
      }
      RETVALUE(LCM_REASON_MEM_NOAVAIL);
   }

#ifdef    GCP_MG
      if (mgCb.genCfg.entType == LMG_ENT_GW)
      {

         /*
          *   Link actPeer and tsap on the MG side;
          */
         /* mg002.105: Removed compilation warning */
         if ((stdPeerCfg->tsapId >= (SuId)0) &&
             (stdPeerCfg->tsapId < (S16)mgCb.genCfg.maxTSaps) &&
             (mgCb.tSAPLst[stdPeerCfg->tsapId]) &&
             (mgCb.tSAPLst[stdPeerCfg->tsapId]->cfgDone == TRUE))
         {
            stdPeer->tsap = mgCb.tSAPLst[stdPeerCfg->tsapId];
         }
         else
         {
            /*  Change cause value below */
            mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL,
                        LMG_EVENT_MTDPEER_CFG_FAIL,
                        LMG_CAUSE_RSRC_UNAVAIL, LMG_ALARMINFO_PEER,
                        NULLP, 0, LMG_ALARMINFO_INVSAPID);

            if(actPeerExist == FALSE)
            {
               /* Delete active peer only if it was created now */
               mgDeletePeer(actPeer, MG_IGNORE, MG_IGNORE, TRUE);
            }
            mgDeletePeer(stdPeer, MG_IGNORE, MG_IGNORE, TRUE);
            RETVALUE(LCM_REASON_MEM_NOAVAIL);
         }

      }
#endif    /* GCP_MG */


   if (resolveAct == TRUE)
   {
      if ((cause = mgResolvePeer(actPeer)) != LCM_REASON_NOT_APPL)
      {
         /* send status ind */
         MG_ISSUE_MGCOPEER_STAIND(actPeer, LCM_CATEGORY_INTERNAL, 
                              LMG_EVENT_MTDPEER_CFG_FAIL, cause);
      }
      if(actPeerExist == FALSE)
      {
         /* Delete active peer only if it was created now */
         mgDeletePeer(actPeer, MG_IGNORE, MG_IGNORE, TRUE);
      }
      mgDeletePeer(stdPeer, MG_IGNORE, MG_IGNORE, TRUE);
      RETVALUE(LCM_REASON_MEM_NOAVAIL);
   }
   if (resolveStd == TRUE)
   {
      if ((cause = mgResolvePeer(stdPeer)) !=  LCM_REASON_NOT_APPL)
      {
         /* send status ind */
         MG_ISSUE_MGCOPEER_STAIND(actPeer, LCM_CATEGORY_INTERNAL, 
                              LMG_EVENT_MTDPEER_CFG_FAIL, cause);
      }
      if(actPeerExist == FALSE)
      {
         /* Delete active peer only if it was created now */
         mgDeletePeer(actPeer, MG_IGNORE, MG_IGNORE, TRUE);
      }
      mgDeletePeer(stdPeer, MG_IGNORE, MG_IGNORE, TRUE);
      RETVALUE(LCM_REASON_MEM_NOAVAIL);
   }
   if(actPeerExist == FALSE)
   {
      /* send add mapping only if ..it was created now */
      ZG_INIT_RSETID_IN_MAPCB(&(actPeer->mapCb));
      zgAddMapping(ZG_CBTYPE_PEER,(Ptr)actPeer);
   }
   /* Now update mated peer info */ 

   actPeer->mgcoInfo.peerType = MG_ACTIVE;
   stdPeer->mgcoInfo.peerType = MG_STANDBY;
      
   actPeer->mgcoInfo.t.matedMG = stdPeer;
   stdPeer->mgcoInfo.t.matedMG = actPeer;

   /* Generate update for active peer */
   if(actPeerExist == FALSE)
   {
      zgRtUpd(ZG_CBTYPE_PEER, (Ptr)actPeer, CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_ADD);
   }
   else
   {
      zgRtUpd(ZG_CBTYPE_PEER, (Ptr)actPeer, CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
   }

   /* Do ZG initilizations for standby peer */
   ZG_INIT_RSETID_IN_MAPCB(&(stdPeer->mapCb));
   zgAddMapping(ZG_CBTYPE_PEER,(Ptr)stdPeer);
   zgRtUpd(ZG_CBTYPE_PEER, (Ptr)stdPeer, CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_ADD);

   zgUpdPeer();
   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgCfgMtdGcpEnt() */

#endif /* GCP_MGC */
#endif /* GCP_MGCO */
#endif /* ZG */

/*
*
*       Fun:   mgFillPeerInitInfo
*
*       Desc:  This function configures an MGCP peer entity.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgFillPeerInitInfo
(
MgPeerCfg          *peerCfg,           /* Peer Configuration Information */
MgPeerInitInfo     *peerInitInfo       /* Peer Initialisation Information */
)
#else
PRIVATE U16 mgFillPeerInitInfo(peerCfg, peerInitInfo)
MgPeerCfg          *peerCfg;           /* Peer Configuration Information */
MgPeerInitInfo     *peerInitInfo;      /* Peer Initialisation Information */
#endif
{
   MgSSAPCb        *ssap;              /* SSAP Control Block */
   U16             nameLen;            /* Name Length */

   TRC2(mgFillPeerInitInfo)

   ssap    = *(mgCb.sSAPLst + peerCfg->sSAPId);
   nameLen = cmStrlen(peerCfg->name);

   cmMemset((U8 *)peerInitInfo, 0, sizeof(MgPeerInitInfo));

   cmMemcpy((U8 *)peerInitInfo->name, (U8 *)peerCfg->name, nameLen);
   
   if (nameLen < CM_DNS_DNAME_LEN)
     peerInitInfo->name[nameLen]  ='\0';
  
   cmMemcpy((U8 *)&peerInitInfo->addrTbl, 
            (U8 *)&peerCfg->peerAddrTbl,sizeof(MgNetAddrTbl));
  
   peerInitInfo->byCfg = TRUE;
   peerInitInfo->protocolType   = ssap->ssapCfg.protocol;

#ifdef ZG
   peerInitInfo->peerId = MG_INVALID_PEERID;
   peerInitInfo->mtdPeerId = MG_INVALID_PEERID;
#ifdef ZG_DFTHA
   peerInitInfo->suConnId = MG_INVALID_LSTNRID;
#endif /* ZG_DFTHA */
#endif /* ZG */

#ifdef GCP_MG
   peerInitInfo->transportType  = peerCfg->transportType;
#endif /* GCP_MG */

#ifdef GCP_MGCO 
#ifdef GCP_MG
   if (ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCO)
   {
#ifdef GCP_VER_1_5     
     peerInitInfo->variant        = LMG_VER_PROF_MGCO_H248_2_0;
#else
     peerInitInfo->variant        = LMG_VER_PROF_MGCO_H248_1_0;
#endif
     peerInitInfo->encodingScheme = peerCfg->encodingScheme;
     peerInitInfo->useAHScheme    = peerCfg->useAHScheme;
     peerInitInfo->mgcoVersion    = ssap->ssapCfg.maxMgcoVersion;
     peerInitInfo->priority       = peerCfg->mgcPriority;
   }
#endif /* GCP_MG */
#endif /* GCP_MGCO */
  
#ifdef GCP_MGCP
   if (ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCP)
   {
#ifdef GCP_MG
     peerInitInfo->variant = ssap->ssapCfg.mgcpVersion;
#endif /* GCP_MG */
     peerInitInfo->mgcpInfo.suspThold   = peerCfg->peerReCfg.suspThold;
     peerInitInfo->mgcpInfo.disconThold = peerCfg->peerReCfg.disconThold;
     peerInitInfo->ttl         = peerCfg->ttl;
   }
#endif /* GCP_MGCP */

   if (ssap->ssapCfg.reCfg.initRetxTmr.enb == TRUE)
   {
      peerInitInfo->initRtt = ssap->ssapCfg.reCfg.initRetxTmr.val;
   }
   else
      peerInitInfo->initRtt = (MG_INIT_RTT_VALUE * mgCb.genCfg.timeRes);

   peerInitInfo->trcLen      = 1024;/*MG_DEFAULT_TRC_LEN;*/
   peerInitInfo->mtuSize     = peerCfg->mtuSize;
   peerInitInfo->remotePort  = peerCfg->port;

   /* Fill MID in the structure */
#ifdef GCP_MGCO 
   if (ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCO)
   {
      MG_INIT_MID(peerInitInfo->mid, peerCfg->mid);
   }
#endif


#ifdef    GCP_PROV_SCTP

   if (peerInitInfo->transportType == LMG_TPT_SCTP)
   {
      U16   cntr;

      cmMemset((U8 *)&(peerInitInfo->assocCfg), 0, sizeof(MgAssocCfg));

      /*
       *   since this function is called only from peer configuration
       *   related functions, pass peerInitInfo->allocAssocCfg as TRUE
       *   since peer->assocCfg needs to be allocated in the peer
       *   configuration function
       */

      peerInitInfo->allocAssocCfg  = TRUE;

      /*
       *   if locOutStrms is present in the peer configuration structure
       *      then use it to fill the locOutStrms of assocCfg
       *      else use the default value of maximum outgoing streams
       */

      if (peerCfg->locOutStrms)
         peerInitInfo->assocCfg.locOutStrms = peerCfg->locOutStrms;
      else
         peerInitInfo->assocCfg.locOutStrms = LMG_MAX_OUT_STRMS;


      /*
       *   copy the SCTP related info from peerInitInfo to assocCfg;
       *   the first address in the list is assumed to be the
       *   primary dest addr to be used for SCTP
       */

      peerInitInfo->assocCfg.priDstAddr = peerInitInfo->addrTbl.netAddr[0];

      /* mg002.105: Removed compilation warning */
      peerInitInfo->assocCfg.dstAddrLst.nmb = (U8)peerInitInfo->addrTbl.count;

      for (cntr=0; cntr < peerInitInfo->addrTbl.count; ++cntr)
         peerInitInfo->assocCfg.dstAddrLst.nAddr[cntr] =
            peerInitInfo->addrTbl.netAddr[cntr];

      /* if remotePort is absent (-1), then use 2944 port */

      peerInitInfo->assocCfg.remPort = 
                  (peerInitInfo->remotePort == -1) ?
                      MG_MGCO_DEFAULT_TEXT_PORT : (peerInitInfo->remotePort);

#ifdef    GCP_MG
      /* mg001.105: If TOS is provided in the peer cfg, use it;
       *            else use the default value */
      if (PRSNT_NODEF == peerCfg->tos.pres)
         peerInitInfo->tos = peerCfg->tos.val;
      else
         peerInitInfo->tos = LMG_DFLT_SCTP_TOS;
#endif /* GCP_MG */
   }

#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
   if (peerInitInfo->transportType == LMG_TPT_MTP3)
   {
      peerInitInfo->peerDpc   =  peerCfg->peerDpc;

      /* 
       * tsap Need to be valid as our Dpc based hash list is in tsap .If tsap is 
       * invalid then we are unable to add this peerCb to our hash list 
       */
      if((mgCb.tSAPLst[peerCfg->tsapId]) &&
            (mgCb.tSAPLst[peerCfg->tsapId]->cfgDone == TRUE))
      {
         peerInitInfo->tsap = mgCb.tSAPLst[peerCfg->tsapId];
      }
      else
         peerInitInfo->tsap = NULLP;
   }
#endif   /* GCP_PROV_MTP3 */   


   RETVALUE(ROK);

} /* end of mgFillPeerInitInfo() */



/*
*
*       Fun:   mgResolvePeer
*
*       Desc:  This function configures an MGCP peer entity.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgResolvePeer
(
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PRIVATE U16 mgResolvePeer (peer)
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
   Bool            peerReady;         /* Peer Ready for Resolution */

   TRC2(mgResolvePeer)

   peerReady = FALSE;

   if(peer->accessInfo.peerAddrTbl.count > 0)
   {
      peerReady = TRUE;
   }
   else
   {
     if (peer->accessInfo.namePres)
     {
       /* need to resolve */
       peer->state = LMG_PEER_STATE_RESOLVING;
       if ((mgSendDnsRslvReq(peer, peer->accessInfo.name)) != ROK)
         RETVALUE(LMG_CAUSE_RSRC_UNAVAIL);
     }
     else
     {
       RETVALUE(LMG_CAUSE_INVALID_PARMS);
     }
   }

   /* If peer has already been resolved */
   if(peerReady)
   {
      /* Use existing MGCP/MGCO specific macros */
      if (LMG_PROTOCOL_MGCO == peer->mntInfo.protocolType) 
      {
#ifdef GCP_MGCO
         MG_ISSUE_MGCOPEER_STAIND(peer, LCM_CATEGORY_INTERNAL, 
                     LMG_EVENT_PEER_ENABLED, LMG_CAUSE_MGMT_INITIATED);
#endif /* GCP_MGCO */
      }
      else
      {
#ifdef GCP_MGCP 
         MG_ISSUE_MGCPPEER_STAIND(peer, LCM_CATEGORY_INTERNAL, 
                     LMG_EVENT_PEER_ENABLED, LMG_CAUSE_MGMT_INITIATED);
#endif /* GCP_MGCP */
      }
   }

   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgResolvePeer() */ 


/******************************************************************************/
/*                  Transport Server Configuration Support Functions          */
/******************************************************************************/

/*
*
*       Fun:   mgCfgTptServer
*
*       Desc:  This function configures an MGCP peer entity.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCfgTptServer
(
MgTptSrvrCfg       *cfg                /* Transport Server Configuration */
)
#else
PRIVATE U16 mgCfgTptServer(cfg)
MgTptSrvrCfg       *cfg;               /* Transport Server Configuration */
#endif
{
   S16             ret;                /* Return Value */
   U16             i;                  /* Temporary Variable */
   MgSrvrInitInfo  initInfo;           /* Initialisation Information */
   MgTptSrvSta     srvrSta;            /* Server Status Information */
   MgSrvrCfg       *srvrCfg;           /* Server Configuration */
   MgTptSrvr       *tptSrvr = NULLP;   /* Transport Server */
   MgSSAPCb        *ssap;              /* SSAP Control Block */
   MgTSAPCb        *tsap;              /* TSAP Control Block */

   TRC2(mgCfgTptServer)

   /* have to have general configuration done first */
   if (mgCb.init.cfgDone == FALSE)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG191, (ErrVal)MG_NONE,
                " General Cfg Not Done");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      RETVALUE(LCM_REASON_GENCFG_NOT_DONE);
   }



   if (cfg->count > LMG_MAX_DEF_LSTNR)
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);

   for (i=0; i < cfg->count;i++)
   {
      srvrCfg = &(cfg->srvr[i]);

#ifdef GCP_MGCO
      srvrSta.encodingScheme = srvrCfg->encodingScheme;
#endif /* GCP_MGCO */

      initInfo.transportType  = srvrCfg->transportType;

#ifdef GCP_MG
      if ((mgCb.genCfg.entType == LMG_ENT_GW) &&
          (srvrCfg->transportType == LMG_NONE))
      {
         MG_SEND_SRVR_STAIND(srvrCfg->transportType,
                             srvrCfg->lclTptAddr, LMG_LSTNR_STATE_NULL,
                             LMG_CAUSE_INVALID_PARMS, srvrSta);
        continue;
      }
#endif /* GCP_MG */


#ifdef GCP_MGCO
      if (srvrCfg->protocol == LMG_PROTOCOL_MGCO)
      {
         initInfo.encodingScheme = srvrCfg->encodingScheme;
    
      }
      else
#endif /* GCP_MGCO */
      {
        initInfo.encodingScheme = LMG_ENCODE_TXT;
      }
#ifdef ZG
     initInfo.suConnId = MG_INVALID_LSTNRID;
     initInfo.peerId = MG_INVALID_PEERID;
#endif /* ZG */


      if (srvrCfg->sSAPId < 0)
        ssap = NULLP;
      else
        ssap = *(mgCb.sSAPLst + srvrCfg->sSAPId);
    
      /*
       *   Has this TUCL TSAP Config happened ?
       *   Only the TUCL TSAPs have to be checked since
       *   UDP/TCP servers are to be opened only on
       *   the TUCL TSAPs : 
       */

      if ((srvrCfg->tSAPId < (SuId)0) ||
          (srvrCfg->tSAPId >= (SuId)mgCb.genCfg.maxTSaps) ||
          (mgCb.tSAPLst[srvrCfg->tSAPId] == NULLP) ||
#ifdef GCP_PROV_SCTP
          (mgCb.tSAPLst[srvrCfg->tSAPId]->endpCfgDone == TRUE) ||
#endif /* GCP_PROV_SCTP */
          (mgCb.tSAPLst[srvrCfg->tSAPId]->tsapCfg.provType
                    != LMG_PROV_TYPE_TUCL))
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
               MGLOGERROR(ERRCLS_INT_PAR, EMG192, (ErrVal)MG_NONE,
                           "Tsap cfg not done.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */  
               continue;
      }

      tsap = mgCb.tSAPLst[srvrCfg->tSAPId];


#ifdef GCP_MGCO
      if (srvrCfg->protocol == LMG_PROTOCOL_MGCO)
         ret = mgGetMgcoSrvrType(&initInfo, srvrCfg);
#endif /* GCP_MGCO */

#ifdef GCP_MGCP
      if (srvrCfg->protocol == LMG_PROTOCOL_MGCP)
         ret = mgGetMgcpSrvrType(&initInfo, srvrCfg);
#endif /* GCP_MGCP */


      if (ret != ROK)
      {
        MG_SEND_SRVR_STAIND(srvrCfg->transportType, 
                             srvrCfg->lclTptAddr, LMG_LSTNR_STATE_NULL,
                             LMG_CAUSE_INVALID_PARMS, srvrSta);
         continue;
      }

      /* mg004.105: Server Reconfig is not allowed. Even if we get a cfg req
         for a already existing server we should just ignore it */
      tptSrvr = mgFindTptSrvr(&srvrCfg->lclTptAddr);

      if (tptSrvr != NULLP)
      {
         continue;
      }


      ret = mgAllocSrvrCb(&initInfo, &(srvrCfg->lclTptAddr), 
                          &(srvrCfg->tptParam), 
                          ssap, NULLP, (Ptr*)&tptSrvr, tsap);

      if (ret != ROK)
      {
         MG_SEND_SRVR_STAIND(srvrCfg->transportType,
                             srvrCfg->lclTptAddr, LMG_LSTNR_STATE_NULL,
                             LMG_CAUSE_RSRC_UNAVAIL, srvrSta);
         continue;
      }


      /* link the tsap and the allocated server */
      tptSrvr->tsap = tsap;

      
#ifdef ZG
      ZG_INIT_RSETID_IN_MAPCB(&(tptSrvr->mapCb));
      zgAddMapping(ZG_CBTYPE_TPTSRVR, (Ptr)tptSrvr);
      zgRtUpd(ZG_CBTYPE_TPTSRVR, (Ptr)tptSrvr, CMPFTHA_UPDTYPE_SYNC,
             CMPFTHA_ACTN_ADD);
#endif /* ZG */

#ifdef GCP_MG
      if (mgCb.genCfg.entType == LMG_ENT_GW && ssap != NULLP)
      {
         /* 
          * If the servers are attached to the SSAP(only on MG side),
          * and ssap has already been enabled. Start servers from here 
          */
         if ((tptSrvr->srvrType == MG_ROUND_ROBIN_SRVR_MGCO) ||
             (tptSrvr->srvrType == MG_ROUND_ROBIN_SRVR_MGCP))
         {
            if (((ssap->state == LMG_SAP_BND_ENB) ||
                (ssap->state == LMG_SAP_UBND_ENB)) &&
                (ssap->enbIndSent == TRUE))
            {
#ifdef ZG
               /* Only master should send server open request */
               if(((zgChkCRsetStatus()) == TRUE))
#endif
               {
                  if ((mgSrvOpenReq(tptSrvr, &(srvrCfg->tptParam),
                                    &(srvrCfg->lclTptAddr))) != ROK) 
                  {
                     mgDeAllocSrvrCb(tptSrvr);

                     MG_SEND_SRVR_STAIND(srvrCfg->transportType, 
                                          srvrCfg->lclTptAddr, 
                                       LMG_LSTNR_STATE_NULL,
                                       LMG_CAUSE_RSRC_UNAVAIL,srvrSta);
                     continue;
                  }
               }
            }
            continue;
         }
      } /* MG */
#endif /* GCP_MG */

#ifdef ZG
      /* Only master should send server open request */
      if(((zgChkCRsetStatus()) == TRUE))
#endif
      {
         if (tsap->state == LMG_SAP_BND_ENB)
         {
            if ((mgSrvOpenReq(tptSrvr, &(srvrCfg->tptParam),
                              &(srvrCfg->lclTptAddr))) != ROK) 
            {
               MG_SEND_SRVR_STAIND(srvrCfg->transportType, 
                                 srvrCfg->lclTptAddr, 
                                 LMG_LSTNR_STATE_NULL,
                                 LMG_CAUSE_RSRC_UNAVAIL,srvrSta);
               continue;
            }
         }
      }
#ifdef ZG
      zgRtUpd(ZG_CBTYPE_TPTSRVR, (Ptr)tptSrvr, CMPFTHA_UPDTYPE_SYNC,
             CMPFTHA_ACTN_MOD);
      zgUpdPeer();
#endif /* ZG */
   } /* end of for  */

   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgCfgTptServer() */




/******************************************************************************/
/*                   Statistics Request Support Functions                     */
/******************************************************************************/



#ifdef CM_DNS_LIB
/*
*
*       Fun:   mgSetTsapSts
*
*       Desc:  Fills the peer statistics information.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgSetTsapSts
(
MgTSAPSts          *tsapSts,           /* TSAP Statistics */
MgTSAPSts          *stsReq,            /* Statistics Request Structure */
Action             action             /* action to be done */
)
#else
PRIVATE U16 mgSetTsapSts(tsapSts, stsReq, action)
MgTSAPSts          *tsapSts;           /* TSAP Statistics */
MgTSAPSts          *stsReq;            /* Statistics Request Structure */
Action             action;             /* action to be done */
#endif
{
   TRC2(mgSetTsapSts)

   /* copy the statistics information from the TSAP */      
   cmMemcpy((U8 *)tsapSts, (U8 *)stsReq, sizeof(MgTSAPSts));
                                                            
   /* zero the statistics if required */                    
   if (action == ZEROSTS)                                   
   {
      cmMemset((U8 *)stsReq, 0, sizeof(MgTSAPSts));
   }

   RETVALUE(ROK);

} /* end of mgSetTsapSts() */

#endif /* CM_DNS_LIB */


/*
*
*       Fun:   mgSetPeerSts
*
*       Desc:  Fills the peer statistics information.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgSetPeerSts
(
MgPeerEntSts       *peerEntSts,        /* status structure */
Action             action              /* Action */
)
#else
PRIVATE U16 mgSetPeerSts(peerEntSts, action)
MgPeerEntSts       *peerEntSts;        /* status structure */
Action             action;             /* Action */
#endif
{
   MgPeerCb        *peer;              /* Peer Control Block */
   MgSSAPCb        *ssap;              /* pointer to session SAP */
   MgPeerInfo      *peerInfo;          /* Peer Information */

   TRC2(mgSetPeerSts)

   peer     = NULLP;
   peerInfo = &peerEntSts->peerInfo;

   if ((peerEntSts->sapId >= (SpId)mgCb.genCfg.maxSSaps) || 
       (peerEntSts->sapId < 0))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG193, peerEntSts->sapId,
                 "mgSetPeerSts():spId out of range");
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);
   }
   ssap = *(mgCb.sSAPLst + peerEntSts->sapId);

   peer     = mgLocatePeer(peerInfo, ssap);

   if (peer == NULLP)
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);

   cmMemcpy((U8 *)&peerEntSts->peerSts, (U8 *)&peer->peerSts,sizeof(MgPeerSts));

   if (action == ZEROSTS)
   {
      cmMemset((U8 *)&peer->peerSts, 0, sizeof(MgPeerSts));
      peer->peerSts.sSAPId = peerEntSts->peerSts.sSAPId;
   }

   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgSetPeerSts() */


/******************************************************************************/
/*                   Status Request Support Functions                         */
/******************************************************************************/

/*
*
*       Fun:   mgGetTsapSta
*
*       Desc:  Fills the peer statistics information.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/

#ifdef ANSI
PRIVATE U16 mgGetTsapSta
(
MgTSAPSta          *tSAPSta,           /* TSAP Status Structure */
MgTSAPCb           *tsap               /* TSAP Cb pointer */
)
#else
PRIVATE U16 mgGetTsapSta(tSAPSta,tsap)
MgTSAPSta          *tSAPSta;           /* TSAP Status Structure */
MgTSAPCb           *tsap;              /* TSAP Cb pointer */
#endif

{
   U16             numMgcpSrvrs;       /* Number of MGCP Servers */
   U16             numMgcoSrvrs;       /* Number of MEGACO Servers */


   TRC2(mgGetTsapSta)


   numMgcpSrvrs = 0;
   numMgcoSrvrs = 0;

#ifdef MG_RUG
   /* TSAP version info */
   tSAPSta->selfIntfVer = HITIFVER;
   tSAPSta->remIntfValid = tsap->remIntfValid;
   tSAPSta->remIntfVer = tsap->spPst.intfVer;
#endif /* MG_RUG */

   tSAPSta->resCong = tsap->resCong;
   tSAPSta->state   = tsap->state;

#ifdef GCP_MGCP
   numMgcpSrvrs = (U16) cmLListLen(&(tsap->mgcpUDPSrvrLst.srvrLstCp));
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
#ifdef GCP_MGC
   numMgcoSrvrs = (U16) cmLListLen(&(tsap->mgcoUDPSrvrLst.srvrLstCp)) +
                  (U16) cmLListLen(&(tsap->tcpSrvrInfo.srvrLstCp));
#endif /* GCP_MGC */
#endif /* GCP_MGCO */

   tSAPSta->numServers = numMgcpSrvrs + numMgcoSrvrs;

   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgGetTsapSta() */




/*
*
*       Fun:   mgGetSsapSta
*
*       Desc:  Fills the peer statistics information.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgGetSsapSta
(
MgMngmt            *sta,               /* Status Structure */
Pst                *post               /* Post Structure */
)
#else
PRIVATE U16 mgGetSsapSta(sta, post)
MgMngmt            *sta;               /* Status Structure */
Pst                *post;              /* Post Structure */
#endif
{
   U16             i;                  /* Temporary Variable */
   U16             ret;                /* result */
   U16             reason = LCM_REASON_NOT_APPL; /* result reason */
   MgSSAPSta       *sSapSta;           /* SSAP Status */
   MgSSAPCb        *ssap;            /* SSAP Control Block */
   MgPeerCb        *peer;              /* Peer Control Block */
   CmLListCp       *lCp;               /* Linked List Control Point */
   CmLList         *tmp;               /* Linked List Node */
   U16             numMgcpSrvrs;       /* Number of MGCP Servers */
   U16             numMgcoSrvrs;       /* Number of MEGACO Servers */

   TRC2(mgGetSsapSta);

   numMgcpSrvrs = 0;
   numMgcoSrvrs = 0;

   sSapSta = &sta->t.ssta.s.mgSSAPSta;

   /* Initialize result and reason */
   ret = LCM_REASON_NOT_APPL;

   MG_MI_VALIDATE_SSAP(ssap,sSapSta->sapId, ret);

#ifdef MG_RUG
   /* SSAP version info */
   sSapSta->selfIntfVer = MGTIFVER;
   sSapSta->remIntfValid = ssap->remIntfValid;
   sSapSta->remIntfVer = ssap->suPst.intfVer;
#endif /* MG_RUG */

   sSapSta->state     = ssap->state;


#ifdef GCP_MG
   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
#ifdef GCP_MGCP
      numMgcpSrvrs = (U16) cmLListLen(&(ssap->mgcpUDPSrvrLst.srvrLstCp));
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
      numMgcoSrvrs = (U16) cmLListLen(&(ssap->mgcoUDPSrvrLst.srvrLstCp));
#endif /* GCP_MGCO */
   }
#endif /* GCP_MG */


   sSapSta->numServers = numMgcpSrvrs + numMgcoSrvrs;
#ifdef GCP_MGCO 
   sSapSta->numTCPlosses = ssap->numTcpLosses;
#endif /* GCp_MGCO */

   sSapSta->more     = FALSE;

   lCp = &(ssap->peerLst);
   i=0;
   for(tmp=lCp->first;tmp;tmp=tmp->next)
   {
      peer = (MgPeerCb *)(tmp->node);

      /* 
       * Fill MgPeerInfo properly, using the existing macros.
       * Remove the existing code for filling peerInfo 
       */
#ifdef GCP_MGCP
      if(LMG_PROTOCOL_MGCP == peer->mntInfo.protocolType)
      {
         MG_COPY_PEERINFO_INTO_MGCPTXN(sSapSta->peerInfo[i], peer);
      }
#endif /* GCP_MGCP */
#ifdef GCP_MGCO 
      if(LMG_PROTOCOL_MGCO == peer->mntInfo.protocolType)
      {
         MG_COPY_PEERINFO_INTO_MGCOMSG(sSapSta->peerInfo[i], peer);
      }
#endif /* GCP_MGCO */

      i++;
      if(i >= LMG_MAX_PEER_ENT)
      {
         if (tmp->next != NULLP)
         {
            /* 
             * Number of Peers could be more than array size,
             * send more status Confirms 
             */  
            sSapSta->numAssocPeer = LMG_MAX_PEER_ENT;
            sSapSta->more = TRUE;
            /* Send Status Confirm */
            mgSendLmCfm(TSSTA, ret, reason, post, sta);
            i = 0;
            sSapSta->more = FALSE;
         }
      }
   }

   sSapSta->numAssocPeer = (U16)i;
   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgGetSsapSta() */


/*
*
*       Fun:   mgGetPeerSta
*
*       Desc:  Fills the peer status information.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgGetPeerSta
(
MgPeerSta          *peerSta            /* Peer Status Structure */
)
#else
PRIVATE U16 mgGetPeerSta(peerSta)
MgPeerSta          *peerSta;           /* Peer Status Structure */
#endif
{
   MgPeerCb        *peer;              /* Peer Control Block */
   U16             nameLen;            /* Domain Name Length */
   Bool            done;        
#ifdef GCP_MGCP
   MgIpAddrEnt     *addrEnt;           /* address entry */
#endif /* GCP_MGCP */

   TRC2(mgGetPeerSta)

   /*
    * Obtain peerCb from information provided.
    */

   peer = NULLP;
   done = FALSE;

#ifdef GCP_USE_PEERID
   /* Get peer from peer id if peer id is present */
   if (peerSta->peerId.pres != NOTPRSNT)
   {
      if (peerSta->peerId.val != MG_INVALID_PEERID)
      {
         /* Implies gateway Id is present */
         if (peerSta->peerId.val < mgCb.genCfg.maxPeer)
         {
            peer = (*(mgCb.peerLst)[peerSta->peerId.val]).peer;
         }
      }
   }
#endif /* GCP_USE_PEERID */

   /* 
    * Ensure that the peer is searched on the basis of MID in case
    * of MEGACO. 
    */
#ifdef GCP_MGCO
   if((NULLP == peer) && (PRSNT_NODEF == peerSta->mid.pres))
   {
      done = TRUE;
      if(done)
      {
         /* do nothing */
      }
      nameLen = peerSta->mid.len;
      /* Search for peer based on MID */
      MG_FIND_PEER_FROM_DOMAIN_INFO(&(mgCb.peerNameLst),
                        (peerSta->mid.val), nameLen, peer);
   }
#endif /* GCP_MGCO */

#ifdef GCP_MGCP
   if( (NULLP == peer) && (FALSE == done) )
   {
      if ((peerSta->peerAddrTbl.netAddr[0].type  == CM_NETADDR_IPV4) ||
          (peerSta->peerAddrTbl.netAddr[0].type  == CM_NETADDR_IPV6))
      {
         /* Check if IP Address can be used to locate Peer */
         addrEnt = NULLP;
         mgFindIpAddrLst(peerSta->peerAddrTbl.netAddr[0].type,
                         &(peerSta->peerAddrTbl.netAddr[0].u.ipv4NetAddr),
                         &(peerSta->peerAddrTbl.netAddr[0].u.ipv6NetAddr),
                         0, &addrEnt);
         if (addrEnt != NULLP)
            peer = addrEnt->peer;
      }
      else
      {
         nameLen =  cmStrlen((CONSTANT U8 *) (peerSta->name));   
         /* Check if domain name can be used to locate Peer */
         MG_FIND_PEER_FROM_DOMAIN_INFO(&(mgCb.peerNameLst),(peerSta->name),
                                    nameLen, peer);
      }
      /* If the peer was found in this "if" condition, then this must be a
       * MGCP peer. Just confirm this */
      if( (NULLP != peer) && (LMG_PROTOCOL_MGCP != peer->mntInfo.protocolType) )
      {
         RETVALUE(LCM_REASON_INVALID_PAR_VAL);
      }
   }
#endif /* GCP_MGCP */
   if(NULLP == peer)
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);

   /*
    * Modify filling of MgPeerSta to refelect the modified MgPeerSta structure
    * where MgPeerInfo has been remeoved and 4 new fields have been added
    * instead
    */
   /* Update Contents of peerInfo structure */
#ifdef GCP_USE_PEERID
   peerSta->peerId.pres = PRSNT_NODEF;
   peerSta->peerId.val  = peer->accessInfo.peerId;
#endif /* GCP_USE_PEERID */

   /*
    * Before filling domain name, check whether the domain name is present?
    */
   if(TRUE == peer->accessInfo.namePres)
   {
      peerSta->namePres.pres = PRSNT_NODEF;
      nameLen = cmStrlen(peer->accessInfo.name);       
      cmMemcpy((U8 *)&peerSta->name,peer->accessInfo.name, nameLen);
      if (nameLen < CM_DNS_DNAME_LEN)
         peerSta->name[nameLen] = '\0';
   }

   cmMemcpy((U8 *)&peerSta->peerAddrTbl,
            (CONSTANT U8 *)&peer->accessInfo.peerAddrTbl, sizeof(MgNetAddrTbl));

   peerSta->peerState       = peer->state;
   peerSta->sSapId          = peer->ssap->suId;
   peerSta->protocol        = peer->mntInfo.protocolType;
   peerSta->transportType   = peer->accessInfo.transportType;
#ifdef GCP_MGCO
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
   {
     peerSta->encodingScheme  = peer->mgcoInfo.encodingScheme;
     /*
      * Instead of copying the negotiatedVersion, provide the LM with LMG hash
      * define.
      */
      if(MG_MGCOVER_1_0 == peer->mgcoInfo.negotiatedVersion)
      {
         peerSta->version = LMG_VER_PROF_MGCO_H248_1_0;
      }
#ifdef GCP_VER_1_5      
      else if(MG_MGCOVER_2_0 == peer->mgcoInfo.negotiatedVersion)
      {
         peerSta->version = LMG_VER_PROF_MGCO_H248_2_0;
      }   
#endif      
      /* Fill MID */
      if(PRSNT_NODEF != peerSta->mid.pres)
      {
         MG_INIT_MID(peerSta->mid, peer->accessInfo.mid);
      }
   }
#endif /* GCP_MGCO */
#ifdef GCP_MGCP
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
   {
     peerSta->version         = peer->mntInfo.variant;
   }
#endif /* GCP_MGCP */
   peerSta->numPendOgTxn    = CM_HASH_NMBENT(&(peer->outTransLst));
   peerSta->numPendIcTxn    = CM_HASH_NMBENT(&(peer->inTransLst));
   peerSta->rttEstimate     = peer->mntInfo.rto;
                  
   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgGetPeerSta() */


/*
*
*       Fun:   mgGetTptSrvrSta
*
*       Desc:  Fills the peer status information.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgGetTptSrvrSta
(
MgTptSrvSta        *tptSrvrSta         /* Transport Server Status */
)
#else
PRIVATE U16 mgGetTptSrvrSta(tptSrvrSta)
MgTptSrvSta        *tptSrvrSta;        /* Transport Server Status */
#endif
{
   U16             i;                  /* Temporary variable */
   MgTptSrvr       *tptCb;             /* Transport Server Block */
   U32             k;                  /* Temporary variable */
   U8              match = 0;          /* Temporary variable */

   TRC2(mgGetTptSrvrSta)

      

   for (k=0; k < mgCb.genCfg.maxTSaps; k++)
   {
      if ((mgCb.tSAPLst[k]) &&
          (mgCb.tSAPLst[k]->tsapCfg.provType == LMG_PROV_TYPE_TUCL) &&
          (mgCb.tSAPLst[k]->state == LMG_SAP_BND_ENB))
      {
         for (i=0; i < mgCb.genCfg.maxServers; i++)
         {

            if (mgCb.tSAPLst[k]->lstnrLst[i])
               tptCb = (mgCb.tSAPLst[k]->lstnrLst[i])->lstnrCb;

            /* compare tptAddr. If same then server found. */
            if(tptCb != NULLP)
            {
               if ((match =
                    (!mgCmpTptAddr(&tptCb->tptAddr, &tptSrvrSta->tptAddr))))
               {
                  break;      /* for servers ... */
               }
            }
         }

         if (match)
         {
            break;      /* for TSAPs ... */
         }
      }
   }


   if (!match)
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);

   tptSrvrSta->transportType  = tptCb->transportType;
   tptSrvrSta->encodingScheme = tptCb->encodingScheme;
   tptSrvrSta->state          = tptCb->state;

   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgGetTptSrvrSta() */




#ifdef    GCP_PROV_SCTP
/*
*
*       Fun:   mgGetSctpEpSta
*
*       Desc:  Fills the endpoint status information.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgGetSctpEpSta
(
MgSctpEpSta        *mgSctpEpSta         /* Transport Server Status */
)
#else
PRIVATE U16 mgGetSctpEpSta(mgSctpEpSta)
MgSctpEpSta        *mgSctpEpSta;        /* Transport Server Status */
#endif
{
   MgEndpCb        *endpCb = NULLP;    /* end point Control Block */
   U32             i;                  /* loop counter */

   TRC2(mgGetSctpEpSta)


   /*
    *   Search in the list of TSAPs for the
    *   relevant TSAP/Endpoint;
    *   The searching is done by comparing
    *   the port in the endpCb with the
    *   mgSctpEpSta->port field in the sta request
    */


   for (i=0; i < mgCb.genCfg.maxTSaps; ++i)
   {
      if ((mgCb.tSAPLst[i]) &&
          (mgCb.tSAPLst[i]->endpCfgDone == TRUE) &&
          (mgCb.tSAPLst[i]->endpCb.port == mgSctpEpSta->port))
      {
         endpCb = &(mgCb.tSAPLst[i]->endpCb);
         break;         /* break through the for loop */
      }
   }


   /*
    *   Error - the endpoint could not be found
    */

   if (endpCb == NULLP)
       RETVALUE(LCM_REASON_INVALID_PAR_VAL);


   mgSctpEpSta->state = endpCb->epState;
   mgSctpEpSta->encodingScheme = endpCb->encodingScheme;

   RETVALUE(LCM_REASON_NOT_APPL);

}      /* mgGetSctpEpSta */
#endif /* GCP_PROV_SCTP */




/******************************************************************************/
/*                   Control Request Support Functions                        */
/******************************************************************************/

/******************************************************************************/
/*                   General Control Support Functions                        */
/******************************************************************************/
/*
*
*       Fun:   mgCntrlGen
*
*       Desc:  This function handles general control requests.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCntrlGen
(
MgCntrl            *cntrl              /* control structure */
)
#else
PRIVATE U16 mgCntrlGen(cntrl)
MgCntrl            *cntrl;             /* control structure */
#endif
{
   U16             ret;                /* Return Value */
   MgTSAPCb        *tsap;              /* DNS TSAP control block */


   TRC2(mgCntrlGen)


   /*
    *   If the TSAP for DNS is NOT available, then
    *   the control request to control the DNS is
    *   meaningless
    */
   if ((mgCb.dnsTsap == MG_INVALID_TSAP_ID) ||
       (mgCb.tSAPLst[mgCb.dnsTsap] == NULLP))
      tsap = NULLP;
   else
      tsap = mgCb.tSAPLst[mgCb.dnsTsap];


   /* set default return values */
   ret = LCM_REASON_NOT_APPL;

   switch (cntrl->action)
   {
      case ASHUTDOWN:
      {

#ifdef ZG
         ret = mgZgShutDown();
#else
         ret = mgShutdown();
#endif /* ZG */
         break;
      }

      case AENA:
      {
         if (cntrl->subAction == SAUSTA)
         {
            mgCb.init.usta = TRUE;
#ifdef ZG
            /* Generate update for mgCb */
            zgRtUpd(ZG_CBTYPE_GCP,(Ptr)&mgCb,CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_MOD);
            zgUpdPeer();
#endif /* ZG */
         }
         else 
         if (cntrl->subAction == SADBG)
         {
#ifdef DEBUGP
            mgCb.init.dbgMask |= cntrl->s.dbg.genDbgMask;
#ifdef ZG
            /* Generate update for mgCb */
            zgRtUpd(ZG_CBTYPE_GCP,(Ptr)&mgCb,CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_MOD);
            zgUpdPeer();
#endif /* ZG */
#endif
         }
         else if (cntrl->subAction == SADNS)
         {

            if (tsap == NULLP)
               RETVALUE(LCM_REASON_INVALID_SAP);

#ifdef CM_DNS_LIB

            /*  issue is when this control request is
             *        is the FIRST one to Enable the DNS;
             *        In this case mgCb.dnsTsap is unknown;
             *        A way out is to provide the tsapId in
             *        this control requst.
             *        However, if this is NOT the FIRST one
             *        to Enable DNS, then there is NO issue
             *        since we already know the tucl tsapId
             *
             *        It appears that this is NOT the FIRST one to
             *        Enable the DNS. The DNS has to be cfg-ed
             *        at the time of TSAP cfg. This cntrl req
             *        is just to enable it at run time.
             */

            tsap->tsapCfg.reCfg.dnsCfg.dnsAccess = LMG_DNS_USE_DNSLIB;

            if ((mgSetUpDns(tsap, FALSE)) != LCM_REASON_NOT_APPL)
               RETVALUE(LCM_REASON_MEM_NOAVAIL);


#else  /* CM_DNS_LIB */

            tsap->tsapCfg.reCfg.dnsCfg.dnsAccess = LMG_DNS_USE_INET;
            tsap->dnsInfo.dnsState = MG_DNS_STATE_UP;

#endif /* CM_DNS_LIB */

#ifdef ZG
           /* Send a runtime update message for TSAP for variables nxtConnIdx,
            * nxtFreeIdx, connIdxWrapArnd */
            zgRtUpd(ZG_CBTYPE_TSAP,(Ptr)(tsap),CMPFTHA_UPDTYPE_SYNC, 
                                                      CMPFTHA_ACTN_MOD);
            /* Generate update for DNS */
            zgRtUpd(ZG_CBTYPE_DNS,(Ptr)&(tsap->dnsInfo),CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD);
            zgUpdPeer();
#endif /* ZG */
         }
         else
            ret = LCM_REASON_INVALID_SUBACTION;
      }
      break;

      case ADISIMM:
      {
         if (cntrl->subAction == SAUSTA)
         {
            mgCb.init.usta =  FALSE;
#ifdef ZG
            /* Generate update for mgCb */
            zgRtUpd(ZG_CBTYPE_GCP,(Ptr)&mgCb,CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_MOD);
            zgUpdPeer();
#endif /* ZG */
         }
         else 
         if (cntrl->subAction == SADBG)
         {
            /*
             * Modify the statement to enable selective diabling of debugMask.
             */
#ifdef DEBUGP
            mgCb.init.dbgMask &= ~(cntrl->s.dbg.genDbgMask);
#endif /* DEBUGP */
#ifdef ZG
            /* Generate update for mgCb */
            zgRtUpd(ZG_CBTYPE_GCP,(Ptr)&mgCb,CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_MOD);
            zgUpdPeer();
#endif /* ZG */
         }
         else 
         if (cntrl->subAction == SADNS)
         {

            if (tsap == NULLP)
               RETVALUE(LCM_REASON_INVALID_SAP);

            tsap->tsapCfg.reCfg.dnsCfg.dnsAccess = LMG_DNS_DISABLED;

#ifdef CM_DNS_LIB
            if (tsap->dnsInfo.dnsCb != NULLP)
            {
               cmDnsDeInitDnsCb(tsap->dnsInfo.dnsCb); 
               mgDeAlloc((Data *)tsap->dnsInfo.dnsCb, sizeof(CmDnsCb));
               tsap->dnsInfo.dnsCb = NULLP;
            }

            if (tsap->dnsInfo.dnsLstnr != NULLP)
            {
               mgSrvDiscReq(tsap->dnsInfo.dnsLstnr, TRUE);
               tsap->dnsInfo.dnsLstnr = NULLP;
            }

#else  /* CM_DNS_LIB */
            tsap->dnsInfo.dnsState = MG_DNS_STATE_DOWN;
#endif /* CM_DNS_LIB */

#ifdef ZG
            /* For DNS server, update was already sent while sending disc req to
             * Hit Interface; Now Generate update for TSAPCb */
            zgRtUpd(ZG_CBTYPE_DNS,(Ptr)&(tsap->dnsInfo),CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_MOD);
            zgUpdPeer();
#endif /* ZG */
         }
         else
           ret = LCM_REASON_INVALID_SUBACTION;
      }
      break;

      default:
         RETVALUE(LCM_REASON_INVALID_ACTION);
        break;
   } 

   RETVALUE(ret);

} /* end of mgCntrlGen() */

#ifdef ZG
/*
*
*       Fun:   mgZgShutDown
*
*       Desc:  This function shuts down GCP layer, when ZG flag is defined.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC U16 mgZgShutDown
(
void
)
#else
PUBLIC U16 mgZgShutDown()
#endif
{
   U16             j;                  /* Temporary Value */
   U16             i;                  /* Temporary Value */
#ifdef CM_ABNF_MT_LIB
   Inst            tmpInst;            /* temp instance */
#endif /* CM_ABNF_MT_LIB */

   TRC2(mgZgShutDown)

   /* Free all memory associated with TSAP */
   if (mgCb.tSAPLst != NULLP)
   {
      for (i=0; i< mgCb.genCfg.maxTSaps; i++)
      {
         MgTSAPCb      *tsap = NULLP;

         tsap = mgCb.tSAPLst[i];

         if (tsap != NULLP)
         {     

            /* Free all memory associated with TSAP */
            if (tsap->cfgDone != FALSE)
            {
               tsap->state = LMG_SAP_DELETED;

               /* remove any mem allocated for TSAP listeners */
               if (tsap->lstnrLst != NULLP)
               {
                  for (j=0; j < mgCb.genCfg.maxServers;j++)
                  {
                     if (tsap->lstnrLst[j] != NULLP)
                     {
                        if (tsap->lstnrLst[j]->lstnrCb != NULLP)
                        {
                           mgDeAlloc((Data *)tsap->lstnrLst[j]->lstnrCb ,
                               sizeof(MgTptSrvr));
                           tsap->lstnrLst[j]->lstnrCb = NULLP;
                        }
                        mgDeAlloc((Data *)tsap->lstnrLst[j] ,
                               sizeof(MgLstnrLst));
                        tsap->lstnrLst[j]=NULLP;
                     }
                  }
                  mgDeAlloc((Data *)tsap->lstnrLst,
                           (mgCb.genCfg.maxServers * sizeof(MgLstnrLst *)));
                  tsap->lstnrLst = NULLP;
               }

#ifdef CM_DNS_LIB
               if ((mgCb.dnsTsap != MG_INVALID_TSAP_ID) &&
                   (tsap == mgCb.tSAPLst[mgCb.dnsTsap]) &&
                   (tsap->tsapCfg.provType == LMG_PROV_TYPE_TUCL) &&
                   (tsap->dnsInfo.dnsCb != NULLP))
               {

                  cmDnsDeInitDnsCb(tsap->dnsInfo.dnsCb); 
                  mgDeAlloc((Data *)tsap->dnsInfo.dnsCb, sizeof(CmDnsCb));
                  tsap->dnsInfo.dnsCb = NULLP;
               }
#endif /* CM_DNS_LIB */

               /*
                *   TCP Connection List is not deinitiatized here as we
                *   still need to free connections; This list is deinitialised
                *   towards the end of the function
                */
            }
         }
      }
   }



   /* Free all memory associated with SSAP */
   if (mgCb.sSAPLst != NULLP)
   {
      for (j=0; j< mgCb.genCfg.maxSSaps; j++)
      {
         MgSSAPCb      *ssap = NULLP;

         ssap = mgCb.sSAPLst[j];
         if (ssap != NULLP)
         {     
            MgPeerCb  *peer;
            CmLListCp *lCpPeer;
            CmLList   *tmpPeer;
#ifdef GCP_VER_1_3
            MgTxnAckList   *node;
#endif /* GCP_VER_1_3 */

            lCpPeer = &ssap->peerLst;
            tmpPeer = lCpPeer->first;
            while(tmpPeer)
            {
               peer = (MgPeerCb *)(tmpPeer->node);
               /* Remove all Transaction for this peer */
               mgRemoveAllTxn(MG_IGNORE, peer);
#ifdef GCP_MGCO 
               /* Free all TCP connectoin */
               {
                  CmLListCp *lCpTcp;
                  CmLList   *tmpTcp;

                  lCpTcp = &peer->mgcoInfo.tcpConnLst;
                  tmpTcp = lCpTcp->first;
                  while(tmpTcp)
                  {
                     MgTptSrvr    *tcpSrvr;
                     tcpSrvr = (MgTptSrvr *)(tmpTcp->node);
                     tmpTcp = tmpTcp->next;
                     mgDeAlloc((Data *)tcpSrvr, sizeof(MgTptSrvr));
                  }
               }
#endif /* GCP_MGCO */

#ifdef GCP_VER_1_3
               /* free all stored txn node..stop timers if started*/
               /* free each txnAckList node */
               node = peer->txnAckQ.next;
               while(node != NULLP)
               {
                  MgTxnAckList   *prv;
                  /* stop timer if started */
                  if(node->info.tmr.tmrEvnt == MG_30SEC_ACK_TMR)
                  {
                     mgStopTmr(node->info.tmr.tmrEvnt,(PTR)node,
                               &(node->info.tmr));
                  }
                  prv = node;
                  node = node->next;
                  mgDeAlloc((Data *)prv, sizeof(MgTxnAckList));
               }              
#endif /* GCP_VER_1_3 */
               /* Update DNS library, if resolution request is still pending */
#ifdef CM_DNS_LIB
               if (peer->dnsReq != NULLP)
               {
                  mgPutMsg(peer->dnsReq);
               }
#endif /* CM_DNS_LIB */
               tmpPeer = tmpPeer->next;
            }
            /* Free SSAP servers */
            /* return the memory for this SAP */
            mgDeAlloc((Data *)ssap, sizeof(MgSSAPCb));
         }
         /* remove the SSAP from the SSAP list */
         mgCb.sSAPLst[j] = NULLP;
      }
      /* Free Memory for the SSAP List */
      mgDeAlloc((Data *)mgCb.sSAPLst, 
                (mgCb.genCfg.maxSSaps * sizeof(MgSSAPCb *)));
   }

#ifdef GCP_USE_PEERID
   /* remove the peer list memory */
   if (mgCb.peerLst != NULLP)
   {
      for (j=0; j < mgCb.genCfg.maxPeer;j++)
      {
         if (mgCb.peerLst[j] != NULLP)
         {
            if(mgCb.peerLst[j]->peer != NULLP)
            {
               mgRemovePeerAddrs(mgCb.peerLst[j]->peer);
               MG_STOP_PEER_TMRS(mgCb.peerLst[j]->peer);
               /* deinit the hash list in the peer blk */
               cmHashListDeinit(&mgCb.peerLst[j]->peer->inTransLst);
               cmHashListDeinit(&mgCb.peerLst[j]->peer->outTransLst);
               mgDeAlloc((Data *)mgCb.peerLst[j]->peer,sizeof(MgPeerCb));
               mgCb.peerLst[j]->peer = NULLP;
            }
            mgDeAlloc((Data *)mgCb.peerLst[j],sizeof(MgPeerLst));
         }
         mgCb.peerLst[j] = NULLP;
      }

      mgDeAlloc((Data *)mgCb.peerLst,
               (mgCb.genCfg.maxPeer * sizeof(MgPeerLst *)));
      mgCb.peerLst = NULLP;
   }
#endif /* GCP_USE_PEERID */


   /* Free all memory associated with TSAP */
   if (mgCb.tSAPLst != NULLP)
   {
      for (i=0; i< mgCb.genCfg.maxTSaps; i++)
      {
         MgTSAPCb      *tsap = NULLP;

         tsap = mgCb.tSAPLst[i];

         if (tsap != NULLP)
         {     

            /* Free Up rest of the resources from TSAP */
            if (tsap->cfgDone != FALSE)
            {     
               /* Disable Transport Server Hash List */
               cmHashListDeinit(&(tsap->tptSrvrLstCp));

            }
            /* Free TSAP servers */
            /* return the memory for this SAP */
            mgDeAlloc((Data *)tsap, sizeof(MgTSAPCb));
         }
         /* remove the TSAP from the TSAP list */
         /* Changed j to i below, to access correct index */
         mgCb.tSAPLst[i] = NULLP;
      }
      /* Free Memory for the TSAP List */
      mgDeAlloc((Data *)mgCb.tSAPLst, 
                (mgCb.genCfg.maxTSaps * sizeof(MgTSAPCb *)));
      /* Added more re-inits  */
      mgCb.dnsTsap = MG_INVALID_TSAP_ID;
      mgCb.tSAPLst = NULLP;
   }


   /* Deinit the hash lists in mgCb */
   mgDeinitIpAddrLst();
   cmHashListDeinit(&mgCb.peerNameLst);

   /* Reset layer manager post structure */
   cmMemset((U8 *)&mgCb.init.lmPst, 0, sizeof(Pst));

   /* clean up what we did in general configuration */
   SDeregTmr(mgCb.init.ent, mgCb.init.inst, (S16)mgCb.genCfg.timeRes, 
             mgActvTmr);
#ifdef GCP_MGCP
   SDeregTmr(mgCb.init.ent, mgCb.init.inst, (S16)mgCb.genCfg.timeResTTL, 
             mgActvTmrTTL);
#endif /* GCP_MGCP */

#ifdef CM_ABNF_MT_LIB
   /* Destroy all Encoder/Decoder Instances */
   tmpInst = mgCb.genCfg.firstInst;
   for(j = 0; j < mgCb.genCfg.noEDInst; j++)
   {
      SDeregTTsk(mgCb.init.ent, tmpInst);
      SDestroySTsk(mgCb.tskIdAr[j]);
      tmpInst ++;
   }
   /* free Task id array */
   if(mgCb.tskIdAr != NULLP)
   {
      mgDeAlloc(mgCb.tskIdAr,(mgCb.genCfg.noEDInst * sizeof(SSTskId)));
   }
   /* Now free all the queued resource ..*/
   mgFreeEncDecRsrc(); 

   mgCb.lastEDInst = 0;
   mgCb.nxtEDInst =  0;
   mgCb.shutDwnCfm.dfrdCfm = FALSE;
#endif /* CM_ABNF_MT_LIB */

#ifdef MG_RUG
   MG_FREE_RUG_VERINFO;
#endif /* MG_RUG */

   /* give away the reserved memory */
   SPutSMem(mgCb.init.region, mgCb.init.pool);

   /* reset the globals */
   cmMemset((U8 *)&mgCb.genCfg, 0, sizeof(MgGenCfg));

   /* Deinitialise cm_inet library */
   cmInetDeInit();

   /* general configuration needs to be done now */
   mgCb.init.cfgDone = FALSE;

   /* Re-Initilize mgCb */
   mgActvInit(mgCb.init.ent, mgCb.init.inst, mgCb.init.region, ASHUTDOWN);

#if (defined(GCP_CH) && defined(GCP_VER_1_5))
/* mg002.105: call mgGCPCleanup to claer command list maintain by GCP*/
   mgGCPCleanup ();
#endif

   RETVALUE(LCM_PRIM_OK);
} /* end of mgZgShutDown */

#else /* ZG */

/*
*
*       Fun:   mgShutdown
*
*       Desc:  This function shuts down GCP layer. All GCP
*              entities, SSAPs and the TSAP are destroyed and
*              general configuration is erased.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC U16 mgShutdown
(
void
)
#else
PUBLIC U16 mgShutdown()
#endif
{
   U32             j;                  /* Temporary Value */
#ifdef CM_ABNF_MT_LIB
   Inst            tmpInst;            /* temp instance */
#endif /* CM_ABNF_MT_LIB */

#if (defined(GCP_CH) && defined(GCP_VER_1_5))
/* mg002.105: Changes for CH*/
MgMgcoChPeerCmdCtl     *peerCmdCtl;      /* CH peer CB */
MgMgcoChPeerCmdCtl     *peerCmdCtlPrev=NULLP;      /* CH peer CB */
MgMgcoChTransIndRsp    *transIndRsp;
MgMgcoChTransIndRsp    *transIndRspPrev=NULLP;
MgMgcoChTransReq       *transReq;
MgMgcoChTransReq       *transReqPrev=NULLP;
#endif /* GCP_CH && GCP_VER_1_5 */

   TRC2(mgShutdown)


   /* remove the tsap list memory */
   if (mgCb.tSAPLst != NULLP)
   {
      for (j=0; j < mgCb.genCfg.maxTSaps; ++j)
      {
         if ((mgCb.tSAPLst[j]) &&
             (mgCb.tSAPLst[j]->cfgDone != FALSE))
         {
            /*
             * The following func has to be enhanced to close/dealloc
             * endpoints/associations 
             */
            mgDeleteTsap(mgCb.tSAPLst[j]);
            mgCb.tSAPLst[j] = NULLP;
         }
      }

      /* Free Memory for the TSAP List */
      mgDeAlloc((Data *)mgCb.tSAPLst, 
                (mgCb.genCfg.maxTSaps * sizeof(MgTSAPCb *)));

      mgCb.tSAPLst = NULLP;
   }


   /* remove the ssap list memory */
   if (mgCb.sSAPLst != NULLP)
   {
      for (j=0; j< mgCb.genCfg.maxSSaps; j++)
      {
         if (mgCb.sSAPLst[j] != NULLP)
         {     
            mgDeleteSsap(mgCb.sSAPLst[j]);
         }
      }

      /* Free Memory for the SSAP List */
      mgDeAlloc((Data *)mgCb.sSAPLst, 
                (mgCb.genCfg.maxSSaps * sizeof(MgSSAPCb *)));
   }

#ifdef GCP_USE_PEERID
   /* remove the peer list memory */
   if (mgCb.peerLst != NULLP)
   {
      for (j=0; j < mgCb.genCfg.maxPeer;j++)
      {
         if (mgCb.peerLst[j] != NULLP)
         {
            mgDeAlloc((Data *)mgCb.peerLst[j],sizeof(MgPeerLst));
         }
      }

      mgDeAlloc((Data *)mgCb.peerLst,
               (mgCb.genCfg.maxPeer * sizeof(MgPeerLst *)));
   }
#endif /* GCP_USE_PEERID */

   /* Deinit the hash lists in mgCb */
   mgDeinitIpAddrLst();
   cmHashListDeinit(&mgCb.peerNameLst);

   /* Reset layer manager post structure */
   cmMemset((U8 *)&mgCb.init.lmPst, 0, sizeof(Pst));

   /* clean up what we did in general configuration */
   SDeregTmr(mgCb.init.ent, mgCb.init.inst, (S16)mgCb.genCfg.timeRes, 
             mgActvTmr);
#ifdef GCP_MGCP
   SDeregTmr(mgCb.init.ent, mgCb.init.inst, (S16)mgCb.genCfg.timeResTTL, 
             mgActvTmrTTL);
#endif /* GCP_MGCP */

#ifdef CM_ABNF_MT_LIB
   /* Destroy all Encoder/Decoder Instances */
   tmpInst = mgCb.genCfg.firstInst;
   for(j = 0; j < mgCb.genCfg.noEDInst; j++)
   {
      SDeregTTsk(mgCb.init.ent, tmpInst);
      SDestroySTsk(mgCb.tskIdAr[j]);
      tmpInst ++;
   }
   /* free Task id array */
   if(mgCb.tskIdAr != NULLP)
   {
      mgDeAlloc(mgCb.tskIdAr,(mgCb.genCfg.noEDInst * sizeof(SSTskId)));
   }
   /* Now free all the queued resource ..*/
   mgFreeEncDecRsrc(); 
   mgCb.shutDwnCfm.dfrdCfm = FALSE;
   mgCb.lastEDInst = 0;
   mgCb.nxtEDInst =  0;
#endif /*CM_ABNF_MT_LIB */

#ifdef MG_RUG
   MG_FREE_RUG_VERINFO;
#endif /* MG_RUG */

   /* give away the reserved memory */
   SPutSMem(mgCb.init.region, mgCb.init.pool);

   /* reset the globals */
   cmMemset((U8 *)&mgCb.genCfg, 0, sizeof(MgGenCfg));

   /* Deinitialise cm_inet library */
   cmInetDeInit();

   /* general configuration needs to be done now */
   mgCb.init.cfgDone = FALSE;

   /* Re-Initilize mgCb */
   mgCb.sSAPLst = NULLP;
   for (j=0; j < MG_TQSIZE; j++)
   {
      mgCb.mgTq[j].first = NULLP;
   }

   for(j=0; j< MG_TTLTQSZ; j++)
   {
      mgCb.mgTTLTq[j].first = NULLP;
   }

   mgCb.mgTqCp.nxtEnt = 0;
   mgCb.mgTqCp.tmrLen = MG_TQSIZE;
   mgCb.mgTTLTqCp.nxtEnt = 0;
   mgCb.mgTTLTqCp.tmrLen = MG_TTLTQSZ;
   mgCb.init.acnt    = TRUE;          /* enable accounting */
   mgCb.init.usta    = TRUE;          /* enable unsolicited status */
   mgCb.init.trc     = FALSE;         /* enable trace */
   mgCb.init.procId  = SFndProcId();  /* processor id */

   
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
   /* mg002.105: Deinit the hash lists in mgCb */
   while (ROK == cmHashListGetNext(&(mgCb.chCb.peerCmdCtlLst),
                  (PTR)peerCmdCtlPrev,(PTR *)&peerCmdCtl)) 
   {
      while (ROK == cmHashListGetNext(&(peerCmdCtl->transIndRspLst),
                     (PTR)transIndRspPrev,(PTR *)&transIndRsp))
         mgChCleanupTransIndRsp (&transIndRsp); 
      cmHashListDeinit(&(peerCmdCtl->transIndRspLst)); 
      while (ROK == cmHashListGetNext(&(peerCmdCtl->transReqLst),
                     (PTR)transReqPrev,(PTR *)&transReq))
         mgChCleanupTransReq (&transReq, TRUE); 
      cmHashListDeinit(&(peerCmdCtl->transReqLst)); 
      cmHashListDelete(&(mgCb.chCb.peerCmdCtlLst), (PTR )peerCmdCtl);
      mgDeAlloc((Data *)peerCmdCtl,sizeof(MgMgcoChPeerCmdCtl));
   }  
   cmHashListDeinit(&mgCb.chCb.peerCmdCtlLst);
#endif /* GCP_CH */

#ifdef ZG
   /* Now do delMapping for all control blocks */
   zgDelMapping(ZG_CBTYPE_DNS, (Ptr)&(mgCb.tsapCb.dnsInfo));
   zgDelMapping(ZG_CBTYPE_TSAP, (Ptr)&(mgCb.tsapCb));
   zgDelMapping(ZG_CBTYPE_GCP, (Ptr)&(mgCb));
#endif  /* ZG */

   RETVALUE(LCM_PRIM_OK);
} /* end of mgShutDown */
#endif /* ZG */


/******************************************************************************/
/*                   TSAP Control Support Functions                           */
/******************************************************************************/
/*
*
*       Fun:   mgGetTsapViaSpId
*
*       Desc:  This function find the Tsap via sipId.
*
*       Ret:   MgTSAPCb*
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/

#ifdef ANSI
PRIVATE MgTSAPCb* mgGetTsapViaSpId
(
SpId  spId             /* spId   */
)
#else
PRIVATE MgTSAPCb* mgGetTsapViaSpId(spId)
SpId  spId             /* spId   */
#endif
{
	U32 i;
	MgTSAPCb        *tsap = NULLP;              /* TSAP cb */

	for (i=0; i < mgCb.genCfg.maxTSaps; i++)
    {
       tsap = *(mgCb.tSAPLst + i);

       if (tsap == NULLP)
          continue;

       if(tsap->tsapCfg.spId == spId)
	   {
		   break;
	   }
    }

	RETVALUE(tsap);
}

/*

*       Fun:   mgCntrlTsap
*
*       Desc:  This function implements the control actions on TSAP.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/

#ifdef ANSI
PRIVATE U16 mgCntrlTsap
(
MgCntrl            *cntrl,             /* Control Structure */
MgTSAPCb           *tsap               /* TSAP Cb pointer   */
)
#else
PRIVATE U16 mgCntrlTsap(cntrl, tsap)
MgCntrl            *cntrl;             /* Control Structure */
MgTSAPCb           *tsap;              /* TSAP Cb pointer   */
#endif

{
   S16             ret;                /* Return Value */

   TRC2(mgCntrlTsap)


   /*mg002.105: Changes for TCR 21 - GCP */
   /*chendh MG_MI_VALIDATE_TSAP_ACTION(tsap, cntrl->spId, cntrl->action, ret);*/

 	if(tsap == NULLP)
   		{
	   		tsap = mgGetTsapViaSpId(cntrl->spId);
   		}
   


   if (tsap == NULLP)
      RETVALUE(RFAILED);


   ret = LCM_REASON_NOT_APPL;

   if (cntrl->subAction == SATRC)
   {
     ret = mgCntrlTsapTrc(&cntrl->s.trcCntrl, cntrl->action, tsap);
     RETVALUE(ret);
   }

   switch(cntrl->action)
   {
      case ADISIMM:
      case AUBND_DIS: 
      /* added action to lock GCP layer */
      case AINH:
      {
         ret = mgDisableTsap(tsap, cntrl->action);

         /* Added missing TUCL recovery code */
#ifdef ZG
         /* 
          * if changeOver flag is TRUE..means service provider has
          * failed..so send status ind to service user 
          * statusInd to be generated for ALL TSAPs?
          */
         if ((tsap->tsapCfg.reCfg.changeOver == TRUE) &&
             (AUBND_DIS == cntrl->action))
         {
            tsap->state = LMG_SAP_UBND_DIS;
            mgGenUserStaInd(NULLP, NULLP,
                            MGT_STATUS_SRVC_PRVDR_FAILED,
                            NULLP);
         }
#endif /* ZG */

         if (cntrl->action == AUBND_DIS)
            tsap->contEnt = ENTSM;
#ifdef ZG
         /* Update modify TsapCb*/
         zgRtUpd(ZG_CBTYPE_TSAP,(Ptr)tsap,CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
         zgUpdPeer();
#endif /* ZG */
      }
      break;

      case ADEL:
        mgCb.tSAPLst[tsap->tsapCfg.tSAPId] = NULLP;    /* added */
        ret = mgDeleteTsap(tsap);
        tsap = NULLP;
        /* mg005.105: zgRtUpd is already calling in mgDeleteTsap */
#ifdef ZG
         zgUpdPeer();
#endif /* ZG */
        break;

      case AENA:
      case ABND_ENA:        
        ret = mgEnableTsap(tsap, cntrl->action);

        if (cntrl->action == ABND_ENA)
          tsap->contEnt = ENTNC;
#ifdef ZG
         /* Update modify TsapCb*/
         zgRtUpd(ZG_CBTYPE_TSAP,(Ptr)tsap,CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
         zgUpdPeer();
#endif /* ZG */
        break;
      default:
         ret = LCM_REASON_INVALID_ACTION;
         break;
   }/* end action */

   RETVALUE(ret);

} /* end of mgCntrlTsap */


/*
*
*       Fun:   mgCntrlTsapTrc
*
*       Desc:  This function disables the TSAP.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/

#ifdef ANSI
PRIVATE U16 mgCntrlTsapTrc
(
MgTrcCntrl         *trcCntrl,          /* Control Trace Structure */
U16                action,             /* Action */
MgTSAPCb           *tsap               /* TSAP Cb pointer */
)
#else
PRIVATE U16 mgCntrlTsapTrc(trcCntrl, action, tsap)
MgTrcCntrl         *trcCntrl;          /* Control Trace Structure */
U16                action;             /* Action */
MgTSAPCb           *tsap;              /* TSAP Cb pointer */
#endif 

{
  U16              ret;                /* Return Value */

  TRC2(mgCntrlTsapTrc)

   ret = LCM_REASON_NOT_APPL;


   if (tsap == NULLP)
      RETVALUE(RFAILED);


   if (action ==  AENA)
     tsap->trcLen = trcCntrl->trcLen;
   else if (action == ADISIMM)
     tsap->trcLen = -1;
   else
     ret = LCM_REASON_INVALID_ACTION;
    
   RETVALUE(ret);

}  /* end of mgCntrlTsapTrc() */


/*
*
*       Fun:   mgDisableTsap
*
*       Desc:  This function disables the TSAP.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgDisableTsap
(
MgTSAPCb           *tsapCb,            /* TSAP Control Block */
U16                action              /* Action */
)
#else
PRIVATE U16 mgDisableTsap(tsapCb, action)
MgTSAPCb           *tsapCb;            /* TSAP Control Block */  
U16                action;             /* Action */
#endif
{
   U16             ret;                /* Return Value */
   U8              i;                  /* Temporary Variable */
   Bool            delSrvr;            /* Delete Server */
   MgSSAPCb        *ssap;            /* SSAP Control Block */

   TRC2(mgDisableTsap)

   ret = LCM_REASON_NOT_APPL;

   switch (tsapCb->state)
   {
      case LMG_SAP_BND_DIS:
         if (action == AUBND_DIS)
            tsapCb->state = LMG_SAP_UBND_DIS;
         break;

      case LMG_SAP_BND_ENB:
      { 
         delSrvr = FALSE;

#ifndef ZG
         if ((action == ADEL) || (action == AUBND_DIS))
         {
            delSrvr = TRUE;
         }
#else
         if ((action == ADEL) || 
             ((action == AUBND_DIS) && 
             (tsapCb->tsapCfg.reCfg.changeOver == FALSE)))
         {
            delSrvr = TRUE;
         }
#endif /* ZG */

#ifdef   GCP_PROV_MTP3

         if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_MTP3)
            mgDownMtpPointCode(tsapCb);
         else
#endif   /* GCP_PROV_MTP3 */

#ifdef    GCP_PROV_SCTP

         /*  Do we need to deAllocAssocCb s also? */
         if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_SCTP)
            mgCloseEndp(&(tsapCb->endpCb), tsapCb, delSrvr);
         else

#endif    /* GCP_PROV_SCTP */
            mgRemTsapSrvrs(tsapCb, delSrvr);




#ifdef CM_DNS_LIB

         if ((mgCb.dnsTsap != MG_INVALID_TSAP_ID) &&
             (tsapCb == mgCb.tSAPLst[mgCb.dnsTsap]) &&
             (tsapCb->dnsInfo.dnsLstnr != NULLP))
                  mgSrvDiscReq(tsapCb->dnsInfo.dnsLstnr, delSrvr);

#endif /* CM_DNS_LIB */



         for (i=0;i<mgCb.genCfg.maxSSaps;i++)
         {
            ssap = (MgSSAPCb *)mgCb.sSAPLst[i];
            if(ssap != NULLP)
            {
               if (action == ADEL)
               {  /* calling a new macro now */
                  /* passing extra argument for dealloc peerCb */
                  MG_REM_SSAP_PEERS_FOR_THIS_TSAP(ssap, tsapCb, FALSE, TRUE);
               }
               else 
               {
#ifdef ZG
                  if(tsapCb->tsapCfg.reCfg.changeOver == TRUE)
                  {  /* calling a new macro now */
                     MG_RESET_SSAP_PEERS_FOR_THIS_TSAP(ssap,tsapCb);
                  }
                  else  /* calling a new macro now */
#endif /* ZG */
/* paul modifyed for NEC feedback */
#ifdef GCP_MGCO
#ifdef GCP_MG
                  /* if action is AINH do not dealloc peerCb */   
                  if((action == AINH) && (mgCb.genCfg.entType == LMG_ENT_GW))
                  {   
                     ssap->lockUnlock = TRUE;
                     MG_REM_SSAP_PEERS_FOR_THIS_TSAP(ssap, tsapCb, TRUE, FALSE);
                  }
                  else
#endif  /* GCP_MG */
#endif  /* GCP_MGCO */
                  {   
                      /* passing extra argument for dealloc peerCb */
                      MG_REM_SSAP_PEERS_FOR_THIS_TSAP(ssap, tsapCb, TRUE, TRUE);
                  }   
               }
#ifdef GCP_MG
               if (mgCb.genCfg.entType == LMG_ENT_GW)
               {  /* calling a new function now */
                  mgRemSsapSrvrsForThisTsap(ssap, tsapCb, delSrvr);
               }
#endif /* GCP_MG */
#ifdef ZG
               /* Update mod Ssap */
               zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_MOD);
#endif /* ZG */
               /* mg003.105: Bug fix */
/* move changes in compiler flag */
#ifndef AG              
               ssap->enbIndSent = FALSE;
#endif               
            }
         }
#ifdef ZG_DFTHA
         /* free all the resources attached to reverse update queue */
         mgFreeRvUpdRsrc((&tsapCb->rvUpdQ), MG_TSAP_TXNQ); 
#endif /* ZG */
         tsapCb->state = LMG_SAP_BND_DIS;
      }
      break;

      case LMG_SAP_WAIT_BNDENB:
      {
         /* if we were waiting for bind stop bnd timer */
         if ((tsapCb->state == LMG_SAP_WAIT_BNDENB) &&
             (tsapCb->bndTmr.tmrEvnt == MG_BNDREQ_TMR))
            mgStopTmr (MG_BNDREQ_TMR,(PTR) tsapCb, &tsapCb->bndTmr);

         tsapCb->state = LMG_SAP_UBND_DIS;               
      }
      break;
     
      case LMG_SAP_UBND_DIS:
         break;

      default:
         ret = LCM_REASON_INVALID_STATE;
         break;

   } /* end switch(state)*/

   RETVALUE(ret);

} /* end of mgDisableTsap() */





/*
*
*       Fun:   mgRemTsapSrvrs
*
*       Desc:  This function disables the TSAP.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgRemTsapSrvrs
(
MgTSAPCb           *tsapCb,            /* TSAP Control Block */
Bool               delSrvr             /* Delete Server ? */
)
#else
PRIVATE U16 mgRemTsapSrvrs(tsapCb, delSrvr)
MgTSAPCb           *tsapCb;            /* TSAP Control Block */  
Bool               delSrvr;            /* Delete Server ? */
#endif
{
   MgTptSrvrInfo   *srvrInfo;

   TRC2(mgRemTsapSrvrs)

#ifdef GCP_MGCP
   srvrInfo = &(tsapCb->mgcpUDPSrvrLst);
   MG_REM_SRVRS(srvrInfo, delSrvr);
#endif /* GCP_MGCP */

#ifdef GCP_MGCO 

   srvrInfo = &tsapCb->mgcoUDPSrvrLst;
   MG_REM_SRVRS(srvrInfo, delSrvr);

#ifdef GCP_MGC
   srvrInfo = &tsapCb->tcpSrvrInfo;
   MG_REM_SRVRS(srvrInfo, delSrvr);
#endif /* GCP_MGC */

#endif /* GCP_MGCO */

   RETVALUE(ROK);

} /* end of mgRemTsapSrvrs() */


/*
*
*       Fun:   mgDeleteTsap
*
*       Desc:  This function disables the TSAP.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgDeleteTsap
(
MgTSAPCb           *tsapCb            /* TSAP Control Block */
)
#else
PRIVATE U16 mgDeleteTsap(tsapCb)
MgTSAPCb           *tsapCb;            /* TSAP Control Block */  
#endif
{
   U16             ret;                /* Return Value */
   U16             j;                  /* Temporary Variable */

   TRC2(mgDeleteTsap)

   ret = LCM_REASON_NOT_APPL;

   if ((ret = mgDisableTsap(tsapCb, ADEL)) != LCM_REASON_NOT_APPL)
      RETVALUE(ret);


   if (tsapCb->state ==  LMG_SAP_BND_DIS)
   {
#ifdef ZG
      /* Only master should send uBnd Req */
      if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG */
      {


         if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_TUCL)
         {
           (Void) MgLiHitUbndReq (&tsapCb->spPst, tsapCb->tsapCfg.spId,
                                  HI_UBNDREQ_MNGMT);
         }
          /*
           *   For SCTP as provider there is NO such primitive
           *   as SCT Un-Bind request
           */
      }
   }


   tsapCb->state = LMG_SAP_DELETED;


   /* remove any mem allocated for listeners */
   /*
    *   servers are attached only to TUCL TSAPs
    */

   if ((tsapCb->tsapCfg.provType == LMG_PROV_TYPE_TUCL) &&
       (tsapCb->lstnrLst != NULLP))
   {
      for(j=0; j < mgCb.genCfg.maxServers;j++)
      {
         if(tsapCb->lstnrLst[j] != NULLP)
         {
            if(tsapCb->lstnrLst[j]->lstnrCb != NULLP)
            {
               mgDeAlloc((Data *)tsapCb->lstnrLst[j]->lstnrCb ,
                   sizeof(MgTptSrvr));
               tsapCb->lstnrLst[j]->lstnrCb = NULLP;
            }
            mgDeAlloc((Data *)tsapCb->lstnrLst[j] ,sizeof(MgLstnrLst));
            tsapCb->lstnrLst[j]=NULLP;
         }
      }
       
      /*  issue with mgCb.genCfg.maxServers since
       *        this has the max number of servers spread
       *        across all the TUCL TSAPs. However, a single
       *        TSAP may NOT allocate memory for all these
       *        servers. What to allocate and deallocate?
       */
      mgDeAlloc((Data *)tsapCb->lstnrLst,
               (mgCb.genCfg.maxServers * sizeof(MgLstnrLst *)));
      tsapCb->lstnrLst = NULLP;
   }



#ifdef CM_DNS_LIB
   if ((mgCb.dnsTsap != MG_INVALID_TSAP_ID) &&
       (tsapCb == mgCb.tSAPLst[mgCb.dnsTsap]) &&
       (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_TUCL) &&
       (tsapCb->dnsInfo.dnsCb != NULLP))
   {

      cmDnsDeInitDnsCb(tsapCb->dnsInfo.dnsCb); 
      mgDeAlloc((Data *)tsapCb->dnsInfo.dnsCb, sizeof(CmDnsCb));
      tsapCb->dnsInfo.dnsCb = NULLP;
#ifdef ZG
      if(((zgChkCRsetStatus()) == TRUE))
      {
         /* Send update del for DNS Cb */
         zgRtUpd(ZG_CBTYPE_DNS,(Ptr )(&(tsapCb->dnsInfo)),
            CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);  
      }
#endif /* ZG */

   }

#endif /* CM_DNS_LIB */


   /* Disable Transport Server Hash List */
   cmHashListDeinit(&(tsapCb->tptSrvrLstCp));

#ifdef    GCP_PROV_SCTP
   if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_SCTP)
   {
      cmHashListDeinit(&(tsapCb->endpCb.assocCp));
   }
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3
   if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_MTP3)
   {
      cmHashListDeinit(&(tsapCb->mgcoMtpHlCp));
   }
#endif    /* GCP_PROV_MTP3 */


#ifdef ZG
   /* send Update Del Tsap */
   zgRtUpd(ZG_CBTYPE_TSAP,(Ptr)tsapCb,CMPFTHA_UPDTYPE_SYNC,
           CMPFTHA_ACTN_DEL);
   zgDelMapping(ZG_CBTYPE_TSAP, (Ptr)tsapCb);
#endif /* ZG */


   /* free the TSAP control block */
   mgDeAlloc((Data *)tsapCb, sizeof(MgTSAPCb));

   RETVALUE(ret);

} /* end of mgDeleteTsap() */


/*
*
*       Fun:   mgEnableTsap
*
*       Desc:  This function disables the TSAP.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgEnableTsap
(
MgTSAPCb           *tsapCb,            /* TSAP Control Block */
U16                action              /* Action */
)
#else
PRIVATE U16 mgEnableTsap(tsapCb, action)
MgTSAPCb           *tsapCb;            /* TSAP Control Block */  
U16                action;             /* Action */
#endif
{
   U16             ret;                /* Return Value */

   ret = LCM_REASON_NOT_APPL;

#ifdef MG_RUG
   /* Binding cannot be performed in case SAP does not have a valid 
    * destination version number, i.e., bind has to be performed
    * only after version synchronization has been done
    */
   if(tsapCb->remIntfValid == FALSE)
   {
      ret = LCM_REASON_SWVER_NAVAIL;    /* version not found */
      RETVALUE(ret);
   }
#endif /* MG_RUG */

   switch(tsapCb->state)
   {
      case LMG_SAP_UBND_DIS:
      {
         if(action == ABND_ENA)
         {
            tsapCb->state = LMG_SAP_WAIT_BNDENB;
            MG_MI_ISSUE_BNDREQ (tsapCb);
         }
         else
            RETVALUE(LCM_REASON_INVALID_ACTION);
#ifdef ZG
         /* update mod TSAP to standby */
         zgRtUpd(ZG_CBTYPE_TSAP,(Ptr)tsapCb,CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
         zgUpdPeer();
#endif /* ZG */
      }
      break;
            
      case LMG_SAP_BND_DIS:
      {
         tsapCb->state = LMG_SAP_BND_ENB;


#ifdef    GCP_PROV_SCTP
         if (tsapCb->tsapCfg.provType == LMG_PROV_TYPE_SCTP)
         {
            MgEndpCfg        endpCfg;           /* end point cfg var  */

            cmMemset((U8 *)&endpCfg, 0, sizeof(MgEndpCfg));

            /*
             * we are NOT using intfAddr in endpCfg at present here;
             * Therefore for consistency, we might remove it from
             * MgEndpCfg also so that its not used in mp_mi.c : endpCfgReq
             */

            endpCfg.sctPort = tsapCb->endpCb.port;

            mgEndpOpenReq(tsapCb, &endpCfg);
         }
    else
#endif    /* GCP_PROV_SCTP */
            mgStartTsapServers(tsapCb);


        
#ifdef CM_DNS_LIB

         if ((tsapCb->tsapCfg.provType == LMG_PROV_TYPE_TUCL) &&
             (tsapCb->tsapCfg.reCfg.dnsCfg.dnsAccess == LMG_DNS_USE_DNSLIB))
         {           
            if ((mgSetUpDns(tsapCb, FALSE)) != LCM_REASON_NOT_APPL)
            {
               mgRemTsapSrvrs(tsapCb, TRUE);
               RETVALUE(LCM_REASON_MEM_NOAVAIL);
            }
            MG_ENA_DNS_LSTNR(tsapCb, &(tsapCb->tsapCfg.reCfg.tptParam));
#ifdef ZG
            /* send update for DNS Server & TSAP; */ 
            zgRtUpd(ZG_CBTYPE_TPTSRVR,(Ptr)tsapCb->dnsInfo.dnsLstnr,
               CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
            zgUpdPeer();
#endif /* ZG */
         }

#endif /* CM_DNS_LIB */
      }
      break;
            
      case LMG_SAP_WAIT_BNDENB:
      case LMG_SAP_BND_ENB:
         break;

      default:
         ret = LCM_REASON_INVALID_STATE;
         break;
      
   }/* end switch state */

   RETVALUE(ret);

} /* end of mgEnableTsap () */
 


/******************************************************************************/
/*                   SSAP Control Support Functions                           */
/******************************************************************************/


/*
*
*       Fun:   mgCntrlSsap
*
*       Desc:  This function implements SSAP control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCntrlSsap
(
MgCntrl            *cntrl              /* Control Structure */
)
#else
PRIVATE U16 mgCntrlSsap(cntrl)
MgCntrl            *cntrl;             /* Control Structure */
#endif
{
   U16             ret;                /* Return Value */
   MgSSAPCb        *ssap;              /* SSAP Control Block */

   TRC2(mgCntrlSsap)

   ret = LCM_REASON_NOT_APPL;
   /*mg002.105: Changes for TCR 21 - GCP */
   MG_MI_VALIDATE_SSAP_ACTION(ssap, cntrl->spId, cntrl->action, ret);
   /* MG_MI_VALIDATE_SSAP(ssap, cntrl->spId, ret); */

   switch(cntrl->action)
   {
      case AENA:
        ret = mgEnableSsap(ssap);
        break;
      case AUBND_DIS:
        ret = mgUbndDisSsap(ssap);
        break;
      case ADEL:
        ret = mgDeleteSsap(ssap);
        break;
      default:
        ret = LCM_REASON_INVALID_ACTION;
        break;
   }
#ifdef ZG
   /* send update to peer */
   zgUpdPeer();
#endif /* ZG */
   RETVALUE(ret);

} /* end of mgCntrlSsap() */


/*
*
*       Fun:   mgEnableSsap
*
*       Desc:  This function implements SSAP control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC U16 mgEnableSsap
(
MgSSAPCb           *ssap               /* SSAP Control Block */
)
#else
PUBLIC U16 mgEnableSsap(ssap)
MgSSAPCb           *ssap;              /* SSAP Control Block */
#endif
{
   U16             ret;                /* Return Value */
   /* mg008.105: changed from U8 */
   U32              i;                  /* Temporary variable */
   MgPeerCb        *peer;              /* Peer Control Block */
   CmLList         *tmp;               /* Linked List Node */
#ifdef GCP_MG
   U32             j;                  /* Temporary variable */
   Bool            enb;                /* Temporary variable */
#endif /* GCP_MG */
   ret = LCM_REASON_NOT_APPL;

   /* mg002.105: changes for TCR 21 - GCP */
   if ((ssap->state == LMG_SAP_BND_ENB) || (ssap->state == LMG_SAP_WAIT_BNDENB))
   {
      RETVALUE(ret);
   }

   switch(ssap->state)
   {
      case LMG_SAP_UBND_DIS:
      {         
         ssap->state = LMG_SAP_UBND_ENB;

         /* we are enabling after bind disable */
         if (ssap->enbIndSent == FALSE)
         {
            CM_LLIST_FIRST_NODE(&(ssap->peerLst), tmp);

            for (i=0; i< ssap->peerLst.count; i++)
            {
               peer = (MgPeerCb *)tmp->node;

               if(peer->accessInfo.peerAddrTbl.count > 0)
               {
                 /* 
                  * if we know addr we do not resolve until needed 
                  * register the name to the peerNameLst 
                  */
                 ssap->numPeerRslvd++;
#ifdef GCP_MGCO
#ifdef GCP_MG
                 if(ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCO)
                 {
                    if(ssap->crntMgc == NULLP)
                    {
                       /* Assign crntMgc to primary */
                       MgPeerCb    *peer1;
                       mgSelectPeer(&peer1, ssap);
                       ssap->crntMgc = peer1;
                    }
                 }
#endif /* GCP_MG */
#endif /* GCP_MGCO */
               }
               else
               {
                 if (peer->accessInfo.namePres)
                 {
                   U8   oldState;
                   oldState = peer->state;
                   /* need to resolve */
                   peer->state = LMG_PEER_STATE_RESOLVING;
                   if(ROK != mgSendDnsRslvReq(peer, peer->accessInfo.name))
                   {
                     peer->state = oldState;
                   }
#ifdef ZG
                   else
                   {
                      /* send update for peer */
                      zgRtUpd(ZG_CBTYPE_PEER, (Ptr)(peer) , 
                            CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
                   }
#endif /* ZG */
                 }
               }

               CM_LLIST_NEXT_NODE(&(ssap->peerLst), tmp);

            } /* end for */

         } /* if enbSent */
         
#ifdef GCP_MG
         /*
          *   we should check the state of ALL the TUCL TSAPs;
          *
          *    shd all the TSAPs be checked OR shd only the
          *          relevant TSAPs be checked?
          */

         enb = TRUE;

         for (j=0; j < mgCb.genCfg.maxTSaps; ++j)
         {
            if ((mgCb.tSAPLst[j]) &&
                (mgCb.tSAPLst[j]->tsapCfg.provType == LMG_PROV_TYPE_TUCL))
            {
               if (mgCb.tSAPLst[j]->state != LMG_SAP_BND_ENB)
               {
                  enb = FALSE;
                  break;
               }
            }
         }

         if (enb == TRUE)
            mgStartSsapServers(ssap);

#endif /* GCP_MG */


#ifdef ZG
      zgRtUpd(ZG_CBTYPE_SSAP,(Ptr )(ssap),
        CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);  
#endif /* ZG */
         break;
      }

      /* mg004.105: Added a new check : If SAp is already bound and 
       another enable is received, ignore it and not return error*/
      case LMG_SAP_BND_ENB:
      case LMG_SAP_UBND_ENB:
         break;
         /* end change */
      default:
         ret = LCM_REASON_INVALID_STATE;
         break;

   } /* end of switch(state) */  

   RETVALUE(ret);

} /* end of mgEnableSsap() */
  

#ifdef GCP_MG

/*
*
*       Fun:   mgStartSsapServers
*
*       Desc:  This function starts listeners on TSAP or SSAP
*
*       Ret:   ROK              - successful
*              RFAILED          - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PUBLIC U16 mgStartSsapServers
(
MgSSAPCb           *ssap               /* SSAP Control Block */
)
#else
PUBLIC U16 mgStartSsapServers(ssap)
MgSSAPCb           *ssap;              /* SSAP Control Block */
#endif
{
   MgTptSrvrInfo   *srvrInfo;          /* Transport Server Information */

   TRC2(mgStartSsapServers)

#ifdef GCP_MGCO
   srvrInfo = &ssap->mgcoUDPSrvrLst;
   mgStartServers(srvrInfo);
#endif /* GCP_MGCO */

#ifdef GCP_MGCP
   srvrInfo = &ssap->mgcpUDPSrvrLst;
   mgStartServers(srvrInfo);
#endif /* GCP_MGCP */

   RETVALUE(ROK);

} /* end of mgStartSsapServers() */

#endif /* GCP_MG */


/*
*
*       Fun:   mgUbndDisSsap
*
*       Desc:  This function implements SSAP control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgUbndDisSsap
(
MgSSAPCb           *ssap               /* SSAP Control Block */
)
#else
PRIVATE U16 mgUbndDisSsap(ssap)
MgSSAPCb           *ssap;              /* SSAP Control Block */
#endif
{
   U16             ret;                /* Return Value */
   /* mg004.105: BugFix: Service change(With method "Forced" and "OOS" */
#ifdef 	GCP_MGCO
#ifdef GCP_MG
   MgPeerCb       *peer;
#endif
#endif

   TRC2(mgUbndDisSsap)

   ret = LCM_REASON_NOT_APPL;

#ifdef MG_RUG
   ssap->remIntfValid = FALSE;

#ifdef ZG
   /* Update the invalid ver num flag in sap to the slaves */
   zgRtUpd(ZG_CBTYPE_SSAP, (Ptr)ssap, CMPFTHA_UPDTYPE_SYNC, 
               CMPFTHA_ACTN_MOD);
#endif /* ZG */
#endif /* MG_RUG */

   /* mg002.105: changes for TCR 21 - GCP */
   if (ssap->state == LMG_SAP_UBND_DIS)
   {
      RETVALUE(ret);
   }
   switch(ssap->state)
   {
      case LMG_SAP_UBND_ENB:
      case LMG_SAP_BND_ENB:
      {

         /* mg004.105: Added check on ssaps in peerCfg */      
#ifdef 	GCP_MGCO
#ifdef  GCP_MG
         /*-- BugFix: Send the service change(With method "Forced" and "OOS" to Mgc if this
          *   GWY is connected to any Mgc --*/
         /*-- 1. Get the handle on the connected Mgc --*/
         if (NULLP == (peer = ssap->crntMgc))
             MGDBGP(DBGMASK_MI, (mgCb.init.prntBuf,
                    "mgUbndDisSsap(): Info: No current Mgc exists for this Vag(%d)\n", 
                    ssap->ssapCfg.sSAPId));

         /*-- 2. Check if the peer exist and system is in sane state to send service
          *   change --*/
         if (peer                                            &&
             peer->state            == LMG_PEER_STATE_ACTIVE &&
             mgCb.genCfg.entType    == LMG_ENT_GW            &&
             ssap->state            == LMG_SAP_BND_ENB       &&
             ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCO)
         {
             MGDBGP(DBGMASK_MI, (mgCb.init.prntBuf,
                    "mgUbndDisSsap(): Info: Sending SvcChg (Forced, OOS) to Mgc\n"));
             /* Bug Fix: Send reason as IMPENDING Failure - Mudit */
             ret = mgSendSrvcChng(peer, MGT_SVCCHGMETH_FORCED, MG_SCRSN_MG_IMPN_FAIL,
                                  NULLP, LMG_INVALID_PEER_PORT, NULLP); 
         }
#endif /*-- GCP_MG --*/
#endif /*-- GCP_MGCO --*/

         ssap->state = LMG_SAP_UBND_DIS;
         MG_RESET_SSAP_PEERS(ssap);
         ssap->numPeerRslvd = 0;
         ssap->enbIndSent = FALSE;
         ssap->resCong    = FALSE;

#ifdef GCP_MGC        
         /* Update next use ssapId (for round robin assignment) if necessary */ 
#ifdef GCP_MGCP
         if ((ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCP) &&                   
             (ssap->ssapCfg.sSAPId == mgCb.nxtMgcpSsapId))                      
         {                                                                      
            MG_UPDATE_NXTUSE_MGCP_SSAPID();
         }     
#endif /* GCP_MGCP */
#ifdef GCP_MGCO
         if ((ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCO) &&                   
             (ssap->ssapCfg.sSAPId == mgCb.nxtMgcoSsapId))                      
         {                                                                      
            MG_UPDATE_NXTUSE_MGCO_SSAPID();                                     
         }     
#endif /* GCP_MGCO */
#endif /* GCP_MGC */

#ifdef GCP_MG
#ifdef ZG
         {
            MgTptSrvrInfo *srvrInfo;
            CmLListCp *_lCp;
            CmLList   *_tmp;
            MgTptSrvr *tptSrvr;

#ifdef GCP_MGCO 
            srvrInfo = &(ssap->mgcoUDPSrvrLst);

            tptSrvr = NULLP;
            _lCp = &srvrInfo->srvrLstCp;
            _tmp = _lCp->first;

            while(_tmp)
            {
               tptSrvr = (MgTptSrvr *)(_tmp->node);
               _tmp    = _tmp->next;
               /* this will send HitDiscReq */
               if ((tptSrvr) && (tptSrvr->tsap) &&
                   (tptSrvr->tsap->tsapCfg.reCfg.changeOver == FALSE))
                  mgSrvDiscReq(tptSrvr, TRUE);
            }
#endif /* GCP_MGCO */

#ifdef GCP_MGCP 
            srvrInfo = &(ssap->mgcpUDPSrvrLst);

            tptSrvr = NULLP;
            _lCp = &srvrInfo->srvrLstCp;
            _tmp = _lCp->first;

            while(_tmp)
            {
               tptSrvr = (MgTptSrvr *)(_tmp->node);
               _tmp    = _tmp->next;
               /* this will send HitDiscReq */
               if ((tptSrvr) && (tptSrvr->tsap) &&
                   (tptSrvr->tsap->tsapCfg.reCfg.changeOver == FALSE))
                  mgSrvDiscReq(tptSrvr, TRUE);
            }
#endif /* GCP_MGCP */

         }
#endif /* ZG */
#endif /* GCP_MG */

       /* fall through */
      }

      case LMG_SAP_BND_DIS:
         ssap->state = LMG_SAP_UBND_DIS;
#ifdef ZG
         /* Update mod Ssap */
         zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
#endif /* ZG */
         break;

      default:
         ret = LCM_REASON_INVALID_STATE;
         break;
   }

   RETVALUE(ret);

} /* end of mgUbndDisSsap() */



/*
*
*       Fun:   mgDeleteSsap
*
*       Desc:  This function implements SSAP control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgDeleteSsap
(
MgSSAPCb           *ssap               /* SSAP Control Block */
)
#else
PRIVATE U16 mgDeleteSsap(ssap)
MgSSAPCb           *ssap;              /* SSAP Control Block */
#endif
{
   U16             ret;                /* Return Value */
   U16             idx;
   MgTptSrvr       *srvr;
   U32             j;                  /* temporary variable */


   TRC2(mgDeleteSsap)


   ret = LCM_REASON_NOT_APPL;

   if ((ssap->state == LMG_SAP_BND_ENB) || 
       (ssap->state == LMG_SAP_UBND_ENB))
   {
      MG_REM_SSAP_PEERS(ssap, FALSE);
#ifdef GCP_MG
      mgRemSsapSrvrs(ssap, TRUE);
#endif /* GCP_MG */
   }

#ifdef GCP_MGC
#ifdef GCP_MGCP
   if ((ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCP) &&                   
       (ssap->ssapCfg.sSAPId == mgCb.nxtMgcpSsapId))                      
   {                                                                      
      MG_UPDATE_NXTUSE_MGCP_SSAPID();                                     
   }     
#endif /* GCP_MGCP */
#ifdef GCP_MGCO
   if ((ssap->ssapCfg.protocol == LMG_PROTOCOL_MGCO) &&                   
       (ssap->ssapCfg.sSAPId == mgCb.nxtMgcoSsapId))                      
   {                                                                      
      MG_UPDATE_NXTUSE_MGCO_SSAPID();                                     
   }     
#endif /* GCP_MGCO */
#endif /* GCP_MGC */



   /* remove the SSAP from the SSAP list */
   *(mgCb.sSAPLst + ssap->ssapCfg.sSAPId) = NULLP;


   /* 
    * Go through the list of the TUCL TSAPs;
    *    Within each TUCL TSAP, go through the list of the servers
    *    associated with that TSAP.
    *    If the SSAP associated with any of these servers is the
    *    same as the ssap which is being deleted, make the SSAP
    *    in that server as NULL
    *  Remove the part from the #ifdef completely -
    */

   if (mgCb.tSAPLst)
      for (j=0; j < mgCb.genCfg.maxTSaps; ++j)
         if ((mgCb.tSAPLst[j]) &&
             (mgCb.tSAPLst[j]->tsapCfg.provType == LMG_PROV_TYPE_TUCL) &&
             (NULLP != mgCb.tSAPLst[j]->lstnrLst))
         {
            idx = 0;
            srvr = mgCb.tSAPLst[j]->lstnrLst[idx]->lstnrCb;
            while(srvr != NULLP)
            {
               if(srvr->t.ssap == ssap)
               {
                  srvr->t.ssap = NULLP;
               }
               idx++;
               srvr = mgCb.tSAPLst[j]->lstnrLst[idx]->lstnrCb;
            }
         }



   
   /* return the memory for this SAP */
#ifdef ZG
   /* send Update Del Ssap */
   zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
           CMPFTHA_ACTN_DEL);
   zgDelMapping(ZG_CBTYPE_SSAP, (Ptr)ssap);
#endif /* ZG */
   mgDeAlloc((Data *)ssap, sizeof(MgSSAPCb));
   
   RETVALUE(ret);

} /* end of mgDeleteSsap() */ 



/******************************************************************************/
/*                   Group TSAP Control Support Functions                     */
/******************************************************************************/


/*
*
*       Fun:   mgCntrlGrpTsap
*
*       Desc:  This function implements TSAP control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCntrlGrpTsap
(
MgCntrl            *cntrl              /* Control Structure */
)
#else
PRIVATE U16 mgCntrlGrpTsap(cntrl)
MgCntrl            *cntrl;             /* Control Structure */
#endif
{
   U16             ret;                /* Return Value */
   U32             i;                  /* Temporary Variable */
   MgTSAPCb        *tsap;              /* TSAP Control Block */
     
   TRC2(mgCntrlGrpTsap)

   ret = LCM_REASON_NOT_APPL;

   /*
    *   subAction = SATRC is NOT allowed for Group control of
    *   TSAP. If tracing is desired for all the TSAPs, do it
    *   multiple times for each TSAP.
    */

   if (cntrl->subAction != SAGR_DSTPROCID)
      RETVALUE(LCM_REASON_INVALID_SUBACTION);

   for (i = 0;  i < mgCb.genCfg.maxTSaps;  i++)
   {
      tsap = *(mgCb.tSAPLst + i);

      if (tsap == NULLP)
         continue;

      if (cntrl->s.par.dstProcId != tsap->spPst.dstProcId)
         continue;

      mgCntrlTsap(cntrl, tsap);
   }

   RETVALUE(ret);

} /* end of mgCntrlGrpTsap() */






/******************************************************************************/
/*                   Group SSAP Control Support Functions                     */
/******************************************************************************/


/*
*
*       Fun:   mgCntrlGrpSsap
*
*       Desc:  This function implements SSAP control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCntrlGrpSsap
(
MgCntrl            *cntrl              /* Control Structure */
)
#else
PRIVATE U16 mgCntrlGrpSsap(cntrl)
MgCntrl            *cntrl;             /* Control Structure */
#endif
{
   U16             ret;                /* Return Value */
   U16             i;                  /* Temporary Variable */
   MgSSAPCb        *ssap;              /* SSAP Control Block */
     
   TRC2(mgCntrlGrpSsap)

   ret = LCM_REASON_NOT_APPL;

   switch(cntrl->action)
   {
      case ADEL:
      case AUBND_DIS:
      {
         if (cntrl->subAction != SAGR_DSTPROCID)
            RETVALUE(LCM_REASON_INVALID_SUBACTION);

         for (i = 0;  i < mgCb.genCfg.maxSSaps;  i++)
         {
            ssap = *(mgCb.sSAPLst + i);
            if (ssap == NULLP)
               continue;

            if (cntrl->s.par.dstProcId != ssap->suPst.dstProcId)
               continue;

            if (cntrl->action == ADEL)
            {
               mgDeleteSsap(ssap);
            }
            else
            {
               mgUbndDisSsap(ssap);
            }
          }
      }
      break;

      default:
         ret = LCM_REASON_INVALID_ACTION;
         break;
   }
#ifdef ZG
   /* send update */
   zgUpdPeer();
#endif /* ZG */
   RETVALUE(ret);

} /* end of mgCntrlGrpSsap() */


/******************************************************************************/
/*                  GCP Peer Entity Control Support Functions                 */
/******************************************************************************/
/*
*
*       Fun:   mgCntrlPeer
*
*       Desc:  This function implements SSAP control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCntrlPeer
(
MgCntrl            *cntrl              /* Control Structure */
)
#else
PRIVATE U16 mgCntrlPeer(cntrl)
MgCntrl            *cntrl;             /* Control Structure */
#endif
{
   U16             ret;                /* Return Value */
   MgPeerCb        *peer;              /* Peer Control Block */
   MgSSAPCb        *ssap;              /* pointer to session SAP */
   MgPeerInfo      *peerInfo;          /* Peer Information */

   TRC2(mgCntrlPeer)

   ret = LCM_REASON_NOT_APPL;

   if ((cntrl->spId >= (SpId)mgCb.genCfg.maxSSaps) || 
       (cntrl->spId < 0))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG194, cntrl->spId,
                 "mgCntrlPeer():spId out of range");
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);
   }

   ssap = *(mgCb.sSAPLst + cntrl->spId);

   if (cntrl->subAction == SAELMNT)
      peerInfo = &(cntrl->s.peerInfo);
   else if (cntrl->subAction == SATRC)
      peerInfo = &(cntrl->s.trcCntrl.peerInfo);
   else  /* Added failure case for invalid subaction value */
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);

   peer = mgLocatePeer(peerInfo, ssap);

   if (peer == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG195, 
                 (ErrVal)cntrl->s.trcCntrl.peerInfo.id.val,
                "Invalid GCP peer.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);
   }

   switch(cntrl->action)
   {
      case ADEL:
      {
         if (cntrl->subAction != SAELMNT)
         {
            ret = LCM_REASON_INVALID_SUBACTION;
            break;
         }

         mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED,
                      LMG_CAUSE_MGMT_INITIATED, TRUE);
      }
      break;

      case AENA:
      case ADISIMM:
      {
         if (cntrl->subAction != SATRC)
         {
            ret = LCM_REASON_INVALID_SUBACTION;
            break;
         }
        
         if (cntrl->action == AENA)
         {
            /* if this is zero, the effect is the same as disabling trace */
            peer->mntInfo.trcLen = cntrl->s.trcCntrl.trcLen;
         }
         else
         {
            peer->mntInfo.trcLen = 0;
         }

      }
      break;

      default:
         ret = LCM_REASON_INVALID_ACTION;
         break;
   }
#ifdef ZG
   /* send update to peer */
   zgUpdPeer();
#endif /* ZG */
   RETVALUE(ret);

} /* end of mgCntrlPeer() */


/******************************************************************************/
/*                 Transport Server Control Support Functions                 */
/******************************************************************************/
/*
*
*       Fun:   mgCntrlTptServer
*
*       Desc:  This function implements SSAP control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCntrlTptServer
(
MgCntrl            *cntrl              /* Control Structure */
)
#else
PRIVATE U16 mgCntrlTptServer(cntrl)
MgCntrl            *cntrl;             /* Control Structure */
#endif
{
   MgTptSrvr       *tptSrvr;           /* Transport Server Control Block */

   TRC2(mgCntrlTptServer)

   if (cntrl->action != ADEL)
       RETVALUE(LCM_REASON_INVALID_ACTION);

   /* Changed parameter passed to FindTptSrvr */
   tptSrvr = mgFindTptSrvr(&cntrl->s.tptCntrl.serverAddr);
   
   /*-- mg004.105: BugFix: TCR21: If tptServer is not present then delete
        operation is always successful. --*/
   if (tptSrvr == NULLP)
      RETVALUE(LCM_REASON_NOT_APPL);
      /*--  RETVALUE(LCM_REASON_INVALID_PAR_VAL); --*/

   /* Remove Server */
   mgSrvDiscReq(tptSrvr, TRUE);
#ifdef ZG
   /* send update to peer */
   zgUpdPeer();
#endif /* ZG */
   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgCntrlTptServer() */ 


/*
*
*       Fun:   mgFindTptSrvr
*
*       Desc:  This function implements SSAP control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
/* Changed Function params */
#ifdef ANSI
PRIVATE MgTptSrvr * mgFindTptSrvr
(
CmTptAddr          *srvrAddr         /* Server Address */
)
#else
PRIVATE MgTptSrvr * mgFindTptSrvr(srvrAddr)
CmTptAddr          *srvrAddr;          /* Server Address */
#endif
{
   MgTptSrvr       *tptSrvr;           /* Transport Server Control Block */
   U16             i;                  /* Temporary Variable */
   U32             k;                  /* Temporary Variable */


   TRC2(mgFindTptSrvr)


   /*
    *   go thru the list of servers in each TUCL TSAP;
    *   one of the servers in one of the TUCL TSAPs
    *   might match the required server
    */
   for (k=0; k < mgCb.genCfg.maxTSaps; k++)
   {
      if ((mgCb.tSAPLst[k]) &&
          (mgCb.tSAPLst[k]->tsapCfg.provType == LMG_PROV_TYPE_TUCL) &&
          (mgCb.tSAPLst[k]->state == LMG_SAP_BND_ENB))
      {
         for (i=0; i < mgCb.genCfg.maxServers; i++)
         {

            if (mgCb.tSAPLst[k]->lstnrLst[i])
               tptSrvr = (mgCb.tSAPLst[k]->lstnrLst[i])->lstnrCb;

            /* compare tptAddr. If same then server found. */
            if(tptSrvr != NULLP)
            {
               if (!mgCmpTptAddr(&tptSrvr->tptAddr, srvrAddr))
               {
                  RETVALUE(tptSrvr);
               }
            }
         }

      }
   }


   RETVALUE(NULLP);

} /* end of mgFindTptSrvr() */

/******************************************************************************/
/*                 All SAPs Control Support Functions                         */
/******************************************************************************/
/*
*
*       Fun:   mgCntrlAllSaps
*
*       Desc:  This function implements control for all SAPs.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCntrlAllSaps
(
MgCntrl            *cntrl              /* Control Structure */
)
#else
PRIVATE U16 mgCntrlAllSaps(cntrl)
MgCntrl            *cntrl;             /* Control Structure */
#endif
{
   U32             i;                  /* counter */
   MgSSAPCb        *ssap;              /* SSAP cb */
   MgTSAPCb        *tsap;              /* TSAP cb */

   TRC2(mgCntrlAllSaps)


   if ((cntrl->action != AUBND_DIS) &&
       (cntrl->action != ABND_ENA))
     RETVALUE(LCM_REASON_INVALID_ACTION);

   for (i=0; i < mgCb.genCfg.maxTSaps; i++)
   {
      tsap = *(mgCb.tSAPLst + i);

      if (tsap == NULLP)
         continue;

      mgCntrlTsap(cntrl, tsap);
   }


   if (cntrl->action == AUBND_DIS)
   {
      for (i=0; i < mgCb.genCfg.maxSSaps; i++)
      {
         ssap = *(mgCb.sSAPLst + i);

         if (ssap == NULLP)
            continue;

         mgUbndDisSsap(ssap);
      }
   }/* end action */
#ifdef ZG
   /* send update */
   zgUpdPeer();
#endif /* ZG */
   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgCntrlAllSaps() */


/******************************************************************************/
/*                 MG Control Support Functions                               */
/******************************************************************************/
#ifdef GCP_MGCO
#ifdef GCP_MG
/*
*
*       Fun:   mgCntrlMG
*
*       Desc:  This function implements SSAP control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCntrlMG
(
MgCntrl            *cntrl              /* Control Structure */
)
#else
PRIVATE U16 mgCntrlMG(cntrl)
MgCntrl            *cntrl;             /* Control Structure */
#endif
{
   U16             ret;                /* Return Value */
   U16             retVal;             /* Return Value */
   U8              method;             /* RSIP/ServiceChange Method */
   MgSSAPCb        *ssap;              /* SSAP Control Block */

   TRC2(mgCntrlMG)

   ret = LCM_REASON_NOT_APPL;
   
   MG_MI_VALIDATE_SSAP(ssap, cntrl->spId, ret);

   retVal = RFAILED;   /* initialize */

   /* 
    * AENA, ADISIMM are used to mark SSAP on MG side as Active, standby in a
    * mated pair cfg.
    * ADEL is used to revert from a mated pair cfg to a stand alone cfg for the
    * SSAP 
    */
     
   switch(cntrl->action)
   {
      case AENA:
      {
         ssap->mgType = MG_ACTIVE;
#ifdef ZG
         /* Update mod Ssap */
         zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
#endif /* ZG */
      }
      break;

      case ADISIMM:
      {
         ssap->mgType = MG_STANDBY;
#ifdef ZG
         /* Update mod Ssap */
         zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
#endif /* ZG */
      }
      break;

      case ADEL:
      {
         ssap->mgType = MG_NONE;
#ifdef ZG
         /* Update mod Ssap */
         zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
#endif /* ZG */
      }
      break;

      case AFAILOVER:
      {
         if (ssap->crntMgc == NULLP)
           RETVALUE(LCM_REASON_INVALID_PAR_VAL);

         method = MG_NONE;

         if (ssap->mgType == MG_NONE)
         {
            method = MGT_SVCCHGMETH_FORCED;
         }
         else 
         if (ssap->mgType == MG_ACTIVE)
         {
            method = MGT_SVCCHGMETH_FAILOVER;
         }

         if (method != MG_NONE)
         {
            retVal = mgSendSrvcChng(ssap->crntMgc, method, 
                                    MG_SCRSN_MG_IMPN_FAIL, 
                                    NULLP, (S32) MGT_NONE,
                                    NULLP);
         }

         if (retVal != ROK)
            ret = LMG_REASON_FAILOVER_FAILED;
      }
      break;

      case ARESTART:
      {
         if (ssap->crntMgc == NULLP)
            RETVALUE(LCM_REASON_INVALID_PAR_VAL);
         
         retVal = mgSendSrvcChng(ssap->crntMgc, MGT_SVCCHGMETH_RESTART , 
                                MG_SCRSN_COLD_BOOT,NULLP,(S32) MGT_NONE,
                                NULLP);

         if (retVal != ROK)
            ret = LMG_REASON_RESTART_FAILED;
      }
      break;

      default:
         ret = LCM_REASON_INVALID_ACTION;
         break;
   }
#ifdef ZG
   /* send update */
   zgUpdPeer();
#endif /* ZG */   
   RETVALUE(ret);

} /* end of mgCntrlMG() */

#endif /* GCP_MG */


/******************************************************************************/
/*                 MGC Control Support Functions                              */
/******************************************************************************/
#ifdef GCP_MGCO
#ifdef GCP_MGC
/*
*
*       Fun:   mgCntrlMGC
*
*       Desc:  This function implements SSAP control.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCntrlMGC
(
MgCntrl            *cntrl              /* Control Structure */
)
#else
PRIVATE U16 mgCntrlMGC(cntrl)
MgCntrl            *cntrl;             /* Control Structure */
#endif
{
   U16             ret;                /* Return Value */
   U16             retVal;             /* Return Value */
   MgPeerCb        *activePeer;        /* Active Peer */
   MgPeerCb        *standbyPeer;       /* Standby Peer */
   MgPeerInfo      *activePeerInfo;    /* Active Peer Information */
   MgAddrInfo      *handoffMgc;        /* Handoff MGC */
   MgPeerInfo      *standbyPeerInfo;   /* Standby Peer Information */
   MgSSAPCb        *ssap;              /* SSAP Control Block */

   TRC2(mgCntrlMGC)

   ret = LCM_REASON_NOT_APPL;

   switch (cntrl->action)
   {
      case AHANDOFF:
      {       
         activePeerInfo = &(cntrl->s.peerCntrlInfo.activePeer);

         handoffMgc = &(cntrl->s.peerCntrlInfo.u.handoffMgc);

         /* 
          * Since handoffMgc is now MgAddrInfo, removed the check
          * for pres field 
          */

         /* 
          * If NO MG is specified for handoff, it implies all MG associated
          * with the SSAP need to be handed off
          */
         if (activePeerInfo->pres.pres != NOTPRSNT)
         {
            /* 
             * Handoff a particular MG 
             * MGC side, ssap is not required in mgLocatePeer 
             */
            activePeer = mgLocatePeer(activePeerInfo, NULLP);

            if (activePeer == NULLP)
               RETVALUE(LCM_REASON_INVALID_PAR_VAL);

            if (activePeer->mntInfo.protocolType != LMG_PROTOCOL_MGCO)
               RETVALUE(LMG_REASON_INVALID_PROTOCOL);

            retVal = mgSendSrvcChng(activePeer, MGT_SVCCHGMETH_HANDOFF, 
                                    MG_SCRSN_MGC_IMPN_FAIL, NULLP, 
                                    (S32) MGT_NONE,
                                    handoffMgc);

            if (retVal != ROK)
               ret = LMG_REASON_HANDOFF_FAILED;
         }
         else
         {
            /* 
             * Layer Manager Intends to do a hand off all MG associated with
             * specified SSAP
             */
            CmLList    *cmLstEnt;

            MG_MI_VALIDATE_SSAP(ssap, cntrl->spId, ret);

            cmLstEnt = ssap->peerLst.first;

            while (cmLstEnt != NULLP)
            {
               activePeer = (MgPeerCb *)cmLstEnt->node;
               cmLstEnt   = cmLstEnt->next;

               if (activePeer->mntInfo.protocolType != LMG_PROTOCOL_MGCO)
                  continue;

               if ((mgSendSrvcChng(activePeer, MGT_SVCCHGMETH_HANDOFF, 
                                       MG_SCRSN_MGC_IMPN_FAIL, NULLP, 
                                       (S32) MGT_NONE,
                                       handoffMgc)) != ROK)
               {
                  /* Use existing MGCP/MGCO specific macros */
                  MG_ISSUE_MGCOPEER_STAIND(activePeer, LCM_CATEGORY_INTERNAL,
                                       LMG_EVENT_PEER_HANDOFF_FAILURE, 
                                       LMG_CAUSE_RSRC_UNAVAIL);

                  mgDeletePeer(activePeer, MG_IGNORE, MG_IGNORE, TRUE);
                  continue;
               }
            }

         }
      }
#ifdef ZG
      zgUpdPeer();
#endif /* ZG */
      break;
#ifndef ZG
      case AMATEDCFG_ADD:
      {
         /* 
          * This cntrl is to make a pair of MGs(peers) into a redundant pair cfg
          * on the MGC side 
          */
         activePeerInfo = &(cntrl->s.peerCntrlInfo.activePeer);
         standbyPeerInfo = &(cntrl->s.peerCntrlInfo.u.standbyPeer);

         /* MGC side, ssap is not required in mgLocatePeer */
         activePeer = mgLocatePeer(activePeerInfo, NULLP);
         standbyPeer =  mgLocatePeer(standbyPeerInfo, NULLP);

         if ((activePeer == NULLP) || (standbyPeer == NULLP))
           RETVALUE(LCM_REASON_INVALID_PAR_VAL);

         if ((activePeer->mntInfo.protocolType != LMG_PROTOCOL_MGCO) ||
              (standbyPeer->mntInfo.protocolType != LMG_PROTOCOL_MGCO))
         {
            RETVALUE(LMG_REASON_INVALID_PROTOCOL);
         }

         if ((activePeer->state != LMG_PEER_STATE_ACTIVE) ||
              (standbyPeer->state != LMG_PEER_STATE_ACTIVE))
         {
            RETVALUE(LMG_REASON_INVALID_PEER_STATE);
         }

         activePeer->mgcoInfo.peerType = MG_ACTIVE;
         standbyPeer->mgcoInfo.peerType = MG_STANDBY;
          
         activePeer->mgcoInfo.t.matedMG = standbyPeer;
         standbyPeer->mgcoInfo.t.matedMG = activePeer;

         mgMoveAllTxn(standbyPeer, activePeer, MG_INTERNAL);
      }
      break;
#endif /* ZG */
      case AMATEDCFG_RMV:
      {
         /* 
          * This cntrl req is used to remove association between a mated 
          * MG pair 
          */
         activePeerInfo = &(cntrl->s.peerCntrlInfo.activePeer);
         standbyPeerInfo = &(cntrl->s.peerCntrlInfo.u.standbyPeer);
           
         /* MGC side, ssap is not required in mgLocatePeer */
         activePeer = mgLocatePeer(activePeerInfo, NULLP);
         standbyPeer =  mgLocatePeer(standbyPeerInfo, NULLP);


         if ((activePeer == NULLP) || (standbyPeer == NULLP))
           RETVALUE(LCM_REASON_INVALID_PAR_VAL);
          
         if ((activePeer->mntInfo.protocolType != LMG_PROTOCOL_MGCO) ||
             (standbyPeer->mntInfo.protocolType != LMG_PROTOCOL_MGCO))
         {
            RETVALUE(LMG_REASON_INVALID_PROTOCOL);
         }

         if ((activePeer->mgcoInfo.t.matedMG != standbyPeer) ||
             (standbyPeer->mgcoInfo.t.matedMG != activePeer))
         {
            RETVALUE(LCM_REASON_INVALID_PAR_VAL);
         }
           
         activePeer->mgcoInfo.t.matedMG = NULLP;
         activePeer->mgcoInfo.peerType = MG_NONE;
         standbyPeer->mgcoInfo.t.matedMG = NULLP;
         standbyPeer->mgcoInfo.peerType = MG_NONE;
#ifdef ZG
         /* Send update mod for active and standby peer */
         zgRtUpd(ZG_CBTYPE_PEER,(Ptr)activePeer,
            CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_MOD);
         zgRtUpd(ZG_CBTYPE_PEER,(Ptr)standbyPeer,
            CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_MOD);
         zgUpdPeer();
#endif /* ZG */
      }
      break;

      default:
         RETVALUE(LCM_REASON_INVALID_ACTION);
   }
   RETVALUE(ret);

} /* end of mgCntrlMGC() */
#endif /* GCP_MGC */
#endif /* GCP_MGCO */


/*
*
*       Fun:  mgGetMgcoSrvrType
*
*       Desc:  This function configures an MGCP peer entity.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgGetMgcoSrvrType
(
MgSrvrInitInfo     *initInfo,          /* Initialisation Information */
MgSrvrCfg          *srvrCfg            /* Server Configuration Info */
)
#else
PRIVATE U16 mgGetMgcoSrvrType(initInfo, srvrCfg)
MgSrvrInitInfo     *initInfo;          /* Initialisation Information */
MgSrvrCfg          *srvrCfg;           /* Server Configuration Info */
#endif
{
#ifdef GCP_MG 
   MgSSAPCb        *ssap;              /* SSAP Control Block */
#endif /* GCP_MG */

   TRC2(mgGetMgcoSrvrType)

#ifdef GCP_MGC 
   if (mgCb.genCfg.entType == LMG_ENT_GC)
   {
      if (srvrCfg->isDefault == TRUE)
         initInfo->srvrType = MG_MGCO_DEFLT_SRVR;
      else
         initInfo->srvrType = MG_ROUND_ROBIN_SRVR_MGCO;
   }
#endif /* GCP_MGC */

#ifdef GCP_MG 
   ssap = *(mgCb.sSAPLst + srvrCfg->sSAPId);

   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
      /*
       * If "isDefault" flag is TRUE in configuration, mark this server as a
       * default server. Further, make sure that for round-robin server, ssap is
       * not NULLP.
       */
      if (srvrCfg->isDefault == TRUE)
         initInfo->srvrType = MG_MGCO_DEFLT_SRVR;
      else
      {
         if (ssap != NULLP)
            initInfo->srvrType = MG_ROUND_ROBIN_SRVR_MGCO;
         else
            RETVALUE(RFAILED);
      }
   }
#endif /* GCP_MG */
   RETVALUE(ROK);

} /* end of mgGetMgcoSrvrType() */





#ifdef    GCP_PROV_SCTP

/*----------------------------------------------------------------------------*/
/*                  New Functions added for supporting SCTP                   */
/*----------------------------------------------------------------------------*/




/******************************************************************************/
/*                  end point Configuration Function                          */
/******************************************************************************/

/*
*
*       Fun:   mgEndpCfg
*
*       Desc:  This function configures an SCTP end point.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes:  new typedefs - MgEndpLstCfg, MgEndpCfg
*                     are needed in lmg.x.
*                     new hash define LMG_MAX_DEF_ENDPTS needed.
*
*       File:  mg_mi.c
*
*        The following func name clashes with a structure
*              name. U should change the name of this function.
*
*/
#ifdef ANSI
PRIVATE U16 mgEndpCfg
(
MgEndpLstCfg       *cfg                /* list of end point cfg structs */
)
#else
PRIVATE U16 mgEndpCfg(cfg)
MgEndpLstCfg       *cfg;               /* list of end point cfg structs */
#endif
{
   U16             i;                  /* loop Variable */
   MgEndpCfg       *endpCfg = NULLP;   /* SSAP Control Block */
   MgTSAPCb        *tsap = NULLP;      /* TSAP Control Block */
   MgSSAPCb        *ssap = NULLP;      /* SSAP Control Block */
   MgParId         parId;


   TRC2(mgEndpCfg)



   /*
    *   Need to have general configuration done first
    */

   if (mgCb.init.cfgDone == FALSE)
   {

#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG196, (ErrVal)MG_NONE,
                " General Cfg Not Done");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      RETVALUE(LCM_REASON_GENCFG_NOT_DONE);
   }




   /*
    *   check if the end points count is within range
    */

   if (cfg->count > LMG_MAX_DEF_ENDPTS)
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);




   /*
    *   Traverse the list of end point
    *   configuration structures
    */

   for (i=0; i < cfg->count; i++)
   {

      endpCfg = &(cfg->endp[i]);


      /*
       *   Find out the tsap from the tSAPId
       *   field of endpCfg
       */

      /*mg002.105: Removed compilation error */
      if ((endpCfg->tSAPId < 0) || (endpCfg->tSAPId > (SpId)mgCb.genCfg.maxTSaps))
      {

#if (ERRCLASS & ERRCLS_INT_PAR)
            MGLOGERROR(ERRCLS_INT_PAR, EMG197, (ErrVal)MG_NONE,
                                       "mgEndpCfg: Invalid TSAP Id");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */  


            /*
             *   generate a status indication and continue
             *   since the remaining endpCfgs may specify
             *   correct tSAPIds
             */

            MG_SEND_ENDP_STAIND(LMG_CAUSE_INVALID_TSAPID,
                                LMG_ALARMINFO_INVSAPID, parId);
            continue;
      }
      else
         tsap = mgCb.tSAPLst[endpCfg->tSAPId];




      /*
       *   Check if -
       *
       *      1) tsap cfg has been done
       *      2) tsap provider is SCTP
       */

      if ((tsap == NULLP)          ||
          (tsap->cfgDone == FALSE) ||
          (tsap->tsapCfg.provType != LMG_PROV_TYPE_SCTP))
      {

#if (ERRCLASS & ERRCLS_INT_PAR)
            MGLOGERROR(ERRCLS_INT_PAR, EMG198, (ErrVal)MG_NONE,
                                       "mgEndpCfg: Invalid TSAP/"
                                        "TSAP Cfg not done");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */  


            /*
             *   generate a status indication and continue
             *   since the remaining endpCfgs may specify
             *   correct tsap
             */

            MG_SEND_ENDP_STAIND(LMG_REASON_TSAPCFG_NOT_DONE,
                                (endpCfg->tSAPId), parId);
            continue;
      }




      if (tsap->endpCfgDone == TRUE)
      {

#if (ERRCLASS & ERRCLS_INT_PAR)
            MGLOGERROR(ERRCLS_INT_PAR, EMG199, (ErrVal)MG_NONE,
                                       "mgEndpCfg: End point "
                                        "Cfg already done");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */  


            /*
             *   generate a status indication and continue
             *   since the remaining endpCfgs may specify
             *   correct tSAPIds
             */

            MG_SEND_ENDP_STAIND(LMG_REASON_ENDPCFG_ALREADY_DONE,
                                (endpCfg->tSAPId), parId);
            continue;
      }


         tsap->endpCb.encodingScheme = endpCfg->encodingScheme;



#ifdef GCP_MG
      if (mgCb.genCfg.entType == LMG_ENT_GW)
      {
         /*
          *   Find out the ssap from the sSAPId
          *   field of endpCfg
          */

         if ((endpCfg->sSAPId < 0) || (endpCfg->sSAPId > mgCb.genCfg.maxSSaps))
            ssap = NULLP;
         else
            ssap = mgCb.sSAPLst[endpCfg->sSAPId];


      }
#endif /* GCP_MG */



      /*
       *   call the function mgEndpOpenReq which sends the SCTP
       *   EndpOpenReq only if the SCTP TSAP is in BND_ENB state
       */

      if (ROK != mgEndpOpenReq(tsap, endpCfg))
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
            MGLOGERROR(ERRCLS_INT_PAR, EMG200, (ErrVal)MG_NONE,
                                       "mgEndpCfg: mgEnpdOpenReq()"
                                        "failure");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */  


            /*
             *   generate a status indication and continue
             *   since the remaining endpCfgs may specify
             *   correct tSAPIds
             */

            MG_SEND_ENDP_STAIND(LCM_REASON_MISC_FAILURE,
                                (endpCfg->tSAPId), parId);
            continue;

      }

   }   /* end of for loop */


   RETVALUE(LCM_REASON_NOT_APPL);

} /* end of mgEndpCfg() */






/******************************************************************************/
/*                 End point Control Support Functions                        */
/******************************************************************************/
/*
*
*       Fun:   mgCntrlEndp
*
*       Desc:  This function implements endpoint deletion control request
*
*       Ret:   LCM_REASON_NOT_APPL      - successful
*
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgCntrlEndp
(
MgCntrl            *cntrl              /* Control Structure */
)
#else
PRIVATE U16 mgCntrlEndp(cntrl)
MgCntrl            *cntrl;             /* Control Structure */
#endif
{
   MgEndpCb        *endpCb = NULLP;    /* end point Control Block */
   MgTSAPCb        *tsap;              /* TSAP control block */
   U32             i;                  /* loop counter */

   TRC2(mgCntrlEndp)


   /*
    *   The Only action allowed is the Deletion of the endpoint
    */

   if (cntrl->action != ADEL)
       RETVALUE(LCM_REASON_INVALID_ACTION);


   /*
    *    a new field endpCntrl of type MgEndpCntrl is
    *          required in union s of MgCntrl. The typedef of
    *          MgEndpCntrl shall be -
    *          typedef SctPort MgEndpCntrl;
    */


   /*
    *   Search in the list of TSAPs for the
    *   relevant TSAP/Endpoint;
    *   The searching is done by comparing
    *   the port in the endpCb with the
    *   cntrl->s.endpCntrl field in the control request
    */


   for (i=0; i < mgCb.genCfg.maxTSaps; ++i)
   {
      if ((mgCb.tSAPLst[i]) &&
          (mgCb.tSAPLst[i]->endpCfgDone == TRUE) &&
          (mgCb.tSAPLst[i]->endpCb.port == cntrl->s.endpCntrl))
      {
         endpCb = &(mgCb.tSAPLst[i]->endpCb);
         tsap   = mgCb.tSAPLst[i];
         break;         /* break through the for loop */
      }
   }


   /*
    *   Error - the endpoint could not be found
    */

   if (endpCb == NULLP)
       RETVALUE(LCM_REASON_INVALID_PAR_VAL);



   /*
    *   Close the endpoint only if the end point is
    *   in READY state
    */

   if (endpCb->epState == LMG_EP_STATE_READY)
   {
      if (ROK == mgCloseEndp(endpCb, tsap,FALSE))
         RETVALUE(LCM_REASON_NOT_APPL);
      else
         RETVALUE(LCM_REASON_MISC_FAILURE);
   }
   /*
    *   Error - the endpoint state is not valid to
    *           allow this operation
    */
   else
      RETVALUE(LCM_REASON_INVALID_STATE);



} /* end of mgCntrlEndp() */ 


#endif    /* GCP_PROV_SCTP */



#endif /* GCP_MGCO */



#ifdef GCP_MGCP

/*
*
*       Fun:  mgGetMgcpSrvrType
*
*       Desc:  This function configures an MGCP peer entity.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE U16 mgGetMgcpSrvrType
(
MgSrvrInitInfo     *initInfo,          /* Initialisation Information */
MgSrvrCfg          *srvrCfg            /* Server Configuration Info */
)
#else
PRIVATE U16 mgGetMgcpSrvrType(initInfo, srvrCfg)
MgSrvrInitInfo     *initInfo;          /* Initialisation Information */
MgSrvrCfg          *srvrCfg;           /* Server Configuration Info */
#endif
{
#ifdef GCP_MG 
   MgSSAPCb        *ssap;              /* SSAP Control Block */
#endif /* GCP_MG */

   TRC2(mgGetMgcpSrvrType)

   if (srvrCfg->transportType != LMG_TPT_UDP)
      RETVALUE(RFAILED);

#ifdef GCP_MGC 
   if (mgCb.genCfg.entType == LMG_ENT_GC)
   {
   if (srvrCfg->isDefault == TRUE)
      initInfo->srvrType = MG_MGCP_DEFLT_SRVR;
   else
      initInfo->srvrType = MG_ROUND_ROBIN_SRVR_MGCP;
   }
#endif /* GCP_MGC */

#ifdef GCP_MG 
   ssap = *(mgCb.sSAPLst + srvrCfg->sSAPId);

   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
      /*
       * If "isDefault" flag is TRUE in configuration, mark this server as a
       * default server. Further, make sure that for round-robin server, ssap is
       * not NULLP.
       */
      if (srvrCfg->isDefault == TRUE)
         initInfo->srvrType = MG_MGCP_DEFLT_SRVR;
      else
      {
         if (ssap != NULLP)
            initInfo->srvrType = MG_ROUND_ROBIN_SRVR_MGCP;
         else
            RETVALUE(RFAILED);
      }
   }
#endif /* GCP_MG */

   RETVALUE(ROK);

} /* end of mgGetMgcpSrvrType() */

#endif /* GCP_MGCP */



/******************************************************************************/
/*                 Syatem Agent Control Request                               */
/******************************************************************************/

#ifdef MG_FTHA
    /*
     *
     *       Fun  :  System agent control Request 
     *
     *       Desc :  Processes system agent control request primitive
     *
     *       Ret  :  ROK  - ok
     *
     *       Notes:  None
     *
     *       File :  mg_bdy1.c
     *
     */
#ifdef ANSI
PUBLIC S16 MgMiShtCntrlReq
(
Pst                *pst,               /* post structure */
ShtCntrlReqEvnt    *reqInfo            /* system agent control request event */
)
#else
PUBLIC S16 MgMiShtCntrlReq(pst, reqInfo)
Pst                *pst;               /* post structure          */
ShtCntrlReqEvnt    *reqInfo;           /* system agent control request event */
#endif
{
   ShtCntrlCfmEvnt cfmInfo;  /* system agent control confirm event */
#ifdef MG_RUG
   ShtVerInfo      *intfInfo;/* Version Information */
#endif /* MG_RUG */
   Reason          reason;   /* Reason */
   U16             ret;      /* Return Code */
   U8              action;   /* control action */
   /*mg002.105: Removed compilation error */
   U32             i;        /* counter */
   MgSSAPCb        *ssap;    /* ssap cb */

   TRC3(MgMiShtCntrlReq);

   reason = LCM_REASON_NOT_APPL;

   cmMemset((U8 *)&(cfmInfo), 0, sizeof(ShtCntrlCfmEvnt));

#ifdef MG_RUG
   cfmInfo.reqType = reqInfo->reqType;
#endif /* SI_RUG */

   /* check if general configuration done */
   if (mgCb.init.cfgDone != TRUE)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
     MGLOGERROR(ERRCLS_INT_PAR, EMG201, (ErrVal)pst->event,
                "Invalid element.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

     mgSendShCfm(LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE, 
                 pst, reqInfo, &cfmInfo);
     RETVALUE(ROK);
   }

   /* fill status value */
   cfmInfo.status.reason = LCM_REASON_NOT_APPL;
        
#ifdef ZG
   if ((reqInfo->reqType != SHT_REQTYPE_GETVER) &&
       (reqInfo->reqType != SHT_REQTYPE_SETVER))
   {
      /* 
       * Validation of Critical Resource Set being active is to be done
       * for all other SHT Control Requests
       */
      if ((zgChkCRsetStatus()) == FALSE) 
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
         MGLOGERROR(ERRCLS_INT_PAR, EMG202, (ErrVal)pst->event,
                     "Invalid ShtControl Request.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

         mgGenStaInd(STGEN, LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                    LCM_CAUSE_PROT_NOT_ACTIVE, LMG_ALARMINFO_NONE, NULLP, 
                    0, LMG_ALARMINFO_NONE);
         RETVALUE(RFAILED);
      }
   }
#endif /* ZG */

    switch (reqInfo->reqType)
    {
       case SHT_REQTYPE_BND_ENA:   /* system agent control bind enable */
       {
          action = ABND_ENA;
          switch (reqInfo->s.bndEna.grpType)
          {
             case SHT_GRPTYPE_ENT:
             case SHT_GRPTYPE_ALL:
             {
                reason = LCM_REASON_INVALID_PAR_VAL;

                for (i=0; i< mgCb.genCfg.maxTSaps; i++)
                {
                   MgTSAPCb      *tsap = NULLP;

                   tsap = mgCb.tSAPLst[i];

                   if (tsap != NULLP)
                   {     

                      if ((tsap->spPst.dstEnt == reqInfo->s.bndEna.dstEnt.ent)
                                      &&
                          (tsap->spPst.dstInst ==
                           reqInfo->s.bndEna.dstEnt.inst))
                      {
                          if (!((reqInfo->reqType == SHT_GRPTYPE_ALL) &&
                                (tsap->spPst.dstProcId != 
                                 reqInfo->s.bndEna.dstProcId)))
                          {
                             if (tsap->contEnt != ENTSM)
                             {
                                 reason = mgEnableTsap(tsap, action);
                             }
                          }
                      }
                   }
                }
             }
             break;
             default:
                reason = LCM_REASON_INVALID_PAR_VAL;
             break;
          }
       }
       break;
         

       /* system agent control unbind disable */
       case SHT_REQTYPE_UBND_DIS:
       {
         ShtGrpBndInfo      *ubndDis;
#ifdef MG_RUG
         MgIntVerInfo       *verInfo;
#ifdef ZG
         ZgUpdVerInfo       updVer;
#endif /* ZG */
         U16                infIdx;
#endif /* MG_RUG */

         action = AUBND_DIS;
         ubndDis = &(reqInfo->s.ubndDis);

         switch (ubndDis->grpType)
         {
            case SHT_GRPTYPE_ALL:
            case SHT_GRPTYPE_ENT:
            {
               for (i = 0;  i < mgCb.genCfg.maxSSaps;  i++)
               {                  
                  ssap = *(mgCb.sSAPLst + i);
                  if (ssap == NULLP)
                  continue;
                  
                  if ((ssap->suPst.dstEnt == ubndDis->dstEnt.ent) &&
                     (ssap->suPst.dstInst == ubndDis->dstEnt.inst))
                  {                    
                     if ((ubndDis->grpType == SHT_GRPTYPE_ALL) &&
                           (ssap->suPst.dstProcId != ubndDis->dstProcId))
                     {
                        continue;
                     }
                     
                     reason = mgUbndDisSsap(ssap);                   
                  }

                  reason = LCM_REASON_NOT_APPL;
               } /* for each ssap */
               
               
               for (i=0; i< mgCb.genCfg.maxTSaps; i++)
               {
                  MgTSAPCb      *tsap = NULLP;

                  tsap = mgCb.tSAPLst[i];

                  if (tsap != NULLP)
                  {
                     /* For TSAP */
                     if ((tsap->spPst.dstEnt == ubndDis->dstEnt.ent) &&
                         (tsap->spPst.dstInst == ubndDis->dstEnt.inst))
                     {
                        reason = mgDisableTsap(tsap, action);
                        /* Moved followed code within TSAP case */
#ifdef ZG
                        /* 
                         * if changeOver flag is TRUE..means service provider
                         * has failed..so send status ind to service user 
                         *  statusInd to be generated for ALL TSAPs?
                         */
                        if (tsap->tsapCfg.reCfg.changeOver == TRUE)
                        {
                           tsap->state = LMG_SAP_UBND_DIS;
                           mgGenUserStaInd(NULLP, NULLP,
                                           MGT_STATUS_SRVC_PRVDR_FAILED,
                                           NULLP);
                        }
#endif /* ZG */
                     }
                  }
               }


#ifdef MG_RUG
               verInfo = &(mgCb.verInfo);
               for (i = (verInfo->numIntfInfo - 1); i >= 0; i--)
               {
                  intfInfo = &(verInfo->intfInfo[i]);

                  if ((intfInfo->dstEnt.ent == ubndDis->dstEnt.ent) &&
                      (intfInfo->dstEnt.inst == ubndDis->dstEnt.inst))
                  {
                     if ((ubndDis->grpType == SHT_GRPTYPE_ALL) &&
                         (intfInfo->dstProcId != ubndDis->dstProcId))
                     {
                        continue;
                     }

#ifdef ZG
                     /* Delete the interface version at SBY/Shadows */
                     ZG_INIT_UPDVER_STRUCT(updVer, intfInfo);

                     zgRtUpd(ZG_CBTYPE_VERINFO, (Ptr)&(updVer),
                            CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_DEL);
#endif /* ZG */

                     /* 
                      * Delete the version information by copying the last
                      * version information into current location
                      */
                     
                     infIdx = (verInfo->numIntfInfo -1);
                     cmMemcpy((U8 *) &(verInfo->intfInfo[i]), 
                              (CONSTANT U8 *)&(verInfo->intfInfo[infIdx]),
                              sizeof(ShtVerInfo));
                     verInfo->numIntfInfo--;
                  }
               }
#endif /* MG_RUG */
            }
            break;
            
            default:
               cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
            break;
         } /* switch on grpType */
       }
         
       /* For rolling upgrade */
#ifdef MG_RUG
       case SHT_REQTYPE_GETVER:      /* system agent get version */
       {
          mgGetVer(&cfmInfo.t.gvCfm);
       }
       break;

       case SHT_REQTYPE_SETVER:      /* system agent set version */
       {
          mgSetVer(&reqInfo->s.svReq, &cfmInfo.status);
#ifdef ZG
         /* send the interface version to standby */
         if (cfmInfo.status.reason == LCM_REASON_NOT_APPL)
         {
            ZgUpdVerInfo     updVer;

            ZG_INIT_UPDVER_STRUCT(updVer, &(reqInfo->s.svReq));

            zgRtUpd(ZG_CBTYPE_VERINFO, (Ptr)&(updVer), CMPFTHA_UPDTYPE_SYNC, 
                    CMPFTHA_ACTN_MOD);
         }
#endif /* ZG */
       }
       break;
#endif /* MG_RUG */

          break;
      default:
        cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
        break;
    } /* switch on reqType */


   if (reason != LCM_REASON_NOT_APPL)
   {
       ret = LCM_PRIM_NOK;
   }
   else
   {
      ret = LCM_PRIM_OK;
   }

    mgSendShCfm(ret, reason, pst, reqInfo, &cfmInfo);
    
#ifdef ZG
    zgUpdPeer();
#endif /* ZG */
    
    RETVALUE(ROK);

} /* end MgMiShtCntrlReq */




/******************************************************************************/
/*                   System Agent  Confirm  Function                          */
/******************************************************************************/

/*
*
*       Fun:   mgSendShCfm
*
*       Desc:  This function sends various confirm primitives to the
*              Layer Manager
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  mg_mi.c
*
*/
#ifdef ANSI
PRIVATE Void mgSendShCfm
(
U16                status,             /* confirm status */
U16                reason,             /* failure reason */
Pst                *srcPst,            /* incoming Pst */
ShtCntrlReqEvnt    *req,               /* system agent control request */
ShtCntrlCfmEvnt    *cfm                /* system agent control confirm */
)
#else
PRIVATE Void mgSendShCfm(status, reason, srcPst, req, cfm)
U16                status;             /* confirm status */
U16                reason;             /* failure reason */
Pst                *srcPst;            /* incoming Pst */
ShtCntrlReqEvnt    *req;               /* system agent control request */
ShtCntrlCfmEvnt    *cfm;               /* system agent control confirm */
#endif
{
   Pst             cfmPst;             /* Pst structure for confimation */

   TRC2(mgSendShCfm)

   /* fill up the Pst structure for comfirm */
   cfmPst.srcEnt    = mgCb.init.ent;
   cfmPst.srcInst   = mgCb.init.inst;
   cfmPst.srcProcId = mgCb.init.procId;
   cfmPst.dstEnt    = srcPst->srcEnt;
   cfmPst.dstInst   = srcPst->srcInst;
   cfmPst.dstProcId = srcPst->srcProcId;

   cfmPst.selector  = req->hdr.response.selector;
   cfmPst.prior     = req->hdr.response.prior;
   cfmPst.route     = req->hdr.response.route;
   cfmPst.region    = req->hdr.response.mem.region;
   cfmPst.pool      = req->hdr.response.mem.pool;
 
   /* fill reply transaction Id */
   cfm->transId = req->hdr.transId;

   /* set the result */
   cfm->status.status = status;
   cfm->status.reason = reason;

   MgMiShtCntrlCfm(&cfmPst, cfm);
   
   RETVOID;

} /* end of mgSendShCfm() */

#endif /* MG_FTHA */


#ifdef MG_RUG
/******************************************************************************/
/*                   Get Interface Version Function                           */
/******************************************************************************/


/*
 *
 *      Fun:   Get Interface Version Handling
 *
 *      Desc:  Processes system agent control request primitive
 *             to get interface version for all interface implemented 
 *             by the protocol.
 *
 *      Ret:   ROK   - ok
 *
 *      Notes: None
 *
 *      File:  mp_mi.c
 *
 */
#ifdef ANSI
PUBLIC S16 mgGetVer
(
ShtGetVerCfm       *getVerCfmInfo      /* Return interface version information */
)
#else
PUBLIC S16 mgGetVer(getVerCfmInfo)
ShtGetVerCfm       *getVerCfmInfo;     /* Return interface version information */
#endif
{
   TRC3 (mgGetVer)

   /* Fill the upper interface IDs and their ver number */
   getVerCfmInfo->numUif = 1;
   getVerCfmInfo->uifList[0].intfId = MGTIF;
   getVerCfmInfo->uifList[0].intfVer = MGTIFVER;

   /* Fill the lower interface IDs and their ver number */
   getVerCfmInfo->numLif = 1;
   getVerCfmInfo->lifList[0].intfId = HITIF;
   getVerCfmInfo->lifList[0].intfVer = HITIFVER;

#ifdef ZG 
   /* Fill peer interface ID and version number */
   zgGetVer(&getVerCfmInfo->pif);
#endif /* ZG */

   RETVALUE(ROK);
} /* End of mgGetVer */


/******************************************************************************/
/*                   Set Interface Version Function                           */
/******************************************************************************/

/*
 *
 *      Fun:   Set Interface Version Handling
 *
 *      Desc:  Processes system agent control request primitive
 *             to set interface version.
 *
 *      Ret:   
 *
 *      Notes: None
 *
 *      File:  mp_mi.c
 *
 */
#ifdef ANSI
PUBLIC Void mgSetVer
(
ShtVerInfo         *setVerInfo,        /* version information to set */
CmStatus           *status             /* status to return */
)
#else
PUBLIC Void mgSetVer(setVerInfo, status)
ShtVerInfo         *setVerInfo;        /* version information to set */
CmStatus           *status;            /* status to return */
#endif
{
   Bool            found;     /* Flag to indicate if found in stored structure */
   U16             i;         /* index */
   U16             j;         /* counter */
   ShtVerInfo      *intfInf;  /* interface version info */
   MgSSAPCb        *ssap;     /* SSAP control block */
   MgTSAPCb        *tsap;     /* TSAP Control Block */
   MgIntVerInfo    *verInfo;           /* Version Information */

   TRC2(mgSetVer)

   found = FALSE;
   /* Validate Set Version Information */
   switch(setVerInfo->intf.intfId)
   {
      case MGTIF:
         if (setVerInfo->intf.intfVer > MGTIFVER)
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;

      case HITIF:
         if (setVerInfo->intf.intfVer > HITIFVER)
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;
   }

   if (status->reason != LCM_REASON_NOT_APPL )
      RETVOID;

#ifdef ZG
   /* See if this is applicable to PSF. If PSF says it is not applicable (RNA)
    * we analyze further.                      
    */
   if(zgSetVer(&setVerInfo->intf, status) != RNA)
      RETVOID;
#endif /* ZG */

   /* validate grptype */
   if ((setVerInfo->grpType != SHT_GRPTYPE_ALL) &&
       (setVerInfo->grpType != SHT_GRPTYPE_ENT))
   {
      status->reason = LCM_REASON_INVALID_PAR_VAL;
      RETVOID;
   }

   /* See if stored information already exists */
   verInfo = &(mgCb.verInfo);

   for(i = 0; i < verInfo->numIntfInfo && found == FALSE; i++)
   {
      intfInf = &(verInfo->intfInfo[i]);

      if (intfInf->intf.intfId == setVerInfo->intf.intfId)
      {
         if (intfInf->grpType == setVerInfo->grpType)
         {
            /* 
             * Stored information found. Replace the information with new 
             * version information specified in this set version request  
             */
            switch(setVerInfo->grpType)
            {
               case SHT_GRPTYPE_ALL:
               {
                  if (intfInf->dstProcId == setVerInfo->dstProcId &&
                      intfInf->dstEnt.ent == setVerInfo->dstEnt.ent &&
                      intfInf->dstEnt.inst == setVerInfo->dstEnt.inst)
                  {
                     intfInf->intf.intfVer = setVerInfo->intf.intfVer;
                     found = TRUE;
                  }
               }
               break;

               case SHT_GRPTYPE_ENT:
               {
                  if (intfInf->dstEnt.ent == setVerInfo->dstEnt.ent &&
                     intfInf->dstEnt.inst == setVerInfo->dstEnt.inst )
                  {
                     intfInf->intf.intfVer = setVerInfo->intf.intfVer;
                     found = TRUE;
                  }
               }
               break;

               default:
                  /* not possible */
                  break;
            }
         }
      }
   }

   /* 
    * In the worst case we should be required to store one version
    * information for every configured sap in the layer.           
    */
   if (found == FALSE)
   {
      if (verInfo->numIntfInfo < (mgCb.genCfg.maxSSaps + 1))
      {
         cmMemcpy ((U8 *)&(verInfo->intfInfo[i]), (U8 *)setVerInfo, 
                   sizeof(ShtVerInfo));
         verInfo->numIntfInfo++;
      }
      else
      {
         status->reason = LCM_REASON_EXCEED_CONF_VAL;
         RETVOID;
      }
   }

   /* Information in set version stored. Now update the SAPs */
   switch (setVerInfo->intf.intfId)
   {
      case MGTIF:
      {
         for (j = 0; j < mgCb.genCfg.maxSSaps; j++)
         {
            ssap = mgCb.sSAPLst[j];
            if (ssap == NULLP)
               continue;

             /* 
              * If it is an unbound SAP then the remote entity, instance 
              * and proc ID would not be available and hence we should  
              * wait for bind to happen to set the remote interface ver  
              */
            if (ssap->state != LMG_SAP_BND_ENB)
               continue;

            /* now match on dstproc/ent/inst */
            found = FALSE;

            switch(setVerInfo->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if(ssap->suPst.dstProcId == setVerInfo->dstProcId &&
                     ssap->suPst.dstEnt == setVerInfo->dstEnt.ent &&
                     ssap->suPst.dstInst == setVerInfo->dstEnt.inst)
                  {
                     found = TRUE;
                  }
                  break;
               case SHT_GRPTYPE_ENT:
                  if(ssap->suPst.dstEnt == setVerInfo->dstEnt.ent &&
                     ssap->suPst.dstInst == setVerInfo->dstEnt.inst)
                  {
                     found = TRUE;
                  }
                  break;
               default:
                  /* not possible */
                  break;
            }

            if (found == TRUE)
            {
               ssap->suPst.intfVer = setVerInfo->intf.intfVer;
               ssap->remIntfValid = TRUE;
            }
         }
      }
      break;
         
      case HITIF:
      {
         if ((mgCb.dnsTsap != MG_INVALID_TSAP_ID) &&
             (mgCb.tSAPLst[mgCb.dnsTsap]) &&
             (mgCb.tSAPLst[mgCb.dnsTsap]->tsapCfg.provType ==
                   LMG_PROV_TYPE_TUCL))
            tsap = mgCb.tSAPLst[mgCb.dnsTsap];

         /* now match on dstproc/ent/inst */
         found = FALSE;
         switch(setVerInfo->grpType)
         {
            case SHT_GRPTYPE_ALL:
               if (tsap->spPst.dstProcId == setVerInfo->dstProcId &&
                     tsap->spPst.dstEnt == setVerInfo->dstEnt.ent &&
                     tsap->spPst.dstInst == setVerInfo->dstEnt.inst)
                  found = TRUE;
               break;

            case SHT_GRPTYPE_ENT:
               if (tsap->spPst.dstEnt == setVerInfo->dstEnt.ent &&
                     tsap->spPst.dstInst == setVerInfo->dstEnt.inst)
                  found = TRUE;
               break;

            default:
               /* not possible */
               break;
         }

         if (found == TRUE)
         {
            tsap->spPst.intfVer = setVerInfo->intf.intfVer;
            tsap->remIntfValid = TRUE;
         }
      }
      break;

      default:
          /* not possible */
         break;
   }

   RETVOID;

} /* End of mgSetVer */

/******************************************************************************/
/*                   Set Cfg Default Value For RUG                            */
/******************************************************************************/

#ifdef GCP_MGCO

/*
*
*       Fun:   mgSetDefMgcoCfgVal
*
*       Desc:  This function is used to fill default configuration values for
*              MEGACO protocol when rolling upgrade is enabled.
*
*       Ret:   None
*
*       Notes:
*
*       File:  mp_mi.c
*
*/
#ifdef ANSI
PRIVATE Void mgSetDefMgcoCfgVal 
(
MgMngmt            *cfg                /* configuration structure */
)
#else
PRIVATE Void mgSetDefMgcoCfgVal(cfg)
MgMngmt            *cfg;               /* configuration structure */
#endif
{
#ifndef ZG
   U16             i;                  /* Temporary variable */
#endif /* ZG */
   MgCfg           *gcpCfg;            /* GCP Configuration */

   TRC2(mgSetDefMgcoCfgVal);

   gcpCfg = &(cfg->t.cfg);

   switch(cfg->hdr.elmId.elmnt)
   {
      case STTSAP:
      {
         gcpCfg->c.tSAPCfg.reCfg.idleTmr.enb = FALSE;
      }
      break;

      case STSSAP:
      {
#ifdef GCP_MG
#ifdef GCP_VER_1_5        
         gcpCfg->c.sSAPCfg.maxMgcoVersion = LMG_VER_PROF_MGCO_H248_2_0;
#else
         gcpCfg->c.sSAPCfg.maxMgcoVersion = LMG_VER_PROF_MGCO_H248_1_0;
#endif
#endif /* GCP_MG */
      }
      break;

#ifndef ZG
      /* 
       * Peer configuration should be done through Control req if ZG 
       * is defined
       */
      case STGCPENT:
      {
         MgGcpEntCfg   *gcpEntCfg = &(gcpCfg->c.mgGcpEntCfg);

         for(i=0; i < gcpEntCfg->numPeer; i++)
         {
            gcpEntCfg->peerCfg[i].mid.pres = PRSNT_NODEF;
            gcpEntCfg->peerCfg[i].mid.len = 
                cmStrlen((U8*)LMGIF_VER1_CFGREQ_DEF_MID);
            cmMemcpy(gcpEntCfg->peerCfg[i].mid.val, 
                (U8 *)LMGIF_VER1_CFGREQ_DEF_MID, gcpEntCfg->peerCfg[i].mid.len);
#ifdef GCP_MG
            gcpEntCfg->peerCfg[i].encodingScheme = LMG_ENCODE_TXT;
            gcpEntCfg->peerCfg[i].mgcPriority = 0; 
            gcpEntCfg->peerCfg[i].useAHScheme = FALSE; 
#endif /* GCP_MG */
         }
      }
      break;

      /* 
       * Server configuration should be done through Control Req if ZG is
       * defined 
       */
      case STSERVER:
      {
         MgTptSrvrCfg   *srvrCfg = &(gcpCfg->c.tptSrvrCfg);

         for (i=0; i < srvrCfg->count; i++)
         {
            srvrCfg->srvr[i].encodingScheme = LMG_ENCODE_TXT;
         }
      }
      break;

#endif /* ZG */

      default:
         break;
   }

   RETVOID;

} /* end of mgSetDefMgcoCfgVal() */

#endif /* GCP_MGCO */


#ifdef GCP_MGCP 

/*
*
*       Fun:   mgSetDefMgcpCfgVal
*
*       Desc:  This function is used to fill default configuration values for
*              MGCP protocol when rolling upgrade is enabled.
*
*       Ret:   None
*
*       Notes:
*
*       File:  mp_mi.c
*
*/
#ifdef ANSI
PRIVATE Void mgSetDefMgcpCfgVal
(
MgMngmt            *cfg                /* configuration structure */
)
#else
PRIVATE Void mgSetDefMgcpCfgVal(cfg)
MgMngmt            *cfg;               /* configuration structure */
#endif
{
#ifndef ZG
   U16             i;                  /* Temporary variable */
#endif /* ZG */
   MgCfg           *gcpCfg;            /* GCP Configuration */

   TRC2(mgSetDefMgcpCfgVal)

   gcpCfg = &(cfg->t.cfg);

   switch(cfg->hdr.elmId.elmnt)
   {
      case STGEN:
      {
         gcpCfg->c.genCfg.timeResTTL = LMGIF_VER1_CFGREQ_DEF_TIMERESTTL;
      }
      break;

      case STTSAP:
      {
         gcpCfg->c.tSAPCfg.reCfg.defDisConThold = 
                        LMGIF_VER1_CFGREQ_DEF_DEFDISCONTHOLD;
         gcpCfg->c.tSAPCfg.reCfg.defSuspThold = 
                        LMGIF_VER1_CFGREQ_DEF_DEFSUSPTHOLD;
      }
      break;

      case STSSAP:
      {
#ifdef GCP_MG
         gcpCfg->c.sSAPCfg.mgcpVersion = LMG_VER_PROF_MGCP_RFC2705_1_0;
#endif /* GCP_MG */

#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
         gcpCfg->c.sSAPCfg.reCfg.txnTmoutTmr.enb = FALSE;
         gcpCfg->c.sSAPCfg.reCfg.txnTmoutTmr.val = 0;
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */
      }
      break;

#ifndef ZG
      /* 
       * Peer configuration should be done through Control req if ZG 
       * is defined
       */
      case STGCPENT:
      {
         MgGcpEntCfg   *gcpEntCfg = &(gcpCfg->c.mgGcpEntCfg);

         for(i=0; i < gcpEntCfg->numPeer; i++)
         {
            gcpEntCfg->peerCfg[i].ttl = LMGIF_VER1_CFGREQ_DEF_TTL;
            gcpEntCfg->peerCfg[i].peerReCfg.disconThold = 
                        LMGIF_VER1_CFGREQ_DEF_DEFDISCONTHOLD;
            gcpEntCfg->peerCfg[i].peerReCfg.suspThold = 
                        LMGIF_VER1_CFGREQ_DEF_DEFSUSPTHOLD;
         }
      }
      break;
#endif /* ZG */

      default:
         break;
   }
   RETVOID;

} /* end of mgSetDefMgcpCfgVal() */

#endif /* GCP_MGCP */


/******************************************************************************/
/*                   Set CntrlReq Default Value For RUG                            */
/******************************************************************************/

#ifdef GCP_MGCO

/*
*
*       Fun:   mgSetDefMgcoCntrlVal
*
*       Desc:  This function is used to fill default control request values for
*              MEGACO protocol when rolling upgrade is enabled.
*
*       Ret:   None
*
*       Notes:
*
*       File:  mp_mi.c
*
*/
#ifdef ANSI
PRIVATE Void mgSetDefMgcoCntrlVal 
(
MgMngmt            *cntrl                /* control structure */
)
#else
PRIVATE Void mgSetDefMgcoCntrlVal(cntrl)
MgMngmt            *cntrl;               /* control structure */
#endif
{
#ifdef ZG
   U16             i;                  /* Temporary variable */
#endif /* ZG */
   MgCntrl         *gcpCntrl;          /* GCP Control structure */

   TRC2(mgSetDefMgcoCntrlVal);

   gcpCntrl = &(cntrl->t.cntrl);

   gcpCntrl->s.peerInfo.mid.pres = NOTPRSNT;
   gcpCntrl->s.trcCntrl.peerInfo.mid.pres = NOTPRSNT;

   switch(cntrl->hdr.elmId.elmnt)
   {
#ifdef ZG
      case STGCPENTCFG:
      {
         MgGcpEntCfg   *gcpEntCfg = &(gcpCntrl->s.mgGcpEntCfg);
         
         for(i=0; i < gcpEntCfg->numPeer; i++)
         {
            gcpEntCfg->peerCfg[i].mid.pres = PRSNT_NODEF;
            gcpEntCfg->peerCfg[i].mid.len = 
                cmStrlen((U8*)LMGIF_VER1_CFGREQ_DEF_MID);
            cmMemcpy(gcpEntCfg->peerCfg[i].mid.val, 
                (U8 *)LMGIF_VER1_CFGREQ_DEF_MID, gcpEntCfg->peerCfg[i].mid.len);
#ifdef GCP_MG
            gcpEntCfg->peerCfg[i].encodingScheme = LMG_ENCODE_TXT;
            gcpEntCfg->peerCfg[i].mgcPriority = 0; 
            gcpEntCfg->peerCfg[i].useAHScheme = FALSE; 
#endif /* GCP_MG */
         }
      }
      break;

      case STGCPSRVRCFG:
      {
         MgTptSrvrCfg   *srvrCfg = &(gcpCntrl->s.tptSrvrCfg);

         for (i=0; i < srvrCfg->count; i++)
         {
            srvrCfg->srvr[i].encodingScheme = LMG_ENCODE_TXT;
         }
      }
      break;

#endif /* ZG */

      default:
      break;
   }


   RETVOID;
} /* end of mgSetDefMgcoCntrlVal() */

#endif /* GCP_MGCO */

#ifdef GCP_MGCP 

/*
*
*       Fun:   mgSetDefMgcpCntrlVal
*
*       Desc:  This function is used to fill default control request values for
*              MGCP protocol when rolling upgrade is enabled.
*
*       Ret:   None
*
*       Notes:
*
*       File:  mp_mi.c
*
*/
#ifdef ANSI
PRIVATE Void mgSetDefMgcpCntrlVal
(
MgMngmt            *cntrl                /* control structure */
)
#else
PRIVATE Void mgSetDefMgcpCntrlVal(cntrl)
MgMngmt            *cntrl;               /* control structure */
#endif
{
#ifdef ZG
   U16             i;                  /* Temporary variable */
#endif /* ZG */
   MgCntrl         *gcpCntrl;          /* GCP Control structure */

   TRC2(mgSetDefMgcpCntrlVal)

   gcpCntrl = &(cntrl->t.cntrl);

   switch(cntrl->hdr.elmId.elmnt)
   {
#ifdef ZG
      case STGCPENTCFG:
      {
         MgGcpEntCfg   *gcpEntCfg = &(gcpCntrl->s.mgGcpEntCfg);
         
         for(i=0; i < gcpEntCfg->numPeer; i++)
         {
            gcpEntCfg->peerCfg[i].ttl = LMGIF_VER1_CFGREQ_DEF_TTL;
            gcpEntCfg->peerCfg[i].peerReCfg.disconThold = 
                        LMGIF_VER1_CFGREQ_DEF_DEFDISCONTHOLD;
            gcpEntCfg->peerCfg[i].peerReCfg.suspThold = 
                        LMGIF_VER1_CFGREQ_DEF_DEFSUSPTHOLD;
         }
      }
      break;
#endif /* ZG */

      default:
      break;
   }

   RETVOID;
} /* end of mgSetDefMgcpCntrlVal() */

#endif /* GCP_MGCP */

#endif /* MG_RUG */


/********************************************************************30**
  
         End of file:     mp_mi.c@@/main/mgcp_rel_1.5_mnt/6 - Tue Jun  7 16:29:44 2005
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rrp  1. initial release
1.2          ---      bbk  1. Fixed C++ compilation warnings
1.2+        mg001.101 bbk  1. Added memory size required for MgIpAddrEnt's
                              in SGetSMem() computation
                           2. DNS Control Block Allocation was being done twice
                              in mgCfgGen and mgCfgTSAP...kept in mgCfgTSAP 
                              now
                           3. Moved mgInitDnsCb() to enabling of TSAP
                           4. cmDnsDeInitDnsCb () was never being called. Now
                              It will be called in TSAP disable/delete
            mg002.101  pk  5. Modified error checking in mgCfgTSap.
                           6. Added argument in MG_ENA_DNS_LSTNR macro 
                              call in function  mgCntrlTsap.
            mg002.101  bbk 1. Added code for supporting UDP PDU Size 
                              limitation.
            mg003.101  bbk 1. numPeersRslvd should be incremented even if
                              name is unknown and IP Address is known
            mg004.101  bbk 1. In SSAP enable, if peers have been configured
                              only with IP Address, still increment 
                              numPeersRslvd
            mg007.101  bbk 1. Added changes to LMG Interface to perform
                              layer management operations on a peer entity
                              by using IP Address only also. Changed have
                              been added under GCP_ENHNC_1_2 compile time
                              flag. Added port configuration for a peer
                           2. Changed data type for peerId from U16 to U32
                           3. Added support for sending multiple status
                              confirms for a SSAP when number of peers is
                              more than LMG_MAX_PEER_ENT
                           4. Changes 1, 2, 3 for mg007.101 have been 
                              added under GCP_ENHNC_1_2 compile time
                              flag.
            mg008.101  bbk 1. Null Terminate domain name only if length is
                              less than CM_DNS_DNAME_LEN
/main/3      ---        pk 1. Added MEGACO related configuration parameters.
                           2. Added server cfg.
                           3. Added additional control requests.
                           4. Reorganized code.
            mg006.102   vj 1. Modified mgCntrlGen so that debugMask is "anded".
            mg007.102   vj 1. Modify the enable/disable debug mask functionality
                           2. Modify the mgGetPeerSta() to reflect the changes 
                              made in MgPeerSta structure in lmg.x. Copy domain 
                              name only if the domain name is present. 
                           3. Provide the LMG define as version number, instead 
                              of negotiated number in mgGetPeerSta.
            mg008.102   vj 1. In mgEnableSsap, do not increment mgCb.curNumPeer 
                              as this is incremented when the peerCb is 
                              allocated. 
                           2. Add the missing break statement in mgCntrlMG 
                              function
            mg009.102   vj 1. During MG server configuration, make sure 
                              that the server is made a default server, if 
                              "isDefault" flag is enabled. Make these changes 
                              in MGCP as well as MEGACO paths.
            mg011.102   vj 1. Invoked MG_INIT_MID wherever the mid needs to be 
                              filled.
                           2. Since the macros MG_ISSUE_PEER_STAIND and 
                              MG_COPY_PEERINFO_INTO_TXN have been broken into 
                              MGCP & MGCO specific macros, converted the calls 
                              to each specific macro. Further, used these macros
                              everywhere for consistency, whereever they were 
                              not being used.
/main/4      ---       ra  1. GCP 1.3 release
            mg014.103  ra  1. Initialized some variables.
/main/5      ---       ka  1. Changes for Release v 1.4
            mg005.104  pk  1. Changed index for tsap in mgZgShutdown.
            mg006.104  pk  1. PSF related changes.
                           2. Changed comment header pavitra with patch name. 
            mg007.104  ra  1. Fixed problems in the macro
                              MG_REM_ALLOC_SRVR_MEM.
                           2. In the control request for deleting TSAP,
                              re-initializing the corresponding tsap CB in the
                              list of tsaps in mgCb to NULLP.
            mg008.104  ra  1. Replaced some macros with the following ones -
                              MG_RESET_SSAP_PEERS_FOR_THIS_TSAP
                              MG_REM_SSAP_PEERS_FOR_THIS_TSAP
                              Also replaced a function call with the new one -
                              mgRemSsapSrvrsForThisTsap()
                              These work on the tsap specified in the arguments.
            mg009.104  ra  1. The control request to unbind disable and bind
                              enable TSAPs can come from LM instead of SH.
                              Added missing code to handle that.
/main/6      ---      pk   1. GCP 1.5 release
            mg001.105 ra   1. TOS related changes.

           mg002.105  ra  1. zgAddMapping() should be called only once
                              when the TSAP is configured for the first
                              time.
                          2. rspAckEnb in genCfg is now a reconfigurable
                              parameter.
                          3. Changes for TCR 21
                          4. Removed patch reference for 1.3 and 1.4
                          5. Remove compilation warnings 
                          6. Changes for Command Handler
           mg003.105  ps  1. Changes for MG/MGC default Pending Limit 
                      dp  2. Bug fix 
           mg004.105  gk  1. Changed prototype from MgTptCntrl to CmTptAddr 
                          2. Initialize restart end timer 
                          3. Added check on ssaps in peerCfg 
                          4. Server Reconfig is not allowed. Even if we get
                             a cfg req for a already existing server we should
                             just ignore it
                          5. Added a new check : If SAp is already bound and
                             another enable is received, ignore it and not
                             return error
                          6. BugFix: Service change
                          7. BugFix: TCR21: If tptServer is not present then
                             delete operation is always successful.
           mg005.105  gk   1. zgRtUpd is already calling in mgDeleteTsap
           mg007.105  gk   1. Added DeAllocation of memeory checks
           mg008.105  gk   1. tSAPId must be less than mgCb.genCfg.maxTSaps
*********************************************************************91*/
