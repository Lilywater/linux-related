/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Megaco package RegExp file

     Type:     C source file

     Desc:     Regular expressions for Megaco basic packages

     File:     mgco_prx.c

     Sid:      mgco_prx.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:52:09 2005

     Prg:      nct

*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_mblk.h"       /* common event memory management */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_inet.h"       /* Inet header file */
#include "cm_tpt.h"        /* Transport  header file */
#include "cm_sdp.h"
#include "cm_dns.h"
#include "mgcopdb1.h"
#ifdef GCP_MGCO
#ifdef GCP_VER_1_3
#include "mgcopdb2.h"      /* [TEL]: Hash defines for megaco packages */
#include "mgcopdb3.h"      /* [TEL2]: Hash defines for megaco packages */
#endif /* GCP_VER_1_3 */
#endif /* GCP_MGCO */
#ifdef ZG
#include "cm_ftha.h"
#include "cm_psfft.h"
#endif /* ZG */
#include "mgt.h"

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_lib.x"        /* common library file */
#include "cm_inet.x"       /* Inet header file */
#include "cm_tpt.x"        /* Transport  header file */
#include "cm_sdp.x"
#include "mgcopdb1.x"
#ifdef GCP_MGCO
#ifdef GCP_VER_1_3
#include "mgcopdb2.x"      /* [TEL]: Extern declarations for megaco packages */
#include "mgcopdb3.x"      /* [TEL2]: Extern declarations for megaco packages */
#endif /* GCP_VER_1_3 */
#endif /* GCP_MGCO */
#ifdef ZG
#include "cm_ftha.x"
#include "cm_psfft.x"
#endif /* ZG */
#include "mgt.x"
#include "mgco_db.x"

#ifdef GCP_MGCO

#ifdef GCP_PKG_MGCO_ANALOG
/*
*
*       Fun:   mgMgcoRegExpEvtNameAnalog
*
*       Desc:  Description for the regular expression EvtNameAnalog
*                [Oo][Nn]     {return(MGT_PKG_ANALOG_EVT_ON);}
*                [Oo][Ff]     {return(MGT_PKG_ANALOG_EVT_OF);}
*                [Ff][Ll]     {return(MGT_PKG_ANALOG_EVT_FL);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtNameAnalog
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtNameAnalog(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtNameAnalog)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy4;
   case 'O':   case 'o':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy7;
   case 'N':   case 'n':   goto yy9;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ANALOG_EVT_FL;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ANALOG_EVT_OF;
      goto yyReturn;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ANALOG_EVT_ON;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtNameAnalog */
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_CONT
/*
*
*       Fun:   mgMgcoRegExpEvtNameCont
*
*       Desc:  Description for the regular expression EvtNameCont
*                [Cc][Mm][Pp] {return(MGT_PKG_CONT_EVT_CMP);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtNameCont
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtNameCont(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtNameCont)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_CONT_EVT_CMP;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtNameCont */
#endif /* GCP_PKG_MGCO_CONT */

#ifdef GCP_PKG_MGCO_CPDET
/*
*
*       Fun:   mgMgcoRegExpEvtNameCpDet
*
*       Desc:  Description for the regular expression EvtNameCpDet
*                std    =  [Ss][Tt][Dd];
*                etd    =  [Ee][Tt][Dd];
*                ltd    =  [Ll][Tt][Dd];
*              
*                [Dd]"0"         {return(MGT_PKG_TONEID_D0);}
*                [Dd]"1"         {return(MGT_PKG_TONEID_D1);}
*                [Dd]"2"         {return(MGT_PKG_TONEID_D2);}
*                [Dd]"3"         {return(MGT_PKG_TONEID_D3);}
*                [Dd]"4"         {return(MGT_PKG_TONEID_D4);}
*                [Dd]"5"         {return(MGT_PKG_TONEID_D5);}
*                [Dd]"6"         {return(MGT_PKG_TONEID_D6);}
*                [Dd]"7"         {return(MGT_PKG_TONEID_D7);}
*                [Dd]"8"         {return(MGT_PKG_TONEID_D8);}
*                [Dd]"9"         {return(MGT_PKG_TONEID_D9);}
*                [Dd][Aa]        {return(MGT_PKG_TONEID_DA);}
*                [Dd][Bb]        {return(MGT_PKG_TONEID_DB);}
*                [Dd][Cc]        {return(MGT_PKG_TONEID_DC);}
*                [Dd][Dd]        {return(MGT_PKG_TONEID_DD);}
*                [Dd][Ss]        {return(MGT_PKG_TONEID_DS);}
*                [Dd][Oo]        {return(MGT_PKG_TONEID_DO);}
*                [Dd][Tt]        {return(MGT_PKG_TONEID_DT);}
*                [Rr][Tt]        {return(MGT_PKG_TONEID_RT);}
*                [Bb][Tt]        {return(MGT_PKG_TONEID_BT);}
*                [Cc][Tt]        {return(MGT_PKG_TONEID_CT);}
*                [Ss][Ii][Tt]    {return(MGT_PKG_TONEID_SIT);}
*                [Ww][Tt]        {return(MGT_PKG_TONEID_WT);}
*                [Pp][Rr][Tt]    {return(MGT_PKG_TONEID_PT);}
*                [Cc][Ww]        {return(MGT_PKG_TONEID_CW);}
*                [Cc][Rr]        {return(MGT_PKG_TONEID_CR);}
*              
*                std       {return(MGT_PKG_TONEDET_EVT_STD);}
*                etd       {return(MGT_PKG_TONEDET_EVT_ETD);}
*                ltd       {return(MGT_PKG_TONEDET_EVT_LTD);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtNameCpDet
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtNameCpDet(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtNameCpDet)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy5;
   case 'C':   case 'c':   goto yy6;
   case 'D':   case 'd':   goto yy3;
   case 'E':   case 'e':   goto yy10;
   case 'L':   case 'l':   goto yy11;
   case 'P':   case 'p':   goto yy9;
   case 'R':   case 'r':   goto yy4;
   case 'S':   case 's':   goto yy7;
   case 'W':   case 'w':   goto yy8;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy71;
   case '1':   goto yy69;
   case '2':   goto yy67;
   case '3':   goto yy65;
   case '4':   goto yy63;
   case '5':   goto yy61;
   case '6':   goto yy59;
   case '7':   goto yy57;
   case '8':   goto yy55;
   case '9':   goto yy53;
   case 'A':   case 'a':   goto yy51;
   case 'B':   case 'b':   goto yy49;
   case 'C':   case 'c':   goto yy47;
   case 'D':   case 'd':   goto yy45;
   case 'O':   case 'o':   goto yy41;
   case 'S':   case 's':   goto yy43;
   case 'T':   case 't':   goto yy39;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy37;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy35;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy29;
   case 'T':   case 't':   goto yy33;
   case 'W':   case 'w':   goto yy31;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy24;
   case 'T':   case 't':   goto yy23;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy21;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy18;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy15;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEDET_EVT_LTD;
      goto yyReturn;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEDET_EVT_ETD;
      goto yyReturn;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy19;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_PT;
      goto yyReturn;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_WT;
      goto yyReturn;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy27;
   default:   goto yyErr;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy25;
   default:   goto yyErr;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_SIT;
      goto yyReturn;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEDET_EVT_STD;
      goto yyReturn;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_CR;
      goto yyReturn;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_CW;
      goto yyReturn;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_CT;
      goto yyReturn;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_BT;
      goto yyReturn;
   }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_RT;
      goto yyReturn;
   }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DT;
      goto yyReturn;
   }
yy41:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DO;
      goto yyReturn;
   }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DS;
      goto yyReturn;
   }
yy45:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DD;
      goto yyReturn;
   }
yy47:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DC;
      goto yyReturn;
   }
yy49:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DB;
      goto yyReturn;
   }
yy51:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DA;
      goto yyReturn;
   }
yy53:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D9;
      goto yyReturn;
   }
yy55:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D8;
      goto yyReturn;
   }
yy57:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D7;
      goto yyReturn;
   }
yy59:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D6;
      goto yyReturn;
   }
yy61:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D5;
      goto yyReturn;
   }
yy63:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D4;
      goto yyReturn;
   }
yy65:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D3;
      goto yyReturn;
   }
yy67:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D2;
      goto yyReturn;
   }
yy69:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D1;
      goto yyReturn;
   }
yy71:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D0;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtNameCpDet */
#endif /* GCP_PKG_MGCO_CPDET */

#ifdef GCP_PKG_MGCO_DTMFDET
/*
*
*       Fun:   mgMgcoRegExpEvtNameDtmfDet
*
*       Desc:  Description for the regular expression EvtNameDtmfDet
*                std    =  [Ss][Tt][Dd];
*                etd    =  [Ee][Tt][Dd];
*                ltd    =  [Ll][Tt][Dd];
*                ce     =  [Cc][Ee];
*              
*                std       {return(MGT_PKG_TONEDET_EVT_STD);}
*                etd       {return(MGT_PKG_TONEDET_EVT_ETD);}
*                ltd       {return(MGT_PKG_TONEDET_EVT_LTD);}
*                ce         {return(MGT_PKG_DTMFDET_EVT_CE);}
*                [Dd]"0"         {return(MGT_PKG_TONEID_D0);}
*                [Dd]"1"         {return(MGT_PKG_TONEID_D1);}
*                [Dd]"2"         {return(MGT_PKG_TONEID_D2);}
*                [Dd]"3"         {return(MGT_PKG_TONEID_D3);}
*                [Dd]"4"         {return(MGT_PKG_TONEID_D4);}
*                [Dd]"5"         {return(MGT_PKG_TONEID_D5);}
*                [Dd]"6"         {return(MGT_PKG_TONEID_D6);}
*                [Dd]"7"         {return(MGT_PKG_TONEID_D7);}
*                [Dd]"8"         {return(MGT_PKG_TONEID_D8);}
*                [Dd]"9"         {return(MGT_PKG_TONEID_D9);}
*                [Dd][Aa]        {return(MGT_PKG_TONEID_DA);}
*                [Dd][Bb]        {return(MGT_PKG_TONEID_DB);}
*                [Dd][Cc]        {return(MGT_PKG_TONEID_DC);}
*                [Dd][Dd]        {return(MGT_PKG_TONEID_DD);}
*                [Dd][Ss]        {return(MGT_PKG_TONEID_DS);}
*                [Dd][Oo]        {return(MGT_PKG_TONEID_DO);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtNameDtmfDet
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtNameDtmfDet(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtNameDtmfDet)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy6;
   case 'D':   case 'd':   goto yy7;
   case 'E':   case 'e':   goto yy4;
   case 'L':   case 'l':   goto yy5;
   case 'S':   case 's':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy48;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy45;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy42;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy40;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy38;
   case '1':   goto yy36;
   case '2':   goto yy34;
   case '3':   goto yy32;
   case '4':   goto yy30;
   case '5':   goto yy28;
   case '6':   goto yy26;
   case '7':   goto yy24;
   case '8':   goto yy22;
   case '9':   goto yy20;
   case 'A':   case 'a':   goto yy18;
   case 'B':   case 'b':   goto yy16;
   case 'C':   case 'c':   goto yy14;
   case 'D':   case 'd':   goto yy12;
   case 'O':   case 'o':   goto yy8;
   case 'S':   case 's':   goto yy10;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DO;
      goto yyReturn;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DS;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DD;
      goto yyReturn;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DC;
      goto yyReturn;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DB;
      goto yyReturn;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DA;
      goto yyReturn;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D9;
      goto yyReturn;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D8;
      goto yyReturn;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D7;
      goto yyReturn;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D6;
      goto yyReturn;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D5;
      goto yyReturn;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D4;
      goto yyReturn;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D3;
      goto yyReturn;
   }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D2;
      goto yyReturn;
   }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D1;
      goto yyReturn;
   }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D0;
      goto yyReturn;
   }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_DTMFDET_EVT_CE;
      goto yyReturn;
   }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy43;
   default:   goto yyErr;
   }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEDET_EVT_LTD;
      goto yyReturn;
   }
yy45:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy46;
   default:   goto yyErr;
   }
yy46:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEDET_EVT_ETD;
      goto yyReturn;
   }
yy48:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy49;
   default:   goto yyErr;
   }
yy49:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEDET_EVT_STD;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtNameDtmfDet */
#endif /* GCP_PKG_MGCO_DTMFDET */

#ifdef GCP_PKG_MGCO_GENERIC 
/*
*
*       Fun:   mgMgcoRegExpEvtNameGeneric
*
*       Desc:  Description for the regular expression EvtNameGeneric
*                [Cc][Aa][Uu][Ss][Ee]  {return(MGT_PKG_GENERIC_EVT_CAUSE);}
*                [Ss][Cc]              {return(MGT_PKG_GENERIC_EVT_SIG_COMPL);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtNameGeneric
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtNameGeneric(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtNameGeneric)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy3;
   case 'S':   case 's':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy7;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_SIG_COMPL;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_CAUSE;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtNameGeneric */
#endif /* GCP_PKG_MGCO_GENERIC */

#if (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) || \
     defined(GCP_PKG_MGCO_TDMC))
/*
*
*       Fun:   mgMgcoRegExpEvtNameNetwork
*
*       Desc:  Description for the regular expression EvtNameNetwork
*                netfail   = [Nn][Ee][Tt][Ff][Aa][Ii][Ll];
*                qualert   = [Qq][Uu][Aa][Ll][Ee][Rr][Tt];
*              
*                netfail   {return(MGT_PKG_NETWORK_EVT_NETFAIL);}
*                qualert   {return(MGT_PKG_NETWORK_EVT_QUALERT);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtNameNetwork
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtNameNetwork(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtNameNetwork)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy3;
   case 'Q':   case 'q':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy12;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_EVT_QUALERT;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_EVT_NETFAIL;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtNameNetwork */
#endif /* (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) ||
     defined(GCP_PKG_MGCO_TDMC)) */

#ifdef GCP_PKG_MGCO_RTP
/*
*
*       Fun:   mgMgcoRegExpEvtNameRtp
*
*       Desc:  Description for the regular expression EvtNameRtp
*                netfail   = [Nn][Ee][Tt][Ff][Aa][Ii][Ll];
*                qualert   = [Qq][Uu][Aa][Ll][Ee][Rr][Tt];
*                pltrans   = [Pp][Ll][Tt][Rr][Aa][Nn][Ss];
*              
*                netfail   {return(MGT_PKG_NETWORK_EVT_NETFAIL);}
*                qualert   {return(MGT_PKG_NETWORK_EVT_QUALERT);}
*                pltrans   {return(MGT_PKG_RTP_EVT_PLTRANS);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtNameRtp
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtNameRtp(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtNameRtp)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy3;
   case 'P':   case 'p':   goto yy5;
   case 'Q':   case 'q':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy20;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy13;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_RTP_EVT_PLTRANS;
      goto yyReturn;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_EVT_QUALERT;
      goto yyReturn;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy21;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy22;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy24;
   default:   goto yyErr;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy25;
   default:   goto yyErr;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_EVT_NETFAIL;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtNameRtp */
#endif /* GCP_PKG_MGCO_RTP */

#if (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) || \
     defined(GCP_PKG_MGCO_CPDET))
/*
*
*       Fun:   mgMgcoRegExpEvtNameToneDet
*
*       Desc:  Description for the regular expression EvtNameToneDet
*                std    =  [Ss][Tt][Dd];
*                etd    =  [Ee][Tt][Dd];
*                ltd    =  [Ll][Tt][Dd];
*              
*                std       {return(MGT_PKG_TONEDET_EVT_STD);}
*                etd       {return(MGT_PKG_TONEDET_EVT_ETD);}
*                ltd       {return(MGT_PKG_TONEDET_EVT_LTD);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtNameToneDet
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtNameToneDet(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtNameToneDet)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy4;
   case 'L':   case 'l':   goto yy5;
   case 'S':   case 's':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy12;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy9;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEDET_EVT_LTD;
      goto yyReturn;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEDET_EVT_ETD;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEDET_EVT_STD;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtNameToneDet */
#endif /* (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) ||
     defined(GCP_PKG_MGCO_CPDET)) */

#ifdef GCP_PKG_MGCO_GENERIC
/*
*
*       Fun:   mgMgcoRegExpEvtOtherGenericCauseFailureValue
*
*       Desc:  Description for the regular expression EvtOtherGenericCauseFailureValue
*               SP               = [ ];
*               HTAB             = [\t];
*               WSP              = ( SP | HTAB );
*               DIGIT            = [0-9];
*               ALPHA            = [A-Za-z];
*               OthSafeChar      = [-+&!_/'?@^`~*$\\()%|.];
*               SafeChar         = ( DIGIT | ALPHA | OthSafeChar );
*               RestChar         = [;[\]{}:,#<>=];
*               DQUOTE           = "\"";
*              
*               quotedString     = DQUOTE (SafeChar | RestChar | WSP)* DQUOTE;
*               VALUE            = quotedString | (SafeChar (SafeChar)*);
*              
*               VALUE            {return(1);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtOtherGenericCauseFailureValue
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtOtherGenericCauseFailureValue(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtOtherGenericCauseFailureValue)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '!':   case '$':
   case '%':
   case '&':
   case '\'':
   case '(':
   case ')':
   case '*':
   case '+':   case '-':
   case '.':
   case '/':
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case '?':
   case '@':
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case '\\':   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   case '|':   case '~':   goto yy5;
   case '"':   goto yy3;
   default:   goto yyErr;
   }
yy3:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':   case ' ':
   case '!':   case '#':
   case '$':
   case '%':
   case '&':
   case '\'':
   case '(':
   case ')':
   case '*':
   case '+':
   case ',':
   case '-':
   case '.':
   case '/':
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':
   case ':':
   case ';':
   case '<':
   case '=':
   case '>':
   case '?':
   case '@':
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':
   case '\\':
   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':
   case '{':
   case '|':
   case '}':
   case '~':   goto yy3;
   case '"':   goto yy8;
   default:   goto yyErr;
   }
yy5:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '!':   case '$':
   case '%':
   case '&':
   case '\'':
   case '(':
   case ')':
   case '*':
   case '+':   case '-':
   case '.':
   case '/':
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case '?':
   case '@':
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case '\\':   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   case '|':   case '~':   goto yy5;
   default:   goto yy7;
   }
yy7:
   {
      yyret = 1;
      goto yyReturn;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   goto yy7;



yyReturn:
   CM_ABNF_DEC_CSPSTRXL(decCp, mem, len, yydecode);

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtOtherGenericCauseFailureValue */
#endif /* GCP_PKG_MGCO_GENERIC */

#ifdef GCP_PKG_MGCO_GENERIC
/*
*
*       Fun:   mgMgcoRegExpEvtOtherGenericCauseGeneralValue
*
*       Desc:  Description for the regular expression EvtOtherGenericCauseGeneralValue
*                [Nn][Rr]        {return(MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_NR);}
*                [Uu][Rr]        {return(MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_UR);}
*                [Ff][Tt]        {return(MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_FT);}
*                [Ff][Pp]        {return(MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_FP);}
*                [Ii][Ww]        {return(MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_IW);}
*                [Uu][Nn]        {return(MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_UN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtOtherGenericCauseGeneralValue
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtOtherGenericCauseGeneralValue(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtOtherGenericCauseGeneralValue)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy5;
   case 'I':   case 'i':   goto yy6;
   case 'N':   case 'n':   goto yy3;
   case 'U':   case 'u':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy17;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy13;
   case 'R':   case 'r':   goto yy15;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy9;
   case 'T':   case 't':   goto yy11;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_IW;
      goto yyReturn;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_FP;
      goto yyReturn;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_FT;
      goto yyReturn;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_UN;
      goto yyReturn;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_UR;
      goto yyReturn;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_CAUSE_GENERAL_NR;
      goto yyReturn;
   }





yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtOtherGenericCauseGeneralValue */
#endif /* GCP_PKG_MGCO_GENERIC */

#ifdef GCP_PKG_MGCO_GENERIC 
/*
*
*       Fun:   mgMgcoRegExpEvtOtherGenericCausePar
*
*       Desc:  Description for the regular expression EvtOtherGenericCausePar
*                general = [Gg][Ee][Nn][Ee][Rr][Aa][Ll][Cc][Aa][Uu][Ss][Ee];
*                failure = [Ff][Aa][Ii][Ll][Uu][Rr][Ee][Cc][Aa][Uu][Ss][Ee];
*              
*                general   {return(MGT_PKG_GENERIC_EVT_CAUSE_GENERAL);}
*                failure   {return(MGT_PKG_GENERIC_EVT_CAUSE_FAILURE);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtOtherGenericCausePar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtOtherGenericCausePar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtOtherGenericCausePar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy4;
   case 'G':   case 'g':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy17;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_CAUSE_FAILURE;
      goto yyReturn;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy19;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy20;
   default:   goto yyErr;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy21;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy22;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy24;
   default:   goto yyErr;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy25;
   default:   goto yyErr;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy26;
   default:   goto yyErr;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy27;
   default:   goto yyErr;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_CAUSE_GENERAL;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtOtherGenericCausePar */
#endif /* GCP_PKG_MGCO_GENERIC */

#ifdef GCP_PKG_MGCO_GENERIC 
/*
*
*       Fun:   mgMgcoRegExpEvtOtherGenericCauseType
*
*       Desc:  Description for the regular expression EvtOtherGenericCauseType
*                general = [Gg][Ee][Nn][Ee][Rr][Aa][Ll][Cc][Aa][Uu][Ss][Ee];
*                failure = [Ff][Aa][Ii][Ll][Uu][Rr][Ee][Cc][Aa][Uu][Ss][Ee];
*              
*                known     = general | failure;
*                all       = "*";
*                unkStart  = [A-Za-z0-9];
*              
*                known     {return(MGT_GEN_TYPE_KNOWN);}
*                all       {return(MGT_GEN_TYPE_ALL);}
*                unkStart  {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtOtherGenericCauseType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtOtherGenericCauseType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   S16 yyaccept = -1;

   TRC2(mgMgcoRegExpEvtOtherGenericCauseType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy6;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'F':   case 'f':   goto yy5;
   case 'G':   case 'g':   goto yy3;
   default:   goto yyErr;
   }
yy3:   yyaccept = 0;
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy21;
   default:   goto yy4;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:   yyaccept = 0;
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy9;
   default:   goto yy4;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   goto yy4;
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy19;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy22;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy24;
   default:   goto yyErr;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy25;
   default:   goto yyErr;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy26;
   default:   goto yyErr;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy27;
   default:   goto yyErr;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy28;
   default:   goto yyErr;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy29;
   default:   goto yyErr;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy30;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy19;
   default:   goto yyErr;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtOtherGenericCauseType */
#endif /* GCP_PKG_MGCO_GENERIC */

#ifdef GCP_PKG_MGCO_GENERIC 

/*
*
*       Fun:   mgMgcoRegExpEvtOtherGenericSigComplPar
*
*       Desc:  Description for the regular expression EvtOtherGenericSigComplPar
*                [Ss][Ii][Gg][Ii][Dd]  {return(MGT_PKG_GENERIC_EVT_SIG_COMPL_SIGID);}
*                [Mm][Ee][Tt][Hh]      {return(MGT_PKG_GENERIC_EVT_SIG_COMPL_METH);}
*                [Ss][Ll][Ii][Dd]      {return(MGT_PKG_GENERIC_EVT_SIG_COMPL_SIGLSTID);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtOtherGenericSigComplPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtOtherGenericSigComplPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtOtherGenericSigComplPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy4;
   case 'S':   case 's':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy10;
   case 'L':   case 'l':   goto yy9;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_SIG_COMPL_METH;
      goto yyReturn;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy15;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_SIG_COMPL_SIGID;
      goto yyReturn;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_SIG_COMPL_SIGLSTID;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtOtherGenericSigComplPar */
#endif /* GCP_PKG_MGCO_GENERIC */

#ifdef GCP_PKG_MGCO_GENERIC 
/*
*
*       Fun:   mgMgcoRegExpEvtOtherGenericSigComplTermMethValue
*
*       Desc:  Description for the regular expression EvtOtherGenericSigComplTermMethValue
*                [Tt][Oo]     {return(MGT_PKG_GENERIC_EVT_SIG_COMPL_METH_TO);}
*                [Ee][Vv]     {return(MGT_PKG_GENERIC_EVT_SIG_COMPL_METH_EV);}
*                [Ss][Dd]     {return(MGT_PKG_GENERIC_EVT_SIG_COMPL_METH_SD);}
*                [Nn][Cc]     {return(MGT_PKG_GENERIC_EVT_SIG_COMPL_METH_NC);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtOtherGenericSigComplTermMethValue
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtOtherGenericSigComplTermMethValue(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpEvtOtherGenericSigComplTermMethValue)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy4;
   case 'N':   case 'n':   goto yy6;
   case 'S':   case 's':   goto yy5;
   case 'T':   case 't':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy13;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy11;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy9;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_SIG_COMPL_METH_NC;
      goto yyReturn;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_SIG_COMPL_METH_SD;
      goto yyReturn;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_SIG_COMPL_METH_EV;
      goto yyReturn;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_GENERIC_EVT_SIG_COMPL_METH_TO;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtOtherGenericSigComplTermMethValue */
#endif /* GCP_PKG_MGCO_GENERIC */

/* Regenerated to fix a bug */
#ifdef GCP_PKG_MGCO_GENERIC 
/*
*
*       Fun:   mgMgcoRegExpEvtOtherGenericSigComplType
*
*       Desc:  Description for the regular expression EvtOtherGenericSigComplType
*              
*                   known = ([Ss][Ii][Gg][Ii][Dd] | [Mm][Ee][Tt][Hh] | [Ss][Ll][Ii][Dd]);
*                   all   = "*";
*                   unk   = [A-Za-z0-9]+;
*                 
*                   all    {return(MGT_GEN_TYPE_ALL);}
*                   known  {return(MGT_GEN_TYPE_KNOWN);}
*                   unk    {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpEvtOtherGenericSigComplType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpEvtOtherGenericSigComplType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMgcoRegExpEvtOtherGenericSigComplType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'M':   case 'm':   goto yy7;
   case 'S':   case 's':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy14;
   case 'L':   case 'l':   goto yy15;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy10;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy11;
   default:   goto yy9;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy12;
   default:   goto yy9;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy13;
   }
yy13:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy17;
   default:   goto yy9;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy16;
   default:   goto yy9;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy12;
   default:   goto yy9;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy18;
   default:   goto yy9;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy12;
   default:   goto yy9;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpEvtOtherGenericSigComplType */
#endif /* GCP_PKG_MGCO_GENERIC */

#ifdef GCP_PKG_MGCO_ANALOG
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherAnalogOnHookPar
*
*       Desc:  Description for the regular expression ObsEvtOtherAnalogOnHookPar
*                init   =  [Ii][Nn][Ii][Tt];
*              
*                init   {return(MGT_PKG_ANALOG_EVT_ONHOOK_INIT);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherAnalogOnHookPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherAnalogOnHookPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherAnalogOnHookPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ANALOG_EVT_ONHOOK_INIT;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherAnalogOnHookPar */
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_ANALOG
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherAnalogOnHookType
*
*       Desc:  Description for the regular expression ObsEvtOtherAnalogOnHookType
*                known  =  [Ii][Nn][Ii][Tt];
*                all    =  "*";
*                unkn   =  [A-Za-z0-9]+;
*              
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                all    {return(MGT_GEN_TYPE_ALL);}
*                unkn   {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherAnalogOnHookType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherAnalogOnHookType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherAnalogOnHookType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy5;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'I':   case 'i':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy9;
   default:   goto yy8;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy4;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy10;
   default:   goto yy8;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy11;
   default:   goto yy8;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy12;
   }
yy12:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherAnalogOnHookType */
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_CONT
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherContCmpPar
*
*       Desc:  Description for the regular expression ObsEvtOtherContCmpPar
*                res = [Rr][Ee][Ss];
*              
*                res    {return(MGT_PKG_CONT_EVT_CMP_RES);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherContCmpPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherContCmpPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherContCmpPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_CONT_EVT_CMP_RES;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherContCmpPar */
#endif /* GCP_PKG_MGCO_CONT */

#ifdef GCP_PKG_MGCO_CONT
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherContCmpResValue
*
*       Desc:  Description for the regular expression ObsEvtOtherContCmpResValue
*                failure   =  [Ff][Aa][Ii][Ll][Uu][Rr][Ee];
*                success   =  [Ss][Uu][Cc][Cc][Ee][Ss][Ss];
*              
*                failure   {return(MGT_PKG_CONT_EVT_CMP_RES_FAILURE);}
*                success   {return(MGT_PKG_CONT_EVT_CMP_RES_SUCCESS);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherContCmpResValue
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherContCmpResValue(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherContCmpResValue)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy3;
   case 'S':   case 's':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy12;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_CONT_EVT_CMP_RES_SUCCESS;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_CONT_EVT_CMP_RES_FAILURE;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherContCmpResValue */
#endif /* GCP_PKG_MGCO_CONT */

#ifdef GCP_PKG_MGCO_CONT
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherContCmpType
*
*       Desc:  Description for the regular expression ObsEvtOtherContCmpType
*                res = [Rr][Ee][Ss];
*                all = "*";
*                unk = [A-Za-z0-9]+;
*              
*                res    {return(MGT_GEN_TYPE_KNOWN);}
*                all    {return(MGT_GEN_TYPE_ALL);}
*                unk    {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherContCmpType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherContCmpType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherContCmpType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy5;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'R':   case 'r':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy9;
   default:   goto yy8;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy4;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy10;
   default:   goto yy8;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy11;
   }
yy11:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherContCmpType */
#endif /* GCP_PKG_MGCO_CONT */

#ifdef GCP_PKG_MGCO_DTMFDET
/* Regular expression 
 * mgMgcoRegExpObsEvtOtherDtmfDetCeDigitStringValue is changed */

/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherDtmfDetCeDigitStringValue
*
*       Desc:  Description for the regular expression ObsEvtOtherDtmfDetCeDigitStringValue
*                 dsChar     = [0-9a-fA-FLl];
*                 ds         = ["](dsChar)*["]|(dsChar)+;
*                 ds           {return(1);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {mgco_prx.c}
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherDtmfDetCeDigitStringValue
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherDtmfDetCeDigitStringValue(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMgcoRegExpObsEvtOtherDtmfDetCeDigitStringValue)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '"':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':   case 'L':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':   case 'l':   goto yy5;
   default:   goto yyErr;
   }
yy3:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '"':   goto yy8;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':   case 'L':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':   case 'l':   goto yy3;
   default:   goto yyErr;
   }
yy5:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':   case 'L':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':   case 'l':   goto yy5;
   default:   goto yy7;
   }
yy7:
   {
      yyret = 1;
      goto yyReturn;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   goto yy7;



yyReturn:
   CM_ABNF_DEC_CSPSTRXL(decCp, mem, len, yydecode);

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherDtmfDetCeDigitStringValue */
#endif /* GCP_PKG_MGCO_DTMFDET */

#ifdef GCP_PKG_MGCO_DTMFDET
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherDtmfDetCePar
*
*       Desc:  Description for the regular expression ObsEvtOtherDtmfDetCePar
*                [Dd][Ss]           {return(MGT_PKG_DTMFDET_EVT_CE_DS);}
*                [Mm][Ee][Tt][Hh]   {return(MGT_PKG_DTMFDET_EVT_CE_METH);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherDtmfDetCePar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherDtmfDetCePar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherDtmfDetCePar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy3;
   case 'M':   case 'm':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy9;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_DTMFDET_EVT_CE_METH;
      goto yyReturn;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_DTMFDET_EVT_CE_DS;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherDtmfDetCePar */
#endif /* GCP_PKG_MGCO_DTMFDET */

#ifdef GCP_PKG_MGCO_DTMFDET
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherDtmfDetCeTermMethValue
*
*       Desc:  Description for the regular expression ObsEvtOtherDtmfDetCeTermMethValue
*                [Uu][Mm]  {return(MGT_PKG_DTMFDET_EVT_CE_METH_UM);}
*                [Pp][Mm]  {return(MGT_PKG_DTMFDET_EVT_CE_METH_PM);}
*                [Ff][Mm]  {return(MGT_PKG_DTMFDET_EVT_CE_METH_FM);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherDtmfDetCeTermMethValue
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherDtmfDetCeTermMethValue(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherDtmfDetCeTermMethValue)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy5;
   case 'P':   case 'p':   goto yy4;
   case 'U':   case 'u':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy10;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy8;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_DTMFDET_EVT_CE_METH_FM;
      goto yyReturn;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_DTMFDET_EVT_CE_METH_PM;
      goto yyReturn;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_DTMFDET_EVT_CE_METH_UM;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherDtmfDetCeTermMethValue */
#endif /* GCP_PKG_MGCO_DTMFDET */

#ifdef GCP_PKG_MGCO_DTMFDET

/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherDtmfDetCeType
*
*       Desc:  Description for the regular expression ObsEvtOtherDtmfDetCeType
*                known  = ([Dd][Ss]|[Mm][Ee][Tt][Hh]);
*                all    = "*";
*                unk    = [A-Za-z0-9]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unk    {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherDtmfDetCeType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherDtmfDetCeType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherDtmfDetCeType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'D':   case 'd':   goto yy5;
   case 'M':   case 'm':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy12;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy10;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy11;
   default:   goto yy9;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy12;
   default:   goto yy9;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy13;
   }
yy13:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherDtmfDetCeType */
#endif /* GCP_PKG_MGCO_DTMFDET */

#if (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) || \
     defined(GCP_PKG_MGCO_TDMC))
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherNetworkNetfailPar
*
*       Desc:  Description for the regular expression ObsEvtOtherNetworkNetfailPar
*                [Cc][Ss]  {return(MGT_PKG_NETWORK_EVT_NETFAIL_CAUSE);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherNetworkNetfailPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherNetworkNetfailPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherNetworkNetfailPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_EVT_NETFAIL_CAUSE;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherNetworkNetfailPar */
#endif /* (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) ||
     defined(GCP_PKG_MGCO_TDMC)) */

#if (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) || \
     defined(GCP_PKG_MGCO_TDMC))
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherNetworkNetfailType
*
*       Desc:  Description for the regular expression ObsEvtOtherNetworkNetfailType
*                [Cc][Ss]     {return(MGT_GEN_TYPE_KNOWN);}
*                "*"          {return(MGT_GEN_TYPE_ALL);}
*                [A-Za-z0-9]+ {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherNetworkNetfailType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherNetworkNetfailType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherNetworkNetfailType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy5;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'C':   case 'c':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy9;
   default:   goto yy8;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy4;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy10;
   }
yy10:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherNetworkNetfailType */
#endif /* (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) ||
     defined(GCP_PKG_MGCO_TDMC)) */

#if (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) || \
     defined(GCP_PKG_MGCO_TDMC))
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherNetworkQualertPar
*
*       Desc:  Description for the regular expression ObsEvtOtherNetworkQualertPar
*                [Tt][Hh]  {return(MGT_PKG_NETWORK_EVT_QUALERT_TH);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherNetworkQualertPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherNetworkQualertPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherNetworkQualertPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'T':   case 't':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_EVT_QUALERT_TH;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherNetworkQualertPar */
#endif /* (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) ||
     defined(GCP_PKG_MGCO_TDMC)) */

#if (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) || \
     defined(GCP_PKG_MGCO_TDMC))
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherNetworkQualertType
*
*       Desc:  Description for the regular expression ObsEvtOtherNetworkQualertType
*                [Tt][Hh]  {return(MGT_GEN_TYPE_KNOWN);}
*                "*"       {return(MGT_GEN_TYPE_ALL);}
*                [A-Za-z0-9]+ {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherNetworkQualertType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherNetworkQualertType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherNetworkQualertType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy5;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'T':   case 't':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy9;
   default:   goto yy8;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy4;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy10;
   }
yy10:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherNetworkQualertType */
#endif /* (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) ||
     defined(GCP_PKG_MGCO_TDMC)) */

#ifdef GCP_PKG_MGCO_RTP
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherRtpPltransPar
*
*       Desc:  Description for the regular expression ObsEvtOtherRtpPltransPar
*                payload = [Rr][Tt][Pp][Pp][Aa][Yy][Ll][Oo][Aa][Dd];
*                pltype  = [Rr][Tt][Pp][Pp][Ll][Tt][Yy][Pp][Ee];
*              
*                pl      = payload | pltype;
*              
*                pl        {return(MGT_PKG_RTP_EVT_PLTRANS_PAYLOAD);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherRtpPltransPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherRtpPltransPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherRtpPltransPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy7;
   case 'L':   case 'l':   goto yy8;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy14;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_RTP_EVT_PLTRANS_PAYLOAD;
      goto yyReturn;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy12;
   default:   goto yyErr;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherRtpPltransPar */
#endif /* GCP_PKG_MGCO_RTP */

#ifdef GCP_PKG_MGCO_RTP
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherRtpPltransType
*
*       Desc:  Description for the regular expression ObsEvtOtherRtpPltransType
*                payload = [Rr][Tt][Pp][Pp][Aa][Yy][Ll][Oo][Aa][Dd];
*                pltype  = [Rr][Tt][Pp][Pp][Ll][Tt][Yy][Pp][Ee];
*              
*                pl      = payload | pltype;
*                all     = "*";
*                unk     = [0-9A-Za-z]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                pl     {return(MGT_GEN_TYPE_KNOWN);}
*                unk    {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherRtpPltransType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherRtpPltransType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherRtpPltransType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'R':   case 'r':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy9;
   default:   goto yy8;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy6;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy10;
   default:   goto yy8;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy11;
   default:   goto yy8;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy12;
   case 'L':   case 'l':   goto yy13;
   default:   goto yy8;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy19;
   default:   goto yy8;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy14;
   default:   goto yy8;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy15;
   default:   goto yy8;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy16;
   default:   goto yy8;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy17;
   default:   goto yy8;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy18;
   }
yy18:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy20;
   default:   goto yy8;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy21;
   default:   goto yy8;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy22;
   default:   goto yy8;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy17;
   default:   goto yy8;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherRtpPltransType */
#endif /* GCP_PKG_MGCO_RTP */

#if (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) || \
     defined(GCP_PKG_MGCO_CPDET))
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherToneDetEtdPar
*
*       Desc:  Description for the regular expression ObsEvtOtherToneDetEtdPar
*                tid    = [Tt][Ii][Dd];
*                dur    = [Dd][Uu][Rr];
*              
*                tid    {return(MGT_PKG_TONEDET_EVT_STD_TID);}
*                dur    {return(MGT_PKG_TONEDET_EVT_LTD_DUR);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherToneDetEtdPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherToneDetEtdPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherToneDetEtdPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy4;
   case 'T':   case 't':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy8;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEDET_EVT_LTD_DUR;
      goto yyReturn;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEDET_EVT_STD_TID;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherToneDetEtdPar */
#endif /* (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) ||
     defined(GCP_PKG_MGCO_CPDET)) */

#if (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) || \
     defined(GCP_PKG_MGCO_CPDET))
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherToneDetEtdType
*
*       Desc:  Description for the regular expression ObsEvtOtherToneDetEtdType
*                known  = ([Tt][Ii][Dd]|[Dd][Uu][Rr]);
*                all    = "*";
*                unkn   = [0-9A-Za-z]+;
*              
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unkn   {return(MGT_GEN_TYPE_UNKNOWN);}
*                all    {return(MGT_GEN_TYPE_ALL);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherToneDetEtdType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherToneDetEtdType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherToneDetEtdType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy8;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy6;
   case 'D':   case 'd':   goto yy5;
   case 'T':   case 't':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy13;
   default:   goto yy7;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy10;
   default:   goto yy7;
   }
yy6:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy7:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy6;
   default:   goto yy4;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy11;
   default:   goto yy7;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy6;
   default:   goto yy12;
   }
yy12:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy11;
   default:   goto yy7;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherToneDetEtdType */
#endif /* (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) ||
     defined(GCP_PKG_MGCO_CPDET)) */

#if (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) || \
     defined(GCP_PKG_MGCO_CPDET))
/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherToneDetStdPar
*
*       Desc:  Description for the regular expression ObsEvtOtherToneDetStdPar
*                [Tt][Ii][Dd]    {return(MGT_PKG_TONEDET_EVT_STD_TID);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherToneDetStdPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherToneDetStdPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherToneDetStdPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'T':   case 't':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEDET_EVT_STD_TID;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherToneDetStdPar */
#endif /* (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) ||
     defined(GCP_PKG_MGCO_CPDET)) */

#if (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) || \
     defined(GCP_PKG_MGCO_CPDET))

/*
*
*       Fun:   mgMgcoRegExpObsEvtOtherToneDetStdType
*
*       Desc:  Description for the regular expression ObsEvtOtherToneDetStdType
*                known  =  [Tt][Ii][Dd];
*                all    =  "*";
*                unkn   =  [0-9A-Za-z]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unkn   {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpObsEvtOtherToneDetStdType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpObsEvtOtherToneDetStdType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpObsEvtOtherToneDetStdType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'T':   case 't':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy9;
   default:   goto yy8;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy6;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy10;
   default:   goto yy8;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy11;
   }
yy11:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpObsEvtOtherToneDetStdType */
#endif /* (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) ||
     defined(GCP_PKG_MGCO_CPDET)) */

/*
*
*       Fun:   mgMgcoRegExpParmValDecUint
*
*       Desc:  Description for the regular expression ParmValDecUint
*
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpParmValDecUint
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpParmValDecUint(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   TRC2(mgMgcoRegExpParmValDecUint)
   UNUSED(decCp);
   UNUSED(tknCons);
   UNUSED(mem);
   UNUSED(len);

   RETVALUE(MGT_VALTYPE_UINT32);
}

/*
*
*       Fun:   mgMgcoRegExpParmValDecSint
*
*       Desc:  Description for the regular expression ParmValDecSint
*
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpParmValDecSint
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpParmValDecSint(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   TRC2(mgMgcoRegExpParmValDecSint)
   UNUSED(decCp);
   UNUSED(tknCons);
   UNUSED(mem);
   UNUSED(len);

   RETVALUE(MGT_VALTYPE_SINT32);
}

/*
*
*       Fun:   mgMgcoRegExpParmValHexUint
*
*       Desc:  Description for the regular expression ParmValHexUint
*
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpParmValHexUint
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpParmValHexUint(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   TRC2(mgMgcoRegExpParmValHexUint)
   UNUSED(decCp);
   UNUSED(tknCons);
   UNUSED(mem);
   UNUSED(len);

   RETVALUE(MGT_VALTYPE_HEX_UINT32);
}

/*
*
*       Fun:   mgMgcoRegExpParmValHexSint
*
*       Desc:  Description for the regular expression ParmValHexSint
*
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpParmValHexSint
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpParmValHexSint(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   TRC2(mgMgcoRegExpParmValHexSint)
   UNUSED(decCp);
   UNUSED(tknCons);
   UNUSED(mem);
   UNUSED(len);

   RETVALUE(MGT_VALTYPE_HEX_SINT32);
}

/*
*
*       Fun:   mgMgcoRegExpParmValEnume
*
*       Desc:  Description for the regular expression ParmValEnume
*
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpParmValEnume
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpParmValEnume(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   TRC2(mgMgcoRegExpParmValEnume)
   UNUSED(decCp);
   UNUSED(tknCons);
   UNUSED(mem);
   UNUSED(len);

   RETVALUE(MGT_VALTYPE_ENUM);
}


/*
*
*       Fun:   mgMgcoRegExpParmValOctStrXL
*
*       Desc:  Description for the regular expression ParmValOctStrXL
*
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpParmValOctStrXL
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpParmValOctStrXL(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   TRC2(mgMgcoRegExpParmValOctStrXL)
   UNUSED(decCp);
   UNUSED(tknCons);
   UNUSED(mem);
   UNUSED(len);

   RETVALUE(MGT_VALTYPE_OCTSTRXL);
}



/*
*
*       Fun:   mgMgcoRegExpParmValAnncSpec
*
*       Desc:  Description for the regular expression ParmValAnncSpec
*
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpParmValAnncSpec
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpParmValAnncSpec(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   TRC2(mgMgcoRegExpParmValAnncSpec)
   UNUSED(decCp);
   UNUSED(tknCons);
   UNUSED(mem);
   UNUSED(len);

   RETVALUE(MGT_VALTYPE_ADV_AUD_SEGLST);
}




/*
*
*       Fun:   mgMgcoRegExpParmValProvSegSpec
*
*       Desc:  Description for the regular expression ParmValProvSegSpec
*
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpParmValProvSegSpec
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpParmValProvSegSpec(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   TRC2(mgMgcoRegExpParmValProvSegSpec)
   UNUSED(decCp);
   UNUSED(tknCons);
   UNUSED(mem);
   UNUSED(len);

   RETVALUE(MGT_VALTYPE_ADV_AUD_PROVSEGSPEC);
}


/*
*
*       Fun:   mgMgcoRegExpParmValTermId
*
*       Desc:  Description for the regular expression ParmValTermId
*
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpParmValTermId
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpParmValTermId(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   TRC2(mgMgcoRegExpParmValTermId)
   UNUSED(decCp);
   UNUSED(tknCons);
   UNUSED(mem);
   UNUSED(len);

   RETVALUE(MGT_VALTYPE_TERMID);
}


/*
*
*       Fun:   mgMgcoRegExpParmValTermIdLst
*
*       Desc:  Description for the regular expression ParmValTermIdLst
*
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpParmValTermIdLst
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpParmValTermIdLst(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   TRC2(mgMgcoRegExpParmValTermIdLst)
   UNUSED(decCp);
   UNUSED(tknCons);
   UNUSED(mem);
   UNUSED(len);

   RETVALUE(MGT_VALTYPE_TERMIDLST);
}


/*
*
*       Fun:   mgMgcoRegExpParmValSigNameOrLst
*
*       Desc:  Description for the regular expression ParmValSigNameOrLst
*               DIGIT            = [0-9];
*               ALPHA            = [A-Za-z];
*               SLASH            = "/";
*               NAME             = ALPHA (ALPHA | DIGIT | "_")*;
*              
*               PkgdNameStart    = (NAME | "*") SLASH;
*               SigReqStart      = PkgdNameStart;
*               SigListStart     = (DIGIT)+;
*              
*               SigListStart       {return(MGT_VALTYPE_SIGLST);}
*               SigReqStart        {return(MGT_VALTYPE_SIGNAME);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpParmValSigNameOrLst
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpParmValSigNameOrLst(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpParmValSigNameOrLst)
   UNUSED(mem);

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy6;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy3;
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy3:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy3;
   default:   goto yy5;
   }
yy5:
   {
      yyret = MGT_VALTYPE_SIGLST;
      goto yyReturn;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '/':   goto yy9;
   default:   goto yyErr;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '/':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case '_':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_VALTYPE_SIGNAME;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpParmValSigNameOrLst */

#ifdef GCP_PKG_MGCO_ANALOG
/*
*
*       Fun:   mgMgcoRegExpPkgAnalogEvtType
*
*       Desc:  Description for the regular expression PkgAnalogEvtType
*                [Oo][Nn]     {return(MGT_GEN_TYPE_KNOWN);}
*                [Oo][Ff]     {return(MGT_GEN_TYPE_KNOWN);} 
*                [Ff][Ll]     {return(MGT_GEN_TYPE_KNOWN);}
*                "*"          {return(MGT_GEN_TYPE_ALL);}
*                [0-9A-Za-z]+ {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgAnalogEvtType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgAnalogEvtType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgAnalogEvtType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy6;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'F':   case 'f':   goto yy5;
   case 'O':   case 'o':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy12;
   case 'N':   case 'n':   goto yy14;
   default:   goto yy9;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy10;
   default:   goto yy9;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy4;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy11;
   }
yy11:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy13;
   }
yy13:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy15;
   }
yy15:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgAnalogEvtType */
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_ANALOG
/*
*
*       Fun:   mgMgcoRegExpPkgAnalogSigType
*
*       Desc:  Description for the regular expression PkgAnalogSigType
*                [Rr][Ii]        {return(MGT_GEN_TYPE_KNOWN);}
*                "*"             {return(MGT_GEN_TYPE_ALL);}
*                [0-9A-Za-z]+    {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgAnalogSigType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgAnalogSigType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgAnalogSigType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy5;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'R':   case 'r':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy9;
   default:   goto yy8;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy4;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy10;
   }
yy10:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgAnalogSigType */
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_CONT
/*
*
*       Fun:   mgMgcoRegExpPkgContEvtType
*
*       Desc:  Description for the regular expression PkgContEvtType
*                [Cc][Mm][Pp]    {return(MGT_GEN_TYPE_KNOWN);}
*                "*"             {return(MGT_GEN_TYPE_ALL);}
*                [0-9A-Za-z]+    {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgContEvtType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgContEvtType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgContEvtType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy5;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'C':   case 'c':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy9;
   default:   goto yy8;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy4;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy10;
   default:   goto yy8;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy11;
   }
yy11:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgContEvtType */
#endif /* GCP_PKG_MGCO_CONT */

#ifdef GCP_PKG_MGCO_CONT
/*
*
*       Fun:   mgMgcoRegExpPkgContSigType
*
*       Desc:  Description for the regular expression PkgContSigType
*                known  = [Cc][Tt]|[Rr][Ss][Pp];
*                known           {return(MGT_GEN_TYPE_KNOWN);}
*                "*"             {return(MGT_GEN_TYPE_ALL);}
*                [0-9A-Za-z]+    {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgContSigType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgContSigType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgContSigType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy6;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'C':   case 'c':   goto yy3;
   case 'R':   case 'r':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy11;
   default:   goto yy9;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy10;
   default:   goto yy9;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy4;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy11;
   default:   goto yy9;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy12;
   }
yy12:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgContSigType */
#endif /* GCP_PKG_MGCO_CONT */

#ifdef GCP_PKG_MGCO_CPDET
/*
*
*       Fun:   mgMgcoRegExpPkgCpDetEvtType
*
*       Desc:  Description for the regular expression PkgCpDetEvtType
*                known  = ([SsEeLl][Tt][Dd]|[Dd][0-9A-Da-dSsOoTt]|[RrBbCcWwPp][Tt]|[Ss][Ii][Tt]|[Cc][Ww]|[Cc][Rr]); 
*                all    =  "*";
*                unkn   =  [0-9A-Za-z]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unkn   {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgCpDetEvtType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgCpDetEvtType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgCpDetEvtType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':   case 'M':
   case 'N':
   case 'O':   case 'Q':   case 'T':
   case 'U':
   case 'V':   case 'X':
   case 'Y':
   case 'Z':   case 'a':   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':   case 'm':
   case 'n':
   case 'o':   case 'q':   case 't':
   case 'u':
   case 'v':   case 'x':
   case 'y':
   case 'z':   goto yy11;
   case 'B':   case 'P':   case 'R':   case 'W':   case 'b':   case 'p':   case 'r':   case 'w':   goto yy9;
   case 'C':   case 'c':   goto yy10;
   case 'D':   case 'd':   goto yy8;
   case 'E':   case 'L':   case 'e':   case 'l':   goto yy5;
   case 'S':   case 's':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy16;
   default:   goto yy12;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy15;
   case 'T':   case 't':   goto yy16;
   default:   goto yy12;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':   case 'O':   case 'S':
   case 'T':   case 'a':
   case 'b':
   case 'c':
   case 'd':   case 'o':   case 's':
   case 't':   goto yy13;
   default:   goto yy12;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy13;
   default:   goto yy12;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'T':   case 'W':   case 'r':   case 't':   case 'w':   goto yy13;
   default:   goto yy12;
   }
yy11:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy12:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   default:   goto yy6;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   default:   goto yy14;
   }
yy14:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy13;
   default:   goto yy12;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy13;
   default:   goto yy12;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgCpDetEvtType */
#endif /* GCP_PKG_MGCO_CPDET */

#ifdef GCP_PKG_MGCO_CPGEN

/*
*
*       Fun:   mgMgcoRegExpPkgCpGenSigType
*
*       Desc:  Description for the regular expression PkgCpGenSigType
*                known  = ([Dd][0-9A-Da-dSsOoTt]|[RrBbCcWwPp][Tt]|[Ss][Ii][Tt]|[Cc][Ww]|[Cc][Rr]|[Pp][Rr][Tt]);
*                all    =  "*";
*                unkn   =  [0-9A-Za-z]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unkn   {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgCpGenSigType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgCpGenSigType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgCpGenSigType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':   case 'Q':   case 'T':
   case 'U':
   case 'V':   case 'X':
   case 'Y':
   case 'Z':   case 'a':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':   case 'q':   case 't':
   case 'u':
   case 'v':   case 'x':
   case 'y':
   case 'z':   goto yy11;
   case 'B':   case 'R':   case 'W':   case 'b':   case 'r':   case 'w':   goto yy7;
   case 'C':   case 'c':   goto yy8;
   case 'D':   case 'd':   goto yy5;
   case 'P':   case 'p':   goto yy9;
   case 'S':   case 's':   goto yy10;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':   case 'O':   case 'S':
   case 'T':   case 'a':
   case 'b':
   case 'c':
   case 'd':   case 'o':   case 's':
   case 't':   goto yy14;
   default:   goto yy12;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy14;
   default:   goto yy12;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'T':   case 'W':   case 'r':   case 't':   case 'w':   goto yy14;
   default:   goto yy12;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy16;
   case 'T':   case 't':   goto yy14;
   default:   goto yy12;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy13;
   default:   goto yy12;
   }
yy11:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy12:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   default:   goto yy6;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy14;
   default:   goto yy12;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   default:   goto yy15;
   }
yy15:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy14;
   default:   goto yy12;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgCpGenSigType */
#endif /* GCP_PKG_MGCO_CPGEN */

#ifdef GCP_PKG_MGCO_DTMFDET
/*
*
*       Fun:   mgMgcoRegExpPkgDtmfDetEvtType
*
*       Desc:  Description for the regular expression PkgDtmfDetEvtType
*                std    =  [Ss][Tt][Dd];
*                etd    =  [Ee][Tt][Dd];
*                ltd    =  [Ll][Tt][Dd];
*                ce     =  [Cc][Ee];
*                known  =  std | etd | ltd | ce |
*                          [Dd]"0"|[Dd]"1"|[Dd]"2"|[Dd]"3"|[Dd]"4"|[Dd]"5"|[Dd]"6"|[Dd]"7"|
*                          [Dd]"8"|[Dd]"9"|[Dd][Aa]|[Dd][Bb]|[Dd][Cc]|[Dd][Dd]|[Dd][Ss]|
*                          [Dd][Oo];
*                all       =  "*";
*                unknown   =  [A-Za-z0-9]+;
*              
*                all       {return(MGT_GEN_TYPE_ALL);}
*                known     {return(MGT_GEN_TYPE_KNOWN);}
*                unknown   {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgDtmfDetEvtType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgDtmfDetEvtType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgDtmfDetEvtType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   case 'C':   case 'c':   goto yy9;
   case 'D':   case 'd':   goto yy10;
   case 'E':   case 'e':   goto yy7;
   case 'L':   case 'l':   goto yy8;
   case 'S':   case 's':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy17;
   default:   goto yy12;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy16;
   default:   goto yy12;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy15;
   default:   goto yy12;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy13;
   default:   goto yy12;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':   case 'O':   case 'S':   case 'a':
   case 'b':
   case 'c':
   case 'd':   case 'o':   case 's':   goto yy13;
   default:   goto yy12;
   }
yy11:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy12:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   default:   goto yy6;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy11;
   default:   goto yy14;
   }
yy14:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy13;
   default:   goto yy12;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy13;
   default:   goto yy12;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy13;
   default:   goto yy12;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgDtmfDetEvtType */
#endif /* GCP_PKG_MGCO_DTMFDET */

#ifdef GCP_PKG_MGCO_DTMFGEN
/*
*
*       Fun:   mgMgcoRegExpPkgDtmfGenSigType
*
*       Desc:  Description for the regular expression PkgDtmfGenSigType
*                known     =  ([Dd]"0"|[Dd]"1"|[Dd]"2"|[Dd]"3"|[Dd]"4"|[Dd]"5"|[Dd]"6"|
*                              [Dd]"7"|[Dd]"8"|[Dd]"9"|[Dd][Aa]|[Dd][Bb]|[Dd][Cc]|[Dd][Dd]|
*                              [Dd][Ss]|[Dd][Oo]|[Pp][Tt]);
*                all       =  "*";
*                unknown   =  [A-Za-z0-9]+;
*              
*                all       {return(MGT_GEN_TYPE_ALL);}
*                known     {return(MGT_GEN_TYPE_KNOWN);}
*                unknown   {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgDtmfGenSigType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgDtmfGenSigType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgDtmfGenSigType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'D':   case 'd':   goto yy5;
   case 'P':   case 'p':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':   case 'O':   case 'S':   case 'a':
   case 'b':
   case 'c':
   case 'd':   case 'o':   case 's':   goto yy10;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy10;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy11;
   }
yy11:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgDtmfGenSigType */
#endif /* GCP_PKG_MGCO_DTMFGEN */

#ifdef GCP_PKG_MGCO_GENERIC 

/*
*
*       Fun:   mgMgcoRegExpPkgGenericEvtType
*
*       Desc:  Description for the regular expression PkgGenericEvtType
*                known = ([Cc][Aa][Uu][Ss][Ee] | [Ss][Cc]);
*                all   = "*";
*                unk   = [0-9a-zA-Z]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unk    {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgGenericEvtType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgGenericEvtType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgGenericEvtType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'C':   case 'c':   goto yy5;
   case 'S':   case 's':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy12;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy10;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy11;
   }
yy11:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy13;
   default:   goto yy9;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy14;
   default:   goto yy9;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy10;
   default:   goto yy9;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgGenericEvtType */
#endif /* GCP_PKG_MGCO_GENERIC */

#if (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) || \
     defined(GCP_PKG_MGCO_TDMC))
/*
*
*       Fun:   mgMgcoRegExpPkgNetworkEvtType
*
*       Desc:  Description for the regular expression PkgNetworkEvtType
*                netfail   = [Nn][Ee][Tt][Ff][Aa][Ii][Ll];
*                qualert   = [Qq][Uu][Aa][Ll][Ee][Rr][Tt];
*                known     = netfail | qualert;
*                all       = "*";
*                unkn      = [A-Za-z0-9]+;
*              
*                all       {return(MGT_GEN_TYPE_ALL);}
*                known     {return(MGT_GEN_TYPE_KNOWN);}
*                unkn      {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgNetworkEvtType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgNetworkEvtType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgNetworkEvtType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':   case 'O':
   case 'P':   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':   case 'o':
   case 'p':   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'N':   case 'n':   goto yy5;
   case 'Q':   case 'q':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy17;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy10;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy11;
   default:   goto yy9;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy12;
   default:   goto yy9;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy13;
   default:   goto yy9;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy14;
   default:   goto yy9;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy15;
   default:   goto yy9;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy16;
   }
yy16:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy18;
   default:   goto yy9;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy19;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy20;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy21;
   default:   goto yy9;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy15;
   default:   goto yy9;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgNetworkEvtType */
#endif /* (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) ||
     defined(GCP_PKG_MGCO_TDMC)) */

#if (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) || \
     defined(GCP_PKG_MGCO_TDMC))
/*
*
*       Fun:   mgMgcoRegExpPkgNetworkPropType
*
*       Desc:  Description for the regular expression PkgNetworkPropType
*                [Jj][Ii][Tt] {return(MGT_GEN_TYPE_KNOWN);}
*                "*"          {return(MGT_GEN_TYPE_ALL);}
*                [0-9A-Za-z]+ {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgNetworkPropType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgNetworkPropType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgNetworkPropType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy5;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'J':   case 'j':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy9;
   default:   goto yy8;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy4;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy10;
   default:   goto yy8;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy11;
   }
yy11:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgNetworkPropType */
#endif /* (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) ||
     defined(GCP_PKG_MGCO_TDMC)) */


#if (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) || \
     defined(GCP_PKG_MGCO_TDMC))
/*
*
*       Fun:   mgMgcoRegExpPkgNetworkStatsType
*
*       Desc:  Description for the regular expression PkgNetworkStatsType
*                dur    =  [Dd][Uu][Rr];
*                os     =  [Oo][Ss];
*                or     =  [Oo][Rr];
*              
*                known  =  dur | os | or;
*              
*                known        {return(MGT_GEN_TYPE_KNOWN);}
*                "*"          {return(MGT_GEN_TYPE_ALL);}
*                [0-9A-Za-z]+ {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgNetworkStatsType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgNetworkStatsType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgNetworkStatsType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy6;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'D':   case 'd':   goto yy3;
   case 'O':   case 'o':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy12;
   default:   goto yy9;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':
   case 'S':   case 'r':
   case 's':   goto yy10;
   default:   goto yy9;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy4;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy11;
   }
yy11:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy10;
   default:   goto yy9;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgNetworkStatsType */
#endif /* (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) ||
     defined(GCP_PKG_MGCO_TDMC)) */

/* RE regenerated */
#ifdef GCP_PKG_MGCO_ROOT

/*
*
*       Fun:   mgMgcoRegExpPkgRootPropType
*
*       Desc:  Description for the regular expression PkgRootPropType
*               MaxNrOfCxts=[Mm][Aa][Xx][Nn][Uu][Mm][Bb][Ee][Rr][Oo][Ff][Cc][Oo][Nn][Tt][Ee][Xx][Tt][Ss];
*               MaxTermsPerCxt=[Mm][Aa][Xx][Tt][Ee][Rr][Mm][Ii][Nn][Aa][Tt][Ii][Oo][Nn][Ss][Pp][Ee][Rr][Cc][Oo][Nn][Tt][Ee][Xx][Tt];
*               MGExecTime=[Nn][Oo][Rr][Mm][Aa][Ll][Mm][Gg][Ee][Xx][Ee][Cc][Uu][Tt][Ii][Oo][Nn][Tt][Ii][Mm][Ee];
*               MGCExecTime=[Nn][Oo][Rr][Mm][Aa][Ll][Mm][Gg][Cc][Ee][Xx][Ee][Cc][Uu][Tt][Ii][Oo][Nn][Tt][Ii][Mm][Ee];
*               MGProvRspTmrVal=[Mm][Gg][Pp][Rr][Oo][Vv][Ii][Ss][Ii][Oo][Nn][Aa][Ll][Rr][Ee][Ss][Pp][Oo][Nn][Ss][Ee][Tt][Ii][Mm][Ee][Rr][Vv][Aa][Ll][Uu][Ee];
*               MGCProvRspTmrVal=[Mm][Gg][Cc][Pp][Rr][Oo][Vv][Ii][Ss][Ii][Oo][Nn][Aa][Ll][Rr][Ee][Ss][Pp][Oo][Nn][Ss][Ee][Tt][Ii][Mm][Ee][Rr][Vv][Aa][Ll][Uu][Ee];
*               MGOriginatedPendingLimit=[Mm][gG][oO][Rr][Ii][Gg][Ii][Nn][Aa][Tt][Ee][Dd][pP][Ee][Nn][Dd][Ii][Nn][Gg][lL][Ii][Mm][Ii][Tt];
*               MGCOriginatedPendingLimit=[Mm][gG][Cc][oO][Rr][Ii][Gg][Ii][Nn][Aa][Tt][Ee][Dd][pP][Ee][Nn][Dd][Ii][Nn][Gg][lL][Ii][Mm][Ii][Tt];
*              
*               
*               known=MaxNrOfCxts | MaxTermsPerCxt | MGExecTime | MGCExecTime |MGProvRspTmrVal | MGCProvRspTmrVal |MGOriginatedPendingLimit |MGCOriginatedPendingLimit;
*               all="*";
*               unk=[0-9a-zA-Z]+;
*               all {return(MGT_GEN_TYPE_ALL);}
*               known {return(MGT_GEN_TYPE_KNOWN);}
*               unk {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgRootPropType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgRootPropType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMgcoRegExpPkgRootPropType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'M':   case 'm':   goto yy5;
   case 'N':   case 'n':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy44;
   case 'G':   case 'g':   goto yy45;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy10;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy11;
   default:   goto yy9;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy12;
   default:   goto yy9;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy13;
   default:   goto yy9;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy14;
   default:   goto yy9;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy15;
   default:   goto yy9;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy16;
   default:   goto yy9;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy18;
   case 'E':   case 'e':   goto yy17;
   default:   goto yy9;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy33;
   default:   goto yy9;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy19;
   default:   goto yy9;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy20;
   default:   goto yy9;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy21;
   default:   goto yy9;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy22;
   default:   goto yy9;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy23;
   default:   goto yy9;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy24;
   default:   goto yy9;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy25;
   default:   goto yy9;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy26;
   default:   goto yy9;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy27;
   default:   goto yy9;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy28;
   default:   goto yy9;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy29;
   default:   goto yy9;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy30;
   default:   goto yy9;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy31;
   default:   goto yy9;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy32;
   }
yy32:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy34;
   default:   goto yy9;
   }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy35;
   default:   goto yy9;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy36;
   default:   goto yy9;
   }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy37;
   default:   goto yy9;
   }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy38;
   default:   goto yy9;
   }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy39;
   default:   goto yy9;
   }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy40;
   default:   goto yy9;
   }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy41;
   default:   goto yy9;
   }
yy41:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy42;
   default:   goto yy9;
   }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy43;
   default:   goto yy9;
   }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy31;
   default:   goto yy9;
   }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy145;
   default:   goto yy9;
   }
yy45:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy47;
   case 'O':   case 'o':   goto yy48;
   case 'P':   case 'p':   goto yy46;
   default:   goto yy9;
   }
yy46:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy118;
   default:   goto yy9;
   }
yy47:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy69;
   case 'P':   case 'p':   goto yy70;
   default:   goto yy9;
   }
yy48:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy49;
   default:   goto yy9;
   }
yy49:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy50;
   default:   goto yy9;
   }
yy50:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy51;
   default:   goto yy9;
   }
yy51:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy52;
   default:   goto yy9;
   }
yy52:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy53;
   default:   goto yy9;
   }
yy53:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy54;
   default:   goto yy9;
   }
yy54:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy55;
   default:   goto yy9;
   }
yy55:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy56;
   default:   goto yy9;
   }
yy56:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy57;
   default:   goto yy9;
   }
yy57:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy58;
   default:   goto yy9;
   }
yy58:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy59;
   default:   goto yy9;
   }
yy59:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy60;
   default:   goto yy9;
   }
yy60:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy61;
   default:   goto yy9;
   }
yy61:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy62;
   default:   goto yy9;
   }
yy62:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy63;
   default:   goto yy9;
   }
yy63:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy64;
   default:   goto yy9;
   }
yy64:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy65;
   default:   goto yy9;
   }
yy65:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy66;
   default:   goto yy9;
   }
yy66:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy67;
   default:   goto yy9;
   }
yy67:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy68;
   default:   goto yy9;
   }
yy68:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy31;
   default:   goto yy9;
   }
yy69:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy98;
   default:   goto yy9;
   }
yy70:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy71;
   default:   goto yy9;
   }
yy71:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy72;
   default:   goto yy9;
   }
yy72:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy73;
   default:   goto yy9;
   }
yy73:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy74;
   default:   goto yy9;
   }
yy74:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy75;
   default:   goto yy9;
   }
yy75:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy76;
   default:   goto yy9;
   }
yy76:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy77;
   default:   goto yy9;
   }
yy77:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy78;
   default:   goto yy9;
   }
yy78:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy79;
   default:   goto yy9;
   }
yy79:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy80;
   default:   goto yy9;
   }
yy80:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy81;
   default:   goto yy9;
   }
yy81:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy82;
   default:   goto yy9;
   }
yy82:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy83;
   default:   goto yy9;
   }
yy83:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy84;
   default:   goto yy9;
   }
yy84:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy85;
   default:   goto yy9;
   }
yy85:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy86;
   default:   goto yy9;
   }
yy86:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy87;
   default:   goto yy9;
   }
yy87:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy88;
   default:   goto yy9;
   }
yy88:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy89;
   default:   goto yy9;
   }
yy89:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy90;
   default:   goto yy9;
   }
yy90:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy91;
   default:   goto yy9;
   }
yy91:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy92;
   default:   goto yy9;
   }
yy92:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy93;
   default:   goto yy9;
   }
yy93:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy94;
   default:   goto yy9;
   }
yy94:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy95;
   default:   goto yy9;
   }
yy95:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy96;
   default:   goto yy9;
   }
yy96:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy97;
   default:   goto yy9;
   }
yy97:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy31;
   default:   goto yy9;
   }
yy98:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy99;
   default:   goto yy9;
   }
yy99:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy100;
   default:   goto yy9;
   }
yy100:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy101;
   default:   goto yy9;
   }
yy101:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy102;
   default:   goto yy9;
   }
yy102:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy103;
   default:   goto yy9;
   }
yy103:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy104;
   default:   goto yy9;
   }
yy104:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy105;
   default:   goto yy9;
   }
yy105:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy106;
   default:   goto yy9;
   }
yy106:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy107;
   default:   goto yy9;
   }
yy107:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy108;
   default:   goto yy9;
   }
yy108:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy109;
   default:   goto yy9;
   }
yy109:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy110;
   default:   goto yy9;
   }
yy110:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy111;
   default:   goto yy9;
   }
yy111:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy112;
   default:   goto yy9;
   }
yy112:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy113;
   default:   goto yy9;
   }
yy113:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy114;
   default:   goto yy9;
   }
yy114:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy115;
   default:   goto yy9;
   }
yy115:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy116;
   default:   goto yy9;
   }
yy116:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy117;
   default:   goto yy9;
   }
yy117:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy31;
   default:   goto yy9;
   }
yy118:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy119;
   default:   goto yy9;
   }
yy119:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy120;
   default:   goto yy9;
   }
yy120:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy121;
   default:   goto yy9;
   }
yy121:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy122;
   default:   goto yy9;
   }
yy122:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy123;
   default:   goto yy9;
   }
yy123:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy124;
   default:   goto yy9;
   }
yy124:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy125;
   default:   goto yy9;
   }
yy125:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy126;
   default:   goto yy9;
   }
yy126:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy127;
   default:   goto yy9;
   }
yy127:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy128;
   default:   goto yy9;
   }
yy128:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy129;
   default:   goto yy9;
   }
yy129:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy130;
   default:   goto yy9;
   }
yy130:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy131;
   default:   goto yy9;
   }
yy131:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy132;
   default:   goto yy9;
   }
yy132:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy133;
   default:   goto yy9;
   }
yy133:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy134;
   default:   goto yy9;
   }
yy134:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy135;
   default:   goto yy9;
   }
yy135:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy136;
   default:   goto yy9;
   }
yy136:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy137;
   default:   goto yy9;
   }
yy137:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy138;
   default:   goto yy9;
   }
yy138:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy139;
   default:   goto yy9;
   }
yy139:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy140;
   default:   goto yy9;
   }
yy140:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy141;
   default:   goto yy9;
   }
yy141:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy142;
   default:   goto yy9;
   }
yy142:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy143;
   default:   goto yy9;
   }
yy143:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy144;
   default:   goto yy9;
   }
yy144:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy31;
   default:   goto yy9;
   }
yy145:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy146;
   case 'T':   case 't':   goto yy147;
   default:   goto yy9;
   }
yy146:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy168;
   default:   goto yy9;
   }
yy147:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy148;
   default:   goto yy9;
   }
yy148:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy149;
   default:   goto yy9;
   }
yy149:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy150;
   default:   goto yy9;
   }
yy150:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy151;
   default:   goto yy9;
   }
yy151:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy152;
   default:   goto yy9;
   }
yy152:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy153;
   default:   goto yy9;
   }
yy153:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy154;
   default:   goto yy9;
   }
yy154:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy155;
   default:   goto yy9;
   }
yy155:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy156;
   default:   goto yy9;
   }
yy156:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy157;
   default:   goto yy9;
   }
yy157:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy158;
   default:   goto yy9;
   }
yy158:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy159;
   default:   goto yy9;
   }
yy159:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy160;
   default:   goto yy9;
   }
yy160:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy161;
   default:   goto yy9;
   }
yy161:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy162;
   default:   goto yy9;
   }
yy162:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy163;
   default:   goto yy9;
   }
yy163:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy164;
   default:   goto yy9;
   }
yy164:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy165;
   default:   goto yy9;
   }
yy165:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy166;
   default:   goto yy9;
   }
yy166:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy167;
   default:   goto yy9;
   }
yy167:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy31;
   default:   goto yy9;
   }
yy168:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy169;
   default:   goto yy9;
   }
yy169:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy170;
   default:   goto yy9;
   }
yy170:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy171;
   default:   goto yy9;
   }
yy171:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy172;
   default:   goto yy9;
   }
yy172:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy173;
   default:   goto yy9;
   }
yy173:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy174;
   default:   goto yy9;
   }
yy174:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy175;
   default:   goto yy9;
   }
yy175:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy176;
   default:   goto yy9;
   }
yy176:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy177;
   default:   goto yy9;
   }
yy177:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy178;
   default:   goto yy9;
   }
yy178:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy179;
   default:   goto yy9;
   }
yy179:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy180;
   default:   goto yy9;
   }
yy180:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy181;
   default:   goto yy9;
   }
yy181:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy31;
   default:   goto yy9;
   }
                


yyReturn:
   CM_ABNF_DEC_CSPSTRXL(decCp, mem, len, yydecode);

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgRootPropType */

#endif /* GCP_PKG_MGCO_ROOT */

#ifdef GCP_PKG_MGCO_RTP
/*
*
*       Fun:   mgMgcoRegExpPkgRtpEvtType
*
*       Desc:  Description for the regular expression PkgRtpEvtType
*                netfail   = [Nn][Ee][Tt][Ff][Aa][Ii][Ll];
*                qualert   = [Qq][Uu][Aa][Ll][Ee][Rr][Tt];
*                pltrans   = [Pp][Ll][Tt][Rr][Aa][Nn][Ss];
*                
*                known     = netfail | qualert | pltrans;
*                all       = "*";
*                unkn      = [A-Za-z0-9]+;
*              
*                all       {return(MGT_GEN_TYPE_ALL);}
*                known     {return(MGT_GEN_TYPE_KNOWN);}
*                unkn      {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgRtpEvtType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgRtpEvtType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgRtpEvtType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':   case 'O':   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':   case 'o':   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   case 'N':   case 'n':   goto yy5;
   case 'P':   case 'p':   goto yy8;
   case 'Q':   case 'q':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy23;
   default:   goto yy10;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy18;
   default:   goto yy10;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy11;
   default:   goto yy10;
   }
yy9:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy10:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yy6;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy12;
   default:   goto yy10;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy13;
   default:   goto yy10;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy14;
   default:   goto yy10;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy15;
   default:   goto yy10;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy16;
   default:   goto yy10;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yy17;
   }
yy17:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy19;
   default:   goto yy10;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy20;
   default:   goto yy10;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy21;
   default:   goto yy10;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy22;
   default:   goto yy10;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy16;
   default:   goto yy10;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy24;
   default:   goto yy10;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy25;
   default:   goto yy10;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy26;
   default:   goto yy10;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy27;
   default:   goto yy10;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy16;
   default:   goto yy10;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgRtpEvtType */
#endif /* GCP_PKG_MGCO_RTP */

#ifdef GCP_PKG_MGCO_RTP
/*
*
*       Fun:   mgMgcoRegExpPkgRtpStatsType
*
*       Desc:  Description for the regular expression PkgRtpStatsType
*                dur    =  [Dd][Uu][Rr];
*                os     =  [Oo][Ss];
*                or     =  [Oo][Rr];
*                ps     =  [Pp][Ss];
*                pr     =  [Pp][Rr];
*                pl     =  [Pp][Ll];
*                jit    =  [Jj][Ii][Tt];
*                delay  =  [Dd][Ee][Ll][Aa][Yy];
*              
*                known  =  dur | os | or | ps | pr | pl | jit | delay;
*              
*                known        {return(MGT_GEN_TYPE_KNOWN);}
*                "*"          {return(MGT_GEN_TYPE_ALL);}
*                [0-9A-Za-z]+ {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgRtpStatsType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgRtpStatsType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgRtpStatsType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy8;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':   case 'K':
   case 'L':
   case 'M':
   case 'N':   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':   case 'k':
   case 'l':
   case 'm':
   case 'n':   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   case 'D':   case 'd':   goto yy3;
   case 'J':   case 'j':   goto yy7;
   case 'O':   case 'o':   goto yy5;
   case 'P':   case 'p':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy15;
   case 'U':   case 'u':   goto yy16;
   default:   goto yy11;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':
   case 'S':   case 'r':
   case 's':   goto yy13;
   default:   goto yy11;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'R':
   case 'S':   case 'l':   case 'r':
   case 's':   goto yy13;
   default:   goto yy11;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy12;
   default:   goto yy11;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy10:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy11:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   default:   goto yy4;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy13;
   default:   goto yy11;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy10;
   default:   goto yy14;
   }
yy14:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy17;
   default:   goto yy11;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy13;
   default:   goto yy11;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy18;
   default:   goto yy11;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy13;
   default:   goto yy11;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgRtpStatsType */
#endif /* GCP_PKG_MGCO_RTP */

#ifdef GCP_PKG_MGCO_TDMC
/*
*
*       Fun:   mgMgcoRegExpPkgTdmcPropType
*
*       Desc:  Description for the regular expression PkgTdmcPropType
*                [Jj][Ii][Tt] {return(MGT_GEN_TYPE_KNOWN);}
*                [Ee][Cc]     {return(MGT_GEN_TYPE_KNOWN);}
*                [Gg][Aa][Ii][Nn]   {return(MGT_GEN_TYPE_KNOWN);}
*              
*                "*"          {return(MGT_GEN_TYPE_ALL);}
*                [0-9A-Za-z]+ {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgTdmcPropType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgTdmcPropType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgTdmcPropType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy7;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':   case 'F':   case 'H':
   case 'I':   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':   case 'f':   case 'h':
   case 'i':   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   case 'E':   case 'e':   goto yy5;
   case 'G':   case 'g':   goto yy6;
   case 'J':   case 'j':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy17;
   default:   goto yy10;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy15;
   default:   goto yy10;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy11;
   default:   goto yy10;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy9:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy10:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yy4;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy12;
   default:   goto yy10;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy13;
   default:   goto yy10;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yy14;
   }
yy14:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yy16;
   }
yy16:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy18;
   default:   goto yy10;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy9;
   default:   goto yy19;
   }
yy19:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgTdmcPropType */
#endif /* GCP_PKG_MGCO_TDMC */

#if (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) || \
     defined(GCP_PKG_MGCO_CPDET))
/*
*
*       Fun:   mgMgcoRegExpPkgToneDetEvtType
*
*       Desc:  Description for the regular expression PkgToneDetEvtType
*                known  =  [SsEeLl][Tt][Dd];
*                all    =  "*";
*                unkn   =  [0-9A-Za-z]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unkn   {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgToneDetEvtType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgToneDetEvtType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgToneDetEvtType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'E':   case 'L':   case 'S':   case 'e':   case 'l':   case 's':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy9;
   default:   goto yy8;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy6;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy10;
   default:   goto yy8;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy11;
   }
yy11:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgToneDetEvtType */
#endif /* (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) ||
     defined(GCP_PKG_MGCO_CPDET)) */

#if (defined(GCP_PKG_MGCO_TONEGEN) || defined(GCP_PKG_MGCO_DTMFGEN) || \
     defined(GCP_PKG_MGCO_CPGEN)   || defined(GCP_PKG_MGCO_TONEDET) || \
     defined(GCP_PKG_MGCO_DTMFDET) || defined(GCP_PKG_MGCO_CPDET))
/*
*
*       Fun:   mgMgcoRegExpPkgToneGenSigType
*
*       Desc:  Description for the regular expression PkgToneGenSigType
*                known     =  [Pp][Tt];
*                all       =  "*";
*                unknown   =  [A-za-z]+;
*              
*                all       {return(MGT_GEN_TYPE_ALL);}
*                known     {return(MGT_GEN_TYPE_KNOWN);}
*                unknown   {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgToneGenSigType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgToneGenSigType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgToneGenSigType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':
   case '\\':
   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'P':   case 'p':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy9;
   default:   goto yy8;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':
   case '\\':
   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy6;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':
   case '\\':
   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy10;
   }
yy10:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgToneGenSigType */
#endif /* (defined(GCP_PKG_MGCO_TONEGEN) || defined(GCP_PKG_MGCO_DTMFGEN) 
        || defined(GCP_PKG_MGCO_CPGEN))  || defined(GCP_PKG_MGCO_TONEDET)
        || defined(GCP_PKG_MGCO_DTMFDET) || defined(GCP_PKG_MGCO_CPDET)) */

/*
*
*       Fun:   mgMgcoRegExpPkgTonegenSigType
*
*       Desc:  Description for the regular expression PkgTonegenSigType
*                known  =  [Pp][Tt];
*                all    =  "*";
*                unkn   =  [0-9A-Za-z]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unkn   {return(MGT_GEN_TYPE_UNKNOWN);}
*                
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPkgTonegenSigType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPkgTonegenSigType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPkgTonegenSigType)
   UNUSED(mem);

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'P':   case 'p':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy9;
   default:   goto yy8;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy6;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy10;
   }
yy10:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }

  


yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPkgTonegenSigType */

#if (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) || \
     defined(GCP_PKG_MGCO_TDMC))
/*
*
*       Fun:   mgMgcoRegExpPropParmNetwork
*
*       Desc:  Description for the regular expression PropParmNetwork
*                [Jj][Ii][Tt] {return(MGT_PKG_NETWORK_PROP_JIT);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPropParmNetwork
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPropParmNetwork(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPropParmNetwork)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'J':   case 'j':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_PROP_JIT;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPropParmNetwork */
#endif /* (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) ||
     defined(GCP_PKG_MGCO_TDMC)) */

/* RE regenerated */
#ifdef GCP_PKG_MGCO_ROOT



/*
*
*       Fun:   mgMgcoRegExpPropParmRoot
*
*       Desc:  Description for the regular expression PropParmRoot
*               MaxNrOfCxts=[Mm][Aa][Xx][Nn][Uu][Mm][Bb][Ee][Rr][Oo][Ff][Cc][Oo][Nn][Tt][Ee][Xx][Tt][Ss];
*               MaxTermsPerCxt=[Mm][Aa][Xx][Tt][Ee][Rr][Mm][Ii][Nn][Aa][Tt][Ii][Oo][Nn][Ss][Pp][Ee][Rr][Cc][Oo][Nn][Tt][Ee][Xx][Tt];
*               MGExecTime=[Nn][Oo][Rr][Mm][Aa][Ll][Mm][Gg][Ee][Xx][Ee][Cc][Uu][Tt][Ii][Oo][Nn][Tt][Ii][Mm][Ee];
*               MGCExecTime=[Nn][Oo][Rr][Mm][Aa][Ll][Mm][Gg][Cc][Ee][Xx][Ee][Cc][Uu][Tt][Ii][Oo][Nn][Tt][Ii][Mm][Ee];
*               MGProvRspTmrVal=[Mm][Gg][Pp][Rr][Oo][Vv][Ii][Ss][Ii][Oo][Nn][Aa][Ll][Rr][Ee][Ss][Pp][Oo][Nn][Ss][Ee][Tt][Ii][Mm][Ee][Rr][Vv][Aa][Ll][Uu][Ee];
*               MGCProvRspTmrVal=[Mm][Gg][Cc][Pp][Rr][Oo][Vv][Ii][Ss][Ii][Oo][Nn][Aa][Ll][Rr][Ee][Ss][Pp][Oo][Nn][Ss][Ee][Tt][Ii][Mm][Ee][Rr][Vv][Aa][Ll][Uu][Ee];
*               MGOriginatedPendingLimit=[Mm][gG][oO][Rr][Ii][Gg][Ii][Nn][Aa][Tt][Ee][Dd][pP][Ee][Nn][Dd][Ii][Nn][Gg][lL][Ii][Mm][Ii][Tt];
*               MGCOriginatedPendingLimit=[Mm][gG][Cc][oO][Rr][Ii][Gg][Ii][Nn][Aa][Tt][Ee][Dd][pP][Ee][Nn][Dd][Ii][Nn][Gg][lL][Ii][Mm][Ii][Tt];
*                 
*                 
*                MaxNrOfCxts            {return(MGT_PKG_ROOT_PROP_MAXNROFCXTS);}
*                MaxTermsPerCxt         {return(MGT_PKG_ROOT_PROP_MAXTERMSPERCXT);}
*                MGExecTime             {return(MGT_PKG_ROOT_PROP_MGEXECTIME);}
*                MGCExecTime            {return(MGT_PKG_ROOT_PROP_MGCEXECTIME);}
*                MGProvRspTmrVal        {return(MGT_PKG_ROOT_PROP_MGPROVRSPTMRVAL);}
*                MGCProvRspTmrVal       {return(MGT_PKG_ROOT_PROP_MGCPROVRSPTMRVAL);}
*                MGOriginatedPendingLimit{return(MGT_PKG_ROOT_PROP_MGORIGPENDLIMIT);}
*                MGCOriginatedPendingLimit{return(MGT_PKG_ROOT_PROP_MGCORIGPENDLIMIT);}
*              
*              
*              
*              
*              
*              
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPropParmRoot
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPropParmRoot(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMgcoRegExpPropParmRoot)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy3;
   case 'N':   case 'n':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy42;
   case 'G':   case 'g':   goto yy41;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy13;
   case 'E':   case 'e':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy28;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy15;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy19;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy20;
   default:   goto yyErr;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy21;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy22;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy24;
   default:   goto yyErr;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy25;
   default:   goto yyErr;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy26;
   default:   goto yyErr;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ROOT_PROP_MGCEXECTIME;
      goto yyReturn;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy29;
   default:   goto yyErr;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy30;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy31;
   default:   goto yyErr;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy32;
   default:   goto yyErr;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy33;
   default:   goto yyErr;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy34;
   default:   goto yyErr;
   }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy35;
   default:   goto yyErr;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy36;
   default:   goto yyErr;
   }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy37;
   default:   goto yyErr;
   }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy38;
   default:   goto yyErr;
   }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy39;
   default:   goto yyErr;
   }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ROOT_PROP_MGEXECTIME;
      goto yyReturn;
   }
yy41:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy85;
   case 'O':   case 'o':   goto yy86;
   case 'P':   case 'p':   goto yy84;
   default:   goto yyErr;
   }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy43;
   default:   goto yyErr;
   }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy45;
   case 'T':   case 't':   goto yy44;
   default:   goto yyErr;
   }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy62;
   default:   goto yyErr;
   }
yy45:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy46;
   default:   goto yyErr;
   }
yy46:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy47;
   default:   goto yyErr;
   }
yy47:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy48;
   default:   goto yyErr;
   }
yy48:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy49;
   default:   goto yyErr;
   }
yy49:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy50;
   default:   goto yyErr;
   }
yy50:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy51;
   default:   goto yyErr;
   }
yy51:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy52;
   default:   goto yyErr;
   }
yy52:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy53;
   default:   goto yyErr;
   }
yy53:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy54;
   default:   goto yyErr;
   }
yy54:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy55;
   default:   goto yyErr;
   }
yy55:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy56;
   default:   goto yyErr;
   }
yy56:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy57;
   default:   goto yyErr;
   }
yy57:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy58;
   default:   goto yyErr;
   }
yy58:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy59;
   default:   goto yyErr;
   }
yy59:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy60;
   default:   goto yyErr;
   }
yy60:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ROOT_PROP_MAXNROFCXTS;
      goto yyReturn;
   }
yy62:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy63;
   default:   goto yyErr;
   }
yy63:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy64;
   default:   goto yyErr;
   }
yy64:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy65;
   default:   goto yyErr;
   }
yy65:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy66;
   default:   goto yyErr;
   }
yy66:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy67;
   default:   goto yyErr;
   }
yy67:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy68;
   default:   goto yyErr;
   }
yy68:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy69;
   default:   goto yyErr;
   }
yy69:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy70;
   default:   goto yyErr;
   }
yy70:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy71;
   default:   goto yyErr;
   }
yy71:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy72;
   default:   goto yyErr;
   }
yy72:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy73;
   default:   goto yyErr;
   }
yy73:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy74;
   default:   goto yyErr;
   }
yy74:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy75;
   default:   goto yyErr;
   }
yy75:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy76;
   default:   goto yyErr;
   }
yy76:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy77;
   default:   goto yyErr;
   }
yy77:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy78;
   default:   goto yyErr;
   }
yy78:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy79;
   default:   goto yyErr;
   }
yy79:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy80;
   default:   goto yyErr;
   }
yy80:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy81;
   default:   goto yyErr;
   }
yy81:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy82;
   default:   goto yyErr;
   }
yy82:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ROOT_PROP_MAXTERMSPERCXT;
      goto yyReturn;
   }
yy84:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy162;
   default:   goto yyErr;
   }
yy85:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy109;
   case 'P':   case 'p':   goto yy110;
   default:   goto yyErr;
   }
yy86:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy87;
   default:   goto yyErr;
   }
yy87:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy88;
   default:   goto yyErr;
   }
yy88:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy89;
   default:   goto yyErr;
   }
yy89:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy90;
   default:   goto yyErr;
   }
yy90:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy91;
   default:   goto yyErr;
   }
yy91:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy92;
   default:   goto yyErr;
   }
yy92:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy93;
   default:   goto yyErr;
   }
yy93:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy94;
   default:   goto yyErr;
   }
yy94:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy95;
   default:   goto yyErr;
   }
yy95:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy96;
   default:   goto yyErr;
   }
yy96:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy97;
   default:   goto yyErr;
   }
yy97:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy98;
   default:   goto yyErr;
   }
yy98:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy99;
   default:   goto yyErr;
   }
yy99:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy100;
   default:   goto yyErr;
   }
yy100:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy101;
   default:   goto yyErr;
   }
yy101:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy102;
   default:   goto yyErr;
   }
yy102:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy103;
   default:   goto yyErr;
   }
yy103:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy104;
   default:   goto yyErr;
   }
yy104:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy105;
   default:   goto yyErr;
   }
yy105:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy106;
   default:   goto yyErr;
   }
yy106:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy107;
   default:   goto yyErr;
   }
yy107:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ROOT_PROP_MGORIGPENDLIMIT;
      goto yyReturn;
   }
yy109:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy140;
   default:   goto yyErr;
   }
yy110:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy111;
   default:   goto yyErr;
   }
yy111:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy112;
   default:   goto yyErr;
   }
yy112:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy113;
   default:   goto yyErr;
   }
yy113:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy114;
   default:   goto yyErr;
   }
yy114:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy115;
   default:   goto yyErr;
   }
yy115:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy116;
   default:   goto yyErr;
   }
yy116:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy117;
   default:   goto yyErr;
   }
yy117:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy118;
   default:   goto yyErr;
   }
yy118:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy119;
   default:   goto yyErr;
   }
yy119:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy120;
   default:   goto yyErr;
   }
yy120:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy121;
   default:   goto yyErr;
   }
yy121:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy122;
   default:   goto yyErr;
   }
yy122:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy123;
   default:   goto yyErr;
   }
yy123:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy124;
   default:   goto yyErr;
   }
yy124:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy125;
   default:   goto yyErr;
   }
yy125:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy126;
   default:   goto yyErr;
   }
yy126:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy127;
   default:   goto yyErr;
   }
yy127:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy128;
   default:   goto yyErr;
   }
yy128:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy129;
   default:   goto yyErr;
   }
yy129:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy130;
   default:   goto yyErr;
   }
yy130:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy131;
   default:   goto yyErr;
   }
yy131:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy132;
   default:   goto yyErr;
   }
yy132:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy133;
   default:   goto yyErr;
   }
yy133:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy134;
   default:   goto yyErr;
   }
yy134:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy135;
   default:   goto yyErr;
   }
yy135:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy136;
   default:   goto yyErr;
   }
yy136:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy137;
   default:   goto yyErr;
   }
yy137:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy138;
   default:   goto yyErr;
   }
yy138:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ROOT_PROP_MGCPROVRSPTMRVAL;
      goto yyReturn;
   }
yy140:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy141;
   default:   goto yyErr;
   }
yy141:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy142;
   default:   goto yyErr;
   }
yy142:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy143;
   default:   goto yyErr;
   }
yy143:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy144;
   default:   goto yyErr;
   }
yy144:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy145;
   default:   goto yyErr;
   }
yy145:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy146;
   default:   goto yyErr;
   }
yy146:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy147;
   default:   goto yyErr;
   }
yy147:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy148;
   default:   goto yyErr;
   }
yy148:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy149;
   default:   goto yyErr;
   }
yy149:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy150;
   default:   goto yyErr;
   }
yy150:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy151;
   default:   goto yyErr;
   }
yy151:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy152;
   default:   goto yyErr;
   }
yy152:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy153;
   default:   goto yyErr;
   }
yy153:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy154;
   default:   goto yyErr;
   }
yy154:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy155;
   default:   goto yyErr;
   }
yy155:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy156;
   default:   goto yyErr;
   }
yy156:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy157;
   default:   goto yyErr;
   }
yy157:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy158;
   default:   goto yyErr;
   }
yy158:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy159;
   default:   goto yyErr;
   }
yy159:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy160;
   default:   goto yyErr;
   }
yy160:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ROOT_PROP_MGCORIGPENDLIMIT;
      goto yyReturn;
   }
yy162:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy163;
   default:   goto yyErr;
   }
yy163:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy164;
   default:   goto yyErr;
   }
yy164:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy165;
   default:   goto yyErr;
   }
yy165:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy166;
   default:   goto yyErr;
   }
yy166:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy167;
   default:   goto yyErr;
   }
yy167:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy168;
   default:   goto yyErr;
   }
yy168:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy169;
   default:   goto yyErr;
   }
yy169:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy170;
   default:   goto yyErr;
   }
yy170:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy171;
   default:   goto yyErr;
   }
yy171:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy172;
   default:   goto yyErr;
   }
yy172:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy173;
   default:   goto yyErr;
   }
yy173:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy174;
   default:   goto yyErr;
   }
yy174:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy175;
   default:   goto yyErr;
   }
yy175:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy176;
   default:   goto yyErr;
   }
yy176:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy177;
   default:   goto yyErr;
   }
yy177:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy178;
   default:   goto yyErr;
   }
yy178:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy179;
   default:   goto yyErr;
   }
yy179:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy180;
   default:   goto yyErr;
   }
yy180:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy181;
   default:   goto yyErr;
   }
yy181:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy182;
   default:   goto yyErr;
   }
yy182:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy183;
   default:   goto yyErr;
   }
yy183:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy184;
   default:   goto yyErr;
   }
yy184:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy185;
   default:   goto yyErr;
   }
yy185:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy186;
   default:   goto yyErr;
   }
yy186:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy187;
   default:   goto yyErr;
   }
yy187:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy188;
   default:   goto yyErr;
   }
yy188:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy189;
   default:   goto yyErr;
   }
yy189:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ROOT_PROP_MGPROVRSPTMRVAL;
      goto yyReturn;
   }










yyReturn:
   CM_ABNF_DEC_CSPSTRXL(decCp, mem, len, yydecode);

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPropParmRoot */
#endif /* GCP_PKG_MGCO_ROOT */

#ifdef GCP_PKG_MGCO_TDMC
/*
*
*       Fun:   mgMgcoRegExpPropParmTdmc
*
*       Desc:  Description for the regular expression PropParmTdmc
*                [Jj][Ii][Tt] {return(MGT_PKG_NETWORK_PROP_JIT);}
*                [Ee][Cc]     {return(MGT_PKG_TDMC_PROP_EC);}
*                [Gg][Aa][Ii][Nn]   {return(MGT_PKG_TDMC_PROP_GAIN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpPropParmTdmc
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpPropParmTdmc(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpPropParmTdmc)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy4;
   case 'G':   case 'g':   goto yy5;
   case 'J':   case 'j':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy12;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy10;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TDMC_PROP_GAIN;
      goto yyReturn;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TDMC_PROP_EC;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_PROP_JIT;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpPropParmTdmc */
#endif /* GCP_PKG_MGCO_TDMC */

#ifdef GCP_PKG_MGCO_ANALOG
/*
*
*       Fun:   mgMgcoRegExpReqEvtOtherAnalogFlashHookPar
*
*       Desc:  Description for the regular expression ReqEvtOtherAnalogFlashHookPar
*                 mindur      = [Mm][Ii][Nn][Dd][Uu][Rr];
*                 maxdur      = [Mm][Aa][Xx][Dd][Uu][Rr];
*              
*                 mindur         {return(MGT_PKG_ANALOG_EVT_FLASHHOOK_MINDUR);}
*                 maxdur         {return(MGT_PKG_ANALOG_EVT_FLASHHOOK_MAXDUR);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpReqEvtOtherAnalogFlashHookPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpReqEvtOtherAnalogFlashHookPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpReqEvtOtherAnalogFlashHookPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy4;
   case 'I':   case 'i':   goto yy5;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy11;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ANALOG_EVT_FLASHHOOK_MINDUR;
      goto yyReturn;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy14;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ANALOG_EVT_FLASHHOOK_MAXDUR;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpReqEvtOtherAnalogFlashHookPar */
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_ANALOG
/*
*
*       Fun:   mgMgcoRegExpReqEvtOtherAnalogFlashHookType
*
*       Desc:  Description for the regular expression ReqEvtOtherAnalogFlashHookType
*                 mindur      = [Mm][Ii][Nn][Dd][Uu][Rr];
*                 maxdur      = [Mm][Aa][Xx][Dd][Uu][Rr];
*              
*                 known       = mindur | maxdur;
*                 all         = "*";
*                 unkn        = [0-9A-Za-z]+;
*              
*                 all         {return(MGT_GEN_TYPE_ALL);}
*                 known       {return(MGT_GEN_TYPE_KNOWN);}
*                 unkn        {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpReqEvtOtherAnalogFlashHookType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpReqEvtOtherAnalogFlashHookType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpReqEvtOtherAnalogFlashHookType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'M':   case 'm':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy9;
   case 'I':   case 'i':   goto yy10;
   default:   goto yy8;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy6;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy16;
   default:   goto yy8;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy11;
   default:   goto yy8;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy12;
   default:   goto yy8;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy13;
   default:   goto yy8;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy14;
   default:   goto yy8;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy15;
   }
yy15:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy17;
   default:   goto yy8;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy18;
   default:   goto yy8;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy14;
   default:   goto yy8;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpReqEvtOtherAnalogFlashHookType */
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_ANALOG
/*
*
*       Fun:   mgMgcoRegExpReqEvtOtherAnalogOnHookPar
*
*       Desc:  Description for the regular expression ReqEvtOtherAnalogOnHookPar
*              
*                strict    = [Ss][Tt][Rr][Ii][Cc][Tt];
*              
*                strict    {return(MGT_PKG_ANALOG_EVT_ONHOOK_STRICT);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpReqEvtOtherAnalogOnHookPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpReqEvtOtherAnalogOnHookPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpReqEvtOtherAnalogOnHookPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'S':   case 's':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ANALOG_EVT_ONHOOK_STRICT;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpReqEvtOtherAnalogOnHookPar */
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_ANALOG
/*
*
*       Fun:   mgMgcoRegExpReqEvtOtherAnalogOnHookStrictValue
*
*       Desc:  Description for the regular expression ReqEvtOtherAnalogOnHookStrictValue
*                exact     = [Ee][Xx][Aa][Cc][Tt];
*                state     = [Ss][Tt][Aa][Tt][Ee];
*                failWrong = [Ff][Aa][Ii][Ll][Ww][Rr][Oo][Nn][Gg];
*              
*                exact     {return(MGT_PKG_ANALOG_EVT_ONHOOK_STRICT_EXACT);}
*                state     {return(MGT_PKG_ANALOG_EVT_ONHOOK_STRICT_STATE);}
*                failWrong {return(MGT_PKG_ANALOG_EVT_ONHOOK_STRICT_FAILWRONG);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpReqEvtOtherAnalogOnHookStrictValue
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpReqEvtOtherAnalogOnHookStrictValue(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpReqEvtOtherAnalogOnHookStrictValue)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy3;
   case 'F':   case 'f':   goto yy5;
   case 'S':   case 's':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy20;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy15;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy9;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ANALOG_EVT_ONHOOK_STRICT_FAILWRONG;
      goto yyReturn;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ANALOG_EVT_ONHOOK_STRICT_STATE;
      goto yyReturn;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy21;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy22;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ANALOG_EVT_ONHOOK_STRICT_EXACT;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpReqEvtOtherAnalogOnHookStrictValue */
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_ANALOG

/*
*
*       Fun:   mgMgcoRegExpReqEvtOtherAnalogOnHookType
*
*       Desc:  Description for the regular expression ReqEvtOtherAnalogOnHookType
*              
*                strict    = [Ss][Tt][Rr][Ii][Cc][Tt];
*              
*                known     = strict;
*                all       = "*";
*                unkn      = [0-9A-Za-z]+;
*              
*                all       {return(MGT_GEN_TYPE_ALL);}
*                known     {return(MGT_GEN_TYPE_KNOWN);}
*                unkn      {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpReqEvtOtherAnalogOnHookType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpReqEvtOtherAnalogOnHookType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpReqEvtOtherAnalogOnHookType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'S':   case 's':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy9;
   default:   goto yy8;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy6;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy10;
   default:   goto yy8;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy11;
   default:   goto yy8;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy12;
   default:   goto yy8;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy13;
   default:   goto yy8;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy14;
   }
yy14:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpReqEvtOtherAnalogOnHookType */
#endif /* GCP_PKG_MGCO_ANALOG */

#if (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) || \
     defined(GCP_PKG_MGCO_TDMC))
/*
*
*       Fun:   mgMgcoRegExpReqEvtOtherNetworkQualertPar
*
*       Desc:  Description for the regular expression ReqEvtOtherNetworkQualertPar
*                [Tt][Hh]  {return(MGT_PKG_NETWORK_EVT_QUALERT_TH);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpReqEvtOtherNetworkQualertPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpReqEvtOtherNetworkQualertPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpReqEvtOtherNetworkQualertPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'T':   case 't':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_EVT_QUALERT_TH;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpReqEvtOtherNetworkQualertPar */
#endif /* (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) ||
     defined(GCP_PKG_MGCO_TDMC)) */

#if (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) || \
     defined(GCP_PKG_MGCO_TDMC))
/*
*
*       Fun:   mgMgcoRegExpReqEvtOtherNetworkQualertType
*
*       Desc:  Description for the regular expression ReqEvtOtherNetworkQualertType
*                [Tt][Hh]  {return(MGT_GEN_TYPE_KNOWN);}
*                "*"       {return(MGT_GEN_TYPE_ALL);}
*                [0-9A-Za-z]+ {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpReqEvtOtherNetworkQualertType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpReqEvtOtherNetworkQualertType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpReqEvtOtherNetworkQualertType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy5;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   case 'T':   case 't':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy9;
   default:   goto yy8;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy8:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy4;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy10;
   }
yy10:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpReqEvtOtherNetworkQualertType */
#endif /* (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) ||
     defined(GCP_PKG_MGCO_TDMC)) */

#if (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) || \
     defined(GCP_PKG_MGCO_CPDET))
/*
*
*       Fun:   mgMgcoRegExpReqEvtOtherToneDetLtdPar
*
*       Desc:  Description for the regular expression ReqEvtOtherToneDetLtdPar
*                tl  =  [Tt][Ll];
*                dur =  [Dd][Uu][Rr];
*              
*                tl  {return(MGT_PKG_TONEGEN_SIG_PT_TONEIDLST);}
*                dur {return(MGT_PKG_TONEDET_EVT_LTD_DUR);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpReqEvtOtherToneDetLtdPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpReqEvtOtherToneDetLtdPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpReqEvtOtherToneDetLtdPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy4;
   case 'T':   case 't':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy8;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEDET_EVT_LTD_DUR;
      goto yyReturn;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEGEN_SIG_PT_TONEIDLST;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpReqEvtOtherToneDetLtdPar */
#endif /* (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) ||
     defined(GCP_PKG_MGCO_CPDET)) */

#if (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) || \
     defined(GCP_PKG_MGCO_CPDET))
/*
*
*       Fun:   mgMgcoRegExpReqEvtOtherToneDetLtdType
*
*       Desc:  Description for the regular expression ReqEvtOtherToneDetLtdType
*                known  =  [Tt][Ll] | [Dd][Uu][Rr];
*                all    =  "*";
*                unkn   =  [0-9A-Za-z]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unkn   {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpReqEvtOtherToneDetLtdType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpReqEvtOtherToneDetLtdType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpReqEvtOtherToneDetLtdType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'D':   case 'd':   goto yy7;
   case 'T':   case 't':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy11;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy10;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy11;
   default:   goto yy9;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy12;
   }
yy12:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpReqEvtOtherToneDetLtdType */
#endif /* (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) ||
     defined(GCP_PKG_MGCO_CPDET)) */

#if (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) || \
     defined(GCP_PKG_MGCO_CPDET))
/*
*
*       Fun:   mgMgcoRegExpReqEvtOtherToneDetStdPar
*
*       Desc:  Description for the regular expression ReqEvtOtherToneDetStdPar
*                [Tt][Ll]  {return(MGT_PKG_TONEGEN_SIG_PT_TONEIDLST);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpReqEvtOtherToneDetStdPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpReqEvtOtherToneDetStdPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpReqEvtOtherToneDetStdPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'T':   case 't':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEGEN_SIG_PT_TONEIDLST;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpReqEvtOtherToneDetStdPar */
#endif /* (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) ||
     defined(GCP_PKG_MGCO_CPDET)) */

#if (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) || \
     defined(GCP_PKG_MGCO_CPDET))
/*
*
*       Fun:   mgMgcoRegExpReqEvtOtherToneDetStdType
*
*       Desc:  Description for the regular expression ReqEvtOtherToneDetStdType
*                known  =  [Tt][Ll];
*                all    =  "*";
*                unkn   =  [0-9A-Za-z]+;
*              
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unkn   {return(MGT_GEN_TYPE_UNKNOWN);}
*                all    {return(MGT_GEN_TYPE_ALL);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpReqEvtOtherToneDetStdType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpReqEvtOtherToneDetStdType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpReqEvtOtherToneDetStdType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy7;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy5;
   case 'T':   case 't':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy9;
   default:   goto yy6;
   }
yy4:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy5:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy6:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy5;
   default:   goto yy4;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy5;
   default:   goto yy10;
   }
yy10:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpReqEvtOtherToneDetStdType */
#endif /* (defined(GCP_PKG_MGCO_TONEDET) || defined(GCP_PKG_MGCO_DTMFDET) ||
     defined(GCP_PKG_MGCO_CPDET)) */

#ifdef GCP_PKG_MGCO_ANALOG
/*
*
*       Fun:   mgMgcoRegExpSigNameAnalog
*
*       Desc:  Description for the regular expression SigNameAnalog
*                [Rr][Ii]  {return(MGT_PKG_ANALOG_SIG_RI);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpSigNameAnalog
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpSigNameAnalog(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpSigNameAnalog)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ANALOG_SIG_RI;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpSigNameAnalog */
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_CONT
/*
*
*       Fun:   mgMgcoRegExpSigNameCont
*
*       Desc:  Description for the regular expression SigNameCont
*                [Cc][Tt]        {return(MGT_PKG_CONT_SIG_CT);}
*                [Rr][Ss][Pp]    {return(MGT_PKG_CONT_SIG_RSP);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpSigNameCont
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpSigNameCont(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpSigNameCont)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy3;
   case 'R':   case 'r':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy8;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_CONT_SIG_RSP;
      goto yyReturn;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_CONT_SIG_CT;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpSigNameCont */
#endif /* GCP_PKG_MGCO_CONT */

#ifdef GCP_PKG_MGCO_CPGEN
/*
*
*       Fun:   mgMgcoRegExpSigNameCpGen
*
*       Desc:  Description for the regular expression SigNameCpGen
*                [Dd]"0"         {return(MGT_PKG_TONEID_D0);}
*                [Dd]"1"         {return(MGT_PKG_TONEID_D1);}
*                [Dd]"2"         {return(MGT_PKG_TONEID_D2);}
*                [Dd]"3"         {return(MGT_PKG_TONEID_D3);}
*                [Dd]"4"         {return(MGT_PKG_TONEID_D4);}
*                [Dd]"5"         {return(MGT_PKG_TONEID_D5);}
*                [Dd]"6"         {return(MGT_PKG_TONEID_D6);}
*                [Dd]"7"         {return(MGT_PKG_TONEID_D7);}
*                [Dd]"8"         {return(MGT_PKG_TONEID_D8);}
*                [Dd]"9"         {return(MGT_PKG_TONEID_D9);}
*                [Dd][Aa]        {return(MGT_PKG_TONEID_DA);}
*                [Dd][Bb]        {return(MGT_PKG_TONEID_DB);}
*                [Dd][Cc]        {return(MGT_PKG_TONEID_DC);}
*                [Dd][Dd]        {return(MGT_PKG_TONEID_DD);}
*                [Dd][Ss]        {return(MGT_PKG_TONEID_DS);}
*                [Dd][Oo]        {return(MGT_PKG_TONEID_DO);}
*                [Dd][Tt]        {return(MGT_PKG_TONEID_DT);}
*                [Rr][Tt]        {return(MGT_PKG_TONEID_RT);}
*                [Bb][Tt]        {return(MGT_PKG_TONEID_BT);}
*                [Cc][Tt]        {return(MGT_PKG_TONEID_CT);}
*                [Ss][Ii][Tt]    {return(MGT_PKG_TONEID_SIT);}
*                [Ww][Tt]        {return(MGT_PKG_TONEID_WT);}
*                [Pp][Rr][Tt]    {return(MGT_PKG_TONEID_PT);}
*                [Cc][Ww]        {return(MGT_PKG_TONEID_CW);}
*                [Cc][Rr]        {return(MGT_PKG_TONEID_CR);}
*                [Pp][Tt]        {return(MGT_PKG_TONEGEN_SIG_PT);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpSigNameCpGen
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpSigNameCpGen(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpSigNameCpGen)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy5;
   case 'C':   case 'c':   goto yy6;
   case 'D':   case 'd':   goto yy3;
   case 'P':   case 'p':   goto yy9;
   case 'R':   case 'r':   goto yy4;
   case 'S':   case 's':   goto yy7;
   case 'W':   case 'w':   goto yy8;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy62;
   case '1':   goto yy60;
   case '2':   goto yy58;
   case '3':   goto yy56;
   case '4':   goto yy54;
   case '5':   goto yy52;
   case '6':   goto yy50;
   case '7':   goto yy48;
   case '8':   goto yy46;
   case '9':   goto yy44;
   case 'A':   case 'a':   goto yy42;
   case 'B':   case 'b':   goto yy40;
   case 'C':   case 'c':   goto yy38;
   case 'D':   case 'd':   goto yy36;
   case 'O':   case 'o':   goto yy32;
   case 'S':   case 's':   goto yy34;
   case 'T':   case 't':   goto yy30;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy28;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy26;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy20;
   case 'T':   case 't':   goto yy24;
   case 'W':   case 'w':   goto yy22;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy17;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy15;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy12;
   case 'T':   case 't':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEGEN_SIG_PT;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_PT;
      goto yyReturn;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_WT;
      goto yyReturn;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_SIT;
      goto yyReturn;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_CR;
      goto yyReturn;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_CW;
      goto yyReturn;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_CT;
      goto yyReturn;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_BT;
      goto yyReturn;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_RT;
      goto yyReturn;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DT;
      goto yyReturn;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DO;
      goto yyReturn;
   }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DS;
      goto yyReturn;
   }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DD;
      goto yyReturn;
   }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DC;
      goto yyReturn;
   }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DB;
      goto yyReturn;
   }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DA;
      goto yyReturn;
   }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D9;
      goto yyReturn;
   }
yy46:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D8;
      goto yyReturn;
   }
yy48:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D7;
      goto yyReturn;
   }
yy50:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D6;
      goto yyReturn;
   }
yy52:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D5;
      goto yyReturn;
   }
yy54:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D4;
      goto yyReturn;
   }
yy56:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D3;
      goto yyReturn;
   }
yy58:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D2;
      goto yyReturn;
   }
yy60:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D1;
      goto yyReturn;
   }
yy62:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D0;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpSigNameCpGen */
#endif /* GCP_PKG_MGCO_CPGEN */

#ifdef GCP_PKG_MGCO_DTMFGEN
/*
*
*       Fun:   mgMgcoRegExpSigNameDtmfGen
*
*       Desc:  Description for the regular expression SigNameDtmfGen
*                [Dd]"0"         {return(MGT_PKG_TONEID_D0);}
*                [Dd]"1"         {return(MGT_PKG_TONEID_D1);}
*                [Dd]"2"         {return(MGT_PKG_TONEID_D2);}
*                [Dd]"3"         {return(MGT_PKG_TONEID_D3);}
*                [Dd]"4"         {return(MGT_PKG_TONEID_D4);}
*                [Dd]"5"         {return(MGT_PKG_TONEID_D5);}
*                [Dd]"6"         {return(MGT_PKG_TONEID_D6);}
*                [Dd]"7"         {return(MGT_PKG_TONEID_D7);}
*                [Dd]"8"         {return(MGT_PKG_TONEID_D8);}
*                [Dd]"9"         {return(MGT_PKG_TONEID_D9);}
*                [Dd][Aa]        {return(MGT_PKG_TONEID_DA);}
*                [Dd][Bb]        {return(MGT_PKG_TONEID_DB);}
*                [Dd][Cc]        {return(MGT_PKG_TONEID_DC);}
*                [Dd][Dd]        {return(MGT_PKG_TONEID_DD);}
*                [Dd][Ss]        {return(MGT_PKG_TONEID_DS);}
*                [Dd][Oo]        {return(MGT_PKG_TONEID_DO);}
*                [Pp][Tt]        {return(MGT_PKG_TONEGEN_SIG_PT);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpSigNameDtmfGen
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpSigNameDtmfGen(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpSigNameDtmfGen)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy3;
   case 'P':   case 'p':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy37;
   case '1':   goto yy35;
   case '2':   goto yy33;
   case '3':   goto yy31;
   case '4':   goto yy29;
   case '5':   goto yy27;
   case '6':   goto yy25;
   case '7':   goto yy23;
   case '8':   goto yy21;
   case '9':   goto yy19;
   case 'A':   case 'a':   goto yy17;
   case 'B':   case 'b':   goto yy15;
   case 'C':   case 'c':   goto yy13;
   case 'D':   case 'd':   goto yy11;
   case 'O':   case 'o':   goto yy7;
   case 'S':   case 's':   goto yy9;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEGEN_SIG_PT;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DO;
      goto yyReturn;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DS;
      goto yyReturn;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DD;
      goto yyReturn;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DC;
      goto yyReturn;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DB;
      goto yyReturn;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DA;
      goto yyReturn;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D9;
      goto yyReturn;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D8;
      goto yyReturn;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D7;
      goto yyReturn;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D6;
      goto yyReturn;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D5;
      goto yyReturn;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D4;
      goto yyReturn;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D3;
      goto yyReturn;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D2;
      goto yyReturn;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D1;
      goto yyReturn;
   }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D0;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpSigNameDtmfGen */
#endif /* GCP_PKG_MGCO_DTMFGEN */

#if (defined(GCP_PKG_MGCO_TONEGEN) || defined(GCP_PKG_MGCO_DTMFGEN) || \
     defined(GCP_PKG_MGCO_CPGEN)   || defined(GCP_PKG_MGCO_TONEDET) || \
     defined(GCP_PKG_MGCO_DTMFDET) || defined(GCP_PKG_MGCO_CPDET))
/*
*
*       Fun:   mgMgcoRegExpSigNameToneGen
*
*       Desc:  Description for the regular expression SigNameToneGen
*                [Pp][Tt]  {return(MGT_PKG_TONEGEN_SIG_PT);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpSigNameToneGen
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpSigNameToneGen(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpSigNameToneGen)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEGEN_SIG_PT;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpSigNameToneGen */
#endif /* (defined(GCP_PKG_MGCO_TONEGEN) || defined(GCP_PKG_MGCO_DTMFGEN) 
        || defined(GCP_PKG_MGCO_CPGEN))  || defined(GCP_PKG_MGCO_TONEDET)
        || defined(GCP_PKG_MGCO_DTMFDET) || defined(GCP_PKG_MGCO_CPDET)) */

#ifdef GCP_PKG_MGCO_ANALOG
/*
*
*       Fun:   mgMgcoRegExpSigOtherAnalogRingPar
*
*       Desc:  Description for the regular expression SigOtherAnalogRingPar
*                cad    = [Cc][Aa][Dd];
*                freq   = [Ff][Rr][Ee][Qq];
*              
*                cad    {return(MGT_PKG_ANALOG_SIG_RI_CAD);}
*                freq   {return(MGT_PKG_ANALOG_SIG_RI_FREQ);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpSigOtherAnalogRingPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpSigOtherAnalogRingPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpSigOtherAnalogRingPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy3;
   case 'F':   case 'f':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy9;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Q':   case 'q':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ANALOG_SIG_RI_FREQ;
      goto yyReturn;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ANALOG_SIG_RI_CAD;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpSigOtherAnalogRingPar */
#endif /* GCP_PKG_MGCO_ANALOG */

#ifdef GCP_PKG_MGCO_ANALOG
/*
*
*       Fun:   mgMgcoRegExpSigOtherAnalogRingType
*
*       Desc:  Description for the regular expression SigOtherAnalogRingType
*                cad    = [Cc][Aa][Dd];
*                freq   = [Ff][Rr][Ee][Qq];
*              
*                known  = cad | freq;
*                all    = "*";
*                unkn   = [0-9A-Za-z]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unkn   {return(MGT_GEN_TYPE_UNKNOWN);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpSigOtherAnalogRingType
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpSigOtherAnalogRingType(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpSigOtherAnalogRingType)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':   case 'D':
   case 'E':   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':   case 'd':
   case 'e':   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'C':   case 'c':   goto yy5;
   case 'F':   case 'f':   goto yy7;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy14;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy10;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy11;
   default:   goto yy9;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Q':   case 'q':   goto yy12;
   default:   goto yy9;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy13;
   }
yy13:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy12;
   default:   goto yy9;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpSigOtherAnalogRingType */
#endif /* GCP_PKG_MGCO_ANALOG */

#if (defined(GCP_PKG_MGCO_TONEGEN) || defined(GCP_PKG_MGCO_DTMFGEN) || \
     defined(GCP_PKG_MGCO_CPGEN)   || defined(GCP_PKG_MGCO_TONEDET) || \
     defined(GCP_PKG_MGCO_DTMFDET) || defined(GCP_PKG_MGCO_CPDET))
/*
*
*       Fun:   mgMgcoRegExpSigOtherToneGenPt
*
*       Desc:  Description for the regular expression SigOtherToneGenPt
*                known = [Tt][Ll] | [Ii][Nn][Dd];
*                all   = "*";
*                unk   = [0-9A-Za-z]+;
*              
*                all    {return(MGT_GEN_TYPE_ALL);}
*                known  {return(MGT_GEN_TYPE_KNOWN);}
*                unk    {return(MGT_GEN_TYPE_UNKNOWN);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpSigOtherToneGenPt
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpSigOtherToneGenPt(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpSigOtherToneGenPt)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   case 'I':   case 'i':   goto yy7;
   case 'T':   case 't':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_GEN_TYPE_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy11;
   default:   goto yy9;
   }
yy6:
   {
      yyret = MGT_GEN_TYPE_UNKNOWN;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy10;
   default:   goto yy9;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy9:   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy6;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy11;
   default:   goto yy9;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy8;
   default:   goto yy12;
   }
yy12:
   {
      yyret = MGT_GEN_TYPE_KNOWN;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpSigOtherToneGenPt */
#endif /* (defined(GCP_PKG_MGCO_TONEGEN) || defined(GCP_PKG_MGCO_DTMFGEN) 
        || defined(GCP_PKG_MGCO_CPGEN))  || defined(GCP_PKG_MGCO_TONEDET)
        || defined(GCP_PKG_MGCO_DTMFDET) || defined(GCP_PKG_MGCO_CPDET)) */

#if (defined(GCP_PKG_MGCO_TONEGEN) || defined(GCP_PKG_MGCO_DTMFGEN) || \
     defined(GCP_PKG_MGCO_CPGEN)   || defined(GCP_PKG_MGCO_TONEDET) || \
     defined(GCP_PKG_MGCO_DTMFDET) || defined(GCP_PKG_MGCO_CPDET))
/*
*
*       Fun:   mgMgcoRegExpSigOtherToneGenPtPar
*
*       Desc:  Description for the regular expression SigOtherToneGenPtPar
*                [Tt][Ll]     {return(MGT_PKG_TONEGEN_SIG_PT_TONEIDLST);}
*                [Ii][Nn][Dd] {return(MGT_PKG_TONEGEN_SIG_PT_INTERSIGDURATION);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpSigOtherToneGenPtPar
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpSigOtherToneGenPtPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpSigOtherToneGenPtPar)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy4;
   case 'T':   case 't':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy8;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy5;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy6;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEGEN_SIG_PT_INTERSIGDURATION;
      goto yyReturn;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEGEN_SIG_PT_TONEIDLST;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpSigOtherToneGenPtPar */
#endif /* (defined(GCP_PKG_MGCO_TONEGEN) || defined(GCP_PKG_MGCO_DTMFGEN) 
        || defined(GCP_PKG_MGCO_CPGEN))  || defined(GCP_PKG_MGCO_TONEDET)
        || defined(GCP_PKG_MGCO_DTMFDET) || defined(GCP_PKG_MGCO_CPDET)) */

#if (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) || \
     defined(GCP_PKG_MGCO_TDMC))
/*
*
*       Fun:   mgMgcoRegExpStatsParNetwork
*
*       Desc:  Description for the regular expression StatsParNetwork
*                dur    = [Dd][Uu][Rr];
*                os     = [Oo][Ss];
*                or     = [Oo][Rr];
*              
*                dur       {return(MGT_PKG_NETWORK_STATS_DUR);}
*                os        {return(MGT_PKG_NETWORK_STATS_OS);}
*                or        {return(MGT_PKG_NETWORK_STATS_OR);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpStatsParNetwork
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpStatsParNetwork(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpStatsParNetwork)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy3;
   case 'O':   case 'o':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy9;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy5;
   case 'S':   case 's':   goto yy7;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_STATS_OR;
      goto yyReturn;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_STATS_OS;
      goto yyReturn;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_STATS_DUR;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpStatsParNetwork */
#endif /* (defined(GCP_PKG_MGCO_NETWORK) || defined(GCP_PKG_MGCO_RTP) ||
     defined(GCP_PKG_MGCO_TDMC)) */

#ifdef GCP_PKG_MGCO_RTP
/*
*
*       Fun:   mgMgcoRegExpStatsParRtp
*
*       Desc:  Description for the regular expression StatsParRtp
*                dur    = [Dd][Uu][Rr];
*                os     = [Oo][Ss];
*                or     = [Oo][Rr];
*                ps     = [Pp][Ss];
*                pr     = [Pp][Rr];
*                pl     = [Pp][Ll];
*                jit    = [Jj][Ii][Tt];
*                delay  = [Dd][Ee][Ll][Aa][Yy];
*              
*                dur       {return(MGT_PKG_NETWORK_STATS_DUR);}
*                os        {return(MGT_PKG_NETWORK_STATS_OS);}
*                or        {return(MGT_PKG_NETWORK_STATS_OR);}
*                ps        {return(MGT_PKG_RTP_STATS_PS);}
*                pr        {return(MGT_PKG_RTP_STATS_PR);}
*                pl        {return(MGT_PKG_RTP_STATS_PL);}
*                jit       {return(MGT_PKG_RTP_STATS_JIT);}
*                delay     {return(MGT_PKG_RTP_STATS_DELAY);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpStatsParRtp
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpStatsParRtp(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpStatsParRtp)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy3;
   case 'J':   case 'j':   goto yy6;
   case 'O':   case 'o':   goto yy4;
   case 'P':   case 'p':   goto yy5;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy20;
   case 'U':   case 'u':   goto yy21;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy16;
   case 'S':   case 's':   goto yy18;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy10;
   case 'R':   case 'r':   goto yy12;
   case 'S':   case 's':   goto yy14;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_RTP_STATS_JIT;
      goto yyReturn;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_RTP_STATS_PL;
      goto yyReturn;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_RTP_STATS_PR;
      goto yyReturn;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_RTP_STATS_PS;
      goto yyReturn;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_STATS_OR;
      goto yyReturn;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_STATS_OS;
      goto yyReturn;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy24;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy22;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_NETWORK_STATS_DUR;
      goto yyReturn;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy25;
   default:   goto yyErr;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy26;
   default:   goto yyErr;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_RTP_STATS_DELAY;
      goto yyReturn;
   }




yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpStatsParRtp */
#endif /* GCP_PKG_MGCO_RTP */




/*
 * [TEL]: Enhanced to take care of extended Tone ID's
 */


/*
*
*       Fun:   mgMgcoRegExpToneID
*
*       Desc:  Description for the regular expression ToneID
*               
*              
*                 "*"             {return(MGT_PKG_TONEID_ALL);}
*                 [Dd]"0"         {return(MGT_PKG_TONEID_D0);}
*                 [Dd]"1"         {return(MGT_PKG_TONEID_D1);}
*                 [Dd]"2"         {return(MGT_PKG_TONEID_D2);}
*                 [Dd]"3"         {return(MGT_PKG_TONEID_D3);}
*                 [Dd]"4"         {return(MGT_PKG_TONEID_D4);}
*                 [Dd]"5"         {return(MGT_PKG_TONEID_D5);}
*                 [Dd]"6"         {return(MGT_PKG_TONEID_D6);}
*                 [Dd]"7"         {return(MGT_PKG_TONEID_D7);}
*                 [Dd]"8"         {return(MGT_PKG_TONEID_D8);}
*                 [Dd]"9"         {return(MGT_PKG_TONEID_D9);}
*                 [Dd][Aa]        {return(MGT_PKG_TONEID_DA);}
*                 [Dd][Bb]        {return(MGT_PKG_TONEID_DB);}
*                 [Dd][Cc]        {return(MGT_PKG_TONEID_DC);}
*                 [Dd][Dd]        {return(MGT_PKG_TONEID_DD);}
*                 [Dd][Ss]        {return(MGT_PKG_TONEID_DS);}
*                 [Dd][Oo]        {return(MGT_PKG_TONEID_DO);}
*                 [Dd][Tt]        {return(MGT_PKG_TONEID_DT);}
*                 [Rr][Tt]        {return(MGT_PKG_TONEID_RT);}
*                 [Bb][Tt]        {return(MGT_PKG_TONEID_BT);}
*                 [Cc][Tt]        {return(MGT_PKG_TONEID_CT);}
*                 [Ss][Ii][Tt]    {return(MGT_PKG_TONEID_SIT);}
*                 [Ww][Tt]        {return(MGT_PKG_TONEID_WT);}
*                 [Pp][Rr][Tt]    {return(MGT_PKG_TONEID_PT);}
*                 [Cc][Ww]        {return(MGT_PKG_TONEID_CW);}
*                 [Cc][Rr]        {return(MGT_PKG_TONEID_CR);}
*                 [Bb][Dd][Tt]    {return(MGT_PKG_TONEID_BDT);}
*                 [Bb][Rr][Tt]    {return(MGT_PKG_TONEID_BRT);}
*                 [Bb][Bb][Tt]    {return(MGT_PKG_TONEID_BBT);}
*                 [Bb][Cc][Tt]    {return(MGT_PKG_TONEID_BCT);}
*                 [Bb][Ss][Ii][Tt]    {return(MGT_PKG_TONEID_BSIT);}
*                 [Bb][Ww][Tt]    {return(MGT_PKG_TONEID_BWT);}
*                 [Bb][Pp][Tt]    {return(MGT_PKG_TONEID_BPT);}
*                 [Bb][Cc][Ww]    {return(MGT_PKG_TONEID_BCW);}
*                 [Bb][Cc][Rr]    {return(MGT_PKG_TONEID_BCR);}
*                 [Bb][Pp][Yy]    {return(MGT_PKG_TONEID_BPY);}
*                 [Ee][Nn][Tt][Ee][Rr]    {return(MGT_PKG_TONEID_ENTER);}
*                 [Ee][Xx][Ii][Tt]    {return(MGT_PKG_TONEID_EXIT);}
*                 [Ll][Oo][Cc][Kk]    {return(MGT_PKG_TONEID_LOCK);}
*                 [Uu][Nn][Ll][Oo][Cc][Kk]    {return(MGT_PKG_TONEID_UNLOCK);}
*                 [Tt][Ii][Mm][Ee][Ll][Ii][Mm]    {return(MGT_PKG_TONEID_TIMELIM);}
*                 [Ll][Oo][Ww]    {return(MGT_PKG_TONEID_LOW);}
*                 [Hh][Ii][Gg][Hh]    {return(MGT_PKG_TONEID_HIGH);}
*                 [Ll][Oo][Uu][Dd]    {return(MGT_PKG_TONEID_LOUD);}
*                 [Ff][Aa][Ii][Nn][Tt]    {return(MGT_PKG_TONEID_FAINT);}
*                 [Ss][Ll][Oo][Ww]    {return(MGT_PKG_TONEID_SLOW);}
*                 [Ff][Aa][Ss][Tt]    {return(MGT_PKG_TONEID_FAST);}
*                 [Cc][Dd][Tt]    {return(MGT_PKG_TONEID_CDT);}
*                 [Aa][Nn][Ss]    {return(MGT_PKG_TONEID_ANS);}
*                 [Cc][Hh][Gg]    {return(MGT_PKG_TONEID_CHG);}
*                 [Ll][Dd][Ii]    {return(MGT_PKG_TONEID_LDI);}
*                 [Mm][Ff][0]     {return(MGT_PKG_TONEID_MF0);}
*                 [Mm][Ff][1]     {return(MGT_PKG_TONEID_MF1);}
*                 [Mm][Ff][2]     {return(MGT_PKG_TONEID_MF2);}
*                 [Mm][Ff][3]     {return(MGT_PKG_TONEID_MF3);}
*                 [Mm][Ff][4]     {return(MGT_PKG_TONEID_MF4);}
*                 [Mm][Ff][5]     {return(MGT_PKG_TONEID_MF5);}
*                 [Mm][Ff][6]     {return(MGT_PKG_TONEID_MF6);}
*                 [Mm][Ff][7]     {return(MGT_PKG_TONEID_MF7);}
*                 [Mm][Ff][8]     {return(MGT_PKG_TONEID_MF8);}
*                 [Mm][Ff][9]     {return(MGT_PKG_TONEID_MF9);}
*                 [Mm][Ff][Aa]    {return(MGT_PKG_TONEID_MFA);}
*                 [Mm][Ff][Bb]    {return(MGT_PKG_TONEID_MFB);}
*                 [Mm][Ff][Cc]    {return(MGT_PKG_TONEID_MFC);}
*                 [Mm][Ff][Dd]    {return(MGT_PKG_TONEID_MFD);}
*                 [Mm][Ff][Ee]    {return(MGT_PKG_TONEID_MFE);}
*                 [Mm][Ff][Ff]    {return(MGT_PKG_TONEID_MFF);}
*                 [Mm][Ff][Gg]    {return(MGT_PKG_TONEID_MFG);}
*                 [Mm][Ff][Hh]    {return(MGT_PKG_TONEID_MFH);}
*              
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpToneID
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpToneID(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMgcoRegExpToneID)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '*':   goto yy3;
   case 'A':   case 'a':   goto yy18;
   case 'B':   case 'b':   goto yy7;
   case 'C':   case 'c':   goto yy8;
   case 'D':   case 'd':   goto yy5;
   case 'E':   case 'e':   goto yy12;
   case 'F':   case 'f':   goto yy17;
   case 'H':   case 'h':   goto yy16;
   case 'L':   case 'l':   goto yy13;
   case 'M':   case 'm':   goto yy19;
   case 'P':   case 'p':   goto yy11;
   case 'R':   case 'r':   goto yy6;
   case 'S':   case 's':   goto yy9;
   case 'T':   case 't':   goto yy15;
   case 'U':   case 'u':   goto yy14;
   case 'W':   case 'w':   goto yy10;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_ALL;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy194;
   case '1':   goto yy192;
   case '2':   goto yy190;
   case '3':   goto yy188;
   case '4':   goto yy186;
   case '5':   goto yy184;
   case '6':   goto yy182;
   case '7':   goto yy180;
   case '8':   goto yy178;
   case '9':   goto yy176;
   case 'A':   case 'a':   goto yy174;
   case 'B':   case 'b':   goto yy172;
   case 'C':   case 'c':   goto yy170;
   case 'D':   case 'd':   goto yy168;
   case 'O':   case 'o':   goto yy164;
   case 'S':   case 's':   goto yy166;
   case 'T':   case 't':   goto yy162;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy160;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy134;
   case 'C':   case 'c':   goto yy131;
   case 'D':   case 'd':   goto yy136;
   case 'P':   case 'p':   goto yy130;
   case 'R':   case 'r':   goto yy135;
   case 'S':   case 's':   goto yy133;
   case 'T':   case 't':   goto yy137;
   case 'W':   case 'w':   goto yy132;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy119;
   case 'H':   case 'h':   goto yy118;
   case 'R':   case 'r':   goto yy120;
   case 'T':   case 't':   goto yy124;
   case 'W':   case 'w':   goto yy122;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy112;
   case 'L':   case 'l':   goto yy111;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy109;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy106;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy98;
   case 'X':   case 'x':   goto yy97;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy85;
   case 'O':   case 'o':   goto yy86;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy79;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy72;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy68;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy60;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy57;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy20;
   default:   goto yyErr;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':   goto yy21;
   case '1':   goto yy23;
   case '2':   goto yy25;
   case '3':   goto yy27;
   case '4':   goto yy29;
   case '5':   goto yy31;
   case '6':   goto yy33;
   case '7':   goto yy35;
   case '8':   goto yy37;
   case '9':   goto yy39;
   case 'A':   case 'a':   goto yy41;
   case 'B':   case 'b':   goto yy43;
   case 'C':   case 'c':   goto yy45;
   case 'D':   case 'd':   goto yy47;
   case 'E':   case 'e':   goto yy49;
   case 'F':   case 'f':   goto yy51;
   case 'G':   case 'g':   goto yy53;
   case 'H':   case 'h':   goto yy55;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MF0;
      goto yyReturn;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MF1;
      goto yyReturn;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MF2;
      goto yyReturn;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MF3;
      goto yyReturn;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MF4;
      goto yyReturn;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MF5;
      goto yyReturn;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MF6;
      goto yyReturn;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MF7;
      goto yyReturn;
   }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MF8;
      goto yyReturn;
   }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MF9;
      goto yyReturn;
   }
yy41:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MFA;
      goto yyReturn;
   }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MFB;
      goto yyReturn;
   }
yy45:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MFC;
      goto yyReturn;
   }
yy47:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MFD;
      goto yyReturn;
   }
yy49:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MFE;
      goto yyReturn;
   }
yy51:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MFF;
      goto yyReturn;
   }
yy53:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MFG;
      goto yyReturn;
   }
yy55:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_MFH;
      goto yyReturn;
   }
yy57:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy58;
   default:   goto yyErr;
   }
yy58:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_ANS;
      goto yyReturn;
   }
yy60:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy61;
   case 'S':   case 's':   goto yy62;
   default:   goto yyErr;
   }
yy61:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy65;
   default:   goto yyErr;
   }
yy62:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy63;
   default:   goto yyErr;
   }
yy63:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_FAST;
      goto yyReturn;
   }
yy65:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy66;
   default:   goto yyErr;
   }
yy66:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_FAINT;
      goto yyReturn;
   }
yy68:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy69;
   default:   goto yyErr;
   }
yy69:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy70;
   default:   goto yyErr;
   }
yy70:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_HIGH;
      goto yyReturn;
   }
yy72:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy73;
   default:   goto yyErr;
   }
yy73:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy74;
   default:   goto yyErr;
   }
yy74:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy75;
   default:   goto yyErr;
   }
yy75:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy76;
   default:   goto yyErr;
   }
yy76:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy77;
   default:   goto yyErr;
   }
yy77:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_TIMELIM;
      goto yyReturn;
   }
yy79:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy80;
   default:   goto yyErr;
   }
yy80:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy81;
   default:   goto yyErr;
   }
yy81:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy82;
   default:   goto yyErr;
   }
yy82:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy83;
   default:   goto yyErr;
   }
yy83:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_UNLOCK;
      goto yyReturn;
   }
yy85:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy95;
   default:   goto yyErr;
   }
yy86:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy87;
   case 'U':   case 'u':   goto yy90;
   case 'W':   case 'w':   goto yy88;
   default:   goto yyErr;
   }
yy87:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy93;
   default:   goto yyErr;
   }
yy88:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_LOW;
      goto yyReturn;
   }
yy90:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy91;
   default:   goto yyErr;
   }
yy91:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_LOUD;
      goto yyReturn;
   }
yy93:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_LOCK;
      goto yyReturn;
   }
yy95:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_LDI;
      goto yyReturn;
   }
yy97:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy103;
   default:   goto yyErr;
   }
yy98:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy99;
   default:   goto yyErr;
   }
yy99:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy100;
   default:   goto yyErr;
   }
yy100:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy101;
   default:   goto yyErr;
   }
yy101:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_ENTER;
      goto yyReturn;
   }
yy103:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy104;
   default:   goto yyErr;
   }
yy104:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_EXIT;
      goto yyReturn;
   }
yy106:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy107;
   default:   goto yyErr;
   }
yy107:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_PT;
      goto yyReturn;
   }
yy109:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_WT;
      goto yyReturn;
   }
yy111:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy115;
   default:   goto yyErr;
   }
yy112:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy113;
   default:   goto yyErr;
   }
yy113:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_SIT;
      goto yyReturn;
   }
yy115:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy116;
   default:   goto yyErr;
   }
yy116:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_SLOW;
      goto yyReturn;
   }
yy118:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy128;
   default:   goto yyErr;
   }
yy119:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy126;
   default:   goto yyErr;
   }
yy120:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_CR;
      goto yyReturn;
   }
yy122:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_CW;
      goto yyReturn;
   }
yy124:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_CT;
      goto yyReturn;
   }
yy126:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_CDT;
      goto yyReturn;
   }
yy128:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_CHG;
      goto yyReturn;
   }
yy130:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy156;
   case 'Y':   case 'y':   goto yy158;
   default:   goto yyErr;
   }
yy131:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy154;
   case 'T':   case 't':   goto yy150;
   case 'W':   case 'w':   goto yy152;
   default:   goto yyErr;
   }
yy132:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy148;
   default:   goto yyErr;
   }
yy133:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy145;
   default:   goto yyErr;
   }
yy134:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy143;
   default:   goto yyErr;
   }
yy135:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy141;
   default:   goto yyErr;
   }
yy136:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy139;
   default:   goto yyErr;
   }
yy137:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_BT;
      goto yyReturn;
   }
yy139:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_BDT;
      goto yyReturn;
   }
yy141:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_BRT;
      goto yyReturn;
   }
yy143:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_BBT;
      goto yyReturn;
   }
yy145:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy146;
   default:   goto yyErr;
   }
yy146:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_BSIT;
      goto yyReturn;
   }
yy148:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_BWT;
      goto yyReturn;
   }
yy150:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_BCT;
      goto yyReturn;
   }
yy152:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_BCW;
      goto yyReturn;
   }
yy154:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_BCR;
      goto yyReturn;
   }
yy156:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_BPT;
      goto yyReturn;
   }
yy158:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_BPY;
      goto yyReturn;
   }
yy160:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_RT;
      goto yyReturn;
   }
yy162:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DT;
      goto yyReturn;
   }
yy164:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DO;
      goto yyReturn;
   }
yy166:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DS;
      goto yyReturn;
   }
yy168:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DD;
      goto yyReturn;
   }
yy170:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DC;
      goto yyReturn;
   }
yy172:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DB;
      goto yyReturn;
   }
yy174:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_DA;
      goto yyReturn;
   }
yy176:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D9;
      goto yyReturn;
   }
yy178:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D8;
      goto yyReturn;
   }
yy180:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D7;
      goto yyReturn;
   }
yy182:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D6;
      goto yyReturn;
   }
yy184:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D5;
      goto yyReturn;
   }
yy186:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D4;
      goto yyReturn;
   }
yy188:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D3;
      goto yyReturn;
   }
yy190:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D2;
      goto yyReturn;
   }
yy192:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D1;
      goto yyReturn;
   }
yy194:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_TONEID_D0;
      goto yyReturn;
   }
 


yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpToneID */


/*
*
*       Fun:   mgMgcoRegExpIntFrac
*
*       Desc:  Description for the regular expression IntFrac
*                integ     =  [0-9]+;
*                intfrac   =  (integ | (integ)"." | "."(integ) | (integ)"."(integ));
*              
*                intfrac   {return(1);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  mgco_prx.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpIntFrac
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpIntFrac(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;

   TRC2(mgMgcoRegExpIntFrac)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '.':   goto yy6;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy3;
   default:   goto yyErr;
   }
yy3:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '.':   goto yy9;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy3;
   default:   goto yy5;
   }
yy5:
   {
      yyret = 1;
      goto yyReturn;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy7;
   default:   goto yyErr;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy7;
   default:   goto yy5;
   }
yy9:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy9;
   default:   goto yy5;
   }




yyReturn:
   CM_ABNF_DEC_CSPSTRXL(decCp, mem, len, yydecode);

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpIntFrac */


/*
*
*       Fun:   mgMgcoRegExpOffOn
*
*       Desc:  Description for the regular expression OffOn
*               [Oo][Ff][Ff]           {return(MGT_PKG_OFF);}
*               [Oo][Nn]               {return(MGT_PKG_ON); }
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {mgco_prx.c}
*
*/

#ifdef ANSI
PUBLIC S16 mgMgcoRegExpOffOn
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 mgMgcoRegExpOffOn(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(mgMgcoRegExpOffOn)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy6;
   case 'N':   case 'n':   goto yy4;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_ON;
      goto yyReturn;
    }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy7;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = MGT_PKG_OFF;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* mgMgcoRegExpOffOn */

#endif /* GCP_MGCO */

/********************************************************************30**

         End of file:     mgco_prx.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:52:09 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      nct  1. Initial version
          mg002.102   sk   1. Changed Regular Exp. Function 
                              mgMgcoRegExpObsEvtOtherDtmfDetCeDigitStringValue  
                      sk   2. Added new RegExp Function mgMgcoRegExpOffOn 
/main/2      ---      ra   1. GCP 1.3 release
/main/2    mg003.103  ra   1. Changed ALL function definations to return S16
                              instead of S8. Changed the type of yyret type
                              variables to S16.
           mg006.103  ra   1. Regenerated REs -
                              mgMgcoRegExpPkgRootPropType
                              mgMgcoRegExpPropParmRoot
                              to reflect the changed package definitions.
                           2. Regenerated RE -
                              mgMgcoRegExpEvtOtherGenericSigComplType
                              to fix a bug.
/main/3      ---      TEL  1. Function mgMgcoRegExpToneID enhanced to take 
                              care of extended Tone ID's defined in 
                              Basic call progress tone generator with 
                              directionality package.
                      TEL2    Conferencing tones generatation package
                              Diagnostic tones generatation package
                              Carrier tones generatation package
                              Multi-Frequency tones generatation package
/main/3      ---       ka  1. Changes for Release v 1.4
/main/4      ---      pk   1. GCP 1.5 release
          mg002.105   ps   1. Removed patch reference for 1.3
*********************************************************************91*/
