/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:    GCP - lower interface
  
     Type:    C source file
  
     Desc:    C source code for MGCP Lower interface

     File:    mg_ptli.c

     Sid:      mg_ptli.c@@/main/6 - Wed Mar 30 07:52:40 2005
  
     Prg:     rrp
  
*********************************************************************21*/
 

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "cm5.h"           /* common timer library */
#include "cm_hash.h"       /* common hash library */
#include "cm_llist.h"      /* common linked list library */
#include "cm_inet.h"       /* common socket library */
#include "cm_tpt.h"        /* common transport library */
#include "cm_tkns.h"       /* common tokens */
#include "cm_mblk.h"       /* common mem alloc defines */
#include "cm_abnf.h"
#include "cm_dns.h"        /* common DNS library defines */
#include "cm_sdp.h"        /* SDP module */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || RUG) */
#include "sct.h"           /* SCT interface */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.h"        /* Common SS7 defines */
#include "snt.h"           /* MTP3 Interface defines */
#endif   /* GCP_PROV_MTP3 */

#include "mgt.h"           /* MGP upper interface */
#include "lmg.h"           /* MGP layer management */
#include "hit.h"           /* MGP lower interface */
#include "mg.h"            /* MGP */
#include "mg_err.h"        /* MGP error */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "cm5.x"           /* common timer library */
#include "cm_lib.x"        /* common 'C' library */
#include "cm_hash.x"       /* common hash library */
#include "cm_llist.x"      /* common linked list library */
#include "cm_inet.x"       /* common socket library */
#include "cm_tpt.x"        /* common transport library */
#include "cm_tkns.x"       /* common tokens */
#include "cm_mblk.x"       /* common mem alloc defines */
#include "cm_abnf.x"
#include "cm_dns.x"        /* common DNS library defines */
#include "cm_sdp.x"        /* SDP module */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || RUG) */
#include "sct.x"           /* SCT interface */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.x"        /* Common SS7 structure */
#include "snt.x"           /* MTP3 Interface structure */
#endif   /* GCP_PROV_MTP3 */

#include "mgt.x"           /* MGCP upper interface */
#include "lmg.x"           /* MGCP layer management */
#include "hit.x"           /* MGCP lower interface */
#include "mg.x"            /* MGCP */
#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */

#ifdef L4
#include "l4.x"            /* Acceptance Test Transport Layer */
#endif /* L4 */



/* local defines */

#define MG_MAX_SCT_SEL               3
#define MG_MAX_SNT_SEL               3

#ifndef LCMGLIHIT
#ifndef PTMGLIHIT
#define PTMGLIHIT          /* portable, GCP, lower HIT interface */
#endif
#else
#ifndef HI 
#ifndef PTMGLIHIT
#define PTMGLIHIT          /* portable, GCP, lower HIT interface */
#endif
#else
#ifndef L4
#ifndef PTMGLIHIT
#define PTMGLIHIT          /* portable, GCP, lower HIT interface */
#endif
#endif
#endif
#endif


#ifndef LCMGLISCT
#ifndef PTMGLISCT
#define PTMGLISCT          /* portable, GCP, lower SCT interface */
#endif
#else
#ifndef SB
#ifndef PTMGLISCT
#define PTMGLISCT          /* portable, GCP, lower SCT interface */
#endif
#else
#ifndef L4
#ifndef PTMGLISCT
#define PTMGLISCT          /* portable, GCP, lower SCT interface */
#endif
#endif
#endif
#endif

/* Portable Lower Interface Flag Define for MTP3 */

#ifndef LCMGLISNT
#ifndef PTMGLISNT
#define PTMGLISNT          /* portable, GCP, lower SNT interface */
#endif
#else
#ifndef SN
#ifndef PTMGLISNT
#define PTMGLISNT          /* portable, GCP, lower SNT interface */
#endif
#endif
#endif

#ifndef IT
#ifndef PTMGLISNT
#define PTMGLISNT          /* portable, GCP, lower SNT interface */
#endif
#endif



/* local typedefs */

/* local externs */
  
/* forward references */

/* local function definition */

#ifdef PTMGLIHIT

/* portable functions */

PRIVATE S16 PtLiHitBndReq       ARGS((Pst *post, SuId suId, SpId spId));

PRIVATE S16 PtLiHitUbndReq      ARGS((Pst *post, SpId spId, Reason reason));

PRIVATE S16 PtLiHitServOpenReq  ARGS((Pst *post, SpId spId, UConnId servConId,
                                     CmTptAddr *servTAddr, CmTptParam *tPar,
                                     CmIcmpFilter *icmpFilter, U8 srvcType));

#ifdef HI_REL_1_4
PRIVATE S16 PtLiHitUDatReq      ARGS((Pst *post, SpId spId,UConnId spConId,
                                     CmTptAddr *remAddr, CmTptAddr *srcAddr, 
                                     CmIpHdrParm *hdrParm,
                                     CmTptParam *tPar,
                                     Buffer *mBuf));

#else
PRIVATE S16 PtLiHitUDatReq      ARGS((Pst *post, SpId spId,UConnId spConId,
                                     CmTptAddr *remAddr, CmTptAddr *srcAddr, 
                                     CmIpHdrParm *hdrParm,
                                     Buffer *mBuf));
#endif

PRIVATE S16 PtLiHitDiscReq      ARGS((Pst *post, SpId spId, U8 choice,
                                     UConnId conId, Action action,
                                     CmTptParam *tPar));

PRIVATE S16 PtLiHitConReq       ARGS((Pst *post, SpId spId, UConnId suConId,
                                     CmTptAddr *remAddr, CmTptAddr *localAddr,
                                     CmTptParam *tPar, U8 srvcType));

PRIVATE S16 PtLiHitConRsp       ARGS((Pst *post, SpId spId, UConnId suConId,
                                     UConnId spConId));

PRIVATE S16 PtLiHitDatReq       ARGS((Pst *post, SpId spId, UConnId spConId, 
                                      Buffer *mBuf));
#endif /* PTMGLIHIT */



#ifdef GCP_PROV_SCTP

#ifdef PTMGLISCT

/* portable functions */


PRIVATE S16 PtLiSctBndReq            ARGS((Pst           *pst,
                                          SuId           suId,
                                          SpId           spId));


PRIVATE S16 PtLiSctEndpOpenReq       ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        suEndpId,
                                          SctPort        port,
                                          CmNetAddr     *intfNAddr));



PRIVATE S16 PtLiSctEndpCloseReq      ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        endpId,
                                          U8             endpIdType));



PRIVATE S16 PtLiSctAssocReq          ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        spEndpId,
                                          UConnId        suAssocId,
                                          CmNetAddr     *priDstNAddr,
                                          SctPort        dstPort,
                                          SctStrmId      outStrms,
                                          SctNetAddrLst *dstNAddrLst,
                                          SctNetAddrLst *srcNAddrLst,
                                          Buffer        *vsInfo));



PRIVATE S16 PtLiSctAssocRsp          ARGS((Pst               *pst,
                                          SpId               spId,
                                          UConnId            spEndpId,
                                          SctAssocIndParams *assocIndParams,
                                          SctResult          result,
                                          Buffer            *vsInfo));



PRIVATE S16 PtLiSctTermReq           ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        assocId,
                                          U8             assocIdType,
                                          Bool           abrtFlg));



PRIVATE S16 PtLiSctSetPriReq         ARGS((Pst           *pst,
                                           SpId          spId,
                                           UConnId       spAssocId,
                                           CmNetAddr     *dstNAddr));


PRIVATE S16 PtLiSctDatReq            ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        spAssocId,
                                          CmNetAddr     *dstNAddr,
                                          SctStrmId      strmId,
                                          Bool           unorderFlg,
                                          Bool           nobundleFlg,
                                          U16            lifeTime,
                                          U32            protId,
                                          Buffer        *mBuf));


PRIVATE S16 PtLiSctStaReq            ARGS((Pst           *pst,
                                          SpId           spId,
                                          UConnId        spAssocId,
                                          CmNetAddr     *dstNAddr,
                                          U8             staType));
#endif

#endif

#ifdef   GCP_PROV_MTP3
#ifdef   PTMGLISNT

PRIVATE S16 PtLiSntBndReq ARGS((Pst*, SuId, SpId, SrvInfo));
PRIVATE S16 PtLiSntUDatReq ARGS((Pst*, SpId, Dpc, Dpc, SrvInfo, LnkSel, 
                                 Priority, Buffer *));
#ifdef SNT2
PRIVATE S16 PtLiSntStaReq ARGS((Pst*, SpId, Dpc)); 
#endif /* SNT2 */



#endif   /* GCP_PROV_MTP3 */
#endif   /* PTMGLISNT */





/* functions in other modules */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */



/************************************************************************
                             TUCL Matrices
************************************************************************/

PUBLIC HitBndReq mgLiHitBndReqMt [] =
{
#ifdef LCMGLIHIT
   cmPkHitBndReq,        /* 0 - loosely coupled */
#else
   PtLiHitBndReq,        /* 0 - loosely coupled, portable */
#endif
#ifdef HI
   HiUiHitBndReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitBndReq,        /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiHitBndReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitBndReq         /* 1 - tightly coupled, portable */
#endif
};



PUBLIC HitUbndReq mgLiHitUbndReqMt [] =
{
#ifdef LCMGLIHIT
   cmPkHitUbndReq,        /* 0 - loosely coupled */
#else
   PtLiHitUbndReq,        /* 0 - loosely coupled, portable */
#endif
#ifdef HI
   HiUiHitUbndReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitUbndReq,        /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiHitUbndReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitUbndReq         /* 1 - tightly coupled, portable */
#endif
};



PUBLIC HitServOpenReq mgLiHitServOpenReqMt [] =
{
#ifdef LCMGLIHIT
   cmPkHitServOpenReq,        /* 0 - loosely coupled */
#else
   PtLiHitServOpenReq,        /* 0 - loosely coupled, portable */
#endif
#ifdef HI
   HiUiHitServOpenReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitServOpenReq,        /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiHitServOpenReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitServOpenReq         /* 1 - tightly coupled, portable */
#endif
};



PUBLIC HitConReq mgLiHitConReqMt [] =
{
#ifdef LCMGLIHIT
   cmPkHitConReq,        /* 0 - loosely coupled */
#else
   PtLiHitConReq,        /* 0 - loosely coupled, portable */
#endif
#ifdef HI
   HiUiHitConReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitConReq,        /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiHitConReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitConReq         /* 1 - tightly coupled, portable */
#endif
};



PUBLIC HitConRsp mgLiHitConRspMt [] =
{
#ifdef LCMGLIHIT
   cmPkHitConRsp,        /* 0 - loosely coupled */
#else
   PtLiHitConRsp,        /* 0 - loosely coupled, portable */
#endif
#ifdef HI
   HiUiHitConRsp,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitConRsp,        /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiHitConRsp,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitConRsp         /* 1 - tightly coupled, portable */
#endif
};



PUBLIC HitDatReq mgLiHitDatReqMt [] =
{
#ifdef LCMGLIHIT
   cmPkHitDatReq,        /* 0 - loosely coupled */
#else
   PtLiHitDatReq,        /* 0 - loosely coupled, portable */
#endif
#ifdef HI
   HiUiHitDatReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitDatReq,        /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiHitDatReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitDatReq         /* 1 - tightly coupled, portable */
#endif
};



PUBLIC HitUDatReq mgLiHitUDatReqMt [] =
{
#ifdef LCMGLIHIT
   cmPkHitUDatReq,        /* 0 - loosely coupled */
#else
   PtLiHitUDatReq,        /* 0 - loosely coupled, portable */
#endif
#ifdef HI
   HiUiHitUDatReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitUDatReq,        /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiHitUDatReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitUDatReq         /* 1 - tightly coupled, portable */
#endif
};



PUBLIC HitDiscReq mgLiHitDiscReqMt [] =
{
#ifdef LCMGLIHIT
   cmPkHitDiscReq,        /* 0 - loosely coupled */
#else
   PtLiHitDiscReq,        /* 0 - loosely coupled, portable */
#endif
#ifdef HI
   HiUiHitDiscReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitDiscReq,        /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiHitDiscReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiHitDiscReq         /* 1 - tightly coupled, portable */
#endif

};



#ifdef    GCP_PROV_SCTP

/*
 * The following matrices define the mapping between the
 * primitives called by the upper layer interface of SCTP
 * layer and the corresponding primitives in the SCTP.
 * 
 * The parameter MG_MAX_SCT_SEL defines the maximum number
 * of selector options below the upper layer.
 * There is an array of functions per primitive invoked by
 * the upper layer.
 * 
 * Every array is MG_MAX_SCT_SEL long.
 * 
 * The dispatching is performed by the configurable
 * variable: selector.
 * The selector is configured during general configuration.
 * 
 * The values used in selector are:
 * 
 *    0 - loosely coupled (#define LCMGLISCT)
 *    1 - Lsb (#define SB)
 * 
 */



/************************************************************************
                             SCTP Matrices
************************************************************************/



/* Bind request Primitive */

PUBLIC  SctBndReq mgLiSctBndReqMt[MG_MAX_SCT_SEL] =
{
#ifdef LCMGLISCT
   cmPkSctBndReq,          /* 0 - loosely coupled  */
#else
   PtLiSctBndReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctBndReq,          /* 1 - tightly coupled, stub layer */
#else
   PtLiSctBndReq,          /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiSctBndReq,          /* 1 - tightly coupled, stub layer */
#else
   PtLiSctBndReq           /* 1 - tightly coupled, portable */
#endif
};




/* Open endpoint request primitive */

PUBLIC  SctEndpOpenReq mgLiSctEndpOpenReqMt[MG_MAX_SCT_SEL] =
{
#ifdef LCMGLISCT
   cmPkSctEndpOpenReq,     /* 0 - loosely coupled */
#else
   PtLiSctEndpOpenReq,     /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctEndpOpenReq,     /* 1 - tightly coupled, stub layer */
#else
   PtLiSctEndpOpenReq,     /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiSctEndpOpenReq,     /* 1 - tightly coupled, stub layer */
#else
   PtLiSctEndpOpenReq,     /* 1 - tightly coupled, portable */
#endif
};




/* Close endpoint request primitive */

PUBLIC  SctEndpCloseReq mgLiSctEndpCloseReqMt[MG_MAX_SCT_SEL] =
{
#ifdef LCMGLISCT
   cmPkSctEndpCloseReq,     /* 0 - loosely coupled */
#else
   PtLiSctEndpCloseReq,     /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctEndpCloseReq,     /* 1 - tightly coupled, stub layer */
#else
   PtLiSctEndpCloseReq,     /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiSctEndpCloseReq,     /* 1 - tightly coupled, stub layer */
#else
   PtLiSctEndpCloseReq,     /* 1 - tightly coupled, portable */
#endif
};




/* Association request primitive */

PUBLIC  SctAssocReq mgLiSctAssocReqMt[MG_MAX_SCT_SEL] =
{
#ifdef LCMGLISCT
   cmPkSctAssocReq,        /* 0 - loosely coupled */
#else
   PtLiSctAssocReq,        /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctAssocReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiSctAssocReq,        /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiSctAssocReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiSctAssocReq,        /* 1 - tightly coupled, portable */
#endif
};




/* Association response primitive */

PUBLIC  SctAssocRsp mgLiSctAssocRspMt[MG_MAX_SCT_SEL] =
{
#ifdef LCMGLISCT
   cmPkSctAssocRsp,        /* 0 - loosely coupled */
#else
   PtLiSctAssocRsp,        /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctAssocRsp,        /* 1 - tightly coupled, stub layer */
#else
   PtLiSctAssocRsp,        /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiSctAssocRsp,        /* 1 - tightly coupled, stub layer */
#else
   PtLiSctAssocRsp,        /* 1 - tightly coupled, portable */
#endif
};




/* Association termination request primitive */

PUBLIC  SctTermReq mgLiSctTermReqMt[MG_MAX_SCT_SEL] =
{
#ifdef LCMGLISCT
   cmPkSctTermReq,        /* 0 - loosely coupled */
#else
   PtLiSctTermReq,        /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctTermReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiSctTermReq,        /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiSctTermReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiSctTermReq,        /* 1 - tightly coupled, portable */
#endif
};




/* Set Primary Destination Address request primitive */

PUBLIC  SctSetPriReq mgLiSctSetPriReqMt[MG_MAX_SCT_SEL] =
{
#ifdef LCMGLISCT
   cmPkSctSetPriReq,      /* 0 - loosely coupled */
#else
   PtLiSctSetPriReq,      /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctSetPriReq,      /* 1 - tightly coupled, stub layer */
#else
   PtLiSctSetPriReq,      /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiSctSetPriReq,      /* 1 - tightly coupled, stub layer */
#else
   PtLiSctSetPriReq,      /* 1 - tightly coupled, portable */
#endif
};




/* Data request primitive */

PUBLIC  SctDatReq mgLiSctDatReqMt[MG_MAX_SCT_SEL] =
{
#ifdef LCMGLISCT
   cmPkSctDatReq,          /* 0 - loosely coupled */
#else
   PtLiSctDatReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctDatReq,          /* 1 - tightly coupled, stub layer */
#else
   PtLiSctDatReq,          /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiSctDatReq,          /* 1 - tightly coupled, stub layer */
#else
   PtLiSctDatReq,          /* 1 - tightly coupled, portable */
#endif
};




/* Status request primitive */

PUBLIC  SctStaReq mgLiSctStaReqMt[MG_MAX_SCT_SEL] =
{
#ifdef LCMGLISCT
   cmPkSctStaReq,         /* 0 - loosely coupled */
#else
   PtLiSctStaReq,         /* 0 - tightly coupled, portable */
#endif
#ifdef SB
   SbUiSctStaReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiSctStaReq,        /* 1 - tightly coupled, portable */
#endif
#ifdef L4
   L4UiSctStaReq,        /* 1 - tightly coupled, stub layer */
#else
   PtLiSctStaReq,        /* 1 - tightly coupled, portable */
#endif
};

#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
/*
 *the following matrices define the mapping between the primitives
 *called by the lower interface of GCP and the corresponding
 *primitives of the MTP level 3 service user(s).
 *  
 *The parameter MG_MAX_SNT_SEL defines the maximum number of service users on
 *top of MTP level 3. There is an array of functions per primitive
 *invoked by MTP level 3. Every array is MG_MAX_SNT_SEL long (i.e. there
 *are as many functions as the number of service users).
 *  
 *The dispatching is performed by the configurable variable: selector.
 *The selector is configured on a per SAP basis.
 *  
 *The selectors are:
 *  
 *   0 - loosely coupled (#define LCMGLISNT)
 *   1 - MTP Level 3 (#define SN)
 *   2 - M3UA (sigtran) (#define IT)  
*/
  

/* Bind Request primitive */
  
PUBLIC SntBndReq mgLiSntBndReqMt[MG_MAX_SNT_SEL] =
{
#ifdef LCMGLISNT
   cmPkSntBndReq,          /* 0 - loosely coupled, portable */
#else
   PtLiSntBndReq,          /* 0 - loosely coupled, portable */
#endif
#ifdef SN
   SnUiSntBndReq,          /* 1 - tightly coupled, Snt */
#else
   PtLiSntBndReq,          /* 1 - tightly coupled, portable */
#endif
#ifdef IT
   ItUiSntBndReq,          /* 2 - tightly coupled, M3UA */
#else
   PtLiSntBndReq,          /* 2 - tightly coupled, portable */
#endif
};


/* Unit Data Request primitive */
  
PUBLIC SntUDatReq mgLiSntUDatReqMt[MG_MAX_SNT_SEL] =
{
#ifdef LCMGLISNT
   cmPkSntUDatReq,         /* 0 - loosely coupled, portable */
#else
   PtLiSntUDatReq,         /* 0 - loosely coupled, portable */
#endif
#ifdef SN
   SnUiSntUDatReq,         /* 1 - tightly coupled, SNT */
#else
   PtLiSntUDatReq,         /* 1 - tightly coupled, portable */
#endif
#ifdef IT
   ItUiSntUDatReq,         /* 2 - tightly coupled, M3UA */
#else
   PtLiSntUDatReq,         /* 2 - tightly coupled, portable */
#endif
};


#ifdef SNT2

/* status Request primitive */
  
PUBLIC SntStaReq mgLiSntStaReqMt[MG_MAX_SNT_SEL] =
{
#ifdef LCMGLISNT
   cmPkSntStaReq,         /* 0 - loosely coupled, portable */
#else
   PtLiSntStaReq,         /* 0 - loosely coupled, portable */
#endif
#ifdef SN
   SnUiSntStaReq,         /* 1 - tightly coupled, SNT */
#else
   PtLiSntStaReq,         /* 1 - tightly coupled, portable */
#endif
#ifdef IT
   ItUiSntStaReq,         /* 2 - tightly coupled, M3UA */
#else
   PtLiSntStaReq,         /* 2 - tightly coupled, portable */
#endif
};
#endif /* SNT2 */


#endif   /* GCP_PROV_MTP3 */



/************************************************************************
                   TUCL Lower Interface Functions
************************************************************************/


/*
 *
 *       Fun:   MgLiHitBndReq
 *
 *       Desc:  This function resolves the HitBndReq primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgLiHitBndReq
(
Pst *post,
SuId suId,
SpId spId
)
#else 
PUBLIC S16 MgLiHitBndReq (post, suId, spId)
Pst *post;
SuId suId;
SpId spId;
#endif
{
   TRC3(MgLiHitBndReq)

   MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
           "MgLiHitBndReq(post, suId: %d, spId: %d)\n", suId, spId));

   (*mgLiHitBndReqMt[post->selector]) (post, suId, spId);

   RETVALUE(ROK);
}





/*
 *
 *       Fun:   MgLiHitUbndReq
 *
 *       Desc:  This function resolves the HitUbndReq primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgLiHitUbndReq
(
Pst *post,
SpId spId,
Reason reason
)
#else 
PUBLIC S16 MgLiHitUbndReq (post, spId, reason)
Pst *post;
SpId spId;
Reason reason;
#endif
{
   TRC3(MgLiHitUbndReq)

   MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
           "MgLiHitUBndReq(post, spId(%d), reason(%d))\n", spId, reason));

   (*mgLiHitUbndReqMt[post->selector]) (post, spId, reason);

   RETVALUE(ROK);
}





/*
 *
 *       Fun:   MgLiHitServOpenReq
 *
 *       Desc:  This function resolves the HitServOpenReq primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgLiHitServOpenReq
(
Pst *post,
SpId spId,
UConnId servConId,
CmTptAddr *servTAddr,
CmTptParam *tPar,
CmIcmpFilter *icmpFilter,
U8 srvcType
)
#else 
PUBLIC S16 MgLiHitServOpenReq (post, spId, servConId, servTAddr, tPar, icmpFilter, srvcType)
Pst *post;
SpId spId;
UConnId servConId;
CmTptAddr *servTAddr;
CmTptParam *tPar;
CmIcmpFilter *icmpFilter;
U8 srvcType;
#endif
{
   TRC3(MgLiHitServOpenReq)

#ifdef DEBUGP
   {
      U16   port;
      Txt   addr[2 * CM_IPV6ADDR_SIZE + 1];

      mgGetPortAndAscAddr (servTAddr, &port, addr);

      MGDBGP ( DBGMASK_LI, (mgCb.init.prntBuf, 
           "MgLiHitServOpenReq(post, spId(%d), servConId(%ld), "
           "servTAddr.type(%d), servTAddr.port(%d), servTAddr.address(%s),"
           " tpar, srvcType (%d))\n",
           spId, servConId, servTAddr->type, port, addr, srvcType));
   }
#endif /* DEBUGP */

   (*mgLiHitServOpenReqMt[post->selector]) (post, spId, servConId, servTAddr, 
                                           tPar, icmpFilter, srvcType);

   RETVALUE(ROK);
}





/*
 *
 *       Fun:   MgLiHitConReq
 *
 *       Desc:  This function resolves the HitConReq primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgLiHitConReq
(
Pst *post,
SpId spId,
UConnId suConId,
CmTptAddr *remAddr,
CmTptAddr *localAddr,
CmTptParam *tPar,
U8 srvcType
)
#else 
PUBLIC S16 MgLiHitConReq (post, spId, suConId, remAddr, localAddr, tPar, 
                          srvcType)
Pst *post;
SpId spId;
UConnId suConId;
CmTptAddr *remAddr;
CmTptAddr *localAddr;
CmTptParam *tPar;
U8 srvcType;
#endif
{
   TRC3(MgLiHitConReq)

#ifdef DEBUGP
   {
      U16   port1;
      U16   port2;
      Txt   addr1[2 * CM_IPV6ADDR_SIZE + 1];
      Txt   addr2[2 * CM_IPV6ADDR_SIZE + 1];

      mgGetPortAndAscAddr (remAddr, &port1, addr1);
      mgGetPortAndAscAddr (localAddr, &port2, addr2);
      MGDBGP ( DBGMASK_LI, (mgCb.init.prntBuf, 
           "MgLiHitConReq(post, spId(%d), suConId(%ld), "
           "remAddr.type(%d), remAddr.port(%d), remAddr.address(%s),"
           "localAddr.type(%d), localAddr.port(%d), localAddr.address(%s),"
           " tpar, srvcType (%d))\n",
           spId, suConId, remAddr->type, port1, addr1, localAddr->type, 
           port2, addr2, srvcType));
   }
#endif /* DEBUGP */

   (*mgLiHitConReqMt[post->selector])
      (post, spId, suConId, remAddr, localAddr, tPar, srvcType);

   RETVALUE(ROK);
}





/*
 *
 *       Fun:   MgLiHitConRsp
 *
 *       Desc:  This function resolves the HitConRsp primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgLiHitConRsp
(
Pst *post,
SpId spId,
UConnId suConId,
UConnId spConId
)
#else 
PUBLIC S16 MgLiHitConRsp (post, spId, suConId, spConId)
Pst *post;
SpId spId;
UConnId suConId;
UConnId spConId;
#endif
{
   TRC3(MgLiHitConRsp)

   MGDBGP ( DBGMASK_LI, (mgCb.init.prntBuf, 
        "MgLiHitConRsp(post, spId(%d), suConId(%ld), spConId(%ld)\n",
        spId, suConId, spConId));

   (*mgLiHitConRspMt[post->selector])
      (post, spId, suConId, spConId);

   RETVALUE(ROK);
}





/*
 *
 *       Fun:   MgLiHitDatReq
 *
 *       Desc:  This function resolves the HitDatReq primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgLiHitDatReq
(
Pst *post,
SpId spId,
UConnId spConId,
Buffer *mBuf
)
#else 
PUBLIC S16 MgLiHitDatReq (post, spId, spConId, mBuf)
Pst *post;
SpId spId;
UConnId spConId;
Buffer *mBuf;
#endif
{
   TRC3(MgLiHitDatReq)

   MGDBGP ( DBGMASK_LI, (mgCb.init.prntBuf, 
        "MgLiHitDatReq(post, spId(%d), spConId(%ld), mBuf(%p)\n",
        spId, spConId, (void *)mBuf));

#ifdef DEBUGP
   if (mgCb.init.dbgMask & MG_DBGMASK_LI_MBUF)
   {
      SPrntMsg (mBuf, 0, 0);
   }
#endif /* DEBUGP */

   (*mgLiHitDatReqMt[post->selector]) (post, spId, spConId, mBuf);

   RETVALUE(ROK);
}





/*
 *
 *       Fun:   MgLiHitUDatReq
 *
 *       Desc:  This function resolves the HitUDatReq primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgLiHitUDatReq
(
Pst *post,
SpId spId,
UConnId spConId,
CmTptAddr *remAddr,
CmTptAddr *srcAddr,
CmIpHdrParm *hdrParm,
#ifdef HI_REL_1_4
CmTptParam *tPar,
#endif /* HI_REL_1_4 */
Buffer *mBuf
)
#else 
PUBLIC S16 MgLiHitUDatReq (post, spId, spConId, remAddr, srcAddr, hdrParm, 
#ifdef HI_REL_1_4
tPar,
#endif /* HI_REL_1_4 */
mBuf)
Pst *post;
SpId spId;
UConnId spConId;
CmTptAddr *remAddr;
CmTptAddr *srcAddr;
CmIpHdrParm *hdrParm;
#ifdef HI_REL_1_4
CmTptParam *tPar;
#endif /* HI_REL_1_4 */
Buffer *mBuf;
#endif
{
   TRC3(MgLiHitUDatReq)

#ifdef DEBUGP
   {
      U16   port;
      Txt   addr[2 * CM_IPV6ADDR_SIZE + 1];

      mgGetPortAndAscAddr (remAddr, &port, addr);

      MGDBGP ( DBGMASK_LI, (mgCb.init.prntBuf, 
           "MgLiHitUDatReq(post, spId(%d), remAddr.type(%d), remAddr.port(%d),"
           "remAddr.address(%s), mBuf(%p))\n",
           spId, remAddr->type, port, addr, (void *)mBuf));

      if (mgCb.init.dbgMask & MG_DBGMASK_LI_MBUF)
         SPrntMsg (mBuf, 0, 0);
   }
#endif /* DEBUGP */

#ifdef HI_REL_1_4
      /* HI Release 1.4 has additional parameter ( transport parameter) */
   (*mgLiHitUDatReqMt[post->selector]) (post, spId, spConId, remAddr, srcAddr,
                                        hdrParm, tPar, mBuf);
#else  /* HI_REL_1_4 */
   (*mgLiHitUDatReqMt[post->selector]) (post, spId, spConId, remAddr, srcAddr,
                                        hdrParm, mBuf);
#endif /* HI_REL_1_4 */

   RETVALUE(ROK);
}






/*
 *
 *       Fun:   MgLiHitDiscReq
 *
 *       Desc:  This function resolves the HitDiscReq primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgLiHitDiscReq
(
Pst *post,
SpId spId,
U8 choice,
UConnId conId,
Action action,
CmTptParam *tPar
)
#else 
PUBLIC S16 MgLiHitDiscReq (post, spId, choice, conId, action, tPar)
Pst *post;
SpId spId;
U8 choice;
UConnId conId;
Action action;
CmTptParam *tPar;
#endif
{
   TRC3(MgLiHitDiscReq)

   MGDBGP ( DBGMASK_LI, (mgCb.init.prntBuf, 
           "MgLiHitDiscReq(post, spId(%d), choice(%d), conId(%ld), action(%d),"
           "tPar\n", spId, choice, conId, action));

   (*mgLiHitDiscReqMt[post->selector]) (post, spId, choice, conId, action, tPar);

   RETVALUE(ROK);
}



#ifdef    GCP_PROV_SCTP

/************************************************************************
                   SCTP Lower Interface Functions
************************************************************************/


/*
*
*       Fun:   Bind request
*
*       Desc:  This function is used to bind two upper SAPs.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctBndReq
(
Pst *pst,                 /* post structure */
SuId suId,                /* Su SAP Id */
SpId spId                 /* Sp SAP Id */
)
#else
PUBLIC S16 MgLiSctBndReq(pst, suId, spId)
Pst *pst;                 /* post structure */
SuId suId;                /* Su SAP Id */
SpId spId;                /* Sp SAP Id */
#endif
{
   TRC3(MgLiSctBndReq)

#ifdef DEBUGP
   MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
           "MgLiSctBndReq(pst, suId: %d, spId: %d)\n", suId, spId));
#endif /* DEBUGP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= MG_MAX_SCT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* jump to specific primitive depending on configured selector */
   RETVALUE((*mgLiSctBndReqMt[pst->selector])(pst, suId, spId));
  

} /* end of MgLiSctBndReq */





/*
*
*       Fun:   Opening of endpoint request
*
*       Desc:  This function is used to request the opening of
*              an endpoint at the SCTP layer.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctEndpOpenReq
(
Pst *pst,                    /* post structure */
SpId spId,                   /* Service provider SAP Id */
UConnId suEndpId,            /* Service user Endpoint Id */
SctPort port,                /* SCTP Port number */
CmNetAddr *intfNAddr         /* Interface IP address   */
)
#else
PUBLIC S16 MgLiSctEndpOpenReq(pst, spId, suEndpId, port, intfNAddr)
Pst *pst;                    /* post structure */
SpId spId;                   /* Service provider SAP Id */
UConnId suEndpId;            /* Service user Endpoint Id */
SctPort port;                /* SCTP Port number */
CmNetAddr *intfNAddr;        /* Interface IP address   */
#endif
{
   TRC3(MgLiSctEndpOpenReq)

#ifdef DEBUGP
   {

      MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
              "MgLiSctEndpOpenReq(pst, spId: %d, suEndpId: %ld, "
              "port: %d, intfNAddr->type: %d)\n",
              spId, suEndpId, port, intfNAddr->type));
   }
#endif /* DEBUGP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= MG_MAX_SCT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* jump to specific primitive depending on configured selector */
   RETVALUE((*mgLiSctEndpOpenReqMt[pst->selector])(pst, spId, suEndpId, port, 
                                                   intfNAddr));
} /* end of MgLiSctEndpOpenReq */





/*
*
*       Fun:   Endpoint closing request
*
*       Desc:  This function is used to send a request for the closing of 
*              the SCTP endpoint
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctEndpCloseReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAPID */
UConnId endpId,           /* endpoint ID */
U8 endpIdType             /* endpoint ID type */
)
#else
PUBLIC S16 MgLiSctEndpCloseReq(pst, spId, endpId, endpIdType)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAPID */
UConnId endpId;           /* endpoint ID */
U8 endpIdType;            /* endpoint ID type */
#endif
{
   TRC3(MgLiSctEndpCloseReq)

#ifdef DEBUGP
   {
      MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
              "MgLiSctEndpCloseReq(pst, spId: %d, endpId: %ld, "
              "endpIdType: %d)\n",
              spId, endpId, endpIdType));
   }
#endif /* DEBUGP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= MG_MAX_SCT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* jump to specific primitive depending on configured selector */
   RETVALUE((*mgLiSctEndpCloseReqMt[pst->selector])(pst, spId, endpId, 
                                                    endpIdType));
} /* end of MgLiSctEndpCloseReq */





/*
*
*       Fun:   Association establishment request
*
*       Desc:  This function is used to send a request for the closing of 
*              the SCTP endpoint
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

/* mg001.105: Added TOS as the parameter. This is defined within the
 *            SCT3 flag. This flag needs to be defined in the make
 *            file. The envopt.h file has also been modified for this. */

#ifdef ANSI
PUBLIC S16 MgLiSctAssocReq
(
Pst *pst,                  /* post structure */
SpId spId,                 /* service provider SAP ID */
UConnId spEndpId,          /* service provider endpoint ID */
UConnId suAssocId,         /* service userassociation ID */
CmNetAddr *priDstNAddr,    /* primary destination network address */
SctPort dstPort,           /* destination port number */
SctStrmId outStrms,        /* no. of outgoing streams */
SctNetAddrLst *dstNAddrLst, /* dest. network address list */
SctNetAddrLst *srcNAddrLst, /* src. network address list */
SctTos        tos,          /* type of service */
Buffer *vsInfo              /* vendor specific info */
)
#else
PUBLIC S16 MgLiSctAssocReq(pst, spId, spEndpId, suAssocId, priDstNAddr, dstPort,
outStrms, dstNAddrLst, srcNAddrLst, tos, vsInfo)
Pst *pst;                  /* post structure */
SpId spId;                 /* service provider SAP ID */
UConnId spEndpId;          /* service provider endpoint ID */
UConnId suAssocId;         /* service userassociation ID */
CmNetAddr *priDstNAddr;    /* primary destination network address */
SctPort dstPort;           /* destination port number */
SctStrmId outStrms;        /* no. of outgoing streams */
SctNetAddrLst *dstNAddrLst; /* dest. network address list */
SctNetAddrLst *srcNAddrLst; /* src. network address list */
SctTos        tos;          /* type of service */
Buffer *vsInfo;             /* vendor specific info */
#endif
{
   TRC3(MgLiSctAssocReq)

#ifdef DEBUGP
   {

      MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
              "MgLiSctAssocReq(pst, spId: %d, spEndpId: %ld, "
              "suAssocId: %ld, dstPort: %d, outStrms: %d)\n",
              spId, spEndpId, suAssocId, dstPort, outStrms));
   }
#endif /* DEBUGP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= MG_MAX_SCT_SEL)
   {
      if (vsInfo != (Buffer *)NULLP)
      {
         SPutMsg(vsInfo);
      }
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* jump to specific primitive depending on configured selector */
   RETVALUE((*mgLiSctAssocReqMt[pst->selector])(pst, spId, spEndpId, suAssocId,
                                                priDstNAddr, dstPort, outStrms, 
                                                dstNAddrLst, srcNAddrLst, 
                                                tos, vsInfo));
} /* end of MgLiSctAssocReq */





/*
*
*       Fun:   Association Establishment response
*
*       Desc:  This function is used by the service user to respond to an 
*              association iniitialization indication by accepting the 
*              association.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

/* mg001.105: Added TOS as the parameter. This is defined within the
 *            SCT3 flag. This flag needs to be defined in the make
 *            file. The envopt.h file has also been modified for this. */

#ifdef ANSI
PUBLIC S16 MgLiSctAssocRsp
(
Pst *pst,                  /* post structure */
SpId spId,                 /* service provider SAP ID */
UConnId spAssocId,         /* service provider association ID */
SctAssocIndParams *assocIndParams, /* association parameters */
SctTos    tos,             /* type of service */
SctResult result,          /* result */
Buffer *vsInfo             /* vendor specific info */
)
#else
PUBLIC S16 MgLiSctAssocRsp(pst, spId, spAssocId, assocIndParams,
                           tos, result, vsInfo)
Pst *pst;                  /* post structure */
SpId spId;                 /* service provider SAP ID */
UConnId spAssocId;         /* service provider association ID */
SctAssocIndParams *assocIndParams; /* association parameters */
SctTos    tos;             /* type of service */
SctResult result;          /* result */
Buffer *vsInfo;            /* vendor specific info */
#endif
{
   TRC3(MgLiSctAssocRsp)

#ifdef DEBUGP
   {
      if (assocIndParams->type == SCT_ASSOC_IND_INIT)
      {

         SctInitParams *ip;

         ip = &(assocIndParams->t.initParams);

         MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
                 "MgLiSctAssocRsp(pst, spId: %d, spAssocId: %ld, "
                 "result: %d, assocIndParams->type: %d, "
                 "initParams.iTag: %ld, initParams.a_rwnd: %ld, "
                 "initParams.outStrms: %d, initParams.inStrms: %d, "
                 "initParams.iTsn: %ld, initParams.cookieLife: %ld, "
                 "initParams.peerPort: %d, initParams.localPort: %d, "
                 "initParams.supAddress: %d)\n",
                 spId, spAssocId, result, assocIndParams->type,
                 ip->iTag, ip->a_rwnd, ip->outStrms, ip->inStrms,
                 ip->iTsn, ip->cookieLife, ip->peerPort,
                 ip->localPort, ip->supAddress));
      }
      else if (assocIndParams->type == SCT_ASSOC_IND_COOKIE)
      {

         SctCookieParams *cp;

         cp = &(assocIndParams->t.cookieParams);

         MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
                 "MgLiSctAssocRsp(pst, spId: %d, spAssocId: %ld, "
                 "result: %d, assocIndParams->type: %d, "
                 "cookieParams.spAssocId: %ld, cookieParams.suAssocId: %ld, "
                 "cookieParams.peerPort: %d)\n",
                 spId, spAssocId, result, assocIndParams->type,
                 cp->spAssocId, cp->suAssocId, cp->peerPort));
      }
   }
#endif /* DEBUGP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= MG_MAX_SCT_SEL)
   {
      if (vsInfo != (Buffer *)NULLP)
      {
         SPutMsg(vsInfo);
      }
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* jump to specific primitive depending on configured selector */
   RETVALUE((*mgLiSctAssocRspMt[pst->selector])(pst, spId, spAssocId, 
                                                assocIndParams, tos,
                                                result, vsInfo));
} /* end of MgLiSctAssocRsp */





/*
*
*       Fun:   Association Termination Request
*
*       Desc:  This function is used to request the termination of an 
*              association which is either established or being established.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctTermReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId assocId,          /* association ID */
U8 assocIdType,           /* association ID type */
Bool abrtFlg              /* abort flag */
)
#else
PUBLIC S16 MgLiSctTermReq(pst, spId, assocId, assocIdType, abrtFlg)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId assocId;          /* association ID */
U8 assocIdType;           /* association ID type */
Bool abrtFlg;             /* abort flag */
#endif
{
   TRC3(MgLiSctTermReq)

#ifdef DEBUGP
   {
      MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
              "MgLiSctTermReq(pst, spId: %d, assocId: %ld, "
              "assocIdType: %d, abrtFlg: %d)\n",
              spId, assocId, assocIdType, abrtFlg));
   }
#endif /* DEBUGP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= MG_MAX_SCT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* jump to specific primitive depending on configured selector */
   RETVALUE((*mgLiSctTermReqMt[pst->selector])(pst, spId, assocId, assocIdType, 
                                               abrtFlg));
} /* end of MgLiSctTermReq */





/*
*
*       Fun:   Set Primary Destination Address request
*
*       Desc:  This function is used to set a particular
*              primary destination address.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctSetPriReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId spAssocId,        /* service provider association ID */
CmNetAddr *dstNAddr       /* dest. network address */
)
#else
PUBLIC S16 MgLiSctSetPriReq(pst, spId, spAssocId, dstNAddr)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId spAssocId;        /* service provider association ID */
CmNetAddr *dstNAddr;      /* dest. network address */
#endif
{
   TRC3(MgLiSctSetPriReq)

#ifdef DEBUGP
   {

      MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
              "MgLiSctSetPriReq(pst, spId: %d, spAssocId: %ld)\n",
              spId, spAssocId));
   }
#endif /* DEBUGP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= MG_MAX_SCT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* jump to specific primitive depending on configured selector */
   RETVALUE((*mgLiSctSetPriReqMt[pst->selector])(pst, spId, spAssocId,
                                                 dstNAddr));
} /* end of MgLiSctSetPriReq */





/*
*
*       Fun:   Data request
*
*       Desc:  This function is used to request the service provider to send a
*              user datagram to the destination.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctDatReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId spAssocId,        /* service provider association ID */
CmNetAddr *dstNAddr,      /* dest. network address */
SctStrmId strmId,         /* stream ID */
Bool unorderFlg,          /* unordered delivery flag */
Bool nobundleFlg,         /* nobundleFlg */
U16 lifetime,             /* datagram lifetime */
U32 protId,               /* protocol ID */
Buffer *mBuf              /* message buffer */
)
#else
PUBLIC S16 MgLiSctDatReq(pst, spId, spAssocId, dstNAddr, strmId, unorderFlg, 
                         nobundleFlg, lifetime, protId, mBuf)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId spAssocId;        /* service provider association ID */
CmNetAddr *dstNAddr;      /* dest. network address */
SctStrmId strmId;         /* stream ID */
Bool unorderFlg;          /* unordered delivery flag */
Bool nobundleFlg;         /* nobundleFlg */
U16 lifetime;             /* datagram lifetime */
U32 protId;               /* protocol ID */
Buffer *mBuf;             /* message buffer */
#endif
{
   TRC3(MgLiSctDatReq)

#ifdef DEBUGP
   {

      MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
              "MgLiSctDatReq(pst, spId: %d, spAssocId: %ld, "
              "strmId: %d, unorderFlg: %d, nobundleFlg: %d, "
              "lifetime: %d, protId: %ld)\n",
              spId, spAssocId, strmId, unorderFlg, nobundleFlg,
              lifetime, protId));

      if (mgCb.init.dbgMask & MG_DBGMASK_LI_MBUF)
         SPrntMsg (mBuf, 0, 0);
   }
#endif /* DEBUGP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= MG_MAX_SCT_SEL)
   {
      /* removed the de-allocation of message buffer 
         to resolve the problem of double de-allocation */
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */



#ifdef DEBUGP
   /*
    *   Put the existing SPrntMsg inside GCP_ACC_TESTS as this
    *   printing is needed for acceptance tests - actually the
    *   acceptance tests seem to work without these!!
    */
#ifdef GCP_ACC_TESTS
   SPrntMsg(mBuf, 0, 0);
#endif /* GCP_ACC_TESTS */

#endif /* DEBUGP */


   /* At the moment only MEGACO uses SCTP */
   /* mg004.105: Removed mgGenTrcInd call */
/*   mgGenTrcInd (mgCb.tSAPLst[spId], MG_NONE, LMG_TRC_EVENT_MGCOTX, NULLP, mBuf);*/


   /* jump to specific primitive depending on configured selector */
   RETVALUE((*mgLiSctDatReqMt[pst->selector])(pst, spId, spAssocId, dstNAddr, 
                                              strmId, unorderFlg, nobundleFlg, 
                                              lifetime, protId, mBuf));
} /* end of MgLiSctDatReq */





/*
*
*       Fun:   Status request
*
*       Desc:  This function is used to retrieve 
*              unsent/unacknowledged/undelivered datagrams from the service 
*              provider and to get statistical information from the service 
*              provider.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctStaReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId spAssocId,        /* service provider association ID */
CmNetAddr *dstNAddr,      /* dest. network address */
U8 staType                /* status type */
)
#else
PUBLIC S16 MgLiSctStaReq(pst, spId, spAssocId, dstNAddr, staType)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId spAssocId;        /* service provider association ID */
CmNetAddr *dstNAddr;      /* dest. network address */
U8 staType;               /* status type */
#endif
{
   TRC3(MgLiSctStaReq)

#ifdef DEBUGP
   {

      MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
              "MgLiSctStaReq(pst, spId: %d, spAssocId: %ld, "
              "staType: %d)\n",
              spId, spAssocId, staType));
   }
#endif /* DEBUGP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= MG_MAX_SCT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* jump to specific primitive depending on configured selector */
   RETVALUE((*mgLiSctStaReqMt[pst->selector])(pst, spId, spAssocId, dstNAddr, 
                                              staType));
} /* end of MgLiSctStaReq */


#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
/*
 *
 *       Fun:   lower interface - Network Bind Request
 *
 *       Desc:  This function binds an GCP entity to an MTP 3 Entity.
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgLiSntBndReq
(
Pst *pst,                       /* post structure */
SuId suId,                      /* service user id */
SpId spId,                      /* service provider id */
SrvInfo sInfo                   /* service info */
)
#else
PUBLIC S16 MgLiSntBndReq(pst, suId, spId, sInfo)
Pst *pst;                       /* post structure */
SuId suId;                      /* service user id */
SpId spId;                      /* service provider id */
SrvInfo sInfo;                  /* service info */
#endif
{
   TRC3(MgLiSntBndReq);

#ifdef DEBUGP
   MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
           "MgLiSntBndReq(pst, suId: %d, spId: %d, SrvInfo: %d)\n", suId, spId, sInfo));
#endif /* DEBUGP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= MG_MAX_SNT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* jump to specific primitive depending on configured selector */
 
   RETVALUE((*mgLiSntBndReqMt[pst->selector])(pst, suId, spId, sInfo));
} /* end of MgLiSntBndReq */

  
/*
 *
 *       Fun:   lower interface - Unit Data Request
 *
 *       Desc:  This function tells MTP 3 to transmit data;
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgLiSntUDatReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc opc,                        /* originating pont code */
Dpc dpc,                        /* destination point code */
SrvInfo sInfo,                  /* service information */
LnkSel sls,                     /* service link selector */
Priority prior,                 /* priority */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 MgLiSntUDatReq(pst, spId, opc, dpc, sInfo, sls, prior, mBuf)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Dpc opc;                        /* originating point code */
Dpc dpc;                        /* destination point code */
SrvInfo sInfo;                  /* service information */
LnkSel sls;                     /* service link selector */
Priority prior;                 /* priority */
Buffer *mBuf;                   /* message buffer */
#endif
{

   TRC3(MgLiSntUDatReq);
#ifdef DEBUGP
   {

      MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
              "MgLiSntDatReq(pst, spId: %d, Opc: %d, "
              "Dpc: %d, SrvInfo: %d, sls: %d, "
              "Priority: %d)\n",
              spId, (S16)opc, (S16)dpc, (S16)sInfo, sls, prior));

      if (mgCb.init.dbgMask & MG_DBGMASK_LI_MBUF)
         SPrntMsg (mBuf, 0, 0);
   }
#endif /* DEBUGP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= MG_MAX_SNT_SEL)
   {
      /* removed the de-allocation of message buffer 
         to resolve the problem of double de-allocation */
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */



#ifdef DEBUGP
   /*
    *   Put the existing SPrntMsg inside GCP_ACC_TESTS as this
    *   printing is needed for acceptance tests - actually the
    *   acceptance tests seem to work without these!!
    */
#ifdef GCP_ACC_TESTS
   SPrntMsg(mBuf, 0, 0);
#endif /* GCP_ACC_TESTS */

#endif /* DEBUGP */


   /* At the moment only MEGACO uses MTP3 */
   /* mg004.105: Removed mgGenTrcInd call */
/*   mgGenTrcInd (mgCb.tSAPLst[spId], MG_NONE, LMG_TRC_EVENT_MGCOTX, NULLP, mBuf);*/


   /* jump to specific primitive depending on configured selector */

   RETVALUE((*mgLiSntUDatReqMt[pst->selector])(pst, spId, opc, dpc, sInfo, sls,
                                               prior, mBuf));

} /* end of MgLiSntUDatReq */

#ifdef SNT2 
  
/*
 *
 *       Fun:   lower interface - status Request
 *
 *       Desc:  This function sends status request to MTP3;
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgLiSntStaReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc dpc                         /* destination point code */
)
#else
PUBLIC S16 MgLiSntStaReq(pst, spId, dpc)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Dpc dpc;                        /* destination point code */
#endif
{
   TRC3(MgLiSntStaReq);

#ifdef DEBUGP
   {

      MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
              "MgLiSntStaReq(pst, spId: %d, Dpc: %ld, ",
              spId, dpc ));
   }
#endif /* DEBUGP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == (Pst *)NULLP || pst->selector >= MG_MAX_SNT_SEL)
   {
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   /* jump to specific primitive depending on configured selector */
    RETVALUE(*mgLiSntStaReqMt[pst->selector])(pst, spId, dpc);

} /* end of MgLiSntStaReq */
#endif /* SNT2 */

#endif   /* GCP_PROV_MTP3 */






/************************************************************************
                      TUCL Portable Functions
************************************************************************/

#ifdef PTMGLIHIT

/*
 *
 *       Fun:   PtLiHitBndReq
 *
 *       Desc:  Portable version of HitBndReq primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PRIVATE S16 PtLiHitBndReq
(
Pst *post,
SuId suId,
SpId spId
)
#else 
PRIVATE S16 PtLiHitBndReq (post, suId, spId)
Pst *post;
SuId suId;
SpId spId;
#endif
{
   TRC3(PtLiHitBndReq)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG005, (ErrVal) 0, "PtLiHitBndReq() called");
#endif

   RETVALUE(ROK);
}





/*
 *
 *       Fun:   PtLiHitUbndReq
 *
 *       Desc:  Portable version of HitUbndReq primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PRIVATE S16 PtLiHitUbndReq
(
Pst *post,
SpId spId,
Reason reason
)
#else 
PRIVATE S16 PtLiHitUbndReq (post, spId, reason)
Pst *post;
SpId spId;
Reason reason;
#endif
{
   TRC3(PtLiHitUbndReq)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG006, (ErrVal) 0, "PtLiHitUbndReq() called");
#endif

   RETVALUE(ROK);
}






/*
 *
 *       Fun:   PtLiHitServOpenReq
 *
 *       Desc:  Portable version of HitServOpenReq primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PRIVATE S16 PtLiHitServOpenReq
(
Pst *post,
SpId spId,
UConnId servConId,
CmTptAddr *servTAddr,
CmTptParam *tPar,
CmIcmpFilter *icmpFilter, 
U8 srvcType
)
#else 
PRIVATE S16 PtLiHitServOpenReq (post, spId, servConId, servTAddr, tPar, icmpFilter, srvcType)
Pst *post;
SpId spId;
UConnId servConId;
CmTptAddr *servTAddr;
CmTptParam *tPar;
CmIcmpFilter *icmpFilter;
U8 srvcType;
#endif
{
   TRC3(PtLiHitServOpenReq)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG007, (ErrVal) 0, "PtLiHitServOpenReq() called");
#endif

   RETVALUE(ROK);
}






/*
 *
 *       Fun:   PtLiHitUDatReq
 *
 *       Desc:  Portable version of HitUDatReq primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PRIVATE S16 PtLiHitUDatReq
(
Pst *post,
SpId spId,
UConnId spConId,
CmTptAddr *remAddr,
CmTptAddr *srcAddr,
CmIpHdrParm *ipHdrParm,
#ifdef HI_REL_1_4
CmTptParam *tPar,
#endif
Buffer *mBuf
)
#else 
PRIVATE S16 PtLiHitUDatReq (post, spId, spConId, remAddr,
                            srcAddr, ipHdrParm,
#ifdef HI_REL_1_4
                            tPar,
#endif
                            mBuf)
Pst *post;
SpId spId;
UConnId spConId;
CmTptAddr *remAddr;
CmTptAddr *srcAddr;   
CmIpHdrParm *ipHdrParm;
#ifdef HI_REL_1_4
CmTptParam *tPar;
#endif
Buffer *mBuf;
#endif
{
   TRC3(PtLiHitUDatReq)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG008, (ErrVal) 0, "PtLiHitUDatReq() called");
#endif

   RETVALUE(ROK);
}





/*
 *
 *       Fun:   PtLiHitDiscReq
 *
 *       Desc:  Portable version of HitDiscReq primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PRIVATE S16 PtLiHitDiscReq
(
Pst *post,
SpId spId,
U8 choice,
UConnId conId,
Action action,
CmTptParam *tPar
)
#else 
PRIVATE S16 PtLiHitDiscReq (post, spId, choice, conId, action, tPar)
Pst *post;
SpId spId;
U8 choice;
UConnId conId;
Action action;
CmTptParam *tPar;
#endif
{
   TRC3(PtLiHitDiscReq)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG009, (ErrVal) 0, "PtLiHitDiscReq() called");
#endif

   RETVALUE(ROK);
}





/*
 *
 *       Fun:   PtLiHitConReq
 *
 *       Desc:  Portable version of HitConReq primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtLiHitConReq
(
Pst *post,
SpId spId,
UConnId suConId,
CmTptAddr *remAddr,
CmTptAddr *localAddr,
CmTptParam *tPar,
U8 srvcType
)
#else 
PUBLIC S16 PtLiHitConReq (post, spId, suConId, remAddr, localAddr, 
                           tPar, srvcType)
Pst *post;
SpId spId;
UConnId suConId;
CmTptAddr *remAddr;
CmTptAddr *localAddr;
CmTptParam *tPar;
U8 srvcType;
#endif
{
   TRC3(PtLiHitConReq)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG010, (ErrVal) 0, "PtLiHitConReq() called");
#endif

   RETVALUE(RFAILED);
}





/*
 *
 *       Fun:   PtLiHitConRsp
 *
 *       Desc:  Portable version of HitConRsp primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtLiHitConRsp
(
Pst *post,
SpId spId,
UConnId suConId,
UConnId spConId
)
#else 
PUBLIC S16 PtLiHitConRsp (post, spId, suConId, spConId)
Pst *post;
SpId spId;
UConnId suConId;
UConnId spConId;
#endif
{
   TRC3(PtLiHitConRsp)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG011, (ErrVal) 0, "PtLiHitConRsp() called");
#endif

   RETVALUE(RFAILED);
}





/*
 *
 *       Fun:   PtLiHitDatReq
 *
 *       Desc:  Portable version of HitDatReq primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtLiHitDatReq
(
Pst *post,
SpId spId,
UConnId spConId,
Buffer *mBuf
)
#else 
PUBLIC S16 PtLiHitDatReq (post, spId, spConId, mBuf)
Pst *post;
SpId spId;
UConnId spConId;
Buffer *mBuf;
#endif
{
   TRC3(PtLiHitDatReq)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG012, (ErrVal) 0, "PtLiHitDatReq() called");
#endif

   RETVALUE(RFAILED);
}

#endif /* PTMGLIHIT */



#ifdef    GCP_PROV_SCTP

/************************************************************************
                      SCTP Portable Functions
************************************************************************/

#ifdef PTMGLISCT


/*
*
*       Fun:   Portable bind Request
*
*       Desc:  This function is used to request a bind
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctBndReq
(
Pst *pst,                 /* post structure */
SuId suId,                /* Service user SAP Id */
SpId spId                /* Service provider SAP Id */
)
#else
PRIVATE S16 PtLiSctBndReq(pst, suId, spId)
Pst *pst;                 /* post structure */
SuId suId;                /* Service user SAP Id */
SpId spId;                /* Service provider SAP Id */
#endif
{
   TRC3(PtLiSctBndReq);

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG013, (ErrVal) 0, "PtLiSctBndReq() called");
#endif

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(spId);
   RETVALUE(ROK);
} /* end of PtLiSctBndReq */


/*
*
*       Fun:   Portable open endpoint request
*
*       Desc:  This function is used to request a new endpoint
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctEndpOpenReq
(
Pst *pst,                    /* post structure */
SpId spId,                   /* Service provider SAP Id */
UConnId suEndpId,          /* Service user Endpoint Id */
U16 port,                    /* SCTP Port number */
CmNetAddr *intfNAddr         /* Interface IP address   */
)
#else
PRIVATE S16 PtLiSctEndpOpenReq(pst, spId, suEndpId, port, intfNAddr)
Pst *pst;                    /* post structure */
SpId spId;                   /* Service provider SAP Id */
UConnId suEndpId;          /* Service user Endpoint Id */
U16 port;                    /* SCTP Port number */
CmNetAddr *intfNAddr;        /* Interface IP address   */
#endif
{
   TRC3(PtLiSctEndpOpenReq);

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG014, (ErrVal) 0,
                            "PtLiSctEndpOpenReq() called");
#endif

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(suEndpId);
   UNUSED(port);
   UNUSED(intfNAddr);

   RETVALUE(ROK);
} /* end of PtLiSctEndpOpenReq */


/*
*
*       Fun:   Portable close endpoint request
*  
*       Desc:  This function is used to close an endpoint
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctEndpCloseReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAPID */
UConnId endpId,           /* endpoint ID */
U8 endpIdType             /* endpoint ID type */
)
#else
PRIVATE S16 PtLiSctEndpCloseReq(pst, spId, endpId, endpIdType)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAPID */
UConnId endpId;           /* endpoint ID */
U8 endpIdType;            /* endpoint ID type */
#endif
{
   TRC3(PtLiSctEndpCloseReq);

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG015, (ErrVal) 0,
                            "PtLiSctEndpCloseReq() called");
#endif

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(endpId);
   UNUSED(endpIdType);
   RETVALUE(ROK);
} /* end of PtLiSctEndpCloseReq */


/*
*
*       Fun:   Portable Association request
*
*       Desc:  This function is used to request a new association
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctAssocReq
(
Pst *pst,                  /* post structure */
SpId spId,                 /* service provider SAP ID */
UConnId spEndpId,        /* service provider endpoint ID */
UConnId suAssocId,      /* service userassociation ID */
CmNetAddr *priDstNAddr,    /* primary destination network address */
U16 dstPort,               /* destination port number */
SctStrmId outStrms,        /* no. of outgoing streams */
SctNetAddrLst *dstNAddrLst, /* dest. network address list */
SctNetAddrLst *srcNAddrLst, /* src. network address list */
Buffer *vsInfo          /* vendor specific info */
)
#else
PRIVATE S16 PtLiSctAssocReq(pst, spId, spEndpId, suAssocId, priDstNAddr, 
                            dstPort, outStrms, dstNAddrLst, srcNAddrLst, vsInfo)
Pst *pst;                  /* post structure */
SpId spId;                 /* service provider SAP ID */
UConnId spEndpId;        /* service provider endpoint ID */
UConnId suAssocId;      /* service userassociation ID */
CmNetAddr *priDstNAddr;    /* primary destination network address */
U16 dstPort;               /* destination port number */
SctStrmId outStrms;        /* no. of outgoing streams */
SctNetAddrLst *dstNAddrLst; /* dest. network address list */
SctNetAddrLst *srcNAddrLst; /* src. network address list */
Buffer *vsInfo;          /* vendor specific info */
#endif
{
   TRC3(PtLiSctAssocReq);

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG016, (ErrVal) 0,
                            "PtLiSctAssocReq() called");
#endif

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(spEndpId);
   UNUSED(suAssocId);
   UNUSED(priDstNAddr);
   UNUSED(dstPort);
   UNUSED(outStrms);
   UNUSED(dstNAddrLst);
   UNUSED(srcNAddrLst);
   if (vsInfo != (Buffer *)NULLP)
   {
      SPutMsg(vsInfo);
   }

   RETVALUE(ROK);
} /* end of PtLiSctAssocReq */


/*
*
*       Fun:   Portable association response
*
*       Desc:  This function is used to respond to an association indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctAssocRsp
(
Pst *pst,                  /* post structure */
SpId spId,                 /* service provider SAP ID */
UConnId spAssocId,         /* service provider association ID */
SctAssocIndParams *assocIndParams, /* association parameters */
SctResult result,          /* result */
Buffer *vsInfo             /* vendor specific info */
)
#else
PRIVATE S16 PtLiSctAssocRsp(pst, spId, spAssocId, assocIndParams, result, 
                            vsInfo)
Pst *pst;                  /* post structure */
SpId spId;                 /* service provider SAP ID */
UConnId spAssocId;         /* service provider association ID */
SctAssocIndParams *assocIndParams; /* association parameters */
SctResult result;          /* result */
Buffer *vsInfo;            /* vendor specific info */
#endif
{
   TRC3(PtLiSctAssocRsp);

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG017, (ErrVal) 0,
                            "PtLiSctAssocRsp() called");
#endif

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(spAssocId);
   UNUSED(assocIndParams);
   UNUSED(result);
   if (vsInfo != (Buffer *)NULLP)
   {
      SPutMsg(vsInfo);
   }

   RETVALUE(ROK);
} /* end of PtLiSctAssocRsp */


/*
*
*       Fun:   Portable termination request
*
*       Desc:  This function is used to terminate an association
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctTermReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId assocId,          /* association ID */
U8 assocIdType,           /* association ID type */
Bool abrtFlg              /* abort flag */
)
#else
PRIVATE S16 PtLiSctTermReq(pst, spId, assocId, assocIdType, abrtFlg)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId assocId;          /* association ID */
U8 assocIdType;           /* association ID type */
Bool abrtFlg;             /* abort flag */
#endif
{
   TRC3(PtLiSctTermReq);

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG018, (ErrVal) 0,
                            "PtLiSctTermReq() called");
#endif

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(assocId);
   UNUSED(assocIdType);
   UNUSED(abrtFlg);
   RETVALUE(ROK);
} /* end of PtLiSctTermReq */


/*
*
*       Fun:   Portable set Primary destination address request
*
*       Desc:  This function is used to set a particular
*              primary destination address
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctSetPriReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId spAssocId,        /* service provider association ID */
CmNetAddr *dstNAddr       /* dest. network address */
)
#else
PRIVATE S16 PtLiSctSetPriReq(pst, spId, spAssocId, dstNAddr)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId spAssocId;        /* service provider association ID */
CmNetAddr *dstNAddr;      /* dest. network address */
#endif
{
   TRC3(PtLiSctSetPriReq);

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG019, (ErrVal) 0,
                            "PtLiSctSetPriReq() called");
#endif

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(spAssocId);
   UNUSED(dstNAddr);
   RETVALUE(ROK);
} /* end of PtLiSctSetPriReq */


/*
*
*       Fun:   Portable data Request
*
*       Desc:  This function is used to send data to a peer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctDatReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId spAssocId,        /* service provider association ID */
CmNetAddr *dstNAddr,      /* dest. network address */
SctStrmId strmId,         /* stream ID */
Bool unorderFlg,          /* unordered delivery flag */
Bool nobundleFlg,         /* nobundleFlg */
U16 lifetime,             /* datagram lifetime */
U32 protId,               /* protocol ID */
Buffer *mBuf              /* message buffer */
)
#else
PRIVATE S16 PtLiSctDatReq(pst, spId, spAssocId, dstNAddr, strmId, unorderFlg,
   nobundleFlg, lifetime, protId, mBuf)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId spAssocId;        /* service provider association ID */
CmNetAddr *dstNAddr;      /* dest. network address */
SctStrmId strmId;         /* stream ID */
Bool unorderFlg;          /* unordered delivery flag */
Bool nobundleFlg;         /* nobundleFlg */
U16 lifetime;             /* datagram lifetime */
U32 protId;               /* protocol ID */
Buffer *mBuf;             /* message buffer */
#endif
{
   TRC3(PtLiSctDatReq);

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG020, (ErrVal) 0,
                            "PtLiSctDatReq() called");
#endif

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(spAssocId);
   UNUSED(dstNAddr);
   UNUSED(strmId);
   UNUSED(unorderFlg);
   UNUSED(nobundleFlg);
   UNUSED(lifetime);
   UNUSED(protId);
   if (mBuf != (Buffer *)NULLP)
   {
      SPutMsg(mBuf);
   }

   RETVALUE(ROK);
} /* end of PtLiSctDatReq */


/*
*
*       Fun:   Portable status request
*
*       Desc:  This function is used to request status
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptli.c
*
*/

#ifdef ANSI
PRIVATE S16 PtLiSctStaReq
(
Pst *pst,                 /* post structure */
SpId spId,                /* service provider SAP ID */
UConnId spAssocId,        /* service provider association ID */
CmNetAddr *dstNAddr,      /* dest. network address */
U8 staType                /* status type */
)
#else
PRIVATE S16 PtLiSctStaReq(pst, spId, spAssocId, dstNAddr, staType)
Pst *pst;                 /* post structure */
SpId spId;                /* service provider SAP ID */
UConnId spAssocId;        /* service provider association ID */
CmNetAddr *dstNAddr;      /* dest. network address */
U8 staType;               /* status type */
#endif
{
   TRC3(PtLiSctStaReq);

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG021, (ErrVal) 0,
                            "PtLiSctStaReq() called");
#endif

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(spAssocId);
   UNUSED(dstNAddr);
   UNUSED(staType);
   RETVALUE(ROK);
} /* end of PtLiSctStaReq */

#endif /* PTMGLISCT */

#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
/************************************************************************
                      MTP3 Portable Functions
************************************************************************/
#ifdef   PTMGLISNT
/*
 *
 *       Fun:   portable - Network Bind Request
 *
 *       Desc:  This function binds an GCP Entity to an MTP 3 Entity.
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  mg_ptli.c
 *
 */
#ifdef ANSI
PRIVATE S16 PtLiSntBndReq
(
Pst *pst,                       /* post structure */
SuId suId,                      /* service user id */
SpId spId,                      /* service provider id */
SrvInfo sInfo                   /* service information */
)
#else
PRIVATE S16 PtLiSntBndReq(pst, suId, spId, sInfo)
Pst *pst;                       /* post structure */
SuId suId;                      /* service user id */
SpId spId;                      /* service provider id */
SrvInfo sInfo;                  /* service information */
#endif
{
   TRC3(PtLiSntBndReq)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(spId);
   UNUSED(sInfo);
#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG022, (ErrVal) 0, "PtLiSctBndReq() called");
#endif

   RETVALUE(ROK);
} /* end of PtLiSntBndReq */

  
/*
 *
 *       Fun:   portable - Network Unit Data Request
 *
 *       Desc:  This function tells the MTP Level 3 to transmit data.
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  sp_ptli.c
 *
 */
#ifdef ANSI
PRIVATE S16 PtLiSntUDatReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc opc,                        /* originating pont code */
Dpc dpc,                        /* destination point code */
SrvInfo sInfo,                  /* service information */
LnkSel sls,                     /* signalling link selection */
Priority prior,                 /* priority */
Buffer *mBuf                    /* message buffer */
)
#else
PRIVATE S16 PtLiSntUDatReq(pst, spId, opc, dpc, sInfo, sls, prior, mBuf)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Dpc opc;                        /* originating pont code */
Dpc dpc;                        /* destination point code */
SrvInfo sInfo;                  /* service information */
LnkSel sls;                     /* signalling link selection */
Priority prior;                 /* priority */
Buffer *mBuf;                   /* message buffer */
#endif
{
   TRC3(PtLiSntUDatReq)

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(opc);
   UNUSED(dpc);
   UNUSED(sInfo);
   UNUSED(sls);
   UNUSED(prior);
   UNUSED(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG023, (ErrVal)ERRZERO, "PtLiSntUDatReq is called");
#endif /* ERRCLASS */

   RETVALUE(ROK);
}  /* end of PtLiSntUDatReq */

#ifdef SNT2
  
/*
 *
 *       Fun:   portable - Network status Request
 *
 *       Desc:  This function sends status request to MTP3
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  mg_ptli.c
 *
 */
#ifdef ANSI
PRIVATE S16 PtLiSntStaReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc dpc                         /* destination point code */
)
#else
PRIVATE S16 PtLiSntStaReq(pst, spId, dpc)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Dpc dpc;                        /* destination point code */
#endif
{
   TRC3(PtLiSntStaReq)

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(dpc);
#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG024, (ErrVal)ERRZERO, "PtLiSntStaReq is called");
#endif /* ERRCLASS */

   RETVALUE(ROK);
}  /* end of PtLiSntStaReq */
#endif /* SNT2 */


#endif   /* PTMGLISNT */

#endif   /* GCP_PROV_MTP3 */





/********************************************************************30**
  
         End of file:     mg_ptli.c@@/main/6 - Wed Mar 30 07:52:40 2005
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rrp  1. Initial release
1.2          ---      bbk  1. Fixed C++ compilation warnings
/main/3      ---       pk  1. Reorganized file for new release.
/main/4      ---      ra   1. GCP 1.3 release
/main/5      ---      ra   1. GCP 1.4 release. Added support for SCTP as
                              the lower layer.
/main/5      ---      ka   1. Changes for Release v 1.4
/main/6      ---      pk   1. GCP 1.5 release
           mg001.105  ra   1. Added TOS as the parameter. This is defined
                              within the SCT3 flag. This flag needs to be
                              defined in the make file. The envopt.h file
                              has also been modified for this.
           mg004.105  gk   1. Removed mgGenTrcInd call 
*********************************************************************91*/
