/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
 
     Name:     GCP - PLDF Functions
 
     Type:     C source file
  
     Desc:     C Source Code for PLDF module
 
     File:     mg_pldf.c
  
     Sid:      mp_pldf.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:53:44 2005
  
     Prg:      sk
  
*********************************************************************21*/
 
/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*
*/
 
/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*    
*   
*
*/

 
/*
 * The core of MGC product is implemented in following files:
 *
 *    mg_dns.c      DNS Interaction functions 
 *    mg_tmr.c      Timer Management/Maintenance functions
 *    mg_tpt.c      Transport Layer Interaction functions
 *    mg_trans.c    Transaction Management functions
 *    mg_cord.c     Co-ordinator Module functions
 *    mg_ui.c       MGCP Upper Interface Functions
 *    mg_mi.c       MGCP Layer Management Interface
 *    mg_li.c       MGCP Lower Layer (TUCL) Interface
 *    cm_tenc.c     Common Text Based Encode Engine for MGCP messages
 *    cm_tdec.c     Common Text Based Decode Engine for MGCP messages
 */

/* header include files (.h) */



#include "envopt.h"        /* Environment options */  
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */
#ifdef MG
#ifdef ZG_DFTHA
#include "gen.h"           /* General layer */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common Timer Library */
#include "cm_hash.h"       /* Hash library */
#include "cm_llist.h"      /* Doubly Linked List library */
#include "cm_inet.h"       /* Common Sockets Library */
#include "cm_tpt.h"        /* Common Transport Defines */
#include "cm_tkns.h"       /* Common Tokens Defines */
#include "cm_sdp.h"        /* Session Description Protocol Defines */
#include "cm_mblk.h"       /* Common Memory Manager Defines */
#include "cm_abnf.h"       /* Common ABNF  Defines */

#ifdef GCP_ASN
#include "mgasnwrp.h"         /* Encode/Decode wrappers */
#endif /* GCP_ASN */

#include "cm_dns.h"        /* common DNS library */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */
#include "mgt.h"           /* MGT Interface Defines */
#include "lmg.h"           /* MGCP Layer Management */
#include "mg_err.h"        /* MGCP Error Codes */
#include "mg.h"            /* MGCP Defines */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF's defines */
#endif /* ZG */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer */
#include "ssi.x"           /* System services */
#include "cm5.x"           /* Common Timer Library */
#include "cm_hash.x"       /* Hash library */
#include "cm_llist.x"      /* Doubly Linked List library */
#include "cm_inet.x"       /* Common Sockets Library */
#include "cm_tpt.x"        /* Common Transport Definitions */
#include "cm_tkns.x"       /* Common Tokens Defines */
#include "cm_lib.x"        /* Common library functions */
#include "cm_sdp.x"        /* Session Description Protocol Defines */
#include "cm_mblk.x"       /* Common Memory Manager Defines */
#include "cm_abnf.x"       /* Common ABNF  Defines */

#ifdef GCP_ASN
#include "mgasnwrp.x"         /* Encode/Decode wrappers */
#endif /* GCP_ASN */

#include "cm_dns.x"        /* common dns library */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */
#include "mgt.x"           /* MGT Interface Structures */
#include "lmg.x"           /* MGCP Layer Management */
#include "mg.x"            /* MGCP Data Structures */
#include "mg_db.x"         /* MGCP ABNF Datbase */
#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF's typedefs */
#endif /* ZG */

#ifdef GCP_MGCO
#include "mgco_db.x"       /* MEGACO ABNF Database */
#endif /* GCP_MGCO */



/* local defines, if any */

/* local typedefs, if any */
 
/* local externs, if any */

/* forward references */

/* public variable declaration */

/* private variable declaration */


/******************************************************************************/
/*                      Forward Declarations                                  */
/******************************************************************************/



/******************************************************************************/
/*                      PLDF Module Functions                         */
/******************************************************************************/

/*  README*********************************************************************
 * Whenever Non critical receives a message (either from Peer or User), if that
 * requires peer state change, then NC will generate reverse update to master
 * and queue the txn. PSF while sending reverse update also starts a timer..

 * Master after receiving Reverse update, processes it and generates run time
 * update (for control blocks whichever got changed). At the end of processing
 * PSF will send reverse update Ack.

 * Non critical after receiving the ack, checks its queue and process the
 * queued msg.
 
 * If master can't process reverse update successfully then it doesn't send Ack. * At NC side, reverse update timer will expire and the queued msg will be
 * freed.


 * Typically reverse update will be generated for following events:

1) service change/Rsip cmd from user: NonCritical will send reverse update and
queue the txns. After receiving reverse upadate ack..non critical will continue
processing the txn.

2) service change/RSIP Rsp from user: Non critical sends reverse update to
master ..and continue processing the txns. it doesn't queue the txn in this
case.

******************************************************************************/



#ifdef GCP_MGCO


/*
*
*       Fun:   mgSndRvUpdSvcRspP
*
*       Desc:  This function sends reverse update for service change reply from
*       peer.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or an acknowledgement or
*              acknowledgements for acknoledgements transmitted
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgSndRvUpdSvcRspP
(
UConnId            suConnId,           /* Listener Control Block */
CmTptAddr          *srcAddr,           /* Source Transport Address */
MgPeerCb           *peer,              /* Peer Id */
MgMgcoVersion      ver,                /* MEGACO version */
MgSvcChgInfo       *svcChg,            /* Service change or reply Information */
U8                 msgInfo,            /* txCb->msgInfo ?*/
U8                 qType               /* queue type */
)
#else
PUBLIC S16 mgSndRvUpdSvcRspP(suConnId, srcAddr, peer, ver, svcChg, msgInfo,
qType)
UConnId            suConnId;           /* Listener Control Block */
CmTptAddr          *srcAddr;           /* Source Transport Address */
MgPeerCb           *peer;              /* Peer Id */
MgMgcoVersion      ver;                /* MEGACO version */
MgSvcChgInfo       *svcChg;            /* Service change or reply Information */
U8                 msgInfo;            /* txCb->msgInfo ?*/
U8                 qType;              /* queue type */
#endif
{
   ZgRvUpdInfo          updInfo;

   TRC2(mgSndRvUpdSvcRspP)
      /* send reverse update */
   /* Fill all the relevant information which should go into
      *  reverse update */
   MG_FILL_RVUPD_SVCRSP_PEER(updInfo,peer,msgInfo, suConnId, ver, \
      svcChg, srcAddr);
   peer->tsap->rvNode = 
        (MgRvUpdQNode *)zgReverseUpd(&updInfo, peer->accessInfo.peerId,
                                     qType, peer->tsap->tsapCfg.tSAPId);
   RETVALUE(ROK);
} /* mgSndRvUpdSvcRspP */


/*
*
*       Fun:   mgPrcRvUpdSvcChgCmdU
*
*       Desc:  This function processes the reverse update sent by Nc after
*       receiving service change command from user.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdSvcChgCmdU 
(
ZgRvUpdInfo        *info,              /* Info to process rvrs update */
U32                *id                 /* peerId */
)
#else
PUBLIC S16 mgPrcRvUpdSvcChgCmdU(info , id)
ZgRvUpdInfo        *info;              /* Info to process rvrs update*/
U32                *id;                /* peerId */
#endif
{
   MgPeerCb     *peer;                 /* Peer Control block */
   U32           peerId;               /* peer id  */
   U8            idx;                  /* timer index */

   TRC2(mgPrcRvUpdSvcChgCmdU)

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG210, 0,
               "[MGCP] mgPrcRvUpdSvcChgCmdU : Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }
   
   peerId = info->u.sCmdU;

   /* Get peer control block from peerid */
   if(((peerId & DG_PEER_ID_MASK)>= mgCb.genCfg.maxPeer) ||  
         ((peer = MG_GET_PEER_FRM_PEERID(peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG211, 0,
               "[MGCP] mgPrcRvUpdSvcChgCmdU : Invalid PeerId \n");
#endif 
       RETVALUE(RFAILED);
   }
   if(peer->accessInfo.transportType == LMG_TPT_UDP)
   {
      if(peer->state == LMG_PEER_STATE_AWAIT_REG)
         peer->state = LMG_PEER_STATE_REGISTER;
   }
   else
   {
      if( (peer->state == LMG_PEER_STATE_AWAIT_REG) &&
          (mgCb.genCfg.entType == LMG_ENT_GW) )
      {  
         MgTptSrvr       *srvr;
         if ((srvr = mgGetSendSrvr(peer->ssap, peer)) == NULLP)
         {
            MG_INIT_TCP_CONN(peer, srvr); 
            if (srvr  == NULLP)
            {
#ifdef ZG
               zgUpdPeer();
#endif /* ZG */
               RETVALUE(RFAILED);
            }
         }
      }
   }
   /* stop restart timer if running */
   idx = MG_RST_AVLNCH_TMR - MG_PEER_TMR_BASE;

   if (peer->mntInfo.tmr[idx].tmrEvnt == MG_RST_AVLNCH_TMR)
      mgStopTmr(MG_RST_AVLNCH_TMR, (PTR)peer, &(peer->mntInfo.tmr[idx]));

#ifdef GCP_MG
   peer->ssap->crntMgc = peer;
#endif /* GCP_MG */

   /* Check for Peer State and accordingly change usrKnows
    Set usrKnows to TRUE if state is active/register */
   if((peer->state == LMG_PEER_STATE_ACTIVE) || 
      (peer->state == LMG_PEER_STATE_REGISTER))
   {
      peer->mntInfo.usrKnows = TRUE;
   }

   /* Now send runtime update for peer and ssap */
   zgRtUpd(ZG_CBTYPE_PEER,peer,CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_MOD); 
   zgRtUpd(ZG_CBTYPE_SSAP,peer->ssap,CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_MOD); 
   zgUpdPeer();
   *id = peer->accessInfo.peerId;
   RETVALUE(ROK);
}  /* end of mgPrcRvUpdSvcChgCmdU */


/*
*
*       Fun:   mgPrcRvUpdSvcChgRspU
*
*       Desc:  This function processes the reverse update sent by Nc after
*       receiving service change response from user.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdSvcChgRspU 
(
ZgRvUpdInfo        *info,              /* Info to process rvrs update */
U32                *id                 /* peerId */
)
#else
PUBLIC S16 mgPrcRvUpdSvcChgRspU(info , id)
ZgRvUpdInfo        *info;              /* Info to process rvrs update*/
U32                *id;                /* peerId */
#endif
{
   MgPeerCb     *peer;            /* Peer Control block */
   U8           regCmdMethod;     /* regitration command method */
   S32          lclPort;          /* local port */
   S16           ret;             /* return */
   MgSvcChgInfo *svcChgInfo;      /* service change information */
#ifdef GCP_MGC
   U8            idx;             /* timer index */
   S16           match;           
#ifdef ZG_DFTHA
   ZgProcUpdInfo  updInfo;        /* procedural Rt update info */
#endif /* ZG_DFTHA */
#endif /* GCP_MGC */

   TRC2(mgPrcRvUpdSvcChgRspU)

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG212, 0,
               "[MGCP] mgPrcRvUpdSvcChgRspU : Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }
   /* Get peer control block from peerid */
   if(((info->u.sRspU.peerId & DG_PEER_ID_MASK) >= mgCb.genCfg.maxPeer) ||  
         ((peer = MG_GET_PEER_FRM_PEERID(info->u.sRspU.peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG213, 0,
               "[MGCP] mgPrcRvUpdSvcChgRspU : Invalid PeerId \n");
#endif 
       /* send update to remove queued txn */
       RETVALUE(RFAILED);
   }

   /* Initialize variables from arguments */
   lclPort      = info->u.sRspU.lclPort;
   regCmdMethod = info->u.sRspU.regCmdMethod;
   svcChgInfo   = info->u.sRspU.svcChg;

   /* 
    * In case of service change reply, we only need to
    * process the case when restart or failover or handoff
    * is being issued : A case of new peer being acknowledged
    * by service user 
    */
   if ((mgCb.genCfg.entType == LMG_ENT_GC) &&
       (peer->state == LMG_PEER_STATE_REGISTER) &&
       ((regCmdMethod == MGT_SVCCHGMETH_RESTART) ||
        (regCmdMethod == MGT_SVCCHGMETH_FAILOVER) ||
        (regCmdMethod == MGT_SVCCHGMETH_HANDOFF)))
   {
#ifdef GCP_MGC
      if ((svcChgInfo->u.svcChgReply->pres.pres == PRSNT_NODEF) &&
          (svcChgInfo->u.svcChgReply->res.type.pres == PRSNT_NODEF) &&
          (svcChgInfo->u.svcChgReply->res.type.val == MGT_ERRDESC))
      {
         /* 
          * Service change reply is an error, This peer should 
          * be deleted after 30 seconds 
          * Start Delete Peer timer 
          */
         peer->state = LMG_PEER_STATE_AWAIT_REG;
         idx = MG_DEL_PEER_TMR - MG_PEER_TMR_BASE;
         if (peer->ssap->ssapCfg.reCfg.atMostOnceTmr.enb == TRUE)
         {
#ifdef ZG
            peer->delPeerTmr = TRUE;
#endif /* ZG */
            mgStartTmr(MG_DEL_PEER_TMR, 
                     peer->ssap->ssapCfg.reCfg.atMostOnceTmr.val,
                     (PTR)peer, &(peer->mntInfo.tmr[idx]));
         }
         /* Now send the state update */
         zgRtUpd(ZG_CBTYPE_PEER, peer, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
         RETVALUE(ROK);
      } 

      if ((svcChgInfo->u.svcChgReply->pres.pres == PRSNT_NODEF) &&
          (svcChgInfo->u.svcChgReply->res.type.pres == PRSNT_NODEF) &&
          (svcChgInfo->u.svcChgReply->res.type.val == MGT_SVCCHGDESC))
      {
         /* Service change reply is success for restart */
         /* Check whether redirection is required */
         MgMgcoMid *addr = &(svcChgInfo->u.svcChgReply->res.u.parm.addr);
            /* Only master should update critical information */
         peer->state = LMG_PEER_STATE_ACTIVE;
         if ((regCmdMethod == MGT_SVCCHGMETH_HANDOFF) &&
            (peer->ssap->ssapCfg.reCfg.atMostOnceTmr.enb == TRUE))
         {
            /* If service change is received with handoff, 
            * start handoff timer and set the flag in PeerCb */
            peer->mgcoInfo.hndOffInProg = TRUE;
            idx = MG_HANDOFF_TMR - MG_PEER_TMR_BASE;
            mgStartTmr(MG_HANDOFF_TMR, 
                     peer->ssap->ssapCfg.reCfg.atMostOnceTmr.val, 
                     (PTR)peer, &(peer->mntInfo.tmr[idx]));
         }

         if ((addr->type.pres == PRSNT_NODEF) &&
            (svcChgInfo->u.svcChgReply->res.u.parm.pres.pres == PRSNT_NODEF))
         {
             /* 
              * Indicates that service change address is present 
              * Check whether address matches the MId configured with SSAP,
              * compare IPV4 address or domain name whichever is applicable
              */
             match = mgMatchMId(peer, addr);

             if (match == MG_IGNORE)
             {
                peer->mgcoInfo.lclSrvcChngPort = lclPort;
             }
          } /* service change address present in the message */
          else if ((svcChgInfo->u.svcChgReply->res.u.parm.mgcId.type.pres == 
                   PRSNT_NODEF))
          {

             /* mgcId is available , delete the peer after 30 seconds */
             peer->state = LMG_PEER_STATE_AWAIT_REG;
             idx = MG_DEL_PEER_TMR - MG_PEER_TMR_BASE;
             if (peer->ssap->ssapCfg.reCfg.atMostOnceTmr.enb == TRUE)
             {
#ifdef ZG
                 peer->delPeerTmr = TRUE;
#endif /* ZG */
                 mgStartTmr(MG_DEL_PEER_TMR, 
                            peer->ssap->ssapCfg.reCfg.atMostOnceTmr.val,
                            (PTR)peer, &(peer->mntInfo.tmr[idx]));
             }
          }
          else 
          {
             /* 
              * service address and mgcId both are not present , 
              * copy lclPort to
              * mgcoInfo.lclSrvcChngPort 
              */
               peer->mgcoInfo.lclSrvcChngPort = lclPort;
          } /* service change address and MId are not present */
       } /* case of successful service change reply */
       /* Now send the state update */
       zgRtUpd(ZG_CBTYPE_PEER, peer, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);

#endif /* GCP_MGC */
    } /* service change reply for restart at MGC */
    else if ((mgCb.genCfg.entType == LMG_ENT_GW) &&
       (peer->state == LMG_PEER_STATE_UNDR_HNDOFF) &&
       (regCmdMethod == MGT_SVCCHGMETH_HANDOFF))
    {
       /* Response from service user for an earlier handoff request 
        * sent by peer */
      if ((svcChgInfo->u.svcChgReply->pres.pres == PRSNT_NODEF) &&
          (svcChgInfo->u.svcChgReply->res.type.pres == PRSNT_NODEF) &&
          (svcChgInfo->u.svcChgReply->res.type.val == MGT_ERRDESC))
      {
         /* Service user rejected handoff */
         /* In this case we should delete the new peer and just carry on 
          * with the current peer */
         if (peer->mgcoInfo.t.handOffMGC != NULLP)
         {
            mgDeletePeer(peer->mgcoInfo.t.handOffMGC, LMG_EVENT_PEER_REMOVED,
                         LMG_CAUSE_HANDOFF, FALSE);
         }
         peer->state = LMG_PEER_STATE_ACTIVE;
         peer->mgcoInfo.t.handOffMGC = NULLP;
         /* Now send the state update */
         zgRtUpd(ZG_CBTYPE_PEER, peer, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
      }
      else
      {
         MgPeerCb  *hndOffPeer;
          /* initiate handoff procedure */
         hndOffPeer = peer->mgcoInfo.t.handOffMGC;
         /* send request for resolution from DNS if required */
         ret = ROK;
         /* move resolution procedure */
         if (hndOffPeer->accessInfo.peerAddrTbl.count == MG_NONE)
         {
            hndOffPeer->state = LMG_PEER_STATE_RESOLVING;
            ret = mgSendDnsRslvReq(hndOffPeer, hndOffPeer->accessInfo.name);
         }
         if (ret == ROK)
             ret = mgSendSrvcChng(hndOffPeer, MGT_SVCCHGMETH_HANDOFF,
                                  MG_SCRSN_MGC_DIR_CHNG, NULLP,
                                  LMG_INVALID_PEER_PORT, NULLP);
         /* Now send the state update */
         zgRtUpd(ZG_CBTYPE_PEER, hndOffPeer, CMPFTHA_UPDTYPE_SYNC, 
            CMPFTHA_ACTN_MOD);
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
      }
   } /* handoff case at MG */
   else if ((mgCb.genCfg.entType == LMG_ENT_GC) &&
       (peer->state == LMG_PEER_STATE_FAILOVER) &&
        (regCmdMethod == MGT_SVCCHGMETH_FAILOVER))
   {
#ifdef GCP_MGC
      MgPeerCb   *matedPeer = peer->mgcoInfo.t.matedMG;
      /* active MG indicated that it is failing */
      if ((peer->mgcoInfo.peerType == MG_ACTIVE) &&
         (matedPeer != NULLP) &&
         (matedPeer->mgcoInfo.peerType == MG_STANDBY))
      {
         if (matedPeer->state == LMG_PEER_STATE_ACTIVE)
         {
            /* keep association with standby peer and
             * make standby peer active and vice versa 
             * , so all new requests
             * and replies to existing requests go to
             * standby peer only */
             peer->mgcoInfo.peerType = MG_STANDBY;
             matedPeer->mgcoInfo.peerType = MG_ACTIVE;
             mgMoveAllTxn(peer, matedPeer, MG_INTERNAL);
             peer->state = LMG_PEER_STATE_AWAIT_REG;
             /* Now send the state update */
             /* set state update for peers..also send update to move all txn
              * from peer to matedPeer */
#ifdef ZG_DFTHA
             /* send update to all shadows to move txn */
             updInfo.procType = ZG_PROCTYPE_MOVE_TRANS;
             updInfo.u.cntrlTrans.peerId = peer->accessInfo.peerId;
             updInfo.u.cntrlTrans.newPeerId = matedPeer->accessInfo.peerId;
             updInfo.u.cntrlTrans.info.transType = MGT_ALL_TRANS;
             updInfo.u.cntrlTrans.source = MG_INTERNAL;
             zgRtProcUpd(&updInfo, CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);
#endif /* ZG_DFTHA */
             zgRtUpd(ZG_CBTYPE_PEER, peer, CMPFTHA_UPDTYPE_SYNC, 
                CMPFTHA_ACTN_MOD);
             zgRtUpd(ZG_CBTYPE_PEER, matedPeer, CMPFTHA_UPDTYPE_SYNC, 
                CMPFTHA_ACTN_MOD);

         }
         else
         {
            /* Other peer is not ready to take over,
             * delete both peers */
             mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED,
                          LMG_CAUSE_UNKNOWN, FALSE);
             mgDeletePeer(matedPeer, LMG_EVENT_PEER_REMOVED,
                          LMG_CAUSE_UNKNOWN, FALSE);
         }
      }
#endif /* GCP_MGC */
   } /* failover case for active MG */
    
   zgUpdPeer();
   *id = peer->accessInfo.peerId;
   RETVALUE(ROK);
}  



/*
*
*       Fun:   mgPrcRvUpdSvcChgCmdP
*
*       Desc:  This function processes the reverse update sent by Nc after
*       receiving service change command from Peer.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdSvcChgCmdP
(
ZgRvUpdInfo         *info,              /* Info to process rvrs update */
U32                 *id,                /* peerId */
MgTSAPCb            *tsap               /* TSAP Control block */
)
#else
PUBLIC S16 mgPrcRvUpdSvcChgCmdP(info , id, tsap)
ZgRvUpdInfo         *info;              /* Info to process rvrs update*/
U32                 *id;                /* peerId */
MgTSAPCb            *tsap;              /* TSAP Control block */
#endif
{
   MgPeerCb         *peer;            /* Peer Control block */
   MgTptSrvr        *srvr;            /* srvr control block */
   CmTptAddr        *srcAddr;         /* source address */
   MgSvcChgInfo     *svcChgInfo;      /* Service Change Inforamtion Structure */
   TknStrOSXL       *msgMid;          /* mid in MEGACO message*/
   MgMgcoVersion    *msgVer;          /* version in MEGACO message*/
   S16              errAction;        /* Action to be taken on error */
   S16              rspCode;          /* Error Response Code */
   S16              ret;              /* return value */
   MgMgcoTxn        *mgcoTxn;         /* MEGACo transaction */
   
   TRC2(mgPrcRvUpdSvcChgCmdP)

   mgcoTxn = NULLP;

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG214, 0,
               "[MGCP] mgPrcRvUpdSvcChgCmdP : Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }

  /* Now call mgProcessSrvcChng function to process this reverse update..don't
   * process rxCb in this case */
   
   msgMid      = info->u.sCmdP.mid;
   msgVer      = &(info->u.sCmdP.ver);
   svcChgInfo  = info->u.sCmdP.svcChg;
   srcAddr     = info->u.sCmdP.srcTptAddr;
   MG_GET_SRVRCB(srvr, (info->u.sCmdP.suConnId), tsap);
   /* Initialize srvr->suRsetId; Since "info->u.sCmdP.suConnId" has rset 
      embedded into it */
   if(srvr)
   {
      srvr->suRsetId = info->u.sCmdP.suConnId;
   }
   
   if(info->u.sCmdP.peerId == MG_INVALID_PEERID)
   {
      peer = NULLP;
   }
   else
   {
      peer = MG_GET_PEER_FRM_PEERID(info->u.sCmdP.peerId);
   }
      
   /* Process Service change message */
   ret = mgProcessSrvcChng(&errAction, &rspCode, msgMid, 
                           msgVer, svcChgInfo, &peer, tsap,
#if    (defined(GCP_PROV_MTP3) || defined(GCP_PROV_SCTP))
                           NULLP,     
#endif    /* GCP_PROV_MTP3 || GCP_PROV_SCTP  */                   
                           srvr, srcAddr, MG_INVALID_TRANSID, FALSE,
                           mgcoTxn);

   if(ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   /* Send state updates */
   zgUpdPeer();
   *id = peer->accessInfo.peerId;
      
   RETVALUE(ROK);
} /* mgPrcRvUpdSvcChgCmdP */



/*
*
*       Fun:   mgPrcRvUpdSvcChgRspP
*
*       Desc:  This function processes the reverse update sent by Nc after
*       receiving service change response from Peer.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdSvcChgRspP
(
ZgRvUpdInfo         *info,              /* Info to process rvrs update */
U32                 *id                 /* peerId */
)
#else
PUBLIC S16 mgPrcRvUpdSvcChgRspP(info , id)
ZgRvUpdInfo         *info;              /* Info to process rvrs update*/
U32                 *id;                /* peerId */
#endif
{
   MgPeerCb         *peer;            /* Peer Control block */
   MgTptSrvr        *srvr;            /* srvr control block */
   CmTptAddr        *srcAddr;         /* source address */
   MgSvcChgInfo     *svcChgInfo;      /* Service Change Inforamtion Structure */
   MgMgcoVersion    *msgVer;          /* version in MEGACO message*/
   U8               msgInfo;          /* msg Information */
   S16              errAction;        /* Action to be taken on error */
   S16              ret;              /* return value */
   MgTxTransIdEnt   *txCb;            /* transaction control block */
   
   TRC2(mgPrcRvUpdSvcChgRspP)

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG215, 0,
               "[MGCP] mgPrcRvUpdSvcChgRspP : Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }

   /* Get peer control block from peerid */
   if(((info->u.sRspP.peerId  & DG_PEER_ID_MASK)>= mgCb.genCfg.maxPeer) ||  
         ((peer = MG_GET_PEER_FRM_PEERID(info->u.sRspP.peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG216, 0,
               "[MGCP] mgPrcRvUpdSvcChgRspU : Invalid PeerId \n");
#endif 
       RETVALUE(RFAILED);
   }

  /* Now call mgProcessSrvcChng function to process this reverse update..don't
   * process rxCb in this case */
   txCb = NULLP;
   
   msgVer      = &(info->u.sRspP.ver);
   svcChgInfo = info->u.sRspP.svcChg;
   srcAddr     = info->u.sRspP.srcTptAddr;
   msgInfo     = info->u.sRspP.msgInfo;
   MG_GET_SRVRCB(srvr, (info->u.sRspP.suConnId), peer->tsap);

   ret = mgProcessSrvcChngReply(&errAction, msgVer, svcChgInfo, peer,
                                srvr, srcAddr, msgInfo, MG_INVALID_TRANSID, 
                                FALSE, &txCb);

   /* Check for Peer State and accordingly change usrKnows
    Set usrKnows to TRUE if state is active/register */
   if((peer->state == LMG_PEER_STATE_ACTIVE) || 
      (peer->state == LMG_PEER_STATE_REGISTER))
   {
      peer->mntInfo.usrKnows = TRUE;
   }
   if(ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   zgUpdPeer();
   *id = peer->accessInfo.peerId;

   RETVALUE(ROK);

}   /* end of mgPrcRvUpdSvcChgRspP() */

#ifdef GCP_MG
/*
*
*       Fun:   mgPrcRvUpdAdjPeer
*
*       Desc:  This function processes the reverse update sent by Nc for
*       adjusting peer. This is the case when peer exists in Mid list as well as
*       IP/domain list.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdAdjPeer
(
ZgRvUpdInfo         *info,              /* Info to process rvrs update */
U32                 *id,                /* peerId */
MgTSAPCb            *tsap               /* TSAP Control block */
)
#else
PUBLIC S16 mgPrcRvUpdAdjPeer(info , id, tsap)
ZgRvUpdInfo         *info;              /* Info to process rvrs update */
U32                 *id;                /* peerId */
MgTSAPCb            *tsap;              /* TSAP Control block */
#endif
{
   MgPeerCb         *peer;            /* Peer Control block */
   MgTptSrvr        *srvr;            /* srvr control block */
   CmTptAddr        *srcAddr;         /* source address */
   TknStrOSXL       *mid;             /* mid */
   MgSSAPCb         *ssap;            /* ssap pointer */
   Bool             sendUpd;          /* send update */
   
   TRC2(mgPrcRvUpdAdjPeer)

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG217, 0,
               "[MGCO] mgPrcRvUpdAdjPeer: Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }

   /* Get peer control block from peerid */
   if((info->u.adjPeer.mid  == NULLP) || (info->u.adjPeer.addr == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG218, 0,
               "[MGCO] mgPrcRvUpdAdjPeer: Invalid parameter \n");
#endif 
       RETVALUE(RFAILED);
   }
   /* initialize all the parameters */
   srcAddr = (info->u.adjPeer.addr);
   mid     = (info->u.adjPeer.mid);
   MG_GET_SRVRCB(srvr, (info->u.adjPeer.suConnId), tsap);

   if(srvr == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG219, 0,
               "[MGCO] mgPrcRvUpdAdjPeer: Invalid parameter \n");
#endif 
       RETVALUE(RFAILED);
   }

   if(srvr->transportType == LMG_TPT_TCP)
   {
      ssap = srvr->t.peer->ssap;
   }
   else
   {
      ssap = srvr->t.ssap;
   }

   sendUpd = FALSE;
   /* call function to adjust peer into different list */
   peer = mgGetAndAdjstPeerInLst(mid, srcAddr, NULLP, ssap, &sendUpd);

   if((peer == NULLP) || (sendUpd == TRUE))
   {
      zgUpdPeer();
      RETVALUE(RFAILED);
   }
   zgUpdPeer();
   *id = peer->accessInfo.peerId;
   RETVALUE(ROK);
}   /* mgPrcRvUpdAdjPeer () */

#endif /* GCP_MG */

#endif /* GCP_MGCO */

/*
*
*       Fun:   mgPrcRvUpdRegCmdInt
*
*       Desc:  This function sends RSIP/SRVCCHNG command to peer. This function
*       will be called once reverse update from Nc is rcved
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdRegCmdInt
(
ZgRvUpdInfo        *info,              /* Info to process rvrs update */
U32                *id                 /* peerId */
)
#else
PUBLIC S16 mgPrcRvUpdRegCmdInt(info , id)
ZgRvUpdInfo        *info;              /* Info to process rvrs update*/
U32                *id;                /* peerId */
#endif
{
   MgPeerCb        *peer;            /* Peer Control block */
   U8               mthd;            /* RSIP/SvcChng Method*/
   S16              ret;             /* return value */
   
   TRC2(mgPrcRvUpdRgCmdInt)

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG220, 0,
               "[MGCP] mgPrcRvUpdRegCmdInt: Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }

   /* Get peer control block from peerid */
   if(((info->u.rsCmdI.peerId  & DG_PEER_ID_MASK)>= mgCb.genCfg.maxPeer) ||  
         ((peer = MG_GET_PEER_FRM_PEERID(info->u.rsCmdI.peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG221, 0,
               "[MGCP] mgPrcRvUpdRegCmdInt : Invalid PeerId \n");
#endif 
       /* send update to remove queued txn */
       RETVALUE(RFAILED);
   }
   /* get method */
   mthd = info->u.rsCmdI.method;
   
   if(peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
   {
#ifdef GCP_MGCO
     ret = mgSendSrvcChng(peer, mthd, NULLP, NULLP, (S32)MGT_NONE, NULLP); 
#endif /* GCP_MGCO */
   }
   else
   {
#ifdef GCP_MGCP
#ifdef GCP_MG
     ret = mgMgcpSendRSIP(peer, mthd);
#endif /* GCP_MG */
#endif /* GCP_MGCP */
   }
   if(ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   *id = peer->accessInfo.peerId;
   zgUpdPeer();
      
   RETVALUE(ROK);
}   /* end of fn mgPrcRvUpdRegCmdInt */

#ifdef GCP_MGCP

#ifdef GCP_MGC

/*
*
*       Fun:   mgPrcRvUpdRsipCmdP
*
*       Desc:  This function prcesses reverse update for RSIP command
*       from Peer.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdRsipCmdP
(
ZgRvUpdInfo         *info,              /* Info to process rvrs update */
U32                 *id,                /* peerId */
MgTSAPCb            *tsap               /* TSAP Control block */
)
#else
PUBLIC S16 mgPrcRvUpdRsipCmdP(info , id, tsap)
ZgRvUpdInfo         *info;              /* Info to process rvrs update*/
U32                 *id;                /* peerId */
MgTSAPCb            *tsap;              /* TSAP Control block */
#endif
{
   MgPeerCb         *peer;            /* Peer Control block */
   U32              variant;          /* Variant of protocol */
   U8               mthd;             /* method */
   MgTptSrvr        *srvr;            /* SuConnId */
   MgEPName         *endPt;           /* endpoint name */
   CmTptAddr        *tptAddr;         /* source transport address */
   S16              errAction;        /* error action */
   U32              rspCode;          /* response code */
   MgTransId        trId;             /* Transction id */
   Bool             newPeer;          /* Is this new peer */
   S16              ret;              /* return value */
   
   TRC2(mgPrcRvUpdRsipCmdP)

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG222, 0,
               "[MGCP] mgPrcRvUpdRsipCmdP: Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }

   /* Get peer control block from peerid */
   if(info->u.rCmdP.peerId == MG_INVALID_PEERID)
   {
      peer= NULLP;
   }
   else
   {
      peer = MG_GET_PEER_FRM_PEERID(info->u.rCmdP.peerId);
   }

   /* Get all the information to process RSIP command from peer */
   trId    = info->u.rCmdP.trId;
   variant = info->u.rCmdP.variant;
   mthd    = info->u.rCmdP.method;
   endPt   = info->u.rCmdP.endPt;
   tptAddr = info->u.rCmdP.srcTptAddr;
   newPeer = FALSE;
   /* get srvr control block */
   MG_GET_SRVRCB(srvr, (info->u.rCmdP.suConnId), tsap);
   /* Initialize srvr->suRsetId; Since "info->u.rCmdP.suConnId" has rset 
      embedded into it */
   if(srvr)
   {
      srvr->suRsetId = info->u.rCmdP.suConnId;
   }

   
   ret = mgProcessRSIP(&errAction, &rspCode, variant, mthd, endPt, &peer,
             srvr, tptAddr, &newPeer, tsap);
   
   if(ret != ROK)
   {
      /* send error response to peer */
      mgMgcpSendErrorResponse(tptAddr, trId, rspCode, 
                              (U8 *)"Decoding of the Command Failed",
                              tsap);
      RETVALUE(RFAILED);
   }
   else
   {
      if (newPeer == TRUE)
      {
         /* Update the next SSAP Id */
         MG_UPDATE_NXTUSE_MGCP_SSAPID();

         MG_ISSUE_MGCPPEER_STAIND(peer, LCM_CATEGORY_PROTOCOL, 
                     LMG_EVENT_PEER_ENABLED, LMG_CAUSE_RSIP_ACCEPTED);
      }      
   }
   zgUpdPeer();
   *id = peer->accessInfo.peerId;

   RETVALUE(ROK);
}   /* end of fn MgRvUpdRsipCmdP*/


/*
*
*       Fun:   mgPrcRvUpdRsipRspU
*
*       Desc:  This function prcesses reverse update for RSIP rsp from user.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdRsipRspU
(
ZgRvUpdInfo        *info,              /* Info to process rvrs update */
U32                *id                 /* peerId */
)
#else
PUBLIC S16 mgPrcRvUpdRsipRspU(info , id)
ZgRvUpdInfo        *info;              /* Info to process rvrs update*/
U32                *id;                /* peerId */
#endif
{
   MgPeerCb         *peer;            /* Peer Control block */
   
   TRC2(mgPrcRvUpdRsipRspU)

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG223, 0,
               "[MGCP] mgPrcRvUpdRsipRspU: Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }

   /* Get peer control block from peerid */
   if(((info->u.rRspU.peerId & DG_PEER_ID_MASK) >= mgCb.genCfg.maxPeer) ||  
         ((peer = MG_GET_PEER_FRM_PEERID(info->u.rRspU.peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG224, 0,
               "[MGCP] mgPrcRvUpdRsipRspU: Invalid PeerId \n");
#endif 
       RETVALUE(RFAILED);
   }

   if (peer->state == LMG_PEER_STATE_REGISTER)
      peer->state = LMG_PEER_STATE_ACTIVE;

   zgRtUpd(ZG_CBTYPE_PEER,peer,CMPFTHA_UPDTYPE_SYNC,
         CMPFTHA_ACTN_MOD); 
   zgUpdPeer();
   *id = peer->accessInfo.peerId;

   RETVALUE(ROK);
}   /* end of fn MgPrcRvUpdRsipRspU*/

#endif /* GCP_MGC */

#ifdef GCP_MG

/*
*
*       Fun:   mgPrcRvUpdRsipCmdU
*`
*       Desc:  This function prcesses reverse update for RSIP
*       will be called once reverse update from Nc is rcved
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdRsipCmdU
(
ZgRvUpdInfo        *info,              /* Info to process rvrs update */
U32                *id                 /* peerId */
)
#else
PUBLIC S16 mgPrcRvUpdRsipCmdU(info , id)
ZgRvUpdInfo        *info;              /* Info to process rvrs update*/
U32                *id;                /* peerId */
#endif
{
   MgPeerCb        *peer;              /* Peer Control block */
   U32              peerId;            /* peer id in info */
   
   TRC2(mgPrcRvRsipCmdUsr)

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG225, 0,
               "[MGCP] mgPrcRvUpdRsipCmdU: Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }

   peerId = info->u.rCmdU;

   /* Get peer control block from peerid */
   if(((peerId & DG_PEER_ID_MASK)>= mgCb.genCfg.maxPeer) ||  
         ((peer = MG_GET_PEER_FRM_PEERID(peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG226, 0,
               "[MGCP] mgPrcRvUpdRsipCmdU: Invalid PeerId \n");
#endif 
       RETVALUE(RFAILED);
   }
   
   if((peer->state == LMG_PEER_STATE_AWAIT_REG) 
         || (peer->state == LMG_PEER_STATE_DISCONNECTED))
   {
      peer->state = LMG_PEER_STATE_REGISTER;
   }

   /* Check for Peer State and accordingly change usrKnows
    Set usrKnows to TRUE if state is active/register */
   if((peer->state == LMG_PEER_STATE_ACTIVE) || 
      (peer->state == LMG_PEER_STATE_REGISTER))
   {
      peer->mntInfo.usrKnows = TRUE;
   }
   
   
   zgRtUpd(ZG_CBTYPE_PEER,peer,CMPFTHA_UPDTYPE_SYNC,
      CMPFTHA_ACTN_MOD);
   zgUpdPeer();
   *id = peer->accessInfo.peerId;

   /* After receiving this update NcRset will look into peer->usrTxnQ and
    * transmit the message */
      
   RETVALUE(ROK);
}   /* end of fn MgPrcRvRsipCmdU*/

/*
*
*       Fun:   mgPrcRvUpdRsipRspP
*
*       Desc:  This function prcesses reverse update for RSIP response
*       from Peer.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdRsipRspP
(
ZgRvUpdInfo         *info,              /* Info to process rvrs update */
U32                 *id                 /* peerId */
)
#else
PUBLIC S16 mgPrcRvUpdRsipRspP(info , id)
ZgRvUpdInfo         *info;              /* Info to process rvrs update*/
U32                 *id;                /* peerId */
#endif
{
   MgPeerCb         *peer;            /* Peer Control block */
   U32              variant;          /* Variant of protocol */
   S16              errAction;        /* error action */
   U32              action;           /* Action */
   U32              rspCode;          /* response code */
   MgNtfiedEnt      *ntfiedEnt;       /* MGCP notified entity */
   MgTransId        trId;             /* transaction id */
   S16              ret;              /* return value */

   
   TRC2(mgPrcRvUpdRsipRspP)

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG227, 0,
               "[MGCP] mgPrcRvUpdRsipRspP: Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }

   /* Get peer control block from peerid */
   if(((info->u.rRspP.peerId & DG_PEER_ID_MASK) >= mgCb.genCfg.maxPeer) ||  
         ((peer = MG_GET_PEER_FRM_PEERID(info->u.rRspP.peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG228, 0,
               "[MGCP] mgPrcRvUpdRsipRspU: Invalid PeerId \n");
#endif 
       RETVALUE(RFAILED);
   }

   /* Get all the information to process RSIP command from peer */
   variant   = info->u.rRspP.variant;
   rspCode   = info->u.rRspP.rspCode;
   ntfiedEnt = info->u.rRspP.ntfyEnt;
   trId      = info->u.rRspP.trId;      

   ret = mgMgcpPrcRSIPResponse(&errAction,&action,peer,rspCode,ntfiedEnt,
            variant, trId); 
   /* Check for Peer State and accordingly change usrKnows
    Set usrKnows to TRUE if state is active/register */
   if((peer->state == LMG_PEER_STATE_ACTIVE) || 
      (peer->state == LMG_PEER_STATE_REGISTER))
   {
      peer->mntInfo.usrKnows = TRUE;
   }
   /* generate run time update to all shadows */
   zgRtUpd(ZG_CBTYPE_PEER,peer,CMPFTHA_UPDTYPE_SYNC,
         CMPFTHA_ACTN_MOD); 
   zgUpdPeer();
   *id = peer->accessInfo.peerId;

   RETVALUE(ret);
}   /* end of fn MgRvUpdRsipRspP*/

/*
*
*       Fun:   mgPrcRvUpdNtfyEnt
*
*       Desc:  This function prcesses reverse update for notified entity
*       parameter in received command from peer  
*       from Peer.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdNtfyEnt
(
ZgRvUpdInfo   *info,              /* Info to process rvrs update */
U32           *id                 /* peerId */
)
#else
PUBLIC S16 mgPrcRvUpdNtfyEnt(info, id) 
ZgRvUpdInfo   *info;              /* Info to process rvrs update*/
U32           *id;                /* peerId */
#endif
{
   MgPeerCb         *peer;            /* Peer Control block */
   MgPeerCb         *newPeer;         /* Peer Control block */
   U32              variant;          /* Variant of protocol */
   MgNtfiedEnt      *ntfiedEnt;       /* MGCP notified entity */

   
   TRC2(mgPrcRvUpdNtfyEnt)

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG229, 0,
               "[MGCP] : mgPrcRvUpdNtfyEnt Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }

   /* Get peer control block from peerid */
   if(((info->u.ntfyInfo.peerId & DG_PEER_ID_MASK) >= mgCb.genCfg.maxPeer) ||  
         ((peer = MG_GET_PEER_FRM_PEERID(info->u.ntfyInfo.peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG230, 0,
               "[MGCP] mgPrcRvUpdNtfyEnt : Invalid PeerId \n");
#endif 
       RETVALUE(RFAILED);
   }

   variant   = info->u.ntfyInfo.variant;
   ntfiedEnt = info->u.ntfyInfo.ntfiedEnt;
   newPeer = NULLP;

   if(mgMgcpChkAndPrcNtfiedEntity(ntfiedEnt, peer, &newPeer, variant) ==
      RFAILED)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG231, 0,
               "[MGCP] mgPrcRvUpdNtfyEnt : ntfied ent processing failed\n");
#endif 
       RETVALUE(RFAILED);
   }
   /* send state updates */
   zgUpdPeer();
   if(newPeer == NULLP)
   {
      /* This is the case..when peer is created and then deleted ( since it
       * couldn't be resolved ) ..then don't send reverse update Ack..txn will
       * be dropped at non critical after timer expiry */ 
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* mgPrcRvUpdNtfyEnt */

#endif /* GCP_MG */
#endif /* GCP_MGCP */


/*
*
*       Fun:   mgPrcRvUpdDelPeer
*
*       Desc:  This function prcesses reverse update for Deleting peer.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdDelPeer
(
ZgRvUpdInfo       *info,              /* Info to process rvrs update */
U32               *id                 /* peerId */
)
#else
PUBLIC S16 mgPrcRvUpdDelPeer(info , id)
ZgRvUpdInfo       *info;              /* Info to process rvrs update*/
U32               *id;                /* peerId */
#endif
{
   MgPeerCb         *peer;            /* Peer Control block */
   U16              event;            /* event */
   U16              cause;            /* cause for peer delete */
   Bool             delReqd;          /* peer to be deleted ?? */
   
   TRC2(mgPrcRvUpdDelPeer)

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG232, 0,
               "[MGCP] : mgPrcRvUpdDelPeer Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }

   /* Get peer control block from peerid */
   if(((info->u.delPeer.peerId & DG_PEER_ID_MASK) >= mgCb.genCfg.maxPeer) ||  
         ((peer = MG_GET_PEER_FRM_PEERID(info->u.delPeer.peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG233, 0,
               "[MGCP] mgPrcRvUpdDelPeer : Invalid PeerId \n");
#endif 
       RETVALUE(RFAILED);
   }

   /* Check for Peer State and accordingly change usrKnows
    Set usrKnows to TRUE if state is active/register */
   if((peer->state != LMG_PEER_STATE_ACTIVE) && 
      (peer->state != LMG_PEER_STATE_REGISTER))
   {
      peer->mntInfo.usrKnows = FALSE;
   }

   event   = info->u.delPeer.peerId;
   cause   = info->u.delPeer.cause;
   delReqd = info->u.delPeer.delReqd;

   mgDeletePeer(peer, event,cause, delReqd);
   zgUpdPeer();

   RETVALUE(ROK);
}   /* end of fn MgRvUpdDelPeer*/


/*
*
*       Fun:   mgPrcRvUpdRetxFailed
*
*       Desc:  This function prcesses reverse update for retx failure.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdRetxFailed 
(
ZgRvUpdInfo      *info,               /* Info to process rvrs update */
U32              *id                 /* peerId */
)
#else
PUBLIC S16 mgPrcRvUpdRetxFailed(info , id)
ZgRvUpdInfo      *info;              /* Info to process rvrs update*/
U32              *id;                /* peerId */
#endif
{
   MgPeerCb         *peer;            /* Peer Control block */
   U32               peerId;          /* peer Id from info */

   
   TRC2(mgPrcRvUpdRetxFailed)


   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG234, 0,
               " mgPrcRvUpdRetxFailed Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }

   peerId = info->u.retxPeer;

   /* Get peer control block from peerid */
   if(((peerId & DG_PEER_ID_MASK) >= mgCb.genCfg.maxPeer) ||  
         ((peer = MG_GET_PEER_FRM_PEERID(peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG235, 0,
               "mgPrcRvUpdRetxFailed : Invalid PeerId \n");
#endif 
       RETVALUE(RFAILED);
   }
   
#ifdef GCP_MGCO
   if(peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
   {
      if (mgCb.genCfg.entType == LMG_ENT_GW)
      {
#ifdef GCP_MG         
         mgProcessPeerMGCFailure(peer);
         RETVALUE(ROK);
#endif /* GCP_MG */        
      }
#ifndef GCP_USER_RETX_CNTRL
      else
         mgDeletePeer (peer, LMG_EVENT_PEER_REMOVED, 
                        LMG_CAUSE_PEER_NOT_RESPONDING, FALSE);
#endif /* GCP_USER_RETX_CNTRL */
   }
   else
#endif /* GCP_MGCO */
   {
      peer->state = LMG_PEER_STATE_DISCONNECTED;
      mgDeletePeer (peer, LMG_EVENT_PEER_REMOVED,
                       LMG_CAUSE_PEER_NOT_RESPONDING, FALSE);
   }

   zgUpdPeer();
   RETVALUE(ROK);
} /* mgPrcRvUpdRetxFailed */


/*
*
*       Fun:   mgPrcRvUpdRslvPeer
*
*       Desc:  This function prcesses reverse update for reSolve peer. Typically
*       when Nc needs to resolve peer ( when retx fails ) it sends reverse
*       update to peer.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdRslvPeer 
(
ZgRvUpdInfo    *info,               /* Info to process rvrs update */
U32            *id                 /* peerId */
)
#else
PUBLIC S16 mgPrcRvUpdRslvPeer (info, id )
ZgRvUpdInfo    *info;              /* Info to process rvrs update*/
U32            *id;                /* peerId */
#endif
{
   MgPeerCb         *peer;            /* Peer Control block */
   U32               peerId;          /* peer Id */

   
   TRC2(mgPrcRvUpdRslvPeer)

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG236, 0,
               " mgPrcRvUpdRetxFailed Fn called from Shadow \n");
#endif 
       RETVALUE(RFAILED);
   }

   peerId = info->u.rslvPeer;

   /* Get peer control block from peerid */
   if(((peerId & DG_PEER_ID_MASK) >= mgCb.genCfg.maxPeer) ||  
         ((peer = MG_GET_PEER_FRM_PEERID(peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG237, 0,
               "mgPrcRvUpdRetxFailed : Invalid PeerId \n");
#endif 
       RETVALUE(RFAILED);
   }

   mgSendDnsRslvPeer(peer);
   zgUpdPeer();
   RETVALUE(ROK);
} /* mgPrcRvUpdRslvPeer */


/*
*
*       Fun:   mgQueueRvUpdTxnInd
*
*       Desc:  This function queues a transaction indication, when GCP copy
*              sends a reverse update to the master copy and waits for an ack
*              to process the queued message.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mp_pldf.c
*
*/
#ifdef ANSI
PUBLIC S16 mgQueueRvUpdTxnInd
(
Ptr                 msg,               /* msg buffer to be processed later */
MgRvUpdQNode       *queue,             /* list in which node is queued */
MgRvUpdQNode       *node,              /* allocated for storing queued info */
U8                  prot,              /* protocol - MGCP/MEGACO */
CmTptAddr          *srcAddr,           /* Source transport address */
MgTptSrvr          *srvr               /* listener control block */
)
#else
PUBLIC S16 mgQueueRvUpdTxnInd(msg, queue, node, prot, srcAddr, srvr)
Ptr                 msg;               /* msg buffer to be processed later */
MgRvUpdQNode       *queue;             /* list in which node is queued */
MgRvUpdQNode       *node;              /* allocated for storing queued info */
U8                  prot;              /* protocol - MGCP/MEGACO */
CmTptAddr          *srcAddr;           /* Source transport address */
MgTptSrvr          *srvr;              /* listener control block */
#endif
{
   MgRvrsQTxnInd      *qTxn;           /* info stored with the txn */
   MgRvUpdQNode       *tmp;            /* temporary node for list traversal */

   TRC2(mgQueueRvUpdTxnInd)

   if ((qTxn = (MgRvrsQTxnInd *)mgMalloc(sizeof(MgRvrsQTxnInd))) != NULLP)
   {
      qTxn->msg =  (Ptr)(msg);
      qTxn->prot = prot;
      qTxn->srcAddr = *(srcAddr);
      qTxn->connId = srvr->suConnId;
   }

   if (node != NULLP)
   {
      node->info = (Ptr)qTxn;
      node->next = NULLP;
      node->prev = NULLP;
      node->prot = prot;

      /* Now add the node into linked list */
      tmp = queue;
      while (tmp->next != NULLP)
      {
         tmp = tmp->next;
      }

      tmp->next = node;
      node->prev = tmp;
   } /* if node is not NULL */

   RETVALUE(ROK);
} /* mgQueueRvUpdTxnInd */



/*
*
*       Fun:   mgQueueRvUpdTxnReq
*
*       Desc:  This function queues a transaction request, when GCP copy
*              sends a reverse update to the master copy and waits for an ack
*              to process the queued message.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mp_pldf.c
*
*/
#ifdef ANSI
PUBLIC S16 mgQueueRvUpdTxnReq
(
Ptr                 msg,               /* msg buffer to be processed later */
MgRvUpdQNode       *queue,             /* list in which node is queued */
MgRvUpdQNode       *node,              /* allocated for storing queued info */
U8                  prot,              /* protocol - MGCP/MEGACO */
SpId                spId               /* SSAP Id */
)
#else
PUBLIC S16 mgQueueRvUpdTxnReq(msg, queue, node, prot, spId)
Ptr                 msg;               /* msg buffer to be processed later */
MgRvUpdQNode       *queue;             /* list in which node is queued */
MgRvUpdQNode       *node;              /* allocated for storing queued info */
U8                  prot;              /* protocol - MGCP/MEGACO */
SpId                spId;              /* SSAP Id */
#endif
{
   MgRvrsQTxnReq      *qTxn;           /* info stored with the txn */
   MgRvUpdQNode       *tmp;            /* temporary node for list traversal */

   TRC2(mgQueueRvUpdTxnReq)

   if ((qTxn = (MgRvrsQTxnReq *)mgMalloc(sizeof(MgRvrsQTxnReq))) != NULLP)
   {
      qTxn->msg =  (Ptr)(msg);
      qTxn->prot = prot;
      qTxn->spId = (SpId)spId;
   }

   if (node != NULLP)
   {
      node->info = (Ptr)qTxn;
      node->prot = prot;
      node->next = NULLP;
      node->prev = NULLP;

      /* Now add the node into linked list */
      tmp = queue;
      while (tmp->next != NULLP)
      {
         tmp = tmp->next;
      }

      tmp->next = node;
      node->prev = tmp;
   } /* if node is not NULL */

   RETVALUE(ROK);
} /* mgQueueRvUpdTxnReq */


/*
*
*       Fun:   mgFreeRvUpdRsrc
*
*       Desc:  This function queues a transaction request, when GCP copy
*              sends a reverse update to the master copy and waits for an ack
*              to process the queued message.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mp_pldf.c
*
*/
#ifdef ANSI
PUBLIC S16 mgFreeRvUpdRsrc
(
MgRvUpdQNode       *queue,             /* list in which node is queued */
U8                  qType              /* type of queue to be deallocated */
)
#else
PUBLIC S16 mgFreeRvUpdRsrc(queue, qType)
MgRvUpdQNode       *queue;             /* list in which node is queued */
U8                  qType;             /* type of queue to be deallocated */
#endif
{
#ifdef GCP_MGCO
   MgMgcoMsg          *mgcoMsg;        /* MEGACO msg pointer */
#endif /* GCP_MGCO */
#ifdef GCP_MGCP
   MgMgcpTxn          *txn;            /* MGCP txn pointer */
#endif /* GCP_MGCP */
   MgRvUpdQNode       *node;           /* temporary node for list traversal */
   MgRvUpdQNode       *tmp;            /* temporary node for list traversal */

   TRC2(mgFreeRvUpdRsrc)

   /* Deallocate from next node onwards */
   node = queue->next;

   while (node != NULLP)
   {
      if (node->prot == LMG_PROTOCOL_MGCO)
      {
#ifdef GCP_MGCO
         if(qType == MG_PEER_OUTTXNQ)
         {
            mgcoMsg = (MgMgcoMsg *)(((MgRvrsQTxnReq *)node->info)->msg);
            /* free queued info */
            mgDeAlloc((Data *)(node->info), sizeof(MgRvrsQTxnReq));
         }
         else
         {
            mgcoMsg = (MgMgcoMsg *)(((MgRvrsQTxnInd *)node->info)->msg);
            /* free queued info */
            mgDeAlloc((Data *)(node->info), sizeof(MgRvrsQTxnInd));
         }
         /* free queued message */
         MG_FREE_MGCO_EVNT_MEM(mgcoMsg,TRUE);
#endif /* GCP_MGCO */
      } /* protocol is MEGACO */
      else if (tmp->prot == LMG_PROTOCOL_MGCP)
      {
#ifdef GCP_MGCP
         if(qType == MG_PEER_OUTTXNQ)
         {
            txn = (MgMgcpTxn *)(((MgRvrsQTxnReq *)node->info)->msg);
            /* free queued info */
            mgDeAlloc((Data *)(node->info), sizeof(MgRvrsQTxnReq));
         }
         else
         {
            txn = (MgMgcpTxn *)(((MgRvrsQTxnInd *)node->info)->msg);
            /* free queued info */
            mgDeAlloc((Data *)(node->info), sizeof(MgRvrsQTxnInd));
         }
         /* free queued message */
         MG_FREE_MGCP_EVNT_MEM(txn,TRUE);
#endif /* GCP_MGCP */
      } /* protocol is MGCP */

      if (node->prev != NULLP)
      {
         node->prev->next = node->next;
      }
      if (node->next != NULLP)
      {
         node->next->prev = node->prev;
      }
      tmp = node->next;
      node->next = NULLP;
      node->prev = NULLP;
      mgDeAlloc((Data *)node, sizeof(MgRvUpdQNode));
      node = tmp;
   } /* while the list ends */

   queue->next = NULLP;

   RETVALUE(ROK);
} /* mgFreeRvUpdRsrc */



/*
*
*       Fun:   mgPrcRvUpdRspAck
*
*       Desc:  This function processes the reverse update sent by a GCP copy
*              for a response ack message, when it is unable to determine the
*              correct GCP copy holding the transaction control block. The
*              master copy searches itself for the transactionr; if not found,
*              it broadcasts the message via the PLDF function.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mp_pldf.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdRspAck
(
ZgRvUpdInfo         *info,              /* Info to process rvrs update */
U32                 *id                 /* peerId */
)
#else
PUBLIC S16 mgPrcRvUpdRspAck(info , id)
ZgRvUpdInfo         *info;              /* Info to process rvrs update */
U32                 *id;                /* peerId */
#endif
{
   MgPeerCb    *peer;                   /* peer control block */
   U8           msgType;                /* message type */

   TRC2(mgPrcRvUpdRspAck)

   /* Check if this master..only master should call this fn */
   if((zgChkCRsetStatus()) != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG238, 0,
               "mgPrcRvUpdRspAck: Fn called from Shadow \n");
#endif /* ERRCLS_DEBUG */
       RETVALUE(RFAILED);
   }

   /* Get peer control block from peerid */
   if(((info->u.rspAck.peerId & DG_PEER_ID_MASK) >= mgCb.genCfg.maxPeer) ||
      ((peer = MG_GET_PEER_FRM_PEERID(info->u.rspAck.peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG239, 0,
                  "mgPrcRvUpdRspAck: Invalid PeerId \n");
#endif /* ERRCLS_DEBUG */
       RETVALUE(RFAILED);
   }

   /* Get the message type for the response ack */
   if (info->u.rspAck.protocol == LMG_PROTOCOL_MGCO)
   {
      msgType = MGT_TXNRSPACK;
   }
   else
   {
      msgType = MG_MGCP_MSG_RSPACK;
   }

   if (!zgChkNCRsetStatus(info->u.rspAck.trId,info->u.rspAck.protocol,
                          peer, msgType, MG_TRANS_TYPE_RX,
                          MG_INVALID_LSTNRID, NULLP, 0))
   {
      /* if transaction control block not found on current copy, broadcast it
       * through PLDF */
      zgPldfSendRspAck(info->u.rspAck.trId, info->u.rspAck.protocol, 
                       info->u.rspAck.peerId);
   }
   else
   {
      mgPrcRcvdResponseAck(peer, info->u.rspAck.trId);
   }

   RETVALUE(ROK);
} /* mgPrcRvUpdRspAck */



/*
*
*       Fun:   mgFindRvUpdNode
*
*       Desc:  This function prcesses reverse update timer expiry.It deletes the
*       stored message information from the queue. 
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC Ptr mgFindRvUpdNode
(
U32              peerId,              /* PeerId */
U16              seqNo,               /* Sequence no. */
U8               qType,               /* Queue Type */
MgTSAPCb         **tsap               /* TSAP */
)
#else
PUBLIC Ptr mgFindRvUpdNode(peerId, seqNo, qType, tsap)
U32              peerId;              /* PeerId */
U16              seqNo;               /* Sequence no. */
U8               qType;               /* Queue Type */
MgTSAPCb         **tsap;              /* TSAP */
#endif
{
   MgPeerCb         *peer;            /* Peer Control block */
   MgRvUpdQNode     *node;            /* Reverse Update node to be located */
   MgRvUpdQNode     *queue;           /* Q from which node is to be located */
   
   TRC2(mgFindRvUpdNode)

   node = NULLP;

   *tsap = NULLP;      /* initialization */

   /* Get peerCb from peerID */ 
   if((peerId == MG_INVALID_PEERID) && (qType != MG_TSAP_TXNQ))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG240, 0,
               "mgFindRvUpdNode: Invalid PeerId \n");
#endif 
       RETVALUE((Ptr)node);
   }
   /* Get peer from peerId */
   if(peerId != MG_INVALID_PEERID)
   {
      peer = MG_GET_PEER_FRM_PEERID(peerId);
      if((peer == NULLP) && (qType != MG_TSAP_TXNQ))
      {
         /* This might be the case when peer is deleted..due to some reasons..so
          * all the nodes and queued txn attached to this peer would have been
          * freed already ..so just return*/
         RETVALUE((Ptr)node);
      }
   }
   else
   {
      peer = NULLP;
   }
   
   /* find qtype */
   if(qType == MG_PEER_INTXNQ)
   {
      queue = &(peer->peerTxnQ);
   }
   else if(qType == MG_PEER_OUTTXNQ)
   {
      queue = &(peer->usrTxnQ);
   }
   else
   {
      queue = &(peer->tsap->rvUpdQ);
   }

   *tsap = peer->tsap;

   /* now find node from the queue corresponding to seqno */
   node = queue;
   while (node != NULLP)
   {
      if (node->rvSeqNum == seqNo)
         break;

      node = node->next;
   }

   RETVALUE((Ptr)node);
} /* mgFindRvUpdNode*/


/*
*
*       Fun:   mgPrcRvUpdTmrExpiry
*
*       Desc:  This function prcesses reverse update timer expiry.It deletes the
*       stored message information from the queue. 
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdTmrExpiry
(
MgRvUpdQNode    *rvNode               /* Node for which timer has expired */
)
#else
PUBLIC S16 mgPrcRvUpdTmrExpiry(rvNode)
MgRvUpdQNode    *rvNode;              /* Node for which timer has expired */
#endif
{
   MgPeerCb         *peer;            /* Peer Control block */
#ifdef GCP_MGCP
   MgMgcpTxn        *txn;             /* MGCP message */
#endif /* GCP_MGCP */
#ifdef GCP_MGCO
   MgMgcoMsg        *mgcoMsg;         /* Megaco Message */
#endif /* GCP_MGCO */
   
   TRC2(mgPrcRvUpdTmrExpiry)

   /* Get peerCb from peerID */ 

   if((rvNode->peerId == MG_INVALID_PEERID) && (rvNode->qType != MG_TSAP_TXNQ))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG241, 0,
               "mgPrcRvUpdTmrExpiry: Invalid PeerId \n");
#endif 
       RETVALUE(RFAILED);
   }
   /* Get peer from peerId */
   if(rvNode->peerId != MG_INVALID_PEERID)
   {
      peer = MG_GET_PEER_FRM_PEERID(rvNode->peerId);
      if((peer == NULLP) && (rvNode->qType != MG_TSAP_TXNQ))
      {
         /* This might be the case when peer is deleted..due to some reasons..so
          * all the nodes and queued txn attached to this peer would have been
          * freed already ..so just return*/
         RETVALUE(ROK);
      }
   }
   else
   {
      peer = NULLP;
   }
   
   /* based on reverse update type free message..which can be either megaco
    * message or Mgcp txn */
   switch(rvNode->prot)
   {
#ifdef GCP_MGCP
      case LMG_PROTOCOL_MGCP:
      {
         /* Find MGCP message and free it */
         if(rvNode->qType == MG_PEER_OUTTXNQ)
         {
            txn = (MgMgcpTxn *)(((MgRvrsQTxnReq *)rvNode->info)->msg);
            /* send error message to service user */
            mgHandleMgcpTxnReqErr(peer->ssap, txn, MGT_ERR_RSRC_UNAVAIL);
         }
         else
         {            
            txn = (MgMgcpTxn *)(((MgRvrsQTxnInd *)rvNode->info)->msg);
            MG_FREE_MGCP_EVNT_MEM(txn,TRUE);
         }
      }
      break;
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
      case LMG_PROTOCOL_MGCO:
      {
         /* Find MEGACO message and free it */
         if(rvNode->qType == MG_PEER_OUTTXNQ)
         {
            mgcoMsg = (MgMgcoMsg *)(((MgRvrsQTxnReq *)rvNode->info)->msg);
            /* send error message to service user */
            mgHandleMgcoTxnReqErr(peer->ssap, mgcoMsg, MGT_ERR_RSRC_UNAVAIL,
                 MG_USER);
         }
         else
         {
            mgcoMsg = (MgMgcoMsg *)(((MgRvrsQTxnInd *)rvNode->info)->msg);
            /* send error message to service user */
            MG_FREE_MGCO_EVNT_MEM(mgcoMsg,TRUE);
         }
      }
      break;
#endif /* GCP_MGCO */

      default:
      {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG242, 0,
               "mgPrcRvUpdTmrExpiry: Invalid protocol value \n");
#endif 
      }
      break;
   } /* end of switch */

   /* now free rvNode */
   MG_FREE_RVUPD_NODE(rvNode);

   RETVALUE(ROK);
} /* mgPrcRvUpdTmrExpiry*/
   


/*
*
*       Fun:   mgPrcRvUpdAck
*
*       Desc:  This function prcesses reverse update Ack from Master. Typically
*       it looks into different queue and takes appropriate action. 
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: None
*
*       File:  mg_cord.c
*
*/
#ifdef ANSI
PUBLIC S16 mgPrcRvUpdAck
(
MgRvUpdQNode    *node                  /* Node to be processed for rev upd */
)
#else
PUBLIC S16 mgPrcRvUpdAck (node)
MgRvUpdQNode    *node;                 /* Node to be processed for rev upd */
#endif 
{
   MgPeerCb         *peer;            /* Peer Control block */
#ifdef GCP_MGCP
   MgMgcpTxn        *txn;             /* MGCP message */
#endif /* GCP_MGCP */
#ifdef GCP_MGCO
   MgMgcoMsg        *mgcoMsg;         /* Megaco Message */
#endif /* GCP_MGCO */
   MgSSAPCb         *ssap;            /* SSAP Cb */
   MgTptSrvr        *srvr;            /* srvr control block */

   
   TRC2(mgPrcRvUpdAck )

   peer = NULLP;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if(node == NULLP)
   {
       MGLOGERROR(ERRCLS_DEBUG, EMG243, 0,
               "mgPrcRvUpdAck : Invalid node obtained \n");
       RETVALUE(RFAILED);
   }
#endif /* ERRCLS_INT_PAR */

   /* Get peer control block from peerid */
   if(node->peerId != MG_INVALID_PEERID)
   {
      if( ((node->peerId & DG_PEER_ID_MASK) >= mgCb.genCfg.maxPeer) ||  
           ((peer = MG_GET_PEER_FRM_PEERID(node->peerId)) == NULLP) )
      {
#if (ERRCLASS & ERRCLS_DEBUG)
          MGLOGERROR(ERRCLS_DEBUG, EMG244, 0,
                  "mgPrcRvUpdAck : Invalid PeerId \n");
#endif 
          RETVALUE(RFAILED);
      }
   }
   
   switch(node->qType)
   {
      case MG_PEER_OUTTXNQ:
      {
         /* This is the case when reverse update was generated due to txnReq
          * from service user */
         SpId       spId;         /* SSAP Id */
         spId = ((MgRvrsQTxnReq *)(node->info))->spId;
         ssap = *(mgCb.sSAPLst + spId);
#ifdef GCP_MGCP
         if(node->prot == LMG_PROTOCOL_MGCP)
         {
            txn = (MgMgcpTxn *)(((MgRvrsQTxnReq *)(node->info))->msg);
            /* call MGCP fn to handle txn req */
            RETVALUE(mgPrcMgcpTxnReq(ssap, txn, peer));
         }
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
         if(node->prot == LMG_PROTOCOL_MGCO)
         {
            /* get queued Megaco message */
            mgcoMsg = (MgMgcoMsg *)(((MgRvrsQTxnReq *)(node->info))->msg);
            /* Call fn to process megaco message */
            RETVALUE(mgPrcMgcoTxnReq(ssap, mgcoMsg, peer, MG_USER));
         }
#endif /* GCP_MGCO */
      }
      break;
      case MG_PEER_INTXNQ:
      case MG_TSAP_TXNQ:
      {
         CmTptAddr    *srcAddr;        /* Source address */
         UConnId      suConnId;        /* connection identifier */
         srcAddr =  &(((MgRvrsQTxnInd *)(node->info))->srcAddr);

         if(node->prot == LMG_PROTOCOL_MGCP)
         {
#ifdef GCP_MGCP
            txn = (MgMgcpTxn *)(((MgRvrsQTxnInd *)(node->info))->msg);
            suConnId = ((MgRvrsQTxnInd *)(node->info))->connId;
            MG_GET_SRVRCB(srvr, suConnId, peer->tsap);
            
            if(txn->numMsg == 0)
            {
               MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
#if (ERRCLASS & ERRCLS_DEBUG)
               MGLOGERROR(ERRCLS_DEBUG, EMG245, 0,
                  "mgPrcRvUpdAck : numMsg is zero in MGCP Txn \n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
               RETVALUE(RFAILED);
            }
            /* call Funtion to process Mgcp txn */
            RETVALUE(mgPrcMgcpTxnInd(peer->tsap, srvr, srcAddr,
                                     NULLP, txn, peer));
#endif /* GCP_MGCP */
         } 
         else
         {
#ifdef GCP_MGCO
            mgcoMsg = (MgMgcoMsg *)(((MgRvrsQTxnInd *)(node->info))->msg);
            suConnId = ((MgRvrsQTxnInd *)(node->info))->connId;
            MG_GET_SRVRCB(srvr,suConnId, peer->tsap);
            if(mgcoMsg->body.u.tl.num.val == 0)
            {
               MG_FREE_MGCO_EVNT_MEM(mgcoMsg, TRUE);
#if (ERRCLASS & ERRCLS_DEBUG)
               MGLOGERROR(ERRCLS_DEBUG, EMG246, 0,
                  "mgPrcRvUpdAck : numMsg is zero in MGCO Msg \n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
               RETVALUE(RFAILED);
            }
            /* call MGCO fn to handle txn req */
            RETVALUE(mgPrcMgcoTxnInd(peer->tsap, srvr, srcAddr,
                                     NULLP, mgcoMsg, peer));
#endif /* GCP_MGCO */
         }
      }
      break;
   }
   RETVALUE(ROK);
} /* mgPrcRvUpdAck */


/* PLDF Related functions */
#ifdef GCP_MGCO

/*
*
*       Fun:   mgPrcPldfMgcoMsg
*
*       Desc:  This function megaco msg from peer sent through PLDF.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or an acknowledgement or
*              acknowledgements for acknoledgements transmitted
*
*       File:  mg_cord.c
*
*
*/

#ifdef ANSI
PUBLIC S16 mgPrcPldfMgcoMsg
(
UConnId            suConnId,           /* Listener Control Block */
UConnId            suRsetId,           /* suConnId with rsetId embedded */
CmTptAddr          *srcAddr,           /* Source Transport Address */
U32                peerId,             /* Peer Id */
MgMgcoMsg          *mgcoMsg,           /* megaco message */
MgTSAPCb           *tsap               /* TSAP Control block */
)
#else
PUBLIC S16 mgPrcPldfMgcoMsg (suConnId, suRsetId, srcAddr, peerId, mgcoMsg, tsap)
UConnId            suConnId;           /* Listener Control Block */
UConnId            suRsetId;           /* suConnId with rsetId embedded */
CmTptAddr          *srcAddr;           /* Source Transport Address */
U32                peerId;             /* Peer Id */
MgMgcoMsg          *mgcoMsg;           /* megaco message */
MgTSAPCb           *tsap;              /* TSAP Control block */
#endif
{
   MgPeerCb        *peer;              /* Peer Control Block */
   MgTptSrvr       *srvr;              /* Listener Control Block */

   TRC2(mgPrcPldfMgcoMsg)

   /* Initialise variables */
   peer      = NULLP;

   /* If no SSAP is available; discard the transaction */
   if (tsap->crntActvSsap == MG_NONE)
   {
      /* Discard the message and return */
      MG_FREE_MGCO_EVNT_MEM(mgcoMsg, TRUE);
      RETVALUE(RFAILED);
   }
   /* find out peer , if known */
   if(peerId != MG_INVALID_PEERID)
   {
      peer = MG_GET_PEER_FRM_PEERID(peerId);
   }
   else
   {
      peer = NULLP;
   }

   MG_GET_SRVRCB(srvr, suConnId, tsap);

   if(srvr == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG247, 0,
               "[MGCO] : mgPrcPldfMgcoMsg srvrCb is NULLP \n");
#endif 
      RETVALUE(RFAILED);
   }
#ifdef ZG_DFTHA
   else
   {
      srvr->suRsetId = suRsetId;
   }
#endif /* ZG_DFTHA */

   /* call Megaco fn to handle txn ind */
   RETVALUE(mgPrcMgcoTxnInd(tsap, srvr, srcAddr, NULLP, mgcoMsg, peer));

} /* end of mgPrcPldfMgcoMsg () */
#endif /* GCP_MGCO */
#ifdef GCP_MGCP

/*
*
*       Fun:   mgPrcPldfMgcpMsg
*
*       Desc:  This function megacp msg from peer sent through PLDF.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or an acknowledgement.
*
*       File:  mg_cord.c
*
*
*/

#ifdef ANSI
PUBLIC S16 mgPrcPldfMgcpMsg
(
UConnId            suConnId,           /* Listener Control Block */
UConnId            suRsetId,           /* suConnId with rsetId embedded */
CmTptAddr          *srcAddr,           /* Source Transport Address */
U32                peerId,             /* Peer Id */
MgMgcpTxn          *txn,               /* mgcp message */
MgTSAPCb           *tsap               /* TSAP Control block */
)
#else
PUBLIC S16 mgPrcPldfMgcpMsg (suConnId, suRsetId, srcAddr, peerId, txn, tsap)
UConnId            suConnId;           /* Listener Control Block */
UConnId            suRsetId;           /* suConnId with rsetId embedded */
CmTptAddr          *srcAddr;           /* Source Transport Address */
U32                peerId;             /* Peer Id */
MgMgcpTxn          *txn;                /* mgcp message */
MgTSAPCb           *tsap;              /* TSAP Control block */
#endif
{
   MgPeerCb        *peer;              /* Peer Control Block */
   MgTptSrvr       *srvr;              /* Listener Control Block */

   TRC2(mgPrcPldfMgcpMsg)

   /* Initialise variables */
   peer      = NULLP;

   /* If no SSAP is available; discard the transaction */
   if (tsap->crntActvSsap == MG_NONE)
   {
      /* Discard the message and return */
      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
      RETVALUE(RFAILED);
   }
   /* find out peer , if known */
   if(peerId != MG_INVALID_PEERID)
   {
      peer = MG_GET_PEER_FRM_PEERID(peerId);
   }
   else
   {
      peer = NULLP;
   }

   MG_GET_SRVRCB(srvr, suConnId, tsap);
   if(srvr == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG248, 0,
               "[MGCP] : mgPrcPldfMgcpMsg srvrCb is NULLP \n");
#endif 
      RETVALUE(RFAILED);
   }
#ifdef ZG_DFTHA
   else
   {
      srvr->suRsetId = suRsetId;
   }
#endif /* ZG_DFTHA */

   /* call MGCP function to process txnInd */ 
   RETVALUE(mgPrcMgcpTxnInd(tsap, srvr, srcAddr, NULLP, txn, peer));
} /* end of function mgPrcPldfMgcpMsg */



/*
*
*       Fun:   mgPrcPldfPiggyBkdMsg
*
*       Desc:  This function mgcp piggybacked msg from User sent through PLDF.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command.
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgPrcPldfPiggyBkdMsg 
(
SpId               spId,               /* SSap Id */
U32                peerId,             /* PeerId */
MgMgcpTxn          *txn,               /* MGCP txn from user */
U8                 msgIdx              /* msg to be processed */
)
#else
PUBLIC S16 mgPrcPldfPiggyBkdMsg (spId, peerId, txn, msgIdx)
SpId               spId;               /* SSap Id */
U32                peerId;             /* PeerId */
MgMgcpTxn          *txn;               /* MGCP txn from user */
U8                 msgIdx;             /* msg to be processed */
#endif
{
   S16           ret;                  /* return code */
   MgSSAPCb      *ssap;                /* session SAP cb */   
   CmTptAddr     tptAddr;              /* destination Address  */
   MgTptSrvr     *srvr;                /* server control block */
   Bool          ssapSrvr;             /* Is ssap server */
   MgPeerCb      *peer;                /* peer control block */

   TRC2(mgPrcPldfPiggyBkdMsg)


   if(txn == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG249, spId, 
                 "mgPrcPldfPiggyBkdMsg () Failed : Txn Nullp");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      RETVALUE(RFAILED);
   }

   if ((spId >= mgCb.genCfg.maxSSaps) || 
        ((ssap = *(mgCb.sSAPLst + (spId))) == NULLP))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG250, spId, 
                 "mgPrcPldfPiggyBkdMsg () Failed : Invalid spId");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      MG_FREE_MGCP_EVNT_MEM(txn, TRUE);

      RETVALUE(RFAILED);
   }
   /* Check if SSAP is in proper state to accept the request */
   if((ssap->state != LMG_SAP_BND_ENB))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG251, spId, 
                 "mgPrcPldfPiggyBkdMsg () Failed : Incorrect SAP state");
#endif
      RETVALUE(RFAILED);
   }

   /* Get peer control block from peerid */
   if(((peerId & DG_PEER_ID_MASK) >= mgCb.genCfg.maxPeer) ||  
         ((peer = MG_GET_PEER_FRM_PEERID(peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG252, 0,
               " mgPrcPldfPiggyBkdMsg: Invalid PeerId \n");
#endif 
       RETVALUE(RFAILED);
   }
   /* Address will be filled while sending the txn */
   tptAddr.type = CM_TPTADDR_NOTPRSNT; 

   srvr = mgMgcpGetSrvrForTx(ssap, (peer->tsap), &ssapSrvr);

   if(srvr == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG253, 0,
               " mgPrcPldfPiggyBkdMsg: Couldn't get servr for tx \n");
#endif 
       RETVALUE(RFAILED);
   }

   ret = mgPrcEachPiggyBkdTxn(peer, ssap, txn, &tptAddr, 
      msgIdx, ssapSrvr, srvr);
   if(ret == ROKDNA)
   {
      /* Don't free txn here..since it was queued */
      RETVALUE(ROK);
   }
   MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
   RETVALUE(ret);

} /* mgPrcPldfPiggyBkdMsg */


/*
*
*       Fun:   mgPrcEachPiggyBkdTxn
*
*       Desc:  This function mgcp piggybacked txn from User sent through PLDF.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command.
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16  mgPrcEachPiggyBkdTxn
(
MgPeerCb        *peer,          /* peer control block */
MgSSAPCb        *ssap,          /* SSAp control block */
MgMgcpTxn       *txn,           /* MGCP txn */
CmTptAddr       *tptAddr,       /* Destination address */
U8              msgIdx,         /* message to be processed */
Bool            ssapSrvr,       /* Is Ssap srvr */
MgTptSrvr       *srvr           /* srver control block */
)
#else
PUBLIC S16 mgPrcEachPiggyBkdTxn (peer, ssap, txn, tptAddr, msgIdx, ssapSrvr,
srvr)
MgPeerCb        *peer;          /* peer control block */
MgSSAPCb        *ssap;          /* SSAp control block */
MgMgcpTxn       *txn;           /* MGCP txn */
CmTptAddr       *tptAddr;       /* Destination address */
U8              msgIdx;         /* message to be processed */
Bool            ssapSrvr;       /* Is Ssap srvr */
MgTptSrvr       *srvr;          /* srver control block */
#endif
{
   Bool            immTx;              /* Transmit Immediately */
   U16             numMsg;             /* Number of messages */
   U16             loopIdx;            /* Loop Index */
   S16             ret;                /* Return Value */
   U32             mgtError;           /* MGT Interface Error */
   MsgLen          crntPduLen;         /* Current PDU Length */
   CmAbnfErr       err;                /* ABNF Encoding Error */
   MgTSAPCb        *tsap;              /* TSAP Control Block */
   MgTxTransIdEnt  *txCb;              /* Command Transaction Control Block */
   MgMgcpMsg       *msg;               /* MGCP Message */
   Buffer          *mBuf;              /* Message Buffer */
   MgTxBufInfo     *txBufInfo;        /* Transmitted buffer information*/
   Bool            crtTxCb;            /* whether to process command */
   Bool            alreadyPrcdCmd;     /* cmd is already processed */
   MsgLen          msgLen;             /* messagen length */

   TRC2(mgPrcEachPiggyBkdTxn)

   /* Initialise variables */
   tsap         = peer->tsap;
   txBufInfo    = NULLP;
   alreadyPrcdCmd = FALSE;
   mBuf           = NULLP;

   /*
    * For Piggybacking, UDP header + message separator needs to be added as
    * length, so initialise crntPduLen accordingly
    */
   crntPduLen = MG_UDP_HDR_LEN;   

   /* Process each transaction from the user */
   numMsg = txn->numMsg;
   txCb     = NULLP;

   for (loopIdx = 0; loopIdx < numMsg; loopIdx++)
   {
      /* Initialise variables used inside the loop */

      mgtError = 0;
      immTx    = FALSE;

      /* Obtain message pointer */
      if ((msg = txn->mgcpMsg[loopIdx]) == NULLP)
         continue;
      /* Only if loopIdx is equal to msgIdx..create TxCb */
      if(loopIdx == msgIdx )
         crtTxCb = TRUE;
      else
         crtTxCb = FALSE;

      /* Verify is message is in conformance with local entity */
      MG_VERIFY_TX_MGCP_MSG_ENT_RELATION(msg->msgType.val,
                                         mgCb.genCfg.entType, ret);
      if (ret != ROK)
      {
         /* Free txn */
         RETVALUE(RFAILED);
      }
      if(mBuf == NULLP) 
      {
         if (mgGetMsg(tsap->tsapCfg.memId.region, tsap->tsapCfg.memId.pool,
                     &(mBuf)) != ROK)
         {
            RETVALUE(RFAILED);
         }
      }

      if (msg->msgType.val == MGT_MSG_RSP)
      {
         /* piggy backed message should only contain command */
         mgPutMsg(mBuf);
         RETVALUE(RFAILED);
      }
      else if(crtTxCb == TRUE)
      {

         /* we are here..this means..this is command and also txCb needs to be
          * created ..since crtTxCb is true. crtTxCb as False implies that this
          * command was sent through PLDF to appropriate copy. */ 
         
#if (defined (GCP_VER_1_3) && defined(GCP_2705BIS))
         /* If this first txn (cmd ) in the message , then get memory for 
          * txBufInfo. */
         if(txBufInfo == NULLP)
         {
            if((txBufInfo = (MgTxBufInfo *)mgMalloc(sizeof(MgTxBufInfo))) ==
               NULLP)
            {
               mgPutMsg(mBuf);
               RETVALUE(RFAILED);
            }
            else
            {
               txBufInfo->mBuf = NULLP;
               txBufInfo->expctdRspCnt = 0;
               txBufInfo->rcvdRspCnt =0;
               txBufInfo->retxCnt = 0;
            }
         }
         txBufInfo->expctdRspCnt = 1;
         /* Process the Received Command */
         if ((ret = mgMgcpPrcCmdInTxnReq(peer, msg, tptAddr, srvr, 
               &txCb, &mgtError, (Void *)txBufInfo, &immTx, tsap)) == RFAILED)
#else  /* GCP_2705BIS */
         if ((ret = mgMgcpPrcCmdInTxnReq(peer, msg, tptAddr, srvr, 
               &txCb, &mgtError, (Void *)mBuf, &immTx, tsap)) == RFAILED)
#endif /* GCP_2705BIS */
         {
            mgPutMsg(mBuf);
            RETVALUE(RFAILED);
         }
         /* 
          * The following condition should not get executed. However, the code
          * has been writeen, so that any future enhancements which may result
          * in returning of ROKDNA is handled correctly 
          */
#ifdef ZG_DFTHA
         else if(ret == ROKDNA)
         {
            /* Now txn should be queued here..this will be processed once state
             * update will be received from master */
            /* Free resources; don't free txn as txn is queued */
            mgQueueRvUpdTxnReq(txn, &peer->usrTxnQ, tsap->rvNode,
                               LMG_PROTOCOL_MGCP, ssap->ssapCfg.sSAPId);
            mgPutMsg(mBuf);
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
            if(txBufInfo)
            {
               mgDeAlloc((Data *)txBufInfo, sizeof(MgTxBufInfo));
            }
#endif /* GCP_2705BIS */

            RETVALUE(ROKDNA);
         }
#endif /* ZG_DFTHA */
#ifdef CM_ABNF_MT_LIB
         {
            Bool   unUsed;
            MgTransId   transId;
            /* Get trans Id  */
            if (msg->msgType.val != MGT_MSG_NONSTD) 
            {
               transId = msg->t.epcfCmd.cmdLine.trId.val;
            }
            else
            {
               transId = msg->t.nonStdCmd.cmd.cmdLine.trId.val;            
            }
            /* Create txCb..*/
            if ((txCb = mgPrcOutGoingTxn(transId, msg->msgType.val, 
               MG_NONE, immTx, tptAddr, peer->ssap, peer, srvr, 
#if (defined (GCP_VER_1_3) && defined(GCP_2705BIS))
               (Void *)txBufInfo, 
#else
               (Void *)mBuf, 
#endif /* GCP_VER_1_3 && GCP_2705BIS */
               &unUsed)) == NULLP)
            {
               if(mBuf)
                  mgPutMsg(mBuf);
               RETVALUE(RFAILED);
            }
         }
#endif /* CM_ABNF_MT_LIB */
         /* Mark the address to be used for Transmission */
         alreadyPrcdCmd = TRUE;
      } /* end of if for crtTxCb */

      /* Encode the message for transmission */
#ifdef GCP_ASN      
     if (peer->mgcoInfo.encodingScheme == LMG_ENCODE_BIN)
     {  
      if ((mgEncPduMsg(peer->mntInfo.variant,
                           (U8 *)msg, 0, mBuf, MGED_MGCP,
                           &(tsap->tsapCfg.memId), &err)) != ROK)
       {
         MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
         if(alreadyPrcdCmd == FALSE)
         {
            mgPutMsg(mBuf);
         }
         RETVALUE(RFAILED);
      }
     }
     else
     {  
      
#endif
      if ((cmAbnfEncPduMsg(peer->mntInfo.variant,
                           (U8 *)(&msg->msgType), mBuf, &mgMsgDef, 
                           &(tsap->tsapCfg.memId), &err)) != ROK)
      {
         MG_FREE_MGCP_EVNT_MEM(txn, TRUE);
         if(alreadyPrcdCmd == FALSE)
         {
            mgPutMsg(mBuf);
         }
         RETVALUE(RFAILED);
      }

      /* find out length of mBuf..if it is more than mtuSize.then free it */
      SFndLenMsg(mBuf, &msgLen);
      if ((crntPduLen + msgLen) > peer->mntInfo.mtuSize)
      {
         if(alreadyPrcdCmd == TRUE)
            break;
         if(crtTxCb == FALSE)
         {
            mgPutMsg(mBuf);
            mBuf = NULLP;
         }
      }
      /* Only till last message we shall add seperator */
      if(loopIdx < numMsg - 1)
      {
         /* if crtTxCb is false so required message is still not processed so 
          * add seperator to mBuf */
         Data     msgSeparator[2] = {'.', '\n'};
         /* Add a message separator between buffers */
         if ((SAddPstMsgMult(msgSeparator, MG_MGCP_MSG_SEPARATOR_SZ,
                           mBuf)) != ROK)
         {
            RETVALUE(RFAILED);
         }
      }
      crntPduLen += msgLen;
   } /* end of for (loopIdx) */

   if(alreadyPrcdCmd == TRUE)
   {
#if (defined( GCP_VER_1_3 ) && defined(GCP_2705BIS))
      txBufInfo->mBuf = mBuf;
#endif/* GCP_VER_1_3 && GCP_2705BIS */
      /* Generate runtime update for txCb */
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
      if(txCb)
      {
         zgRtUpd(ZG_CBTYPE_TXN_TX, (Ptr)txCb, 
                     CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);
         zgUpdPeer();
      }
#endif /* ZG */
#endif /* ZG_TXN_LVL_UPD */
   }

   RETVALUE(ROK);
}
#endif /* GCP_MGCP */


/*
*
*       Fun:   mgPrcPldfRspAck
*
*       Desc:  This function Response Ack from peer sent through PLDF.
*
*       Ret:   ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes: Transaction could be a new command or an acknowledgement.
*
*       File:  mg_cord.c
*
*/

#ifdef ANSI
PUBLIC S16 mgPrcPldfRspAck
(
MgTransId          trId,               /* transaction Id */
U32                peerId,             /* peer identifier */
U32                protocol            /* protocol */
)
#else
PUBLIC S16 mgPrcPldfRspAck (trId, peerId, protocol)
MgTransId          trId;               /* transaction Id */
U32                peerId;             /* peer identifier */
U32                protocol;           /* protocol */
#endif
{
   MgPeerCb  *peer;                    /* peer control block */

   TRC2(mgPrcPldfRspAck)

   /* Findout peer */
  
   if((peerId == MG_INVALID_PEERID) ||
         ((peer = MG_GET_PEER_FRM_PEERID(peerId)) == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       MGLOGERROR(ERRCLS_DEBUG, EMG254, 0,
               "[MGCP] : mgPrcPldfRspAck peerId is Invalid \n");
#endif 
      RETVALUE(RFAILED);
   }
   /* call function to process response ack */      
   RETVALUE(mgPrcRcvdResponseAck(peer, trId)); 
   
} /* mgPrcPldfRspAck */


#endif /* ZG_DFTHA */

#endif /* MG */


/********************************************************************30**
 
        End of file:     mp_pldf.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:53:44 2005
*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------

/main/1      ---      ra   1. GCP 1.3 release
/main/2      ---      ka   1. Changes for Release for v 1.4
           mg005.104  ra   1. FTHA related changes.
           mg006.104 pk    1. PSF related changes.
                           2. Changed comment header pavitra with patch name.
/main/3      ---      pk   1. GCP 1.5 release
           mg002.105  ps   1. Removed patch reference for 1.4
*********************************************************************91*/
