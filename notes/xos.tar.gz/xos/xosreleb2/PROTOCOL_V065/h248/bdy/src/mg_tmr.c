/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/
 
/********************************************************************20**
 
     Name:     GCP - Timer Module Implementation
 
     Type:     C source file
  
     Desc:     C Source Code for Timer Management of MGCP
 
     File:     mg_tmr.c
  
     Sid:      mp_tmr.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:53:56 2005
    
     Prg:      bbk
  
*********************************************************************21*/

 
/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*
*/
 
/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*    
*   
*
*/

 
/*
 * The core of MGC product is implemented in following files:
 *
 *    mg_dns.c      DNS Interaction functions 
 *    mg_tmr.c      Timer Management/Maintenance functions
 *    mg_tpt.c      Transport Layer Interaction functions
 *    mg_trans.c    Transaction Management functions
 *    mg_cord.c     Co-ordinator Module functions
 *    mg_ui.c       MGCP Upper Interface Functions
 *    mg_mi.c       MGCP Layer Management Interface
 *    mg_li.c       MGCP Lower Layer (TUCL) Interface
 *    cm_tenc.c     Common Text Based Encode Engine for MGCP messages
 *    cm_tdec.c     Common Text Based Decode Engine for MGCP messages
 */


/* header include files (.h) */
#include "envopt.h"        /* Environment options */  
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */

#ifdef MG

#include "gen.h"           /* General layer */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common Timer functions */
#include "cm_hash.h"       /* Hash List Library */
#include "cm_llist.h"      /* Doubly Linked List library */
#include "cm_inet.h"       /* Common Sockets Library */
#include "cm_tpt.h"        /* Common Transport Defines */
#include "cm_tkns.h"       /* Common Tokens Defines */
#include "cm_sdp.h"        /* Session Description Protocol Defines */
#include "cm_mblk.h"       /* Common Memory Manager Defines */
#include "cm_abnf.h" 
#include "cm_dns.h"        /* common DNS library defines */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */
#include "hit.h"           /* HIT Interface */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include  "cm_ss7.h"       /* Common SS7 Defines */
#include  "snt.h"          /* MTP3 Interface Defines */
#endif   /* GCP_PROV_MTP3 */

#include "mgt.h"           /* MGT Interface Defines */
#include "lmg.h"           /* MGCP Layer Management */
#include "mg_err.h"        /* MGCP Error Codes */
#include "mg.h"            /* MGCP Defines */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer */
#include "ssi.x"           /* System services */
#include "cm5.x"           /* Common timer functions */
#include "cm_hash.x"       /* Hash List Library */
#include "cm_llist.x"      /* Doubly Linked List library */
#include "cm_inet.x"       /* Common Sockets Library */
#include "cm_tpt.x"        /* Common Transport Definitions */
#include "cm_tkns.x"       /* Common Tokens Defines */
#include "cm_sdp.x"        /* Session Description Protocol Defines */
#include "cm_mblk.x"       /* Common Memory Manager Defines */
#include "cm_abnf.x" 
#include "cm_dns.x"        /* common DNS library defines */
#include "cm_lib.x"        /* Common library functions */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */
#include "hit.x"           /* HIT Interface Structures */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3 
#include  "cm_ss7.x"       /* Common SS7 Structure */
#include  "snt.x"          /* MTP3 Interface Structure */
#endif    /* GCP_PROV_MTP3 */

#include "mgt.x"           /* MGT Interface Structures */
#include "lmg.x"           /* MGCP Layer Management */
#include "mg.x"            /* MGCP Data Structures */

#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */


/* local defines, if any */
 
/* local typedefs, if any */
 
/* local externs, if any */

/* forward references */
#ifdef GCP_USER_RETX_CNTRL
PRIVATE Void mgHndlPeerInRetxExpiry ARGS((
        MgPeerCb        *peer,
        MgSSAPCb        *ssap,
        MgTxTransIdEnt  *txCb
      ));
#endif

#if (defined(GCP_MGCO) && defined(GCP_CH))
PUBLIC S16 mgChPrcCmdReqTmrExpiry ARGS((
   MgMgcoChTransReq  *trReq
));
#endif /*defined(GCP_MGCO) && defined(GCP_CH)*/ 

PUBLIC Void mgPrcRstEndTmrExpiry ARGS((
      MgPeerCb           *peer  
      /* Peer Control Block */));

/* public variable declaration */

/* private variable declaration */



/******************************************************************************/
/*                    Timer Expiry Processing  Functions                      */
/******************************************************************************/
/*
*
*       Fun:    mgPrcTmrExpiry
*
*       Desc:   This function handles expiry of timer started by MGCP
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcTmrExpiry
(
PTR                cb,                  /* Entry for which Timer Expired */
S16                tmrEvnt              /* Timer Event */
)
#else
PUBLIC Void mgPrcTmrExpiry (cb, tmrEvnt)
PTR                cb;                 /* Entry for which Timer Expired */
S16                tmrEvnt;            /* Timer Event */
#endif
{
   TRC2(mgPrcTmrExpiry)

   switch (tmrEvnt)
   {
#ifdef CM_DNS_LIB
      case MG_DNSREQ_TMR:
      {
         /* Resolution Request to DNS has timed out */
         mgPrcDnsReqTmrExpiry (((MgPeerCb *)cb));
         break;
      }
#endif /* CM_DNS_LIB */
      case MG_30SEC_TMR:
      {
         /* 30 second queuing timout for Acknowledgement is over */
         mgPrcTxnRspTmrExpiry (((MgRxTransIdEnt *) cb));
         break;
      }

      case MG_PROVRSP_TMR:
      {
        /* Provisional Response Timer Expiry */
         mgPrcProvRspTmrExpiry (((MgRxTransIdEnt *) cb));
         break;
      }

      case MG_RETX_TMR:
      {
         /*
          * Do not process retx timer expiry if the peer delete timer is
          * running. This is required, since once the SU has issued the delete
          * peer request, his peer is not expecting any retransmissions.
          */
         U16             idx;                /* Timer Index */
         MgPeerCb        *peer;              /* Peer Control Block */
         peer = ((MgTxTransIdEnt *)cb)->peer;
         idx = MG_DEL_PEER_TMR - MG_PEER_TMR_BASE;
         if (peer->mntInfo.tmr[idx].tmrEvnt == TMR_NONE) 
         {
            /* Acknowledgement for transaction hasn't been received... */
            mgPrcRetxTmrExpiry (((MgTxTransIdEnt *)cb));
         }
         break;
      }
#ifdef GCP_VER_1_3
#ifdef GCP_MGCP
#ifdef GCP_2705BIS
      case MG_RETX_RSP_TMR:
      {
         /* Response Acknowledgement Response hasn't been rcved..so retransmit
          * the final response */
         mgPrcRetxRspTmrExpiry(((MgRxTransIdEnt *)cb));
         break;
      }
      case MG_TXNTMOUT_TMR:
      {
         /* Transaction timeout timer expired ( user hasn't send response for
          * the command)..so delete txn and send error response "406" to Peer
          * also indicate to service user about this*/
         mgPrcTxnTmoutTmrExpiry(((MgRxTransIdEnt *)cb));
         break;
      }
      
      case MG_TXN_DISC_TMR:
      {
         /* Disconnect timer expired..so deallocate txCb ..and delete peer */
         mgPrcDiscTmrExpiry(((MgTxTransIdEnt *)cb));
         break;
      }
#endif /* GCP_2705BIS */
      case MG_30SEC_ACK_TMR:
      {
         /* Remove stored response which was to be acked..but couldn't, 
          *  because Service user didn't send any command during this period */
         mgPrcTxnRspAckTmrExpiry(((MgTxnAckList *)cb));
         break;
      }
#endif /* GCP_MGCP */
#endif /* GCP_VER_1_3 */
      case MG_BNDREQ_TMR:
      {
         /* Bind Request to TUCL has timed out */
         mgPrcBndReqTmrExpiry(((MgTSAPCb *)cb));
         break;
      }

      case MG_DEL_PEER_TMR:
      {
         /* Delete Peer Timer has expired out */
         mgPrcDelPeerTmrExpiry(((MgPeerCb *)cb));
         break;
      }

#ifdef GCP_MG    
      case MG_RST_AVLNCH_TMR:
      {
         /* Restart Avalanche Timer has expired out */
         mgPrcRstEndTmrExpiry(((MgPeerCb *)cb));
         break;
      }
#endif /* GCP_MG */

#ifdef GCP_MGCO
      case MG_IDLE_CONN_TMR:
      {
         /* IDLE TCP Connection Timer has expired out */
         mgPrcIdleConnTmrExpiry(((MgTptSrvr *)cb));
         break;
      }
      
#ifdef GCP_MGC    
      case MG_HANDOFF_TMR:
      {
         /* Handoff Timer has expired out */
         mgPrcHndOffTmrExpiry(((MgPeerCb *)cb));
         break;
      }
#endif /* GCP_MGC */
#endif /* GCP_MGCO */

#ifdef CM_ABNF_MT_LIB
      case MG_ED_ENCTMR:
      {
         mgPrcEncTmrExpiry((U32)(cb));
         break;
      }
      case MG_ED_DECTMR:
      {
         mgPrcDecTmrExpiry((U32)(cb));
         break;
      }
#endif /* CM_ABNF_MT_LIB */

#ifdef   GCP_PROV_MTP3
      
      case MG_MTP_STSENQ_TMR:
      {
         mgPrcStsEnqTmrExpiry(((MgPeerCb *)cb));
         break;
      }
      case MG_MTP_RSTEND_TMR:
      {
         /* 
          * Either a StaInd from MTP3 is lost or a 
          * wrong timer value is configured. 
          * I hope it is the former.so Call sync function
          * since we assume that MTP_RESTART is over by this time
          */
         /*mgMtpStsSync(((MgTSAPCb *)cb)); */         
         /* mg004.105: Added mgHndlRstEnd method */
         mgHndlRstEnd(((MgTSAPCb *)cb));
         break;
      }
       
#endif /* GCP_PROV_MTP3 */

#if (defined(GCP_CH) && defined(GCP_VER_1_5))
      case CH_CMD_REQ_TMR:
      {
         mgChPrcCmdReqTmrExpiry((MgMgcoChTransReq *)(cb));
         break;
      }
#endif /* GCP_CH && GCP_VER_1_5 */ 
#if (defined (GCP_PKG_MGCO_ROOT ) && defined (GCP_VER_1_5))
      /*This case is for handling the case of provisional response timer
      * value specified in root package .
      * This is different from the provisional response timer .
      * We may have to stop the  transaction.This is because ,
      * Expiry of this timer means we  havent got any reply from other 
      * side .
      */
      case MG_PROV_RSP_ROOT_TMR:
      {
         mgPrcProvRspRootTmrExpiry(((MgTxTransIdEnt *)cb));
         break;
      }
      
#endif      
      default:
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         MGLOGERROR(ERRCLS_DEBUG, EMG264, tmrEvnt,
                    "[MGCP] mgPrcTmrExpiry(): Unknown Timer Event\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         break;
      }
   }

#ifdef ZG
   zgUpdPeer();
#endif /* ZG */

   RETVOID;

} /* end of mgPrcTmrExpiry */


#ifdef GCP_VER_1_3
#ifdef GCP_MGCP

/*
*
*       Fun:    mgPrcTxnRspAckTmrExpiry
*
*       Desc:   This function process Response Timer Expiry
*
*       Ret:    None
*
*       Notes:  Implies that we can dequeue the response which was to be acked 
*               ,but we couldn't as no command was rcved from service user 
*               during this time.
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcTxnRspAckTmrExpiry
(
MgTxnAckList     *node                 /* Queued rcvd response */
)
#else
PUBLIC Void mgPrcTxnRspAckTmrExpiry (node)
MgTxnAckList     *node;                /* Queued rcvd response */
#endif
{
   MgPeerCb      *peer;

   TRC2(mgPrcTxnRspAckTmrExpiry)
    
   peer = node->info.peer; 

   /* Remove node from the list */
   MG_RMV_FROM_LIST(&peer->txnAckQ,node);

   /* Free node */
   mgDeAlloc((Data *)node,sizeof(MgTxnAckList));

   RETVOID;

} /* end of mgPrcTxnRspAckTmrExpiry */


#ifdef GCP_2705BIS
/*
*
*       Fun:    mgPrcRetxRspTmrExpiry
*
*       Desc:   This function handles retransmission timeout for final response
*
*
*       Ret:    None
*
*       Notes:  This means that expected response acknowledgement response 
*               from the peer hasn't been received.
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcRetxRspTmrExpiry
(
MgRxTransIdEnt     *rxCb               /* Unacked response */
)
#else
PUBLIC Void mgPrcRetxRspTmrExpiry (rxCb)
MgRxTransIdEnt     *rxCb;              /* Unacked response */
#endif
{
   Bool            retx;               /* Retransmit The Message ?  */
   Ticks           crntTime;           /* Current Time */
   MgPeerCb        *peer;              /* Associated Peer */
   MgTptSrvr       *tptSrvr;           /* Transport Server for Tx */
   MgSSAPCb        *ssap;              /* SSAP Control Block */

   TRC2(mgPrcRetxRspTmrExpiry)

   /* Initialise variables */
   retx    = FALSE;
   tptSrvr = NULLP;
   peer    = rxCb->peer;
   ssap    = peer->ssap;
  
   /*
    * Check if we have not exceeded the upper bound for retransmission
    * time out
    */
   if ((SGetSysTime(&(crntTime))) == ROK)
   {
      if ((crntTime - rxCb->timeStamp) > peer->tsap->tsapCfg.reCfg.tMax)
      {
        /* Delete the transaction */
         mgDeAllocRxTransIdEnt(peer, rxCb, TRUE);
         RETVOID;
      }
   }

   /* Obtain a transport server for transmission */
   if (peer->accessInfo.transportType == LMG_TPT_UDP)
   {
      tptSrvr = MG_CHKLSTNRCB(peer->tsap, rxCb->suConnId);
   }

   /* If previous transport server not available, get next one */
   if (tptSrvr == NULLP)
   {
      if ((tptSrvr = mgGetSendSrvr(ssap, peer)) == NULLP)
      {
        /* Delete the transaction */
        mgDeAllocRxTransIdEnt(peer, rxCb, TRUE);
        RETVOID;
      }

      rxCb->suConnId = tptSrvr->suConnId;
   }

   /* MGCP Based Retransmission Algorithm */
   if (rxCb->retxCnt <= peer->mgcpInfo.disconThold)
   {
      retx = TRUE;
      rxCb->retxCnt++;
      /* check for rto exceeding tMax */
      MG_UPDATE_RTO_PARMS_ON_RETX(rxCb->aad, rxCb->adev, rxCb->rto,
                                             peer->tsap->tsapCfg.reCfg.tMax);
   }

   if (retx == TRUE)
   {
      Buffer    *newMbuf;  /* buffer */
      if(rxCb->tmr[MG_RETX_RSP_TMR - MG_INTXN_TMR_BASE].tmrEvnt == TMR_NONE)
         mgStartTmr (MG_RETX_RSP_TMR,(rxCb->rto/mgCb.genCfg.timeRes),
          (PTR) rxCb, &(rxCb->tmr[MG_RETX_RSP_TMR - MG_INTXN_TMR_BASE]));       
      /* make a refrence copy */
      if ((SAddMsgRef (rxCb->mBuf, peer->tsap->tsapCfg.memId.region, 
                  peer->tsap->tsapCfg.memId.pool, &(newMbuf))) != ROK)
      {
         MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
            mgCb.init.region, mgCb.init.pool);
         RETVOID;
      }
      /* Transmit the buffer */
      mgSrvDatReq(tptSrvr, &(rxCb->tptAddr), newMbuf);
      RETVOID;
   }
   /*
    * Coming here implies that we got response from DNS and the transaction
    * was transmitted to the last IP Address used and retransmission count 
    * was incremented there and we haven't received ack so far
    */
   if (rxCb->retxCnt > peer->mgcpInfo.disconThold)
   {
      /* Delete the transaction */
      mgDeAllocRxTransIdEnt(peer, rxCb, TRUE);
      RETVOID;
   }

} /* end of mgPrcRetxRspTmrExpiry */


/*
*
*       Fun:    mgPrcTxnTmoutTmrExpiry
*
*       Desc:   This function process Transaction timeout timer expiry.
*
*       Ret:    None
*
*       Notes:  User didn't send response within timeout period..so abort it
*       send Transaction timeout response to peer..also indicate to user.
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcTxnTmoutTmrExpiry
(
MgRxTransIdEnt     *rxCb               /* Transaction control block */
)
#else
PUBLIC Void mgPrcTxnTmoutTmrExpiry(rxCb)
MgRxTransIdEnt     *rxCb;              /* Transaction control block */
#endif
{
   MgTransId       trId;               /* transaction id */

   TRC2(mgPrcTxnTmoutTmrExpiry)

   trId = rxCb->transId;

   mgMgcpSendErrorResponse(&(rxCb->tptAddr), trId, 
                           MGT_MGCP_RSP_CODE_TXNTMOUT, 
                           (U8 *)"Transaction timeout",
                           rxCb->peer->tsap);

   /* Indicate to service user also */
   mgAbortRxTrans(rxCb->peer, rxCb, MGT_ERR_TXNTMOUT);
   
   RETVOID;

} /* end of mgPrcTxnTmoutTmrExpiry*/




/*
*
*       Fun:    mgPrcDiscTmrExpiry
*
*       Desc:   This function process disc timeout timer expiry.
*
*       Ret:    None
*
*       Notes:  delete peer..and deallocate txCb .
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcDiscTmrExpiry
(
MgTxTransIdEnt     *txCb               /* Transaction control block */
)
#else
PUBLIC Void mgPrcDiscTmrExpiry(txCb)
MgTxTransIdEnt     *txCb;              /* Transaction control block */
#endif
{

   TRC2(mgPrcDiscTmrExpiry)

#ifdef ZG_DFTHA
   /* only Master should delete peer association..if master doesn't lie
      * on the same copy then reverse update to the master will be
      * generated */
   if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
   {
      MG_MGCP_ASSOCIATION_LOST(txCb->peer->ssap, txCb->peer, txCb->transId);
   }
#ifdef ZG_DFTHA
   /* send reverse update to Master..indicating retransmission has 
      * failed */
   else
   {
      ZgRvUpdInfo  info;
      info.action = ZG_RVUPD_RETX_FAILED; 
      info.u.retxPeer = txCb->peer->accessInfo.peerId;
      zgReverseUpd(&info, (txCb->peer->accessInfo.peerId), MG_QUEUE_NONE,
                   txCb->peer->tsap->tsapCfg.tSAPId);
   }
#endif /* ZG_DFTHA */
   
   RETVOID;

} /* end of mgPrcDiscTmrExpiry*/

#endif /* GCP_2705BIS */
#endif /* GCP_MGCP */
#endif /* GCP_VER_1_3 */


#ifdef CM_DNS_LIB
/*
*
*       Fun:    mgPrcDnsReqTmrExpiry
*
*       Desc:   This function signals timeout for a resolution request sent
*               to DNS and takes care of retransmission/cleanup
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcDnsReqTmrExpiry
(
MgPeerCb           *peer               /* Peer Control Block under Resolution */
)
#else
PUBLIC Void mgPrcDnsReqTmrExpiry (peer)
MgPeerCb           *peer;              /* Peer Control Block under Resolution */
#endif
{
   TmrCfg            *tmr;      /* Timer Value */
   MgTSAPCfg         *tsapCfg;  /* Tsap Configuration */
   MgTSAPCb          *tsap;     /* TSAP for DNS  */
   MgDnsTxFuncParam  reqParam;  /* DNS Request Parameters */


   TRC2(mgPrcDnsReqTmrExpiry);


#if (ERRCLASS & ERRCLS_DEBUG)
#ifdef ZG_DFTHA
   if(!((zgChkCRsetStatus()) == TRUE))
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG265, MG_DNSREQ_TMR,
         "[MGCP] mgPrcDnsReqTmrExpiry(): DnsReq Timer Expired in NcRset\n");
      RETVOID;
   }
#endif /* ZG_DFTHA */
#endif /* ERRCLASS & ERRCLS_DEBUG */


   if ((mgCb.dnsTsap == MG_INVALID_TSAP_ID) ||
       (mgCb.tSAPLst[mgCb.dnsTsap] == NULLP))
      tsap = NULLP;
   else
      tsap = mgCb.tSAPLst[mgCb.dnsTsap];


   /* if DNS resolution request can be retried, do it */
   if ((peer->dnsRetxCnt < tsap->tsapCfg.reCfg.dnsCfg.maxRetxCnt)
       && (tsap))
   {
      /* Increment the retransmission count */
      peer->dnsRetxCnt++;

      if (peer->dnsReq != NULLP)
      {
         tsapCfg = &(tsap->tsapCfg);

         /* Start Timer for timing out the DNS Resolution Request */
         tmr = &(tsapCfg->reCfg.dnsCfg.dnsRslvTmr);
         if (tmr->enb == TRUE)
         {
            mgStartTmr (MG_DNSREQ_TMR, tmr->val, (PTR)peer, 
                        &(peer->mntInfo.tmr[MG_DNSREQ_TMR - MG_PEER_TMR_BASE]));
         }

         /* Transmit the Data buffer */
         reqParam.srvr = tsap->dnsInfo.dnsLstnr;
         reqParam.peer  = peer;

         /* Send resolve request to DNS */
         mgSndRslvReqToDns((Ptr)&(reqParam), &(tsapCfg->reCfg.dnsCfg.dnsAddr),
                           peer->dnsReq);
         RETVOID;
      }
      else
      {
         /* Send Resolution Request for DNS */
         mgSendDnsRslvPeer(peer);
         RETVOID;
      }
   }

   /* 
    * No Retries can be done....we will presume that gateway is still alive
    * and Detection of Loss of Association Algorithm should lead to removal of
    * gateway from GCP database
    */
   MG_ABORT_DNS_RSLV_REQ (peer->dnsReqId);
   mgPutMsg(peer->dnsReq);
   peer->dnsReq = NULLP;

   if (peer->state == LMG_PEER_STATE_RESOLVING)
      mgDeletePeer (peer, LMG_EVENT_PEER_REMOVED, 
                    LMG_CAUSE_NS_NOT_RESPONDING, FALSE);

   RETVOID;

} /* end of mgPrcDnsReqTmrExpiry */

#endif /* if CM_DNS_LIB */


/*
*
*       Fun:    mgPrcTTLTmrExpiry
*
*       Desc:   This function process the expiry of TTL for a Peer
*
*       Ret:    None
*
*       Notes:  This function is directly called by the timer library once 
*               TTL for a Peer has expired => it is not called by 
*               mgPrcTmrExpiry () like rest of expiry functions
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcTTLTmrExpiry
(
MgPeerCb           *peer               /* Peer for which Timer Expired */
)
#else
PUBLIC Void mgPrcTTLTmrExpiry (peer)
MgPeerCb           *peer;              /* Peer for which Timer Expired */
#endif
{
   TmrCfg          *tmr;              /* Timer Value */
   MgTSAPCb        *tsap;             /* DNS TSAP control block */


   TRC2(mgPrcTTLTmrExpiry)


#ifdef ZG_DFTHA
   if(!((zgChkCRsetStatus()) == TRUE))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG266, MG_DEL_PEER_TMR,
         "[MGCP] mgPrcTTLTmrExpiry(): TTL Timer Expired in NcRset\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVOID;
   }
#endif /* ZG_DFTHA */


   if ((mgCb.dnsTsap == MG_INVALID_TSAP_ID) ||
       (mgCb.tSAPLst[mgCb.dnsTsap] == NULLP))
      tsap = NULLP;
   else
      tsap = mgCb.tSAPLst[mgCb.dnsTsap];



   if ((tsap == NULLP) ||
       (tsap->tsapCfg.reCfg.dnsCfg.dnsAccess == LMG_DNS_DISABLED) ||
       (tsap->dnsInfo.dnsState == MG_DNS_STATE_DOWN))
   {
      if (peer->state == LMG_PEER_STATE_NULL)
         mgDeletePeer (peer, LMG_EVENT_PEER_REMOVED, 
                       LMG_CAUSE_NS_NOT_RESPONDING, FALSE);

      RETVOID;
   }

   /* Start Time for timing out the DNS Resolution Request */
   tmr = &(tsap->tsapCfg.reCfg.dnsCfg.dnsRslvTmr);
   if (tmr->enb == TRUE)
   {
      mgStartTmr (MG_DNSREQ_TMR, tmr->val, (PTR)peer, 
                  &(peer->mntInfo.tmr[MG_DNSREQ_TMR - MG_PEER_TMR_BASE]));
   }

   /* Send a Resolution Request to DNS */
   mgSendDnsRslvReq(peer, peer->accessInfo.name); 

   RETVOID;

} /* end of mgPrcTTLTmrExpiry */



/*
*
*       Fun:    mgPrcTxnRspTmrExpiry
*
*       Desc:   This function process Response Timer Expiry
*
*       Ret:    None
*
*       Notes:  Implies that we can dequeue the ACK sent to a command received
*               previously since 30 seconds queuing time is over
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcTxnRspTmrExpiry
(
MgRxTransIdEnt     *rxCb               /* Queued Acknowledgement */
)
#else
PUBLIC Void mgPrcTxnRspTmrExpiry (rxCb)
MgRxTransIdEnt     *rxCb;              /* Queued Acknowledgement */
#endif
{
   TRC2(mgPrcTxnRspTmrExpiry)

   /* Free resources associated with transaction */
   mgDeAllocRxTransIdEnt(rxCb->peer, rxCb, TRUE);

   RETVOID;

} /* end of mgPrcTxnRspTmrExpiry */


/*
*
*       Fun:    mgPrcProvRspTmrExpiry
*
*       Desc:   This function process Response Timer Expiry
*
*       Ret:    None
*
*       Notes:  Implies that we can dequeue the ACK sent to a command received
*               previously since 30 seconds queuing time is over
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcProvRspTmrExpiry
(
MgRxTransIdEnt     *rxCb               /* Queued Acknowledgement */
)
#else
PUBLIC Void mgPrcProvRspTmrExpiry(rxCb)
MgRxTransIdEnt     *rxCb;              /* Queued Acknowledgement */
#endif
{
   MgPeerCb        *peer;              /* Peer Control Block */

   TRC2(mgPrcProvRspTmrExpiry)

   peer = rxCb->peer;

#ifdef GCP_MGCO
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
   {
      mgSendMgcoTxnPend(rxCb);
      RETVOID;
   }
#endif /* GCP_MGCO */

#ifdef GCP_MGCP
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
   {
      mgMgcpSendPrvsnlResponse(rxCb);
      RETVOID;
   }
#endif /* GCP_MGCP */

   RETVOID;

} /* end of mgPrcProvRspTmrExpiry() */




/*
*
*       Fun:    mgPrcRetxTmrExpiry
*
*       Desc:   This function handles retransmission timeout for a transaction
*
*
*       Ret:    None
*
*       Notes:  This means that expected acknowledgement from the peer hasn't 
*               been received and we will run Detection of Loss of Association
*               Algorithm for the peer in question. 
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcRetxTmrExpiry
(
MgTxTransIdEnt     *txCb               /* Unacked Transaction */
)
#else
PUBLIC Void mgPrcRetxTmrExpiry (txCb)
MgTxTransIdEnt     *txCb;              /* Unacked Transaction */
#endif
{
   Bool            retx;               /* Retransmit The Message ?  */
   Ticks           crntTime;           /* Current Time */
   MgPeerCb        *peer;              /* Associated Peer */
   MgTptSrvr       *tptSrvr;           /* Transport Server for Tx */
   MgTSAPCb        *tsap;              /* TSAP Control Block */
   MgSSAPCb        *ssap;              /* SSAP Control Block */

   TRC2(mgPrcRetxTmrExpiry)
   /* Initialise variables */
   retx    = FALSE;
   tptSrvr = NULLP;
   peer    = txCb->peer;

   tsap    = peer->tsap;

   ssap    = peer->ssap;
  
   /*
    * Check if we have not exceeded the upper bound for retransmission
    * time out
    */
   if ((SGetSysTime(&(crntTime))) == ROK)
   {
      if ((crntTime - txCb->timeStamp) > tsap->tsapCfg.reCfg.tMax)
      {

#ifdef GCP_MGCP
         if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
         {
            U16      tHist;
            U16      idx;

            /*
             *   RFC 3435 states that if the total time elapsed is
             *   greater than T-MAX but less than 2*T-HIST, do NOT
             *   retransmit; rather simply wait for the response.
             *   Otherwise, initiate the disconnect procedure i.e.
             *   execute the following lines of code.
             *
             *   If atMostOnceTmr (T-HIST), has not been enabled
             *   use the default value of 30 seconds.
             */

            tHist   = 
               (TRUE == peer->ssap->ssapCfg.reCfg.atMostOnceTmr.enb) ?
                  (peer->ssap->ssapCfg.reCfg.atMostOnceTmr.val) : 30;

            if ((crntTime - txCb->timeStamp)
                           <=
                ((2 * tHist)
                    * (mgCb.genCfg.timeRes)))
            {
               /* Start the Retx & TTL timers */

               /* Update RTO */
               if (peer->mntInfo.rtoCap == FALSE)
               {
                 /* 
                  *   AAD for the peer should not be updated for
                  *   retransmissions since the acknowledgement delay
                  *   for a retransmitted command cannot be calculated
                  *   deterministically. The ack may have been sent in
                  *   response to the first time transmission or the
                  *   retransmission.
                  *   The retransmission timer should be calculated by
                  *   doubling the value of AAD for the transaction
                  *   to be retransmitted. 
                  */
                 MG_UPDATE_RTO_PARMS_ON_RETX(txCb->aad,
                                             peer->mntInfo.adev, 
                                             txCb->rto,
                                             tsap->tsapCfg.reCfg.tMax);
          
               }

               /* 
                *   Start the retransmission timer. RTO is in ticks.
                *   convert to multiples of timeRes .
                *   Start timer based on RTO for the transaction since
                *   this is a retransmission case. Do not use the RTO
                *   value for the peer.
                */
               mgStartTmr (MG_RETX_TMR, (txCb->rto/mgCb.genCfg.timeRes), 
                           (PTR) txCb, &(txCb->retxTmr));
            


               /* If TTL time is not running and DNS Is up; start TTL Timer */
               idx = MG_TTL_TMR - MG_PEER_TMR_BASE;


               if ((peer != NULLP) && 
                   (mgCb.dnsTsap != MG_INVALID_TSAP_ID) &&
                   (mgCb.tSAPLst[mgCb.dnsTsap]) &&
                   (mgCb.tSAPLst[mgCb.dnsTsap]->tsapCfg.reCfg.dnsCfg.dnsAccess
                          != LMG_DNS_DISABLED) &&
                   (peer->mntInfo.tmr[idx].tmrEvnt == TMR_NONE))
               {
                  mgStartTmr(MG_TTL_TMR, peer->mgcpInfo.ttl, (PTR)peer, 
                             &(peer->mntInfo.tmr[idx]));
               }




               RETVOID;
            }

         }
#endif /* GCP_MGCP */

         /* 
          * For MGCP path, if this transction is stack generated RSIP, then
          * reset peer->regReqTxnId, and indicate to LM. Also issue a status
          * indication at the MGT interface. All this is now being done inside
          * mgHndlPeerInRetxExpiry
          */
#ifdef GCP_USER_RETX_CNTRL
        mgHndlPeerInRetxExpiry(peer, ssap, txCb);
        RETVOID;
#else /* GCP_USER_RETX_CNTRL */

#ifdef GCP_MGCP
         if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
         {
#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
            /* if 2705BIS is defined..and disc timer is started..then don't do
             * anything here..txCb will be deallocated and ..peer will be put
             * into disconnected state once discTmr expires */
            if(TRUE == ssap->ssapCfg.reCfg.txnTmoutTmr.enb)
            {
               RETVOID;
            }
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */
            /* 
             * Loss of Association Detected  - Remove All Transaction;
             * Bring Peer to Configuration Status 
             */
#ifdef ZG_DFTHA
            /* only Master should delete peer association..if master doesn't lie
             * on the same copy then reverse update to the master will be
             * generated */
            if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
            {

#ifdef GCP_PKG_MGCP_BASE
               /* Loss of Response for the MESG Cmd should not lead
                * to the end point getting disconnected
                */
               if (txCb->msgType != MGT_MSG_MESG)
#endif /* GCP_PKG_MGCP_BASE */
                  MG_MGCP_ASSOCIATION_LOST(ssap, peer, txCb->transId);

            }
#ifdef ZG_DFTHA
            /* send reverse update to Master..indicating retransmission has 
             * failed */
            else
            {
               ZgRvUpdInfo  info;
               info.action = ZG_RVUPD_RETX_FAILED; 
               info.u.retxPeer = peer->accessInfo.peerId;
               zgReverseUpd(&info, (peer->accessInfo.peerId), MG_QUEUE_NONE,
                            peer->tsap->tsapCfg.tSAPId);
            }
#endif /* ZG_DFTHA */
            RETVOID;
         }
#endif /* GCP_MGCP */

#ifdef GCP_MGCO 
         if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
         {
#ifdef ZG_DFTHA
            /* only Master should delete peer association..if master doesn't lie
             * on the same copy then reverse update to the master will be
             * generated */
            if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
            {
               if (mgCb.genCfg.entType == LMG_ENT_GW)
               {
#ifdef GCP_MG         
                  mgProcessPeerMGCFailure(peer);
                  RETVOID;
#endif /* GCP_MG */        
               }
               else
                  mgDeletePeer (peer, LMG_EVENT_PEER_REMOVED, 
                                 LMG_CAUSE_PEER_NOT_RESPONDING, FALSE);
            }
#ifdef ZG_DFTHA
            /* generate reverse update */
            else
            {
               ZgRvUpdInfo  info;
               info.action = ZG_RVUPD_RETX_FAILED; 
               info.u.retxPeer = peer->accessInfo.peerId;
               zgReverseUpd(&info, (peer->accessInfo.peerId),MG_QUEUE_NONE,
                            peer->tsap->tsapCfg.tSAPId);
            }
#endif /* ZG_DFTHA */
         }
#endif /* GCP_MGCO */
         RETVOID;
#endif /* GCP_USER_RETX_CNTRL */
      }
   }

   /* Obtain a transport server for transmission */
   if (peer->accessInfo.transportType == LMG_TPT_UDP)
   {
      tptSrvr = MG_CHKLSTNRCB(tsap, txCb->suConnId);
   }
#ifdef GCP_MGCO
   else if (peer->accessInfo.transportType == LMG_TPT_TCP)
   {
      CmLList      *cmLstEnt;          /* Linked List Entry */

      cmLstEnt = peer->mgcoInfo.tcpConnLst.first;

      while (cmLstEnt != NULLP)
      {
         tptSrvr = (MgTptSrvr *)(cmLstEnt->node);

         if (tptSrvr->suConnId == txCb->suConnId)
            break;

         tptSrvr  = NULLP;
         cmLstEnt = cmLstEnt->next;
      }
   }
#endif /* GCP_MGCO */

   /* If previous transport server not available, get next one */
   if (
#ifdef    GCP_PROV_MTP3
      (peer->accessInfo.transportType != LMG_TPT_MTP3) &&
#endif    /* GCP_PROV_MTP3 */      
#ifdef    GCP_PROV_SCTP
       (NULLP == peer->assocCb) &&
#endif    /* GCP_PROV_SCTP */
       (tptSrvr == NULLP))
   {
      if ((tptSrvr = mgGetSendSrvr(ssap, peer)) == NULLP)
      {
        mgAbortTxTrans (peer, txCb, MGT_ERR_RSRC_UNAVAIL);
        RETVOID;
      }

      txCb->suConnId = tptSrvr->suConnId;
   }
#ifdef   GCP_PROV_MTP3   
       /*
        * See if transport if MTP3 but point code is down then Abort the Txn
        */

      if ((peer->accessInfo.transportType == LMG_TPT_MTP3) && 
         (!(peer->mgcoMtpCb.status & SP_ONLINE)))
      {
        mgAbortTxTrans (peer, txCb, MGT_ERR_RSRC_UNAVAIL);
        RETVOID;
      }
#endif   /* GCP_PROV_MTP3 */      

#ifdef GCP_MGCP
   /* MGCP Based Retransmission Algorithm */
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
   {
      mgMgcpExecRetxAlgo(tsap, peer, txCb, &retx);
   } 
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
   /* For MEGACO, just retransmit */
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
   {
      retx = TRUE;
      txCb->retxCnt++;
   }
#endif /* GCP_MGCO */

   if (retx == TRUE)
   {
      mgRetransmitMessage(tptSrvr, tsap, peer, txCb);
      RETVOID;
   }

#ifdef GCP_MGCP
   /*
    * Coming here implies that we got response from DNS and the transaction
    * was transmitted to the last IP Address used and retransmission count 
    * was incremented there and we haven't received ack so far
    */
   if (txCb->retxCnt > peer->mgcpInfo.disconThold)
   {
      /* 
       * For MGCP path, if this transction is stack generated RSIP, then
       * reset peer->regReqTxnId, and indicate to LM. Also issue a status
       * indication at the MGT interface. All this is now being done inside
       * mgHndlPeerInRetxExpiry
       */
#ifdef GCP_USER_RETX_CNTRL
        mgHndlPeerInRetxExpiry(peer, ssap, txCb);
        RETVOID;
#else

#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
            /* if 2705BIS is defined..and disc timer is started..then don't do
             * anything here..txCb will be deallocated and ..peer will be put
             * into disconnected state once discTmr expires */
            if(TRUE == ssap->ssapCfg.reCfg.txnTmoutTmr.enb)
            {
               RETVOID;
            }
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */
      /* 
       * Loss of Association Detected  - Remove All Transaction;
       * Bring Peer to Configuration Status 
       */
#ifdef ZG_DFTHA
      if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
      {

#ifdef GCP_PKG_MGCP_BASE
         /* Loss of Response for the MESG Cmd should not lead
          * to the end point getting disconnected
          */
         if (txCb->msgType != MGT_MSG_MESG)
#endif /* GCP_PKG_MGCP_BASE */
            MG_MGCP_ASSOCIATION_LOST(ssap, peer, txCb->transId);

      }
#ifdef ZG_DFTHA
      /* send reverse update to Master..indicating retransmission has failed */
      else
      {
         ZgRvUpdInfo  info;
         info.action = ZG_RVUPD_RETX_FAILED; 
         info.u.retxPeer = peer->accessInfo.peerId;
         zgReverseUpd(&info, (peer->accessInfo.peerId), MG_QUEUE_NONE,
                      peer->tsap->tsapCfg.tSAPId);
      }
#endif /* ZG_DFTHA */

      RETVOID;
#endif /* GCP_USER_RETX_CNTRL */
   }
#endif /* GCP_MGCP */

} /* end of mgPrcRetxTmrExpiry */



#ifdef GCP_USER_RETX_CNTRL
/*
*
*       Fun:    mgHndlPeerInRetxExpiry
*
*       Desc:   This function handles the various peer related indications in
*       case of a last retx timer expiry for stack generated RSIP/Servic
*       Change restart messages, if GCP_USER_RETX_CNTRL flag is defined.
*
*
*       Ret:    None
*
*       Notes:  
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PRIVATE Void mgHndlPeerInRetxExpiry
(
MgPeerCb           *peer,          /* Peer Control Block */
MgSSAPCb           *ssap,          /* SSAP control block */
MgTxTransIdEnt     *txCb           /* Unacked transaction */
)
#else
PRIVATE Void mgHndlPeerInRetxExpiry (peer, ssap, txCb)
MgPeerCb           *peer;          /* Peer Control Block */
MgSSAPCb           *ssap;          /* SSAP control block */
MgTxTransIdEnt     *txCb;          /* Unacked transaction */
#endif
{
   U8              errCode = MGT_ERR_TXN_RETX_FAILED;
#ifdef GCP_MGCP
   if (LMG_PROTOCOL_MGCP == peer->mntInfo.protocolType) 
   {
#ifdef GCP_MG
      U8              reason;

      if (peer->regReqTxnId == txCb->transId) 
      {
         peer->regReqTxnId = MG_INVALID_TRANSID;
         errCode = MG_IGNORE;

         /* Issue LMG status indication */
         MG_ISSUE_MGCPPEER_STAIND(peer, LCM_CATEGORY_PROTOCOL, 
                       LMG_EVENT_MGC_FAILED, LMG_CAUSE_PEER_NOT_RESPONDING);

         /* Issue MGT status indication */
         reason = MGT_MAX_INIT_REG_DONE;
         mgGenUserStaInd(peer, peer->ssap, MGT_STATUS_PEER, &reason);
      }
#endif /* GCP_MG */
      /* Delete the transaction */
      mgAbortTxTrans(peer, txCb, errCode);

      RETVOID;
   }
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
   if (LMG_PROTOCOL_MGCO == peer->mntInfo.protocolType)
   {
      /* Stack generated message */
      if(txCb->msgInfo & MG_SELF_INIT)
      {
         errCode = MG_IGNORE;
#ifdef ZG_DFTHA
         /* only Master should delete peer association..if master doesn't lie
          * on the same copy then reverse update to the master will be
          * generated */
         if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
         {
            if (mgCb.genCfg.entType == LMG_ENT_GW)
            {
#ifdef GCP_MG         
               mgProcessPeerMGCFailure(peer);
               RETVOID;
#endif /* GCP_MG */        
            }
         }
#ifdef ZG_DFTHA
         /* generate reverse update */
         else
         {
            ZgRvUpdInfo  info;
            info.action = ZG_RVUPD_RETX_FAILED; 
            info.u.retxPeer = peer->accessInfo.peerId;
            zgReverseUpd(&info, (peer->accessInfo.peerId), MG_QUEUE_NONE,
                         peer->tsap->tsapCfg.tSAPId);
         }
#endif /* ZG_DFTHA */
      }
      /* Delete the transaction */
      mgAbortTxTrans(peer, txCb, errCode);
   }
#endif /* GCP_MGCO */

   RETVOID;
}

#endif /* GCP_USER_RETX_CNTRL */



/*
*
*       Fun:    mgPrcBndReqTmrExpiry
*
*       Desc:   This function process Response Timer Expiry
*
*       Ret:    None
*
*       Notes:  Implies that we can dequeue the ACK sent to a command received
*               previously since 30 seconds queuing time is over
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcBndReqTmrExpiry
(
MgTSAPCb           *tsap               /* TSAP Control Block */
)
#else
PUBLIC Void mgPrcBndReqTmrExpiry  (tsap)
MgTSAPCb           *tsap;              /* TSAP Control Block */
#endif
{
   TRC2(mgPrcBndReqTmrExpiry)

#if (ERRCLASS & ERRCLS_DEBUG)
#ifdef ZG_DFTHA
   if(!((zgChkCRsetStatus()) == TRUE))
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG267, MG_BNDREQ_TMR,
         "[MGCP] mgPrcBndReqTmrExpiry(): BndReq Timer Expired in NcRset\n");
      RETVOID;
   }
#endif /* ZG_DFTHA */
#endif /* ERRCLASS & ERRCLS_DEBUG */

   if (tsap->state == LMG_SAP_WAIT_BNDENB && 
       tsap->bndRetxCnt < MG_MAX_INTRETRY)
   {
      /* Increment bind retry count */
      tsap->bndRetxCnt++;
      MG_ISSUE_BNDREQ(tsap);
      RETVOID;
   }

   /* Update the State of the tsap */
   tsap->state = LMG_SAP_UBND_DIS;

   /* Send a Status Indication to the Layer Manager that Bind Failed */
   mgGenStaInd(STTSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_FAIL,
               LCM_CAUSE_UNKNOWN, LMG_ALARMINFO_NONE, NULLP, 0, 
               LMG_ALARMINFO_INVSAPID);

   RETVOID;
} /* end of mgPrcBndReqTmrExpiry */




/*
*
*       Fun:    mgPrcDelPeerTmrExpiry
*
*       Desc:   This function process Delete Peer timer Expiry
*
*       Ret:    None
*
*       Notes:  Implies that delete peer timer is expired, this is possible
*       when service user has invoked a primitive or some internal event had
*       occured
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcDelPeerTmrExpiry
(
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PUBLIC Void mgPrcDelPeerTmrExpiry(peer)
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
#ifdef GCP_MGCO
#ifdef GCP_MG
   U8              state;              /* peer state */    
   U8              protocol;           /* protocol type of peer */
   MgSSAPCb        *ssap;
   MgPeerCb        *newPeer;           /* New Peer Control Block */
   CmLList         *node;              /* Linked List Node */
   S16             ret;                /* Return Value */
   SpId            sapId;              /* SSAP Id */
#endif /* GCP_MG */
#endif /* GCP_MGCO */

   TRC2(mgPrcDelPeerTmrExpiry)

#if (ERRCLASS & ERRCLS_DEBUG)
#ifdef ZG_DFTHA
   if(!((zgChkCRsetStatus()) == TRUE))
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG268, MG_DEL_PEER_TMR,
         "[MGCP] mgPrcDelPeerTmrExpiry(): Del Peer Timer Expired in NcRset\n");
      RETVOID;
   }
#endif /* ZG_DFTHA */
#endif /* ERRCLASS & ERRCLS_DEBUG */

#ifdef GCP_MGCO
#ifdef GCP_MG
   state = peer->state; 
   protocol = peer->mntInfo.protocolType;
   ssap = peer->ssap;
#endif /* GCP_MG */
#endif /* GCP_MGCO */

   mgDeletePeer (peer, LMG_EVENT_PEER_REMOVED, LMG_CAUSE_USER_DEL_PEER, TRUE);
   /* 
    * On the MG side for MEGACO if we are removing association with
    * MGC we need to try and re-establish connection with one of
    * the secondary MGCs on the list 
    */
#ifdef GCP_MGCO
#ifdef GCP_MG
   if ((protocol == LMG_PROTOCOL_MGCO) &&
      (mgCb.genCfg.entType == LMG_ENT_GW) &&
      (ssap->crntMgc == peer))
   {
      newPeer = NULLP;

      /* We need to try other peer in the list */
      if (state == LMG_PEER_STATE_ACTIVE)
      {         
         CM_LLIST_FIRST_NODE(&(ssap->peerLst), node);
         if (peer != (MgPeerCb *)node->node)
            ssap->crntMgc = NULLP;
      }

      /* Select a new peer */
      mgSelectPeer(&(newPeer), ssap);
      if (newPeer != NULLP)
      {
         /* Valid peer is found */
         /* Initiate service change on the new peer */
         if (state != LMG_PEER_STATE_ACTIVE)
         {
            /*
             *  Changed theservice change reason code in the service change
             *  request , when the request is send to a secondary  MGC 
             */
             ret = mgSendSrvcChng(newPeer, MGT_SVCCHGMETH_RESTART,
                                 MG_SCRSN_COLD_BOOT, NULLP,
                                 LMG_INVALID_PEER_PORT,
                                 NULLP);
         }
         else
         {
            ret = mgSendSrvcChng(newPeer, MGT_SVCCHGMETH_FAILOVER,
                                 MG_SCRSN_MGC_IMPN_FAIL, NULLP,
                                 LMG_INVALID_PEER_PORT,
                                 NULLP);
         }
      }

      /* 
      * If no MGCs are available in the list then indicate to the layer
      * manager 
      */
      if ((newPeer == NULLP) || (ret != ROK))
      {
         /* No more MGCs available Should inform LM */
         sapId = ssap->ssapCfg.sSAPId;

         /* Send Status Indication to the layer manager */
         mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                     LMG_EVENT_ALL_MGC_FAILED, LCM_CAUSE_UNKNOWN, 
                     LMG_ALARMINFO_SAP, (Ptr)&(sapId), sizeof(SpId), 
                     LMG_ALARMINFO_INVSAPID);
         ssap->crntMgc = NULLP;
         /* assign crntMgc to the first node in the peerList */
         mgSelectPeer(&(ssap->crntMgc), ssap);
         RETVOID;
      }
      ssap->crntMgc = newPeer;
#ifdef ZG
      /* send SSAP update */
      zgRtUpd(ZG_CBTYPE_SSAP, (Ptr)ssap, CMPFTHA_UPDTYPE_SYNC, 
                                                      CMPFTHA_ACTN_MOD);
      zgUpdPeer();
#endif /* ZG */
   }
#endif /* GCP_MG */
#endif /* GCP_MGCO */

   RETVOID;

} /* end of mgPrcDelPeerTmrExpiry */





/******************************************************************************/
/*                    Timer Start/Stop  Functions                             */
/******************************************************************************/
/*
*
*       Fun:    mgStartTmr
*
*       Desc:   This function starts a timer for an entry
*
*       Ret:    ROK     -  SUCCESS
*               RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgStartTmr
(
S16                tmrEvnt,            /* Timer Event */
U32                tmrVal,             /* Timeout Period */
PTR                cb,                 /* Entry for which Timer Expired */
CmTimer            *timers             /* Timer Block */
)
#else
PUBLIC Void mgStartTmr (tmrEvnt, tmrVal, cb, timers)
S16                tmrEvnt;            /* Timer Event */
U32                tmrVal;             /* Timeout Period */
PTR                cb;                 /* Entry for which Timer Expired */
CmTimer            *timers;            /* Timer Block */
#endif
{
   CmTmrArg        tmrArg;             /* Timer Function Argument */

   TRC2(mgStartTmr)

   MG_FILL_TMR_ARG(tmrEvnt, tmrArg);
   
   /* Fill in rest of timer arguments */
   tmrArg.cb     = cb;                 /* Entry for which timer is started */
   tmrArg.timers = timers;             /* Timer List */
   tmrArg.evnt   = tmrEvnt;            /* Timer to be started */
   tmrArg.wait   = tmrVal;             /* Timeout period */
   tmrArg.tNum   = 0;                  /* Timer Index in Timer List..not used */
   /* Place the timer in the Timing Queue */
   cmPlcCbTq (&(tmrArg));

   RETVOID;

} /* end of mgStartTmr */




/*
*
*       Fun:    mgStopTmr
*
*       Desc:   This function stops a timer for an entry
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgStopTmr
(
S16                tmrEvnt,            /* Timer Event */
PTR                cb,                 /* Entry for which Timer Expired */
CmTimer            *timers             /* Timer Block */
)
#else
PUBLIC Void mgStopTmr (tmrEvnt, cb, timers)
S16                tmrEvnt;            /* Timer Event */
PTR                cb;                 /* Entry for which Timer Expired */
CmTimer            *timers;            /* Timer Block */
#endif
{
   CmTmrArg        tmrArg;             /* Timer function arguments */
   U8              idx;                /* Timer Index */

   TRC2(mgStopTmr)

   MG_FILL_TMR_ARG(tmrEvnt, tmrArg);

   for (idx = 0; idx < tmrArg.max; idx++)
   {
      if ((timers + idx)->tmrEvnt == tmrEvnt)
         break;
   }

#if (ERRCLASS & ERRCLS_DEBUG)
   if (idx == tmrArg.max)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG269, tmrEvnt,
                 "[MGCP] mgStopTmr(): Invalid Timer Event\n");
      RETVOID;
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   /* Fill in the rest of the timer arguments */
   tmrArg.cb     = cb;                 /* Entry for which timer is started */
   tmrArg.timers = timers;             /* Timer List */
   tmrArg.evnt   = tmrEvnt;            /* Timer to be started */
   tmrArg.tNum   = idx;                /* Timer Index in Timer List */

   /* Remove the timer from the timing queue */
   cmRmvCbTq(&(tmrArg));

   RETVOID;

} /* end of mgStopTmr */




/******************************************************************************/
/*                    Timer Activation Functions                              */
/******************************************************************************/

/*
*
*      Fun:    mgActvTmr
*
*      Desc:   Invoked by system services to process timers.
*
*              This function is registered during general configuration
*              using SRegTmr and is invoked at the specified period
*              by system services.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_tmr.c
*
*/
#ifdef ANSI
PUBLIC S16 mgActvTmr
(
void
)
#else
PUBLIC S16 mgActvTmr ()
#endif
{
   TRC2(mgActvTmr)

   cmPrcTmr(&mgCb.mgTqCp, mgCb.mgTq, (PFV) mgPrcTmrExpiry);

   RETVALUE(ROK);

} /* end of mgActvTmr() */





/*
*
*      Fun:    mgActvTmrTTL
*
*      Desc:   Invoked by system services to process timers.
*
*              This function is registered during general configuration
*              using SRegTmr and is invoked at the specified period
*              by system services.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mg_tmr.c
*
*/
#ifdef ANSI
PUBLIC S16 mgActvTmrTTL
(
void
)
#else
PUBLIC S16 mgActvTmrTTL ()
#endif
{
   TRC2(mgActvTmrTTL)

   cmPrcTmr(&mgCb.mgTTLTqCp, mgCb.mgTTLTq, (PFV) mgPrcTTLTmrExpiry);

   RETVALUE(ROK);

} /* end of mgActvTmrTTL() */



#ifdef GCP_MGCO

/*
*
*       Fun:    mgPrcIdleConnTmrExpiry
*
*       Desc:   This function process Idle TCP connection timer Expiry
*
*       Ret:    None
*
*       Notes:  Implies that remote end has invoked a TCP connection but
*       hasn't invoked any message within this time period
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcIdleConnTmrExpiry
(
MgTptSrvr          *srvr               /* Server Control Block */
)
#else
PUBLIC Void mgPrcIdleConnTmrExpiry  (srvr)
MgTptSrvr          *srvr;              /* Server Control Block */
#endif
{
   TRC2(mgPrcIdleConnTmrExpiry)

#if (ERRCLASS & ERRCLS_DEBUG)
#ifdef ZG_DFTHA
   if(!((zgChkCRsetStatus()) == TRUE))
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG270, MG_IDLE_CONN_TMR,
         "[MGCP] mgPrcIdleTmrExpiry(): Idle Timer Expired in NcRset\n");
      RETVOID;
   }
#endif /* ZG_DFTHA */
#endif /* ERRCLASS & ERRCLS_DEBUG */

   if (srvr->t.peer != NULLP)
   {
      mgPrcPeerDiscInd(srvr->t.peer);
   }
   mgSrvDiscReq(srvr, TRUE);

   RETVOID;

} /* end of mgPrcIdleConnTmrExpiry */
#endif /* GCP_MGCO */



#ifdef GCP_MG
/*
*
*       Fun:    mgPrcRstEndTmrExpiry
*
*       Desc:   This function processes Restart Avalanche timer Expiry
*
*       Ret:    None
*
*       Notes:  
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcRstEndTmrExpiry
(
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PUBLIC Void mgPrcRstEndTmrExpiry  (peer)
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
#ifdef GCP_MGCO
   MgPeerCb        *newPeer = NULLP;   /* MGC */
#endif /* GCP_MGCO */
   MgSSAPCb        *ssap;              /* SSAP Control Block */
   S16             ret;                /* Return Value */
   SpId            sapId;              /* SAP ID */

   TRC2(mgPrcRstEndTmrExpiry)

#if (ERRCLASS & ERRCLS_DEBUG)
#ifdef ZG_DFTHA
   if(!((zgChkCRsetStatus()) == TRUE))
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG271, MG_RST_AVLNCH_TMR,
         "[MGCP] mgPrcRstEndTmrExpiry(): Avalanche Timer Expired in NcRset\n");
      RETVOID;
   }
#endif /* ZG_DFTHA */
#endif /* ERRCLASS & ERRCLS_DEBUG */


   ssap    = NULLP;
   ret     = ROK;   

   ssap    = peer->ssap;
#ifdef GCP_MGCP
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
      ret = mgMgcpSendRSIP(peer, MGT_PARAM_RSTRT_RSTRT);
#endif /* GCP_MGCP */

#ifdef GCP_MGCO 
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
   {
      ssap->crntMgc = NULLP;

      mgSelectPeer(&newPeer, ssap);

      if (newPeer != NULLP)
      {
         /* Valid MGC found Initiate service change on the new peer */
         /* mg005.105: Added new state to support MG in lock/unlock state */
         /* if stack in in service after lock state, send reason as restoration */
/* mg007.105: Removed compilation problems with the MGCP */
#ifdef GCP_MG
         if(ssap->lockUnlock == TRUE)
         {   
            ret = mgSendSrvcChng(newPeer, MGT_SVCCHGMETH_RESTART,
                                  MG_SCRSN_SRV_RESTORED, NULLP,
                                  LMG_INVALID_PEER_PORT,
                                  NULLP);
         }
         else
#endif  /* GCP_MG */
         {   
            ret = mgSendSrvcChng(newPeer, MGT_SVCCHGMETH_RESTART,
                                  MG_SCRSN_COLD_BOOT, NULLP,
                                  LMG_INVALID_PEER_PORT,
                                  NULLP);
         }   
         
         if(ret == ROK)
         {
            ssap->crntMgc = newPeer;
         }
      }
   }
#endif /* GCP_MGCO */

   if (ret != ROK)
   {
      /* No more MGCs available - Inform LM */
      sapId = ssap->ssapCfg.sSAPId;

      /* Send Status Indication to the layer manager */
      mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, LMG_EVENT_ALL_MGC_FAILED, 
                  LCM_CAUSE_UNKNOWN, LMG_ALARMINFO_SAP, 
                  (Ptr)&(sapId), sizeof(SpId), LMG_ALARMINFO_INVSAPID);      
   }

   RETVOID;

} /* end of mgPrcRstEndTmrExpiry */

#endif /* GCP_MG */





#ifdef GCP_MGCO
#ifdef GCP_MGC
/*
*
*       Fun:    mgPrcHndOffTmrExpiry
*
*       Desc:   This function processes Handoff timer Expiry
*
*       Ret:    None
*
*       Notes:  
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcHndOffTmrExpiry
(
MgPeerCb *peer            /* Peer Control Block */
)
#else
PUBLIC Void mgPrcHndOffTmrExpiry  (peer)
MgPeerCb *peer;           /* Peer Control Block */
#endif
{
   TRC2(mgPrcHndOffTmrExpiry);

#if (ERRCLASS & ERRCLS_DEBUG)
#ifdef ZG_DFTHA
   if(!((zgChkCRsetStatus()) == TRUE))
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG272, MG_HANDOFF_TMR,
         "[MGCP] mgPrcHndOffTmrExpiry(): Handoff Timer Expired in NcRset\n");
      RETVOID;
   }
#endif /* ZG_DFTHA */
#endif /* ERRCLASS & ERRCLS_DEBUG */

   peer->mgcoInfo.hndOffInProg = FALSE;
   RETVOID;
} /* end of mgPrcHndOffTmrExpiry */

#endif /* GCP_MGC */
#endif /* GCP_MGCO */


#ifdef CM_ABNF_MT_LIB

/*
*
*       Fun:    mgPrcEncTmrExpiry
*
*       Desc:   This function processes Encode timer Expiry
*
*       Ret:    None
*
*       Notes:  
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcEncTmrExpiry
(
U32                 nodeIndx           /* node Index */
)
#else
PUBLIC Void mgPrcEncTmrExpiry  (nodeIndx)
U32                 nodeIndx;           /* node Index */
#endif
{
   MgStoreList     *node;           /* node */
   MgStoreEncReq   *txnBuf;         /* stored encode information */
   U16             noOfMsg;         /* no of msg */
   MgSSAPCb        *ssap;           /* ssap cb */
   MgPeerCb        *peer;           /* peer cb */
   U16             cntr;            /* counter */

   TRC2(mgPrcEncTmrExpiry)

   /* find out node */

   MG_FIND_AND_DEL_NODE_FRM_STORELST(node, nodeIndx, (&mgCb.encList));

   if(node == NULLP)
   {
      RETVOID;
   }
   txnBuf = (MgStoreEncReq *)(node->info); 
   /* free event structure */
   peer = MG_GET_PEER_FRM_PEERID(txnBuf->peerId);
   if(peer)
      ssap = peer->ssap;
   else
      ssap = mgCb.sSAPLst[txnBuf->spId];   

   if(txnBuf->protoVar == CM_ABNF_PROT_MEGACO_H248 /*MAH_TODO ||*/)
   {
#ifdef GCP_MGCO
      /* MEGACO case */
      MgMgcoMsg       *msg;        /* megaco message */
      msg = ((MgMgcoMsg *)(txnBuf->event));
      noOfMsg = msg->body.u.tl.num.val;
      /* only if source is User send txnReq Error to user */
      if(txnBuf->source == MG_USER)
      {
         mgHandleMgcoTxnReqErr(ssap, msg, MGT_ERR_INVALID_PARMS,MG_USER);
         /* txn will be freed by user */
         txnBuf->event = NULLP;      
      }
      for(cntr =0;cntr < noOfMsg; cntr++)
      {
         if(txnBuf->encBuf[cntr]->buf)
            mgPutMsg(txnBuf->encBuf[cntr]->buf);
      }
      /* now free resorces */
      mgFreeEncRsrc(&node, &txnBuf, NULLP, noOfMsg,txnBuf->protoVar, TRUE);
#endif /* GCP_MGCO */
   }
   else
   {
#ifdef GCP_MGCP
      /* MGCP Case */
      MgMgcpTxn       *txn;        /* MGCP txn */
      txn = ((MgMgcpTxn *)(txnBuf->event));
      noOfMsg = txn->numMsg;
      /* send error message to service user */
      if(txnBuf->source == MG_USER)
      {
         mgHandleMgcpTxnReqErr(ssap, txn, MG_IGNORE);
         txnBuf->event = NULLP;      
      }
      for(cntr =0;cntr < noOfMsg; cntr++)
      {
         if(txnBuf->encBuf[cntr]->buf)
            mgPutMsg(txnBuf->encBuf[cntr]->buf);
      }
      /* now free resorces */
      mgFreeEncRsrc(&node, &txnBuf, NULLP, noOfMsg,txnBuf->protoVar , TRUE);
#endif /* GCP_MGCP */
   }
   /* Check if no Encode/Decode Cfms are pending..and if we need to send 
    * deffered cfm for shutdown req ?? */
   if((mgCb.shutDwnCfm.dfrdCfm == TRUE) && (! MG_ENCDEC_CFM_IS_PENDING))
   {
      /* perform shutdown and send confirmation */
      mgDfrdShutDwn();
   }

   RETVOID;

} /* end of mgPrcEncTmrExpiry */


/*
*
*       Fun:    mgPrcDecTmrExpiry
*
*       Desc:   This function processes Encode timer Expiry
*
*       Ret:    None
*
*       Notes:  
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcDecTmrExpiry
(
U32                 nodeIndx           /* node Index */
)
#else
PUBLIC Void mgPrcDecTmrExpiry  (nodeIndx)
U32                 nodeIndx;           /* node Index */
#endif
{
   MgStoreList     *node;           /* node */
   MgStoreDecReq   *msgBuf;         /* stored encode information */
   CmTptAddr       *srcAddr;        /* source address */
   MgTptSrvr       *srvr;           /* server control block */

   TRC2(mgPrcDecTmrExpiry)

   /* find out node */

   MG_FIND_AND_DEL_NODE_FRM_STORELST(node, nodeIndx, (&mgCb.decList));

   if(node == NULLP)
   {
      RETVOID;
   }

   msgBuf = (MgStoreDecReq *)(node->info); 

   /* get server control block */
   MG_GET_SRVRCB(srvr,(msgBuf->suConnId), msgBuf->tsap);

   srcAddr = &(msgBuf->srcAddr);
   /* free event structure */
   if(msgBuf->protoVar == CM_ABNF_PROT_MEGACO_H248 /*|| MAH_TODO */ )
   {
#ifdef GCP_MGCO
      /* MEGACO case */
      MgMgcoMsg       *msg;        /* megaco message */
      msg = ((MgMgcoMsg *)(msgBuf->event));
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
#endif /* GCP_MGCO */
   }
   else
   {
#ifdef GCP_MGCP
      /* MGCP Case */
      MgMgcpTxn       *txn;        /* MGCP txn */
      MgMgcpMsg       *mgcpMsg;    /* MGCP Message */
      txn = ((MgMgcpTxn *)(msgBuf->event));
            /* send error response to Peer */
      mgcpMsg = txn->mgcpMsg[txn->numMsg];
      if (mgcpMsg->msgType.pres == PRSNT_NODEF &&
            mgcpMsg->msgType.val != MGT_MSG_RSP)
      {         
         /* Get transaction id */
         U32    trId;
         MG_MGCP_GET_TRANSID(mgcpMsg, trId);

         mgMgcpSendErrorResponse(srcAddr, trId, 
                              MGT_MGCP_RSP_CODE_PROT_ERROR, 
                              (U8 *)"Decoding of the Command Failed",
                              msgBuf->tsap); 
      }
      /* call function to process MgcpTxnInd */
      mgPrcMgcpTxnInd(msgBuf->tsap, srvr, srcAddr, NULLP, txn, NULLP);
#endif /* GCP_MGCP */
   }
   /* free resources */
   mgDeAlloc((Data *)msgBuf, sizeof(MgStoreDecReq));
   mgDeAlloc((Data *)node, sizeof(MgStoreList));

   /* Check if no Encode/Decode Cfms are pending..and if we need to send 
    * deffered cfm for shutdown req ?? */
   if((mgCb.shutDwnCfm.dfrdCfm == TRUE) && (! MG_ENCDEC_CFM_IS_PENDING))
   {
      /* perform shutdown and send confirmation */
      mgDfrdShutDwn();
   }

   RETVOID;
} /* end of mgPrcDecTmrExpiry */

#endif /* CM_ABNF_MT_LIB */

#endif /* ifdef MG */

#ifdef   GCP_PROV_MTP3
/*
*
*       Fun:    mgPrcStsEnqTmrExpiry
*
*       Desc:   This function processes Status Request timer Expiry
*
*       Ret:    None
*
*       Notes:  
*
*       File:   mg_tmr.c
*
*/

#ifdef ANSI
PUBLIC Void mgPrcStsEnqTmrExpiry
(
MgPeerCb                 *peerCb           /* Peer Control Block */
)
#else
PUBLIC Void mgPrcStsEnqTmrExpiry  (peerCb)
MgPeerCb                 *peerCb;           /* peer control Block */
#endif
{
   MgTSAPCb    *tsap = NULLP;
   U8          idx;
   U32         tmrVal;

   TRC2(mgPrcStsEnqTmrExpiry)

   /* Find the tsap */
   tsap  = peerCb->tsap;
   if ( peerCb->mgcoMtpCb.stsRetxCnt < MG_MAX_MTP_STSREQ_RETRY)
   {
        /* increment the retry count */
        peerCb->mgcoMtpCb.stsRetxCnt++;

      /* 
       * Check for Max retry for Status request  if it is less 
       * it  shall again issue a status request to MTP3 
       * Start a status request timer to query its status */
   
      idx = MG_MTP_STSENQ_TMR - MG_PEER_TMR_BASE;
      tmrVal = tsap->tsapCfg.mgMtpNwCfg.defStatusEnqTmr.val;
      if(tsap->tsapCfg.mgMtpNwCfg.defStatusEnqTmr.enb == TRUE)
      {        
         mgStartTmr(MG_MTP_STSENQ_TMR,tmrVal,(PTR)peerCb,
               &(peerCb->mntInfo.tmr[idx]));
      }
      /* Check if TSAP is valid and enabled then send status request again     */
      tsap = peerCb->tsap;
      if (( tsap != NULL) && ( tsap->state & LMG_SAP_BND_ENB ))
      {
         MgLiSntStaReq(&(tsap->spPst), tsap->tsapCfg.spId, peerCb->mgcoMtpCb.peerDpc);
      }
   }
   else 
   {
    /* Generate Layer Manager Alarm for this Peer */
   }
  
  RETVOID;
}  /* end of mgPrcStsEnqTmrExpiry */
#endif   /* GCP_PROV_MTP3 */

#if (defined (GCP_PKG_MGCO_ROOT ) && defined (GCP_VER_1_5))

#ifdef ANSI
PUBLIC  Void mgPrcProvRspRootTmrExpiry 
(
MgTxTransIdEnt   *txCb          /* Transaction Control Block */
)
#else
PUBLIC  Void mgPrcProvRspRootTmrExpiry (txCb ) 
MgTxTransIdEnt   *txCb;         /* Transaction Control Block */
#endif
{

   MgTransId       trId;               /* transaction id */
   TRC2(mgPrcProvRspRootTmrExpiry)
   
   trId = txCb->transId;
   /* Abort the transaction and  */
   /* Indicate the service user  */
   mgAbortTxTrans(txCb->peer, txCb, MG_PROV_RSP_ROOTTM_TMR);
   
   RETVOID;
}
#endif /* GCP_PKG_MGCO_ROOT */

/********************************************************************30**
 
        End of file:     mp_tmr.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:53:56 2005
*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bbk  1. Initial release.
1.1+        mg001.101 bbk  1. Fixed code for DNS Resolve Request Transmission
                              so that on retransmission we utilise the 
                              previously encoded buffer
            mg004.101 bbk  1. Do not contact DNS, if DNS is not available
            mg005.101 bbk  1. If DNS is not responding and peer is in 
                              in resolving state, remove the peer
            mg008.101 bbk  1. Removed check in mgPrcRetxTmrExpiry() to ensure
                              that notified entity filled by GCP layer is 
                              still alove as we don't fill Notified Entity
                              anymore.
                           2. Added remotePort variable to MgTxTransIdEnt
                              structure to ensure that retransmission happens
                              to same remote port. This ensures that 
                              message always goes to the notified entity 
                              port specified previously by Service User
                           3. Added retxOnIpAddr to MgTxTransIdEnt to ensure 
                              that if retransmission is required to be done
                              to a particular IP Addresses then that is where
                              it should go
/main/2      ---      pk  1. Added Timer support for MEGACO.
                           2. Modified Retransmission timer algo for MGCP.
                           3. Added Provisional Response timer for MGCP
                              and MEGACO.
             mg002.102  vj 1. Added a check for not doing any retransmissions 
                              if the peer delete timer is running.
             mg008.102  vj 1. In mgPrcRetxTmrExpiry, call RETVOID immeditaely 
                              after invoking mgAbortTxTrans().
                           2. A new function mgHndlPeerInRetxExpiry has been 
                              added which takes care of all processing for 
                              final expiry of retx timer under 
                              GCP_USER_RETX_CNTRL flag. This includes reseting 
                              peer->regReqTxnId if this is the "last" expiry for
                              MGCP transaction and this transaction is stack 
                              generated RSIP restart.  Further generate a alarm
                              to LM & a MgtStaInd at MGT interface in case of 
                              MGCP. In case of MEGACO handle the peer failure.
                              if the peer delete timer is running.
/main/3      ---      ra   1. GCP 1.3 release
            mg004.103 rg   1. Updated parameters of macro for modified 
                              algorithm for calculation of RTO for
                              retransmitted transactions
/main/4      ---      ka   1. Changes for Release v 1.4
            mg003.104 ka   1. Corrected the service change reason(code value)
                              for resending the service change message to a secondary
                              MGC
            mg005.104 ra   1. FTHA related changes.
/main/5      ---      pk   1. GCP 1.5 release
            mg002.105 ps   1.  Removed patch reference for 1.3 and 1.4
            mg004.105 gk   1.  Added mgHndlRstEnd method 
            mg005.105 gk   1. Added new state to support MG in lock/unlock state
            mg007.105 gk   1. Removed compilation problems with the MGCP
*********************************************************************91*/
