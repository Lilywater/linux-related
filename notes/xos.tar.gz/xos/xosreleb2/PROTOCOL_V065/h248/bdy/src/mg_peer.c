/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/
/********************************************************************20**
 
     Name:     GCP - Peer Control Module
 
     Type:     C source file
  
     Desc:     C Source Code for Peer Control Module
 
     File:     mg_peer.c
  
     Sid:      mp_peer.c@@/main/mgcp_rel_1.5_mnt/9 - Tue Jun  7 13:04:55 2005
   
     Prg:      bbk
  
*********************************************************************21*/
 
/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*
*/
 
/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*    
*   
*
*/

 
/*
 * The core of MGC product is implemented in following files:
 *
 *    mg_dns.c      DNS Interaction functions 
 *    mg_tmr.c      Timer Management/Maintenance functions
 *    mg_tpt.c      Transport Layer Interaction functions
 *    mg_trans.c    Transaction Management functions
 *    mg_peer.c     Peer Control functions
 *    mg_cord.c     Co-ordinator Module functions
 *    mg_ui.c       MGCP Upper Interface Functions
 *    mg_mi.c       MGCP Layer Management Interface
 *    mg_li.c       MGCP Lower Layer (TUCL) Interface
 *    cm_tenc.c     Common Text Based Encode Engine for MGCP messages
 *    cm_tdec.c     Common Text Based Decode Engine for MGCP messages
 */

/* header include files (.h) */
#include "envopt.h"        /* Environment options */  
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */

#ifdef MG

#include "gen.h"           /* General layer */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common Timer functions */
#include "cm_hash.h"       /* Hash library */
#include "cm_llist.h"      /* Doubly Linked List library */
#include "cm_inet.h"       /* Common Sockets Library */
#include "cm_tpt.h"        /* Common Transport Defines */
#include "cm_tkns.h"       /* Common Tokens Defines */
#include "cm_sdp.h"        /* SDP Defines */
#include "cm_dns.h"        /* common DNS library */
#include "cm_mblk.h"       /* Memory Management Defines */
#include "cm_abnf.h"
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include  "cm_ss7.h"       /* Common SS7 Defines */
#include  "snt.h"          /* MTP3 Interface Defines */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.h"           /* MGT Interface Defines */
#include "lmg.h"           /* MGCP Layer Management */
#include "mg_err.h"        /* MGCP Error Codes */
#include "mg.h"            /* MGCP Defines */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer */
#include "ssi.x"           /* System services */
#include "cm5.x"           /* Common timer functions */
#include "cm_hash.x"       /* Hash library */
#include "cm_llist.x"      /* Doubly Linked List library */
#include "cm_inet.x"       /* Common Sockets Library */
#include "cm_tpt.x"        /* Common Transport Definitions */
#include "cm_tkns.x"       /* Common Tokens Defines */
#include "cm_sdp.x"        /* SDP Definitions */
#include "cm_mblk.x"       /* Memory Block Management */
#include "cm_abnf.x"
#include "cm_lib.x"        /* Common library functions */
#include "cm_dns.x"        /* common dns library */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3 
#include  "cm_ss7.x"       /* Common SS7 Structure */
#include  "snt.x"          /* MTP3 Interface Structure */
#endif    /* GCP_PROV_MTP3 */

#include "mgt.x"           /* MGT Interface Structures */
#include "lmg.x"           /* MGCP Layer Management */
#include "mg.x"            /* MGCP Data Structures */
#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */


/* local defines, if any */
 
/* local typedefs, if any */
 
/* local externs, if any */

/* forward references */

/* public variable declaration */

/* private variable declaration */
PRIVATE S16 mgInsertPeerCbInLst ARGS((
        MgSSAPCb        *ssap,         /* SSAP control block */
        MgPeerCb        *peer,         /* Peer Control Block */
        MgPeerInitInfo  *peerInfo      /* Peer INIT info */
      ));

#ifdef GCP_MGCO
#ifdef GCP_MGC
PUBLIC S16 mgMatchMId ARGS((
        MgPeerCb        *peer,         /* Peer Control Block */
        MgMgcoMid       *addr          /* address */
      ));
#endif /* GCP_MGC */

#ifdef GCP_MG
PRIVATE Void mgAddIpAddr ARGS((
        MgPeerCb        *peer,         /* Peer Control Block */
        CmNetAddr       *addr          /* network address */
      ));
#endif /* GCP_MG */
 
#ifdef GCP_VER_1_5
/*mg002.105: Extern moved from mg.x for g++ compilation issue*/
EXTERN S16 mgAllocEventMem ARGS((
       Ptr       *memPtr,
       Size      memSize
    ));
       
EXTERN S16 mgFreeEventMem ARGS((
       Ptr       memPtr
    ));

EXTERN PUBLIC S16 mgVerifyVersion ARGS((
            MgMgcoTxn *mgcoTxn ,
            MgSSAPCb   *ssap));
#endif

#ifdef   GCP_PROV_MTP3
EXTERN PUBLIC MgPeerCb *mgGetMtpPeer ARGS((
MgMgcoMid          *mid,              /* MId */   
MgPeerCb           *peer,             /* Peer Control Block */
Dpc                *newDpc));            
#endif /* GCP_PROV_MTP3 */

#endif /* GCP_MGCO */



/******************************************************************************/
/*                 Peer Control Block Related Functions                       */
/******************************************************************************/


/*
*
*       Fun:    mgAllocPeerCb
*
*       Desc:   This function allocates and initialises a Peer Control Block
*
*       Ret:    Pointer to MgPeerCb - SUCCESS
*               NULLP               - FAILURE
*
*       Notes:  None
*
*       File:   mg_peer.c
*
*/

#ifdef ANSI
PUBLIC MgPeerCb * mgAllocPeerCb
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgPeerInitInfo     *peerInfo           /* Peer Information */
)
#else
PUBLIC MgPeerCb * mgAllocPeerCb (ssap, peerInfo)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgPeerInitInfo     *peerInfo;          /* Peer Information */
#endif
{
   U32             peerId;               /* Gateway Id */
   U16             idx;                /* Index/offset */
   U16             nameLen;            /* Peer Name Length */
   U8              errCode;            /* Error Code */
   MgPeerCb        *peer;              /* Peer Control Block */
   U8              protocol;

   TRC2(mgAllocPeerCb)

   /* Initialise */
   peer    = NULLP;
   peerId  = MG_INVALID_PEERID;
   errCode = MG_NONE;

#ifdef GCP_MGCO
#ifndef GCP_ASN
   /* Binary Support enabled for V_1_5 and with GCP_ASN support  */
   if ((peerInfo->protocolType == LMG_PROTOCOL_MGCO) &&
       (peerInfo->encodingScheme == LMG_ENCODE_BIN))
   {
      RETVALUE(NULLP);
   }
#endif /* GCP_ASN */
#endif /* GCP_MGCO */

#ifdef GCP_USE_PEERID
#ifdef ZG
   /* call PSF function to allocate peerId */
   zgObtainPeerId(peerInfo, &peerId);
#else
   MG_OBTAIN_FREE_PEERID(peerId);
#endif /* ZG */

#ifdef ZG
/* Now generate runtime update for freePeerIdx and lastFreePeerIdx , only master
 * should generate this update*/
   if(((zgChkCRsetStatus()) == TRUE))
   {
      zgRtUpd(ZG_CBTYPE_GCP,(Ptr)&mgCb,CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
   }
#endif /* ZG_DFTHA */
   if (peerId == MG_INVALID_PEERID)
   {
      /* No more Id's available */
      MG_GEN_RSRC_CATEG_ALRM(STSSAP, LMG_EVENT_PEERLST_EXHAUSTED, MG_IGNORE,
                             MG_IGNORE);
      RETVALUE(NULLP);
   }
#endif /* GCP_USE_PEERID */

   /* Allocate memory for the Peer Control Block */
   if ((peer = (MgPeerCb *)mgMalloc(sizeof(MgPeerCb))) == NULLP)
   {
#ifdef GCP_USE_PEERID
      /* Free the PeerId allocated for this peer */
      MG_RELEASE_PEERID(peerId);
#endif /* GCP_USE_PEERID */

      MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_SMEM_ALLOC_FAIL,
                             mgCb.init.region, mgCb.init.pool);
      RETVALUE(NULLP);
   }



#ifdef    GCP_PROV_SCTP

   if (peerInfo->transportType == LMG_TPT_SCTP)
   {
      /*
       *   allocate assocCfg struct iff peerInfo->allocAssocCfg is set
       *   to TRUE.
       *
       *   peerInfo->allocAssocCfg is set to TRUE when MgAllocPeerCb()
       *   is called from mp_mi.c peer configuration routines.
       *
       *   peerInfo->allocAssocCfg is set to FALSE when MgAllocPeerCb()
       *   is called from mp_peer.c routines to allocate peer CB at
       *   run time. At these places, assocCfg would already have been
       *   allocated in the SctAssocInd primitive. However, svcChgMgcId
       *   cases are different since a new peer is allocated for which
       *   SctAssocInd was never received & a SctAssocReq is to be sent
       *   to them immediately. For such cases peerInfo->allocAssocCfg
       *   should be set to TRUE.
       */

      if (peerInfo->allocAssocCfg == TRUE)
      {
         if ((peer->assocCfg = (MgAssocCfg *)mgMalloc(sizeof(MgAssocCfg)))
              == NULLP)
         {
#ifdef GCP_USE_PEERID
               /* Free the PeerId allocated for this peer */
               MG_RELEASE_PEERID(peerId);
#endif /* GCP_USE_PEERID */

               mgDeAlloc((Data *)peer, sizeof(MgPeerCb));

               MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_SMEM_ALLOC_FAIL,
                                      mgCb.init.region, mgCb.init.pool);

               RETVALUE(NULLP);
         }
      /*
       *   copy the assocCfg information from peerInfo
       */

      cmMemcpy((U8 *)peer->assocCfg, (CONSTANT U8 *)&(peerInfo->assocCfg),
               sizeof(MgAssocCfg));
      }

      /* mg001.105: TOS related changes */
#ifdef    GCP_MG
      peer->mgcoInfo.tos = peerInfo->tos;
#endif /* GCP_MG */
   }

#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
   if (peerInfo->transportType == LMG_TPT_MTP3)
   {
      /* Sanity check for peer Dpc and tsap validity in MTP3 case */
      if((peerInfo->tsap == NULLP) || (peerInfo->peerDpc == NULLD))
      {
#ifdef GCP_USE_PEERID
               /* Free the PeerId allocated for this peer */
               MG_RELEASE_PEERID(peerId);
#endif /* GCP_USE_PEERID */

               mgDeAlloc((Data *)peer, sizeof(MgPeerCb));

               MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_SMEM_ALLOC_FAIL,
                                      mgCb.init.region, mgCb.init.pool);

               RETVALUE(NULLP);
       }

         peer->mgcoMtpCb.peerDpc = peerInfo->peerDpc;

      /* If Peer is configured then mark the state of DPC as OFFLINE but if
       * it is by discovery then mark the state as ONLINE as We have only
       * received this service change when this point code is onLine 
       */  
      if(peerInfo->byCfg == TRUE)
         {
         peer->mgcoMtpCb.status &= SP_OFFLINE;
         /* Send Status Request to MTP3 for this Point Code */
         MG_ISSUE_MTP_STS_REQ(peer, peerInfo->tsap)
         }
      else
         peer->mgcoMtpCb.status |= SP_ONLINE;
         
      /* Mark the initial congestion level as uncongested */
      peer->mgcoMtpCb.congLvl = SN_PRI0;
      /* Initialise Retransmission of Status Request to NULL */
      peer->mgcoMtpCb.stsRetxCnt  = 0;
      peer->tsap  = peerInfo->tsap;
   }
#endif   /* GCP_PROV_MTP3 */



   /* Initialise the Peer Control Block */

   nameLen = cmStrlen((CONSTANT U8 *)peerInfo->name);
   if (nameLen > 0)
   {
      cmMemcpy((U8 *)peer->accessInfo.name, (CONSTANT U8 *)peerInfo->name, 
               nameLen);
      peer->accessInfo.namePres = TRUE;
   }
   else 
      peer->accessInfo.namePres = FALSE;

#ifdef GCP_USE_PEERID
   peer->accessInfo.peerId      = peerId;
#endif /* GCP_USE_PEERID */

#ifdef ZG
   peer->removeAllTxns =  FALSE;
   peer->bringToCfg    =  FALSE;
   peer->delPeerTmr    =  FALSE;
#endif /* ZG */

#ifdef GCP_MGCP
   if (peerInfo->protocolType == LMG_PROTOCOL_MGCP)
   {
      peer->mgcpInfo.suspThold   = peerInfo->mgcpInfo.suspThold;
      peer->mgcpInfo.disconThold = peerInfo->mgcpInfo.disconThold;
      peer->mgcpInfo.ttl         = peerInfo->ttl; 
      peer->mgcpInfo.ntfyEntPeer = FALSE;
   }
#endif /* MG_MGCP */

  /* 
   * all RTO calculations will be done in ticks so convert 
   * the initRtt to ticks; Calculate initial rto
   */
   MG_SET_PEER_INIT_RTO (peerInfo->initRtt, peer);

#ifdef GCP_MG
   peer->regReqTxnId              = MG_INVALID_TRANSID;
#endif /* GCP_MG */
   peer->ssap                     = ssap;
   peer->mntInfo.usrKnows         = FALSE;
   peer->state                    = LMG_PEER_STATE_NULL;
   peer->mntInfo.trcLen           = peerInfo->trcLen;
   peer->mntInfo.mtuSize          = peerInfo->mtuSize;
   peer->mntInfo.protocolType     = protocol = peerInfo->protocolType;
   peer->mntInfo.variant          = peerInfo->variant;
   peer->mntInfo.resOrder         = MG_NONE;
   peer->accessInfo.transportType = peerInfo->transportType;
   if ((peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP) &&
       (peer->accessInfo.transportType != LMG_TPT_UDP))
   {
      peer->accessInfo.transportType = LMG_TPT_UDP;
   }
   /* 
    * In case of LM initiated peer Configuration, this variable should be set
    * outside this function to TRUE 
    */
   peer->mntInfo.byCfg            = peerInfo->byCfg;
   
   /* Added port number to peer configuration */
   peer->accessInfo.remotePort  = peerInfo->remotePort;

   /* if we are GC we send to the default port on MG  and vice versa,
    * at the configuration , cfgPort and remote Port in accessInfo 
    * should be same. The remotePort field in access Info shall be changed
    * in case we receive service change address from other side */
   if (peer->accessInfo.remotePort == LMG_INVALID_PEER_PORT)
   {
      if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
      {
         peer->accessInfo.remotePort = (mgCb.genCfg.entType == LMG_ENT_GC) ? 
                             MG_DEFAULT_MG_PORT : MG_DEFAULT_MGC_PORT;
      }
      else
      {
#ifdef GCP_MGCO
         if (protocol == LMG_PROTOCOL_MGCO)
         {

         /* mg004.105: Bugfix Start: Change for 2945 (Binary port) usage */
            peer->accessInfo.remotePort = 
                 (peerInfo->encodingScheme == LMG_ENCODE_BIN)
                                              ? MG_MGCO_DEFAULT_BINARY_PORT 
                                              : MG_MGCO_DEFAULT_TEXT_PORT ;
         }
#endif /* MG_MGCO */
      }
   }
#ifdef GCP_MGCO
   if (protocol == LMG_PROTOCOL_MGCO)
   {
#ifdef GCP_MG
      peer->mgcoInfo.cfgPort         = peer->accessInfo.remotePort;
      peer->mgcoInfo.mgcPriority     = peerInfo->priority;
#endif /* GCP_MG */
      peer->mgcoInfo.encodingScheme  = peerInfo->encodingScheme;
      peer->mgcoInfo.negotiatedVersion =
                    (peerInfo->mgcoVersion) & LMG_GET_MGCO_VER;
      peer->mgcoInfo.useAHScheme     = peerInfo->useAHScheme;
      peer->mgcoInfo.numActvConn     = 0;
#ifdef GCP_MGC
      peer->mgcoInfo.lclSrvcChngPort = LMG_INVALID_PEER_PORT;
      peer->mgcoInfo.origSrvcChngPort = LMG_INVALID_PEER_PORT;
      peer->mgcoInfo.hndOffInProg = FALSE;
#endif /* GCP_MGC */
      cmLListInit(&(peer->mgcoInfo.tcpConnLst));
      peer->mgcoInfo.nxtUseConn      = NULLP;
      peer->mgcoInfo.t.matedMG       = NULLP;

/* mg003.105: Configure MG/MGC pending limit */ 
#if (defined (GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))
      if (peer->limit.pres.pres != PRSNT_NODEF)
      {
         peer->limit.pres.pres = PRSNT_NODEF;
         peer->limit.mgOriginatedPendingLimit = 
            mgCb.genCfg.limit.mgOriginatedPendingLimit;
         peer->limit.mgcOriginatedPendingLimit = 
            mgCb.genCfg.limit.mgcOriginatedPendingLimit;
      }
#endif /*GCP_VER_1_5 GCP_PKG_MGCO_ROOT */ 
      
   }
#endif /* MG_MGCO */

   /* zero out all peer statistics */
   cmMemset(((U8 *)&peer->peerSts), 0, sizeof(MgPeerSts));
   if (ssap)
      peer->peerSts.sSAPId = ssap->ssapCfg.sSAPId;

#ifdef CM_DNS_LIB
   peer->dnsRetxCnt  = 0;
   peer->dnsReq      = NULLP;
#endif /* CM_DNS_LIB */

   /* Insert Peer CB in appropriate HASH lists */
   if(ROK != mgInsertPeerCbInLst(ssap, peer, peerInfo))
   {
      if (peer->accessInfo.peerAddrTbl.count > MG_NONE) 
      {
#ifdef GCP_MGCO
         if( (LMG_PROTOCOL_MGCO == protocol) && 
             (PRSNT_NODEF != peerInfo->mid.pres))
         {
            mgRemovePeerAddrs(peer);
         }
#endif /* GCP_MGCO */
#ifdef GCP_MGCP
         if (LMG_PROTOCOL_MGCP == protocol)
         {
            mgRemovePeerAddrs(peer);
         }
#endif /* GCP_MGCP */
      }
#ifdef GCP_USE_PEERID
      MG_RELEASE_PEERID(peerId);
#endif /* GCP_USE_PEERID */

      mgDeAlloc((Data *)peer, sizeof(MgPeerCb));

      MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_SMEM_ALLOC_FAIL,
                             mgCb.init.region, mgCb.init.pool);
      RETVALUE(NULLP);
   }
   if (peer->accessInfo.peerAddrTbl.count > MG_NONE)
      peer->state = LMG_PEER_STATE_AWAIT_REG;

   /* Initialise timer control blocks */
   cmInitTimers(peer->mntInfo.tmr, MG_MAXPEER_TMR);

   /* Initialise incoming transaction hash list */
   idx = (U16)(((PTR) &(((MgRxTransIdEnt *) 0)->inTransEnt)));
   if(ROK == cmHashListInit(&(peer->inTransLst), mgCb.genCfg.numBinsTxnIdHl, 
                       idx, FALSE, MG_TXNID_HASH_FUNC, mgCb.init.region, 
                       mgCb.init.pool))
   {
      /* Initialise outgoing transaction hash list */
      idx = (U16)(((PTR) &(((MgTxTransIdEnt *) 0)->outTransEnt)));
      if(ROK == cmHashListInit(&(peer->outTransLst), mgCb.genCfg.numBinsTxnIdHl
                        ,idx, FALSE, MG_TXNID_HASH_FUNC,
                        mgCb.init.region, mgCb.init.pool))           
      {
         /* Initialise linked lists */
         cmLListInit(&(peer->transQ));

#ifdef ZG_DFTHA
         cmLListInit((CmLListCp *) &(peer->peerTxnQ));
         cmLListInit((CmLListCp *) &(peer->usrTxnQ));
 
#endif /* ZG_DFTHA */

#ifdef GCP_MGCP
#ifdef GCP_VER_1_3
         /* Initialise list; this link list stores the transaction id for which
          * responses has been rcved and will be acknowledged subsequently when
          * commands will be rcved from user */
         peer->txnAckQ.info.trId = 0;
         peer->txnAckQ.info.peer = NULLP;
         peer->txnAckQ.next = NULLP;
         cmInitTimers(&(peer->txnAckQ.info.tmr),MG_DEFAULT_MAXTMR);
#endif
#endif /* GCP_MGCP */
         
#ifdef GCP_USE_PEERID
#ifdef ZG
         mgCb.peerLst[peerId & MG_PEERID_MASK]->peer = peer;
#else
         /* Insert peer control block in peerId based list */
         mgCb.peerLst[peerId]->peer = peer;
#endif /* ZG */
#endif /* GCP_USE_PEERID */

         /* Add the gateway in linked list of the SSAP */
         /* If the layer is representing MGC or it is MGCP protocol, 
          * add this peer to the tail of the list */
         peer->ssapPeerLstNode.node = (PTR)peer;
         if ((mgCb.genCfg.entType == LMG_ENT_GC) ||
             (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP))
         {
            cmLListAdd2Tail (&(ssap->peerLst), &(peer->ssapPeerLstNode));
         }
#ifdef GCP_MGCO
#ifdef GCP_MG
         else
         {
            CmLList *node;
            U32     i;
            Bool    crnt = FALSE;
            CM_LLIST_FIRST_NODE(&(ssap->peerLst), node);
            /* In case of MEGACO protocol and Media gateway , we should insert 
             * this peer in the priority order as specified by LM since this
             * list shall be used to select MGC, before this function is
             * called, no MGC with same priority should exist,
             * check this logic */
            for ( i = 0; i < cmLListLen(&(ssap->peerLst)); i++)
            {
               if (((MgPeerCb *)node->node)->mgcoInfo.mgcPriority > 
                       peer->mgcoInfo.mgcPriority)
               {
                  crnt = TRUE;
                  break;
               }
               CM_LLIST_NEXT_NODE(&(ssap->peerLst), node);
            }
            if (crnt == TRUE)
               cmLListInsCrnt(&(ssap->peerLst), &(peer->ssapPeerLstNode));
            else
               cmLListAdd2Tail (&(ssap->peerLst), &(peer->ssapPeerLstNode));
         }
#endif /* GCP_MG */
#endif /* MG_MGCO */
      }
      else
      {
         cmHashListDeinit(&(peer->inTransLst));
         errCode = RFAILED;
      }
   }
   else 
      errCode = RFAILED;

   if(RFAILED == errCode)
   {
      if (peer->accessInfo.peerAddrTbl.count > MG_NONE) 
      {
#ifdef GCP_MGCO
         if( (LMG_PROTOCOL_MGCO == protocol) && 
             (PRSNT_NODEF != peerInfo->mid.pres))
         {
            mgRemovePeerAddrs(peer);
         }
#endif /* GCP_MGCO */
#ifdef GCP_MGCP
         if (LMG_PROTOCOL_MGCP == protocol)
         {
            mgRemovePeerAddrs(peer);
         }
#endif /* GCP_MGCP */
      }
#ifdef GCP_USE_PEERID 
      /* Free the PeerId allocated for this peer */
      MG_RELEASE_PEERID(peerId);
#endif /* GCP_USE_PEERID */

      /* Free the allocated memory */
      mgDeAlloc((Data *)peer, sizeof(MgPeerCb));

      /* Send Status Indication to the layer manager */
      MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_SMEM_ALLOC_FAIL,
                             mgCb.init.region, mgCb.init.pool);
      RETVALUE(NULLP);
   }
               
#ifdef GCP_MGCP
   /* 
    * Start TTL expiry Timer only if we have IP Addresses otherwise
    * expect resolution to be done by the calling function
    */
#ifdef ZG_DFTHA
   /* Only Master shall start TTL Timer */
   if(zgChkCRsetStatus() == TRUE)
#endif /* ZG_DFTHA */
   {
      if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP &&
         peer->accessInfo.namePres == TRUE && 
         peer->accessInfo.peerAddrTbl.count > 0)
      {
         idx = MG_TTL_TMR - MG_PEER_TMR_BASE;
         mgStartTmr(MG_TTL_TMR, peer->mgcpInfo.ttl, (PTR)peer, 
                  &(peer->mntInfo.tmr[idx]));
      }
   }
#ifdef GCP_MGC
   if ( (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP) &&
        (peer->accessInfo.peerAddrTbl.count > 0) &&
        (LMG_ENT_GC == mgCb.genCfg.entType) )
   {
      peer->state = LMG_PEER_STATE_ACTIVE;
   }
#endif /* GCP_MGC */

#endif /* GCP_MGCP */

   /* Update the current peer count */
   mgCb.curNumPeer++;
   if (peerInfo->addrTbl.count > MG_NONE && 
       peer->accessInfo.peerAddrTbl.count != peerInfo->addrTbl.count)
   {
      /* Some Memory Allocation had failed */
      MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_SMEM_ALLOC_FAIL,
                             mgCb.init.region, mgCb.init.pool);
   }

#ifdef DEBUGP
   MGDBGP (MG_DBGMASK_PEER, (mgCb.init.prntBuf,
           "Peer created with peerId(%ld) and state(%d)\n", peerId, 
           peer->state));
#endif 


   RETVALUE(peer);
} /* end of mgAllocPeerCb */



/*
*
*       Fun:    mgInsertPeerCbInLst
*
*       Desc:   This function inserts Peer CB in appropriate hash lists.
*       For MGCP, insert in IP address based list, if IP address available &
*       also insert in domain name based list if available.
*       For MEGACO, insert the peer in the name based list, using MID as the
*       key. If the stack is MG, check if this is a duplicate entry. This may
*       happen in virtal MG scenario, where >1 virtual MGs are talking to
*       same MGC. Further, at MG side, if the MID is not present(This can happen 
*       in some transient scenarios virtual MGs), then insert based on IP
*       address in IP address based list, and if that is not present, insert 
*       based on domain name in name based list. 
* 
*       At MG side, while inserting, check for duplicates. At MGC duplicates
*       can never occur, as each MG will identified by a unique MID. Further,
*       for MEGACO-MGC, only MID based list would be used. 
 
*       Ret:    Pointer to MgPeerCb - SUCCESS
*               NULLP               - FAILURE
*
*       Notes:  None
*
*       File:   mg_peer.c
*
*/
#ifdef ANSI
PRIVATE S16 mgInsertPeerCbInLst
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgPeerCb           *peer,              /* Peer Control Block */
MgPeerInitInfo     *peerInfo           /* Peer Information */
)
#else
PRIVATE S16 mgInsertPeerCbInLst(ssap, peer, peerInfo)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgPeerCb           *peer;              /* Peer Control Block */
MgPeerInitInfo     *peerInfo;          /* Peer Information */
#endif
{
   MgIpAddrEnt    *addrEnt;
#ifdef GCP_MGCO
   MgPeerCb       *existPeer;
   U8             protocol;
#endif /* GCP_MGCO */
   U16            nameLen, idx = 0;
   Bool           insert = FALSE;

#ifdef GCP_MGCO
   protocol = peer->mntInfo.protocolType;
   existPeer = NULLP;
#endif /* GCP_MGCO */
   
   /* Insert baed on MID */
#ifdef GCP_MGCO
   if(LMG_PROTOCOL_MGCO == protocol)
   {
      if(PRSNT_NODEF == peerInfo->mid.pres)
      {
         cmMemcpy((U8 *)&(peer->accessInfo.mid), (U8 *)&(peerInfo->mid), 
               sizeof(MgMgcoMidStr));
#ifdef GCP_MG
         if(LMG_ENT_GW == mgCb.genCfg.entType)
         {
            if(ROK == cmHashListFind(&(mgCb.peerNameLst), 
                            peer->accessInfo.mid.val, peer->accessInfo.mid.len, 
                            (U16)MG_HASH_SEQNMB_DEF, (PTR *)&existPeer))
            {
               if(peer->ssap != existPeer->ssap)
               {
                 /* set the duplicate present flag for both of them */
                  existPeer->mgcoInfo.dupPeerPrsnt = TRUE;
                  peer->mgcoInfo.dupPeerPrsnt      = TRUE;
#ifdef DEBUGP
                  MGDBGP (MG_DBGMASK_PEER, (mgCb.init.prntBuf,
                          "Duplicate peer found with domain name %s\n", 
                          peer->accessInfo.name));
#endif
               }
               else
               {
                  RETVALUE(RFAILED);
               }
            }
         }
#endif /* GCP_MG */
         if(ROK != cmHashListInsert (&(mgCb.peerNameLst), (PTR) peer, 
                                  peer->accessInfo.mid.val,  
                                  peer->accessInfo.mid.len))
         {
            RETVALUE(RFAILED);
         }
         insert = TRUE;
      }
      else /* MID not present */
      {
#ifdef GCP_MGC
         if(LMG_ENT_GC == mgCb.genCfg.entType)
         {
            RETVALUE(RFAILED);
         }
#endif /* GCP_MGC */
      }

#ifdef   GCP_PROV_MTP3
   if(peer->accessInfo.transportType == LMG_TPT_MTP3)
   {
#ifdef GCP_MG
      if(LMG_ENT_GW == mgCb.genCfg.entType)
      {

         U16 i=0;
         MgPeerCb *oldMtpPeer;
         Bool  peerSameSsap = FALSE;

         while( ROK == cmHashListFind(&(peerInfo->tsap->mgcoMtpHlCp),
                  (U8 *)&(peer->mgcoMtpCb.peerDpc), 
                  MG_DPC_LEN, i, (PTR *)&oldMtpPeer))
         {
            /* Point the index to next peer */
            i++;
            if(peer->ssap == oldMtpPeer->ssap)
               /* peer with same ssap already exist so exit without adding the peer */
            {  
               peerSameSsap = TRUE;
               break;
            }
         }
         if ( peerSameSsap == TRUE)
         {

            RETVALUE(RFAILED);
         }
      }
#endif   /* GCP_MG */         
      if(ROK != cmHashListInsert(&(peerInfo->tsap->mgcoMtpHlCp), (PTR) peer,
               (U8 *) &(peer->mgcoMtpCb.peerDpc), MG_DPC_LEN))
      {
         /* Remove from MID list. At MG side, if reqd, reset dupPrsnt flag */
         /* To Maintain Consistency with both the List */
         cmHashListDelete(&(mgCb.peerNameLst), (PTR)peer);
#ifdef GCP_MG
         if( (peer->mgcoInfo.dupPeerPrsnt == TRUE) &&
             (LMG_ENT_GW == mgCb.genCfg.entType) )
         {
            MgPeerCb *peer1 = NULLP;
            MgPeerCb *peer2 = NULLP;
            U16      len;
            len = peer->accessInfo.mid.len;
            if(ROK == cmHashListFind(&(mgCb.peerNameLst), 
                            (U8 *)peer->accessInfo.mid.val, len, 
                            (U16)MG_HASH_SEQNMB_DEF, (PTR *)&peer1))
            {
               cmHashListFind(&(mgCb.peerNameLst), 
                            (U8 *)peer->accessInfo.mid.val, len, 
                            (U16)(MG_HASH_SEQNMB_DEF + 1), (PTR *)&peer2);
            }
            if ((peer1 != NULLP) && (peer2 == NULLP))
               peer1->mgcoInfo.dupPeerPrsnt = FALSE;
         }
#endif /* GCP_MG */

         RETVALUE(RFAILED);
      }
      insert = TRUE;
   }

#endif   /* GCP_PROV_MTP3 */
   }

#endif /* GCP_MGCO */

   /* 
    * Copy IP Addresses of the gateway and insert them in the IP address based 
    * hash list 
    */
   peer->accessInfo.peerAddrTbl.count = 0;
   for (idx = 0; idx < peerInfo->addrTbl.count; idx++)
   {
      /* Insert into IP address based list only if insert=FALSE. This will be
       * set to TRUE only in MEGACO path, when the peer has already been
       * inserted in MID based list */
      if(FALSE == insert)
      {
         addrEnt = NULLP;
         if ((addrEnt = (MgIpAddrEnt *) mgMalloc(sizeof(MgIpAddrEnt))) == NULLP)
            continue;

         /* Initialise addrEnt */
         addrEnt->peer = peer;
         /* Copy IP Address */
         cmMemcpy ((U8 *)&(addrEnt->ipAddr), 
                   (CONSTANT U8 *) &(peerInfo->addrTbl.netAddr[idx]), 
                   sizeof(CmNetAddr));
#ifdef GCP_MGCO
#ifdef GCP_MG
         if( (LMG_PROTOCOL_MGCO == protocol) && 
             (LMG_ENT_GW == mgCb.genCfg.entType))
         {
            MgIpAddrEnt     *addrEntExist = NULLP;        /* IP Address Entry */
            /* At MG, check whether a peer exists with same IP address */
            if (mgFindIpAddrLst(addrEnt->ipAddr.type, 
                                &(addrEnt->ipAddr.u.ipv4NetAddr),
                                &(addrEnt->ipAddr.u.ipv6NetAddr),
                                MG_HASH_SEQNMB_DEF,
                                &addrEntExist) == ROK)
            {
               /* check for duplicate configuration */
               if (peer->ssap != addrEntExist->peer->ssap)
               {
                  /* set the duplicate present flag for both of them */
                  peer->mgcoInfo.dupPeerPrsnt                   = TRUE;
                  addrEntExist->peer->mgcoInfo.dupPeerPrsnt      = TRUE;
#ifdef DEBUGP
                  MGDBGP (MG_DBGMASK_PEER, (mgCb.init.prntBuf,
                          "Duplicate peer found with IP address %lx\n", 
                          (U32)addrEnt->ipAddr.u.ipv4NetAddr));
#endif 
               }
               else
               {
                  RETVALUE(RFAILED);
               }
            }
         }
#endif /* GCP_MG */
#endif /* MG_MGCO */

         /* Add the IP Address entry into Hash List */
         if (mgInsertIpAddrLst(addrEnt) != ROK)
         {
            mgDeAlloc((Data *)addrEnt, sizeof(MgIpAddrEnt));
            continue;
         }
         /* Copy IP Address into Peer Control Block */
         cmMemcpy((U8 *) &(peer->accessInfo.peerAddrTbl.netAddr
                              [peer->accessInfo.peerAddrTbl.count++]),
                  (CONSTANT U8 *) &(addrEnt->ipAddr), sizeof(CmNetAddr));
      }
      else
      {
         cmMemcpy((U8 *) &(peer->accessInfo.peerAddrTbl.netAddr
                              [peer->accessInfo.peerAddrTbl.count++]),
                          (CONSTANT U8 *) &(peerInfo->addrTbl.netAddr[idx]), 
                          sizeof(CmNetAddr));
      }
   }

   if (peerInfo->addrTbl.count > MG_NONE && 
       peer->accessInfo.peerAddrTbl.count == MG_NONE)
   {
      RETVALUE(RFAILED);
   }

   /* Now do insertion based on domain name, if required */
   if (peer->accessInfo.namePres) 
   {
      nameLen = cmStrlen((CONSTANT U8 *)peer->accessInfo.name);
      if(FALSE == insert)
      {
#ifdef GCP_MGCO
#ifdef GCP_MG
         if( (LMG_PROTOCOL_MGCO == protocol) && 
             (LMG_ENT_GW == mgCb.genCfg.entType))
         {
            if(ROK == cmHashListFind(&(mgCb.peerNameLst), 
                         peer->accessInfo.name, nameLen, 
                         (U16)MG_HASH_SEQNMB_DEF, (PTR *)&existPeer))
            {
               if(peer->ssap != existPeer->ssap)
               {
                 /* set the duplicate present flag for both of them */
                  existPeer->mgcoInfo.dupPeerPrsnt = TRUE;
                  peer->mgcoInfo.dupPeerPrsnt      = TRUE;
#ifdef DEBUGP
                  MGDBGP (MG_DBGMASK_PEER, (mgCb.init.prntBuf,
                          "Duplicate peer found with domain name %s\n", 
                          peer->accessInfo.name));
#endif
               }
               else
               {
                  RETVALUE(RFAILED);
               }
            }
         }
#endif /* GCP_MG */
#endif /* GCP_MGCO */
         if(ROK != cmHashListInsert (&(mgCb.peerNameLst), (PTR) peer, 
                              peer->accessInfo.name, nameLen)) 
         {
            RETVALUE(RFAILED);
         }
      }
   }
   RETVALUE(ROK);
}



/*
*
*       Fun:    mgDeAllocPeerCb
*
*       Desc:   This function deallocates Peer Control Block
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_peer.c
*
*/

#ifdef ANSI
PUBLIC Void mgDeAllocPeerCb
(
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PUBLIC Void mgDeAllocPeerCb (peer)
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
   TRC2(mgDeAllocPeerCb)

#if (ERRCLASS & ERRCLS_DEBUG)
   if ((CM_HASH_NMBENT(&(peer->inTransLst)) > MG_NONE) ||
       (CM_HASH_NMBENT(&(peer->outTransLst)) > MG_NONE))
   {
#ifdef GCP_USE_PEERID
      MGLOGERROR(ERRCLS_DEBUG, EMG203, peer->accessInfo.peerId,
                 "[MGCP] mgDeAllocPeerCb: Transaction not freed\n");
#else
      MGLOGERROR(ERRCLS_DEBUG, EMG204, MG_INVALID_PEERID,
                 "[MGCP] mgDeAllocPeerCb: Transaction not freed\n");
#endif
      RETVOID;
   }

#ifdef GCP_MGCO
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
   {
      if ((cmLListLen(&(peer->mgcoInfo.tcpConnLst)) > MG_NONE))
      {
#ifndef ZG
#ifdef GCP_USE_PEERID
         MGLOGERROR(ERRCLS_DEBUG, EMG205, peer->accessInfo.peerId,
                 "[MGCP] mgDeAllocPeerCb: TCP connection not cleared\n");
#else
         MGLOGERROR(ERRCLS_DEBUG, EMG206, MG_INVALID_PEERID,
                 "[MGCP] mgDeAllocPeerCb: TCP connection not cleared\n");
#endif
#endif /* ZG */
         RETVOID;
      }
   }
#endif /* MG_MGCO */
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   /* 
    * Try to remove from IP address list only if MID is not present. 
    * If MID is present, the peer would only be in MID based list.
    */
#ifdef GCP_MGCO
   if(LMG_PROTOCOL_MGCO == peer->mntInfo.protocolType) 
   {
      /* Remove from IP address list if there is any entry */
      mgRemovePeerAddrs(peer);

      if(PRSNT_NODEF == peer->accessInfo.mid.pres)
      {
         /* Remove from MID list. At MG side, if reqd, reset dupPrsnt flag */
         cmHashListDelete(&(mgCb.peerNameLst), (PTR)peer);
#ifdef GCP_MG
         if( (peer->mgcoInfo.dupPeerPrsnt == TRUE) &&
             (LMG_ENT_GW == mgCb.genCfg.entType) )
         {
            MgPeerCb *peer1 = NULLP;
            MgPeerCb *peer2 = NULLP;
            U16      len;
            len = peer->accessInfo.mid.len;
            if(ROK == cmHashListFind(&(mgCb.peerNameLst), 
                            (U8 *)peer->accessInfo.mid.val, len, 
                            (U16)MG_HASH_SEQNMB_DEF, (PTR *)&peer1))
            {
               cmHashListFind(&(mgCb.peerNameLst), 
                            (U8 *)peer->accessInfo.mid.val, len, 
                            (U16)(MG_HASH_SEQNMB_DEF + 1), (PTR *)&peer2);
            }
            if ((peer1 != NULLP) && (peer2 == NULLP))
               peer1->mgcoInfo.dupPeerPrsnt = FALSE;
         }
#endif /* GCP_MG */
     }
#ifdef   GCP_PROV_MTP3
   /* Delete the peer from DPC based hash list at Tsap */
   if(peer->accessInfo.transportType == LMG_TPT_MTP3)
      cmHashListDelete(&(peer->tsap->mgcoMtpHlCp),(PTR)peer);      
#endif   /* GCP_PROV_MTP3 */      
         
  }
#endif /* GCP_MGCO */

#ifdef GCP_MGCP 
   if(LMG_PROTOCOL_MGCP == peer->mntInfo.protocolType) 
   {
      mgRemovePeerAddrs(peer);
   }
#endif /* GCP_MGCP */

#ifdef GCP_USE_PEERID
   /* Free the gateway Id attached */
#ifdef ZG
   /* Only master should release peerId */
   if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG */
   {
      MG_RELEASE_PEERID(peer->accessInfo.peerId);
#ifdef ZG
      /* Send runtime update to shadows ( for freePeerIdx and lastFreePeerIdx)
       *  */
      zgRtUpd(ZG_CBTYPE_GCP, (Ptr)(&mgCb), CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_MOD);
      zgUpdPeer();
#endif /* ZG */
   }
#ifdef ZG
   else
   {
      U32     id;
      id = peer->accessInfo.peerId & MG_PEERID_MASK;
      mgCb.peerLst[id]->peer   = NULLP;
   }
#endif /* ZG */
#endif /* GCP_USE_PEERID */

   /* Delete the gateway from name based list in Global Control Block */
   if (peer->accessInfo.namePres)
      cmHashListDelete(&(mgCb.peerNameLst), (PTR)peer);

   /* Reset of dupPrsnt flag reqd only at MG side */
   /* In case of MEGACO protocol, if dupPeerPrsnt flag is TRUE , there may be
    * a need to reset it to FALSE if there is only one peer remaining with
    * same domain name */
#ifdef GCP_MGCO
#ifdef GCP_MG
   if ( (LMG_PROTOCOL_MGCO == peer->mntInfo.protocolType) &&
        (LMG_ENT_GW == mgCb.genCfg.entType) &&
        (TRUE == peer->mgcoInfo.dupPeerPrsnt) )
   {
      S16      ret;  
      MgPeerCb *peer1 = NULLP;
      MgPeerCb *peer2 = NULLP;
      U8      nameLen = (U8)cmStrlen(peer->accessInfo.name);
         
      ret = cmHashListFind(&(mgCb.peerNameLst), (U8 *)peer->accessInfo.name, 
                           (U16)nameLen, (U16)MG_HASH_SEQNMB_DEF, 
                           (PTR *)&peer1);
      if (ret == ROK)
         ret = cmHashListFind(&(mgCb.peerNameLst), (U8 *)peer->accessInfo.name, 
                                (U16)nameLen, MG_HASH_SEQNMB_DEF + 1, 
                                (PTR *)&peer2);
      if ((peer1 != NULLP) && (peer2 == NULLP))
         peer1->mgcoInfo.dupPeerPrsnt = FALSE;
   }
#endif /* GCP_MG */
#endif /* MG_MGCO */

   /* Delete the gateway from the SSAP Based Linked List */
   cmLListDelFrm(&(peer->ssap->peerLst), &(peer->ssapPeerLstNode));

   /* update the current peer count */
   if(mgCb.curNumPeer)
      mgCb.curNumPeer--;

   /* Stop Any active timers */
   MG_STOP_PEER_TMRS(peer);


   /* deinit the hash list in the peer blk */
   cmHashListDeinit(&peer->inTransLst);
   cmHashListDeinit(&peer->outTransLst);

#ifdef DEBUGP
#ifdef GCP_USE_PEERID
   MGDBGP (MG_DBGMASK_PEER, (mgCb.init.prntBuf,
           "Peer deleted with peerId(%ld)\n", peer->accessInfo.peerId));
#else
   MGDBGP (MG_DBGMASK_PEER, (mgCb.init.prntBuf,
           "Peer deleted with peerId(%d)\n", MG_INVALID_PEERID));
#endif
#endif 



#ifdef    GCP_PROV_SCTP
   /*
    *   For SCTP as transport, re-initialize the assocCb's peer
    *   field to NULLP since this peer is NO longer valid;
    *
    *   Free peer->assocCfg;
    */
   if ((peer->accessInfo.transportType == LMG_TPT_SCTP) && (peer->assocCb))
   {
      peer->assocCb->peer = NULLP;

      if (peer->assocCfg)
      {
         mgDeAlloc((Data *)peer->assocCfg, sizeof(MgAssocCfg));
         peer->assocCfg = NULLP;
      }
   }
#endif /* GCP_PROV_SCTP */



   /* Free the memory attached with the control block */
   mgDeAlloc((Data *)peer, sizeof(MgPeerCb));


   RETVOID;

} /* end of mgDeAllocPeerCb */


/*
*
*       Fun:    mgDeletePeer
*
*       Desc:   This function frees resources attached to a Peer and 
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_peer.c
*
*/

#ifdef ANSI
PUBLIC Void mgDeletePeer
(
MgPeerCb           *peer,              /* Peer Control Block */
U16                event,              /* Event for Status Indication */
U16                cause,              /* Cause of Event */
Bool               delReqd             /* Delete Required */
)
#else
PUBLIC Void mgDeletePeer (peer, event, cause, delReqd)
MgPeerCb           *peer;              /* Peer Control Block */
U16                event;              /* Event for Status Indication */
U16                cause;              /* Cause of Event */
Bool               delReqd;            /* Delete Required */
#endif

{
   S16             ret;                /* Return Value */
   Bool            updateUsr;          /* Update Service User */
   MgSSAPCb        *ssap;              /* SSAP Control Block */
   MgPeerInfo      alarmInfo;          /* Peer Information for Layer Manager */

#ifdef GCP_MGCP
   MgMgcpTxn       *txn = NULLP;       /* Transaction Structure */
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
   MgMgcoMsg       *msg = NULLP;       /* MEGACO message structure */
#ifdef GCP_MG
   U8               method;
   MgPeerCb        *newPeer = NULLP;
   Bool            setCrntMgc = FALSE;
   Bool            initReg = FALSE;
   U8              idx;
#endif /* GCP_MG */

/* mg003.105: Changes for command indication,it should be send in case of GCP_CH
 */
#if (defined(GCP_CH) && defined(GCP_VER_1_5))   
   MgMgcoInd       chInd; 
#endif /* GCP_CH && GCP_VER_1_5 */
#endif /* GCP_MGCO */

   Bool            informLM;           /* Update Layer manager */
   U8              protocol;
   State           origPeerState;

   TRC2(mgDeletePeer)

   updateUsr = (peer->mntInfo.usrKnows);
   ssap      = peer->ssap;
   protocol  = peer->mntInfo.protocolType;
   informLM  = FALSE;
   origPeerState = peer->state;
   cmMemset( (U8 *) (&alarmInfo), 0, sizeof(MgPeerInfo));

#ifdef ZG
   /* Only master should indicate about peer deletion to service user */
   if(!((zgChkCRsetStatus()) == TRUE))
   {
      updateUsr = FALSE;
   }
#endif /* ZG */

   if (event != MG_IGNORE)   
   {
      /* Use the MGCP specific macro */
      /* Copy Information for layer manager */
      if(LMG_PROTOCOL_MGCP == protocol)
      {
#ifdef GCP_MGCP
         MG_COPY_PEERINFO_INTO_MGCPTXN(alarmInfo, peer);
#endif /* GCP_MGCP */
      }
      else
      {
#ifdef GCP_MGCO
         MG_COPY_PEERINFO_INTO_MGCOMSG(alarmInfo, peer);
#endif /* GCP_MGCO */
      }
   }

   if (delReqd  == TRUE)
   {
      /* Check if the peer is in restart avalanche timer and this is 
       * the primary peer , we need to initiate the service change
       * on the first secondary peer */

#ifdef GCP_MGCO
#ifdef GCP_MG
      idx = MG_RST_AVLNCH_TMR - MG_PEER_TMR_BASE;
      if ((peer->mntInfo.tmr[idx].tmrEvnt == MG_RST_AVLNCH_TMR) &&
          (peer->state == LMG_PEER_STATE_AWAIT_REG))
      {
         initReg = TRUE;
      }
#endif /* GCP_MG */
#endif /* GCP_MGCO */
   }
   /* Free All Transactions and connections */
   mgBringPeerToCfgStatus(peer, TRUE);

#ifdef GCP_MGCO
#ifdef GCP_MG
   /* If the MGC with which communication is lost, is contacted
    * again, then the MG should send a service change with method as
    * DISCONNECTED. We need to store information for configured peers in the
    * peerflg variable that the MGC has been disconnected.
    */
   /* The peerflg variable was reset in function mgBringPeerToCfgStatus.
    * Ensure that accessInfo.peerflg is not reset again
    */
   if ((peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO) &&
       (mgCb.genCfg.entType == LMG_ENT_GW))
   {
      if ((origPeerState == LMG_PEER_STATE_ACTIVE) ||
          (origPeerState == LMG_PEER_STATE_UNDR_HNDOFF))
      {
         peer->accessInfo.peerflg |= MG_DISCONNECTED_TO_MGC;
      }
   }

#endif /* GCP_MG */
#endif /* GCP_MGCO */

   /* Store Information to be sent to User */
   if ((updateUsr == TRUE) && (ssap->state == LMG_SAP_BND_ENB))
   {
      if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
      {
#ifdef GCP_MGCP
         ret = mgAllocEventMem((Ptr *)&txn, sizeof(MgMgcpTxn)); 

         if (ret == ROK)
         {
            /* Fill local info Transaction Structure */
            MG_COPY_PEERINFO_INTO_MGCPTXN(txn->mgLclInfo, peer);
            ret = mgAllocEventMem((Ptr *)&(txn->mgcpMsg[0]), sizeof(MgMgcpMsg));
            if(ret == ROK)
            {
               txn->numMsg = 1;
               txn->mgcpMsg[0]->mgLclErr.errType.pres = PRSNT_NODEF;
               txn->mgcpMsg[0]->mgLclErr.errType.val = MGT_ERR_RMV_PEER_ID;
               txn->mgcpMsg[0]->msgType.pres = PRSNT_NODEF;
               txn->mgcpMsg[0]->msgType.val = MGT_MSG_NONE;
            }
         }
         else
            updateUsr = FALSE;
#endif /* MG_MGCP */
      } /* case of MGCP*/
      else if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
      {
#ifdef GCP_MGCO
         ret = mgAllocEventMem((Ptr *)&msg, sizeof(MgMgcoMsg)); 

         if (ret == ROK)
         {
            /* Initilized pres field of mgcoMsg */
            msg->pres.pres = PRSNT_NODEF;
         /* Fill local info Transaction Structure */
            /* Use the MGCO specific macro */
            MG_COPY_PEERINFO_INTO_MGCOMSG(msg->lcl, peer);
            {
               msg->body.type.pres = PRSNT_NODEF;
               msg->body.type.val = MGT_TXN;
               msg->body.u.tl.num.pres = PRSNT_NODEF;
               msg->body.u.tl.num.val = 1;
               MGGETMEM((Ptr *)&(msg->body.u.tl.txns), sizeof(PTR), 
                        (Ptr)msg, ret);
               if (ret != ROK)
               {
                  updateUsr = FALSE;
               }
               else
               {
                  MGGETMEM((Ptr *)&(msg->body.u.tl.txns[0]), sizeof(MgMgcoTxn), 
                           (Ptr)msg, ret);
                  if (ret != ROK)
                  {
                     updateUsr = FALSE;
                  }
                  else
                  {
                     msg->body.u.tl.txns[0]->type.pres = PRSNT_NODEF;
                     msg->body.u.tl.txns[0]->type.val = MGT_NONE;
                     msg->body.u.tl.txns[0]->mgLclErr.errType.pres = 
                                                    PRSNT_NODEF;
                     msg->body.u.tl.txns[0]->mgLclErr.errType.val = 
                                                    MGT_ERR_RMV_PEER_ID;
                     msg->body.u.tl.txns[0]->mgLclErr.trId.pres = NOTPRSNT;
                  }
               }
            }
         }
         else
            updateUsr = FALSE;
#endif /* MG_MGCO */
      } /* case of MEGACO */
   }


   /* Free the peer control block , if it is LM initiated deletion or
    * if this peer is a discovered peer */
   if ((delReqd == TRUE) || (peer->mntInfo.byCfg == FALSE))
   {
#ifdef GCP_MGCO
#ifdef GCP_MGC
      if ((peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO) &&
          (mgCb.genCfg.entType == LMG_ENT_GC))
      {
         if (peer->mgcoInfo.t.matedMG != NULLP)
         {
            peer->mgcoInfo.t.matedMG->mgcoInfo.t.matedMG = NULLP;
            peer->mgcoInfo.t.matedMG->mgcoInfo.peerType = MG_NONE;
         }
      }
#endif /* GCP_MGCO */
#endif /* GCP_MGC */

      informLM = TRUE;
#ifdef ZG
      if(!((zgChkCRsetStatus()) == TRUE))
      {
         informLM = FALSE;
      }
      /* send update del to standby , do del mapping in active for this peer */
      peer->removeAllTxns =  TRUE;
      zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
              CMPFTHA_ACTN_DEL);
      zgDelMapping(ZG_CBTYPE_PEER, (Ptr)peer);
#endif /* ZG */
#ifdef GCP_MGCO
#ifdef GCP_MG
      if(ssap->crntMgc == peer)
      {
         setCrntMgc = TRUE;
      }
#endif
#endif

      mgDeAllocPeerCb (peer);

#ifdef GCP_MGCO
#ifdef GCP_MG
      if(TRUE == setCrntMgc)
      {
         ssap->crntMgc = NULLP;
         mgSelectPeer(&(ssap->crntMgc), ssap);
      }
#endif
#endif
   }
#ifdef ZG
   else
   {
      /* send update del to standby */
      peer->removeAllTxns =  TRUE;
      zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
         CMPFTHA_ACTN_MOD);
      peer->removeAllTxns =  FALSE;
   }
#endif /* ZG */

   /* Indicate to the user */
   if ((updateUsr == TRUE) && (ssap->state == LMG_SAP_BND_ENB))
   {
      if (protocol == LMG_PROTOCOL_MGCP)
      {
#ifdef GCP_MGCP
         MgUiMgtMgcpTxnInd (&(ssap->suPst), ssap->suId, txn);
#endif /* MG_MGCP */
      }
      else if (protocol == LMG_PROTOCOL_MGCO)
      {
#ifdef GCP_MGCO
/* mg003.105: Changes for command indication */
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
         if ((ssap->ssapCfg.chEnabled == TRUE) &&
             (msg->body.u.tl.txns[0]->mgLclErr.errType.pres == PRSNT_NODEF))
         {
            chInd.transId.pres = NOTPRSNT;
            mgChHandleMgcoPrcIndErr(ssap, &chInd, 
                           msg->body.u.tl.txns[0]->mgLclErr.errType.val,
                           MG_USER);
            mgFreeEventMem((Ptr)(msg)->body.u.tl.txns[0]);
            mgFreeEventMem((Ptr) msg);
         }
         else
#endif /* GCP_CH && GCP_VER_1_5 */         
         MgUiMgtMgcoTxnInd (&(ssap->suPst), ssap->suId, msg);
#endif /* MG_MGCO */
      }
   }

   /* Indicate to the layer manager if required */
   /* fixed a typo - should be == instead of =. */
   if ((event != MG_IGNORE) && (informLM == TRUE))
   {
      mgGenStaInd (STSSAP, LCM_CATEGORY_PROTOCOL, event, cause, 
                   LMG_ALARMINFO_PEER,(Ptr)&alarmInfo, sizeof(MgPeerInfo), 
                   LMG_ALARMINFO_INVSAPID);
   }
#ifdef GCP_MGCO
#ifdef GCP_MG
   if ((protocol == LMG_PROTOCOL_MGCO) && (initReg == TRUE))
   {
      /* Select a new peer */
#ifdef ZG
      /* Only Master is allowed to update ssap->crntMgc */
      if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG */
      {
         mgSelectPeer(&(newPeer), ssap);
         if (newPeer != NULLP)
         {
            /* If the peer MGC is being contacted again after
             * disconnection, send method as DISCONNECTED **/
            MG_OBTAIN_SVCCHG_METHOD(method, newPeer);
            ret = mgSendSrvcChng(newPeer, method,
                                 MG_SCRSN_COLD_BOOT, NULLP,
                                 LMG_INVALID_PEER_PORT, NULLP);
         }
      }
   }
#endif /* GCP_MG */
#endif /* GCP_MGCO */

#ifdef ZG
   zgUpdPeer();
#endif /* ZG */

   RETVOID;

} /* end of mgDeletePeer */


/*
*
*       Fun:    mgBringPeerToCfgStatus
*
*       Desc:   This function frees brings peer to a configuration status
*
*       Ret:    None
*
*       Notes:  Removes all transactions, stops all timers
*
*       File:   mg_peer.c
*
*/
#ifdef ANSI
PUBLIC Void mgBringPeerToCfgStatus
(
MgPeerCb           *peer,              /* Peer Control Block */
Bool               stopTmrs            /* Stop Timers */
)
#else
PUBLIC Void mgBringPeerToCfgStatus (peer, stopTmrs)
MgPeerCb           *peer;              /* Peer Control Block */
Bool               stopTmrs;           /* Stop Timers */
#endif
{
#ifdef GCP_MGCO
   MgTptSrvr       *srvr;              /* Transport connections */ 
   CmLList         *cmLstEnt;          /* Next Linked List Entry */
#endif /* MG_MGCO */
#ifdef GCP_VER_1_3
   MgTxnAckList   *node;
#endif /* GCP_VER_1_3 */


   TRC2(mgBringPeerToCfgStatus)

#ifdef GCP_MG
   peer->regReqTxnId = MG_INVALID_TRANSID;
#endif /* GCP_MG */

   /* Remove all Transaction for this peer */
   mgRemoveAllTxn(MG_IGNORE, peer);
#ifdef ZG
   peer->bringToCfg = TRUE;
#endif /* ZG */

#ifdef GCP_VER_1_3
   /* free all stored txn node..stop timers if started*/
   /* free each txnAckList node */
   node = peer->txnAckQ.next;
   while(node != NULLP)
   {
      /* stop timer if started */
      if(node->info.tmr.tmrEvnt == MG_30SEC_ACK_TMR)
      {
         mgStopTmr(node->info.tmr.tmrEvnt,(PTR)node,&(node->info.tmr));
      }
      MG_RMV_FROM_LIST((&(peer->txnAckQ)),node);
      mgDeAlloc((Data *)node, sizeof(MgTxnAckList));
      node = peer->txnAckQ.next;
   }  
   
#endif /* GCP_VER_1_3 */

#ifdef ZG_DFTHA
   /* free all the message and node..which were queued when reverse
    * upadate was generaeted after receiving message from service user */
   mgFreeRvUpdRsrc((&peer->usrTxnQ), MG_PEER_OUTTXNQ); 
   /* now free all the message and node..which were queued when reverse
    * upadate was generaeted after receiving message from peer */
   mgFreeRvUpdRsrc((&peer->peerTxnQ), MG_PEER_INTXNQ); 

#endif /* ZG_DFTHA */

#ifdef GCP_MGCO
   /* Delete all TCP connections running on this peer */
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
   {
      cmLstEnt =  peer->mgcoInfo.tcpConnLst.first;
      while (cmLstEnt != NULLP)
      {
         srvr = (MgTptSrvr *) cmLstEnt->node;
         /* Move to next entry in the list */
         cmLstEnt = cmLstEnt->next;
         /* Delete the TCP connection */
         mgSrvDiscReq(srvr, TRUE);
      }


      /*
       *   Abort the association associated with this peer.
       *    Should the last arg (abrtFlag) be configurable?
       *   The flow is ->
       *   mgShutDown() calls mgDeleteTsap() which calls mgDisableTsap()
       *   which in turn calls mgCloseEndp() which frees the endpoint
       *   and all SCTP layer associations. mgCloseEndp() should be
       *   enhanced to free all GCP layer associations for that endpoint.
       *   mgBringPeerToCfgStatus() is called from mgDeletePeer() which
       *   in turn is called from mgShutDown(). mgBringPeerToCfgStatus()
       *   can also be from other places in the code. Therefore,
       *   check peer->assocCb before sending SctTermReq since it might
       *   already be NULLP when called from mgShutDown().
       */
#ifdef   GCP_PROV_SCTP
      if ((peer->accessInfo.transportType == LMG_TPT_SCTP) &&
          (peer->tsap) && 
          (peer->assocCb) &&
          (peer->assocCb->assocState == LMG_ASSOC_STATE_ACTIVE))
      {
         UConnId   spAssocId;

         /*
          *   The assocCb and the assocCfg would be freed
          *   in the mgDeAllocAssocCb func called from SctTermCfm
          */
         
         spAssocId = peer->assocCb->spAssocId;


         /*
          *   set assoc state to DOWN which means that the
          *   assoc is IN the PROCESS of tear-down. Once
          *   SctTermCfm is received, the assocCb is reset
          *   to NULLP.
          *
          *   The assoc state is set to WAIT_CFM if a Sct
          *   assoc req is to be made after SctTermReq has
          *   been sent but SctTermCfm has not been received
          *   yet.
          */

         peer->assocCb->assocState = LMG_ASSOC_STATE_DOWN;

         /*  peer->assocCb  = NULLP;  */

         /*
          *   Following is NOT to be done since assocCfg is
          *   supposed to be freed in mgDeAllocPeerCb() -
          *
          *   peer->assocCfg = NULLP;
          */

#ifdef ZG
      /* Send Mod Update to Standby */
         zgRtUpd(ZG_CBTYPE_ASSOC,(Ptr)(peer->assocCb),CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_MOD);
#endif /* ZG */

         MgLiSctTermReq(&(peer->tsap->spPst),
                        peer->tsap->tsapCfg.spId,
                        spAssocId,
                        SCT_ASSOCID_SP,
                        FALSE);

      }
         /*  we should NOT close the endpoint since we wud have to
          *  establish another association again using this endpoint
          *  mgCloseEndp(&(peer->tsap->endpCb), peer->tsap);  */
#endif /* GCP_PROV_SCTP */


#ifdef GCP_MGC
      /* Make the redirectred port as invalid */
      peer->mgcoInfo.lclSrvcChngPort = LMG_INVALID_PEER_PORT;
#endif /* GCP_MGC */
   }
#endif /* MG_MGCO */

   /* Update DNS library, if resolution request is still pending */
#ifdef CM_DNS_LIB
   if (peer->dnsReq != NULLP)
   {
      MG_ABORT_DNS_RSLV_REQ (peer->dnsReqId);
      mgPutMsg(peer->dnsReq);
   }
#endif /* CM_DNS_LIB */

   if (stopTmrs == TRUE)
   {
      MG_STOP_PEER_TMRS(peer);
   }
   /* In case of MEGACO, copy remote port value from configured value */
#ifdef GCP_MGCO
#ifdef GCP_MG
   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO)
      peer->accessInfo.remotePort = peer->mgcoInfo.cfgPort;
   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
      if (peer->mgcoInfo.t.handOffMGC != NULLP)
      {
         peer->mgcoInfo.t.handOffMGC->mgcoInfo.t.handOffMGC = NULLP;
         peer->mgcoInfo.t.handOffMGC = NULLP;
      }

/* mg003.105: Reset the negotiated version on the peer once VG is disabled */
      if(peer->ssap)
         peer->mgcoInfo.negotiatedVersion =
                 (peer->ssap->ssapCfg.maxMgcoVersion) & LMG_GET_MGCO_VER;
   }
#endif /* GCP_MG */
#endif /* MG_MGCO */
   /* Reset peer flag */
   peer->accessInfo.peerflg = 0;
#ifdef GCP_MGCO
#ifdef GCP_MGC
   peer->mgcoInfo.lclSrvcChngPort = LMG_INVALID_PEER_PORT;
   peer->mgcoInfo.hndOffInProg = FALSE;
#endif /* GCP_MGC */
#endif /* GCP_MGCO */
   if (peer->accessInfo.peerAddrTbl.count > 0)
      peer->state = LMG_PEER_STATE_AWAIT_REG;
   else
      peer->state = LMG_PEER_STATE_NULL;

   RETVOID;
} /* end of mgBringPeerToCfgStatus() */

 

/*
*
*       Fun:    mgRemovePeerAddrs
*
*       Desc:   This function frees resources attached ip address entries of a 
*               peer
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_peer.c
*
*/

#ifdef ANSI
PUBLIC Void mgRemovePeerAddrs
(
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PUBLIC Void mgRemovePeerAddrs (peer)
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
   U16             idx;                /* Index */
   MgIpAddrEnt     *addrEnt;           /* IP Address Entry */
   CmNetAddr       *ipAddr;            /* IP V4/V6 Address */
   Bool            found;              /* entry found */
#ifdef GCP_MGCO
   U16             i;                  /* temporary variable */
#endif /* GCP_MGCO */

   TRC2(mgRemovePeerAddrs)

   found = TRUE;

   for (idx = 0; idx < peer->accessInfo.peerAddrTbl.count; idx++)
   {
      /* Delete All IP Addresses inserted */
      addrEnt = NULLP;

      ipAddr = &(peer->accessInfo.peerAddrTbl.netAddr[idx]);

      if (mgFindIpAddrLst(ipAddr->type, &(ipAddr->u.ipv4NetAddr),
                          &(ipAddr->u.ipv6NetAddr), MG_HASH_SEQNMB_DEF,
                          &addrEnt) != ROK)
      {
         continue;
      }

      /* Delete from the hash list only if the peer matches */
#ifdef GCP_MGCO
      if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO) 
      {
         if (addrEnt->peer != peer)
         {
            found = FALSE;
            /* Find other entries in list to check if peer matches any
             * of them */
            for ( i = 1;; i++)
            {
               if (mgFindIpAddrLst(ipAddr->type, &(ipAddr->u.ipv4NetAddr),
                       &(ipAddr->u.ipv6NetAddr), (U16)(MG_HASH_SEQNMB_DEF + i),
                          &addrEnt) != ROK)
               {
                   break;
               }
               else
               {
                  if (addrEnt->peer != peer)
                     continue;
                  else
                  {
                     found = TRUE;
                     break;
                  }
               }
            } /* for */
         }
         else
            found = TRUE;
      } /* if ( protocol = MEGACO */
#endif /* MG_MGCO */
         
      if (found == TRUE)
      {
         mgDeleteIpAddrLst(addrEnt);
        /* in case of MEGACO protocol, if dupPeerPrsnt flag is TRUE , there may
         * be a need to reset it to FALSE if there is only one peer remaining 
         * with same address */
#ifdef GCP_MGCO
#ifdef GCP_MG
        if ( (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO) &&
             (peer->mgcoInfo.dupPeerPrsnt == TRUE) &&
             (LMG_ENT_GW == mgCb.genCfg.entType) )
        {
           MgIpAddrEnt     *addrEnt1 = NULLP;   /* IP Address Entry */
           MgIpAddrEnt     *addrEnt2 = NULLP;   /* IP Address Entry */
      
           if (mgFindIpAddrLst(ipAddr->type, &(ipAddr->u.ipv4NetAddr),
                                 &(ipAddr->u.ipv6NetAddr), 
                                 MG_HASH_SEQNMB_DEF, &addrEnt1) == ROK)
           {
              mgFindIpAddrLst(ipAddr->type, &(ipAddr->u.ipv4NetAddr),
                              &(ipAddr->u.ipv6NetAddr), 
                              MG_HASH_SEQNMB_DEF +1, &addrEnt2);
           }
           if ((addrEnt1 != NULLP) && (addrEnt2 == NULLP))
           {
              addrEnt1->peer->mgcoInfo.dupPeerPrsnt = FALSE;
           }
        }
#endif /* GCP_MG */
#endif /* MG_MGCO */

         /* Free the memory */
         mgDeAlloc((Data *)addrEnt, sizeof(MgIpAddrEnt));
      }
   }

   /* Reset count */
   peer->accessInfo.peerAddrTbl.count = 0;

   RETVOID;

} /* end of mgRemovePeerAddrs() */


/*
*
*       Fun:    mgRcvDnsRslvCfm
*
*       Desc:   This function process the response received from DNS for the
*               resolution request sent previously
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_peer.c
*
*/

#ifdef ANSI
PUBLIC Void mgRcvDnsRslvCfm
(
MgPeerCb           *peer,              /* Peer Control Block */
MgNetAddrTbl       *addrTbl,           /* Network Addresses of the Peer */
U16                port,               /* Contact Port */
U32                ttl                 /* Associated TTL */
)
#else
PUBLIC Void mgRcvDnsRslvCfm (peer, addrTbl, port, ttl)
MgPeerCb           *peer;              /* Peer Control Block */
MgNetAddrTbl       *addrTbl;           /* Network Addresses of the Peer */
U16                port;               /* Contact Port */
U32                ttl;                /* Associated TTL */
#endif

{
   U16             idx;                /* Index */
   Bool            informLM;           /* Update Layer Manger */
#ifdef GCP_MGCO
#ifdef GCP_MG
   S16             ret;                /* Return Value */
#endif /* GCP_MG */
#endif /* GCP_MGCO */


   TRC2(mgRcvDnsRslvCfm)


   informLM  = TRUE;

#ifdef CM_DNS_LIB
   /* Free DNS Request Buffer */
   if (peer->dnsReq != NULLP)
   {
      mgPutMsg(peer->dnsReq);
      peer->dnsReq = NULLP;
   }
#endif /* CM_DNS_LIB */

   /* Stop the DNS Request Timer */
   idx = MG_DNSREQ_TMR - MG_PEER_TMR_BASE;

   if (peer->mntInfo.tmr[idx].tmrEvnt == MG_DNSREQ_TMR)
      mgStopTmr(MG_DNSREQ_TMR, (PTR)peer, &(peer->mntInfo.tmr[idx]));

   /*
    * Check if indication has to be sent to SU. This indication has to be sent
    * irrespective of the value of addrTbl->count. 
    */
    if (peer->ssap->enbIndSent != TRUE)
    {
      peer->ssap->numPeerRslvd++;
      mgCheckEnbSsap(peer->ssap);
    }

   if (addrTbl->count == MG_NONE)
   {
      /* 
       * Resolution failed - Could have failed because Request was sent for
       * IPV4(or IPV6) while as peer is IPV6(or IPV4) - Send another request
       * if that is the case and resolution order configured requires it
       */
      if (((mgCb.genCfg.resOrder == LMG_RES_IPV4_IPV6) && 
          (peer->mntInfo.resOrder == LMG_RES_IPV4)) ||
          ((mgCb.genCfg.resOrder == LMG_RES_IPV6_IPV4) && 
          (peer->mntInfo.resOrder == LMG_RES_IPV6)))
      {
         mgSendDnsRslvReq (peer, peer->accessInfo.name);
         RETVOID;
      }

      /* Else consider that resolution failed */
      /* Possible cases of resolution for a peer */
      /* 1 : Configured peer at MG or MGC 
       * 2 : MGC handed off this MG to a new peer 
       * 3 : MGC gave a new mgcId in service change reply to
       *     the initial service change message 
       */
      if ((peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO) &&
          (mgCb.genCfg.entType == LMG_ENT_GW))
      {
#ifdef GCP_MGCO
         if (peer->accessInfo.peerflg & MG_HANDOFF_RQSTD)
         {
            /* current MGC has requested Handoff */
            mgAbortHandOff(peer, LMG_CAUSE_RESL_FAILED);
         }
         else if (peer->accessInfo.peerflg & MG_REDIRECTED_BY_MGC)
         {
            /* MG was redirected by the MGC earlier */
            mgAbortRedirection(peer, LMG_CAUSE_RESL_FAILED);
         }
         else 
            mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED, LMG_CAUSE_RESL_FAILED, 
                         FALSE);

#endif /* GCP_MGCO */
      }
      else 
         mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED, LMG_CAUSE_RESL_FAILED, 
                      FALSE);
      RETVOID;
   }
   else
   {
      /* 
       * DNS Resolution was successful this time around; reset the resolution
       * order to none so that next DNS Request goes out appropriately
       */
      peer->mntInfo.resOrder = MG_NONE;
   }
 
   if (peer->state != LMG_PEER_STATE_RESOLVING)
   {
      informLM = FALSE;
   }

   /* Update Peer State */
   if (peer->state == LMG_PEER_STATE_RESOLVING)
      peer->state = LMG_PEER_STATE_AWAIT_REG;

#ifdef GCP_MGCO
#ifdef GCP_MG
   /* Initialise ssap->crntMgc to proper value */
   if(peer->ssap->crntMgc == NULLP)
   {
      MgPeerCb    *peerCb = NULLP;
      mgSelectPeer(&peerCb, peer->ssap);
      peer->ssap->crntMgc = peerCb;
   }
#endif /* GCP_MG */
#endif /* GCP_MGCO */

   /* Update IP Addresses Received from DNS */
   if ((mgUpdatePeerIpAddr(peer, addrTbl)) != ROK)
   {
      if ((peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO) &&
          (mgCb.genCfg.entType == LMG_ENT_GW))
      {
#ifdef GCP_MGCO
         if (peer->accessInfo.peerflg & MG_HANDOFF_RQSTD)
         {
            /* current MGC has requested Handoff */
            mgAbortHandOff(peer, LMG_CAUSE_RESL_FAILED);
            RETVOID;
         }
         else if (peer->accessInfo.peerflg & MG_REDIRECTED_BY_MGC)
         {
            /* MG was redirected by the MGC earlier */
            mgAbortRedirection(peer, LMG_CAUSE_RESL_FAILED);
            RETVOID;
         }
#endif /* GCP_MGCO */
      }
      mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED, LMG_CAUSE_RESL_FAILED,
                   FALSE);
      RETVOID;
   }


#ifdef    GCP_PROV_SCTP

   /*
    *   Now that we have the DNS resolved ip addresses,
    *   update the destination address list and the
    *   primary destination address in assocCfg
    */

   if (peer->assocCfg)
   {
      U16      adrIndx;

      cmMemset((U8 *)&(peer->assocCfg->dstAddrLst), 0,
               sizeof(SctNetAddrLst));

      for (adrIndx=0; adrIndx < addrTbl->count; ++adrIndx)
         peer->assocCfg->dstAddrLst.nAddr[adrIndx]
                           = addrTbl->netAddr[adrIndx];

      /* mg002.105: remove compilation warning*/
      peer->assocCfg->dstAddrLst.nmb = (U8)addrTbl->count;

      /*
       *   use the first address in the resolved address
       *   list as the primary destination address
       */

      peer->assocCfg->priDstAddr     = addrTbl->netAddr[0];

   }

#endif    /* GCP_PROV_SCTP */

   
#ifdef GCP_MGCP
   peer->mgcpInfo.ttl     = ttl;

   if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
   {
      /* 
       * Update peer state to ACTIVE if this is a notified entity
       * peer 
       */
      if( (peer->accessInfo.peerAddrTbl.count > 0) && 
          (TRUE == peer->mgcpInfo.ntfyEntPeer) )
      {
         peer->state = LMG_PEER_STATE_ACTIVE;
      }
      /* Start TTL expiry Timer */
      idx = MG_TTL_TMR - MG_PEER_TMR_BASE;
      mgStartTmr(MG_TTL_TMR, ttl, (PTR)peer, &(peer->mntInfo.tmr[idx]));
   }
#endif /* GCP_MGCP */

   /* If any messages are required to be sent, if this is a case of TCP
    * , TCP connection has to be established before any messages can be sent
    */

   if (cmLListLen(&(peer->transQ)) > MG_NONE)  
   {
#ifdef GCP_MGCO
#ifdef GCP_MG
      if ((peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO) &&
          (peer->accessInfo.transportType == LMG_TPT_TCP) &&
          (mgCb.genCfg.entType == LMG_ENT_GW))
      {
         CmTptAddr remAddr;
         MgTptSrvr *conn;
         MgSrvrInitInfo  info;

         info.transportType = LMG_TPT_TCP;
         info.srvrType      = MG_TCP_CLIENT_CONNECTION;
         info.encodingScheme = peer->mgcoInfo.encodingScheme;
#ifdef ZG
         info.suConnId = MG_INVALID_LSTNRID;
         info.peerId = peer->accessInfo.peerId;
#endif /* ZG */
         /* Initiate connection request to remote server */
         /* copy IPV4/IPV6 tpt address and port */

         MG_FILL_TPTADDR_FRM_NETADDR(&remAddr,
                         &(peer->accessInfo.peerAddrTbl.netAddr[0]));
         
         MG_FILL_TPTADDR_PORT(&remAddr, peer->accessInfo.remotePort);

         ret = mgAllocSrvrCb(&info, &remAddr, NULLP, peer->ssap, peer, 
                              (Ptr *)&conn, peer->tsap);
         if (ret != ROK)
         {
            if (peer->accessInfo.peerflg & MG_HANDOFF_RQSTD)
            {
               /* current MGC has requested Handoff */
               mgAbortHandOff(peer, LMG_CAUSE_RSRC_UNAVAIL);
               RETVOID;
            }
            else if (peer->accessInfo.peerflg & MG_REDIRECTED_BY_MGC)
            {
               /* MG was redirected by the MGC earlier */
               mgAbortRedirection(peer, LMG_CAUSE_RSRC_UNAVAIL);
               RETVOID;
            }
            else
            {
               mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED, 
                            LMG_CAUSE_RSRC_UNAVAIL, FALSE);
               RETVOID;
            }
         }
         peer->state = LMG_PEER_STATE_CONNECT;
#ifdef ZG
         /* Do add mapping for srvr and send update add to standby */
         ZG_INIT_RSETID_IN_MAPCB(&(conn->mapCb));
         zgAddMapping(ZG_CBTYPE_TPTSRVR,(Ptr)conn);
         zgRtUpd(ZG_CBTYPE_TPTSRVR,(Ptr)conn,CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_ADD);
#endif /* ZG */
         /* mg008.105: mgSrvConReq need to be call after PSF runtime update */
         mgSrvConReq(conn, &(peer->tsap->tsapCfg.reCfg.tptParam),
                     peer->tsap, &remAddr);
      }
#ifdef    GCP_PROV_SCTP
      else if ((peer->mntInfo.protocolType == LMG_PROTOCOL_MGCO) &&
          (peer->accessInfo.transportType == LMG_TPT_SCTP) &&
          (mgCb.genCfg.entType == LMG_ENT_GW))
      {
         MG_INIT_SCTP_ASSOC(peer,ret);

         peer->state = LMG_PEER_STATE_CONNECT;

         if (ret != ROK)
         {
            if (peer->accessInfo.peerflg & MG_HANDOFF_RQSTD)
            {
               /* current MGC has requested Handoff */
               mgAbortHandOff(peer, LMG_CAUSE_RSRC_UNAVAIL);
               RETVOID;
            }
            else if (peer->accessInfo.peerflg & MG_REDIRECTED_BY_MGC)
            {
               /* MG was redirected by the MGC earlier */
               mgAbortRedirection(peer, LMG_CAUSE_RSRC_UNAVAIL);
               RETVOID;
            }
            else
            {
               mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED, 
                            LMG_CAUSE_RSRC_UNAVAIL, FALSE);
               RETVOID;
            }
         }

      }
#endif    /* GCP_PROV_SCTP */
      else
#endif /* GCP_MG */
#endif /* GCP_MGCO */
      {
         if (peer->state == LMG_PEER_STATE_AWAIT_REG)
           peer->state = LMG_PEER_STATE_REGISTER;
         mgTxQueueMsg(peer);
      }
   }
#ifdef ZG
   /* send update for peer and ssap */
   zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
        CMPFTHA_ACTN_MOD);
   zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)peer->ssap,CMPFTHA_UPDTYPE_SYNC,
        CMPFTHA_ACTN_MOD);
#endif /* ZG */

   /* Send Status Indication to layer manager that gateway has come up */
   if (informLM == TRUE)
   {
      /* Use the MGCO specific macro */
      if (LMG_PROTOCOL_MGCO == peer->mntInfo.protocolType) 
      {
#ifdef GCP_MGCO
         MG_ISSUE_MGCOPEER_STAIND(peer, LCM_CATEGORY_INTERNAL, 
                   LMG_EVENT_PEER_ENABLED, LMG_CAUSE_MGMT_INITIATED);
#endif /* GCP_MGCO */
      }
      else
      {
#ifdef GCP_MGCP 
         MG_ISSUE_MGCPPEER_STAIND(peer, LCM_CATEGORY_INTERNAL, 
                   LMG_EVENT_PEER_ENABLED, LMG_CAUSE_MGMT_INITIATED);
#endif /* GCP_MGCP */
      }
   }

   RETVOID;

} /* end of mgRcvDnsRslvCfm() */

/*
*
*       Fun:    mgUpdatePeerIpAddr
*
*       Desc:   This function updates the IP Address Information of the Peer
*               based on new IP Address Information received from DNS
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_trans.c
*/
#ifdef ANSI
PUBLIC S16 mgUpdatePeerIpAddr
(
MgPeerCb           *peer,              /* Peer Control Block */
MgNetAddrTbl       *newAddrTbl         /* New Address Table */
)
#else
PUBLIC S16 mgUpdatePeerIpAddr(peer, newAddrTbl)
MgPeerCb           *peer;              /* Peer Control Block */
MgNetAddrTbl       *newAddrTbl;        /* New Address Table */
#endif
{
   U16             idx;                /* Index */
   CmNetAddr       *ipAddr;            /* IPV4/IPV6 Address */
   Bool            informLM;           /* Inform Layer Manager */
   S16             ret;                /* Return Value */
   U16             count;              /* Index */
   MgNetAddrTbl    prsntAddrTbl;       /* Already Existing Addresses */
   MgNetAddrTbl    finalLst;           /* Final Address List */
   CmNetAddr       *addr;              /* IPV4/IPV6 Address */
   MgIpAddrEnt     *ipAddrEnt;         /* IP Address Entry */
   U16             leftOvrIdx;         /* Left Over Numbers */
   U16             maxAddrs;           /* Maximum Address to copy */

   TRC2(mgUpdatePeerIpAddr)

   /* 
    * In case the protocol is MGCO, just copy all the IP addresses in the peer
    * CB. All the remaining code of this function holds only for MGCP
    * processing.
    */
#ifdef GCP_MGCO
   if(LMG_PROTOCOL_MGCO == peer->mntInfo.protocolType)
   {
      /* Copy new IP Address into Peer Control Block overwriting the previous
       * IP addresses */
      /* 
       * If Mid is not present in the peer, this means that this is a
       * temporary peer which was created at the time of handoff. Remove this
       * from domain name based list and add it into IP address list, else
       * simply return. If no IP address was found when MID is not present,
       * return failure.
       */
      if(peer->accessInfo.mid.pres == PRSNT_NODEF)
      {
          peer->accessInfo.peerAddrTbl.count = 0;
          for (idx = 0; idx < newAddrTbl->count; idx++)
          {
             cmMemcpy((U8 *) &(peer->accessInfo.peerAddrTbl.netAddr
                              [peer->accessInfo.peerAddrTbl.count++]),
               (CONSTANT U8 *)(&newAddrTbl->netAddr[idx]), sizeof(CmNetAddr));
          }
          RETVALUE(ROK);
      }
      else
      {
         if(newAddrTbl->count == 0)
         {
            RETVALUE(RFAILED);
         }
         else
         {
            /* 
             * Remove the entry from domain name list. Continue from here and
             * this peer will be inserted in IP address based list 
             */
            cmHashListDelete(&(mgCb.peerNameLst), (PTR)peer);
         }
      }
   }
#endif /* GCP_MGCO */

   prsntAddrTbl.count = 0;
   finalLst.count     = 0;
   informLM           = FALSE;
   /*
    * Identify the already present addresses into prsntAddrTbl and new ones
    * into finalLst. Also insert the new ones into IP Address hash list. The new
    * ones should always be given preference over old ones
    */
   for (idx = 0; idx < newAddrTbl->count; idx++)
   {
      ipAddr = &(newAddrTbl->netAddr[idx]);

      ret = mgFindIpAddrLst(ipAddr->type, &(ipAddr->u.ipv4NetAddr),
                            &(ipAddr->u.ipv6NetAddr), 
                            MG_HASH_SEQNMB_DEF, &ipAddrEnt);
      if (ret == ROK)
      {
         /* If the IP Address doesn't belong to same peer; discard that */
         if (ipAddrEnt->peer != peer)
         {
            continue;
         }

         /* IP Address found */
         cmMemcpy((U8 *) &(prsntAddrTbl.netAddr[prsntAddrTbl.count++]),
                  (CONSTANT U8 *)&(newAddrTbl->netAddr[idx]),sizeof(CmNetAddr));
         continue;
      }

      /* Address is not found - Allocate Address entry and add to database */
      ipAddrEnt = NULLP;

      if ((ipAddrEnt = (MgIpAddrEnt *)mgMalloc(sizeof(MgIpAddrEnt))) == NULLP)
      {
         informLM = TRUE;
         continue;
      }

      /* Initialise ip address entry */
      ipAddrEnt->peer = peer;

      cmMemcpy ((U8 *)&(ipAddrEnt->ipAddr), 
                (CONSTANT U8 *) &(newAddrTbl->netAddr[idx]), sizeof(CmNetAddr));

      /* Add the IP Address entry into Hash List */
      if (mgInsertIpAddrLst(ipAddrEnt) != ROK)
      {
         informLM = TRUE;
         mgDeAlloc((Data *)ipAddrEnt, sizeof(MgIpAddrEnt));
         continue;
      }

      /* Copy address as final list */
      cmMemcpy((U8 *)&(finalLst.netAddr[finalLst.count++]),
               (CONSTANT U8 *)&(newAddrTbl->netAddr[idx]), sizeof(CmNetAddr));
   }

   /*
    * New addresses have been identified; already present have been identified;
    * Identify the absent ones by comparing current addresses in peerAddrTbl
    * with the prsntAddrTbl; Delete the absent ones, carry over the present
    * ones to newAddrTbl; So at the end of next for loop, addresses are
    * present in newAddrTbl and finalLst and all of them are present in
    * hash lists
    */

   newAddrTbl->count = 0;

   for (idx = 0; idx < peer->accessInfo.peerAddrTbl.count; idx++)
   {
      ipAddr = &(peer->accessInfo.peerAddrTbl.netAddr[idx]);

      /* if the address is not in already present list...remove it */
      for (count = 0; count < prsntAddrTbl.count; count++)
      {
         addr = &(prsntAddrTbl.netAddr[count]);

         if ((cmMemcmp((U8 *)ipAddr, (CONSTANT U8 *) addr, 
                       sizeof(CmNetAddr))) == 0)
         {
            /* 
             * Copy into newAddrTbl instead of finalLst 
             * Address is there ..Add this address to newAddrTbl for keeps 
             */
            cmMemcpy((U8 *)&(newAddrTbl->netAddr[newAddrTbl->count++]),
                     (CONSTANT U8 *)&(peer->accessInfo.peerAddrTbl.netAddr[idx])
                     , sizeof(CmNetAddr));
            break;
         }
      }

      if (count >= prsntAddrTbl.count) 
      {
         /* 
          * An address is missing ... Delete the IP Address from Hash List 
          * and free Memory 
          */
         ipAddrEnt = NULLP;
         if (mgFindIpAddrLst(ipAddr->type, &(ipAddr->u.ipv4NetAddr),
                             &(ipAddr->u.ipv6NetAddr), MG_HASH_SEQNMB_DEF, 
                             &ipAddrEnt) != ROK)
         {
            /* LOG ERROR */
#if (ERRCLASS & ERRCLS_DEBUG)
            MGLOGERROR(ERRCLS_DEBUG, EMG207, 0,
                       "[MGCP] mgUpdatePeerIpAddr: Address Not Found \n");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
            continue;
         }

         /* Free Resources */
         mgDeleteIpAddrLst(ipAddrEnt);
         mgDeAlloc((Data *)ipAddrEnt, sizeof(MgIpAddrEnt));
      }

      ipAddr = NULLP;
      addr   = NULLP;
   }

   /*
    * Having come here implies, peerAddrTbl in peerCb is of no significance
    * as new addresses are in finalLst; already present addresses are in
    * newAddrTbl. And all entries in the tables are in IP Address hash list
    */

   /*
    * Now if finalLst.count is 0, implying no new addresses were found, then
    * 1. if newAddrTbl.count == peerAddrTbl.count; implies nothing changed 
    * 2. else, copy newAddrTbl into peerAddrTbl 
    */

   if (finalLst.count == 0)
   {
      if (peer->accessInfo.peerAddrTbl.count == newAddrTbl->count)
      {
         RETVALUE(ROK);
      }
      else
      {
         cmMemcpy((U8 *)&(peer->accessInfo.peerAddrTbl), 
                  (CONSTANT U8 *)(newAddrTbl), sizeof(MgNetAddrTbl));
         RETVALUE(ROK);
      }
   }


   /*
    * At this point, all valid addresses are present in finalLst and newAddrTbl
    * and all entries in them are in ip Address hash list. Now pool two tables
    * to the size of peerAddress Table and remove the extra ones. The addresses
    * in newAddrTbl should be pooled into finalLst and left over in newAddrTbl
    * should be discarded. Also, optimise for the case when this is first
    * resolution for the peer (i.e. peerAddrTbl->count = 0). Here everything
    * should be in finalLst and hence no pooling should occur
    */

   if (peer->accessInfo.peerAddrTbl.count > 0 && finalLst.count > 0)
   {
      /* 
       * Process only if this is not the first resolution
       * Calculate the number of addresses that can be copied into finalLst
       * from newAddrTbl
       */
      maxAddrs = (LMG_MAX_NET_ADDR - finalLst.count);

      for (leftOvrIdx = 0; leftOvrIdx < maxAddrs; leftOvrIdx++)
      {
        if (leftOvrIdx >= newAddrTbl->count)
          break;

        cmMemcpy((U8 *)&(finalLst.netAddr[finalLst.count++]),
                  (CONSTANT U8 *)&(newAddrTbl->netAddr[leftOvrIdx]), 
                  sizeof(CmNetAddr));
      }

      /* Remove the left over Addresses */
      for (idx = leftOvrIdx; idx < newAddrTbl->count; idx++)
      {
         ipAddr = &(newAddrTbl->netAddr[idx]);

         ipAddrEnt = NULLP;

         if (mgFindIpAddrLst(ipAddr->type, &(ipAddr->u.ipv4NetAddr),
                             &(ipAddr->u.ipv6NetAddr), MG_HASH_SEQNMB_DEF, 
                             &ipAddrEnt) != ROK)
         {
            /* LOG ERROR */
#if (ERRCLASS & ERRCLS_DEBUG)
            MGLOGERROR(ERRCLS_DEBUG, EMG208, 0,
                       "[MGCP] mgUpdatePeerIpAddr: Address Not Found \n");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
            continue;
         }

         /* Free Resources */
         mgDeleteIpAddrLst(ipAddrEnt);
         mgDeAlloc((Data *)ipAddrEnt, sizeof(MgIpAddrEnt));
         ipAddr = NULLP;
      }
   }

   /* Add the IP Addresses from Final List now to peer Address Table */
   if (finalLst.count > MG_NONE)
   {
      cmMemcpy((U8 *)&(peer->accessInfo.peerAddrTbl), (CONSTANT U8 *)&(finalLst)
               , sizeof(MgNetAddrTbl));
   }
   else
   {
      /* 
       * Implies no new addresses and none were present in hash list 
       */
      peer->accessInfo.peerAddrTbl.count = 0;
      RETVALUE(RFAILED);
   }

   if (informLM == TRUE)
   {
      /* Send Status Indication to the Layer Manager */
      MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_SMEM_ALLOC_FAIL, 
                             mgCb.init.region, mgCb.init.pool);
   }

   RETVALUE(ROK);

} /* end of mgUpdatePeerIpAddr () */



/*
*
*       Fun:    mgTxQueueMsg 
*
*       Desc:   This function transmits all messages in peer Queue
*
*       Ret:    None
*
*       Notes: None 
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC Void mgTxQueueMsg
(
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PUBLIC Void mgTxQueueMsg(peer)
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
   CmLList         *cmLstEnt;          /* Linked List Entry */
   MgTxTransIdEnt  *txCb;              /* Pending Transactions */
   MgTptSrvr       *tptSrvr;           /* Server */
   S16             msgType;            /* Message Type */
   CmTptAddr       *tptAddr;           /* Transport Address */
   U16             idx;                /* Index */
   Buffer          *mBuf;              /* Message Buffer */
   CmTptAddr       tAddr;              /* Transport Address */
   /* Added a new variable */
#ifdef ZG_DFTHA
   CmFthaRsetId     rsetId;            /* resource set id */   
   ZgRsetCb         *rsetCb;           /* resource set control block */   
#endif /* ZG_DFTHA */


   TRC2(mgTxQueueMsg)
  
   /* 
    * Go through the list of pending transactions - if transaction is 
    * in NULL state, transmit it after taking timestamp; If Transaction
    * is in refresh state, then try to locate a new IP Address for 
    * transaction or if no new IP address has been found, use the most 
    * recent one used and retransmit the transaction
    */
   cmLstEnt = peer->transQ.first;
   tptAddr  = NULLP;

   while (cmLstEnt != NULLP)
   {
      txCb      = NULLP;
      tptSrvr = NULLP;

      if (*((U8 *)(cmLstEnt->node)) == MG_OUTTXN_TXN_SENT)
      {
         txCb = (MgTxTransIdEnt *)cmLstEnt->node;
         msgType = txCb->msgType;
#ifdef ZG_DFTHA
         rsetId = txCb->mapCb.rsetId;
#endif /* ZG_DFTHA */
      }

      /* Move to next entry */
      cmLstEnt = cmLstEnt->next;

#ifdef ZG_DFTHA
      /* Check if NonCritical rSet is active..if yes, then transmit it */
      rsetCb = NULLP;
      if ((rsetCb = zgGetRsetCb(rsetId)) == NULLP)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         MGLOGERROR(ERRCLS_DEBUG, EMG209, (ErrVal)rsetId,
                  "mgTxQueueMsg: PSF Rset is not configured");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         continue;
      }
      /* Check if the identified resource set is active on the current node */
      if (rsetCb->sta.state != CMPFTHA_STATE_ACTIVE) 
      {
         continue;
      }

#endif /* ZG_DFTHA */

      if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
      {
#ifdef GCP_MGCP
         tptSrvr = mgGetLstnrForTx(peer->ssap, peer->tsap,
                                   peer->mntInfo.protocolType);

         if (tptSrvr == NULLP)
         {
            if (txCb != NULLP)
            {
               mgAbortTxTrans (peer, txCb, MGT_ERR_RSRC_UNAVAIL);
            }
            continue;
         }

         /* Take time-stamp if this is a new transaction */
         if (txCb->state == MG_OUTTXN_TXN_QUEUED)
         {
            S16     ret;

            SGetSysTime(&(txCb->timeStamp));

            /* Obtain an address for transmission */
            ret = mgGetIpAddrForTx (txCb, peer);

            if (ret != RFAILED)
            {
               txCb->state   = MG_OUTTXN_TXN_SENT;

               if (ret == ROK)
               {
                 txCb->retxCnt = 0;
               }
               else /* It is ROKDNA */
                  txCb->retxCnt++;
            }
            else
            {
               mgAbortTxTrans (peer, txCb, MGT_ERR_RSRC_UNAVAIL);
               continue;
            }
         }
         else
         {
            /* Try Locating a new IP Address for transmission */
            if ((mgGetIpAddrForTx (txCb, peer)) != ROK)
            {
               /* 
               * No new IP address ..retransmit to old IP Address 
               * Increment the retransmission count
               */
               txCb->retxCnt++;
               /* 
                * AAD for the peer should not be updated for
                * retransmissions since the acknowledgement delay for a
                * retransmitted command cannot be calculated deterministically.
                * The ack may have been sent in response to the first time
                * transmission or the retransmission.
                * The retransmission timer should be calculated by
                * doubling the value of AAD for the transaction to be
                * retransmitted. 
                */
               MG_UPDATE_RTO_PARMS_ON_RETX(txCb->aad, peer->mntInfo.adev,
                                           txCb->rto,
                                           peer->tsap->tsapCfg.reCfg.tMax);
            }
            else
            {
               /* New IP Address found...reset retransmission count */
               txCb->retxCnt = 0;
            }
         }
            /* Remove the transaction from the list */
         cmLListDelFrm(&(peer->transQ), &(txCb->lnkLstNode));

         /* Update the transaction state */
         txCb->state = MG_OUTTXN_TXN_SENT;

         /* Prepare for transmission .....copy transport information */
         tptAddr                     = &tAddr;                       
         idx                         = txCb->addrTbl.count;

         /* copy IPV4/IPV6 tpt address */
         MG_FILL_TPTADDR_FRM_NETADDR(tptAddr, 
                                     &(txCb->addrTbl.netAddr[idx-1]));
         MG_FILL_TPTADDR_PORT(tptAddr, peer->accessInfo.remotePort);

         /* Start the retransmission timer */
         /* rto is in ticks. convert to multiples of timeRes */
         /* timer val needs to be taken from txCb if the
          * transaction is to be retransmitted */
         if (txCb->everRetxed == TRUE)
         {
            mgStartTmr (MG_RETX_TMR, 
                       (txCb->rto/mgCb.genCfg.timeRes), 
                       (PTR) txCb, &(txCb->retxTmr));
         }
         else
         {
            mgStartTmr (MG_RETX_TMR, 
                        (peer->mntInfo.rto/mgCb.genCfg.timeRes), 
                        (PTR) txCb, &(txCb->retxTmr));
         }

         /* Create a copy of mBuf for transmission */

#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
         if ((SAddMsgRef (txCb->u.txBufInfo->mBuf, 
                          peer->tsap->tsapCfg.memId.region,
                          peer->tsap->tsapCfg.memId.pool, 
                          &mBuf)) != ROK)
#else
         if ((SAddMsgRef (txCb->u.mBuf, peer->tsap->tsapCfg.memId.region,
                          peer->tsap->tsapCfg.memId.pool, 
                          &mBuf)) != ROK)
               /* copy IPV4/IPV6 tpt address */
               MG_FILL_TPTADDR_FRM_NETADDR(tptAddr, 
                                           &(txCb->addrTbl.netAddr[idx-1]));
               MG_FILL_TPTADDR_PORT(tptAddr, peer->accessInfo.remotePort);


#endif /* GCP_VER_1_3 && GCP_2705BIS */
         {
            mBuf      = NULLP;
         }
#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
#ifndef GCP_USER_RETX_CNTRL
         /* 
          * start disconnect timer..time out period as twice of txn 
          * timeout period..this timer will be stopped when response is 
          * received from peer. 
          */
         if(peer->ssap->ssapCfg.reCfg.txnTmoutTmr.enb == TRUE)
         {
            /* This timer is not required for NCS/TGCP */
            if(peer->mntInfo.variant == LMG_VER_PROF_MGCP_RFC2705_1_0)
            {
               if(txCb->discTmr.tmrEvnt == TMR_NONE)
               {
                  (Void) mgStartTmr (MG_TXN_DISC_TMR, 
                        (2 * peer->ssap->ssapCfg.reCfg.txnTmoutTmr.val), 
                           (PTR) txCb, &(txCb->discTmr));
               }
            }
         }
#endif /* ! GCP_USER_RETX_CNTRL */
#endif /* GCP_2705BIS */
#endif /* GCP_VER_1_3 */
#endif /* GCP_MGCP */
      } /* MGCP */
      else 
      {
#ifdef GCP_MGCO
         /* For commands, use sockets in a round-robin fashion */
         tptSrvr = NULLP;

#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
         if ((peer->accessInfo.transportType != LMG_TPT_SCTP) &&
               (peer->accessInfo.transportType != LMG_TPT_MTP3))
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
            if ((tptSrvr = mgGetSendSrvr(peer->ssap, peer)) == NULLP)
            {
               continue;
            }

         /* Take time-stamp if this is a new transaction */
         if (txCb->state == MG_OUTTXN_TXN_QUEUED)
         {
            SGetSysTime(&(txCb->timeStamp));

            /* Copy the peer IP address from peer */
            cmMemcpy((U8 *)&(txCb->addrTbl.netAddr[0]), 
                  (CONSTANT U8 *) &(peer->accessInfo.peerAddrTbl.netAddr[0]),
                  sizeof(CmNetAddr));
            txCb->addrTbl.count = 1;
            txCb->retxCnt = 0;
            txCb->state = MG_OUTTXN_TXN_SENT;                                
            /* Start the retransmission timer */     
            /* rto is in ticks. convert to multiples of timeRes */
            mgStartTmr (MG_RETX_TMR,(peer->mntInfo.rto/mgCb.genCfg.timeRes),
                        (PTR) txCb, &(txCb->retxTmr));                       
         }
         else
         {
            txCb->retxCnt++;
            /* Start the retransmission timer */
            /* rto is in ticks. convert to multiples of timeRes */
            MG_UPDATE_RTO_PARMS_ON_RETX(txCb->aad, peer->mntInfo.adev,
                                        txCb->rto,
                                        peer->tsap->tsapCfg.reCfg.tMax);
            mgStartTmr (MG_RETX_TMR, (peer->mntInfo.rto/mgCb.genCfg.timeRes), 
                        (PTR) txCb, &(txCb->retxTmr));
         }
         /* Remove the transaction from the list */
         cmLListDelFrm(&(peer->transQ), &(txCb->lnkLstNode));

         /* Update the transaction state */
         txCb->state = MG_OUTTXN_TXN_SENT;

         if (tptSrvr)
            txCb->suConnId = tptSrvr->suConnId;

         /* Prepare for transmission .....copy transport information */
         if ((tptSrvr) && (tptSrvr->transportType == LMG_TPT_UDP))
         {
            tptAddr                     = &tAddr;                       
            idx                         = 0;

            /* copy IPV4/IPV6 tpt address */
            MG_FILL_TPTADDR_FRM_NETADDR(tptAddr,
                                        &(txCb->addrTbl.netAddr[idx]));
            MG_FILL_TPTADDR_PORT(tptAddr, peer->accessInfo.remotePort);
         }

         /* Create a copy of mBuf for transmission */
         if ((SAddMsgRef (txCb->u.mBuf, peer->tsap->tsapCfg.memId.region,
                           peer->tsap->tsapCfg.memId.pool, &mBuf)) != ROK)
         {
            mBuf      = NULLP;
         }
#endif /* GCP_MGCO */
      } /* MEGACO */

      /* mg008.105: runtime update need to be generate before generate any
       * lower/upper layer primitive */
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
      if(txCb != NULLP)
      {
         zgRtUpd(ZG_CBTYPE_TXN_TX,(Ptr)txCb,CMPFTHA_UPDTYPE_NORMAL,
            CMPFTHA_ACTN_MOD);
      }
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */

      /* Transmit the transaction */
      if (mBuf != NULLP)
      {
         /* Update Statistics */
         if (peer->mntInfo.protocolType == LMG_PROTOCOL_MGCP)
         {
#ifdef GCP_MGCP
            MG_UPD_MGCP_PEER_TX_STS(msgType, peer->peerSts);
#endif /* GCP_MGCP */
         }
         else
         {
#ifdef GCP_MGCO
            MG_UPD_MGCO_PEER_TX_STS(msgType, peer->peerSts);
#endif /* GCP_MGCO */
         }

         /* Transmit Transaction */
#ifdef    GCP_PROV_MTP3
      if (peer->accessInfo.transportType == LMG_TPT_MTP3)
         mgMtpDatReq(peer, NULLD ,NULLD ,peer->tsap,mBuf);
                 
    else
#endif    /* GCP_PROV_MTP3 */


#ifdef   GCP_PROV_SCTP
         if (peer->accessInfo.transportType != LMG_TPT_SCTP)
#endif   /* GCP_PROV_SCTP */
            mgSrvDatReq(tptSrvr, tptAddr, mBuf);
#ifdef   GCP_PROV_SCTP
         else
         {
            SctStrmId      strm;
            TknU32         ctxId;

            /*
             *   Since we do NOT have the MgcoMsg event structures
             *   corresponding to each txn in the queue, we shall
             *   use the round-robin mechanism to determine the
             *   stream-Ids - this way there shall be even more
             *   load sharing on the streams. Anyways, most likely
             *   the different txns in the Q would be related to
             *   different contexts.
             *
             *   We wud be using ordered delivery so as not to
             *   interfere with the intended order of commands.
             */
            /* mg002.105: remove compilation warning*/
            ctxId.pres = NOTPRSNT;
            ctxId.val    = 0;

            MG_MGCO_GET_STRMID_FRM_CTXID(strm,(&ctxId),(peer->assocCb));

            MG_TRANSMIT_PDU(peer, peer->assocCb,
                            strm, FALSE, tptSrvr,
                            tptAddr, mBuf);
         }
#endif   /* GCP_PROV_SCTP */

      }

   } /* end of while loop */

} /* end of mgTxQueueMsg () */

#ifdef GCP_MGCO
/*
*
*       Fun:    mgProcessSrvcChng 
*
*       Desc:   This function processes the service change message from the peer
*               This function is only required in case of MEGACO. 
*
*       Ret:    ROK - SUCCESS
*               RFAILED - FAILURE
*               ROKDNA - txn will be queued.
*
*       Notes:  None
*
*       File:   mg_peer.c
*/

#if    (defined(GCP_PROV_SCTP)  || defined(GCP_PROV_MTP3))

#ifdef ANSI
PUBLIC S16 mgProcessSrvcChng
(
S16                *errAction,         /* Action to be taken on error */
S16                *rspCode,           /* Response code */
TknStrOSXL         *msgMid,            /* mid in MEGACO message*/
MgMgcoVersion      *msgVer,            /* version in MEGACO message*/
MgSvcChgInfo       *svcChg,            /* Service change or reply Information */
MgPeerCb           **peerCb,           /* Peer Control block */
MgTSAPCb           *tsap,              /* TSAP Control Block */
MgcoTptInfo        *mgcoTptInfo,         /* Megaco Transport Information */
MgTptSrvr          *srvr,              /* Server Control Block */
CmTptAddr          *srcTptAddr,        /* Source Transport Address */
MgTransId          transId,            /* Transaction Id */
Bool               crtRxCb,             /* whether to create rxCb */
MgMgcoTxn          *mgcoTxn             /* whether to create rxCb */
)
#else
PUBLIC S16 mgProcessSrvcChng(errAction, rspCode, msgMid, msgVer, svcChg, peerCb,
                             tsap, mgcoTptInfo, srvr, srcTptAddr, transId, crtRxCb,mgcoTxn)
S16                *errAction;         /* Action to be taken on error */
S16                *rspCode;           /* Response code */
TknStrOSXL         *msgMid;            /* mid in MEGACO message*/
MgMgcoVersion      *msgVer;            /* version in MEGACO message*/
MgSvcChgInfo       *svcChg;            /* Service change or reply Information */
MgPeerCb           **peerCb;           /* Peer Control block */
MgTSAPCb           *tsap;              /* TSAP Control Block */
MgcoTptInfo        *mgcoTptInfo;         /* Megaco Transport Information */
MgTptSrvr          *srvr;              /* Server Control Block */
CmTptAddr          *srcTptAddr;        /* Source Transport Address */
MgTransId          transId;            /* Transaction Id */
Bool               crtRxCb;            /* whether to create rxCb */
MgMgcoTxn          *mgcoTxn;            /* whether to create rxCb */
#endif

#else     /* GCP_PROV_SCTP || GCP_PROC_MTP3 */

#ifdef ANSI
PUBLIC S16 mgProcessSrvcChng
(
S16                *errAction,         /* Action to be taken on error */
S16                *rspCode,           /* Response code */
TknStrOSXL         *msgMid,            /* mid in MEGACO message*/
MgMgcoVersion      *msgVer,            /* version in MEGACO message*/
MgSvcChgInfo       *svcChg,            /* Service change or reply Information */
MgPeerCb           **peerCb,           /* Peer Control block */
MgTSAPCb           *tsap,              /* TSAP Control Block */
MgTptSrvr          *srvr,              /* Server Control Block */
CmTptAddr          *srcTptAddr,        /* Source Transport Address */
MgTransId          transId,            /* Transaction Id */
Bool               crtRxCb,             /* whether to create rxCb */
MgMgcoTxn          *mgcoTxn
)
#else
PUBLIC S16 mgProcessSrvcChng(errAction, rspCode, msgMid, msgVer, svcChg,
                           peerCb, tsap, srvr, srcTptAddr, transId, crtRxCb,mgcoTxn)
S16                *errAction;         /* Action to be taken on error */
S16                *rspCode;           /* Response code */
TknStrOSXL         *msgMid;            /* mid in MEGACO message*/
MgMgcoVersion      *msgVer;            /* version in MEGACO message*/
MgSvcChgInfo       *svcChg;            /* Service change or reply Information */
MgPeerCb           **peerCb;           /* Peer Control block */
MgTSAPCb           *tsap;              /* TSAP Control Block */
MgTptSrvr          *srvr;              /* Server Control Block */
CmTptAddr          *srcTptAddr;        /* Source Transport Address */
MgTransId          transId;            /* Transaction Id */
Bool               crtRxCb;            /* whether to create rxCb */
MgMgcoTxn            *mgcoTxn;            /* whether to create rxCb */
#endif

#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
{
   U8              method;              /* Method for service change */
   MgPeerCb        *peer;               /* Peer control block */
   MgPeerInitInfo  init;                /* Peer initialisation structure */
   MgSSAPCb        *ssap;               /* SAP Control block */
   MgRxTransIdEnt  *rxCb;               /* Incoming Transaction Control Block */
   Bool            dupFlag;             /* Duplicate Flag */
#ifdef GCP_MGC
   CmNetAddr       tmpAddr;             /* IP addr to check duplicate entry */
#endif /* GCP_MGC */

#ifdef GCP_MG
   /* Add a new local variable */
   Bool            newPeerAllocated = FALSE; /* indicates if a new peer
                                            control block has been allocated */
   MgPeerCb        *newPeer = NULLP;    /* New Peer Control Block */
#endif /* GCP_MG */

#ifdef GCP_MGC
   Bool            dupl;                /* Duplicate ? */
   CmNetAddr       address;             /* IP Address */
   S32             remotePort;
   MgNetAddrTbl    addrTbl;             /* Network Addresses of the Peer */
#endif /* GCP_MGC */

#ifdef   GCP_PROV_SCTP 
   MgAssocCb       *assoc = NULLP;     /* Association Control Block as passed in mgcoTptInfo */
#endif   /* GCP_PROV_SCTP */
#ifdef   GCP_PROV_MTP3
   Dpc             peerDpc = NULLD;     /* Peer DPC as passed in MgcoTptInfo */
   Dpc             newDpc = NULLD;     /* Peer DPC as passed in MgcoTptInfo */
#endif   /* GCP_PROV_MTP3 */




   TRC2(mgProcessSrvcChng)


   /*
    * Initilize all local variables
    */
   cmMemset((U8*)&init, 0, sizeof(MgPeerInitInfo));
   ssap    = NULLP;
   rxCb    = NULLP;
#ifdef GCP_MG
   newPeer = NULLP;
#endif /* GCP_MG */

   /* 
    * Code added to pass multiple trasport parameter and then make each 
    * transport available in an
    * local copy of its transport variable 
    */
#if   (defined(GCP_PROV_SCTP) | defined(GCP_PROV_MTP3))
   if(mgcoTptInfo != NULLP)
   {
#ifdef   GCP_PROV_SCTP
      if(mgcoTptInfo->tptType == LMG_TPT_SCTP)
         assoc = mgcoTptInfo->u.assocCb;
#endif   /* GCP_PROV_SCTP */    

#ifdef   GCP_PROV_MTP3
      if (mgcoTptInfo->tptType == LMG_TPT_MTP3) 
         peerDpc  = mgcoTptInfo->u.mgMtpInfo.clgAddr;
#endif   /* GCP_PROV_MTP3 */         
    }     
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
 


   peer = *peerCb;
   /* extract the method */
   if ((svcChg->u.svcChgReq->pres.pres == PRSNT_NODEF) &&
       (svcChg->u.svcChgReq->parm.pres.pres == PRSNT_NODEF) &&
       (svcChg->u.svcChgReq->parm.meth.pres.pres == PRSNT_NODEF))
   {
      /* method present */
      if (svcChg->u.svcChgReq->parm.meth.type.pres == PRSNT_NODEF)
         method = svcChg->u.svcChgReq->parm.meth.type.val;
      else
         /* non-standard method is available, don't process it
          * but pass it to service user as we cannot interpret it */
         RETVALUE(ROK);
   } /* method present */
   else
      /* method not available : decoder error */
   {
      *errAction = MG_DISCARD_MSG;
      *rspCode   = MGT_MGCO_RSP_CODE_BAD_REQ;  /* code changed */
      RETVALUE(RFAILED);
   }

   if (mgCb.genCfg.entType == LMG_ENT_GC)
   {
      /* layer is acting as MGC */
#ifdef GCP_MGC
      if (peer == NULLP)
      {
#ifdef ZG_DFTHA
         if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
         {
            /*  if peer is still not identified, method has to be either
             *
             *  1. RESTART                
             *  2. FAILOVER : MGC Impending Failure
             *  3. HANDOFF  : MGC directed change 
             *  Should we check for reason field as well 
             *
             */
            if (((method == MGT_SVCCHGMETH_RESTART) ||
                 (method == MGT_SVCCHGMETH_FAILOVER) ||
                 (method == MGT_SVCCHGMETH_DISCON) ||
                 (method == MGT_SVCCHGMETH_HANDOFF)) &&
                (
#ifdef    GCP_PROV_MTP3
                (peerDpc) ||
#endif    /* GCP_PROV_MTP3 */                
#ifdef    GCP_PROV_SCTP
                (assoc) ||
#endif  /* GCP_PROV_SCTP */
                  ((srvr) &&
                   ((srvr->srvrType == MG_TCP_CLIENT_CONNECTION) ||
                    (srvr->srvrType == MG_MGCO_DEFLT_SRVR)))))
            {
               /* 
                *   create a new peer; find a suitable SSAP for this peer 
                *   We assume that service change was received on a
                *   default listener.
                *   if round robin for this listener is disabled i.e. it is 
                *   attached to an SSAP then give the service change on that
                *   SSAP else use round-robin methodology to obtain an SSAP
                */
                if (

#ifdef    GCP_PROV_MTP3
                   (peerDpc) ||
#endif    /* GCP_PROV_MTP3 */               
#ifdef    GCP_PROV_SCTP
                   (assoc) ||
#endif    /* GCP_PROV_SCTP */
                   ((srvr) && (srvr->t.ssap == NULLP)))
                {
                     ssap = (mgCb.sSAPLst[mgCb.nxtMgcoSsapId]);
                }
               else 
               {
                     ssap = srvr->t.ssap;
               }

               /* Check if we have resources to allocate in our layer */
               if (mgAdmitTxn(ssap, tsap) != ROK)
               {
                  *errAction = MG_DISCARD_MSG;
                  *rspCode   = MGT_MGCO_RSP_CODE_RSRC_ERROR;
                  RETVALUE(RFAILED);
               }

               /* Initialise peerInit structure */
               init.name[0] = '\0';
               init.addrTbl.count = 0;
#ifdef ZG
               init.peerId = MG_INVALID_PEERID;
               init.mtdPeerId = MG_INVALID_PEERID;
#ifdef ZG_DFTHA
               init.suConnId = srvr->suRsetId;
#endif /* ZG_DFTHA */
#endif /* ZG */

               /*
                * For UDP, initialise remote port as the port number
                * from where the serviceChange message has been received,
                * copied from source transport address. This will ensure
                * that all future commands from this MGC are send to
                * this port number, which may be different from the
                * default port. In case, a serviceChangeAddress
                * is received with a different port number, this will get 
                * over-ridden.
                */
               /*
                * For MTP3 TSAP Copy the peerDpc and tsap info to peerInfo structure
                */
#ifdef    GCP_PROV_MTP3      
               if(tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3)
               {
                  /* Copy the Peer Point Code in the Init Structure */
                  init.peerDpc = peerDpc;
                  /* Copy the  Tsap also as it will be used for tsapCfg and
                   * to Locate Hash List */
                  init.tsap   = tsap; 
               }
               else
#endif    /* GCP_PROV_MTP3 */

#ifdef    GCP_PROV_SCTP
               if (assoc && (assoc->assocCfg))
               {
                  init.assocCfg   = *(assoc->assocCfg);
                  init.allocAssocCfg = FALSE;
                  init.remotePort = assoc->assocCfg->remPort;
               }
               else   /* do NOT delete this comment */
#endif    /* GCP_PROV_SCTP */
               if (srvr->srvrType != MG_TCP_CLIENT_CONNECTION)
               {
                  MG_FILL_PORT_FRM_TPTADDR(init.remotePort,srcTptAddr);
               }
               else
                  init.remotePort = LMG_INVALID_PEER_PORT;

               /* 
                * If SVC addr is present, fill MgPeerInitInfo directly
                * from svcAddr field, rather than calling mgCnvrtMID and going
                * through it.
                */
               if (svcChg->u.svcChgReq->parm.addr.type.pres == PRSNT_NODEF)
               {
                  MgMgcoMid *mid;

                  mid = &(svcChg->u.svcChgReq->parm.addr);
                  if (svcChg->u.svcChgReq->parm.addr.type.val == MGT_MID_PORT)
                  {
                     init.remotePort = mid->u.port.val;
                  }
                  else 
                  if (svcChg->u.svcChgReq->parm.addr.type.val == 
                                                            MGT_MID_DADDRPORT)
                  {
                     S16               ret;
                     MgMgcoDomAddrPort *dAP = &(mid->u.dAddrPort);

                     ret = mgGetIpAddrFromDomainNameStr(dAP->u.ipv4.len, 
                                                        dAP->u.ipv4.val, 
                                                        &(address),
                                                        LMG_PROTOCOL_MGCO);

                     if (ret == ROK)
                     {
                        /* Always put this IP address as first entry */
                        init.addrTbl.netAddr[init.addrTbl.count].type
                                       = address.type;
                        
                        cmMemcpy((U8 *)(&(init.addrTbl.netAddr\
                                          [init.addrTbl.count++])),
                                 (U8*) &(address), sizeof (CmNetAddr));

                        if (PRSNT_NODEF == dAP->port.pres)
                           init.remotePort = dAP->port.val;
                        else
                           init.remotePort = LMG_INVALID_PEER_PORT;
                     }
                  }
                  else 
                  if (svcChg->u.svcChgReq->parm.addr.type.val == 
                           MGT_MID_DNAMEPORT)
                  {
                     /* This should not be used by peer */
                     cmMemcpy((U8 *)init.name, (U8 *)mid->u.dNamePort.name.val, 
                              CM_DNS_DNAME_LEN);
                     if (PRSNT_NODEF == mid->u.dNamePort.port.pres)
                        init.remotePort = mid->u.dNamePort.port.val;
                     else 
                        init.remotePort = LMG_INVALID_PEER_PORT;
                  }
#ifdef   GCP_PROV_MTP3                  
                 else 
                  {
                       MG_FILL_MTP_DPC_FRM_MID_TEXT(mid,init.peerDpc);
                  }
#endif    /* GCP_PROV_MTP3 */                  
               } /* service change address present */



               /* 
                * MID is a string. Just copy the MID of the peer in
                * MgPeerInitInfo.
                */

               /* Copy MID of peer */
               init.mid.pres = msgMid->pres;
               init.mid.len = msgMid->len;
               cmMemcpy(init.mid.val, msgMid->val, msgMid->len);

#ifdef   GCP_PROV_MTP3
               if(tsap->tsapCfg.provType != LMG_PROV_TYPE_MTP3)
               {
#endif   /* GCP_PROV_MTP3 */
               /* if mId is anything else , copy address from remote address */
               MG_FILL_NETADDR_FRM_TPTADDR(&tmpAddr, srcTptAddr);
               MG_CHK_DUPL_ADDR(init.addrTbl, &tmpAddr, dupl);
               if (dupl == FALSE)
               {
                  MG_FILL_NETADDR_FRM_TPTADDR(&(init.addrTbl.netAddr\
                                                [init.addrTbl.count]),
                                              srcTptAddr);
                  init.addrTbl.count++;
               }

#ifdef   GCP_PROV_MTP3
               }
#endif   /* GCP_PROV_MTP3 */
               

#ifdef    GCP_PROV_SCTP
               if (srvr)
                  init.transportType     = srvr->transportType;
               else
                  init.transportType     = LMG_TPT_SCTP; /*  new define */
#endif     /* GCP_PROV_SCTP */
#ifdef   GCP_PROV_MTP3               
               if (srvr)
#endif   /* GCP_PROV_MTP3 */ 
#ifndef GCP_PROV_SCTP                  
                  init.transportType     = srvr->transportType;
#endif

#ifdef    GCP_PROV_MTP3               
               if(tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3)
                  init.transportType     = LMG_TPT_MTP3; /*  new define */
#endif     /* GCP_PROV_MTP3 */




               init.protocolType      = LMG_PROTOCOL_MGCO;
               /* Initialize variant to LMG_VER_PROF_MGCO_H248_1_0
                *            rather than 0 for MEGACO. */
               init.variant           = LMG_VER_PROF_MGCO_H248_1_0;


#ifdef    GCP_PROV_MTP3               
               if(tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3)
               {
                  init.encodingScheme = mgcoTptInfo->encodingScheme;
               }
               else
#endif     /* GCP_PROV_MTP3 */
               if (srvr)
                  init.encodingScheme    = srvr->encodingScheme;
#ifdef    GCP_PROV_SCTP
               else
                  /*
                   *  shd it be
                   * assoc->tsap->endpCb.endpCfg.encodingScheme?
                   */
                  init.encodingScheme    = assoc->tsap->endpCb.encodingScheme;
#endif    /* GCP_PROV_SCTP */
               init.useAHScheme       = 0;
 

               /* Check for version negotiation */
               if (svcChg->u.svcChgReq->parm.ver.pres == PRSNT_NODEF)
               {
                  init.mgcoVersion = 
                     (svcChg->u.svcChgReq->parm.ver.val) | LMG_GET_MGCO_LMG_VER;
               }
               else if (msgVer->pres == PRSNT_NODEF)
                  init.mgcoVersion = (msgVer->val) | LMG_GET_MGCO_LMG_VER;

               if (ssap->ssapCfg.reCfg.initRetxTmr.enb == TRUE)
               {
                  init.initRtt = ssap->ssapCfg.reCfg.initRetxTmr.val;
               }
               else
                  init.initRtt = (MG_INIT_RTT_VALUE * mgCb.genCfg.timeRes);

               init.trcLen            = MG_DEFAULT_TRC_LEN;

               init.mtuSize           =
                       (init.transportType == LMG_TPT_UDP) ?
                       MG_MAX_UDP_MTU_SIZE : MG_MAX_TCP_MTU_SIZE;

               init.priority          = 0;
               init.byCfg             = FALSE;



#ifdef    GCP_PROV_SCTP
               {
                  U16      indx;

                  /*
                   * The following fields were copied from the original
                   * peer above -
                   *
                   * init.assocCfg.locOutStrms
                   *
                   * cmMemset((U8 *)&(init.assocCfg.srcAddrLst),
                   *          0, sizeof(SctNetAddrLst));
                   *
                   * So there is no need to fill them again;
                   *
                   * The only relevant fields which might have changed
                   * are the dstAddr(Lst) & the remotePort;
                   *
                   */

                  init.assocCfg.priDstAddr = init.addrTbl.netAddr[0];

                  /* mg002.105: remove compilation warning*/
                  init.assocCfg.dstAddrLst.nmb = (U8)init.addrTbl.count;

                  for (indx = 0; indx < init.addrTbl.count; ++indx)
                  {
                     init.assocCfg.dstAddrLst.nAddr[indx]
                        = init.addrTbl.netAddr[indx];
                  }

                  init.assocCfg.remPort
                       = (init.remotePort == -1) ?
                         MG_MGCO_DEFAULT_TEXT_PORT : (init.remotePort);
               }
#endif    /* GCP_PROV_SCTP */

               peer = mgAllocPeerCb(ssap, &init);
               if (peer == NULLP)
               {
                  *errAction = MG_DISCARD_MSG;
                  *rspCode   = MGT_MGCO_RSP_CODE_RSRC_ERROR;
                  RETVALUE(RFAILED);
               }

               /*
                *  Set the peer pointer to be returned for calling function
                */
               *peerCb = peer;


               /*
                *  Initialize the tsap field of peer - Discovered Peer
                */
               peer->tsap = tsap;
#ifdef GCP_VER_1_5
               /* As per Service Negotiation procedure of Version 2 first */
               /* Service change message should contain message version 1.*/
               /* True for handoff and failure cases also. Refer Section  */
               /* 11.3. Assuming ssapCfg.minMgcoVersion is set as 1.0.    */
               if ( (msgVer->pres == PRSNT_NODEF) && 
                    (msgVer->val != ssap->ssapCfg.minMgcoVersion) ) 
               {
                  *errAction = MG_DISCARD_MSG;                                     
                  *rspCode = MGT_MGCO_RSP_CODE_VERSION_UNSUPP;                    
                  RETVALUE(RFAILED);
               }

               if(ROK!= mgVerifyVersion(mgcoTxn ,ssap))
               {
                  *errAction = MG_DISCARD_MSG;                                     
                  *rspCode = MGT_MGCO_RSP_CODE_VERSION_UNSUPP;                    
                  RETVALUE(RFAILED);
               }
#endif /* GCP_VER_1_5 */
               /* Negotiate for version in Service change or message header */
               MG_NEGOTIATE_VERSION_MGC_SIDE(init.mgcoVersion, ssap->ssapCfg,
                                             peer, errAction, rspCode)

               /* 
                * if this peer is created on a service change received on a TCP
                * client connection, add this connection to peerLst 
                */
               if ((srvr) &&
                   (srvr->srvrType == MG_TCP_CLIENT_CONNECTION) &&
                   (srvr->t.peer == NULLP))
               {
                  srvr->t.peer = peer;
                  srvr->lstnrNode.node = (PTR)srvr;
                  cmLListAdd2Tail (&(peer->mgcoInfo.tcpConnLst),
                                 &(srvr->lstnrNode));
                  peer->mgcoInfo.numActvConn++;
                  if (peer->mgcoInfo.nxtUseConn == NULLP)
                     peer->mgcoInfo.nxtUseConn = srvr;
                  if (srvr->idleTmr.tmrEvnt == MG_IDLE_CONN_TMR)
                  {
                     mgStopTmr(MG_IDLE_CONN_TMR, (PTR)srvr,
                              &(srvr->idleTmr));
                  }
               }
#ifdef    GCP_PROV_SCTP
               else if ((assoc) && (assoc->peer == NULLP))
               {
                  assoc->peer = peer;  /*  link peer->assocCfg below */
                  peer->assocCb = assoc;
                  if((assoc->assocCfg) && (peer->assocCfg == NULLP))
                     peer->assocCfg = assoc->assocCfg;
               }
#endif    /* GCP_PROV_SCTP */


               if (srvr)
               {
                  MG_FILL_PORT_FRM_TPTADDR(peer->mgcoInfo.origSrvcChngPort,
                                           &(srvr->tptAddr));
               }
#ifdef    GCP_PROV_SCTP
               else
               {
                  if (assoc->assocCfg)
                     peer->mgcoInfo.origSrvcChngPort
                          = assoc->assocCfg->remPort;
               }
#endif    /* GCP_PROV_SCTP */


               
#ifdef ZG
               ZG_INIT_RSETID_IN_MAPCB(&(peer->mapCb));
               zgAddMapping(ZG_CBTYPE_PEER,(Ptr)peer);
               zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_ADD);
               zgUpdPeer();
#endif /* ZG */
               if(crtRxCb == TRUE)
               {
                  /* Create a record of incoming transaction */
                  rxCb = mgPrcIncomingTxn(peer, srcTptAddr,
                                          transId, &dupFlag,
                                          FALSE,
#ifdef    GCP_PROV_SCTP
                                          assoc,
#endif    /* GCP_PROV_SCTP */
                                          srvr, MGT_TXNREQ,
                                          method);
                  if (rxCb == NULLP)
                  {
                     mgDeAllocPeerCb(peer);
                     *peerCb = NULLP;
                     *errAction = MG_DISCARD_MSG;
                     *rspCode   = MGT_MGCO_RSP_CODE_RSRC_ERROR;
                     RETVALUE(RFAILED);
                  }
               }


               /* Update the next SSAP Id */
               if( 
#ifdef    GCP_PROC_MTP3
                (peerDpc) || 
#endif    /* GCP_PROV_MTP3 */   
#ifdef    GCP_PROV_SCTP
               (assoc) || 
#endif    /* GCP_PROV_SCTP */
               ((srvr) && (srvr->t.ssap == NULLP))
                  )

                  {
                  MG_UPDATE_NXTUSE_MGCO_SSAPID();
                  }

               if (srvr)
               {
                  MG_FILL_PORT_FRM_TPTADDR(peer->mgcoInfo.origSrvcChngPort,
                                           &(srvr->tptAddr));
               }
#ifdef    GCP_PROV_SCTP
               else
               {
                  if (assoc->assocCfg)
                     peer->mgcoInfo.origSrvcChngPort
                          = assoc->assocCfg->remPort;
                  /* else - What to do : */
               }
#endif    /* GCP_PROV_SCTP */


               /* generate an alarm to layer manager */
               MG_ISSUE_MGCOPEER_STAIND(peer, LCM_CATEGORY_PROTOCOL, 
                                 LMG_EVENT_PEER_ENABLED,
                                 LMG_CAUSE_SRVC_CHNG_ACCEPTED);
               /* 
               * Update peer state to register and wait for positive response 
               * from Service User to make it active
               */
               peer->state = LMG_PEER_STATE_REGISTER;
#ifdef ZG
               zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_MOD);
               if ((srvr)&&(srvr->srvrType == MG_TCP_CLIENT_CONNECTION))
               {               
                  /* Send delete and Add srvr to all shadows..*/
                  zgRtUpd(ZG_CBTYPE_TPTSRVR, (Ptr)srvr, CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_DEL);
                  zgRtUpd(ZG_CBTYPE_TPTSRVR, (Ptr)srvr, CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_ADD);
               }
               zgUpdPeer();
#endif /* ZG */
               RETVALUE(ROK);
            } /* creating a new peer for restart method */
            else
            {
               /* peer not found, should not be processed */
               *errAction = MG_DISCARD_MSG;
               *rspCode   = MGT_MGCO_RSP_CODE_PROT_ERROR;
               RETVALUE(RFAILED);
            } 
         } /* if (zgChCRsetStatus()) */
#ifdef ZG_DFTHA
         else
            RETVALUE(ROKDNA);
#endif /* ZG_DFTHA */
      } /* peer == NULLP */
      else /* Peer available */
      {

         /* For configured peer, insert the server in tcpConnList */
         if ((srvr) &&
             (srvr->srvrType == MG_TCP_CLIENT_CONNECTION))
         {
            if(srvr->t.peer == NULLP)
            {
               srvr->t.peer = peer;
               srvr->lstnrNode.node = (PTR)srvr;
               cmLListAdd2Tail (&(peer->mgcoInfo.tcpConnLst),
                              &(srvr->lstnrNode));
               peer->mgcoInfo.numActvConn++;
               if (peer->mgcoInfo.nxtUseConn == NULLP)
                  peer->mgcoInfo.nxtUseConn = srvr;
               if (srvr->idleTmr.tmrEvnt == MG_IDLE_CONN_TMR)
               {
                  mgStopTmr(MG_IDLE_CONN_TMR, (PTR)srvr,
                           &(srvr->idleTmr));
               }
            }
         }
#ifdef   GCP_PROV_SCTP
         else if ((assoc) && (assoc->peer == NULLP))
         {
            assoc->peer = peer;  /*  link peer->assocCfg below */
            peer->assocCb = assoc;
         }
#endif   /* GCP_PROV_SCTP */
         else
#ifdef   GCP_PROV_MTP3
             if (peer->accessInfo.transportType != LMG_TPT_MTP3)
#endif   /* GCP_PROV_MTP3 */            
         {
            addrTbl.count = 1;
            MG_FILL_NETADDR_FRM_TPTADDR(&(addrTbl.netAddr[0]),
                                        srcTptAddr);
            MG_FILL_PORT_FRM_TPTADDR(remotePort, srcTptAddr);

            if (svcChg->u.svcChgReq->parm.addr.type.pres == PRSNT_NODEF)
            {
               MgMgcoMid *mid;
               mid = &(svcChg->u.svcChgReq->parm.addr);
               if (svcChg->u.svcChgReq->parm.addr.type.val == MGT_MID_PORT)
               {
                  remotePort = mid->u.port.val;
               }
               else if (svcChg->u.svcChgReq->parm.addr.type.val == 
                        MGT_MID_DADDRPORT)
               {
                  if (PRSNT_NODEF == mid->u.dAddrPort.port.pres)
                     remotePort = mid->u.dAddrPort.port.val;
               }
               else if (svcChg->u.svcChgReq->parm.addr.type.val == 
                        MGT_MID_DNAMEPORT)
               {
                  if (PRSNT_NODEF == mid->u.dNamePort.port.pres)
                     remotePort = mid->u.dNamePort.port.val;
               }
            } /* service change address present */
         }


#ifdef ZG_DFTHA
          if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
          {
             if (peer->accessInfo.transportType == LMG_TPT_NONE)
             {

                if (srvr)
                   peer->accessInfo.transportType = srvr->transportType;
#ifdef    GCP_PROV_SCTP
                else if (assoc)
                   peer->accessInfo.transportType = LMG_TPT_SCTP;
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3
                else
                   peer->accessInfo.transportType = LMG_TPT_MTP3;
#endif    /* GCP_PROV_MTP3 */                   

             }

        
             /*
              *   Initialize tsap field of peer - Configured Peer
              */
             peer->tsap = tsap;

        
             if (peer->state != LMG_PEER_STATE_ACTIVE)
             {
               peer->state = LMG_PEER_STATE_REGISTER;


               if ((srvr) &&
                   (srvr->srvrType != MG_TCP_CLIENT_CONNECTION))
               {
                  peer->accessInfo.remotePort = remotePort;
                  MG_FILL_NETADDR_FRM_TPTADDR(&(addrTbl.netAddr[0]), srcTptAddr);
               }


               if ((srvr) &&
                   (srvr->srvrType != MG_TCP_CLIENT_CONNECTION))
                  MG_FILL_PORT_FRM_TPTADDR(remotePort,srcTptAddr);


               /* Learn IP addr if not available */
               /* mg004.105: Added check for transport type */
               if((peer->accessInfo.peerAddrTbl.count == 0) &&
                  (peer->accessInfo.transportType != LMG_TPT_MTP3))
               {
                  if ((mgUpdatePeerIpAddr(peer, &addrTbl)) != ROK)
                  {
                     RETVALUE(RFAILED);
                  }
               }
#ifdef ZG
               zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_MOD);

               /*mg002.105: Added additional check*/
               if ((srvr) &&
                  (srvr->srvrType == MG_TCP_CLIENT_CONNECTION))
               {               
                  /* Send delete and Add srvr to all shadows..*/
                  zgRtUpd(ZG_CBTYPE_TPTSRVR, (Ptr)srvr, CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_DEL);
                  zgRtUpd(ZG_CBTYPE_TPTSRVR, (Ptr)srvr, CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_ADD);
               }
               zgUpdPeer();
#endif /* ZG */
             }
          }
#ifdef ZG_DFTHA
          else
          {
            if ((LMG_TPT_NONE == peer->accessInfo.transportType) ||
               (peer->state != LMG_PEER_STATE_ACTIVE))
            {
               if(peer->state == LMG_PEER_STATE_REGISTER)
               {
                  if((peer->accessInfo.remotePort != remotePort) ||
                     (peer->accessInfo.peerAddrTbl.count == 0))
                  {
                     RETVALUE(ROKDNA);
                  }
               }
               else
               {
                  RETVALUE(ROKDNA);
               }
            }
          }
#endif /* ZG_DFTHA */
         /* 
          * If it is a case of RESTART, we have to go by current state
          * and do the processing accordingly 
          */
         if (method == MGT_SVCCHGMETH_RESTART)
         {
            if ((peer->state == LMG_PEER_STATE_ACTIVE) ||
                (peer->state == LMG_PEER_STATE_DISCONNECTED))
            {
               /* Reset all transactions */
#ifdef ZG
               peer->removeAllTxns =  TRUE;
#endif /* ZG */
               mgRemoveAllTxn(MG_IGNORE, peer);
            }
         }
        /*
         * If peer is available at the MGC side, invoke mgPrcIncomingTxn 
         * irrespective of the peer state
         */
         ssap = peer->ssap;



         if (svcChg->u.svcChgReq->parm.ver.pres == PRSNT_NODEF)
         {
            MG_NEGOTIATE_VERSION_MGC_SIDE(svcChg->u.svcChgReq->parm.ver.val,
                                          ssap->ssapCfg, peer,
                                          errAction, rspCode)
         }
         else if (msgVer->pres == PRSNT_NODEF)
            MG_NEGOTIATE_VERSION_MGC_SIDE(msgVer->val, ssap->ssapCfg, peer,
                                          errAction, rspCode)



        /* peer is available */
         if ((peer->state == LMG_PEER_STATE_AWAIT_REG) &&
             ((method == MGT_SVCCHGMETH_RESTART) ||
              (method == MGT_SVCCHGMETH_DISCON) ||
              (method == MGT_SVCCHGMETH_FAILOVER)))
         {
#ifdef ZG_DFTHA
            if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
            {
               /* 
               * This is a new request from MG to establish association with 
               * this MGC stop delete peer timer if running 
               */

               U8        idx;                /* Timer Index */

               idx = (MG_DEL_PEER_TMR - MG_PEER_TMR_BASE);

               if (peer->mntInfo.tmr[idx].tmrEvnt == MG_DEL_PEER_TMR)
               {
#ifdef ZG
                  peer->delPeerTmr = FALSE;
#endif /* ZG */
                  mgStopTmr(MG_DEL_PEER_TMR, (PTR) peer, 
                           &(peer->mntInfo.tmr[idx]));
               }

               /* 
               * If SVC addr is present, fill MgPeerInitInfo directly
               * from svcAddr field, rather than calling mgCnvrtMID and going
               * through it.
               */
               if (svcChg->u.svcChgReq->parm.addr.type.pres == PRSNT_NODEF)
               {
                  MgMgcoMid *mid;
                  mid = &(svcChg->u.svcChgReq->parm.addr);
                  if (svcChg->u.svcChgReq->parm.addr.type.val == MGT_MID_PORT)
                  {
                     peer->accessInfo.remotePort = mid->u.port.val;
                  }
                  else if (svcChg->u.svcChgReq->parm.addr.type.val == 
                           MGT_MID_DADDRPORT)
                  {
                     /* Always put this IP address as first entry */
                     if (PRSNT_NODEF == mid->u.dAddrPort.port.pres)
                        peer->accessInfo.remotePort = mid->u.dAddrPort.port.val;
                  }
                  else if (svcChg->u.svcChgReq->parm.addr.type.val == 
                           MGT_MID_DNAMEPORT)
                  {
                     if (PRSNT_NODEF == mid->u.dNamePort.port.pres)
                     peer->accessInfo.remotePort = mid->u.dNamePort.port.val;
                  }
               } /* service change address present */


               /*
               * Ir-respective of whether this is TCP or UDP, get the
               * origSrvcChngPort from "srvr" since this is the pointer on which
               * the service change was received.
               */

               if (srvr)
               {
                  MG_FILL_PORT_FRM_TPTADDR(peer->mgcoInfo.origSrvcChngPort,
                                           &(srvr->tptAddr));
               }
#ifdef    GCP_PROV_SCTP
               else
               {
                  if (assoc->assocCfg)
                     peer->mgcoInfo.origSrvcChngPort
                          = assoc->assocCfg->remPort;
                  /* else - What to do :  */
               }
#endif    /* GCP_PROV_SCTP */



               /* generate an alarm to layer manager */
               /* Use the MGCO specific macro */
               MG_ISSUE_MGCOPEER_STAIND(peer, LCM_CATEGORY_PROTOCOL, 
                                        LMG_EVENT_PEER_ENABLED,
                                        LMG_CAUSE_MGMT_INITIATED);
               /* 
               * Update peer state to register and wait for positive 
               * response from Service User to make it active
               */
               peer->state = LMG_PEER_STATE_REGISTER;
            }
#ifdef ZG_DFTHA
            else
               RETVALUE(ROKDNA);
#endif /* ZG_DFTHA */
         }
         /*
          * Place the method=RESTART & state=ACTIVE or DISOCNNECT check 
          * before PrcIncomingTxn is invoked, as all txns have to be removed
          * in this case.
          */
         else if (method == MGT_SVCCHGMETH_DISCON)
         {
            if ((peer->state == LMG_PEER_STATE_DISCONNECTED))
            {
#ifdef ZG_DFTHA
               if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
                  peer->state = LMG_PEER_STATE_ACTIVE;
				  if (peer->ssap != NULLP)  			 /*cdw add by 2006.9.28*/
					   peer->ssap->alarmIndSent=FALSE; 	 /*cdw add by 2006.9.28*/
#ifdef ZG_DFTHA
               else
                  RETVALUE(ROKDNA);
#endif /* ZG_DFTHA */
            }
         }
         else if (method == MGT_SVCCHGMETH_FAILOVER)
         {

             /* 
              * Active MG failed , move all transactions to standby 
              * Nothing is performed here, this action shall
              * be performed when service user gives positive service change 
              * reply for this in mgPrcUserRegRsp function 
              */
            if(peer->state != LMG_PEER_STATE_FAILOVER) 
            {
#ifdef ZG_DFTHA
               if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
                  peer->state = LMG_PEER_STATE_FAILOVER;
#ifdef ZG_DFTHA
               else
			   if (peer->ssap != NULLP)            /*cdw add by 2006.9.28*/
                  peer->ssap->alarmIndSent=FALSE;  /*cdw add by 2006.9.28*/
                  RETVALUE(ROKDNA);
#endif /* ZG_DFTHA */
            }
         }
         else
         {
            /* Any other method is passed transparently to the service user */
         }



         if(crtRxCb == TRUE)
         {
            /* Create a record of incoming transaction */
            rxCb = mgPrcIncomingTxn(peer, srcTptAddr,
                                    transId, &dupFlag,
                                    FALSE,
#ifdef    GCP_PROV_SCTP
                                    assoc,
#endif    /* GCP_PROV_SCTP */
                                    srvr,
                                    MGT_TXNREQ, method);
            if (rxCb == NULLP)
            {
               *errAction = MG_DISCARD_TXN;
               *rspCode   = MGT_MGCO_RSP_CODE_RSRC_ERROR;
               RETVALUE(RFAILED);
            }
            if (dupFlag == TRUE)
               RETVALUE(ROK);
         }
#ifdef ZG
#ifdef ZG_DFTHA
         if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
         {
            zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_NORMAL,
               CMPFTHA_ACTN_MOD);
            zgUpdPeer();
         }
#endif /* ZG */
      } /* peer available */
#endif /* GCP_MGC */
   } /* MGC related processing */
   else 
   {
#ifdef GCP_MG
      /*
       * For MG side, peer pointer will always be valid. Obtain ssap pointer
       * for processing.
       */
      ssap = peer->ssap;
      /* layer is acting as MG;Process Handoff message from MGC */
      if ((method == MGT_SVCCHGMETH_HANDOFF) && 
          (peer->state == LMG_PEER_STATE_ACTIVE))
      {
#ifdef ZG_DFTHA
         if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
         {
            /* 
            * Current peer must be in active state for handoff 
            * processing.
            */
           /* If mgcId is not present in the handoff message, MG
            * shall start contacting secondary MGCs 
            */

            /* 
            * For handoff scenario at MG side, mgcIdToTry is to be
            * treated as a transport address and has nothing to do with the MID
            * of the new peer. Make changes to reflect this.
            */
            if (svcChg->u.svcChgReq->parm.mgcId.type.pres == PRSNT_NODEF)
            {
               MgMgcoMid *mid = &(svcChg->u.svcChgReq->parm.mgcId);
               CmTptAddr   newAddr;       /* Remote Transport Address */
               U8          name[CM_DNS_DNAME_LEN];/* Peer Name */
               Bool   sendUpd;

               sendUpd = FALSE;

               cmMemset(((U8 *)&newAddr), 0, sizeof(CmTptAddr));
               cmMemset(((U8 *)name), 0, sizeof(U8 *));

               MG_FILL_TPTADDR_FRM_MID(&newAddr, mid, name);
#ifdef   GCP_PROV_MTP3
               if (peer->accessInfo.transportType == LMG_TPT_MTP3)
                  newPeer = mgGetMtpPeer(mid, peer, &newDpc);
               else  
#endif   /* GCP_PROV_MTP3 */                        
            /* Find if a peer exists with the provided mgcIdToTry */
               newPeer = mgGetPeer(NULLP, &newAddr, name, 
                                   (MgSSAPCb *)ssap, &sendUpd); 
                /*
                * For MTP Transport case do not allow new peer at MG side as
                * it may happen that new MGC address may not have linkset and
                * point code configured towards new peer 
                */
               if ((newPeer == NULLP)
#ifdef   GCP_PROV_MTP3
                    && (peer->accessInfo.transportType != LMG_TPT_MTP3)
#endif   /* GCP_PROV_MTP3 */
                    )      /* Do not remove this brase */
               {
                  /* 
                  * Create a new Peer and initiate a new service change
                  * on this peer;Initialise peerInit structure 
                  */
                  init.name[0] = '\0';
                  init.addrTbl.count = 0;
                  init.remotePort = LMG_INVALID_PEER_PORT;
#ifdef ZG
                  init.peerId = MG_INVALID_PEERID;
                  init.mtdPeerId = MG_INVALID_PEERID;
#ifdef ZG_DFTHA
                  init.suConnId = MG_INVALID_LSTNRID;
#endif /* ZG_DFTHA */
#endif /* ZG */
               
               /*
                * For MTP3 TSAP Copy the peerDpc and tsap info to peerInfo structure
                */
#ifdef    GCP_PROV_MTP3      
               if(tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3)
               {
                  /* Copy the Peer Point Code in the Init Structure */
                  init.peerDpc = newDpc;
                  /* Copy the  Tsap also as it will be used for tsapCfg and
                   * to Locate Hash List */
                  init.tsap   =  tsap; 
               }
               else
#endif    /* GCP_PROV_MTP3 */

#ifdef    GCP_PROV_SCTP
                  if (assoc && (assoc->assocCfg))
                  {
                     init.assocCfg   = *(assoc->assocCfg);
                     init.allocAssocCfg = TRUE;
                  }
#endif    /* GCP_PROV_SCTP */


                  if (mid->type.val == MGT_MID_DNAMEPORT)
                  {
                     /* domain name is available in the MId received */
                     cmMemcpy((U8 *)init.name, (U8 *)mid->u.dNamePort.name.val, 
                           mid->u.dNamePort.name.len);
                     init.name[mid->u.dNamePort.name.len] = '\0';
                     if (PRSNT_NODEF == mid->u.dNamePort.port.pres)
                        init.remotePort = mid->u.dNamePort.port.val;
                  }
                  else if (mid->type.val == MGT_MID_DADDRPORT)
                  {
                     /* Always put this IP address as first entry */
                     MG_FILL_NETADDR_FRM_TPTADDR(&(init.addrTbl.netAddr[init.addrTbl.count]),
                                                 &newAddr);
                     init.addrTbl.count++;

                     if (PRSNT_NODEF == mid->u.dAddrPort.port.pres)
                     {
                        /*
                         *                 removed the macro call which was
                         *                 initializing remotePort to -1;
                         *                 added code to correctly populate
                         *                 the remotePort field in init.
                         */

                         if (newAddr.type == CM_TPTADDR_IPV4)
                         {
                            init.remotePort = newAddr.u.ipv4TptAddr.port;
                         }
                         else
                         {
                            init.remotePort = newAddr.u.ipv6TptAddr.port;
                         }

                     }
                  }
#ifdef   GCP_PROV_MTP3                  
                 else if (mid->type.val == MGT_MID_MTPADDR)
                  {
                       MG_FILL_MTP_DPC_FRM_MID_TEXT(mid,init.peerDpc);
                  }
#endif    /* GCP_PROV_MTP3 */                  
 
                  /* MID is not present */
                  init.mid.pres = NOTPRSNT;
                  /* Contact new MGC using the transportType of the existing MGC */



#ifdef    GCP_PROV_SCTP
                  if (srvr)
                     init.transportType = srvr->transportType;
                  else
                     init.transportType = LMG_TPT_SCTP;
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3               
               if (srvr)
#endif   /* GCP_PROV_MTP3 */                  
#ifndef GCP_PROV_SCTP                  
                  init.transportType     = srvr->transportType;
#endif
#ifdef    GCP_PROV_MTP3               
               if(tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3)
                  init.transportType     = LMG_TPT_MTP3; /*  new define */
#endif     /* GCP_PROV_MTP3 */





                  init.protocolType      = LMG_PROTOCOL_MGCO;
                  /* Initialize variant to be 
                   *            LMG_VER_PROF_MGCO_H248_1_0 than 0 for MEGACO. */
#ifdef GCP_VER_1_5                  
                  init.variant           = LMG_VER_PROF_MGCO_H248_2_0;
#else
                  init.variant           = LMG_VER_PROF_MGCO_H248_1_0;
#endif

                  /*
                   * MAH_TODO Taking the encoding scheme from the port.
                   * Now we have the remote port here .So we will try to take
                   * the  encoding secheme from the port .If we fails , we
                   * we will take the encoding scheme from the  
                   * srvrencoding scheme
                   */
#ifdef    GCP_PROV_MTP3               
                  if(tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3)
                  {
                     /* Copy the encoding scheme from the peerCb as New Peer will also 
                      * use the same encoding scheme */
                      
                     init.encodingScheme = peer->mgcoInfo.encodingScheme;
                  }
                  else
#endif     /* GCP_PROV_MTP3 */
                    
                   /* mg008.105: Bug fix */
                   if (srvr)
                   {  
                     init.encodingScheme    = srvr->encodingScheme;
                   } 
                   else if (init.remotePort == MG_MGCO_DEFAULT_TEXT_PORT )
                   { 
                     init.encodingScheme    = LMG_ENCODE_TXT;
                   }  
                   else if (init.remotePort == MG_MGCO_DEFAULT_BINARY_PORT )
                   {  
                     init.encodingScheme    = LMG_ENCODE_BIN;
                   }
#ifdef    GCP_PROV_SCTP
                   else
                   {
                     init.encodingScheme = assoc->tsap->endpCb.encodingScheme;
                   } 
#endif    /* GCP_PROV_SCTP */

                  init.useAHScheme       = 0; 


                  /*
                   *   Fill in the version for the new peer the same as
                   *   the version of the MGC which has initiated the
                   *   Handoff procedure.
                   *
                   *   The logic behind this is that the new MGC should
                   *   have atleast same version capabilities as the current
                   *   MGC (pointed to by peer).
                   *
                   *   BTW, we don't care about the version negotiation
                   *   on receiving a SvcChg Handoff since the negotiation
                   *   already happened previously.TODO_MAH
                   */
                  /*MAH_TODO
                   *In the case of a Handoff use the maximum version while
                   * sending a service change to hand off mgc.This was clarified
                   * in the mailing list.
                   *
                   */
                  init.mgcoVersion = ssap->ssapCfg.maxMgcoVersion;
                  
                    
                  if (ssap->ssapCfg.reCfg.initRetxTmr.enb == TRUE)
                  {
                     init.initRtt = ssap->ssapCfg.reCfg.initRetxTmr.val;
                  }
                  else
                  {
                     init.initRtt = (MG_INIT_RTT_VALUE * mgCb.genCfg.timeRes);
                  }
                  init.trcLen            = MG_DEFAULT_TRC_LEN;
                  init.mtuSize           = (init.transportType == 
                                          LMG_TPT_UDP) ? 
                                          MG_MAX_UDP_MTU_SIZE : 
                                          MG_MAX_TCP_MTU_SIZE;
                  init.priority          = MG_INVALID_PRIORITY;
                  init.byCfg             = FALSE;

#ifdef    GCP_PROV_SCTP
               {
                  U16      indx;

                  /*
                   * The following fields were copied from the original
                   * peer above -
                   *
                   * init.assocCfg.locOutStrms
                   *
                   * cmMemset((U8 *)&(init.assocCfg.srcAddrLst),
                   *          0, sizeof(SctNetAddrLst));
                   *
                   * So there is no need to fill them again;
                   *
                   * The only relevant fields which might have changed
                   * are the dstAddr(Lst) & the remotePort;
                   *
                   */

                  init.assocCfg.priDstAddr = init.addrTbl.netAddr[0];

                  /* mg002.105: remove compilation warning*/
                  init.assocCfg.dstAddrLst.nmb = (U8)init.addrTbl.count;

                  for (indx = 0; indx < init.addrTbl.count; ++indx)
                  {
                     init.assocCfg.dstAddrLst.nAddr[indx]
                        = init.addrTbl.netAddr[indx];
                  }

                  init.assocCfg.remPort
                       = (init.remotePort == -1) ?
                         MG_MGCO_DEFAULT_TEXT_PORT : (init.remotePort);

                  /* mg001.105: We are the GWY & we have received
                   *            SrvcChng Handoff from an unknown MGC.
                   *            So use the tos configured in the
                   *            endpoint cfg */
                  init.tos = tsap->endpCb.defaultTos;
               }
#endif    /* GCP_PROV_SCTP */



                  newPeer = mgAllocPeerCb(ssap, &init);
                  if (newPeer == NULLP)
                  {
                     /* Resource error */
                     *errAction = MG_DISCARD_TXN;
                     *rspCode   = MGT_MGCO_RSP_CODE_RSRC_ERROR;
                     RETVALUE(RFAILED);
                  }

                  newPeerAllocated = TRUE;

                  /*
                   *   Initialize the tsap field of the new peer
                   */
                  newPeer->tsap = tsap;

#ifdef ZG
                  ZG_INIT_RSETID_IN_MAPCB(&(newPeer->mapCb));
                  zgAddMapping(ZG_CBTYPE_PEER, (Ptr)newPeer);
                  zgRtUpd(ZG_CBTYPE_PEER,(Ptr)newPeer,CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_ADD);
                  zgUpdPeer();
#endif /* ZG */
               }
               else
               {
                  /* Peer is already available with MG on this SSAP */
               }
            } /* mgcId is present in Handoff message */
            /* If mgcId is not present in the handoff message, MG
             * shall start contacting secondary MGCs. The else part has been
             * added to the above code.
             */
            else
            {
               CmLList *firstNode;
               /* check if currently active MGC was the primary MGC, 
                * if not, make crntMgc NULL, so that the primary MGC is
                * selected.
                */
               CM_LLIST_FIRST_NODE(&(ssap->peerLst), firstNode);
               if (ssap->crntMgc == (MgPeerCb *)firstNode->node)
               {
                  mgSelectPeer(&newPeer, ssap);
               }
               else if ( ((MgPeerCb *)firstNode->node)->state ==
                                        LMG_PEER_STATE_AWAIT_REG)
               {
                   newPeer = (MgPeerCb *)firstNode->node;
               }


               if (newPeer == NULLP) 
               {
                  /* No more MGCs available; Inform LM */
                  SpId sapId;
                  sapId = peer->ssap->ssapCfg.sSAPId;
				  if(ssap->alarmIndSent == FALSE)     /*cdw add "if" by 2006.9.28 */
				  {
                  		mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                              		LMG_EVENT_ALL_MGC_FAILED, LCM_CAUSE_UNKNOWN, 
                              		LMG_ALARMINFO_SAP, (Ptr)&(sapId), sizeof(SpId),
                              		LMG_ALARMINFO_INVSAPID);
						ssap->alarmIndSent = TRUE;   /*cdw add by 2006.9.28*/
				  }
               }
            } /* mgcId was not present in the handoff message */

            peer->mgcoInfo.t.handOffMGC = newPeer;
            peer->state = LMG_PEER_STATE_UNDR_HNDOFF;

            /* newPeer may still be NULL if there is no secondary MGC
             * configured. So check for newPeer == NULL. 
             * Also if there is no mgcId specified in the service change, set a
             * bit in peer flag. The reason filled in the SVC Handoff 
             * to be sent will depend on this bit in the peerFlg.
             */
            if (newPeer)
            {

               /*
                *   Fill in the version for the new peer the same as
                *   the version of the MGC which has initiated the
                *   Handoff procedure.
                *
                *   The logic behind this is that the new MGC should
                *   have atleast same version capabilities as the current
                *   MGC (pointed to by peer).
                *
                *   BTW, we don't care about the version negotiation
                *   on receiving a SvcChg Handoff since the negotiation
                *   already happened previously.
                */
              
              /*MAH_TODO
               *In the case of a Handoff use the maximum version while
               *sending a service change to hand off mgc.This was clarified
               *in the mailing list.
               */
               newPeer->mgcoInfo.negotiatedVersion =
                 ssap->ssapCfg.maxMgcoVersion;

               newPeer->mgcoInfo.t.undrHndOffMGC = peer;
               newPeer->accessInfo.peerflg |= MG_HANDOFF_RQSTD;
               if (svcChg->u.svcChgReq->parm.mgcId.type.pres == NOTPRSNT)
               {
                  newPeer->accessInfo.peerflg |= MG_HANDOFF_RQSTD_NO_MGCID;
               }
            }

               /* 
               * Wait for the service user to accept handoff request before
               * initiating actual Handoff procedures 
               */
#ifdef ZG
               /* mg007.105: Send update only if newpeer is not null */
               if (newPeer != NULLP)
                  zgRtUpd(ZG_CBTYPE_PEER,(Ptr)newPeer,CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_MOD);
               zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                  CMPFTHA_ACTN_MOD);
               zgUpdPeer();
#endif /* ZG */
         }
#ifdef ZG_DFTHA
         else
            RETVALUE(ROKDNA);
#endif /* ZG_DFTHA */
      } /* If method is HANDOFF */
      else
      {
         /*
          *              if we receive a SrvChng from any peer other
          *              than primary MGC (active one), generate an error
          *              response with - 402 Unauthorized error code.
          */

         if (peer->state != LMG_PEER_STATE_ACTIVE)
         {
            *errAction = MG_DISCARD_MSG;
            *rspCode   = MGT_MGCO_RSP_CODE_UNAUTHORIZED;
            RETVALUE(RFAILED);
         }

         /* No special processing required in case of any other method */
      }


      if(crtRxCb == TRUE)
      {
         rxCb = mgPrcIncomingTxn(peer, srcTptAddr, transId, &dupFlag,
                                 FALSE,
#ifdef    GCP_PROV_SCTP
                                 assoc,
#endif    /* GCP_PROV_SCTP */
                                 srvr,
                                 MGT_TXNREQ, method);
         if (rxCb == NULLP)
         {
            /* Deallocate peerCb only if it was newly created */
            if(newPeerAllocated)
            {
#ifdef ZG
               /* Send update del to standby */
               newPeer->removeAllTxns =  TRUE;
               zgRtUpd(ZG_CBTYPE_PEER,(Ptr)newPeer,CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_DEL);
               zgDelMapping(ZG_CBTYPE_PEER, (Ptr)newPeer);
               zgUpdPeer();
#endif /* ZG */
               mgDeAllocPeerCb(newPeer);
               newPeer = NULLP;
            }
            *errAction = MG_DISCARD_TXN;
            *rspCode   = MGT_MGCO_RSP_CODE_RSRC_ERROR;
            RETVALUE(RFAILED);
         }
      }
#endif /* GCP_MG */
   } /* MG related processing */

   RETVALUE(ROK);

} /* end of mgProcessSrvcChng () */




/*
*
*       Fun:    mgProcessSrvcChngReply 
*
*       Desc:   This function processes the service change reply message from 
*               the peer. This function is only required in case of MEGACO. 
*               
*
*       Ret:    ROK - SUCCESS
*               RFAILED - FAILURE 
*               ROKDNA - Txn will queued ( in case reverse update is generated).
*
*       Notes:  None
*
*       File:   mg_peer.c
*/
#ifdef    GCP_PROV_SCTP

#ifdef ANSI
PUBLIC S16 mgProcessSrvcChngReply
(
S16                *errAction,         /* Action to be taken on error */
MgMgcoVersion      *msgVer,            /* Version in MEGACO message */
MgSvcChgInfo       *svcChg,            /* Service change or reply Information */
MgPeerCb           *peer,              /* Peer Control block */
MgAssocCb          *assoc,             /* Association Control Block */
MgTptSrvr          *srvr,              /* Server Control Block */
CmTptAddr          *srcTptAddr,        /* Source Transport Address */
U8                 msgInfo,            /* txCb->msgInfo ?*/
MgTransId          transId,            /* transaction id */
Bool               updTxCb,            /* whether update txCb */
MgTxTransIdEnt     **txCb              /* transaction control block */
)
#else
PUBLIC S16 mgProcessSrvcChngReply(errAction, msgVer, svcChg, peer,
                                  assoc, srvr, srcTptAddr, msgInfo,
                                  transId, updTxCb, txCb)
S16                *errAction;         /* Action to be taken on error */
MgMgcoVersion      *msgVer;            /* Version in MEGACO message */
MgSvcChgInfo       *svcChg;            /* Service change or reply Information */
MgPeerCb           *peer;              /* Peer Control block */
MgAssocCb          *assoc;             /* Association Control Block */
MgTptSrvr          *srvr;              /* Server Control Block */
CmTptAddr          *srcTptAddr;        /* Source Transport Address */
U8                 msgInfo;            /* txCb->msgInfo ?*/
MgTransId          transId;            /* transaction id */
Bool               updTxCb;            /* whether update txCb */
MgTxTransIdEnt     **txCb;             /* transaction control block */
#endif

#else     /* GCP_PROV_SCTP */

#ifdef ANSI
PUBLIC S16 mgProcessSrvcChngReply
(
S16                *errAction,         /* Action to be taken on error */
MgMgcoVersion      *msgVer,            /* Version in MEGACO message */
MgSvcChgInfo       *svcChg,            /* Service change or reply Information */
MgPeerCb           *peer,              /* Peer Control block */
MgTptSrvr          *srvr,              /* Server Control Block */
CmTptAddr          *srcTptAddr,        /* Source Transport Address */
U8                 msgInfo,            /* txCb->msgInfo ?*/
MgTransId          transId,            /* transaction id */
Bool               updTxCb,            /* whether update txCb */
MgTxTransIdEnt     **txCb              /* transaction control block */
)
#else
PUBLIC S16 mgProcessSrvcChngReply(errAction, msgVer, svcChg, peer, srvr,
                                  srcTptAddr, msgInfo, transId, updTxCb, txCb)
S16                *errAction;         /* Action to be taken on error */
MgMgcoVersion      *msgVer;            /* Version in MEGACO message */
MgSvcChgInfo       *svcChg;            /* Service change or reply Information */
MgPeerCb           *peer;              /* Peer Control block */
MgTptSrvr          *srvr;              /* Server Control Block */
CmTptAddr          *srcTptAddr;        /* Source Transport Address */
U8                 msgInfo;            /* txCb->msgInfo ?*/
MgTransId          transId;            /* transaction id */
Bool               updTxCb;            /* whether update txCb */
MgTxTransIdEnt     **txCb;             /* transaction control block */
#endif

#endif    /* GCP_PROV_SCTP */
{
   MgSSAPCb        *ssap;              /* SAP Control block */

#ifdef GCP_MG
   MgPeerInitInfo init;                /* peer initialisation structure */
   MgPeerCb       *newPeer;            /* new Peer control block */
   CmNetAddr      address;             /* IP Address */
   S16             ret;                /* Return value */
   /* adding new local variable */
   U8              method;             /* method to be sent for SVC msg */
#endif /* GCP_MG */
   U8             msgType;             /* message Type */


   TRC2(mgProcessSrvcChngReply)



#ifdef GCP_MG
   cmMemset(((U8 *)&init), 0, sizeof(MgPeerInitInfo));
#endif /* GCP_MG */

      

   ssap = peer->ssap;

   if (mgCb.genCfg.entType == LMG_ENT_GC)
   {
#ifdef GCP_MGC
      /* layer is acting as MGC */
      if ((msgInfo & MG_HANDOFF) && (msgInfo & MG_LM_INIT))
      {
         /* If LM initiated the handoff procedure */
         /* Report result to LM via ALARM */
         U16             event;         

         if ((svcChg->u.svcChgReply->res.type.pres == PRSNT_NODEF)
         && (svcChg->u.svcChgReply->res.type.val == 
         MGT_ERRDESC))
         {
            event = LMG_EVENT_PEER_HANDOFF_FAILURE;
         }
         else
            event = LMG_EVENT_PEER_HANDOFF_SUCCESS;
         /* Use the MGCO specific macro */
         MG_ISSUE_MGCOPEER_STAIND(peer, LCM_CATEGORY_PROTOCOL, event, 
                              LMG_CAUSE_MGMT_INITIATED);

         if(updTxCb == TRUE)
         {
            /* NO need to pass assoc to the following function for SCTP */
            mgPrcIncomingAck(txCb, &msgType, srvr, peer, transId, 
                                    MGT_MGCP_RSP_CODE_OK);
         }
         *errAction = MG_DISCARD_TXN;
         RETVALUE(RFAILED);
      }
#endif /* GCP_MGC */
   } /* MGC related processing */
   else 
   {
#ifdef GCP_MG
      /* if stack in in lock state, unlock it */
      /* mg005.105: Added new state to support MG in lock/unlock state */
      if(ssap->lockUnlock)
         ssap->lockUnlock = FALSE;
      /* Added condition for SVC request sent with method
       * DISCONNECT */
      if ((msgInfo & MG_RESTART) || (msgInfo & MG_FAILOVER) ||
          (msgInfo & MG_HANDOFF) || (msgInfo & MG_DISCONNECT) ||
          (peer->state == LMG_PEER_STATE_REGISTER))
      {
         /* mg008.105: Added check whether version negotiation was failed with
          * peer */
         if ((peer->state == LMG_PEER_STATE_REGISTER) ||
            (peer->state == LMG_PEER_STATE_VER_UNSUPP))
         {
            /* waiting for a response for service change initiated */
            if ((svcChg->u.svcChgReply->res.type.pres == PRSNT_NODEF) && 
                (svcChg->u.svcChgReply->res.type.val == MGT_ERRDESC))
            {
               /* process incoming transaction */
               if(updTxCb == TRUE)
               {
                  if((mgPrcIncomingAck(txCb, &msgType, srvr, peer, transId, 
                                    MGT_MGCP_RSP_CODE_OK)) != ROK)
                  {
                     *errAction = MG_DISCARD_TXN;
                     RETVALUE(RFAILED);                     
                  }
                  updTxCb = FALSE;
               }
               /* 
                * Service change reply is an error. If it is self initiated 
                * service change, neednot give anything to service user. This 
                * function shall also bring down all transactions on
                * this peer, so whatever has been queued on this peer shall
                * be removed 
                */
               if (msgInfo & MG_SELF_INIT)
               {
                  if (peer->accessInfo.peerflg & MG_HANDOFF_RQSTD)
                  {
                     /* current MGC has requested Handoff */
#ifdef ZG_DFTHA
                     if ((((zgChkCRsetStatus()) == TRUE)) == TRUE)
#endif /* ZG_DFTHA */
                        mgAbortHandOff(peer, LMG_CAUSE_PEER_REJECT);
#ifdef ZG_DFTHA
                     else
                     {
                        /* send reverse update , don't queue it*/
                        mgSndRvUpdSvcRspP((srvr->suConnId), srcTptAddr, peer, *msgVer,
                                          svcChg, msgInfo, MG_QUEUE_NONE);
                     }
#endif /* ZG_DFTHA */

                     /* mg008.105: changing form MG_DISCARD_MSG */
                     *errAction = MG_DISCARD_TXN;
                     RETVALUE(RFAILED);
                  }
                  else if (peer->accessInfo.peerflg & MG_REDIRECTED_BY_MGC)
                  {
                     /* MG was redirected by the MGC earlier */
#ifdef ZG_DFTHA
                     /* Only master should process it*/
                     if(zgChkCRsetStatus())
#endif /* ZG_DFTHA */
                        mgAbortRedirection(peer, LMG_CAUSE_PEER_REJECT);
#ifdef ZG_DFTHA
                     else
                        /* send reverse update , don't queue it*/
                        mgSndRvUpdSvcRspP((srvr->suConnId), srcTptAddr, peer, *msgVer,
                                          svcChg, msgInfo, MG_QUEUE_NONE);
#endif /* ZG_DFTHA */

                     /* mg008.105: changing form MG_DISCARD_MSG */
                     *errAction = MG_DISCARD_TXN;
                     RETVALUE(RFAILED);
                  }
                  else
                  {
                     mgIndicateAbortTxnToUsr(MGT_ERR_RESET_SSAP_TXN, 
                                 MG_INVALID_TRANSID, peer);
                     /* mg008.105: changing form MG_DISCARD_MSG */
                     *errAction = MG_DISCARD_TXN;
#ifdef ZG_DFTHA
                     /* Only master should process it*/
                     if(zgChkCRsetStatus())
#endif /* ZG_DFTHA */
                     { 
                        mgBringPeerToCfgStatus(peer, TRUE);
#ifdef ZG
                        peer->bringToCfg =  TRUE;
                        zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC,
                                CMPFTHA_ACTN_MOD);
#endif /* ZG */
                     }
                  } 
               } /* selfInit */
               else
               { 
                  /* user initiated service change */
                  /* Peer should be brought to config state
                  * after service change reply with error is 
                  * passed up, user may require to check the
                  * error type */
                  *errAction = MG_DELETE_PEER_PASS_TXN;

                 /* SrvcChng with method Disconnected. 
                  * If error response code is 504/402 - Unauthorized, it  may
                  * have been received for  a User initiated SrvcChng with
                  * method DISCONNECTED (if MGC has lost all MG information).
                  * The stack should not contact secondary MGCs in this case,
                  * the service user would send SrvcChng-RESTART instead.  **/
                 if (svcChg->u.svcChgReply->res.u.err.code.pres == PRSNT_NODEF)
                 {
                    U16  rspCode;

                    rspCode = svcChg->u.svcChgReply->res.u.err.code.val;
                    if ((rspCode == MGT_MGCO_RSP_CODE_UNAUTHORIZED) ||
                        (rspCode == MGT_MGCO_RSP_CODE_UNAUTH_ENTITY))
                    RETVALUE(RFAILED);
                 }
               } /* user init service chng */
#ifdef ZG_DFTHA
               if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
               {
                  /* Find a new peer */
                  mgSelectPeer(&newPeer, ssap);
                  if (newPeer != NULLP)
                  {
                     /* Valid peer is found */
                     /* Initiate service change on the new peer */
                     ssap->crntMgc = newPeer;
                    /* If the peer MGC is being contacted again after
                     * disconnection, send method as DISCONNECTED **/
                     MG_OBTAIN_SVCCHG_METHOD(method, newPeer);


                     /*
                      *   Use the same version as we used for the
                      *   current MGC so that the new MGC has atleast
                      *   the same set of version capabilities as
                      *   the current MGC.
                      */
                     newPeer->mgcoInfo.negotiatedVersion =
                        peer->mgcoInfo.negotiatedVersion;


                     ret = mgSendSrvcChng(newPeer, MGT_SVCCHGMETH_RESTART,
                                          MG_SCRSN_WARM_BOOT, NULLP,
                                          LMG_INVALID_PEER_PORT, NULLP);

#ifdef ZG
                     zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
                        CMPFTHA_ACTN_MOD);
#endif /* ZG */
                  }

                  if ((newPeer == NULLP) || (ret != ROK))
                  {
                     SpId sapId;
                     /* No more MGCs available */
                     /* Should inform LM */
                     sapId = ssap->ssapCfg.sSAPId;
					 if(ssap->alarmIndSent == FALSE)	/*cdw add "if" on 2006.9.29*/
					 	{
                     		/* Send Status Indication to the layer manager */
                     		mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                        		LMG_EVENT_ALL_MGC_FAILED, LCM_CAUSE_UNKNOWN, 
                        		LMG_ALARMINFO_SAP, (Ptr)&(sapId), sizeof(SpId), 
                        		LMG_ALARMINFO_INVSAPID);
							ssap->alarmIndSent = TRUE;   /*cdw add on 2006.9.29*/
					 	}
                     ssap->crntMgc = NULLP;
                     /* assign crntMgc to the first node in the peerList */
                     mgSelectPeer(&(ssap->crntMgc), ssap);
#ifdef ZG
                     zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
                        CMPFTHA_ACTN_MOD);
#endif /* ZG */
                     RETVALUE(RFAILED);
                  }
               }
#ifdef ZG_DFTHA
               else
               {
                  /* send reverse update , don't queue it*/
                  mgSndRvUpdSvcRspP((srvr->suConnId), srcTptAddr, peer, *msgVer,
                                    svcChg, msgInfo, MG_QUEUE_NONE);
               }
#endif /* ZG_DFTHA */
               RETVALUE(RFAILED);
            } /* service change reply in error */
            else if ((svcChg->u.svcChgReply->res.type.pres == PRSNT_NODEF) &&
                     (svcChg->u.svcChgReply->res.type.val == MGT_SVCCHGDESC))
            {
               /* Service change reply success for restart */
               /* Check whether service change address is present */
               MgMgcoMid *addr = &(svcChg->u.svcChgReply->res.u.
                  parm.addr);
               MgMgcoMid *mid = &(svcChg->u.svcChgReply->res.u.
                  parm.mgcId);


               if ((addr->type.pres == PRSNT_NODEF) &&
                   (svcChg->u.svcChgReply->res.u.parm.pres.pres == PRSNT_NODEF))
               {
#ifdef ZG_DFTHA
                  /* Only master should process it */
                  if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
                  {
                     Bool        newConnReqd = FALSE;
                     /* process incoming transaction */
                     if(updTxCb == TRUE)
                     {
                        if((mgPrcIncomingAck(txCb, &msgType, srvr, peer, 
                           transId, MGT_MGCP_RSP_CODE_OK)) != ROK)
                        {
                           *errAction = MG_DISCARD_TXN;
                           RETVALUE(RFAILED);                     
                        }
                        updTxCb = FALSE;
                     }

                     if (addr->type.val == MGT_MID_PORT)
                     {
                        if (peer->accessInfo.remotePort != addr->u.port.val)
                        {
                            /* Copy the port value in peer */
                            peer->accessInfo.remotePort = addr->u.port.val;


#ifdef    GCP_PROV_SCTP
                            if (((srvr) &&
                                 (srvr->transportType == LMG_TPT_TCP)) ||
                                (assoc))
#else     /* GCP_PROV_SCTP */
                            if ((srvr)&&(srvr->transportType == LMG_TPT_TCP))
#endif    /* GCP_PROV_SCTP */
                               newConnReqd = TRUE;
                        }
                     }
                     else if (addr->type.val == MGT_MID_DNAMEPORT)
                     {
                        /* This case should not happen , assume only port is
                        * changing */
                        if ( (PRSNT_NODEF == addr->u.dNamePort.port.pres) &&
                              (peer->accessInfo.remotePort != 
                                                addr->u.dNamePort.port.val) )
                        {
                           /* Copy the port value in peer */
                           peer->accessInfo.remotePort = 
                                             addr->u.dNamePort.port.val;


#ifdef    GCP_PROV_SCTP
                            if (((srvr) &&
                                 (srvr->transportType == LMG_TPT_TCP)) ||
                                (assoc))
#else     /* GCP_PROV_SCTP */
                           if (srvr->transportType == LMG_TPT_TCP)
#endif    /* GCP_PROV_SCTP */
                              newConnReqd = TRUE;
                        }
                     }
                     else if (addr->type.val == MGT_MID_DADDRPORT)
                     {
                        if (ROK == mgGetIpAddrFromDomainNameStr(
                                    /* mg003.105: Bug fixes */
                                    addr->u.dAddrPort.u.ipv4.len, 
                                    addr->u.dAddrPort.u.ipv4.val, &(address),
                                    LMG_PROTOCOL_MGCO)) 
                        {
                          if(cmMemcmp((U8 *) &(peer->accessInfo.peerAddrTbl.netAddr[0]),
                                      (U8 *) &address, sizeof(CmNetAddr)) != 0)
                          {
                              /* There may be a need to add or move the peer
                              * address into 1st position in AddrTbl */
                              mgAddIpAddr(peer, &address);


#ifdef    GCP_PROV_SCTP
                            if (((srvr) &&
                                 (srvr->transportType == LMG_TPT_TCP)) ||
                                (assoc))
#else     /* GCP_PROV_SCTP */
                              if (srvr->transportType == LMG_TPT_TCP)
#endif    /* GCP_PROV_SCTP */
                                    newConnReqd = TRUE;
                          } /* comparison failed */
                        }
                        if( (PRSNT_NODEF == addr->u.dAddrPort.port.pres) &&
                           (peer->accessInfo.remotePort != 
                                          addr->u.dAddrPort.port.val) )
                        {
                           peer->accessInfo.remotePort = 
                                       addr->u.dAddrPort.port.val;


#ifdef    GCP_PROV_SCTP
                            if (((srvr) &&
                                 (srvr->transportType == LMG_TPT_TCP)) ||
                                (assoc))
#else     /* GCP_PROV_SCTP */
                           if (srvr->transportType == LMG_TPT_TCP)
#endif    /* GCP_PROV_SCTP */
                              newConnReqd = TRUE;
                        }
                     }
#ifdef   GCP_PROV_MTP3                  
                 else 
                 {
                    Dpc   newDpc;
                    MG_FILL_MTP_DPC_FRM_MID_TEXT(addr,newDpc);
                    /* Check if New Dpc and current Dpc in PeerCb is different */
                    if ( newDpc != peer->mgcoMtpCb.peerDpc)
                    {
                       /* Modify the Dpc Based Hash List i.e. First Delete the peerCb for old Dpc 
                        * Then Add for new Dpc .Also Update peerDpc in PeerCb */
                       cmHashListDelete(&(peer->tsap->mgcoMtpHlCp),(PTR)peer);      

                       peer->mgcoMtpCb.peerDpc = newDpc;

                       if(ROK != cmHashListInsert(&(peer->tsap->mgcoMtpHlCp), (PTR) peer,
                                (U8 *) &(peer->mgcoMtpCb.peerDpc), MG_DPC_LEN))
                          /* Should we give an alarm to layer   
                           * manager */
                          RETVALUE(RFAILED);

                    }
                 }
#endif    /* GCP_PROV_MTP3 */                  
 



                     /*
                      *   Negotiate MEGACO version even if this SvcChgReply
                      *   msg has SvcChgAddress parameter. There is no point
                      *   in continuing (or establishing a new) the association
                      *   with this MGC if MEGACO version can NOT be decided.
                      *
                      */
                     if (svcChg->u.svcChgReply->res.u.parm.ver.pres == PRSNT_NODEF)
                     {
                        MG_NEGOTIATE_VERSION_GWY_SIDE(svcChg->u.svcChgReply->\
                                                      res.u.parm.ver.val,
                                                      ssap,
                                                      peer,
                                                      errAction,
                                                      msgInfo)
                     }
                     /*else if (msgVer->pres == PRSNT_NODEF) */
                     if (msgVer->pres == PRSNT_NODEF)
                     {
                        MG_NEGOTIATE_VERSION_GWY_SIDE(msgVer->val,
                                                      ssap,
                                                      peer,
                                                      errAction,
                                                      msgInfo)
                     }


                     peer->accessInfo.peerflg |= MG_ASSOC_SUCC;
                     if (newConnReqd == TRUE)
                     {
                        MgSrvrInitInfo  info;
                        CmTptAddr       dstAddr;
                        MgTptSrvr       *newSrvr;

#ifdef    GCP_PROV_SCTP
                        if (assoc)
                           info.transportType = LMG_TPT_SCTP;
                        else      /* do NOT remove this comment */
#endif    /* GCP_PROV_SCTP */
                           info.transportType = LMG_TPT_TCP;


                        info.srvrType      = MG_TCP_CLIENT_CONNECTION;

                        if (srvr)
                           info.encodingScheme = srvr->encodingScheme;
#ifdef    GCP_PROV_SCTP
                        else
                           info.encodingScheme =
                                      assoc->tsap->endpCb.encodingScheme;
#endif    /* GCP_PROV_SCTP */


#ifdef ZG
                        info.suConnId = MG_INVALID_LSTNRID;
                        info.peerId = peer->accessInfo.peerId;
#endif /* ZG */
                        MG_FILL_TPTADDR_FRM_NETADDR(&dstAddr,
                                                    &(peer->accessInfo.\
                                                    peerAddrTbl.netAddr[0]));

                        MG_FILL_TPTADDR_PORT(&dstAddr, peer->\
                                             accessInfo.remotePort);


                        /* remove the old transport connection */

                        if (srvr)
                           mgSrvDiscReq(srvr, TRUE);
#ifdef    GCP_PROV_SCTP
                        else if (peer->assocCb->assocState
                                    == LMG_ASSOC_STATE_ACTIVE)
                        {
                           UConnId   spAssocId;

                           /*
                            *   The assocCb and the assocCfg would be freed
                            *   in the mgDeAllocAssocCb func called from SctTermCfm
                            */
         
                           spAssocId = peer->assocCb->spAssocId;


                           /*
                            *   set assoc state to DOWN which means that the
                            *   assoc is IN the PROCESS of tear-down. Once
                            *   SctTermCfm is received, the assocCb is reset
                            *   to NULLP.
                            *
                            *   The assoc state is set to WAIT_CFM if a Sct
                            *   assoc req is to be made after SctTermReq has
                            *   been sent but SctTermCfm has not been received
                            *   yet.
                            */

                           peer->assocCb->assocState = LMG_ASSOC_STATE_DOWN;

                           /*  peer->assocCb  = NULLP;  */

                           /*
                            *   Following is NOT to be done since assocCfg is
                            *   supposed to be freed in mgDeAllocPeerCb() -
                            *
                            *   peer->assocCfg = NULLP;
                            */

                           MgLiSctTermReq(&(peer->tsap->spPst),
                                          peer->tsap->tsapCfg.spId,
                                          spAssocId,
                                          SCT_ASSOCID_SP,
                                          FALSE);

                        }

                        if (info.transportType == LMG_TPT_SCTP)
                        {
                           U16   cntr;

                           /*
                            *   update the dst addr lst, pri dst addr
                            *   and the remote port in peer->assocCfg
                            */

                           peer->assocCfg->remPort =
                                 peer->accessInfo.remotePort;

                           peer->assocCfg->priDstAddr =
                                 peer->accessInfo.peerAddrTbl.netAddr[0];

                           /* mg002.105: remove compilation warning*/
                           peer->assocCfg->dstAddrLst.nmb =
                                 (U8)peer->accessInfo.peerAddrTbl.count;

                           for (cntr=0; cntr <
                                        peer->accessInfo.peerAddrTbl.count;
                                ++cntr)
                              peer->assocCfg->dstAddrLst.nAddr[cntr] =
                                 peer->accessInfo.peerAddrTbl.netAddr[cntr];

                           MG_INIT_SCTP_ASSOC(peer,ret);
                        }
                        else      /* do NOT remove this comment */
#endif    /* GCP_PROV_SCTP */
                        ret = mgAllocSrvrCb(&info, &dstAddr, NULLP, ssap, peer, 
                                 (Ptr *)&newSrvr, peer->tsap);


                        if (ret != ROK)
                        {
                           /* if is self initiated or user initiated
                           * service change, service change reply should
                           * not be given to service user, else user shall
                           * misinterpret it as a success */
                           mgBringPeerToCfgStatus(peer, TRUE);
                           mgIndicateAbortTxnToUsr(MGT_ERR_RESET_SSAP_TXN, 
                                             MG_INVALID_TRANSID, peer);
                           *errAction = MG_DISCARD_MSG;
                           ssap->crntMgc = NULLP;
#ifdef ZG
                           peer->bringToCfg =  TRUE;
                           zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                               CMPFTHA_ACTN_MOD);
                           zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
                               CMPFTHA_ACTN_MOD);
#endif /* ZG */
                           /* Should we give an alarm to layer   
                           * manager */
                           RETVALUE(RFAILED);
                        }
#ifdef ZG
                        ZG_INIT_RSETID_IN_MAPCB(&(newSrvr->mapCb));
                        zgAddMapping(ZG_CBTYPE_TPTSRVR, (Ptr)newSrvr);
                        zgRtUpd(ZG_CBTYPE_TPTSRVR,newSrvr,CMPFTHA_UPDTYPE_SYNC,
                           CMPFTHA_ACTN_ADD);
#endif /* ZG */


                        /*
                         *   for SCTP, the association was already
                         *   initiated above
                         */
                        if (info.transportType != LMG_TPT_SCTP)
                        {
                           /* Initiate a new connection */
                           peer->state = LMG_PEER_STATE_CONNECT;

                           /* mg008.105: mgSrvConReq need to be call after
                            * runtime update */
#ifdef ZG
                           zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                                   CMPFTHA_ACTN_MOD);
#endif /* ZG */
                           mgSrvConReq(newSrvr,
                                       &(peer->tsap->tsapCfg.reCfg.tptParam),
                                       peer->tsap,
                                       &dstAddr);
                        }
                        else
                        {
                           /* mg008.105: mgSrvConReq need to be call after
                            * runtime update */
#ifdef ZG
                           zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                                   CMPFTHA_ACTN_MOD);
#endif /* ZG */
                        }
                     }
                     else
                     {
                        peer->state = LMG_PEER_STATE_ACTIVE;
#ifdef ZG
                        zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                                CMPFTHA_ACTN_MOD);
#endif /* ZG */
						if(ssap != NULLP)                /*cdw add on 2006.9.29*/
							ssap->alarmIndSent = FALSE;  /*cdw add*/
                     }
                  } /* end of if for master */
               } /* service change address is available */
              /* 
               * If mgcIdToTry is present, try to find if the
               * peer is already existing in IP address based list/dname
               * basedlist. At this point since, we dont know the MID of the
               * new peer, we cant search based on MID of the new peer.
               */
               else if ((mid->type.pres == PRSNT_NODEF) &&
                        (svcChg->u.svcChgReply->res.u.parm.pres.pres == 
                                                                  PRSNT_NODEF))
               {
                  /* process incoming transaction */
                  if(updTxCb == TRUE)
                  {

                     if((mgPrcIncomingAck(txCb, &msgType, srvr, peer, transId, 
                                       MGT_MGCP_RSP_CODE_OK)) != ROK)

                     {
                        *errAction = MG_DISCARD_TXN;
                        RETVALUE(RFAILED);                     
                     }
                     updTxCb = FALSE;
                  }
#ifdef ZG_DFTHA
                  /* only master should do processing */
                  if(zgChkCRsetStatus())
#endif /* ZG_DFTHA */
                  {
                     CmTptAddr   newAddr;       /* Remote Transport Address */
                     U8          name[CM_DNS_DNAME_LEN];/* Peer Name */
                     Bool        sendUpd;
#ifdef GCP_PROV_MTP3                     
                     Dpc         peerDpc=0;
#endif
                     MG_FILL_TPTADDR_FRM_MID(&newAddr, mid, name);
#ifdef   GCP_PROV_MTP3
                     if (peer->accessInfo.transportType == LMG_TPT_MTP3)
                        newPeer = mgGetMtpPeer(mid, peer, &peerDpc);
                     else  
#endif   /* GCP_PROV_MTP3 */                        
                     /* Find if a peer exists with the provided mgcIdToTry */
                     newPeer = mgGetPeer(NULLP, &newAddr, name, 
                                         (MgSSAPCb *)ssap, &sendUpd); 

                     if ((newPeer == NULLP)
#ifdef   GCP_PROV_MTP3
                    && (peer->accessInfo.transportType != LMG_TPT_MTP3)
#endif   /* GCP_PROV_MTP3 */
                    )      /* Do not remove this brase */

                     {
                        /* Create a new Peer and initiate a new service change
                        * on this peer */
                        /* Initialise peerInit structure */
                        init.name[0] = '\0';
                        init.addrTbl.count = 0;
                        init.remotePort = LMG_INVALID_PEER_PORT;
   
               /*
                * For MTP3 TSAP Copy the peerDpc and tsap info to peerInfo structure
                */
#ifdef    GCP_PROV_MTP3      
                     if(peer->tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3)
                     {
                        /* Copy the Peer Point Code in the Init Structure */
                        init.peerDpc = peerDpc;
                        /* Copy the  Tsap as of current peer
                         * to Locate Hash List */
                        init.tsap   = peer->tsap; 
                     }
                     else
#endif    /* GCP_PROV_MTP3 */



#ifdef    GCP_PROV_SCTP
                        if (assoc && (assoc->assocCfg))
                        {
                           init.assocCfg   = *(assoc->assocCfg);
                           init.allocAssocCfg = TRUE;
                           init.remotePort = assoc->assocCfg->remPort;
                        }
#endif    /* GCP_PROV_SCTP */


#ifdef ZG
                        init.peerId = MG_INVALID_PEERID;
                        init.mtdPeerId = MG_INVALID_PEERID;
                        init.suConnId = MG_INVALID_LSTNRID;
#endif /* ZG */
                        if (mid->type.val == MGT_MID_DNAMEPORT)
                        {
                          cmMemcpy((U8 *)init.name, 
                            (U8 *)mid->u.dNamePort.name.val, CM_DNS_DNAME_LEN);
                          if (PRSNT_NODEF == mid->u.dNamePort.port.pres)
                          {
                            init.remotePort = mid->u.dNamePort.port.val;
                          }
                        }
                        else if (mid->type.val == MGT_MID_DADDRPORT)
                        {
                           if (ROK == mgGetIpAddrFromDomainNameStr(
                                     mid->u.dAddrPort.u.ipv4.len, 
                                     mid->u.dAddrPort.u.ipv4.val, &(address),
                                     LMG_PROTOCOL_MGCO)) 
                           {
                              cmMemcpy((U8 *) &(init.addrTbl.netAddr\
                                                [init.addrTbl.count]),
                                       (CONSTANT U8 *) &address,
                                       sizeof(CmNetAddr));

                              init.addrTbl.count++;

                              if(PRSNT_NODEF == mid->u.dAddrPort.port.pres) 
                              {
                                 init.remotePort = mid->u.dAddrPort.port.val;
                              }
                           }
                           else
                           {
                              RETVALUE(RFAILED);
                           }
                        }
#ifdef   GCP_PROV_MTP3                  
                       else if (mid->type.val == MGT_MID_MTPADDR)
                        {
                             MG_FILL_MTP_DPC_FRM_MID_TEXT(mid,init.peerDpc);
                        }
#endif    /* GCP_PROV_MTP3 */                  
                        /* Contact new MGC using the transportType of
                         * the existing MGC */



#ifdef    GCP_PROV_SCTP
                        if (srvr)
                           init.transportType     = srvr->transportType;
                        else
                           init.transportType     = LMG_TPT_SCTP;
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3               
                        if (srvr)
#endif   /* GCP_PROV_MTP3 */                  
#ifndef GCP_PROV_SCTP                        
                           init.transportType     = srvr->transportType;
#endif
#ifdef    GCP_PROV_MTP3               
                        if(peer->tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3)
                           init.transportType     = LMG_TPT_MTP3; /* new define */
#endif     /* GCP_PROV_MTP3 */




                        init.protocolType      = LMG_PROTOCOL_MGCO;
                        /* Initialize variant to be 
                         *            LMG_VER_PROF_MGCO_H248_1_0 
                         *            rather than 0 for MEGACO. */
#ifdef GCP_VER_1_5
                        init.variant           = LMG_VER_PROF_MGCO_H248_2_0;
#else                        
                        init.variant           = LMG_VER_PROF_MGCO_H248_1_0;
#endif
#ifdef    GCP_PROV_MTP3               
                        if(peer->tsap->tsapCfg.provType == LMG_PROV_TYPE_MTP3)
                        {
                           /* Copy the encoding scheme from the peerCb as New Peer will also 
                            * use the same encoding scheme */
                            
                           init.encodingScheme = peer->mgcoInfo.encodingScheme;
                        }
                        else
#endif     /* GCP_PROV_MTP3 */
 

                        if (srvr)
                           init.encodingScheme    = srvr->encodingScheme;
#ifdef    GCP_PROV_SCTP
                        else
                           init.encodingScheme    =
                                      assoc->tsap->endpCb.encodingScheme;
#endif    /* GCP_PROV_SCTP */


                        init.useAHScheme       = 0; 


                        /*
                         *   The current MEGACO version we used to try to
                         *   register with the current MGC should be used to
                         *   send the SvcChg to the new MGC.
                         */
                        init.mgcoVersion =
                           (peer->mgcoInfo.negotiatedVersion)
                                     | LMG_GET_MGCO_LMG_VER;


                        if (ssap->ssapCfg.reCfg.initRetxTmr.enb == TRUE)
                        {
                           init.initRtt = ssap->ssapCfg.reCfg.initRetxTmr.val;
                        }
                        else
                           init.initRtt = (MG_INIT_RTT_VALUE *
                                           mgCb.genCfg.timeRes);

                        init.trcLen            = MG_DEFAULT_TRC_LEN;
                        init.mtuSize           = (init.transportType == 
                                       LMG_TPT_UDP) ? 
                                       MG_MAX_UDP_MTU_SIZE : 
                                       MG_MAX_TCP_MTU_SIZE;
                        init.priority          = MG_INVALID_PRIORITY;
                        init.byCfg             = FALSE;


#ifdef    GCP_PROV_SCTP
                        {
                           U16      indx;

                           /*
                            * The following fields were copied from the original
                            * peer above -
                            *
                            * init.assocCfg.locOutStrms
                            *
                            * cmMemset((U8 *)&(init.assocCfg.srcAddrLst),
                            *          0, sizeof(SctNetAddrLst));
                            *
                            * So there is no need to fill them again;
                            *
                            * The only relevant fields which might have changed
                            * are the dstAddr(Lst) & the remotePort;
                            *
                            */

                           init.assocCfg.priDstAddr = init.addrTbl.netAddr[0];

                           /* mg002.105: remove compilation warning*/
                           init.assocCfg.dstAddrLst.nmb = (U8)init.addrTbl.count;

                           for (indx = 0; indx < init.addrTbl.count; ++indx)
                           {
                              init.assocCfg.dstAddrLst.nAddr[indx]
                                 = init.addrTbl.netAddr[indx];
                           }

                           init.assocCfg.remPort
                                = (init.remotePort == -1) ?
                                  MG_MGCO_DEFAULT_TEXT_PORT : (init.remotePort);

                           /* mg001.105: We are the GWY & we have received
                            *            SrvcChngReply with a new unknown
                            *            MGC specified in MgcIdToTry. So
                            *            use the tos configured in the
                            *            endpoint cfg */
                           init.tos = assoc->tsap->endpCb.defaultTos;
                        }
#endif    /* GCP_PROV_SCTP */



                        newPeer = mgAllocPeerCb(ssap, &init);
                        if (newPeer == NULLP)
                        {
                           /* Resource error */
                           /* Should we leave this peer and attempt other
                           * peers in the list or just give a failure to 
                           * LM */
                           RETVALUE(RFAILED);

                        }

                        /*
                         *  Initialize the tsap field of the peer -
                         *  Discovered Peer
                         */
                        newPeer->tsap = peer->tsap;



#ifdef ZG
                        ZG_INIT_RSETID_IN_MAPCB(&(newPeer->mapCb));
                        zgAddMapping(ZG_CBTYPE_PEER,(Ptr)newPeer);
                        zgRtUpd(ZG_CBTYPE_PEER, (Ptr)newPeer,
                           CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_ADD);
                        zgUpdPeer();
#endif /* ZG */
                        /* send request for resolution from DNS if 
                        * required */
                        ret = ROK;
                        if ((newPeer->accessInfo.peerAddrTbl.count == MG_NONE)
#ifdef   GCP_PROV_MTP3
                           && (newPeer->accessInfo.transportType != LMG_TPT_MTP3)
#endif   /* GCP_PROV_MTP3 */                           
                           )
                        {
                           newPeer->state = LMG_PEER_STATE_RESOLVING;
                           ret = mgSendDnsRslvReq(newPeer,
                                                  newPeer->accessInfo.name);
                        }
                        /* If the peer has been resolved we need 
                         *            to update the ssap counter also. */
                        else
                        {
                           ssap->numPeerRslvd++;
                        }
#ifdef ZG
                        zgRtUpd(ZG_CBTYPE_PEER, (Ptr)newPeer,
                           CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
                        if (ret == ROK)
                           ret = mgSendSrvcChng(newPeer, MGT_SVCCHGMETH_RESTART,
                                                MG_SCRSN_MGC_DIR_CHNG, NULLP,
                                                LMG_INVALID_PEER_PORT, NULLP);

                        if (ret != ROK)
                        {
                           /* Resource failure */
                           RETVALUE(RFAILED);
                        }

                        newPeer->accessInfo.peerflg |= MG_REDIRECTED_BY_MGC;
                        if (msgInfo & MG_SELF_INIT)
                        {
                           mgBringPeerToCfgStatus(peer, TRUE);
                           mgIndicateAbortTxnToUsr(MGT_ERR_RESET_SSAP_TXN, 
                                             MG_INVALID_TRANSID,
                                             peer);
                           /* mg008.105: changing form MG_DISCARD_MSG */
                           *errAction = MG_DISCARD_TXN;
#ifdef ZG
                           peer->bringToCfg =  TRUE;
                           zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer,
                              CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */

                        }
                        else
                        { 
                           /* user initiated service change */
                           /* Peer should be brought to config state
                           * User must understand this logic that new MGC
                           * is given, and stack is internally trying to
                           * contact new MGC */
                           *errAction = MG_DELETE_PEER_PASS_TXN;
                        }
#ifdef ZG
                        zgRtUpd(ZG_CBTYPE_PEER, (Ptr)newPeer,
                        CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
                     }
                     else
                     {
                        /* Peer is already available */
                        /* send service change to peer */


                        /*
                         *   The MEGACO version we used to send the SvcChg
                         *   to the current MGC should be used to send the
                         *   new SvcChg to the new MGC.
                         */

                        newPeer->mgcoInfo.negotiatedVersion =
                           peer->mgcoInfo.negotiatedVersion;


                        ret = mgSendSrvcChng(newPeer, MGT_SVCCHGMETH_RESTART,
                                             MG_SCRSN_MGC_DIR_CHNG, NULLP,
                                             LMG_INVALID_PEER_PORT, NULLP);

                        if (ret != ROK)
                        {
                           /* Resource failure */
                           RETVALUE(RFAILED);
                        }

                        newPeer->accessInfo.peerflg |= MG_REDIRECTED_BY_MGC;
                        if (msgInfo & MG_SELF_INIT)
                        {
                           mgBringPeerToCfgStatus(peer, TRUE);
                           mgIndicateAbortTxnToUsr(MGT_ERR_RESET_SSAP_TXN, 
                                             MG_INVALID_TRANSID,
                                             peer);
#ifdef ZG
                           peer->bringToCfg =  TRUE;
                           zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                              CMPFTHA_ACTN_ADD);
#endif /* ZG */
                           /* mg008.105: changing form MG_DISCARD_MSG */
                           *errAction = MG_DISCARD_TXN;
                        }
                        else
                        { 
                           /* user initiated service change */
                           /* Peer should be brought to config state
                           * User must understand this logic that new MGC
                           * is given, and stack is internally trying to
                           * contact new MGC */
                           *errAction = MG_DELETE_PEER_PASS_TXN;
                        }
                     } /* Peer already available */
                  } /* end of if (zgChkCRsetStatus) */
#ifdef ZG_DFTHA
                  else
                  {
                     /* Fill all the relevant information which should go into 
                      * reverse update */
                     mgSndRvUpdSvcRspP((srvr->suConnId), srcTptAddr, peer, 
                        (*msgVer), svcChg, msgInfo, MG_QUEUE_NONE);

                     if (msgInfo & MG_SELF_INIT)
                        *errAction = MG_DISCARD_MSG;
                     else
                        *errAction = MG_DELETE_PEER_PASS_TXN;
                  }
#endif /* ZG_DFTHA */
                  RETVALUE(RFAILED);
               } /* MgcId is available */
               else
               {
                  /* neither service change nor MGCId is available, 
                  * association is successful */
#ifdef ZG_DFTHA
                  if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
                     peer->state = LMG_PEER_STATE_ACTIVE;
					 if(ssap != NULLP)    				/*cdw add if on 2006.9.29*/
						ssap->alarmIndSent = FALSE;  	/*cdw add*/
               }
#ifdef ZG_DFTHA
               if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
               {
                  /* process incoming transaction */
                  if(updTxCb == TRUE)
                  {

                     if((mgPrcIncomingAck(txCb, &msgType, srvr, peer, transId, 
                                       MGT_MGCP_RSP_CODE_OK)) != ROK)

                     {
                        *errAction = MG_DISCARD_TXN;
                        RETVALUE(RFAILED);                     
                     }
                     updTxCb = FALSE;
                  }


                  /*
                   *   Negotiate MEGACO version.
                   */
                  if (svcChg->u.svcChgReply->res.u.parm.ver.pres == PRSNT_NODEF)
                  {
                     MG_NEGOTIATE_VERSION_GWY_SIDE(svcChg->u.svcChgReply->\
                                                   res.u.parm.ver.val,
                                                   ssap,
                                                   peer,
                                                   errAction,
                                                   msgInfo)
                  }
                  /*else if (msgVer->pres == PRSNT_NODEF) */
                  if (msgVer->pres == PRSNT_NODEF)
                  {
                     MG_NEGOTIATE_VERSION_GWY_SIDE(msgVer->val,
                                                   ssap,
                                                   peer,
                                                   errAction,
                                                   msgInfo)
                  }



                  /* update crntMgc */
                  ssap->crntMgc = peer;
                  /* The MG might have got disconnected with
                   * another MGC earlier. Now that successful association
                   * has been established with a peer, we can reset the 
                   * DISONNECTED in all peer control blocks if it is set. 
                   **/
                  MG_RESET_DISCON_BIT_IN_PEERLST(ssap);

                  /* If this is a case of handoff, move all transactions
                  * from old MGC to new MGC */
                  if (peer->accessInfo.peerflg & MG_HANDOFF_RQSTD)
                  {
                     peer->accessInfo.peerflg &= ~(MG_HANDOFF_RQSTD);
                     if(peer->mgcoInfo.t.undrHndOffMGC != NULL)
                     {
#ifdef ZG_DFTHA 
                     /* send update to all shadows to move txn in blocking mode
                      * since underHndOffMgc will be deleted; */
                        ZgProcUpdInfo   procUpdInfo;    /* info for sending procedural Rt upd*/

                        procUpdInfo.procType = ZG_PROCTYPE_MOVE_TRANS;
                        procUpdInfo.u.cntrlTrans.peerId = 
                           peer->mgcoInfo.t.undrHndOffMGC->accessInfo.peerId;
                        procUpdInfo.u.cntrlTrans.newPeerId = peer->accessInfo.peerId;
                        procUpdInfo.u.cntrlTrans.info.transType = MGT_ALL_TRANS;
                        procUpdInfo.u.cntrlTrans.source = MG_INTERNAL;
                        zgRtProcUpd(&procUpdInfo, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
                        zgUpdPeer();
#endif  /* ZG_DFTHA */
                        mgMoveAllTxn(peer->mgcoInfo.t.undrHndOffMGC, peer, 
                              MG_INTERNAL);
                        /* Should peer removal indication to be given to
                        * service user */
                        peer->mgcoInfo.t.undrHndOffMGC->mntInfo.usrKnows
                                  = FALSE; 

                        mgDeletePeer(peer->mgcoInfo.t.undrHndOffMGC,
                                     LMG_EVENT_PEER_REMOVED, LMG_CAUSE_HANDOFF,
                                     FALSE);
                        peer->mgcoInfo.t.undrHndOffMGC = NULLP;
                     }
                  }
                  else if (peer->accessInfo.peerflg & MG_REDIRECTED_BY_MGC)
                     peer->accessInfo.peerflg &= ~(MG_REDIRECTED_BY_MGC);
#ifdef ZG
                  zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_MOD);
                  zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_MOD);
#endif /* ZG */
               }


               if (msgInfo & MG_SELF_INIT)
               {
                  U32 ver = peer->mgcoInfo.negotiatedVersion;
/*                   
#ifdef GCP_VER_1_5
                  U32 ver = LMG_VER_PROF_MGCO_H248_2_0;
#else
                  U32 ver = LMG_VER_PROF_MGCO_H248_1_0;
#endif */
                  /* process incoming transaction */
                  if(updTxCb == TRUE)
                  {

                     if((mgPrcIncomingAck(txCb, &msgType, srvr, peer, transId, 
                                       MGT_MGCP_RSP_CODE_OK)) != ROK)
                     {
                        *errAction = MG_DISCARD_TXN;
                        RETVALUE(RFAILED);                     
                     }
                     updTxCb = FALSE;
                  }
                  /* 
                   * Self initiated service change, issue a StaInd
                   * towards service user to indicate association
                   * process is successful 
                   */
                  mgGenUserStaInd(peer, peer->ssap, MGT_STATUS_MGCO_VER, &ver);

                  /*mg002.105: Generate the alarm to layer manager that 
                     one of the peer responded*/
                  mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL,
                              LMG_EVENT_PEER_ENABLED, LCM_CAUSE_UNKNOWN,
                              LMG_ALARMINFO_PEER, NULLP, sizeof(MgPeerInfo),
                              peer->ssap->ssapCfg.sSAPId);

                  *errAction = MG_DISCARD_TXN;
#ifdef ZG_DFTHA
                  if(!((zgChkCRsetStatus()) == TRUE))
                  {
                     /* send reverse update*/
                     mgSndRvUpdSvcRspP((srvr->suConnId), srcTptAddr, peer, *msgVer, svcChg,
                                       msgInfo, MG_QUEUE_NONE);
                  }
#endif /* ZG_DFTHA */ 
                  RETVALUE(RFAILED);
               } /* self-init */
               else
               {
#ifdef ZG_DFTHA
                  /* In DFTHA case this message will be queued ..so return
                  * ROKDNA */
                  if(!((zgChkCRsetStatus()) == TRUE))
                  {
                     /* send reverse update*/
                     mgSndRvUpdSvcRspP((srvr->suConnId), srcTptAddr, peer, *msgVer, 
                                       svcChg, msgInfo, MG_PEER_INTXNQ);
                     RETVALUE(ROKDNA);
                  }
#else
                  /* process incoming transaction */
                  if(updTxCb == TRUE)
                  {
                     if((mgPrcIncomingAck(txCb, &msgType, srvr, peer, transId, 
                                       MGT_MGCP_RSP_CODE_OK)) != ROK)
                     {
                        *errAction = MG_DISCARD_TXN;
                        RETVALUE(RFAILED);                     
                     }
                     updTxCb = FALSE;
                  }
                  RETVALUE(ROK);
#endif /* ZG_DFTHA */
               } /* user initiated */
            } /* Service change reply is successful */       
            /*
            * SVC descriptor is optional in SVC reply. Change the
            * state to ACTIVE even if desc not present. It has already been
            * made sure that it is not error descriptor.
            */           
            else
            {
#ifdef ZG_DFTHA
               if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
               {
                  peer->state = LMG_PEER_STATE_ACTIVE;
                  /* The MG might have got disconnected with
                   * another MGC earlier. Now that successful association
                   * has been established with a peer, we can reset the 
                   * DISONNECTED in all peer control blocks if it is set. 
                   **/

                  /*
                   *   Negotiate MEGACO version.
                   */
                  if (svcChg->u.svcChgReply->res.u.parm.ver.pres == PRSNT_NODEF)
                  {
                     MG_NEGOTIATE_VERSION_GWY_SIDE(svcChg->u.svcChgReply->\
                                                   res.u.parm.ver.val,
                                                   ssap,
                                                   peer,
                                                   errAction,
                                                   msgInfo)
                  }
                  /* else if (msgVer->pres == PRSNT_NODEF) */
                  if (msgVer->pres == PRSNT_NODEF)
                  {
                     /* mg004.105: Bug fix for sending pending with V=1 */
                     /* Updated the correct version information in */
                     /* peer block */
                     MG_NEGOTIATE_VERSION_GWY_SIDE(peer->mgcoInfo.negotiatedVersion,
                                                   ssap,
                                                   peer,
                                                   errAction,
                                                   msgInfo)
                  }

                  ssap->crntMgc = peer;

                  MG_RESET_DISCON_BIT_IN_PEERLST(ssap);

                  /* Rest of the changes */

                  /*
                   *   If this is a case of handoff, move all
                   *   transactions from old MGC to new MGC
                   */
                  if (peer->accessInfo.peerflg & MG_HANDOFF_RQSTD)
                  {
                     peer->accessInfo.peerflg &= ~(MG_HANDOFF_RQSTD);
                     if(peer->mgcoInfo.t.undrHndOffMGC != NULL)
                     {
#ifdef ZG_DFTHA 
                     /*
                      *   send update to all shadows to move txn in
                      *   blocking mode since underHndOffMgc will be deleted;
                      */

                        /* info for sending procedural Rt upd*/
                        ZgProcUpdInfo   procUpdInfo;

                        procUpdInfo.procType = ZG_PROCTYPE_MOVE_TRANS;
                        procUpdInfo.u.cntrlTrans.peerId = 
                           peer->mgcoInfo.t.undrHndOffMGC->accessInfo.peerId;
                        procUpdInfo.u.cntrlTrans.newPeerId
                                     = peer->accessInfo.peerId;
                        procUpdInfo.u.cntrlTrans.info.transType = MGT_ALL_TRANS;
                        procUpdInfo.u.cntrlTrans.source = MG_INTERNAL;
                        zgRtProcUpd(&procUpdInfo,
                                    CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
                        zgUpdPeer();
#endif  /* ZG_DFTHA */
                        mgMoveAllTxn(peer->mgcoInfo.t.undrHndOffMGC, peer, 
                                     MG_INTERNAL);
                        /*
                         *   Should peer removal indication to be
                         *   given to service user
                         */
                        peer->mgcoInfo.t.undrHndOffMGC->mntInfo.usrKnows
                                         = FALSE; 

                        mgDeletePeer(peer->mgcoInfo.t.undrHndOffMGC,
                           LMG_EVENT_PEER_REMOVED, LMG_CAUSE_HANDOFF, FALSE);
                        peer->mgcoInfo.t.undrHndOffMGC = NULLP;
                     }
                  }
                  else if (peer->accessInfo.peerflg & MG_REDIRECTED_BY_MGC)
                     peer->accessInfo.peerflg &= ~(MG_REDIRECTED_BY_MGC);
#ifdef ZG
                  zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                          CMPFTHA_ACTN_MOD);
                  zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)ssap,CMPFTHA_UPDTYPE_SYNC,
                          CMPFTHA_ACTN_MOD);
#endif /* ZG */



                  if (msgInfo & MG_SELF_INIT)
                  {
                     U32 ver = peer->mgcoInfo.negotiatedVersion;
/*                     
#ifdef GCP_VER_1_5                    
                     U32 ver = LMG_VER_PROF_MGCO_H248_2_0;
#else
                     U32 ver = LMG_VER_PROF_MGCO_H248_1_0;
#endif */
                     /* process incoming transaction */
                     if(updTxCb == TRUE)
                     {
                        if((mgPrcIncomingAck(txCb, &msgType, srvr,
                                             peer, transId, 
                                             MGT_MGCP_RSP_CODE_OK)) != ROK)
                        {
                           *errAction = MG_DISCARD_TXN;
                           RETVALUE(RFAILED);                     
                        }
                        updTxCb = FALSE;
                     }

                     /*mg002.105: Generate the alarm to layer manager that 
                              one of the peer responded*/
                     mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL,
                                 LMG_EVENT_PEER_ENABLED, LCM_CAUSE_UNKNOWN,
                                 LMG_ALARMINFO_PEER, NULLP, sizeof(MgPeerInfo),
                                 peer->ssap->ssapCfg.sSAPId);

                     mgGenUserStaInd(peer, peer->ssap, MGT_STATUS_MGCO_VER,
                           &ver);
                     *errAction = MG_DISCARD_TXN;
#ifdef ZG_DFTHA
                     if(!((zgChkCRsetStatus()) == TRUE))
                     {
                        /* send reverse update*/
                        mgSndRvUpdSvcRspP((srvr->suConnId), srcTptAddr,
                                          peer, *msgVer, svcChg,
                                          msgInfo, MG_QUEUE_NONE);
                     }
#endif /* ZG_DFTHA */ 
                     RETVALUE(RFAILED);
                  }
#ifdef ZG
                  zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                     CMPFTHA_ACTN_MOD);
#endif /* ZG */
               }
#ifdef ZG_DFTHA
               else
               {
                  /* send reverse update*/
                  mgSndRvUpdSvcRspP((srvr->suConnId), srcTptAddr, peer, *msgVer, 
                                       svcChg, msgInfo, MG_PEER_INTXNQ);
                  RETVALUE(ROKDNA);
               }
#endif /* ZG_DFTHA */
            }
         } /* Peer state is REGISTER */
         else
         {
            if (((msgInfo & MG_FAILOVER) || (msgInfo & MG_FORCED)) &&
                (msgInfo & MG_LM_INIT))
            {
               /* Layer manager initiated request for Failover or
                * forced */
               /* Report result to LM via ALARM */
               U16  event;         

               /* process incoming transaction */
               if (updTxCb == TRUE)
               {

                  if((mgPrcIncomingAck(txCb, &msgType, srvr, peer, transId, 
                                    MGT_MGCP_RSP_CODE_OK)) != ROK)
                  {
                     *errAction = MG_DISCARD_TXN;
                     RETVALUE(RFAILED);                     
                  }
                  updTxCb = FALSE;
               }


               /*
                *   Negotiate MEGACO version.
                */
               if (svcChg->u.svcChgReply->res.u.parm.ver.pres == PRSNT_NODEF)
               {
                  MG_NEGOTIATE_VERSION_GWY_SIDE(svcChg->u.svcChgReply->\
                                                res.u.parm.ver.val,
                                                ssap,
                                                peer,
                                                errAction,
                                                msgInfo)
               }
               /*else if (msgVer->pres == PRSNT_NODEF) */
               if (msgVer->pres == PRSNT_NODEF)
               {
                  MG_NEGOTIATE_VERSION_GWY_SIDE(msgVer->val,
                                                ssap,
                                                peer,
                                                errAction,
                                                msgInfo)
               }


               if ((svcChg->u.svcChgReply->res.type.pres == PRSNT_NODEF)
                  && (svcChg->u.svcChgReply->res.type.val == 
                  MGT_ERRDESC))
               {
                  event = LMG_EVENT_AFAILOVER_FAILURE;
               }
               else
                  event = LMG_EVENT_AFAILOVER_SUCCESS;

               /* Use the MGCO specific macro */
               MG_ISSUE_MGCOPEER_STAIND(peer, LCM_CATEGORY_PROTOCOL, event, 
                  LMG_CAUSE_MGMT_INITIATED);

               *errAction = MG_DISCARD_TXN;
               RETVALUE(RFAILED);
            }
         }
      } /* Service change reply is for restart */
#endif /* GCP_MG */
   } /* MG related processing */

   /* process incoming transaction */
   if(updTxCb == TRUE)
   {

      if((mgPrcIncomingAck(txCb, &msgType, srvr, peer, transId, 
                        MGT_MGCP_RSP_CODE_OK)) != ROK)
      {
         *errAction = MG_DISCARD_TXN;
         RETVALUE(RFAILED);                     
      }
      updTxCb = FALSE;
   }
   RETVALUE(ROK);
} /* end of mgProcessSrvcChngReply () */

/*
*
*       Fun:    mgPrcUserRegRsp
*
*       Desc:   This function processes the service change reply message 
*               generated by user. This function is only required in case of 
*               processing at MGC. 
*               MGCP : rsp --> MgMgcpRsp
*               MEGACO : rsp -> MgSvcChgInfo
*
*
*       Ret:    ROK - SUCCESS
*               RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_peer.c
*/

#ifdef ANSI
PUBLIC S16 mgPrcUserRegRsp
(
MgPeerCb           *peer,              /* Peer Control Block */
MgRxTransIdEnt     *rxCb,              /* Txn Control Block */
Ptr                rsp                 /* MEGACO or MGCP Response */
)
#else
PUBLIC S16 mgPrcUserRegRsp(peer, rxCb, rsp)
MgPeerCb           *peer;              /* Peer Control Block */
MgRxTransIdEnt     *rxCb;              /* Txn Control Block */
Ptr                rsp;                /* MEGACO or MGCP Response */
#endif

{
   S16             ret;                /* Return Value */
   MgTptSrvr       *srvr;              /* redirection server */
   MgSvcChgInfo    *svcChgInfo;        /* Service Change Information */

#ifdef GCP_MGC
   U8              idx;                /* Index */
   S16             match;              /* Service Change Address matches MID? */
#endif /* GCP_MGC */

   Bool            isMaster;           /* whether this is master ?? */
   Bool            genRvUpd;           /* Generate Reverse Update?? */
#ifdef ZG_DFTHA
   S32             lclPort;            /* local port */
#endif /* ZG_DFTHA */


   TRC2(mgPrcUserRegRsp)


#if (ERRCLASS & ERRCLS_DEBUG)
   if (peer->mntInfo.protocolType != LMG_PROTOCOL_MGCO)
      RETVALUE(RFAILED);
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   isMaster = TRUE; 
   genRvUpd = FALSE;
#ifdef ZG_DFTHA
   lclPort  = LMG_INVALID_PEER_PORT;
   /* Find out whether critical rSet present with this copy */
   if(!((zgChkCRsetStatus()) == TRUE))
      isMaster = FALSE;
#endif /* ZG_DFTHA */

   srvr      = NULLP;
   svcChgInfo = (MgSvcChgInfo *)rsp;

/*TODO_MAH */   
      if (NOTPRSNT != svcChgInfo->u.svcChgReply->pres.pres)
        if (NOTPRSNT != svcChgInfo->u.svcChgReply->res.u.parm.pres.pres)
           if (NOTPRSNT != svcChgInfo->u.svcChgReply->res.u.parm.ver.pres)

   {
           if ((peer->ssap->ssapCfg.minMgcoVersion > \
                 svcChgInfo->u.svcChgReply->res.u.parm.ver.val)  || \
                 (svcChgInfo->u.svcChgReply->res.u.parm.ver.val >\
             (peer->ssap->ssapCfg.maxMgcoVersion) ))
          RETVALUE(RFAILED);
   
   } 
   /* 
    * In case of service change reply, we only need to
    * process the case when restart or failover or handoff
    * is being issued : A case of new peer being acknowledged
    * by service user 
    */
   if ((mgCb.genCfg.entType == LMG_ENT_GC) &&
       (peer->state == LMG_PEER_STATE_REGISTER) &&
       ((rxCb->regCmdMethod == MGT_SVCCHGMETH_RESTART) ||
        (rxCb->regCmdMethod == MGT_SVCCHGMETH_FAILOVER) ||
        (rxCb->regCmdMethod == MGT_SVCCHGMETH_DISCON) ||
        (rxCb->regCmdMethod == MGT_SVCCHGMETH_HANDOFF)))
   {
#ifdef GCP_MGC
      if ((svcChgInfo->u.svcChgReply->pres.pres == PRSNT_NODEF) &&
          (svcChgInfo->u.svcChgReply->res.type.pres == PRSNT_NODEF) &&
          (svcChgInfo->u.svcChgReply->res.type.val == MGT_ERRDESC))
      {
         /* 
          * Service change reply is an error, This peer should 
          * be deleted after 30 seconds 
          * Start Delete Peer timer 
          */
         if(isMaster == TRUE)
         {
            peer->state = LMG_PEER_STATE_AWAIT_REG;
            idx = MG_DEL_PEER_TMR - MG_PEER_TMR_BASE;
            if (peer->ssap->ssapCfg.reCfg.atMostOnceTmr.enb == TRUE)
            {
#ifdef ZG
               peer->delPeerTmr = TRUE;
#endif /* ZG */
               mgStartTmr(MG_DEL_PEER_TMR, 
                        peer->ssap->ssapCfg.reCfg.atMostOnceTmr.val,
                        (PTR)peer, &(peer->mntInfo.tmr[idx]));
            }
#ifdef ZG
             zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
                        CMPFTHA_ACTN_MOD);
#endif /* ZG */
         }
         else
         {
#ifdef ZG_DFTHA
            /* generate reverse update  */
            ZgRvUpdInfo      rvUpdInfo;
            MG_FILL_RVUPD_SVCRSP_USR(rvUpdInfo,(peer->accessInfo.peerId), 
               (rxCb->regCmdMethod), (rxCb->suConnId), lclPort, (svcChgInfo));
            /* call pldf fn to send reverse update */
            peer->tsap->rvNode = 
                 (MgRvUpdQNode *)zgReverseUpd(&rvUpdInfo,
                                              peer->accessInfo.peerId,
                                              MG_QUEUE_NONE,
                                              peer->tsap->tsapCfg.tSAPId);
            RETVALUE(ROK);
#endif /* ZG_DFTHA */
         }

         RETVALUE(ROK);
      }

      if ((svcChgInfo->u.svcChgReply->pres.pres == PRSNT_NODEF) &&
          (svcChgInfo->u.svcChgReply->res.type.pres == PRSNT_NODEF) &&
          (svcChgInfo->u.svcChgReply->res.type.val == MGT_SVCCHGDESC))
      {
         /* Service change reply is success for restart */
         /* Check whether redirection is required */
         MgMgcoMid *addr = &(svcChgInfo->u.svcChgReply->res.u.parm.addr);
         if(isMaster == TRUE)
         {
            /* Only master should update critical information */
            peer->state = LMG_PEER_STATE_ACTIVE;
			if (peer->ssap != NULLP)               /*cdw add on 2006.9.28*/
                peer->ssap->alarmIndSent=FALSE;	   /*cdw add*/	
			
            if ((rxCb->regCmdMethod == MGT_SVCCHGMETH_HANDOFF) &&
               (peer->ssap->ssapCfg.reCfg.atMostOnceTmr.enb == TRUE))
            {
               /* If service change is received with handoff, 
               * start handoff timer and set the flag in PeerCb */
               peer->mgcoInfo.hndOffInProg = TRUE;
               idx = MG_HANDOFF_TMR - MG_PEER_TMR_BASE;
               mgStartTmr(MG_HANDOFF_TMR, 
                        peer->ssap->ssapCfg.reCfg.atMostOnceTmr.val, 
                        (PTR)peer, &(peer->mntInfo.tmr[idx]));
            }
         }

         if ((addr->type.pres == PRSNT_NODEF) &&
            (svcChgInfo->u.svcChgReply->res.u.parm.pres.pres == PRSNT_NODEF))
         {
            /*
             * Dont allow redirection in case of TCP. Redirection is useful
             * only with UDP.
             * should we allow redirection for SCTP? - NO (?)
             * Do not allow redirection in case of MTP3 as we are not sure
             * whether point code and linkset is configured by lower layer or not
             */

            if (
#ifdef   GCP_PROV_MTP3
                  (LMG_TPT_MTP3 == peer->accessInfo.transportType) ||
#endif   /* GCP_PROV_MTP3 */
#ifdef   GCP_PROV_SCTP
                  (LMG_TPT_SCTP == peer->accessInfo.transportType) ||
#endif /* GCP_PROV_SCTP */
                  (LMG_TPT_TCP == peer->accessInfo.transportType))
            {
               addr->type.pres = NOTPRSNT;
               addr->type.val = 0;
            }
            else /* UDP */
            {
               /* 
                * Indicates that service change address is present 
                * Check whether address matches the MId configured with SSAP,
                * compare IPV4/IPV6 address or domain name whichever
           * is applicable
                */
               match = mgMatchMId(peer, addr);
               if (match == MG_IGNORE)
               {
                  /* return value is MG_IGNORE, indicates that 
                     port is available */
                  /* copy port information */
                  /* Should user give the port number */
                  if (addr->type.val == MGT_MID_PORT)
                  {
                     if(isMaster == TRUE)
                        peer->mgcoInfo.lclSrvcChngPort = addr->u.port.val;

#ifdef ZG_DFTHA
                     lclPort = addr->u.port.val;
#endif /* ZG_DFTHA */
                  }
               }
            } /* UDP */
          } /* service change address present in the message */
          else if ((svcChgInfo->u.svcChgReply->res.u.parm.mgcId.type.pres == 
                   PRSNT_NODEF)&&(isMaster == TRUE))
          {

             /* mgcId is available , delete the peer after 30 seconds */
             peer->state = LMG_PEER_STATE_AWAIT_REG;
             idx = MG_DEL_PEER_TMR - MG_PEER_TMR_BASE;
             if (peer->ssap->ssapCfg.reCfg.atMostOnceTmr.enb == TRUE)
             {
#ifdef ZG
                 peer->delPeerTmr = TRUE;
#endif /* ZG */
                 mgStartTmr(MG_DEL_PEER_TMR, 
                            peer->ssap->ssapCfg.reCfg.atMostOnceTmr.val,
                            (PTR)peer, &(peer->mntInfo.tmr[idx]));
             }
          }
          else 
          {
             U16 tptPort;
             /*
              * Use redirection servers only in case of UDP. In case of TCP,
              * there is no need for re-direction if service Change address &
              * mgcId are not present. Removed all code which was for the TCP
              * case.
              */
             if (peer->accessInfo.transportType == 
                          LMG_TPT_UDP)
             {
                /* case of UDP */
                srvr = peer->tsap->mgcoUDPSrvrLst.nxtSrvr2Use;
                peer->tsap->mgcoUDPSrvrLst.nxtSrvr2Use = 
                              mgGetSrvrForRedirection(LMG_TPT_UDP,
                                                      peer->tsap);
             }
             else 
               srvr = NULLP;
             if (srvr != NULLP)
                MG_FILL_PORT_FRM_TPTADDR(tptPort, &(srvr->tptAddr));
             if ((srvr != NULLP) &&
                 (tptPort != peer->mgcoInfo.origSrvcChngPort))
             {
                svcChgInfo->u.svcChgReply->res.u.parm.pres.pres = PRSNT_NODEF;
                addr->type.pres = PRSNT_NODEF;
                addr->type.val = MGT_MID_PORT;
                addr->u.port.pres = PRSNT_NODEF;
                addr->u.port.val = tptPort;
                if (isMaster == TRUE)
                   peer->mgcoInfo.lclSrvcChngPort = tptPort;
#ifdef ZG_DFTHA
                lclPort = tptPort;
#endif /* ZG_DFTHA */
             }
          } /* service change address and MId are not present */
#ifdef ZG
#ifdef ZG_DFTHA
          /* generate reverse update if this is not master copy..else generate
           * state update for peer */
         if((isMaster == FALSE) && (peer->state != LMG_PEER_STATE_ACTIVE))
         {
            /* generate reverse update and return ROKDNA..*/
            ZgRvUpdInfo      rvUpdInfo;

            MG_FILL_RVUPD_SVCRSP_USR(rvUpdInfo,(peer->accessInfo.peerId), 
               (rxCb->regCmdMethod), (rxCb->suConnId), lclPort, (svcChgInfo));
            /* call pldf fn to send reverse update */
            peer->tsap->rvNode = 
                 (MgRvUpdQNode *)zgReverseUpd(&rvUpdInfo,
                                              peer->accessInfo.peerId,
                                              MG_QUEUE_NONE,
                                              peer->tsap->tsapCfg.tSAPId);
            RETVALUE(ROK);
         }
         else
#endif /* ZG_DFTHA */
         {
            zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_MOD);
         }
#endif /* ZG */

          RETVALUE(ROK);
       } /* case of successful service change reply */
#endif /* GCP_MGC */
    } /* service change reply for restart at MGC */
    else if ((mgCb.genCfg.entType == LMG_ENT_GW) &&
       (peer->state == LMG_PEER_STATE_UNDR_HNDOFF) &&
       (rxCb->regCmdMethod == MGT_SVCCHGMETH_HANDOFF))
    {
      if(isMaster == TRUE)
      {
         /* Response from service user for an earlier handoff request 
         * sent by peer */
         if ((svcChgInfo->u.svcChgReply->pres.pres == PRSNT_NODEF) &&
            (svcChgInfo->u.svcChgReply->res.type.pres == PRSNT_NODEF) &&
            (svcChgInfo->u.svcChgReply->res.type.val == MGT_ERRDESC))
         {
            /* Service user rejected handoff */
            /* In this case we should delete the new peer and just carry on 
            * with the current peer */
            if (peer->mgcoInfo.t.handOffMGC != NULLP)
            {
               mgDeletePeer(peer->mgcoInfo.t.handOffMGC, LMG_EVENT_PEER_REMOVED,
                           LMG_CAUSE_HANDOFF,
                           FALSE);
            }
            peer->state = LMG_PEER_STATE_ACTIVE;
			if(peer->ssap != NULLP)           /*cdw add on 2006.9.29*/
                peer->ssap->alarmIndSent=FALSE;   /*cdw add*/
            peer->mgcoInfo.t.handOffMGC = NULLP;
#ifdef ZG
            zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_MOD);
#endif /* ZG */
         }
         else
         {
            MgPeerCb  *hndOffPeer;
            U8        *scReason;        /* service change reason */

            /* initiate handoff procedure */
            hndOffPeer = peer->mgcoInfo.t.handOffMGC;
            /* send request for resolution from DNS if required */
            ret = ROK;

            /* hndOffPeer may be NULL if MG selected the HandOff MGC.
             * So check for hndOffPeer == NULL. Also the reason for Service
             * Change Handoff should be ImpendingFailure if no MgcId was
             * specified in the initial handoff request */
            if (hndOffPeer != NULLP)
            {
               /* move resolution procedure */
               if (hndOffPeer->accessInfo.peerAddrTbl.count == MG_NONE)
               {
                  hndOffPeer->state = LMG_PEER_STATE_RESOLVING;
                  ret = mgSendDnsRslvReq(hndOffPeer,
                                         hndOffPeer->accessInfo.name);

#ifdef ZG
                  zgRtUpd(ZG_CBTYPE_PEER, (Ptr)hndOffPeer, CMPFTHA_UPDTYPE_SYNC,
                    CMPFTHA_ACTN_MOD);
#endif /* ZG */
               }
               if (ret == ROK)
               {
                  if(hndOffPeer->accessInfo.peerflg & MG_HANDOFF_RQSTD_NO_MGCID)
                  {
                     scReason = MG_SCRSN_MGC_IMPN_FAIL;
                  }
                  else
                  {
                     scReason = MG_SCRSN_MGC_DIR_CHNG;
                  }
                  ret = mgSendSrvcChng(hndOffPeer, MGT_SVCCHGMETH_HANDOFF,
                                       scReason, NULLP,
                                       LMG_INVALID_PEER_PORT,
                                       NULLP);
               }
               if (ret != ROK)
               {
                  /* Resource failure */
                  RETVALUE(RFAILED);
               }
            } /* handOff peer is not NULL */
         } /* Service Change Response is not in Error */
      } /* Is Master?? */
      else
      {
         /* Generate Reverse Update */
         genRvUpd = TRUE;
      }
   } /* handoff case at MG */
   else if ((mgCb.genCfg.entType == LMG_ENT_GC) &&
            (peer->state == LMG_PEER_STATE_FAILOVER) &&
            (rxCb->regCmdMethod == MGT_SVCCHGMETH_FAILOVER))
   {
#ifdef GCP_MGC
      MgPeerCb   *matedPeer = peer->mgcoInfo.t.matedMG;
      /* active MG indicated that it is failing */
      if ((peer->mgcoInfo.peerType == MG_ACTIVE) &&
         (matedPeer != NULLP) &&
         (matedPeer->mgcoInfo.peerType == MG_STANDBY))
      {
         if(isMaster == TRUE)
         {
            if (matedPeer->state == LMG_PEER_STATE_ACTIVE)
            {
               /* keep association with standby peer and
               * make standby peer active and vice versa 
               * , so all new requests
               * and replies to existing requests go to
               * standby peer only */
               peer->mgcoInfo.peerType = MG_STANDBY;
               matedPeer->mgcoInfo.peerType = MG_ACTIVE;
               mgMoveAllTxn(peer, matedPeer, MG_INTERNAL);
               peer->state = LMG_PEER_STATE_AWAIT_REG;
#ifdef ZG
               /* Send update for peer */
               peer->removeAllTxns = FALSE;
               zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_MOD);
#ifdef ZG_DFTHA
               /* send update to all shadows to move txn */
               {
                  ZgProcUpdInfo    procUpdInfo;     /* info for sending procedural Rt update */

                  procUpdInfo.procType = ZG_PROCTYPE_MOVE_TRANS;
                  procUpdInfo.u.cntrlTrans.peerId = peer->accessInfo.peerId;
                  procUpdInfo.u.cntrlTrans.newPeerId = matedPeer->accessInfo.peerId;
                  procUpdInfo.u.cntrlTrans.source = MG_INTERNAL;
                  procUpdInfo.u.cntrlTrans.info.transType = MGT_ALL_TRANS;
                  zgRtProcUpd(&procUpdInfo, CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);
               }
#endif /* ZG_DFTHA */
#endif /* ZG */
            }
            else
            {
               /* Other peer is not ready to take over,
               * delete both peers */
               mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED,
                            LMG_CAUSE_UNKNOWN,
                            FALSE);
               mgDeletePeer(matedPeer, LMG_EVENT_PEER_REMOVED,
                            LMG_CAUSE_UNKNOWN,
                            FALSE);
            }
         }
         else
         {
            genRvUpd = TRUE;
         }
      }
#endif /* GCP_MGC */
   } /* failover case for active MG */
#ifdef ZG_DFTHA
   if((isMaster == FALSE) && (genRvUpd == TRUE))
   {
      /* Now send reverse update to Master..return ROK..txn won't be queued */
      ZgRvUpdInfo      rvUpdInfo;

      MG_FILL_RVUPD_SVCRSP_USR(rvUpdInfo,(peer->accessInfo.peerId), 
           (rxCb->regCmdMethod), (rxCb->suConnId), lclPort, (svcChgInfo));
      /* call pldf fn to send reverse update */
      peer->tsap->rvNode = 
           (MgRvUpdQNode *)zgReverseUpd(&rvUpdInfo,
                                        peer->accessInfo.peerId,
                                        MG_QUEUE_NONE,
                                        peer->tsap->tsapCfg.tSAPId);
      RETVALUE(ROK);
   }
#endif /* ZG_DFTHA */
   RETVALUE(ROK);

} /* end of mgPrcUserRegRsp () */



#ifdef GCP_MG
/*
*
*       Fun:    mgPrcUserSrvcChng
*
*       Desc:   This function processes the service change message 
*               generated by user. This function is only required in 
*               case of processing at MG.
*
*       Ret:    ROK - SUCCESS
*               RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC S16 mgPrcUserSrvcChng
(
MgPeerCb           *peer,              /* Peer Control Block */
MgSvcChgInfo       *svcChgInfo         /* Service Change Info */
)
#else
PUBLIC S16 mgPrcUserSrvcChng(peer, svcChgInfo)
MgPeerCb           *peer;              /* Peer Control Block */
MgSvcChgInfo       *svcChgInfo;        /* Service Change Info */
#endif
{
   MgMgcoMid       *addr;              /* Service Change Address */
   U16             idx;                /* Index */
   S16             ret;                /* return value */

   TRC2(mgPrcUserSrvcChng)

   addr = &(svcChgInfo->u.svcChgReq->parm.addr);

   ret = ROK;

   /* 
    * In case of service change, we only need to process the case when restart 
    * is being issued in AWAIT_REG_STATE 
    */
   if (peer->state == LMG_PEER_STATE_AWAIT_REG)
   {
#ifdef   GCP_PROV_MTP3

      if (peer->accessInfo.transportType == LMG_TPT_MTP3)
      {
         if ((svcChgInfo->u.svcChgReq->parm.pres.pres == PRSNT_NODEF) &&
            (addr->type.pres == PRSNT_NODEF))
         {
            /* Normally service change address should not be
             * specified by service user because service user 
             * normally won't be aware of the MTP Address */
               RETVALUE(RFAILED);
         }

         peer->accessInfo.peerflg |= MG_USER_INITIATED_REG;
         peer->state = LMG_PEER_STATE_REGISTER;

      }
      else
#endif   /* GCP_PROV_MTP3 */      
      if (peer->accessInfo.transportType == LMG_TPT_UDP)
      {
         if ((svcChgInfo->u.svcChgReq->parm.pres.pres == PRSNT_NODEF) &&
            (addr->type.pres == PRSNT_NODEF))
         {
            /* Normally service change address should not be
             * specified by service user because service user 
             * normally won't be aware of the port numbers */
            if (addr->type.val != MGT_MID_PORT)
               RETVALUE(RFAILED);
         }
         /* check whether service change address information 
          * is to be added */
         peer->accessInfo.peerflg |= MG_USER_INITIATED_REG;
         if ((addr->type.pres == NOTPRSNT) &&
             (peer->ssap->nxtUseMgcoSrvr != NULLP))
         {
            svcChgInfo->u.svcChgReq->parm.pres.pres = PRSNT_NODEF;
            /* servers are available on SSAP */
            addr->type.pres = PRSNT_NODEF;
            addr->type.val = MGT_MID_PORT;
            addr->u.port.pres = PRSNT_NODEF;
            /* nxtUse is used here because it doesnot matter which 
             * server we choose as long as it is on SSAP */
            MG_FILL_PORT_FRM_TPTADDR(addr->u.port.val,  
                                     &(peer->ssap->nxtUseMgcoSrvr->tptAddr));
         }
#ifdef ZG_DFTHA
         if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
            peer->state = LMG_PEER_STATE_REGISTER;
#ifdef ZG_DFTHA
         else
            ret = ROKDNA;
#endif /* ZG_DFTHA */
      }
      else
      {
         /* No service change address should be sent in case of TCP */
         if ((svcChgInfo->u.svcChgReq->parm.pres.pres == PRSNT_NODEF) &&
             (addr->type.pres == PRSNT_NODEF))
            RETVALUE(RFAILED);
         /* TCP connection request shall be initiated when processing
          * of transaction request is completed */
#ifdef ZG_DFTHA
         if(((zgChkCRsetStatus()) != TRUE))
         {
            RETVALUE(ROKDNA);
         }
#endif /* ZG_DFTHA */
      }
#ifdef ZG_DFTHA
      if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
      {
         /* stop restart timer if running */
         idx = MG_RST_AVLNCH_TMR - MG_PEER_TMR_BASE;

         if (peer->mntInfo.tmr[idx].tmrEvnt == MG_RST_AVLNCH_TMR)
            mgStopTmr(MG_RST_AVLNCH_TMR, (PTR)peer, &(peer->mntInfo.tmr[idx]));
         peer->ssap->crntMgc = peer;
      }
#ifdef ZG
#ifdef ZG_DFTHA
      /* 
       * If this master then it should generate state update for 
       * peer and ssap 
       */
      if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
      {
         zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC, 
                CMPFTHA_ACTN_MOD);
         zgRtUpd(ZG_CBTYPE_SSAP, (Ptr)(peer->ssap), CMPFTHA_UPDTYPE_SYNC, 
                CMPFTHA_ACTN_MOD);
         zgUpdPeer();
      }
#endif
   }
   RETVALUE(ret);

} /* end of mgPrcUserSrvcChng () */

#endif /* GCP_MG */

/*
*
*       Fun:    mgPrcPeerConInd 
*
*       Desc:   This function processes the TCP connection received from peer.
*               This function is only applicable for a MGC supporting MEGACO
*               protocol.
*
*       Ret:    ROK - SUCCESS
*               RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC S16 mgPrcPeerConInd
(
MgTptSrvr          *srvrCb,            /* Server Control Block */
MgTSAPCb           *tsap,              /* TSAP Control Block */
MgTptSrvr          *lclSrvr            /* Server on which connection was rcvd */
)
#else
PUBLIC S16 mgPrcPeerConInd(srvrCb, tsap, lclSrvr)
MgTptSrvr          *srvrCb;            /* Server Control Block */
MgTSAPCb           *tsap;              /* TSAP Control Block */
MgTptSrvr          *lclSrvr;           /* Server on which connection was rcvd */
#endif
{
#ifdef GCP_MGC
   TRC2(mgPrcPeerConInd)

   /* 
    * Since TCP redirection is no longer permitted by the stack, receipt of a
    * ConInd implies that a new peer is trying to contct us. It is not
    * possible to have a existing peer trying to make a TCP connection.
    * Modified code for that.
    */
    if (lclSrvr->srvrType == MG_ROUND_ROBIN_SRVR_MGCO)
    {
       /* connection received on unexpected server or peer not available */
       RETVALUE(RFAILED);
    }
    else
    {
       if (tsap->tsapCfg.reCfg.idleTmr.enb == TRUE)
          mgStartTmr(MG_IDLE_CONN_TMR, 
                     tsap->tsapCfg.reCfg.idleTmr.val,
                     (PTR)srvrCb, &(srvrCb->idleTmr));
          RETVALUE(ROK);
    }

#else 
    RETVALUE(RFAILED);
#endif /* GCP_MGC */

} /* end of mgPrcPeerConInd () */

/*
*
*       Fun:    mgPrcPeerConCfm 
*
*       Desc:   This function processes the TCP connection confirmation
*               This function is only applicable for a MGC supporting 
*               MEGACO protocol.
*
*       Ret:    ROK - SUCCESS
*               RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC S16 mgPrcPeerConCfm
(
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PUBLIC S16 mgPrcPeerConCfm(peer)
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
   TRC2(mgPrcPeerConCfm)

   if (peer->state == LMG_PEER_STATE_CONNECT)
   {
      if (peer->accessInfo.peerflg & MG_ASSOC_SUCC)
      {
         peer->state = LMG_PEER_STATE_ACTIVE;
      }
      else
         peer->state = LMG_PEER_STATE_REGISTER;

      /* send all message queued */
      mgTxQueueMsg(peer);
   }

#ifdef   GCP_PROV_MTP3
   if (LMG_TPT_MTP3 == peer->accessInfo.transportType)
   {
      if ((peer->mgcoMtpCb.status & SP_ONLINE)
         && (peer->accessInfo.peerflg & MG_ASSOC_SUCC))
      {
         peer->state = LMG_PEER_STATE_ACTIVE;
      }
      /* send all message queued */
      mgTxQueueMsg(peer);
   }
#endif   /* GCP_PROV_MTP3 */

#ifdef ZG
   /* send run timeupdate for peer */
   zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
   RETVALUE(ROK);

} /* end of mgPrcPeerConCfm () */

/*
*
*       Fun:    mgPrcPeerDiscInd 
*
*       Desc:   This function processes the TCP connection disconnect
*               indication from HIT
*
*       Ret:    ROK - SUCCESS
*               RFAILED - FAILURE
*
*       Notes:  This function should only be called for a TCP connection
*               failure
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC S16 mgPrcPeerDiscInd
(
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PUBLIC S16 mgPrcPeerDiscInd(peer)
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{

   TRC2(mgPrcPeerDiscInd)

   /* This indication can be received on MG or MGC side */
   if (mgCb.genCfg.entType == LMG_ENT_GC)
   {
#ifdef GCP_MGC
      if (peer->state == LMG_PEER_STATE_ACTIVE)
      {
#ifdef   GCP_PROV_MTP3
         if (LMG_TPT_MTP3 == peer->accessInfo.transportType)
         {
            if (peer->mgcoMtpCb.status & SP_OFFLINE)
               peer->state = LMG_PEER_STATE_DISCONNECTED;
         }
         else      /* do NOT delete this comment */
#endif   /* GCP_PROV_MTP3 */         

#ifdef   GCP_PROV_SCTP
         if (LMG_TPT_SCTP == peer->accessInfo.transportType)
         {
            if (NULLP == peer->assocCb)
            {
               peer->state = LMG_PEER_STATE_DISCONNECTED;
#ifdef ZG
      /* send update del to standby */
            peer->removeAllTxns =  TRUE;
            zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
               CMPFTHA_ACTN_MOD);
            peer->removeAllTxns =  FALSE;
#endif /* ZG */
            
            }
         }
         else      /* do NOT delete this comment */
#endif /* GCP_PROV_SCTP */
         if (peer->mgcoInfo.numActvConn <= 1)
         {
            /* 
             * if this is the last connection, communication with peer
             * no longer possible 
             */
            peer->state = LMG_PEER_STATE_DISCONNECTED;
            /* run a timer expecting service change */
#ifdef ZG
      /* send update del to standby */
            peer->removeAllTxns =  TRUE;
            zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
               CMPFTHA_ACTN_MOD);
            peer->removeAllTxns =  FALSE;
#endif /* ZG */
         }
      }
      else if (peer->state == LMG_PEER_STATE_REGISTER)
      {
         /* 
          * This scenario is possible, when we have given service change
          * restart to the service user and user hasn't responded yet 
          */
         mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED, LMG_CAUSE_CONN_FAILURE,
                      FALSE);
      }
#endif /* GCP_MGC */
   } /* layer is MGC */
   else
   {
#ifdef GCP_MG
      if(peer->ssap->crntMgc == peer)
      {
         /* Media Gateway case */
         mgProcessPeerMGCFailure(peer);
      }
      else
      {
         mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED, LMG_CAUSE_CONN_FAILURE, 
                      FALSE);
      }
#endif /* GCP_MG */
   } /* layer is MG */
   RETVALUE(ROK);

} /* end of mgPrcPeerDiscInd () */


#ifdef GCP_MG
/*
*
*       Fun:    mgProcessPeerMGCFailure
*
*       Desc:   This function processes the Peer Association Failure
*
*       Ret:    None
*
*       Notes:  
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC Void mgProcessPeerMGCFailure
(
MgPeerCb           *peer               /* Peer Control Block */
)
#else
PUBLIC Void mgProcessPeerMGCFailure(peer)
MgPeerCb           *peer;              /* Peer Control Block */
#endif
{
#ifdef GCP_MG
   MgPeerCb        *newPeer = NULLP;   /* Peer Control Block */
   S16             ret;                /* Return Value */
#endif /* GCP_MG */
   MgSSAPCb        *ssap = peer->ssap; /* SSAP Control Block */
   U8              state = peer->state;/* State */
   /* adding new local variable */
   U8              method;             /* method to be sent for SVC msg */

   TRC2(mgProcessPeerMGCFailure)

   if ((peer->state == LMG_PEER_STATE_CONNECT) ||
       (peer->state == LMG_PEER_STATE_REGISTER))
   {
      if (peer->accessInfo.peerflg & MG_HANDOFF_RQSTD)
      {
         /* current MGC has requested Handoff */
         mgAbortHandOff(peer, LMG_CAUSE_CONN_FAILURE);
         RETVOID;
      }
      else if (peer->accessInfo.peerflg & MG_REDIRECTED_BY_MGC)
      {
         /* MG was redirected by the MGC earlier */
         mgAbortRedirection(peer, LMG_CAUSE_CONN_FAILURE);
         RETVOID;
      }
      else
      {
         /* If user initiated this service change, user needs to be informed */
         U8 flag = peer->accessInfo.peerflg;
         mgBringPeerToCfgStatus(peer, TRUE);
         if (flag & MG_USER_INITIATED_REG)
         {
            mgIndicateAbortTxnToUsr(MGT_ERR_REGISTER_FAILED, 
                                    MG_INVALID_TRANSID, peer);
         }
#ifdef ZG
         /* send update del to standby */
         peer->removeAllTxns =  TRUE;
         zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
         peer->removeAllTxns =  FALSE;
#endif /* ZG */
      }
   }
   else if (peer->state == LMG_PEER_STATE_ACTIVE)
   {
      CmLList *node;
      CM_LLIST_FIRST_NODE(&(ssap->peerLst), node);
      /* Active association with peer is established */
      mgDeletePeer(peer, LMG_EVENT_MGC_FAILED, LMG_CAUSE_CONN_FAILURE,
                   FALSE);
      if (peer != (MgPeerCb *)node->node)
      {
         ssap->crntMgc = NULLP;
      }
   }
         
   /* Select a new peer */
   mgSelectPeer(&(newPeer), ssap);
   if (newPeer != NULLP)
   {
      /* Valid peer is found; Initiate service change on the new peer */
      if (state != LMG_PEER_STATE_ACTIVE)
      {
         /* If the peer MGC is being contacted again after
          * disconnection, send method as DISCONNECTED **/
         MG_OBTAIN_SVCCHG_METHOD(method, newPeer);
        /*
         *  Changed theservice change reason code in the service change
         *  request , when the request is send to a secondary  MGC 
         */
         ret = mgSendSrvcChng(newPeer, method,
                              MG_SCRSN_COLD_BOOT, NULLP,
                              LMG_INVALID_PEER_PORT,
                              NULLP);
      }
      else
          ret = mgSendSrvcChng(newPeer, MGT_SVCCHGMETH_FAILOVER,
                               MG_SCRSN_MGC_IMPN_FAIL, NULLP,
                               LMG_INVALID_PEER_PORT,
                               NULLP);
   }
   if ((newPeer == NULLP) || (ret != ROK))
   {
      SpId  sapId;
      /* No more MGCs available; Should inform LM */
      sapId = ssap->ssapCfg.sSAPId;

	  if (ssap->alarmIndSent == FALSE)   /*cdw add if on 2006.9.28*/
	  	{
      		/* Send Status Indication to the layer manager */
     		 mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                  		LMG_EVENT_ALL_MGC_FAILED, LCM_CAUSE_UNKNOWN, 
                  		LMG_ALARMINFO_SAP, (Ptr)&(sapId), sizeof(SpId), 
                  		LMG_ALARMINFO_INVSAPID);
			ssap->alarmIndSent=TRUE;	
	  	}
      ssap->crntMgc = NULLP;

      /* assign crntMgc to the first node in the peerList */
      mgSelectPeer(&(ssap->crntMgc), ssap);
      RETVOID;
   }
   ssap->crntMgc = newPeer;
#ifdef ZG
   /* send update for ssap */
   zgRtUpd(ZG_CBTYPE_SSAP, (Ptr)ssap, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
   RETVOID;
} /* end of mgProcessPeerMGCFailure () */
#endif /* GCP_MG */



/*
*
*       Fun:    mgGetPeer 
*
*       Desc:   This function finds the peer based on mId and then Remote IP
*       address. 
*
*       Ret:   Pointer to peer control block 
*
*       Notes:  
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC MgPeerCb *mgGetPeer
(
TknStrOSXL         *mid,               /* MId */   
CmTptAddr          *remAddr,           /* Remote Transport Address */
U8                 *name,              /* Domain name */
MgSSAPCb           *ssap,               /* Pointer to MgSSAPCb */
Bool               *sendUpd            /* send Update */
)
#else
PUBLIC MgPeerCb *mgGetPeer(mid, remAddr, name, ssap, sendUpd)
TknStrOSXL         *mid;               /* MId */   
CmTptAddr          *remAddr;           /* Remote Transport Address */
U8                 *name;              /* Domain name */
MgSSAPCb           *ssap;              /* Pointer to MgSSAPCb */
Bool               *sendUpd;           /* send Update */
#endif
{
   MgPeerCb        *peer;  /* Peer Control Block */

   TRC2(mgGetPeer)

   /* Initialise */
   peer      = NULLP;

   *sendUpd = FALSE;

   /* 
    * Search for peer based on MID. If the peer is present, one should always
    * find a peer at the MGC. 
    */
#ifdef GCP_MGC
   if (LMG_ENT_GC == mgCb.genCfg.entType)
   {
      if(NULLP != mid)
      {
         cmHashListFind(&(mgCb.peerNameLst), (U8 *)(mid->val), mid->len, 
                 MG_HASH_SEQNMB_DEF, (PTR *) &peer);
      }
   }
#endif /* GCP_MGC */

#ifdef GCP_MG
   if (LMG_ENT_GW == mgCb.genCfg.entType)
   {
      peer = mgGetAndAdjstPeerInLst(mid, remAddr, name, ssap, sendUpd);
   }
#endif /* GCP_MG */
   RETVALUE(peer);
} /* end of mgGetPeer () */

#ifdef   GCP_PROV_MTP3
/*
*
*       Fun:    mgGetMtpPeer 
*
*       Desc:   This function finds the peer based on mId and then from Peer Dpc 
*       address. 
*
*       Ret:   Pointer to peer control block 
*
*       Notes:  
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC MgPeerCb *mgGetMtpPeer
(
MgMgcoMid          *mid,              /* MId */   
MgPeerCb           *peer,             /* Peer Control Block */
Dpc                *newDpc             /* New Point Code */
)
#else
PUBLIC MgPeerCb *mgGetMtpPeer(mid, peer, newDpc)
MgMgcoMid          *mid;               /* MId */   
MgPeerCb           *peer;             /* Peer Control Block */
Dpc                *newDpc;            /* New Point Code */
#endif
{
   MgPeerCb        *newPeer;  /* Peer Control Block */
   Dpc             peerDpc;  /* peer Point Code */

   TRC2(mgGetMtpPeer)

   /* Initialise */
   newPeer      = NULLP;

   /* Extract the Peer Dpc from MID */

   MG_FILL_MTP_DPC_FRM_MID_TEXT(mid, peerDpc);
   *newDpc = peerDpc; 

   /* 
    * Search for peer based on MID. If the peer is present, one should always
    * find a peer at the MGC. 
    */
#ifdef GCP_MG
   if (LMG_ENT_GW == mgCb.genCfg.entType)
   {
         U16 i=0;

         while( ROK == cmHashListFind(&(peer->tsap->mgcoMtpHlCp),
                  (U8 *)&(peerDpc), 
                  MG_DPC_LEN, i, (PTR *)&newPeer))
         {
            /* Point the index to next peer */
            i++;
            if((newPeer) && (peer->ssap == newPeer->ssap))
               /* peer with same ssap already exist so just return the Peer  */
            {  
               break;
            }
         }
   }
#endif /* GCP_MG */
   RETVALUE(newPeer);
} /* end of mgGetMtpPeer () */


#endif   /* GCP_PROV_MTP3 */

#ifdef GCP_MG
/*
*
*       Fun:    mgGetAndAdjstPeerInLst
*
*       Desc:   This function finds the peer at the MGCO MG side. It checks if
*       the peer is present in any of transient lists (IP addr/domain name),
*       and if it is present and if the MID is now available, it removes the
*       peer from those lists and add it to MID based list.
*
*       Ret:   Pointer to peer control block 
*
*       Notes:  
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC MgPeerCb *mgGetAndAdjstPeerInLst
(
TknStrOSXL         *mid,               /* MId */   
CmTptAddr          *remAddr,           /* Remote Transport Address */
U8                 *name,              /* Domain name */
MgSSAPCb           *ssap,              /* Pointer to MgSSAPCb */
Bool               *sendUpd            /* send update */
)
#else
PUBLIC MgPeerCb *mgGetAndAdjstPeerInLst(mid, remAddr, name, ssap, sendUpd)
TknStrOSXL         *mid;               /* MId */   
CmTptAddr          *remAddr;           /* Remote Transport Address */
U8                 *name;              /* Domain name */
MgSSAPCb           *ssap;              /* Pointer to MgSSAPCb */
Bool               *sendUpd;           /* send update */
#endif
{
   MgPeerCb        *peer, *existPeer;  /* Peer Control Block */
   MgIpAddrEnt     *ipAddrEnt;         /* IP Address Entry */
   Bool            insert, ipFnd, dnameFnd, endSrch;

   TRC2(mgGetAndAdjstPeerInLst)

   /* Initialise */
   peer      = NULLP;
   existPeer = NULLP;
   ipAddrEnt = NULLP;
   insert = ipFnd = dnameFnd = endSrch = FALSE;

   /* Search for peer in MID based list */
   if(NULLP != mid)
   {
      cmHashListFind(&(mgCb.peerNameLst), (U8 *)(mid->val), mid->len, 
              MG_HASH_SEQNMB_DEF, (PTR *) &peer);
      if(NULLP != peer)
      {
         if (TRUE == peer->mgcoInfo.dupPeerPrsnt) 
         {
           U16 i = 1;
           do
           {
             if(peer->ssap == ssap)
                break;
             peer = NULLP;
             if(ROK != cmHashListFind(&(mgCb.peerNameLst), (U8 *)(mid->val), 
                         mid->len, (U16)(MG_HASH_SEQNMB_DEF + i), (PTR *)&peer))
             {
               break;
             }
             i++;
           } while (1);
         }
         /* The probability of the same peer existing in MID list as well
          * as other lists exist only if this is configured */
         if(FALSE == peer->mntInfo.byCfg )
         {
            endSrch = TRUE;
         }
      }
   }
   /* Search based on IP address in IP address based list if required */
   if( (NULLP != remAddr) && (FALSE == endSrch) )
   {
      if (mgFindIpAddrLst(remAddr->type, 
                          &(remAddr->u.ipv4TptAddr.address),
                          &(remAddr->u.ipv6TptAddr.ipv6NetAddr),
                          MG_HASH_SEQNMB_DEF, 
                          &ipAddrEnt) == ROK)
      {
         MgPeerCb   *tmpPeer;
         tmpPeer = ipAddrEnt->peer;
         if (TRUE == tmpPeer->mgcoInfo.dupPeerPrsnt)
         {
            U16 i = 1;
            do
            {
               if(tmpPeer->ssap == ssap)
                  break;
               tmpPeer = NULLP;
               ipAddrEnt = NULLP;
               /* Search if Next Peer with IP address is available */
               if (mgFindIpAddrLst(remAddr->type, 
                                   &(remAddr->u.ipv4TptAddr.address),
                                   &(remAddr->u.ipv6TptAddr.ipv6NetAddr),
                                   (U16)(MG_HASH_SEQNMB_DEF +i), 
                                   &ipAddrEnt) == ROK)
                  tmpPeer = ipAddrEnt->peer;
               else
                  break;
               i++;
            } while (1);
         }
         ipFnd = TRUE;
         if(peer != NULLP)
         {
            existPeer = tmpPeer;
            endSrch = TRUE;
         }
         else
            peer = tmpPeer;
      }
   }
   /* Search in domain name based list if required */
   if( (NULLP != name) && (FALSE == endSrch) )
   {
      MgPeerCb   *tmpPeer = NULLP;
      U16 nameLen = (U16)cmStrlen(name);
      if(ROK == cmHashListFind(&(mgCb.peerNameLst), (U8 *)(name), nameLen, 
                         MG_HASH_SEQNMB_DEF, (PTR *) &tmpPeer))
      {
         if (TRUE == tmpPeer->mgcoInfo.dupPeerPrsnt)
         {
            U16 i = 1;
            do
            {
               if(tmpPeer->ssap == ssap)
                  break;
               tmpPeer = NULLP;
               if(ROK != cmHashListFind (&(mgCb.peerNameLst), (U8 *)&(name),
                          nameLen, (U16)(MG_HASH_SEQNMB_DEF + i),
                          (PTR *) &tmpPeer))
                  break;
                  i++;
            } while (1);
         }
         dnameFnd = TRUE;
         if(peer != NULLP)
         {
            existPeer = tmpPeer;
            endSrch = TRUE;
         }
         else
            peer = tmpPeer;
      }
   }

   /* mg008.105: peer->ssap should always equal inputed ssap*/
   if( (peer != NULLP) && (peer->ssap != ssap) )
   {
      RETVALUE(NULLP);     
   }

   /* If their is a existing peer in any of the lists other than MID based
    * list, remove it from there, and make sure that it exists only in MID
    * based list. If the peer was not found in IP/Dname list, return the
    * peerCb, whatever it is from here itself */
   if( (FALSE == dnameFnd) && (FALSE == ipFnd) )
   {
      RETVALUE(peer);
   }
   else
   {

       /* Peer exists in MID list as well as IP/Dname lists. Coming here
        * also means that "peer" is a configured peer. Delete peer */
       if( (NULLP != peer) && (NULLP != existPeer) )
       {
         /* Swap existPeer and peer..User knows about peer ( since this is
          * configured ..) so peerId of existPeer Should be same as that of peer
          * */
         U32   peerId;
#ifdef ZG_DFTHA
         if(!zgChkCRsetStatus())
         {
            /* Only matser should update mid/Ip address list ..so send update */
            *sendUpd = TRUE;
            RETVALUE(NULLP);
         }
#endif /* ZG_DFTHA */
         MG_INIT_MID(existPeer->accessInfo.mid, peer->accessInfo.mid);
         existPeer->mntInfo.byCfg = peer->mntInfo.byCfg;
         existPeer->mntInfo.usrKnows = peer->mntInfo.usrKnows;
         existPeer->mgcoInfo.mgcPriority = peer->mgcoInfo.mgcPriority;

#ifdef GCP_USE_PEERID
         peerId = peer->accessInfo.peerId;
         peer->accessInfo.peerId = existPeer->accessInfo.peerId;
         existPeer->accessInfo.peerId = peerId;
         mgCb.peerLst[peerId]->peer = existPeer;
         mgCb.peerLst[peer->accessInfo.peerId]->peer = peer;
#endif /* GCP_USE_PEERID */
#ifdef ZG
         {
            /* send update in blocking mode */
            ZgProcUpdInfo     procUpdInfo;

            procUpdInfo.procType = ZG_PROCTYPE_SWAP_PEER;
            procUpdInfo.u.swapPeer.peerId1 = peer->accessInfo.peerId;
            procUpdInfo.u.swapPeer.peerId2 = existPeer->accessInfo.peerId;
            zgRtProcUpd(&procUpdInfo, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
            zgUpdPeer();
         }
#endif /* ZG */
         peer->mntInfo.usrKnows = FALSE;
         peer->mntInfo.byCfg = FALSE;
#ifdef ZG
         /* send modify update for peer and existPeer */
         zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
         zgRtUpd(ZG_CBTYPE_PEER, (Ptr)existPeer, CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
         zgUpdPeer();
#endif /* ZG */
         mgDeletePeer(peer, MG_IGNORE, MG_NONE, TRUE);
         peer = existPeer;
         insert = TRUE;
       }
       /* Peer exists only in IP/Dname lists and not in MID list. If we
        * have the MID now, insert it in MID list and remove from IP/Dname
        * list. If we dont have the MID now, return this peerCb */
       else if( (NULLP == existPeer) && (NULLP != mid) )
       {
          MG_INIT_MID(peer->accessInfo.mid, (*mid));
          insert = TRUE;
       }
       if(TRUE == insert)
       {
          MgPeerCb   *tmpPeer;
#ifdef ZG_DFTHA
         if((zgChkCRsetStatus()) == FALSE)
         {
            /* if peer is not found in Mid list..this so */
            *sendUpd = TRUE;
            RETVALUE(NULLP);
         }
#endif /* ZG_DFTHA */
          if(TRUE == ipFnd)
          {
             /* Remove from IP address based lists, but make sure that the
              * address infomation stored in the accessInfo of peer is not
              * lost, since this peerCb is replacing the configured Peer CB.
              * This would be required when this peer is used at a later
              * point in time */
             U16   addrCnt;
             addrCnt = peer->accessInfo.peerAddrTbl.count;
             mgRemovePeerAddrs(peer);
             peer->accessInfo.peerAddrTbl.count = addrCnt;
          }
          if(TRUE == dnameFnd)
          {
             cmHashListDelete(&(mgCb.peerNameLst), (PTR)peer);
             if(TRUE == peer->mgcoInfo.dupPeerPrsnt)
             {
                MgPeerCb *peer1 = NULLP;
                MgPeerCb *peer2 = NULLP;
                U16 nameLen = (U8)cmStrlen(peer->accessInfo.name);
                if(ROK == cmHashListFind(&(mgCb.peerNameLst), 
                          (U8 *)peer->accessInfo.name, (U16)nameLen, 
                          (U16)MG_HASH_SEQNMB_DEF, (PTR *)&peer1))
                {
                   cmHashListFind(&(mgCb.peerNameLst), 
                          (U8 *)peer->accessInfo.name, (U16)nameLen, 
                          (MG_HASH_SEQNMB_DEF + 1), (PTR *)&peer2);
                }
                if ((peer1 != NULLP) && (peer2 == NULLP))
                   peer1->mgcoInfo.dupPeerPrsnt = FALSE;
             }
          }
          if(ROK == cmHashListFind(&(mgCb.peerNameLst), 
                         peer->accessInfo.mid.val, peer->accessInfo.mid.len, 
                         (U16)MG_HASH_SEQNMB_DEF, (PTR *)&tmpPeer))
          {
            if(peer->ssap != tmpPeer->ssap)
            {
               tmpPeer->mgcoInfo.dupPeerPrsnt = TRUE;
               peer->mgcoInfo.dupPeerPrsnt      = TRUE;
            }
            else
            {
               RETVALUE(NULLP);
            }
         }
         if(ROK != cmHashListInsert (&(mgCb.peerNameLst), (PTR) peer, 
                            peer->accessInfo.mid.val, peer->accessInfo.mid.len))
         {
            RETVALUE(NULLP);
         }
         /* Delete the existPeer from the SSAP Based Linked List, and then 
          * re-insert it based on the newly found mgcPriority */
         cmLListDelFrm(&(peer->ssap->peerLst), &(peer->ssapPeerLstNode));
         peer->ssapPeerLstNode.node = (PTR)peer;
         {
            CmLList *node;
            U32     i;
            Bool    crnt = FALSE;
            CM_LLIST_FIRST_NODE(&(ssap->peerLst), node);
            for ( i = 0; i < cmLListLen(&(ssap->peerLst)); i++)
            {
               if (((MgPeerCb *)node->node)->mgcoInfo.mgcPriority > 
                       peer->mgcoInfo.mgcPriority)
               {
                  crnt = TRUE;
                  break;
               }
               CM_LLIST_NEXT_NODE(&(ssap->peerLst), node);
            }
            if (crnt == TRUE)
               cmLListInsCrnt(&(ssap->peerLst), &(peer->ssapPeerLstNode));
            else
               cmLListAdd2Tail (&(ssap->peerLst), &(peer->ssapPeerLstNode));
         }
#ifdef ZG
         /* send update to delete peer..then add peer */
         zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_DEL);
         zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peer, CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_ADD);
         zgUpdPeer();
#endif /* ZG */
         
      }
   }
   RETVALUE(peer);
} /* end of mgGetAndAdjstPeerInLst() */

#endif /* GCP_MG */


/*
*
*       Fun:    mgSendSrvcChng 
*
*       Desc:   This function composes a service change message and prepares
*       to transmits service change message
*
*       Ret:   Pointer to peer control block 
*
*       Notes: None 
*
*       File:   mg_peer.c
*/

#ifdef ANSI
PUBLIC S16 mgSendSrvcChng
(
MgPeerCb           *peer,              /* Peer Control Block */
U8                 method,             /* Service Change method */
U8                 *reason,            /* Reason */
MgTptSrvr          *srvr,              /* transport server used for sending */
S32                port,               /* Service Change Port */
MgAddrInfo         *mgcInf             /* Handoff MGC Info */
)
#else
PUBLIC S16 mgSendSrvcChng(peer, method, reason, srvr, port, mgcInf)
MgPeerCb           *peer;              /* Peer Control Block */
U8                 method;             /* Service Change method */
U8                 *reason;            /* Reason */
MgTptSrvr          *srvr;              /* transport server used for sending */
S32                port;               /* Service Change Port */
MgAddrInfo         *mgcInf;            /* Handoff MGC Info */
#endif

{
   MgMgcoCommandReq      *cmdReq;      /* Megaco Command Request */
   MgMgcoTxn             *mgcoTxn;     /* Megaco Transaction */
   MgMgcoTxnReq          *txnReq;      /* Transaction Request */
   MgMgcoActionReq       *action;      /* Megaco Action */
   MgMgcoMsg             *msg;         /* Megaco Message */
   MgSSAPCb              *ssap;        /* SSAP Control Block */
   MgMgcoSvcChgReq       *svc;         /* Service Change Request Structure */
   Buffer                *mBuf;        /* Message buffer */
   S16                   ret;          /* Return Value */
   Bool                  txnSend;      /* Transmit Transaction */
   U8                    idx;
   MgTxTransIdEnt        *txCb;        /* Transaction Control Block */
   U8                    msgInfo;      /* Message Information */
   CmTptAddr             tptAddr;      /* Transport Address */
#ifdef GCP_ALLOW_PROF_CFG
   U8                     *val;
#endif /* GCP_ALLOW_PROF_CFG */


   TRC2(mgSendSrvcChng)


   ssap = peer->ssap;


   txnSend = FALSE;

   msgInfo = 0;  /* initialized */

   /* 
    * This service change can be either due to restart avalanche timer 
    * expiry or MG service user has sent some message which is other 
    * than service change due to some activity while restart avalanche 
    * timer is running or we are handing off to a new MGC or a failure 
    * is detected for an active MGC 
    */
   /* stop restart timer if running */
   idx = MG_RST_AVLNCH_TMR - MG_PEER_TMR_BASE;

   if (peer->mntInfo.tmr[idx].tmrEvnt == MG_RST_AVLNCH_TMR)
      mgStopTmr(MG_RST_AVLNCH_TMR, (PTR)peer, &(peer->mntInfo.tmr[idx]));

#ifdef GCP_MG
   if (method != MGT_SVCCHGMETH_HANDOFF)
   {
      peer->ssap->crntMgc = peer;
#ifdef ZG
      /* send update for crntMgc */
      zgRtUpd(ZG_CBTYPE_SSAP, (Ptr)(peer->ssap), CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_MOD);
#endif /* ZG */
   }
#endif /* GCP_MG */

   /* Compose Service change message */

   ret = mgAllocEventMem((Ptr *)&msg, sizeof(MgMgcoMsg)); 

   if (ret != ROK)
     RETVALUE(ret);
   else   /* Initilized pres field of mgcoMsg */
      msg->pres.pres = PRSNT_NODEF;

   msg->ah.pres.pres = NOTPRSNT;

   msg->ver.pres = PRSNT_NODEF;

#ifdef GCP_VER_1_5
   /* Since stack sending Service Change the version in the message */
   /* should be 1.0,because it will initiate for restart, handover  */
   /* and failover cases, all other termination related service     */
   /* will be initiated by the user.                                */
   
   /* mg004.105: Bug Fix : If the method is FORCED, the version should be the  */
   /* negotiated Version. - Mudit                                   */
   if (method == MGT_SVCCHGMETH_FORCED)
      msg->ver.val = peer->mgcoInfo.negotiatedVersion;
   else	
   /* msg->ver.val = ssap->ssapCfg.minMgcoVersion;*/ /* Assuming it is 1.0 */
      msg->ver.val = 1;
      
#else
   msg->ver.val = peer->mgcoInfo.negotiatedVersion;
#endif /* GCP_VER_1_5 */

   /* Fill msg mid */
   MG_FILL_MID_IN_MSG(msg->mid, ssap->ssapCfg.userInfo.mid, ret, &(msg->memCp));

   if (ret != ROK)
   {
      mgFreeEventMem(msg);
      RETVALUE(ret);
   }

   msg->lcl.pres.pres = NOTPRSNT;
   msg->body.type.pres = PRSNT_NODEF;
   msg->body.type.val  = MGT_TXN;
   msg->body.u.tl.num.pres = PRSNT_NODEF; 
   msg->body.u.tl.num.val = 1;

#ifdef GCP_VER_1_3   
   mgcoTxn = msg->body.u.tl.txns[0];
   if(ROK != mgAllocEventMem((Ptr *)&mgcoTxn, sizeof(MgMgcoTxn)))
   {
      mgFreeEventMem(msg);
      RETVALUE(RFAILED);
   }
   msg->body.u.tl.txns[0] = mgcoTxn;
#else
   MGGETMEM((Ptr *)&(msg->body.u.tl.txns), sizeof(Ptr), (Ptr)msg, ret);
   if (ret != ROK)
   {
      mgFreeEventMem(msg);
      RETVALUE(ret);
   }

   MGGETMEM((Ptr *)&(msg->body.u.tl.txns[0]), sizeof(MgMgcoTxn), 
            (Ptr)msg, ret);

   if (ret != ROK)
   {
      mgFreeEventMem(msg);
      RETVALUE(ret);
   }

   mgcoTxn = msg->body.u.tl.txns[0];
#endif /* GCP_VER_1_3 */

   mgcoTxn->type.pres = PRSNT_NODEF;    
   mgcoTxn->type.val = MGT_TXNREQ;

   txnReq = &(mgcoTxn->u.req);
   txnReq->pres.pres = PRSNT_NODEF;
   txnReq->transId.pres = PRSNT_NODEF;

   /*
    * The MGC GCP stack can also initiate txns on its own e.g.
    * a service change Handoff to a MG (as a result of Control MGC)
    */
   MG_OBTAIN_TRANSID(ssap, &(txnReq->transId.val), LMG_PROTOCOL_MGCO);

   txnReq->al.num.pres = PRSNT_NODEF;
   txnReq->al.num.val = 1;

   MGGETMEM((Ptr *)&(txnReq->al.actns), sizeof(Ptr), (Ptr)msg, ret);

   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
      RETVALUE(ret);
   }

   MGGETMEM((Ptr *)&(txnReq->al.actns[0]), sizeof(MgMgcoActionReq), 
            (Ptr)msg, ret);

   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
      RETVALUE(ret);
   }

   action = txnReq->al.actns[0];
   action->pres.pres = PRSNT_NODEF;
   action->cxtId.type.pres = PRSNT_NODEF;
   action->cxtId.type.val = MGT_CXTID_NULL;
   action->cl.num.pres = PRSNT_NODEF;
   action->cl.num.val = 1;


#ifndef GCP_CH
   MGGETMEM((Ptr *)&(action->cl.cmds), sizeof(Ptr), (Ptr)msg, ret);
#endif /* GCP_CH */

   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
      RETVALUE(ret);
   }
#ifndef GCP_CH
   MGGETMEM((Ptr *)&(action->cl.cmds[0]), sizeof(MgMgcoCommandReq), 
            (Ptr)msg, ret);
#else
   MG_ALLOC_EVNT_MEM((action->cl.cmds[0]), ret, sizeof(MgMgcoCommandReq));
#endif /* GCP_CH */


   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
      RETVALUE(ret);
   }

   cmdReq = action->cl.cmds[0];
   cmdReq->pres.pres = PRSNT_NODEF;
   /* removed the wildcard from the service change message */
   cmdReq->wild.pres = NOTPRSNT;
   cmdReq->cmd.type.pres = PRSNT_NODEF;
   cmdReq->cmd.type.val = MGT_SVCCHG;
   svc = &(cmdReq->cmd.u.svc);
   svc->pres.pres = PRSNT_NODEF;
   svc->termId.type.pres = PRSNT_NODEF;
   svc->termId.type.val = MGT_TERMID_ROOT;
   svc->parm.pres.pres = PRSNT_NODEF;
   svc->parm.meth.pres.pres = PRSNT_NODEF;
   svc->parm.meth.type.pres = PRSNT_NODEF;
   svc->parm.meth.type.val = (U8)method;

#ifdef GCP_MG
   /* Check whether service change address is required to be filled */
   /* Add check for method as DISCONNECTED **/
   if ((mgCb.genCfg.entType == LMG_ENT_GW) &&
       ((method == MGT_SVCCHGMETH_RESTART) ||
        (method == MGT_SVCCHGMETH_DISCON) ||
        (method == MGT_SVCCHGMETH_FAILOVER) ||
        (method == MGT_SVCCHGMETH_HANDOFF)) &&
        (peer->accessInfo.transportType == LMG_TPT_UDP))
   {
      if (ssap->nxtUseMgcoSrvr != NULLP)
      {
         /* servers are available on SSAP */
         svc->parm.addr.type.pres = PRSNT_NODEF;
         svc->parm.addr.type.val = MGT_MID_PORT;
         svc->parm.addr.u.port.pres = PRSNT_NODEF;
         /* nxtUse is used here because it doesnot matter which 
          * server we choose as long as it is on SSAP */
         MG_FILL_PORT_FRM_TPTADDR(svc->parm.addr.u.port.val,
                                  &(ssap->nxtUseMgcoSrvr->tptAddr));
      }
   }
#endif /* GCP_MG */

   /* mg004.105: Bug Fix: If the method is FORCED then no need to send version */
   /* as it's not required to be negotiated. - Mudit                */
   if (method == MGT_SVCCHGMETH_FORCED)
      svc->parm.ver.pres = NOTPRSNT;
   else
   {
      svc->parm.ver.pres = PRSNT_NODEF;
      svc->parm.ver.val = peer->mgcoInfo.negotiatedVersion;
   }

   if (reason)
   {
      svc->parm.reason.pres = PRSNT_NODEF;
      svc->parm.reason.len = cmStrlen(reason);

      MGGETMEM((Ptr *)&(svc->parm.reason.val), svc->parm.reason.len , 
               (Ptr)msg, ret);

      if (ret != ROK)
      {
         MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
         RETVALUE(ret);
      }
      cmMemcpy((U8 *)svc->parm.reason.val, (U8 *)reason, 
               svc->parm.reason.len);
   }
#ifdef GCP_ALLOW_PROF_CFG
   if (ssap->ssapCfg.profile.len != 0)
   {
      /* mg004.105: Bug Fix: If the method is FORCED then no need to send profile */
      /* Needed at the time of RESTART only. - Mudit                   */
      if (method == MGT_SVCCHGMETH_FORCED)
         svc->parm.ver.pres = NOTPRSNT;
      else
      {
      /* Start filling the SVC profile information from the ssapCfg */
         svc->parm.prof.pres.pres = PRSNT_NODEF;
         /* Copy the version information */
         svc->parm.prof.ver.pres = PRSNT_NODEF;
         svc->parm.prof.ver.val = ssap->ssapCfg.profile.ver;
         /* set the SVC profile string */
         MGGETMEM((Ptr *)&(val), ssap->ssapCfg.profile.len,(Ptr)(msg),ret);
         svc->parm.prof.name.type.pres = PRSNT_NODEF;
         svc->parm.prof.name.type.val = MGT_GEN_TYPE_UNKNOWN;

         svc->parm.prof.name.u.str.pres = PRSNT_NODEF;                               
         svc->parm.prof.name.u.str.len  = ssap->ssapCfg.profile.len;                 
         svc->parm.prof.name.u.str.val  = val;                                       

         cmMemcpy((U8*)(val),(U8*)(ssap->ssapCfg.profile.profStr), ssap->ssapCfg.profile.len);
      }/* method != FORCED */
   }

#endif /* GCP_ALLOW_PROF_CFG */

#ifdef GCP_MGC
   /* Check whether mgcId field has to be filled */
   if ((mgCb.genCfg.entType == LMG_ENT_GC) &&
       (method == MGT_SVCCHGMETH_HANDOFF) && 
       (mgcInf != NULLP))
   {
      ret = mgCnvrtPeerInfoToMId(mgcInf, &(svc->parm.mgcId), (Ptr)msg);
      if (ret != ROK)
      {
         MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
         RETVALUE(ret);
      }
   }
#endif /* GCP_MGC */

   if ((method == MGT_SVCCHGMETH_HANDOFF) && 
       (mgCb.genCfg.entType == LMG_ENT_GC))
      msgInfo = MG_HANDOFF|MG_LM_INIT;
   else if ((method == MGT_SVCCHGMETH_HANDOFF) && 
       (mgCb.genCfg.entType == LMG_ENT_GW))
      msgInfo = MG_HANDOFF|MG_SELF_INIT;
   else if (method == MGT_SVCCHGMETH_RESTART)
      msgInfo = MG_RESTART|MG_SELF_INIT;
   else if (method == MGT_SVCCHGMETH_DISCON)   /* Set DISCON bit */
      msgInfo = MG_DISCONNECT|MG_SELF_INIT;
   else if (method == MGT_SVCCHGMETH_FAILOVER)
   {
      if (cmStrcmp(reason, MG_SCRSN_MGC_IMPN_FAIL) == 0)
         msgInfo = MG_FAILOVER|MG_SELF_INIT;
      else
         msgInfo = MG_FAILOVER|MG_LM_INIT;
   }
   else if (method == MGT_SVCCHGMETH_FORCED)
      msgInfo = MG_FORCED|MG_LM_INIT;

   tptAddr.type = CM_TPTADDR_NOTPRSNT;

   if (srvr == NULLP)
      srvr = mgGetSendSrvr(ssap, peer);

   ret = mgGetMsg(peer->tsap->tsapCfg.memId.region,
                  peer->tsap->tsapCfg.memId.pool,
                  &(mBuf));

   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
      RETVALUE(ret);
   }

   /* Process outgoing transaction */
   txCb  = mgPrcOutGoingTxn(txnReq->transId.val, MGT_TXNREQ, msgInfo, FALSE,
                           &tptAddr , ssap, peer,
#ifdef    GCP_PROV_SCTP
                           peer->assocCb,
#endif    /* GCP_PROV_SCTP */
                           srvr ,mBuf, &txnSend);
   if (txCb == NULLP)
   {
      mgPutMsg(mBuf);
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
      RETVALUE(ret);
   }
   
   /* This function encodes the message and prepares for transmission,
    * if message is required to be queued , message shall be queued 
    * in this function */

   ret = mgTransmitSrvcChng(peer, mBuf, msg, txnSend);

   if (ret != ROK)
   {
      mgPutMsg(mBuf);
      RETVALUE(ret);
   }

   MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 

   if ((mgCb.genCfg.entType == LMG_ENT_GW) &&
       (peer->state == LMG_PEER_STATE_AWAIT_REG))
   {
#ifdef   GCP_PROV_MTP3
      if (peer->accessInfo.transportType == LMG_TPT_MTP3)
      {
         peer->state = LMG_PEER_STATE_REGISTER;
      }
      else
#endif   /* GCP_PROV_MTP3 */      

      if (peer->accessInfo.transportType == LMG_TPT_UDP)
      {
         peer->state = LMG_PEER_STATE_REGISTER;
      }
      else  /* do NOT remove this comment */
#if    ( defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
             if (peer->accessInfo.transportType == LMG_TPT_TCP)
#endif    /* GCP_PROV_SCTP | GCP_PROC_MTP3 */
      {
         CmTptAddr remAddr;
         MgTptSrvr *conn;
         MgSrvrInitInfo  info;

         info.transportType = LMG_TPT_TCP;
         info.srvrType      = MG_TCP_CLIENT_CONNECTION;
         info.encodingScheme = peer->mgcoInfo.encodingScheme;
#ifdef ZG
         info.suConnId = MG_INVALID_LSTNRID;
         info.peerId = peer->accessInfo.peerId;
#endif /* ZG */
         /* Initiate connection request to remote server */
         MG_FILL_TPTADDR_FRM_NETADDR(&(remAddr),
                                &(peer->accessInfo.peerAddrTbl.netAddr[0]));

         MG_FILL_TPTADDR_PORT(&remAddr,peer->accessInfo.remotePort);

         ret = mgAllocSrvrCb(&info, &remAddr, NULLP, ssap, peer, 
                              (Ptr *)&conn, peer->tsap);

         if (ret != ROK)
         {
            MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
            RETVALUE(ret);
         }
         
         peer->state = LMG_PEER_STATE_CONNECT;
#ifdef ZG
         ZG_INIT_RSETID_IN_MAPCB(&(conn->mapCb));
         zgAddMapping(ZG_CBTYPE_TPTSRVR,(Ptr)conn);
         zgRtUpd(ZG_CBTYPE_TPTSRVR,(Ptr)conn,CMPFTHA_UPDTYPE_SYNC,
            CMPFTHA_ACTN_ADD);
#endif /* ZG */

         mgSrvConReq(conn, &(peer->tsap->tsapCfg.reCfg.tptParam),
                     peer->tsap, &remAddr);

      }
#ifdef    GCP_PROV_SCTP
      else
#ifdef   GCP_PROV_MTP3
      if (peer->accessInfo.transportType == LMG_TPT_SCTP)
#endif   /* GCP_PROV_MTP3 */
      {
         MG_INIT_SCTP_ASSOC(peer, ret);

         if (ret != ROK)
         {
            MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
            RETVALUE(ret);
         }
      }
#endif    /* GCP_PROV_SCTP */


#ifdef ZG
      zgRtUpd(ZG_CBTYPE_PEER,(Ptr)peer,CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_MOD);
#endif /* ZG */
   }
   RETVALUE(ret);
} /* end of mgSendSrvcChng () */

/*
*
*       Fun:    mgSendSrvcChngReply 
*
*       Desc:   This function composes a service change reply message and 
*               prepares to transmits service reply change message
*
*       Ret:    Pointer to peer control block 
*
*       Notes:  None 
*
*       File:   mg_peer.c
*/
#if    (defined(GCP_PROV_SCTP) | defined(GCP_PROV_MTP3))

#ifdef ANSI
PUBLIC S16 mgSendSrvcChngReply
(
MgPeerCb           *peer,              /* Peer Control Block */
U32                rspCode,            /* Response Code */
MgTSAPCb           *tsap,              /* TSAP Control Block */
MgcoTptInfo        *mgcoTptInfo,       /* Megaco Transport Information */
MgTptSrvr          *srvr,              /* Listener Control Block */
CmTptAddr          *tptAddr,           /* Source Transport Address */
MgMgcoMsg          *mgcoMsg,           /* Error Message */
MgTransId          transId             /* Transaction Id */
)
#else
PUBLIC S16 mgSendSrvcChngReply(peer, rspCode, tsap, mgcoTptInfo,
                               srvr, tptAddr, mgcoMsg, transId)
MgPeerCb           *peer;              /* Peer Control Block */
U32                rspCode;            /* Response Code */
MgTSAPCb           *tsap;              /* TSAP Control Block */
MgcoTptInfo        *mgcoTptInfo;       /* Megaco Transport Information */
MgTptSrvr          *srvr;              /* Listener Control Block */
CmTptAddr          *tptAddr;           /* Source Transport Address */
MgMgcoMsg          *mgcoMsg;           /* Error Message */
MgTransId          transId;            /* Transaction Id */
#endif

#else     /* GCP_PROV_SCTP || GCP_PROV_MTP3 */

#ifdef ANSI
PUBLIC S16 mgSendSrvcChngReply
(
MgPeerCb           *peer,              /* Peer Control Block */
U32                rspCode,            /* Response Code */
MgTSAPCb           *tsap,              /* TSAP Control Block */
MgTptSrvr          *srvr,              /* Listener Control Block */
CmTptAddr          *tptAddr,           /* Source Transport Address */
MgMgcoMsg          *mgcoMsg,           /* Error Message */
MgTransId          transId             /* Transaction Id */
)
#else
PUBLIC S16 mgSendSrvcChngReply(peer, rspCode, tsap, srvr,
                               tptAddr, mgcoMsg, transId)
MgPeerCb           *peer;              /* Peer Control Block */
U32                rspCode;            /* Response Code */
MgTSAPCb           *tsap;              /* TSAP Control Block */
MgTptSrvr          *srvr;              /* Listener Control Block */
CmTptAddr          *tptAddr;           /* Source Transport Address */
MgMgcoMsg          *mgcoMsg;           /* Error Message */
MgTransId          transId;            /* Transaction Id */
#endif

#endif    /* GCP_PROV_SCTP */
{
   MgMgcoCmdReply  *cmdReply;          /* Megaco Command Reply */
   MgMgcoTxn       *mgcoTxn;           /* Megaco Transaction */
   MgMgcoTxnReply  *txnReply;          /* Megaco Transaction Reply */
   MgMgcoActnReply *actionReply;       /* Megaco Action Reply */
   MgMgcoMsg       *msg;               /* Megaco Message */
   MgSSAPCb        *ssap;              /* SSAP Control Block */ 
   S16             ret;                /* Return Value */
   Buffer          *mBuf;              /* Buffer */
#ifdef   GCP_PROV_SCTP 
   MgAssocCb       *assoc = NULLP;     /* Association Control Block as passed in mgcoTptInfo */
#endif   /* GCP_PROV_SCTP */
#ifdef   GCP_PROV_MTP3
   Dpc             peerDpc = NULLD;     /* Peer DPC as passed in MgcoTptInfo */
#endif   /*  GCP_PROV_MTP3 */


   TRC2(mgSendSrvcChngReply)

   ssap = NULLP;
   /* 
    * Code added to pass multiple trasport parameter and then make each 
    * transport available in an
    * local copy of its transport variable 
    */
#if   (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
   if(mgcoTptInfo != NULLP)
   {
#ifdef   GCP_PROV_SCTP      
      if(mgcoTptInfo->tptType == LMG_TPT_SCTP)
         assoc = mgcoTptInfo->u.assocCb;
#endif   /* GCP_PROV_SCTP */
#ifdef   GCP_PROV_MTP3
      if (mgcoTptInfo->tptType == LMG_TPT_MTP3) 
         peerDpc  = mgcoTptInfo->u.mgMtpInfo.clgAddr;
#endif   /* GCP_PROV_MTP3 */    
    }     
#endif    /* GCP_PROV_SCTP | GCP_PROV_MTP3 */
 

#ifdef GCP_MGC
   if (mgCb.genCfg.entType == LMG_ENT_GC)
   {
      ssap = (mgCb.sSAPLst[mgCb.nxtMgcoSsapId]);
   }
#endif
   /*
    *             added missing part of the code for MG side.
    *             On the MG side, SrvcChng Handoff can be received
    *             and the MG side stack has to generate the reply
    *             if there is an error in the received message.
    *             peer will always be valid on the MG side.
    */
#ifdef GCP_MG
   if (mgCb.genCfg.entType == LMG_ENT_GW)
   {
      ssap = peer->ssap;
   }
#endif

   if (ssap == NULLP)
      RETVALUE(RFAILED);




   /* Compose Service change Reply message */
   ret = mgAllocEventMem((Ptr *)&msg, sizeof(MgMgcoMsg)); 
   if (ret != ROK)
     RETVALUE(ret);
   else   /* Initilized pres field of mgcoMsg */
      msg->pres.pres = PRSNT_NODEF;
   msg->ah.pres.pres = NOTPRSNT;

   msg->ver.pres = PRSNT_NODEF;
   msg->ver.val = mgcoMsg->ver.val;

   /* Fill msg mid */
   MG_FILL_MID_IN_MSG(msg->mid, ssap->ssapCfg.userInfo.mid, ret, &(msg->memCp));
   if (ret != ROK)
   {
      mgFreeEventMem(msg);
      RETVALUE(ret);
   }
   msg->lcl.pres.pres = NOTPRSNT;
   msg->body.type.pres = PRSNT_NODEF;
   msg->body.type.val  = MGT_TXN;
   msg->body.u.tl.num.pres = PRSNT_NODEF; 
   msg->body.u.tl.num.val = 1;
#ifdef GCP_VER_1_3   
   mgcoTxn = msg->body.u.tl.txns[0];
   if(ROK != mgAllocEventMem((Ptr *)&mgcoTxn, sizeof(MgMgcoTxn)))
   {
      mgFreeEventMem(msg);
      RETVALUE(RFAILED);
   }
   msg->body.u.tl.txns[0] = mgcoTxn;
#else
   MGGETMEM((Ptr *)&(msg->body.u.tl.txns), sizeof(Ptr), (Ptr)msg, ret);
   if (ret != ROK)
   {
      mgFreeEventMem(msg);
      RETVALUE(ret);
   }
   MGGETMEM((Ptr *)&(msg->body.u.tl.txns[0]), sizeof(MgMgcoTxn), 
            (Ptr)msg, ret);
   if (ret != ROK)
   {
      mgFreeEventMem(msg);
      RETVALUE(ret);
   }
   mgcoTxn = msg->body.u.tl.txns[0];
#endif /* GCP_VER_1_3 */
   mgcoTxn->type.pres = PRSNT_NODEF;    
   mgcoTxn->type.val = MGT_TXNREPLY;

   txnReply = &(mgcoTxn->u.reply);
   txnReply->pres.pres = PRSNT_NODEF;
   txnReply->transId.pres = PRSNT_NODEF;
   txnReply->transId.val = transId;
   txnReply->type.pres = PRSNT_NODEF;
   txnReply->type.val = MGT_ACTIONREPLY;
   txnReply->u.arl.num.pres = PRSNT_NODEF;
   txnReply->u.arl.num.val = 1;
   MGGETMEM((Ptr *)&(txnReply->u.arl.repl), sizeof(Ptr), (Ptr)msg, ret);
   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
      RETVALUE(ret);
   }
   MGGETMEM((Ptr *)&(txnReply->u.arl.repl[0]), sizeof(MgMgcoActnReply), 
            (Ptr)msg, ret);
   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
      RETVALUE(ret);
   }
   actionReply = txnReply->u.arl.repl[0];
   actionReply->pres.pres = PRSNT_NODEF;
   actionReply->cxtId.type.pres = PRSNT_NODEF;
   actionReply->cxtId.type.val = MGT_CXTID_NULL;


#ifdef MGT_GCP_VER_1_4
   actionReply->repErrSet.pres.pres = PRSNT_NODEF;
   actionReply->repErrSet.reply.pres.pres = PRSNT_NODEF;
   actionReply->repErrSet.reply.cl.num.pres = PRSNT_NODEF;
   actionReply->repErrSet.reply.cl.num.val = 1;
#else /* MGT_GCP_VER_1_4 */
   actionReply->type.pres = PRSNT_NODEF;
   actionReply->type.val = MGT_CXTCMDREPLY;
   actionReply->u.reply.pres.pres = PRSNT_NODEF;
   actionReply->u.reply.cl.num.pres = PRSNT_NODEF;
   actionReply->u.reply.cl.num.val = 1;
#endif /* MGT_GCP_VER_1_4 */



#ifdef MGT_GCP_VER_1_4
#ifndef GCP_CH
   MGGETMEM((Ptr *)&(actionReply->repErrSet.reply.cl.repl),
            sizeof(Ptr), (Ptr)msg, ret);
#endif /* GCP_CH */
#else /* MGT_GCP_VER_1_4 */
#ifndef GCP_CH
   MGGETMEM((Ptr *)&(actionReply->u.reply.cl.repl),
            sizeof(Ptr), (Ptr)msg, ret);
#endif /* GCP_CH */
#endif /* MGT_GCP_VER_1_4 */

   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
      RETVALUE(ret);
   }



#ifdef MGT_GCP_VER_1_4
#ifndef GCP_CH
   MGGETMEM((Ptr *)&(actionReply->repErrSet.reply.cl.repl[0]),
             sizeof(MgMgcoCmdReply), (Ptr)msg, ret);
#else
   MG_ALLOC_EVNT_MEM((actionReply->repErrSet.reply.cl.repl[0]), 
                                          ret, sizeof(MgMgcoCmdReply));
#endif /* GCP_CH */
#else /* MGT_GCP_VER_1_4 */
#ifndef GCP_CH
   MGGETMEM((Ptr *)&(actionReply->u.reply.cl.repl[0]),
             sizeof(MgMgcoCmdReply), (Ptr)msg, ret);
#else
   MG_ALLOC_EVNT_MEM((actionReply->u.reply.cl.repl[0]), 
                                          ret, sizeof(MgMgcoCmdReply));
#endif /* GCP_CH */
#endif /* MGT_GCP_VER_1_4 */

   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
      RETVALUE(ret);
   }



#ifdef MGT_GCP_VER_1_4
   cmdReply = actionReply->repErrSet.reply.cl.repl[0];
#else /* MGT_GCP_VER_1_4 */
   cmdReply = actionReply->u.reply.cl.repl[0];
#endif /* MGT_GCP_VER_1_4 */


   cmdReply->pres.pres = PRSNT_NODEF;
   cmdReply->type.pres = PRSNT_NODEF;
   cmdReply->type.val = MGT_SVCCHG;
   cmdReply->u.svc.pres.pres = PRSNT_NODEF;
   cmdReply->u.svc.termId.type.pres = PRSNT_NODEF;
   cmdReply->u.svc.termId.type.val = MGT_TERMID_ROOT;
   cmdReply->u.svc.res.type.pres = PRSNT_NODEF;
   cmdReply->u.svc.res.type.val = MGT_ERRDESC;
   cmdReply->u.svc.res.u.err.pres.pres = PRSNT_NODEF;
   cmdReply->u.svc.res.u.err.code.pres = PRSNT_NODEF;
   cmdReply->u.svc.res.u.err.code.val = rspCode;
   

   ret = mgGetMsg(tsap->tsapCfg.memId.region, tsap->tsapCfg.memId.pool,
                 &(mBuf));
   if (ret != ROK)
   {
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
      RETVALUE(ret);
   }
 

   /* This function encodes the message and prepares for transmission,
    * if message is required to be queued , message shall be queued 
    * in this function */


   ret = mgTransmitSrvcChngReply(mBuf, msg,
                                 tsap,
#if    (defined(GCP_PROV_SCTP) ||  defined(GCP_PROV_MTP3))
                                 mgcoTptInfo,
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
                                 srvr, tptAddr
#if (defined (GCP_VER_1_5) && defined(GCP_ASN)) 
                         ,peer->mgcoInfo.encodingScheme
#endif /* GCP_VER_1_5 GCP_ASN */
                                );


   if (ret != ROK)
      mgPutMsg(mBuf);

   MG_FREE_MGCO_EVNT_MEM(msg, TRUE); 
   RETVALUE(ret);
} /* end of mgSendSrvcChngReply () */



#ifdef GCP_MG
/*
*
*       Fun:    mgSelectPeer 
*
*       Desc:   This function selects a new MGC at MG 
*
*       Ret:   Pointer to peer control block 
*
*       Notes: None 
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC Void mgSelectPeer
(
MgPeerCb           **peer,             /* Peer Control Block */
MgSSAPCb           *ssap               /* SSAP Control Block */
)
#else
PUBLIC Void mgSelectPeer(peer, ssap)
MgPeerCb           **peer;             /* Peer Control Block */
MgSSAPCb           *ssap;              /* SSAP Control Block */
#endif
{
   CmLList         *node;              /* Linked List Node */
   CmLList         *startNode;              /* Linked List Node */

   TRC2(mgSelectPeer)

   *peer = NULLP;
   node = NULLP;
   /* mg003.105: Bug fixes */
   startNode = NULLP;

   if (ssap->crntMgc == NULLP)
   {
      /* Start from the first peer in the peerLst */
      CM_LLIST_FIRST_NODE(&(ssap->peerLst), node);
   }
   else
      /* Start from the next node in the current MGC */
      node = ssap->crntMgc->ssapPeerLstNode.next;
      
   if(!node)   
   {   
      CM_LLIST_FIRST_NODE(&(ssap->peerLst), node);
   }
      
   /* mg003.105: Bug fixes */
   /* Store the Starting Node in temporary vairiable */
   startNode = node;

   while (node != NULLP)
   {
      if (((MgPeerCb *)node->node)->state == LMG_PEER_STATE_AWAIT_REG)
      {
         *peer = (MgPeerCb *)(node->node);
         break;
      }
      node = node->next; 

      /* mg003.105: Bug fixes */
      /* [RA]: If we have reached the end of the peer list then start
       *       from the begining again. MG should keep on trying to
       *       contact a MGC indefinately. */
      if (node == NULLP)
      {
         /* Start from the first peer in the peerLst */
         CM_LLIST_FIRST_NODE(&(ssap->peerLst), node);
      }
      /* 
       * compare now the node with starting node i.e. 
       * we have traversed the list once 
       */
      if(startNode == node)
         break;
   }
} /* end of mgSelectPeer () */
#endif /* GCP_MG */

#ifdef GCP_MGC
/*
*
*       Fun:    mgMatchMId      
*
*       Desc:   This function matches mid received in the message with the
*               configured value
*
*       Ret:   Pointer to peer control block 
*
*       Notes: None 
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC S16 mgMatchMId
(
MgPeerCb           *peer,              /* Peer Control Block */
MgMgcoMid          *mid                /* MId */
)
#else
PUBLIC S16 mgMatchMId(peer, mid)   
MgPeerCb           *peer;              /* Peer Control Block */
MgMgcoMid          *mid;               /* MId */
#endif
{
   S16             ret;                /* Return Value */ 

   TRC2(mgMatchMId)

   ret = MG_IGNORE;

   /* This part of the code is kept empty since service user is not
    * expected to send IP address or domain name information in
    * service change address and it should be sent only with
    * servicechaneMGCId if required */
   if (mid->type.val == MGT_MID_DADDRPORT)
   {
      /* Compare the address part with the address configured
       * with SSAP */
   }
   else if (mid->type.val == MGT_MID_DNAMEPORT)
   {
      /* Compare the domain part with the domain configured
       * with SSAP */
   }
   RETVALUE(ret);
   
} /* end of mgMatchMId () */
#endif /* GCP_MGC */


/*
*
*       Fun:    mgCnvrtPeerInfoToMId      
*
*       Desc:   This function convers PeerInfo to MID to be filled in 
*               the outgoing message.
*
*       Ret:   Pointer to peer control block 
*
*       Notes: None 
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC S16 mgCnvrtPeerInfoToMId
(
MgAddrInfo         *peerInfo,          /* Transport Addr Info */
MgMgcoMid          *mid,               /* MID  to be filled */
Ptr                memLstCp            /* Memory list Control point */
)
#else
PUBLIC S16 mgCnvrtPeerInfoToMId(peerInfo, mid, memLstCp)   
MgAddrInfo         *peerInfo;          /* Transport Addr Info */
MgMgcoMid          *mid;               /* MID  to be filled */
Ptr                memLstCp;           /* Memory list Control point */
#endif
{
   S16             ret;                /* Return Value */
   U16             nameLen;            /* Length of the Name */
   U16             len;                /* Length */

   TRC2(mgCnvrtPeerInfoToMId)
   
   len = MG_NONE;
   nameLen = cmStrlen(peerInfo->addr.name);

   /* 
    * Use IP address to be filled in the MID as first preference
    * if both IP Address and domain name are available 
    */
   mid->type.pres = PRSNT_NODEF;
   /* Fixed a bug - changed && to || */
   if ((peerInfo->addr.netAddr.type == CM_NETADDR_IPV4) ||
       (peerInfo->addr.netAddr.type == CM_NETADDR_IPV6))
   {
      /* IP Address is configured */
      mid->type.val = MGT_MID_DADDRPORT;
      mid->u.dAddrPort.pres.pres = PRSNT_NODEF;
      mid->u.dAddrPort.type.pres = PRSNT_NODEF;
      if (peerInfo->addr.netAddr.type == CM_NETADDR_IPV4)
        mid->u.dAddrPort.type.val = MGT_IPV4;
      else
        mid->u.dAddrPort.type.val = MGT_IPV6;
      /* it's ok to use ipv4.val because ipv4 and ipv6 points to
         the same structure */
      MGGETMEM((Ptr *)&(mid->u.dAddrPort.u.ipv4.val), 
               MG_DNAME_FRMT2_LEN, memLstCp, ret);
      if (ret != ROK)
         RETVALUE(RFAILED);
      mid->u.dAddrPort.u.ipv4.pres = PRSNT_NODEF;
      mgConvertIpAddrToAscii(&(peerInfo->addr.netAddr),
                             mid->u.dAddrPort.u.ipv4.val, 
                             MG_DNAME_FRMT2_LEN, &len,
                             LMG_PROTOCOL_MGCO);
      if (len == MG_NONE)
         RETVALUE(RFAILED);
      mid->u.dAddrPort.u.ipv4.len = len;
      if (peerInfo->port.pres == PRSNT_NODEF)
      {
         mid->u.dAddrPort.port.pres = PRSNT_NODEF;
         mid->u.dAddrPort.port.val = peerInfo->port.val;
      }
   }
   else if(nameLen > 0)
   {
      /* Domain name is configured */
      mid->type.val = MGT_MID_DNAMEPORT;
      mid->u.dNamePort.pres.pres = PRSNT_NODEF;
      MGGETMEM((Ptr *)&(mid->u.dNamePort.name.val), 
               nameLen, memLstCp, ret);
      if (ret != ROK)
         RETVALUE(RFAILED);
      mid->u.dNamePort.name.pres = PRSNT_NODEF;
      mid->u.dNamePort.name.len = nameLen;
      cmMemcpy((U8 *)mid->u.dNamePort.name.val,
               (U8 *)peerInfo->addr.name, nameLen);
      if (peerInfo->port.pres == PRSNT_NODEF)
      {
         mid->u.dNamePort.port.pres = PRSNT_NODEF;
         mid->u.dNamePort.port.val = peerInfo->port.val;
      }
   }
#ifdef   GCP_PROV_MTP3
   else if(peerInfo->peerDpc.pres == PRSNT_NODEF)
   {
      U32      shiftedDpc;
      U8       lengthDpc;

      mid->type.val = MGT_MID_MTPADDR;
      mid->u.mtpAddr.pres = PRSNT_NODEF; 


      /*MGGETMEM((Ptr *)&(mid->u.mtpAddr.val), 
               MG_DPC_LEN, memLstCp, ret);*/
      mid->u.mtpAddr.len = MG_DPC_LEN;
      /* zero out MTP address bytes */
      cmMemset(((U8 *)mid->u.mtpAddr.val), 0, 8);
      /* Left Shift the PeerDpc to 2 bits as low
       * order bit represent Network Indicator
       * Convert the peerDpc to String Format */
       shiftedDpc = peerInfo->peerDpc.val << 2;
       MG_MTP_I2A(shiftedDpc, (U8 *) mid->u.mtpAddr.val, lengthDpc);
   }

#endif   /* GCP_PROV_MTP3 */   
   else
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
   
} /* end of mgCnvrtPeerInfoToMId () */


/*
*
*       Fun:    mgAbortHandOff
*
*       Desc:   This function processes Handoff failure and attempts other
*               peers if possible 
*
*       Ret:    None
*
*       Notes: None 
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC Void mgAbortHandOff
(
MgPeerCb           *peer,              /* Peer Control Block */
U16                cause               /* Cause for Abortion */
)
#else
PUBLIC Void mgAbortHandOff(peer, cause)
MgPeerCb           *peer;              /* Peer Control Block */
U16                cause;              /* Cause for Abortion */
#endif
{
#ifdef GCP_MG
   S16             ret;                /* Return Value */
   SpId            alarmInfo;          /* Alarm Information */
   MgPeerCb        *newPeer;           /* New Peer */
   CmLList         *node;              /* Linked List Node */
   MgSSAPCb        *ssap;              /* SSAP Control Block */
  
   TRC2(mgAbortHandOff)
 
   if (peer->mgcoInfo.t.undrHndOffMGC)
   {
       /* 
        * Give status indication to service user indicating handoff failed,
        * user should remove all context regarding the existing association
        * and wait for a successful association with some other MGC in the
        * list 
        */
       mgGenUserStaInd(peer->mgcoInfo.t.undrHndOffMGC, 
                       peer->mgcoInfo.t.undrHndOffMGC->ssap,
                       MGT_STATUS_HANDOFF_FAILED, NULLP);

       /* 
        * Must Delete(or bring peer to configure status) currently active peer 
        * and give indication to service user that Handoff attempt failed 
        */
       peer->mgcoInfo.t.undrHndOffMGC->mntInfo.usrKnows = FALSE;

       /* 
        * Delete Peer is performed here to inform LM in case this peer was
        * not configured by LM 
        */
       mgDeletePeer(peer->mgcoInfo.t.undrHndOffMGC, LMG_EVENT_PEER_REMOVED,
                    LMG_CAUSE_HANDOFF,
                    FALSE);
   }
   ssap = peer->ssap;
   peer->mntInfo.usrKnows = FALSE;
   mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED, cause, FALSE);

   /* 
    * check if currently active MGC was same as primary MGC, if that is the
    * case start from next MGC after that else start from primary MGC 
    */
   CM_LLIST_FIRST_NODE(&(ssap->peerLst), node);
   if (ssap->crntMgc != (MgPeerCb *)node->node)
       ssap->crntMgc = NULLP;
   mgSelectPeer(&newPeer, ssap);
   if (newPeer != NULLP)
   { 
      /* 
       * Valid peer is found; Initiate service change on the new peer 
       * This case is treated as if current active MGC failed 
       */
      ret = mgSendSrvcChng(newPeer, MGT_SVCCHGMETH_FAILOVER,
                           MG_SCRSN_MGC_IMPN_FAIL, NULLP,
                           LMG_INVALID_PEER_PORT,
                           NULLP);
   }
   ssap->crntMgc = newPeer;
   if ((newPeer == NULLP) || (ret != ROK))
   {
      /* No more MGCs available - Should inform LM */
      alarmInfo = ssap->ssapCfg.sSAPId;

 	if(ssap->alarmIndSent == FALSE)  /*cdw add if on 2006.9.28*/
      {
      		/* Send Status Indication to the layer manager */
      		mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                  		LMG_EVENT_ALL_MGC_FAILED, LCM_CAUSE_UNKNOWN, 
                  		LMG_ALARMINFO_SAP,(Ptr)&(alarmInfo), sizeof(SpId), 
                  		LMG_ALARMINFO_INVSAPID);
			ssap->alarmIndSent=TRUE;   /*cdw add on 2006.9.28*/
 		}
      ssap->crntMgc = NULLP;
      /* Assign crntMgc to first primary */
      mgSelectPeer(&(ssap->crntMgc), ssap);
   }
#ifdef ZG
   zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)(peer->ssap),CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_MOD);
#endif /* ZG */
#endif /* GCP_MG */
   RETVOID;
} /* mgAbortHandOff */



/*
*
*       Fun:    mgAbortRedirection
*
*       Desc:   This function processes redirection failure to a new
*               MGC and attempts other peers if possible 
*
*       Ret:    None
*
*       Notes: None 
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PUBLIC Void mgAbortRedirection
(
MgPeerCb           *peer,              /* Peer Control Block */
U16                cause               /* Cause for Abortion */
)
#else
PUBLIC Void mgAbortRedirection(peer, cause)
MgPeerCb           *peer;              /* Peer Control Block */
U16                cause;              /* Cause for Abortion */
#endif
{
#ifdef GCP_MG
   S16             ret;                /* Return Value */
   SpId            alarmInfo;          /* Alarm Information */
   MgPeerCb        *newPeer;           /* New Peer */
   MgSSAPCb        *ssap;              /* SSAP Control Block */
   /* adding new local variable */
   U8              method;             /* method for Service Change msg */
  
   TRC2(mgAbortRedirection)
 
   /* 
    * Must Delete(or bring peer to configure status) current peer 
    * and give indication to service user that redirect attempt failed 
    */
   peer->mntInfo.usrKnows = FALSE;
   ssap = peer->ssap;

   /* 
    * Delete Peer is performed here to inform LM in case this peer was
    * not configured by LM 
    */
   mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED, cause, FALSE);

   /* 
    * Give status indication to service user indicating redirection failed,
    * user should remove all context regarding the existing association
    * and wait for a successful association with some other MGC in the
    * list 
    */
   mgGenUserStaInd(peer, ssap, MGT_STATUS_REDIRECTION_FAILED, NULLP);
   mgSelectPeer(&newPeer, ssap);
   if (newPeer == peer)
   {
      /* 
       * next peer is same as currently failed redirected to peer 
       * try to find next one 
       */
      ssap->crntMgc = newPeer;
      mgSelectPeer(&newPeer, ssap);
   }

   if (newPeer != NULLP)
   { 
      /* Valid peer is found - Initiate service change on the new peer */
      /* If the peer MGC is being contacted again after
       * disconnection, send method as DISCONNECTED **/
      MG_OBTAIN_SVCCHG_METHOD(method, newPeer);
        /*
         * Changed the Servicechange reason code in the service change
         *  message, when the request is send to a secondary  MGC 
         */
      ret = mgSendSrvcChng(newPeer, method,
                           MG_SCRSN_COLD_BOOT, NULLP,
                           LMG_INVALID_PEER_PORT,
                           NULLP);
   }
   ssap->crntMgc = newPeer;
   if ((newPeer == NULLP) || (ret != ROK))
   {
      /* No more MGCs available - Should inform LM */
      alarmInfo = ssap->ssapCfg.sSAPId;

 	  if(ssap->alarmIndSent == FALSE) /*cdw add if by 2006.9.28*/
 	  	{
      		/* Send Status Indication to the layer manager */
      		mgGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, 
                  		LMG_EVENT_ALL_MGC_FAILED, LCM_CAUSE_UNKNOWN, 
                  		LMG_ALARMINFO_SAP, (Ptr)&(alarmInfo), sizeof(SpId), 
                  		LMG_ALARMINFO_INVSAPID);
			ssap->alarmIndSent=TRUE; /*cdw add by 2006.9.28*/
 	  	}
      ssap->crntMgc = NULLP;
      /* Assign crntMgc to first primary */
      mgSelectPeer(&(ssap->crntMgc), ssap);
   }
#ifdef ZG
   zgRtUpd(ZG_CBTYPE_SSAP,(Ptr)(peer->ssap),CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_MOD);
#endif /* ZG */
#endif /* GCP_MG */
} /* mgAbortRedirection */



#ifdef GCP_MG

/*
*
*       Fun:    mgAddIpAddr         
*
*       Desc:   This function adds an IP address to the list of IP 
*               addresses 
*
*       Ret:    None
*
*       Notes: None 
*
*       File:   mg_peer.c
*/
#ifdef ANSI
PRIVATE Void mgAddIpAddr 
(
MgPeerCb           *peer,              /* Peer Control Block */
CmNetAddr          *addr               /* network address */
)
#else
PRIVATE Void mgAddIpAddr(peer, addr)
MgPeerCb           *peer;              /* Peer Control Block */
CmNetAddr          *addr;              /* network address */
#endif
{
   U16             count;              /* Address count */
   CmNetAddr       netAddr;            /* Net Address */

   TRC2(mgAddIpAddr);

   /* 
    * Add this IP address as the first address in netAddr table 
    * shift all entries in peerAddrTbl by one 
    */
   count  =  peer->accessInfo.peerAddrTbl.count;
   for (; count>0; count--)
   {
      cmMemcpy((U8 *)&(peer->accessInfo.peerAddrTbl.netAddr[count]),
               (U8 *)&(peer->accessInfo.peerAddrTbl.netAddr[count-1]),
               sizeof(CmNetAddr));
   }
   /* Add addr entry at 0th index */
   cmMemcpy((U8 *) &netAddr, (U8 *)addr, sizeof(CmNetAddr));

   /* Copy IP Address into Peer Control Block */
   cmMemcpy((U8 *) &(peer->accessInfo.peerAddrTbl.netAddr[0]),
            (CONSTANT U8 *) &(addr), sizeof(CmNetAddr));
   peer->accessInfo.peerAddrTbl.count++;
}
#endif /* GCP_MG */


#endif /* GCP_MGCO */

#ifdef GCP_MGCP
/*
*
*       Fun:    mgFindPeerFrmDmn
*
*       Desc:   This function finds peer from domain name
*
*       Ret:    Pointer to MgPeerCb - SUCCESS
*               NULLP               - FAILURE
*
*       Notes:  None
*
*       File:   mg_peer.c
*
*/

#ifdef ANSI
PUBLIC MgPeerCb * mgFindPeerFrmDmn
(
U8           *val,              /* endpoint name */
U16          len                /* length */
)
#else
PUBLIC MgPeerCb * mgFindPeerFrmDmn(val , len)
U8           *val;               /* endpoint name */
U16          len;                /* length */
#endif
{
   CmNetAddr       ipAddr;             /* IPV4/IPV6 Addr */
   MgPeerCb        *peer;              /* Peer Control Block */
   MgIpAddrEnt     *ipAddrEnt;         /* IP Address Entry */

   TRC2(mgFindPeerFrmDomain)

   peer = NULLP;

   /* First Check for format 1 */
   if (val[0] != '#' && val[0] != '[')
   {
      cmHashListFind(&(mgCb.peerNameLst), val, len, MG_HASH_SEQNMB_DEF, 
                     (PTR *) &peer);
      RETVALUE(peer);
   }


   if ((mgGetIpAddrFromDomainNameStr(len, val, &ipAddr, LMG_PROTOCOL_MGCP)) 
                      != ROK)
      RETVALUE(NULLP);


   /*  Locate the peer using IP Address now */
   ipAddrEnt = NULLP;
   mgFindIpAddrLst(ipAddr.type, &(ipAddr.u.ipv4NetAddr),
                   &(ipAddr.u.ipv6NetAddr), 
                   MG_HASH_SEQNMB_DEF, &ipAddrEnt);

   if (ipAddrEnt != NULLP)
      peer = ipAddrEnt->peer;

   RETVALUE(peer);

} /* mgFindPeerFrmDomain */
#endif /* GCP_MGCP */

#endif /* ifdef MG */

/********************************************************************30**
 
        End of file:     mp_peer.c@@/main/mgcp_rel_1.5_mnt/9 - Tue Jun  7 13:04:55 2005
*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---       pk  1. Initial release.
             mg002.102 vj  1. Modified mgProcessSrvcChng so that during 
                              handoff, mgPrcIncomingTxn is not invoked 
                              twice at the MG side. 
             mg003.102 vj  1. For UDP as transport, the commands to MG should 
                              be sent to the source port used by MG to send 
                              the first command, rather than default port.
             mg004.102 vj  1. Check for validity of midPort in case domain 
                              name is received in mid.
             mg007.102 vj  1. Instead of copying a U32 maxMgcoVersion in the 
                              msg->ver which is a U8, initialize with a proper 
                              value.
                            2. In mgCnvrtPeerInfoToMId, changed len from U8 to U16
             mg008.102 vj   1. In mgRcvDnsRslvCfm, invoke mgCheckEnbSsap, 
                               if required, irrespective of the value of 
                               addrTbl->count.
                            2. In mgRcvDnsRslvCfm, curNumPeer should never 
                               be incremented as this variable is incremented 
                               whenever peerCb is allocated.
                            3. Peer state was getting assigned in the if 
                               condition, instead of comparison. Modified it 
                               in mgProcessSrvcChng.
            mg010.102  vj   1. In mgProcessSrvcChng, initialise origSrvcChndPort
                               with the port number from the server on which 
                               the SVC was received, ir-respective of whether 
                               the transport is TCP or UDP.
                            2. In mgPrcUserRegRsp, when service change address 
                               or mgcId is present with a new TCP redirection 
                               port, then close the old TCP connection, by 
                               starting the idle time with "old connection".
                            3. In mgPrcUserRegRsp, when service change address
                               or mgcId is not present, and transport is TCP, 
                               do not do redirection. Redirection is to be done
                               only when servers are available and transport is
                               UDP.
            mg011.102   vj  1. Added a new function mgInsertPeerCbInLst, which 
                               adds peerCb in appropriate hash lists.
                            2. Modified mgAllocPeerCb, mgDeAllocPeerCb, and 
                               mgRemovePeerAddrs to ensure that in case of
                               MEGACO, the peerCb is in name based list based on
                               MID. In case of MGCO MG, transient scenarios 
                               exist where the peer may be in IP address & 
                               domain name based lists. Further dupPeerPrsnt is
                               applicable only in case of MEGACO MG. Made 
                               changes relating to this new condition throughout
                               the code.
                            3. Invoked MG_FILL_MID_IN_MSG to fill MID in stack 
                               generated messages. This macro obtains the MID 
                               from the configured MID in SSAP. Deleted the call
                               to mgCnvrtPeerInfoToMId.
                            4. Since the macros MG_ISSUE_PEER_STAIND and 
                               MG_COPY_PEERINFO_INTO_TXN have been broken into 
                               MGCP & MGCO specific macros, converted the calls 
                               to each specific macro.
                            5. In case of MGCP MG, for a notified entity peer, 
                               removed the restriction that the first message 
                               from the SU should be a RSIP.
                            6. Modified code handiling service change command 
                               & replies to treat MID as a string.
                            7. Made sure that the mgcIdToTry in cases like 
                               handoff, re-direction to a new MGC, etc is 
                               treated as a transport address and not as MID.
                            8. TCP re-direction to a new port is no longer 
                               aplicable. Made changes in mgPrcPeerConInd to 
                               remove some dead code at MGC side.
                            9. Removed the function mgCnvrtMId as this is no 
                               longer required.
                           10. Modified mgGetPeer and its parameters to bring 
                               it in sync with the new MID based insertion 
                               policy in case of MEGACO.
                           11. Added a new function mgGetAndAdjstPeerInLst, 
                               specific to MGCO MG, which ensures that the 
                               peerCb is removed from any transient lists and 
                               added to MID based list as soon as MID becomes 
                               available.
                           12. Modified the last param of mgSendSrvcChng and 
                               mgCnvrtPeerInfoToMId from MgPeerInfo to 
                               MgAddrInfo.
/main/2      ---      ra   1. GCP 1.3 release
            mg004.103 rg   1. Updated parameters of macro for modified 
                              algorithm for calculation of RTO for
                              retransmitted transactions
            mg010.103 rg   1. Set DISCONNECTED bit in peerflg in function
                              mgDeletePeer()to indicate the loss of 
                              communication with a configured peer.
                           2. Added check for method before sending a Service
                              Change message.
                           3. Reset the DISCONNECTED bit in peerflg once
                              ACTIVE association is established with a peer.
                           4. Added handling of a Handoff message with no
                              mgcId in the message. The MG tries to contact
                              secondary MGCs configured in its list.
                           5. Removed the wildcard from the Service Change
                              message in function mgSendSrvcChng().
            mg011.103 ra   1. Initialize variant to LMG_VER_PROF_MGCO_H248_1_0
                           2. If the peer has been resolved we need to 
                              update the ssap counter also.
            mg012.103 ra   1. Bug Fix - changed && to ||.
            mg014.103 ra   1. Initialized some variables.
            mg015.103 ra   1. Send an error rsp - 402 unauthorized to a
                              service change message received on an MG side
                              from any MGC other than the primary active MGC.
                           2. Now initializing ssap in mgSendSrvcChngReply()
                              on the MG side.
            mg016.103 ra   1. Removed wrong macro call and replaced it
                              with the correct code to populate init.\
                              remotePort.
            mg017.103 ra   1. Added some missing code for Handoff case.
/main/3      ---      ka   1. Changes for Release v 1.4
            mg003.104 ka   1. Corrected the service change reason(code value)
                              for resending the service change message to a secondary
                              MGC
            mg005.104 ra   1. FTHA related changes.
/main/4      ---      pk   1. GCP 1.5 release
            mg001.105 ra   1. TOS related changes for SCTP. If we are
                              the GWY & we receive SrvcChng Handoff or
                              SrvcChng with MgcIdToTry specifying an
                              unknown MGC (not configured), then use the
                              TOS configured in the endpoint.
            mg002.105 ra   1. Extern moved from mg.x for g++ compilation issue
                           2. Remove compilation warnings
                           3. Removed patch reference for 1.3 and 1.4
                           4. Added additional check in case srvr NULL
                           5. Generate the alarm to layer manager 
                              that one of the peer responded
            mg003.105 ps   1. Configure MG/MGC pending limit in Peer control block  
                      dp   2. Bug fixes
                           3. Changes for command indication 
                      ps   4. Reset the negotiated version on the peer once VG is disabled 
            mg004.105 gk   1. Bugfix Start: Change for 2945 (Binary port) usage 
                           2. Added check for transport type
                           3. Bug fix for sending pending with V=1
                           4. Bug Fix : If the method is FORCED, the version should be the
                              negotiated Version
                           5. Bug Fix: If the method is FORCED then no need to send profile
                           6. BugFix: Service change(With method "Forced" and "OOS"
                              Needed at the time of RESTART only
            mg005.105 gk   1. Added new state to support MG in lock/unlock state
            mg007.105 gk   1. Send update only if newpeer is not null
            mg008.105 gk   1. mgSrvConReq need to be call after runtime update
                           2. runtime update need to be generate before generate any
                              lower/upper layer primitive
                           3. Added check whether version negotiation was failed with peer
*********************************************************************91*/
