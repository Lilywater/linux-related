/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
 
     Name:     GCP - Transport Layer Interaction Module
 
     Type:     C source file
  
     Desc:     C Source Code for Transport Layer Interaction Module
 
     File:     mg_tpt.c
  
     Sid:      mp_tpt.c@@/main/mgcp_rel_1.5_mnt/3 - Tue May 31 11:49:16 2005
  
     Prg:      bbk
  
*********************************************************************21*/
 
/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*
*/
 
/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*    
*   
*
*/

 
/*
 * The core of MGC product is implemented in following files:
 *
 *    mg_dns.c      DNS Interaction functions 
 *    mg_tmr.c      Timer Management/Maintenance functions
 *    mg_tpt.c      Transport Layer Interaction functions
 *    mg_trans.c    Transaction Management functions
 *    mg_peer.c     Peer Control Module functions
 *    mg_cord.c     Co-ordinator Module functions
 *    mg_ui.c       MGCP Upper Interface Functions
 *    mg_mi.c       MGCP Layer Management Interface
 *    mg_li.c       MGCP Lower Layer (TUCL) Interface
 *    cm_tenc.c     Common Text Based Encode Engine for MGCP messages
 *    cm_tdec.c     Common Text Based Decode Engine for MGCP messages
 */


/* header include files (.h) */
#include "envopt.h"        /* Environment options */  
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */

#ifdef MG

#include "gen.h"           /* General layer */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common Timer functions */
#include "cm_hash.h"       /* Hash library */
#include "cm_llist.h"      /* Doubly Linked List library */
#include "cm_inet.h"       /* Common Sockets Library */
#include "cm_tpt.h"        /* Common Transport Defines */
#include "cm_tkns.h"       /* Common Tokens Defines */
#include "cm_sdp.h"        /* Session Description Protocol Defines */
#include "cm_mblk.h"       /* Common Memory Manager Defines */
#include "cm_abnf.h"       /* Common ABNF  Defines */
#include "cm_dns.h"        /* common DNS library */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */
#include "hit.h"           /* HIT Interface */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include  "cm_ss7.h"       /* Common SS7 Defines */
#include  "snt.h"          /* MTP3 Interface Defines */
#endif   /* GCP_PROV_MTP3 */

#include "mgt.h"           /* MGT Interface Defines */
#include "lmg.h"           /* MGCP Layer Management */
#include "mg_err.h"        /* MGCP Error */
#include "mg.h"            /* MGCP Defines */
#ifdef ZG
#include "mrs.h"  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer */
#include "ssi.x"           /* System services */
#include "cm5.x"           /* Common timer functions */
#include "cm_hash.x"       /* Hash library */
#include "cm_llist.x"      /* Doubly Linked List library */
#include "cm_inet.x"       /* Common Sockets Library */
#include "cm_tpt.x"        /* Common Transport Definitions */
#include "cm_tkns.x"       /* Common Tokens Defines */
#include "cm_lib.x"        /* Common library functions */
#include "cm_sdp.x"        /* Session Description Protocol Defines */
#include "cm_mblk.x"       /* Common Memory Manager Defines */
#include "cm_abnf.x"       /* Common ABNF  Defines */
#include "cm_dns.x"        /* common dns library */
#include "hit.x"           /* HIT Interface */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3 
#include  "cm_ss7.x"       /* Common SS7 Structure */
#include  "snt.x"          /* MTP3 Interface Structure */
#endif    /* GCP_PROV_MTP3 */

#include "mgt.x"           /* MGT Interface Structures */
#include "lmg.x"           /* MGCP Layer Management */
#include "mg.x"            /* MGCP Data Structures */
#ifdef ZG
#include "mrs.x" 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */


/* local defines, if any */
 
/* local typedefs, if any */
 
/* local externs, if any */

/* forward references */

PUBLIC S16 mgObtainSuConnId  ARGS((
        MgSrvrInitInfo  *initInfo,     /* Server Initialisation Info */
        MgTptSrvr       *srvr,         /* Server Control Block */
        MgTSAPCb        *tsap,         /* TSAP Control Block */
        UConnId         *suConnId,     /* Allocated SuConnId */
        U16             *event         /* Usta Event */
      ));

/* public variable declaration */

/* private variable declaration */


/*
*
*       Fun:    mgObtainSuConnId
*
*       Desc:   This function allocates, a suConnId for a transport server
*               control block
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/
#ifdef ANSI
PUBLIC S16 mgObtainSuConnId 
(
MgSrvrInitInfo     *initInfo,          /* Server Type */
MgTptSrvr          *srvr,              /* Server Control Block */
MgTSAPCb           *tsap,              /* TSAP Control Block */
UConnId            *suConnId,          /* Allocated SuConnId */
U16                *event              /* Usta Event */
)
#else
PUBLIC S16 mgObtainSuConnId (initInfo, srvr, tsap, suConnId, event)
MgSrvrInitInfo     *initInfo;          /* Server Type */
MgTptSrvr          *srvr;              /* Server Control Block */
MgTSAPCb           *tsap;              /* TSAP Control Block */
UConnId            *suConnId;          /* Allocated SuConnId */
U16                *event;             /* Usta Event */
#endif
{
   Bool            found;              /* free suConnId available */
   S16             entryPres;          /* entry is present */
   U32             idx;                /* Index */
   UConnId         lclConnId;          /* connection identifier, local copy */
   PTR             entry;              /* pointer to the entry */

   TRC2(mgObtainSuConnId)

   found = FALSE;  /* initialized the var */

   /* 
    * Allocate a free suConnId to be used for this interface : 
    * suConnId based list should be initialised with duplicate values 
    * allowed to avoid search at the time of hash list insert 
    */
#ifdef ZG
   /* If suConnId is not invalid then no need to allocate suConnid. This may be
    * the case when PSF , while doing runtime update is calling this function */

   if(initInfo->suConnId != MG_INVALID_LSTNRID)
   {
      *suConnId = initInfo->suConnId;
      RETVALUE(ROK); 
   }
#endif /* ZG */
   if (initInfo->srvrType == MG_TCP_CLIENT_CONNECTION)
   {
      lclConnId = tsap->nxtConnIdx;

      if (tsap->connIdxWrapArnd)
      {
         /* 
          * If wrap around has already happened once, check whether the
          * suConnId is used by finding in the hash list 
          */
         for (idx = mgCb.genCfg.maxServers; idx < MG_HIT_MAX_CONNID; idx++)
         {
            entryPres = cmHashListFind (&(tsap->tptSrvrLstCp), 
                                        (U8 *)&lclConnId, sizeof(UConnId)
                                        , 0, &entry);
            if (entryPres != ROK) /* no entry was found */
            {
               found = TRUE;
               *suConnId = lclConnId;
               if (++lclConnId >= MG_HIT_MAX_CONNID)
                  lclConnId = mgCb.genCfg.maxServers;
               tsap->nxtConnIdx = lclConnId;
               break;
            }
            else
            {
               /* If entry was found, try the next one */
               if (++lclConnId >= MG_HIT_MAX_CONNID)
                  lclConnId = mgCb.genCfg.maxServers;
            }
         } /* for */

         if (found == FALSE)
         {
            *event = LMG_EVENT_OUTOF_TCP_CONNS;
            RETVALUE(RFAILED);
         }
      } /* if (wrap around) */
      else
      {
         /* next suConnId in sequence will always be free */
         *suConnId = lclConnId;

         if (++lclConnId >= MG_HIT_MAX_CONNID)
         {
            lclConnId = mgCb.genCfg.maxServers;
            tsap->connIdxWrapArnd = TRUE;
         }

         tsap->nxtConnIdx = lclConnId;
      }
#ifdef ZG
      /* Send a runtime update message for TSAP for variables nxtConnIdx,
       * nxtFreeIdx, connIdxWrapArnd */
      if(((zgChkCRsetStatus()) == TRUE))
      {
         zgRtUpd(ZG_CBTYPE_TSAP, (Ptr)(tsap), CMPFTHA_UPDTYPE_NORMAL, 
                                                      CMPFTHA_ACTN_MOD);
      }
#endif /* ZG */
   } /* Case of client connection */
   else
   {
      /* case of server, find free Id in array based list for servers */
      MG_OBTAIN_FREE_LSTNRID(*suConnId, tsap);

      if (*suConnId == MG_INVALID_LSTNRID)
      {
         *event = LMG_EVENT_OUTOF_TPT_SRVRS;
         RETVALUE(RFAILED);
      }

      tsap->lstnrLst[*suConnId]->lstnrCb = srvr;
   }

   RETVALUE(ROK);

} /* end of mgObtainSuConnId() */



/******************************************************************************/
/*                  Allocate Server Control Block                             */
/******************************************************************************/

/*
*
*       Fun:    mgAllocSrvrCb
*
*       Desc:   This function allocates, initialises and inserts a 
*               server control block
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAllocSrvrCb
(
MgSrvrInitInfo     *initInfo,          /* Initialisation Info */
CmTptAddr          *tptAddr,           /* Transport Server Address */
CmTptParam         *tptParam,          /* Transport Parameters */
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgPeerCb           *peer,              /* Peer Control Block */
Ptr                *srvr,              /* Allocated server */
MgTSAPCb           *tsap               /* TSAP Control Block */
)
#else
PUBLIC S16 mgAllocSrvrCb (initInfo, tptAddr, tptParam, ssap, peer, srvr, tsap)
MgSrvrInitInfo     *initInfo;          /* Initialisation Info */
CmTptAddr          *tptAddr;           /* Transport Server Address */
CmTptParam         *tptParam;          /* Transport Parameters */
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgPeerCb           *peer;              /* Peer Control Block */
Ptr                *srvr;              /* Allocated server */
MgTSAPCb           *tsap;              /* TSAP Control Block */
#endif
{
   UConnId         suConnId;           /* suConnId to be used at HIT */
   U16             event;              /* Layer Mgmt Usta Event */
   MgTptSrvr       *srvrCb;            /* Socket to be allocated */
   CmLListCp       *lCp;               /* Linked List Control Point */

   TRC2(mgAllocSrvrCb)

   /* Initialise */
   suConnId = MG_INVALID_LSTNRID;
   srvrCb   = NULLP;
   lCp      = NULLP;


#if (ERRCLASS & ERRCLS_DEBUG)
   if (tsap == NULLP)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG273, 0,
                 "[MGCP] mgAllocSrvrCb(): NULL tsap argument\n");
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */


   /* Allocate memory for server block */
   if ((srvrCb = (MgTptSrvr *) mgMalloc(sizeof(MgTptSrvr))) == NULLP)
   {
      MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_SMEM_ALLOC_FAIL, 
                             mgCb.init.region, mgCb.init.pool);
      RETVALUE(RFAILED);
   }

   /* Obtain suConnId */
#ifdef ZG
   ZG_INIT_RSETID_IN_MAPCB(&(srvrCb->mapCb));
   if ((zgObtainSuConnId(initInfo, srvrCb, tsap, &suConnId, &event)) != ROK)
   {
      mgDeAlloc((Data *)srvrCb, sizeof(MgTptSrvr));
      MG_GEN_RSRC_CATEG_ALRM(STTSAP, event, mgCb.init.region, mgCb.init.pool);
      RETVALUE(RFAILED);
   }
#else /* ZG */
   if ((mgObtainSuConnId(initInfo, srvrCb, tsap, &suConnId, &event)) != ROK)
   {
      mgDeAlloc((Data *)srvrCb, sizeof(MgTptSrvr));
      MG_GEN_RSRC_CATEG_ALRM(STTSAP, event, mgCb.init.region, mgCb.init.pool);
      RETVALUE(RFAILED);
   }
#endif /* ZG */

   *srvr = (Ptr)srvrCb;

   /* Initialise the server control block */
   srvrCb->suConnId  = suConnId;
   srvrCb->state     = LMG_LSTNR_STATE_NULL;

   /* 
    * In case of TCP connection received from peer, this address shall 
    * represent remote address 
    */
   if (tptAddr != NULLP)
   {
      cmMemcpy((U8 *)&(srvrCb->tptAddr), (CONSTANT U8 *) tptAddr, 
               sizeof(CmTptAddr));
      if (initInfo->srvrType != MG_TCP_CLIENT_CONNECTION)
         cmMemcpy((U8 *)&(srvrCb->cfgTptAddr), (CONSTANT U8 *) tptAddr, 
                  sizeof(CmTptAddr));
   }

   srvrCb->transportType   = initInfo->transportType;
   srvrCb->srvrType        = initInfo->srvrType;
   srvrCb->encodingScheme  = initInfo->encodingScheme;
   srvrCb->t.ssap          = NULLP;
   
   /* If TCP connection */
   if (initInfo->srvrType == MG_TCP_CLIENT_CONNECTION)
   {
      /* Insert server control block into suConnId based hash list */
      if ((cmHashListInsert(&(tsap->tptSrvrLstCp), (PTR) srvrCb, 
                            (U8 *)&(srvrCb->suConnId),
                            sizeof(UConnId))) != ROK)
      {
          mgDeAlloc((Data *)srvrCb, sizeof(MgTptSrvr));
#if (ERRCLASS & ERRCLS_DEBUG)
          MGLOGERROR(ERRCLS_DEBUG, EMG274, (ErrVal) ERRZERO,
                     "[MGCP] mgAllocSrvrCb(): hash list insert failed\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
          RETVALUE(RFAILED);
      }
   }

   if (tptParam)
   {
      cmMemcpy((U8 *)&(srvrCb->tptParam), (U8 *)tptParam, sizeof(CmTptParam));
   }


   /* Perform processing specific to each server type */
   switch (srvrCb->srvrType)
   {
#ifdef GCP_MGCO
      case MG_MGCO_DEFLT_SRVR: 
      {
         /* Add the server to linked list in TSAP */
         if (srvrCb->transportType == LMG_TPT_UDP)
         {
            lCp = &(tsap->mgcoUDPSrvrLst.srvrLstCp);
         }
         else if (mgCb.genCfg.entType == LMG_ENT_GC)
         {
#ifdef GCP_MGC
            lCp = &(tsap->tcpSrvrInfo.srvrLstCp);
#endif /* GCP_MGC */
         }
         else
         {
             mgDeAlloc((Data *)srvrCb, sizeof(MgTptSrvr));
#if (ERRCLASS & ERRCLS_DEBUG)
             MGLOGERROR(ERRCLS_DEBUG, EMG275, (ErrVal) ERRZERO,
                     "[MGCP] mgAllocSrvrCb(): TCP server config at MG\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
             RETVALUE(RFAILED);
         }
         srvrCb->protocol = LMG_PROTOCOL_MGCO;
         srvrCb->t.ssap   = ssap;
      }
      break;

      case MG_ROUND_ROBIN_SRVR_MGCO :
      {
         /* Add the server to MGCO server Linked List */
         if (mgCb.genCfg.entType == LMG_ENT_GC)
         {
#ifdef GCP_MGC
            if (srvrCb->transportType == LMG_TPT_UDP)
            {
               lCp = &(tsap->mgcoUDPSrvrLst.srvrLstCp);
            }
            else
            {
               /* TCP case */
               lCp =  &(tsap->tcpSrvrInfo.srvrLstCp); 
            }
#endif /* GCP_MGC */
         }
         else
         {
#ifdef GCP_MG
            lCp = &(ssap->mgcoUDPSrvrLst.srvrLstCp);
#endif /* GCP_MG */
         }

         srvrCb->protocol = LMG_PROTOCOL_MGCO;
         srvrCb->t.ssap = ssap;
      }
      break;

      case MG_TCP_CLIENT_CONNECTION :
      {
         srvrCb->protocol = LMG_PROTOCOL_MGCO;
         cmInitTimers(&(srvrCb->idleTmr), 1);

         /* 
          * Since peer may not be identified before this function is called ,
          * so no additional processing is performed here in some cases 
          */
         if (peer != NULLP)
         {
            srvrCb->t.peer = peer;
            lCp = &(peer->mgcoInfo.tcpConnLst);
            srvrCb->t.peer->mgcoInfo.numActvConn++;
         }
      }
      break;
#endif /* GCP_MGCO */

#ifdef GCP_MGCP
      case MG_MGCP_DEFLT_SRVR :
      {
         /* Add the server to linked list in TSAP */
         lCp = &(tsap->mgcpUDPSrvrLst.srvrLstCp);
         srvrCb->protocol = LMG_PROTOCOL_MGCP;
         srvrCb->t.ssap = ssap;
         break;
      }

      case MG_ROUND_ROBIN_SRVR_MGCP :
      {
         /* Add the server to MGCP UDP server Linked List */
         if (mgCb.genCfg.entType == LMG_ENT_GC)
         {
#ifdef GCP_MGC
            lCp = &(tsap->mgcpUDPSrvrLst.srvrLstCp);
#endif /* GCP_MGC */
         }
         else
         {
#ifdef GCP_MG
            lCp =  &(ssap->mgcpUDPSrvrLst.srvrLstCp);
#endif /* GCP_MG */
         }
         srvrCb->protocol = LMG_PROTOCOL_MGCP;
         srvrCb->t.ssap = ssap;
      }
      break;
#endif /* GCP_MGCP */

      default :
         break;  /* Assume it to be a dns server */

   } /* switch ( srvrType ) */

   srvrCb->lstnrNode.node = (PTR)srvrCb;
   if (lCp != NULLP)
   {
      cmLListAdd2Tail (lCp, &(srvrCb->lstnrNode));
   }      

   /* mg002.105: initialize tsap in srvrCb */
   srvrCb->tsap = tsap;

   RETVALUE(ROK);

} /* end of mgAllocSrvrCb */




/******************************************************************************/
/*               Deallocate Server Control Block                              */
/******************************************************************************/

/*
*
*       Fun:    mgDeAllocSrvrCb
*
*       Desc:   This function frees resources attached with a server   
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC Void mgDeAllocSrvrCb
(
MgTptSrvr          *srvrCb             /* Pointer to Server control block */
)
#else
PUBLIC Void mgDeAllocSrvrCb (srvrCb)
MgTptSrvr          *srvrCb;            /* Pointer to Server control block */
#endif
{
   MgTSAPCb        *tsap;              /* TSAP Control Block */
   MgSSAPCb        *ssap;              /* SSAP Control Block */
#ifdef GCP_MGCO
   MgPeerCb        *peer;              /* Peer Control block */
#endif /* GCP_MGCO */



   TRC2(mgDeAllocSrvrCb)


   /* Initialise */
   /* get tsap from the server control block */
   tsap = srvrCb->tsap;



   ssap = NULLP;
#ifdef GCP_MGCO
   peer = NULLP;
#endif /* GCP_MGCO */


   if ((srvrCb->srvrType == MG_ROUND_ROBIN_SRVR_MGCP) ||
       (srvrCb->srvrType == MG_ROUND_ROBIN_SRVR_MGCO))
      ssap = srvrCb->t.ssap;
#ifdef GCP_MGCO
   else if (srvrCb->srvrType == MG_TCP_CLIENT_CONNECTION)
      peer = srvrCb->t.peer;
#endif /* GCP_MGCO */


   /* Update DNS Listener pointer, if the listener is DNS Listener */
   if (tsap->dnsInfo.dnsLstnr == srvrCb)
   {
      tsap->dnsInfo.dnsLstnr = NULLP;
      tsap->dnsInfo.dnsState = MG_DNS_STATE_DOWN;
   }
   else if ((srvrCb->srvrType == MG_ROUND_ROBIN_SRVR_MGCP) ||
            (srvrCb->srvrType == MG_MGCP_DEFLT_SRVR))
   {
#ifdef GCP_MGCP
      if (mgCb.genCfg.entType == LMG_ENT_GC)
      {
#ifdef GCP_MGC

               /* Remove this server from TSAP */
               if (tsap->nxtUseMgcpSrvr == srvrCb)
               {
                   tsap->nxtUseMgcpSrvr =
                         mgGetLstnrForTx(NULLP, tsap, LMG_PROTOCOL_MGCP);

                   if (tsap->nxtUseMgcpSrvr == srvrCb)
                      tsap->nxtUseMgcpSrvr = NULLP;
               }
               /* Remove this server from list in TSAP */
               cmLListDelFrm (&(tsap->mgcpUDPSrvrLst.srvrLstCp), 
                              &(srvrCb->lstnrNode));


#endif /* GCP_MGC */
      }
      else
      {
#ifdef GCP_MG
        /*
         * Modified the following condition to ensure that for a round-robin
         * server, SSAP server list is checked, and for default server, TSAP 
         * server list is checked in case of MG.
         */
         if (MG_ROUND_ROBIN_SRVR_MGCP == srvrCb->srvrType) 
         {
            /* Remove this server from SSAP */
            if (ssap->nxtUseMgcpSrvr == srvrCb)
            {
                ssap->nxtUseMgcpSrvr = mgGetLstnrForTx(ssap, tsap,
                                                       LMG_PROTOCOL_MGCP);
                if (ssap->nxtUseMgcpSrvr == srvrCb)
                   ssap->nxtUseMgcpSrvr = NULLP;
            }
            /* Remove this server from list in SSAP */
            cmLListDelFrm (&(ssap->mgcpUDPSrvrLst.srvrLstCp), 
                           &(srvrCb->lstnrNode));
         }
         else /* This means this is a MG_MGCP_DEFLT_SRVR */
         {

                  /* Remove this server from TSAP */
                  if (tsap->nxtUseMgcpSrvr == srvrCb)
                  {
                      tsap->nxtUseMgcpSrvr =
                            mgGetLstnrForTx(NULLP, tsap, LMG_PROTOCOL_MGCP);
                      if (tsap->nxtUseMgcpSrvr == srvrCb)
                         tsap->nxtUseMgcpSrvr = NULLP;
                  }
                  /* Remove this server from list in TSAP */
                  cmLListDelFrm (&(tsap->mgcpUDPSrvrLst.srvrLstCp), 
                                 &(srvrCb->lstnrNode));


         }
#endif /* GCP_MG */
      }
#endif /* GCP_MGCP */
   }
   else if (((srvrCb->srvrType == MG_ROUND_ROBIN_SRVR_MGCO)||
            (srvrCb->srvrType == MG_MGCO_DEFLT_SRVR)) &&
            (srvrCb->transportType == LMG_TPT_UDP))
   {
#ifdef GCP_MGCO
      if ((srvrCb->srvrType == MG_MGCO_DEFLT_SRVR) ||
          (mgCb.genCfg.entType == LMG_ENT_GC))
      {

               /* Remove this server from TSAP */
               if (tsap->nxtUseMgcoSrvr == srvrCb)
               {
                   tsap->nxtUseMgcoSrvr =
                         mgGetLstnrForTx(NULLP, tsap, LMG_PROTOCOL_MGCO);

                   if (tsap->nxtUseMgcoSrvr == srvrCb)
                      tsap->nxtUseMgcoSrvr = NULLP;
               }
#ifdef GCP_MGC
               if (tsap->mgcoUDPSrvrLst.nxtSrvr2Use == srvrCb)
               {
                   tsap->mgcoUDPSrvrLst.nxtSrvr2Use = 
                         mgGetSrvrForRedirection(LMG_TPT_UDP,
                                                 tsap);

                   if (tsap->mgcoUDPSrvrLst.nxtSrvr2Use == srvrCb)
                      tsap->mgcoUDPSrvrLst.nxtSrvr2Use = NULLP;
               }
#endif /* GCP_MGC */
               /* Remove this server from list in TSAP */
               cmLListDelFrm (&(tsap->mgcoUDPSrvrLst.srvrLstCp), 
                              &(srvrCb->lstnrNode));


      }
      else
      {
#ifdef GCP_MG
         /* Remove this server from SSAP */
         if (ssap->nxtUseMgcoSrvr == srvrCb)
         {
             ssap->nxtUseMgcoSrvr = mgGetLstnrForTx(ssap, tsap,
                                                    LMG_PROTOCOL_MGCO);

             if (ssap->nxtUseMgcoSrvr == srvrCb)
                ssap->nxtUseMgcoSrvr = NULLP;
         }
         /* Remove this server from list in SSAP */
         cmLListDelFrm (&(ssap->mgcoUDPSrvrLst.srvrLstCp), 
                        &(srvrCb->lstnrNode));
#endif /* GCP_MG */
      }
#endif /* GCP_MGCO */
   }
   else if (((srvrCb->srvrType == MG_ROUND_ROBIN_SRVR_MGCO) ||
            (srvrCb->srvrType == MG_MGCO_DEFLT_SRVR)) &&
               (srvrCb->transportType == LMG_TPT_TCP))
   {
#ifdef GCP_MGCO
#ifdef GCP_MGC


            /* Since these TCP servers are used for redirection , update
             * next server to be used for redirection */
            if (tsap->tcpSrvrInfo.nxtSrvr2Use == srvrCb)
            {
               tsap->tcpSrvrInfo.nxtSrvr2Use = 
                     mgGetSrvrForRedirection(LMG_TPT_TCP,
                                             tsap);

               if (tsap->tcpSrvrInfo.nxtSrvr2Use == srvrCb)
               {
                  tsap->tcpSrvrInfo.nxtSrvr2Use = NULLP;
               }
            }
            /* Remove this server from list in SSAP */
            cmLListDelFrm (&(tsap->tcpSrvrInfo.srvrLstCp),
                           &(srvrCb->lstnrNode));


#endif  /* GCP_MGC */
#endif  /* GCP_MGCO */
   }
   else if (srvrCb->srvrType == MG_TCP_CLIENT_CONNECTION) 
   {
#ifdef GCP_MGCO
      if (srvrCb->idleTmr.tmrEvnt == MG_IDLE_CONN_TMR)
         mgStopTmr(MG_IDLE_CONN_TMR, (PTR)srvrCb,
                   &(srvrCb->idleTmr));
      /* In case of TCP client connection, remove this connection from the
       * list of connections in peer */
      if (peer != NULLP)
      {
         if (peer->mgcoInfo.nxtUseConn == srvrCb)
         {
            peer->mgcoInfo.nxtUseConn = mgGetNxtUseConnForTx(peer);
            if (peer->mgcoInfo.nxtUseConn == srvrCb)
               peer->mgcoInfo.nxtUseConn = NULLP;
         }
         peer->mgcoInfo.numActvConn--;
         cmLListDelFrm (&(peer->mgcoInfo.tcpConnLst), &(srvrCb->lstnrNode));
      }
#endif /* GCP_MGCO */
   }


   if (srvrCb->srvrType == MG_TCP_CLIENT_CONNECTION)
   {
#ifdef GCP_MGCO      
      /* Delete this connection from suConnId based hash list */
      cmHashListDelete(&(peer->tsap->tptSrvrLstCp), (PTR)srvrCb);
#endif /* GCP_MGCO */      
   }
   else
   {
#ifdef ZG
      if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG */
      {
         /*
          * Free the listener Id allocated to this listener;
          * At this point tsap should have a valid value;
          * if tsap is NULLP, then its an error;
          */
         MG_RELEASE_LSTNR_ID(srvrCb->suConnId, tsap);
      }
#ifdef ZG
      else
      {
          UConnId     id;
          id = (srvrCb->suConnId) & (MG_SUCONNID_VAL_MASK);
          (tsap->lstnrLst[id])->lstnrCb = NULLP;
      }
#endif /* ZG */
   }

   /* Free the memory */
#ifdef ZG
   if(((zgChkCRsetStatus()) == TRUE))
   {
      /* send update for nxtFreeIdx/nxtConnIdx/ connIdxWrarArnd */
      zgRtUpd(ZG_CBTYPE_TSAP, (Ptr)(tsap), CMPFTHA_UPDTYPE_SYNC,
         CMPFTHA_ACTN_MOD);
      /* Send Del update to standby ..and do del mapping for active */
      zgRtUpd(ZG_CBTYPE_TPTSRVR,(Ptr)srvrCb,CMPFTHA_UPDTYPE_SYNC,
          CMPFTHA_ACTN_DEL);
      zgUpdPeer();
      zgDelMapping(ZG_CBTYPE_TPTSRVR, (Ptr)srvrCb);
   }
#endif /* ZG */
   cmMemset ((U8*)srvrCb, 0, sizeof(MgTptSrvr));
   mgDeAlloc((Data *)srvrCb, sizeof(MgTptSrvr));
   srvrCb = NULLP;

   RETVOID;

} /* end of mgDeAllocSrvrCb */




/*
*
*       Fun:    mgBringSrvrToCfgStatus
*
*       Desc:   This function brings server to configuration status but
*       doesnot release the server control block
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC Void mgBringSrvrToCfgStatus
(
MgTptSrvr          *srvrCb             /* Pointer to Server control block */
)
#else
PUBLIC Void mgBringSrvrToCfgStatus (srvrCb)
MgTptSrvr          *srvrCb;            /* Pointer to Server control block */
#endif
{
   MgTSAPCb        *tsap;              /* TSAP Control Block */
   MgSSAPCb        *ssap;              /* SSAP Control Block */


   TRC2(mgBringSrvrToCfgStatus)


   /* Initialise */
   /* find the tsap from the server control block */
   tsap = srvrCb->tsap;


   ssap = NULLP;


   if ((srvrCb->srvrType == MG_ROUND_ROBIN_SRVR_MGCP) ||
       (srvrCb->srvrType == MG_ROUND_ROBIN_SRVR_MGCO))
      ssap = srvrCb->t.ssap;


   /* Update DNS Listener pointer, if the listener is DNS Listener */
   if ((tsap->dnsInfo.dnsLstnr == srvrCb)
  
#ifdef ZG 
         && (tsap->tsapCfg.reCfg.changeOver == FALSE)
#endif /* ZG */
         )
   {
      tsap->dnsInfo.dnsLstnr = NULLP;
      tsap->dnsInfo.dnsState = MG_DNS_STATE_DOWN;
   }
   else if ((srvrCb->srvrType == MG_ROUND_ROBIN_SRVR_MGCP) ||
            (srvrCb->srvrType == MG_MGCP_DEFLT_SRVR))
   {
#ifdef GCP_MGCP
      if ((mgCb.genCfg.entType == LMG_ENT_GC) ||
          (srvrCb->srvrType == MG_MGCP_DEFLT_SRVR))
      {
#ifdef GCP_MGC
         /* Remove this server from TSAP */
         if (tsap->nxtUseMgcpSrvr == srvrCb)
         {
             tsap->nxtUseMgcpSrvr = mgGetLstnrForTx(NULLP, tsap,
                                                    LMG_PROTOCOL_MGCP);

             if (tsap->nxtUseMgcpSrvr == srvrCb)
                tsap->nxtUseMgcpSrvr = NULLP;
         }
#endif /* GCP_MGC */
      }
      else
      {
#ifdef GCP_MG
         /* Remove this server from SSAP */
         if (ssap->nxtUseMgcpSrvr == srvrCb)
         {
             ssap->nxtUseMgcpSrvr = mgGetLstnrForTx(ssap, tsap,
                                                    LMG_PROTOCOL_MGCP);

             if (ssap->nxtUseMgcpSrvr == srvrCb)
                ssap->nxtUseMgcpSrvr = NULLP;
         }
#endif /* GCP_MG */
      }
#endif /* GCP_MGCP */
   }
   else if (((srvrCb->srvrType == MG_ROUND_ROBIN_SRVR_MGCO)||
            (srvrCb->srvrType == MG_MGCO_DEFLT_SRVR)) &&
            (srvrCb->transportType == LMG_TPT_UDP))
   {
#ifdef GCP_MGCO
      if ((mgCb.genCfg.entType == LMG_ENT_GC) ||
          (srvrCb->srvrType == MG_MGCO_DEFLT_SRVR))
      {
#ifdef GCP_MGC
         /* Remove this server from TSAP */
         if (tsap->nxtUseMgcoSrvr == srvrCb)
         {
             tsap->nxtUseMgcoSrvr = mgGetLstnrForTx(NULLP, tsap,
                                                    LMG_PROTOCOL_MGCO);

             if (tsap->nxtUseMgcoSrvr == srvrCb)
                tsap->nxtUseMgcoSrvr = NULLP;
         }
         if (tsap->mgcoUDPSrvrLst.nxtSrvr2Use == srvrCb)
         {
             tsap->mgcoUDPSrvrLst.nxtSrvr2Use = 
                              mgGetSrvrForRedirection(LMG_TPT_UDP,
                                                      tsap);
             if (tsap->mgcoUDPSrvrLst.nxtSrvr2Use == srvrCb)
                tsap->mgcoUDPSrvrLst.nxtSrvr2Use = NULLP;
         }
#endif /* GCP_MGC */
      }
      else
      {
#ifdef GCP_MG
         /* Remove this server from SSAP */
         if (ssap->nxtUseMgcoSrvr == srvrCb)
         {
             ssap->nxtUseMgcoSrvr = mgGetLstnrForTx(ssap, tsap,
                                                    LMG_PROTOCOL_MGCO);

             if (ssap->nxtUseMgcoSrvr == srvrCb)
                ssap->nxtUseMgcoSrvr = NULLP;
         }
#endif /* GCP_MG */
      }
#endif /* GCP_MGCO */
   }
   else if (((srvrCb->srvrType == MG_ROUND_ROBIN_SRVR_MGCO) ||
            (srvrCb->srvrType == MG_MGCO_DEFLT_SRVR)) &&
               (srvrCb->transportType == LMG_TPT_TCP))
   {
#ifdef GCP_MGCO
#ifdef GCP_MGC
      /* Since these TCP servers are used for redirection , update
       * next server to be used for redirection */
      if (tsap->tcpSrvrInfo.nxtSrvr2Use == srvrCb)
      {
         tsap->tcpSrvrInfo.nxtSrvr2Use = 
                       mgGetSrvrForRedirection(LMG_TPT_TCP,
                                               tsap);

         if (tsap->tcpSrvrInfo.nxtSrvr2Use == srvrCb)
         {
            tsap->tcpSrvrInfo.nxtSrvr2Use = NULLP;
         }
      }
#endif  /* GCP_MGC */
#endif  /* GCP_MGCO */
   }
   RETVOID;
} /* end of mgBringSrvrToCfgStatus */



/******************************************************************************/
/*                         Server Open Rquest                                 */
/******************************************************************************/

/*
*
*       Fun:    mgSrvOpenReq
*
*       Desc:   This function interacts with TUCL to open a UDP or TCP server
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgSrvOpenReq
(
MgTptSrvr        *srvrCb,       /* Server */
CmTptParam       *tptParam,     /* Transport Parameters */
CmTptAddr        *srvrAddr      /* Server Address */
)
#else
PUBLIC S16 mgSrvOpenReq (srvrCb, tptParam, srvrAddr)
MgTptSrvr        *srvrCb;       /* Server */
CmTptParam       *tptParam;     /* Transport Parameters */
CmTptAddr        *srvrAddr;     /* Server Address */
#endif
{
   U8              srvcType;           /* Service Type Desired */
   CmIcmpFilter    icmpFilter;         /* ICMP filter */
   MgTSAPCb        *tsap;              /* TSAP Control Block */


   TRC2(mgSrvOpenReq)


   /* use the tsap linked to the server in server cfg */
   tsap = srvrCb->tsap;



#if (ERRCLASS & ERRCLS_DEBUG)
   if (srvrCb->state != LMG_LSTNR_STATE_NULL)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG276, srvrCb->state,
                 "[MGCP] mgSrvOpenReq(): invalid listener state\n");
      RETVALUE(RFAILED);
   }
   if (tsap->state != LMG_SAP_BND_ENB)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG277, srvrCb->state,
                 "[MGCP] mgSrvOpenReq(): invalid TSAP state\n");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */



   /* Update Listener State */
   srvrCb->state   = LMG_LSTNR_STATE_CONNECTING;
   icmpFilter.type = CM_ICMP_NO_FILTER;

   /* Send Connect Request to TUCL */
   if (srvrCb->transportType == LMG_TPT_TCP)
   {
      srvcType = HI_SRVC_TCP_TPKT_HDR;
   }
   else
   {
      /* setting the service type to priority socket to enable
       * multiple messages to be read from the socket in one scheduling */ 
      srvcType = HI_SRVC_UDP_PRIOR;
   }

   /* Send Open Request */
   RETVALUE(MgLiHitServOpenReq(&(tsap->spPst), tsap->tsapCfg.spId, 
                               srvrCb->suConnId, srvrAddr, tptParam, 
                               &(icmpFilter), srvcType));

} /* end of mgSrvOpenReq() */



/******************************************************************************/
/*                         Server Connection Confirm Function                 */
/******************************************************************************/

/*
*
*       Fun:    mgSrvConCfm
*
*       Desc:   This function process the confirmation of the Socket of being
*               successfully opened by TUCL for our use. This primitive is
*               received in case of a server being successfully opened or
*               success of a TCP connection establishment at client side. 
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgSrvConCfm
(
UConnId            spConnId,           /* Service Provider ConnId */
MgTptSrvr          *srvrCb,            /* server */
MgTSAPCb           *tsap,              /* TSAP CB */
CmTptAddr          *locAddr            /* local Address */
)
#else
PUBLIC S16 mgSrvConCfm (spConnId, srvrCb, tsap, locAddr)
UConnId            spConnId;           /* Service Provider ConnId */
MgTptSrvr          *srvrCb;            /* server */
MgTSAPCb           *tsap;              /* TSAP CB */
CmTptAddr          *locAddr;           /* local Address */
#endif
{
   MgSSAPCb        *ssap;              /* SSAP Control Block */
   Bool            skip;               /* Skip the loop */

   TRC2(mgSrvConCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (srvrCb->state != LMG_LSTNR_STATE_CONNECTING)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG278, srvrCb->state,
                 "[MGCP] mgSrvConCfm(): invalid listener state\n");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   /* Initialise variables */
   ssap = srvrCb->t.ssap;
   skip = FALSE;

   /* Update the State of the listener */
   srvrCb->state = LMG_LSTNR_STATE_CONNECTED;

   /* Store the spConnId */
   srvrCb->spConnId = spConnId;

   /* Copy the transport Address - port and IP Address allocated */
   cmMemcpy ((U8 *)&(srvrCb->tptAddr), (CONSTANT U8 *)locAddr, 
             sizeof(CmTptAddr));
#ifdef ZG
   /* send update for server..send "add server" to standby since tptAddr
    * itself is getting modified...at standby first server will be deleted
    * and then added..*/
   zgRtUpd(ZG_CBTYPE_TPTSRVR, (Ptr)srvrCb, CMPFTHA_UPDTYPE_SYNC, 
      CMPFTHA_ACTN_ADD);
   zgUpdPeer();
#endif /* ZG */
#ifdef CM_DNS_LIB
   if (tsap->dnsInfo.dnsLstnr == srvrCb)
   {
      /* DNS is ready for use...update the state */
      tsap->dnsInfo.dnsState = MG_DNS_STATE_UP;
#ifdef ZG
      /* send update for DNSCb */
      zgRtUpd(ZG_CBTYPE_DNS, (Ptr)(&tsap->dnsInfo), CMPFTHA_UPDTYPE_SYNC, 
         CMPFTHA_ACTN_MOD);
#endif /* ZG */
      RETVALUE(ROK);
   }
#endif /* CM_DNS_LIB */

#ifdef GCP_MGCP
   /* Update the relevant lists based on the server type */
   if ((srvrCb->srvrType == MG_ROUND_ROBIN_SRVR_MGCP) ||
       (srvrCb->srvrType == MG_MGCP_DEFLT_SRVR))
   {
      skip = TRUE;
      
      if(skip)
      {
         /* do nothing */
      }

      /*
       * Make sure that in case of MGC, all servers are attached to TSAP,
       * whereas in case of MG, round-robin servers are attached to SSAP,
       * whereas default servers are attached to TSAP.
       */
      if (mgCb.genCfg.entType == LMG_ENT_GC)
      {
#ifdef GCP_MGC
         if (tsap->nxtUseMgcpSrvr == NULLP)
            tsap->nxtUseMgcpSrvr = srvrCb;
#endif /* GCP_MGC */
      }
      else
      {
#ifdef GCP_MG
         if(MG_ROUND_ROBIN_SRVR_MGCP == srvrCb->srvrType)
         {
            if (ssap->nxtUseMgcpSrvr == NULLP)
               ssap->nxtUseMgcpSrvr = srvrCb;
         }
         else
         {
            if (tsap->nxtUseMgcpSrvr == NULLP)
               tsap->nxtUseMgcpSrvr = srvrCb;
         }
#endif /* GCP_MG */
      }
   }
#endif /* GCP_MGCP */

#ifdef GCP_MGCO

   if (skip == FALSE)
   {
      if ((srvrCb->srvrType == MG_ROUND_ROBIN_SRVR_MGCO) ||
           (srvrCb->srvrType == MG_MGCO_DEFLT_SRVR))
      {
        /* For the UDP case , update relevant lists based on server type*/
        if (srvrCb->transportType == LMG_TPT_UDP)
        {
          /*
           * Make sure that in case of MGC, all servers are attached to TSAP,
           * whereas in case of MG, round-robin servers are attached to SSAP,
           * whereas default servers are attached to TSAP.
           */
            if (mgCb.genCfg.entType == LMG_ENT_GC)
            {
#ifdef GCP_MGC
               if (tsap->nxtUseMgcoSrvr == NULLP)
                  tsap->nxtUseMgcoSrvr = srvrCb;
               if (tsap->mgcoUDPSrvrLst.nxtSrvr2Use == NULLP)
                  tsap->mgcoUDPSrvrLst.nxtSrvr2Use = srvrCb;
#endif /* GCP_MGC */
            }
            else
            {
#ifdef GCP_MG
               if(MG_ROUND_ROBIN_SRVR_MGCO == srvrCb->srvrType)
               {
                  if (ssap->nxtUseMgcoSrvr == NULLP)
                     ssap->nxtUseMgcoSrvr = srvrCb;
               }
               else
               {
                  if (tsap->nxtUseMgcoSrvr == NULLP)
                     tsap->nxtUseMgcoSrvr = srvrCb;
               }
#endif /* GCP_MG */
            }
         }
         else
         {
#ifdef GCP_MGC
            /* TCP Transport */
            if (tsap->tcpSrvrInfo.nxtSrvr2Use == NULLP)
               tsap->tcpSrvrInfo.nxtSrvr2Use = srvrCb;
#endif /* GCP_MGC */
         }
      }
      else
      {
         /* It is a TCP Connection */
         if (srvrCb->t.peer->mgcoInfo.nxtUseConn == NULLP)
         {
            srvrCb->t.peer->mgcoInfo.nxtUseConn = srvrCb;
         }

         /* TCP Connection for the peer is up...process it */
         mgPrcPeerConCfm(srvrCb->t.peer);
      }

   }
#endif /* GCP_MGCO */


#ifdef ZG
   /*
    *    with multiple TSAPs, only one Service Change
    *         should be sent. A logic has to be added to PSF to
    *         wait for all server/endpoint confirmations before sending
    *         service change. Also how do we decide which TSAP to use?
    */
   if(mgCb.genCfg.entType == LMG_ENT_GW)
   {
#ifdef GCP_MG
      /* re-establish assoc with MGC only if transport
       *            is not UDP since for UDP the association was
       *            not reset. However,it might have got disconnected
       *            because of retransmission timeouts even for
       *            UDP. In that unlikely case, we still can't send
       *            registration message because we did not remove
       *            the txns in the list. We shall let the retransmission
       *            method discover that the association has been lost.
       *            The philosophy is that we shall be optimistic that
       *            the TUCL recovery does not take so much time so as
       *            to cause the association with the MGC to be closed.
       */
      if (tsap->tsapCfg.reCfg.changeOver == TRUE)
      {
         if (srvrCb->transportType != LMG_TPT_UDP)
            mgSendRegReq(srvrCb, tsap); /* changeOver is set to FALSE in
                                         * this function */
         else
         {
            tsap->tsapCfg.reCfg.changeOver = FALSE;
            mgGenStaInd (STSSAP, LCM_CATEGORY_PROTOCOL, 
               LMG_EVENT_TSAP_RECVRY_SUCCESS, LMG_CAUSE_UNKNOWN, 
               LMG_ALARMINFO_NONE, (Ptr)NULLP, 0, LMG_ALARMINFO_INVSAPID);
            /* Send status ind to service user */
            mgGenUserStaInd(NULLP,NULLP, MGT_STATUS_SAP_RECVRY_SUCCESS, NULLP);
         }
      }
#endif /* GCP_MG */
   }
   else
   {
      if (tsap->tsapCfg.reCfg.changeOver == TRUE)
      {
         tsap->tsapCfg.reCfg.changeOver = FALSE;
         mgGenStaInd (STSSAP, LCM_CATEGORY_PROTOCOL, 
            LMG_EVENT_TSAP_RECVRY_SUCCESS, LMG_CAUSE_UNKNOWN, 
            LMG_ALARMINFO_NONE, (Ptr)NULLP, 0, LMG_ALARMINFO_INVSAPID);
         /* Send status ind to service user */
         mgGenUserStaInd(NULLP,NULLP, MGT_STATUS_SAP_RECVRY_SUCCESS , NULLP);
      }
   }
#endif /* ZG */
    
   /* Check of ssap enable has been completed. If not do it now 
      since the server is up */
   if(LMG_SAP_UBND_DIS != ssap->state)
      mgCheckEnbSsap(ssap);
   RETVALUE(ROK);

} /* end of mgSrvConCfm */




/******************************************************************************/
/*                       Disconnect Server Function                           */
/******************************************************************************/

/*
*
*       Fun:    mgSrvDiscReq
*
*       Desc:   This function instructs TUCL to close a TCP or UDP server or a
*               TCP connection
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC Void mgSrvDiscReq
(
MgTptSrvr          *srvrCb,            /* Server */
Bool               delReqd             /* Delete Required */
)
#else
PUBLIC Void mgSrvDiscReq (srvrCb, delReqd)
MgTptSrvr          *srvrCb;            /* Server */
Bool               delReqd;            /* Delete Required */
#endif
{
   MgTSAPCb        *tsap;              /* TSAP Control Block */
   UConnId         conId;              /* ConnId to be used over HIT */
   U8              choice;             /* Choice of ConId used over HIT */


   TRC2(mgSrvDiscReq)



   /* find out the tsap from the server control block */
   tsap      = srvrCb->tsap;



   conId     = MG_INVALID_LSTNRID;

   /* If MgLiHitServOpenReq() has been sent, send disconnet too */
   if (srvrCb->state != LMG_LSTNR_STATE_NULL)
   {
      if (srvrCb->state == LMG_LSTNR_STATE_CONNECTED)
      {
         conId  = srvrCb->spConnId;
         choice = HI_PROVIDER_CON_ID;
         /* Decrement active connection count in Peer */
#ifdef GCP_MGCO
         if ((srvrCb->srvrType == MG_TCP_CLIENT_CONNECTION) &&
             (srvrCb->t.peer != NULLP) && (delReqd == FALSE))
            srvrCb->t.peer->mgcoInfo.numActvConn--;
#endif /* GCP_MGCO */
      }
      else
      {
         conId  = srvrCb->suConnId;
         choice = HI_USER_CON_ID;    
      }

      /* Update Listener State */
      srvrCb->state = LMG_LSTNR_STATE_NULL;
   }

   /* 
    * Release the resources attached to the listener
    * initiated by MGCP layer
    */
   if (delReqd == TRUE)
   {
      mgDeAllocSrvrCb(srvrCb);
   }
   else
   {
      /* Copy the configured address to tptAddr */
      cmMemcpy((U8 *) &(srvrCb->tptAddr), (U8 *) &(srvrCb->cfgTptAddr),
               sizeof(CmTptAddr));
      /* should we take this server out of the next use servers as
       * well, make a common function */
      mgBringSrvrToCfgStatus(srvrCb);
#ifdef ZG
      /* Send Mod Update to Standby */
      zgRtUpd(ZG_CBTYPE_TPTSRVR,(Ptr)srvrCb,CMPFTHA_UPDTYPE_SYNC,
         CMPFTHA_ACTN_MOD);
#endif /* ZG */
   }

   /* Send Disconnect to HIT if needed */
   if (conId != MG_INVALID_LSTNRID)
   {
      CmTptParam   tparam;             /* Tranport Parameters */

      tparam.type = CM_TPTPARAM_NOTPRSNT;

      /* Send Disconnect to TUCL, if changeOver flag is TRUE this means 
       * Service provider is dead */
      if(tsap->state == LMG_SAP_BND_ENB)
      {
#ifdef ZG
            if((((zgChkCRsetStatus()) == TRUE))&&
               (tsap->tsapCfg.reCfg.changeOver == FALSE))
#endif /* ZG */
            {
               MgLiHitDiscReq(&(tsap->spPst), tsap->tsapCfg.spId, 
                     choice, conId, HI_CLOSE, &tparam);
            }
      }
   }
   RETVOID;

} /* end of mgSrvDiscReq */



/******************************************************************************/
/*               Server Diconnect Indication Function                         */
/******************************************************************************/

/*
*
*       Fun:    mgSrvDiscInd
*
*       Desc:   This function indicates that a TCP/UDP server or a TCP
*               Connection has gone down
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC Void mgSrvDiscInd
(
MgTptSrvr          *srvrCb             /* Server */
)
#else
PUBLIC Void mgSrvDiscInd (srvrCb)
MgTptSrvr          *srvrCb;            /* Server */
#endif
{
   U16             event;              /* Status Indication Event */
   MgTptSrvSta     tptAlarm;           /* Alarm Information */

   TRC2(mgSrvDiscInd)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (srvrCb->state == LMG_LSTNR_STATE_NULL)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG279, srvrCb->state,
                 "[MGCP] mgSrvDiscInd(): invalid server state\n");
      RETVOID;
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   /* Initialise */
   event = 0;

   if ((srvrCb->srvrType == MG_MGCO_DEFLT_SRVR) ||
       (srvrCb->srvrType == MG_MGCP_DEFLT_SRVR))
   {
      /* Ddefault listener went down, inform  Layer Manager */
      event = LMG_EVENT_TPTSRV;

      /* Fill the alarm Information */
      cmMemcpy((U8 *)&(tptAlarm.tptAddr), 
               (CONSTANT U8 *)&(srvrCb->tptAddr), sizeof(CmTptAddr));

      tptAlarm.state = srvrCb->state;
#ifdef ZG
      if (srvrCb->tsap->tsapCfg.reCfg.changeOver == TRUE)
      {
         mgGenStaInd (STSSAP, LCM_CATEGORY_PROTOCOL, 
            LMG_EVENT_TSAP_RECVRY_FAILED, LMG_CAUSE_TPT_FAILURE, 
            LMG_ALARMINFO_NONE, (Ptr)NULLP, 0, LMG_ALARMINFO_INVSAPID);
         /* Send status ind to service user */
         mgGenUserStaInd(NULLP,NULLP, MGT_STATUS_SAP_RECVRY_FAILED,
            NULLP);         
         srvrCb->tsap->tsapCfg.reCfg.changeOver = FALSE;
      }
#endif /* ZG */
   }
#ifdef GCP_MGCO
   else if (srvrCb->srvrType == MG_TCP_CLIENT_CONNECTION)
   {
      MgPeerCb        *peer;              /* Peer Control Block */

      peer = srvrCb->t.peer;

      /* case of TCP client connection */
      if (srvrCb->t.peer != NULLP)
      {
#ifdef ZG
         if (srvrCb->tsap->tsapCfg.reCfg.changeOver == TRUE)
         {
            /* Send status ind to service user */
            mgGenUserStaInd(NULLP,NULLP, MGT_STATUS_SAP_RECVRY_FAILED,
               NULLP);         
            srvrCb->tsap->tsapCfg.reCfg.changeOver = FALSE;
         }
#endif /* ZG */
         mgDeAllocSrvrCb(srvrCb);
         srvrCb = NULLP;
         mgPrcPeerDiscInd(peer);
         RETVOID;
      }
   }
#endif /* GCP_MGCO */

   /* Free the resources attached with the listener */
   mgDeAllocSrvrCb(srvrCb);
   srvrCb = NULLP;

   if (event == LMG_EVENT_TPTSRV)
   {
      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERNAL, event, LMG_CAUSE_TPT_FAILURE,
                   LMG_ALARMINFO_SRVR, (Ptr) &(tptAlarm), sizeof(MgTptSrvSta), 
                   LMG_ALARMINFO_INVSAPID);
   }

   RETVOID;

} /* end of mgSrvDiscInd */



/******************************************************************************/
/*                         Data Reuest Function                               */
/******************************************************************************/

/*
*
*       Fun:    mgSrvDatReq
*
*       Desc:   This function transmits data over a listener
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgSrvDatReq
(
MgTptSrvr          *srvrCb,            /* Pointer to Server control block */
CmTptAddr          *remoteAddr,        /* Destination Transport Address */
Buffer             *mBuf               /* Data buffer to transmit */
)
#else
PUBLIC S16 mgSrvDatReq (srvrCb, remoteAddr, mBuf)
MgTptSrvr          *srvrCb;            /* Pointer to Server control block */
CmTptAddr          *remoteAddr;        /* Destination Transport Address */
Buffer             *mBuf;              /* Data buffer to transmit */
#endif
{
   MgTSAPCb        *tsap;              /* TSAP Control Block */


   TRC2(mgSrvDatReq)


#if (ERRCLASS & ERRCLS_DEBUG)
   if (srvrCb->state != LMG_LSTNR_STATE_CONNECTED)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG280, srvrCb->state,
                 "[MGCP] mgSrvDatReq(): invalid listener state\n");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */



   /* find the tsap from the server control block */
   tsap = srvrCb->tsap;



#ifdef DEBUGP
   /*
    * Put the existing SPrntMsg inside GCP_ACC_TESTS as this printing is
    * needed for acceptance tests
    */
#ifdef GCP_ACC_TESTS
   SPrntMsg(mBuf, 0, 0);
#endif /* GCP_ACC_TESTS */

#endif /* DEBUGP */

   /* Ensure TSAP is in proper State for Transmission */
   if (tsap->state != LMG_SAP_BND_ENB)
   {
      mgPutMsg(mBuf);
      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERNAL, LMG_EVENT_DATA_TX, 
                   LCM_CAUSE_INV_STATE,
                   LMG_ALARMINFO_NONE, (Ptr) NULLP,0, LMG_ALARMINFO_INVSAPID);
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG281, tsap->state,
                 "[MGCP] mgSrvDatReq(): invalid tsap state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }

   /* Generate Trace Indication if Required */
   if (srvrCb->protocol == LMG_PROTOCOL_MGCO)
   {
      mgGenTrcInd (tsap, MG_NONE, LMG_TRC_EVENT_MGCOTX, NULLP, mBuf);
   }
   else
   if (srvrCb->protocol == LMG_PROTOCOL_MGCP)
   {
      mgGenTrcInd (tsap, MG_NONE, LMG_TRC_EVENT_MGCPTX, NULLP, mBuf);
   }
   else
   {
      mgGenTrcInd (tsap, MG_NONE, LMG_TRC_EVENT_DNSTX, NULLP, mBuf);
   }

   /* If TCp */
   if (srvrCb->transportType == LMG_TPT_TCP)
   {
      MgLiHitDatReq (&(tsap->spPst), tsap->tsapCfg.spId, srvrCb->spConnId, 
                     mBuf);
   }
   else
   {
      /* 
       * UDP case : remote address must be valid : to be changed as per
       * latest HI release ( HI_REL_1_3 ) 
       */
      CmIpHdrParm       ipHdrParm;
      CmTptParam        tPar;
      ipHdrParm.type = CM_HDRPARM_NOTPRSNT;
      tPar.type = CM_TPTPARAM_NOTPRSNT;
#ifdef HI_REL_1_4
      /* HI Release 1.4 has additional parameter ( transport parameter) */
      MgLiHitUDatReq (&(tsap->spPst), tsap->tsapCfg.spId, srvrCb->spConnId, 
                      remoteAddr, &(srvrCb->tptAddr), &ipHdrParm,
                      &tPar, mBuf);
#else  /* HI_REL_1_4 */
      MgLiHitUDatReq (&(tsap->spPst), tsap->tsapCfg.spId, srvrCb->spConnId, 
                      remoteAddr, &(srvrCb->tptAddr), &ipHdrParm, mBuf);
#endif /* HI_REL_1_4 */
   }
   RETVALUE(ROK);

} /* end of mgSrvDatReq */



/******************************************************************************/
/*                      DNS Resolve Request Function                          */
/******************************************************************************/

#ifdef CM_DNS_LIB

/*
*
*       Fun:    mgSndRslvReqToDns
*
*       Desc:   This function transmits data to DNS
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgSndRslvReqToDns
(
Ptr                txFuncParam,        /* Pointer to Listener control block */
CmTptAddr          *remoteAddr,        /* Destination Transport Address */
Buffer             *mBuf               /* Data buffer to transmit */
)
#else
PUBLIC S16 mgSndRslvReqToDns (txFuncParam, remoteAddr, mBuf)
Ptr                txFuncParam;        /* Pointer to Listener control block */
CmTptAddr          *remoteAddr;        /* Destination Transport Address */
Buffer             *mBuf;              /* Data buffer to transmit */
#endif
{
   MgTSAPCb         *tsap;             /* TSAP Control Block */
   MgTptSrvr        *srvrCb;           /* Server Control Block */
   Buffer           *newMbuf;          /* Message Buffer */
   MgDnsTxFuncParam *reqParam;         /* DNS Request Parameters */
   MgPeerCb         *peer;             /* Peer Control Block */


   TRC2(mgSndRslvReqToDns)



   if (!((mgCb.dnsTsap != MG_INVALID_TSAP_ID) &&
         (tsap = mgCb.tSAPLst[mgCb.dnsTsap])))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG282, 0,
                 "[MGCP] mgSrvDatReq(): DNS listener not configured\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }



   reqParam = (MgDnsTxFuncParam *) txFuncParam;
   srvrCb   = reqParam->srvr;
   peer     = reqParam->peer;

   /* Check for valid DNS listener */
   if (srvrCb == NULLP || tsap->dnsInfo.dnsLstnr != srvrCb)
   {
      if(peer)
      {
        peer->mntInfo.resOrder = MG_NONE;
      }
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG283, 0,
                 "[MGCP] mgSrvDatReq(): invalid listener \n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }

#if (ERRCLASS & ERRCLS_DEBUG)
   if (srvrCb->state != LMG_LSTNR_STATE_CONNECTED)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG284, srvrCb->state,
                 "[MGCP] mgSrvDatReq(): invalid listener state\n");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   /* 
    * On DNS Resolve Request Time out we use the same buffer as one passed 
    * as an argument to this function and hence avoid encoding.
    * Since TUCL frees the buffer on data request, we increment the 
    * buffer reference count here
    */

   /* Store the buffer only if DNS retransmission is enabled */
   if (tsap->tsapCfg.reCfg.dnsCfg.dnsRslvTmr.enb == TRUE)
   {
      peer->dnsReq = mBuf;

      if ((SAddMsgRef (mBuf, tsap->tsapCfg.memId.region, 
                       tsap->tsapCfg.memId.pool, &newMbuf)) != ROK)
      {
         /* 
          * Ooops...now we will have to wait till Retransmission timer expires
          */ 
        RETVALUE(ROK);
      }
      /* Send DNS request */
      mgSrvDatReq(srvrCb, remoteAddr, newMbuf);
   }
   else
   {
      /* Send DNS request */
      mgSrvDatReq(srvrCb, remoteAddr, mBuf);
   }

   RETVALUE(ROK);

} /* end of mgSndRslvReqToDns */
#endif /* CM_DNS_LIB */




/******************************************************************************/
/*                   TCP  connection Request  Function                        */
/******************************************************************************/

#ifdef GCP_MGCO
/*
*
*       Fun:    mgSrvConReq
*
*       Desc:   This function interacts with TUCL to open a TCP connection to 
*               the destination address specified. 
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgSrvConReq
(
MgTptSrvr          *srvrCb,            /* Server */
CmTptParam         *tptParam,          /* Transport Parameters */
MgTSAPCb           *tsap,              /* TSAP CB */
CmTptAddr          *srvrAddr           /* Remote Server Address */
)
#else
PUBLIC S16 mgSrvConReq (srvrCb, tptParam, tsap, srvrAddr)
MgTptSrvr          *srvrCb;            /* Server */
CmTptParam         *tptParam;          /* Transport Parameters */
MgTSAPCb           *tsap;              /* TSAP CB */
CmTptAddr          *srvrAddr;          /* Remote Server Address */
#endif
{
   CmTptAddr       lclAddr;            /* Local Address */

   TRC2(mgSrvConReq)
   

#if (ERRCLASS & ERRCLS_DEBUG)
   if (srvrCb->state != LMG_LSTNR_STATE_NULL)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG285, srvrCb->state,
                 "[MGCP] mgSrvConReq(): invalid listener state\n");
      RETVALUE(RFAILED);
   }
   if (tsap->state != LMG_SAP_BND_ENB)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG286, tsap->state,
                 "[MGCP] mgSrvConReq(): invalid TSAP state\n");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */


   /* link the tsap and the connection CB */
   srvrCb->tsap = tsap;


   
   /* Update Listener State */
   srvrCb->state = LMG_LSTNR_STATE_CONNECTING;

   /* This function can only be invoked at the master */
#ifdef ZG
   zgRtUpd(ZG_CBTYPE_TPTSRVR, (Ptr)srvrCb, CMPFTHA_UPDTYPE_SYNC, 
       CMPFTHA_ACTN_MOD);
#endif /* ZG */

   lclAddr.type = CM_TPTADDR_NOTPRSNT;

   /* 
    * Pick address information in case of MEGACO from userInfo. Further, since 
    * MID has become in-dependent of the IP addr/Port numebr where the MG
    * is running, open the TCP connection from any port.
    */
   /* Get local address from MId in SSAP, if available */
   if (srvrCb->t.peer->ssap->ssapCfg.userInfo.dname.netAddr.type == 
       CM_NETADDR_IPV4)
   {
      lclAddr.type = CM_TPTADDR_IPV4;
      lclAddr.u.ipv4TptAddr.address = 
         srvrCb->t.peer->ssap->ssapCfg.userInfo.dname.netAddr.u.ipv4NetAddr;
      lclAddr.u.ipv4TptAddr.port = CM_INPORT_ANY;
   }
   else if (srvrCb->t.peer->ssap->ssapCfg.userInfo.dname.netAddr.type == 
            CM_NETADDR_IPV6)
   {
      lclAddr.type = CM_TPTADDR_IPV6;
      MG_FILL_TPTADDR_FRM_NETADDR(&lclAddr, 
                                  &(srvrCb->t.peer->ssap->ssapCfg.userInfo.dname.netAddr));
      MG_FILL_TPTADDR_PORT(&lclAddr, CM_INPORT_ANY);
   }


   /* Send Connect Request to TUCL */
   MgLiHitConReq (&(tsap->spPst), tsap->tsapCfg.spId, srvrCb->suConnId, 
                  srvrAddr , &lclAddr, tptParam, HI_SRVC_TCP_TPKT_HDR);

   RETVALUE(ROK);

} /* end of mgSrvConReq */




/******************************************************************************/
/*              TCP Connection Indication Processing Function                 */
/******************************************************************************/

/*
*
*       Fun:    mgSrvConInd
*
*       Desc:   This function processes the receipt of a TCP connection from
*               the remote end. This function doesnot issue HitDiscReq in case
*               of error but just returns failure to calling function which
*               issues HitDiscReq
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgSrvConInd
(
MgTptSrvr          *srvrCb,            /* Server on which connection received */
CmTptAddr          *tptAddr,           /* Remote Transport Address */
MgTSAPCb           *tsap,              /* TSAP control block */
UConnId            spConnId            /* Service provider connection Id */
)
#else
PUBLIC S16 mgSrvConInd (srvrCb, tptAddr, tsap, spConnId)
MgTptSrvr          *srvrCb;            /* Server on which connection received */
CmTptAddr          *tptAddr;           /* Remote Transport Address */
MgTSAPCb           *tsap;              /* TSAP control block */
UConnId            spConnId;           /* Service provider connection Id */
#endif
{
   S16             ret;                /* local return */
   MgSrvrInitInfo  initInfo;           /* Connection initialisation Info */
   MgTptSrvr       *allocSrvrCb;       /* new TCP connection received */


   TRC2(mgSrvConInd)
   

   initInfo.transportType  = LMG_TPT_TCP;
   initInfo.srvrType       = MG_TCP_CLIENT_CONNECTION;
   /* 
    * Encoding scheme should be same as what is configured on the TCP server
    * on which this connection is received 
    */
   initInfo.encodingScheme = srvrCb->encodingScheme;
#ifdef ZG
   initInfo.suConnId = MG_INVALID_LSTNRID;
   initInfo.peerId = MG_INVALID_PEERID;
#endif /* ZG */

   ret = mgAllocSrvrCb(&initInfo, tptAddr, NULLP, NULLP, NULLP, 
                       (Ptr *)&allocSrvrCb, tsap);
   if (ret != ROK)
   {
      /* Allocation of server control block failed */
      RETVALUE(RFAILED);
   }


   /*
    *   link the tsap and the connection CB;
    *   srvrCb (the server on which this connection
    *   is received) already has its tsap field
    *   linked to this tsap;
    */
   allocSrvrCb->tsap = tsap;


   allocSrvrCb->spConnId = spConnId;

   ret = mgPrcPeerConInd(allocSrvrCb, tsap, srvrCb);

   if (ret != ROK)
   {
      mgDeAllocSrvrCb(allocSrvrCb);
      RETVALUE(RFAILED);
   }
   cmMemcpy((U8 *)&(allocSrvrCb->cfgTptAddr), (U8 *)&(srvrCb->tptAddr), 
            sizeof(CmTptAddr));
   allocSrvrCb->state = LMG_LSTNR_STATE_CONNECTED;
#ifdef ZG
   /* send runtime update and do add mapping */
   ZG_INIT_RSETID_IN_MAPCB(&(allocSrvrCb->mapCb));
   zgAddMapping(ZG_CBTYPE_TPTSRVR, (Ptr)allocSrvrCb);
   zgRtUpd(ZG_CBTYPE_TPTSRVR, (Ptr)allocSrvrCb,
      CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_ADD);
#endif /* ZG */
   /* Send Connection Response to TUCL */
   MgLiHitConRsp (&(tsap->spPst), tsap->tsapCfg.spId, allocSrvrCb->suConnId, 
                  allocSrvrCb->spConnId);
   RETVALUE(ROK);

} /* end of mgSrvConInd */





#ifdef    GCP_PROV_SCTP


/*----------------------------------------------------------------------------*/
/*                  New Functions added for supporting SCTP                   */
/*----------------------------------------------------------------------------*/








/******************************************************************************/
/*                         Server Open Rquest                                 */
/******************************************************************************/

/*
*
*       Fun:    mgEndpOpenReq
*
*       Desc:   This function interacts with SCTP to open an end point
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgEndpOpenReq
(
MgTSAPCb           *tsap,              /* TSAP Control Block */
MgEndpCfg          *cfg                /* endpoint configuration pointer */
)
#else
PUBLIC S16 mgEndpOpenReq (tsap, cfg)
MgTSAPCb           *tsap;              /* TSAP Control Block */
MgEndpCfg          *cfg;               /* endpoint configuration pointer */
#endif
{
   CmNetAddr       intfAddr;           /* TSAP Control Block */


   TRC2(mgEndpOpenReq)


   cmMemset ((U8 *)&intfAddr, 0, sizeof(CmNetAddr));

   intfAddr.type = CM_NETADDR_IPV4;
   intfAddr.u.ipv4NetAddr = CM_INET_INADDR_ANY;

   /* mg001.105: added support for TOS cfg */
#ifdef    GCP_MG
   if (PRSNT_NODEF == cfg->defaultTos.pres)
      tsap->endpCb.defaultTos = cfg->defaultTos.val;
   else
      tsap->endpCb.defaultTos = LMG_DFLT_SCTP_TOS;
#endif /* GCP_MG */


   /*
    *   send the end point cfg request to SCTP
    *   only if the tsap state is BND_ENB;
    *
    *   mgEndpOpenReq() can be called from 2 places -
    *
    *      1) end point cfg request in mp_mi.c
    *      2) SCTP Bind cfm in mp_li.c
    *
    *   If the SCTP tsap has not been Bound enabled yet,
    *   then the this function does nothing. The actual
    *   SCTP end point cfg request would be sent in the
    *   SCTP tsap Bind cfm function which calls this
    *   function.
    *
    *   Else If the SCTP tsap has been Bound, then this
    *   function will send the SCTP end point cfg request.
    *
    */

   if (tsap->state != LMG_SAP_BND_ENB)
   {
      tsap->endpCb.port = cfg->sctPort;

      tsap->endpCb.locSuEndpId = cfg->tSAPId;

      /*
       *   mark endpoint cfg as done since the Sct Bnd Cfm function
       *   sends an endpoint open req depening on this variable;
       *   TRUE here means that the endpoint cfg has been INITIATED;
       */

      tsap->endpCfgDone = TRUE;
      RETVALUE(ROK);
   }


   
   /*
    *   use the tSAPId provided in the endpCfg struct
    *   by the layer manager as the GCP allocated
    *   SU end point Id;
    *
    *   Consequently, it becomes the layer manager's
    *   responsibility to allocate tSAPId i.e. the
    *   SU end point Id;
    *
    *   This comes from the ONE to ONE mapping between
    *   tsap <-- and --> end point;
    */

   tsap->endpCb.locSuEndpId = cfg->tSAPId;



   /*
    *   update the end point state to WAIT_CFM and wait
    *   for the end point open confirmation from SCTP
    */

   tsap->endpCb.epState     = LMG_EP_STATE_WAIT_CFM;


   /*
    *   mark end point configuration done as TRUE
    */

   tsap->endpCfgDone = TRUE;


   /*
    *   send the SCTP end point cfg request
    */

   RETVALUE(MgLiSctEndpOpenReq(&(tsap->spPst), tsap->tsapCfg.spId, 
                               tsap->endpCb.locSuEndpId, cfg->sctPort,
                               &intfAddr));

} /* end of mgEndpOpenReq() */








/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                 endpoint closing function                                  */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

/*
*
*       Fun:    mgCloseEndp
*
*       Desc:   This function does the following -
*
*               1) make the endpoint state as WAIT_CFM
*               2) send SCTP endpoint close request
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgCloseEndp
(
MgEndpCb           *endpCb,            /* endpoint CB pointer */
MgTSAPCb           *tsap,               /* TSAP Control Block */
Bool                sendFlag             /* Whether to send EndpCloseReq */
)
#else
PUBLIC S16 mgCloseEndp (endpCb, tsap, sendFlag)
MgEndpCb           *endpCb;            /* endpoint CB pointer */
MgTSAPCb           *tsap;              /* TSAP Control Block */
Bool                sendFlag;             /* Whether to send EndpCloseReq */
#endif
{
   MgAssocCb   *nextAssocCb;
   S16         ret;


   TRC2(mgCloseEndp)


   nextAssocCb = NULLP;



#if (ERRCLASS & ERRCLS_INT_PAR)

   if ((endpCb == NULLP) || (tsap == NULLP))
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG287, (ErrVal) endpCb,
                    "mgCloseEndp: Invalid endpCb");

      RETVALUE(RFAILED);
   }

#endif /* ERRCLASS & ERRCLS_INT_PAR */



   /*
    *   1) make the endpoint state as WAIT_CFM.
    *      The state shall be reset to INIT on
    *      getting the endpclose cfm.
    */

   endpCb->epState = LMG_EP_STATE_WAIT_CFM;



   /*
    *   2) send SCTP endpoint close request.
    *
    *      This frees all association contexts and this
    *      endpoint context within the SCTP layer.
    */
    

       if(          /* Don't Remove this brace */
#ifdef ZG
   (tsap->tsapCfg.reCfg.changeOver != TRUE) &&
      /* 
       * Check if ChangeOver Flag is Set Then Do Not Send EndpClose 
       * Request as SCTP is down 
       */
#endif /* ZG */
       (sendFlag == FALSE))
      MgLiSctEndpCloseReq(&(tsap->spPst), tsap->tsapCfg.spId,
                       endpCb->locSpEndpId, SCT_ENDPID_SP);


   /*
    *   3) now clear the associations within our (GCP) layer.
    *      Traverse the suAssocId based hash list of assocCbs.
    */

   while ((ret = cmHashListGetNext(&(tsap->endpCb.assocCp),
           (PTR)NULLP, (PTR *)&nextAssocCb)) != ROKDNA)
   {
      if (ret == RFAILED)   /* This should never happen; if it happens */
         break;             /* then just exit this function gracefully */


      /*
       * Update the peer pointers to indicate freeing of nextAssocCb.
       * This wud also prevent SctTermReq() from getting called
       * from mgBringPeerToCfgStatus().
       */

      if (nextAssocCb->peer)
         nextAssocCb->peer->assocCb  = NULLP;
         /* nextAssocCb->peer->assocCfg = NULLP; */


      /* Free assocCb, assocCfg & the assocCb from the hash list */
      mgDeAllocAssocCb(nextAssocCb);

   }   /* end of while loop */


   /* now de-initialize the hash list */
   if(sendFlag == TRUE)
   cmHashListDeinit(&(tsap->endpCb.assocCp));


   RETVALUE(ROK);
   
} /* mgCloseEndp */











/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                 endpoint de-allocation function                            */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

/*
*
*       Fun:    mgDeAllocEndpCb
*
*       Desc:   This function does the following -
*
*               1) reset the endpoint state
*               2) reset the endpoint configuration done flag
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgDeAllocEndpCb
(
MgEndpCb          *endpCb              /* endpoint CB pointer */
)
#else
PUBLIC S16 mgDeAllocEndpCb (endpCb)
MgEndpCb          *endpCb;             /* endpoint CB pointer */
#endif
{

   TRC2(mgDeAllocEndpCb)


   /*
    */

#if (ERRCLASS & ERRCLS_INT_PAR)

   if (endpCb == NULLP)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG288, (ErrVal) endpCb,
                    "mgDeAllocEndpCb: Invalid endpCb");

      RETVALUE(RFAILED);
   }

#endif /* ERRCLASS & ERRCLS_INT_PAR */



   /*
    *   1) reset the endpoint state
    */

   endpCb->epState = LMG_EP_STATE_INIT;



   RETVALUE(ROK);
   
} /* mgDeAllocEndpCb */






/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                 association confirmation processing function               */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

/*
*
*       Fun:    mgPrcAssocCfm
*
*       Desc:   This function does the following -
*
*               1) store the spAssocId in the assoc CB
*               2) update the local outgoing number of streams
*               3) link the assocCfg pointers in assocCb and assoCb->peer
*               4) update the destination address list and the
*                  primary destination address
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgPrcAssocCfm
(
MgAssocCb          *assocCb,           /* association CB pointer */
UConnId            spAssocId,          /* SCTP assoc identifier */
SctStrmId          inStrms,            /* outgoing streams */
SctStrmId          outStrms,           /* outgoing streams */
SctNetAddrLst      *dstAddrLst         /* destination net address list */
)
#else
PUBLIC S16 mgPrcAssocCfm (assocCb, spAssocId, inStrms, outStrms, dstAddrLst)
MgAssocCb          *assocCb;           /* association CB pointer */
UConnId            spAssocId;          /* SCTP assoc identifier */
SctStrmId          inStrms;            /* outgoing streams */
SctStrmId          outStrms;           /* outgoing streams */
SctNetAddrLst      *dstAddrLst;        /* destination net address list */
#endif
{

   TRC2(mgPrcAssocCfm)




   /*
    *        done at the other places in code
    */

#if (ERRCLASS & ERRCLS_INT_PAR)

   if (assocCb == NULLP)
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG289, (ErrVal) assocCb,
                    "mgPrcAssocCfm: Invalid suId/assocCb");

      RETVALUE(RFAILED);
   }

#endif /* ERRCLASS & ERRCLS_INT_PAR */



   /*
    *   1) store the spAssocId in the assoc CB
    */

   assocCb->spAssocId = spAssocId;



   /*
    *   assocCb->peer was assigned in the association request
    */

   if (assocCb->peer)
   {
      /*
       *   2) update the local outgoing number of streams
       *      to the minimum of assocCfg->locOutStrms (cfg'ed)
       *      or the received inStrms.
       *
       *    What to do is the inStrms exceeds cfg'ed streams
       *          in SCTP gen Cfg (does SCTP take care of that?)??
       */

      if (assocCb->peer->assocCfg)
      {
         assocCb->peer->assocCfg->locOutStrms =
            ((assocCb->peer->assocCfg->locOutStrms) < inStrms)
                     ?
            (assocCb->peer->assocCfg->locOutStrms) : inStrms;
      }


      /*
       *   3) link the assocCfg pointers in assocCb and assoCb->peer
       */

      assocCb->assocCfg = assocCb->peer->assocCfg;


      /*
       *   4) update the destination address list and the
       *      primary destination address
       */

      assocCb->assocCfg->dstAddrLst = *dstAddrLst;

      /*
       * we take the first address in the list
       * as the primary address
       */

      assocCb->assocCfg->priDstAddr = dstAddrLst->nAddr[0];

      /*
       *   The following is NOT to be done here. Instead, it
       *   is to be called from SctStaInd (COMM_UP)
       *
       *   mgPrcPeerConCfm(assocCb->peer);
       *
       */

#ifdef ZG
      /* Send Mod Update to Standby */
         zgRtUpd(ZG_CBTYPE_ASSOC,(Ptr)assocCb,CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_MOD);
#endif /* ZG */
   }
   else          /* this case should never arise */
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG290, (ErrVal) assocCb->peer,
                    "mgPrcAssocCfm: Invalid assocCb->peer");

      RETVALUE(RFAILED);
   }


   RETVALUE(ROK);
   
} /* mgPrcAssocCfm */







/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                   Process association indication from the peer             */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

/*
*
*       Fun:    mgPrcAssocInd
*
*       Desc:   This function does the following -
*
*
*               If the association indication has INIT params -
*
*                  1) allocate assocCb, initialize assocState
*                  2) assign suAssocId
*                  3) negotiate streams, address lists etc.
*                  4) insert assocCb in the suAssocId based
*                     hash list in end point CB
*                  5) generate SCTP association response
*
*
*               Else If the association indication has COOKIE params -
*
*                  1) find out the assocCb using the peerAddrLst
*                     received in COOKIE params
*                  2) If a match is found, update address lists etc.
*                  3) update association state
*                  4) generate the SCTP association response by
*                     giving the suAssocId stored in assoc CB
*
*
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgPrcAssocInd
(
SuId               suId,               /* GCP assigned TSAP identifier */
MgEndpCb           *endpCb,            /* endpoint Control Block */
SctAssocIndParams  *assocParams        /* prmt to the association indication */
)
#else
PUBLIC S16 mgPrcAssocInd (suId, endpCb, assocParams)
SuId               suId;               /* GCP assigned TSAP identifier */
MgEndpCb           *endpCb;            /* endpoint Control Block */
SctAssocIndParams  *assocParams;       /* prmt to the association indication */
#endif
{
   MgAssocCb *assocCb = NULLP;         /* association control block */
   SctAssocIndParams  locAssocParams;  /* local association ind parameter */
   MgPeerCb  *peer    = NULLP;         /* peer CB */
   U16       i;                        /* for loop variable */
   S16       ret;                      /* for checking the ret value */

   TRC2(mgPrcAssocInd)



   /*
    *   copy the received assocParams to the local variable;
    *   The local variable is used in the association response
    */

   cmMemcpy((U8 *)&(locAssocParams), (U8 *)(assocParams), 
            sizeof(SctAssocIndParams));

   /* mg001.105: use the same TOS as that rcvd in assocInd */
   locAssocParams.tos = assocParams->tos;

   switch (assocParams->type)
   {

      /*
       *   If this is the first association indication it
       *   has INIT chunk (parameters)
       */

      case SCT_ASSOC_IND_INIT:
      {
         /*
          *   1) allocate assocCb, initialize assocState
          */

         if ((assocCb = (MgAssocCb *) mgMalloc(sizeof(MgAssocCb))) == NULLP)
         {
            MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_SMEM_ALLOC_FAIL, 
                                   mgCb.init.region, mgCb.init.pool);
            RETVALUE(RFAILED);
         }


         assocCb->nxtOutStrmId = 0;

         assocCb->assocState = LMG_ASSOC_STATE_DOWN;

         assocCb->tsap       = mgCb.tSAPLst[suId];


         /*
          *   2) assign suAssocId
          */

         MG_GET_NEXT_UCONNID(assocCb->suAssocId, mgCb.tSAPLst[suId]);



         /*
          *   3) negotiate streams, address lists etc.
          *
          *   Find out if the peer is configured by searching
          *   for the addresses in the peer address list given
          *   in the INIT params in the configured addresses list
          *   of GCP.
          *
          */

         for (i=0; i < assocParams->t.initParams.peerAddrLst.nmb; ++i)
         {
            MgIpAddrEnt   *addrEnt = NULLP;
            CmTptAddr      remAddr;

            /* convert the CmNetAddr to CmTptAddr format */

            MG_FILL_TPTADDR_FRM_NETADDR(&(remAddr),
                  &(assocParams->t.initParams.peerAddrLst.nAddr[i]));

            /* Find the converted address in the ip address list */

            if (mgFindIpAddrLst(remAddr.type,
                                &(remAddr.u.ipv4TptAddr.address),
                                &(remAddr.u.ipv6TptAddr.ipv6NetAddr),
                                MG_HASH_SEQNMB_DEF,
                                &addrEnt) == ROK)
            {
               /* address match found */

               peer = addrEnt->peer;

               break;   /* break the for loop */

            }   /* end of if */

         }   /* end of for */



         /*
          *   if peer is found (i.e. the peer is configured),
          *      update the outStrms in locAssocParams as the
          *      minimum of locally configured outgoing streams
          *      and incoming streams in INIT params
          *
          *   else if peer is NOT found (i.e. its a discovered peer),
          *      update the outStrms in locAssocParams as the
          *      incoming streams in INIT params
          */

         if (peer)
         {
            locAssocParams.t.initParams.outStrms =
                     ((peer->assocCfg->locOutStrms) < (assocParams->\
                      t.initParams.inStrms)) ? 
                     (peer->assocCfg->locOutStrms) : (assocParams->\
                     t.initParams.inStrms);

            /*
             *   for configured peers, assocCfg is allocated
             *   in peer configuration
             */

            assocCb->assocCfg = peer->assocCfg;
         }
         else
         {
            locAssocParams.t.initParams.outStrms =
                     assocParams->t.initParams.inStrms;

            /*
             *   for discovered peers, allocate the assocCfg here
             */

            if ((assocCb->assocCfg =
                 (MgAssocCfg *) mgMalloc(sizeof(MgAssocCfg))) == NULLP)
            {
               mgDeAlloc((Data *)assocCb, sizeof(MgAssocCb));

               MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_SMEM_ALLOC_FAIL, 
                                      mgCb.init.region, mgCb.init.pool);
               RETVALUE(RFAILED);
            }
         }



         /*
          *   assign outStrms from INIT params to inStrms
          */

         locAssocParams.t.initParams.inStrms =
                     assocParams->t.initParams.outStrms;



         /*
          *   copy the peerAddrLst & the peerPort to dstAddrLst
          *   and remote port in AssocCfg;
          *   we take the first address in the peerAddrLst as
          *   primary destination address;
          */

         assocCb->assocCfg->dstAddrLst =
                     assocParams->t.initParams.peerAddrLst;

         assocCb->assocCfg->priDstAddr =
                     assocParams->t.initParams.peerAddrLst.nAddr[0];

         assocCb->assocCfg->remPort =
                     assocParams->t.initParams.peerPort;

         /*
          *   store the negotiated out going stream number in
          *   the out going stream number in AssocCfg
          */

         assocCb->assocCfg->locOutStrms =
                     locAssocParams.t.initParams.outStrms;



         /*
          *   4) insert assocCb in the suAssocId based
          *      hash list in end point CB
          */

         if (ROK != cmHashListInsert(&(mgCb.tSAPLst[suId]->endpCb.assocCp),
                                     (PTR)(assocCb),
                                     (U8 *)&(assocCb->suAssocId),
                                     MG_ASSOCID_LEN))
         {

            /*
             *   de-allocate the assocCfg block if allocated above.
             *   This is to be de-allocated here since the peerCb
             *   is not yet available. Normally, assocCfg is freed
             *   in mgDeAllocPeerCb() function;
             *
             *   de-allocate the association control block;
             */

            if (peer == NULLP)
               mgDeAlloc((Data *)assocCb->assocCfg, sizeof(MgAssocCfg));

            mgDeAlloc((Data *)assocCb, sizeof(MgAssocCb));


            RETVALUE(RFAILED);
         }

#ifdef ZG
      /* send runtime update and do add mapping */
      ZG_INIT_RSETID_IN_MAPCB(&(assocCb->mapCb));
      zgAddMapping(ZG_CBTYPE_ASSOC, (Ptr)assocCb);
      zgRtUpd(ZG_CBTYPE_ASSOC, (Ptr)assocCb,
              CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_ADD);
#endif /* ZG */


         /*
          *   5) generate SCTP association response
          */

         /* mg001.105: use the same TOS as that rcvd in assocInd */
         MgLiSctAssocRsp(&(mgCb.tSAPLst[suId]->spPst),
                         mgCb.tSAPLst[suId]->tsapCfg.spId,
                         mgCb.tSAPLst[suId]->endpCb.locSpEndpId,
                         &(locAssocParams),
                         /* reply with the same TOS as rcvd in ind */
                         assocParams->tos,
                         SCT_OK,
                         (Buffer *)NULLP);

         break;

      }

      /*
       *   If this is the first association indication it
       *   has INIT chunk (parameters)
       */

      case SCT_ASSOC_IND_COOKIE:
      {
         MgAssocCb   *prevAssocCb, *nextAssocCb;
         Bool        match = FALSE;

         prevAssocCb = nextAssocCb = NULLP;


         /*
          *   1) find out the assocCb using the peerAddrLst
          *      received in COOKIE params using the following
          *      logic -
          *
          *      Traverse the suAssocId based hash List in endpCb
          *      and see if the first address in the peerAddrList
          *      of COOKIE params is present in the dstAddrList of
          *      the association CB
          *
          *      Searching just for the first address should be
          *      sufficient since the addresses in the peerAddList
          *      ARE a SUBSET of the addresses in the assocCb
          */

         while ((ret = cmHashListGetNext(&(mgCb.tSAPLst[suId]->endpCb.assocCp),
                 (PTR)prevAssocCb, (PTR *)&nextAssocCb)) != ROKDNA)
         {
            if (ret == RFAILED)
               break;

            if (assocParams->t.cookieParams.peerPort ==
                nextAssocCb->assocCfg->remPort)
            {
               U16   k;

               for (k=0; k < nextAssocCb->assocCfg->dstAddrLst.nmb; k++)
               {
                  if ((cmMemcmp((U8 *)&(assocParams->t.cookieParams.\
                                        peerAddrLst.nAddr[0]),
                                (U8 *)&(nextAssocCb->assocCfg->\
                                        dstAddrLst.nAddr[k]), 
                                sizeof(CmNetAddr))) == 0)
                  {
                      match = TRUE;

                     break;         /* break the for loop */
                  }   /* end of if cmMemcmp */

               }   /* end of for loop */
            }   /* end of if - port comparison */

            if (match == TRUE)
               break;         /* break the while loop */

            prevAssocCb = nextAssocCb;
         }   /* end of while loop */




         /*
          *   2) If a match is found, update address lists etc.
          */

         if ((ret == ROK) && (match == TRUE))
         {

            /*
             *   store the spAssocId allocated by SCTP in the assocCb
             */

            nextAssocCb->spAssocId = assocParams->t.cookieParams.spAssocId;


            /*
             *   give the suAssocId alloated by us to SCTP in the response
             */

            locAssocParams.t.cookieParams.suAssocId = nextAssocCb->suAssocId;


            /*
             *   update the configured dstAddrLst and the priDstAddr
             */

            nextAssocCb->assocCfg->dstAddrLst =
                     assocParams->t.cookieParams.peerAddrLst;


            nextAssocCb->assocCfg->priDstAddr =
                     assocParams->t.cookieParams.peerAddrLst.nAddr[0];


            /*
             *   3) update association state - this indicates that
             *      the spAssocId is now available
             */

            nextAssocCb->assocState = LMG_ASSOC_STATE_WAIT_CFM;


#ifdef ZG
      /* Send Mod Update to Standby */
         zgRtUpd(ZG_CBTYPE_ASSOC,(Ptr)nextAssocCb,CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_MOD);
#endif /* ZG */
            /*
             *   4) generate the SCTP association response by
             *      giving the suAssocId stored in assoc CB
             */

            /* mg001.105: use the same TOS as that rcvd in assocInd */
            MgLiSctAssocRsp(&(mgCb.tSAPLst[suId]->spPst),
                            mgCb.tSAPLst[suId]->tsapCfg.spId,
                            mgCb.tSAPLst[suId]->endpCb.locSpEndpId,
                            &(locAssocParams),
                            /* reply with the same TOS as rcvd in ind */
                            assocParams->tos,
                            SCT_OK,
                            (Buffer *)NULLP);

         }
         else
         /* the association could NOT be found; return error response */
         {
            /* mg001.105: use the same TOS as that rcvd in assocInd */
            MgLiSctAssocRsp(&(mgCb.tSAPLst[suId]->spPst),
                            mgCb.tSAPLst[suId]->tsapCfg.spId,
                            mgCb.tSAPLst[suId]->endpCb.locSpEndpId,
                            &(locAssocParams),
                            /* reply with the same TOS as rcvd in ind */
                            assocParams->tos,
                            SCT_NOK,
                            (Buffer *)NULLP);

            RETVALUE(RFAILED);
         }

         break;

      }

   }

   RETVALUE(ROK);
   
} /* mgPrcAssocInd */







/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                   Initiate association establishment request               */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

/*
*
*       Fun:    mgAssocReq
*
*       Desc:   This function does the following -
*
*               1) initiate and start the idle timers
*               2) update the association state
*               3) insert the association CB in the suAssocId
*                  based hash list in the endpoint CB
*               4) Initiate the actual SCTP association request
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  This function is called on the MG side to
*               initiate the association request. Therefore,
*               ssap and peer shall ALWAYS be valid.
*               mgAssocReq() call is preceeded by the
*               mgAllocAssocCb() function call.
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAssocReq
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgPeerCb           *peer,              /* Peer Control Block */
MgAssocCb          *assocCb            /* Allocated association CB */
)
#else
PUBLIC S16 mgAssocReq (ssap, peer, assocCb)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgPeerCb           *peer;              /* Peer Control Block */
MgAssocCb          *assocCb;           /* Allocated association CB */
#endif
{
   MgTSAPCb  *tsap;                    /* TSAP Control Block */

   TRC2(mgAssocReq)



   /*
    *   1) initiate and start the idle timers
    */

   cmInitTimers(&(assocCb->idleTmr), 1);


   tsap = peer->tsap;


   /*
    *   2) update the association state
    */

   assocCb->assocState = LMG_ASSOC_STATE_WAIT_CFM;



   /*
    *   3) insert the association CB in the suAssocId
    *      based hash list in the endpoint CB
    *
    *    #define MG_ASSOCID_LEN  sizeof(UConnId)
    */

   if (ROK != cmHashListInsert(&(tsap->endpCb.assocCp), (PTR)(assocCb),
                               (U8 *)&(assocCb->suAssocId),
                               MG_ASSOCID_LEN))
   {

      /*
       *   de-allocates the association control block
       */

      /*
       *   Following is not called now. Its called ONLY from the
       *   mgDeAllocPeerCb() function -
       *
       *   mgDeAlloc((Data *)assocCb->assocCfg, sizeof(MgAssocCfg));
       */

      mgDeAlloc((Data *)assocCb, sizeof(MgAssocCb));

      /* peer->assocCfg = NULLP; */

      peer->assocCb = NULLP;


      RETVALUE(RFAILED);
   }


   /*
    *   4) Initiate the actual SCTP association request
    */

   /* mg001.105: use the TOS configured in the peer */
   MgLiSctAssocReq(&(tsap->spPst), tsap->tsapCfg.spId,
                   tsap->endpCb.locSpEndpId, assocCb->suAssocId,
                   &(peer->assocCfg->priDstAddr), peer->assocCfg->remPort,
                   peer->assocCfg->locOutStrms, &(peer->assocCfg->dstAddrLst),
                   &(peer->assocCfg->srcAddrLst),
                   peer->mgcoInfo.tos,
                   (Buffer *)NULLP);


   RETVALUE(ROK);
   
} /* mgAssocReq */








/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                   Alloc association control block Function                 */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

/*
*
*       Fun:    mgAllocAssocCb
*
*       Desc:   This function does the following -
*
*               1) allocate memory for the association CB
*               2) allocate and assign the suAssocId
*               3) initialize peer field of assocaiation CB
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  This function is called on the MG side to
*               initiate the association request. Therefore,
*               ssap and peer shall ALWAYS be valid.
*               mgAllocAssocCb() call is followed by the
*               mgAssocReq() function call.
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgAllocAssocCb
(
MgSSAPCb           *ssap,              /* SSAP Control Block */
MgPeerCb           *peer,              /* Peer Control Block */
MgAssocCb          **assocCb           /* Allocated association CB */
)
#else
PUBLIC S16 mgAllocAssocCb (ssap, peer, assocCb)
MgSSAPCb           *ssap;              /* SSAP Control Block */
MgPeerCb           *peer;              /* Peer Control Block */
MgAssocCb          **assocCb;          /* Allocated association CB */
#endif
{
   MgAssocCb *allocAssocCb = NULLP;    /* association control block */
   MgTSAPCb  *tsap;                    /* TSAP Control Block */

   TRC2(mgAllocAssocCb)



   /*
    *   1) allocate memory for the association CB
    */

   if ((allocAssocCb = (MgAssocCb *) mgMalloc(sizeof(MgAssocCb))) == NULLP)
   {
      /*
       *   Following is not called now. It is called ONLY from
       *   mgDeAllocPeerCb() function -
       *
       *   mgDeAlloc((Data *)peer->assocCfg, sizeof(MgAssocCfg));
       */

      /* peer->assocCfg = NULLP; */

      MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_SMEM_ALLOC_FAIL, 
                             mgCb.init.region, mgCb.init.pool);
      RETVALUE(RFAILED);
   }

   /* *assocCb = (Ptr)allocAssocCb; */
   *assocCb = allocAssocCb;


   allocAssocCb->nxtOutStrmId = 0;



   /*
    *   2) allocate and assign the suAssocId
    */

   tsap = peer->tsap;

   MG_GET_NEXT_UCONNID(allocAssocCb->suAssocId, tsap);

   allocAssocCb->tsap       = tsap;



   /*
    *   3) initialize peer field of assocaiation CB
    */

   allocAssocCb->peer = peer;

   peer->assocCb = allocAssocCb;

   peer->assocCb->assocCfg = peer->assocCfg;



   RETVALUE(ROK);
   
} /* mgAllocAssocCb */









/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*                 Dealloc association control block Function                 */
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

/*
*
*       Fun:    mgDeAllocAssocCb
*
*       Desc:   This function does the following -
*
*               1) stop the idle timer if it has been started
*               2) if suAssocId s have wrapped around, add the
*                  suAssocId of this assoc CB to the terminated
*                  associations linked list
*               3) remove this assoc CB from the endpoint CB hash list
*               4) de-allocates the association control block
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgDeAllocAssocCb
(
MgAssocCb          *assocCb            /* association CB pointer */
)
#else
PUBLIC S16 mgDeAllocAssocCb (assocCb)
MgAssocCb          *assocCb;           /* association CB pointer */
#endif
{

   TRC2(mgDeAllocAssocCb)



   /*
    *   2) if suAssocId s have wrapped around, add the
    *      suAssocId of this assoc CB to the terminated
    *      associations linked list
    */

   if (assocCb->tsap->assocIdWrpd == TRUE)
   {
      MgSuAssocLl   *suAssocLl = NULLP;

      /* Allocate the structure which is used to store the suAssocId */
      if ((suAssocLl = (MgSuAssocLl *) mgMalloc(sizeof(MgSuAssocLl))) == NULLP)
      {
         MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_SMEM_ALLOC_FAIL, 
                                mgCb.init.region, mgCb.init.pool);
         RETVALUE(RFAILED);
      }

      /* Initialize the CmLList field of suAssocLl to point to itself */
      suAssocLl->lkEnt.node = (PTR)suAssocLl;

      /* store the suAssocId info from the assocCb */
      suAssocLl->suAssocId  = assocCb->suAssocId;

      /* insert suAssocLl into the linked list */
      cmLListAdd2Tail(&(assocCb->tsap->termAssocsCp),
                      &(suAssocLl->lkEnt));
   }


   /*
    *   3) do NOT de-allocate association cfg. This shall be
    *      done ONLY in the mgDeAllocPeerCb() function -
    *
    *   if (assocCb->assocCfg)
    *      mgDeAlloc((Data *)assocCb->assocCfg, sizeof(MgAssocCfg));
    */



   /*
    *   4) remove this assoc CB from the endpoint CB's
    *      suAssocId based hash list of association CBs
    */

   cmHashListDelete(&(assocCb->tsap->endpCb.assocCp),
                      (PTR)assocCb);


   /*
    *   5) de-allocate the association control block
    */

   mgDeAlloc((Data *)assocCb, sizeof(MgAssocCb));


   RETVALUE(ROK);
   
} /* mgDeAllocAssocCb */



#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
/*
 *
 *       Fun:   mghndlPause
 *
 *       Desc:  GCP Handling of pause indication from MTP3
 *
 *       Ret:   None
 *
 *       Notes: None  
 *
 *       File:  mp_tpt.c
 *
 */
#ifdef ANSI
PUBLIC Void mgHndlPause
(
MgPeerCb  *peerCb                 /* Peer Control Block */
)
#else
PUBLIC Void mgHndlPause(peerCb)
MgPeerCb  *peerCb;                /* peer Control Block */
#endif
{

        U8        idx;
        U16       tmrVal;
        MgTSAPCb  *tSap;
        MgParId   parId;
        
        TRC2(MgHndlPause)
        
        /* Initialise the TSAP */
        tSap = peerCb->tsap;

        /* 
         * Find the peer and check its status  
         * See if status is already marked as offline then
         * Just Return and do nothing
         */
        if(!(peerCb->mgcoMtpCb.status & SP_ONLINE)) 
                RETVOID;

        /* Peer dpc is online so mark it offline and 
           call its handling function */
        peerCb->mgcoMtpCb.status &= SP_OFFLINE; 

        /* Start a status request timer to query its status */
        idx = MG_MTP_STSENQ_TMR - MG_PEER_TMR_BASE;
        tmrVal = tSap->tsapCfg.mgMtpNwCfg.defStatusEnqTmr.val;
        if(tSap->tsapCfg.mgMtpNwCfg.defStatusEnqTmr.enb == TRUE)
        {        
                mgStartTmr(MG_MTP_STSENQ_TMR, tmrVal, (PTR)peerCb,
                                &(peerCb->mntInfo.tmr[idx]));
        }
        /* Call the Function for handling of Peer DiscInd */
        mgPrcPeerDiscInd(peerCb);
#ifdef ZG
        zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peerCb,
                CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
        /* Send Status Indication to the Layer Manager */
        parId.parType = LMG_PAR_TPTADDR;
        parId.sapId = peerCb->mgcoMtpCb.peerDpc;
        mgGenStaInd(STTSAP, LCM_CATEGORY_INTERNAL,
                    LMG_EVENT_SNT_STAIND, LMG_CAUSE_TPT_FAILURE,
                    LMG_ALARMINFO_PAR,(Ptr)&parId, sizeof(MgParId),
                    LMG_ALARMINFO_INVSAPID);
   RETVOID;        
}


/*
*
*       Fun:   spMngtCong
*
*       Desc:  This Function handle  congestion Status Indication from MTP3
*
*       Ret:   None
*
*       Notes: 
*
*       File:  mp_tpt.c
*
*/
#ifdef ANSI
PUBLIC Void mgHndlCong
(
MgPeerCb  *peerCb,                 /* affected peer Control Block */
Priority prior                     /* affected priority */
)
#else
PUBLIC Void mgHndlCong(peerCb, prior)
MgPeerCb   *peerCb;                 /* affected peer Control Block */
Priority prior;                     /* affected priority */
#endif
{
  
   TRC2(mgHndlCong);
  
  /* Check if Point Code is offline then do nothing */
   if (!(peerCb->mgcoMtpCb.status & SP_ONLINE))   /* sanity check */
      RETVOID;

   if (prior == SN_PRI0)        /* lowest priority (uncongested) */
   {
      peerCb->mgcoMtpCb.status &= SP_UNCONG; 
      peerCb->mgcoMtpCb.congLvl = prior;        /* set priority to 0 */

   }
   else
   {
      peerCb->mgcoMtpCb.status |= SP_CONG;        /* mark sp congested */
      peerCb->mgcoMtpCb.congLvl = prior;
   }
#ifdef ZG
        zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peerCb,
                CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
   RETVOID;
} /* spMngtCong */

/*
 *
 *       Fun:   mgHndlResume
 *
 *       Desc:  MTP Management - resume
 *
 *       Ret:   None
 *
 *       Notes: 
 *
         File:  mp_tpt.c
 *
 */
#ifdef ANSI
PUBLIC Void mgHndlResume
(
MgPeerCb *peerCb         /* Peer Control Block */
)
#else
PUBLIC Void mgHndlResume(peerCb)
MgPeerCb *peerCb;         /* Peer Control Block */
#endif
{
   U8       idx;
   MgTSAPCb *tSap;

   TRC2(mgHndlResume)

      /* stop if any Status Request Timer is Run/ning */
   idx = (MG_MTP_STSENQ_TMR - MG_PEER_TMR_BASE);

   if (peerCb->mntInfo.tmr[idx].tmrEvnt == MG_MTP_STSENQ_TMR)
   {
      mgStopTmr(MG_MTP_STSENQ_TMR, (PTR) peerCb, 
            &(peerCb->mntInfo.tmr[idx]));
   }
   /* An online congested node should still process the MTP-RESUME   */

   if ((peerCb->mgcoMtpCb.status & SP_ONLINE) && 
      !(peerCb->mgcoMtpCb.status & SP_CONG)) /* sanity check */
      RETVOID;

   peerCb->mgcoMtpCb.status |= SP_ONLINE;         /* mark sp allowed */
   peerCb->mgcoMtpCb.status &= SP_UNCONG;         /* mark sp uncongested */
#ifdef ZG
        zgRtUpd(ZG_CBTYPE_PEER, (Ptr)peerCb,
                CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
   /*
    * Check if MTP Restart Begin Flag is not Set 
    * call the function to transmit queued transactions
    * on the MG side;
    */
   tSap = peerCb->tsap;

   if( tSap->mtpRstStart != TRUE) /* Restart is not taking place */
   {
#ifdef GCP_MG
      if (mgCb.genCfg.entType == LMG_ENT_GW)
         mgPrcPeerConCfm(peerCb);
#endif /* GCP_MG */
   }
   RETVOID;
}

/*
*
*
*       Fun:   mgHndlRstBeg
*
*       Desc:  Handle Restart begin.
*
*       Ret:   RETVOID
*
*/      
#ifdef ANSI
PUBLIC Void mgHndlRstBeg
(
MgTSAPCb *tSap       /* transport sap */
)
#else
PUBLIC Void mgHndlRstBeg(tSap)
MgTSAPCb *tSap;       /* network sap */
#endif
{
   MgPeerCb *prevPeerCb;
   MgPeerCb *nextPeerCb;
   S16 ret;
   U16 tmrVal;

   TRC2(mgHndlRstBeg);

   /* 
    * 1. Mark all the Mtp routes associated with tSap to be inaccessible and
    * 2. Take all the actions which are taken when the pc goes 
    *    down (SN_PAUSE) i.e call mgpeerDiscInd to handle Transport Going Down
    */

      prevPeerCb = (PTR)NULLP;
      nextPeerCb = (PTR)NULLP;
      
      ret = cmHashListGetNext(&(tSap->mgcoMtpHlCp), (PTR ) prevPeerCb, (PTR *)
                              &nextPeerCb); 
      while (ret == ROK)
      {
         /* Mark the status of each point code as OFFLINE */
         nextPeerCb->mgcoMtpCb.status &= SP_OFFLINE;
         /* call the Peer Disconnect Handling function for each Point Code */
         mgPrcPeerDiscInd(nextPeerCb);

#ifdef ZG
        zgRtUpd(ZG_CBTYPE_PEER, (Ptr)nextPeerCb,
                CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
         prevPeerCb = nextPeerCb;
         ret = cmHashListGetNext(&(tSap->mgcoMtpHlCp), (PTR ) prevPeerCb, 
         (PTR *) &nextPeerCb);
      }
         
   /* Change the status of Tsap as Restart started */
   tSap->mtpRstStart = TRUE;
#ifdef ZG
         /* send run time update for tsap */
         zgRtUpd(ZG_CBTYPE_TSAP, (Ptr)tSap, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */

   /* Start the MTP3 restart status end timer */
   tmrVal = tSap->tsapCfg.mgMtpNwCfg.defRstEndTmr.val;
   if(tSap->tsapCfg.mgMtpNwCfg.defRstEndTmr.enb == TRUE)
   {        
      mgStartTmr(MG_MTP_RSTEND_TMR,tmrVal,(PTR)tSap,
         &(tSap->rstEndTmr));
   }

   RETVOID;
} /* mgHndlRstBeg */

/*
*
*
*       Fun:   mgHndlRstEnd
*
*       Desc:  Handle Restart end.
*
*       Ret:   RETVOID
*
*/      
#ifdef ANSI
PUBLIC Void mgHndlRstEnd
(
MgTSAPCb *tSap       /* transport sap */
)
#else
PUBLIC Void mgHndlRstEnd(tSap)
MgTSAPCb *tSap;       /* transport sap */
#endif
{
   MgPeerCb    *prevPeerCb; 
   MgPeerCb    *nextPeerCb;
   S16 ret;

   TRC2(mgHndlRstEnd);

   /* Stop the reset end timer, if running */

   if (tSap->rstEndTmr.tmrEvnt == MG_MTP_STSENQ_TMR)
      mgStopTmr(MG_MTP_RSTEND_TMR, (PTR) tSap, 
            &(tSap->rstEndTmr));

      prevPeerCb = (PTR)NULLP;
      nextPeerCb = (PTR)NULLP;
      
#ifdef   GCP_MG      
      if(LMG_ENT_GW == mgCb.genCfg.entType)
      {
      ret = cmHashListGetNext(&(tSap->mgcoMtpHlCp), (PTR ) prevPeerCb, (PTR *)
                              &nextPeerCb); 
      while (ret == ROK)
      {
         /* 
          * Check the Status of Point Code if it is online and if we are MG
          * then transmit all queued txn since we are queuing them even if we 
          * have received MTP_RESUME for a PC but rstEnd flag was TRUE 
          */
          if(nextPeerCb->mgcoMtpCb.status & SP_ONLINE) 
              
             mgPrcPeerConCfm(nextPeerCb);

         prevPeerCb = nextPeerCb;
         ret = cmHashListGetNext(&(tSap->mgcoMtpHlCp), (PTR ) prevPeerCb, 
                                (PTR *) &nextPeerCb);
      
      }
      }
#endif   /* GCP_MG */      

   /* 
    * Check all the routes in tsap which are either offline or congested
    * start a Status Request Timer for all such routes 
    */
   mgMtpStsSync(tSap);         

   /* reset the flag of Restart Started  */
   tSap->mtpRstStart = FALSE;

#ifdef ZG
         /* send run time update for tsap */
         zgRtUpd(ZG_CBTYPE_TSAP, (Ptr)tSap, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */

   RETVOID;
} /* mgHndlRstEnd */

/*
*
*
*       Fun:   mgMtpStsSync
*
*       Desc:  This function checks the status of all routes in the system
*              and starts status enquiry timer for sending Status request
*              to MTP3 for all routes with status SP_CONG/SPOFFLINE
*
*       Ret:   RETVOID
*
*/      
#ifdef ANSI
PUBLIC Void mgMtpStsSync
(
MgTSAPCb    *tSap       /* Transport sap */
)
#else
PUBLIC Void mgMtpStsSync(tSap)
MgTSAPCb *tSap;       /* transport sap */
#endif
{
   MgPeerCb    *prevPeerCb, *nextPeerCb;      /* next,prev. peer control block */
   S16 ret;           /* return value */
   U16 tmrVal;
   U8 idx;

   TRC2(mgMtpStsSync)

   /* 
    * go through the Dpc to peerCb hash list and for all the Point codes's which are
    * SP_OFFLINE, start 
    * status enquiry timers 
    */
      prevPeerCb = (PTR)NULLP;
      nextPeerCb = (PTR)NULLP;
      
      ret = cmHashListGetNext(&(tSap->mgcoMtpHlCp), (PTR ) prevPeerCb, (PTR *)
                              &nextPeerCb); 
      while (ret == ROK)
      {
         /* 
          * Check the Status of Point Code if it is offline and if we are MG
          * then transmit all queued txn since we are queuing them even if we 
          * have received MTP_RESUME for a PC but rstEnd flag was TRUE 
          */
          if(!(nextPeerCb->mgcoMtpCb.status & SP_ONLINE))
          {
             /* Start a status request timer to query its status */

             idx = MG_MTP_STSENQ_TMR - MG_PEER_TMR_BASE;
             tmrVal = tSap->tsapCfg.mgMtpNwCfg.defStatusEnqTmr.val;
             if(tSap->tsapCfg.mgMtpNwCfg.defStatusEnqTmr.enb == TRUE)
             {        
                mgStartTmr(MG_MTP_STSENQ_TMR,tmrVal,(PTR)nextPeerCb,
                      &(nextPeerCb->mntInfo.tmr[idx]));
             }

          }

         prevPeerCb = nextPeerCb;
         ret = cmHashListGetNext(&(tSap->mgcoMtpHlCp), (PTR ) prevPeerCb, (PTR *)
               &nextPeerCb); 
      }

   RETVOID;
} /* mgMtpStsSync */

/******************************************************************************/
/*                         Data Reuest Function                               */
/******************************************************************************/

/*
*
*       Fun:    mgMtpDatReq
*
*       Desc:   This function transmits data over a SNT Interface towards MTP3
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
PUBLIC S16 mgMtpDatReq
(
MgPeerCb           *peer,              /* Pointer to Peer control block */
Dpc                 peerDpc,            /* Peer Dpc to whom msg is to be sent */
Dpc                 opc,                /* Self POint Code */  
MgTSAPCb            *tsap,              /* Tsap Cb Pointer */
Buffer             *mBuf               /* Data buffer to transmit */
)
#else
PUBLIC S16 mgMtpDatReq (peer, peerDpc, opc, tsap, mBuf)
MgPeerCb           *peer;              /* Pointer to peer control block */
Dpc                 peerDpc;            /* Peer Dpc to whom msg is to be sent */
Dpc                 opc;                /* Self POint Code */  
MgTSAPCb            *tsap;              /* Tsap Cb Pointer */
Buffer             *mBuf;              /* Data buffer to transmit */
#endif
{
   Dpc             selfPc;             /* Self Point Code */


   TRC2(mgMtpDatReq)

   /* Check if peer Dpc  passed in function argument is NULL then pick Dpc from peerCb */
   if((peerDpc == NULLD)&& (peer))
      peerDpc = peer->mgcoMtpCb.peerDpc;


#if (ERRCLASS & ERRCLS_DEBUG)
   if ((peer)&&(!(peer->mgcoMtpCb.status & SP_ONLINE))&& 
      (peer->mgcoMtpCb.peerDpc != peerDpc)) /* sanity check only */
   {
      MGLOGERROR(ERRCLS_DEBUG, EMG291, peer->mgcoMtpCb.status,
                 "[MGCO] mgMtpDatReq(): invalid Point Code state\n");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */





#ifdef DEBUGP
   /*
    * Put the existing SPrntMsg inside GCP_ACC_TESTS as this printing is
    * needed for acceptance tests
    */
#ifdef GCP_ACC_TESTS
   SPrntMsg(mBuf, 0, 0);
#endif /* GCP_ACC_TESTS */

#endif /* DEBUGP */

   /* Ensure TSAP is in proper State for Transmission */
   if ((tsap->state != LMG_SAP_BND_ENB) && (tsap->mtpRstStart == TRUE))
   {
      mgPutMsg(mBuf);
      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERNAL, LMG_EVENT_DATA_TX, 
                   LCM_CAUSE_INV_STATE,
                   LMG_ALARMINFO_NONE, (Ptr) NULLP,0, LMG_ALARMINFO_INVSAPID);
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG292, tsap->state,
                 "[MGCP] mgMtpDatReq(): invalid tsap state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }

   /* Generate Trace Indication if Required */
      mgGenTrcInd (tsap, MG_NONE, LMG_TRC_EVENT_MGCOTX, NULLP, mBuf);

   /* Copy the Self Point Code if it is not available then fill
    * NULL so MTP3 will fill the correct point code */
   if((peer) && (PRSNT_NODEF == peer->ssap->ssapCfg.userInfo.selfPc.pres))
      selfPc = peer->ssap->ssapCfg.userInfo.selfPc.val;
   else if (opc != SNT_OPC_NULL)
      selfPc = opc;
   else
      selfPc = SNT_OPC_NULL;

   /* Now call SNT Interface Primitive to send the Message */
   /* mg004.105: Changed the Priority of SNT in MgLiSntUDatReq */
   MgLiSntUDatReq(&(tsap->spPst), tsap->tsapCfg.spId, selfPc, peerDpc,
                          tsap->sInfo,LMG_ITU_SLS_RANGE,(Priority)SN_PRI0,mBuf);

   RETVALUE(ROK);

} /* end of mgMtpDatReq */

/*
*
*       Fun:    mgDownMtpPointCode
*
*       Desc:   This function does the following -
*
*               1) make each PointCode state as OFFLINE
*
*       Ret:    ROK - SUCCESS; RFAILED - FAILURE
*
*       Notes:  None
*
*       File:   mg_tpt.c
*
*/

#ifdef ANSI
EXTERN PUBLIC S16 mgDownMtpPointCode
(
MgTSAPCb           *tsap               /* TSAP Control Block */
)
#else
EXTERN PUBLIC S16 mgDownMtpPointCode (tsap)
MgTSAPCb           *tsap;              /* TSAP Control Block */
#endif
{
   MgPeerCb    *prevPeerCb;
   MgPeerCb    *nextPeerCb;
   MgPeerCb    *newNextPeerCb;
   S16         ret;


   TRC2(mgDownMtpPointCode)

   /* 
    * 1. Mark all the Mtp routes associated with tSap to be inaccessible and
    */

      prevPeerCb = (PTR)NULLP;
      nextPeerCb = (PTR)NULLP;
      newNextPeerCb = (PTR)NULLP;
      
      ret = cmHashListGetNext(&(tsap->mgcoMtpHlCp), (PTR ) prevPeerCb, (PTR *)
                              &nextPeerCb); 
      while ((ret == ROK) && (nextPeerCb))
      {
         /* Mark the status of each point code as OFFLINE */
         nextPeerCb->mgcoMtpCb.status &= SP_OFFLINE;
         /* call the Peer Disconnect Handling function for each Point Code */
         prevPeerCb = nextPeerCb;
         ret = cmHashListGetNext(&(tsap->mgcoMtpHlCp), (PTR ) prevPeerCb, 
         (PTR *) &newNextPeerCb);
#ifdef   ZG         
         if(tsap->tsapCfg.reCfg.changeOver != TRUE)
#endif   /* ZG */           
           mgPrcPeerDiscInd(nextPeerCb);
           nextPeerCb=newNextPeerCb;
#ifdef ZG
        zgRtUpd(ZG_CBTYPE_PEER, (Ptr)nextPeerCb,
                CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
      }

   RETVALUE(ROK);
   
} /* mgDownMtpPointCode */


#endif   /* GCP_PROV_MTP3 */

 



#endif /* GCP_MGCO */

#endif /* ifdef MG */

/********************************************************************30**
 
         End of file:     mp_tpt.c@@/main/mgcp_rel_1.5_mnt/3 - Tue May 31 11:49:16 2005
 
*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bbk  1. Initial release.
1.1+        mg001.101 bbk  1. In mgSndRslvReqToDns () added code to ensure
                              that MGCP layer retains a valid copy of 
                              DNS Resolve Request for later retransmission
            mg002.101  pk  2. Changed return from RETVOID to ROK in
                              mgSndRslvReqToDns().
/main/2      ---       pk  1. Added support for MEGACO.
                           2. Added support for TCP connections.
                           3. Modified transport module implementation 
                              for MGCP.
            mg008.102  vj  1. In function mgSrvDatReq, call SPrntMsg inside 
                              GCP_ACC_TESTS flag. This cant be removed as it is
                              required in acceptance tests code. As far as debug
                              printing inside debugMask is concerned for the 
                              product, it is beng taken care of in the 
                              interface function.
                           2. In function mgSndRslvReqToDns, SPrntMsg is not 
                              required.
            mg009.102  vj  1. In function mgDeAllocSrvrCb, ensure that for a 
                              round-robin server, SSAP server list is checked, 
                              and for default server, TSAP server list is 
                              checked in case of MG.
                           2. In function mgSrvConCfm, ensure that for MGC, all 
                              UDP servers are attached to TSAP, whereas for MG, 
                              only default servers are attached to TSAP, and 
                              round-robin servers are attached to SSAP.
            mg011.102   vj 1. In mgServConReq, modify to obtain self IP 
                              address from ssapCfg->addrInfo.
/main/3      ---      ra   1. GCP 1.3 release
            mg009.103 rg   1. Set the service type to priority socket to enable
                              multiple messages to be read from the socket in
                              one scheduling.
            mg014.103 ra   1. Initialized some variables.
/main/4      ---      ka   1. Changes for Release v 1.4
            mg005.104 ra   1. FTHA related changes.
            mg006.104 pk   1. PSF related changes.
                           2. Changed comment header pavitra with patch name. 
            mg008.104 ra   1. In the function mgSrvConCfm, we are not sending
                              serviceChange/RSIP to the MGC if UDP is the
                              transport since for UDP case the TUCL changeOver
                              does not lead to loss of association between
                              the MG and the MGC anymore.
/main/5      ---      pk   1. GCP 1.5 release
            mg001.105 ra   1. Pass back the TOS rcvd in AssocInd in
                              AssocRsp.
                           2. Use the TOS configured in peer in
                              AssocReq.            
            mg002.105 ra   1. Populate the tsap field in srvrCb.
                           2. Removed patch reference for 1.3 and 1.4
            mg004.105 gk   1. Changed the Priority of SNT in MgLiSntUDatReq
*********************************************************************91*/
