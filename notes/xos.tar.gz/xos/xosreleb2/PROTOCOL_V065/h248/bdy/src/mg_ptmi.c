/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     GCP - Management interface pack interface

     Type:     C source file

     Desc:     C source code for the management interface primitives of
               GCP

     File:     mg_ptmi.c

     Sid:      mg_ptmi.c@@/main/6 - Wed Mar 30 07:52:58 2005

     Prg:      rrp

*********************************************************************21*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "cm5.h"           /* common timers */
#include "cm_hash.h"       /* common hash list */
#include "cm_inet.h"       /* common INET */
#include "cm_llist.h"      /* common linked list */
#include "cm_mblk.h"       /* memory management */
#include "cm_abnf.h"
#include "cm_tkns.h"       /* common tokens */
#include "cm_tpt.h"        /* common transport defines */
#include "cm_dns.h"        /* common DNS library defines */
#include "cm_sdp.h"        /* SDP related constants */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || RUG) */
#include "hit.h"           /* HI layer */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.h"        /* Common SS7 defines */
#include "snt.h"           /* MTP3 Interface defines */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.h"           /* MGT defines */
#include "lmg.h"           /* MG layer management defines */
#include "mg.h"            /* MG layer defines */
#include "mg_err.h"        /* MG error defines */
#ifdef ZG
#include "mrs.h"            /* Message Router defines */ 
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */

#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_inet.x"       /* common INET */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_abnf.x"
#include "cm_tkns.x"       /* common tokens */
#include "cm_tpt.x"        /* common transport types */
#include "cm_dns.x"        /* common DNS library defines */
#include "cm_sdp.x"        /* SDP related types */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || RUG) */
#include "hit.x"           /* HI layer */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.x"        /* Common SS7 structure */
#include "snt.x"           /* MTP3 Interface structure */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.x"           /* MGT types */
#include "lmg.x"           /* MG layer management types */
#include "mg.x"            /* MG layer types */
#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */


PUBLIC S16 PtMiLmgCfgCfm   ARGS((Pst *post,MgMngmt *cfg));
PUBLIC S16 PtMiLmgCntrlCfm ARGS((Pst *post,MgMngmt *cntrl));
PUBLIC S16 PtMiLmgStaCfm   ARGS((Pst *post,MgMngmt *sta));
PUBLIC S16 PtMiLmgStaInd   ARGS((Pst *post,MgMngmt *sta));
PUBLIC S16 PtMiLmgStsCfm   ARGS((Pst *post,MgMngmt *sts));
PUBLIC S16 PtMiLmgTrcInd   ARGS((Pst *post,MgMngmt *trc,Buffer *mBuf));

#ifdef MG_FTHA
PUBLIC S16 PtMgMiShtCntrlCfm ARGS((Pst *pst,ShtCntrlCfmEvnt *cfmInfo));
#endif /* MG_FTHA */

#ifdef LCMGMILMG
PUBLIC S16 cmPkLmgCfgCfm   ARGS((Pst *post,MgMngmt *cfg));
PUBLIC S16 cmPkLmgCntrlCfm ARGS((Pst *post,MgMngmt *cntrl));
PUBLIC S16 cmPkLmgStaCfm   ARGS((Pst *post,MgMngmt *sta));
PUBLIC S16 cmPkLmgStaInd   ARGS((Pst *post,MgMngmt *sta));
PUBLIC S16 cmPkLmgStsCfm   ARGS((Pst *post,MgMngmt *sts));
PUBLIC S16 cmPkLmgTrcInd   ARGS((Pst *post,MgMngmt *trc,Buffer *mBuf));
#endif




/************************************************************************
                                Matrices
************************************************************************/

PUBLIC LmgCfgCfm mgMiLmgCfgCfmMt [] =
{
#ifdef LCMGMILMG
   cmPkLmgCfgCfm,      /* 0 - loosely coupled */
#else
   PtMiLmgCfgCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLmgCfgCfm,        /* 1 - tightly coupled, stub layer */
#else
   PtMiLmgCfgCfm,        /* 1 - tightly coupled, portable */
#endif
};



PUBLIC LmgCntrlCfm mgMiLmgCntrlCfmMt [] =
{
#ifdef LCMGMILMG
   cmPkLmgCntrlCfm,        /* 0 - loosely coupled */
#else
   PtMiLmgCntrlCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLmgCntrlCfm,        /* 1 - tightly coupled, stub layer */
#else
   PtMiLmgCntrlCfm,        /* 1 - tightly coupled, portable */
#endif
};



PUBLIC LmgStaCfm mgMiLmgStaCfmMt [] =
{
#ifdef LCMGMILMG
   cmPkLmgStaCfm,        /* 0 - loosely coupled */
#else
   PtMiLmgStaCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLmgStaCfm,        /* 1 - tightly coupled, stub layer */
#else
   PtMiLmgStaCfm,        /* 1 - tightly coupled, portable */
#endif
};

PUBLIC LmgStaInd mgMiLmgStaIndMt [] =
{
#ifdef LCMGMILMG
   cmPkLmgStaInd,        /* 0 - loosely coupled */
#else
   PtMiLmgStaInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLmgStaInd,        /* 1 - tightly coupled, stub layer */
#else
   PtMiLmgStaInd,        /* 1 - tightly coupled, portable */
#endif
};



PUBLIC LmgStsCfm mgMiLmgStsCfmMt [] =
{
#ifdef LCMGMILMG
   cmPkLmgStsCfm,        /* 0 - loosely coupled */
#else
   PtMiLmgStsCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLmgStsCfm,        /* 1 - tightly coupled, stub layer */
#else
   PtMiLmgStsCfm,        /* 1 - tightly coupled, portable */
#endif
};

PUBLIC LmgTrcInd mgMiLmgTrcIndMt [] =
{
#ifdef LCMGMILMG
   cmPkLmgTrcInd,        /* 0 - loosely coupled */
#else
   PtMiLmgTrcInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLmgTrcInd,        /* 1 - tightly coupled, stub layer */
#else
   PtMiLmgTrcInd,        /* 1 - tightly coupled, portable */
#endif
};



#ifdef MG_FTHA
/* System agent control Confirm primitive */
PRIVATE ShtCntrlCfm MgMiShtCntrlCfmMt [] =
{
  cmPkMiShtCntrlCfm,               /* 0 - loosely coupled          */
#ifdef SH
  ShMiShtCntrlCfm,                 /* 1 - tightly coupled system agent */
#else
  PtMgMiShtCntrlCfm,               /* 1 - tightly coupled, portable*/
#endif
};

#endif /* MG_FTHA */

/************************************************************************
                          Management Interface Functions
************************************************************************/

/*
 *
 *       Fun:   MgMiLmgCfgCfm
 *
 *       Desc:  This function resolves the LmgCfgCfm primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgMiLmgCfgCfm
(
Pst     *post,
MgMngmt *cfg
)
#else 
PUBLIC S16 MgMiLmgCfgCfm (post, cfg)
Pst     *post;
MgMngmt *cfg;
#endif
{
   TRC3(MgMiLmgCfgCfm)

   (*mgMiLmgCfgCfmMt[post->selector])(post, cfg);

   RETVALUE(ROK);
}






/*
 *
 *       Fun:   MgMiLmgCntrlCfm
 *
 *       Desc:  This function resolves the LmgCntrlCfm primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgMiLmgCntrlCfm
(
Pst     *post,
MgMngmt *cntrl
)
#else 
PUBLIC S16 MgMiLmgCntrlCfm (post, cntrl)
Pst     *post;
MgMngmt *cntrl;
#endif
{
   TRC3(MgMiLmgCntrlCfm)

   (*mgMiLmgCntrlCfmMt[post->selector])(post, cntrl);

   RETVALUE(ROK);
}




/*
 *
 *       Fun:   MgMiLmgStaCfm
 *
 *       Desc:  This function resolves the LmgStaCfm primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgMiLmgStaCfm
(
Pst *post,
MgMngmt *sta
)
#else 
PUBLIC S16 MgMiLmgStaCfm (post, sta)
Pst *post;
MgMngmt *sta;
#endif
{
   TRC3(MgMiLmgStaCfm)

   (*mgMiLmgStaCfmMt[post->selector])(post, sta);

   RETVALUE(ROK);
}





/*
 *
 *       Fun:   MgMiLmgStaInd
 *
 *       Desc:  This function resolves the LmgStaInd primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgMiLmgStaInd
(
Pst *post,
MgMngmt *sta
)
#else 
PUBLIC S16 MgMiLmgStaInd (post, sta)
Pst *post;
MgMngmt *sta;
#endif
{
   TRC3(MgMiLmgStaInd)

   (*mgMiLmgStaIndMt[post->selector])(post, sta);

   RETVALUE(ROK);
}




/*
 *
 *       Fun:   MgMiLmgStsCfm
 *
 *       Desc:  This function resolves the LmgStsCfm primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgMiLmgStsCfm
(
Pst *post,
MgMngmt *sts
)
#else 
PUBLIC S16 MgMiLmgStsCfm (post, sts)
Pst *post;
MgMngmt *sts;
#endif
{
   TRC3(MgMiLmgStsCfm)

   (*mgMiLmgStsCfmMt[post->selector])(post, sts);

   RETVALUE(ROK);
}





/*
 *
 *       Fun:   MgMiLmgTrcInd
 *
 *       Desc:  This function resolves the LmgTrcInd primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgMiLmgTrcInd
(
Pst *post,
MgMngmt *trc,
Buffer *mBuf
)
#else 
PUBLIC S16 MgMiLmgTrcInd (post, trc, mBuf)
Pst *post;
MgMngmt *trc;
Buffer *mBuf;
#endif
{
   TRC3(MgMiLmgTrcInd)

   (*mgMiLmgTrcIndMt[post->selector])(post, trc, mBuf);

   RETVALUE(ROK);
}


/************************************************************************
                      System Agent Interface Function      
************************************************************************/
#ifdef MG_FTHA
/*
*
*       Fun:   System agent control Confirm
*
*       Desc:  This function is used to send the system agent control confirm 
*              primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 MgMiShtCntrlCfm
(
Pst *pst,                    /* post structure */
ShtCntrlCfmEvnt *cfmInfo     /* system agent control confirm event */
)
#else
PUBLIC S16 MgMiShtCntrlCfm(pst, cfmInfo)
Pst *pst;                    /* post structure */
ShtCntrlCfmEvnt *cfmInfo;    /* system agent control confirm event */
#endif
{
   TRC3(MgMiShtCntrlCfm)

   /* jump to specific primitive depending on configured selector */
   (*MgMiShtCntrlCfmMt[pst->selector])(pst, cfmInfo); 

   RETVALUE(ROK);
} /* end of MgMiShtCntrlCfm */ 
#endif /* MG_FTHA */



/************************************************************************
                             Portable Functions
************************************************************************/

/*
 *
 *       Fun:   PtMiLmgCfgCfm
 *
 *       Desc:  Portable version of LmgCfgCfm primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtMiLmgCfgCfm
(
Pst *post,
MgMngmt *cfg
)
#else 
PUBLIC S16 PtMiLmgCfgCfm (post, cfg)
Pst *post;
MgMngmt *cfg;
#endif
{
   TRC3(PtMiLmgCfgCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG025, (ErrVal) 0, 
              "PtMiLmgCfgCfm() called");
#endif

   RETVALUE(ROK);
}




/*
 *
 *       Fun:   PtMiLmgCntrlCfm
 *
 *       Desc:  Portable version of LmgCntrlCfm primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtMiLmgCntrlCfm
(
Pst *post,
MgMngmt *cntrl
)
#else 
PUBLIC S16 PtMiLmgCntrlCfm (post, cntrl)
Pst *post;
MgMngmt *cntrl;
#endif
{
   TRC3(PtMiLmgCntrlCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG026, (ErrVal) 0, 
              "PtMiLmgCntrlCfm() called");
#endif

   RETVALUE(ROK);
}



/*
 *
 *       Fun:   PtMiLmgStaCfm
 *
 *       Desc:  Portable version of LmgStaCfm primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtMiLmgStaCfm
(
Pst *post,
MgMngmt *sta
)
#else 
PUBLIC S16 PtMiLmgStaCfm (post, sta)
Pst *post;
MgMngmt *sta;
#endif
{
   TRC3(PtMiLmgStaCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG027, (ErrVal) 0, 
              "PtMiLmgStaCfm() called");
#endif

   RETVALUE(ROK);
}




/*
 *
 *       Fun:   PtMiLmgStaInd
 *
 *       Desc:  Portable version of LmgStaInd primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtMiLmgStaInd
(
Pst *post,
MgMngmt *sta
)
#else 
PUBLIC S16 PtMiLmgStaInd (post, sta)
Pst *post;
MgMngmt *sta;
#endif
{
   TRC3(PtMiLmgStaInd)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG028, (ErrVal) 0, 
              "PtMiLmgStaInd() called");
#endif

   RETVALUE(ROK);
}




/*
 *
 *       Fun:   PtMiLmgStsCfm
 *
 *       Desc:  Portable version of LmgStsCfm primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtMiLmgStsCfm
(
Pst *post,
MgMngmt *sts
)
#else 
PUBLIC S16 PtMiLmgStsCfm (post, sts)
Pst *post;
MgMngmt *sts;
#endif
{
   TRC3(PtMiLmgStsCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG029, (ErrVal) 0, 
              "PtMiLmgStsCfm() called");
#endif

   RETVALUE(ROK);
}




/*
 *
 *       Fun:   PtMiLmgTrcInd
 *
 *       Desc:  Portable version of LmgTrcInd primitive
 *
 *       Ret:   ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtMiLmgTrcInd
(
Pst *post,
MgMngmt *trc,
Buffer *mBuf
)
#else 
PUBLIC S16 PtMiLmgTrcInd (post, trc, mBuf)
Pst *post;
MgMngmt *trc;
Buffer *mBuf;
#endif
{
   TRC3(PtMiLmgTrcInd)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG030, (ErrVal) 0, 
              "PtMiLmgTrcInd() called");
#endif

   RETVALUE(ROK);
}


/************************************************************************
                      System Agent Interface Function      
************************************************************************/
#ifdef MG_FTHA
/*
*
*       Fun:   System agent control Confirm
*
*       Desc:  This function is used to send the system agent control confirm 
*              primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mg_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 PtMgMiShtCntrlCfm
(
Pst *pst,                    /* post structure */
ShtCntrlCfmEvnt *cfmInfo     /* system agent control confirm event */
)
#else
PUBLIC S16 PtMgMiShtCntrlCfm(pst, cfmInfo)
Pst *pst;                    /* post structure */
ShtCntrlCfmEvnt *cfmInfo;    /* system agent control confirm event */
#endif
{
   TRC3(PtMgMiShtCntrlCfm);

   RETVALUE(ROK);
} /* end of PtMgMiShtCntrlCfm */ 
#endif /* MG_FTHA */

/* mg007.105: Corrected Footer */

/********************************************************************30**

         End of file:     mg_ptmi.c@@/main/6 - Wed Mar 30 07:52:58 2005

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rrp  1. initial release
1.2          ---      bbk  1. Fixed C++ compilation warnings
/main/3      ---       pk  1. Reorganized file for new release.
/main/4      ---      ra   1. GCP 1.3 release
/main/5      ---      ka   1. Changes for Release v 1.4
/main/6      ---      pk   1. GCP 1.5 release
	mg007.105     gk   1. Corrected Footer
*********************************************************************91*/
