/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     GCP _ System Services Interface Function.

     Type:     C source file

     Desc:     C source code for the interface to System Services
               of MGCP

     File:     mg_ex_ms.c
  
     Sid:      mp_ex_ms.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:53:33 2005

     Prg:      rrp

*********************************************************************21*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "cm5.h"           /* common timers */
#include "cm_hash.h"       /* common hash list */
#include "cm_inet.h"       /* common INET */
#include "cm_llist.h"      /* common linked list */
#include "cm_mblk.h"       /* memory management */
#include "cm_abnf.h"  
#include "cm_tkns.h"       /* common tokens */
#include "cm_tpt.h"        /* common transport defines */
#include "cm_dns.h"        /* common DNS library defines */
#include "hit.h"           /* HI layer */
#include "cm_sdp.h"        /* SDP related constants */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include  "cm_ss7.h"       /* Common SS7 Defines */
#include  "snt.h"          /* MTP3 Interface Defines */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.h"           /* MGT defines */
#include "lmg.h"           /* MG layer management defines */
#include "mg.h"            /* MG layer defines */
#include "mg_err.h"        /* MG error defines */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_inet.x"       /* common INET */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_abnf.x"  
#include "cm_tkns.x"       /* common tokens */
#include "cm_tpt.x"        /* common transport types */
#include "cm_dns.x"        /* common dns library */
#include "hit.x"           /* HI layer */
#include "cm_sdp.x"        /* SDP related types */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3 
#include  "cm_ss7.x"       /* Common SS7 Structure */
#include  "snt.x"          /* MTP3 Interface Structure */
#endif    /* GCP_PROV_MTP3 */




#include "mgt.x"           /* MGT types */
#include "lmg.x"           /* MG layer management types */
#include "mg.x"            /* MG layer types */
#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */

#include "mg_nms.h"
#include "mg_cfg.h"
#include "xosshell.h"
#include "h248_oam.x"
#include "mg_cfg.x"
/*   #include "sm.h"
      #include "sm.x"       cdw delele    */
#include "cp_tab_def.h"  /*cdw add*/

/* Extern Function */
EXTERN Void  RegisterXosCli();

EXTERN U32 g_mgDbgMask;

/***********************************************************************
                      System Service Interface Functions
 ***********************************************************************/


/*
 *
 *     Fun:   mgActvInit
 *
 *     Desc:  This function is invoked by system services to initialize 
 *            the GCP layer. This is an entry point used by GCP layer to 
 *            initialize its global variables, before becoming operational.
 *
 *            The first and second parameters (entity, instance)
 *            specify the entity and instance id of the GCP task.
 *
 *            The third parameter (region) specifies the memory region
 *            from which GCP should allocate structures and buffers.
 *
 *            The fourth parameter (reason) specifies the reason for
 *            calling this initialization function.
 *
 *            Allowable values for parameters are specified in ssi.h.
 *
 *     Ret:   ROK   - ok
 *
 *     Notes: None
 *
       File:  mg_ui.c
 *
 */


#ifdef ANSI
PUBLIC S16 mgActvInit
(
Ent    ent,                 /* entity */
Inst   inst,                /* instance */
Region region,              /* region */
Reason reason               /* reason */
)
#else
PUBLIC S16 mgActvInit(ent, inst, region, reason)
Ent    ent;                 /* entity */
Inst   inst;                /* instance */
Region region;              /* region */
Reason reason;              /* reason */
#endif
{
   Cntr i;                  /* counter */
/* mg007.105: Removed unsused variables */

   TRC3(mgActvInit)
   /* initialize other lists */
   mgCb.sSAPLst = NULLP;

   /* added initialization of tsap list */
   mgCb.tSAPLst = NULLP;

   /* initialize timing queues */

   /* we have two timing queues */
   for (i=0; i < MG_TQSIZE; i++)
      mgCb.mgTq[i].first = NULLP;

   for(i=0; i< MG_TTLTQSZ; i++)
      mgCb.mgTTLTq[i].first = NULLP;

   mgCb.mgTqCp.nxtEnt = 0;
   mgCb.mgTqCp.tmrLen = MG_TQSIZE;

   mgCb.mgTTLTqCp.nxtEnt = 0;
   mgCb.mgTTLTqCp.tmrLen = MG_TTLTQSZ;
    

   /* initialize task configuration parameters */
   mgCb.init.ent     = ent;           /* entity */
   mgCb.init.inst    = inst;          /* instance */
   mgCb.init.region  = region;        /* static region */
   mgCb.init.pool    = 0;             /* static pool */
   mgCb.init.reason  = reason;        /* reason */
   mgCb.init.cfgDone = FALSE;         /* configuration done */
   mgCb.init.acnt    = TRUE;          /* enable accounting */
   mgCb.init.usta    = TRUE;          /* enable unsolicited status */
   mgCb.init.trc     = FALSE;         /* enable trace */
   mgCb.init.procId  = SFndProcId();  /* processor id */

#ifdef MG_DEBUG
   mgCb.init.dbgMask = g_mgDbgMask;
#endif


#ifdef ZG
   /* call PSF initialization function */
   /*-- [BugFix]: mgActvInit is also called from the shutDown
        routine and when the ZG is turned on following corrupts the
        zg data structure...:Dobhal--*/
   /* mg003.105: Bug fix */
   if (reason == PWR_UP)
   zgActvInit(ent, inst, region, reason);
#endif /* ZG */

/*cdw add 2006.7.17*/
#ifdef SSI_WITH_CLI_ENABLED   
   RegisterXosCli();
#endif

   /* call external function for intialization */
   mgInitExt();

   RETVALUE(ROK);
} /* end of mgActvInit */


/*
 *
 *       Fun:    initialize external
 *
 *       Desc:   Initializes variables used to interface with Upper/Lower
 *               Layer  
 *
 *       Ret:    RETVOID
 *
 *       Notes:  None
 *
         File:   mg_ex_ms.c
 *
*/
  
#ifdef ANSI
PUBLIC S16 mgInitExt
(
void
)
#else
PUBLIC S16 mgInitExt()
#endif
{
   TRC2(mgInitExt);
   RETVALUE(ROK);

} /* end of mgInitExt */





/*
*
*       Fun:    Activation task
*
*       Desc:   Processes events received for MGCP layer via System
*               Services from other layers.
*
*       Ret:    ROK
*
*       Notes:  None
*
*       File:   mg_ex_ms.c
*
*/
#ifdef ANSI
PUBLIC S16 mgActvTsk
(
Pst *post,              /* post structure */
Buffer *mBuf            /* message buffer */
)
#else
PUBLIC S16 mgActvTsk(post, mBuf)
Pst *post;              /* post structure */
Buffer *mBuf;           /* message buffer */
#endif
{
   S16 ret = ROK;

   TRC3(mgActvTsk);

   switch(post->srcEnt)
   {
#ifdef LCMGMILMG
      case ENTSM:
      {
         switch(post->event)
         {
            case EVTLMGCFGREQ:
               ret = cmUnpkLmgCfgReq(MgMiLmgCfgReq, post, mBuf);
               break;

            case EVTLMGCNTRLREQ:
               ret = cmUnpkLmgCntrlReq(MgMiLmgCntrlReq, post, mBuf);
               break;

            case EVTLMGSTSREQ:
               ret = cmUnpkLmgStsReq(MgMiLmgStsReq, post, mBuf);
               break;

            case EVTLMGSTAREQ:
               ret = cmUnpkLmgStaReq(MgMiLmgStaReq, post, mBuf);
               break;

            default:
#ifdef  ZG
               /* the event received could be for PSF; call PSF's activate
                * function */
               zgActvTsk(post, mBuf);
#else
               (Void) mgPutMsg(mBuf);
#if  (ERRCLASS & ERRCLS_DEBUG)
               MGLOGERROR(ERRCLS_INT_PAR, EMG095, (ErrVal)post->event,
                          "Invalid Event from SM");
#endif /* ERRCLASS & ERRCLS_DEBUG */
               ret = RFAILED;
#endif /* ZG */
               break;
         }
         break;
      }
#endif  /* LCMGMILMG */

#ifdef LCMGLIHIT
      case ENTHI:
      {
         switch(post->event)
         {
            case EVTHITCONIND:             /* Connect indication */
               ret = cmUnpkHitConInd(MgLiHitConInd, post, mBuf);
               break;

            case EVTHITCONCFM:             /* Connect confirm*/
               ret = cmUnpkHitConCfm(MgLiHitConCfm, post, mBuf);
               break;

            case EVTHITBNDCFM:             /* Bind  confirm*/
               ret = cmUnpkHitBndCfm(MgLiHitBndCfm, post, mBuf);
               break;

            case EVTHITDATIND:             /* TCP Data indication */
               ret = cmUnpkHitDatInd(MgLiHitDatInd, post, mBuf);
               break;

            case EVTHITUDATIND:            /* UDP Data indication */
               ret = cmUnpkHitUDatInd(MgLiHitUDatInd, post, mBuf);
               break;

            case EVTHITDISCIND:            /* Disconnect indication */
               ret = cmUnpkHitDiscInd(MgLiHitDiscInd, post, mBuf);
               break;

            case EVTHITDISCCFM:            /* Disconnect confirm */
               ret = cmUnpkHitDiscCfm(MgLiHitDiscCfm, post, mBuf);
               break;

            case EVTHITFLCIND:             /* Flow Control indication */
               ret = cmUnpkHitFlcInd(MgLiHitFlcInd, post, mBuf);
               break;
            default:
               (Void) mgPutMsg(mBuf);
#if  (ERRCLASS & ERRCLS_DEBUG)
               MGLOGERROR(ERRCLS_DEBUG, EMG096, (ErrVal)post->event,
                          "Invalid  Event from HI");
#endif /* ERRCLASS & ERRCLS_DEBUG */
               ret = RFAILED;
               break;
         }
         break;
      }
#endif  /* LCMGLIHIT */


#ifdef    GCP_PROV_SCTP
#ifdef LCMGLISCT
      case ENTSB:
      {
         switch(post->event)
         {
            case SCT_EVTBNDCFM:             /* Bind Confirmation */
               ret = cmUnpkSctBndCfm(MgLiSctBndCfm, post, mBuf);
               break;

            case SCT_EVTENDPOPENCFM:        /* End point open confirm */
               ret = cmUnpkSctEndpOpenCfm(MgLiSctEndpOpenCfm, post, mBuf);
               break;

            case SCT_EVTENDPCLOSECFM:       /* End point close confirm */
               ret = cmUnpkSctEndpCloseCfm(MgLiSctEndpCloseCfm, post, mBuf);
               break;

            case SCT_EVTASSOCIND:           /* Association indication */
               ret = cmUnpkSctAssocInd(MgLiSctAssocInd, post, mBuf);
               break;

            case SCT_EVTASSOCCFM:           /* Association confirmation */
               ret = cmUnpkSctAssocCfm(MgLiSctAssocCfm, post, mBuf);
               break;

            case SCT_EVTTERMIND:            /* Termination indication */
               ret = cmUnpkSctTermInd(MgLiSctTermInd, post, mBuf);
               break;

            case SCT_EVTTERMCFM:            /* Termination confirmation */
               ret = cmUnpkSctTermCfm(MgLiSctTermCfm, post, mBuf);
               break;

            case SCT_EVTDATIND:             /* Datagram indication */
               ret = cmUnpkSctDatInd(MgLiSctDatInd, post, mBuf);
               break;

            case SCT_EVTSTAIND:             /* Status indication */
               ret = cmUnpkSctStaInd(MgLiSctStaInd, post, mBuf);
               break;

            case SCT_EVTSTACFM:             /* Status confirmation */
               ret = cmUnpkSctStaCfm(MgLiSctStaCfm, post, mBuf);
               break;

            case SCT_EVTFLCIND:             /* Flow control indication */
               ret = cmUnpkSctFlcInd(MgLiSctFlcInd, post, mBuf);
               break;

            case SCT_EVTSETPRICFM:          /* Set Primary address cfm */
               ret = cmUnpkSctSetPriCfm(MgLiSctSetPriCfm, post, mBuf);
               break;

            case SCT_EVTHBEATCFM:           /* Heart Beat confirmation */
               ret = cmUnpkSctHBeatCfm(MgLiSctHBeatCfm, post, mBuf);
               break;
         }
         break;
      }
#endif  /* LCMGLISCT */
#endif /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3      
#ifdef   LCMGLISNT
      case ENTSN :  /* MTP3 */
      case ENTIT :  /* M3UA */
      {
         switch (post->event)
         {
            case EVTSNTUDATIND:                    /* Unit Data indication */
               ret = cmUnpkSntUDatInd(MgLiSntUDatInd, post, mBuf);
               break;

            case EVTSNTSTAIND:                     /* Status indication */
               ret = cmUnpkSntStaInd(MgLiSntStaInd, post, mBuf);
               break;
#ifdef SNT2
            case EVTSNTSTACFM:                     /* status confirmation*/
               ret = cmUnpkSntStaCfm(MgLiSntStaCfm, post, mBuf);
               break;
            case EVTSNTBNDCFM:                     /* bind confirmation*/
               ret = cmUnpkSntBndCfm(MgLiSntBndCfm, post, mBuf);
               break;
            default:
               (Void) mgPutMsg(mBuf);
#if  (ERRCLASS & ERRCLS_DEBUG)
               MGLOGERROR(ERRCLS_DEBUG, EMG097, (ErrVal)post->event,
                          "Invalid  Event from SNT");
#endif /* ERRCLASS & ERRCLS_DEBUG */
               ret = RFAILED;
               break;

#endif /* SNT2 */
         }
         break;
      }
#endif   /* LCMGLISNT */
#endif   /* GCP_PROV_MTP3 */     
      

#if ((defined(LCMGUIMGT)) || ((defined(LWLCMGUIMGT))))
      case ENTMU:
      /* mg003.105: Bug fix */
#ifdef AG      
      case ENTAG:
#endif      
      {
         Mem sMem;

         sMem.region = mgCb.init.region;
         sMem.pool = mgCb.init.pool;

         switch(post->event)
         {
            case EVTMGTBNDREQ:              /* Bind request */
               ret = cmUnpkMgtBndReq(MgUiMgtBndReq, post, mBuf );
               break;

            case EVTMGTUBNDREQ:             /* Unbind request */
               ret = cmUnpkMgtUbndReq(MgUiMgtUbndReq, post, mBuf );
               break;

#ifdef GCP_MGCP
            case EVTMGTMGCPTXNREQ:               /* transaction request */
               ret = cmUnpkMgtMgcpTxnReq(MgUiMgtMgcpTxnReq, post, mBuf, 
                                     &sMem, mgCb.genCfg.maxBlkSize);
               break;
#endif /* GCP_MGCP */
           
#ifdef GCP_MGCO
            case EVTMGTMGCOTXNREQ:               /* transaction request */
               ret = cmUnpkMgtMgcoTxnReq(MgUiMgtMgcoTxnReq, post, mBuf, 
                                     &sMem, mgCb.genCfg.maxBlkSize);
               break;
#ifdef GCP_CH
            case EVTMGTMGCOCMDREQ:
               {
                  ret = cmUnpkMgtMgcoCmdReq(MgUiMgtMgcoCmdReq, post, mBuf, 
                        &sMem, mgCb.genCfg.maxBlkSize);      
                  break;
               }
 
            case EVTMGTMGCOUPDCNTXTREQ:
               {
                 
                  ret = cmUnpkMgtMgcoUpdCtxtReq(MgUiMgtMgcoUpdCtxtReq, post, 
                                                mBuf, &sMem, mgCb.genCfg.maxBlkSize);  
                  break;
               }
            case EVTMGTMGCOERRREQ:
               {
                  ret = cmUnpkMgtMgcoErrReq(MgUiMgtMgcoErrReq, post, 
                                             mBuf, &sMem, mgCb.genCfg.maxBlkSize);  
                  break;
               }
#endif /* GCP_CH  */

#endif /* GCP_MGCO */
            
            case EVTMGTCNTRLREQ:               /* control request */
               ret = cmUnpkMgtCntrlReq(MgUiMgtCntrlReq, post, mBuf);
               break;

            case EVTMGTAUDREQ:               /* Audit request */
               ret = cmUnpkMgtAuditReq(MgUiMgtAuditReq, post, mBuf);
               break;
             
            default:
               (Void) mgPutMsg(mBuf);
#if  (ERRCLASS & ERRCLS_DEBUG)
               MGLOGERROR(ERRCLS_DEBUG, EMG098, (ErrVal)post->event,
                          "Invalid Event");
#endif /* ERRCLASS & ERRCLS_DEBUG */
               ret = RFAILED;
               break;
         }
         break;
      }
#endif  /* LCMGUIMGT */
      case ENTSH:  /* events from system agent */
         /* check event */
         switch (post->event)
         {
#ifdef MG_FTHA
            case EVTSHTCNTRLREQ:  /* system agent control request */
               /* call unpakcing function */
               ret = cmUnpkMiShtCntrlReq(MgMiShtCntrlReq, post, mBuf);
               break;
#endif /* MG_FTHA */

            default:
#ifdef ZG
               /* call PSF's activate function */
               zgActvTsk(post,mBuf);
#else
#if  (ERRCLASS & ERRCLS_DEBUG)
               SLogError(post->dstEnt, post->dstInst, post->dstProcId,
                         __FILE__, __LINE__, ERRCLS_INT_PAR, EMG099, 
                         (ErrVal) post->event, "Invalid event from ENTSH");
#endif /* ERRCLASS & ERRCLS_DEBUG */
              (Void) mgPutMsg(mBuf);
               ret = RFAILED;
#endif /* ZG */
               break;
         }
         break;
      case ENTMG:
#ifdef CM_ABNF_MT_LIB
         if( (mgCb.init.cfgDone == TRUE) &&
             (post->srcInst >= mgCb.genCfg.firstInst )&&
             (post->srcInst < mgCb.lastEDInst) )
         {
            if(post->event == EVTMEDENCCFM)
            {
               /* Encode cfm from ED */
               ret = cmUnpkMedEncCfm(mgRcvEncPduMsgCfm, post, mBuf);
            }
            else if(post->event == EVTMEDDECCFM)
            {
               /* decode cfm from ED */
               ret = cmUnpkMedDecCfm(mgRcvDecPduMsgCfm, post, mBuf);
            }
            else
            {
#if  (ERRCLASS & ERRCLS_DEBUG)
               SLogError(post->dstEnt, post->dstInst, post->dstProcId,
                         __FILE__, __LINE__, ERRCLS_INT_PAR, EMG100, 
                         (ErrVal) post->event, "Invalid event from ENTMG");
#endif /* ERRCLASS & ERRCLS_DEBUG */
              (Void) mgPutMsg(mBuf);
               ret = RFAILED;
            }
            break;
         }
         /* fall through */
#endif /* CM_ABNF_MT_LIB */
      default:
#ifdef  ZG
      /* the event received could be for PSF */
         zgActvTsk(post, mBuf);
#else
#if  (ERRCLASS & ERRCLS_DEBUG)
         MGLOGERROR(ERRCLS_DEBUG, EMG101, (ErrVal)post->srcEnt,
                    "Invalid Source Entity ");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         (Void) mgPutMsg(mBuf);
         ret = RFAILED;
#endif /* ZF */
         break;
   }

   /* For rolling upgrade */
#ifdef MG_RUG
   /* Generate an alarm on receiving an interface primitive with invalid
    * version number on any of the product interfaces.
    */
   if ((ret == RINVIFVER) && (mgCb.init.cfgDone == TRUE))
   {
      mgGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, LCM_EVENT_INV_EVT,
                    LCM_CAUSE_DECODE_ERR, LMG_ALARMINFO_NONE,
                    (Ptr)NULLP, 0, LMG_ALARMINFO_INVSAPID);
   }
#endif /* MG_RUG */

   SExitTsk();

   RETVALUE(ret);
}



/********************************************************************30**
  
         End of file:     mp_ex_ms.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:53:33 2005
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rrp  1. initial release
1.2          ---      bbk  1. Fixed C/C++compilation warnings
/main/3      ---       pk  1. Added MEGACO support.
                           2. Added support for new upper interface primitives.
/main/4      ---      ra   1. GCP 1.3 release
/main/5      ---      ka   1. Changes for release v 1.4
            mg009.104  ra  1. Added initialization of TSAP list.
/main/6      ---      pk   1. GCP 1.5 release
            mg002.105 ps   1. Removed patch reference for 1.4
            mg003.105 dp   1. Bug fix 
            mg007.105 gk   1. Removed unsused variables
*********************************************************************91*/
