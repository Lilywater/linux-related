/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:    GCP - lower interface
  
     Type:    C source file
  
     Desc:    C source code for GCP lower interface entry points
 
     File:    mg_li.c

     Sid:      mp_li.c@@/main/mgcp_rel_1.5_mnt/3 - Tue May 31 11:49:09 2005
  
     Prg:     rrp
  
*********************************************************************21*/
 

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "cm5.h"           /* common timer library */
#include "cm_hash.h"       /* common hash library */
#include "cm_llist.h"      /* common linked list library */
#include "cm_inet.h"       /* common socket library */
#include "cm_tpt.h"        /* common transport library */
#include "cm_tkns.h"       /* common tokens */
#include "cm_mblk.h"       /* common mem alloc defines */
#include "cm_dns.h"        /* common DNS library defines */
#include "cm_sdp.h"        /* SDP module */
#include "cm_abnf.h"       /* Common ABNF Encode/Decode Library */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include  "cm_ss7.h"       /* Common SS7 Defines */
#include  "snt.h"          /* MTP3 Interface Defines */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.h"           /* MGP upper interface */
#include "lmg.h"           /* MGP layer management */
#include "hit.h"           /* MGP lower interface */
#include "mg.h"            /* MGP */
#include "mg_err.h"        /* MGP error */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "cm5.x"           /* common timer library */
#include "cm_lib.x"        /* common 'C' library */
#include "cm_hash.x"       /* common hash library */
#include "cm_llist.x"      /* common linked list library */
#include "cm_inet.x"       /* common socket library */
#include "cm_tpt.x"        /* common transport library */
#include "cm_tkns.x"       /* common tokens */
#include "cm_mblk.x"       /* common mem alloc defines */
#include "cm_dns.x"        /* common DNS library defines */
#include "cm_sdp.x"        /* SDP module */
#include "cm_abnf.x"       /* Common ABNF Encode/Decode Library */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3 
#include  "cm_ss7.x"       /* Common SS7 Structure */
#include  "snt.x"          /* MTP3 Interface Structure */
#endif    /* GCP_PROV_MTP3 */

#include "mgt.x"           /* GCP upper interface */
#include "lmg.x"           /* GCP layer management */
#include "hit.x"           /* GCP lower interface */
#include "mg.x"            /* GCP */
#ifdef ZG
#include "mrs.x"            /* Message Router typedefs */
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */




/* local defines */

/* local typedefs */

/* local externs */
  
/* forward references */

/* local function definition */

/* functions in other modules */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */

/* support functions */


/******************************************************************************/
/*                  Bind Confirm Function                                     */
/******************************************************************************/

/*
*
*       Fun:   MgLiHitBndCfm
*
*       Desc:  Bind confirm
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to 
*              ack the bind request from the service user.
*
*       File:  mg_li.c
*
*/
#ifdef ANSI
PUBLIC S16 MgLiHitBndCfm
(
Pst   *post,     /* post structure */
SuId  suId,      /* service user SAP identifier */
U8    status     /* bind status */
)
#else
PUBLIC S16 MgLiHitBndCfm(post, suId, status)
Pst   *post;     /* post structure */
SuId  suId;      /* service user SAP identifier */
U8    status;    /* bind status */
#endif
{
   U16             event;              /* Event */
   U16             cause;              /* Cause */
   MgTSAPCb        *tsap;              /* TSAP Control Block */
   MgParId         parId;

   TRC3(MgLiHitBndCfm)
     
   MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
           "MgLiHitBndCfm(post, suId(%d), status(%d)\n", suId, status));

   UNUSED(post);

   if (mgCb.init.cfgDone != TRUE)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG102, (ErrVal) suId,
                 "MgLiHitBndCfm: General configuration not done");
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_BNDCFM,
                   LCM_CAUSE_INV_STATE, LMG_ALARMINFO_NONE,NULLP, 0, 
                   LMG_ALARMINFO_INVSAPID);

      RETVALUE(RFAILED);
   }

#ifdef ZG_DFTHA
   if((zgChkCRsetStatus()) == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG103, (ErrVal) ERRZERO ,
         "[MGCP] MgLiHitBndCfm: BndCfm rcved in Invalid resource state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_BNDCFM,
                   LCM_CAUSE_PROT_NOT_ACTIVE, LMG_ALARMINFO_NONE,NULLP, 0,
                   LMG_ALARMINFO_INVSAPID);
      RETVALUE(RFAILED);
   }
#endif /* ZG_DFTHA */


   /*mg002.105: Removed compilation warning*/
   if ((suId < 0)|| (suId >= (S16)mgCb.genCfg.maxTSaps) ||
       (mgCb.tSAPLst[suId] == NULLP))
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_INT_PAR, EMG104, (ErrVal) suId,
                 "[MGCP] MgLiHitBndCfm: Invalid suId");
#endif /* ERRCLASS & ERRCLS_DEBUG */

#if (ERRCLASS & ERRCLS_INT_PAR)

      parId.parType = LMG_PAR_SPID;
      parId.sapId = suId;
      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_BNDCFM,
                   LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR,
                  (Ptr) &parId, sizeof (MgParId), LMG_ALARMINFO_INVSAPID);

#endif /* ERRCLASS & ERRCLS_INT_PAR */

      RETVALUE(RFAILED);
   }


   tsap = mgCb.tSAPLst[suId];

   /* Check tsap state */
   switch (tsap->state)
   {
      case LMG_SAP_WAIT_BNDENB:
      {
         mgStopTmr (MG_BNDREQ_TMR, (PTR)tsap, &(tsap->bndTmr));

         tsap->bndRetxCnt = 0;
          
         if (status == CM_BND_OK)
         {
            event = LCM_EVENT_BND_OK;
            if (tsap->state == LMG_SAP_WAIT_BNDENB)
            {
               tsap->state = LMG_SAP_BND_ENB;
               cause = LMG_CAUSE_SAP_BNDENB;
#ifdef ZG
#ifdef GCP_MG
               if (tsap->tsapCfg.reCfg.changeOver == TRUE)
               {
                  U32   i;
                  for(i=0; i< mgCb.genCfg.maxSSaps; i++)
                  {
                     MgSSAPCb   *ssap = NULLP;
                     ssap = mgCb.sSAPLst[i];
                     if(ssap != NULLP)
                     {
                        mgStartSsapServers(ssap);
                     }
                  }
               }
#endif /* GCP_MG */
#endif /* ZG */
               mgStartTsapServers(tsap);

#ifdef CM_DNS_LIB
               if (tsap->tsapCfg.reCfg.dnsCfg.dnsAccess == LMG_DNS_USE_DNSLIB)
               {
                  MG_ENA_DNS_LSTNR(tsap, &(tsap->tsapCfg.reCfg.tptParam));
#ifdef ZG
                  /* send update for server update */
                  zgRtUpd(ZG_CBTYPE_TPTSRVR, (Ptr)(tsap->dnsInfo.dnsLstnr),
                     CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
               }
#endif /* CM_DNS_LIB */

#ifdef ZG
#ifdef GCP_MGCO
#ifdef GCP_MG
               if (tsap->tsapCfg.reCfg.changeOver == TRUE)
                  mgRecovrConn(tsap);
#endif /* GCP_MG */
#endif /* GCP_MGCO */
#endif /* ZG */
            }
            else
            {
               tsap->state = LMG_SAP_BND_DIS;
               cause       = LMG_CAUSE_SAP_BNDDIS;
            }
         }
         else
         {
            tsap->state  = LMG_SAP_UBND_DIS;
            event        = LCM_EVENT_BND_FAIL;
            cause        = LMG_CAUSE_UNKNOWN;
         }
#ifdef ZG
         /* send run time update for tsap */
         zgRtUpd(ZG_CBTYPE_TSAP, (Ptr)tsap, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
      }
      break;

     default:
        event = LMG_EVENT_HIT_BNDCFM;
        cause = LCM_CAUSE_INV_STATE;
        break;
   }

   parId.parType = LMG_PAR_SPID;
   parId.sapId = suId;

   mgGenStaInd(STTSAP, LCM_CATEGORY_INTERFACE, event, cause,
               LMG_ALARMINFO_PAR, (Ptr)(&parId), sizeof(MgParId),
               (suId));
#ifdef ZG
   /* send update message to stndby */
   zgUpdPeer();
#endif /* ZG */

   RETVALUE(ROK);

} /* end of MgLiHitBndCfm */

/******************************************************************************/
/*                  Connect Confirm Function                                  */
/******************************************************************************/

/*
*
*       Fun:   MgLiHitConCfm
*
*       Desc:  Connect confirm
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to 
*              ack the HitServOpenReq or HitConReq primitives. 
*
*       File:  mg_li.c
*
*/
#ifdef ANSI
PUBLIC S16 MgLiHitConCfm
(
Pst             *post,             /* post structure */
SuId            suId,              /* service user SAP identifier */
UConnId         suConnId,          /* service user connection id */
UConnId         spConnId,          /* service provider connection id */
CmTptAddr       *localAddr         /* local transport address */
)
#else
PUBLIC S16 MgLiHitConCfm(post, suId, suConnId, spConnId, localAddr)
Pst             *post;             /* post structure */
SuId            suId;              /* service user SAP identifier */
UConnId         suConnId;          /* service user connection id */
UConnId         spConnId;          /* service provider connection id */
CmTptAddr       *localAddr;        /* local transport address */
#endif
{
   MgTptSrvr   *srvrCb;            /* listener control block */
   U8           srvrState;         /* listener state */
   S16          ret;               /* return value */
#ifdef DEBUGP
   U16   port;
   Txt   addr[2 * CM_IPV6ADDR_SIZE + 1];
#endif /* DEBUGP */
   MgParId   parId;

   TRC3(MgLiHitConCfm);
   UNUSED(post);

#ifdef DEBUGP   
   mgGetPortAndAscAddr (localAddr, &port, addr);
   
   MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf,
                        "MgLiHitConCfm(post, suId(%d), suConnId(%ld), spConnId(%ld),"
                        "localAddr.type(%d), localAddr.port(%d), localAddr.address(%s))\n",
                        suId, suConnId, spConnId, localAddr->type, port, addr));
#endif /* DEBUGP */



#if (ERRCLASS & ERRCLS_INT_PAR)
   MG_CHK_SUID (suId, NULLP, EMG105, MgLiHitConCfm, LMG_EVENT_HIT_CONCFM);
#endif /* ERRCLASS & ERRCLS_INT_PAR */


#ifdef ZG_DFTHA
   if((zgChkCRsetStatus()) == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG106, (ErrVal) ERRZERO ,
         "[MGCP] MgLiHitConCfm: ConCfm rcved in InValid Resource State\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_CONCFM,
                  LCM_CAUSE_PROT_NOT_ACTIVE , LMG_ALARMINFO_NONE,NULLP, 0, 
                  LMG_ALARMINFO_INVSAPID);
      RETVALUE(RFAILED);
   }
#endif /* ZG_DFTHA */

   if (localAddr == NULLP)
   {
      parId.parType = LMG_PAR_TPTADDR;
      parId.sapId   = suId;

#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG107, (ErrVal) ERRZERO,
                 "MgLiHitConCfm: Invalid parameter");
#endif /* ERRCLASS & ERRCLS_INT_PAR */

      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_CONCFM,
                   LCM_CAUSE_INV_PAR_VAL, LMG_ALARMINFO_PAR,
                   (Ptr) &parId, sizeof (MgParId), LMG_ALARMINFO_INVSAPID);

      RETVALUE(RFAILED);
   }


   MG_CHK_TSAP_ST (mgCb.tSAPLst[suId], NULLP);

   srvrState = LMG_LSTNR_STATE_NULL;

   MG_GET_SRVRCB(srvrCb, suConnId, mgCb.tSAPLst[suId]);

   if (srvrCb != NULLP)
   {
      srvrState = srvrCb->state; 
   }
   else
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      /* debug error */
      MGLOGERROR(ERRCLS_INT_PAR, EMG108, (ErrVal) ERRZERO,
                 "MgLiHitConCfm: Invalid parameter:suConnId");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      RETVALUE(RFAILED);
   }

   switch (srvrState)
   {
      case LMG_LSTNR_STATE_NULL:
         /* 
          * Earlier DiscReq might have got lost or crossed or this 
          * ConCfm is spurious 
          */
         mgSrvDiscReq(srvrCb, TRUE);
         ret = RFAILED;

      case LMG_LSTNR_STATE_CONNECTED:
#if (ERRCLASS & ERRCLS_DEBUG)
         MGLOGERROR(ERRCLS_DEBUG, EMG109, (ErrVal) suConnId,
                    "MgLiHitConCfm: Received HitConCfm in CONNECTED tptState ");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         ret = RFAILED;

      case LMG_LSTNR_STATE_CONNECTING:
         /* update the control block with the new state etc.*/
         ret = mgSrvConCfm(spConnId,srvrCb,
                           mgCb.tSAPLst[suId],
                           localAddr);

         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         MGLOGERROR(ERRCLS_DEBUG, EMG110, (ErrVal) srvrState,
                    "MgLiHitConCfm: Invalid tptState in control block");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         ret = RFAILED;
   }

#ifdef ZG
   /* send update to peer */
   zgUpdPeer();
#endif /* ZG */
   RETVALUE(ret);
} /* end of MgLiHitConCfm */




/******************************************************************************/
/*                  Connect Indication  Function                              */
/******************************************************************************/

/*
*
*       Fun:   MgLiHitConInd
*
*       Desc:  Connection indication
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider
*              to indicate TCP connection. This primitive will never
*              be issued in case of MGCP but shall be used only if
*              MEGACO protocol is used
*
*       File:  mg_li.c
*
*/
#ifdef ANSI
PUBLIC S16 MgLiHitConInd
(
Pst            *post,         /* post structure */
SuId           suId,          /* service user SAP identifier */
UConnId        srvSuConnId,   /* service user server connection id */
UConnId        spConnId,      /* service provider connection identifier */
CmTptAddr      *peerAddr      /* transport address */
)
#else
PUBLIC S16 MgLiHitConInd(post, suId, srvSuConnId, spConnId, peerAddr)
Pst            *post;         /* post structure */
SuId           suId;          /* service user SAP identifier */
UConnId        srvSuConnId;   /* service user server connection id */
UConnId        spConnId;      /* service provider connection identifier */
CmTptAddr      *peerAddr;     /* transport address */
#endif
{
   S16   ret = ROK;        /* return value */
   
#ifdef GCP_MGCO
#ifdef GCP_MGC

#ifdef DEBUGP
   U16   port;
   Txt   addr[2 * CM_IPV6ADDR_SIZE + 1];
#endif /* DEBUGP */
   MgParId   parId;
   MgTptSrvr *srvrCb;

   TRC3(MgLiHitConInd);

   UNUSED(post);

#ifdef DEBUGP
   {
     mgGetPortAndAscAddr (peerAddr, &port, addr);

     MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf,
                          "MgLiHitConInd(post, suId(%d), srvSuConnId(%ld), spConnId(%ld),"
                          "peerAddr.type(%d), peerAddr.port(%d), peerAddr.address(%s))\n",
                          suId, srvSuConnId, spConnId, peerAddr->type, port, addr));
   }
#endif /* DEBUGP */


#ifdef ZG_DFTHA
   if((zgChkCRsetStatus()) == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG111, (ErrVal) ERRZERO ,
       "[MGCP] MgLiHitConnInd(): Conn Ind rcved in Invalid Resource State\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_DISCIND,
                   LCM_CAUSE_PROT_NOT_ACTIVE , LMG_ALARMINFO_NONE,NULLP, 0, 
                   LMG_ALARMINFO_INVSAPID);
      RETVALUE(RFAILED);
   }
#endif /* ZG_DFTHA */

#if (ERRCLASS & ERRCLS_INT_PAR)
   MG_CHK_SUID (suId, NULLP, EMG112, MgLiHitConInd, LMG_EVENT_HIT_CONIND);
#endif /* ERRCLASS & ERRCLS_INT_PAR */


   if (peerAddr == NULLP)
   {
      parId.parType = LMG_PAR_TPTADDR;
      parId.sapId   = suId;

#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG113, (ErrVal) ERRZERO,
                 "MgLiHitConInd: Invalid parameter");
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_CONIND, 
                      LCM_CAUSE_INV_PAR_VAL, LMG_ALARMINFO_PAR,
                   (Ptr) &parId, sizeof (MgParId), LMG_ALARMINFO_INVSAPID);

      RETVALUE(RFAILED);
   }

   if ((srvrCb = MG_CHKLSTNRCB(mgCb.tSAPLst[suId], srvSuConnId)) == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      /* debug error */
      MGLOGERROR(ERRCLS_INT_PAR, EMG114, (ErrVal) ERRZERO,
                 "MgLiHitConInd: Invalid parameter:suConnId");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      RETVALUE(RFAILED);
   }


   if (srvrCb->state != LMG_LSTNR_STATE_CONNECTED)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
     MGLOGERROR(ERRCLS_DEBUG, EMG115, (ErrVal) srvrCb->state,
                "MgLiHitConCfm: Invalid tptState in control block");
#endif /* ERRCLASS & ERRCLS_DEBUG */
     RETVALUE(RFAILED);
   }   
   

   ret = mgSrvConInd(srvrCb, peerAddr,
                     mgCb.tSAPLst[suId],
                     spConnId);


#endif /* GCP_MGC */
#endif /* GCP_MGCO */

#ifdef ZG
   /* send run time update */
   zgUpdPeer();
#endif /* ZG */
   UNUSED(post);
   UNUSED(suId);
   UNUSED(srvSuConnId);
   UNUSED(spConnId);
   UNUSED(peerAddr);

   RETVALUE(ret);
} /* end of MgLiHitConInd */




/******************************************************************************/
/*                  DisConnect Indication Function                            */
/******************************************************************************/


/*
*
*       Fun:   MgLiHitDiscInd
*
*       Desc:  Disconnect indication
*
*       Ret:   ROK on success*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to 
*              indicate that the server is down.
*
*       File:  mg_li.c
*
*/
#ifdef ANSI
PUBLIC S16 MgLiHitDiscInd
(
Pst           *post,       /* post structure */
SuId          suId,        /* service user SAP identifier */
U8            choice,      /* type of connection identifier */
UConnId       connId,      /* connection identifier suConnId or spConnId */
Reason        reason       /* disconnect reason */
)
#else
PUBLIC S16 MgLiHitDiscInd(post, suId, choice, connId, reason)
Pst           *post;       /* post structure */
SuId          suId;        /* service user SAP identifier */
U8            choice;      /* type of connection identifier */
UConnId       connId;      /* connection identifier suConnId or spConnId */
Reason        reason;      /* disconnect reason */
#endif
{
   MgTptSrvr *srvrCb;      /* server control block */
   MgParId   parId;

   TRC3(MgLiHitDiscInd);

   UNUSED(post);
   /*
    * Initialize srvrCb to NULLP
    */
   srvrCb = NULLP;

#ifdef DEBUGP
   MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
           "MgLiHitDiscInd(post, suId(%d), choice(%d), connId(%ld),"
           "reason(%d)\n", suId, choice, connId, reason));
#endif /* DEBUGP */


#if (ERRCLASS & ERRCLS_INT_PAR)
   MG_CHK_SUID (suId, NULLP, EMG116, MgLiHitDiscInd, LMG_EVENT_HIT_DISCIND);
#endif /* ERRCLASS & ERRCLS_INT_PAR */

#ifdef ZG_DFTHA
   if((zgChkCRsetStatus()) == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG117, (ErrVal) ERRZERO ,
       "[MGCP] MgLiHitDiscInd(): Disc Ind rcved in Invalid Resource State\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_DISCIND,
                  LCM_CAUSE_PROT_NOT_ACTIVE  , LMG_ALARMINFO_NONE,NULLP, 0, 
                  LMG_ALARMINFO_INVSAPID);
      RETVALUE(RFAILED);
   }
#endif /* ZG_DFTHA */

   if (choice != HI_PROVIDER_CON_ID && choice != HI_USER_CON_ID)
   {
      parId.parType = LMG_PAR_CHOICE;
      parId.sapId   = suId;

#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG118, (ErrVal) choice,
                 "MgLiHitDiscInd: Invalid choice value");
#endif /* ERRCLASS & ERRCLS_INT_PAR */

      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_DISCIND,
                   LCM_CAUSE_INV_PAR_VAL, LMG_ALARMINFO_PAR,
                   (Ptr) &parId, sizeof (MgParId), LMG_ALARMINFO_INVSAPID);

      RETVALUE(RFAILED);
   }

   MG_CHK_TSAP_ST (mgCb.tSAPLst[suId], NULLP);

   if(choice == HI_PROVIDER_CON_ID)
   {
      MgTptSrvr   *prevSrvr;

      prevSrvr = srvrCb;

      while(ROK == cmHashListGetNext(
                                     &(mgCb.tSAPLst[suId]->tptSrvrLstCp), 
                                     (PTR)prevSrvr, (PTR *)&srvrCb) )
      {
         if(connId == srvrCb->spConnId)
            break;
         prevSrvr = srvrCb;
         srvrCb = NULLP;
      }
   }
   else if (choice == HI_USER_CON_ID)
   {
      MG_GET_SRVRCB(srvrCb, connId, mgCb.tSAPLst[suId]);
   }

   if (srvrCb != NULLP)
   {
      /* this is a server connection */
      if (srvrCb->state == LMG_LSTNR_STATE_NULL)
         RETVALUE(RFAILED);
      mgSrvDiscInd(srvrCb);

#ifdef ZG
      /* send update to peer */      
      zgUpdPeer();
#endif /* ZG */
   }

   RETVALUE(ROK);
} /* end of MgLiHitDiscInd */




/******************************************************************************/
/*                  Data Indication Function                                  */
/******************************************************************************/
/*
*
*       Fun:   MgLiHitDatInd
*
*       Desc:  Data indication
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to 
*              forward received data on TCP a connection. MGCP does not use this
*              primitive. This is valid only for MEGACO.
*
*       File:  mg_li.c
*
*/
#ifdef ANSI
PUBLIC S16 MgLiHitDatInd
(
Pst     *post,       /* post structure */
SuId    suId,        /* service user SAP identifier */
UConnId suConnId,    /* service user connection identifier */
Buffer  *mBuf        /* message buffer */
)
#else
PUBLIC S16 MgLiHitDatInd(post, suId, suConnId, mBuf)
Pst     *post;       /* post structure */
SuId    suId;        /* service user SAP identifier */
UConnId suConnId;    /* service user connection identifier */
Buffer  *mBuf;       /* message buffer */
#endif
{
#ifdef GCP_MGCO
   MgParId  parId;
   MgTptSrvr *srvrCb;
   UConnId   connId;    /* service user connection identifier */
#endif /* GCP_MGCO */

   TRC3(MgLiHitDatInd);

#ifdef GCP_MGCP
   UNUSED(post);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(mBuf);
#endif /* GCP_MGCP */

   /* mg008.105: if configuration not done do not process message */
   if (mgCb.init.cfgDone != TRUE)
   {
      if (mBuf)
         mgPutMsg (mBuf);

      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_DATIND,
                   LCM_CAUSE_INV_STATE, LMG_ALARMINFO_NONE,NULLP, 0, 
                   LMG_ALARMINFO_INVSAPID);

      RETVALUE(RFAILED);
   }

#ifdef GCP_MGCO

   if (mBuf == NULLP)
   {
     parId.parType = LMG_PAR_MBUF;
     parId.sapId   = suId;

#if (ERRCLASS & ERRCLS_INT_PAR)
     MGLOGERROR(ERRCLS_INT_PAR, EMG119, (ErrVal) ERRZERO,
                "MgLiHitDatInd: Invalid mBuf");
#endif /* ERRCLASS & ERRCLS_INT_PAR */

      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_DATIND,
                  LCM_CAUSE_INV_PAR_VAL, LMG_ALARMINFO_PAR,
                  (Ptr) &parId, sizeof (MgParId), LMG_ALARMINFO_INVSAPID);
      RETVALUE(RFAILED);
   }

   
   MG_CHK_TSAP_ST (mgCb.tSAPLst[suId], mBuf);
   
   connId = suConnId & MG_SUCONNID_TCP_MASK;

   MG_GET_TCP_CONN(connId, srvrCb, mgCb.tSAPLst[suId]);

   if (srvrCb == NULLP)
   {
      (Void) mgPutMsg(mBuf);
      RETVALUE(RFAILED);
   }

   /*
    * Add the debug printing and control for DatInd, inside DEBUGP flag.
    */
#ifdef DEBUGP
   {
      MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf,
             "MgLiHitDatInd(post, suId(%d), suConnId(%ld))\n", suId, suConnId));
      if (mgCb.init.dbgMask & MG_DBGMASK_LI_MBUF)
         SPrntMsg (mBuf, 0, 0);
   }

   /*
    * Put the existing SPrntMsg inside GCP_ACC_TESTS as this printing is
    * needed for acceptance tests
    */
#ifdef GCP_ACC_TESTS
   SPrntMsg(mBuf, 0, 0);
#endif /* GCP_ACC_TESTS */

#endif /* DEBUGP */

#ifdef ZG_DFTHA
   /* Some cases LLDF embeds rsetid in suconnid ..which will be different from
    * srvr->suConnd..so store it */
   srvrCb->suRsetId = suConnId;
#endif /* ZG_DFTHA */

   /* Generate Trace Indication To Layer Manager if enabled */
   mgGenTrcInd(mgCb.tSAPLst[suId], MG_NONE, LMG_TRC_EVENT_MGCORX, NULLP, mBuf);

   /* Process Transaction from peer */
   mgPrcMgcoTxnInd(
#if    (defined(GCP_PROV_MTP3) || defined(GCP_PROV_SCTP))
                   NULLP,
#endif    /* GCP_PROV_MTP3 || GCP_PROV_SCTP  */                   
                   mgCb.tSAPLst[suId],
                   srvrCb, &srvrCb->tptAddr, mBuf, NULLP, srvrCb->t.peer);


#endif /* MGCO */

   RETVALUE(ROK);
} /* end of MgLiHitDatInd */




/******************************************************************************/
/*                  Unit Data Indication Function                             */
/******************************************************************************/
/*
*
*       Fun:   MgLiHitUDatInd
*
*       Desc:  Unit data indication
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to 
*              forward received datagram (UDP) to MGCP 
*
*       File:  mg_li.c
*
*/
#ifdef ANSI
PUBLIC S16 MgLiHitUDatInd
(
Pst            *post,       /* post structure */
SuId           suId,        /* service user SAP identifier */
UConnId        suConnId,    /* service user server connection identifier */
CmTptAddr      *srcAddr,    /* transport address */
CmTptAddr      *remAddr,    /* transport address */
CmIpHdrParm    *ipHdrParm,
Buffer         *mBuf        /* message buffer */
)
#else
PUBLIC S16 MgLiHitUDatInd(post, suId, suConnId, srcAddr, remAddr, ipHdrParm, mBuf)
Pst            *post;       /* post structure */
SuId           suId;        /* service user SAP identifier */
UConnId        suConnId;    /* service user connection identifier */
CmTptAddr      *srcAddr;    /* transport address */
CmTptAddr      *remAddr;    /* transport address */
CmIpHdrParm    *ipHdrParm;
Buffer         *mBuf;       /* message buffer */
#endif
{
   MgTptSrvr  *srvrCb;      /* listener control block */
#ifdef DEBUGP
   U16   port;
   Txt   addr[2 * CM_IPV6ADDR_SIZE + 1];
#endif /* DEBUGP */
   MgParId  parId;


   TRC3(MgLiHitUDatInd);

   UNUSED(post);

   /* mg008.105: if configuration not done do not process message */
   if (mgCb.init.cfgDone != TRUE)
   {
      if (mBuf)
         mgPutMsg (mBuf);

      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_UDATIND,
                   LCM_CAUSE_INV_STATE, LMG_ALARMINFO_NONE,NULLP, 0, 
                   LMG_ALARMINFO_INVSAPID);

      RETVALUE(RFAILED);
   }

   if (mBuf == NULLP)
   {
      parId.parType = LMG_PAR_MBUF;
      parId.sapId   = suId;

#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG120, (ErrVal) ERRZERO,
                 "MgLiHitUDatInd: Invalid mBuf");
#endif /* ERRCLASS & ERRCLS_INT_PAR */

      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_UDATIND,
                   LCM_CAUSE_INV_PAR_VAL, LMG_ALARMINFO_PAR,
                   (Ptr) &parId, sizeof (MgParId), LMG_ALARMINFO_INVSAPID);
      RETVALUE(RFAILED);
   }

#ifdef DEBUGP
   {
      mgGetPortAndAscAddr (srcAddr, &port, addr);

      MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf,
              "MgLiHitUDatInd(post, suId(%d), suConnId(%ld), "
              "srcAddr.type(%d), srcAddr.port(%d), srcAddr.address(%s))\n",
              suId, suConnId, srcAddr->type, port, addr));
      if (mgCb.init.dbgMask & MG_DBGMASK_LI_MBUF)
	        SPrntMsg (mBuf, 0, 0);
   }
#endif /* DEBUGP */


#if (ERRCLASS & ERRCLS_INT_PAR)
   MG_CHK_SUID (suId, mBuf, EMG121, MgLiHitUDatInd, LMG_EVENT_HIT_UDATIND);
#endif /* ERRCLASS & ERRCLS_INT_PAR */


   if (srcAddr == NULLP)
   {
      parId.parType = LMG_PAR_TPTADDR;
      parId.sapId   = suId;
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG122, (ErrVal) ERRZERO,
                 "MgLiHitUDatInd: Invalid srcAddr");
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      if (mBuf)
         mgPutMsg (mBuf);

      mgGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_HIT_UDATIND,
                   LCM_CAUSE_INV_PAR_VAL, LMG_ALARMINFO_PAR,
                   (Ptr) &parId, sizeof (MgParId), LMG_ALARMINFO_INVSAPID);
      RETVALUE(RFAILED);
   }


   MG_CHK_TSAP_ST (mgCb.tSAPLst[suId], mBuf);


   if ((srvrCb = MG_CHKLSTNRCB(mgCb.tSAPLst[suId], suConnId)) == NULLP)
   {
      (Void) mgPutMsg(mBuf);
      RETVALUE(RFAILED);
   }

#ifdef DEBUGP
   /*
    * Put the existing SPrntMsg inside GCP_ACC_TESTS as this printing is
    * needed for acceptance tests
    */
#ifdef GCP_ACC_TESTS
   SPrntMsg(mBuf, 0, 0);
#endif /* GCP_ACC_TESTS */

#endif /* DEBUGP */

#ifdef ZG_DFTHA
   /* Some cases LLDF embeds rsetid in suconnid ..which will be different from
    * srvr->suConnd..so store it */
   srvrCb->suRsetId = suConnId;
#endif /* ZG_DFTHA */


   if (mgCb.tSAPLst[suId]->dnsInfo.dnsLstnr == srvrCb)
   {
#ifdef CM_DNS_LIB
       /* Generate Trace Indication To Layer Manager if enabled */
       mgGenTrcInd(mgCb.tSAPLst[suId], MG_NONE, LMG_TRC_EVENT_DNSRX, NULLP, mBuf);

      /* Response from DNS */
      cmDnsPrcDnsRsp (
                      mgCb.tSAPLst[suId]->dnsInfo.dnsCb,
                      srcAddr, mBuf);

#endif /* CM_DNS_LIB */

      /* Free Message Buffer */
      if (mBuf != NULLP)
         mgPutMsg(mBuf);
   }
   else
   {
     /* Transaction from peer */
     if (srvrCb->protocol == LMG_PROTOCOL_MGCO)
     {
#ifdef GCP_MGCO
       /* Generate Trace Indication To Layer Manager if enabled */
       mgGenTrcInd(mgCb.tSAPLst[suId], MG_NONE, LMG_TRC_EVENT_MGCORX, NULLP, mBuf);
       mgPrcMgcoTxnInd(
#if    (defined(GCP_PROV_MTP3) || defined(GCP_PROV_SCTP))
                       NULLP,
#endif    /* GCP_PROV_MTP3  || GCP_PROV_SCTP */                       
                       mgCb.tSAPLst[suId],
                       srvrCb,srcAddr,mBuf, NULLP, NULLP);

#endif /* GCP_MGCO */
     }
     else if (srvrCb->protocol == LMG_PROTOCOL_MGCP)
     {
#ifdef GCP_MGCP
       mgGenTrcInd(mgCb.tSAPLst[suId], MG_NONE, LMG_TRC_EVENT_MGCPRX, NULLP, mBuf);

       mgPrcMgcpTxnInd(
                       mgCb.tSAPLst[suId],
                       srvrCb,srcAddr,mBuf, NULLP, NULLP);

#endif /* GCP_MGCP */
     }
   }

   RETVALUE(ROK);

} /* end of MgLiHitUDatInd */




/******************************************************************************/
/*                  Disconnect Confirm Function                               */
/******************************************************************************/
/*
*
*       Fun:   MgLiHitDiscCfm
*
*       Desc:  Disconnect confirm
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to 
*              confirm the disconnect request from MGCP
*
*       File:  mg_li.c
*
*/
#ifdef ANSI
PUBLIC S16 MgLiHitDiscCfm
(
Pst     *post,       /* post structure */
SuId    suId,        /* service user SAP identifier */
U8      choice,      /* type of connection identifier */
UConnId connId,      /* connection identifier either suConnId or spConnId */
Action  action       /* action */
)
#else
PUBLIC S16 MgLiHitDiscCfm(post, suId, choice, connId, action)
Pst     *post;       /* post structure */
SuId    suId;        /* service user SAP identifier */
U8      choice;      /* type of connection identifier */
UConnId connId;      /* connection identifier either suConnId or spConnId */
Action  action;      /* action */
#endif
{
   TRC3(MgLiHitDiscCfm)

#ifdef DEBUGP
   MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
          "MgLiHitDiscCfm(post, suId(%d), choice(%d), connId(%ld), action(%d)\n",
          suId, choice, connId, action));
#endif /* DEBUGP */


   UNUSED(post);
   UNUSED(suId);
   UNUSED(choice);
   UNUSED(connId);
   UNUSED(action);
  
   RETVALUE(ROK);
} /* end of MgLiHitDiscCfm */





/******************************************************************************/
/*                 Flow Control Indication Function                           */
/******************************************************************************/
/*
*
*       Fun:   MgLiHitFlcInd
*
*       Desc:  Flow control indication
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to 
*              indicate MGCP to start/stop flow control of data
*
*       File:  mg_li.c
*
*/
#ifdef ANSI
PUBLIC S16 MgLiHitFlcInd
(
Pst     *post,       /* post structure */
SuId    suId,        /* service user SAP identifier */
UConnId suConnId,    /* Connection identifier */
Reason  reason       /* reason */
)
#else
PUBLIC S16 MgLiHitFlcInd(post, suId, suConnId, reason)
Pst     *post;       /* post structure */
SuId    suId;        /* service user SAP identifier */
UConnId suConnId;    /* Connection identifier */
Reason  reason;      /* reason */
#endif
{
   S16 ret;

   TRC3(MgLiHitFlcInd)

   MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf, 
           "MgLiHitFlcInd(post, suId(%d),suConnId(%ld), reason(%d)\n", 
             suId, suConnId, reason));

   UNUSED(post);
   UNUSED(suId);
   UNUSED(reason);
  
   /* Send Flow Control Indication to all the service users */
   ret = mgGenUserStaInd(NULLP, NULLP,  MGT_STATUS_FLOW, (Ptr) &reason);

   RETVALUE(ret);
} /* end of MgLiHitFlcInd */





#ifdef    GCP_PROV_SCTP

/* ------------------------------------------------------------------*
 * Interface Functions for Lower SCTP Interface                      *
 * ------------------------------------------------------------------*/




/*
*
*       Fun:   MgLiSctBndCfm
*
*       Desc:  Confirms a bind request.
*
*       Ret:   Failure:     RFAILED
*
*              Success:     ROK
*
*       Notes: <none>
*
*       File:  mp_li.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctBndCfm
(
Pst         *pst,             /* post structure */
SuId        suId,             /* service user SAP identifier */
SctResult   result            /* bind result */
)
#else
PUBLIC S16 MgLiSctBndCfm(pst, suId, result)
Pst         *pst;             /* post structure */
SuId        suId;             /* service user SAP identifier */
SctResult   result;           /* bind result */
#endif
{
   U16             event;              /* Event */
   U16             cause;              /* Cause */
   MgTSAPCb        *tsap;              /* TSAP Control Block */
   MgEndpCfg       endpCfg;            /* end point cfg var  */
   MgParId         parId;



   TRC3(MgLiSctBndCfm)

#ifdef DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
      "MgLiSctBndCfm(pst, suId(%d), result(%d))\n", suId, result));
#endif /* DEBUGP */

   UNUSED(pst);


   if (mgCb.init.cfgDone != TRUE)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG123, (ErrVal) suId,
                 "MgLiSctBndCfm: General configuration not done");
#endif /* ERRCLASS & ERRCLS_INT_PAR */

      MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_BNDCFM, LCM_CAUSE_INV_STATE,
                           LMG_ALARMINFO_INVSAPID, (parId));

      RETVALUE(RFAILED);
   }


#ifdef ZG_DFTHA
   if((zgChkCRsetStatus()) == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG124, (ErrVal) ERRZERO ,
         "[MGCP] MgLiSctBndCfm: BndCfm rcved in Invalid resource state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_BNDCFM, LCM_CAUSE_PROT_NOT_ACTIVE,
                           LMG_ALARMINFO_INVSAPID, (parId));

      RETVALUE(RFAILED);
   }
#endif /* ZG_DFTHA */



   /*
    *
    * Check if suId is valid; if tsap has been allocated
    * for this suId;
    *
    */

   /*mg002.105: Removed compilation warning*/
   if ((suId < 0)|| (suId >= (SuId)mgCb.genCfg.maxTSaps) ||
       (mgCb.tSAPLst[suId] == NULLP))
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_INT_PAR, EMG125, (ErrVal) suId,
                 "[MGCP] MgLiSctBndCfm: Invalid suId");
#endif /* ERRCLASS & ERRCLS_DEBUG */


      /*
       *
       * Raise an alarm - invalid suId received
       *
       */

      MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_BNDCFM, LCM_CAUSE_INV_SAP,
                           LMG_ALARMINFO_INVSAPID, (parId));

      RETVALUE(RFAILED);
   }



   /*
    * mgCb now has a list of TSAPs
    */

   tsap = mgCb.tSAPLst[suId];


   /* Check tsap state */
   switch (tsap->state)
   {
      case LMG_SAP_WAIT_BNDENB:
      {
         /*
          *
          * Stop Bind timer; validate result;
          * if Bind result is OK, change tsap state to BND_ENB;
          *
          */

         mgStopTmr (MG_BNDREQ_TMR, (PTR)tsap, &(tsap->bndTmr));

         tsap->bndRetxCnt = 0;
          
         if (result == CM_BND_OK)
         {
            tsap->state = LMG_SAP_BND_ENB;
            event = LCM_EVENT_BND_OK;
            cause = LMG_CAUSE_SAP_BNDENB;

#ifdef ZG
#ifdef GCP_MG
            if(tsap->tsapCfg.reCfg.changeOver == TRUE)
            {
               U32   i;
               for(i=0; i< mgCb.genCfg.maxSSaps; i++)
               {
                  MgSSAPCb   *ssap = NULLP;
                  ssap = mgCb.sSAPLst[i];
                  if(ssap != NULLP)
                  {
                     mgStartSsapServers(ssap);
                  }
               }
            }
#endif /* GCP_MG */
#endif /* ZG */


            /*
             *
             * send end point open request;
             * the following function sends MgLiSctEndpOpenReq
             * if it has already not been sent;
             *
             */


            cmMemset((U8 *)&endpCfg, 0, sizeof(MgEndpCfg));

            /*
             * we are NOT using intfAddr in endpCfg at present here;
             * Therefore for consistency, we might remove it from
             * MgEndpCfg also so that its not used in mp_mi.c : endpCfgReq
             */

            endpCfg.sctPort = tsap->endpCb.port;

            /*
             * Copy the suEndpId - tSAPId was assigned to
             * suEndpId in endpoint cfg
             */
            endpCfg.tSAPId  = tsap->endpCb.locSuEndpId;


            
#ifdef   ZG
            /*
             * If Changeover Flag is true and We have successfully
             * Bound to new copy of SCTP then issue endpoint open req
             */  
             if (((zgChkCRsetStatus()) == TRUE) && 
                (tsap->tsapCfg.reCfg.changeOver == TRUE))
               mgEndpOpenReq(tsap,&endpCfg);
             else    /* Do not Remove this */  
#endif   /* ZG */             
            
            /*
             * if an endpoint was configured on this SCT TSAP previously
             * but the SCT TSAP was not bound at that time, then issue
             * the endpoint open req now.
             */
             
            if (tsap->endpCfgDone == TRUE)
               mgEndpOpenReq(tsap,&endpCfg);


            /*
             * Following code required for DFTHA -
             *
             *
             * #ifdef ZG
             * #ifdef GCP_MGCO
             * #ifdef GCP_MG
                     if(tsap->tsapCfg.reCfg.changeOver == TRUE)
                        mgRecovrEndpsAndAssoc(tsap);
             * #endif
             * #endif
             * #endif
             *
             *
             */
         }
         else
         {
            tsap->state  = LMG_SAP_UBND_DIS;
            event        = LCM_EVENT_BND_FAIL;
            cause        = LMG_CAUSE_UNKNOWN;
         }
#ifdef ZG
         /* send run time update for tsap */
         zgRtUpd(ZG_CBTYPE_TSAP, (Ptr)tsap, CMPFTHA_UPDTYPE_SYNC,
                                 CMPFTHA_ACTN_MOD);
#endif /* ZG */
      }
      break;

     default:
        event = LMG_EVENT_SCT_BNDCFM;
        cause = LCM_CAUSE_INV_STATE;
        break;
   }

   MG_GEN_SCTP_LI_ALARM(event, cause,
                        (suId), (parId));


#ifdef ZG
   /* send update message to stndby */
   zgUpdPeer();
#endif /* ZG */

   RETVALUE(ROK);

} /* end of MgLiSctBndCfm */





/*
*
*       Fun:   MgLiSctEndpOpenCfm
*
*       Desc:  Confirms an endpoint open request.
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  mp_li.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctEndpOpenCfm
(
Pst         *pst,             /* post structure */
SuId        suId,             /* service user SAP identifier */
UConnId     suEndpId,         /* service user endpoint identifier */
UConnId     spEndpId,         /* service provider endpoint identifier */
SctResult   result,           /* endpoint open result */
SctCause    cause             /* cause of failure */
)
#else
PUBLIC S16 MgLiSctEndpOpenCfm(pst, suId, suEndpId, spEndpId, result, cause)
Pst         *pst;             /* post structure */
SuId        suId;             /* service user SAP identifier */
UConnId     suEndpId;         /* service user endpoint identifier */
UConnId     spEndpId;         /* service provider endpoint identifier */
SctResult   result;           /* endpoint open result */
SctCause    cause;            /* cause of failure */
#endif
{
   MgEndpCb *endpCb = NULLP;         /* endpoint control block */
   MgParId   parId;
   MgTSAPCb  *tsap;              /* TSAP Control Block */



   TRC3(MgLiSctEndpOpenCfm)

#ifdef DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
          "MgLiSctEndpOpenCfm(pst, suId(%d), suEndpId(%ld), spEndpId(%ld), "
          "result(%d)\n", suId, suEndpId, spEndpId, result));
#endif /* DEBUGP */

   UNUSED(cause);
   UNUSED(pst);




#if (ERRCLASS & ERRCLS_INT_PAR)

   /*
    * The following macro checks -
    *
    *    1) for the sanity of suId
    *    2) if the tsap state is BND_ENB
    *
    */

   MG_CHK_SUID(suId, NULLP, EMG126, MgLiSctEndpOpenCfm,
                     LMG_EVENT_SCT_ENDPOPENCFM);
   
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   tsap   = mgCb.tSAPLst[suId];
   endpCb = &(mgCb.tSAPLst[suId]->endpCb);



   /*
    * validate the following -
    *
    *    1) endpCfgDone should have been set to TRUE
    *       in end point cfg req
    *    1) current end point state
    *    2) result of end point open cfm
    *    3) compare received suEndpId against the one stored
    *
    */

   if ((mgCb.tSAPLst[suId]->endpCfgDone == TRUE) &&
       (endpCb->epState == LMG_EP_STATE_WAIT_CFM) &&
       (result == SCT_OK) &&
       (endpCb->locSuEndpId == suEndpId))
   {
      /* 
       * Do the following -
       *    a) Store the received spEndpId
       *    b) update the end point state to READY
       *
       */
      endpCb->locSpEndpId = spEndpId;
      endpCb->epState = LMG_EP_STATE_READY;

#ifdef ZG
#ifdef GCP_MGCO
      /*
       * Change Over Flag is Set i.e. new copy of
       * SCTP has come up now esablish association with concerned
       * MGC again and Send Service Change Request
       */
      if(tsap->tsapCfg.reCfg.changeOver == TRUE)  
         mgRecovrEndp(tsap);
#endif /* GCP_MGCO */
#endif /* ZG */
             
#ifdef ZG
            /* send run time update for tsap */
          zgRtUpd(ZG_CBTYPE_TSAP, (Ptr)tsap, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
          zgUpdPeer();
#endif /* ZG */
      RETVALUE(ROK);         
   }
   else

   /*
    * end point open cfm validation failed
    */

   {
     /*
      *   The following function will update
      * endpCfgDone to FALSE
      */

      mgDeAllocEndpCb(endpCb);

      /*
       *  reset the endpoint configuration done flag
       */

      mgCb.tSAPLst[suId]->endpCfgDone = FALSE;

#ifdef ZG
         /* send run time update for tsap */
      zgRtUpd(ZG_CBTYPE_TSAP, (Ptr)tsap, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
      zgUpdPeer();
#endif /* ZG */

      MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_ENDPOPENCFM, LCM_CAUSE_UNKNOWN,
                           (suId), (parId));

      RETVALUE(RFAILED);
   }



} /* end of MgLiSctEndpOpenCfm */





/*
*
*       Fun:   MgLiSctEndpCloseCfm
*
*       Desc:  Confirms an endpoint close request.
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  mp_li.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctEndpCloseCfm
(
Pst         *pst,             /* post structure */
SuId        suId,             /* service user SAP identifier */
UConnId     suEndpId,         /* service user endpoint identifier */
SctResult   result,           /* endpoint close result */
SctCause    cause             /* cause of failure */
)
#else
PUBLIC S16 MgLiSctEndpCloseCfm(pst, suId, suEndpId, result, cause)
Pst         *pst;             /* post structure */
SuId        suId;             /* service user SAP identifier */
UConnId     suEndpId;         /* service user endpoint identifier */
SctResult   result;           /* endpoint close result */
SctCause    cause;            /* cause of failure */
#endif
{
   MgEndpCb *endpCb = NULLP;         /* endpoint control block */
   MgParId   parId;
   MgTSAPCb  *tsap;              /* TSAP Control Block */


   TRC3(MgLiSctEndpCloseCfm)

#ifdef DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
   "MgLiSctEndpCloseCfm(pst, suId(%d), suEndpId(%ld), result(%d), cause(%d))\n",
                       suId, suEndpId, result, cause));
#endif /* DEBUGP */

   UNUSED(pst);

#ifndef DEBUGP
   UNUSED(cause);
   UNUSED(result);
#endif


#if (ERRCLASS & ERRCLS_INT_PAR)

   /*
    * The following macro checks -
    *
    *    1) for the sanity of suId
    *    2) if the tsap state is BND_ENB
    *
    */

   MG_CHK_SUID(suId, NULLP, EMG127, MgLiSctEndpCloseCfm,
                     LMG_EVENT_SCT_ENDPCLOSECFM);
   
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   tsap   = mgCb.tSAPLst[suId];

   endpCb = &(mgCb.tSAPLst[suId]->endpCb);



   /*
    * validate the following -
    *
    *    1) endpCfgDone should have been set to TRUE
    *       in end point cfg req
    *    1) current end point state
    *    2) result of end point close cfm
    *    3) compare received suEndpId against the one stored
    *
    */

   if ((mgCb.tSAPLst[suId]->endpCfgDone == TRUE) &&
       (endpCb->epState == LMG_EP_STATE_WAIT_CFM) &&
       (result == SCT_OK) &&
       (endpCb->locSuEndpId == suEndpId))
   {
     /*
      *   The following function will update
      * endpCfgDone to FALSE
      */

      mgDeAllocEndpCb(endpCb);

      /*
       *  reset the endpoint configuration done flag
       */

      mgCb.tSAPLst[suId]->endpCfgDone = FALSE;

#ifdef ZG
         /* send run time update for tsap */
      zgRtUpd(ZG_CBTYPE_TSAP, (Ptr)tsap, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
      zgUpdPeer();
#endif /* ZG */


      RETVALUE(ROK);         
   }
   else

   /*
    * end point close cfm validation failed
    */

   {
      MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_ENDPCLOSECFM, LCM_CAUSE_UNKNOWN,
                           (suId), (parId));

      RETVALUE(RFAILED);
   }


} /* end of MgLiSctEndpCloseCfm */





/*
*
*       Fun:   MgLiSctAssocInd
*
*       Desc:  Indicates a request for association from a peer SCTP user
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  mp_li.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctAssocInd
(
Pst                  *pst,          /* post structure */
SuId                 suId,          /* service user SAP identifier */
UConnId              suEndpId,      /* service user endpoint identifier */
SctAssocIndParams    *assocParams,  /* prmt to the association indication */
Buffer               *vsInfo        /* vendor-specific information */
)
#else
PUBLIC S16 MgLiSctAssocInd (pst, suId, suEndpId, assocParams, vsInfo)
Pst                  *pst;          /* post structure */
SuId                 suId;          /* service user SAP identifier */
UConnId              suEndpId;      /* service user endpoint identifier */
SctAssocIndParams    *assocParams;  /* prmt to the association indication */
Buffer               *vsInfo;       /* vendor-specific information */
#endif
{
   MgEndpCb     *endpCb;            /* end point control block */

#if (ERRCLASS & ERRCLS_INT_PAR)
   MgParId   parId;
#endif /* ERRCLASS & ERRCLS_INT_PAR */



   TRC3(MgLiSctAssocInd)

#ifdef DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
      "MgLiSctAssocInd(pst, suId(%d), suEndpId(%ld), assocParams)\n", 
      suId, suEndpId));
#endif /* DEBUGP */

   UNUSED(pst);

   /* vsInfo not used */
   MG_DROPDATA(vsInfo);



#if (ERRCLASS & ERRCLS_INT_PAR)

   /*
    * The following macro checks -
    *
    *    1) for the sanity of suId
    *    2) if the tsap state is BND_ENB
    *
    */

   MG_CHK_SUID(suId, NULLP, EMG128, MgLiSctAssocInd,
                     LMG_EVENT_SCT_ASSOCIND);
   
#endif /* ERRCLASS & ERRCLS_INT_PAR */


   endpCb = &(mgCb.tSAPLst[suId]->endpCb);



   /*
    * validate the following -
    *
    *    1) endpCfgDone should have been done
    *    2) current end point state
    *    3) compare received suEndpId against the one stored
    *
    */

   if (!((mgCb.tSAPLst[suId]->endpCfgDone == TRUE) &&
         (endpCb->epState == LMG_EP_STATE_READY) &&
         (endpCb->locSuEndpId == suEndpId)))
   {
      /* 
       * Send Assoc Response to SCTP indicating failure
       */
      /* mg001.105: Use the same TOS in the Rsp as that rcvd in the Ind */
      MgLiSctAssocRsp(&(mgCb.tSAPLst[suId]->spPst),
                      mgCb.tSAPLst[suId]->tsapCfg.spId,
                      endpCb->locSpEndpId,
                      assocParams,
                      /* reply with the same TOS as rcvd in ind */
                      assocParams->tos,
                      SCT_NOK,
                      (Buffer *)NULLP);

#if (ERRCLASS & ERRCLS_DEBUG)
         MGLOGERROR(ERRCLS_DEBUG, EMG129, (ErrVal) endpCb->epState,
                    "MgLiSctAssocInd: Invalid end point state");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      RETVALUE(RFAILED);
   }



   /*
    * call the following function which is defined in mp_tpt.c
    * to handle the association indication
    */

   (Void) mgPrcAssocInd(suId, endpCb, assocParams);

#ifdef ZG
   /* send run time update */
   zgUpdPeer();
#endif /* ZG */

   RETVALUE(ROK);
} /* end of MgLiSctAssocInd */





/*
*
*       Fun:   MgLiSctAssocCfm
*
*       Desc:  Confirms a local request for association establishment
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  mp_li.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctAssocCfm
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
UConnId       spAssocId,      /* service provider assoc identifier */
SctNetAddrLst *dstNAddrLst,   /* destination net address list */
SctPort       dstPort,        /* destination port */
SctStrmId     inStrms,        /* outgoing streams */
SctStrmId     outStrms,       /* outgoing streams */
Buffer        *vsInfo         /* vendor-specific information */
)
#else
PUBLIC S16 MgLiSctAssocCfm (pst, suId, suAssocId, spAssocId, dstNAddrLst, 
                            dstPort, inStrms, outStrms, vsInfo)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
UConnId       spAssocId;      /* service provider assoc identifier */
SctNetAddrLst *dstNAddrLst;   /* destination net address list */
SctPort       dstPort;        /* destination port */
SctStrmId     inStrms;        /* outgoing streams */
SctStrmId     outStrms;       /* outgoing streams */
Buffer        *vsInfo;        /* vendor-specific information */
#endif
{
   MgAssocCb *assocCb = NULLP;              /* association control block */
   S16       ret;                           /* return value */
   MgParId   parId;



   TRC3(MgLiSctAssocCfm)

#ifdef DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf,
      "MgLiSctAssocCfm(pst, suId(%d), suAssocId(%ld), spAssocId(%ld), "
      "dstNAddrLst(%p), dstPort(%d), outStrms(%d), vsInfo(%p))\n",
      suId, suAssocId, spAssocId, (void *)dstNAddrLst, dstPort, 
         outStrms, (void *)vsInfo));
#endif /* DEBUGP */

   UNUSED(pst);

   /* vsInfo not used */
   MG_DROPDATA(vsInfo);


#if (ERRCLASS & ERRCLS_INT_PAR)

   /*
    * The following macro checks -
    *
    *    1) for the sanity of suId
    *    2) if the tsap state is BND_ENB
    *
    */

   MG_CHK_SUID(suId, NULLP, EMG130, MgLiSctAssocCfm,
                     LMG_EVENT_SCT_ASSOCCFM);
   
#endif /* ERRCLASS & ERRCLS_INT_PAR */




   /*
    * search for the association control block in the
    * endpoint CB's suAssocId based hash list of assoc CBs
    */

   ret = cmHashListFind(&(mgCb.tSAPLst[suId]->endpCb.assocCp),
                        (U8 *)&suAssocId, MG_ASSOCID_LEN,
                        MG_HASH_SEQNMB_DEF, (PTR *)&assocCb);


   if ((ret != ROK) || (assocCb == NULLP) ||
       (assocCb->assocState != LMG_ASSOC_STATE_WAIT_CFM))
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG131, (ErrVal) assocCb,
                    "MgLiSctAssocCfm: Invalid end point state");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_ASSOCCFM, LCM_CAUSE_INV_STATE,
                           (suId), (parId));

      RETVALUE(RFAILED);
   }



   /*
    * Call the following function to process the association cfm;
    * This function is defined in mp_tpt.c
    */

   mgPrcAssocCfm(assocCb, spAssocId, inStrms, outStrms, dstNAddrLst);


#ifdef ZG
   /* send run time update */
   zgUpdPeer();
#endif /* ZG */

   RETVALUE(ROK);
} /* end of MgLiSctAssocCfm */





/*
*
*       Fun:   MgLiSctTermInd
*
*       Desc:  Indicates that an association has been terminated
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  mp_li.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctTermInd
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       assocId,        /* service user assoc identifier */
U8            assocIdType,    /* association identifier type */
SctStatus     status,         /* SCT SAP status */
SctCause      cause,          /* reason for assoc termination */
SctRtrvInfo   *rtrvInfo       /* retrieval information */
)                             
#else
PUBLIC S16 MgLiSctTermInd (pst, suId, assocId, assocIdType, 
                           status, cause, rtrvInfo)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       assocId;        /* service user assoc identifier */
U8            assocIdType;    /* association identifier type */
SctStatus     status;         /* SCT SAP status */
SctCause      cause;          /* reason for assoc termination */
SctRtrvInfo   *rtrvInfo;      /* retrieval information */
#endif
{
   MgAssocCb *assocCb = NULLP;         /* association control block */
   MgTptSrvSta     tptAlarm;           /* Alarm Information */
   S16       ret;                      /* return value */
   MgParId   parId;


   
   TRC3(MgLiSctTermInd)

#ifdef DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
          "MgLiSctTermInd(pst, suid(%d), assocId(%ld), assocIdType(%d), "
          "status(%d), cause(%d), rtrvInfo(%p)\n", suId, assocId, 
          assocIdType, status, cause, (void *)rtrvInfo));
#endif /* DEBUGP */

   UNUSED(pst);
   UNUSED(cause);
   UNUSED(rtrvInfo);


#if (ERRCLASS & ERRCLS_INT_PAR)

   /*
    * The following macro checks -
    *
    *    1) for the sanity of suId
    *    2) if the tsap state is BND_ENB
    *
    */

   MG_CHK_SUID(suId, NULLP, EMG132, MgLiSctTermInd,
                     LMG_EVENT_SCT_TERMIND);
   
#endif /* ERRCLASS & ERRCLS_INT_PAR */




   
   switch (assocIdType)
   {
      case SCT_ASSOCID_SU:
      {
         /*
          *   SctTermInd is received only once from SCTP layer expect
          *   for graceful shutdown case where its received TWICE -
          *   once with status as SCT_STATUS_SHUTDOWN and the second
          *   time with status as SCT_STATUS_SHUTDOWN_CMPLT.
          *   Therefore, if status is SCT_STATUS_SHUTDOWN, then ignore
          *   it and wait for SctTermInd with status SCT_STATUS_SHUTDOWN_CMPLT.
          */

         if (SCT_STATUS_SHUTDOWN == status)
            RETVALUE(ROK);


         /*
          * search for the association control block in the
          * endpoint CB's suAssocId based hash list of assoc CBs
          */

         ret = cmHashListFind(&(mgCb.tSAPLst[suId]->endpCb.assocCp),
                              (U8 *)&assocId, MG_ASSOCID_LEN,
                              MG_HASH_SEQNMB_DEF, (PTR *)&assocCb);


         if ((ret != ROK) || (assocCb == NULLP))
         {

#if (ERRCLASS & ERRCLS_DEBUG)
            MGLOGERROR(ERRCLS_DEBUG, EMG133, (ErrVal) assocCb,
                          "MgLiSctTermInd: Invalid suId/assocCb");
#endif /* ERRCLASS & ERRCLS_DEBUG */

            MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_TERMIND, LCM_CAUSE_INV_STATE,
                                 (suId), (parId));

            RETVALUE(RFAILED);

         }


         /*
          * If a valid peer is present, execute the
          * peer disconnection procedures.
          *
          * Set peer->assocCb to NULLP to prevent
          * SctTermReq from being called from
          *   mgPrcPeerDiscInd() -> mgDeletePeer() ->
          *   mgBringPeerToCfgStatus() -> SctTermReq()
          */

         if (assocCb->peer)
         {
            assocCb->peer->assocCb  = NULLP;

            /*
             *   Following is NOT to be called (its supposed to be
             *   called only from mgDeAllocPeerCb()) -
             *   assocCb->peer->assocCfg = NULLP;
             */

            mgPrcPeerDiscInd(assocCb->peer);
         }


         /*
          * The following function -
          *    a) de-allocates the assocition CB
          *    b) stops the timers
          */
#ifdef ZG
   if(((zgChkCRsetStatus()) == TRUE))
   {
      /* Send Del update to standby ..and do del mapping for active */
      zgRtUpd(ZG_CBTYPE_ASSOC,(Ptr)assocCb,CMPFTHA_UPDTYPE_SYNC,
          CMPFTHA_ACTN_DEL);
      zgUpdPeer();
      zgDelMapping(ZG_CBTYPE_ASSOC, (Ptr)assocCb);
   }
#endif /* ZG */

         mgDeAllocAssocCb(assocCb);



         /*
          * Generate an alarm indicating transport failure
          * should new alarm parameters be defined for SCTP? 
          *
          */

         /* Fill the alarm Information */

         tptAlarm.state = assocCb->assocState;

         mgGenStaInd (STTSAP, LCM_CATEGORY_INTERNAL, LMG_EVENT_TPTSRV,
                      LMG_CAUSE_TPT_FAILURE, LMG_ALARMINFO_SRVR,
                      (Ptr) &(tptAlarm), sizeof(MgTptSrvSta), 
                      LMG_ALARMINFO_INVSAPID);


         RETVALUE(ROK);
         break;

      }

      case SCT_ASSOCID_SP:

      /*
       * TermInd with spAssocId should NEVER come since SCTP 
       * does not generate TermInd with spAssocId
       *
       *   ----  fall through ----
       *
       */

      default:
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         MGLOGERROR(ERRCLS_DEBUG, EMG134, (ErrVal) assocCb,
                          "MgLiSctTermInd: Invalid assocId type");
#endif /* ERRCLASS & ERRCLS_DEBUG */

         RETVALUE(RFAILED);
      }
   } /* switch */



} /* end of MgLiSctTermInd */





/*
*
*       Fun:   MgLiSctTermCfm
*
*       Desc:  Confirms a local request for association termination
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  mp_li.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctTermCfm
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
SctResult     result,         /* result */
SctCause      cause           /* reason for assoc termination */
)
#else
PUBLIC S16 MgLiSctTermCfm (pst, suId, suAssocId, result, cause)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
SctResult     result;         /* result */
SctCause      cause;          /* reason for assoc termination */
#endif
{
   MgAssocCb *assocCb = NULLP;         /* association control block */
   S16       ret;                      /* return value */
   MgParId   parId;



   TRC3(MgLiSctTermCfm)

#ifdef DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
      "MgLiSctTermCfm(pst, suId(%d), suAssocId(%ld), result(%d), cause(%d))\n", 
      suId, suAssocId, result, cause));
#endif /* DEBUGP */

   UNUSED(pst);
   UNUSED(result);
   UNUSED(cause);




#if (ERRCLASS & ERRCLS_INT_PAR)

   /*
    * The following macro checks -
    *
    *    1) for the sanity of suId
    *    2) if the tsap state is BND_ENB
    *
    */

   MG_CHK_SUID(suId, NULLP, EMG135, MgLiSctTermCfm,
                     LMG_EVENT_SCT_TERMCFM);
   
#endif /* ERRCLASS & ERRCLS_INT_PAR */


   /*
    * search for the association control block in the
    * endpoint CB's suAssocId based hash list of assoc CBs
    */

   ret = cmHashListFind(&(mgCb.tSAPLst[suId]->endpCb.assocCp),
                        (U8 *)&suAssocId, MG_ASSOCID_LEN,
                        MG_HASH_SEQNMB_DEF, (PTR *)&assocCb);


   if ((ret != ROK) || (assocCb == NULLP))
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG136, (ErrVal) assocCb,
                    "MgLiSctTermCfm: Invalid suId/assocCb");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_TERMCFM, LCM_CAUSE_INV_STATE,
                           (suId), (parId));

      RETVALUE(RFAILED);

   }


   if (assocCb->peer)
   {
      /* Since this is a Term Cfm, reset peer->assocCb to NULL */
      assocCb->peer->assocCb = NULLP;

      /*
       *   If assoc state is WAIT_CFM, then this implies that an
       *   assoc req needs to be made to the peer
       */
      if (assocCb->assocState == LMG_ASSOC_STATE_WAIT_CFM)
      {
         MgAssocCb   *oldAssocCb;

         oldAssocCb = assocCb;

         if (ROK == mgAllocAssocCb((assocCb->peer)->ssap, (assocCb->peer),
                                   (MgAssocCb **)(&((assocCb->peer)->assocCb))))
         {
            (assocCb->peer)->state = LMG_PEER_STATE_CONNECT;

            mgAssocReq((assocCb->peer)->ssap, (assocCb->peer),
                       ((assocCb->peer)->assocCb));
#ifdef ZG
      /* send runtime update and do add mapping */
         ZG_INIT_RSETID_IN_MAPCB(&(assocCb->mapCb));
         zgAddMapping(ZG_CBTYPE_ASSOC, (Ptr)assocCb);
         zgRtUpd(ZG_CBTYPE_ASSOC, (Ptr)assocCb,
                 CMPFTHA_UPDTYPE_SYNC,CMPFTHA_ACTN_ADD);
         zgRtUpd(ZG_CBTYPE_PEER, (Ptr)(assocCb->peer),
                CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
         }

#ifdef ZG
         if(((zgChkCRsetStatus()) == TRUE))
         {
            /* Send Del update to standby ..and do del mapping for active */
            zgRtUpd(ZG_CBTYPE_ASSOC,(Ptr)oldAssocCb,CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_DEL);
            zgDelMapping(ZG_CBTYPE_ASSOC, (Ptr)oldAssocCb);
         }
#endif /* ZG */
         mgDeAllocAssocCb(oldAssocCb);

      }
      else
      {
         /*
          * The following function -
          *    a) de-allocates the assocition CB
          *    b) stops the timers
          */

#ifdef ZG
         if(((zgChkCRsetStatus()) == TRUE))
         {
            /* Send Del update to standby ..and do del mapping for active */
            zgRtUpd(ZG_CBTYPE_ASSOC,(Ptr)assocCb,CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_DEL);
            zgDelMapping(ZG_CBTYPE_ASSOC, (Ptr)assocCb);
         }
#endif /* ZG */
         mgDeAllocAssocCb(assocCb);
      }
   }
   else
   {
#ifdef ZG
         if(((zgChkCRsetStatus()) == TRUE))
         {
            /* Send Del update to standby ..and do del mapping for active */
            zgRtUpd(ZG_CBTYPE_ASSOC,(Ptr)assocCb,CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_DEL);
            zgDelMapping(ZG_CBTYPE_ASSOC, (Ptr)assocCb);
         }
#endif /* ZG */
      mgDeAllocAssocCb(assocCb);
   }


#ifdef ZG
   /* send run time update */
   zgUpdPeer();
#endif /* ZG */
   RETVALUE(ROK);


} /* end of MgLiSctTermCfm */





/*
*
*       Fun:   MgLiSctDatInd
*
*       Desc:  Indicates receipt of data from peer SCTP user
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  mp_li.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctDatInd
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
SctStrmId     strmId,         /* SCTP stream identifier */
SctDatIndType *indType,       /* data indication type */
U32           protId,         /* protocol ID */
Buffer        *mBuf           /* message buffer */
)
#else
PUBLIC S16 MgLiSctDatInd (pst, suId, suAssocId, strmId, indType, protId, mBuf)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
SctStrmId     strmId;         /* SCTP stream identifier */
SctDatIndType *indType;       /* data indication type */
U32           protId;         /* protocol ID */
Buffer        *mBuf;          /* message buffer */
#endif
{
   MgAssocCb *assocCb = NULLP;         /* association control block */
   S16       ret;                      /* return value */
   CmTptAddr tptAddr;                  /* primary dest addr */
   MgParId   parId;
   MgcoTptInfo mgcoTptInfo;         /* Pass Assoc Information in a structure */



   TRC3(MgLiSctDatInd)

#ifdef DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
          "MgLiSctDatInd(pst, suId(%d), suAssocId(%ld), strmId(%d), "
          "indType(%p), protId(%ld), mBuf(%p))\n", suId, suAssocId, strmId,
          (void *)indType, protId, (void *)mBuf));
#endif /* DEBUGP */

   UNUSED(pst);

   /* mg008.105: if configuration not done do not process message */
   if (mgCb.init.cfgDone != TRUE)
   {

      MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_DATIND, LCM_CAUSE_INV_STATE,
                           (suId), (parId));

      if (mBuf)
      {
         (Void) mgPutMsg(mBuf);
         mBuf = (Buffer *)NULLP;
      }

      RETVALUE(RFAILED);
   }





#if (ERRCLASS & ERRCLS_INT_PAR)

   /*
    * The following macro checks -
    *
    *    1) for the sanity of suId
    *    2) if the tsap state is BND_ENB
    *
    */

   MG_CHK_SUID(suId, NULLP, EMG137, MgLiSctDatInd,
                     LMG_EVENT_SCT_DATIND);
   
#endif /* ERRCLASS & ERRCLS_INT_PAR */




   /*
    * search for the association control block in the
    * endpoint CB's suAssocId based hash list of assoc CBs
    */

   ret = cmHashListFind(&(mgCb.tSAPLst[suId]->endpCb.assocCp),
                        (U8 *)&suAssocId, MG_ASSOCID_LEN,
                        MG_HASH_SEQNMB_DEF, (PTR *)&assocCb);


   if ((ret != ROK) || (assocCb == NULLP) ||
       (assocCb->assocState != LMG_ASSOC_STATE_ACTIVE))
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG138, (ErrVal) assocCb,
                    "MgLiSctDatInd: Invalid suId/assocCb");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_DATIND, LCM_CAUSE_INV_STATE,
                           (suId), (parId));

      RETVALUE(RFAILED);

   }




   /*
    *   check if the mBuf is actually a MEGACO msg. The data
    *   type can be either SCT_PEER_DAT or SCT_UNORDER_DAT (when
    *   the peer has set the unorder flag).
    *
    *    Should we indicate this unorder info in
    *          MgMgcoMsg.unorder to the user?
    */

   if (!((indType->type == SCT_PEER_DAT) ||
         (indType->type == SCT_UNORDER_DAT)))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG139, (ErrVal) indType->type,
                    "MgLiSctDatInd: Invalid indType->type");
#endif /* ERRCLASS & ERRCLS_INT_PAR */


      MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_DATIND, LCM_CAUSE_INV_PAR_VAL,
                           (suId), (parId));


      if (mBuf)
      {
         (Void) mgPutMsg(mBuf);
         mBuf = (Buffer *)NULLP;
      }

      RETVALUE(RFAILED);
   }




   /* SCTP may send NULL mBuf - check for this */

   if (mBuf == (Buffer *) NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG140, (ErrVal) indType->type,
                    "MgLiSctDatInd: NULLP mBuf");
#endif /* ERRCLASS & ERRCLS_INT_PAR */


      MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_DATIND, LCM_CAUSE_INV_PAR_VAL,
                           (suId), (parId));


      RETVALUE(RFAILED);
   }




   /* check if the protocol Id is that of MEGACO */



   if (protId != SCT_PROTID_H248)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG141, (ErrVal) protId,
                    "MgLiSctDatInd: Invalid protId");
#endif /* ERRCLASS & ERRCLS_INT_PAR */


      MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_DATIND, LCM_CAUSE_INV_PAR_VAL,
                           (suId), (parId));


      RETVALUE(RFAILED);

   }




#ifdef DEBUGP

   MGDBGP (DBGMASK_LI, (mgCb.init.prntBuf,
           "MgLiSctDatInd(post, suId(%d), suAssocId(%ld), "
           "strmId(%d), indType->type(%d), "
           "protId(%ld))\n",
           suId, suAssocId, strmId,
           indType->type, protId));


   if (mgCb.init.dbgMask & MG_DBGMASK_LI_MBUF)
      SPrntMsg (mBuf, 0, 0);


#ifdef GCP_ACC_TESTS
   /*
    * Put the SPrntMsg inside GCP_ACC_TESTS as this
    * printing is needed for acceptance tests
    */
   SPrntMsg(mBuf, 0, 0);
#endif /* GCP_ACC_TESTS */


#endif /* DEBUGP */





   /* Generate Trace Indication To Layer Manager if enabled */
   mgGenTrcInd(mgCb.tSAPLst[suId], MG_NONE, LMG_TRC_EVENT_MGCORX, NULLP, mBuf);


   /*
    *
    *        typedef struct mgTptCb
    *        {
    *            MgTptSrvr   *srvr;         // pointer to srvr
    *            MgAssocCb   *assoc;        // pointer to assoc
    *        } MgTptCb;
    * NOT needed anymore
    */



   /* copy the primary destination address as the source address */
   
   MG_FILL_TPTADDR_FRM_NETADDR(&tptAddr, &assocCb->assocCfg->priDstAddr);

   /* Copy the Trasport Inforamtion in a Structure to be passed to function */
   mgcoTptInfo.tptType   = LMG_TPT_SCTP;
   mgcoTptInfo.u.assocCb = assocCb;
   /* Process Transaction from peer */
   
   mgPrcMgcoTxnInd(&mgcoTptInfo, mgCb.tSAPLst[suId], NULLP, &tptAddr,
                   mBuf, NULLP, NULLP);



   RETVALUE(ROK);
} /* end of MgLiSctDatInd */





/*
*
*       Fun:   MgLiSctStaCfm
*
*       Desc:  Confirms a status report
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  mp_li.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctStaCfm
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
CmNetAddr     *dstNAddr,      /* destination network address */
SctResult     result,         /* result */
SctCause      cause,          /* cause */
SctStaInfo    *staInfo        /* status information */
)
#else
PUBLIC S16 MgLiSctStaCfm (pst, suId, suAssocId, dstNAddr,
                          result, cause, staInfo)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
CmNetAddr     *dstNAddr;      /* destination network address */
SctResult     result;         /* result */
SctCause      cause;          /* cause */
SctStaInfo    *staInfo;       /* status information */
#endif
{

#if (ERRCLASS & ERRCLS_INT_PAR)
   MgParId   parId;
#endif /* ERRCLASS & ERRCLS_INT_PAR */


   TRC3(MgLiSctStaCfm)

#ifdef DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
          "MgLiSctStaCfm(pst, suId(%d), suAssocId(%ld), dstNAddr(%p), "
          "result(%d), cause(%d), staInfo(%p))\n", suId, suAssocId, 
     (void *)dstNAddr, result, cause, (void *)staInfo));
#endif /* DEBUGP */

   UNUSED(pst);

#ifndef DEBUGP
   UNUSED(staInfo);
   UNUSED(cause);
   UNUSED(result);
   UNUSED(dstNAddr);
#endif




#if (ERRCLASS & ERRCLS_INT_PAR)

   /*
    * The following macro checks -
    *
    *    1) for the sanity of suId
    *    2) if the tsap state is BND_ENB
    *
    */

   MG_CHK_SUID(suId, NULLP, EMG142, MgLiSctStaCfm,
                     LMG_EVENT_SCT_STACFM);
   
#endif /* ERRCLASS & ERRCLS_INT_PAR */






   RETVALUE(ROK);
} /* end of MgLiSctStaCfm */





/*
*
*       Fun:   MgLiSctStaInd
*
*       Desc:  Indicates change of status of an SCTP association
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  mp_li.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctStaInd
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
UConnId       spAssocId,      /* service provider assoc identifier */
CmNetAddr     *dstNAddr,      /* destination network address */
SctStatus     status,         /* status */
SctCause      cause,          /* cause */
Buffer        *mBuf           /* message buffer */
)
#else
PUBLIC S16 MgLiSctStaInd (pst, suId, suAssocId, spAssocId, dstNAddr,
                          status, cause, mBuf)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
UConnId       spAssocId;      /* service provider assoc identifier */
CmNetAddr     *dstNAddr;      /* destination network address */
SctStatus     status;         /* status */
SctCause      cause;          /* cause */
Buffer        *mBuf;          /* message buffer */
#endif
{
   MgAssocCb *assocCb = NULLP;         /* association control block */
   MgAssocCfg *cfg    = NULLP;         /* association cfg struct */
   S16       ret;                      /* return value */
   CmTptAddr tptAddr;                  /* primary dest addr */
   MgParId   parId;
   MgcoTptInfo mgcoTptInfo;            /* Transport Information */



   TRC3(MgLiSctStaInd)

#ifdef DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
          "MgLiSctStaInd(pst, suId(%d), suAssocId(%ld), spAssocId(%ld), "
          "dstNAddr(%p), status(%d), cause(%d), mBuf(%p))\n", 
          suId, suAssocId, spAssocId, (void *)dstNAddr, 
     status, cause, (void *)mBuf));
#endif /* DEBUGP */


   UNUSED(pst);

#ifndef DEBUGP
   UNUSED(dstNAddr);
   /* it015.104 parameter spAssocId deleted from USED list as
      its being used now */
#endif




#if (ERRCLASS & ERRCLS_INT_PAR)

   /*
    * The following macro checks -
    *
    *    1) for the sanity of suId
    *    2) if the tsap state is BND_ENB
    *
    */

   MG_CHK_SUID(suId, NULLP, EMG143, MgLiSctStaInd,
                     LMG_EVENT_SCT_STAIND);
   
#endif /* ERRCLASS & ERRCLS_INT_PAR */



   /*
    * search for the association control block in the
    * endpoint CB's suAssocId based hash list of assoc CBs
    */

   ret = cmHashListFind(&(mgCb.tSAPLst[suId]->endpCb.assocCp),
                        (U8 *)&suAssocId, MG_ASSOCID_LEN,
                        MG_HASH_SEQNMB_DEF, (PTR *)&assocCb);


   if ((ret != ROK) || (assocCb == NULLP))
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG144, (ErrVal) assocCb,
                    "MgLiSctStaInd: Invalid suId/assocCb");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_STAIND, LCM_CAUSE_INV_STATE,
                           (suId), (parId));

      RETVALUE(RFAILED);

   }



   
   /*
    * EITHER assocCb->peer->assocCfg is valid (configured peer)
    * OR assocCb->assocCfg is valid (discovered peer)
    *
    */

   if ((assocCb->peer) && (assocCb->peer->assocCfg))
      cfg = assocCb->peer->assocCfg;
   else if (assocCb->assocCfg)
      cfg = assocCb->assocCfg;
   else
      RETVALUE(RFAILED);       /* this case should never happen */





   /*
    * Handle the status indication based on the value of status
    */

   switch(status)
   {
      /*
       * Indicates that the communication with the peer is now up;
       * INIT chunk and COOKIE chunk have been sucessfully exchanged
       * with the peer;
       */
      case SCT_STATUS_COMM_UP:
      {
         /*
          * update the association state to ACTIVE
          */

         assocCb->assocState = LMG_ASSOC_STATE_ACTIVE;


         if (assocCb->spAssocId != spAssocId)
         {
            RETVALUE(RFAILED);
         }



         /*
          * call the function to transmit queued transactions
          * on the MG side;
          * On the MG side, peer is gauranteed to be valid i.e.
          * assocCb->peer is NOT NULLP;
          */

#ifdef GCP_MG
         if (mgCb.genCfg.entType == LMG_ENT_GW)
            mgPrcPeerConCfm(assocCb->peer);
#endif /* GCP_MG */

#ifdef ZG
      /* Send Mod Update to Standby */
         zgRtUpd(ZG_CBTYPE_ASSOC,(Ptr)assocCb,CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_MOD);
#endif /* ZG */



         /*
          * If mBuf if present, it might be the service change
          * msg from the MG;
          * In that case we have to process that msg;
          */

#ifdef GCP_MGC
         if ((mgCb.genCfg.entType == LMG_ENT_GC) && (mBuf))
         {
            /* Generate Trace Indication To Layer Manager if enabled */

            mgGenTrcInd(mgCb.tSAPLst[suId], MG_NONE, LMG_TRC_EVENT_MGCORX, NULLP, mBuf);

            /* copy the primary destination address as the source address */
   
            MG_FILL_TPTADDR_FRM_NETADDR(&tptAddr, &assocCb->assocCfg->priDstAddr);
            /* Copy the Trasport Inforamtion in a Structure to be passed to function */
            mgcoTptInfo.tptType   = LMG_TPT_SCTP;
            mgcoTptInfo.u.assocCb = assocCb;

            mgPrcMgcoTxnInd(&mgcoTptInfo, mgCb.tSAPLst[suId], NULLP,
                            &tptAddr, mBuf, NULLP, NULLP);
         }
#endif /* GCP_MGC */


         break;
      }


      /*
       * Indicates that the communication with the peer has been lost;
       */
      case SCT_STATUS_COMM_LOST:
      {
         /*
          * update the association state to DOWN
          */

         assocCb->assocState = LMG_ASSOC_STATE_DOWN;


         /*
          * The following function -
          *    a) de-allocates the assocition CB
          *    b) stops the timers
          */

#ifdef ZG
   if(((zgChkCRsetStatus()) == TRUE))
   {
      /* Send Del update to standby ..and do del mapping for active */
      zgRtUpd(ZG_CBTYPE_ASSOC,(Ptr)assocCb,CMPFTHA_UPDTYPE_SYNC,
          CMPFTHA_ACTN_DEL);
      zgUpdPeer();
      zgDelMapping(ZG_CBTYPE_ASSOC, (Ptr)assocCb);
   }
#endif /* ZG */
         mgDeAllocAssocCb(assocCb);


         /*
          * If cause is available, use it to generate
          * the relevant alarm
          */

         if (cause == SCT_STATUS_SND_FAIL)
         {
            MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_SENDFAIL, LCM_CAUSE_UNKNOWN,
                                 (suId), (parId));

         }
         else
         {
            MG_GEN_SCTP_LI_ALARM(LMG_EVENT_SCT_COMMDOWN, LCM_CAUSE_UNKNOWN,
                                 (suId), (parId));

         }

         break;
      }


      /*
       * Indicates that one of the addresses used to communicate
       * with the peer (dstNAddr) is now NOT usable;
       * GCP should update the primary destination address
       * from the remaining addresses available to it;
       */
      case SCT_STATUS_NET_DOWN:
      {
         U8 i,j;

         /*
          * Two possibilities arise -
          *
          *   1) The dstNAddr in the Status Ind is the
          *      not the primary destination address.
          *      Just remove dstNAddr from the destination
          *      address list.
          *
          *   2) The dstNAddr in the Status Ind is the
          *      primary destination address. Set another
          *      address as the primary destination address.
          *      In addition remove the dstNAddr from the
          *      destination address list just like above.
          *
          */


         for (i=0; i < cfg->dstAddrLst.nmb; ++i)
         {
            /* If the i-th address is the dstNAddr */
            if (cmMemcmp((U8 *)&(cfg->dstAddrLst.nAddr[i]),
                     (U8 *)dstNAddr, sizeof(CmNetAddr)) == 0)
            {
               /* If the dstNAddr is the pri-dest-address */
               if (cmMemcmp((U8 *)&(cfg->priDstAddr),
                     (U8 *)dstNAddr, sizeof(CmNetAddr)) == 0)
               {
                  /*
                   * if priDstAddr is the last address in the list
                   * assign the first address in the list as the
                   * new priDstAddr
                   *
                   * else assign the next address in the list as the
                   * new priDstAddr
                   */
                  if (i == (cfg->dstAddrLst.nmb - 1))
                     cfg->priDstAddr = cfg->dstAddrLst.nAddr[0];
                  else
                     cfg->priDstAddr = cfg->dstAddrLst.nAddr[i + 1];


                  /*
                   * call the SCTP primitive to set the priDstAddr
                   */
                  MgLiSctSetPriReq (&(mgCb.tSAPLst[suId]->spPst),
                                    mgCb.tSAPLst[suId]->tsapCfg.spId,
                                    assocCb->spAssocId, &(cfg->priDstAddr));

               }   /* end of if priDstAddr == dstNAddr */


               /*
                * move all the higher addresses in the list
                * down by one position starting from the location
                * of the dstNAddr
                *
                * [ if dstNAddr is the last address in the list ]
                * clear the last address in the list
                *
                */

               for (j=i; j < cfg->dstAddrLst.nmb; ++j)
               {
                  if (j == (cfg->dstAddrLst.nmb - 1))
                     cmMemset((U8 *)&(cfg->dstAddrLst.nAddr[j]),
                                      0, sizeof(CmNetAddr));
                  else
                     cfg->dstAddrLst.nAddr[j] =
                               cfg->dstAddrLst.nAddr[j + 1];
               }   /* end of for j=i ... loop */

               cfg->dstAddrLst.nmb--;

               break;   /* break from the upper for loop */

            }   /* end of if i-th addr == dstNAddr */
         }   /* end of for i=0 ... loop */

#ifdef ZG
      /* Send Mod Update to Standby */
         zgRtUpd(ZG_CBTYPE_ASSOC,(Ptr)assocCb,CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_MOD);
#endif /* ZG */

         break;   /* case NET_DOWN */
      }


      /*
       * Indicates that one of the addresses used to communicate
       * with the peer (dstNAddr) is now available again;
       * GCP should update its address list
       */
      case SCT_STATUS_NET_UP:
      {
         /*
          * Update the address if there is space for it
          */
         if ((cfg->dstAddrLst.nmb + 1) < SCT_MAX_NET_ADDRS)
         {
            cfg->dstAddrLst.nAddr[cfg->dstAddrLst.nmb] = *dstNAddr;
            cfg->dstAddrLst.nmb++;

#ifdef ZG
      /* Send Mod Update to Standby */
         zgRtUpd(ZG_CBTYPE_ASSOC,(Ptr)assocCb,CMPFTHA_UPDTYPE_SYNC,
                 CMPFTHA_ACTN_MOD);
#endif /* ZG */
         }
         else
         {
            RETVALUE(RFAILED);
         }

         break;
      }

      default:
      {
         break;
      }
   }


#ifdef ZG
   /* send run time update */
   zgUpdPeer();
#endif /* ZG */




   RETVALUE(ROK);
} /* end of MgLiSctStaInd */





/*
*
*       Fun:   MgLiSctFlcInd
*
*       Desc:  Indicates change of flow control status
*
*       Ret:   Failure:    RFAILED
*
*              Success:    ROK
*
*       Notes: <none>
*
*       File:  mp_li.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSctFlcInd
(
Pst        *pst,              /* post structure */
SuId       suId,              /* service user SAP identifier */
UConnId    suAssocId,         /* service user association ID */
Reason     reason             /* reason for flow control indication */
)
#else
PUBLIC S16 MgLiSctFlcInd (pst, suId, suAssocId, reason)
Pst        *pst;              /* post structure */
SuId       suId;              /* service user SAP identifier */
UConnId    suAssocId;         /* service user association ID */        
Reason     reason;            /* reason for flow control indication */ 
#endif
{

#if (ERRCLASS & ERRCLS_INT_PAR)
   MgParId   parId;
#endif /* ERRCLASS & ERRCLS_INT_PAR */


   TRC3(MgLiSctFlcInd)

#ifdef DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
          "MgLiSctFlcInd(pst, suId(%d), suAssocId(%ld), reason(%d))\n",
          suId, suAssocId, reason));
#endif /* DEBUGP */

   UNUSED(pst);




#if (ERRCLASS & ERRCLS_INT_PAR)

   /*
    * The following macro checks -
    *
    * 1) for the sanity of suId
    * 2) if the tsap state is BND_ENB
    *
    */

   MG_CHK_SUID(suId, NULLP, EMG145, MgLiSctFlcInd,
                     LMG_EVENT_SCT_FLCIND);
   
#endif /* ERRCLASS & ERRCLS_INT_PAR */




   /*
    * Generate Flow Control indication to the service user
    */

   mgGenUserStaInd(NULLP, NULLP,  MGT_STATUS_FLOW, (Ptr) &reason);


   /*
    * Basically GCP is not doing anything for Flow control
    * since the re-transmission algorithm should take care
    * of this implicitly courtesy the exponential backoff
    */

   switch (reason)
   {
      case SCT_FLC_DROP:
      {
         mgCb.tSAPLst[suId]->resCong = TRUE;

         break;
      }

      case SCT_FLC_START:       /* fall through */
      case SCT_FLC_ACTIVE:
      {
         break;
      }

      case SCT_FLC_STOP:        /* fall through */
      case SCT_FLC_INACTIVE:
      {
         mgCb.tSAPLst[suId]->resCong = FALSE;

         break;
      }
   }




   RETVALUE(ROK);
} /* end of MgLiSctFlcInd */





/*
 *
 *       Fun:   MgLiSctSetPriCfm
 *
 *       Desc:  Confirms a request for setting the primary destination address
 *
 *       Ret:   Failure:
 *
 *              Success:
 *
 *       Notes: <none>
 *
 *       File:  mp_li.c
 *
 */

#ifdef ANSI
PUBLIC S16 MgLiSctSetPriCfm
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
SctResult     result,         /* result */
SctCause      cause           /* cause */
)
#else
PUBLIC S16 MgLiSctSetPriCfm (pst, suId, suAssocId, result, cause)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
SctResult     result;         /* result */
SctCause      cause;          /* cause */
#endif
{
   TRC3(MgLiSctSetPriCfm)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suAssocId);
   UNUSED(result);
   UNUSED(cause);

   RETVALUE(ROK);
} /* end of MgLiSctSetPriCfm */





/*
 *
 *       Fun:   MgLiSctHBeatCfm
 *
 *       Desc:  Confirms a heartbeat request
 *
 *       Ret:   Failure:
 *
 *              Success:
 *
 *       Notes: <none>
 *
 *       File:  mp_li.c
 *
 */

#ifdef ANSI
PUBLIC S16 MgLiSctHBeatCfm
(
Pst           *pst,           /* post structure */
SuId          suId,           /* service user SAP identifier */
UConnId       suAssocId,      /* service user assoc identifier */
CmNetAddr     *dstNAddr,      /* destination net address */
SctStatus     status,         /* status */
SctResult     result,         /* result */
SctCause      cause           /* cause */
)
#else
PUBLIC S16 MgLiSctHBeatCfm (pst, suId, suAssocId, dstNAddr, status, result, cause)
Pst           *pst;           /* post structure */
SuId          suId;           /* service user SAP identifier */
UConnId       suAssocId;      /* service user assoc identifier */
CmNetAddr     *dstNAddr;      /* destination net address */
SctStatus     status;         /* status */
SctResult     result;         /* result */
SctCause      cause;          /* cause */
#endif
{
   TRC3(MgLiSctHBeatCfm)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suAssocId);
   UNUSED(result);
   UNUSED(cause);

   RETVALUE(ROK);
} /* end of MgLiSctHBeatCfm */




#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3

/* ------------------------------------------------------------------*
 * Interface Functions for Lower MTP3 Interface                      *
 * ------------------------------------------------------------------*/

/*
*
*       Fun:   MgLiSntBndCfm
*
*       Desc:  Confirms a bind request.
*
*       Ret:   Failure:     RFAILED
*
*              Success:     ROK
*
*       Notes: <none>
*
*       File:  mp_li.c
*
*/

#ifdef ANSI
PUBLIC S16 MgLiSntBndCfm
(
Pst         *pst,             /* post structure */
SuId        suId,             /* service user SAP identifier */
U8          result            /* bind result */
)
#else
PUBLIC S16 MgLiSntBndCfm(pst, suId, result)
Pst         *pst;             /* post structure */
SuId        suId;             /* service user SAP identifier */
U8          result;           /* bind result */
#endif
{
   U16             event;              /* Event */
   U16             cause;              /* Cause */
   MgTSAPCb        *tsap;              /* TSAP Control Block */
   MgParId         parId;



   TRC3(MgLiSntBndCfm)

#ifdef DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
      "MgLiSntBndCfm(pst, suId(%d), status(%d))\n", suId, result));
#endif /* DEBUGP */

   UNUSED(pst);


   if (mgCb.init.cfgDone != TRUE)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG146, (ErrVal) suId,
                 "MgLiSntBndCfm: General configuration not done");
#endif /* ERRCLASS & ERRCLS_INT_PAR */

      MG_GEN_MTP_LI_ALARM(LMG_EVENT_SNT_BNDCFM, LCM_CAUSE_INV_STATE,
                           LMG_ALARMINFO_INVSAPID, (parId));

      RETVALUE(RFAILED);
   }

#ifdef ZG
   if((zgChkCRsetStatus()) == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG147, (ErrVal) ERRZERO ,
         "[MGCP] MgLiSntBndCfm: BndCfm rcved in Invalid resource state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      MG_GEN_MTP_LI_ALARM(LMG_EVENT_SNT_BNDCFM, LCM_CAUSE_PROT_NOT_ACTIVE,
                           LMG_ALARMINFO_INVSAPID, (parId));

      RETVALUE(RFAILED);
   }
#endif /* ZG */


   /*
    *
    * Check if suId is valid; if tsap has been allocated
    * for this suId;
    *
    */

   /*mg002.105: Removed compilation warning*/
   if ((suId < 0)|| (suId >= (SuId)mgCb.genCfg.maxTSaps) ||
       (mgCb.tSAPLst[suId] == NULLP))
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_INT_PAR, EMG148, (ErrVal) suId,
                 "[MGCP] MgLiSntBndCfm: Invalid suId");
#endif /* ERRCLASS & ERRCLS_DEBUG */


      /*
       *
       * Raise an alarm - invalid suId received
       *
       */

      MG_GEN_MTP_LI_ALARM(LMG_EVENT_SNT_BNDCFM, LCM_CAUSE_INV_SAP,
                           LMG_ALARMINFO_INVSAPID, (parId));

      RETVALUE(RFAILED);
   }



   /*
    * mgCb now has a list of TSAPs
    */

   tsap = mgCb.tSAPLst[suId];


   /* Check tsap state */
   switch (tsap->state)
   {
      case LMG_SAP_WAIT_BNDENB:
      {
         /*
          *
          * Stop Bind timer; validate result;
          * if Bind result is OK, change tsap state to BND_ENB;
          *
          */

         mgStopTmr (MG_BNDREQ_TMR, (PTR)tsap, &(tsap->bndTmr));

         tsap->bndRetxCnt = 0;
          
         if (result == CM_BND_OK)
         {
            tsap->state = LMG_SAP_BND_ENB;
            event = LCM_EVENT_BND_OK;
            cause = LMG_CAUSE_SAP_BNDENB;

            /*
             * Now This TSAP is UP so check status of all point code 
             * and send status request if they are Offline
             */
             mgMtpStsSync(tsap);

         }
         else
         {
            tsap->state  = LMG_SAP_UBND_DIS;
            event        = LCM_EVENT_BND_FAIL;
            cause        = LMG_CAUSE_UNKNOWN;
         }
#ifdef ZG
         /* send run time update for tsap */
         zgRtUpd(ZG_CBTYPE_TSAP, (Ptr)tsap, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZG */
      }

      break;

     default:
        event = LMG_EVENT_SNT_BNDCFM;
        cause = LCM_CAUSE_INV_STATE;
        break;
   }

   MG_GEN_MTP_LI_ALARM(event, cause,
                        (suId), (parId));
#ifdef ZG
   /* send update message to stndby */
   zgUpdPeer();
#endif /* ZG */


   RETVALUE(ROK);

} /* end of MgLiSntBndCfm */


/*
*       Fun:   MgLiSntStaInd
*
*       Desc:  Indiacates Point Code Status Change at MTP3 Level 
*
*       Ret:   ROK   - ok
*
*
*       File:  mp_li.c
*
*/
#ifdef ANSI
PUBLIC S16 MgLiSntStaInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* service user id */
Dpc apc,                        /* affected point code */
Status status,                  /* mtp-3 status */
Priority prior                  /* priority */
)
#else
PUBLIC S16 MgLiSntStaInd(pst, suId, apc, status, prior)
Pst *pst;                       /* post structure */
SuId suId;                      /* service user id */
Dpc apc;                        /* affected point code */
Status status;                  /* mtp-3 status */
Priority prior;                 /* priority */
#endif
{
   MgTSAPCb *tSap = NULLP;               /* TSAP Control Block */
   MgPeerCb *peerCb = NULLP;       /* Peer Cb Pointer */              
   S16      ret;                    
   MgParId  parId;
  
   TRC3(MgLiSntStaInd)
   UNUSED(pst);

#ifdef ZG
   if((zgChkCRsetStatus()) == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG149, (ErrVal) ERRZERO ,
         "[MGCP] MgLiSntStaInd: StaInd rcved in Invalid resource state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      MG_GEN_MTP_LI_ALARM(LMG_EVENT_SNT_STAIND, LCM_CAUSE_PROT_NOT_ACTIVE,
                           LMG_ALARMINFO_INVSAPID, (parId));

      RETVALUE(RFAILED);
   }
#endif /* ZG */



   
#ifdef DEBUGP   

   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
      "MgLiSntStaInd(pst, suId (%d), apc (%ld), status (%d), priority (%d))\n",
      suId, apc, status, prior));
#endif   /* DEBUGP */   

   UNUSED(pst);

#if (ERRCLASS & ERRCLS_INT_PAR)

   /*
    * The following macro checks -
    *
    * 1) for the sanity of suId
    * 2) if the tsap state is BND_ENB
    *
    */

   MG_CHK_SUID(suId, NULLP, EMG150, MgLiSntStaInd,
                     LMG_EVENT_SNT_STAIND);
   
#endif /* ERRCLASS & ERRCLS_INT_PAR */

/* Find the TSAP from SuId */

   tSap = mgCb.tSAPLst[suId];

   /* 
    * Check if state is RSTBEG or RSTEND then this shall apply 
    * for whole tSap so handle it before any other status
    */
    
    if( status == SN_RSTBEG)
    {
      mgHndlRstBeg(tSap);
      RETVALUE(ROK);
    }
    if((status == SN_RSTEND) && (tSap->mtpRstStart == TRUE))
    {
      mgHndlRstEnd(tSap);
      RETVALUE(ROK);
    }

   /* 
    * Find the Peers which are using this point code 
    * At MG side Multiple VMG may be using a single DPC since
    * it may happen that all virtual MG's may configured with  
    * same MGC as their controlling peer so all such Peer
    * MGC shall have multiple entry for single DPC in
    * DPC->peerCb Hash List 
    */
   

#ifdef GCP_MG
   if(LMG_ENT_GW == mgCb.genCfg.entType)
      {
         U32   i=0;  /* index to hash table entry */     
      
         /*mg002.105: Removed compilation warning*/
         while( ROK == cmHashListFind(&(tSap->mgcoMtpHlCp),(U8 *)&apc, 
             MG_DPC_LEN, (U16)(MG_HASH_SEQNMB_DEF + i), (PTR *)&peerCb))
         {
            /* Point the index to next peer */
             i++;
             /* Check for NULL Peer */
             if(peerCb == NULL) 
                continue;  /* Search for next Peer */
    
         /* We have found DPC  in Hash List */

           switch (status)
           {
              /* Pause and Remote User Unavailable are almost identical,
               * a paused route will be resumed. A RUU route will not be,
               * but may automagically reappear, so skip the pause logic.
               */
              case SN_RMTUSRUNAV:
              case SN_PAUSE:
                    mgHndlPause(peerCb);
                 break;

              case SN_RESUME:
                    mgHndlResume(peerCb);
                 break;

              case SN_STPCONG:
              case SN_CONG:
                 mgHndlCong(peerCb, prior);
                 break;


              default:

#if (ERRCLASS & ERRCLS_INT_PAR)      
               MGLOGERROR(ERRCLS_INT_PAR, EMG151, (ErrVal)status, 
               "MgLiSntStaInd() invalid  mtp-3 status");
                    
#endif /* ERRCLASS & ERRCLS_INT_PAR */         
        
               MG_GEN_MTP_LI_ALARM(LMG_EVENT_SNT_STAIND, LCM_CAUSE_OUT_OF_RANGE,  
                            (suId), (parId) );                                    
               break;                                                             
           } /* Switch */                                                         
         } /* while */                                                            
         if(i == 0) /* We didnot find any peer matching this Point Code */
         {

#if (ERRCLASS & ERRCLS_DEBUG)
            /* MGLOGERROR(ERRCLS_DEBUG, EMG152, (ErrVal) peerCb,
                  "MgLiSntStaInd: Invalid suId/peerCb"); */
#endif /* ERRCLASS & ERRCLS_DEBUG */

           /* MG_GEN_MTP_LI_ALARM(LMG_EVENT_SNT_STAIND, LCM_CAUSE_INV_STATE,
                  (suId), (parId));*/

            RETVALUE(ROK);

         }


      }                                                                           
#endif /* GCP_MG */                                                               

#ifdef   GCP_MGC      
   if (LMG_ENT_GC == mgCb.genCfg.entType) 
   {
                                                                                  
    /* 
    *  At MGC Side only one peer should be there for one DPC so 
    * search once and find peerCb
    */                                                                            
                                                                                  
   ret = cmHashListFind(&(tSap->mgcoMtpHlCp),                                     
                        (U8 *)&apc, MG_DPC_LEN,                                   
                        MG_HASH_SEQNMB_DEF, (PTR *)&peerCb);                     
                                                                                 
                                                                                  
   if ((ret != ROK) || (peerCb == NULLP) )  
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      /* MGLOGERROR(ERRCLS_DEBUG, EMG153, (ErrVal) peerCb,
                    "MgLiSntStaInd: Invalid suId/peerCb");*/
#endif   /* ERRCLASS & ERRCLS_DEBUG */

     /* MG_GEN_MTP_LI_ALARM(LMG_EVENT_SNT_STAIND, LCM_CAUSE_INV_STATE,
                           (suId), (parId));*/

      RETVALUE(ROK); 

   }

   /* We have found DPC  in Hash List */
   
   switch (status)
   {
      /* Pause and Remote User Unavailable are almost identical,
       * a paused point code  will be resumed. A RUU route will not be,
       * but may automagically reappear, so skip the pause logic.
       */
      case SN_RMTUSRUNAV:
      case SN_PAUSE:
         mgHndlPause(peerCb);
         break;

      case SN_RESUME:
         mgHndlResume(peerCb);
         break;

      case SN_STPCONG:
      case SN_CONG:
         mgHndlCong(peerCb, prior);
         break;

      default:

#if (ERRCLASS & ERRCLS_INT_PAR)      
         MGLOGERROR(ERRCLS_INT_PAR, EMG154, (ErrVal) status,
               "MgLiSntStaInd() invalid  mtp-3 status");
#endif /* ERRCLASS & ERRCLS_INT_PAR */         

         MG_GEN_MTP_LI_ALARM(LMG_EVENT_SNT_STAIND, LCM_CAUSE_OUT_OF_RANGE, 
               (suId), (parId) );
         break;
   }
   }
#endif   /* GCP_MGC */   
   
#ifdef ZG
   /* send update message to stndby */
   zgUpdPeer();
#endif /* ZG */
   RETVALUE (ROK);
} /* MgLiSntStaInd */

/*
*       Fun:   MgLiSntStaCfm
*
*       Desc:  Status confirmation
*
*       Ret:   ROK   - ok
*
*
*       File:  mp_li.c
*
*/
#ifdef ANSI
PUBLIC S16 MgLiSntStaCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* service user id */
Dpc  dpc,                       /* destination point code */
Status status,                  /* mtp-3 status */
U8 congLevel                    /* congestion level */
)
#else
PUBLIC S16 MgLiSntStaCfm(pst, suId, dpc, status, congLevel)
Pst *pst;                       /* post structure */
SuId suId;                      /* service user id */
Dpc dpc;                        /* affected point code */
Status status;                  /* mtp-3 status */
U8 congLevel;                   /* congestion level */
#endif
{
   MgTSAPCb *tSap; /* network SAP */
   MgPeerCb *peerCb; /* Peer Control Block */
#if (defined(ZG) || (ERRCLASS & ERRCLS_INT_PAR))
   MgParId    parId; /* Mg Par Id */
#endif /* ZG */
   S16       ret; /* Return Value */

   TRC3(MgLiSntStaCfm)
   UNUSED(pst);

#ifdef ZG
   if((zgChkCRsetStatus()) == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG155, (ErrVal) ERRZERO ,
         "[MGCP] MgLiSntStaCfm: StaCfm rcved in Invalid resource state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      MG_GEN_MTP_LI_ALARM(LMG_EVENT_SNT_STACFM, LCM_CAUSE_PROT_NOT_ACTIVE,
                           LMG_ALARMINFO_INVSAPID, (parId));

      RETVALUE(RFAILED);
   }
#endif /* ZG */



#ifdef DEBUGP   

   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
      "MgLiSntStaCfm(pst, suId (%d), dpc (%ld), status (%d), congLevel (%d))\n",
      suId, dpc, status, congLevel));
#endif   /* DEBUGP */   

   UNUSED(pst);

#if (ERRCLASS & ERRCLS_INT_PAR)

   /*
    * The following macro checks -
   
    * 1) for the sanity of suId
    * 2) if the tsap state is BND_ENB
    *
    */

   MG_CHK_SUID(suId, NULLP, EMG156, MgLiSntStaInd,
                     LMG_EVENT_SNT_STACFM);
   
#endif /* ERRCLASS & ERRCLS_INT_PAR */

/* Find the TSAP from SuId */

   tSap = mgCb.tSAPLst[suId];


   /* 
    * Find the Peers which are using this point code 
    * At MG side Multiple VMG may be using a single DPC since
    * it may happen that all virtual MG's may configured with  
    * same MGC as their controlling peer so all such Peer
    * MGC shall have multiple entry for single DPC in
    * DPC->peerCb Hash List */
   
#ifdef GCP_MG
   if(LMG_ENT_GW == mgCb.genCfg.entType)
      {
         U32   i = 0;  /* index to hash table entry */     
      
         /*mg002.105: Removed compilation warning*/
         while( ROK == cmHashListFind(&(tSap->mgcoMtpHlCp),(U8 *)&dpc, 
             MG_DPC_LEN, (U16)(MG_HASH_SEQNMB_DEF + i), (PTR *)&peerCb))
         {
            /* Point the index to next peer */
             i++;
             /* Check for NULL Peer */
             if(peerCb == NULL) 
                continue;  /* Search for next Peer */
             
             /* route came up or route came up and congested */
             switch (status)
             {
                case SN_RESUME:
                     mgHndlResume(peerCb);
                     break;

                case SN_CONG:
                
                /* 
                 * if Congestion Status is received then Point Code has to 
                 *  be ONLINE since no congestion can be there when point code
                 * is Offline so do resume handling if point code is offline 
                 */
                     if (!(peerCb->mgcoMtpCb.status & SP_ONLINE))
                        mgHndlResume(peerCb); 

                     if ((peerCb->mgcoMtpCb.status & SP_CONG) && 
                             (peerCb->mgcoMtpCb.congLvl != congLevel))

                         mgHndlCong(peerCb, congLevel);
                     break;

                default:
                     break;
                   }
         } /* while */
      } /* layer is MG */
#endif /* GCP_MG */      

#ifdef   GCP_MGC
   /* Entity is Working as MGC */      
   if (LMG_ENT_GC == mgCb.genCfg.entType)
   {

 /* Since at MGC side there shall be only one entry for the peer */
      ret = cmHashListFind(&(tSap->mgcoMtpHlCp),(U8 *)&dpc, 
                 MG_DPC_LEN, MG_HASH_SEQNMB_DEF , (PTR *)&peerCb);
         
         if ((ret != ROK) || (peerCb == NULLP))
         {
#if  (ERRCLASS & ERRCLS_DEBUG)
            MGLOGERROR(ERRCLS_DEBUG, EMG157, (ErrVal) dpc,
                       "MgLiSntStaInd: Invalid Point Code");
#endif /* ERRCLASS & ERRCLS_DEBUG */

                          RETVALUE(RFAILED);
         }
          /* route came up or route came up and congested */
             switch (status)
             {
                case SN_RESUME:
                
                /* 
                 * if Congestion Status is received then Point Code has to 
                 *  be ONLINE since no congestion can be there when point code
                 * is Offline so do resume handling if point code is offline 
                 */

                     mgHndlResume(peerCb);
                     break;

                case SN_CONG:
                     if (!(peerCb->mgcoMtpCb.status & SP_ONLINE))
                        mgHndlResume(peerCb); 

                     if ((peerCb->mgcoMtpCb.status & SP_CONG) && 
                             (peerCb->mgcoMtpCb.congLvl != congLevel))

                         mgHndlCong(peerCb, congLevel);
                     break;

                default:
                     break;
             }

   }
#endif /* GCP_MGC */     
              
#ifdef ZG
   /* send update message to stndby */
   zgUpdPeer();
#endif /* ZG */
   RETVALUE(ROK);
} /* end of MgLiSntStaCfm */

/*
 *
 *       Fun:   MgLiSntUDatInd
 *
 *       Desc:  Data Indication from the MTP3 layer.
 *
 *       Ret:   ROK   - ok
 *
 *       Notes :  None
 *       
 *       File:  mp_li.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgLiSntUDatInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Sevice user id */
Dpc opc,                        /* Originating point code*/
Dpc dpc,                        /* Destination point code */
SrvInfo srvInfo,                /* service information */
LnkSel lnkSel,                  /* link selector */
Buffer *mBuf                    /* data */
)
#else
PUBLIC S16 MgLiSntUDatInd(pst, suId, opc, dpc, srvInfo, lnkSel, mBuf)
Pst *pst;                       /* post structure */
SuId suId;                      /* Sevice user id */
Dpc opc;                        /* Origination point code */
Dpc dpc;                        /* Destination point code */
SrvInfo srvInfo;                /* service information */
LnkSel lnkSel;                  /* link selector */ 
Buffer *mBuf;                   /* data */
#endif
{
   S16 ret;                     /* return flag */
   MgPeerCb *mtpPeer = NULL;       /* peerCb */
   MgTSAPCb *tSap = NULL;        /* Tsap Cb */
   MgcoTptInfo mgcoTptInfo;      /* Transport Information */
   MgParId       parId;

   TRC3(MgLiSntUDatInd)

#ifdef   DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
       "MgLiSntUDatInd(pst, suId (%d), opc (%ld), dpc (%ld), srvinfo (%d), lnksel (%d)\n"
       , suId, opc, dpc, srvInfo, lnkSel));
#endif   /* DEBUGP */
   UNUSED(pst);

#ifdef ZG
   if((zgChkCRsetStatus()) == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG158, (ErrVal) ERRZERO ,
         "[MGCP] MgLiSntUDatInd: UDatInd rcved in Invalid resource state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */

      MG_GEN_MTP_LI_ALARM(LMG_EVENT_SNT_UDATIND, LCM_CAUSE_PROT_NOT_ACTIVE,
                           LMG_ALARMINFO_INVSAPID, (parId));

      RETVALUE(RFAILED);
   }
#endif /* ZG */


   /* mg008.105: if configuration not done do not process message */
   if (mgCb.init.cfgDone != TRUE)
   {
      MG_GEN_MTP_LI_ALARM(LMG_EVENT_SNT_UDATIND, LCM_CAUSE_INV_STATE,
                           LMG_ALARMINFO_INVSAPID, (parId));
      if (mBuf)
      {
         (Void) mgPutMsg(mBuf);
         mBuf = (Buffer *)NULLP;
      }
      RETVALUE(RFAILED);
   }


#if (ERRCLASS & ERRCLS_INT_PAR)

   /*
    * The following macro checks -
   
    * 1) for the sanity of suId
    * 2) if the tsap state is BND_ENB
    *
    */

   MG_CHK_SUID(suId, NULLP, EMG159, MgLiSntStaInd,
                     LMG_EVENT_SNT_UDATIND);
   
#endif /* ERRCLASS & ERRCLS_INT_PAR */

/* Find the TSAP from SuId */

   tSap = mgCb.tSAPLst[suId];

/* Validate the SrvInfo field as it is stored in our Tsap */
   if ( tSap->sInfo != srvInfo)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG160, (ErrVal) srvInfo,
                    "MgLiSntUDatInd: Invalid srvInfo");
#endif /* ERRCLASS & ERRCLS_INT_PAR */


      MG_GEN_MTP_LI_ALARM(LMG_EVENT_SCT_DATIND, LCM_CAUSE_INV_PAR_VAL,
                           (suId), (parId));


      if (mBuf)
      {
         (Void) mgPutMsg(mBuf);
         mBuf = (Buffer *)NULLP;
      }

      RETVALUE(RFAILED);
   }     
   
   /* MTP3 may send NULL mBuf - check for this */

   if (mBuf == (Buffer *) NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG161, (ErrVal )dpc,
                    "MgLiSctDatInd: NULLP mBuf");
#endif /* ERRCLASS & ERRCLS_INT_PAR */


      MG_GEN_MTP_LI_ALARM(LMG_EVENT_SNT_UDATIND, LCM_CAUSE_INV_PAR_VAL,
                           (suId), (parId));


      RETVALUE(RFAILED);
   }


#ifdef DEBUGP
   MGDBGP(DBGMASK_LI, (mgCb.init.prntBuf, 
          "MgLiSntUDatInd(pst, suId (%d), opc (%ld), dpc (%ld),srvinfo (%d), lnksel (%d)\n" 
          , suId, opc, dpc, srvInfo, lnkSel));


   if (mgCb.init.dbgMask & MG_DBGMASK_LI_MBUF)
      SPrntMsg (mBuf, 0, 0);


#ifdef GCP_ACC_TESTS
   /*
    * Put the SPrntMsg inside GCP_ACC_TESTS as this
    * printing is needed for acceptance tests
    */
   SPrntMsg(mBuf, 0, 0);
#endif /* GCP_ACC_TESTS */

#endif /* DEBUGP */

   /* Generate Trace Indication To Layer Manager if enabled */
   mgGenTrcInd(mgCb.tSAPLst[suId], MG_NONE, LMG_TRC_EVENT_MGCORX, NULLP, mBuf);



  /* Check with SS7 if any decoding is required or not */

  /* 
   * Now Search the DPC Hash List if GCP is MGC then we may not find any peer
   *  then assume it is discoverd Peer case
   *  if we are gateway then peer must exist and calling address(dpc) must
   *  match with origination point code stored in our SSAP to correctly identify
   *  a peer 
   */

#ifdef GCP_MG
   if (LMG_ENT_GW == mgCb.genCfg.entType)
      {
         U32   i = 0;        /* index to hash table entry */     
         Bool  peerFound = FALSE;        
      
         /*mg002.105: Removed compilation warning*/
         while( ROK == cmHashListFind(&(tSap->mgcoMtpHlCp),(U8 *)&opc, 
            MG_DPC_LEN, (U16)(MG_HASH_SEQNMB_DEF + i), (PTR *)&mtpPeer))
         {
            /* Point the index to next peer */
             i++;
             /* Check for NULL Peer */
             if(mtpPeer == NULL) 
                continue;  /* Search for next Peer */
                /* 
                 * check this peer->ssap is having valid self Point code 
                 * and this point code is same as dpc then we found the peer
                 * come out from while loop
                 */
                
             if ((mtpPeer->ssap->ssapCfg.userInfo.selfPc.pres == PRSNT_NODEF) &&
                (mtpPeer->ssap->ssapCfg.userInfo.selfPc.val == dpc))
             {
                /* set the peer Found Flag to TRUE */
                peerFound = TRUE;
                break;
             }

         } /* while */
         if(peerFound == FALSE)
         {
            /*
             * Message doesnot have valid peer so dump the message and
             * generate an alarm to LM
             */
#if (ERRCLASS & ERRCLS_INT_PAR)
            MGLOGERROR(ERRCLS_INT_PAR, EMG162, (ErrVal) dpc,
                  "MgLiSntUDatInd: Invalid peer point code");
#endif /* ERRCLASS & ERRCLS_INT_PAR */


            MG_GEN_MTP_LI_ALARM(LMG_EVENT_SNT_UDATIND, LCM_CAUSE_INV_PAR_VAL,
                  (suId), (parId));


            if (mBuf)
            {
               (Void) mgPutMsg(mBuf);
               mBuf = (Buffer *)NULLP;
            }

            RETVALUE(RFAILED);
         }
         
   } /* layer is MG */
#endif /* GCP_MG */      

#ifdef   GCP_MGC
   /* Entity is Working as MGC */      
   if (LMG_ENT_GC == mgCb.genCfg.entType)
   {

 /* Since at MGC side there shall be only one entry for the peer */
      ret = cmHashListFind(&(tSap->mgcoMtpHlCp),(U8 *)&opc, 
                 MG_DPC_LEN, MG_HASH_SEQNMB_DEF , (PTR *)&mtpPeer);
      /* 
       * No Need to check return value as in Discovered MG case we won't have
       * any peer for any new point code 
       */

   }
#endif /* GCP_MGC */     

   /* If We are able to Find the Peer Then Change the Point Code Status as SP_ONLINE
    * As we are receiving something from this point Code i.e this point code is reachable */
    if (mtpPeer)
        mtpPeer->mgcoMtpCb.status |= SP_ONLINE;
   
   /*
    * Copy all MTP information in a structure and pass it to TxnInd
    * function 
    */
    mgcoTptInfo.tptType               = LMG_TPT_MTP3;
    mgcoTptInfo.u.mgMtpInfo.mtpPeer   = mtpPeer;
    mgcoTptInfo.u.mgMtpInfo.clgAddr   = opc; /* This is Peer Point Code */
    mgcoTptInfo.u.mgMtpInfo.cldAddr   = dpc; /* This should be our Address */

/* Process Transaction from peer */

   mgPrcMgcoTxnInd(& mgcoTptInfo, mgCb.tSAPLst[suId], NULLP, NULLP,
                   mBuf, NULLP, NULLP);

#ifdef ZG
   /* send update message to stndby */
   zgUpdPeer();
#endif /* ZG */

   RETVALUE(ROK);
} /* MgLiSntUDatInd */


#endif  /* GCP_PROV_MTP3 */ 











/********************************************************************30**
  
         End of file:     mp_li.c@@/main/mgcp_rel_1.5_mnt/3 - Tue May 31 11:49:09 2005
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------  
1.1          ---      rrp  1. Initial release
1.2          ---      bbk  1. Fixed C++ compilation warnings
1.2+      mg002.101    pk  1. Modified function call to function
                              cmDnsPrcDnsRsp.
                           2. Added argument in MG_ENA_DNS_LSTNR macro 
                              call in function  mgCntrlTsap.
/main/3      ---       pk  1. Added support for MEGACO.
                           2. Added Flow Control Indication Functionality
          mg004.102    vj  1. Modify MgLiHitDiscInd to take care of the 
                              scenario where choice is HI_PROVIDER_CON_ID.
          mg008.102    vj  1. Added support for debug printing in MgLiHitDatInd
                           2. In MgLiHitUDatInd and MgLiHitDatInd, direct calls
                              to SPrntMsg() is put inside GCP_ACC_TEST
/main/4      ---      ra   1. GCP 1.3 release
/main/5      ---      ra   1. GCP 1.4 release - added SCTP support
/main/5      ---      ka   1. Changes for Release v 1.4
          mg005.104   ra   1. FTHA related changes.
/main/6      ---      pk   1. GCP 1.5 release
          mg001.105   ra   1. Use the same TOS in the AssocRsp as that rcvd
                              in the AssocInd.
          mg002.105   ps   1. Removed compilation warning
          mg008.105   gk   1. if configuration not done do not process message
*********************************************************************91*/
