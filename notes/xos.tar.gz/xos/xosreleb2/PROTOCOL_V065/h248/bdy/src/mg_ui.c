/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     GCP - upper interface

     Type:     C source file

     Desc:     C entry points for MGCP Upper Layer
               supplied by TRILLIUM.

     File:     mg_ui.c

     Sid:      mp_ui.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:54:04 2005

     Prg:      pk

*********************************************************************21*/


/************************************************************************

     

     This file has been extracted to support the following options:

     Option             Description
     ------    ------------------------------


************************************************************************/


/************************************************************************

Upper layer primitives:

The following functions are provided in this file:

   MgUiUiMgtBndReq     Bind Request
   MgUiMgtUbndReq      Unbind Request
   MgUiMgtCntrlReq     Unbind Request
   MgUiMgtMgcpTxnReq   MGCP Transaction request
   MgUiMgtMgcoTxnReq   MEGACO Transaction request

It is assumed that the following functions are provided in the
MGCP service user file:

   MgUiMgtMgcoStaInd       MEGACO Status Indication
   MgUiMgtMgcoTxnInd       MEGACO Transaction indication
   MgUiMgtMgcpTxnInd       MGCP Transaction indication
   MgUiMgtBndCfm           Bind confirm

************************************************************************/


/************************************************************************

System services are the functions required by the protocol layer for
buffer management, timer management, date/time management, resource
checking and initialization.

The following functions are provided in this file:

     mgActvInit     Activate layer - initialization task
     mgActvTmr      Activate layer - timer task 1
     mgActvTmrTTL   Activate layer - timer task 2

It is assumed that the following functions are provided in the system
services service provider file:

     SRegInit       Register initialization task
     SFndProcId     Finds id of processor on which task is running
     SRegTmr        Register timer activation task
     SRegActvTsk    Register layer activation task
     SPstTsk        Post a message buffer to a destination task
     SExitTsk       Exit a task

     SInitQueue     Initialize Queue (used only for testing)
     SQueueLast     Queue to Last Place (used only for testing)
     SDequeueFirst  Dequeue from First Place (used only for testing)
     SFndLenQueue   Find Length of Queue (used only for testing)

     SGetSMem       Allocate a static memory block
     SGetSBuf       Allocate a buffer from static memory block
     SPutSBuf       Deallocate a buffer from static memory block

     SGetMsg        Get a message buffer
     SPutMsg        Put a message buffer

     SAddPstMsg     Add an octet at the tail of a message
     SRemPreMsg     Remove an octet from the head of a message
     SExMgMsg       Return the value of a specified octet in a message
     SRepMsg        Replace a  specified octet in a message with new value
     SFndLenMsg     Find the length of a message
     SPrntMsg       Print a message buffer
     SCpyMsgMsg     Copy a message into a new buffer

     SPkS8          Add a signed  8-bit value at the head of a message
     SPkS16         Add a signed 16-bit value at the head of a message
     SPkS32         Add a signed 32-bit value at the head of a message
     SPkU8          Add an unsigned  8-bit value at the head of a message
     SPkU16         Add an unsigned 16-bit value at the head of a message
     SPkU32         Add an unsigned 32-bit value at the head of a message

     SUnpkS8        Remove a signed  8-bit value from the head of a message
     SUnpkS16       Remove a signed 16-bit value from the head of a message
     SUnpkS32       Remove a signed 32-bit value from the head of a message
     SUnpkU8        Remove an unsigned  8-bit value from the head of a message
     SUnpkU16       Remove an unsigned 16-bit value from the head of a message
     SUnpkU32       Remove an unsigned 32-bit value from the head of a message

     SChkRes        Report available system dynMgic memory
     SLogError      Handle fatal system error
     SPrint         Print a pre-formatted string
     SGetDateTime   Get current date and time
     SGetSysTime    Get current system time in ticks

************************************************************************/


/*
 *    this software may be combined with the following TRILLIUM
 *    software:
 *
 *    part no.             description
 *    --------    ----------------------------------------------
 *
 */




/* Header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hash functions */
#include "cm5.h"           /* common timer functions */
#include "cm_llist.h"      /* common linked list */
#include "cm_inet.h"       /* common sockets lib */
#include "cm_tpt.h"        /* common transport */
#include "cm_mblk.h"       /* ASN memory management */
#include "cm_tkns.h"       /* common tokens */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.h"        /* Common SS7 defines */
#include "snt.h"           /* MTP3 Interface defines */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.h"           /* upper interface */
#include "lmg.h"           /* layer management interface */
#include "cm_dns.h"        /* common DNS library defines */
#include "cm_sdp.h"        /* SDP related constants */
#include "cm_abnf.h"       /* ABNF related constants */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */
#include "mg.h"            /* MGCP contol related */
#include "hit.h"           /* TUCL layer */
#include "mg_err.h"        /* MGCP error */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */  
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */


#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* hashing functions */
#include "cm5.x"           /* timer functions */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common lib */
#include "cm_inet.x"       /* common sockets lib */
#include "cm_tpt.x"        /* common transport */
#include "cm_mblk.x"       /* ASN memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_dns.x"        /* common DNS library defines */
#include "cm_sdp.x"        /* SDP related types */
#include "cm_abnf.x"       /* ABNF related  */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.x"        /* Common SS7 structure */
#include "snt.x"           /* MTP3 Interface structure */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.x"           /* upper interface */
#include "lmg.x"           /* layer management interface */
#include "mg.x"            /* MGCP contol related */
#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */



/* Global control block */

MgCb  mgCb;

/*mg002.105: Extern moved from mg.x for g++ compilation issue*/
EXTERN S16 mgAllocEventMem ARGS((
       Ptr       *memPtr,
       Size      memSize
    ));
       
EXTERN S16 mgFreeEventMem ARGS((
       Ptr       memPtr
    ));

EXTERN U16 mgEnableSsap ARGS ((
      MgSSAPCb           *ssap               /* SSAP Control Block */
      ));

#if (defined(GCP_CH) && defined(GCP_VER_1_5))
EXTERN PUBLIC Void mgChHandleMgcoPrcIndErr ARGS((
         MgSSAPCb           *ssap,              /* SSAP Control Block */
         MgMgcoInd      *mgInd,             /* MGCO Command       */
         U8                 mgtError,           /* Error to be reported */
         U8                 source              /* Initiated by user/ internal */
));

EXTERN PUBLIC Void mgChHandleMgcoCntxtUpdErr ARGS((
         MgSSAPCb           *ssap,              /* SSAP Control Block */
         MgMgcoUpdateCntxt      *mgCntxt,             /* MGCO Command       */
         U8                 mgtError,           /* Error to be reported */
         U8                 source              /* Initiated by user/ internal */
));


EXTERN PUBLIC Void mgChHandleMgcoCmdReqErr ARGS((
       MgSSAPCb           *ssap,              /* SSAP Control Block */
       MgMgcoCommand      *chCmd,             /* MGCO Command       */
       U8                 mgtError,           /* Error to be reported */
       U8                 source              /* Initiated by user/ internal */
      ));
 
EXTERN S16 mgChPrcCmdReq ARGS((
   MgMgcoCommand        *chCmdReq,      /* CH Command Request */
   MgSSAPCb           *sSap           /* session SAP cb */
));

EXTERN S16 mgChPrcCmdRsp ARGS((
   MgMgcoCommand        *chCmdRsp,      /* CH Command Response */
   MgSSAPCb           *sSap           /* session SAP cb */
));

EXTERN S16 mgChPrcCntxtUpd ARGS((
   MgMgcoUpdateCntxt *chUpdCntxt,   /* CH Context Update  */
   MgSSAPCb            *sSap          /* session SAP cb     */
)); 

EXTERN S16 mgChPrcMgcoInd ARGS((
   MgMgcoInd          *chInd,         /* CH Command Response */
   MgSSAPCb           *sSap           /* session SAP cb */
));

 
/* mg007.105: Removed GCP_USE_DEF_PEERID flag */
EXTERN PUBLIC S16 mgChCmdFillDefPeerId ARGS((
      MgMgcoCommand *chCmd, 
      MgSSAPCb  *sSap
));

EXTERN PUBLIC S16 mgChCxtFillDefPeerId ARGS((
      MgMgcoUpdateCntxt *chCxt, 
      MgSSAPCb  *sSap
));

EXTERN PUBLIC S16 mgChErrReqFillDefPeerId ARGS((
      MgMgcoInd *chInd, 
      MgSSAPCb  *sSap
));

#endif /* GCP_CH && GCP_VER_1_5 */ 
 
#ifdef DEBUGP
Txt dnsPrntBuf[PRNTSZE];


U8 *layerName=(U8 *)("GCP");
#endif /* DEBUGP */


/* local defines */
/* local typedefs */  
/* local externs */
/* forward references */
/* private variable declarations */
/* public variable declarations */

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif




/***********************************************************************
                     Upper Interface (MGT) Primitives 
 ***********************************************************************/

/***********************************************************************
                       Bine Request Primitive
 ***********************************************************************/
/*
 *
 *      Fun:   MgUiMgtBndReq
 *
 *      Desc:  This function binds the GCP service user
 *             with the GCP layer. 
 *  
 *             On receiving this primitive the GCP layer will create an
 *             association between a service user SAP (represented by 
 *             suId parameter) and a GCP layer upper SAP (represented by 
 *             spId parameter).
 *
 *             The  selector field in the first parameter, post, 
 *             (post->selector),is used to route the primitive from the
 *             GCP user to GCP. It is also used to convey the
 *             service users's processor id, entity id and instance id
 *             to the GCP.
 *
 *             The second parameter, suId, indicates the upper layer SAP
 *             number from which the primitive arrived.
 *
 *             The third parameter, spId, indicates the GCP SAP
 *             on which the primitive arrived.
 *
 *
 *      Ret:   ROK     - bind successful
 *             RFAILED - bind unsuccessful
 *
 *      Notes: Prior to binding, the specified SAP should have been
 *             configured  by the layer management
 *            
 *      File:  mg_ui.c
 *
 */

#ifdef ANSI
PUBLIC S16 MgUiMgtBndReq
(
Pst                *post,              /* post structure */
SuId               suId,               /* service user SAP id */
SpId               spId                /* service provider SAP id */
)
#else
PUBLIC S16 MgUiMgtBndReq(post, suId, spId)
Pst                *post;              /* post structure */
SuId               suId;               /* service user SAP id */
SpId               spId;               /* service provider SAP id */
#endif
{

   MgSSAPCb        *sSap;              /* pointer to session SAP */
   S16             ret;                /* return value */
#ifdef MG_RUG
   Bool            found;              /* flag to indicate if have version info */
   U16             idx;                /* counter */
   MgIntVerInfo    *verInfo;           /* Version Information */
#endif /* MG_RUG */

#if (ERRCLASS & ERRCLS_INT_PAR)  
   MgParId        parId;
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   TRC3(MgUiMgtBndReq);

   MGDBGP(DBGMASK_UI, (mgCb.init.prntBuf,
          "[MGCP] SSAP (spId=%d) Received Bind Request (suId=%d)\n", 
          spId, suId)); 

#ifdef ZG_DFTHA
   if((zgChkCRsetStatus()) == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG294, (ErrVal)0,
         "[MGCP] MgUiMgtBndReq: Bnd Req rcved in Invalid Resource state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      mgGenStaInd (STSSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_MGT_BNDREQ,
                 LCM_CAUSE_PROT_NOT_ACTIVE , LMG_ALARMINFO_NONE,NULLP, 0, 
                 LMG_ALARMINFO_INVSAPID);
      RETVALUE(RFAILED);
   }
#endif /* ZG_DFTHA */

   if ((spId >= (SpId)mgCb.genCfg.maxSSaps) || (spId < 0))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG295, spId,
                 "MgUiMgtBndReq():spId out of range");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_MGT_BNDREQ,
                  LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR, &parId, sizeof(MgParId), 
                  LMG_ALARMINFO_INVSAPID);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      RETVALUE(RFAILED);
   }

   ret = ROK;
   /* Get SSAP */
   sSap = *(mgCb.sSAPLst + spId);
  
   /* Check Validity of SSAP */
   if (sSap == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG296, (ErrVal) spId,
                 "MgUiMgtBndReq():SSAP not configured");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_MGT_BNDREQ,
                  LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR,
                  &parId, sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      RETVALUE(RFAILED);
   }

#ifdef MG_RUG
   /* 
    * For upper interface SAP, we look up the version info from the stored
    * information if it is available already at first bound request
    */
   found = FALSE;
   verInfo = &(mgCb.verInfo);

   if (sSap->remIntfValid == FALSE)
   {
      for (idx = 0; idx < verInfo->numIntfInfo && found == FALSE; idx++)
      {
         if (verInfo->intfInfo[idx].intf.intfId == MGTIF)
         {
            switch (verInfo->intfInfo[idx].grpType)
            {
               case SHT_GRPTYPE_ALL:
               {
                  if ((verInfo->intfInfo[idx].dstProcId == post->srcProcId) &&
                      (verInfo->intfInfo[idx].dstEnt.ent == post->srcEnt) &&
                      (verInfo->intfInfo[idx].dstEnt.inst == post->srcInst))
                  {
                     found = TRUE;
                  }
               }
               break;

               case SHT_GRPTYPE_ENT:
               {
                  if ((verInfo->intfInfo[idx].dstEnt.ent == post->srcEnt) &&
                      (verInfo->intfInfo[idx].dstEnt.inst == post->srcInst))
                  {
                     found = TRUE;
                  }
               }
               break;

               default:
                  /* not possible */
                  break;
            }
         }
      }

      if (found == TRUE)
      {
         sSap->suPst.intfVer = verInfo->intfInfo[idx-1].intf.intfVer;

         sSap->remIntfValid = TRUE;
#ifdef ZG
         /* 
          * Send runtime update of the sap control block for modifying ver num
          * & the remote ver valid flag on the slaves 
          */
         zgRtUpd(ZG_CBTYPE_VERINFO, (Ptr)sSap, CMPFTHA_UPDTYPE_SYNC, 
                    CMPFTHA_ACTN_MOD);
#endif /* ZG */
      }
      else
      {
         /* SSAP cannot be bound if remote ver info is not available */
         MGDBGP(DBGMASK_UI, (mgCb.init.prntBuf,
               "Remote Version Unavailable;Bind Failed for spId:%d,\n", spId));

#if (ERRCLASS & ERRCLS_INT_PAR)
         MGLOGERROR(ERRCLS_INT_PAR, EMG297, (ErrVal) spId, 
               "MgUiMgtBndReq() Failed, remote ver info is not available");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

         /* Send status ind to service user */
         mgGenUserStaInd(NULLP,NULLP, MGT_STATUS_VER_FOUND_FAILED, NULLP);

         /* Send status ind to layer manager */
         mgGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_MGT_BNDREQ,
                     LCM_CAUSE_SWVER_NAVAIL, LMG_ALARMINFO_NONE,
                     (Ptr)NULLP, 0, LMG_ALARMINFO_INVSAPID);

         RETVALUE(RFAILED);
      }
   }
#endif /* MG_RUG */

   /* Verify SSAP State */
   switch(sSap->state)
   {
      case LMG_SAP_UBND_DIS:
      {
         /*
          * For conventional GCP, this implies Service User has issued a Bind 
          * before layer manager issued enable request. The bind request will 
          * is interpreted as SU is ready to USE GCP and SSAP will be enabled.
          *
          * For DFT/HA GCP, the layer manager will never issue Control Enable for
          * SSAP. Hence on receiving bind request, SSAP enable procedure will be 
          * started first and then SSAP Bind State will be updated
          */

         mgEnableSsap(sSap);
         mgCheckEnbSsap(sSap);
         /* Fall Through */
      }

      case LMG_SAP_UBND_ENB:
      {
         /* copy bind configuration parameters in SSAP sap */
         sSap->suId            = suId;
         sSap->suPst.dstProcId = post->srcProcId;
         sSap->suPst.dstEnt    = post->srcEnt;
         sSap->suPst.dstInst   = post->srcInst;

         /* Update the State */
         sSap->state = LMG_SAP_BND_ENB;

         /* Fall through to send Bind Confirm */
      }

      case LMG_SAP_BND_ENB:
      {
#ifdef ZG
         /* This section was added to allow user to update bind parameters 
            in case it is using a FT user */
         /* Re-copy bind configuration parameters in SSAP sap */
         sSap->suId            = suId;
         sSap->suPst.dstProcId = post->srcProcId;
         sSap->suPst.dstEnt    = post->srcEnt;
         sSap->suPst.dstInst   = post->srcInst;

         /* Send ssap update to all shadows before issuing a BndCfm */
         zgRtUpd(ZG_CBTYPE_SSAP, (Ptr)sSap, CMPFTHA_UPDTYPE_SYNC, 
                                                   CMPFTHA_ACTN_MOD);
         zgUpdPeer();
#endif /* ZG */
         /* SAP is already bound */
         MgUiMgtBndCfm(&sSap->suPst,suId,CM_BND_OK);
      }
      break;

     default:
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG298, (ErrVal) spId,
                 "MgUiMgtBndReq():SSAP state not valid");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_MGT_BNDREQ,
                  LCM_CAUSE_INV_STATE, LMG_ALARMINFO_PAR,
                  &parId, sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      ret = RFAILED;
   }
   RETVALUE(ret);
} /* end of MgUiMgtBndReq */







/***********************************************************************
                      Unbind Request Primitive
 ***********************************************************************/

/*
 *
 *      Fun:   MgUiMgtUbndReq
 *
 *      Desc:  This function unbinds the GCP service
 *             user from the GCP layer.
 *
 *             The first parameter, post, is used for its selector 
 *             field (post->selector) to route the primitive from the
 *             GCP user to GCP layer. Once the primitive reaches 
 *             the GCP layer,the first parameter is no longer needed.
 *
 *             The second parameter, spId, indicates the session SAP
 *             number on which the primitive arrived.
 *
 *             The third parameter, reason, indicates the reason for
 *             unbind. Allowable values are specified in Mgt.h.
 *
 *             All existing calls are deactivated
 *
 *
 *      Ret:   ROK     - unbind successful
 *             RFAILED - unbind unsuccessful
 *
 *      Notes: None
 *
        File:  mg_ui.c
 *
 */

#ifdef ANSI
PUBLIC S16 MgUiMgtUbndReq
(
Pst    *post,            /* post structure */
SpId   spId,             /* service provider SAP id */
Reason reason            /* reason for unbinding */
)
#else
PUBLIC S16 MgUiMgtUbndReq(post, spId, reason)
Pst    *post;            /* post structure */
SpId   spId;             /* service provider SAP id */
Reason reason;           /* reason for unbinding */
#endif
{
   MgSSAPCb  *sSap;
#if (ERRCLASS & ERRCLS_INT_PAR)  
   MgParId        parId;
#endif /* ERRCLASS & ERRCLS_INT_PAR */


   TRC3(MgUiMgtUbndReq);
      
   UNUSED(post);
   UNUSED(reason);


   MGDBGP(DBGMASK_UI, (mgCb.init.prntBuf,
          "[MGCP]  SSAP (spId) %d: Received Unbind Request\n\n", spId)); 


   if ((spId >= (SpId)mgCb.genCfg.maxSSaps) || (spId < 0))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG299, spId,
                 "MgUiMgtUbndReq():spId out of range");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_UBNDREQ,
                  LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR,
                  &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      RETVALUE(RFAILED);
   }


#ifdef ZG_DFTHA
   if((zgChkCRsetStatus()) == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG300, (ErrVal)0,
         "[MGCP] MgUiMgtUBndReq: UBnd Req rcved in Invalid Resource state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      mgGenStaInd (STSSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_MGT_UBNDREQ,
                   LCM_CAUSE_PROT_NOT_ACTIVE, LMG_ALARMINFO_NONE,NULLP, 0, 
                   LMG_ALARMINFO_INVSAPID);
      RETVALUE(RFAILED);
   }
#endif /* ZG_DFTHA */
   /* Get SSAP */
   sSap = *(mgCb.sSAPLst + spId);


   if (sSap == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG301, (ErrVal) spId,
                 "MgUiMgtUbndReq():Sap not configured");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_UBNDREQ,
                  LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR,
                  &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      RETVALUE(RFAILED);
   }



   /* SSAP already unbound */
   if (sSap->state == LMG_SAP_UBND_DIS)
   {
      RETVALUE(ROK);
   }

   sSap->state = LMG_SAP_UBND_ENB;


   /* Disable SSAP resource if any */
   MG_REM_SSAP_PEERS(sSap, FALSE);

#ifdef GCP_MG
   mgRemSsapSrvrs(sSap, TRUE);
#endif /* GCP_MG */

#ifdef GCP_MGC
#ifdef GCP_MGCP
   if ((sSap->ssapCfg.protocol == LMG_PROTOCOL_MGCP) &&                   
       (sSap->ssapCfg.sSAPId == mgCb.nxtMgcpSsapId))                      
   {                                                                      
      MG_UPDATE_NXTUSE_MGCP_SSAPID();                                     
   }     
#endif /* GCP_MGCP */
#ifdef GCP_MGCO
   if ((sSap->ssapCfg.protocol == LMG_PROTOCOL_MGCO) &&                   
       (sSap->ssapCfg.sSAPId == mgCb.nxtMgcoSsapId))                      
   {                                                                      
      MG_UPDATE_NXTUSE_MGCO_SSAPID();                                     
   }     
#endif /* GCP_MGCO */
#endif /* GCP_MGC */
#ifdef ZG
   /* send updates */
   zgRtUpd(ZG_CBTYPE_SSAP, (Ptr)sSap, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
   zgUpdPeer();
#endif /* ZG */
   RETVALUE(ROK);
} /* end of MgUiMgtUbndReq */






/***********************************************************************
                      Control Request Primitive
 ***********************************************************************/

/*
 *
 *      Fun:   MgUiMgtCntrlReq
 *
 *      Desc:  The service user issues this primitive to remove peer
 *             associations / to remove specific transactions in the 
 *             GCP layer.
 * 
 *             The first parameter, post, is used for its selector 
 *             field (post->selector). The selector field is used 
 *             to route the primitive from the GCP user to the GCP
 *             GCP layer. Once the primitive reaches the GCP layer
 *             this parameter is no longer needed.
 *
 *             The second parameter, spId, indicates the session SAP
 *             number for which the  primitive is destined.
 *
 *      Ret:   ROK     - unbind successful
 *             RFAILED - unbind unsuccessful
 *
 *      Notes: None
 *
 *      File:  mg_ui.c
 *
 */

#ifdef ANSI
PUBLIC S16 MgUiMgtCntrlReq
(
Pst    *post,            /* post structure */
SpId   spId,             /* service provider SAP id */
MgMgtCntrl *cntrl        /* Control information */
)
#else
PUBLIC S16 MgUiMgtCntrlReq(post, spId, cntrl)
Pst    *post;            /* post structure */
SpId   spId;             /* service provider SAP id */
MgMgtCntrl *cntrl;       /* Control information */
#endif
{
   MgSSAPCb  *sSap;

#ifdef GCP_MGC   
   MgSSAPCb  *newSsap;
#endif /* GCP_MG */

#if (ERRCLASS & ERRCLS_INT_PAR)  
   MgParId        parId;
#endif /* ERRCLASS & ERRCLS_INT_PAR */
   S16  ret;

   TRC3(MgUiMgtCntrlReq);
      
   UNUSED(post);

   MGDBGP(DBGMASK_UI, (mgCb.init.prntBuf,
          "[MGCP]  SSAP (spId) %d: Received Control Request\n\n", spId)); 


   if ((spId >= (SpId)mgCb.genCfg.maxSSaps) || (spId < 0))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG302, spId,
                 "MgUiMgtCntrlReq():spId out of range");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_CNTRLREQ,
                  LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR,
                  &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      RETVALUE(RFAILED);
   }


#ifdef ZG_DFTHA
   if((zgChkCRsetStatus()) == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG303, (ErrVal)0,
         "[MGCP] MgUiMgtCntrlReq: Cntrl Req rcved in Invalid Resource state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      mgGenStaInd (STSSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_MGT_CNTRLREQ,
                   LCM_CAUSE_PROT_NOT_ACTIVE, LMG_ALARMINFO_NONE,NULLP, 0, 
                   LMG_ALARMINFO_INVSAPID);
      RETVALUE(RFAILED);
   }
#endif /* ZG_DFTHA */
  /* Get SSAP */
   sSap = *(mgCb.sSAPLst + spId);


   if (sSap == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG304, (ErrVal) spId,
                 "MgUiMgtCntrlReq():Sap not configured");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_UBNDREQ,
                  LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR,
                  &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      RETVALUE(RFAILED);
   }

   if (cntrl == NULLP)
   {
     MgUiMgtCntrlCfm(&sSap->suPst,sSap->suId,cntrl, 
                         MGT_ERR_INVALID_PARMS);
     RETVALUE(RFAILED);
   }


   ret = MGT_NONE;

#ifdef MG_RUG
   /* RUG Support - Fill default values for control request */
#ifdef GCP_MGCO
   /* 
    * If binary is compiled with MGCO flag but MGCO values are not specified
    * fill in the default MGCO values for control request
    */
   if (!(cntrl->bitVector & LMG_GCP_MGCO_BIT))
   {
      cntrl->peerInfo.mid.pres = NOTPRSNT;
   }
#endif /* GCP_MGCO */
#endif /* MG_RUG */

   /* Verify SSAP State */
   switch(cntrl->action)
   {
      case MGT_RMV_ASSOC:
      {
         ret = mgRmvPeerAssoc(sSap, cntrl);
         break;
      }

      case MGT_RMV_TRANS:
      {
         ret = mgRmvPeerTrans(sSap, cntrl);
#ifdef ZG_DFTHA
         ret = MGT_NONE;
#endif /* ZG_DFTHA */
         break;
      }

#ifdef GCP_MGC
      case MGT_MOVE_PEER:
      {
         if (mgCb.genCfg.entType == LMG_ENT_GC)
         {
            newSsap = *(mgCb.sSAPLst + cntrl->u.ssapId);

           if (newSsap == NULLP || newSsap->state != LMG_SAP_BND_ENB)
           {
              ret = MGT_ERR_INVALID_PARMS;
           }
           else
              ret = mgMovePeer(newSsap, cntrl);
         }
      }
      break;
#endif /* GCP_MGC */

       case MGT_MOVE_TRANS:
       {
          ret = mgMoveTrans(cntrl, sSap);
#ifdef ZG_DFTHA
         ret = MGT_NONE;
#endif /* ZG_DFTHA */
          break;
       }

       case MGT_CANCEL_RMV_ASSOC:
       {
          ret = mgCancelRmvAssoc(sSap, cntrl);
          break;
       }
 
      case MGT_RESET_RTO:
      {
         ret = mgResetRTO(&(cntrl->peerInfo), sSap);
         break;
      }

      default:
      {
         ret = MGT_ERR_INVALID_PARMS;
         break;
      }
   }
#ifdef ZG
   /* send update to peer */
   zgUpdPeer();
#endif /* ZG */

   MgUiMgtCntrlCfm(&sSap->suPst,sSap->suId,cntrl, ret);

   if (ret != MGT_NONE)
     RETVALUE(RFAILED);

   RETVALUE(ROK);

} /* end of MgUiMgtCntrlReq */






/***********************************************************************
                      Control Request Primitive
 ***********************************************************************/

/*
 *
 *      Fun:   MgUiMgtAuditReq
 *
 *      Desc:  This function is used by service user to locally audit 
 *             transactions on a certain peer.
 *
 *             The first parameter, post, is used for its selector 
 *             field (post->selector). The selector field is used 
 *             to route the primitive from the GCP user to the GCP
 *             GCP layer. Once the primitive reaches the GCP layer
 *             this parameter is no longer needed.
 *
 *             The second parameter, spId, indicates the session SAP
 *             number for which the  primitive is destined.
 *
 *      Ret:   ROK     - unbind successful
 *             RFAILED - unbind unsuccessful
 *
 *      Notes: None
 *
 *      File:  mg_ui.c
 *
 */

#ifdef ANSI
PUBLIC S16 MgUiMgtAuditReq
(
Pst    *post,            /* post structure */
SpId   spId,             /* service provider SAP id */
MgMgtAudit *audit        /* Control information */
)
#else
PUBLIC S16 MgUiMgtAuditReq(post, spId, audit)
Pst    *post;            /* post structure */
SpId   spId;             /* service provider SAP id */
MgMgtAudit *audit;       /* Control information */
#endif
{
   MgSSAPCb  *sSap;
#if (ERRCLASS & ERRCLS_INT_PAR)  
   MgParId        parId;
#endif /* ERRCLASS & ERRCLS_INT_PAR */
   U16  ret;

   TRC3(MgUiMgtAuditReq);
      
   UNUSED(post);

   MGDBGP(DBGMASK_UI, (mgCb.init.prntBuf,
          "[MGCP]  SSAP (spId) %d: Received Control Request\n\n", spId)); 


   if ((spId >= (SpId)mgCb.genCfg.maxSSaps) || (spId < 0))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG305, spId,
                 "MgUiMgtCntrlReq():spId out of range");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE, LMG_EVENT_MGT_UBNDREQ,
                  LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR,
                  &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      RETVALUE(RFAILED);
   }


#ifdef ZG_DFTHA
   if((zgChkCRsetStatus()) == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      MGLOGERROR(ERRCLS_DEBUG, EMG306, (ErrVal)0,
         "[MGCP] MgUiMgtCntrlReq: Cntrl Req rcved in Invalid Resource state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      mgGenStaInd (STSSAP, LCM_CATEGORY_INTERFACE, LMG_EVENT_MGT_UBNDREQ,
                   LCM_CAUSE_PROT_NOT_ACTIVE, LMG_ALARMINFO_NONE,NULLP, 0, 
                   LMG_ALARMINFO_INVSAPID);
      RETVALUE(RFAILED);
   }
#endif /* ZG_DFTHA */
   /* Get SSAP */
   sSap = *(mgCb.sSAPLst + spId);


   if (sSap == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG307, (ErrVal) spId,
                 "MgUiMgtCntrlReq():Sap not configured");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_UBNDREQ,
                  LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR,
                  &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
      RETVALUE(RFAILED);
   }

   if (audit == NULLP)
   {
     MgUiMgtAuditCfm(&sSap->suPst,sSap->suId,audit, 
                         MGT_ERR_INVALID_PARMS);
     RETVALUE(RFAILED);
   }


   ret = MGT_NONE;

#ifdef MG_RUG
   /* RUG Support - Fill default values for control request */
#ifdef GCP_MGCO
   /* 
    * If binary is compiled with MGCO flag but MGCO values are not specified
    * fill in the default MGCO values for control request
    */
   if (!(audit->bitVector & LMG_GCP_MGCO_BIT))
   {
      audit->peerInfo.mid.pres = NOTPRSNT;
   }
#endif /* GCP_MGCO */
#endif /* MG_RUG */

   ret = mgAuditPeerTxn(sSap, audit);
   
   if (ret != MGT_NONE)
   {
     MgUiMgtAuditCfm(&sSap->suPst,sSap->suId,audit, ret);
     RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of MgUiMgtAuditReq */





/***********************************************************************
                      MGCP Transaction Request Primitive
 ***********************************************************************/
#ifdef GCP_MGCP
/*
 *
 *     Fun:   MgUiMgtMgcpTxnReq
 *
 *     Desc:  This function is used to send MGCP transaction
 *            (command/response) to the peer.
 *
 *            The first parameter, post,  is used for its selector 
 *            field (post->selector). This field to route the primitive 
 *            from the MGCP user to MGCP layer. Once the primitive reaches  
 *            MGCP,the first parameter is no longer needed.
 *
 *            The second parameter, spId, indicates the session SAP
 *            on which the primitive arrived.
 *
 *            The third parameter, mgTxn contains the information to be
 *            sent in the MGCP command/response.
 *
 *            MGCP service user selects a transaction Id for the request
 *            and passes it as a part of mgTxn.
 *
 *     Ret:   ROK     - transaction request successful
 *            RFAILED - transaction request unsuccessful
 *
 *     Notes: None
 *
       File:  mg_ui.c
 *
 */

#ifdef ANSI
PUBLIC S16 MgUiMgtMgcpTxnReq
(
Pst       *post,            /* post structure */
SpId      spId,             /* service provider SAP id */
MgMgcpTxn *mgTxn            /* MGCP command/response */
)
#else
PUBLIC S16 MgUiMgtMgcpTxnReq(post, spId, mgTxn)
Pst          *post;          /* post structure */
SpId         spId;           /* service provider SAP id */
MgMgcpTxn    *mgTxn;         /* MGCP command/response */
#endif
{
   S16           ret;          /* return code */
   MgSSAPCb      *sSap;      /* session SAP cb */
#if (ERRCLASS & ERRCLS_INT_PAR)
   MgParId parId;
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */


   TRC3(MgUiMgtMgcpTxnReq);

   UNUSED(post);

   MGDBGP(DBGMASK_UI,(mgCb.init.prntBuf,
          "[MGCP] SSAP (spId %d): Received Transaction Request \n",
          spId)); 

   sSap = *(mgCb.sSAPLst + (spId));

   if (sSap == NULLP || !(spId < mgCb.genCfg.maxSSaps) )
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG308, spId, 
                 "MgUiMgtMgcpTxnReq () Failed : Invalid spId");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;

      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_MGCPTXNREQ,
                  LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR,
                  &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      MG_FREE_MGCP_EVNT_MEM(mgTxn, TRUE);

      RETVALUE(RFAILED);
   }


   /* If the Event Strcuture is Invalid, 
      send indication to layer manager  */

   if(mgTxn == NULLP)
   {
      mgIssueMgcpTxnErr(sSap, MGT_ERR_INVALID_PARMS, NULLP, MG_IGNORE_TRANSID);
      RETVALUE(RFAILED);
   }


   /* Check if SSAP is in proper state to accept the request */
   if((sSap->state != LMG_SAP_BND_ENB))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG309, spId, 
                 "MgUiMgtMgcpTxnReq () Failed : Incorrect SAP state");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_MGCPTXNREQ,
                  LCM_CAUSE_INV_STATE, LMG_ALARMINFO_PAR,
                  &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif

      /* Issue Txn Error to service user */
      mgHandleMgcpTxnReqErr(sSap, mgTxn, MGT_ERR_INVALID_MSG);
     
      RETVALUE(RFAILED);
   }

   /* Process Transaction */
   
   ret = mgPrcMgcpTxnReq(sSap, mgTxn, NULLP);

   RETVALUE(ret);

} /* end of MgUiMgtMgcpTxnReq */

#endif /* GCP_MGCP */




/***********************************************************************
                      MEGACO Transaction Request Primitive
 ***********************************************************************/
#ifdef GCP_MGCO 
/*
 *
 *     Fun:   MgUiMgtMgcoTxnReq
 *
 *     Desc:  This function is used to send MEGACO transaction
 *            (command/response) to the peer.
 *
 *            The first parameter, post,  is used for its selector 
 *            field (post->selector). This field to route the primitive 
 *            from the MGCP user to MGCP layer. Once the primitive reaches  
 *            MGCP,the first parameter is no longer needed.
 *
 *            The second parameter, spId, indicates the session SAP
 *            on which the primitive arrived.
 *
 *            The third parameter, mgTxn contains the information to be
 *            sent in theMEGACO command/response.
 *
 *            The service user selects a transaction Id for the request
 *            and passes it as a part of mgTxn.
 *
 *     Ret:   ROK     - transaction request successful
 *            RFAILED - transaction request unsuccessful
 *
 *     Notes: None
 *
       File:  mg_ui.c
 *
 */

#ifdef ANSI
PUBLIC S16 MgUiMgtMgcoTxnReq
(
Pst       *post,            /* post structure */
SpId      spId,             /* service provider SAP id */
MgMgcoMsg *mgTxn            /* MEGACO command/response */
)
#else
PUBLIC S16 MgUiMgtMgcoTxnReq(post, spId, mgTxn)
Pst          *post;          /* post structure */
SpId         spId;           /* service provider SAP id */
MgMgcoMsg    *mgTxn;         /* MEGACO command/response */
#endif
{
   S16           ret;          /* return code */
   MgSSAPCb      *sSap;      /* session SAP cb */
#if (ERRCLASS & ERRCLS_INT_PAR)
   MgParId parId;
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   TRC3(MgUiMgtMgcoTxnReq);

   UNUSED(post);

   MGDBGP(DBGMASK_UI,(mgCb.init.prntBuf,
          "[MGCP] SSAP (spId %d): Received Transaction Request \n",
          spId)); 

   sSap = *(mgCb.sSAPLst + (spId));

   if (sSap == NULLP || !(spId < mgCb.genCfg.maxSSaps) )
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG310, spId, 
                 "MgUiMgtMgcoTxnReq() Failed : Invalid spId");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;

      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_MGCOTXNREQ,
                  LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR,
                  &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      MG_FREE_MGCO_EVNT_MEM(mgTxn, TRUE);

      RETVALUE(RFAILED);
   }


   /* If the Event Strcuture is Invalid, 
      send indication to layer manager  */

   if(mgTxn == NULLP)
   {
      mgIssueMgcoTxnErr(sSap, MGT_ERR_INVALID_PARMS, NULLP, MG_IGNORE_TRANSID);
      RETVALUE(RFAILED);
   }


   /* Check if SSAP is in proper state to accept the request */
   if((sSap->state != LMG_SAP_BND_ENB))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG311, spId, 
                 "MgUiMgtMgcoTxnReq() Failed : Incorrect SAP state");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_MGCOTXNREQ,
                  LCM_CAUSE_INV_STATE, LMG_ALARMINFO_PAR,
                  &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif

      mgHandleMgcoTxnReqErr(sSap, mgTxn, MGT_ERR_INVALID_MSG, MG_USER);
     RETVALUE(RFAILED);
   }

   /* Process Transaction */
   ret = mgPrcMgcoTxnReq(sSap, mgTxn, NULLP, MG_USER);

   RETVALUE(ret);

} /* end of MgUiMgtMgcoTxnReq */
#endif /* GCP_MGCO */

#if (defined(GCP_CH) && defined(GCP_VER_1_5))
 
/*
 *
 *     Fun:   MgUiMgtMgcoCmdReq
 *
 *     Desc:  This function is used by user to send MEGACO CH command 
 *            request / response to the GCP for further processing.
 *
 *            The first parameter, post,  is used for its selector 
 *            field (post->selector). This field to route the primitive 
 *            from the MGCP user to MGCP layer. Once the primitive reaches  
 *            MGCP,the first parameter is no longer needed.
 *
 *            The second parameter, spId, indicates the session SAP
 *            on which the primitive arrived.
 *
 *            The third parameter, chCmd contains the information to be
 *            sent in the MEGACO command request/response.
 *
 *            The service user selects a transaction Id for the request
 *            and passes it as a part of chCmd.
 *
 *     Ret:   ROK     - transaction request successful
 *            RFAILED - transaction request unsuccessful
 *
 *     Notes: None
 *
       File:  mg_ui.c
 *
 */

#ifdef ANSI
PUBLIC S16 MgUiMgtMgcoCmdReq
(
Pst         *post,            /* post structure                     */
SpId        spId,             /* service provider SAP id            */
MgMgcoCommand *chCmd            /* MEGACO CH command request/response */
)
#else
PUBLIC S16 MgUiMgtMgcoCmdReq (post, spId, chCmd)
Pst          *post;          /* post structure                      */
SpId         spId;           /* service provider SAP id             */
MgMgcoCommand  *chCmd;         /* MEGACO CH command request/response  */
#endif
{
   S16           ret;          /* return code */
   MgSSAPCb      *sSap;      /* session SAP cb */
#if (ERRCLASS & ERRCLS_INT_PAR)
   MgParId parId;
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   TRC3(MgUiMgtMgcoCmdReq);

   UNUSED(post);

   MGDBGP(DBGMASK_UI,(mgCb.init.prntBuf,
          "[MGCP] SSAP (spId %d): Received CH Command Request/Response \n",
          spId)); 

   sSap = *(mgCb.sSAPLst + (spId));

   if (sSap == NULLP || !(spId < mgCb.genCfg.maxSSaps) )
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG312, spId, 
                 "MgUiMgtMgcoCmdReq () Failed : Invalid spId");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;

      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_MGCOCOMMAND,
                  LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR,
                  &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      if ((NULLP != chCmd) && (NULLP != chCmd->u.mgCmdRsp[0]))
         mgFreeEventMem((Ptr) chCmd->u.mgCmdRsp[0]);
      else if ((NULLP != chCmd) && (NULLP != chCmd->u.mgCmdReq[0]))
         mgFreeEventMem((Ptr) chCmd->u.mgCmdReq[0]);
      RETVALUE(RFAILED);
   }


   /* If the Event Strcuture is Invalid, 
      send indication to layer manager  */

   if(chCmd == NULLP)
   {
      /* Handle cmd request error */
      mgChHandleMgcoCmdReqErr(sSap, chCmd, MGT_ERR_INVALID_MSG, MG_USER);
      RETVALUE(RFAILED);
   }


   /* Check if SSAP is in proper state to accept the request */
   if((sSap->state != LMG_SAP_BND_ENB))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG313, spId, 
                 "MgUiMgtMgcoCmdReq () Failed : Incorrect SAP state");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_MGCOCOMMAND,
                  LCM_CAUSE_INV_STATE, LMG_ALARMINFO_PAR,
                  &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif
      /* mg004.105: Bug fix */
      /* mgChHandleMgcoCmdReqErr (sSap, chCmd, MGT_ERR_INVALID_MSG, MG_USER); */
     RETVALUE(RFAILED);
   }
#ifdef GCP_MG
   if(chCmd->peerId.pres == NOTPRSNT)
   {
      if (mgChCmdFillDefPeerId(chCmd, sSap)!= ROK )
         RETVALUE(RFAILED);
   }   
#endif /* GCP_MG */

   /* Process commands from user */
   if (chCmd->cmdType.pres != NOTPRSNT)
   {
      if (chCmd->cmdType.val == CH_CMD_TYPE_REQ)
      {
         ret = mgChPrcCmdReq (chCmd, sSap);
         RETVALUE(ret);
      }
      else if (chCmd->cmdType.val == CH_CMD_TYPE_RSP)
      {
         ret = mgChPrcCmdRsp(chCmd, sSap);
         RETVALUE(ret);
      }
   }
  mgChHandleMgcoCmdReqErr(sSap, chCmd, MGT_ERR_INVALID_MSG, MG_USER);
  if (NULLP != chCmd->u.mgCmdRsp[0])
     mgFreeEventMem((Ptr) chCmd->u.mgCmdRsp[0]);
  else if (NULLP != chCmd->u.mgCmdReq[0])
     mgFreeEventMem((Ptr) chCmd->u.mgCmdReq[0]);

  /* removed mgFreeEventMem because chcmd is of type MgMgcoCommand, which
     does not have memCp */
  /* mgFreeEventMem((Ptr) chCmd); */
  RETVALUE(RFAILED);
} /* end of MgUiMgtMgcoCmdReq */
 
/*
 *
 *     Fun:   MgUiMgtMgcoUpdCtxtReq
 *
 *     Desc:  This function is used by user to send MEGACO CH context 
 *            update to the GCP for further processing.
 *
 *            The first parameter, post,  is used for its selector 
 *            field (post->selector). This field to route the primitive 
 *            from the MGCP user to MGCP layer. Once the primitive reaches  
 *            MGCP,the first parameter is no longer needed.
 *
 *            The second parameter, spId, indicates the session SAP
 *            on which the primitive arrived.
 *
 *            The third parameter, mgCntxt contains the information to be
 *            sent in the MEGACO context update.
 *
 *            The service user selects a transaction Id for the request
 *            and passes it as a part of chCmd.
 *
 *     Ret:   ROK     - transaction request successful
 *            RFAILED - transaction request unsuccessful
 *
 *     Notes: None
 *
       File:  mg_ui.c
 *
 */

#ifdef ANSI
PUBLIC S16 MgUiMgtMgcoUpdCtxtReq
(
Pst         *post,            /* post structure                     */
SpId        spId,             /* service provider SAP id            */
MgMgcoUpdateCntxt *mgCntxt            /* MEGACO CH command request/response */
)
#else
PUBLIC S16 MgUiMgtMgcoUpdCtxtReq (post, spId, mgCntxt)
Pst          *post;          /* post structure                      */
SpId         spId;           /* service provider SAP id             */
MgMgcoUpdateCntxt  *mgCntxt;         /* MEGACO CH command request/response  */
#endif
{
   S16           ret;          /* return code */
   MgSSAPCb      *sSap;      /* session SAP cb */
#if (ERRCLASS & ERRCLS_INT_PAR)
   MgParId parId;
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   TRC3(MgUiMgtMgcoUpdCtxtReq);

   UNUSED(post);

   MGDBGP(DBGMASK_UI,(mgCb.init.prntBuf,
            "[MGCP] SSAP (spId %d): Received CH Command Request/Response \n",
            spId)); 

   sSap = *(mgCb.sSAPLst + (spId));

   if (sSap == NULLP || !(spId < mgCb.genCfg.maxSSaps) )
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG314, spId, 
            "MgUiMgtMgcoUpdCtxtReq () Failed : Invalid spId");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;

      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_MGCOUPDCNTXT,
            LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR,
            &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      mgFreeEventMem((Ptr) mgCntxt);
      RETVALUE(RFAILED);
   }


   /* If the Event Strcuture is Invalid, 
      send indication to layer manager  */

   if(mgCntxt == NULLP)
   {
      /* Handle cmd request error */
      mgChHandleMgcoCntxtUpdErr(sSap, mgCntxt, MGT_ERR_INVALID_MSG, MG_USER);
      RETVALUE(RFAILED);
   }


   /* Check if SSAP is in proper state to accept the request */
   if((sSap->state != LMG_SAP_BND_ENB))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG315, spId, 
            "MgUiMgtMgcoUpdCtxtReq () Failed : Incorrect SAP state");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_MGCOUPDCNTXT,
            LCM_CAUSE_INV_STATE, LMG_ALARMINFO_PAR,
            &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif
      /* mg004.105: Bug fix */
      /* mgChHandleMgcoCntxtUpdErr (sSap, mgCntxt, MGT_ERR_INVALID_MSG, MG_USER); */
      RETVALUE(RFAILED);
   }
#ifdef GCP_MG
   if(mgCntxt->peerId.pres == NOTPRSNT)
   {
      if (mgChCxtFillDefPeerId(mgCntxt, sSap)!= ROK )
         RETVALUE(RFAILED);
   }   
#endif /* GCP_MG */

   /* Process context Update from user */
   ret = mgChPrcCntxtUpd(mgCntxt, sSap);
   RETVALUE(ret);
 
} /* end of MgUiMgtMgcoUpdCtxtReq */
 
/*
 *
 *     Fun:   MgUiMgtMgcoErrReq
 *
 *     Desc:  This function is used by user to send MEGACO CH context 
 *            update to the GCP for further processing.
 *
 *            The first parameter, post,  is used for its selector 
 *            field (post->selector). This field to route the primitive 
 *            from the MGCP user to MGCP layer. Once the primitive reaches  
 *            MGCP,the first parameter is no longer needed.
 *
 *            The second parameter, spId, indicates the session SAP
 *            on which the primitive arrived.
 *
 *            The third parameter, mgInd contains the information to be
 *            sent in the MEGACO context update.
 *
 *            The service user selects a transaction Id for the request
 *            and passes it as a part of chCmd.
 *
 *     Ret:   ROK     - transaction request successful
 *            RFAILED - transaction request unsuccessful
 *
 *     Notes: None
 *
       File:  mg_ui.c
 *
 */

#ifdef ANSI
PUBLIC S16 MgUiMgtMgcoErrReq
(
Pst         *post,            /* post structure                     */
SpId        spId,             /* service provider SAP id            */
MgMgcoInd *mgInd            /* MEGACO CH command request/response */
)
#else
PUBLIC S16 MgUiMgtMgcoErrReq (post, spId, mgInd)
Pst          *post;          /* post structure                      */
SpId         spId;           /* service provider SAP id             */
MgMgcoInd  *mgInd;         /* MEGACO CH command request/response  */
#endif
{
   S16           ret;          /* return code */
   MgSSAPCb      *sSap;      /* session SAP cb */
#if (ERRCLASS & ERRCLS_INT_PAR)
   MgParId parId;
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   TRC3(MgUiMgtMgcoErrReq);

   UNUSED(post);

   MGDBGP(DBGMASK_UI,(mgCb.init.prntBuf,
            "[MGCP] SSAP (spId %d): Received CH Command Request/Response \n",
            spId)); 

   sSap = *(mgCb.sSAPLst + (spId));

   if (sSap == NULLP || !(spId < mgCb.genCfg.maxSSaps) )
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG316, spId, 
            "MgUiMgtMgcoErrReq () Failed : Invalid spId");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;

      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_MGCOIND,
            LCM_CAUSE_INV_SAP, LMG_ALARMINFO_PAR,
            &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

      mgFreeEventMem((Ptr) mgInd);
      RETVALUE(RFAILED);
   }


   /* If the Event Strcuture is Invalid, 
      send indication to layer manager  */

   if(mgInd == NULLP)
   {
      /* Handle cmd request error */
      mgChHandleMgcoPrcIndErr(sSap, mgInd, MGT_ERR_INVALID_MSG, MG_USER);
      RETVALUE(RFAILED);
   }


   /* Check if SSAP is in proper state to accept the request */
   if((sSap->state != LMG_SAP_BND_ENB))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      MGLOGERROR(ERRCLS_INT_PAR, EMG317, spId, 
            "MgUiMgtMgcoErrReq () Failed : Incorrect SAP state");
      parId.parType = LMG_PAR_SPID;
      parId.sapId = spId;
      mgGenStaInd(STSSAP,LCM_CATEGORY_INTERFACE,LMG_EVENT_MGT_MGCOIND,
            LCM_CAUSE_INV_STATE, LMG_ALARMINFO_PAR,
            &parId,sizeof(MgParId), LMG_ALARMINFO_INVSAPID);
#endif
      /* mg004.105: bug fix */
      /* mgChHandleMgcoPrcIndErr (sSap, mgInd, MGT_ERR_INVALID_MSG, MG_USER); */
      RETVALUE(RFAILED);
   }
#ifdef GCP_MG
   if(mgInd->peerId.pres == NOTPRSNT)
   {
      /* mg003.105: Bug fix for GCP PSF */
      if (mgChErrReqFillDefPeerId(mgInd, sSap)!= ROK )
         RETVALUE(RFAILED);
   }   
#endif /* GCP_MG */

   /* Process context Update from user */
   ret = mgChPrcMgcoInd (mgInd, sSap);
   RETVALUE(ret);
 
}
 
#endif /* GCP_CH && GCP_VER_1_5 */ 
 

/********************************************************************30**
  
         End of file:     mp_ui.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:54:04 2005
   
*********************************************************************31*/


/********************************************************************40**

         Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

         Revision history:

*********************************************************************61*/

/********************************************************************90**


     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rrp  1. initial release.
1.2          ---      bbk  1. Fixed C++ compilation warnings
1.2+         mg001.101bbk  1. Added global variable declarations
             mg003.101bbk  1. Removed Solaris C++ compilation error
                              of assigning char to unsigned char
/main/3      ---       pk  1. Added new transaction primitives for MEGACO
                           2. Reorganized code.
                           3. Added new control request primitive at the
                              upper interface.
                           4. Added new audit request primitive at the 
                              upper interface.
/main/4      ---      ra   1. GCP 1.3 release
/main/5      ---      ka   1. Changes for Release v 1.4 
             mg006.104pk   1. PSF related changes.
/main/6      ---      pk   1. GCP 1.5 release
           mg002.105  ps   1. Extern moved from mg.x for g++ compilation issue
                           2. Removed patch reference for 1.4
           mg003.105  dp   1. Bug fix for GCP PSF 
           mg004.105  gk   1. Bug fix
           mg007.105  gk   1. Removed GCP_USE_DEF_PEERID flag
*********************************************************************91*/
