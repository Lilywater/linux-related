/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
 
     Name:     GCP - multithreading Functions
 
     Type:     C source file
  
     Desc:     C Source Code for multithreading module
 
     File:     mp_ed.c
  
     Sid:      mp_ed.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:53:29 2005
  
     Prg:      sk
  
*********************************************************************21*/
 
/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*
*/
 
/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*    
*   
*
*/

 
/*
 * The core of MGC product is implemented in following files:
 *
 *    mg_dns.c      DNS Interaction functions 
 *    mg_tmr.c      Timer Management/Maintenance functions
 *    mg_tpt.c      Transport Layer Interaction functions
 *    mg_trans.c    Transaction Management functions
 *    mg_cord.c     Co-ordinator Module functions
 *    mg_ui.c       MGCP Upper Interface Functions
 *    mg_mi.c       MGCP Layer Management Interface
 *    mg_li.c       MGCP Lower Layer (TUCL) Interface
 *    cm_tenc.c     Common Text Based Encode Engine for MGCP messages
 *    cm_tdec.c     Common Text Based Decode Engine for MGCP messages
 */

/* header include files (.h) */
#include "envopt.h"        /* Environment options */  
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */

#ifdef MG

#include "gen.h"           /* General layer */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common Timer Library */
#include "cm_hash.h"       /* Hash library */
#include "cm_llist.h"      /* Doubly Linked List library */
#include "cm_inet.h"       /* Common Sockets Library */
#include "cm_tpt.h"        /* Common Transport Defines */
#include "cm_tkns.h"       /* Common Tokens Defines */
#include "cm_sdp.h"        /* Session Description Protocol Defines */
#include "cm_mblk.h"       /* Common Memory Manager Defines */
#include "cm_abnf.h"       /* Common ABNF  Defines */
#include "cm_dns.h"        /* common DNS library */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include  "cm_ss7.h"       /* Common SS7 Defines */
#include  "snt.h"          /* MTP3 Interface Defines */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.h"           /* MGT Interface Defines */
#include "lmg.h"           /* MGCP Layer Management */
#include "mg_err.h"        /* MGCP Error Codes */
#include "mg.h"            /* MGCP Defines */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer */
#include "ssi.x"           /* System services */
#include "cm5.x"           /* Common Timer Library */
#include "cm_hash.x"       /* Hash library */
#include "cm_llist.x"      /* Doubly Linked List library */
#include "cm_inet.x"       /* Common Sockets Library */
#include "cm_tpt.x"        /* Common Transport Definitions */
#include "cm_tkns.x"       /* Common Tokens Defines */
#include "cm_lib.x"        /* Common library functions */
#include "cm_sdp.x"        /* Session Description Protocol Defines */
#include "cm_mblk.x"       /* Common Memory Manager Defines */
#include "cm_abnf.x"       /* Common ABNF  Defines */
#include "cm_dns.x"        /* common dns library */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3 
#include  "cm_ss7.x"       /* Common SS7 Structure */
#include  "snt.x"          /* MTP3 Interface Structure */
#endif    /* GCP_PROV_MTP3 */

#include "mgt.x"           /* MGT Interface Structures */
#include "lmg.x"           /* MGCP Layer Management */
#include "mg.x"            /* MGCP Data Structures */
#include "mg_db.x"         /* MGCP ABNF Datbase */
#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */

#ifdef GCP_MGCO
#include "mgco_db.x"       /* MEGACO ABNF Database */
#ifdef GCP_ASN
#include "mgasnwrp.h"         /* Encode/Decode wrappers */
#include "mgasnwrp.x"         /* Encode/Decode wrappers */
#endif /* GCP_ASN */
#endif /* GCP_MGCO */

/*mg002.105: Extern moved from mg.x for g++ compilation issue*/
EXTERN S16 mgAllocEventMem ARGS((
       Ptr       *memPtr,
       Size      memSize
    ));
       
EXTERN S16 mgFreeEventMem ARGS((
       Ptr       memPtr
    ));

#ifdef CM_ABNF_MT_LIB

EXTERN S16 mwrapActvTsk ARGS((Pst *post, Buffer *mBuf));

#define MG_FIND_NODE_FRM_STORELST(_node,_seqNo,_Q)                        \
{                                                                         \
   MgStoreList        *_queue;                                            \
   MgStoreList        *_prv;                                              \
   _queue = _Q->next;                                                     \
   _prv = _Q;                                                             \
   while((_queue) && _queue->nodeIndx != _seqNo)                          \
   {                                                                      \
      _prv = _queue;                                                      \
      _queue = _queue->next;                                              \
   }                                                                      \
   _node = _queue;                                                        \
}
/* local defines, if any */
#define  MG_FREE_DEC_RSRC(_node,_msgBuf,_usrCxt)                  \
{                                                                 \
   if(_node)                                                      \
      MG_FIND_AND_DEL_NODE_FRM_STORELST(_node, _node->nodeIndx,   \
         (&mgCb.decList));                                        \
   if(_usrCxt)                                                    \
   {                                                              \
      mgDeAlloc((Data *)_usrCxt, sizeof(MgGcpCxtToED));           \
      _usrCxt = NULLP;                                            \
   }                                                              \
   if(_msgBuf)                                                    \
   {                                                              \
      mgDeAlloc((Data *)_msgBuf, sizeof(MgStoreDecReq));          \
      _msgBuf = NULLP;                                            \
   }                                                              \
   if(_node)                                                      \
   {                                                              \
      mgDeAlloc((Data *)_node, sizeof(MgStoreList));              \
      _node = NULLP;                                              \
   }                                                              \
}



#define MG_ALLOC_MGCP_ERR_MSG(_errMsg, _mgcpMsg, _cnt)                   \
{                                                                        \
   S16 _ret = ROK;                                                       \
   if ((_errMsg) == NULLP)                                               \
   {                                                                     \
      _ret = mgAllocEventMem((Ptr *)&_errMsg, sizeof(MgMgcpTxn));        \
      if(_ret == ROK)                                                    \
      {                                                                  \
        cmMemcpy((U8 *)&_errMsg->mgLclInfo, (U8*)&_mgcpMsg->mgLclInfo,    \
          sizeof(MgPeerInfo));                                           \
         _errMsg->numMsg = 0;                                            \
      }                                                                  \
   }                                                                     \
   if(_errMsg)                                                           \
   {                                                                     \
      U16    i;                                                          \
      for(i = cnt; i < _mgcpMsg->numMsg; i++)                            \
      {                                                                  \
         _errMsg->mgcpMsg[_errMsg->numMsg++] =                           \
                     _mgcpMsg->mgcpMsg[i];                               \
         _mgcpMsg->mgcpMsg[i] = NULLP;                                   \
      }                                                                  \
   }                                                                     \
}

#define MG_ALLOC_MGCP_ONEERR_MSG(_errMsg, _mgcpMsg, _cnt)                \
{                                                                        \
   S16 _ret = ROK;                                                       \
   if ((_errMsg) == NULLP)                                               \
   {                                                                     \
      _ret = mgAllocEventMem((Ptr *)&_errMsg, sizeof(MgMgcpTxn));        \
      if(_ret == ROK)                                                    \
      {                                                                  \
         U16     cntr;                                                   \
         cmMemcpy((U8 *)&_errMsg->mgLclInfo, (U8*)&_mgcpMsg->mgLclInfo,  \
             sizeof(MgPeerInfo));                                        \
         for(cntr = 0; cntr < _errMsg->numMsg; cntr++)                   \
            _errMsg->mgcpMsg[cntr] = NULLP;                              \
         _errMsg->numMsg = 0;                                            \
      }                                                                  \
   }                                                                     \
   if(_errMsg)                                                           \
   {                                                                     \
      _errMsg->mgcpMsg[_errMsg->numMsg++] = _mgcpMsg->mgcpMsg[_cnt];     \
      _mgcpMsg->mgcpMsg[_cnt] = NULLP;                                   \
   }                                                                     \
}

/*
 * enhanced the following macro to free SDP Tkn Buf
 */
#ifdef CM_SDP_OPAQUE

#define MG_MGCP_FREE_NTH_TXN_ONWARD(_mgcpTxn, _cnt)                      \
{                                                                        \
   U16    i;                                                             \
   for(i= _cnt; i < _mgcpTxn->numMsg; i++)                               \
   {                                                                     \
      mgMgcpFreeAllTkBfs((_mgcpTxn->mgcpMsg[i]));                        \
      mgFreeEventMem(_mgcpTxn->mgcpMsg[i]);                              \
      _mgcpTxn->mgcpMsg[i] = NULLP;                                      \
   }                                                                     \
}

#else

#define MG_MGCP_FREE_NTH_TXN_ONWARD(_mgcpTxn, _cnt)                      \
{                                                                        \
   U16    i;                                                             \
   for(i= _cnt; i < _mgcpTxn->numMsg; i++)                               \
   {                                                                     \
      mgFreeEventMem(_mgcpTxn->mgcpMsg[i]);                                   \
      _mgcpTxn->mgcpMsg[i] = NULLP;                                       \
   }                                                                     \
}

#endif  /* CM_SDP_OPAQUE */

#define MG_ALLOC_MGCO_ERR_MSG(_errMsg, _mgcoMsg, _cnt)                   \
{                                                                        \
   S16 _ret = ROK;                                                       \
   if ((_errMsg) == NULLP)                                               \
   {                                                                     \
      _ret = mgAllocEventMem((Ptr *)&_errMsg, sizeof(MgMgcoMsg));        \
      if(_ret == ROK)                                                    \
      {                                                                  \
          /* copy content */                                             \
        _errMsg->pres.pres =  _mgcoMsg->pres.pres;                       \
        _errMsg->ah.pres.pres = NOTPRSNT;                                \
         cmGetMem((Ptr)&(_errMsg->memCp), _mgcoMsg->mid.len,             \
            (Ptr *)&(_errMsg->mid.val));                                 \
         cmMemcpy((U8 *)_errMsg->mid.val, (U8*)_mgcoMsg->mid.val,        \
            _mgcoMsg->mid.len);                                          \
        _errMsg->body.u.tl.num.val = 0;                                  \
      }                                                                  \
   }                                                                     \
   if(_errMsg)                                                           \
   {                                                                     \
      U16    i;                                                          \
      for(i = cnt; i < _mgcoMsg->body.u.tl.num.val; i++)                 \
      {                                                                  \
         _errMsg->body.u.tl.txns[_errMsg->body.u.tl.num.val++] =         \
                     _mgcoMsg->body.u.tl.txns[i];                        \
         _mgcoMsg->body.u.tl.txns[i] = NULLP;                            \
      }                                                                  \
   }                                                                     \
}


/*
 * enhanced the following macro to free SDP Tkn Buf
 */
#ifdef CM_SDP_OPAQUE

#ifdef GCP_CH
#define MG_MGCO_FREE_NTH_TXN_ONWARD(_mgcoMsg, _cnt)                      \
{                                                                        \
   U16    i;                                                             \
   for(i= cnt; i < _mgcoMsg->body.u.tl.num.val; i++)                     \
   {                                                                     \
      mgMgcoFreeAllTkBfs((_mgcoMsg->body.u.tl.txns[i]));                 \
      mgChFreeCmds(_mgcoMsg,i);                                          \
      mgFreeEventMem(_mgcoMsg->body.u.tl.txns[i]);                       \
      _mgcoMsg->body.u.tl.txns[i] = NULLP;                               \
   }                                                                     \
}
#else
#define MG_MGCO_FREE_NTH_TXN_ONWARD(_mgcoMsg, _cnt)                      \
{                                                                        \
   U16    i;                                                             \
   for(i= cnt; i < _mgcoMsg->body.u.tl.num.val; i++)                     \
   {                                                                     \
      mgMgcoFreeAllTkBfs((_mgcoMsg->body.u.tl.txns[i]));                 \
      mgFreeEventMem(_mgcoMsg->body.u.tl.txns[i]);                       \
      _mgcoMsg->body.u.tl.txns[i] = NULLP;                               \
   }                                                                     \
}

#endif /* GCP_CH */
#else

#ifdef GCP_CH
#define MG_MGCO_FREE_NTH_TXN_ONWARD(_mgcoMsg, _cnt)                      \
{                                                                        \
   U16    i;                                                             \
   for(i= cnt; i < _mgcoMsg->body.u.tl.num.val; i++)                     \
   {                                                                     \
      mgChFreeCmds(_mgcoMsg,i);                                          \
      mgFreeEventMem(_mgcoMsg->body.u.tl.txns[i]);                       \
      _mgcoMsg->body.u.tl.txns[i] = NULLP;                               \
   }                                                                     \
}
#else
#define MG_MGCO_FREE_NTH_TXN_ONWARD(_mgcoMsg, _cnt)                      \
{                                                                        \
   U16    i;                                                             \
   for(i= cnt; i < _mgcoMsg->body.u.tl.num.val; i++)                     \
   {                                                                     \
      mgFreeEventMem(_mgcoMsg->body.u.tl.txns[i]);                       \
      _mgcoMsg->body.u.tl.txns[i] = NULLP;                               \
   }                                                                     \
}

#endif /* GCP_CH */
#endif  /* CM_SDP_OPAQUE */

/* local typedefs, if any */
 
/* local externs, if any */

#ifdef GCP_MGCO
EXTERN  CmAbnfElmDef   mgMgcoAuthHdrMsgDef;
#endif /* GCP_MGCO */

#ifdef GCP_MGCO
PRIVATE Bool mgMgcoChkForMoreMsg ARGS((
Buffer           **mBuf,             /* buffer to be decoded */
MsgLen           numDecBytes       /* no of decoded bytes */
));

PRIVATE S16 mgMgcoDecPduMsgCfm  ARGS((
MgStoreList      *node,             /* node into list */
U32              prot,              /* protocol variant */
Buffer           *mBuf,             /* buffer to be decoded */
MsgLen           numDecBytes,       /* no of decoded bytes */
CmAbnfErr        *err,              /* error */
MgGcpCxtToED     *usrCxt            /* user context */
));

PRIVATE S16 mgMgcoEncPduMsgCfm ARGS((
MgStoreEncReq    *txnBuf,           /* stored encode req */
Buffer           *mBuf,             /* buffer to be decoded */
CmAbnfErr        *err,              /* error */
U16               msgNo            /* mesaage no */
));

#endif /* GCP_MGCO */

#ifdef GCP_MGCP
PRIVATE Bool mgMgcpChkForMoreMsg  ARGS((
Buffer           **mBuf,             /* buffer to be decoded */
MsgLen           numDecBytes        /* no of decoded bytes */
));

PRIVATE S16 mgMgcpDecPduMsgCfm ARGS((
MgStoreList      *node,             /* List node */
U32              prot,              /* protocol variant */
Buffer           *mBuf,             /* buffer to be decoded */
MsgLen           numDecBytes,       /* no of decoded bytes */
CmAbnfErr        *err,              /* error */
MgGcpCxtToED     *usrCxt            /* user context */
));

PRIVATE S16 mgMgcpPrcEncCmd  ARGS((  
MgStoreEncReq    *txnBuf,              /* Stored encode req */
U16               cnt,              /* no of msg in txn to be processed */
MgPeerCb         *peer,             /* peer control block */
MgSSAPCb         *ssap,             /* SSAP control block */
MgMgcpTxn        **discardTxn       /* discard txn */
));

PRIVATE S16 mgMgcpEncPduMsgCfm  ARGS((
MgStoreEncReq    *txnBuf,           /* stored encode req */
Buffer           *mBuf,             /* buffer to be decoded */
CmAbnfErr        *err,              /* error */
Ptr              usrCxt                /* user context */
));

#endif /* GCP_MGCP */



PRIVATE S16 mgPstDecReq   ARGS((
U8               encodingScheme, 
U32              prot,              /* protocol variant */
Ptr              event,             /* event structure */
U32              txnIndx,           /* transaction index */
Buffer           *mBuf,             /* Buffer */
CmAbnfElmDef     *elmDef,           /* elmDef */   
MgGcpCxtToED     *usrCxt,           /* user context */
CmMemListCp      *memCp,            /* mem list cp */
MgStoreList      *node ,             /* node */
U16              elmDef1            /* elmDef */
));


PRIVATE S16 mgPstEncReq   ARGS((
U8               encodingScheme, 
U32              prot,              /* protocol variant */
Ptr              event,             /* event structure */
U32              txnIndx,           /* transaction index */
Buffer           *mBuf,             /* Buffer */
CmAbnfElmDef     *elmDef,           /* elmDef */   
MgGcpCxtToED     *usrCxt,           /* user context */
Mem              *mem,              /* mem list cp */
MgStoreList      *node,             /* node */
U8               source,            /* Source; Internal or User ??*/
Bool             strtTmr ,           /* whether to start timer */
U16              elmDef1            /* elmDef */
));


PRIVATE S16 cmPkMedEncReq  ARGS((
U8             encodingScheme,
Pst            *pst,           /* post structure */
U32            protVar,        /* protocol variant */
U8             *event,         /* event structure */
U32            txnIndx,           /* transaction index */
Buffer         *encBuf,          /* encoded buffer */
CmAbnfElmDef   *elmDef,        /* root of database tree */
U16            elmDef1,         /* elmDef */
Mem            *mem,           /* memory region/pool */ 
Ptr            usrCxt          /* user context */
));

PRIVATE S16 cmPkMedDecReq  ARGS((
U8             encodingScheme,
Pst            *pst,           /* post structure */
U32            protVar,        /* protocol variant */
U8             *event,         /* event structure */
Buffer         *decBuf,        /* encoded buffer */
CmAbnfElmDef   *elmDef,        /* root of database tree */
U16            elmDef1,        /* root of database tree */
CmMemListCp    *memCp,         /* memory region/pool */ 
Ptr            usrCxt          /* user context */
));


/* forward references */

/* PRIVATE variable declaration */

/* private variable declaration */


/*
*
*       Fun:   mgDfrdShutDwn
*
*       Desc:  This function performs shutdown and send shutdown cfm.
*
*       Ret:   void
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PUBLIC Void mgDfrdShutDwn
(
void
)
#else
PUBLIC Void mgDfrdShutDwn()
#endif
{
   MgMngmt    cntrl;
   TRC2(mgDfrdShutDwn)
   /* Copy Header info */
   cmMemset((U8 *)&cntrl, 0, sizeof(MgMngmt));
   cmMemcpy((U8 *)&cntrl.hdr, (U8 *)&mgCb.shutDwnCfm.dfrdHdr, 
      sizeof(Header));
#ifdef ZG
   mgZgShutDown();
#else
   mgShutdown();
#endif /* ZG */      
   /* send confirm */
   mgSendLmCfm(TCNTRL, LCM_PRIM_OK, LCM_REASON_NOT_APPL,
               &mgCb.shutDwnCfm.dfrdPst, &cntrl);        
   RETVOID;
} /* mgDfrdShutDwn */


/*
*
*       Fun:   mgFreeEncRsrc
*
*       Desc:  This function frees encode resource.
*
*       Ret:   void
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PUBLIC Void mgFreeEncRsrc
(
MgStoreList    **node,              /* node in store list */
MgStoreEncReq  **txnBuf,            /* stored encode req */
Ptr            *usrCxt,             /* user cxt */
U16            cnt,                 /* no of txn in mgco message */
U32            prot,                /* protocol */
Bool           freeTxn              /* whether to free MGCO txn */
)
#else
PUBLIC Void mgFreeEncRsrc(node, txnBuf, usrCxt, cnt, prot, freeTxn)
MgStoreList    **node;              /* node in store list */
MgStoreEncReq  **txnBuf;            /* stored encode req */
Ptr            *usrCxt;             /* user cxt */
U16            cnt;                 /* no of txn in mgco message */
U32            prot;                /* protocol */
Bool           freeTxn;             /* whether to free MGCO txn */
#endif
{
   U16         loop;                /* counter */
   TRC2(mgFreeEncRsrc)
   /* free user context */
   if(usrCxt && (*usrCxt))
   {
      mgDeAlloc(((Data *)*usrCxt), sizeof(MgGcpCxtToED));
      *usrCxt = NULLP;
   }
   /* find out node from list*/
   if(node && (*node))
   {
      MG_FIND_AND_DEL_NODE_FRM_STORELST((*node), ((*node)->nodeIndx), 
         (&mgCb.encList));
   }
   /* free node */
   if(node && (*node))
   {
      mgDeAlloc(((Data *)*node), sizeof(MgStoreList));
      *node = NULLP;
   }
   /* free stored encode buffer */ 
   if(txnBuf && (*txnBuf) && (((*txnBuf)->encBuf)))
   {             
      if(prot == CM_ABNF_PROT_MEGACO_H248)
      {
         /* free one extra for Auth header part */
         for(loop = 0; loop < cnt +1; loop++)
         {
            if((*txnBuf)->encBuf[loop]->buf != NULLP)
            {
               mgPutMsg((*txnBuf)->encBuf[loop]->buf);
               (*txnBuf)->encBuf[loop]->buf = NULLP;
            }
            if((*txnBuf)->encBuf[loop] != NULLP)
            {
               mgDeAlloc((Data *)((*txnBuf)->encBuf[loop]), 
                  sizeof(MgEncBuffer));
               (*txnBuf)->encBuf[loop] = NULLP;
            }
         }
         mgDeAlloc((Data *)((*txnBuf)->encBuf), 
            ((cnt +1) * sizeof(MgEncBuffer *)));
         (*txnBuf)->encBuf = NULLP;
      }
      else
      {
         for(loop = 0; loop < cnt; loop++)
         {
            if((*txnBuf)->encBuf[loop]->buf != NULLP)
            {
               mgPutMsg((*txnBuf)->encBuf[loop]->buf);
               (*txnBuf)->encBuf[loop]->buf = NULLP;
            }
            if((*txnBuf)->encBuf[loop] != NULLP)
            {
               mgDeAlloc((Data *)((*txnBuf)->encBuf[loop]), 
                  sizeof(MgEncBuffer));
               (*txnBuf)->encBuf[loop] = NULLP;
            }
         }
         mgDeAlloc((Data *)((*txnBuf)->encBuf), 
            ((cnt)  * sizeof(MgEncBuffer *)));
         (*txnBuf)->encBuf = NULLP;
      }
   }
   /* free event structure */
   if((freeTxn)&& (txnBuf) && (*txnBuf)&&((*txnBuf)->event))
   {
      if(prot == CM_ABNF_PROT_MEGACO_H248)
      {
#ifdef GCP_MGCO
         MgMgcoMsg *mgcoMsg = (MgMgcoMsg*)((*txnBuf)->event);

         MG_FREE_MGCO_EVNT_MEM(mgcoMsg, TRUE);
         (*txnBuf)->event = NULLP;
#endif /* GCP_MGCO */
      }
      else
      {
#ifdef GCP_MGCP
         MgMgcpTxn *mgcpTxn = (MgMgcpTxn*)((*txnBuf)->event);

         MG_FREE_MGCP_EVNT_MEM(mgcpTxn, TRUE);
         (*txnBuf)->event = NULLP;
#endif /* GCP_MGCP */
      }
   }
   /* free encode request buffer */
   if(txnBuf && (*txnBuf))
   {
      if((*txnBuf)->delPeer == TRUE)
      {
         MgPeerCb    *peer;
         peer = MG_GET_PEER_FRM_PEERID((*txnBuf)->peerId);
         if(peer != NULLP)
         {
#ifdef ZG_DFTHA
            /* only master should delete peer */
            if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG_DFTHA */
            {
               mgDeletePeer(peer, LMG_EVENT_PEER_REMOVED, LMG_CAUSE_RSIP_NAK, 
                  FALSE);
            }
#ifdef ZG_DFTHA
            else
            {
                  /* send reverse update to delete peer */
               ZgRvUpdInfo   updInfo;

               MG_FILL_RVUPD_DEL_PEER(updInfo, peer, LMG_EVENT_PEER_REMOVED,
                                    LMG_CAUSE_RSIP_NAK,FALSE);
               /* Generate Reverse Update */
               zgReverseUpd(&updInfo, peer->accessInfo.peerId, MG_QUEUE_NONE);  
            }
#endif /* ZG_DFTHA */
         }
      }
      mgDeAlloc((Data *)(*txnBuf), sizeof(MgStoreEncReq));
      *txnBuf = NULLP;
   } 
   RETVOID;
} /* mgFreeEncRsrc*/

#ifdef GCP_MGCO

/*
*
*       Fun:   mgMgcoChkForMoreMsg
*
*       Desc:  This function check for more MEGACO message in mBuf. 
*
*       Ret:   TRUE -> more MEGACO message is present in mBuf.
*              FALSE -> no more message.
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PRIVATE Bool mgMgcoChkForMoreMsg
(
Buffer           **mBuf,             /* buffer to be decoded */
MsgLen           numDecBytes       /* no of decoded bytes */
)
#else
PRIVATE Bool mgMgcoChkForMoreMsg(mBuf, numDecBytes)
Buffer           **mBuf;             /* buffer to be decoded */
MsgLen           numDecBytes;       /* no of decoded bytes */
#endif
{
   Buffer         *newBuf;          /* Mgcp Message */
   MsgLen         len;              /* message length */
   S16            ret;              /* returned value */


   TRC2(mgMgcoChkForMoreMsg)

   newBuf = NULLP;

#if (ERRCLS & ERRCLS_DEBUG)
   if(*mBuf == NULLP) 
         MGLOGERROR( ERRCLS_DEBUG, EMG045, (ErrVal)0, 0,
         "mgMgcoChkForMoreMsg: parameter NULLP \n");
#endif /* ERRCLS_DEBUG */

   /* initialize len */
   len = 0;
   /* find len of mBuf */
   ret = SFndLenMsg(*mBuf, &len);
   if(ret == RFAILED)
      RETVALUE(FALSE);
   if(len > (numDecBytes + 1))
   {
      /* Segment mBuf into two part */
      if(SSegMsg(*mBuf, numDecBytes-1, &newBuf) != ROK)
         RETVALUE(FALSE);
      /* newBuf contains more Megaco message..now swap buffer */
      mgPutMsg(*mBuf);
      *mBuf = newBuf;
      RETVALUE(TRUE);
   }
   RETVALUE(FALSE);

} /* mgMgcoChkForMoreMsg */

   

/*
*
*       Fun:   mgMgcoDecPduMsgCfm
*
*       Desc:  This function process decode cfm (for MGCO protocol) rcved 
*       from ED instance.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcoDecPduMsgCfm
(
MgStoreList      *node,             /* node into list */
U32              prot,              /* protocol variant */
Buffer           *mBuf,             /* buffer to be decoded */
MsgLen           numDecBytes,       /* no of decoded bytes */
CmAbnfErr        *err,              /* error */
MgGcpCxtToED     *usrCxt            /* user context */
)
#else
PRIVATE S16 mgMgcoDecPduMsgCfm(node, prot, mBuf, numDecBytes, err, usrCxt)
MgStoreList      *node;             /* node into list */
U32              prot;              /* protocol variant */
Buffer           *mBuf;             /* buffer to be decoded */
MsgLen           numDecBytes;       /* no of decoded bytes */
CmAbnfErr        *err;              /* error */
MgGcpCxtToED     *usrCxt;           /* user context */
#endif
{
   MgMgcoMsg      *msg;             /* megaco mesasage */
   MgTptSrvr      *srvr;            /* server control block */
   CmTptAddr      srcAddr;          /* source address */
   MgMgcoTxn      *txn;             /* megaco transaction */
   CmAbnfElmDef   *elmDef;          /* root of database tree*/
   U16            numMsg;           /* no. of message */
   Bool           moreMsg;          /* whether more msg to decode */
   MgMgcoMsg      *newMsg;          /* megaco message */
   MgStoreDecReq  *msgBuf;          /* stored decode req */
   S16            ret;              /* returned value */
   U16            cnt;              /* counter */
   MgMgcoMsg       *errMsg;            /* error message */
#if   (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
   MgcoTptInfo    mgcoTptInfo;       /* Megaco Transport Information */
#endif   /* GCP_PROV_SCTP || GCP_PROV_MTP3 */   
   U8              encodingScheme;  /*MAH_TODO*/

   TRC2(mgMgcoDecPduMsgCfm)
   errMsg = NULLP;
   srvr = NULLP;

#ifdef    GCP_PROV_SCTP
            if(msgBuf->assoc)
               {
                  mgcoTptInfo.tptType  = LMG_TPT_SCTP;
                  mgcoTptInfo.assoc    = msgBuf->assoc;
               }    
               
#endif    /* GCP_PROV_SCTP */
#ifdef    GCP_PROV_MTP3
            if(msgBuf->mgMtpInfo.clgAddr)
               {
                  mgcoTptInfo.tptType  = LMG_TPT_MTP3;
                  mgcoTptInfo.mgMtpInfo= msgBuf->mgMtpInfo;
               }  
#endif    /* GCP_PROV_MTP3 */              
 
#if (ERRCLS & ERRCLS_DEBUG)
   if((mBuf == NULLP) || (msgBuf == NULLP) ||(err == NULLP) ||(usrCxt == NULLP))
         MGLOGERROR( ERRCLS_DEBUG, EMG046, (ErrVal)0, 0,
         "mgMgcoDecPduMsgCfm: parameter NULLP \n");
#endif /* ERRCLS_DEBUG */

   msgBuf = (MgStoreDecReq *)(node->info);


#ifdef    GCP_PROV_SCTP 
   if (NULLP == msgBuf->assoc)
#endif   /* GCP_PROV_SCTP */   
      /* get server control block and src address */
      MG_GET_SRVRCB(srvr,(msgBuf->suConnId), msgBuf->tsap);


   cmMemcpy((U8 *)&srcAddr, (U8 *)&msgBuf->srcAddr, sizeof(CmTptAddr));
   msg = (MgMgcoMsg *)(msgBuf->event);

   if(err->code == CM_ABNF_ERR_NONE)
   {
      /* Check whether mBuf needs to be further deocded */
      moreMsg = mgMgcoChkForMoreMsg(&mBuf, numDecBytes);

      /* added support for error descriptor in msgBody */
      if (msg->body.type.val == MGT_TXN)
      {
         /* added range check */
         if ((msg->body.u.tl.num.val + 1) > MGT_MAX_TXNS)
         {
#ifdef DEBUGP
            MGDBGP (DBGMASK_LI,(mgCb.init.prntBuf,
                                "\nError - Limit Reached!\n"
                                "Increase the val of MGT_MAX_TXNS\n"));
#endif /* DEBUGP */
            RETVALUE(RFAILED);
         }

         msg->body.u.tl.num.pres = PRSNT_NODEF;
         numMsg = msg->body.u.tl.num.val;
         /* increment no of message  */
         if(msg->body.u.tl.txns[numMsg] != NULLP)
            msg->body.u.tl.num.val++;

         numMsg = msg->body.u.tl.num.val;
      }

      /* Check if more msg is there in mBuf; */
      if(moreMsg)
      {
         if(msg->body.u.tl.num.val > 0)
         {
            /* allocate memory for new msg */
            ret = mgAllocEventMem((Ptr *)&newMsg, sizeof(MgMgcoMsg));
            /* copy header content */
            MG_MGCO_COPY_EVNT_STRUCT(msg, newMsg);
            for(cnt = 0; cnt < numMsg; cnt ++)
            {
               newMsg->body.u.tl.num.pres = PRSNT_NODEF;
               newMsg->body.u.tl.txns[cnt] = msg->body.u.tl.txns[cnt];
               msg->body.u.tl.txns[cnt] = NULLP;
            }
            newMsg->body.u.tl.num.val = numMsg;
            newMsg->body.u.tl.num.pres = PRSNT_NODEF;
            msg->body.u.tl.num.val = 0;


            

            /* process txn */
            ret = mgPrcMgcoTxnInd(
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                                 & mgcoTptInfo,
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
                                  msgBuf->tsap,
                                  srvr,
                                  &srcAddr,
                                  NULLP,
                                  newMsg,
                                  NULLP);
         }
         /* get buffer for next msg */
         ret = mgAllocEventMem(
                    (Ptr *)&msg->body.u.tl.txns[msg->body.u.tl.num.val], 
                    sizeof(MgMgcoTxn));
         if(ret != ROK)
         {
            /* Free memory */
            MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
            RETVALUE(RFAILED);
         }
         txn = msg->body.u.tl.txns[msg->body.u.tl.num.val];

         ((MgGcpCxtToED *)usrCxt)->thisMsgNo = msg->body.u.tl.num.val+1;
         elmDef = &mgMgcoTxnDef;
         if(srvr)
          encodingScheme = srvr->encodingScheme;
         /* now call fn which will post msg to ED instances */
#ifdef GCP_VER_1_5
         if (msg->ver.val == 2)
          {
              prot = CM_ABNF_PROT_MEGACO_H248_V2;   
          } 
          else 
          {
              prot = CM_ABNF_PROT_MEGACO_H248;   
          }
#endif
         if (encodingScheme == LMG_ENCODE_BIN)
         {
#ifdef GCP_ASN           
          ret = mgPstDecReq(encodingScheme ,prot, msg, msg->body.u.tl.num.val,
                mBuf, NULLP, usrCxt, &txn->memCp, node,MGED_TXN_DEC);
#endif
         }
         else
         {
           ret = mgPstDecReq(encodingScheme ,prot, &(txn->type),msg->body.u.tl.num.val, 
                mBuf, elmDef, usrCxt, &txn->memCp, node,0/*DUMMY*/);
         }
         if(ret == ROK)
         {
            RETVALUE(ROKDNA);
         }
         else
         {
            /* Free memory */
            MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
            RETVALUE(ret);
         }
      }
      else
      {
         /* process Txn ..*/ 
         ret = mgPrcMgcoTxnInd(
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                              & mgcoTptInfo,
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
                               msgBuf->tsap,
                               srvr,
                               &srcAddr,
                               NULLP,
                               msg,
                               NULLP);
         RETVALUE(ROK);
      }
   }
   else
   {
      /* error case */
      /* send error response to Peer */

      /* added support for error descriptor in msgBody */
      if ((msg->body.type.pres == PRSNT_NODEF)
                  &&
          (msg->body.type.val == MGT_TXN))
      {

         /*
          * If the incoming msg whose decoding failed was a transaction
          * request, then send the error response with EITHER, 1) the same
          * transaction id as in the transaction request if transaction id
          * could be parsed and decoded successfully OR, 2) transaction id
          * as 0 if it could not be parsed. Otherwise, if the incoming msg
          * was a transaction reply, transaction pending or a transaction
          * response ack, do NOT send any error response.
          */

         /* send error response to peer and process the decoded txns */
         if (msg->body.u.tl.txns[msg->body.u.tl.num.val])
         {
            if ((msg->body.u.tl.txns[msg->body.u.tl.num.val]->type.pres
                          == PRSNT_NODEF)
                             &&
                (msg->body.u.tl.txns[msg->body.u.tl.num.val]->type.val
                          == MGT_TXNREQ))
            {

               /* mg007.105: added code to retrieve error statistics */
               MG_UPD_MGCO_PEER_ERROR_STS(MGT_MGCO_RSP_CODE_BAD_REQ, FALSE, NULLP, msg);

               if ((msg->body.u.tl.txns[msg->body.u.tl.num.val]->u.req\
                       .pres.pres == PRSNT_NODEF) &&
                   (msg->body.u.tl.txns[msg->body.u.tl.num.val]->u.req\
                       .transId.pres == PRSNT_NODEF))
               {
                  mgMgcoSendErrRsp(msgBuf->tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                                  & mgcoTptInfo,
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
                                   srvr,
                                   &srcAddr,
                                   MGT_MGCO_RSP_CODE_BAD_REQ,
                                   errMsg,
                                   msg->body.u.tl.txns[msg->body\
                                           .u.tl.num.val]->u.req.transId.val);
               }
               else
               {
                  mgMgcoSendErrRsp(msgBuf->tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                                  & mgcoTptInfo,
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
                                   srvr,
                                   &srcAddr,
                                   MGT_MGCO_RSP_CODE_BAD_REQ,
                                   errMsg,
                                   MGT_TXNID_NULL);
               }
            }

            /* Free allocated msg for the wrongly decoded msg */
            /*
             * now freeing the SDP Tkn Buf also
             */
#ifdef CM_SDP_OPAQUE
            mgMgcoFreeAllTkBfs((msg->body.u.tl.txns[msg->body.u.tl.num.val]));
#endif  /* CM_SDP_OPAQUE */
#ifdef GCP_CH
            mgChFreeCmds(msg, msg->body.u.tl.num.val);
#endif /* GCP_CH  */
            mgFreeEventMem((Ptr) msg->body.u.tl.txns[msg->body.u.tl.num.val]);
            msg->body.u.tl.txns[msg->body.u.tl.num.val] = NULLP;
         }
      }
      else /* else if it decode failure was in the Hdr part */
      {    /*            just send errDesc with transactionId as 0     */

         /* mg007.105: added code to retrieve error statistics */
         MG_UPD_MGCO_PEER_ERROR_STS(MGT_MGCO_RSP_CODE_BAD_REQ, FALSE, NULLP, msg);

         mgMgcoSendErrRsp(msgBuf->tsap,
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
                         & mgcoTptInfo
#endif    /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
                          srvr,
                          &srcAddr,
                          MGT_MGCO_RSP_CODE_BAD_REQ,
                          errMsg,
                          MGT_TXNID_NULL);
      }

      /* Free memory */
      MG_FREE_MGCO_EVNT_MEM(msg, TRUE);
   }
   RETVALUE(ROK);
} /* mgMgcoDecPduMsgCfm */



/*
*
*       Fun:   mgMgcoEncPduMsgCfm
*
*       Desc:  This function process encode cfm (Megaco)rcved from ED instance.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcoEncPduMsgCfm
(
MgStoreEncReq    *txnBuf,           /* stored encode req */
Buffer           *mBuf,             /* buffer to be decoded */
CmAbnfErr        *err,              /* error */
U16              msgNo              /* message no */
)
#else
PRIVATE S16 mgMgcoEncPduMsgCfm(txnBuf, mBuf, err, msgNo)
MgStoreEncReq    *txnBuf;           /* stored encode req */
Buffer           *mBuf;             /* buffer to be decoded */
CmAbnfErr        *err;              /* error */
U16              msgNo;             /* message no */
#endif
{
   MgMgcoMsg      *mgcoMsg;         /* MGCP txn */
   MgMgcoTxn      *mgcoTxn;         /* MEGACO txn */
   MgPeerCb       *peer;            /* peer cb */
   MgSSAPCb       *ssap;            /* ssap cb */
   MgTptSrvr      *srvr;            /* srvr */
   MgTransId      trId;             /* transaction id */
   MgTxTransIdEnt *txCb;            /* Transaction Control Block */
   Bool           txnSend;         

   TRC2(mgMgcoEncPduMsgCfm)

   srvr = NULLP;

#if (ERRCLS & ERRCLS_DEBUG)
   if((mBuf == NULLP) || (txnBuf == NULLP) ||(err == NULLP))
         MGLOGERROR( ERRCLS_DEBUG, EMG047, (ErrVal)0, 0,
         "mgMgcoEncPduMsgCfm: parameter NULLP \n");

#endif /* ERRCLS_DEBUG */

   mgcoMsg = (MgMgcoMsg *)(txnBuf->event);
   /* msgNo shouldn't be zero..as "0" is only for header part..and in that
    * case this fn shall not be called */
   if(msgNo < 1)
      RETVALUE(RFAILED);
   mgcoTxn = mgcoMsg->body.u.tl.txns[msgNo-1];

   /* Get Transaction Id from the Event Structure */
   MG_GET_TRANSID(mgcoTxn, trId);

   peer = MG_GET_PEER_FRM_PEERID(txnBuf->peerId);

   if(peer)
      ssap = peer->ssap;
   else
      ssap = mgCb.sSAPLst[txnBuf->spId];


   if(txnBuf->source == MG_USER)
   {
      Bool          tcpConnInit;

      tcpConnInit = FALSE;

      if(peer == NULLP)
         RETVALUE(RFAILED);

      if(ssap == NULLP)
         RETVALUE(RFAILED);
         

#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
      if ((peer->accessInfo.transportType != LMG_TPT_SCTP) && 
         (peer->accessInfo.transportType != LMG_TPT_MTP3))
      {
#endif   /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */
         /* Get Server on which the message is to be sent */
         if ((srvr = mgGetSendSrvr(ssap, peer)) == NULLP)
         {
            /* for UDP transmit server should always be available;
               * Otherwise for TCP case, we should be here only when
               * Multi-threaded ED is tightly coupled with the GCP layer
               * i.e. MT is not used for encoding/decoding. For TCP cases
               * the TCP connection is always initiated in mgPrcMgcoTxnReq()
               * function
               */
            if (peer->accessInfo.transportType != LMG_TPT_TCP)
            {
               RETVALUE(RFAILED);
            }
            else
            {
               /* Now establish TCP connection here */
               tcpConnInit = TRUE; 
            }
         }
#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
      }
      else     /* Do not Remove the braces */   
   
#ifdef    GCP_PROV_MTP3
   if (peer->accessInfo.transportType != LMG_TPT_MTP3)
#endif    /* GCP_PROV_MTP3 */
      {
         /* Now establish the SCTP association here */
         if (NULLP == peer->assocCb)
            tcpConnInit = TRUE; 
      }
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */


      /* If this is response ..process it */
      switch(mgcoTxn->type.val)
      {
         case MGT_TXNPEND:
         case MGT_TXNREPLY:
         {
            MgRxTransIdEnt  *rxCb;     /* Response Transaction Control Block */
            if ((cmHashListFind(&(peer->inTransLst), 
                  (U8 *)&trId, MG_TRANSID_LEN,
                     MG_HASH_SEQNMB_DEF, (PTR *)&rxCb)) != ROK)
            {
               RETVALUE(ROKDNA);
            }
            
            if (
#ifdef    GCP_PROV_MTP3
                (peer->accessInfo.transportType != LMG_TPT_MTP3) &&
#endif   /* GCP_PROV_MTP3 */
#ifdef    GCP_PROV_SCTP
                (peer->accessInfo.transportType != LMG_TPT_SCTP) &&
#endif    /* GCP_PROV_SCTP */
                (srvr  == NULLP))
               {
                  RETVALUE(RFAILED);
               }

            /* Increment refrence cntr for mBuf and store into rxCb..*/
            if ((SAddMsgRef (mBuf, txnBuf->tsap->tsapCfg.memId.region, 
                             txnBuf->tsap->tsapCfg.memId.pool,
                             &(rxCb->mBuf))) != ROK)
            {
               RETVALUE(RFAILED);
            }      

#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
            if(rxCb != NULLP)
            {
               zgRtUpd(ZG_CBTYPE_TXN_RX, (Ptr)rxCb, CMPFTHA_UPDTYPE_NORMAL,
                       CMPFTHA_ACTN_MOD);
               zgUpdPeer();
            }
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */

            mgTransmitMgcoMsg(peer,
#ifdef    GCP_PROV_SCTP
                              txnBuf->assoc,
                              txnBuf->ctxId,
#endif    /* GCP_PROV_SCTP */
                              srvr,
                              &(rxCb->tptAddr),
                              mBuf,
                              NULLP);

            MG_UPD_MGCO_PEER_TX_STS(mgcoTxn->type.val, peer->peerSts);
            /* If 30 sec timer is not enabled. Remove transaction after 
             * transmission */
            if ((mgcoTxn->type.val == MGT_TXNREPLY) && (rxCb != NULLP) && 
               (rxCb->tmr[MG_30SEC_TMR - MG_INTXN_TMR_BASE].tmrEvnt == 
                  TMR_NONE))
            {
               /* Free resources associated with transaction */
               mgDeAllocRxTransIdEnt(rxCb->peer, rxCb, TRUE);
               rxCb = NULLP;
            }
            RETVALUE(ROK);
         }
         break;

         case  MGT_TXNRSPACK:
         {
            CmTptAddr     tptAddr;
            
            if (
#ifdef    GCP_PROV_MTP3
                (peer->accessInfo.transportType != LMG_TPT_MTP3) &&
#endif   /* GCP_PROV_MTP3 */

#ifdef    GCP_PROV_SCTP
                (peer->accessInfo.transportType != LMG_TPT_SCTP) &&
#endif    /* GCP_PROV_SCTP */
                (srvr  == NULLP))
               {
                  RETVALUE(RFAILED);
               }

            tptAddr.type = CM_TPTADDR_NOTPRSNT;

            mgTransmitMgcoMsg(peer,
#ifdef    GCP_PROV_SCTP
                              txnBuf->assoc,
                              txnBuf->ctxId,
#endif    /* GCP_PROV_SCTP */
                              srvr,
                              &(tptAddr),
                              mBuf,
                              NULLP);

            MG_UPD_MGCO_PEER_TX_STS(mgcoTxn->type.val, peer->peerSts);
            RETVALUE(ROK);
         }
         break;
         case  MGT_TXNREQ:
         {
            CmTptAddr     tptAddr;
            Buffer        *newBuf;

            
            txnSend = FALSE;
            /* 
            * Process Outgoing Transaction. This function starts transaction
            * timers if necessary or it queues the message (depending on peer
            * state)
            */


            txnSend = FALSE;
            tptAddr.type = CM_TPTADDR_NOTPRSNT;

            if ((txCb = mgPrcOutGoingTxn(trId, mgcoTxn->type.val,
                                         MG_NONE, FALSE, &tptAddr,
                                         ssap, peer,
#ifdef    GCP_PROV_SCTP
                                         txnBuf->assoc,
#endif    /* GCP_PROV_SCTP */
                                         srvr, (Void *)mBuf, &txnSend)) 
                   == NULLP)
            {
               MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_SMEM_ALLOC_FAIL,\
                                    mgCb.init.region, mgCb.init.pool);
               RETVALUE(RFAILED);
            }

            /* Establish TCP connection if required 
            * On the MG side, if it is the first message, the TCP 
            * connection is to be initiated before  sending the message 
            */
#ifdef ZG_DFTHA
            if(((zgChkCRsetStatus()) == TRUE))
#endif /* ZG */
            {
               if ((mgCb.genCfg.entType == LMG_ENT_GW) &&
                   (peer->state == LMG_PEER_STATE_AWAIT_REG) &&
                   (peer->accessInfo.transportType != LMG_TPT_UDP) &&
                   (tcpConnInit == TRUE))
               {
                  if (peer->accessInfo.transportType == LMG_TPT_TCP)
                  {
                     srvr = NULLP;
                     MG_INIT_TCP_CONN(peer, srvr); 
                  }
#ifdef    GCP_PROV_SCTP
                  else if (peer->accessInfo.transportType == LMG_TPT_SCTP)
                  {
                     S16      retVal;

                     /*
                      * Since this is a user initiated request, set the
                      * appropriate flag;
                      * However, this flag need NOT be set in the Assoc Request
                      * made from mp_peer.c funtions since those Assoc Reqs are
                      * stack generated;
                      */

                     peer->accessInfo.peerflg |= MG_USER_INITIATED_REG;

                     MG_INIT_SCTP_ASSOC(peer, retVal); 
                  }
#endif    /* GCP_PROV_SCTP */

                  /* In tightly coupling case, if disc ind is received, we
                   * are not able to send the txn, err ind has already been
                   * sent to service user. Return from here.
                   */
                  if ((peer->state == LMG_PEER_STATE_NULL) || 
                      (peer->state == LMG_PEER_STATE_AWAIT_REG))
                  {
                     RETVALUE(ROK);
                  }
               }
            }

            /* Increment refrence cntr for mBuf and store into rxCb..*/
            if ((SAddMsgRef (mBuf, txnBuf->tsap->tsapCfg.memId.region, 
                             txnBuf->tsap->tsapCfg.memId.pool,
                             &(newBuf))) != ROK)
            {
               RETVALUE(RFAILED);
            }      

            if(txnSend == TRUE)
            {
               mgTransmitMgcoMsg(peer,
#ifdef    GCP_PROV_SCTP
                                 txnBuf->assoc,
                                 txnBuf->ctxId,
#endif    /* GCP_PROV_SCTP */
                                 srvr,
                                 &tptAddr,
                                 newBuf,
                                 NULLP);
               MG_UPD_MGCO_PEER_TX_STS(mgcoTxn->type.val, peer->peerSts);
            }
            /* free newBuf */
            else
            {
               if (newBuf != NULLP)
                  mgPutMsg(newBuf);
            } 
            RETVALUE(ROK);
         }
         break;
      }
   }
   RETVALUE(ROK);
} /* mgMgcoEncPduMsgCfm */


#endif /* GCP_MGCO */

#ifdef GCP_MGCP

/*
*
*       Fun:   mgMgcpChkForMoreMsg
*
*       Desc:  This function check for more MGCP message in mBuf. 
*
*       Ret:   TRUE -> more MGCP message is present in mBuf.
*              FALSE -> no more message.
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PRIVATE Bool mgMgcpChkForMoreMsg
(
Buffer           **mBuf,             /* buffer to be decoded */
MsgLen           numDecBytes         /* no of decoded bytes */
)
#else
PRIVATE Bool mgMgcpChkForMoreMsg(mBuf, numDecBytes)
Buffer           **mBuf;             /* buffer to be decoded */
MsgLen           numDecBytes;        /* no of decoded bytes */
#endif
{
   Buffer         *newBuf;          /* Mgcp Message */
   MsgLen         len;              /* message length */
   Data           data;             /* data */
   S16            ret;              /* returned value */


   TRC2(mgMgcpChkForMoreMsg)

#if (ERRCLS & ERRCLS_DEBUG)
   if(*mBuf == NULLP) 
         MGLOGERROR( ERRCLS_DEBUG, EMG048, (ErrVal)0, 0,
         "mgMgcpChkForMoreMsg: parameter NULLP \n");
#endif /* ERRCLS_DEBUG */

   /* initialize len */
   len = 0;
   /* find len of mBuf */
   ret = SFndLenMsg(*mBuf, &len);
   if(ret == RFAILED)
      RETVALUE(FALSE);
   if(len > (numDecBytes + 1))
   {
      /* Segment mBuf into two part */
      if(SSegMsg(*mBuf, numDecBytes, &newBuf) != ROK)
         RETVALUE(FALSE);
      /* now newBuf contains the portion which has more MGCP messages , take all
       * the new line and seperator from newBuf */
      do
      {
         ret = SRemPreMsg(&data, newBuf);
      }while(((data == '.') || (data == '\n'))&& (ret == ROK));
      if(ret == ROK)
      {
         /* Add last data into newBuf and swap buffers */
         SAddPreMsg(data, newBuf);
         /* free allready decoded buffer */
         mgPutMsg(*mBuf);
         *mBuf = newBuf;
         RETVALUE(TRUE);
      }
      else
      {
         /* no more valid MGCP message */
         mgPutMsg(newBuf);
         RETVALUE(FALSE);
      }
   }
   RETVALUE(FALSE);

} /* mgMgcpChkForMoreMsg */


/*
*
*       Fun:   mgMgcpDecPduMsgCfm
*
*       Desc:  This function process decode cfm (for MGCP protocol) rcved 
*       from ED instance.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcpDecPduMsgCfm
(
MgStoreList      *node,             /* List node */
U32              prot,              /* protocol variant */
Buffer           *mBuf,             /* buffer to be decoded */
MsgLen           numDecBytes,       /* no of decoded bytes */
CmAbnfErr        *err,              /* error */
MgGcpCxtToED     *usrCxt            /* user context */
)
#else
PRIVATE S16 mgMgcpDecPduMsgCfm(node, prot, mBuf, numDecBytes, err, usrCxt)
MgStoreList      *node;             /* List node */
U32              prot;              /* protocol variant */
Buffer           *mBuf;             /* buffer to be decoded */
MsgLen           numDecBytes;       /* no of decoded bytes */
CmAbnfErr        *err;              /* error */
MgGcpCxtToED     *usrCxt;           /* user context */
#endif
{
   MgMgcpTxn      *txn;             /* MGCP transaction */
   MgTptSrvr      *srvr;            /* server control block */
   CmTptAddr      srcAddr;         /* source address */
   MgTransId      trId;             /* transaction Id */
   MgMgcpMsg      *mgcpMsg;         /* Mgcp Message */
   CmAbnfElmDef   *elmDef;          /* root of database tree */
   MgStoreDecReq  *msgBuf;          /* stored decode req */
   S16            ret;              /* ret value */
   U8             encodingScheme;
   

   TRC2(mgMgcpDecPduMsgCfm)


   srvr = NULLP;

#if (ERRCLS & ERRCLS_DEBUG)
   if((mBuf == NULLP) || (msgBuf == NULLP) ||(err == NULLP) ||(usrCxt == NULLP))
         MGLOGERROR( ERRCLS_DEBUG, EMG049, (ErrVal)0, 0,
         "mgMgcpDecPduMsgCfm: parameter NULLP \n");
#endif /* ERRCLS_DEBUG */

   msgBuf = (MgStoreDecReq *)(node->info);
   /* get server control block */
   MG_GET_SRVRCB(srvr,(msgBuf->suConnId), msgBuf->tsap);
   cmMemcpy((U8 *)&srcAddr, (U8 *)&msgBuf->srcAddr, sizeof(CmTptAddr));
   txn = (MgMgcpTxn *)(msgBuf->event);
   mgcpMsg = txn->mgcpMsg[txn->numMsg];

   if(err->code == CM_ABNF_ERR_NONE)
   {
      /* increment no of messages in txn */
      txn->numMsg++;
      /* Check if more msg is there in mBuf; */
      if(mgMgcpChkForMoreMsg(&mBuf, numDecBytes))
      {
         /* get buffer for mext msg */
         ret = mgAllocEventMem((Ptr *)&(txn->mgcpMsg[txn->numMsg]),
                        sizeof(MgMgcpMsg));
         if(ret != ROK)
         {
            RETVALUE(RFAILED);
         }
         ((MgGcpCxtToED *)usrCxt)->thisMsgNo = txn->numMsg;
         elmDef = &mgMsgDef;
         /* now call fn which will post msg to ED instances */
         if(srvr)
           encodingScheme = srvr->encodingScheme;
         if(encodingScheme == LMG_ENCODE_BIN)
         {
#ifdef GCP_ASN
         ret = mgPstDecReq(encodingScheme ,prot, txn->mgcpMsg[txn->numMsg], 0,
               mBuf,NULLP, usrCxt, &(txn->mgcpMsg[txn->numMsg]->memCp), node ,MGED_MGCP);
#endif
         }
         else
           ret = mgPstDecReq(encodingScheme ,prot, &(txn->mgcpMsg[txn->numMsg]->msgType),0, 
               mBuf, elmDef, usrCxt, &(txn->mgcpMsg[txn->numMsg]->memCp), node ,0);
         if(ret == RFAILED)
         {
            /* call function to process MgcpTxnInd */
            RETVALUE(mgPrcMgcpTxnInd(msgBuf->tsap, srvr, &srcAddr,
                                     NULLP, txn, NULLP));
         }   
         RETVALUE(ROKDNA);
      }
      else
      {
         /* no more message to decode so process it */
         /* call function to process MgcpTxnInd */
         RETVALUE(mgPrcMgcpTxnInd(msgBuf->tsap, srvr, &srcAddr,
                                  NULLP, txn, NULLP));
      }
   }
   else
   {
      /* error case */
      /* send error response to Peer */
      if (mgcpMsg->msgType.pres == PRSNT_NODEF &&
            mgcpMsg->msgType.val != MGT_MSG_RSP)
      {         
         /* Get transaction id */
         MG_MGCP_GET_TRANSID(mgcpMsg, trId);
         mgMgcpSendErrorResponse(&srcAddr, trId, 
                                 MGT_MGCP_RSP_CODE_PROT_ERROR, 
                                 (U8 *)"Decoding of the Command Failed",
                                 msgBuf->tsap); 
      }

      /* Free allocated msg for the wrongly decoded msg */
/*
 * now freeing the SDP Tkn Buf also
 */
#ifdef CM_SDP_OPAQUE
      mgMgcpFreeAllTkBfs((txn->mgcpMsg[txn->numMsg]));
#endif  /* CM_SDP_OPAQUE */
      mgFreeEventMem((Ptr) txn->mgcpMsg[txn->numMsg]);
      txn->mgcpMsg[txn->numMsg] = NULLP;

      /* call function to process MgcpTxnInd */
      RETVALUE(mgPrcMgcpTxnInd(msgBuf->tsap, srvr, &srcAddr,
                               NULLP, txn, NULLP));
   }
} /* mgMgcpDecPduMsgCfm */


/*
*
*       Fun:   mgMgcpPrcEncCmd
*
*       Desc:  This function process encode cfm for MGCP piggybacked 
*       rcved from ED instance.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcpPrcEncCmd
(
MgStoreEncReq    *txnBuf,           /* Stored encode req */
U16               cnt,              /* no of msg in txn to be processed */
MgPeerCb         *peer,             /* peer control block */
MgSSAPCb         *ssap,             /* SSAP control block */
MgMgcpTxn        **discardTxn       /* discard txn */
)
#else
PRIVATE S16 mgMgcpPrcEncCmd(txnBuf, cnt, peer, ssap, discardTxn)
MgStoreEncReq    *txnBuf;              /* Stored encode req */
U16              cnt;               /* no of msg in txn to be processed */
MgPeerCb         *peer;             /* peer control block */
MgSSAPCb         *ssap;             /* SSAP control block */
MgMgcpTxn        **discardTxn;       /* discard txn */
#endif
{
   U16           msgNo;              /* message no in txn */
   MgMgcpMsg     *msg;               /* MGCP Msg */
   MgTxBufInfo  *txBufInfo;          /* transmit Buffer info */
   Bool          immTx;              /* transmit immediatelly */
   U8            msgType;            /* Message Type */
   Bool          unUsed;             /* Unused Variable */
   MgTransId     transId;            /* Transaction Id */
   MgTxTransIdEnt *txCb;             /* Transaction Control Block */
   CmTptAddr     remoteAddr;         /* remote address */
   MgTptSrvr     *srvr;              /* server control block */
   Bool          ssapSrvr;           /* ssap server */
   MsgLen        crntPduLen;         /* Current PDU Length */
   MgTSAPCb      *tsap;              /* tsap control block */
   Buffer        *mBuf;              /* new Buffer */
   MgPeerInfo    *peerInfo;          /* Destination Peer Information */
   Buffer        *concatMbuf;        /* PiggyBacked Buffer */
   MgMgcpTxn     *txn;               /* MGCP Txn */
   Bool          dontPrcCmd;         /* whether to process cmd further */
   Bool          xmit;               /* Is it possible to Xmit */
   U32           mgtError;           /* MGT Interface Error */
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
   MgTxTransIdEnt  *txCbArray[MGT_MAX_MSG];
   U32             count = 0;
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */ 
   

   TRC2(mgMgcpPrcEncCmd)

   dontPrcCmd = FALSE;
   
#if (ERRCLS & ERRCLS_DEBUG)
   if((peer == NULLP) || (txn == NULLP) ||(ssap == NULLP) )
         MGLOGERROR( ERRCLS_DEBUG, EMG050, (ErrVal)0, 0,
         "mgMgcpPrcEncCmd: parameter NULLP \n");

#endif /* ERRCLS_DEBUG */
   concatMbuf   = NULLP;
   xmit         = FALSE;

   tsap = txnBuf->tsap;

   txn = (MgMgcpTxn *)(txnBuf->event);
   /*
    * For Piggybacking, UDP header + message separator needs to be added as
    * length, so initialise crntPduLen accordingly
    */
   crntPduLen = MG_UDP_HDR_LEN;   

   txBufInfo = NULLP;
   /* Obtain a socket for subsequent transmissions */
   if(txn->numMsg == 0)
      RETVALUE(ROK);
   if ((srvr = mgMgcpGetSrvrForTx(ssap, tsap, &ssapSrvr)) == NULLP)
   {
      RETVALUE(RFAILED);
   }
   peerInfo = &(txn->mgLclInfo);
   MG_GET_REMOTE_ADDR_FOR_TX(&remoteAddr, peerInfo, peer);
   for(msgNo =0; msgNo < cnt; msgNo++)
   {
      Bool     crtTxCb;
      /* initialize variables */
      crtTxCb = TRUE;
      msg = txn->mgcpMsg[msgNo];
      if(msg == NULLP)
         continue;

      MG_MGCP_GET_TRANSID(msg, transId);
      msgType = msg->msgType.val;
#ifdef ZG_DFTHA
      /* If this msg is cmd and it's transId/Rset doesn't lie on this 
       * Copy (Node/Processor ) then don't create txCb for this cmd.
       */
      {
         if(!zgChkNCRsetStatus(transId, LMG_PROTOCOL_MGCP, 
            peer, msgType, MG_TRANS_TYPE_TX, 
            srvr->suRsetId, NULLP, 0))
         {
            /* make crtTxCb False , also call PLDF fn to send this piggybacked
             * txn to appropriate copy */
            crtTxCb = FALSE;
         }
      }
#endif /* ZG_DFTHA */      
      if(dontPrcCmd == TRUE)
      {
         MG_ALLOC_MGCP_ONEERR_MSG((*discardTxn), txn, msgNo);
         if(*discardTxn == NULLP)
         {
/*
 * now freeing the SDP Tkn Buf also
 */
#ifdef CM_SDP_OPAQUE
            mgMgcpFreeAllTkBfs((txn->mgcpMsg[msgNo]));
#endif  /* CM_SDP_OPAQUE */
            mgFreeEventMem(txn->mgcpMsg[msgNo]);
         }
         txn->mgcpMsg[msgNo] = NULLP;
         continue;
      }
      mBuf = txnBuf->encBuf[msgNo]->buf;
      txnBuf->encBuf[msgNo]->buf = NULLP;
      txCb = NULLP;
      immTx = FALSE;
      if(crtTxCb == TRUE)
      {
#ifdef  GCP_2705BIS
         /* If this first txn (cmd ) in the message , then get memory for 
            * txBufInfo. */
         if(txBufInfo == NULLP)
         {
            if((txBufInfo = (MgTxBufInfo *)mgMalloc(sizeof(MgTxBufInfo))) ==
               NULLP)
            {
               MG_ALLOC_MGCP_ONEERR_MSG((*discardTxn), txn, msgNo);
               if(*discardTxn == NULLP)
               {
/*
 * now freeing the SDP Tkn Buf also
 */
#ifdef CM_SDP_OPAQUE
                  mgMgcpFreeAllTkBfs((txn->mgcpMsg[msgNo]));
#endif  /* CM_SDP_OPAQUE */
                  mgFreeEventMem(txn->mgcpMsg[msgNo]);
               }
               txn->mgcpMsg[msgNo] = NULLP;

               dontPrcCmd = TRUE;
               continue;
            }
            else
            {
               txBufInfo->mBuf = NULLP;
               txBufInfo->expctdRspCnt = 0;
               txBufInfo->rcvdRspCnt =0;
               txBufInfo->retxCnt = 0;
            }
         }
         txBufInfo->expctdRspCnt++;
#endif  /* GCP_2705BIS */
         /*
         * If notified entity is present in possible commands, we need to 
         * copy the remote address where commands needs to be transmitted. Also
         * This command needs to be transmitted immediately
         */
         
         if (msgType == MGT_MSG_RQNT || msgType == MGT_MSG_NTFY ||
            msgType == MGT_MSG_DLCX)
         {
            mgMgcpCopyNotifyEntityForTx(&immTx, msg, peer, srvr, &remoteAddr);
         }

         if ((txCb = mgPrcOutGoingTxn(transId, msgType, MG_NONE, immTx, 
                                      &remoteAddr, peer->ssap, peer,
#ifdef    GCP_PROV_SCTP
                                      NULLP,
#endif    /* GCP_PROV_SCTP */
                                      srvr, (Void *)txBufInfo, &unUsed)) 
                  == NULLP)
         {
            MG_ALLOC_MGCP_ONEERR_MSG((*discardTxn), txn, msgNo);
            if(*discardTxn == NULLP)
            {
/*
 * now freeing the SDP Tkn Buf also
 */
#ifdef CM_SDP_OPAQUE
               mgMgcpFreeAllTkBfs((txn->mgcpMsg[msgNo]));
#endif  /* CM_SDP_OPAQUE */
               mgFreeEventMem(txn->mgcpMsg[msgNo]);
            }
            txn->mgcpMsg[msgNo] = NULLP;

            dontPrcCmd = TRUE;

            /* Free txBufInfo */
#ifdef GCP_2705BIS
            if(txBufInfo)
               mgDeAlloc( (Data *)(txBufInfo), sizeof(MgTxBufInfo));
#endif /* GCP_2705BIS */
            if (mBuf != NULLP)
               mgPutMsg(mBuf);

            continue; 
         }
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
         txCbArray[count] = NULLP;
         if(NULLP != txCb)
         {
            txCbArray[count] = txCb;
            count++;
         }
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */ 
      }

      /*
       * Further processing should be done only if buffer can be transmitted
       * else encoded buffer by now should already be queued appropriately and
       * will be transmitted at some later point of time due to appropriate
       * trigger
       */
      if (xmit == FALSE)
      {
         if ((mgCb.genCfg.entType == LMG_ENT_GC) &&
             ((peer->state == LMG_PEER_STATE_ACTIVE) || 
              (peer->state == LMG_PEER_STATE_REGISTER)))
         {        
            xmit = TRUE;
         }
         else
         if ((mgCb.genCfg.entType == LMG_ENT_GW) &&
             (peer->state == LMG_PEER_STATE_REGISTER ||
              peer->state == LMG_PEER_STATE_ACTIVE)) 
         {
            xmit = TRUE;
         }
      }

#if (!(defined(GCP_VER_1_3) && defined(GCP_2705BIS)))
      if(xmit == TRUE)
#endif /* GCP_VER_1_3 && GCP_2705BIS */
      {
         /*
          * After this point, we just need to transmit the buffer; If an
          * error is encountered; it is going to be a memory shortage error
          * At this point, we shouldn't deleted rxCb as it has queued response
          * which can be used if we receive retransmission; txCb should be 
          * deleted as we couldn't transmit command
          */
         /* If txCb is going to be queued..then xmit will be false..so in fn
          * mgMgcpXmitTxnReq transmit message only if xmit is true ( for
          * command) responses will be transmitted if immTx is TRUE. This fn
          * concatnates encoded mBuf into concatMbuf */
         if ((mgMgcpXmitTxnReq(immTx, msg->msgType.val, &crntPduLen, peer, 
                               &remoteAddr, mBuf, &concatMbuf, 
                               &mgtError, srvr, &txBufInfo,
                               xmit, txnBuf->tsap)) != ROK)
            
         {
            MG_ALLOC_MGCP_ONEERR_MSG((*discardTxn), txn, msgNo);
            if(*discardTxn == NULLP)
            {
/*
 * now freeing the SDP Tkn Buf also
 */
#ifdef CM_SDP_OPAQUE
               mgMgcpFreeAllTkBfs((txn->mgcpMsg[msgNo]));
#endif  /* CM_SDP_OPAQUE */
               mgFreeEventMem(txn->mgcpMsg[msgNo]);
            }
            txn->mgcpMsg[msgNo] = NULLP;
            if(txCb)
            {
               mgDeAllocTxTransIdEnt(txCb->peer, txCb , FALSE);
            }
            dontPrcCmd = TRUE;
         }
      }
#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
      /* If this message is command then free mBuf */
      if((msg->msgType.val) != MGT_MSG_RSP) 
      {
         mgPutMsg(mBuf);
      }
#endif /* GCP_VER_1_3 && GCP_2705BIS */
      /* Free txn */
      if(txn->mgcpMsg[msgNo] != NULLP)
      {
/*
 * now freeing the SDP Tkn Buf also
 */
#ifdef CM_SDP_OPAQUE
         mgMgcpFreeAllTkBfs((txn->mgcpMsg[msgNo]));
#endif  /* CM_SDP_OPAQUE */
         mgFreeEventMem(txn->mgcpMsg[msgNo]);
      }
      txn->mgcpMsg[msgNo] = NULLP;
   } /* end of for loop */

#if (defined(GCP_VER_1_3) && defined(GCP_2705BIS))
   /* Update tranmitted buffer information */
   if(concatMbuf != NULLP)
   {
      /* Get a refrence of concatMbuf into mBuf..as concatBuf will be freed
       * in service provider while transmitting the buffer */
      if ((SAddMsgRef (concatMbuf, txnBuf->tsap->tsapCfg.memId.region, 
                       txnBuf->tsap->tsapCfg.memId.pool,
                       &(mBuf))) != ROK)
      {
         MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                      mgCb.init.region, mgCb.init.pool);
         txBufInfo->mBuf = concatMbuf;
         /* return ok */
         RETVALUE(ROK);
      }
      txBufInfo->mBuf = mBuf;
   }
#endif /* GCP_VER_1_3 && GCP_2705BIS */
   /* 
    * After this for loop, each txCb->mBuf or txBufInfo->mBuf will have 
    * required encoded message. Generate RtUpd for all txCbs so that standby
    * also has the same txBufInfo 
    */
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
   {
      U32    idx;
      idx = 0;
      for(idx=0; idx<count; idx++)
      {
         if(txCbArray[idx] != NULLP)
         {
            zgRtUpd(ZG_CBTYPE_TXN_TX, (Ptr)txCbArray[idx], 
                      CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_ADD);
         }
      }
      zgUpdPeer();
   }
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */

   if (concatMbuf != NULLP)
   {
      /* we have a piggybacked buffer for transmission */
#ifdef    GCP_PROV_SCTP
      MG_TRANSMIT_PDU(peer, peer->assocCb, NULLP, FALSE,
                      srvr, &remoteAddr,concatMbuf);
#else     /* GCP_PROV_SCTP */
      MG_TRANSMIT_PDU(peer, srvr, &remoteAddr, concatMbuf);
#endif    /* GCP_PROV_SCTP */

      /*
       * Since Transport Servers are being used in a round-robin fashion
       * Update the next server to be used for a transaction request
       */
      mgMgcpUpdateNxtUseSrvrForTx(ssap, tsap, ssapSrvr);
   }
   RETVALUE(ROK);
} /* mgMgcpPrcEncCmd*/


/*
*
*       Fun:   mgMgcpEncPduMsgCfm
*
*       Desc:  This function process encode cfm rcved from ED instance.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PRIVATE S16 mgMgcpEncPduMsgCfm
(
MgStoreEncReq    *txnBuf,           /* stored encode req */
Buffer           *mBuf,             /* buffer to be decoded */
CmAbnfErr        *err,              /* error */
Ptr              usrCxt             /* user context */
)
#else
PRIVATE S16 mgMgcpEncPduMsgCfm(txnBuf, mBuf, err, usrCxt)
MgStoreEncReq    *txnBuf;           /* stored encode req */
Buffer           *mBuf;             /* buffer to be decoded */
CmAbnfErr        *err;              /* error */
Ptr              usrCxt;               /* user context */
#endif
{
   U8            cnt;               /* counter */
   U16           msgNo;             /* message no in txn */
   MgMgcpTxn     *txn;              /* MGCP txn */
   MgMgcpMsg     *msg;              /* MGCP Msg */
   MgPeerCb      *peer;             /* peer cb */
   MgSSAPCb      *ssap;             /* ssap cb */
   MgTptSrvr     *srvr;             /* server cb */
   Bool          ssapSrvr;          /* whether ssap server */
   MgTransId     trId;              /* transaction id */
   S16           ret;               /* return value */
   

   TRC2(mgMgcpEncPduMsgCfm)

#if (ERRCLS & ERRCLS_DEBUG)
   if((mBuf == NULLP) || (txnBuf == NULLP) ||(usrCxt == NULLP) 
         ||(err == NULLP))
         MGLOGERROR( ERRCLS_DEBUG, EMG051, (ErrVal)0, 0,
         "mgMgcpEncPduMsgCfm: parameter NULLP \n");

#endif /* ERRCLS_DEBUG */

   msgNo = ((MgGcpCxtToED *)(usrCxt))->thisMsgNo; 
   txn = (MgMgcpTxn *)(txnBuf->event);
   msg = txn->mgcpMsg[msgNo];

   MG_MGCP_GET_TRANSID(msg, trId);

   peer = MG_GET_PEER_FRM_PEERID(txnBuf->peerId);
   if(peer)
      ssap = peer->ssap;
   else
      ssap = mgCb.sSAPLst[txnBuf->spId];

   srvr = mgMgcpGetSrvrForTx(ssap, txnBuf->tsap, &ssapSrvr);

   if(txnBuf->source == MG_USER)
   {
      MgMgcpTxn      *discardTxn;
      Buffer         *newBuf;

      if(peer == NULLP)
         RETVALUE(RFAILED);
      if(ssap == NULLP)
         RETVALUE(RFAILED);
      /* Check error code */
      discardTxn = NULLP;
      if(err->code == CM_ABNF_ERR_NONE)
         txnBuf->encBuf[msgNo]->status = MG_ENCODE_OK;
      else
         txnBuf->encBuf[msgNo]->status = MG_ENCODE_NOK;
      ret = ROK;
      for(cnt = 0; cnt < txn->numMsg; cnt++)
      {
         if((txnBuf->encBuf[cnt] == NULLP) || (txnBuf->encBuf[cnt]->status 
                   == MG_ENCODE_NONE))
         {
            ret = ROKDNA;
            break;
         }
      }

      /* Check if shutDown req is pending..if yes, then free everything if all
       * cfm are rcvd*/
      if(mgCb.shutDwnCfm.dfrdCfm == TRUE)
      {
         /* ret == ROKDNA..means still some Cfms are pending */
         mgPutMsg(mBuf);
         RETVALUE(ret);
      }
      /* If this is response ..process it */
      if((msg->msgType.val) == MGT_MSG_RSP)
      {
         if(err->code == CM_ABNF_ERR_NONE)
         {
            /* No error */
            /* find out rxCb */
            MgRxTransIdEnt      *rxCb;
            if ((cmHashListFind(&(peer->inTransLst), (U8 *)&trId, 
                 MG_TRANSID_LEN, MG_HASH_SEQNMB_DEF, (PTR *)&rxCb)) != ROK)
            {
/*
 * now freeing the SDP Tkn Buf also
 */
#ifdef CM_SDP_OPAQUE
               mgMgcpFreeAllTkBfs(msg);
#endif  /* CM_SDP_OPAQUE */
               mgFreeEventMem(msg);
               txn->mgcpMsg[msgNo] = NULLP;      
               RETVALUE(ret);
            }
#if (ERRCLS & ERRCLS_DEBUG)
#ifdef ZG
      /* When multithreaded encoder/decoder is enabled..then there is some
       * probablity that, resource set may go out of service ( only through
       * forced switch over ).. before we rcv cfm back..if that is the case then
       * drop it..*/
         if( (zgChkTxnRsetState(rxCb->mapCb.rsetId)) == FALSE)
         {
/*
 * now freeing the SDP Tkn Buf also
 */
#ifdef CM_SDP_OPAQUE
            mgMgcpFreeAllTkBfs(msg);
#endif  /* CM_SDP_OPAQUE */
            mgFreeEventMem(msg);
            txn->mgcpMsg[msgNo] = NULLP;      
            RETVALUE(ret);
         }
#endif /* ERRCLS_DEBUG */
#endif /* ERRCLS_DEBUG */
            /* Obtain a socket for subsequent transmissions */
            if (srvr == NULLP)
            {
               MG_ALLOC_MGCP_ONEERR_MSG(discardTxn, txn, msgNo);
               mgHandleMgcpTxnReqErr(ssap, discardTxn, MGT_ERR_RSRC_UNAVAIL);
               MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_DMEM_ALLOC_FAIL, \
                  mgCb.init.region, mgCb.init.pool);
               if(ret != ROKDNA)
                  ret = RFAILED;
               RETVALUE(ret);
            }     

            mgMgcpUpdateNxtUseSrvrForTx(ssap, txnBuf->tsap, ssapSrvr);

           /* Get a refrence of mBuf into newBuf..as concatBuf will be freed
            * in service provider while transmitting the buffer */
            if ((SAddMsgRef (mBuf, txnBuf->tsap->tsapCfg.memId.region, 
                             txnBuf->tsap->tsapCfg.memId.pool,
                             &(newBuf))) != ROK)
            {
               MG_ALLOC_MGCP_ONEERR_MSG(discardTxn, txn, msgNo);
               mgHandleMgcpTxnReqErr(ssap, discardTxn, MGT_ERR_RSRC_UNAVAIL);
               MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_DMEM_ALLOC_FAIL, \
                  mgCb.init.region, mgCb.init.pool);
               if(ret != ROKDNA)
                  ret = RFAILED;
               RETVALUE(ret);
            }
            /* Free old buffer and put encoded one */
            if(rxCb->mBuf)
               mgPutMsg(rxCb->mBuf);
            rxCb->mBuf = mBuf;
#ifdef ZG
#ifdef ZG_TXN_LVL_UPD
            /* generate runtime update for rxCb */
            zgRtUpd(ZG_CBTYPE_TXN_RX,(Ptr)rxCb,CMPFTHA_UPDTYPE_NORMAL,
               CMPFTHA_ACTN_MOD);
            zgUpdPeer();
#endif /* ZG_TXN_LVL_UPD */
#endif /* ZG */
            /* Now send this encoded buffer to peer */
            MG_UPD_MGCP_PEER_TX_STS(msg->msgType.val, peer->peerSts);


#ifdef    GCP_PROV_SCTP
            MG_TRANSMIT_PDU(peer, peer->assocCb, NULLP, FALSE,
                            srvr, &(rxCb->tptAddr), newBuf);
#else     /* GCP_PROV_SCTP */
            MG_TRANSMIT_PDU(peer, srvr, &(rxCb->tptAddr), newBuf);
#endif    /* GCP_PROV_SCTP */


/*
 * now freeing the SDP Tkn Buf also
 */
#ifdef CM_SDP_OPAQUE
            mgMgcpFreeAllTkBfs(msg);
#endif  /* CM_SDP_OPAQUE */
            mgFreeEventMem(msg);
            txn->mgcpMsg[msgNo] = NULLP;      
         }
         else
         {
            MG_ALLOC_MGCP_ONEERR_MSG(discardTxn, txn, msgNo);
            mgHandleMgcpTxnReqErr(ssap, discardTxn, MGT_ERR_INVALID_PARMS);
            mgPutMsg(mBuf);
         }
         txnBuf->encBuf[msgNo]->buf = NULLP;
      }
      /* We shall process further..if this msg is command..or if this is 
       * response with ret == ROK, ret == ROK implies..we have rcvd all the 
       * Encode cfm back..so check further if any command is still there to 
       * process */
      if((msg->msgType.val != MGT_MSG_RSP) || 
         ((msg->msgType.val == MGT_MSG_RSP) && (ret == ROK)))
      {
         U16    i;    /* counter */
#if (ERRCLS & ERRCLS_DEBUG)
#ifdef ZG
         /* When multithreaded encoder/decoder is enabled..then there is some
         * probablity that, resource set may go out of service ( only through
         * forced switch over ).. before we rcv cfm back..if that is the case 
         * then drop it..*/
         if(msg->msgType.val != MGT_MSG_RSP)
         {
            MgTransId txnId;
            MG_MGCP_GET_TRANSID((txn->mgcpMsg[0]), txnId);
            /* Check if resource set is active..if not then don't process it */
            if((zgGetTxnRsetStatus(ZG_CBTYPE_TXN_TX, txnBuf->peerId, txnId, 
               LMG_PROTOCOL_MGCP,txn->mgcpMsg[0]->rsetId)) != TRUE)
            {
               RETVALUE(ret);
            }

         }
#endif /* ERRCLS_DEBUG */
#endif /* ERRCLS_DEBUG */
         if(ret == ROKDNA)
            RETVALUE(ROKDNA);
         for(cnt = 0; cnt < txn->numMsg; cnt++)
         {
            if(txnBuf->encBuf[cnt]->status == MG_ENCODE_NONE)
            {
               /* Some of response/command is still leftover */
               RETVALUE(ROKDNA);
            }
            else if(txnBuf->encBuf[cnt]->status == MG_ENCODE_NOK)
            {
               break;
            }
         }
         ret = mgMgcpPrcEncCmd(txnBuf,cnt,peer,ssap, &discardTxn);
         if(discardTxn)
         {
            mgHandleMgcpTxnReqErr(ssap, discardTxn, MGT_ERR_RSRC_UNAVAIL);
            MG_GEN_RSRC_CATEG_ALRM(STSSAP, LCM_EVENT_DMEM_ALLOC_FAIL,\
               mgCb.init.region, mgCb.init.pool);
            discardTxn = NULLP;
         }
         /* Generate error indication for the encode failure */
         for(i = cnt; i< txn->numMsg; i++)
         {
            MG_ALLOC_MGCP_ONEERR_MSG(discardTxn, txn, i);
         }
         if(discardTxn)
         {
            mgHandleMgcpTxnReqErr(ssap, discardTxn, MGT_ERR_INVALID_PARMS);
            discardTxn = NULLP;
         }
      }
      else
      {
         RETVALUE(ret);
      }

   }
   RETVALUE(ROK);      
} /* mgMgcpEncPduMsgCfm */

#endif /* GCP_MGCP */   



/*
*
*       Fun:   mgCreatEDInst
*
*       Desc:  This function registers the multiple ED tasks, 
*              calls SCreateSTsk, attaches the instances to the threads
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PUBLIC S16 mgCreatEDInst 
(
Inst      noEDInst,               /* number of ED instances */
Inst      firstEDInst,            /* first ED instance */
Ent       ent                     /* Entity */
)
#else
PUBLIC S16 mgCreatEDInst(noEDInst, firstEDInst, ent)
Inst      noEDInst;               /* number of ED instances */
Inst      firstEDInst;            /* first ED instance */
Ent       ent;                    /* Entity */
#endif
{
   SSTskId     *instAr;           /* task id array */ 
   Inst        tmpInst;           /* temp instance */
   Bool        deregInst;         /* whether to deregister ?? */
   Inst        cnt;               /* counter */
   S16         ret;               /* ret value */

   TRC2(mgCreatEDInst)
  
   /* Initialisations */
   deregInst = FALSE;
  
   if(noEDInst == 0)
   {
      /* Just return ..*/
      RETVALUE(ROK); 
   }
   /* Allocate memory for the task id array */
   instAr = (SSTskId *)mgMalloc((noEDInst * sizeof(SSTskId)));
   if (!instAr)
      RETVALUE(RFAILED);
#ifdef GCP_ASN
   /* Initialise database */
   (void)mgInitMsgDb();
#endif
   /* Initialise the instance id array */
   for (cnt = 0; cnt < noEDInst; cnt++)
      instAr[cnt] = 0;
   /* Register all ED tasks with SSI starting with firstEDInst. */
   tmpInst = firstEDInst;
   for (cnt = 0; cnt < noEDInst; cnt++)
   { /*MAH_TBD with rashim MAH_TODO*/
      /* All ED instances will have cmAbnfActvTsk as activate function */
#ifdef GCP_ASN     
      ret = SRegTTsk(ent, tmpInst,(Ttype)TTNORM , PRIOR0, 
                     NULLP, mwrapActvTsk);
#else
      ret = SRegTTsk(ent, tmpInst,(Ttype)TTNORM , PRIOR0, 
                     NULLP, cmAbnfActvTsk);
#endif
       /*cmAbnfActvTsk*/
      if (ret != ROK)
      {
#if (ERRCLS & ERRCLS_DEBUG)
         MGLOGERROR( ERRCLS_DEBUG, EMG052, (ErrVal)tmpInst, 0,
             " mgCreatEDInst: Registration of ED instance failed \n");
#endif /* ERRCLS_DEBUG */
         deregInst = TRUE;
         break;
      }
      tmpInst++;
   }
  
   if (deregInst)
   {
      /* Something went wrong during registering tasks. Cleanup */
      tmpInst--;
      /* deregister task */
      while(cnt) 
      {
         SDeregTTsk(ent, tmpInst);
         tmpInst --;
         cnt--;
      }
      mgDeAlloc(instAr,(noEDInst * sizeof(SSTskId)));
      RETVALUE(RFAILED);
   }
   
   for (cnt = 0; cnt < noEDInst; cnt++)
   {
      /* Create the systerm tasks (threads) */
      ret = SCreateSTsk (PRIOR0, &instAr[cnt]);
      if (ret != ROK)
      {
#if (ERRCLS & ERRCLS_DEBUG)
         MGLOGERROR( ERRCLS_DEBUG, EMG053, (ErrVal)cnt, 0,
         "mgCreatEDInst: Creation of receive thread failed \n");
#endif /* ERRCLS_DEBUG */
         deregInst = TRUE;
         break;
      }
   }
   
   if (deregInst)
   {
      /* Something went wrong during creating threads. Cleanup */
      /* Destroy the created system threads */
      cnt --;
      while(cnt)
      {
         SDestroySTsk(instAr[cnt]);
         cnt --;
      }
      /* Deregister the tapa tasks registered */
      tmpInst = firstEDInst;
      for (cnt = 0; cnt < noEDInst; cnt++)
      {
         SDeregTTsk(ent, tmpInst);
         tmpInst ++;
      }
      mgDeAlloc(instAr,(noEDInst * sizeof(SSTskId)));
      RETVALUE(RFAILED);
   }
   
   tmpInst = firstEDInst;
   /* Attach all the registered tasks with system tasks */
   for (cnt = 0; cnt < noEDInst; cnt++)
   {
      ret = SAttachTTsk (ent, tmpInst, instAr[cnt]);
      if (ret != ROK)
      {
#if (ERRCLS & ERRCLS_DEBUG)
         MGLOGERROR( ERRCLS_DEBUG, EMG054, (ErrVal)cnt, 0,
         "mgCreatEDInst: Failed to attach receive task to thread \n");
#endif /* ERRCLS_DEBUG */
         deregInst = TRUE;
         break;
      }
      tmpInst += 1;
   }

   if (deregInst)
   {
      /* Not able to attach the tapa tasks to the system tasks */
      /* Remove all the system threads and deregister all tapa tasks 
       * registered earlier */
      tmpInst = firstEDInst;
      for (cnt = 0; cnt < noEDInst; cnt++)
      {
         SDestroySTsk(instAr[cnt]);
         SDeregTTsk(ent, tmpInst);
         tmpInst ++;
      }
      mgDeAlloc(instAr,(noEDInst * sizeof(SSTskId)));
      RETVALUE(RFAILED);
   }
   
   mgCb.tskIdAr = instAr;

   /* Every things seems ok */

   RETVALUE(ROK);
} /* end of mgCreatEDInst */





/*
*
*       Fun:   mgPstDecReq
*
*       Desc:  This function post decode request to one of ED instances and
*       starts timer.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PRIVATE S16 mgPstDecReq
(
U8               encodingScheme,
U32              prot,              /* protocol variant */
Ptr              event,             /* event structure */
U32              txnIndx,           /* transaction index */
Buffer           *mBuf,             /* Buffer */
CmAbnfElmDef     *elmDef,           /* elmDef */   
MgGcpCxtToED     *usrCxt,           /* user context */
CmMemListCp      *memCp,            /* mem list cp */
MgStoreList      *node ,             /* node */
U16              elmDef1            /* elmDef */
)
#else
PRIVATE S16 mgPstDecReq(encodingScheme, prot, event, , txnIndx, mBuf, elmDef, usrCxt, memCp, node,elmDef1)
U8               encodingScheme;
U32              prot;              /* protocol variant */
Ptr              event;             /* event structure */
U32              txnIndx;           /* transaction index */
Buffer           *mBuf;             /* Buffer */
CmAbnfElmDef     *elmDef;           /* elmDef */   
MgGcpCxtToED     *usrCxt;           /* user context */
CmMemListCp      *memCp;            /* mem list cp */
MgStoreList      *node;             /* node */
U16              elmDef1;            /* elmDef1 */
#endif
{
   S16         ret;               /* ret value */

   TRC2(mgPstDecReq)

   /* If no of ED Instances is Zero ..then directly invoke decoder fn */
   if(mgCb.genCfg.noEDInst == 0)
   {
      CmAbnfErr       err;                /* Error */
      CmAbnfDecOff    offset;             /* DBUF offset information */
      MsgLen          numDecBytes;        /* no of decoded bytes */

      cmMemset((U8 *)&offset, 0, sizeof(CmAbnfDecOff));
      err.code = CM_ABNF_ERR_NONE;
      if(encodingScheme == LMG_ENCODE_BIN )
      {
#ifdef GCP_ASN
       if ((ret = mgDecPduMsg(prot, (U8 *)event, txnIndx, mBuf, elmDef1, &numDecBytes, &offset, &err)) != ROK) 
        { 
          RETVALUE(ret);
        }
#endif        
      }
      else
      {
       cmAbnfDecPduMsg(prot, memCp, (U8 *)event, mBuf, elmDef, 
                &numDecBytes, &offset, &err);
      }
      ret = mgRcvDecPduMsgCfm(prot, event, mBuf, numDecBytes, &err, 
                              (Ptr)usrCxt);
      RETVALUE(ROK);
   }
   /* initialize post structure */
   if(encodingScheme == LMG_ENCODE_BIN)
   {
#ifdef GCP_ASN
     mgCb.edPst.event = MG_WRAP_ASN_DECREQ;
#endif
   }
   else
   {  
     mgCb.edPst.event = MG_WRAP_ABNF_DECREQ;
   }
   mgCb.edPst.dstInst = mgCb.nxtEDInst++;
   /* if nxtEDInst is more then last ED inst no then wrap it */
   if(mgCb.nxtEDInst >= mgCb.lastEDInst)
      mgCb.nxtEDInst = mgCb.genCfg.firstInst;
    
   /* now call fn which will post msg to ED instances */
   ret = cmPkMedDecReq(encodingScheme, &mgCb.edPst, prot, (U8 *)event, mBuf, elmDef,elmDef1 ,
              memCp, (Ptr)usrCxt );
   if(ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   /* now start timer for decode req..we should get Decode Cfm back before timer
    * expires..else stored information will be freed after timer expiry*/
   if(mgCb.genCfg.edDecTmr.enb == TRUE)
   {
      mgStartTmr(MG_ED_DECTMR, mgCb.genCfg.edDecTmr.val, (PTR)node->nodeIndx,
           &(((MgStoreDecReq *)(node->info))->mgEDTimer));
   }

   RETVALUE(ROK);

} /* mgPstDecReq */




/*
*
*       Fun:   mgPstEncReq
*
*       Desc:  This function post encode request to one of ED instances and
*       starts timer.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PRIVATE S16 mgPstEncReq
(
U8               encodingScheme, 
U32              prot,              /* protocol variant */
Ptr              event,             /* event structure */
U32              txnIndx,           /* transaction index */
Buffer           *mBuf,             /* Buffer */
CmAbnfElmDef     *elmDef,           /* elmDef */   
MgGcpCxtToED     *usrCxt,           /* user context */
Mem              *mem,              /* mem list cp */
MgStoreList      *node,             /* node */
U8               source,            /* Source; Internal or User ??*/
Bool             strtTmr,            /* whether to start timer */
U16              elmDef1            /* elmDef */   
)
#else
PRIVATE S16 mgPstEncReq(encodingScheme ,prot, event, txnIndx mBuf, elmDef,
      usrCxt, mem, node, source, strtTmr, elmDef1)
U8               encodingScheme; 
U32              prot;              /* protocol variant */
Ptr              event;             /* event structure */
U32              txnIndx;           /* transaction index */
Buffer           *mBuf;             /* Buffer */
CmAbnfElmDef     *elmDef;           /* elmDef */   
MgGcpCxtToED     *usrCxt;           /* user context */
Mem              *mem;              /* mem list */
MgStoreList      *node;             /* node */
U8               source;            /* Source; Internal or User ??*/
Bool             strtTmr;           /* whether to start timer */
U16              elmDef1;           /* elmDef */   
#endif
{
   S16         ret;               /* ret value */

   TRC2(mgPstEncReq)

   /* If no of ED Instances is Zero ..then directly invoke encoder fn */
   if(mgCb.genCfg.noEDInst == 0)
   {
      CmAbnfErr     err;     /* error */

      err.code = CM_ABNF_ERR_NONE;
      if(encodingScheme == LMG_ENCODE_BIN)
      {
#ifdef GCP_ASN        
        mgEncPduMsg(prot, (U8 *)event, txnIndx, mBuf, elmDef1, mem, &err);
#endif
      }else
      {
      cmAbnfEncPduMsg(prot, (U8 *)event, mBuf, elmDef, mem, &err);
      }
      ret = mgRcvEncPduMsgCfm(prot, event, mBuf, &err, (Ptr)usrCxt);
      RETVALUE(ROK);
   }
   /* initialize post structure */
   if(encodingScheme == LMG_ENCODE_BIN)
   {
#ifdef GCP_ASN
    mgCb.edPst.event =MG_WRAP_ASN_ENCREQ;
#endif
   } 
   else
   {  
    mgCb.edPst.event = MG_WRAP_ABNF_ENCREQ;
   }
   mgCb.edPst.dstInst = mgCb.nxtEDInst;
   if(source != MG_INTERNAL)
   {
      /* Source in not User..then don't update nxtEDInst */ 
      /* if nxtEDInst is more then last ED inst no then wrap it */
      mgCb.nxtEDInst++;
      if(mgCb.nxtEDInst >= mgCb.lastEDInst)
         mgCb.nxtEDInst = mgCb.genCfg.firstInst;
   }
    
   /* now call fn which will post msg to ED instances */
     ret = cmPkMedEncReq(encodingScheme, &mgCb.edPst, prot, (U8 *)event, txnIndx, mBuf, elmDef,elmDef1 ,
              mem, (Ptr)usrCxt );
   if(ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   /*
    * Timer for encode request is started here deliberately; For Encode/Decode
    * as tight coupled, timer never gets started (and hence stopped). For
    * Loose Coupled, we start the timer here
    */
   if((strtTmr == TRUE) && (mgCb.genCfg.edEncTmr.enb == TRUE))
   {
      /* now start timer for encode req..we should get encode Cfm back 
       * before timer expires..else stored information will be freed after 
       * timer expiry
       */
      mgStartTmr(MG_ED_ENCTMR,mgCb.genCfg.edEncTmr.val, (PTR)(node->nodeIndx),
         &((MgStoreEncReq *)(node->info))->mgEDTimer);
   }

   RETVALUE(ROK);

} /* mgPstEncReq */


/*
*
*       Fun:   mgSndDecPduMsgReq
*
*       Desc:  This function sends decode request to one of ED instances.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/

#if    (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))

#ifdef ANSI
PUBLIC S16 mgSndDecPduMsgReq
(
U8              encodingScheme, /*MAH_TODO*/
UConnId          uConnId,           /* connection identifier */
U32              prot,              /* protocol variant */
Buffer           *mBuf,             /* buffer to be decoded */
CmTptAddr        *srcAddr,          /* source address */
Ptr              event,             /* event structure */
MgTSAPCb         *tsap,             /* TSAP Control Block */
MgcoTptInfo      *mgcoTptInfo        /* Megaco Transport Information */
)
#else
PUBLIC S16 mgSndDecPduMsgReq(encodingScheme, uConnId, prot, mBuf, srcAddr, event, tsap, mgcoTptInfo)
U8              encodingScheme; /*MAH_TODO*/
UConnId          uConnId;           /* connection identifier */
U32              prot;              /* protocol variant */
Buffer           *mBuf;             /* buffer to be decoded */
CmTptAddr        *srcAddr;          /* source address */
Ptr              event;             /* event structure */
MgTSAPCb         *tsap;             /* TSAP Control Block */
MgcoTptInfo      *mgcoTptInfo;        /* Megaco Transport Information */
#endif

#else     /* GCP_PROV_SCTP  || GCP_PROV_MTP3 */

#ifdef ANSI
PUBLIC S16 mgSndDecPduMsgReq
(
U8              encodingScheme, /*MAH_TODO*/
UConnId          uConnId,           /* connection identifier */
U32              prot,              /* protocol variant */
Buffer           *mBuf,             /* buffer to be decoded */
CmTptAddr        *srcAddr,          /* source address */
Ptr              event,             /* event structure */
MgTSAPCb         *tsap              /* TSAP Control Block */
)
#else
PUBLIC S16 mgSndDecPduMsgReq(encodingScheme,uConnId, prot, mBuf, srcAddr, event, tsap)
U8              encodingScheme; /*MAH_TODO*/
UConnId          uConnId;           /* connection identifier */
U32              prot;              /* protocol variant */
Buffer           *mBuf;             /* buffer to be decoded */
CmTptAddr        *srcAddr;          /* source address */
Ptr              event;             /* event structure */
MgTSAPCb         *tsap;             /* TSAP Control Block */
#endif

#endif    /* GCP_PROV_SCTP | GCP_PROV_MTP3 */
{
   U16           nodeIndx;          /* node Index in list */
   MgGcpCxtToED  *usrCxt;           /* User context */
   MgStoreList   *node;             /* list */
   MgStoreDecReq *msgBuf;           /* info will be stored here */
   CmAbnfElmDef  *elmDef;           /* root of database tree */
   U16           elmDef1;            /* root of database tree */
   CmMemListCp   *memCp;            /* mem list Cp */
   S16           ret;               /* ret value */
   MgStoreList   *list;             /* store list */
#ifdef   GCP_PROV_SCTP   
   MgAssocCb       *assoc = NULLP;     /* Association Control Block as passed in mgcoTptInfo */
#endif   /* GCP_PROV_SCTP */
#ifdef   GCP_PROV_MTP3
   Dpc             peerDpc = NULL;     /* Peer DPC as passed in MgcoTptInfo */
#endif   /* GCP_PROV_MTP3 */







   TRC2(mgSndDecPduMsgReq)
   /* 
    * Code added to pass multiple trasport parameter and then make each 
    * transport available in an
    * local copy of its transport variable 
    */
#if   (defined(GCP_PROV_SCTP) || defined(GCP_PROV_MTP3))
   if(mgcoTptInfo != NULLP)
   {
#ifdef   GCP_PROV_SCTP      
      if(mgcoTptInfo->tptType == LMG_TPT_SCTP)
         assoc = mgcoTptInfo->u.assocCb;
#endif   /* GCP_PROV_SCTP */
#ifdef  GCP_PROV_MTP3         
      if  (mgcoTptInfo->tptType == LMG_TPT_MTP3) 
         peerDpc  = mgcoTptInfo->u.mgMtpInfo.clgAddr;
         
#endif   /* GCP_PROV_MTP3 */    
   }        /* Do Not Remove This Brace */
#endif    /* GCP_PROV_SCTP || GCP_PROV_MTP3 */
         


#if (ERRCLS & ERRCLS_DEBUG)
   if((mBuf == NULLP) || (srcAddr == NULLP) || (event == NULLP))
         MGLOGERROR( ERRCLS_DEBUG, EMG055, (ErrVal)0, 0,
         "mgSndDecPduMsgReq: parameter NULLP \n");

   if((prot != CM_ABNF_PROT_MEGACO_H248) &&
      (prot != CM_ABNF_PROT_MGCP_RFC2705)&&
      (prot != CM_ABNF_PROT_MEGACO_H248_V2)&&
      (prot != CM_ABNF_PROT_MGCP_TGCP_1_0)&&
      (prot != CM_ABNF_PROT_MGCP_NCS_1_0))
         MGLOGERROR( ERRCLS_DEBUG, EMG056, (ErrVal)0, 0,
         "mgSndDecPduMsgReq: protocol variant is wrong \n");

#endif /* ERRCLS_DEBUG */
   nodeIndx = mgCb.decCntr++;
   /* get memory for node */
   if((node = (MgStoreList *)mgMalloc(sizeof(MgStoreList))) == NULLP)
      RETVALUE(RFAILED);
   /* get memory for usrCxt */ 
   if((usrCxt = (MgGcpCxtToED *)mgMalloc(sizeof(MgGcpCxtToED))) == NULLP)
   {
      mgDeAlloc((Data *)node, sizeof(MgStoreList));
      RETVALUE(RFAILED);
   }
   /* get memory for msgBuf */ 
   if((msgBuf = (MgStoreDecReq *)mgMalloc(sizeof(MgStoreDecReq))) == NULLP)
   {
      mgDeAlloc((Data *)node, sizeof(MgStoreList));
      mgDeAlloc((Data *)usrCxt, sizeof(MgGcpCxtToED));
      RETVALUE(RFAILED);
   }
   /* Initialize timer */
   cmInitTimers(&(msgBuf->mgEDTimer), MG_DEFAULT_MAXTMR);

   /* initialize all the variables */
   if(srcAddr)
   {
      cmMemcpy((U8 *)&msgBuf->srcAddr, (U8 *)srcAddr, sizeof(CmTptAddr));
   }
   else
   {
      cmMemset((U8 *)&msgBuf->srcAddr, 0, sizeof(CmTptAddr));
   }
   node->nodeIndx = nodeIndx;
   node->next = NULLP;
   msgBuf->protoVar = prot;
   msgBuf->suConnId = uConnId;
   msgBuf->event = event;
   msgBuf->mBuf = mBuf; 

#ifdef    GCP_PROV_SCTP
   msgBuf->assoc = assoc;
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
   msgBuf->mgMtpInfo = mgcoTptInfo->mgMtpInfo;
#endif   /* GCP_PROV_MTP3 */   

   msgBuf->tsap  = tsap; 

   node->info = (Ptr)msgBuf;
   usrCxt->indx = nodeIndx;
   usrCxt->thisMsgNo = 0;
   /* now Add node into list */ 
   list = &mgCb.decList;
   MG_ADD_NODE_INTO_STORELST(list, node);

   if(prot == CM_ABNF_PROT_MEGACO_H248)
   {
#ifdef GCP_MGCO
      /* MEGACO msg needs to be decoded into two steps ..first decode
       * authentication header + msgBody..and decode each txn seperately */
       memCp = (CmMemListCp *)(&((MgMgcoMsg *)event)->memCp);
      if(encodingScheme == LMG_ENCODE_BIN)
      {
        elmDef1 = MGED_MEGACO;
      }
      else
      {
       elmDef = &mgMgcoAuthHdrMsgDef;
       event = (Ptr)(&((MgMgcoMsg *)event)->pres);
      }
#endif /* GCP_MGCO */
   }
#ifdef GCP_MGCP
   else
   {
      MgMgcpMsg     *msg;     /* MGCP msg */
      MgMgcpTxn     *txn;     /* MGCP txn */

      if(encodingScheme == LMG_ENCODE_BIN)
      {
        elmDef1 = MGED_MGCP;
      }
      else
      {
        elmDef = &mgMsgDef;
      }
      txn = (MgMgcpTxn *)event;
      txn->numMsg = 0;
      /* allocate memory for first msg */
      ret = mgAllocEventMem((Ptr *)&(txn->mgcpMsg[txn->numMsg]),
                        sizeof(MgMgcpMsg));
      if(ret != ROK)
      {
         /* free all the resources */
         MG_FREE_DEC_RSRC(node, msgBuf, usrCxt);
         RETVALUE(RFAILED);
      }
      msg = txn->mgcpMsg[txn->numMsg];
      memCp = (CmMemListCp *)(&msg->memCp);
      if(encodingScheme == LMG_ENCODE_BIN)
        event = (Ptr)msg;
      else
        event = (Ptr)&msg->msgType;
   }
#endif /* GCP_MGCP */
   /* now call fn which will post msg to ED instances */
   if(encodingScheme == LMG_ENCODE_BIN)
   { 
#ifdef GCP_ASN
     ret = mgPstDecReq(encodingScheme ,prot, event, 0, mBuf, NULLP /*Moved to last*/,
         usrCxt, memCp , node,elmDef1);
#endif
   }
   else
   {
     ret = mgPstDecReq(encodingScheme ,prot, event, 0/*INDEX*/, mBuf, elmDef, usrCxt, memCp , node,0);
   }
   if(ret == RFAILED)
   {
      /* clean up all things and return rfalied */
      MG_FREE_DEC_RSRC(node, msgBuf, usrCxt);
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
  
} /* mgSndDecPduMsgReq */



/*
*
*       Fun:   mgRcvDecPduMsgCfm
*
*       Desc:  This function process decode cfm rcved from ED instance.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PUBLIC  S16 mgRcvDecPduMsgCfm
(
U32              prot,              /* protocol variant */
Ptr              event,             /* event structure */
Buffer           *mBuf,             /* buffer to be decoded */
MsgLen           numDecBytes,       /* no of decoded bytes */
CmAbnfErr        *err,              /* error */
Ptr              usrCxt             /* user context */
)
#else
PUBLIC  S16 mgRcvDecPduMsgCfm(prot, event, mBuf, numDecBytes, err, usrCxt)
U32              prot;              /* protocol variant */
Ptr              event;             /* event structure */
Buffer           *mBuf;             /* buffer to be decoded */
MsgLen           numDecBytes;       /* no of decoded bytes */
CmAbnfErr        *err;              /* error */
Ptr              usrCxt;               /* user context */
#endif
{
   U16           nodeIndx;          /* node Index in list */
   MgStoreList   *node;             /* list */
   MgStoreDecReq *msgBuf;           /* info will be stored here */
   S16           ret;               /* ret value */
   

   TRC2(mgRcvDecPduMsgCfm)
#if (ERRCLS & ERRCLS_DEBUG)
   if((mBuf == NULLP) || (event == NULLP) ||(usrCxt == NULLP))
         MGLOGERROR( ERRCLS_DEBUG, EMG057, (ErrVal)0, 0,
         "mgRcvDecPduMsgCfm: parameter NULLP \n");

   if((prot != CM_ABNF_PROT_MEGACO_H248) &&
      (prot != CM_ABNF_PROT_MEGACO_H248_V2)&&
      (prot != CM_ABNF_PROT_MGCP_RFC2705)&&
      (prot != CM_ABNF_PROT_MGCP_TGCP_1_0)&&
      (prot != CM_ABNF_PROT_MGCP_NCS_1_0))
         MGLOGERROR( ERRCLS_DEBUG, EMG058, (ErrVal)0, 0,
         "mgRcvDecPduMsgCfm: protocol variant is wrong \n");

#endif /* ERRCLS_DEBUG */
   /* get node index and message no from user context */
   nodeIndx = ((MgGcpCxtToED *)usrCxt)->indx;
   /* find out node from list*/
   MG_FIND_NODE_FRM_STORELST(node, nodeIndx, (&mgCb.decList));

   /* Check if shutDown req is pending..if yes, then free everything */
   if(mgCb.shutDwnCfm.dfrdCfm == TRUE)
   {
      /* no more message ..so free all the resources*/
      MG_FREE_DEC_RSRC(node, msgBuf, usrCxt);
      mgPutMsg(mBuf);
      /* Check if any other Enc/Dec Cfms are pending ..if not then perform
       * shutdown..and send confirmation */
      if(! MG_ENCDEC_CFM_IS_PENDING)
      {      
         /* perform shutdown and send confirmation */
         mgDfrdShutDwn();
      }
      RETVALUE(ROK);
   }

   if(node == NULLP)
   {
      /* Node is alreday deleted.for some reasons...free mBuf*/
      mgDeAlloc((Data *)usrCxt, sizeof(MgGcpCxtToED));
      mgPutMsg(mBuf);
      RETVALUE(ROK);
   }
     
   msgBuf = (MgStoreDecReq *)(node->info);
   /* stop timer */
   if(msgBuf->mgEDTimer.tmrEvnt == MG_ED_DECTMR)
      mgStopTmr(MG_ED_DECTMR, (PTR)(nodeIndx), &msgBuf->mgEDTimer);

   if((prot == CM_ABNF_PROT_MEGACO_H248) || (prot == CM_ABNF_PROT_MEGACO_H248_V2))
   {
#ifdef GCP_MGCO
      /* Megaco case */
      if((ret = mgMgcoDecPduMsgCfm(node, prot, mBuf, numDecBytes, err, 
                                   (MgGcpCxtToED *)usrCxt)) 
            != ROKDNA)
      {
         /* no more message ..so free all the resources*/
         MG_FREE_DEC_RSRC(node, msgBuf, usrCxt);
         mgPutMsg(mBuf);
      }
#endif /* GCP_MGCO */
   }
#ifdef GCP_MGCP
   else
   {
      /* Mgcp Case */
      if((ret = mgMgcpDecPduMsgCfm(node, prot, mBuf, numDecBytes, err, 
                                   (MgGcpCxtToED *)usrCxt)) 
            != ROKDNA)
      {
         /* no more message ..so free all the resources*/
         MG_FREE_DEC_RSRC(node, msgBuf, usrCxt);
         mgPutMsg(mBuf);
      }
   }
#endif /* GCP_MGCP */
   RETVALUE(ret);

} /* mgRcvDecPduMsgCfm */



/*
*
*       Fun:   mgRcvEncPduMsgCfm
*
*       Desc:  This function process encode cfm rcved from ED instance.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PUBLIC S16 mgRcvEncPduMsgCfm
(
U32              prot,              /* protocol variant */
Ptr              event,              /* event structure */
Buffer           *mBuf,             /* buffer to be decoded */
CmAbnfErr        *err,              /* error */
Ptr              usrCxt                /* user context */
)
#else
PUBLIC S16 mgRcvEncPduMsgCfm(prot, event, mBuf, err, usrCxt)
U32              prot;              /* protocol variant */
Ptr              event;             /* event structure */
Buffer           *mBuf;             /* buffer to be decoded */
CmAbnfErr        *err;              /* error */
Ptr              usrCxt;               /* user context */
#endif
{
   U16           nodeIndx;          /* node Index in list */
   MgStoreList   *node;             /* list */
   MgStoreEncReq *txnBuf;           /* info will be stored here */
#ifdef GCP_MGCO
   U16           i;                 /* counter */
   MgPeerCb      *peer;             /* peer cb */
   MgSSAPCb      *ssap;             /* ssap cb */
#endif /* GCP_MGCO */
   S16           ret;               /* return value */
   

   TRC2(mgRcvEncPduMsgCfm)

#if (ERRCLS & ERRCLS_DEBUG)
   if((mBuf == NULLP) || (event == NULLP) ||(usrCxt == NULLP))
         MGLOGERROR( ERRCLS_DEBUG, EMG059, (ErrVal)0, 0,
         "mgRcvEncPduMsgCfm: parameter NULLP \n");

   if((prot != CM_ABNF_PROT_MEGACO_H248) &&
      (prot != CM_ABNF_PROT_MGCP_RFC2705)&&
      (prot != CM_ABNF_PROT_MGCP_TGCP_1_0)&&
      (prot != CM_ABNF_PROT_MGCP_NCS_1_0))
         MGLOGERROR( ERRCLS_DEBUG, EMG060, (ErrVal)0, 0,
         "mgRcvEncPduMsgCfm: protocol variant is wrong \n");

#endif /* ERRCLS_DEBUG */

   /* get node index and message no from user context */
   nodeIndx = ((MgGcpCxtToED *)usrCxt)->indx;
   /* find out node from list*/
   MG_FIND_NODE_FRM_STORELST(node, nodeIndx, (&mgCb.encList));

   ret = ROK;
   if(node == NULLP)
   {
      /* Node is alreday deleted..So free resources..*/
      mgPutMsg(mBuf);
      mgDeAlloc((Data *)usrCxt, sizeof(MgGcpCxtToED));
      RETVALUE(ROK);
   }
   /* get stored information */ 
   txnBuf = (MgStoreEncReq *)(node->info);

   if((prot == CM_ABNF_PROT_MEGACO_H248) || (prot == CM_ABNF_PROT_MEGACO_H248_V2))
   {
#ifdef GCP_MGCO
      /* Megaco case */
      U16        noOfMsg;
      MgMgcoMsg *mgcoMsg;
      MgMgcoMsg *errMsg;
      Bool       allCfmRcvd;

      mgcoMsg = (MgMgcoMsg *)(txnBuf->event);

      /* added encoding support for errorDesc in msgBody */
      if (mgcoMsg->body.type.val == MGT_TXN)
         noOfMsg = mgcoMsg->body.u.tl.num.val;
      else
         noOfMsg = 0;

      errMsg = NULLP;
      allCfmRcvd = TRUE;
      /* update status */
      if(err->code == CM_ABNF_ERR_NONE)
      {
         (txnBuf->encBuf[((MgGcpCxtToED *)usrCxt)->thisMsgNo])->status 
            = MG_ENCODE_OK;
      }
      else
      {
         (txnBuf->encBuf[((MgGcpCxtToED *)usrCxt)->thisMsgNo])->status 
            = MG_ENCODE_NOK;
      }

      for(i=0;i<=noOfMsg;i++)
      {
         /* Check if more message are there for encode */
         if(((txnBuf->encBuf[i]) == NULLP) || 
               (txnBuf->encBuf[i]->status == MG_ENCODE_NONE))
         {
            allCfmRcvd= FALSE; 
         }
      }

      /* Check if shutDown req is pending..if yes, then free everything if all
       * cfm are rcvd*/
      if(mgCb.shutDwnCfm.dfrdCfm == TRUE)
      {
         if(allCfmRcvd == TRUE)
         {
            if (txnBuf->mgEDTimer.tmrEvnt == MG_ED_ENCTMR)
            {
               mgStopTmr(MG_ED_ENCTMR, (PTR)(node->nodeIndx), 
                 &txnBuf->mgEDTimer);
            }
            mgFreeEncRsrc(&node, &txnBuf, &usrCxt, noOfMsg, prot, TRUE);
         }
         else
         {
            /* just free usrCxt */
            mgFreeEncRsrc(NULLP, NULLP, &usrCxt, noOfMsg, prot, FALSE);
         }
         mgPutMsg(mBuf);
         if(! MG_ENCDEC_CFM_IS_PENDING)
         {      
            /* perform shutdown and send confirmation */
            mgDfrdShutDwn();
         }
         RETVALUE(ROK);
      }

      peer = MG_GET_PEER_FRM_PEERID(txnBuf->peerId);
      if (peer)
      {
         ssap = peer->ssap;
      }
      else
      {
         ssap = mgCb.sSAPLst[txnBuf->spId];
      }

#if (ERRCLS & ERRCLS_DEBUG)
#ifdef ZG
      /* When multithreaded encoder/decoder is enabled..then there is some
       * probablity that, resource set may go out of service ( only through
       * forced switch over ).. before we rcv cfm back..if that is the case then
       * drop it..*/
      {
         U8    cbType;
         U8    val;
         MgTransId txnId;
         val = mgcoMsg->body.u.tl.txns[0]->type.val;
         if((val == MGT_TXNREQ) || (val == MGT_TXNRSPACK))
         {
            cbType = ZG_CBTYPE_TXN_TX;
         }
         else
         {
            cbType = ZG_CBTYPE_TXN_RX;
         }
         MG_GET_TRANSID((mgcoMsg->body.u.tl.txns[0]), txnId);
         /* Check if resource set is active..if not then don't process it */
         if((zgGetTxnRsetStatus(cbType, txnBuf->peerId, txnId, 
            LMG_PROTOCOL_MGCO, mgcoMsg->body.u.tl.txns[0]->rsetId)) != TRUE)
         {
            if(allCfmRcvd == TRUE)
            {
               if (txnBuf->mgEDTimer.tmrEvnt == MG_ED_ENCTMR)
               {
                  mgStopTmr(MG_ED_ENCTMR, (PTR)(node->nodeIndx), 
                  &txnBuf->mgEDTimer);
               }
               mgFreeEncRsrc(&node, &txnBuf, &usrCxt, noOfMsg, prot, TRUE);
            }
            else
            {
               /* just free usrCxt */
               mgFreeEncRsrc(NULLP, NULLP, &usrCxt, noOfMsg, prot, FALSE);
            }
            mgPutMsg(mBuf);
         }
      }
#endif /* ERRCLS_DEBUG */
#endif /* ERRCLS_DEBUG */
      /* Now check if header is already encoded , if header itself is wrong 
       * then free resources and return */
      if (txnBuf->encBuf[0]->status == MG_ENCODE_NOK)
      {
         /* header itself is encoded wrong..so return rfailed */
         /* but since we might have already sent encode req to ED THread.. we
          * shouldn't free resources here ..Check if we have received all 
          * encode cfm ..back ..if that is the case..back ..if that is the
          *  case then free resources */
         if (allCfmRcvd == TRUE)
         {
            if (txnBuf->mgEDTimer.tmrEvnt == MG_ED_ENCTMR)
            {
               mgStopTmr(MG_ED_ENCTMR, (PTR)(node->nodeIndx), 
                 &txnBuf->mgEDTimer);
            }
            if (txnBuf->source == MG_USER)
            {
               mgHandleMgcoTxnReqErr(ssap, mgcoMsg, MGT_ERR_INVALID_PARMS,
                MG_USER);
            }
            mgFreeEncRsrc(&node, &txnBuf, &usrCxt, noOfMsg, prot, FALSE);
         }
         else
         {
            /* just free usrCxt */
            mgFreeEncRsrc(NULLP, NULLP, &usrCxt, noOfMsg, prot, FALSE);
         }
         mgPutMsg(mBuf);
         RETVALUE(RFAILED);
      }
      else if(txnBuf->encBuf[0]->status == MG_ENCODE_NONE )
      {
         /* Free user context ..since Header itself is not encoded.. so wait for
          * that */
         mgDeAlloc((Data *)usrCxt, sizeof(MgGcpCxtToED));
         RETVALUE(ROK);
      }
      for(i = 0; i <= noOfMsg; i++)
      {
         Buffer     *newBuf;
         /* Initalize newBuf */
         newBuf = NULLP;
         if(((txnBuf->encBuf[i]) == NULLP)|| 
               (txnBuf->encBuf[i]->status == MG_ENCODE_NONE) || (i == 0))
            continue;

         mBuf = txnBuf->encBuf[i]->buf;
         txnBuf->encBuf[i]->buf = NULLP;
         if(txnBuf->encBuf[i]->status == MG_ENCODE_NOK)
         {
            MgTransId   trId;
            MgMgcoTxn   *mgcoTxn;
            /* Free mgcoTxn..and collect error message */
            mgcoTxn = mgcoMsg->body.u.tl.txns[i-1];
            mgcoMsg->body.u.tl.txns[i-1] = NULLP;
            MG_GET_TRANSID(mgcoTxn, trId);
/*
 * now freeing the SDP Tkn Buf also
 */
#ifdef CM_SDP_OPAQUE
            mgMgcoFreeAllTkBfs(mgcoTxn);
#endif  /* CM_SDP_OPAQUE */
#ifdef GCP_CH
            mgChFreeCmds(mgcoMsg, i-1);
#endif /* GCP_CH  */
            mgFreeEventMem(mgcoTxn);
            MG_FILL_MGCO_ERR_MSG((&errMsg), MGT_ERR_INVALID_PARMS, 
                                 mBuf, NULLP, NULLP, trId);

            continue;
         }

         /* Get Buffer to store txn information */
         if ((SAddMsgRef (txnBuf->encBuf[0]->buf, 
                          txnBuf->tsap->tsapCfg.memId.region, 
                          txnBuf->tsap->tsapCfg.memId.pool,
                          &(newBuf))) != ROK)
         {
            /* Only if all cfm is rcvd ..free node and other resources ..else
             * just free usrCxt */
            if(allCfmRcvd == TRUE)
            {
               if(txnBuf->mgEDTimer.tmrEvnt == MG_ED_ENCTMR)
               {
                  mgStopTmr(MG_ED_ENCTMR, (PTR)(node->nodeIndx), 
                     &txnBuf->mgEDTimer);
               }
               /* send error message to user */
               if(txnBuf->source == MG_USER)
               {
                  mgHandleMgcoTxnReqErr(ssap, mgcoMsg, 
                     MGT_ERR_RSRC_UNAVAIL,MG_USER);
               }
               mgFreeEncRsrc(&node, &txnBuf, &usrCxt, noOfMsg, prot, FALSE);
            }
            else
            {
               /* just free usrCxt */
               mgFreeEncRsrc(NULLP, NULLP, &usrCxt, noOfMsg, prot, FALSE);
            }
            mgPutMsg(mBuf);
            RETVALUE(RFAILED);
         }
         
         if(SCatMsg(newBuf,mBuf,M1M2) != ROK)
         {
            /* Only if all cfm is rcvd ..free node and other resources ..else
             * just free usrCxt */
            if(allCfmRcvd == TRUE)
            {
               if(txnBuf->mgEDTimer.tmrEvnt == MG_ED_ENCTMR)
               {
                  mgStopTmr(MG_ED_ENCTMR, (PTR)(node->nodeIndx), 
                     &txnBuf->mgEDTimer);
               }
               /* send error message to user */
               if(txnBuf->source == MG_USER)
               {   mgHandleMgcoTxnReqErr(ssap, mgcoMsg, 
                     MGT_ERR_RSRC_UNAVAIL,MG_USER);
               }
               mgFreeEncRsrc(&node, &txnBuf, &usrCxt, noOfMsg, prot, FALSE);
            }
            else
            {
               /* just free usrCxt */
               mgFreeEncRsrc(NULLP, NULLP, &usrCxt, noOfMsg, prot, FALSE);
            }
            mgPutMsg(mBuf);
            mgPutMsg(newBuf);
            RETVALUE(RFAILED);
         }
           
         if((ret = mgMgcoEncPduMsgCfm(txnBuf, newBuf, err, i)) 
               == ROK)
         {
            /* If returned value is ROK..this means more message are to be
            * encoded so just return ..don't free newBuf..since this is 
            * already freed in mgMgcoEncPduMsgCfm */
            mgPutMsg(mBuf);
/*
 * now freeing the SDP Tkn Buf also
 */
#ifdef CM_SDP_OPAQUE
            mgMgcoFreeAllTkBfs((mgcoMsg->body.u.tl.txns[i-1]));
#endif  /* CM_SDP_OPAQUE */
#ifdef GCP_CH
            mgChFreeCmds(mgcoMsg, i-1);
#endif /* GCP_CH  */
            mgFreeEventMem(mgcoMsg->body.u.tl.txns[i-1]);
            mgcoMsg->body.u.tl.txns[i-1] = NULLP;
         }
         else if(ret == RFAILED)
         {
            /* Only if all cfm is rcvd ..free node and other resources ..else
             * just free usrCxt */
            if(allCfmRcvd == TRUE)
            {
               /* error ..so free all the resources*/
               if(txnBuf->mgEDTimer.tmrEvnt == MG_ED_ENCTMR)
                  mgStopTmr(MG_ED_ENCTMR, (PTR)(node->nodeIndx), 
                     &txnBuf->mgEDTimer);
               /* send error message to user */
               if(txnBuf->source == MG_USER)
                  mgHandleMgcoTxnReqErr(ssap, mgcoMsg, 
                     MGT_ERR_RSRC_UNAVAIL,MG_USER); 
               mgFreeEncRsrc(&node, &txnBuf, &usrCxt, noOfMsg, prot, FALSE);
            }
            else
            {
               /* just free usrCxt */
               mgFreeEncRsrc(NULLP, NULLP, &usrCxt, noOfMsg, prot, FALSE);
            }
            mgPutMsg(mBuf);
            mgPutMsg(newBuf);
            RETVALUE(ret);
         }
         else 
         {
            /* there was some error in processing this message but still we can
             * proceed forward with other message */
/*
 * now freeing the SDP Tkn Buf also
 */
#ifdef CM_SDP_OPAQUE
            mgMgcoFreeAllTkBfs((mgcoMsg->body.u.tl.txns[i-1]));
#endif  /* CM_SDP_OPAQUE */
#ifdef GCP_CH
            mgChFreeCmds(mgcoMsg, i-1);
#endif /* GCP_CH  */
            mgFreeEventMem(mgcoMsg->body.u.tl.txns[i-1]);
            mgcoMsg->body.u.tl.txns[i-1] = NULLP;
            mgPutMsg(mBuf);
            mgPutMsg(newBuf);
         }
      }
      
      /* If there are any errors report it to the user */
      if (errMsg != NULLP)
      {
         /* Copy Gateway information */
         cmMemcpy((U8 *)&(errMsg->lcl),
                  (CONSTANT U8 *)&(mgcoMsg->lcl), sizeof(MgPeerInfo));
         mgHandleMgcoTxnReqErr(ssap, errMsg, MG_IGNORE, MG_USER);
      }      

      for(i = 0; i < noOfMsg; i++)
      {
         /* Check if more message are there for encode */
         if(mgcoMsg->body.u.tl.txns[i] != NULLP)
         {
            mgDeAlloc((Data *)usrCxt, sizeof(MgGcpCxtToED));
            RETVALUE(ret);
         }
      }
      /* Done.. so free all the resources*/
      if((txnBuf) && (txnBuf->mgEDTimer.tmrEvnt == MG_ED_ENCTMR))
         mgStopTmr(MG_ED_ENCTMR, (PTR)(node->nodeIndx), 
            &txnBuf->mgEDTimer);

      mgFreeEncRsrc(&node, &txnBuf, &usrCxt, noOfMsg, prot, TRUE);
      RETVALUE(ret);      
#endif /* GCP_MGCO */
   }
#ifdef GCP_MGCP
   else
   {
      /* MGCP case */
      U16       noOfMsg;
      MgMgcpTxn  *mgcpTxn;

      mgcpTxn = (MgMgcpTxn *)(txnBuf->event);
      noOfMsg = mgcpTxn->numMsg;
      /* Mgcp Case */
      if((ret = mgMgcpEncPduMsgCfm(txnBuf, mBuf, err, usrCxt)) 
            == ROKDNA)
      {
         /* If returned value is ROKDNA..this means more message are to be
          * encoded so just return */
         mgDeAlloc((Data *)usrCxt, sizeof(MgGcpCxtToED));
         RETVALUE(ROK);
      }
      else
      {
         /* no more message ..so free all the resources*/
         if(ret == ROK)
         {
            /* Only if we are done with all message..i.e. no more message with
             * encoder/decoder Thread..we should free every thing */
            if(txnBuf->mgEDTimer.tmrEvnt == MG_ED_ENCTMR)
               mgStopTmr(MG_ED_ENCTMR, (PTR)(node->nodeIndx), 
                  &txnBuf->mgEDTimer);
            mgFreeEncRsrc(&node, &txnBuf, &usrCxt, noOfMsg, prot, TRUE);
         }
         if(ret == RFAILED)
            mgPutMsg(mBuf);

         /* Check if shutDown req is pending..if yes, then free everything if 
          * all cfm are rcvd*/
         if(mgCb.shutDwnCfm.dfrdCfm == TRUE)
         {
            if(! MG_ENCDEC_CFM_IS_PENDING)
            {      
               /* perform shutdown and send confirmation */
               mgDfrdShutDwn();
            }
         }
      }
   } /* if MGCP */
#endif /* GCP_MGCP */
   RETVALUE(ret);      
} /* mgRcvEncPduMsgCfm */




/*
*
*       Fun:   mgSndEncPduMsgReq
*
*       Desc:  This function sends enccode request to one of ED instances.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  mp_ed.c
*
*/
#ifdef    GCP_PROV_SCTP

#ifdef ANSI
PUBLIC S16 mgSndEncPduMsgReq
(
U8               encodingScheme,      /*MAH_TODO*/
U32              prot,              /* protocol variant */
U32              peerId,            /* peer identifier */
U8               source,            /* source; Internal or User */
SpId             spId,              /* SSap identifier */
CmTptAddr        *srcAddr,          /* source address */
Ptr              event,             /* event structure */
Bool             delPeer,           /* Whether peer needs to be deleted */
MgTSAPCb         *tsap,             /* Tsap control block */
MgAssocCb        *assoc,            /* Association Control Block */
TknU32           ctxId              /* Context-Id: MEGACO only */
)
#else
PUBLIC S16 mgSndEncPduMsgReq(encodingScheme ,prot, peerId, source,spId, srcAddr, event,
                             delPeer, tsap, assoc, ctxId)
U8               encodingScheme;      /*MAH_TODO*/
U32              prot;              /* protocol variant */
U32              peerId;            /* peer identifier */
U8               source;            /* source; Internal or User */
SpId             spId;              /* SSap identifier */
CmTptAddr        *srcAddr;          /* source address */
Ptr              event;             /* event structure */
Bool             delPeer;           /* Whether peer needs to be deleted */
MgTSAPCb         *tsap;             /* Tsap control block */
MgAssocCb        *assoc;            /* Association Control Block */
TknU32           ctxId;             /* Context-Id: MEGACO only */
#endif

#else     /* GCP_PROV_SCTP */

#ifdef ANSI
PUBLIC S16 mgSndEncPduMsgReq
(
U8               encodingScheme,      /*MAH_TODO*/
U32              prot,              /* protocol variant */
U32              peerId,            /* peer identifier */
U8               source,            /* source; Internal or User */
SpId             spId,              /* SSap identifier */
CmTptAddr        *srcAddr,          /* source address */
Ptr              event,             /* event structure */
Bool             delPeer,           /* Whether peer needs to be deleted */
MgTSAPCb         *tsap             /* Tsap control block */
)
#else
PUBLIC S16 mgSndEncPduMsgReq(encodingScheme ,prot, peerId, source,spId, srcAddr, event,
                             delPeer, tsap)
U8               encodingScheme;      /*MAH_TODO*/
U32              prot;              /* protocol variant */
U32              peerId;            /* peer identifier */
U8               source;            /* source; Internal or User */
SpId             spId;              /* SSap identifier */
CmTptAddr        *srcAddr;          /* source address */
Ptr              event;             /* event structure */
Bool             delPeer;           /* Whether peer needs to be deleted */
MgTSAPCb         *tsap;             /* Tsap control block */
#endif

#endif    /* GCP_PROV_SCTP */
{
   U16           noOfMsg;           /* no of message */
   U16           cnt;               /* counter */
   U16           nodeIndx;          /* node Index in list */
   MgGcpCxtToED  *usrCxt;           /* User context */
   MgStoreList   *node;             /* list */
   MgStoreEncReq *txnBuf;           /* info will be stored here */
   CmAbnfElmDef  *elmDef;           /* root of database tree */
   MgSSAPCb      *ssap;             /* Ssap control block */
   S16           ret;               /* return value */
   MgStoreList   *list;             /* store list */


   TRC2(mgSndEncPduMsgReq)

   /* Initaialize all variables */
   usrCxt = NULLP;
   node = NULLP;
   txnBuf = NULLP;
   elmDef = NULLP;
   ssap = NULLP;
   list = NULLP;
   noOfMsg = 0;

   /* Get SSAP*/
   if(spId != MG_INVALID_SSAP_ID)
      ssap = mgCb.sSAPLst[spId];
   else
      ssap = NULLP;

#if (ERRCLS & ERRCLS_DEBUG)
   if((event == NULLP))
   {
      MGLOGERROR( ERRCLS_DEBUG, EMG061, (ErrVal)0, 0,
         "mgSndEncPduMsgReq: parameter NULLP \n");
   }

   if((prot != CM_ABNF_PROT_MEGACO_H248) &&
      (prot != CM_ABNF_PROT_MGCP_RFC2705)&&
      (prot != CM_ABNF_PROT_MGCP_TGCP_1_0)&&
      (prot != CM_ABNF_PROT_MGCP_NCS_1_0))
   {
      MGLOGERROR( ERRCLS_DEBUG, EMG062, (ErrVal)0, 0,
         "mgSndEncPduMsgReq: protocol variant is wrong \n");
   }

   if((source == MG_USER) && (ssap == NULLP))
   {
      MGLOGERROR( ERRCLS_DEBUG, EMG063, (ErrVal)0, 0,
         "mgSndEncPduMsgReq: SSAP is NULLP \n");
   }
#endif /* ERRCLS_DEBUG */
   nodeIndx = mgCb.encCntr++;
   /* get memory for node */
   if((node = (MgStoreList *)mgMalloc(sizeof(MgStoreList))) == NULLP)
      RETVALUE(RFAILED);

   /* get memory for txnBuf */ 
   if((txnBuf = (MgStoreEncReq *)mgMalloc(sizeof(MgStoreEncReq))) == NULLP)
   {
      mgDeAlloc((Data *)node, sizeof(MgStoreList));
      RETVALUE(RFAILED);
   }

   /* Initialize timer */
   cmInitTimers(&(txnBuf->mgEDTimer), MG_DEFAULT_MAXTMR);

   /* initialize all the variables */
   node->nodeIndx = nodeIndx;
   node->next = NULLP;
   txnBuf->protoVar = prot;
   txnBuf->source = source;
   txnBuf->peerId = peerId;
   txnBuf->spId = spId;
   txnBuf->delPeer = delPeer;

   txnBuf->tsap  = tsap;
#ifdef    GCP_PROV_SCTP
   txnBuf->assoc = assoc;
   txnBuf->ctxId = ctxId;
#endif    /* GCP_PROV_SCTP */

   /* Initaialize source address */
   if(srcAddr)
   {
      cmMemcpy((U8 *)&txnBuf->srcAddr, (U8 *)srcAddr, sizeof(CmTptAddr));
   }
   else
   {
      cmMemset((U8 *)&txnBuf->srcAddr, 0, sizeof(CmTptAddr));
   }

   txnBuf->event = event;
   node->info = (Ptr)txnBuf;

   /* now Add node into list  */
   list = &mgCb.encList;
   MG_ADD_NODE_INTO_STORELST(list, node);

   if((prot == CM_ABNF_PROT_MEGACO_H248) || (prot == CM_ABNF_PROT_MEGACO_H248_V2))
   {
      /* MEGACO case */
#ifdef GCP_MGCO
      MgMgcoMsg       *mgcoMsg;
      MgMgcoMsg       *errMsg;
      Buffer          *buf;

      /* Initialize all variables */
      errMsg = NULLP;
      mgcoMsg = (MgMgcoMsg *)event;

      /* added encoding support for errorDesc in msgBody */
      if (mgcoMsg->body.type.val == MGT_TXN)
         noOfMsg = mgcoMsg->body.u.tl.num.val;
      else
         noOfMsg = 0;

      buf = NULLP;
      /* MEGACO msg needs to be encoded into two steps ..first encode
       * msgBody..and encode each txn seperately */
      elmDef = &mgMgcoMsgDef;
      /* get memory for usrCxt */ 
      if((usrCxt = (MgGcpCxtToED *)mgMalloc(sizeof(MgGcpCxtToED))) == NULLP)
      {
         mgDeAlloc((Data *)node, sizeof(MgStoreList));
         RETVALUE(RFAILED);
      }
      /* Now get memory for txnBuf->encBuf */
      if((txnBuf->encBuf = 
           (MgEncBuffer **)mgMalloc((noOfMsg +1)* sizeof(MgEncBuffer *))) 
               == NULLP)
      {
         MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                tsap->tsapCfg.memId.region,
                                tsap->tsapCfg.memId.pool);
         mgFreeEncRsrc(&node, &txnBuf, (Ptr*)&usrCxt, 0 , prot, FALSE);
         RETVALUE(RFAILED);
      }
      if((txnBuf->encBuf[0] = 
            (MgEncBuffer *)mgMalloc(sizeof(MgEncBuffer ))) == NULLP)
      {
         mgFreeEncRsrc(&node, &txnBuf, (Ptr*)&usrCxt, noOfMsg, prot, FALSE);
         MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                tsap->tsapCfg.memId.region,
                                tsap->tsapCfg.memId.pool);
         RETVALUE(RFAILED);
      }
      /* get memory for Header */
      if(mgGetMsg(tsap->tsapCfg.memId.region,
                  tsap->tsapCfg.memId.pool, &buf)  != ROK)
      {
         mgFreeEncRsrc(&node, &txnBuf, (Ptr*)&usrCxt, noOfMsg, prot, FALSE);
         MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                tsap->tsapCfg.memId.region,
                                tsap->tsapCfg.memId.pool);
         RETVALUE(RFAILED);
      }
      /* Now send encode req to encode AuthHeader */ 
      txnBuf->encBuf[0]->buf = buf;
      txnBuf->encBuf[0]->status = MG_ENCODE_NONE;
      usrCxt->indx = nodeIndx;
      usrCxt->thisMsgNo = 0;
      if(encodingScheme == LMG_ENCODE_BIN)
      {
#ifdef GCP_ASN        
       ret = mgPstEncReq(encodingScheme ,prot, (Ptr )mgcoMsg, 0, buf,NULLP/*MAH_TODO*/, usrCxt, 
                        &(tsap->tsapCfg.memId),
                        node, source, TRUE, MGED_HDR_ENC);
#endif
      }
      else
      {
        ret = mgPstEncReq(encodingScheme ,prot, (Ptr )(&mgcoMsg->ver),0,/*MAH_TODO*/ buf, elmDef, usrCxt, 
                        &(tsap->tsapCfg.memId),
                        node, source, TRUE,0/*NOTUSED*/);
      }

      if(ret == RFAILED)
      {
         /* resources for txn which are already sent for Encode will be 
          * freed once cfm is rcvd or timer expires */ 
         mgPutMsg(buf);
         mgFreeEncRsrc(&node, &txnBuf, (Ptr*)&usrCxt, noOfMsg, prot, FALSE);
         MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                tsap->tsapCfg.memId.region,
                                tsap->tsapCfg.memId.pool);
         RETVALUE(RFAILED);
      }
      elmDef = &mgMgcoTxnDef;
      for(cnt = 0; cnt < noOfMsg; cnt++)
      {
         MgMgcoTxn     *txn;
         buf = NULLP;
         /* for each Transaction generate encode req */
         /* get memory for Header */
         txn = mgcoMsg->body.u.tl.txns[cnt];
         if((txnBuf->encBuf[cnt+1] = 
               (MgEncBuffer *)mgMalloc(sizeof(MgEncBuffer ))) == NULLP)
         {
            if(source == MG_USER)
            {
               /* only if source is User send txnReq Error to user */
               MG_ALLOC_MGCO_ERR_MSG(errMsg, mgcoMsg, cnt);
               if(errMsg == NULLP)
               {
                  MG_MGCO_FREE_NTH_TXN_ONWARD(mgcoMsg, cnt);
               }
               else
               {
                  mgHandleMgcoTxnReqErr(ssap, errMsg, 
                     MGT_ERR_RSRC_UNAVAIL,MG_USER);
               }
            }
            MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                   tsap->tsapCfg.memId.region,
                                   tsap->tsapCfg.memId.pool);
            /* Don't free node..and txnBuf..this will be freed after timer
             * expiry.or ..after rcving cfm..since ED thread already may 
             * processing some req */
            mgFreeEncRsrc(NULLP, NULLP, (Ptr*)&usrCxt, noOfMsg, prot, FALSE);
            RETVALUE(ROK);
         }
         if(mgGetMsg(tsap->tsapCfg.memId.region,
                     tsap->tsapCfg.memId.pool, &buf)  != ROK)
         {
            if(source == MG_USER)
            {
               /* only if source is User send txnReq Error to user */
               MG_ALLOC_MGCO_ERR_MSG(errMsg, mgcoMsg, cnt);
               if(errMsg == NULLP)
               {
                  MG_MGCO_FREE_NTH_TXN_ONWARD(mgcoMsg, cnt);
               }
               else
               {
                  mgHandleMgcoTxnReqErr(ssap, errMsg, 
                     MGT_ERR_RSRC_UNAVAIL,MG_USER);
               }
            }
            MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                   tsap->tsapCfg.memId.region,
                                   tsap->tsapCfg.memId.pool);
            mgFreeEncRsrc(NULLP, NULLP, (Ptr*)&usrCxt, noOfMsg, prot, FALSE);
            RETVALUE(ROK);
         }
         
         /* get memory for usrCxt */ 
         if((usrCxt = (MgGcpCxtToED *)mgMalloc(sizeof(MgGcpCxtToED))) == NULLP)
         {
            if(source == MG_USER)
            {
               /* only if source is User send txnReq Error to user */
               MG_ALLOC_MGCO_ERR_MSG(errMsg, mgcoMsg, cnt);
               if(errMsg == NULLP)
               {
                  MG_MGCO_FREE_NTH_TXN_ONWARD(mgcoMsg, cnt);
               }
               else
               {
                  mgHandleMgcoTxnReqErr(ssap, errMsg, 
                     MGT_ERR_RSRC_UNAVAIL,MG_USER);
               }
            }
            MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                   tsap->tsapCfg.memId.region,
                                   tsap->tsapCfg.memId.pool);
            mgFreeEncRsrc(NULLP, NULLP, (Ptr*)&usrCxt, noOfMsg, prot, FALSE);
            mgPutMsg(buf);
            RETVALUE(ROK);
         }
         /* Now send encode req to encode AuthHeader */ 
         txnBuf->encBuf[cnt+1]->buf = buf;
         txnBuf->encBuf[cnt+1]->status = MG_ENCODE_NONE;
         usrCxt->indx = nodeIndx;
         usrCxt->thisMsgNo = cnt+1;
         /* Call fn to post this encode req to one of ED instance */
      if(encodingScheme == LMG_ENCODE_BIN)
      {
#ifdef GCP_ASN
         ret = mgPstEncReq(encodingScheme ,prot, (Ptr)mgcoMsg, cnt, buf, NULLP, usrCxt, 
                           &(tsap->tsapCfg.memId),
                           node, source, FALSE,MGED_TXN_ENC );
         if (ret != RFAILED) 
         {
            ret = mgPrepSend(CM_ABNF_PROT_MEGACO_H248, buf, (CmMemListCp *)(mgcoMsg));
         }
#endif
      }
      else
      {
         ret = mgPstEncReq(encodingScheme ,prot, (Ptr)&(txn->type), cnt,buf, elmDef, usrCxt, &(tsap->tsapCfg.memId), node, source, FALSE,0);
      }
         if(ret == RFAILED)
         {
            /* resources for txn which are already sent for Encode will be 
            * freed once cfm is rcvd or timer expires */ 
            mgPutMsg(buf);
            if(source == MG_USER)
            {
               /* only if source is User send txnReq Error to user */
               MG_ALLOC_MGCO_ERR_MSG(errMsg, mgcoMsg, cnt);
               if(errMsg == NULLP)
               {
                  MG_MGCO_FREE_NTH_TXN_ONWARD(mgcoMsg, cnt);
               }
               else
               {
                  mgHandleMgcoTxnReqErr(ssap, errMsg, 
                     MGT_ERR_RSRC_UNAVAIL,MG_USER);
               }
            }
            mgFreeEncRsrc(NULLP, NULLP, (Ptr*)&usrCxt, noOfMsg, prot, FALSE);
            RETVALUE(ROK);
         }
      }
#endif /* GCP_MGCO */
   }
#ifdef GCP_MGCP
   else
   {
      MgMgcpTxn   *txn;
      MgMgcpTxn   *errTxn;

      /* Initaialize all variables */
      errTxn = NULLP;
      elmDef = &mgMsgDef;
      txn = ((MgMgcpTxn *)event);

      noOfMsg = txn->numMsg;
      /* Now get memory for txnBuf->encBuf */
      if((txnBuf->encBuf = 
         (MgEncBuffer **)mgMalloc(noOfMsg * sizeof(MgEncBuffer *))) == NULLP)
      {
         MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                tsap->tsapCfg.memId.region,
                                tsap->tsapCfg.memId.pool);
         /* Don't free event struct..it will be freed in calling fn */
         mgFreeEncRsrc(&node, &txnBuf, (Ptr*)&usrCxt, 0 , prot, FALSE);
         RETVALUE(RFAILED);
      }
      for(cnt =0;cnt <noOfMsg; cnt++)
      {
         Buffer      *buf;
         MgMgcpMsg   *msg;
         Bool        strtTmr;
        
         buf = NULLP; 
         strtTmr = TRUE;
         msg = ((MgMgcpTxn *)event)->mgcpMsg[cnt];
         /* get each encBuf */
         if((txnBuf->encBuf[cnt] = 
               (MgEncBuffer *)mgMalloc(sizeof(MgEncBuffer ))) == NULLP)
         {
            /* only if source is User send txnReq Error to user */
            if(source == MG_USER)
            {
               MG_ALLOC_MGCP_ERR_MSG(errTxn, txn, cnt);
               if(errTxn == NULLP)
               {
                  MG_MGCP_FREE_NTH_TXN_ONWARD(txn, cnt);
               }
               else
               {
                  mgHandleMgcpTxnReqErr(ssap, errTxn, MGT_ERR_RSRC_UNAVAIL);
               }
                /* txnBuf->event = NULLP; */
            }
            MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                   tsap->tsapCfg.memId.region,
                                   tsap->tsapCfg.memId.pool);
            /* Don't free node if some of encode req is already sent to
             * Encoder / Decoder thread */
            /* Don't free event struct..it will be freed in calling fn */
            if(cnt == 0)
              mgFreeEncRsrc(&node, &txnBuf, (Ptr*)&usrCxt,
                            noOfMsg, prot, FALSE);
            RETVALUE(RFAILED);
         }
         /* for every txn get one buffer */
         if(mgGetMsg(tsap->tsapCfg.memId.region,
                     tsap->tsapCfg.memId.pool, &buf)  != ROK)
         {
            /* Txn which are sent for Encode will be freed once cfm is rcvd or
             * timer expires */ 
               /* only if source is User send txnReq Error to user */
            if(source == MG_USER)
            {
               MG_ALLOC_MGCP_ERR_MSG(errTxn, txn, cnt);
               if(errTxn == NULLP)
               {
                  MG_MGCP_FREE_NTH_TXN_ONWARD(txn, cnt);
               }
               else
               {
                  mgHandleMgcpTxnReqErr(ssap, errTxn, MGT_ERR_RSRC_UNAVAIL);
               }
               /*txnBuf->event = NULLP; */
            }
            MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                   tsap->tsapCfg.memId.region,
                                   tsap->tsapCfg.memId.pool);
            /* Don't free node if some of encode req is already sent to
             * Encoder / Decoder thread */
            if(cnt == 0)
               mgFreeEncRsrc(&node, &txnBuf, (Ptr*)&usrCxt,
                             noOfMsg, prot, TRUE);
            RETVALUE(RFAILED);
         }
         txnBuf->encBuf[cnt]->buf = buf;
         txnBuf->encBuf[cnt]->status = MG_ENCODE_NONE;
         /* get memory for usrCxt */ 
         if((usrCxt = (MgGcpCxtToED *)mgMalloc(sizeof(MgGcpCxtToED))) == NULLP)
         {
            if(source == MG_USER)
            {
               /* only if source is User send txnReq Error to user */
               MG_ALLOC_MGCP_ERR_MSG(errTxn, txn, cnt);
               if(errTxn == NULLP)
               {
                  MG_MGCP_FREE_NTH_TXN_ONWARD(txn, cnt);
               }
               else
               {
                  mgHandleMgcpTxnReqErr(ssap, errTxn, MGT_ERR_RSRC_UNAVAIL);
               }
               /* txnBuf->event = NULLP; */
            }
            MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                   tsap->tsapCfg.memId.region,
                                   tsap->tsapCfg.memId.pool);
            mgPutMsg(buf);
            /* Don't free node if some of encode req is already sent to
             * Encoder / Decoder thread */
            if(cnt == 0)
               mgFreeEncRsrc(&node, &txnBuf, NULLP, noOfMsg, prot, TRUE);
            RETVALUE(RFAILED);
         }

         usrCxt->indx = nodeIndx;
         usrCxt->thisMsgNo = cnt;
         /* if cnt is more than zero..this means timer is already started before
          * so don't start it again */
         if(cnt > 0)
            strtTmr = FALSE;
      if(encodingScheme == LMG_ENCODE_BIN)
      {
#ifdef GCP_ASN
         ret = mgPstEncReq(encodingScheme ,prot, msg, 0, buf, MGED_MGCP, usrCxt, 
                           &(tsap->tsapCfg.memId),
                           node, source, strtTmr,MGED_MGCP);
#endif
      }
      else
      { 
         ret = mgPstEncReq(encodingScheme ,prot, &(encodingScheme ,msg->msgType),0, buf, elmDef, usrCxt, 
                           &(tsap->tsapCfg.memId),
                           node, source, strtTmr,0);
      }
         if(ret == RFAILED)
         {
            /* resources for txn which are already sent for Encode will be 
             * freed once cfm is rcvd or timer expires */ 
            if(source == MG_USER)
            {
               /* only if source is User send txnReq Error to user */
               MG_ALLOC_MGCP_ERR_MSG(errTxn, txn, cnt);
               if(errTxn == NULLP)
               {
                  MG_MGCP_FREE_NTH_TXN_ONWARD(txn, cnt);
               }
               else
               {
                  mgHandleMgcpTxnReqErr(ssap, errTxn, MGT_ERR_RSRC_UNAVAIL);
               }
               /* txnBuf->event = NULLP; */
            }
            MG_GEN_RSRC_CATEG_ALRM(STTSAP, LCM_EVENT_DMEM_ALLOC_FAIL,
                                   tsap->tsapCfg.memId.region,
                                   tsap->tsapCfg.memId.pool);
            mgDeAlloc(((Data *)usrCxt), sizeof(MgGcpCxtToED));
            mgPutMsg(buf);
            /* Don't free node if some of encode req is already sent to
             * Encoder / Decoder thread */
            if(cnt == 0)
               mgFreeEncRsrc(&node, &txnBuf, (Ptr*)NULLP, noOfMsg, prot, TRUE);
            RETVALUE(RFAILED);
         }
      }
   }
#endif /* GCP_MGCP */
   RETVALUE(ROK);
  
} /* mgSndEncPduMsgReq */

/* packing/unpacking functions */


/*
*
*    Fun:    cmPkMedEncReq
*
*    Desc:    pack the primitive Encode Req
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_ed.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkMedEncReq
(
U8             encodingScheme,
Pst            *pst,           /* post structure */
U32            protVar,        /* protocol variant */
U8             *event,         /* event structure */
U32            txnIndx,        /* transaction index */
Buffer         *encBuf,         /* encoded buffer */
CmAbnfElmDef   *elmDef,        /* root of database tree */
U16            elmDef1,
Mem            *mem,           /* memory region/pool */ 
Ptr            usrCxt          /* user context */
)
#else
PRIVATE S16 cmPkMedEncReq(encodingScheme ,pst, protVar, event, txnIndx, encBuf, elmDef,elmDef1 mem, usrCxt)
U8             encodingScheme;
Pst            *pst;           /* post structure */
U32            protVar;        /* protocol variant */
U8             *event;         /* event structure */
U32            txnIndx;        /* transaction index */
Buffer         *encBuf;        /* encoded buffer */
CmAbnfElmDef   *elmDef;        /* root of database tree */
U16            elmDef1;        /* root of database tree */
Mem            *mem;           /* memory region/pool */ 
Ptr            usrCxt;         /* user context */
#endif
{
    S16        ret1;
    Buffer     *mBuf;

    TRC3(cmPkMedEncReq)

    mBuf = NULLP;

    if((ret1 = mgGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMG064, (ErrVal)0, "mgGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(SPkU32, protVar, mBuf, EMG065, pst);
#ifdef GCP_ASN    
    if( encodingScheme == LMG_ENCODE_BIN)
    {
       CMCHKPKLOG(cmPkPtr, mwrapEvntGet((PTR)event, MG_WRAP_ENC_TYPE, elmDef1, txnIndx), mBuf, EMG066, pst); 
    
    }
    else
    {  
#endif      
     CMCHKPKLOG(cmPkPtr, (PTR)event, mBuf, EMG067, pst); 
#ifdef GCP_ASN    
    }
#endif
    CMCHKPKLOG(cmPkPtr, (PTR)encBuf, mBuf, EMG068, pst); 
#ifdef GCP_ASN    
    if( encodingScheme == LMG_ENCODE_BIN)
    {
      CMCHKPKLOG(cmPkPtr, mwrapElmDefGet(MG_WRAP_ENC_TYPE, elmDef1, txnIndx), mBuf, EMG069, pst); 
    }
    else
    {
#endif
      CMCHKPKLOG(cmPkPtr, (PTR)elmDef, mBuf, EMG070, pst); 
    
#ifdef GCP_ASN    
    }
#endif     
    /* Now pack error->idNum and error->code */
    CMCHKPKLOG(cmPkRegion, mem->region, mBuf, EMG071, pst);
    CMCHKPKLOG(cmPkPool, mem->pool, mBuf, EMG072, pst);
    CMCHKPKLOG(cmPkPtr, (PTR)usrCxt, mBuf, EMG073, pst); 
    
    if( encodingScheme == LMG_ENCODE_BIN)
    {
       pst->event = (Event)MG_WRAP_ASN_ENCREQ;
    }
    else
    {
      pst->event  = MG_WRAP_ABNF_ENCREQ;
    }
    RETVALUE(SPstTsk(pst,mBuf));
} /* end of function cmPkMedEncReq */



/*
*
*    Fun:    cmPkMedDecReq
*
*    Desc:    pack the primitive Decode Req
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mp_ed.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkMedDecReq
(
U8             encodingScheme,
Pst            *pst,           /* post structure */
U32            protVar,        /* protocol variant */
U8             *event,         /* event structure */
Buffer         *decBuf,        /* encoded buffer */
CmAbnfElmDef   *elmDef,        /* root of database tree */
U16            elmDef1,         /* root of database tree */
CmMemListCp    *memCp,         /* memory region/pool */ 
Ptr            usrCxt          /* user context */
)
#else
PRIVATE S16 cmPkMedDecReq(encodingScheme,pst, protVar, event, decBuf, elmDef, elmDef1,memCp, usrCxt)
U8             encodingScheme;
Pst            *pst;           /* post structure */
U32            protVar;        /* protocol variant */
U8             *event;         /* event structure */
Buffer         *decBuf;        /* encoded buffer */
CmAbnfElmDef   *elmDef;        /* root of database tree */
U16            elmDef1;         /* root of database tree */
CmMemListCp    *memCp;         /* memory region/pool */ 
Ptr            usrCxt;         /* user context */
#endif
{
    S16        ret1;
    Buffer     *mBuf;

    TRC3(cmPkMedDecReq)

    mBuf = NULLP;

    if((ret1 = mgGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMG074, (ErrVal)0, "mgGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(SPkU32, protVar, mBuf, EMG075, pst);
    CMCHKPKLOG(cmPkPtr, (PTR)event, mBuf, EMG076, pst); 
    CMCHKPKLOG(cmPkPtr, (PTR)decBuf, mBuf, EMG077, pst); 
#ifdef GCP_ASN
    if(encodingScheme == LMG_ENCODE_BIN )
    {
      CMCHKPKLOG(cmPkPtr, mwrapElmDefGet(MG_WRAP_ASN, elmDef1, 0), mBuf, EMG078, pst); 
    }else
    {
#endif
     CMCHKPKLOG(cmPkPtr, (PTR)elmDef, mBuf, EMG079, pst); 
#ifdef GCP_ASN
    }
#endif
    CMCHKPKLOG(cmPkPtr, (PTR)memCp, mBuf, EMG080, pst); 
    CMCHKPKLOG(cmPkPtr, (PTR)usrCxt, mBuf, EMG081, pst); 
#ifdef GCP_ASN
    if(encodingScheme ==LMG_ENCODE_BIN )
    {
     pst->event = (Event)MG_WRAP_ASN_DECREQ;
    }else
    {  
#endif
     pst->event = (Event)  MG_WRAP_ABNF_DECREQ;
#ifdef GCP_ASN
    }
#endif
    RETVALUE(SPstTsk(pst,mBuf));
} /* end of function cmPkMedDecReq */



/*
*
*       Fun:   cmUnpkMedDecCfm
*
*       Desc:  Unpack Dec Cfm
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_abnf.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMedDecCfm
(
MedDecCfm  func,                    /* function */
Pst        *pst,                    /* post structure */
Buffer     *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkMedDecCfm(func, pst, mBuf)
MedDecCfm  func;                    /* function */
Pst        *pst;                    /* post structure */
Buffer     *mBuf;                   /* message buffer */
#endif
{

   U32            protVar;          /* protocol variant */
   U16            numDecBytes;      /* no. of decoded bytes */
   U8             *event;           /* event structure */
   Buffer         *decBuf;          /* Buffer */
   Ptr            usrCxt;           /* user context */
   CmAbnfErr      err;              /* error */
    
   TRC3(cmUnpkMedDecCfm)
   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&event, mBuf, EMG082, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&usrCxt, mBuf, EMG083, pst);
   CMCHKUNPKLOG(SUnpkU16,    &err.idNum, mBuf, EMG084, pst);
   CMCHKUNPKLOG(SUnpkU16,    &err.code, mBuf, EMG085, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&decBuf, mBuf, EMG086, pst);
/* Corrected the unpack function call below.  */
   CMCHKUNPKLOG(cmUnpkMsgLen, (PTR *)&numDecBytes, mBuf, EMG087, pst);
   CMCHKUNPKLOG(SUnpkU32,   &protVar, mBuf, EMG088, pst);
   mgPutMsg(mBuf);
   /* call the primitive */
   (*func)(protVar, event, decBuf, numDecBytes, &err, usrCxt);

   RETVALUE(ROK);
} /* end of cmUnpkMedDecCfm */




/*
*
*       Fun:   cmUnpkMedEncCfm
*
*       Desc:  Unpack Encode Cfm
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  mp_ed.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMedEncCfm
(
MedEncCfm  func,                    /* function */
Pst        *pst,                    /* post structure */
Buffer     *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkMedEncCfm(func, pst, mBuf)
MedEncCfm  func;                    /* function */
Pst        *pst;                    /* post structure */
Buffer     *mBuf;                   /* message buffer */
#endif
{

   U32            protVar;          /* protocol variant */
   Buffer         *encBuf;          /* Buffer */
   Ptr            usrCxt;           /* user context */
   CmAbnfErr      err;              /* error */
   U8             *event;           /* event */
    
   TRC3(cmUnpkMedEncCfm)
   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&usrCxt, mBuf, EMG089, pst);
   CMCHKUNPKLOG(SUnpkU16,    &err.idNum, mBuf, EMG090, pst);
   CMCHKUNPKLOG(SUnpkU16,    &err.code, mBuf, EMG091, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&encBuf, mBuf, EMG092, pst);
   CMCHKUNPKLOG(SUnpkU32,   &protVar, mBuf, EMG093, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&event, mBuf, EMG094, pst);

   mgPutMsg(mBuf);
   /* call the primitive */
   (*func)(protVar, event, encBuf, &err, usrCxt);

   RETVALUE(ROK);
} /* end of cmUnpkMedEncCfm */

#endif /* CM_ABNF_MT_LIB */
#endif /* MG */


/********************************************************************30**
 
        End of file:     mp_ed.c@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:53:29 2005
*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------

/main/1      ---      ra   1. GCP 1.3 release
            mg011.103 ra   1. Now freeing SDP Tkn Buf wherever we are
                              freeing the event structures through the
                              call to the function mgFreeEventMem.
                           2. Corrected the unpack function call for
                              numDecBytes. This patch should be applied
                              along with the common file patches -
                              cm_abnf_c_004.main_6
                              cm_abnf_x_002.main_5
            mg013.103 ra   1. Changes for supporting errorDesc in msgBody.
/main/2      ---      ka   1. Changes for Release v 1.4
            mg005.104 ra   1. FTHA related changes.
/main/3      ---      pk   1. GCP 1.5 release
            mg002.105 ps   1. Extern moved from mg.x for g++ compilation issue
                           2. Removed patch reference for 1.3
            mg007.105 gk   1. Added code to retrieve error statistics
*********************************************************************91*/
