/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     GCP - MGT interface

     Type:     C source file

     Desc:     C source for selector entry points to the upper user

     File:     mg_ptui.c

     Sid:      mp_ptui.c@@/main/6 - Wed Mar 30 07:58:44 2005

     Prg:      rrp

*********************************************************************21*/

/* ---- MGT interface ---- */
/*

the following matrices define the mapping between the primitives
called by the upper interface of MGCP and the corresponding
primitives of the MGCP service user(s).

The parameter MAXMGUIMGT defines the maximum number of service users on
top of MGCP. There is an array of functions per primitive
invoked by MGCP.

The dispatching is performed by the configurable variable: selector.
The selectors are:

   0 - loosely coupled (#define LCMULIMGT)
   1 - application (#define MG)

*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* common hash functions */
#include "cm5.h"           /* common timer functions */
#include "cm_llist.h"      /* common linked list */
#include "cm_inet.h"       /* common sockets lib */
#include "cm_tpt.h"        /* common transport */
#include "cm_mblk.h"       /* ASN memory management */
#include "cm_abnf.h"  
#include "cm_tkns.h"       /* common tokens */
#include "cm_dns.h"        /* common DNS library defines */
#ifdef ZG
#include "cm_ftha.h"       /* common FTHA defines */
#include "cm_psfft.h"      /* common PSF defines */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.h"           /* SHT Interface header file */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.h"        /* Common SS7 defines */
#include "snt.h"           /* MTP3 Interface defines */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.h"           /* upper interface */
#include "lmg.h"           /* layer management interface */
#include "cm_sdp.h"        /* SDP related constants */
#include "mg.h"            /* MGCP contol related */
#include "hit.h"           /* TUCL layer */
#include "mg_err.h"        /* MGCP error */
#ifdef ZG
#include "mrs.h"           /* Message Router defines */   
#include "zgrvupd.h"       /* Reverse update defines */
#include "lzg.h"           /* PSF Layer Management */
#include "zg.h"            /* PSF Defines */
#endif /* ZG */


#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* hashing functions */
#include "cm5.x"           /* timer functions */
#include "cm_llist.x"      /* common linked list */
#include "cm_lib.x"        /* common lib */
#include "cm_inet.x"       /* common sockets lib */
#include "cm_tpt.x"        /* common transport */
#include "cm_mblk.x"       /* ASN memory management */
#include "cm_abnf.x"  
#include "cm_tkns.x"       /* common tokens */
#include "cm_dns.x"        /* common DNS library defines */
#include "cm_sdp.x"        /* SDP related types */
#ifdef ZG
#include "cm_ftha.x"       /* common FTHA typedefs */
#include "cm_psfft.x"      /* common PSF typedefs */
#endif /* ZG */
#if (defined(MG_FTHA) || defined(MG_RUG))
#include "sht.x"           /* SHT Interface typedef's  */
#endif /* MG_FTHA || MG_RUG */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include "cm_ss7.x"        /* Common SS7 structure */
#include "snt.x"           /* MTP3 Interface structure */
#endif   /* GCP_PROV_MTP3 */


#include "mgt.x"           /* upper interface */
#include "lmg.x"           /* layer management interface */
#include "mg.x"            /* MGCP contol related */
#ifdef ZG
#include "mrs.x"           /* Message Router typedefs */ 
#include "zgrvupd.x"       /* Reverse update structures */
#include "lzg.x"           /* PSF Layer Management */
#include "zg.x"            /* PSF Data Structures */
#endif /* ZG */



/************************************************************************
                              Prototypes  
************************************************************************/

#if !(defined(LCMGUIMGT) && defined(MU) && defined (LWLCMGUIMGT))
#define PTMGUIMGT
#endif /* !(defined(LCMGUIMGT) && defined(MU) && defined (LWLCMGUIMGT)) */

#ifdef PTMGUIMGT
EXTERN S16 PtUiMgtBndCfm ARGS((Pst *post, SuId suId, U8 status));
EXTERN S16 PtUiMgtCntrlCfm ARGS((Pst *pst,SpId spId, MgMgtCntrl *cntrl, 
                                     Reason reason));
EXTERN S16 PtUiMgtAuditCfm ARGS((Pst *pst,SpId spId, MgMgtAudit *audit, 
                                     Reason reason));
EXTERN S16 PtUiMgtStaInd ARGS((Pst *pst,SuId suId,MgMgtSta *sta));

#ifdef GCP_MGCP
EXTERN S16 PtUiMgtMgcpTxnInd ARGS((Pst *post, SuId suId, MgMgcpTxn  *mgTxn));
#endif /* GCP_MGCP */

#ifdef GCP_MGCO
EXTERN S16 PtUiMgtMgcoTxnInd ARGS((Pst *post, SuId suId, MgMgcoMsg  *mgTxn));
 
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
EXTERN S16 PtUiMgtMgcoCmdInd ARGS((Pst *post, SuId suId, MgMgcoCommand  *mgTxn));
EXTERN S16 PtUiMgtMgcoUpdCtxtInd ARGS((Pst *post, SuId suId, MgMgcoUpdateCntxt *mgTxn));
EXTERN S16 PtUiMgtMgcoTxnStaInd ARGS((Pst *post, SuId suId, MgMgcoInd *mgTxn));
EXTERN S16 cmPkMgtMgcoCmdInd ARGS((Pst *post, SpId spId, MgMgcoCommand *mgInd));
EXTERN S16 cmPkMgtMgcoUpdCtxtInd ARGS((Pst *post, SpId spId, MgMgcoUpdateCntxt*mgCntxt));
EXTERN S16 cmPkMgtMgcoTxnStaInd ARGS((Pst *post, SpId spId, MgMgcoInd *mgInd));
#endif /* GCP_CH && GCP_VER_1_5 */ 
#endif /* GCP_MGCO */

#endif /* PTMGUIMGT */



/************************************************************************
                                Matrices
************************************************************************/
PUBLIC MgtBndCfm mgUiMgtBndCfmMt [] =
{
#ifdef LCMGUIMGT
   cmPkMgtBndCfm,        /* 0 - loosely coupled */
#else
   PtUiMgtBndCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef MU
   MuLiMgtBndCfm,        /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtBndCfm,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMGUIMGT
   cmPkMgtBndCfm,        /* 0 - loosely coupled */
#else
   PtUiMgtBndCfm,        /* 0 - loosely coupled, portable */
#endif

#ifdef AG
   AgLiMgtBndCfm,        /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtBndCfm,        /* 1 - tightly coupled, portable */
#endif /*AG */

#ifdef LCMGUIMGT
   cmPkMgtBndCfm,        /* 0 - loosely coupled */
#else
   PtUiMgtBndCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef LWLCMGUIMGT
   cmPkMgtBndCfm,        /* 0 - loosely coupled */
#else
   PtUiMgtBndCfm,        /* 0 - loosely coupled, portable */
#endif
 
};


PUBLIC MgtCntrlCfm mgUiMgtCntrlCfmMt [] =
{
#ifdef LCMGUIMGT
   cmPkMgtCntrlCfm,        /* 0 - loosely coupled */
#else
   PtUiMgtCntrlCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef MU
   MuLiMgtCntrlCfm,        /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtCntrlCfm,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMGUIMGT
   cmPkMgtCntrlCfm,        /* 0 - loosely coupled */
#else
   PtUiMgtCntrlCfm,        /* 0 - loosely coupled, portable */
#endif
 
#ifdef AG
   AgLiMgtCntrlCfm,        /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtCntrlCfm,        /* 1 - tightly coupled, portable */
#endif /*AG */

#ifdef LCMGUIMGT
   cmPkMgtCntrlCfm,        /* 0 - loosely coupled */
#else
   PtUiMgtCntrlCfm,        /* 0 - loosely coupled, portable */
#endif

#ifdef LWLCMGUIMGT
   cmPkMgtCntrlCfm,        /* 0 - loosely coupled */
#else
   PtUiMgtCntrlCfm,        /* 0 - loosely coupled, portable */
#endif
 
};



PUBLIC MgtAuditCfm mgUiMgtAuditCfmMt [] =
{
#ifdef LCMGUIMGT
   cmPkMgtAuditCfm,        /* 0 - loosely coupled */
#else
   PtUiMgtAuditCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef MU
   MuLiMgtAuditCfm,        /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtAuditCfm,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMGUIMGT
   cmPkMgtAuditCfm,        /* 0 - loosely coupled */
#else
   PtUiMgtAuditCfm,        /* 0 - loosely coupled, portable */
#endif
 
#ifdef AG
   AgLiMgtAuditCfm,        /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtAuditCfm,        /* 1 - tightly coupled, portable */
#endif /*AG */

#ifdef LCMGUIMGT
   cmPkMgtAuditCfm,        /* 0 - loosely coupled */
#else
   PtUiMgtAuditCfm,        /* 0 - loosely coupled, portable */
#endif

#ifdef LWLCMGUIMGT
   cmPkMgtAuditCfm,        /* 0 - loosely coupled */
#else
   PtUiMgtAuditCfm,        /* 0 - loosely coupled, portable */
#endif
 
};



PUBLIC MgtStaInd mgUiMgtStaIndMt [] =
{
#ifdef LCMGUIMGT
   cmPkMgtStaInd,        /* 0 - loosely coupled */
#else
   PtUiMgtStaInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef MU
   MuLiMgtStaInd,        /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtStaInd,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMGUIMGT
   cmPkMgtStaInd,        /* 0 - loosely coupled */
#else
   PtUiMgtStaInd,        /* 0 - loosely coupled, portable */
#endif
 
#ifdef AG
   AgLiMgtStaInd,        /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtStaInd,        /* 1 - tightly coupled, portable */
#endif /*AG */
 
#ifdef LCMGUIMGT
   cmPkMgtStaInd,        /* 0 - loosely coupled */
#else
   PtUiMgtStaInd,        /* 0 - loosely coupled, portable */
#endif

#ifdef LWLCMGUIMGT
   cmPkMgtStaInd,        /* 0 - loosely coupled */
#else
   PtUiMgtStaInd,        /* 0 - loosely coupled, portable */
#endif

};





#ifdef GCP_MGCP
PUBLIC MgtMgcpTxnInd mgUiMgtMgcpTxnIndMt [] =
{
#ifdef LCMGUIMGT
   cmPkMgtMgcpTxnInd,        /* 0 - loosely coupled */
#else
   PtUiMgtMgcpTxnInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef MU
   MuLiMgtMgcpTxnInd,        /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtMgcpTxnInd,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMGUIMGT
   cmPkMgtMgcpTxnInd,        /* 0 - loosely coupled */
#else
   PtUiMgtMgcpTxnInd,        /* 0 - loosely coupled, portable */
#endif

#ifdef LCMGUIMGT
   cmPkMgtMgcpTxnInd,        /* 0 - loosely coupled */
#else
   PtUiMgtMgcpTxnInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef LWLCMGUIMGT
   cmPkMgtMgcpTxnInd,        /* 0 - loosely coupled */
#else
   PtUiMgtMgcpTxnInd,        /* 0 - loosely coupled, portable */
#endif
};
#endif /* GCP_MGCP */



#ifdef GCP_MGCO
 
PUBLIC MgtMgcoTxnInd mgUiMgtMgcoTxnIndMt [] =
{
#ifdef LCMGUIMGT
   cmPkMgtMgcoTxnInd,        /* 0 - loosely coupled */
#else
   PtUiMgtMgcoTxnInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef MU
   MuLiMgtMgcoTxnInd,        /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtMgcoTxnInd,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMGUIMGT
   cmPkMgtMgcoTxnInd,        /* 0 - loosely coupled */
#else
   PtUiMgtMgcoTxnInd,        /* 0 - loosely coupled, portable */
#endif
 
#ifdef AG
   AgLiMgtMgcoTxnInd,        /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtMgcoTxnInd,        /* 1 - tightly coupled, portable */
#endif /*AG */

#ifdef LCMGUIMGT
   cmPkMgtMgcoTxnInd,        /* 0 - loosely coupled */
#else
   PtUiMgtMgcoTxnInd,        /* 0 - loosely coupled, portable */
#endif

#ifdef LWLCMGUIMGT
   cmPkMgtMgcoTxnInd,        /* 0 - loosely coupled */
#else
   PtUiMgtMgcoTxnInd,        /* 0 - loosely coupled, portable */
#endif
 
};
 
/* Command Primitives  */
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
 
PUBLIC MgtMgcoCmdInd mgUiMgtMgcoCmdIndMt [] =
{
#ifdef LCMGUIMGT
   cmPkMgtMgcoCmdInd,       /* 0 - loosely coupled */
#else
   PtUiMgtMgcoCmdInd,       /* 0 - loosely coupled, portable */
#endif
#ifdef MU
   MuLiMgtMgcoCmdInd,       /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtMgcoCmdInd,       /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMGUIMGT
   cmPkMgtMgcoCmdInd,       /* 0 - loosely coupled */
#else
   PtUiMgtMgcoCmdInd,       /* 0 - loosely coupled, portable */
#endif
 
#ifdef AG
   AgLiMgtMgcoCmdInd,       /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtMgcoCmdInd,       /* 1 - tightly coupled, portable */
#endif /*AG */

#ifdef LCMGUIMGT
   cmPkMgtMgcoCmdInd,       /* 0 - loosely coupled */
#else
   PtUiMgtMgcoCmdInd,       /* 0 - loosely coupled, portable */
#endif

#ifdef LWLCMGUIMGT
   cmPkMgtMgcoCmdInd,       /* 0 - loosely coupled */
#else
   PtUiMgtMgcoCmdInd,       /* 0 - loosely coupled, portable */
#endif
 
};
 
PUBLIC MgtMgcoUpdCtxtInd mgUiMgtMgcoUpdCtxtIndMt [] =
{
#ifdef LCMGUIMGT
   cmPkMgtMgcoUpdCtxtInd,   /* 0 - loosely coupled */
#else
   PtUiMgtMgcoUpdCtxtInd,   /* 0 - loosely coupled, portable */
#endif
#ifdef MU
   MuLiMgtMgcoUpdCtxtInd,   /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtMgcoUpdCtxtInd,   /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMGUIMGT
   cmPkMgtMgcoUpdCtxtInd,   /* 0 - loosely coupled */
#else
   PtUiMgtMgcoUpdCtxtInd,   /* 0 - loosely coupled, portable */
#endif
 
#ifdef AG
   AgLiMgtMgcoUpdCtxtInd,   /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtMgcoUpdCtxtInd,   /* 1 - tightly coupled, portable */
#endif /*AG */
 
#ifdef LCMGUIMGT
   cmPkMgtMgcoUpdCtxtInd,   /* 0 - loosely coupled */
#else
   PtUiMgtMgcoUpdCtxtInd,   /* 0 - loosely coupled, portable */
#endif

#ifdef LWLCMGUIMGT
   cmPkMgtMgcoUpdCtxtInd,   /* 0 - loosely coupled */
#else
   PtUiMgtMgcoUpdCtxtInd,   /* 0 - loosely coupled, portable */
#endif
};
 
PUBLIC MgtMgcoTxnStaInd mgUiMgtMgcoTxnStaIndMt[] =
{
#ifdef LCMGUIMGT
   cmPkMgtMgcoTxnStaInd,   /* 0 - loosely coupled */
#else
   PtUiMgtMgcoTxnStaInd,   /* 0 - loosely coupled, portable */
#endif
#ifdef MU
   MuLiMgtMgcoTxnStaInd,   /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtMgcoTxnStaInd,   /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCMGUIMGT
   cmPkMgtMgcoTxnStaInd,   /* 0 - loosely coupled */
#else
   PtUiMgtMgcoTxnStaInd,   /* 0 - loosely coupled, portable */
#endif
 
#ifdef AG
   AgLiMgtMgcoTxnStaInd,   /* 1 - tightly coupled, stub layer */
#else
   PtUiMgtMgcoTxnStaInd,  /* 1 - tightly coupled, portable */
#endif /*AG */

#ifdef LCMGUIMGT
   cmPkMgtMgcoTxnStaInd,   /* 0 - loosely coupled */
#else
   PtUiMgtMgcoTxnStaInd,   /* 0 - loosely coupled, portable */
#endif

#ifdef LWLCMGUIMGT
   cmPkMgtMgcoTxnStaInd,   /* 0 - loosely coupled */
#else
   PtUiMgtMgcoTxnStaInd,   /* 0 - loosely coupled, portable */
#endif
 
};

#endif /* GCP_CH && GCP_VER_1_5 */ 
 
#endif /* GCP_MGCO */



/************************************************************************
                       Upper Interface Functions
************************************************************************/


/*
 *
 *       Fun:   MgUiMgtBndCfm
 *
 *       Desc:  This function resolves the MgtBndCfm primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgUiMgtBndCfm
(
Pst *post,
SuId suId,
U8 status
)
#else 
PUBLIC S16 MgUiMgtBndCfm (post, suId, status)
Pst *post;
SuId suId;
U8 status;
#endif
{
   TRC3(MgUiMgtBndCfm)

   (*mgUiMgtBndCfmMt[post->selector])
      (post, suId, status);

   RETVALUE(ROK);
}





/*
 *
 *       Fun:   MgUiMgtCntrlCfm
 *
 *       Desc:  This function resolves the MgtCntrlCfm primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgUiMgtCntrlCfm
(
Pst *post,
SuId suId,
MgMgtCntrl *cntrl,
Reason reason
)
#else 
PUBLIC S16 MgUiMgtCntrlCfm (post, suId, cntrl, reason)
Pst *post;
SuId suId;
MgMgtCntrl *cntrl;
Reason reason;
#endif
{
   TRC3(MgUiMgtCntrlCfm)

   (*mgUiMgtCntrlCfmMt[post->selector])(post, suId, cntrl, reason);
   RETVALUE(ROK);
}






/*
 *
 *       Fun:   MgUiMgtAuditCfm
 *
 *       Desc:  This function resolves the MgtAuditCfm primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgUiMgtAuditCfm
(
Pst *post,
SuId suId,
MgMgtAudit *audit,
Reason reason
)
#else 
PUBLIC S16 MgUiMgtAuditCfm (post, suId, audit, reason)
Pst *post;
SuId suId;
MgMgtAudit *audit;
Reason reason;
#endif
{
   TRC3(MgUiMgtAuditCfm)

   (*mgUiMgtAuditCfmMt[post->selector])(post, suId, audit, reason);

   RETVALUE(ROK);
}




/*
 *
 *       Fun:   MgUiMgtStaInd
 *
 *       Desc:  This function resolves the MgtStaInd primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgUiMgtStaInd
(
Pst *post,
SuId suId,
MgMgtSta *sta
)
#else 
PUBLIC S16 MgUiMgtStaInd (post, suId, sta)
Pst *post;
SuId suId;
MgMgtSta *sta;
#endif
{
   TRC3(MgUiMgtStaInd);

   (*mgUiMgtStaIndMt[post->selector])(post, suId, sta);

   RETVALUE(ROK);
}






#ifdef GCP_MGCP

/*
 *
 *       Fun:   MgUiMgtMgcpTxnInd
 *
 *       Desc:  This function resolves the MgtMgcpTxnInd primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgUiMgtMgcpTxnInd
(
Pst *post,
SuId suId,
MgMgcpTxn *mgTxn
)
#else 
PUBLIC S16 MgUiMgtMgcpTxnInd (post, suId, mgTxn)
Pst *post;
SuId suId;
MgMgcpTxn *mgTxn;
#endif
{
   TRC3(MgUiMgtMgcpTxnInd)

   (*mgUiMgtMgcpTxnIndMt[post->selector])
      (post, suId, mgTxn);

   RETVALUE(ROK);
}

#endif /* GCP_MGCP */




#ifdef GCP_MGCO

/*
 *
 *       Fun:   MgUiMgtMgcoTxnInd
 *
 *       Desc:  This function resolves the MgtMgcoTxnInd primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgUiMgtMgcoTxnInd
(
Pst *post,
SuId suId,
MgMgcoMsg *mgTxn
)
#else 
PUBLIC S16 MgUiMgtMgcoTxnInd (post, suId, mgTxn)
Pst *post;
SuId suId;
MgMgcoMsg *mgTxn;
#endif
{
   TRC3(MgUiMgtMgcoTxnInd)

   (*mgUiMgtMgcoTxnIndMt[post->selector])(post, suId, mgTxn);

   RETVALUE(ROK);
}

 
#if (defined(GCP_CH) && defined(GCP_VER_1_5))
/*
 *
 *       Fun:   MgUiMgtMgcoCmdInd
 *
 *       Desc:  This function resolves the MgtMgcoCmdInd primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgUiMgtMgcoCmdInd
(
Pst *post,
SuId suId,
MgMgcoCommand *mgCmd
)
#else 
PUBLIC S16 MgUiMgtMgcoCmdInd (post, suId, mgCmd)
Pst *post;
SuId suId;
MgMgcoCommand *mgCmd;
#endif
{
   TRC3(MgUiMgtMgcoCmdInd)

   (*mgUiMgtMgcoCmdIndMt[post->selector])(post, suId, mgCmd);

   RETVALUE(ROK);
}
 
/*
 *
 *       Fun:  MgtMgcoUpdCtxtInd 
 *
 *       Desc:  This function resolves the MgtMgcoUpdCtxtInd primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgUiMgtMgcoUpdCtxtInd
(
Pst *post,
SuId suId,
MgMgcoUpdateCntxt *mgUpdCxt
)
#else 
PUBLIC S16 MgUiMgtMgcoUpdCtxtInd (post, suId, mgUpdCxt)
Pst *post;
SuId suId;
MgMgcoUpdateCntxt *mgUpdCxt;
#endif
{
   TRC3(MgUiMgtMgcoUpdCtxtInd)

   (*mgUiMgtMgcoUpdCtxtIndMt[post->selector])(post, suId, mgUpdCxt);

   RETVALUE(ROK);
}

/*
 *
 *       Fun:  MgtMgcoTxnStaInd
 *
 *       Desc:  This function resolves the MgtMgcoTxnStaInd primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 MgUiMgtMgcoTxnStaInd
(
Pst *post,
SuId suId,
MgMgcoInd *mgInd
)
#else 
PUBLIC S16 MgUiMgtMgcoTxnStaInd (post, suId, mgInd)
Pst *post;
SuId suId;
MgMgcoInd *mgInd;
#endif
{
   TRC3(MgUiMgtMgcoTxnStaInd)

   (*mgUiMgtMgcoTxnStaIndMt[post->selector])(post, suId, mgInd);

   RETVALUE(ROK);
}
#endif /* GCP_CH */

#endif /* GCP_MGCO */




/************************************************************************
                          Portable  Functions
************************************************************************/


#ifdef PTMGUIMGT


/*
 *
 *       Fun:   PtUiMgtBndCfm
 *
 *       Desc:  Portable version of MgtBndCfm primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiMgtBndCfm
(
Pst *post,
SuId suId,
U8 status
)
#else 
PUBLIC S16 PtUiMgtBndCfm (post, suId, status)
Pst *post;
SuId suId;
U8 status;
#endif
{
   TRC3(PtUiMgtBndCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG255, (ErrVal) 0, 
              "PtUiMgtBndCfm() called");
#endif

   RETVALUE(ROK);
}




/*
 *
 *       Fun:   PtUiMgtCntrlCfm
 *
 *       Desc:  Portable version of MgtBndCfm primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiMgtCntrlCfm
(
Pst *post,
SuId suId,
MgMgtCntrl *cntrl,
Reason reason
)
#else 
PUBLIC S16 PtUiMgtCntrlCfm (post, suId, cntrl, reason)
Pst *post;
SuId suId;
MgMgtCntrl *cntrl;
Reason reason;
#endif
{
   TRC3(PtUiMgtCntrlCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG256, (ErrVal) 0, "PtUiMgtCntrlCfm() called");
#endif

   RETVALUE(ROK);
}





/*
 *
 *       Fun:   PtUiMgtAuditCfm
 *
 *       Desc:  Portable version of MgtAuditCfm primitive
 *
 *       Ret:  ROK - ok; 
 *             RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiMgtAuditCfm
(
Pst *post,
SuId suId,
MgMgtAudit *audit,
Reason reason
)
#else 
PUBLIC S16 PtUiMgtAuditCfm (post, suId, audit, reason)
Pst *post;
SuId suId;
MgMgtAudit *audit;
Reason reason;
#endif
{
   TRC3(PtUiMgtAuditCfm);

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG257, (ErrVal) 0, "PtUiMgtAuditCfm() called");
#endif

   RETVALUE(ROK);
}




/*
 *
 *       Fun:   PtUiMgtStaInd
 *
 *       Desc:  Portable version of MgtStaInd primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiMgtStaInd
(
Pst *post,
SuId suId,
MgMgtSta *sta
)
#else 
PUBLIC S16 PtUiMgtStaInd (post, suId, sta   )
Pst *post;
SuId suId;
MgMgtSta *sta;
#endif
{
   TRC3(PtUiMgtStaInd);

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG258, (ErrVal) 0, "PtUiMgtStaInd() called");
#endif

   RETVALUE(ROK);
}




#ifdef GCP_MGCP 

/*
 *
 *       Fun:   PtUiMgtMgcpTxnInd
 *
 *       Desc:  Portable version of MgtMgcpTxnInd primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiMgtMgcpTxnInd
(
Pst *post,
SuId suId,
MgMgcpTxn *mgTxn
)
#else 
PUBLIC S16 PtUiMgtMgcpTxnInd (post, suId, mgTxn)
Pst *post;
SuId suId;
MgMgcpTxn *mgTxn;
#endif
{
   TRC3(PtUiMgtMgcpTxnInd)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG259, (ErrVal) 0, 
              "PtUiMgtMgcpTxnInd() called");
#endif

   RETVALUE(ROK);
}

#endif /* GCP_MGCP */



#ifdef GCP_MGCO 

/*
 *
 *       Fun:   PtUiMgtMgcoTxnInd
 *
 *       Desc:  Portable version of MgtMgcoTxnInd primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiMgtMgcoTxnInd
(
Pst *post,
SuId suId,
MgMgcoMsg *mgTxn
)
#else 
PUBLIC S16 PtUiMgtMgcoTxnInd (post, suId, mgTxn)
Pst *post;
SuId suId;
MgMgcoMsg *mgTxn;
#endif
{
   TRC3(PtUiMgtMgcoTxnInd)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG260, (ErrVal) 0, "PtUiMgtMgcoTxnInd() called");
#endif

   RETVALUE(ROK);
}

#if (defined(GCP_CH) && defined(GCP_VER_1_5))
 

/*
 *
 *       Fun:   PtUiMgtMgcoCmdInd
 *
 *       Desc:  Portable version of MgtMgcoCmdInd primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiMgtMgcoCmdInd
(
Pst *post,
SuId suId,
MgMgcoCommand *mgCmd 
)
#else 
PUBLIC S16 PtUiMgtMgcoCmdInd (post, suId, mgCmd)
Pst *post;
SuId suId;
MgMgcoCommand *mgCmd;
#endif
{
   TRC3(PtUiMgtMgcoCmdInd)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG261, (ErrVal) 0, "PtUiMgtMgcoCmdInd() called");
#endif

   RETVALUE(ROK);
}

/*
 *
 *       Fun:   PtUiMgtMgcoUpdCtxtInd
 *
 *       Desc:  Portable version of MgtMgcoUpdCtxtInd primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiMgtMgcoUpdCtxtInd
(
Pst *post,
SuId suId,
MgMgcoUpdateCntxt *mgCntxt
)
#else 
PUBLIC S16 PtUiMgtMgcoUpdCtxtInd (post, suId, mgCntxt)
Pst *post;
SuId suId;
MgMgcoUpdateCntxt *mgCntxt;
#endif
{
   TRC3(PtUiMgtMgcoUpdCtxtInd)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG262, (ErrVal) 0, "PtUiMgtMgcoUpdCtxtInd() called");
#endif

   RETVALUE(ROK);
} /* "PtUiMgtMgcoUpdCtxtInd" */
 
/*
 *
 *       Fun:   PtUiMgtMgcoTxnStaInd
 *
 *       Desc:  Portable version of MgtMgcoTxnStaInd primitive
 *
 *       Ret:  ROK - ok; RFAILED - failed
 *
 *       Notes: none
 *
         File:  mg_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiMgtMgcoTxnStaInd
(
Pst *post,
SuId suId,
MgMgcoInd *mgInd
)
#else 
PUBLIC S16 PtUiMgtMgcoTxnStaInd (post, suId, mgInd)
Pst *post;
SuId suId;
MgMgcoInd *mgInd;
#endif
{
   TRC3(PtUiMgtMgcoTxnStaInd)

#if (ERRCLASS & ERRCLS_DEBUG)
   MGLOGERROR(ERRCLS_DEBUG, EMG263, (ErrVal) 0, "PtUiMgtMgcoTxnStaInd() called");
#endif

   RETVALUE(ROK);
}
#endif /* GCP_CH && GCP_VER_1_5 */ 
#endif /* GCP_MGCO */
#endif /* PTMGUIMGT */


/********************************************************************30**
  
         End of file:     mp_ptui.c@@/main/6 - Wed Mar 30 07:58:44 2005
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rrp  1. Initial release
1.2          ---      bbk  1. Fixed C++ compilation warnings
/main/3      ---       pk  1. Added support for MEGACO primitives.
                           2. Added support for new control cfm, audit 
                              cfm and status ind primitives.
/main/4      ---      ra   1. GCP 1.3 release
/main/5      ---      ka   1. Changes for Release v 1.4
/main/6      ---      pk   1. GCP 1.5 release
*********************************************************************91*/
