/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/
/********************************************************************20**
  
     Name:     common asn.1 encoding/decoding
  
     Type:     C include file
  
     Desc:     defines required for encoding/decoding routines
  
     File:     mg_asn.h
  
     Sid:      mg_asn.h@@/main/1 - Wed Mar 30 08:06:58 2005
  
     Prg:      sg
  
*********************************************************************21*/

#ifndef __MGASNH__
#define __MGASNH__

#include "mg_err.h"

#ifdef GCP_ASN
#define MG_ASN_SS 1

/* static buffer size. This parameter is used if tSDtfontadm.l_m.bmSDtfontadm.m.bmSDtfontadm.m.pmSDtfontadm.m_m.bmSDtfontadm.t.bmSDtfontadm.t.pmSDtfontadm.t_m.bmSDtfontadmabout.bmSDtfontadmabout.pmSDtfontadmabout_m.bm of the static string employed should be able to atleast fit the */
/* largest fully encoded parameter of basic asn.1 types defined by the */
/* protocol. The user of the asn.1 library may modify this parameter */
/* to suit his needs */ 


#define MG_ASN_SBUF_SIZE    4096      /* static buffer size */

/* automatic tag base */
#define MG_ASN_PRIMITIVE_TAG_BASE    128
#define MG_ASN_CONSTRUCTOR_TAG_BASE  160

/* action to be taken on receiving an unrecognized element */
#define MG_ASN_DROP_ELMNTS   1        /* drop unrecognized elements */
#define MG_ASN_PASS_ELMNTS   2        /* pass unrecognized elements to user */
#define MG_ASN_GEN_ERR       3        /* generate error unrecognized elmnt */
#define MG_ASN_IGN_ELMNTS    4        /* ignore unrecognized elements */

/* defines for switch and the version flag. The defines below give the
   bit positions in the flag for the following protocol types */
#define MEGACO_V1           0         /* megaco v1 */
#define MEGACO_V2           8         /* megaco v2 */
 
/* defines for the flag bits */
#define ELMNT_INV         0x0         /* entry is invalid for this protocol */
#define ELMNT_OPT         0x1         /* element is optional */
#define ELMNT_MAND        0x2         /* element is mandatory */ 
#define ELMNT_IGN_EXTRA   0x4         /* ignore extra octets */ 
#define ELMNT_IGN_PRES    0x8         /* ignore extra octets */ 

/* values returned to the calling modules from asn.1 module */
#define MG_ASN_MAND_MIS     0x1011  /* Mandatory information is missing */
#define MG_ASN_TAG_ERR      0x1012  /* Error in the tag */
#define MG_ASN_LEN_ERR      0x1013  /* Error in the length field */
#define MG_ASN_UNEXP_VAL    0x1014  /* Unexpected value (for enum's) */
#define MG_ASN_RES_ERR      0x1015  /* resources error */
#define MG_ASN_OUT_RANGE    0x1016  /* out of database defined range */
#define MG_ASN_UNDEF_PARAM  0x1017  /* Parameter undefined for the protocol */
#define MG_ASN_NO_FUNC      0x1018  /* No user function */
#define MG_ASN_EXTRA_PARAM  0x1019  /* extra parameters at the end of the msg */
#define MG_ASN_DUP_ELMNT    0x101A  /* duplicate element */
#define MG_ASN_BAD_IDX      0x101B  /* element index is bad for choice */
#define MG_ASN_INV_IA5STR   0x101C  /* Invalid IA5String */
#define MG_ASN_MEM_ALRDY_ALLOCD 0x101D /* memory already allocated for which 
                                      * lib should allocate the memory */
#define MG_ASN_INVLD_ELMNT  0x101E  /* invalid element type */
#define MG_ASN_INVLD_EVNT   0x101F  /* invalid event structure */
#define MG_ASN_INVLD_MSG    0x1020  /* invalid message data */
#define MG_ASN_INVLD_PKG    0x1021  /* invalid package data */

#define MG_ASN_ELMNID_MGCO_BASE    25000    /* keeping separate from abnf values for debug ease */

/* defines for token element types */
#define TET_STR4        1     /* extra small string */
#define TET_STR12       2     /* small string */
#define TET_STR32       3     /* medium string */
#define TET_STR64       4     /* regular string */
#define TET_STR256      5     /* extended string */
#define TET_U8          6     /* unsigned eigth bit value */
#define TET_ENUM        7     /* enumerated type */
#define TET_NULL        8     /* null type */
#define TET_BITSTR      9     /* bit string */
#define TET_SEQ         10    /* sequence */
#define TET_SEQ_OF      11    /* sequence of */
#define TET_SET         12    /* set */
#define TET_SET_OF      13    /* set of */
#define TET_CHOICE      14    /* choice */
#define TET_INT         15    /* integer */
#define TET_INT32       15    /* integer */
#define TET_OID         16    /* Object Idebtifier */
#define TET_STRXL       17    /* extra long string */
#define TET_ESC_PRIM    18    /* escape type is primitive */
#define TET_TAG         19    /* tagged type */
#define TET_BOOL        20    /* boolean type */
#define TET_ESC_CONST   21    /* escape type is constructor */
#define TET_INT_RNG     22    /* integer - range check */
#define TET_STRXL_MEM      23    /* mem allocated by library while decoding */
#define TET_UNCONS_SEQ_OF  24    /* mem allocated by library while decoding */
#define TET_UNCONS_SET_OF  25    /* mem allocated by library while decoding */
#define TET_IA5STR4        26    /* extra small ia5 string */
#define TET_IA5STR12       27    /* small ia5 string */
#define TET_IA5STR32       28    /* medium ia5 string */
#define TET_IA5STR64       29    /* regular small ia5 string */
#define TET_IA5STR256      30    /* extended ia5 string */
#define TET_IA5STRXL       31    /* extra long ia5 string */
#define TET_IA5STRXL_MEM   32    /* mem allocated by library while decoding */
#define TET_STROSXL_MEM    33    /* mem allocated by library while decoding */
#define TET_INT8           34    /* integer U8 */
#define TET_INT16          36    /* integer U16 */
#define TET_CHOICE0        37    /* choice zero based */
#define TET_IA5STROSXL_MEM 38    /* mem allocated by library while decoding */
#define TET_SEQ_OF_SIMPLE  39    /* sequence of no array of pointers*/
#define TET_SEQ_SPECIAL    40    /* special sequence */
/* mg007.105: Added support for the enume U32 under flag GCP_ENUM_U32 */
#ifdef GCP_ENUM_U32
#define TET_ENUM32         41    /* enumerated 32-bit type */
#endif

/* Some big value for set/seq terminator */
#define TET_SETSEQ_TERM 99    /* set or sequence terminator */

/* escape type by default is primitve - done for BC */
#define TET_ESC TET_ESC_PRIM  /* type for database escape routine */

/* universal tag types used in common asn.1 library */
#define MG_ASN_UBOOL       0x1   /* universal boolean type tag */ 
#define MG_ASN_UINT        0x2   /* universal integer type tag */ 
#define MG_ASN_UBITSTR     0x3   /* universal bit string type tag */ 
#define MG_ASN_UOCTSTR     0x4   /* universal octet string type tag */ 
#define MG_ASN_UNULL       0x5   /* universal null type tag */ 
#define MG_ASN_PRIM_UOID   0x6   /* universal oid type tag - primitive */ 
#define MG_ASN_CONST_UOID  0x26  /* universal oid type tag - constructor */ 
#define MG_ASN_UENUM       0xA   /* universal enumerated type tag */ 
#define MG_ASN_UIA5        0x16  /* universal IA5 string tag */ 
#define MG_ASN_USEQ        0x30  /* universal sequence type tag */ 
#define MG_ASN_USEQOF      0x30  /* universal sequence of type tag */ 
#define MG_ASN_USET        0x31  /* universal set type tag */ 
#define MG_ASN_USETOF      0x31  /* universal set of type tag */ 
#define MG_ASN_UCHOICE     0x32  /* universal choice tag */ 

/* values for boolean type */
#define MG_ASN_TRUE        1     /* boolean true */
#define MG_ASN_FALSE       0     /* boolean false */

/* minimum length */
#define MIN_LEN_NA  0x0        /* minimum length not applicable */
#define MAX_LEN_NA  0x0        /* maximum length not applicable */

/* repeat counter not applicable */
#define REP_CNTR_NA   0x0      /* repeat counter not applicable */

/* maximum's for the ASN.1 module */
#define MAX_TAG_LEN   4         /* maximum tag length */
#define MAX_LEN_BYTES 4         /* maximum number of bytes in length field */ 

/* defines for the encode decode flag */
#define ENCODE_ELMNT  1         /* encode the element */
#define DECODE_ELMNT  2         /* decode the element */

#define PROCESS_LENGTH  3       /* Process the indefinite length encoding */

/* defines for the sizes of the ASN.1 types */
#define SIZEOF_OCTET    1       /* length of the octet in bytes */
#define SIZEOF_NULL     0       /* length of ASN.1 null type */

/* size of the buffer for encoding an octet */
#define OCTET_BUFSIZE   (MAX_TAG_LEN + SIZEOF_OCTET + 1)
#define NULL_BUFSIZE    (MAX_TAG_LEN + 1)
#define STR_BUFSIZE     (MAX_TAG_LEN + MAX_LEN_BYTES)
#define BITSTR_BUFSIZE  (MAX_TAG_LEN + MAX_LEN_BYTES + MF_SIZE_TKNSTRS)
#define SEQ_BUFSIZE     (MAX_TAG_LEN + MAX_LEN_BYTES)
#define OIDSTR_BUFSIZE  (MAX_TAG_LEN + MAX_LEN_BYTES + 64)

/* Return values internal to the ASN.1 module - change later */

/* defines related to encoding/decoding of length */
#define INITIAL_SHIFTBITS  7     /* number of shift bits for initial shift */
#define NUMBITS_BYTE       8     /* number of bits in a byte */
#define EOC_FLAG           0x80  /* Indeterminate length flag */
#define MAX_SBYTE_VAL      127   /* maximum value in a signed byte value */        
#define EOC_LEN            EOC_FLAG   /* Length for EOC type encoding */
#define EOC_LEN_SIZE       1          /* Size of length field - EOC encoding */
#define EOC_TAG            0x00       /* End of constructor type */

#define EOC_TAG_LEN        2     /* EOC Tag length is two bytes */

#define LONG_TAG_IND       0x1f  /* Indicates more than one byte in the tag */
#define TAG_MORE_BIT       0x80  /* Indicates more than one byte in the tag */
#define IA5_CHARMASK       0x80  /* Character mask for IA5String */

/* macro for updating the error code and tag in the error structure */
#ifdef MG_ASN_DBG
#define MG_ASN_ERR(msgCp, error)                           \
   {                                                       \
      msgCp->err->strPtr = (S8*)(*(msgCp->elmntDef))->str;\
      msgCp->err->file = __FILE__;                         \
      msgCp->err->line = __LINE__;                         \
      msgCp->err->code = error;                         \
      msgCp->err->idNum = (*(msgCp->elmntDef))?(*(msgCp->elmntDef))->idNum:0;\
   }
#else
#define MG_ASN_ERR(msgCp, error)                           \
   {                                                       \
      msgCp->err->code = error;                         \
      msgCp->err->idNum = (*(msgCp->elmntDef))?(*(msgCp->elmntDef))->idNum:0;\
   }
#endif

/* get the error code from the message structure */
#define MG_ASN_GETERR(msgCp)    (msgCp->err->code)

/* get the tag from the message structure */
#define MG_ASN_TAGVAL(msgCp)     (msgCp->err->tag)

/* get the tag from the message structure */
#define MG_ASN_EVNTSTR(msgCp)     (msgCp->evntStr)

/* get the tag from the message structure */
#define MG_ASN_MSGBUF(msgCp)     (msgCp->mBuf)

/* this macro generates a flag depending on the element information */
#define TYPE_TO_FLAG(prot, type)   ((U32)(type) << (U32)(prot))

/* this macro gets the element information (optional/mandatory) */
#define FLAG_TO_TYPE(flag, prot)   (((U32)(*flag) >> (U32)(prot)) & 0x3)

/* check to see in the flag if ignore flag is set */
#define IS_IGNORE_EXT(elmd, prot)   ((*(elmd->flagp) >> (prot)) & ELMNT_IGN_EXTRA)
#define IS_IGNORE_PRES(elmd, prot)   ((*(elmd->flagp) >> (prot)) & ELMNT_IGN_PRES)

/* macro for incrementing the event structure pointer over the start */
/* token of the constructor types */

#define MG_ASN_SKIP_TKNPRES(msgCp)                           \
do                                                           \
{                                                            \
   msgCp->evntStr =                                          \
       (TknU8 *) ((PTR) msgCp->evntStr + sizeof(TknU8));     \
                                                             \
}while(0);

#endif  
#endif  /* __MGASNH__ */

  
/********************************************************************30**
  
         End of file:     mg_asn.h@@/main/1 - Wed Mar 30 08:06:58 2005
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1            ---    tlh  1. initial release.
 
*********************************************************************81*/
 
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---      pk   1. GCP 1.5 release
          mg007.105   gk   1. Added support for the enume U32 under 
                              flag GCP_ENUM_U32
*********************************************************************91*/
