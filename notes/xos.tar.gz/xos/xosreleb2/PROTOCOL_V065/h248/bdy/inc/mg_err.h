/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:    GCP - Error File
  
     Type:    C include file 
  
     Desc:    Error defines required by GCP layer
 
     File:    mg_err.h

     Sid:      mg_err.h@@/main/5 - Wed Mar 30 07:51:29 2005
  
     Prg:     rrp
  
*********************************************************************21*/
 
  
/*
*     The defines declared in this file correspond to those
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000XXX     MGCP Layer
*
*/


#ifndef __MGERRH__
#define __MGERRH__

  
/* defines */


/* Macro definitions */

#define MGLOGERROR(errCls, errCode, errVal, errDesc) \
   SLogError(mgCb.init.ent, mgCb.init.inst, mgCb.init.procId, \
             (Txt *) __FILE__,    \
             (S32) __LINE__,      \
             (ErrCls) (errCls),   \
             (ErrCode) (errCode), \
             (ErrVal) (errVal),   \
             (Txt *) errDesc)

/* error codes */
#define   EMGBASE 0

#define   EMGXXX      (EMGBASE + 0)   /* reserved */
#define   ERRMG       (EMGBASE + 0)   /* reserved */

#define   EMG001      (ERRMG +    1)    /*     mg_asn.c:2701 */
#define   EMG002      (ERRMG +    2)    /*     mg_asn.c:4456 */
#define   EMG003      (ERRMG +    3)    /*     mg_asn.c:4623 */
#define   EMG004      (ERRMG +    4)    /*     mg_asn.c:5035 */

#define   EMG005      (ERRMG +    5)    /*    mg_ptli.c:2231 */
#define   EMG006      (ERRMG +    6)    /*    mg_ptli.c:2271 */
#define   EMG007      (ERRMG +    7)    /*    mg_ptli.c:2320 */
#define   EMG008      (ERRMG +    8)    /*    mg_ptli.c:2380 */
#define   EMG009      (ERRMG +    9)    /*    mg_ptli.c:2426 */
#define   EMG010      (ERRMG +   10)    /*    mg_ptli.c:2475 */
#define   EMG011      (ERRMG +   11)    /*    mg_ptli.c:2517 */
#define   EMG012      (ERRMG +   12)    /*    mg_ptli.c:2559 */
#define   EMG013      (ERRMG +   13)    /*    mg_ptli.c:2609 */
#define   EMG014      (ERRMG +   14)    /*    mg_ptli.c:2654 */
#define   EMG015      (ERRMG +   15)    /*    mg_ptli.c:2701 */
#define   EMG016      (ERRMG +   16)    /*    mg_ptli.c:2759 */
#define   EMG017      (ERRMG +   17)    /*    mg_ptli.c:2819 */
#define   EMG018      (ERRMG +   18)    /*    mg_ptli.c:2872 */
#define   EMG019      (ERRMG +   19)    /*    mg_ptli.c:2919 */
#define   EMG020      (ERRMG +   20)    /*    mg_ptli.c:2977 */
#define   EMG021      (ERRMG +   21)    /*    mg_ptli.c:3034 */
#define   EMG022      (ERRMG +   22)    /*    mg_ptli.c:3091 */
#define   EMG023      (ERRMG +   23)    /*    mg_ptli.c:3146 */
#define   EMG024      (ERRMG +   24)    /*    mg_ptli.c:3187 */

#define   EMG025      (ERRMG +   25)    /*    mg_ptmi.c: 611 */
#define   EMG026      (ERRMG +   26)    /*    mg_ptmi.c: 649 */
#define   EMG027      (ERRMG +   27)    /*    mg_ptmi.c: 686 */
#define   EMG028      (ERRMG +   28)    /*    mg_ptmi.c: 724 */
#define   EMG029      (ERRMG +   29)    /*    mg_ptmi.c: 762 */
#define   EMG030      (ERRMG +   30)    /*    mg_ptmi.c: 802 */

#define   EMG031      (ERRMG +   31)    /*    mp_cord.c:1998 */
#define   EMG032      (ERRMG +   32)    /*    mp_cord.c:2013 */
#define   EMG033      (ERRMG +   33)    /*    mp_cord.c:2027 */
#define   EMG034      (ERRMG +   34)    /*    mp_cord.c:2068 */
#define   EMG035      (ERRMG +   35)    /*    mp_cord.c:2132 */
#define   EMG036      (ERRMG +   36)    /*    mp_cord.c:2271 */
#define   EMG037      (ERRMG +   37)    /*    mp_cord.c:2324 */
#define   EMG038      (ERRMG +   38)    /*    mp_cord.c:3107 */
#define   EMG039      (ERRMG +   39)    /*    mp_cord.c:4456 */
#define   EMG040      (ERRMG +   40)    /*    mp_cord.c:6098 */
#define   EMG041      (ERRMG +   41)    /*    mp_cord.c:9355 */
#define   EMG042      (ERRMG +   42)    /*    mp_cord.c:13325 */
#define   EMG043      (ERRMG +   43)    /*    mp_cord.c:13497 */
#define   EMG044      (ERRMG +   44)    /*    mp_cord.c:13556 */

#define   EMG045      (ERRMG +   45)    /*      mp_ed.c: 797 */
#define   EMG046      (ERRMG +   46)    /*      mp_ed.c: 897 */
#define   EMG047      (ERRMG +   47)    /*      mp_ed.c:1183 */
#define   EMG048      (ERRMG +   48)    /*      mp_ed.c:1518 */
#define   EMG049      (ERRMG +   49)    /*      mp_ed.c:1613 */
#define   EMG050      (ERRMG +   50)    /*      mp_ed.c:1768 */
#define   EMG051      (ERRMG +   51)    /*      mp_ed.c:2126 */
#define   EMG052      (ERRMG +   52)    /*      mp_ed.c:2435 */
#define   EMG053      (ERRMG +   53)    /*      mp_ed.c:2466 */
#define   EMG054      (ERRMG +   54)    /*      mp_ed.c:2503 */
#define   EMG055      (ERRMG +   55)    /*      mp_ed.c:2882 */
#define   EMG056      (ERRMG +   56)    /*      mp_ed.c:2890 */
#define   EMG057      (ERRMG +   57)    /*      mp_ed.c:3064 */
#define   EMG058      (ERRMG +   58)    /*      mp_ed.c:3072 */
#define   EMG059      (ERRMG +   59)    /*      mp_ed.c:3191 */
#define   EMG060      (ERRMG +   60)    /*      mp_ed.c:3198 */
#define   EMG061      (ERRMG +   61)    /*      mp_ed.c:3726 */
#define   EMG062      (ERRMG +   62)    /*      mp_ed.c:3735 */
#define   EMG063      (ERRMG +   63)    /*      mp_ed.c:3741 */
#define   EMG064      (ERRMG +   64)    /*      mp_ed.c:4243 */
#define   EMG065      (ERRMG +   65)    /*      mp_ed.c:4248 */
#define   EMG066      (ERRMG +   66)    /*      mp_ed.c:4252 */
#define   EMG067      (ERRMG +   67)    /*      mp_ed.c:4258 */
#define   EMG068      (ERRMG +   68)    /*      mp_ed.c:4262 */
#define   EMG069      (ERRMG +   69)    /*      mp_ed.c:4266 */
#define   EMG070      (ERRMG +   70)    /*      mp_ed.c:4271 */
#define   EMG071      (ERRMG +   71)    /*      mp_ed.c:4277 */
#define   EMG072      (ERRMG +   72)    /*      mp_ed.c:4278 */
#define   EMG073      (ERRMG +   73)    /*      mp_ed.c:4279 */
#define   EMG074      (ERRMG +   74)    /*      mp_ed.c:4347 */
#define   EMG075      (ERRMG +   75)    /*      mp_ed.c:4352 */
#define   EMG076      (ERRMG +   76)    /*      mp_ed.c:4353 */
#define   EMG077      (ERRMG +   77)    /*      mp_ed.c:4354 */
#define   EMG078      (ERRMG +   78)    /*      mp_ed.c:4358 */
#define   EMG079      (ERRMG +   79)    /*      mp_ed.c:4362 */
#define   EMG080      (ERRMG +   80)    /*      mp_ed.c:4366 */
#define   EMG081      (ERRMG +   81)    /*      mp_ed.c:4367 */
#define   EMG082      (ERRMG +   82)    /*      mp_ed.c:4421 */
#define   EMG083      (ERRMG +   83)    /*      mp_ed.c:4422 */
#define   EMG084      (ERRMG +   84)    /*      mp_ed.c:4423 */
#define   EMG085      (ERRMG +   85)    /*      mp_ed.c:4424 */
#define   EMG086      (ERRMG +   86)    /*      mp_ed.c:4425 */
#define   EMG087      (ERRMG +   87)    /*      mp_ed.c:4427 */
#define   EMG088      (ERRMG +   88)    /*      mp_ed.c:4428 */
#define   EMG089      (ERRMG +   89)    /*      mp_ed.c:4475 */
#define   EMG090      (ERRMG +   90)    /*      mp_ed.c:4476 */
#define   EMG091      (ERRMG +   91)    /*      mp_ed.c:4477 */
#define   EMG092      (ERRMG +   92)    /*      mp_ed.c:4478 */
#define   EMG093      (ERRMG +   93)    /*      mp_ed.c:4479 */
#define   EMG094      (ERRMG +   94)    /*      mp_ed.c:4480 */

#define   EMG095      (ERRMG +   95)    /*   mp_ex_ms.c: 384 */
#define   EMG096      (ERRMG +   96)    /*   mp_ex_ms.c: 434 */
#define   EMG097      (ERRMG +   97)    /*   mp_ex_ms.c: 532 */
#define   EMG098      (ERRMG +   98)    /*   mp_ex_ms.c: 612 */
#define   EMG099      (ERRMG +   99)    /*   mp_ex_ms.c: 639 */
#define   EMG100      (ERRMG +  100)    /*   mp_ex_ms.c: 668 */
#define   EMG101      (ERRMG +  101)    /*   mp_ex_ms.c: 684 */

#define   EMG102      (ERRMG +  102)    /*      mp_li.c: 253 */
#define   EMG103      (ERRMG +  103)    /*      mp_li.c: 267 */
#define   EMG104      (ERRMG +  104)    /*      mp_li.c: 284 */
#define   EMG105      (ERRMG +  105)    /*      mp_li.c: 461 */
#define   EMG106      (ERRMG +  106)    /*      mp_li.c: 469 */
#define   EMG107      (ERRMG +  107)    /*      mp_li.c: 485 */
#define   EMG108      (ERRMG +  108)    /*      mp_li.c: 511 */
#define   EMG109      (ERRMG +  109)    /*      mp_li.c: 529 */
#define   EMG110      (ERRMG +  110)    /*      mp_li.c: 544 */
#define   EMG111      (ERRMG +  111)    /*      mp_li.c: 631 */
#define   EMG112      (ERRMG +  112)    /*      mp_li.c: 642 */
#define   EMG113      (ERRMG +  113)    /*      mp_li.c: 652 */
#define   EMG114      (ERRMG +  114)    /*      mp_li.c: 666 */
#define   EMG115      (ERRMG +  115)    /*      mp_li.c: 676 */
#define   EMG116      (ERRMG +  116)    /*      mp_li.c: 763 */
#define   EMG117      (ERRMG +  117)    /*      mp_li.c: 770 */
#define   EMG118      (ERRMG +  118)    /*      mp_li.c: 786 */
#define   EMG119      (ERRMG +  119)    /*      mp_li.c: 897 */
#define   EMG120      (ERRMG +  120)    /*      mp_li.c:1025 */
#define   EMG121      (ERRMG +  121)    /*      mp_li.c:1050 */
#define   EMG122      (ERRMG +  122)    /*      mp_li.c:1059 */
#define   EMG123      (ERRMG +  123)    /*      mp_li.c:1327 */
#define   EMG124      (ERRMG +  124)    /*      mp_li.c:1342 */
#define   EMG125      (ERRMG +  125)    /*      mp_li.c:1367 */
#define   EMG126      (ERRMG +  126)    /*      mp_li.c:1601 */
#define   EMG127      (ERRMG +  127)    /*      mp_li.c:1760 */
#define   EMG128      (ERRMG +  128)    /*      mp_li.c:1896 */
#define   EMG129      (ERRMG +  129)    /*      mp_li.c:1930 */
#define   EMG130      (ERRMG +  130)    /*      mp_li.c:2033 */
#define   EMG131      (ERRMG +  131)    /*      mp_li.c:2056 */
#define   EMG132      (ERRMG +  132)    /*      mp_li.c:2158 */
#define   EMG133      (ERRMG +  133)    /*      mp_li.c:2198 */
#define   EMG134      (ERRMG +  134)    /*      mp_li.c:2288 */
#define   EMG135      (ERRMG +  135)    /*      mp_li.c:2369 */
#define   EMG136      (ERRMG +  136)    /*      mp_li.c:2389 */
#define   EMG137      (ERRMG +  137)    /*      mp_li.c:2564 */
#define   EMG138      (ERRMG +  138)    /*      mp_li.c:2587 */
#define   EMG139      (ERRMG +  139)    /*      mp_li.c:2614 */
#define   EMG140      (ERRMG +  140)    /*      mp_li.c:2640 */
#define   EMG141      (ERRMG +  141)    /*      mp_li.c:2662 */
#define   EMG142      (ERRMG +  142)    /*      mp_li.c:2820 */
#define   EMG143      (ERRMG +  143)    /*      mp_li.c:2919 */
#define   EMG144      (ERRMG +  144)    /*      mp_li.c:2940 */
#define   EMG145      (ERRMG +  145)    /*      mp_li.c:3312 */
#define   EMG146      (ERRMG +  146)    /*      mp_li.c:3526 */
#define   EMG147      (ERRMG +  147)    /*      mp_li.c:3540 */
#define   EMG148      (ERRMG +  148)    /*      mp_li.c:3564 */
#define   EMG149      (ERRMG +  149)    /*      mp_li.c:3693 */
#define   EMG150      (ERRMG +  150)    /*      mp_li.c:3726 */
#define   EMG151      (ERRMG +  151)    /*      mp_li.c:3801 */
#define   EMG152      (ERRMG +  152)    /*      mp_li.c:3815 */
#define   EMG153      (ERRMG +  153)    /*      mp_li.c:3848 */
#define   EMG154      (ERRMG +  154)    /*      mp_li.c:3884 */
#define   EMG155      (ERRMG +  155)    /*      mp_li.c:3945 */
#define   EMG156      (ERRMG +  156)    /*      mp_li.c:3977 */
#define   EMG157      (ERRMG +  157)    /*      mp_li.c:4051 */
#define   EMG158      (ERRMG +  158)    /*      mp_li.c:4149 */
#define   EMG159      (ERRMG +  159)    /*      mp_li.c:4172 */
#define   EMG160      (ERRMG +  160)    /*      mp_li.c:4185 */
#define   EMG161      (ERRMG +  161)    /*      mp_li.c:4208 */
#define   EMG162      (ERRMG +  162)    /*      mp_li.c:4292 */

#define   EMG163      (ERRMG +  163)    /*      mp_mi.c: 499 */
#define   EMG164      (ERRMG +  164)    /*      mp_mi.c: 914 */
#define   EMG165      (ERRMG +  165)    /*      mp_mi.c: 988 */
#define   EMG166      (ERRMG +  166)    /*      mp_mi.c:1015 */
#define   EMG167      (ERRMG +  167)    /*      mp_mi.c:1058 */
#define   EMG168      (ERRMG +  168)    /*      mp_mi.c:1134 */
#define   EMG169      (ERRMG +  169)    /*      mp_mi.c:1162 */
#define   EMG170      (ERRMG +  170)    /*      mp_mi.c:1217 */
#define   EMG171      (ERRMG +  171)    /*      mp_mi.c:1326 */
#define   EMG172      (ERRMG +  172)    /*      mp_mi.c:1340 */
#define   EMG173      (ERRMG +  173)    /*      mp_mi.c:1368 */
#define   EMG174      (ERRMG +  174)    /*      mp_mi.c:1517 */
#define   EMG175      (ERRMG +  175)    /*      mp_mi.c:1595 */
#define   EMG176      (ERRMG +  176)    /*      mp_mi.c:1686 */
#define   EMG177      (ERRMG +  177)    /*      mp_mi.c:1728 */
#define   EMG178      (ERRMG +  178)    /*      mp_mi.c:1774 */
#define   EMG179      (ERRMG +  179)    /*      mp_mi.c:1887 */
#define   EMG180      (ERRMG +  180)    /*      mp_mi.c:2398 */
#define   EMG181      (ERRMG +  181)    /*      mp_mi.c:2421 */
#define   EMG182      (ERRMG +  182)    /*      mp_mi.c:2465 */
#define   EMG183      (ERRMG +  183)    /*      mp_mi.c:3037 */
#define   EMG184      (ERRMG +  184)    /*      mp_mi.c:3063 */
#define   EMG185      (ERRMG +  185)    /*      mp_mi.c:3079 */
#define   EMG186      (ERRMG +  186)    /*      mp_mi.c:3281 */
#define   EMG187      (ERRMG +  187)    /*      mp_mi.c:3310 */
#define   EMG188      (ERRMG +  188)    /*      mp_mi.c:3327 */
#define   EMG189      (ERRMG +  189)    /*      mp_mi.c:3543 */
#define   EMG190      (ERRMG +  190)    /*      mp_mi.c:3569 */
#define   EMG191      (ERRMG +  191)    /*      mp_mi.c:4199 */
#define   EMG192      (ERRMG +  192)    /*      mp_mi.c:4271 */
#define   EMG193      (ERRMG +  193)    /*      mp_mi.c:4482 */
#define   EMG194      (ERRMG +  194)    /*      mp_mi.c:7113 */
#define   EMG195      (ERRMG +  195)    /*      mp_mi.c:7133 */
#define   EMG196      (ERRMG +  196)    /*      mp_mi.c:7866 */
#define   EMG197      (ERRMG +  197)    /*      mp_mi.c:7907 */
#define   EMG198      (ERRMG +  198)    /*      mp_mi.c:7941 */
#define   EMG199      (ERRMG +  199)    /*      mp_mi.c:7965 */
#define   EMG200      (ERRMG +  200)    /*      mp_mi.c:8014 */
#define   EMG201      (ERRMG +  201)    /*      mp_mi.c:8288 */
#define   EMG202      (ERRMG +  202)    /*      mp_mi.c:8311 */

#define   EMG203      (ERRMG +  203)    /*    mp_peer.c:1120 */
#define   EMG204      (ERRMG +  204)    /*    mp_peer.c:1123 */
#define   EMG205      (ERRMG +  205)    /*    mp_peer.c:1136 */
#define   EMG206      (ERRMG +  206)    /*    mp_peer.c:1139 */
#define   EMG207      (ERRMG +  207)    /*    mp_peer.c:2546 */
#define   EMG208      (ERRMG +  208)    /*    mp_peer.c:2630 */
#define   EMG209      (ERRMG +  209)    /*    mp_peer.c:2743 */

#define   EMG210      (ERRMG +  210)    /*    mp_pldf.c: 360 */
#define   EMG211      (ERRMG +  211)    /*    mp_pldf.c: 373 */
#define   EMG212      (ERRMG +  212)    /*    mp_pldf.c: 474 */
#define   EMG213      (ERRMG +  213)    /*    mp_pldf.c: 484 */
#define   EMG214      (ERRMG +  214)    /*    mp_pldf.c: 759 */
#define   EMG215      (ERRMG +  215)    /*    mp_pldf.c: 853 */
#define   EMG216      (ERRMG +  216)    /*    mp_pldf.c: 864 */
#define   EMG217      (ERRMG +  217)    /*    mp_pldf.c: 947 */
#define   EMG218      (ERRMG +  218)    /*    mp_pldf.c: 957 */
#define   EMG219      (ERRMG +  219)    /*    mp_pldf.c: 970 */
#define   EMG220      (ERRMG +  220)    /*    mp_pldf.c:1039 */
#define   EMG221      (ERRMG +  221)    /*    mp_pldf.c:1050 */
#define   EMG222      (ERRMG +  222)    /*    mp_pldf.c:1135 */
#define   EMG223      (ERRMG +  223)    /*    mp_pldf.c:1230 */
#define   EMG224      (ERRMG +  224)    /*    mp_pldf.c:1241 */
#define   EMG225      (ERRMG +  225)    /*    mp_pldf.c:1297 */
#define   EMG226      (ERRMG +  226)    /*    mp_pldf.c:1310 */
#define   EMG227      (ERRMG +  227)    /*    mp_pldf.c:1384 */
#define   EMG228      (ERRMG +  228)    /*    mp_pldf.c:1395 */
#define   EMG229      (ERRMG +  229)    /*    mp_pldf.c:1464 */
#define   EMG230      (ERRMG +  230)    /*    mp_pldf.c:1475 */
#define   EMG231      (ERRMG +  231)    /*    mp_pldf.c:1489 */
#define   EMG232      (ERRMG +  232)    /*    mp_pldf.c:1546 */
#define   EMG233      (ERRMG +  233)    /*    mp_pldf.c:1557 */
#define   EMG234      (ERRMG +  234)    /*    mp_pldf.c:1618 */
#define   EMG235      (ERRMG +  235)    /*    mp_pldf.c:1631 */
#define   EMG236      (ERRMG +  236)    /*    mp_pldf.c:1703 */
#define   EMG237      (ERRMG +  237)    /*    mp_pldf.c:1716 */
#define   EMG238      (ERRMG +  238)    /*    mp_pldf.c:2008 */
#define   EMG239      (ERRMG +  239)    /*    mp_pldf.c:2019 */
#define   EMG240      (ERRMG +  240)    /*    mp_pldf.c:2098 */
#define   EMG241      (ERRMG +  241)    /*    mp_pldf.c:2190 */
#define   EMG242      (ERRMG +  242)    /*    mp_pldf.c:2259 */
#define   EMG243      (ERRMG +  243)    /*    mp_pldf.c:2316 */
#define   EMG244      (ERRMG +  244)    /*    mp_pldf.c:2329 */
#define   EMG245      (ERRMG +  245)    /*    mp_pldf.c:2383 */
#define   EMG246      (ERRMG +  246)    /*    mp_pldf.c:2403 */
#define   EMG247      (ERRMG +  247)    /*    mp_pldf.c:2489 */
#define   EMG248      (ERRMG +  248)    /*    mp_pldf.c:2572 */
#define   EMG249      (ERRMG +  249)    /*    mp_pldf.c:2633 */
#define   EMG250      (ERRMG +  250)    /*    mp_pldf.c:2643 */
#define   EMG251      (ERRMG +  251)    /*    mp_pldf.c:2655 */
#define   EMG252      (ERRMG +  252)    /*    mp_pldf.c:2666 */
#define   EMG253      (ERRMG +  253)    /*    mp_pldf.c:2679 */
#define   EMG254      (ERRMG +  254)    /*    mp_pldf.c:3024 */

#define   EMG255      (ERRMG +  255)    /*    mp_ptui.c: 873 */
#define   EMG256      (ERRMG +  256)    /*    mp_ptui.c: 915 */
#define   EMG257      (ERRMG +  257)    /*    mp_ptui.c: 958 */
#define   EMG258      (ERRMG +  258)    /*    mp_ptui.c: 997 */
#define   EMG259      (ERRMG +  259)    /*    mp_ptui.c:1038 */
#define   EMG260      (ERRMG +  260)    /*    mp_ptui.c:1081 */
#define   EMG261      (ERRMG +  261)    /*    mp_ptui.c:1120 */
#define   EMG262      (ERRMG +  262)    /*    mp_ptui.c:1156 */
#define   EMG263      (ERRMG +  263)    /*    mp_ptui.c:1192 */

#define   EMG264      (ERRMG +  264)    /*     mp_tmr.c: 460 */
#define   EMG265      (ERRMG +  265)    /*     mp_tmr.c: 782 */
#define   EMG266      (ERRMG +  266)    /*     mp_tmr.c: 890 */
#define   EMG267      (ERRMG +  267)    /*     mp_tmr.c:1547 */
#define   EMG268      (ERRMG +  268)    /*     mp_tmr.c:1621 */
#define   EMG269      (ERRMG +  269)    /*     mp_tmr.c:1822 */
#define   EMG270      (ERRMG +  270)    /*     mp_tmr.c:1955 */
#define   EMG271      (ERRMG +  271)    /*     mp_tmr.c:2013 */
#define   EMG272      (ERRMG +  272)    /*     mp_tmr.c:2104 */

#define   EMG273      (ERRMG +  273)    /*     mp_tpt.c: 436 */
#define   EMG274      (ERRMG +  274)    /*     mp_tpt.c: 503 */
#define   EMG275      (ERRMG +  275)    /*     mp_tpt.c: 537 */
#define   EMG276      (ERRMG +  276)    /*     mp_tpt.c:1151 */
#define   EMG277      (ERRMG +  277)    /*     mp_tpt.c:1157 */
#define   EMG278      (ERRMG +  278)    /*     mp_tpt.c:1235 */
#define   EMG279      (ERRMG +  279)    /*     mp_tpt.c:1605 */
#define   EMG280      (ERRMG +  280)    /*     mp_tpt.c:1723 */
#define   EMG281      (ERRMG +  281)    /*     mp_tpt.c:1755 */
#define   EMG282      (ERRMG +  282)    /*     mp_tpt.c:1857 */
#define   EMG283      (ERRMG +  283)    /*     mp_tpt.c:1877 */
#define   EMG284      (ERRMG +  284)    /*     mp_tpt.c:1886 */
#define   EMG285      (ERRMG +  285)    /*     mp_tpt.c:1973 */
#define   EMG286      (ERRMG +  286)    /*     mp_tpt.c:1979 */
#define   EMG287      (ERRMG +  287)    /*     mp_tpt.c:2336 */
#define   EMG288      (ERRMG +  288)    /*     mp_tpt.c:2466 */
#define   EMG289      (ERRMG +  289)    /*     mp_tpt.c:2549 */
#define   EMG290      (ERRMG +  290)    /*     mp_tpt.c:2628 */
#define   EMG291      (ERRMG +  291)    /*     mp_tpt.c:3872 */
#define   EMG292      (ERRMG +  292)    /*     mp_tpt.c:3901 */

#define   EMG293      (ERRMG +  293)    /*   mp_trans.c:1059 */

#define   EMG294      (ERRMG +  294)    /*      mp_ui.c: 472 */
#define   EMG295      (ERRMG +  295)    /*      mp_ui.c: 485 */
#define   EMG296      (ERRMG +  296)    /*      mp_ui.c: 504 */
#define   EMG297      (ERRMG +  297)    /*      mp_ui.c: 580 */
#define   EMG298      (ERRMG +  298)    /*      mp_ui.c: 654 */
#define   EMG299      (ERRMG +  299)    /*      mp_ui.c: 740 */
#define   EMG300      (ERRMG +  300)    /*      mp_ui.c: 756 */
#define   EMG301      (ERRMG +  301)    /*      mp_ui.c: 772 */
#define   EMG302      (ERRMG +  302)    /*      mp_ui.c: 896 */
#define   EMG303      (ERRMG +  303)    /*      mp_ui.c: 912 */
#define   EMG304      (ERRMG +  304)    /*      mp_ui.c: 928 */
#define   EMG305      (ERRMG +  305)    /*      mp_ui.c:1105 */
#define   EMG306      (ERRMG +  306)    /*      mp_ui.c:1121 */
#define   EMG307      (ERRMG +  307)    /*      mp_ui.c:1137 */
#define   EMG308      (ERRMG +  308)    /*      mp_ui.c:1255 */
#define   EMG309      (ERRMG +  309)    /*      mp_ui.c:1285 */
#define   EMG310      (ERRMG +  310)    /*      mp_ui.c:1380 */
#define   EMG311      (ERRMG +  311)    /*      mp_ui.c:1410 */
#define   EMG312      (ERRMG +  312)    /*      mp_ui.c:1496 */
#define   EMG313      (ERRMG +  313)    /*      mp_ui.c:1528 */
#define   EMG314      (ERRMG +  314)    /*      mp_ui.c:1636 */
#define   EMG315      (ERRMG +  315)    /*      mp_ui.c:1666 */
#define   EMG316      (ERRMG +  316)    /*      mp_ui.c:1757 */
#define   EMG317      (ERRMG +  317)    /*      mp_ui.c:1787 */

#define   EMG318      (ERRMG +  318)    /*    mp_util.c: 891 */
#define   EMG319      (ERRMG +  319)    /*    mp_util.c: 957 */
#define   EMG320      (ERRMG +  320)    /*    mp_util.c:1018 */
#define   EMG321      (ERRMG +  321)    /*    mp_util.c:1067 */
#define   EMG322      (ERRMG +  322)    /*    mp_util.c:1872 */
   

#endif /* __MGERRH__ */

/********************************************************************30**
  
         End of file:     mg_err.h@@/main/5 - Wed Mar 30 07:51:29 2005
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rrp  1. Initial release
/main/2      ---       pk  1. Added error codes for new release.
/main/3      ---      ra   1. GCP 1.3 release
/main/4      ---      ka   1. Changes for Release v 1.4
/main/5      ---      pk   1. GCP 1.5 release
*********************************************************************91*/
