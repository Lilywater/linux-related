/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     mg parsing encoding/decoding
  
     Type:     C include file
  
     Desc:     Hash Defines used by encoding/decoding routines. 
  
     File:     masn1m.h
  
     Sid:      mgasnutl.h@@/main/1 - Wed Mar 30 08:11:42 2005
  
     Prg:      rm
  
*********************************************************************21*/

#ifndef __masn1m_h__
#define __masn1m_h__
#ifdef GCP_ASN
#define MGAFUNCSAVE(_msgCp_) \
             MgAsnElmntDef **saveElmntDef;\
             TknU8* saveEvntStr;\
             saveElmntDef = _msgCp_->elmntDef; \
             saveEvntStr = _msgCp_->evntStr;
                                                                                
#define MGAFUNCSKIP(_msgCp_) \
             _msgCp_->elmntDef = saveElmntDef; \
             _msgCp_->evntStr = saveEvntStr; \
             mgAsnSkipElmnt(_msgCp_);
                                                                                
/* mg003.105: Removing double quotes for service change reason in binary encoding */
#define MGASERVICECHANGEREASONMODIFY(_msgCp_) \
{\
             U8 *tmp_reason;\
             U8 i,j,count=0;\
             tmp_reason = ((TknStrOSXL *)(_msgCp_->evntStr))->val;/* Pointer to the string */\
             for (i =0;tmp_reason[i];i++)\
             {\
               if ( tmp_reason[i] == '"' )\
               {\
                  for (j=i;tmp_reason[j];j++)\
                     tmp_reason[j] = tmp_reason[j+1];\
                  count++;\
               }\
             }\
             ((TknStrOSXL *)(_msgCp_->evntStr))->len = ((TknStrOSXL *)(_msgCp_->evntStr))->len - count;\
}\
/* mg007.105: Removal of Unneccessary comments */

#endif
#endif

  
/********************************************************************30**
  
         End of file:     mgasnutl.h@@/main/1 - Wed Mar 30 08:11:42 2005
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**
 
 
*********************************************************************81*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      tlh  1. initial release.
/main/1      ---      pk   1. GCP 1.5 release
            mg003.105 gk   1. Removing double quotes for service change 
                              reason in binary encoding 
            mg007.105 gk   1. Removal of Unneccessary comments 
*********************************************************************91*/
