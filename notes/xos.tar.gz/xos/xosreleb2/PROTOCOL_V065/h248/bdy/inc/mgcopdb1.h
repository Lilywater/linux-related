/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Megaco packages hash defines file

     Type:     C header file

     Desc:     Hash defines for Megaco packages

     File:     mgcopdb1.h

     Sid:      mgcopdb1.h@@/main/3 - Wed Mar 30 08:01:30 2005

     Prg:      ra

*********************************************************************21*/

#ifndef __MGCOPDB1H__
#define __MGCOPDB1H__

#ifdef GCP_MGCO 



/******************************************************************************/
/*              Fax Tone Detection Package - PackageId 14                     */
/******************************************************************************/


#ifdef GCP_PKG_MGCO_FAXTONEDET       

#define MGT_PKG_REVTO_FTD_STD_TONE_LST_ALL 0
#define MGT_PKG_REVTO_FTD_STD_TONE_LST_DTFM 57
#define MGT_PKG_OBEVTO_FTD_STD_TONEID_ALL 0
#define MGT_PKG_OBEVTO_FTD_STD_TONEID_DTFM 57
#define MGT_PKG_REVTO_FTD_STD_TONE_LST 1
#define MGT_PKG_OBEVTO_FTD_STD_TONEID 3
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_ALL 0
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_D0 16
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_D1 17
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_D2 18
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_D3 19
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_D4 20
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_D5 21
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_D6 22
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_D7 23
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_D8 24
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_D9 25
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_DA 26
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_DB 27
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_DC 28
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_DD 29
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_DS 32
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_DO 33
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_DT 48
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_RT 49
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_BT 50
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_CT 51
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_SIT 52
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_WT 53
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_PT 54
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_CW 55
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_CR 56
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST_DTFM 57
#define MGT_PKG_OBEVTO_FTD_ETD_TONEID_ALL 0
#define MGT_PKG_OBEVTO_FTD_ETD_TONEID_DTFM 57
#define MGT_PKG_REVTO_FTD_ETD_TONE_LST 1
#define MGT_PKG_OBEVTO_FTD_ETD_DURATION 2
#define MGT_PKG_OBEVTO_FTD_ETD_TONEID 3
#define MGT_PKG_REVTO_FTD_LTD_TONE_LST_ALL 0
#define MGT_PKG_REVTO_FTD_LTD_TONE_LST_DTFM 57
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_ALL 0
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_D0 16
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_D1 17
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_D2 18
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_D3 19
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_D4 20
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_D5 21
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_D6 22
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_D7 23
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_D8 24
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_D9 25
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_DA 26
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_DB 27
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_DC 28
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_DD 29
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_DS 32
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_DO 33
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_DT 48
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_RT 49
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_BT 50
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_CT 51
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_SIT 52
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_WT 53
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_PT 54
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_CW 55
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_CR 56
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID_DTFM 57
#define MGT_PKG_REVTO_FTD_LTD_TONE_LST 1
#define MGT_PKG_REVTO_FTD_LTD_DURATION 2
#define MGT_PKG_OBEVTO_FTD_LTD_TONEID 3
#define MGT_PKG_REVT_FTD_STD 1
#define MGT_PKG_REVT_FTD_ETD 2
#define MGT_PKG_REVT_FTD_LTD 3

#endif /* GCP_PKG_MGCO_FAXTONEDET */



/******************************************************************************/
/*              Generic Announcement Package - PackageId 35                   */
/******************************************************************************/


#ifdef GCP_PKG_MGCO_GENANNC

#define MGT_PKG_SIGO_GEN_ANNC_FXD_ANN_DIREXT 1
#define MGT_PKG_SIGO_GEN_ANNC_FXD_ANN_DIRINT 2
#define MGT_PKG_SIGO_GEN_ANNC_FXD_ANN_DIRBOTH 3
#define MGT_PKG_SIGO_GEN_ANNC_FXD_ANN_NAME 1
#define MGT_PKG_SIGO_GEN_ANNC_FXD_NUMCYC 2
#define MGT_PKG_SIGO_GEN_ANNC_FXD_ANN_VAR 3
#define MGT_PKG_SIGO_GEN_ANNC_FXD_ANN_DIR 4
#define MGT_PKG_SIGO_GEN_ANNC_VAR_ANNC_DIREXT 1
#define MGT_PKG_SIGO_GEN_ANNC_VAR_ANNC_DIRINT 2
#define MGT_PKG_SIGO_GEN_ANNC_VAR_ANNC_DIRBOTH 3
#define MGT_PKG_SIGO_GEN_ANNC_VAR_ANNC_NAME 1
#define MGT_PKG_SIGO_GENANNC_VAR_NUMCYC 2
#define MGT_PKG_SIGO_GEN_ANNC_VAR_ANNC_VAR 3
#define MGT_PKG_SIGO_GEN_ANNC_VAR_NUM 4
#define MGT_PKG_SIGO_GEN_ANNC_VAR_SPI 5
#define MGT_PKG_SIGO_GEN_ANNC_VAR_SP 6
#define MGT_PKG_SIGO_GEN_ANNC_VAR_ANNC_DIR 7
#define MGT_PKG_SIG_GEN_ANNC_APF 1
#define MGT_PKG_SIG_GEN_ANNC_APV 2

#endif /* GCP_PKG_MGCO_GENANNC */


/******************************************************************************/
/*              Ancillary Input Package - PackageId 35                        */
/******************************************************************************/


#ifdef GCP_PKG_MGCO_ANCILLARYINPUT


#define MGT_PKG_OBEVTO_ANCLRY_INCHAR_INID 1
#define MGT_PKG_REVT_ANCLRY_INCHAR_IN 1

#endif /* GCP_PKG_MGCO_ANCILLARYINPUT */


/******************************************************************************/
/*              Call Type Discrimination Package - PackageId 17               */
/******************************************************************************/

#ifdef GCP_PKG_MGCO_CALLTYPDISCR

#define MGT_PKG_PROP_PARM_CTDP_CTYPE_FAX 1
#define MGT_PKG_PROP_PARM_CTDP_CTYPE_TXT 2
#define MGT_PKG_PROP_PARM_CTDP_CTYPE_DATA 3
#define MGT_PKG_PROP_PARM_CTDP_TTYP_V21 1
#define MGT_PKG_PROP_PARM_CTDP_TTYP_DTMF 2
#define MGT_PKG_PROP_PARM_CTDP_TTYP_BAUDOT45 3
#define MGT_PKG_PROP_PARM_CTDP_TTYP_BAUDOT50 4
#define MGT_PKG_PROP_PARM_CTDP_TTYP_BELL 5
#define MGT_PKG_PROP_PARM_CTDP_TTYP_EDT 6
#define MGT_PKG_PROP_PARM_CTDP_TTYP_MINITEL 7
#define MGT_PKG_PROP_PARM_CTDP_TTYP_V18 8
#define MGT_PKG_PROP_PARM_CTDP_V8BISSUPP_FALSE 0
#define MGT_PKG_PROP_PARM_CTDP_V8BISSUPP_TRUE 1
#define MGT_PKG_PROP_PARM_CTDP_PROBE_ORDR_V21 1
#define MGT_PKG_PROP_PARM_CTDP_PROBE_ORDR_DTMF 2
#define MGT_PKG_PROP_PARM_CTDP_PROBE_ORDR_BAUDOT 3
#define MGT_PKG_PROP_PARM_CTDP_PROBE_ORDR_EDT 4
#define MGT_PKG_PROP_PARM_CTDP_PROBE_ORDR_MINITEL 5
#define MGT_PKG_PROP_PARM_CTDP_PROBE_ORDR_BELL 6
#define MGT_PKG_PROP_PARM_CTDP_PHASE_REVDET_FALSE 0
#define MGT_PKG_PROP_PARM_CTDP_PHASE_REVDET_TRUE 1
#define MGT_PKG_PROP_PARM_CTDP_CTYPE 1
#define MGT_PKG_PROP_PARM_CTDP_TTYP 2
#define MGT_PKG_PROP_PARM_CTDP_V8BISSUPP 3
#define MGT_PKG_PROP_PARM_CTDP_PROBE_MSG 4
#define MGT_PKG_PROP_PARM_CTDP_PROBE_ORDR 5
#define MGT_PKG_PROP_PARM_CTDP_PHASE_REVDET 6
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_CNG 1
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_V21FLG 2
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_XCI 3
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_V18TXP1 4
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_V18TXP2 5
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_BELLHI 6
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_BELLLO 7
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_BAUDOT45 8
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_BAUDOT50 9
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_EDT 10
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_DTMF 11
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_SIG 12
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_CT 13
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_V21HI 14
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_V21LO 15
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_V23HI 16
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_V23LO 17
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_CI 18
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_ANS 19
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_ANSBAR 20
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_ANSAM 21
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_ANSAMBAR 22
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_CM 23
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_CJ 24
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_JM 25
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_ENDOFSIG 26
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT_V8BIS 27
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST_ESI 1
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST_ESR 2
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST_MRE 3
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST_MRDI 4
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST_MRDR 5
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST_CRE 6
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST_CRDI 7
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST_CRDR 8
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST_MS 9
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST_CL 10
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST_CLR 11
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST_ACK 12
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST_NAK 13
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTT 1
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV 2
#define MGT_PKG_OBEVTO_CTDP_DTONE_DTV_V8BIST 4
#define MGT_PKG_REVT_CTDP_DTONE 1
#define MGT_PKG_SIGO_CTDP_V8SIG_V8STYP_CM 1
#define MGT_PKG_SIGO_CTDP_V8SIG_V8STYP_CJ 2
#define MGT_PKG_SIGO_CTDP_V8SIG_V8STYP_JM 3
#define MGT_PKG_SIGO_CTDP_V8SIG_V8STYP_CI 4
#define MGT_PKG_SIGO_CTDP_V8SIG_V8STYP_V8NOSIG 5
#define MGT_PKG_SIGO_CTDP_V8SIG_V18XCI_ENABLE_FALSE 0
#define MGT_PKG_SIGO_CTDP_V8SIG_V18XCI_ENABLE_TRUE 1
#define MGT_PKG_SIGO_CTDP_V8SIG_V8STYP 1
#define MGT_PKG_SIGO_CTDP_V8SIG_V8SIGCONT 2
#define MGT_PKG_SIGO_CTDP_V8SIG_V18XCI_ENABLE 3
#define MGT_PKG_SIGO_CTDP_ANS_ANSTYP_ANS 1
#define MGT_PKG_SIGO_CTDP_ANS_ANSTYP_ANSBAR 2
#define MGT_PKG_SIGO_CTDP_ANS_ANSTYP_ANSAM 3
#define MGT_PKG_SIGO_CTDP_ANS_ANSTYP_ANSAMBAR 4
#define MGT_PKG_SIGO_CTDP_ANS_ANSTYP_V18TXP1 5
#define MGT_PKG_SIGO_CTDP_ANS_ANSTYP_V18TXP2 6
#define MGT_PKG_SIGO_CTDP_ANS_ANSTYP_NOSIG 7
#define MGT_PKG_SIGO_CTDP_ANS_ANSTYP 1
#define MGT_PKG_SIGO_CTDP_CALLSIG_CSN_CT 1
#define MGT_PKG_SIGO_CTDP_CALLSIG_CSN_CNG 2
#define MGT_PKG_SIGO_CTDP_CALLSIG_CSN_NOSIG 3
#define MGT_PKG_SIGO_CTDP_CALLSIG_CSN 1
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_ESI 1
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_ESR 2
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_MRE 3
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_MRDI 4
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_MRDRH 5
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_CREL 6
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_CRDI 7
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_CRDR 8
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_MS 9
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_CL 10
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_CLR 11
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_ACK 12
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_NAK 13
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_MRDRL 14
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN_CREH 15
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSN 1
#define MGT_PKG_SIGO_CTDP_V8BS_V8BSCONT 2
#define MGT_PKG_SIG_CTDP_V8SIG 1
#define MGT_PKG_SIG_CTDP_ANS 2
#define MGT_PKG_SIG_CTDP_CALLSIG 3
#define MGT_PKG_SIG_CTDP_V8BS 4
#define MGT_PKG_SIG_CTDP_V8PROBE 5


#endif /* GCP_PKG_MGCO_CALLTYPDISCR */



/******************************************************************************/
/*              Display Package - PackageId 20                                */
/******************************************************************************/

#ifdef GCP_PKG_MGCO_DISPLAY

#define MGT_PKG_PROP_PARM_DIS_NROWS 1
#define MGT_PKG_PROP_PARM_DIS_NCOLS 2
#define MGT_PKG_PROP_PARM_DIS_CDPGS 3
#define MGT_PKG_PROP_PARM_DIS_CURROW_POS 4
#define MGT_PKG_PROP_PARM_DIS_CURCOL_POS 5
#define MGT_PKG_SIGO_DIS_DI_ATTR_PLAIN 1
#define MGT_PKG_SIGO_DIS_DI_ATTR_BLINK 2
#define MGT_PKG_SIGO_DIS_DI_ATTR_INVERT 3
#define MGT_PKG_SIGO_DIS_DI_ATTR_UNDERLINE 4
#define MGT_PKG_SIGO_DIS_DI_ROW 1
#define MGT_PKG_SIGO_DIS_DI_COL 2
#define MGT_PKG_SIGO_DIS_DI_STR 3
#define MGT_PKG_SIGO_DIS_DI_ATTR 4
#define MGT_PKG_SIG_DIS_DI 1
#define MGT_PKG_SIG_DIS_CLR_DISPLY 2


#endif /* GCP_PKG_MGCO_DISPLAY */



/******************************************************************************/
/*              FAX Package - Package Id 18                                   */
/******************************************************************************/


#ifdef GCP_PKG_MGCO_FAX

#define MGT_PKG_PROP_PARM_FAX_FAXSTATE_IDLE 1
#define MGT_PKG_PROP_PARM_FAX_FAXSTATE_PREPARE 2
#define MGT_PKG_PROP_PARM_FAX_FAXSTATE_NEGOTIATING 3
#define MGT_PKG_PROP_PARM_FAX_FAXSTATE_TRAINR 4
#define MGT_PKG_PROP_PARM_FAX_FAXSTATE_TRAINT 5
#define MGT_PKG_PROP_PARM_FAX_FAXSTATE_CONNECTED 6
#define MGT_PKG_PROP_PARM_FAX_FAXSTATE_EOP 7
#define MGT_PKG_PROP_PARM_FAX_FAXSTATE_PROCINTR 8
#define MGT_PKG_PROP_PARM_FAX_FAXSTATE_DISCONNECT 9
#define MGT_PKG_PROP_PARM_FAX_TPT_T30 1
#define MGT_PKG_PROP_PARM_FAX_TPT_T30ECM 2
#define MGT_PKG_PROP_PARM_FAX_TPT_T30V34 3
#define MGT_PKG_PROP_PARM_FAX_PSTNIF_NA 1
#define MGT_PKG_PROP_PARM_FAX_PSTNIF_V17 2
#define MGT_PKG_PROP_PARM_FAX_PSTNIF_V27TER 3
#define MGT_PKG_PROP_PARM_FAX_PSTNIF_V29 4
#define MGT_PKG_PROP_PARM_FAX_PSTNIF_V21 5
#define MGT_PKG_PROP_PARM_FAX_PSTNIF_V34 6
#define MGT_PKG_PROP_PARM_FAX_FAXSTATE 1
#define MGT_PKG_PROP_PARM_FAX_TRANS_SPEED 2
#define MGT_PKG_PROP_PARM_FAX_PSTNIF 3
#define MGT_PKG_PROP_PARM_FAX_TPT 4
#define MGT_PKG_STAT_PARM_FAX_PAGESTRANS 1
#define MGT_PKG_STAT_PARM_FAX_TRAINDOWNS 2
#define MGT_PKG_OBEVTO_FAX_CONN_CHNG_FCC_IDLE 1
#define MGT_PKG_OBEVTO_FAX_CONN_CHNG_FCC_PREPARE 2
#define MGT_PKG_OBEVTO_FAX_CONN_CHNG_FCC_NEGOTIATING 3
#define MGT_PKG_OBEVTO_FAX_CONN_CHNG_FCC_TRAINR 4
#define MGT_PKG_OBEVTO_FAX_CONN_CHNG_FCC_TRAINT 5
#define MGT_PKG_OBEVTO_FAX_CONN_CHNG_FCC_CONNECTED 6
#define MGT_PKG_OBEVTO_FAX_CONN_CHNG_FCC_EOP 7
#define MGT_PKG_OBEVTO_FAX_CONN_CHNG_FCC_PROCINTR 8
#define MGT_PKG_OBEVTO_FAX_CONN_CHNG_FCC_EOF 9
#define MGT_PKG_OBEVTO_FAX_CONN_CHNG_FCC_PI 10
#define MGT_PKG_OBEVTO_FAX_CONN_CHNG_FCC_DISCONNECT 11
#define MGT_PKG_OBEVTO_FAX_CONN_CHNG_FCC 1
#define MGT_PKG_OBEVTO_FAX_CONN_CHNG 1


#endif /* GCP_PKG_MGCO_FAX */



/******************************************************************************/
/*              Indicator Package - PackageId 25                              */
/******************************************************************************/


#ifdef GCP_PKG_MGCO_INDICATOR

#define MGT_PKG_PROP_PARM_IND_INDLIST 1
#define MGT_PKG_SIGO_IND_IS_STATE_ON 1
#define MGT_PKG_SIGO_IND_IS_STATE_OFF 2
#define MGT_PKG_SIGO_IND_IS_STATE_BLNK 3
#define MGT_PKG_SIGO_IND_IS_STATE_FASTBLNK 4
#define MGT_PKG_SIGO_IND_IS_STATE_SLOWBLNK 5
#define MGT_PKG_SIGO_IND_INDID 1
#define MGT_PKG_SIGO_IND_IS_STATE 2
#define MGT_PKG_SIGO_IND_IS 1


#endif /* GCP_PKG_MGCO_INDICATOR */



/******************************************************************************/
/*              IP FAX Package - PackageId 19                                 */
/******************************************************************************/

#ifdef GCP_PKG_MGCO_IPFAX

#define MGT_PKG_PROP_PARM_IPFAX_FAXSTATE_IDLE 1
#define MGT_PKG_PROP_PARM_IPFAX_FAXSTATE_PREPARE 2
#define MGT_PKG_PROP_PARM_IPFAX_FAXSTATE_NEGOTIATING 3
#define MGT_PKG_PROP_PARM_IPFAX_FAXSTATE_TRAINR 4
#define MGT_PKG_PROP_PARM_IPFAX_FAXSTATE_TRAINT 5
#define MGT_PKG_PROP_PARM_IPFAX_FAXSTATE_CONNECTED 6
#define MGT_PKG_PROP_PARM_IPFAX_FAXSTATE_EOP 7
#define MGT_PKG_PROP_PARM_IPFAX_FAXSTATE_PROCINTR 8
#define MGT_PKG_PROP_PARM_IPFAX_FAXSTATE_DISCONNECT 9
#define MGT_PKG_PROP_PARM_IPFAX_TPT_T38UDPTL 1
#define MGT_PKG_PROP_PARM_IPFAX_TPT_T38TCP 2
#define MGT_PKG_PROP_PARM_IPFAX_TPT_T37 3
#define MGT_PKG_PROP_PARM_IPFAX_TPT_AUDIO 4
#define MGT_PKG_PROP_PARM_IPFAX_T38CAP_FILLBIT_RMVL 1
#define MGT_PKG_PROP_PARM_IPFAX_T38CAP_TRANSCOD_MMR 2
#define MGT_PKG_PROP_PARM_IPFAX_T38CAP_TRANSCOD_JBIG 3
#define MGT_PKG_PROP_PARM_IPFAX_T38CAP_UDPFEC 4
#define MGT_PKG_PROP_PARM_IPFAX_T38CAP_UDP_REDUND 5
#define MGT_PKG_PROP_PARM_IPFAX_FAXSTATE 1
#define MGT_PKG_PROP_PARM_IPFAX_TRANS_SPEED 2
#define MGT_PKG_PROP_PARM_IPFAX_T38_CAP 3
#define MGT_PKG_PROP_PARM_IPFAX_T38_MAXBUFSZ 4
#define MGT_PKG_PROP_PARM_IPFAX_T38_MAXDGRAMSZ 5
#define MGT_PKG_PROP_PARM_IPFAX_T38_VERSION 6
#define MGT_PKG_PROP_PARM_IPFAX_TPT 7
#define MGT_PKG_STAT_PARM_IPFAX_PAGESTRANS 1
#define MGT_PKG_STAT_PARM_IPFAX_TRAINDOWNS 2
#define MGT_PKG_OBEVTO_IPFAX_CONNCHG_CONNSTATE_CHG_IDLE 1
#define MGT_PKG_OBEVTO_IPFAX_CONNCHG_CONNSTATE_CHG_PREPARE 2
#define MGT_PKG_OBEVTO_IPFAX_CONNCHG_CONNSTATE_CHG_NEGOTIATING 3
#define MGT_PKG_OBEVTO_IPFAX_CONNCHG_CONNSTATE_CHG_TRAINR 4
#define MGT_PKG_OBEVTO_IPFAX_CONNCHG_CONNSTATE_CHG_TRAINT 5
#define MGT_PKG_OBEVTO_IPFAX_CONNCHG_CONNSTATE_CHG_CONNECTED 6
#define MGT_PKG_OBEVTO_IPFAX_CONNCHG_CONNSTATE_CHG_EOP 7
#define MGT_PKG_OBEVTO_IPFAX_CONNCHG_CONNSTATE_CHG_PROCINTR 8
#define MGT_PKG_OBEVTO_IPFAX_CONNCHG_CONNSTATE_CHG_EOF 9
#define MGT_PKG_OBEVTO_IPFAX_CONNCHG_CONNSTATE_CHG_PI 10
#define MGT_PKG_OBEVTO_IPFAX_CONNCHG_CONNSTATE_CHG_DISCONNECT 11
#define MGT_PKG_OBEVTO_IPFAX_CONNCHG_CONNSTATE_CHG 1
#define MGT_PKG_REVT_IPFAX_CONNCHG 1


#endif /* GCP_PKG_MGCO_IPFAX */



/******************************************************************************/
/*              Key Package - Package Id 21                                   */
/******************************************************************************/


#ifdef GCP_PKG_MGCO_KEY

#define MGT_PKG_OBEVTO_KEY_KEYDOWN_KEYID 1
#define MGT_PKG_OBEVTO_KEY_KEYUP_KEYID 1
#define MGT_PKG_OBEVTO_KEY_KEYUP_DUR 2
#define MGT_PKG_REVT_KEY_KEYDOWN 1
#define MGT_PKG_REVT_KEY_KEYUP 2


#endif /* GCP_PKG_MGCO_KEY */



/******************************************************************************/
/*              KEY PAD Package - Package Id 22                               */
/******************************************************************************/

#ifdef GCP_PKG_MGCO_KEYPAD

#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_K0 1
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_K1 2
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_K2 3
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_K3 4
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_K4 5
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_K5 6
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_K6 7
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_K7 8
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_K8 9
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_K9 10
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_KS 11
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_KO 12
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_KA 13
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_KB 14
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_KC 15
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID_KD 16
#define MGT_PKG_OBEVTO_KEYPAD_KEYDWN_KEYID 1
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_K0 1
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_K1 2
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_K2 3
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_K3 4
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_K4 5
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_K5 6
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_K6 7
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_K7 8
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_K8 9
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_K9 10
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_KS 11
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_KO 12
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_KA 13
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_KB 14
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_KC 15
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID_KD 16
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_KEYID 1
#define MGT_PKG_OBEVTO_KEYPAD_KEYUP_DUR 2
#define MGT_PKG_OBEVTO_KEYPAD_DGTMAP_COMP_TERM_METH_UM 1
#define MGT_PKG_OBEVTO_KEYPAD_DGTMAP_COMP_TERM_METH_PM 2
#define MGT_PKG_OBEVTO_KEYPAD_DGTMAP_COMP_TERM_METH_FM 3
#define MGT_PKG_OBEVTO_KEYPAD_DGTMAP_COMP_DGTSTR 1
#define MGT_PKG_OBEVTO_KEYPAD_DGTMAP_COMP_TERM_METH 3
#define MGT_PKG_REVT_KEYPAD_KEYDOWN 1
#define MGT_PKG_REVT_KEYPAD_KEYUP 2
#define MGT_PKG_REVT_KEYPAD_DGTMAP_COMP 3

#endif /* GCP_PKG_MGCO_KEYPAD */



/******************************************************************************/
/*              LABEL KEY - Package Id 23                                     */
/******************************************************************************/

#ifdef GCP_PKG_MGCO_LABELKEY

#define MGT_PKG_PROP_PARM_LABELKEY_KEYLIST 1
#define MGT_PKG_REVT_LABELKEY_KEYDOWN 1
#define MGT_PKG_REVT_LABELKEY_KEYUP 2

#define   mgMgcoReqEvtLabelKeyKeyDownDef  mgMgcoReqEvtKeyKeyDownDef

#define   mgMgcoReqEvtLabelKeyKeyUpDef  mgMgcoReqEvtKeyKeyUpDef

#define   mgMgcoEvtSecLabelKeyKeyDownDef  mgMgcoEvtSecKeyKeyDownDef

#define   mgMgcoEvtSecLabelKeyKeyUpDef  mgMgcoEvtSecKeyKeyUpDef

#define   mgMgcoEvSpecLabelKeyKeyDownDef  mgMgcoEvSpecKeyKeyDownDef

#define   mgMgcoEvSpecLabelKeyKeyUpDef  mgMgcoEvSpecKeyKeyUpDef


#endif /* GCP_PKG_MGCO_LABELKEY */


/******************************************************************************/
/*              Functional Key Package - Package Id 24                        */
/******************************************************************************/


#ifdef GCP_PKG_MGCO_FUNCKEY

#define MGT_PKG_PROP_PARM_FUNCKEY_KEYLIST 1
#define MGT_PKG_REVT_FUNCKEY_KEYDOWN 1
#define MGT_PKG_REVT_FUNCKEY_KEYUP 2

#define   mgMgcoPropParmFuncKeyKeyListDef  mgMgcoPropParmLabelKeyKeyListDef

#define   mgMgcoReqEvtFuncKeyKeyDownDef  mgMgcoReqEvtLabelKeyKeyDownDef

#define   mgMgcoReqEvtFuncKeyKeyUpDef  mgMgcoReqEvtLabelKeyKeyUpDef

#define   mgMgcoEvtSecFuncKeyKeyDownDef  mgMgcoEvtSecLabelKeyKeyDownDef

#define   mgMgcoEvtSecFuncKeyKeyUpDef  mgMgcoEvtSecLabelKeyKeyUpDef

#define   mgMgcoEvSpecFuncKeyKeyDownDef  mgMgcoEvSpecLabelKeyKeyDownDef

#define   mgMgcoEvSpecFuncKeyKeyUpDef  mgMgcoEvSpecLabelKeyKeyUpDef


#endif /* GCP_PKG_MGCO_FUNCKEY */


/******************************************************************************/
/*              Soft Key Package - Package Id - 26                            */
/******************************************************************************/


#ifdef GCP_PKG_MGCO_SOFTKEY

#define MGT_PKG_PROP_PARM_SOFTKEY_KEYLIST 1
#define MGT_PKG_PROP_PARM_SOFTKEY_NUM_SOFTKEYS 2
#define MGT_PKG_PROP_PARM_SOFTKEY_DISP_SIZE 3
#define MGT_PKG_PROP_PARM_SOFTKEY_SUPP_UNICODE_PGS 4
#define MGT_PKG_REVT_SOFTKEY_KEYDOWN 1
#define MGT_PKG_REVT_SOFTKEY_KEYUP 2
#define MGT_PKG_SIGO_SOFTKEY_SET_DISP_KEYID 1
#define MGT_PKG_SIGO_SOFTKEY_SET_DISP_DISPCONTENT 2
#define MGT_PKG_SIG_SOFTKEY_SET_DISP 1

#define   mgMgcoPropParmSoftKeyKeyListDef  mgMgcoPropParmLabelKeyKeyListDef

#define   mgMgcoReqEvtSoftKeyKeyDownDef  mgMgcoReqEvtLabelKeyKeyDownDef

#define   mgMgcoReqEvtSoftKeyKeyUpDef  mgMgcoReqEvtLabelKeyKeyUpDef

#define   mgMgcoEvtSecSoftKeyKeyDownDef  mgMgcoEvtSecLabelKeyKeyDownDef

#define   mgMgcoEvtSecSoftKeyKeyUpDef  mgMgcoEvtSecLabelKeyKeyUpDef

#define   mgMgcoEvSpecSoftKeyKeyDownDef  mgMgcoEvSpecLabelKeyKeyDownDef

#define   mgMgcoEvSpecSoftKeyKeyUpDef  mgMgcoEvSpecLabelKeyKeyUpDef


#endif /* GCP_PKG_MGCO_SOFTKEY */




/******************************************************************************/
/*              Text Conversation Package - Package Id 15                     */
/******************************************************************************/


#ifdef GCP_PKG_MGCO_TXTCNVR

#define MGT_PKG_PROP_PARM_TXC_CONNSTATE_IDLE 1
#define MGT_PKG_PROP_PARM_TXC_CONNSTATE_PREPARE 2
#define MGT_PKG_PROP_PARM_TXC_CONNSTATE_INITIATE 3
#define MGT_PKG_PROP_PARM_TXC_CONNSTATE_ACCEPT 4
#define MGT_PKG_PROP_PARM_TXC_CONNSTATE_DENY 5
#define MGT_PKG_PROP_PARM_TXC_CONNSTATE_CONNECTED 6
#define MGT_PKG_PROP_PARM_TXC_TPT_H224 1
#define MGT_PKG_PROP_PARM_TXC_TPT_AL1 2
#define MGT_PKG_PROP_PARM_TXC_TPT_TCP 3
#define MGT_PKG_PROP_PARM_TXC_TPT_RTPT140 4
#define MGT_PKG_PROP_PARM_TXC_TPT_RTPREDT140 5
#define MGT_PKG_PROP_PARM_TXC_TPT_T134 6
#define MGT_PKG_PROP_PARM_TXC_TPT_UNASSGND 7
#define MGT_PKG_PROP_PARM_TXC_BUFFTIME 1
#define MGT_PKG_PROP_PARM_TXC_CONNSTATE 2
#define MGT_PKG_PROP_PARM_TXC_TXTUSRID 3
#define MGT_PKG_PROP_PARM_TXC_TPT 4
#define MGT_PKG_PROP_PARM_TXC_TXTPROTO 5
#define MGT_PKG_PROP_PARM_TXC_REDLEVEL 6
#define MGT_PKG_PROP_PARM_TXC_TXTRQTMR 7
#define MGT_PKG_STAT_PARM_TXC_CHARTRANS 1
#define MGT_PKG_STAT_PARM_TXC_PACKLOST 2
#define MGT_PKG_OBEVTO_TXC_CONNSTATECHG_CONNCHG_IDLE 1
#define MGT_PKG_OBEVTO_TXC_CONNSTATECHG_CONNCHG_PREPARE 2
#define MGT_PKG_OBEVTO_TXC_CONNSTATECHG_CONNCHG_INITIATE 3
#define MGT_PKG_OBEVTO_TXC_CONNSTATECHG_CONNCHG_ACCEPT 4
#define MGT_PKG_OBEVTO_TXC_CONNSTATECHG_CONNCHG_DENY 5
#define MGT_PKG_OBEVTO_TXC_CONNSTATECHG_CONNCHG_CONNECTED 6
#define MGT_PKG_OBEVTO_TXC_CONNSTATECHG_CONNCHG 1
#define MGT_PKG_REVT_TXC_CONNSTATECHG 1


#endif /* GCP_PKG_MGCO_TXTCNVR */


/******************************************************************************/
/*              Text Telephone Package - Package Id 16                        */
/******************************************************************************/


#ifdef GCP_PKG_MGCO_TXTTELPHONE

#define MGT_PKG_PROP_PARM_TXP_CONVMODE_TXTONLY 1
#define MGT_PKG_PROP_PARM_TXP_CONVMODE_ALT 2
#define MGT_PKG_PROP_PARM_TXP_CONVMODE_SIMULT 3
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_V18V21HI 1
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_V18V21LO 2
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_V18V61C 3
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_V18V61A 4
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_V21HI 5
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_V21LO 6
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_DTMF 7
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_EDT 8
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_BAUDOT45 9
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_BAUDOT47 10
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_BAUDOT50 11
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_V23HI 12
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_V23LO 13
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_BELLHI 14
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_BELLLO 15
#define MGT_PKG_PROP_PARM_TXP_COM_MODE_NONE 16
#define MGT_PKG_PROP_PARM_TXP_CONN_MODE_IDLE 1
#define MGT_PKG_PROP_PARM_TXP_CONN_MODE_CONNECTING 2
#define MGT_PKG_PROP_PARM_TXP_CONN_MODE_CONNECTED 3
#define MGT_PKG_PROP_PARM_TXP_LOSS_CONN_KEEP 1
#define MGT_PKG_PROP_PARM_TXP_LOSS_CONN_RETURN 2
#define MGT_PKG_PROP_PARM_TXP_V18OPT_V61CAPAB 1
#define MGT_PKG_PROP_PARM_TXP_CONVMODE 1
#define MGT_PKG_PROP_PARM_TXP_COM_MODE 2
#define MGT_PKG_PROP_PARM_TXP_CONN_MODE 3
#define MGT_PKG_PROP_PARM_TXP_LOSS_CONN 6
#define MGT_PKG_PROP_PARM_TXP_V18OPT 7
#define MGT_PKG_PROP_PARM_TXP_CHARSET 8
#define MGT_PKG_STAT_PARM_TXP_CHAR_TRANS 1
#define MGT_PKG_STAT_PARM_TXP_ALT_TURNS 2
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_V18V21HI 1
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_V18V21LO 2
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_V18V61C 3
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_V18V61A 4
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_V21HI 5
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_V21LO 6
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_DTMF 7
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_EDT 8
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_BAUDOT45 9
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_BAUDOT47 10
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_BAUDOT50 11
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_V23HI 12
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_V23LO 13
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_BELLHI 14
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_BELLLO 15
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE_NONE 16
#define MGT_PKG_OBEVTO_TXP_CONNCHG_COM_MODE 2
#define MGT_PKG_REVT_TXP_CONNCHG 1


#endif /* GCP_PKG_MGCO_TXTTELPHONE */



#ifdef GCP_PKG_MGCO_ADVAUSRVRBASE


/******************************************************************************/
/*              Advanced Audio server base - Package Id 51                    */
/******************************************************************************/



#define MGT_PKG_OBEVTO_AASB_AUOPF_RC 1
#define MGT_PKG_REVT_AASB_AUOPF  1
#define MGT_PKG_SIGO_AASB_PLY_ANC 1
#define MGT_PKG_SIGO_AASB_PLY_ITR 2
#define MGT_PKG_SIGO_AASB_PLY_INTL 3
#define MGT_PKG_SIGO_AASB_PLY_SPD 4
#define MGT_PKG_SIGO_AASB_PLY_VOL 5
#define MGT_PKG_SIG_AASB_PLY 1

#endif /* GCP_PKG_MGCO_ADVAUSRVRBASE */

#ifdef GCP_PKG_MGCO_AASDIGCOLLECT


/******************************************************************************/
/*              Advanced Audio server DigCollect - Package Id 51              */
/******************************************************************************/



#define MGT_PKG_OBEVTO_AASDC_PLY_CSDC 1
#define MGT_PKG_OBEVTO_AASDC_PLY_CSNAT 2
#define MGT_PKG_OBEVTO_AASDC_PLY_CSAP 3

#define MGT_PKG_REVT_AASDC_AUOP  1
#define MGT_PKG_REVT_AASDC_PLY_CS 2

#define MGT_PKG_SIGO_AASDC_PLY_CNIPT 1 
#define MGT_PKG_SIGO_AASDC_PLY_CNIPF 2 

#define MGT_PKG_SIGO_AASDC_PLY_CKDT 1 
#define MGT_PKG_SIGO_AASDC_PLY_CKDF 2 

#define MGT_PKG_SIGO_AASDC_PLY_CCDBT 1 
#define MGT_PKG_SIGO_AASDC_PLY_CCDBF 2 

#define MGT_PKG_SIGO_AASDC_PLY_CIP 1 
#define MGT_PKG_SIGO_AASDC_PLY_CRP 2 
#define MGT_PKG_SIGO_AASDC_PLY_CNDP 3 
#define MGT_PKG_SIGO_AASDC_PLY_CSANNC 4 
#define MGT_PKG_SIGO_AASDC_PLY_CFANNC 5 
#define MGT_PKG_SIGO_AASDC_PLY_CNIPLY 6 
#define MGT_PKG_SIGO_AASDC_PLY_CKDGTS 7 
#define MGT_PKG_SIGO_AASDC_PLY_CCDBUF 8
#define MGT_PKG_SIGO_AASDC_PLY_CMATMPT 9 
#define MGT_PKG_SIGO_AASDC_PLY_CDGTMAP 10 
#define MGT_PKG_SIGO_AASDC_PLY_CSPD 11 
#define MGT_PKG_SIGO_AASDC_PLY_CVOL 12 
#define MGT_PKG_SIGO_AASDC_PLY_COFFS 13 
#define MGT_PKG_SIGO_AASDC_PLY_CRSTRTKEY 14 
#define MGT_PKG_SIGO_AASDC_PLY_CRINPKEY 15 
#define MGT_PKG_SIGO_AASDC_PLY_CRETKEY 16

#define MGT_PKG_SIG_AASDC_PLY 1 
#define MGT_PKG_SIG_AASDC_PLY_CLCT 2

#define   mgMgcoReqEvtAasDigCollectAuOpFailureDef  mgMgcoReqEvtAdvAuSrvrBaseAuOpFailureDef

#define   mgMgcoEvtSecAasDigCollectAuOpFailureDef  mgMgcoEvtSecAdvAuSrvrBaseAuOpFailureDef

#define   mgMgcoEvSpecAasDigCollectAuOpFailureDef  mgMgcoEvSpecAdvAuSrvrBaseAuOpFailureDef

#define   mgMgcoSignalAasDigCollectPlayDef  mgMgcoSignalAdvAuSrvrBasePlayDef

#endif /* GCP_PKG_MGCO_AASDIGCOLLECT */

#ifdef GCP_PKG_MGCO_AASRECODING 


/******************************************************************************/
/*              Advanced Audio server Recording - Package Id 51               */
/******************************************************************************/




#define MGT_PKG_PROPP_AASR_MTRL 1

#define MGT_PKG_OBEVTO_AASR_PLY_RSRRN 0 
#define MGT_PKG_OBEVTO_AASR_PLY_RSRRRC 1 
#define MGT_PKG_OBEVTO_AASR_PLY_RSRRKE 2

#define MGT_PKG_OBEVTO_AASR_PLY_RSAP 1 
#define MGT_PKG_OBEVTO_AASR_PLY_RSNAT 2 
#define MGT_PKG_OBEVTO_AASR_PLY_RSRR 3 
#define MGT_PKG_OBEVTO_AASR_PLY_RSRI 4 
#define MGT_PKG_OBEVTO_AASR_PLY_RSRD 5

#define MGT_PKG_REVT_AASR_AUOPF 1 
#define MGT_PKG_REVT_AASR_PLY_RECSUCC 2

#define MGT_PKG_SIGO_AASR_PLY_RIPRMPT 1 
#define MGT_PKG_SIGO_AASR_PLY_RNSPRMPT 2 
#define MGT_PKG_SIGO_AASR_PLY_RSANNC 3 
#define MGT_PKG_SIGO_AASR_PLY_RFANNC 4 
#define MGT_PKG_SIGO_AASR_PLY_RMATMPT 5 
#define MGT_PKG_SIGO_AASR_PLY_RPRSTMR 6 
#define MGT_PKG_SIGO_AASR_PLY_RPSSTMR 7
#define MGT_PKG_SIGO_AASR_PLY_RLENTMR 8
#define MGT_PKG_SIGO_AASR_PLY_RRECID 9
#define MGT_PKG_SIGO_AASR_PLY_RSPD 10
#define MGT_PKG_SIGO_AASR_PLY_RVOL 11
#define MGT_PKG_SIGO_AASR_PLY_ROFST 12 
#define MGT_PKG_SIGO_AASR_PLY_RSTRTKEY 13 
#define MGT_PKG_SIGO_AASR_PLY_RINPKEY 14 
#define MGT_PKG_SIGO_AASR_PLY_RRETKEY 15

#define MGT_PKG_SIGO_AASR_MPRECID 1

#define MGT_PKG_SIG_AASR_PLY 1 
#define MGT_PKG_SIG_AASR_PLY_REC 2 
#define MGT_PKG_SIG_AASR_MPERS 3

#define   mgMgcoReqEvtAasRecodingAuOpFailureDef  mgMgcoReqEvtAdvAuSrvrBaseAuOpFailureDef

#define   mgMgcoEvtSecAasRecodingAuOpFailureDef  mgMgcoEvtSecAdvAuSrvrBaseAuOpFailureDef

#define   mgMgcoEvSpecAasRecodingAuOpFailureDef  mgMgcoEvSpecAdvAuSrvrBaseAuOpFailureDef

#define   mgMgcoSignalAasRecodingPlayDef  mgMgcoSignalAdvAuSrvrBasePlayDef

#endif /* GCP_PKG_MGCO_AASRECODING */

#ifdef GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT 


/******************************************************************************/
/*              Advanced Audio server seg mngmnt - Package Id 51              */
/******************************************************************************/




#define MGT_PKG_PROPP_AASSM_ASCTN 1

#define MGT_PKG_SIGO_AASSM_DPSEGID 1

#define MGT_PKG_SIGO_AASSM_ORATS 1 
#define MGT_PKG_SIGO_AASSM_ORAORS 2

#define MGT_PKG_SIGO_AASSM_REATS 1

#define MGT_PKG_SIG_AASSM_DELPERS 1 
#define MGT_PKG_SIG_AASSM_OVRRAU 2 
#define MGT_PKG_SIG_AASSM_RSTRAU 3

#endif /* GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT */



#endif /* GCP_MGCO */

#endif /*__MGCOPDB1X__*/



/********************************************************************30**

         End of file:     mgcopdb1.h@@/main/3 - Wed Mar 30 08:01:30 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      ra   1. GCP 1.3 release
/main/2      ---      ka   1. Changes for Release v 1.4
/main/3      ---      pk   1. GCP 1.5 release
*********************************************************************91*/
