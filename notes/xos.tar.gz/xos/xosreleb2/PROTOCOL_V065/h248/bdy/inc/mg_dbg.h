
/**********************************************************************

         (c) COPYRIGHT 1989-2003 by 
         Beijing Xinwei Telecom Technology co., ltd. ShenZhen R&D center
         All rights reserved.

     
**********************************************************************/

/**********************************************************************

     Name:     mg_cfg.h 

     Type:     C include file

     Desc:     Defines MACO 

     Create :  2006-05-19 changdawei
     

**********************************************************************/
#ifndef MU_CFG_H
#define MU_CFG_H

#if 0
#define SO_NODEIDSTR "2F156A"
#define SO_UA_DOMAINNAME "UA.domain.com"
#define SO_ORGANIZATION "XINWEI"
#define SO_SUBJECT_STR  "Message From XINWEI"

#define SO_APPINST_0			0
#define SO_APPINST0             0
#define SO_APPINST1             1
#define SO_APPINST2             2
#define SO_APPINST3             3
#endif

#if 0
/*--------------- Common configuration defines ----------------*/
#ifndef SO_PROTVER
#endif
#endif

#define MGCO_MAX_SSAP           10
#define MGCO_MAX_TSAP           10
#define MGCO_MAX_SERVER         10
#define MGCO_MAX_CONN           10
#define MGCO_MAX_TXN            2000
#define MGCO_MAX_PEER           20
#define MGCO_RES_UPPER          5
#define MGCO_RES_LOWER          3
#define MGCO_TIME_RES           10
#define MGCO_NUM_BLKS           3
#define MGCO_MAX_BLK_SIZE       2048
#define MGCO_NUM_BINS_TXNID_HL  149
#define MGCO_NUM_BINS_NAME_HL   149
#define MGCO_NUM_BINS_TPT_SRVR_HL    149
#define MGCO_INDICATE_RETX      FALSE
#define MGCO_RES_ORDER          LMG_RES_IPV4
#define MGCO_RSP_ACK_ENB        0x10
#define MG_MY_MID_CFG           "<mid1.ccpu.com>"
#define MG_MY_DOMAIN_NAME_CFG   "changdawei.szxinwei.com.cn"   
#define MG_MYADDR_IP_CFG        0xa80002be

#if 0
#define SO_TPTPARAM_QSIZE     1

#define SO_DNS_A_CACHE_SZ     1024
#define SO_DNS_SRV_CACHE_SZ   1024
#define SO_DNS_NAPTR_CACHE_SZ 1024
#define SO_LOCSRV_SZ          1024
#define SO_HL_SIZE            50


#define SO_TSAP_SUID          0
#define SO_TSAP_SPID          0 

#define SO_GMT_OFFSET         2            
#define SO_REM_ADDR_DNS      "172.16.1.210"
#define SO_REM_PORT_DNS      53           
#define SO_TPTSRV_DNS        0           
#define SO_DNS_RETRY         3            
#define SO_1_SECOND          10
#define SO_1_HOUR            7200
#define SO_2_HOUR            14400
#define SO_DNS_QUERY_TM      2 * SO_1_SECOND
#define SO_DNS_CACHE_EXP     12 * SO_1_HOUR
#define SO_MCAST_CACHE_DFLT_EXP SO_1_HOUR
#define SO_MCAST_CACHE_MAX_EXP  SO_2_HOUR


#define  SO_500_MSECONDS     5
#define  SO_4_SECONDS        40
#define  SO_2_SECONDS        20
#define SO_10_SECONDS        100
#define  SO_20_SECONDS       200

#define SO_RETX_T1            SO_500_MSECONDS
#define SO_RETX_T2            SO_4_SECONDS
#define SO_RETX_T4            SO_2_SECONDS


#define SO_NAT_TMR              SO_20_SECONDS
#define SO_LOC_CACHE_DFLT_EXP   SO_1_HOUR
#define SO_LOC_CACHE_MAX_EXP    SO_2_HOUR


#define SO_LOCREG_THRESH_UPPER    0
#define SO_LOCREG_THRESH_LOWER    0
#define SO_LOCREG_DFLT_EXP_REG    SO_1_HOUR
#define SO_60_SECONDS             120
#define SO_LOCREG_DFLT_EXP_INV    SO_60_SECONDS
#define SO_TSAP_BNDRETRY          5
#define SO_TSAP_BNDTM             20*SO_1_SECOND
#define SO_TCP_ACTV_TM            10*SO_1_SECOND

#define SV_ENT_GET_IP_TXT(_entId) "127.0.0.1"

#define SV_ENT_GET_IP_U32(_entId) 0x00000000

#define SO_SV_IP_STR_SZ        16
#define SO_SV_PORT_STR_SZ      8

#define SV_LC                 0
#define SV_TC                 1
#define HI_SO_TC              9

/* defines for TUCL general configuration */
#define SO_TUCL_MAX_TSAP      SO_MAX_TSAP
#define SO_TUCL_MAX_CON       5000
#define SO_TUCL_FDS           1000
#define SO_TUCL_FDBINS        1000
#define SO_TUCL_STP_THRESH    5
#define SO_TUCL_DRP_THRESH    2
#define SO_TUCL_STRT_THRESH   4

/* defines for TUCL upper SAP configuration */
#define SO_TUCL_CONG_STRT     15000
#define SO_TUCL_CONG_DRP      20000
#define SO_TUCL_CONG_STP      10000
#define SO_TUCL_NMB_HLBINS    2

#endif

#define SU_IPV4_LEN			32
#define SU_DOMAIN_LEN       64

EXTERN Void mgSetDbgMaskFromShell(U32 dbgMask);

#endif
