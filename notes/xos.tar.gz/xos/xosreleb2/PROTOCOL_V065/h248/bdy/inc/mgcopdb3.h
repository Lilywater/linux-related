/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Megaco packages hash defines file

     Type:     C header file

     Desc:     Hash defines for Megaco packages implemented by TEL

     File:     mgcopdb3.h

     Sid:      mgcopdb3.h@@/main/1 - Wed Mar 30 08:13:45 2005

     Prg:      TEL2

*********************************************************************21*/
#ifndef __MGCOPDB3H__
#define __MGCOPDB3H__

#ifdef GCP_MGCO

/*
 * [TEL2]: Media Gateway OverLoad Control Package code added
 */
#ifdef GCP_PKG_MGCO_OCP

#define MGT_PKG_ENUM_REQEVT_OCP_MG_OVERLOAD 1

#endif /* GCP_PKG_MGCO_OCP */

/*
 * [TEL2]: Floor Control Package code added
 */
#ifdef GCP_PKG_MGCO_FLR_CTL

#define MGT_PKG_ENUM_PROPPARM_FLR_CTL_ACT_FLR_CTL_OFF 0
#define MGT_PKG_ENUM_PROPPARM_FLR_CTL_ACT_FLR_CTL_ON 1
#define MGT_PKG_ENUM_PROPPARM_FLR_CTL_ACT_FLR_CTL 1

#endif /* GCP_PKG_MGCO_FLR_CTL */

/*
 * [TEL2]: Indication of Being Viewed Package code added
 */
#ifdef GCP_PKG_MGCO_IND_VIEW

#define MGT_PKG_ENUM_SIGOTHER_IND_VIEW_BE_VWD_VWD_WHOM_ALL 1
#define MGT_PKG_ENUM_SIGOTHER_IND_VIEW_BE_VWD_VWD_WHOM_SOMEONE 2
#define MGT_PKG_ENUM_SIGOTHER_IND_VIEW_BE_VWD_VWD_WHOM 1
#define MGT_PKG_ENUM_SIGOTHER_IND_VIEW_BE_VWD_VWR_ID 2
#define MGT_PKG_ENUM_SIGNAL_IND_VIEW_BE_VWD 1
#define MGT_PKG_ENUM_SIGNAL_IND_VIEW_NO_VWR 2

#endif /* GCP_PKG_MGCO_IND_VIEW */

/*
 * [TEL2]: Volume Control Package code added
 */
#ifdef GCP_PKG_MGCO_VOL_CTL

#define MGT_PKG_ENUM_PROPPARM_VOL_CTL_VOL_LEV 1

#endif /* GCP_PKG_MGCO_VOL_CTL */

/*
 * [TEL2]: Volume Detection Package code added
 */
#ifdef GCP_PKG_MGCO_VOL_DET

#define MGT_PKG_ENUM_REQEVTOTHER_VOL_DET_VOL_ACT_DET_VOL_THR 1
#define MGT_PKG_ENUM_REQEVT_VOL_DET_VOL_ACT_DET 1

#endif /* GCP_PKG_MGCO_VOL_DET */

/*
 * [TEL2]: Volume Level Mixing Package code added
 */
#ifdef GCP_PKG_MGCO_VOL_LEV_MIX

#define MGT_PKG_ENUM_PROPPARM_VOL_LEV_MIX_MIX_LEV 1
#define MGT_PKG_ENUM_PROPPARM_VOL_LEV_MIX_N_SPK_MIX 2

#endif /* GCP_PKG_VOL_LEV_MIX */

/*
 * [TEL2]: Voice Activated Video Switch Package code added
 */
#ifdef GCP_PKG_MGCO_VOI_ACT_VID_SW

#define MGT_PKG_ENUM_PROPPARM_VOI_ACT_VID_SW_VID_MIX_BEH_ASP_ASA 1
#define MGT_PKG_ENUM_PROPPARM_VOI_ACT_VID_SW_AUD_STS 1
#define MGT_PKG_ENUM_PROPPARM_VOI_ACT_VID_SW_VOL_VID_SW 2
#define MGT_PKG_ENUM_PROPPARM_VOI_ACT_VID_SW_VID_MIX_BEH 3
#define MGT_PKG_ENUM_REQEVT_VOI_ACT_VID_SW_ACT_SPK 1

#endif /* GCP_PKG_MGCO_VOI_ACT_VID_SW */

/*
 * [TEL2]: Lecture Video Mode Package code added
 */
#ifdef GCP_PKG_MGCO_LEC_VID_MOD

#define MGT_PKG_ENUM_PROPPARM_LEC_VID_MOD_VID_SW_INT 1

#endif /* GCP_PKG_MGCO_LEC_VID_MOD */

/*
 * [TEL2]: Contributing Video Source Package code added
 */
#ifdef GCP_PKG_MGCO_CON_VID_SRC

#define MGT_PKG_ENUM_PROPPARM_CON_VID_SRC_IN_VID_SRC 1
#define MGT_PKG_ENUM_PROPPARM_CON_VID_SRC_CON_SRC_OP 2

#endif /* GCP_PKG_MGCO_CON_VID_SRC */

/*
 * [TEL2]: Profile Package code added
 */
#ifdef GCP_PKG_MGCO_PROF

#define MGT_PKG_ENUM_PROPPARM_PROF_PROF_SUPP 1

#endif /* GCP_PKG_MGCO_PROF */

/*
 * [TEL2]: Semi-Permanent Connection Package code added
 */
#ifdef GCP_PKG_MGCO_SEM_PER

#define MGT_PKG_ENUM_PROPPARM_SEM_PER_ACT_SEM_PER_FALSE 0
#define MGT_PKG_ENUM_PROPPARM_SEM_PER_ACT_SEM_PER_TRUE 1
#define MGT_PKG_ENUM_PROPPARM_SEM_PER_ACT_SEM_PER 1

#endif /* GCP_PKG_MGCO_SEM_PER */

/*
 * [TEL2]: Video Window Package code added
 */
#ifdef GCP_PKG_MGCO_VID_WIN

#define MGT_PKG_ENUM_PROPPARM_VID_WIN_WIN_ID 1
#define MGT_PKG_ENUM_PROPPARM_VID_WIN_WIN_SEQ 2
#define MGT_PKG_ENUM_PROPPARM_VID_WIN_WIN_XPOS 3
#define MGT_PKG_ENUM_PROPPARM_VID_WIN_WIN_YPOS 4
#define MGT_PKG_ENUM_PROPPARM_VID_WIN_WIN_HT 5
#define MGT_PKG_ENUM_PROPPARM_VID_WIN_WIN_WID 6

#endif /* GCP_PKG_MGCO_VID_WIN */

/*
 * [TEL2]: Tiled Window Package code added
 */
#ifdef GCP_PKG_MGCO_TIL_WIN

#define MGT_PKG_ENUM_PROPPARM_TIL_WIN_TIL_DET 1

#endif /* GCP_PKG_MGCO_TIL_WIN */

/*
 * [TEL2]: Enhanced Alerting Package code added
 */
#ifdef GCP_PKG_MGCO_EN_ALERT

#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_RING_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_RING_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_RING_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_RING_PATT 1
#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_RING_TONE_DIR 2
#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_RING_SPL_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_RING_SPL_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_RING_SPL_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_RING_SPL_TONE_DIR 1
#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_CALL_WG_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_CALL_WG_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_CALL_WG_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_CALL_WG_PATT 1
#define MGT_PKG_ENUM_SIGOTHER_EN_ALERT_CALL_WG_TONE_DIR 2
#define MGT_PKG_ENUM_SIGNAL_EN_ALERT_RING 1
#define MGT_PKG_ENUM_SIGNAL_EN_ALERT_RING_SPL 2
#define MGT_PKG_ENUM_SIGNAL_EN_ALERT_CALL_WG 3

#endif /* GCP_PKG_MGCO_EN_ALERT */

/*
 * [TEL2]: Shared Risk Group Package code added
 */
#ifdef GCP_PKG_MGCO_SH_RISK

#define MGT_PKG_ENUM_PROPPARM_SH_RISK_INCL_FALSE 0
#define MGT_PKG_ENUM_PROPPARM_SH_RISK_INCL_TRUE 1
#define MGT_PKG_ENUM_PROPPARM_SH_RISK_INCL 1
#define MGT_PKG_ENUM_PROPPARM_SH_RISK_SR_GP_IR 2
#define MGT_PKG_ENUM_PROPPARM_SH_RISK_AS_SR_GI 3

#endif /* GCP_PKG_MGCO_SH_RISK */

/*
 * [TEL2]: Mixing Volume Level Control Package code added
 */
#ifdef GCP_PKG_MGCO_MIX_VOL_CTL

#define MGT_PKG_ENUM_PROPPARM_MIX_VOL_CTL_MIX_PART_NUM 1
#define MGT_PKG_ENUM_PROPPARM_MIX_VOL_CTL_VOL_LEV_IN 2

#endif /* GCP_PKG_MGCO_MIX_VOL_CTL */

/*
 * [TEL2]: CAS Blocking Alerting Package code added
 */
#ifdef GCP_PKG_MGCO_CAS_BLK

#define MGT_PKG_ENUM_REQEVT_CAS_BLK_BLK 1
#define MGT_PKG_ENUM_REQEVT_CAS_BLK_UN_BLK 2
#define MGT_PKG_ENUM_SIGNAL_CAS_BLK_BLK 1

#endif /* GCP_PKG_MGCO_CAS_BLK */

/*
 * [TEL2]: Conferencing Tones Generation package code added
 */
#ifdef GCP_PKG_MGCO_CONF_TN
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_ENTER_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_ENTER_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_ENTER_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_ENTER_TONE_DIR 1
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_EXIT_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_EXIT_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_EXIT_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_EXIT_TONE_DIR 1
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_LOCK_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_LOCK_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_LOCK_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_LOCK_TONE_DIR 1
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_UN_LOCK_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_UN_LOCK_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_UN_LOCK_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_UN_LOCK_TONE_DIR 1
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_TIME_LIM_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_TIME_LIM_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_TIME_LIM_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_CONF_TN_TIME_LIM_TONE_DIR 1
#define MGT_PKG_ENUM_SIGNAL_CONF_TNPT 1
#define MGT_PKG_ENUM_SIGNAL_CONF_TN_ENTER 97
#define MGT_PKG_ENUM_SIGNAL_CONF_TN_EXIT 98
#define MGT_PKG_ENUM_SIGNAL_CONF_TN_LOCK 99
#define MGT_PKG_ENUM_SIGNAL_CONF_TN_UN_LOCK 100
#define MGT_PKG_ENUM_SIGNAL_CONF_TN_TIME_LIM 101

#define   mgMgcoSignal_Conf_TnPtDef  mgMgcoSignalToneGenPtDef

#endif /* GCP_PKG_MGCO_CONF_TN */

/*
 * [TEL2]: Diagnostic Tones Generation package code added
 */
#ifdef GCP_PKG_MGCO_TEST

#define MGT_PKG_ENUM_SIGOTHER_TEST_LOW_TN_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_TEST_LOW_TN_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_TEST_LOW_TN_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_TEST_LOW_TN_TONE_DIR 1
#define MGT_PKG_ENUM_SIGOTHER_TEST_HI_TN_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_TEST_HI_TN_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_TEST_HI_TN_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_TEST_HI_TN_TONE_DIR 1
#define MGT_PKG_ENUM_SIGOTHER_TEST_LD_TN_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_TEST_LD_TN_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_TEST_LD_TN_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_TEST_LD_TN_TONE_DIR 1
#define MGT_PKG_ENUM_SIGOTHER_TEST_FT_TN_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_TEST_FT_TN_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_TEST_FT_TN_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_TEST_FT_TN_TONE_DIR 1
#define MGT_PKG_ENUM_SIGOTHER_TEST_SW_TN_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_TEST_SW_TN_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_TEST_SW_TN_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_TEST_SW_TN_TONE_DIR 1
#define MGT_PKG_ENUM_SIGOTHER_TEST_FA_TN_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_TEST_FA_TN_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_TEST_FA_TN_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_TEST_FA_TN_TONE_DIR 1
#define MGT_PKG_ENUM_SIGNAL_TESTPT 1
#define MGT_PKG_ENUM_SIGNAL_TEST_LOW_TN 102
#define MGT_PKG_ENUM_SIGNAL_TEST_HI_TN 103
#define MGT_PKG_ENUM_SIGNAL_TEST_LD_TN 104
#define MGT_PKG_ENUM_SIGNAL_TEST_FT_TN 105
#define MGT_PKG_ENUM_SIGNAL_TEST_SW_TN 106
#define MGT_PKG_ENUM_SIGNAL_TEST_FA_TN 107

#define   mgMgcoSignal_TestPtDef  mgMgcoSignalToneGenPtDef

#endif /* GCP_PKG_MGCO_TEST */

/*
 * [TEL2]: Carrier Tones Generation package code added
 */
#ifdef GCP_PKG_MGCO_CARR_TN

#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_CDL_TN_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_CDL_TN_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_CDL_TN_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_CDL_TN_TONE_DIR 1
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_ANS_TN_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_ANS_TN_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_ANS_TN_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_ANS_TN_TONE_DIR 1
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_CHG_TN_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_CHG_TN_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_CHG_TN_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_CHG_TN_TONE_DIR 1
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_LDI_TN_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_LDI_TN_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_LDI_TN_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_CARR_TN_LDI_TN_TONE_DIR 1
#define MGT_PKG_ENUM_SIGNAL_CARR_TNPT 1
#define MGT_PKG_ENUM_SIGNAL_CARR_TN_CDL_TN 108
#define MGT_PKG_ENUM_SIGNAL_CARR_TN_ANS_TN 109
#define MGT_PKG_ENUM_SIGNAL_CARR_TN_CHG_TN 110
#define MGT_PKG_ENUM_SIGNAL_CARR_TN_LDI_TN 111

#define   mgMgcoSignal_Carr_TnPtDef  mgMgcoSignalToneGenPtDef

#endif /* GCP_PKG_MGCO_CARR_TN */

/*
 * [TEL2]: Analog Display Signalling package code added
 */
#ifdef GCP_PKG_MGCO_AN_DISP

#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_DIS_ALT_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_DIS_ALT_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_DIS_ALT_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_DIS_ALT_DIS_DBLK 1
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_DIS_ALT_PATT 2
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_DIS_ALT_TONE_DIR 3
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_GEN_DAT_TERM_SGL_DT 1
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_GEN_DAT_TERM_SGL_RP 2
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_GEN_DAT_TERM_SGL_LR 3
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_GEN_DAT_TERM_SGL_NT 4
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_GEN_DAT_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_GEN_DAT_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_GEN_DAT_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_GEN_DAT_DAT_BLK 1
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_GEN_DAT_TERM_SGL 2
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_GEN_DAT_TONE_DIR 3
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_ERR_TONE_DIR_EXT 1
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_ERR_TONE_DIR_INT 2
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_ERR_TONE_DIR_BOTH 3
#define MGT_PKG_ENUM_SIGOTHER_AN_DISP_ERR_TONE_DIR 3
#define MGT_PKG_ENUM_SIGNAL_AN_DISP_RING 1
#define MGT_PKG_ENUM_SIGNAL_AN_DISP_RING_SPL 2
#define MGT_PKG_ENUM_SIGNAL_AN_DISP_CALL_WG 3
#define MGT_PKG_ENUM_SIGNAL_AN_DISP_DIS_ALT 4
#define MGT_PKG_ENUM_SIGNAL_AN_DISP_GEN_DAT 5
#define MGT_PKG_ENUM_SIGNAL_AN_DISP_ERR 6

#define   mgMgcoSignal_An_Disp_RingDef  mgMgcoSignal_EN_ALERT_RingDef

#define   mgMgcoSignal_An_Disp_Ring_SplDef  mgMgcoSignal_EN_ALERT_Ring_SplDef

#define   mgMgcoSignal_An_Disp_Call_WgDef  mgMgcoSignal_EN_ALERT_Call_WgDef

#endif /* GCP_PKG_MGCO_AN_DISP */

/*
 * [TEL2]: Extended Analog Line Supervision package code added
 */
#ifdef GCP_PKG_MGCO_EXT_ALG

#define MGT_PKG_ENUM_REQEVT_EXT_ALGONHOOK 4
#define MGT_PKG_ENUM_REQEVT_EXT_ALGOFFHOOK 5
#define MGT_PKG_ENUM_REQEVT_EXT_ALGFLASHHOOK 6

#define   mgMgcoReqEvt_Ext_AlgOnHookDef  mgMgcoReqEvtAnalogOnHookDef

#define   mgMgcoReqEvt_Ext_AlgOffHookDef  mgMgcoReqEvtAnalogOffHookDef

#define   mgMgcoReqEvt_Ext_AlgFlashHookDef  mgMgcoReqEvtAnalogFlashHookDef

#define   mgMgcoEvtSec_Ext_AlgOnHookDef  mgMgcoEvtSecAnalogOnHookDef

#define   mgMgcoEvtSec_Ext_AlgOffHookDef  mgMgcoEvtSecAnalogOffHookDef

#define   mgMgcoEvtSec_Ext_AlgFlashHookDef  mgMgcoEvtSecAnalogFlashHookDef

#define   mgMgcoEvSpec_Ext_AlgOnHookDef  mgMgcoEvSpecAnalogOnHookDef

#define   mgMgcoEvSpec_Ext_AlgOffHookDef  mgMgcoEvSpecAnalogOffHookDef

#define   mgMgcoEvSpec_Ext_AlgFlashHookDef  mgMgcoEvSpecAnalogFlashHookDef
#define MGT_PKG_ENUM_SIGNAL_EXT_ALGRING 2
#define MGT_PKG_ENUM_SIGNAL_EXT_ALG_LS_ANS_SUP 3
#define MGT_PKG_ENUM_SIGNAL_EXT_ALG_NET_DISC 4

#define   mgMgcoSignal_Ext_AlgRingDef  mgMgcoSignalAnalogRingDef

/* Code added to avoid undefined reference */
#define  mgMgcoReqEvtAnalogOffHookDef  mgMgcoReqEvtAnalogOnHookDef

#endif /* GCP_PKG_MGCO_EXT_ALG */

/*
 * [TEL2]: Automatic Metering package code added
 */
#ifdef GCP_PKG_MGCO_AUT_MET

#define MGT_PKG_ENUM_STATPARM_AUT_MET_CUR_PUL_CT 1
#define MGT_PKG_ENUM_STATPARM_AUT_MET_PUL_CT_SLR 2
#define MGT_PKG_ENUM_REQEVTOTHER_AUT_MET_PER_REP_REP_PER 1
#define MGT_PKG_ENUM_REQEVT_AUT_MET_PER_REP 1
#define MGT_PKG_ENUM_SIGOTHER_AUT_MET_EN_MET_PUL_CT 1
#define MGT_PKG_ENUM_SIGOTHER_AUT_MET_EN_MET_PUL_REP_INT 2
#define MGT_PKG_ENUM_SIGOTHER_AUT_MET_MET_PUL_BUR_BUR_PUL_CT 1
#define MGT_PKG_ENUM_SIGNAL_AUT_MET_EN_MET 1
#define MGT_PKG_ENUM_SIGNAL_AUT_MET_MET_PUL_BUR 2

#endif /* GCP_PKG_MGCO_AUT_MET */

/*
 * [TEL2]: H.324 package code added
 */
#ifdef GCP_PKG_MGCO_H_324

#define MGT_PKG_ENUM_PROPPARM_H_324_COM_MOD_H324P 1
#define MGT_PKG_ENUM_PROPPARM_H_324_COM_MOD_H324M 2
#define MGT_PKG_ENUM_PROPPARM_H_324_COM_MOD_H324I 3
#define MGT_PKG_ENUM_PROPPARM_H_324_MUX_LEV_LEV_0 1
#define MGT_PKG_ENUM_PROPPARM_H_324_MUX_LEV_LEV_1 2
#define MGT_PKG_ENUM_PROPPARM_H_324_MUX_LEV_LEV_2 3
#define MGT_PKG_ENUM_PROPPARM_H_324_MUX_LEV_LEV_3 4
#define MGT_PKG_ENUM_PROPPARM_H_324_DE_MUX_FALSE 0
#define MGT_PKG_ENUM_PROPPARM_H_324_DE_MUX_TRUE 1
#define MGT_PKG_ENUM_PROPPARM_H_324_COM_MOD 1
#define MGT_PKG_ENUM_PROPPARM_H_324_MUX_LEV 2
#define MGT_PKG_ENUM_PROPPARM_H_324_DE_MUX 3
#define MGT_PKG_ENUM_PROPPARM_H_324_RH223_CAP 4
#define MGT_PKG_ENUM_PROPPARM_H_324_IN_MUX_TAB 5
#define MGT_PKG_ENUM_PROPPARM_H_324_OUT_MUX_TAB 6
#define MGT_PKG_ENUM_STATPARM_H_324_MUX_SENT 1
#define MGT_PKG_ENUM_STATPARM_H_324_MUX_RECV 2
#define MGT_PKG_ENUM_STATPARM_H_324_MUX_ERR 3

#endif /* GCP_PKG_MGCO_H_324 */

/*
 * [TEL2]: H.245 Command package code added
 */
#ifdef GCP_PKG_MGCO_H_245_COM

#define MGT_PKG_ENUM_PROPPARM_H_245_COM_MISC_IN 1
#define MGT_PKG_ENUM_PROPPARM_H_245_COM_MISC_OUT 2
#define MGT_PKG_ENUM_PROPPARM_H_245_COM_H223MR_IN 3
#define MGT_PKG_ENUM_PROPPARM_H_245_COM_H223MR_OUT 4

#endif /* GCP_PKG_MGCO_H_245_COM */

/*
 * [TEL2]: H.245 Indication package code added
 */
#ifdef GCP_PKG_MGCO_H_245_IND

#define MGT_PKG_ENUM_PROPPARM_H_245_IND_MISC_IN 1
#define MGT_PKG_ENUM_PROPPARM_H_245_IND_MISC_OUT 2

#endif /* GCP_PKG_MGCO_H_245_IND */

/*
 * [TEL2]: Extended H.245 Command package code added
 */
#ifdef GCP_PKG_MGCO_H245_COM_EXT

#define MGT_PKG_ENUM_PROPPARM_H245_COM_EXT_MISC_IN 1
#define MGT_PKG_ENUM_PROPPARM_H245_COM_EXT_MISC_OUT 2
#define MGT_PKG_ENUM_PROPPARM_H245_COM_EXT_H223MR_IN 3
#define MGT_PKG_ENUM_PROPPARM_H245_COM_EXT_H223MR_OUT 4
#define MGT_PKG_ENUM_PROPPARM_H245_COM_EXT_H245_VER 5
#define MGT_PKG_ENUM_PROPPARM_H245_COM_EXT_FLOW_CON 6

#define   mgMgcoPropParm_H245_Com_Ext_Misc_InDef  mgMgcoPropParm_H_245_Com_Misc_InDef

#define   mgMgcoPropParm_H245_Com_Ext_Misc_OutDef  mgMgcoPropParm_H_245_Com_Misc_OutDef

#define   mgMgcoPropParm_H245_Com_Ext_H223mr_InDef  mgMgcoPropParm_H_245_Com_H223mr_InDef

#define   mgMgcoPropParm_H245_Com_Ext_H223mr_OutDef  mgMgcoPropParm_H_245_Com_H223mr_OutDef

#endif /* GCP_PKG_MGCO_H245_COM_EXT */

/*
 * [TEL2]: Extended H.245 Indication package code added
 */
#ifdef GCP_PKG_MGCO_H245_IND_EXT

#define MGT_PKG_ENUM_PROPPARM_H245_IND_EXT_MISC_IN 1
#define MGT_PKG_ENUM_PROPPARM_H245_IND_EXT_MISC_OUT 2
#define MGT_PKG_ENUM_PROPPARM_H245_IND_EXT_H223_SKEW_IND 3
#define MGT_PKG_ENUM_PROPPARM_H245_IND_EXT_JIT_IND 4

#define   mgMgcoPropParm_H245_Ind_EXt_Misc_InDef  mgMgcoPropParm_H_245_Ind_Misc_InDef

#define   mgMgcoPropParm_H245_Ind_EXt_Misc_OutDef  mgMgcoPropParm_H_245_Ind_Misc_OutDef

#endif /* GCP_PKG_MGCO_H245_IND_EXT */

/*
 * [TEL2]: Quality Alert Ceasing package code added
 */
#ifdef GCP_PKG_MGCO_QTY_ALT
   
#define MGT_PKG_ENUM_PROPPARM_QTY_ALTJIT 7

#define   mgMgcoPropParm_Qty_AltJitDef  mgMgcoPropParmNetworkJitDef
#define MGT_PKG_ENUM_STATPARM_QTY_ALTDUR 1
#define MGT_PKG_ENUM_STATPARM_QTY_ALTOS 2
#define MGT_PKG_ENUM_STATPARM_QTY_ALTOR 3
#define MGT_PKG_ENUM_REQEVTOTHER_QTY_ALT_QTY_ALRT_CSTHRESHOLD 1
#define MGT_PKG_ENUM_REQEVT_QTY_ALT_QTY_ALRT_CS 4
#define MGT_PKG_ENUM_REQEVT_QTY_ALTNETFAIL 5
#define MGT_PKG_ENUM_REQEVT_QTY_ALTQUALERT 6

#define   mgMgcoReqEvt_Qty_AltNetfailDef  mgMgcoReqEvtNetworkNetfailDef

#define   mgMgcoReqEvt_Qty_AltQualertDef  mgMgcoReqEvtNetworkQualertDef

#define   mgMgcoEvtSec_Qty_AltNetfailDef  mgMgcoEvtSecNetworkNetfailDef

#define   mgMgcoEvtSec_Qty_AltQualertDef  mgMgcoEvtSecNetworkQualertDef

#define   mgMgcoEvSpec_Qty_AltNetfailDef  mgMgcoEvSpecNetworkNetfailDef

#define   mgMgcoEvSpec_Qty_AltQualertDef  mgMgcoEvSpecNetworkQualertDef

#endif /* GCP_PKG_MGCO_QTY_ALT */

/*
 * [TEL2]: Extended H.324 package code added
 */
#ifdef GCP_PKG_MGCO_H324_EXT 

#define MGT_PKG_ENUM_PROPPARM_H324_EXT_COM_MOD 1
#define MGT_PKG_ENUM_PROPPARM_H324_EXT_MUX_LEV 2
#define MGT_PKG_ENUM_PROPPARM_H324_EXT_DE_MUX 3
#define MGT_PKG_ENUM_PROPPARM_H324_EXT_RH223_CAP 4
#define MGT_PKG_ENUM_PROPPARM_H324_EXT_IN_MUX_TAB 5
#define MGT_PKG_ENUM_PROPPARM_H324_EXT_OUT_MUX_TAB 6
#define MGT_PKG_ENUM_PROPPARM_H324_EXT_MAX_PDU 7
#define MGT_PKG_ENUM_PROPPARM_H324_EXT_H223_CAPL 8
#define MGT_PKG_ENUM_PROPPARM_H324_EXT_H223_LC_PARM 9

#define   mgMgcoPropParm_H324_Ext_Com_ModDef  mgMgcoPropParm_H_324_Com_ModDef

#define   mgMgcoPropParm_H324_Ext_Mux_LevDef  mgMgcoPropParm_H_324_Mux_LevDef

#define   mgMgcoPropParm_H324_Ext_De_MuxDef  mgMgcoPropParm_H_324_De_MuxDef

#define   mgMgcoPropParm_H324_Ext_RH223_CapDef  mgMgcoPropParm_H_324_RH223_CapDef

#define   mgMgcoPropParm_H324_Ext_In_Mux_TabDef  mgMgcoPropParm_H_324_In_Mux_TabDef

#define   mgMgcoPropParm_H324_Ext_Out_Mux_TabDef  mgMgcoPropParm_H_324_Out_Mux_TabDef
#define MGT_PKG_ENUM_STATPARM_H324_EXT_MUX_SENT 1
#define MGT_PKG_ENUM_STATPARM_H324_EXT_MUX_RECV 2
#define MGT_PKG_ENUM_STATPARM_H324_EXT_MUX_ERR 3

#endif /* GCP_PKG_MGCO_H324_EXT */

/*
 * [TEL2]: Adaptive Jitter Buffer package code added
 */
#ifdef GCP_PKG_MGCO_AD_JIT_BUFF
   
#define MGT_PKG_ENUM_PROPPARM_AD_JIT_BUFF_ENAB_JB_OFF 0
#define MGT_PKG_ENUM_PROPPARM_AD_JIT_BUFF_ENAB_JB_ON 1
#define MGT_PKG_ENUM_PROPPARM_AD_JIT_BUFF_JIT_TYPE_NO 0
#define MGT_PKG_ENUM_PROPPARM_AD_JIT_BUFF_JIT_TYPE_NON_ADT 1
#define MGT_PKG_ENUM_PROPPARM_AD_JIT_BUFF_JIT_TYPE_ADT 2
#define MGT_PKG_ENUM_PROPPARM_AD_JIT_BUFFJIT 7
#define MGT_PKG_ENUM_PROPPARM_AD_JIT_BUFF_JIT_MIN 8
#define MGT_PKG_ENUM_PROPPARM_AD_JIT_BUFF_JIT_NOM 9
#define MGT_PKG_ENUM_PROPPARM_AD_JIT_BUFF_ENAB_JB 10
#define MGT_PKG_ENUM_PROPPARM_AD_JIT_BUFF_JIT_TYPE 11
#define MGT_PKG_ENUM_PROPPARM_AD_JIT_BUFF_JIT_CUR 12
#define MGT_PKG_ENUM_PROPPARM_AD_JIT_BUFF_ADT_RT 13

#define   mgMgcoPropParm_Ad_Jit_BuffJitDef  mgMgcoPropParmNetworkJitDef
#define MGT_PKG_ENUM_STATPARM_AD_JIT_BUFFDUR 1
#define MGT_PKG_ENUM_STATPARM_AD_JIT_BUFFOS 2
#define MGT_PKG_ENUM_STATPARM_AD_JIT_BUFFOR 3
#define MGT_PKG_ENUM_REQEVT_AD_JIT_BUFFNETFAIL 5
#define MGT_PKG_ENUM_REQEVT_AD_JIT_BUFFQUALERT 6

#define   mgMgcoReqEvt_Ad_Jit_BuffNetfailDef  mgMgcoReqEvtNetworkNetfailDef

#define   mgMgcoReqEvt_Ad_Jit_BuffQualertDef  mgMgcoReqEvtNetworkQualertDef

#define   mgMgcoEvtSec_Ad_Jit_BuffNetfailDef  mgMgcoEvtSecNetworkNetfailDef

#define   mgMgcoEvtSec_Ad_Jit_BuffQualertDef  mgMgcoEvtSecNetworkQualertDef

#define   mgMgcoEvSpec_Ad_Jit_BuffNetfailDef  mgMgcoEvSpecNetworkNetfailDef

#define   mgMgcoEvSpec_Ad_Jit_BuffQualertDef  mgMgcoEvSpecNetworkQualertDef

#endif /* GCP_PKG_MGCO_AD_JIT_BUFF */

/*
 * [TEL2]: International CAS package code added
 */
#ifdef GCP_PKG_MGCO_ICAS
   
#define MGT_PKG_ENUM_PROPPARM_ICAS_TR_DIR_IN_COM 1
#define MGT_PKG_ENUM_PROPPARM_ICAS_TR_DIR_OUT_GO 2
#define MGT_PKG_ENUM_PROPPARM_ICAS_TR_DIR_BOTH_WAY 3
#define MGT_PKG_ENUM_PROPPARM_ICAS_TR_DIR 1
#define MGT_PKG_ENUM_STATPARM_ICAS_CALL_DUR 1
#define MGT_PKG_ENUM_OBSEVTOTHER_ICAS_CAS_FLR_ERR_CD_UNXP_LN_SG 1
#define MGT_PKG_ENUM_OBSEVTOTHER_ICAS_CAS_FLR_ERR_CD_LN_SG_TO 2
#define MGT_PKG_ENUM_OBSEVTOTHER_ICAS_CAS_FLR_ERR_CD_ST_MC_MALFN 4
#define MGT_PKG_ENUM_OBSEVTOTHER_ICAS_CAS_FLR_ERR_CD_IDL_GRD_TO 5
#define MGT_PKG_ENUM_OBSEVTOTHER_ICAS_CAS_FLR_ERR_CD_CLR_FWD_TO 6
#define MGT_PKG_ENUM_OBSEVTOTHER_ICAS_CAS_FLR_ERR_CD_CLR_BK_TO 7
#define MGT_PKG_ENUM_OBSEVTOTHER_ICAS_CAS_FLR_ERR_CD_CONG 8
#define MGT_PKG_ENUM_OBSEVTOTHER_ICAS_CAS_FLR_ERR_CD_DISC 9
#define MGT_PKG_ENUM_OBSEVTOTHER_ICAS_CAS_FLR_ERR_CD 1
#define MGT_PKG_ENUM_OBSEVTOTHER_ICAS_SUB_LN_STS_SUB_LN_CON_SUB_LN_BY 1
#define MGT_PKG_ENUM_OBSEVTOTHER_ICAS_SUB_LN_STS_SUB_LN_CON_SUB_LN_FC 2
#define MGT_PKG_ENUM_OBSEVTOTHER_ICAS_SUB_LN_STS_SUB_LN_CON 1
#define MGT_PKG_ENUM_REQEVTOTHER_ICAS_CLR_FWD_CLR_GD_TMG_OFF 0
#define MGT_PKG_ENUM_REQEVTOTHER_ICAS_CLR_FWD_CLR_GD_TMG_ON 1
#define MGT_PKG_ENUM_REQEVTOTHER_ICAS_CLR_FWD_CLR_GD_TMG 1
#define MGT_PKG_ENUM_REQEVTOTHER_ICAS_CLR_BK_CLR_GD_TMG_OFF 0
#define MGT_PKG_ENUM_REQEVTOTHER_ICAS_CLR_BK_CLR_GD_TMG_ON 1
#define MGT_PKG_ENUM_REQEVTOTHER_ICAS_CLR_BK_CLR_GD_TMG 1
#define MGT_PKG_ENUM_REQEVT_ICAS_SEIZURE 1
#define MGT_PKG_ENUM_REQEVT_ICAS_SEIZE_ACK 2
#define MGT_PKG_ENUM_REQEVT_ICAS_ANS 3
#define MGT_PKG_ENUM_REQEVT_ICAS_IDLE 4
#define MGT_PKG_ENUM_REQEVT_ICAS_CAS_FLR 5
#define MGT_PKG_ENUM_REQEVT_ICAS_SUB_LN_STS 6
#define MGT_PKG_ENUM_REQEVT_ICAS_CLR_FWD 7
#define MGT_PKG_ENUM_REQEVT_ICAS_CLR_BK 8
#define MGT_PKG_ENUM_REQEVT_ICAS_REL_GD 9
#define MGT_PKG_ENUM_REQEVT_ICAS_CONG 10

#define   mgMgcoReqEvt_Icas_SeizureDef  mgMgcoReqEvt_bcas_SeizureDef

#define   mgMgcoReqEvt_Icas_Seize_ackDef  mgMgcoReqEvt_bcas_Seize_ackDef

#define   mgMgcoReqEvt_Icas_AnsDef  mgMgcoReqEvt_bcas_AnsDef

#define   mgMgcoReqEvt_Icas_IdleDef  mgMgcoReqEvt_bcas_IdleDef

#define   mgMgcoEvtSec_Icas_SeizureDef  mgMgcoEvtSec_bcas_SeizureDef

#define   mgMgcoEvtSec_Icas_Seize_ackDef  mgMgcoEvtSec_bcas_Seize_ackDef

#define   mgMgcoEvtSec_Icas_AnsDef  mgMgcoEvtSec_bcas_AnsDef

#define   mgMgcoEvtSec_Icas_IdleDef  mgMgcoEvtSec_bcas_IdleDef

#define   mgMgcoEvSpec_Icas_SeizureDef  mgMgcoEvSpec_bcas_SeizureDef

#define   mgMgcoEvSpec_Icas_Seize_ackDef  mgMgcoEvSpec_bcas_Seize_ackDef

#define   mgMgcoEvSpec_Icas_AnsDef  mgMgcoEvSpec_bcas_AnsDef

#define   mgMgcoEvSpec_Icas_IdleDef  mgMgcoEvSpec_bcas_IdleDef
#define MGT_PKG_ENUM_SIGOTHER_ICAS_SUB_LN_STS_SUB_LN_CON_SUB_LN_BY 1
#define MGT_PKG_ENUM_SIGOTHER_ICAS_SUB_LN_STS_SUB_LN_CON_SUB_LN_FC 2
#define MGT_PKG_ENUM_SIGOTHER_ICAS_SUB_LN_STS_SUB_LN_CON 1
#define MGT_PKG_ENUM_SIGNAL_ICAS_SEIZE 1
#define MGT_PKG_ENUM_SIGNAL_ICAS_SEIZE_ACK 2
#define MGT_PKG_ENUM_SIGNAL_ICAS_ANS 3
#define MGT_PKG_ENUM_SIGNAL_ICAS_IDLE 4
#define MGT_PKG_ENUM_SIGNAL_ICAS_CONG 5
#define MGT_PKG_ENUM_SIGNAL_ICAS_CLR_FWD 6
#define MGT_PKG_ENUM_SIGNAL_ICAS_CLR_BK 7
#define MGT_PKG_ENUM_SIGNAL_ICAS_SUB_LN_STS 8
#define MGT_PKG_ENUM_SIGNAL_ICAS_REL_GD 9

#define   mgMgcoSignal_Icas_SeizeDef  mgMgcoSignal_bcas_SeizeDef

#define   mgMgcoSignal_Icas_Seize_ackDef  mgMgcoSignal_bcas_Seize_ackDef

#define   mgMgcoSignal_Icas_AnsDef  mgMgcoSignal_bcas_AnsDef

#define   mgMgcoSignal_Icas_IdleDef  mgMgcoSignal_bcas_IdleDef

#endif /* GCP_PKG_MGCO_ICAS */

/*
 * [TEL2]: Multi-Frequency Tone Generation package code added
 */
#ifdef GCP_PKG_MGCO_MFQ_TN_GEN
   
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GENPT 1
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_0 80
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_1 81
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_2 82
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_3 83
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_4 84
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_5 85
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_6 86
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_7 87
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_8 88
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_9 89
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_KP 90
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_KPB 91
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_KPC 92
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_KPD 93
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_ST 94
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_STF 95
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_STG 96
#define MGT_PKG_ENUM_SIGNAL_MFQ_TN_GEN_MF_SG_STH 97

#define   mgMgcoSignal_MFq_tn_genPtDef  mgMgcoSignalToneGenPtDef

#endif /* GCP_PKG_MGCO_MFQ_TN_DET */

/*
 * [TEL2]: Multi-Frequency Tone Detection package code added
 */
#ifdef GCP_PKG_MGCO_MFQ_TN_DET
   
#define MGT_PKG_ENUM_OBSEVTOTHER_MFQ_TN_DET_DMAP_COM_EVT_TERM_MTD_UNAMB_MTCH 1
#define MGT_PKG_ENUM_OBSEVTOTHER_MFQ_TN_DET_DMAP_COM_EVT_TERM_MTD_PAR_MTCH 2
#define MGT_PKG_ENUM_OBSEVTOTHER_MFQ_TN_DET_DMAP_COM_EVT_TERM_MTD_FULL_MTCH 3
#define MGT_PKG_ENUM_OBSEVTOTHER_MFQ_TN_DET_DMAP_COM_EVT_DGT_STR 1
#define MGT_PKG_ENUM_OBSEVTOTHER_MFQ_TN_DET_DMAP_COM_EVT_TERM_MTD 2
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DETSTD 1
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DETETD 2
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DETLTD 3
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_DMAP_COM_EVT 4
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_0 80
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_1 81
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_2 82
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_3 83
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_4 84
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_5 85
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_6 86
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_7 87
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_8 88
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_9 89
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_KP 90
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_KPB 91
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_KPC 92
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_KPD 93
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_ST 94
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_STF 95
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_STG 96
#define MGT_PKG_ENUM_REQEVT_MFQ_TN_DET_MF_SG_STH 97

#define   mgMgcoReqEvt_MFq_tn_detStdDef  mgMgcoReqEvtToneDetStdDef

#define   mgMgcoReqEvt_MFq_tn_detEtdDef  mgMgcoReqEvtToneDetEtdDef

#define   mgMgcoReqEvt_MFq_tn_detLtdDef  mgMgcoReqEvtToneDetLtdDef

#define   mgMgcoEvtSec_MFq_tn_detStdDef  mgMgcoEvtSecToneDetStdDef

#define   mgMgcoEvtSec_MFq_tn_detEtdDef  mgMgcoEvtSecToneDetEtdDef

#define   mgMgcoEvtSec_MFq_tn_detLtdDef  mgMgcoEvtSecToneDetLtdDef

#define   mgMgcoEvSpec_MFq_tn_detStdDef  mgMgcoEvSpecToneDetStdDef

#define   mgMgcoEvSpec_MFq_tn_detEtdDef  mgMgcoEvSpecToneDetEtdDef

#define   mgMgcoEvSpec_MFq_tn_detLtdDef  mgMgcoEvSpecToneDetLtdDef

/* Code added to avoid undefined refernce */
#define   mgMgcoReqEvtToneDetEtdDef mgMgcoReqEvtToneDetStdDef
#define   mgMgcoEvtSecToneDetEtdDef mgMgcoEvtSecToneDetStdDef
#define   mgMgcoEvSpecToneDetLtdDef mgMgcoEvSpecToneDetEtdDef

#endif /* GCP_PKG_MGCO_MFQ_TN_DET */

/*
 * [TEL2]: Extended DTMF Detection package code added
 */
#ifdef GCP_PKG_MGCO_EXT_DTMF

#define MGT_PKG_ENUM_REQEVTOTHER_EXT_DTMF_EXT_CE_EXT_DD_OFF 0
#define MGT_PKG_ENUM_REQEVTOTHER_EXT_DTMF_EXT_CE_EXT_DD_ON 1
#define MGT_PKG_ENUM_REQEVTOTHER_EXT_DTMF_EXT_CE_MTCH_PROC_BASE 1
#define MGT_PKG_ENUM_REQEVTOTHER_EXT_DTMF_EXT_CE_MTCH_PROC_ENHAN 2
#define MGT_PKG_ENUM_OBSEVTOTHER_EXT_DTMF_EXT_CE_TERM_METHUM 1
#define MGT_PKG_ENUM_OBSEVTOTHER_EXT_DTMF_EXT_CE_TERM_METHPM 2
#define MGT_PKG_ENUM_OBSEVTOTHER_EXT_DTMF_EXT_CE_TERM_METHFM 3
#define MGT_PKG_ENUM_REQEVTOTHER_EXT_DTMF_EXT_CE_BUF_CTRL 1
#define MGT_PKG_ENUM_REQEVTOTHER_EXT_DTMF_EXT_CE_EXT_DD 2
#define MGT_PKG_ENUM_REQEVTOTHER_EXT_DTMF_EXT_CE_MTCH_PROC 3
#define MGT_PKG_ENUM_OBSEVTOTHER_EXT_DTMF_EXT_CE_DGT_STR 1
#define MGT_PKG_ENUM_OBSEVTOTHER_EXT_DTMF_EXT_CE_TERM_METH 2
#define MGT_PKG_ENUM_OBSEVTOTHER_EXT_DTMF_EXT_CE_EXTRA 3
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFSTD 1
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFETD 2
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFLTD 3
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFCE 4
#define MGT_PKG_ENUM_REQEVT_EXT_DTMF_EXT_CE 5
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMF0 16
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMF1 17
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMF2 18
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMF3 19
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMF4 20
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMF5 21
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMF6 22
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMF7 23
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMF8 24
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMF9 25
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMFA 26
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMFB 27
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMFC 28
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMFD 29
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMFS 32
#define MGT_PKG_ENUM_REQEVT_EXT_DTMFDTMFO 33

#define   mgMgcoReqEvt_Ext_DtmfStdDef  mgMgcoReqEvtDtmfDetStdDef

#define   mgMgcoReqEvt_Ext_DtmfEtdDef  mgMgcoReqEvtDtmfDetEtdDef

#define   mgMgcoReqEvt_Ext_DtmfLtdDef  mgMgcoReqEvtDtmfDetLtdDef

#define   mgMgcoReqEvt_Ext_DtmfCeDef  mgMgcoReqEvtDtmfDetCeDef

#define   mgMgcoReqEvt_Ext_DtmfDtmf0Def  mgMgcoReqEvtDtmfDetDtmf0Def

#define   mgMgcoReqEvt_Ext_DtmfDtmf1Def  mgMgcoReqEvtDtmfDetDtmf1Def

#define   mgMgcoReqEvt_Ext_DtmfDtmf2Def  mgMgcoReqEvtDtmfDetDtmf2Def

#define   mgMgcoReqEvt_Ext_DtmfDtmf3Def  mgMgcoReqEvtDtmfDetDtmf3Def

#define   mgMgcoReqEvt_Ext_DtmfDtmf4Def  mgMgcoReqEvtDtmfDetDtmf4Def

#define   mgMgcoReqEvt_Ext_DtmfDtmf5Def  mgMgcoReqEvtDtmfDetDtmf5Def

#define   mgMgcoReqEvt_Ext_DtmfDtmf6Def  mgMgcoReqEvtDtmfDetDtmf6Def

#define   mgMgcoReqEvt_Ext_DtmfDtmf7Def  mgMgcoReqEvtDtmfDetDtmf7Def

#define   mgMgcoReqEvt_Ext_DtmfDtmf8Def  mgMgcoReqEvtDtmfDetDtmf8Def

#define   mgMgcoReqEvt_Ext_DtmfDtmf9Def  mgMgcoReqEvtDtmfDetDtmf9Def

#define   mgMgcoReqEvt_Ext_DtmfDtmfaDef  mgMgcoReqEvtDtmfDetDtmfaDef

#define   mgMgcoReqEvt_Ext_DtmfDtmfbDef  mgMgcoReqEvtDtmfDetDtmfbDef

#define   mgMgcoReqEvt_Ext_DtmfDtmfcDef  mgMgcoReqEvtDtmfDetDtmfcDef

#define   mgMgcoReqEvt_Ext_DtmfDtmfdDef  mgMgcoReqEvtDtmfDetDtmfdDef

#define   mgMgcoReqEvt_Ext_DtmfDtmfsDef  mgMgcoReqEvtDtmfDetDtmfsDef

#define   mgMgcoReqEvt_Ext_DtmfDtmfoDef  mgMgcoReqEvtDtmfDetDtmfoDef

#define   mgMgcoEvtSec_Ext_DtmfStdDef  mgMgcoEvtSecDtmfDetStdDef

#define   mgMgcoEvtSec_Ext_DtmfEtdDef  mgMgcoEvtSecDtmfDetEtdDef

#define   mgMgcoEvtSec_Ext_DtmfLtdDef  mgMgcoEvtSecDtmfDetLtdDef

#define   mgMgcoEvtSec_Ext_DtmfCeDef  mgMgcoEvtSecDtmfDetCeDef

#define   mgMgcoEvtSec_Ext_DtmfDtmf0Def  mgMgcoEvtSecDtmfDetDtmf0Def

#define   mgMgcoEvtSec_Ext_DtmfDtmf1Def  mgMgcoEvtSecDtmfDetDtmf1Def

#define   mgMgcoEvtSec_Ext_DtmfDtmf2Def  mgMgcoEvtSecDtmfDetDtmf2Def

#define   mgMgcoEvtSec_Ext_DtmfDtmf3Def  mgMgcoEvtSecDtmfDetDtmf3Def

#define   mgMgcoEvtSec_Ext_DtmfDtmf4Def  mgMgcoEvtSecDtmfDetDtmf4Def

#define   mgMgcoEvtSec_Ext_DtmfDtmf5Def  mgMgcoEvtSecDtmfDetDtmf5Def

#define   mgMgcoEvtSec_Ext_DtmfDtmf6Def  mgMgcoEvtSecDtmfDetDtmf6Def

#define   mgMgcoEvtSec_Ext_DtmfDtmf7Def  mgMgcoEvtSecDtmfDetDtmf7Def

#define   mgMgcoEvtSec_Ext_DtmfDtmf8Def  mgMgcoEvtSecDtmfDetDtmf8Def

#define   mgMgcoEvtSec_Ext_DtmfDtmf9Def  mgMgcoEvtSecDtmfDetDtmf9Def

#define   mgMgcoEvtSec_Ext_DtmfDtmfaDef  mgMgcoEvtSecDtmfDetDtmfaDef

#define   mgMgcoEvtSec_Ext_DtmfDtmfbDef  mgMgcoEvtSecDtmfDetDtmfbDef

#define   mgMgcoEvtSec_Ext_DtmfDtmfcDef  mgMgcoEvtSecDtmfDetDtmfcDef

#define   mgMgcoEvtSec_Ext_DtmfDtmfdDef  mgMgcoEvtSecDtmfDetDtmfdDef

#define   mgMgcoEvtSec_Ext_DtmfDtmfsDef  mgMgcoEvtSecDtmfDetDtmfsDef

#define   mgMgcoEvtSec_Ext_DtmfDtmfoDef  mgMgcoEvtSecDtmfDetDtmfoDef

#define   mgMgcoEvSpec_Ext_DtmfStdDef  mgMgcoEvSpecDtmfDetStdDef

#define   mgMgcoEvSpec_Ext_DtmfEtdDef  mgMgcoEvSpecDtmfDetEtdDef

#define   mgMgcoEvSpec_Ext_DtmfLtdDef  mgMgcoEvSpecDtmfDetLtdDef

#define   mgMgcoEvSpec_Ext_DtmfCeDef  mgMgcoEvSpecDtmfDetCeDef

#define   mgMgcoEvSpec_Ext_DtmfDtmf0Def  mgMgcoEvSpecDtmfDetDtmf0Def

#define   mgMgcoEvSpec_Ext_DtmfDtmf1Def  mgMgcoEvSpecDtmfDetDtmf1Def

#define   mgMgcoEvSpec_Ext_DtmfDtmf2Def  mgMgcoEvSpecDtmfDetDtmf2Def

#define   mgMgcoEvSpec_Ext_DtmfDtmf3Def  mgMgcoEvSpecDtmfDetDtmf3Def

#define   mgMgcoEvSpec_Ext_DtmfDtmf4Def  mgMgcoEvSpecDtmfDetDtmf4Def

#define   mgMgcoEvSpec_Ext_DtmfDtmf5Def  mgMgcoEvSpecDtmfDetDtmf5Def

#define   mgMgcoEvSpec_Ext_DtmfDtmf6Def  mgMgcoEvSpecDtmfDetDtmf6Def

#define   mgMgcoEvSpec_Ext_DtmfDtmf7Def  mgMgcoEvSpecDtmfDetDtmf7Def

#define   mgMgcoEvSpec_Ext_DtmfDtmf8Def  mgMgcoEvSpecDtmfDetDtmf8Def

#define   mgMgcoEvSpec_Ext_DtmfDtmf9Def  mgMgcoEvSpecDtmfDetDtmf9Def

#define   mgMgcoEvSpec_Ext_DtmfDtmfaDef  mgMgcoEvSpecDtmfDetDtmfaDef

#define   mgMgcoEvSpec_Ext_DtmfDtmfbDef  mgMgcoEvSpecDtmfDetDtmfbDef

#define   mgMgcoEvSpec_Ext_DtmfDtmfcDef  mgMgcoEvSpecDtmfDetDtmfcDef

#define   mgMgcoEvSpec_Ext_DtmfDtmfdDef  mgMgcoEvSpecDtmfDetDtmfdDef

#define   mgMgcoEvSpec_Ext_DtmfDtmfsDef  mgMgcoEvSpecDtmfDetDtmfsDef

#define   mgMgcoEvSpec_Ext_DtmfDtmfoDef  mgMgcoEvSpecDtmfDetDtmfoDef

/* Code added to avoid undefined refernce */


#define   mgMgcoReqEvtDtmfDetStdDef   mgMgcoReqEvtToneDetStdDef
#define   mgMgcoReqEvtDtmfDetEtdDef   mgMgcoReqEvtToneDetEtdDef
#define   mgMgcoReqEvtDtmfDetLtdDef   mgMgcoReqEvtToneDetLtdDef
#define   mgMgcoReqEvtDtmfDetDtmf0Def mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmf1Def mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmf2Def mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmf3Def mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmf4Def mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmf5Def mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmf6Def mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmf7Def mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmf8Def mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmf9Def mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmfaDef mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmfbDef mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmfcDef mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmfdDef mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmfsDef mgMgcoReqEvtDtmfDet_dxDef
#define   mgMgcoReqEvtDtmfDetDtmfoDef mgMgcoReqEvtDtmfDet_dxDef

#define   mgMgcoEvtSecDtmfDetStdDef   mgMgcoEvtSecToneDetStdDef
#define   mgMgcoEvtSecDtmfDetEtdDef   mgMgcoEvtSecToneDetStdDef
#define   mgMgcoEvtSecDtmfDetLtdDef   mgMgcoEvtSecToneDetLtdDef
#define   mgMgcoEvtSecDtmfDetDtmf0Def mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmf1Def mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmf2Def mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmf3Def mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmf4Def mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmf5Def mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmf6Def mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmf7Def mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmf8Def mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmf9Def mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmfaDef mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmfbDef mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmfcDef mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmfdDef mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmfsDef mgMgcoEvtSecDtmfDet_dxDef
#define   mgMgcoEvtSecDtmfDetDtmfoDef mgMgcoEvtSecDtmfDet_dxDef

#define   mgMgcoEvSpecDtmfDetStdDef   mgMgcoEvSpecToneDetStdDef
#define   mgMgcoEvSpecDtmfDetEtdDef   mgMgcoEvSpecToneDetEtdDef
#define   mgMgcoEvSpecDtmfDetLtdDef   mgMgcoEvSpecToneDetEtdDef
#define   mgMgcoEvSpecDtmfDetDtmf0Def mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmf1Def mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmf2Def mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmf3Def mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmf4Def mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmf5Def mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmf6Def mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmf7Def mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmf8Def mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmf9Def mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmfaDef mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmfbDef mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmfcDef mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmfdDef mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmfsDef mgMgcoEvSpecDtmfDet_dxDef
#define   mgMgcoEvSpecDtmfDetDtmfoDef mgMgcoEvSpecDtmfDet_dxDef

/* Code added to avoid undefined refernce */
#define   mgMgcoReqEvtToneDetEtdDef mgMgcoReqEvtToneDetStdDef
#define   mgMgcoEvtSecToneDetEtdDef mgMgcoEvtSecToneDetStdDef
#define   mgMgcoEvSpecToneDetLtdDef mgMgcoEvSpecToneDetEtdDef

#endif /* GCP_PKG_MGCO_EXT_DTMF */

/*
 * [TEL2]: Enhanced DTMF Detection package code added
 */
#ifdef GCP_PKG_MGCO_ENH_DTMF

#define MGT_PKG_ENUM_OBSEVTOTHER_ENH_DTMF_MTCH_CE_TERM_METH_ESM 4
#define MGT_PKG_ENUM_REQEVTOTHER_ENH_DTMF_MTCH_CE_BUF_CTRL 1
#define MGT_PKG_ENUM_OBSEVTOTHER_ENH_DTMF_MTCH_CE_DGT_STR 1
#define MGT_PKG_ENUM_OBSEVTOTHER_ENH_DTMF_MTCH_CE_TERM_METH 2
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFSTD 1
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFETD 2
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFLTD 3
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFCE 4
#define MGT_PKG_ENUM_REQEVT_ENH_DTMF_EXT_CE 5
#define MGT_PKG_ENUM_REQEVT_ENH_DTMF_MTCH_CE 6
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMF0 16
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMF1 17
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMF2 18
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMF3 19
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMF4 20
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMF5 21
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMF6 22
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMF7 23
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMF8 24
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMF9 25
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMFA 26
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMFB 27
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMFC 28
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMFD 29
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMFS 32
#define MGT_PKG_ENUM_REQEVT_ENH_DTMFDTMFO 33

#define   mgMgcoReqEvt_Enh_DtmfStdDef  mgMgcoReqEvt_Ext_DtmfStdDef

#define   mgMgcoReqEvt_Enh_DtmfEtdDef  mgMgcoReqEvt_Ext_DtmfEtdDef

#define   mgMgcoReqEvt_Enh_DtmfLtdDef  mgMgcoReqEvt_Ext_DtmfLtdDef

#define   mgMgcoReqEvt_Enh_DtmfCeDef  mgMgcoReqEvt_Ext_DtmfCeDef

#define   mgMgcoReqEvt_Enh_Dtmf_Ext_CeDef  mgMgcoReqEvt_Ext_Dtmf_Ext_CeDef

#define   mgMgcoReqEvt_Enh_DtmfDtmf0Def  mgMgcoReqEvt_Ext_DtmfDtmf0Def

#define   mgMgcoReqEvt_Enh_DtmfDtmf1Def  mgMgcoReqEvt_Ext_DtmfDtmf1Def

#define   mgMgcoReqEvt_Enh_DtmfDtmf2Def  mgMgcoReqEvt_Ext_DtmfDtmf2Def

#define   mgMgcoReqEvt_Enh_DtmfDtmf3Def  mgMgcoReqEvt_Ext_DtmfDtmf3Def

#define   mgMgcoReqEvt_Enh_DtmfDtmf4Def  mgMgcoReqEvt_Ext_DtmfDtmf4Def

#define   mgMgcoReqEvt_Enh_DtmfDtmf5Def  mgMgcoReqEvt_Ext_DtmfDtmf5Def

#define   mgMgcoReqEvt_Enh_DtmfDtmf6Def  mgMgcoReqEvt_Ext_DtmfDtmf6Def

#define   mgMgcoReqEvt_Enh_DtmfDtmf7Def  mgMgcoReqEvt_Ext_DtmfDtmf7Def

#define   mgMgcoReqEvt_Enh_DtmfDtmf8Def  mgMgcoReqEvt_Ext_DtmfDtmf8Def

#define   mgMgcoReqEvt_Enh_DtmfDtmf9Def  mgMgcoReqEvt_Ext_DtmfDtmf9Def

#define   mgMgcoReqEvt_Enh_DtmfDtmfaDef  mgMgcoReqEvt_Ext_DtmfDtmfaDef

#define   mgMgcoReqEvt_Enh_DtmfDtmfbDef  mgMgcoReqEvt_Ext_DtmfDtmfbDef

#define   mgMgcoReqEvt_Enh_DtmfDtmfcDef  mgMgcoReqEvt_Ext_DtmfDtmfcDef

#define   mgMgcoReqEvt_Enh_DtmfDtmfdDef  mgMgcoReqEvt_Ext_DtmfDtmfdDef

#define   mgMgcoReqEvt_Enh_DtmfDtmfsDef  mgMgcoReqEvt_Ext_DtmfDtmfsDef

#define   mgMgcoReqEvt_Enh_DtmfDtmfoDef  mgMgcoReqEvt_Ext_DtmfDtmfoDef

#define   mgMgcoEvtSec_Enh_DtmfStdDef  mgMgcoEvtSec_Ext_DtmfStdDef

#define   mgMgcoEvtSec_Enh_DtmfEtdDef  mgMgcoEvtSec_Ext_DtmfEtdDef

#define   mgMgcoEvtSec_Enh_DtmfLtdDef  mgMgcoEvtSec_Ext_DtmfLtdDef

#define   mgMgcoEvtSec_Enh_DtmfCeDef  mgMgcoEvtSec_Ext_DtmfCeDef

#define   mgMgcoEvtSec_Enh_Dtmf_Ext_CeDef  mgMgcoEvtSec_Ext_Dtmf_Ext_CeDef

#define   mgMgcoEvtSec_Enh_DtmfDtmf0Def  mgMgcoEvtSec_Ext_DtmfDtmf0Def

#define   mgMgcoEvtSec_Enh_DtmfDtmf1Def  mgMgcoEvtSec_Ext_DtmfDtmf1Def

#define   mgMgcoEvtSec_Enh_DtmfDtmf2Def  mgMgcoEvtSec_Ext_DtmfDtmf2Def

#define   mgMgcoEvtSec_Enh_DtmfDtmf3Def  mgMgcoEvtSec_Ext_DtmfDtmf3Def

#define   mgMgcoEvtSec_Enh_DtmfDtmf4Def  mgMgcoEvtSec_Ext_DtmfDtmf4Def

#define   mgMgcoEvtSec_Enh_DtmfDtmf5Def  mgMgcoEvtSec_Ext_DtmfDtmf5Def

#define   mgMgcoEvtSec_Enh_DtmfDtmf6Def  mgMgcoEvtSec_Ext_DtmfDtmf6Def

#define   mgMgcoEvtSec_Enh_DtmfDtmf7Def  mgMgcoEvtSec_Ext_DtmfDtmf7Def

#define   mgMgcoEvtSec_Enh_DtmfDtmf8Def  mgMgcoEvtSec_Ext_DtmfDtmf8Def

#define   mgMgcoEvtSec_Enh_DtmfDtmf9Def  mgMgcoEvtSec_Ext_DtmfDtmf9Def

#define   mgMgcoEvtSec_Enh_DtmfDtmfaDef  mgMgcoEvtSec_Ext_DtmfDtmfaDef

#define   mgMgcoEvtSec_Enh_DtmfDtmfbDef  mgMgcoEvtSec_Ext_DtmfDtmfbDef

#define   mgMgcoEvtSec_Enh_DtmfDtmfcDef  mgMgcoEvtSec_Ext_DtmfDtmfcDef

#define   mgMgcoEvtSec_Enh_DtmfDtmfdDef  mgMgcoEvtSec_Ext_DtmfDtmfdDef

#define   mgMgcoEvtSec_Enh_DtmfDtmfsDef  mgMgcoEvtSec_Ext_DtmfDtmfsDef

#define   mgMgcoEvtSec_Enh_DtmfDtmfoDef  mgMgcoEvtSec_Ext_DtmfDtmfoDef

#define   mgMgcoEvSpec_Enh_DtmfStdDef  mgMgcoEvSpec_Ext_DtmfStdDef

#define   mgMgcoEvSpec_Enh_DtmfEtdDef  mgMgcoEvSpec_Ext_DtmfEtdDef

#define   mgMgcoEvSpec_Enh_DtmfLtdDef  mgMgcoEvSpec_Ext_DtmfLtdDef

#define   mgMgcoEvSpec_Enh_DtmfCeDef  mgMgcoEvSpec_Ext_DtmfCeDef

#define   mgMgcoEvSpec_Enh_Dtmf_Ext_CeDef  mgMgcoEvSpec_Ext_Dtmf_Ext_CeDef

#define   mgMgcoEvSpec_Enh_DtmfDtmf0Def  mgMgcoEvSpec_Ext_DtmfDtmf0Def

#define   mgMgcoEvSpec_Enh_DtmfDtmf1Def  mgMgcoEvSpec_Ext_DtmfDtmf1Def

#define   mgMgcoEvSpec_Enh_DtmfDtmf2Def  mgMgcoEvSpec_Ext_DtmfDtmf2Def

#define   mgMgcoEvSpec_Enh_DtmfDtmf3Def  mgMgcoEvSpec_Ext_DtmfDtmf3Def

#define   mgMgcoEvSpec_Enh_DtmfDtmf4Def  mgMgcoEvSpec_Ext_DtmfDtmf4Def

#define   mgMgcoEvSpec_Enh_DtmfDtmf5Def  mgMgcoEvSpec_Ext_DtmfDtmf5Def

#define   mgMgcoEvSpec_Enh_DtmfDtmf6Def  mgMgcoEvSpec_Ext_DtmfDtmf6Def

#define   mgMgcoEvSpec_Enh_DtmfDtmf7Def  mgMgcoEvSpec_Ext_DtmfDtmf7Def

#define   mgMgcoEvSpec_Enh_DtmfDtmf8Def  mgMgcoEvSpec_Ext_DtmfDtmf8Def

#define   mgMgcoEvSpec_Enh_DtmfDtmf9Def  mgMgcoEvSpec_Ext_DtmfDtmf9Def

#define   mgMgcoEvSpec_Enh_DtmfDtmfaDef  mgMgcoEvSpec_Ext_DtmfDtmfaDef

#define   mgMgcoEvSpec_Enh_DtmfDtmfbDef  mgMgcoEvSpec_Ext_DtmfDtmfbDef

#define   mgMgcoEvSpec_Enh_DtmfDtmfcDef  mgMgcoEvSpec_Ext_DtmfDtmfcDef

#define   mgMgcoEvSpec_Enh_DtmfDtmfdDef  mgMgcoEvSpec_Ext_DtmfDtmfdDef

#define   mgMgcoEvSpec_Enh_DtmfDtmfsDef  mgMgcoEvSpec_Ext_DtmfDtmfsDef

#define   mgMgcoEvSpec_Enh_DtmfDtmfoDef  mgMgcoEvSpec_Ext_DtmfDtmfoDef

#endif /* GCP_PKG_MGCO_ENH_DTMF */

/*
 * [TEL3]: MSF UK Call Progess Tones Generator package code added
 */
#ifdef GCP_PKG_MGCO_MSF_UK_CG

#define MGT_PKG_ENUM_SIGNAL_MSF_UK_CG_DIAL 1
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_CG_RING 2
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_CG_BUSY 3
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_CG_EQ_ENGD 4
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_CG_NO_UNOBT 5
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_CG_HOWL 6
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_CG_SPL 7
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_CG_MSG_WG 8

#endif /* GCP_PKG_MGCO_MSF_UK_CG */

/*
 * [TEL3]: MSF UK Announcement package code added
 */
#ifdef GCP_PKG_MGCO_MSF_UK_AN

#define MGT_PKG_ENUM_SIGNAL_MSF_UK_AN_UN_REC 1
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_AN_FAULT 2
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_AN_NUM_OO 3
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_AN_NO_REP 4
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_AN_LN_BUSY 5
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_AN_NUM_UN 6
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_AN_OTH_PARTY 7
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_AN_CALL_NO 8
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_AN_CALL_GAP 9
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_AN_IC_BAR 10

#endif /* GCP_PKG_MGCO_MSF_UK_AN */

/*
 * [TEL3]: MSF UK Analogue Line package code added
 */
#ifdef GCP_PKG_MGCO_MSF_UK_ALG

#define MGT_PKG_ENUM_OBSEVTOTHER_MSF_UK_ALGSTEDSIGSIGBCONNEARTH 0
#define MGT_PKG_ENUM_OBSEVTOTHER_MSF_UK_ALGSTEDSIGSIGNORMPOL 1
#define MGT_PKG_ENUM_OBSEVTOTHER_MSF_UK_ALGSTEDSIGSIGREVPOL 2
#define MGT_PKG_ENUM_OBSEVTOTHER_MSF_UK_ALGSTEDSIGSIGNOBAT 3
#define MGT_PKG_ENUM_OBSEVTOTHER_MSF_UK_ALGSTEDSIGSIG 1
#define MGT_PKG_ENUM_REQEVT_MSF_UK_ALGONHOOK 4
#define MGT_PKG_ENUM_REQEVT_MSF_UK_ALGOFFHOOK 5
#define MGT_PKG_ENUM_REQEVT_MSF_UK_ALGFLASHHOOK 6
#define MGT_PKG_ENUM_REQEVT_MSF_UK_ALGSTEDSIG 7

#define   mgMgcoReqEvt_Msf_Uk_AlgOnHookDef  mgMgcoReqEvtAnalogOnHookDef

#define   mgMgcoReqEvt_Msf_Uk_AlgOffHookDef  mgMgcoReqEvtAnalogOffHookDef

#define   mgMgcoReqEvt_Msf_Uk_AlgFlashHookDef  mgMgcoReqEvtAnalogFlashHookDef

#define   mgMgcoEvtSec_Msf_Uk_AlgOnHookDef  mgMgcoEvtSecAnalogOnHookDef

#define   mgMgcoEvtSec_Msf_Uk_AlgOffHookDef  mgMgcoEvtSecAnalogOffHookDef

#define   mgMgcoEvtSec_Msf_Uk_AlgFlashHookDef  mgMgcoEvtSecAnalogFlashHookDef

#define   mgMgcoEvSpec_Msf_Uk_AlgOnHookDef  mgMgcoEvSpecAnalogOnHookDef

#define   mgMgcoEvSpec_Msf_Uk_AlgOffHookDef  mgMgcoEvSpecAnalogOffHookDef

#define   mgMgcoEvSpec_Msf_Uk_AlgFlashHookDef  mgMgcoEvSpecAnalogFlashHookDef
#define MGT_PKG_ENUM_SIGOTHER_MSF_UK_ALGPULSEDSIGSIGPULNOBAT 0
#define MGT_PKG_ENUM_SIGOTHER_MSF_UK_ALGPULSEDSIGSIGPULREDBAT 1
#define MGT_PKG_ENUM_SIGOTHER_MSF_UK_ALGPULSEDSIGSIGPULONHOOK 2
#define MGT_PKG_ENUM_SIGOTHER_MSF_UK_ALGPULSEDSIGSIG 1
#define MGT_PKG_ENUM_SIGOTHER_MSF_UK_ALGSTEDSIGSIGNALNORMPOL 0
#define MGT_PKG_ENUM_SIGOTHER_MSF_UK_ALGSTEDSIGSIGNALREVPOL 1
#define MGT_PKG_ENUM_SIGOTHER_MSF_UK_ALGSTEDSIGSIGNALREDBAT 2
#define MGT_PKG_ENUM_SIGOTHER_MSF_UK_ALGSTEDSIGSIGNALOFFHOOK 3
#define MGT_PKG_ENUM_SIGOTHER_MSF_UK_ALGSTEDSIGSIGNAL 1
#define MGT_PKG_ENUM_SIGOTHER_MSF_UK_ALGDIGITSDIGITS 1
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_ALGRING 2
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_ALGPULSEDSIG 3
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_ALGSTEDSIG 4
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_ALGDIGITS 5
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_ALGCALLFIN 6

#define   mgMgcoSignal_Msf_Uk_AlgRingDef  mgMgcoSignalAnalogRingDef

/* mg004.105: Code added to avoid undefined reference */
#define  mgMgcoReqEvtAnalogOffHookDef  mgMgcoReqEvtAnalogOnHookDef

#endif /* GCP_PKG_MGCO_MSF_UK_ALG */

/*
 * [TEL3]: MSF UK Automatic Metering package code added
 */
#ifdef GCP_PKG_MGCO_MSF_UK_AUTOMET

#define MGT_PKG_ENUM_OBSEVTOTHER_MSF_UK_AUTOMET_MET_REP_REP_TYPE_MET_CONT 0
#define MGT_PKG_ENUM_OBSEVTOTHER_MSF_UK_AUTOMET_MET_REP_REP_TYPE_MET_END 1
#define MGT_PKG_ENUM_REQEVTOTHER_MSF_UK_AUTOMET_MET_REP_REP_PUL_CT 1
#define MGT_PKG_ENUM_OBSEVTOTHER_MSF_UK_AUTOMET_MET_REP_PUL_CT 2
#define MGT_PKG_ENUM_OBSEVTOTHER_MSF_UK_AUTOMET_MET_REP_REP_TYPE 3
#define MGT_PKG_ENUM_REQEVT_MSF_UK_AUTOMET_MET_REP 1
#define MGT_PKG_ENUM_SIGOTHER_MSF_UK_AUTOMET_EN_MET_PUL_INT 1
#define MGT_PKG_ENUM_SIGOTHER_MSF_UK_AUTOMET_EN_MET_REP_IND 2
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_AUTOMET_EN_MET 1
#define MGT_PKG_ENUM_SIGNAL_MSF_UK_AUTOMET_DIS_MET 2

#endif /* GCP_PKG_MGCO_MSF_UK_AUTOMET */

/*
 * [TEL3]: Stimulus Lines Analogue Package code added
 */
#ifdef GCP_PKG_MGCO_STIM_AL

#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGNORMPOL 0
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGREVPOL 1
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGBATTONCWIRE 2
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGNOBATTONCWIRE 3
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGOFFHOOK 4
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGONHOOK 5
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGBATTONAWIRE 6
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGAWIREONEARTH 7
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGNOBATTONAWIRE 8
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGNOBATTONBWIRE 9
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGREDBATT 10
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGNOBATT 11
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGALTREDPOWER 12
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGNORMBATT 13
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGSTOPRINGING 14
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGSTARTPILOTFREQ 15
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGSTOPPILOTFREQ 16
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGLOWIMPEDBWIRE 17
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGBWIRECONNEARTH 18
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGBWIREDISCONNEARTH 19
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGBATTONBWIRE 20
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGLOWLOOPIMPED 21
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGHIGHLOOPIMPED 22
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGANOMLOOPIMPED 23
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGAWIREDISCONNEARTH 24
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGCWIREONEARTH 25
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGCWIREDISCONNEARTH 26
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGRAMPREVPOL 29
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIGRAMPNORMPOL 30
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGNORMPOL 0
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGREVPOL 1
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGBATTONCWIRE 2
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGNOBATTONCWIRE 3
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGOFFHOOK 4
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGONHOOK 5
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGBATTONAWIRE 6
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGAWIREONEARTH 7
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGNOBATTONAWIRE 8
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGNOBATTONBWIRE 9
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGREDBATT 10
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGNOBATT 11
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGALTREDPOWER 12
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGNORMBATT 13
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGSTOPRINGING 14
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGSTARTPILOTFREQ 15
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGSTOPPILOTFREQ 16
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGLOWIMPEDBWIRE 17
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGBWIRECONNEARTH 18
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGBWIREDISCONNEARTH 19
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGBATTONBWIRE 20
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGLOWLOOPIMPED 21
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGHIGHLOOPIMPED 22
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGANOMLOOPIMPED 23
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGAWIREDISCONNEARTH 24
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGCWIREONEARTH 25
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGCWIREDISCONNEARTH 26
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGRAMPREVPOL 29
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIGRAMPNORMPOL 30
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_DETECT_SIG 1
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_STED_SIG_RECOG_TIME 2
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_STED_SIG_SIG 1
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_LINE_INFO_INFOIMPEDMARKERRESET 0
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_LINE_INFO_INFOIMPEDMARKERSET 1
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_LINE_INFO_INFOLOWLOOPIMPED 2
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_LINE_INFO_INFOANOMLOOPIMPED 3
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_LINE_INFO_INFOANOMLINECOND 4
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_LINE_INFO_INFO 1
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULBWIREDISCONN 107
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULAWIREDISCONN 108
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULNORMBATT 109
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULCWIREDISCONN 110
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULCWIRECONNEARTH 111
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULAWIRECONNBATT 112
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULAWIRECONNEARTH 113
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULBWIRECONNBATT 114
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGEARTHLOOPPUL 115
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULBWIRECONNEARTH 116
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULOFFHOOK 117
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGREGRECALL 118
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIG50HZPUL 119
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGMETERPUL 120
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGINITRING 121
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULNOBATT 122
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULREDBATT 123
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULONHOOK 124
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULBATTONCWIRE 125
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULREVPOL 126
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIGPULNORMPOL 127
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULBWIREDISCONN 107
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULAWIREDISCONN 108
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULNORMBATT 109
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULCWIREDISCONN 110
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULCWIRECONNEARTH 111
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULAWIRECONNBATT 112
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULAWIRECONNEARTH 113
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULBWIRECONNBATT 114
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGEARTHLOOPPUL 115
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULBWIRECONNEARTH 116
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULOFFHOOK 117
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGREGRECALL 118
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIG50HZPUL 119
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGMETERPUL 120
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGINITRING 121
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULNOBATT 122
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULREDBATT 123
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULONHOOK 124
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULBATTONCWIRE 125
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULREVPOL 126
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIGPULNORMPOL 127
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_DETECT_SIG 1
#define MGT_PKG_ENUM_REQEVTOTHER_STIM_AL_PULSED_SIG_RECOG_TIME 2
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_PULSED_SIG_SIG 1
#define MGT_PKG_ENUM_OBSEVTOTHER_STIM_AL_AUTO_SIG_SEQ_RESP_SEQ_RESP_TYPE 1
#define MGT_PKG_ENUM_REQEVT_STIM_AL_STED_SIG 1
#define MGT_PKG_ENUM_REQEVT_STIM_AL_LINE_INFO 2
#define MGT_PKG_ENUM_REQEVT_STIM_AL_PULSED_SIG 3
#define MGT_PKG_ENUM_REQEVT_STIM_AL_AUTO_SIG_SEQ_RESP 4
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULBWIREDISCONN 107
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULAWIREDISCONN 108
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULNORMBATT 109
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULCWIREDISCONN 110
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULCWIRECONNEARTH 111
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULAWIRECONNBATT 112
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULAWIRECONNEARTH 113
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULBWIRECONNBATT 114
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGEARTHLOOPPUL 115
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULBWIRECONNEARTH 116
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULOFFHOOK 117
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGREGRECALL 118
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIG50HZPUL 119
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGMETERPUL 120
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGINITRING 121
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULNOBATT 122
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULREDBATT 123
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULONHOOK 124
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULBATTONCWIRE 125
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULREVPOL 126
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIGPULNORMPOL 127
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_SIG 1
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_PULSED_SIG_NUM_OF_PULSES 2
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALNORMPOL 0
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALREVPOL 1
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALBATTONCWIRE 2
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALNOBATTONCWIRE 3
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALOFFHOOK 4
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALONHOOK 5
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALBATTONAWIRE 6
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALAWIREONEARTH 7
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALNOBATTONAWIRE 8
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALNOBATTONBWIRE 9
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALREDBATT 10
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALNOBATT 11
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALALTREDPOWER 12
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALNORMBATT 13
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALSTOPRINGING 14
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALSTARTPILOTFREQ 15
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALSTOPPILOTFREQ 16
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALLOWIMPEDBWIRE 17
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALBWIRECONNEARTH 18
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALBWIREDISCONNEARTH 19
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALBATTONBWIRE 20
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALLOWLOOPIMPED 21
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALHIGHLOOPIMPED 22
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALANOMLOOPIMPED 23
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALAWIREDISCONNEARTH 24
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALCWIREONEARTH 25
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALCWIREDISCONNEARTH 26
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALRAMPREVPOL 29
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNALRAMPNORMPOL 30
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_STED_SIGSIGNAL 1
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_DIGITS_DIGITS 1
#define MGT_PKG_ENUM_SIGOTHER_STIM_AL_AUTO_SIG_SEQ_SEQ_TYPE 1
#define MGT_PKG_ENUM_SIGNAL_STIM_AL_PULSED_SIG 1
#define MGT_PKG_ENUM_SIGNAL_STIM_AL_STED_SIG 2
#define MGT_PKG_ENUM_SIGNAL_STIM_AL_DIGITS 3
#define MGT_PKG_ENUM_SIGNAL_STIM_AL_AUTO_SIG_SEQ 4
#define MGT_PKG_ENUM_SIGNAL_STIM_AL_CALL_FIN 5

#endif /* GCP_PKG_MGCO_STIM_AL */

#endif /* GCP_MGCO */

#endif /*__MGCOPDB3H__*/

/********************************************************************30**

         End of file:     mgcopdb3.h@@/main/1 - Wed Mar 30 08:13:45 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---     TEL2 Hash defines included for the following megaco 
                          packages:
                          1. Media Gateway Overload Control package 
                          2. Floor Control package
                          3. Indication of being viewed package
                          4. Volume Control package
                          5. Volume Detection package
                          6. Volume Level Mixing package
                          7. Voice Activated Video Switch package
                          8. Lecture Video Mode package
                          9. Contributing Video Source package
                          10. Profile package
                          11. Semi-permanent connection package
                          12. Video Window package
                          13. Tiled Window package
                          14. Enhanced Alerting package
                          15. Shared Risk Group package
                          16. Mixing Volume Level Control package
                          17. CAS Blocking package
                          18. Conferencing Tones Generation package
                          19. Diagnostic Tones Generation package
                          20. Carrier Tones Generation package
                          21. Analog Display Signalling package
                          22. Extended Analog Line Supervision package
                          23. Automatic Metering package
                          24. H.324 package
                          25. H.245 Command package
                          26. H.245 Indication package
                          27. Extended H.245 Command package
                          28. Extended H.245 Indication package
                          29. Quality Alert Ceasing package
                          30. Extended H.324 package
                          31. Adaptive Jitter Buffer package
                          32. International CAS package
                          33. Multi-Frequency Tone Generation package
                          34. Multi-Frequency Tone Detection package
                          35. Extended DTMF Detection package
                          36. Enhanced DTMF Detection package
/main/1      ---     TEL2 Hash defines included for the following megaco 
                          packages:
                           1. MSF UK Call Progess Tones Generator package
                           2. MSF UK Announcement package
                           3. MSF UK Analogue Line package
                           4. MSF UK Automatic Metering package
/main/1      ---       ka 1. Changes for Release v 1.5
/main/1      ---      pk   1. GCP 1.5 release
          mg003.105   ps   1. Stimulus Lines Analogue Package added 
          mg004.105   gk   1. Code added to avoid undefined reference
*********************************************************************91*/
