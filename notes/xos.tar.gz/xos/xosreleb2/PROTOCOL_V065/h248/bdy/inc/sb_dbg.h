/* ***************************************************************************
 *        (c) COPYRIGHT 1995-2006 by Xinwei, Inc.
 *                   All rights reserved.
 *
 * sctp_dbg.h:  
 *          this head file include macro define of debug.
 *           
 * Author:
 *          zhouguishuang
 * Date:
 *          2006-5-8
 * Last Modified:
 *
 ****************************************************************************/
#ifndef __SB_DBGH__
#define __SB_DBGH__

#define     SCTP_PRINT_LAYER_INFO   0x0001   /* print sctp layer info */
#define     SCTP_PRINT_INIT_INFO    0x0002   /* print sctp initialize info */
#define     SCTP_PRINT_ASSOC_INFO   0x0004   /* print sctp associations info */
#define     SCTP_PRINT_ENDP_INFO    0x0008   /* print sctp endpoint info */
#define     SCTP_PRINT_SCTSAP_INFO  0x0010   /* print sctp SCTSAP info */
#define     SCTP_PRINT_TSAP_INFO    0x0020   /* print sctp TSAP info */
#define     SCTP_PRINT_GENCFG_INFO  0x0040   /* print sctp general info */

#define     SCTP_PRINT_ALL_INFO     0x0080   /* print sctp endpoint info */
#define     SCTP_PRINT_CONFIG_INFO     0x0100   /* print sctp general config info */
#define     SCTP_PRINT_STATS_INFO     0x0200   /* print sctp stat. info */

PUBLIC S16 sctp_sys_init_fun(void);
PUBLIC S16 sb_init_fun(void);
PUBLIC S16 sb_close_fun(void);
PUBLIC S16 sb_message_fun(void);
PUBLIC S16 sb_timer_fun(void);
void sctp_config_gen(void);
void sctp_config_sctsap(void);
void sctp_config_tsap(void);

void  sbCfgBndtucl(void);
/*void  sbBndHiReq(SuId suId);*/

#endif /* __SB_DBGH__ */