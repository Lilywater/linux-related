/**********************************************************************

    Name:   mg_nms.h 

    Type:   C include file

    Desc:   

    File:   mg_nms.h

    Sid:    

    Created by: 

**********************************************************************/


#ifndef _MG_NMS_H_
#define _MG_NMS_H_
#include "oam_interface.h"

#ifdef __cplusplus
extern "C" {
#endif
/*--------------------------------------------------------*/

/*--------------------------------------------------------*/
extern void TestPrintGen();
extern int mgTestPrint();
extern S16 mgRecvInitCfg(tb_record* prow);
/*extern void mgInitCfgData();*/
extern S16 mCfgMsg();
extern unsigned char mgNmSyncCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow);

#ifdef __cplusplus
}
#endif



#endif

