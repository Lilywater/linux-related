/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     ASN.1 database
  
     Type:     C Source file
  
     Desc:     C source code for Mg ans.1
  
     File:     mgca_db.h
  
     Sid:      mgasndb1.h@@/main/1 - Wed Mar 30 08:08:05 2005
  
     Prg:      
  
*********************************************************************21*/


/************************************************************************
 

************************************************************************/
 
#ifndef __MGASNDB1H__
#define __MGASNDB1H__

#ifdef GCP_ASN
/* Tune to your taste */
#define MGAMAX_Transactions      MGT_MAX_TXNS
#define MGAMAX_Actions         MGT_MAX_ACTIONREQS
#define MGAMAX_TopologyReq      MGT_MAX_TOPODESCS
#define MGAMAX_Wildcard         100
#define MGAMAX_CommandRequests      MGT_MAX_CMDREQS
#define MGAMAX_TerminationIDList   MGT_MAX_TERMS
#define MGAMAX_Descriptors      MGT_MAX_TOPODESCS
#define MGAMAX_PropertyParms      MGT_MAX_PROPPARMS
#define MGAMAX_PropParmValue      MGT_MAX_VALUES
#define MGAMAX_PropGrps         MGT_MAX_PROPPARMS
#define MGAMAX_PropertyGroup      MGT_MAX_PROPPARMS
#define MGAMAX_MultiStream      100
#define MGAMAX_Mtl         MGT_MAX_MODEMTYPES
#define MGAMAX_Mpl         MGT_MAX_PROPPARMS
#define MGAMAX_TermList         MGT_MAX_TERMS
#define MGAMAX_EventList      MGT_MAX_EVTS
#define MGAMAX_SecondEventList      MGT_MAX_EVTSECS
#define MGAMAX_SignalsDescriptor   MGT_MAX_SIGDESCPARMS
#define MGAMAX_SigParList      MGT_MAX_SIGPARS
#define MGAMAX_Value         MGT_MAX_VALUES
#define MGAMAX_SignalList      MGT_MAX_SIGREQS
#define MGAMAX_EvParList      MGT_MAX_EVTPARMS
#define MGAMAX_EventBufferDescriptor   MGT_MAX_EVTS
#define MGAMAX_EventParList      MGT_MAX_EVTPARMS
#define MGAMAX_ObservedEventLst      MGT_MAX_OBSEVTS
#define MGAMAX_ActionReplies      MGT_MAX_ACTIONREPLYS
#define MGAMAX_CommandReplyList      MGT_MAX_CMDREPLYS
#define MGAMAX_TerminationAudit      MGT_MAX_AUDS
#define MGAMAX_StatisticsDescriptor   MGT_MAX_STATSPARS
#define MGAMAX_Value         MGT_MAX_VALUES
#define MGAMAX_PackagesDescriptor   MGT_MAX_PKGSITEMS
#define MGAMAX_TransactionResponseAck   MGT_MAX_TXNACKS
#define MGAMAX_PropertyParmsIndAud   MGT_MAX_PROPPARMS
#define MGAMAX_IndAudPropertyGroup   MGT_MAX_PROPPARMS
#define MGAMAX_MultiStreamIndAud    MGT_MAX_AUDS
#define MGAMAX_IndAuditParameters    MGT_MAX_AUDRETPARMS

#define MG_ASN_ELMNID_MEGACO_BASE 25000 /* start of unique idNums */
#define MG_ASN_ELMNID_MEGACO_PKG_BASE 27000 /* start of pkg idNums */


/* SDP */
#define VALUE_SDP_V      0x01
#define VALUE_SDP_O      0x02
#define VALUE_SDP_S      0x03
#define VALUE_SDP_I      0x04
#define VALUE_SDP_U      0x05
#define VALUE_SDP_E      0x06
#define VALUE_SDP_P      0x07
#define VALUE_SDP_C      0x08
#define VALUE_SDP_B      0x09
#define VALUE_SDP_Z      0x0A
#define VALUE_SDP_K      0x0B
#define VALUE_SDP_A      0x0C
#define VALUE_SDP_T      0x0D
#define VALUE_SDP_R      0x0E
#define VALUE_SDP_M      0x0F
#define VALUE_SDP_MAX      VALUE_SDP_M
#endif
#endif 
/********************************************************************30**
  
         End of file:     mgasndb1.h@@/main/1 - Wed Mar 30 08:08:05 2005
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**
 
 
*********************************************************************81*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      tlh  1. initial release.
/main/1      ---      pk   1. GCP 1.5 release
*********************************************************************91*/
