/**********************************************************************

    Name:   mgco_cfg.h - Debug print for the GCP

    Type:   C include file

    Desc:   #define and macros for the GCP layer Debug print

    File:   mgco_cfg.h

    Sid:    mgco_cfg.h - 2006/04/04

    Created by: changdawei

**********************************************************************/
#if 0
#ifndef _MGCO_CFG_H_
#define _MGCO_CFG_H_
/*-------------------------include file(s)------------------------------*/
/*  #include "sysInsidePub.h" */
#include "clishell.h"

/*--------Extern Functions------------------------*/
#ifdef __cplusplus
extern "C" {
#endif

extern VOID mgcoPrintMgCb(CLI_ENV *pCliEnv);
extern VOID mgcoPrintSSAPCb(CLI_ENV *pCliEnv, S16 spId);
extern VOID mgcoPrintPeerLst(CLI_ENV *pCliEnv, S16 peerLstId);
extern VOID mgcoPrintTSAPCb(CLI_ENV *pCliEnv, S16 tsapId);
extern VOID mgcoPrintGenCfg(CLI_ENV *pCliEnv);

#ifdef __cplusplus
}
#endif

#endif /* _MGCO_CFG_H_ */
#endif
