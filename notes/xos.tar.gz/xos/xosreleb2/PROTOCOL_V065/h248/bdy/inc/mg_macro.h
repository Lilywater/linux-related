/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
 
     Name:     MGCP - MGC Module
 
     Type:     C code for initialisation transaction structure 
  
     Desc:     Defines Required by MGCP
 
     File:     mg_macro.h
  
     Sid:      mg_macro.h@@/main/5 - Wed Mar 30 07:52:04 2005
  
     Prg:      bbk
  
*********************************************************************21*/
  

/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*
*/
 
/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*    
*   
*
*/

#ifndef __MGMACROH__
#define __MGMACROH__

#ifdef MG
 
#define MG_ACC_GETMEM(_ptr, _len, _memCp)                                 \
{                                                                         \
   if (cmGetMem((_memCp), (_len), (Ptr *)&(_ptr)) != ROK)                 \
      RETVALUE(RFAILED);                                                  \
                                                                          \
   cmMemset((U8 *)(_ptr), (U8)0,  (PTR)(_len));                           \
}

#define MG_ACC_COPY_STRUCT(_to, _from, _size)                             \
{                                                                         \
   cmMemcpy((U8 *)(_to), (CONSTANT U8 *)(_from), (_size));                \
}

/* macro to initialise TknU8 , TknS16, TknU16, TknU32...etc.  */
#define MG_ACC_INIT_TOKEN_VALUE(_tkn, _val)                               \
{                                                                         \
   (_tkn)->pres = PRSNT_NODEF;                                            \
   (_tkn)->val  = (_val);                                                 \
}

#define MG_ACC_COMPARE_TOKEN_VALUE(_tkn1, _tkn2)                          \
{                                                                         \
   if ((_tkn1)->pres != (_tkn2)->pres)                                    \
      RETVALUE(RFAILED);                                                  \
                                                                          \
   if ((_tkn1)->pres != NOTPRSNT)                                         \
   {                                                                      \
      if ((_tkn1)->val != (_tkn2)->val)                                   \
         RETVALUE(RFAILED);                                               \
   }                                                                      \
}

#define MG_ACC_INIT_TKNSTROSXL(_tkn, _val, _len)                          \
{                                                                         \
   (_tkn)->pres = PRSNT_NODEF;                                            \
   (_tkn)->len  = (U16)(_len);                                            \
   (_tkn)->val  = (_val);                                                 \
}

#define MG_ACC_INIT_TKNSTR(_tkn, _val, _len)                              \
{                                                                         \
   (_tkn)->pres = PRSNT_NODEF;                                            \
   (_tkn)->len  = (U8)(_len);                                             \
   cmMemcpy((U8 *)(_tkn)->val, (CONSTANT U8 *)(_val), (_len));            \
}

#define MG_ACC_COMPARE_TKN_STRINGS(_tkn1, _tkn2)                          \
{                                                                         \
   if ((_tkn1)->pres != (_tkn2)->pres)                                    \
      RETVALUE(RFAILED);                                                  \
                                                                          \
   if ((_tkn1)->pres != NOTPRSNT)                                         \
   {                                                                      \
      if ((_tkn1)->len != (_tkn2)->len)                                   \
         RETVALUE(RFAILED);                                               \
                                                                          \
      if ((_tkn1)->len > 0)                                               \
      {                                                                   \
         if ((cmMemcmp((U8 *)((_tkn1)->val), (CONSTANT U8 *)((_tkn2)->val),\
                       (_tkn1)->len)) != 0)                               \
         {                                                                \
            RETVALUE(RFAILED);                                            \
         }                                                                \
      }                                                                   \
   }                                                                      \
}

#define MG_ACC_INIT_TOKEN_BUF(_tkn, _mBuf)                                \
{                                                                         \
   (_tkn)->pres = PRSNT_NODEF;                                            \
   (_tkn)->val  = (_mBuf);                                                \
}

#define MG_ACC_FILL_UPTO_CMDLINE(_msgType, _msg, _cmd, _lclName, _dname,  \
                                 _trId)                                   \
{                                                                         \
   MgMgcpCmdLine *_cmdLine;                                               \
   MgMgcpVer     *_version;                                               \
   U8            *_profName = (U8 *)("NCS");                              \
   U8            _len = 0;                                                \
                                                                          \
   _cmdLine = &((_cmd)->cmdLine);                                         \
   _version = &(_cmdLine->mgcpVer);                                       \
                                                                          \
   /* msgType */                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&(_msg->msgType), (_msgType));                 \
                                                                          \
   /* cmd->pres */                                                        \
   MG_ACC_INIT_TOKEN_VALUE(&((_cmd)->pres), 1);                           \
                                                                          \
   /* cmdLine->pres */                                                    \
   MG_ACC_INIT_TOKEN_VALUE(&(_cmdLine->pres), 1);                         \
                                                                          \
   /* fill Transaction Id */                                              \
   MG_ACC_INIT_TOKEN_VALUE (&(_cmdLine->trId), (_trId));                  \
                                                                          \
   if ((_lclName) != NULLP)                                               \
      _len  = (U8)cmStrlen((CONSTANT U8 *)(_lclName));                    \
                                                                          \
   if (_len > 0)                                                          \
   {                                                                      \
      if (cmGetMem(&((_msg)->memCp), _len,                                \
                  (Ptr *)&((_cmdLine)->epName.lclName.val)) != ROK)       \
      {                                                                   \
         RETVALUE(RFAILED);                                               \
      }                                                                   \
      cmMemset((U8 *)((_cmdLine)->epName.lclName.val),                     \
               (U8)0,  (PTR)(_len));                                      \
                                                                          \
      _cmdLine->epName.pres.pres = PRSNT_NODEF;                           \
      /* localName->pres */                                               \
      _cmdLine->epName.lclName.pres = PRSNT_NODEF;                        \
                                                                          \
      /* local name length */                                             \
      _cmdLine->epName.lclName.len = _len;                                \
                                                                          \
      /* copy local name */                                               \
      cmMemcpy((U8 *)(_cmdLine->epName.lclName.val),                      \
               (CONSTANT U8 *)(_lclName), _len);                          \
                                                                          \
      _len = 0;                                                           \
   }                                                                      \
                                                                          \
                                                                          \
   if ((_dname) != NULLP)                                                 \
      _len = (U8)cmStrlen((CONSTANT U8 *)(_dname));                       \
                                                                          \
   if (_len > 0)                                                          \
   {                                                                      \
      if (cmGetMem(&((_msg)->memCp), _len,                                \
                  (Ptr *)&((_cmdLine)->epName.domainName.val)) != ROK)    \
      {                                                                   \
         RETVALUE(RFAILED);                                               \
      }                                                                   \
      cmMemset((U8 *)((_cmdLine)->epName.domainName.val),                 \
               (U8)0,  (PTR)(_len));                                      \
                                                                          \
      _cmdLine->epName.pres.pres = PRSNT_NODEF;                           \
      /* domainName->pres */                                              \
      _cmdLine->epName.domainName.pres = PRSNT_NODEF;                     \
                                                                          \
      /* domain name length */                                            \
      _cmdLine->epName.domainName.len = _len;                             \
                                                                          \
      /* copy domain name */                                              \
      cmMemcpy((U8 *)(_cmdLine->epName.domainName.val),                   \
               (CONSTANT U8 *)(_dname), _len);                            \
                                                                          \
      _len = 0;                                                           \
   }                                                                      \
                                                                          \
   /* version->pres */                                                    \
   MG_ACC_INIT_TOKEN_VALUE(&(_version->pres), 1);                         \
                                                                          \
   /* version->major */                                                   \
   MG_ACC_INIT_TOKEN_VALUE(&(_version->major), 1);                        \
                                                                          \
   /* version->minor */                                                   \
   MG_ACC_INIT_TOKEN_VALUE(&(_version->minor), 0);                        \
                                                                          \
   /* version->profName */                                                \
                                                                          \
   if (_profName != NULLP)                                                \
      _len  = (U8)cmStrlen((CONSTANT U8 *)_profName);                     \
                                                                          \
   if (_len > 0)                                                          \
   {                                                                      \
      if (cmGetMem(&((_msg)->memCp), _len,                                \
                  (Ptr *)&((_version)->profName.val)) != ROK)             \
      {                                                                   \
         RETVALUE(RFAILED);                                               \
      }                                                                   \
                                                                          \
      cmMemset((U8 *)((_version)->profName.val),                          \
               (U8)0,  (PTR)(_len));                                      \
      /* version->profName.len */                                         \
      _version->profName.len = _len;                                      \
                                                                          \
      /* version->profName.val */                                         \
      cmMemcpy((U8 *)(_version->profName.val), (CONSTANT U8 *) _profName, \
               _len);                                                     \
   }                                                                      \
}

#define MG_ACC_INIT_PARAM_SET(_numParam, _msg, _paramSet)                 \
{                                                                         \
   U8          _idx;                                                      \
   Size        _memSize = (_numParam) * (sizeof(MgMgcpParam *));          \
                                                                          \
   if (cmGetMem(&((_msg)->memCp), _memSize,                               \
                (Ptr *) &((_paramSet)->param)) != ROK)                    \
   {                                                                      \
      RETVALUE(RFAILED);                                                  \
   }                                                                      \
   cmMemset((U8 *)((_paramSet)->param),  (U8)0,  (PTR)(_memSize));        \
                                                                          \
   (_paramSet)->numParam.pres = PRSNT_NODEF;                              \
   (_paramSet)->numParam.val  = 0;                                        \
                                                                          \
   for (_idx = 0; _idx < (_numParam); _idx++)                             \
   {                                                                      \
      *(((_paramSet)->param) + _idx) = NULLP;                             \
                                                                          \
      if (cmGetMem(&((_msg)->memCp), sizeof(MgMgcpParam),                 \
                   (Ptr *)&((_paramSet)->param[_idx])) != ROK)            \
      {                                                                   \
         RETVALUE(RFAILED);                                               \
      }                                                                   \
                                                                          \
      cmMemset((U8 *)((_paramSet)->param[_idx]),                          \
               (U8)0,  (PTR)(sizeof(MgMgcpParam)));                       \
      (_paramSet)->numParam.val++;                                        \
   }                                                                      \
}

#define MG_ACC_INIT_RSPACK_SET(_numComp, _msg, _rspAckSet)                \
{                                                                         \
   U16 i;                                                                 \
   if ((_rspAckSet)->numComp.pres == NOTPRSNT)                            \
   {                                                                      \
      (_rspAckSet)->numComp.pres = PRSNT_NODEF;                           \
      (_rspAckSet)->numComp.val  = 0;                                     \
   }                                                                      \
   MG_ACC_GETMEM((_rspAckSet)->rspAck, ((_numComp) * sizeof(MgRspAck *)), \
      &((_msg)->memCp));                                                  \
   for (i = 0; i < (_numComp); i++)                                       \
   {                                                                      \
      (_rspAckSet)->rspAck[i] = NULLP;                                    \
      MG_ACC_GETMEM(((_rspAckSet)->rspAck[i]), sizeof(MgRspAck),          \
         &((_msg)->memCp));                                               \
   }                                                                      \
}

#define MG_ACC_FILL_RSPACK_SET(_param, _lowBnd, _highBnd)                 \
{                                                                         \
   MgRspAckSet *_rspAckSet;                                               \
   MgRspAck    *_rspAck;                                                  \
                                                                          \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_RSPACK;                           \
                                                                          \
   _rspAckSet = &((_param)->t.rspAckSet);                                 \
                                                                          \
   if (_rspAckSet->numComp.pres == NOTPRSNT)                              \
   {                                                                      \
      _rspAckSet->numComp.pres = PRSNT_NODEF;                             \
      _rspAckSet->numComp.val  = 0;                                       \
   }                                                                      \
                                                                          \
   _rspAck = (_rspAckSet->rspAck[_rspAckSet->numComp.val++]);             \
                                                                          \
   _rspAck->pres.pres     = PRSNT_NODEF;                                  \
   _rspAck->lowBnd.pres   = PRSNT_NODEF;                                  \
   _rspAck->lowBnd.val    = _lowBnd;                                      \
   _rspAck->upperBnd.pres = PRSNT_NODEF;                                  \
   _rspAck->upperBnd.val  = _highBnd;                                     \
}

#define MG_ACC_INIT_BEARER_INFO(_numComp, _msg, _bearerInfo)              \
{                                                                         \
   U16 i;                                                                 \
   if ((_bearerInfo)->numComp.pres == NOTPRSNT)                           \
   {                                                                      \
      (_bearerInfo)->numComp.pres = PRSNT_NODEF;                          \
      (_bearerInfo)->numComp.val = 0;                                     \
   }                                                                      \
   MG_ACC_GETMEM((_bearerInfo)->bearerEnc, ((_numComp) * sizeof(TknU8 *)),\
      &((_msg)->memCp));                                                  \
   for (i = 0; i < (_numComp); i++)                                       \
   {                                                                      \
      (_bearerInfo)->bearerEnc[i] = NULLP;                                \
      MG_ACC_GETMEM(((_bearerInfo)->bearerEnc[i]), sizeof(TknU8),         \
         &((_msg)->memCp));                                               \
   }                                                                      \
}

#define MG_ACC_FILL_BEARER_INFO(_param, _value)                           \
{                                                                         \
   MgBearerInfo *_bearerInfo;                                             \
   TknU8        *_bearerEnt;                                              \
                                                                          \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_BEAR_INFO;                        \
                                                                          \
   _bearerInfo = &((_param)->t.bearerInfo);                               \
                                                                          \
   if (_bearerInfo->numComp.pres == NOTPRSNT)                             \
   {                                                                      \
      _bearerInfo->numComp.pres = PRSNT_NODEF;                            \
      _bearerInfo->numComp.val  = 0;                                      \
   }                                                                      \
                                                                          \
   _bearerEnt = (_bearerInfo->bearerEnc[_bearerInfo->numComp.val++]);     \
                                                                          \
   _bearerEnt->pres = PRSNT_NODEF;                                        \
   _bearerEnt->val  = _value;                                             \
}

#define MG_ACC_FILL_CALLID(_param, _len, _ptrVal)                         \
{                                                                         \
   MgCallId   *_callId;                                                   \
                                                                          \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_CALLID;                           \
                                                                          \
   _callId = &((_param)->t.callId);                                       \
                                                                          \
   _callId->pres = PRSNT_NODEF;                                           \
   _callId->len  = _len;                                                  \
                                                                          \
   cmMemcpy((U8 *)_callId->val, (CONSTANT U8 *)_ptrVal, _len);            \
}

#define MG_ACC_INIT_CONNID_SET(_numComp, _msg, _connIdSet)                \
{                                                                         \
   U16 i;                                                                 \
   if ((_connIdSet)->numComp.pres == NOTPRSNT)                            \
   {                                                                      \
      (_connIdSet)->numComp.pres = PRSNT_NODEF;                           \
      (_connIdSet)->numComp.val  = 0;                                     \
   }                                                                      \
   MG_ACC_GETMEM((_connIdSet)->connId, ((_numComp) * sizeof(MgConnId *)), \
      &((_msg)->memCp));                                                  \
   for (i = 0; i < (_numComp); i++)                                       \
   {                                                                      \
      (_connIdSet)->connId[i] = NULLP;                                    \
      MG_ACC_GETMEM(((_connIdSet)->connId[i]), sizeof(MgConnId),          \
         &((_msg)->memCp));                                               \
   }                                                                      \
}

#define MG_ACC_FILL_CONNID_SET(_param, _len, _ptrVal)                     \
{                                                                         \
   MgConnIdSet *_connIdSet;                                               \
   MgConnId    *_connId;                                                  \
                                                                          \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_CONNID;                           \
                                                                          \
   _connIdSet = &((_param)->t.connIdSet);                                 \
                                                                          \
   if (_connIdSet->numComp.pres == NOTPRSNT)                              \
   {                                                                      \
      _connIdSet->numComp.pres = PRSNT_NODEF;                             \
      _connIdSet->numComp.val  = 0;                                       \
   }                                                                      \
                                                                          \
   _connId = (_connIdSet->connId[_connIdSet->numComp.val++]);             \
                                                                          \
   MG_ACC_INIT_TKNSTR(_connId, _ptrVal, _len);                            \
}

#define MG_ACC_FILL_NOTIFIED_ENTITY(_param, _ptrLclName, _dname, _port)   \
{                                                                         \
   MgNtfiedEnt *_ntfyEnt;                                                 \
   U8          _len;                                                      \
                                                                          \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_NTFIED_ENT;                       \
                                                                          \
   _ntfyEnt = &((_param)->t.ntfiedEnt);                                   \
   _ntfyEnt->pres.pres      = PRSNT_NODEF;                                \
                                                                          \
   _len = (U8)cmStrlen((CONSTANT U8 *)(_ptrLclName));                     \
   MG_ACC_INIT_TKNSTR(&(_ntfyEnt->lclName), (_ptrLclName), _len);         \
                                                                          \
   _len = (U8)cmStrlen((CONSTANT U8 *)(_dname));                          \
   MG_ACC_INIT_TKNSTROSXL(&(_ntfyEnt->domainName), (_dname), _len);       \
                                                                          \
   _ntfyEnt->port.pres     = PRSNT_NODEF;                                 \
   _ntfyEnt->port.val      = (_port);                                     \
}

#define MG_ACC_FILL_RQSTID(_param, _ptrVal, _len)                         \
{                                                                         \
   MgRqstId    *_rqstId;                                                  \
                                                                          \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_RQSTID;                           \
                                                                          \
   _rqstId = &((_param)->t.rqstId);                                       \
   MG_ACC_INIT_TKNSTR(_rqstId, (_ptrVal), (_len));                        \
}

#define MG_ACC_INIT_LOCAL_CONN_OPTSET(_numComp, _msg, _optSet)            \
{                                                                         \
   U16 i;                                                                 \
   if ((_optSet)->numComp.pres == NOTPRSNT)                               \
   {                                                                      \
      (_optSet)->numComp.pres = PRSNT_NODEF;                              \
      (_optSet)->numComp.val = 0;                                         \
   }                                                                      \
   MG_ACC_GETMEM((_optSet)->lclConnOpt,                                   \
      ((_numComp) * sizeof(MgLclConnOpts *)), &((_msg)->memCp));          \
   for (i = 0; i < (_numComp); i++)                                       \
   {                                                                      \
      (_optSet)->lclConnOpt[i] = NULLP;                                   \
      MG_ACC_GETMEM(((_optSet)->lclConnOpt[i]), sizeof(MgLclConnOpts),    \
         &((_msg)->memCp));                                               \
   }                                                                      \
}

#define MG_ACC_INIT_LCL_CONNOPT_ALGO_NAME_SET(_numComp, _msg, _algoNameSet) \
{                                                                         \
   U16 i;                                                                 \
   if ((_algoNameSet)->numComp.pres == NOTPRSNT)                          \
   {                                                                      \
      (_algoNameSet)->numComp.pres = PRSNT_NODEF;                         \
      (_algoNameSet)->numComp.val = 0;                                    \
   }                                                                      \
   MG_ACC_GETMEM((_algoNameSet)->algoName, ((_numComp) * sizeof(TknStr32 *)), \
      &((_msg)->memCp));                                                  \
   for (i = 0; i < (_numComp); i++)                                       \
   {                                                                      \
      (_algoNameSet)->algoName[i] = NULLP;                                \
      MG_ACC_GETMEM(((_algoNameSet)->algoName[i]), sizeof(TknStr32),      \
         &((_msg)->memCp));                                               \
   }                                                                      \
}

#define MG_ACC_INIT_LCL_CONNOPT_SUPP_MODES(_numComp, _msg, _suppModes)    \
{                                                                         \
   U16 i;                                                                 \
   if ((_suppModes)->numComp.pres == NOTPRSNT)                            \
   {                                                                      \
      (_suppModes)->numComp.pres = PRSNT_NODEF;                           \
      (_suppModes)->numComp.val = 0;                                      \
   }                                                                      \
   MG_ACC_GETMEM((_suppModes)->mode, ((_numComp) * sizeof(TknU8 *)),      \
      &((_msg)->memCp));                                                  \
   for (i = 0; i < (_numComp); i++)                                       \
   {                                                                      \
      (_suppModes)->mode[i] = NULLP;                                      \
      MG_ACC_GETMEM(((_suppModes)->mode[i]), sizeof(TknU8),               \
         &((_msg)->memCp));                                               \
   }                                                                      \
}

#define MG_ACC_INIT_LCL_CONNOPT_SUPP_PKGS(_numComp, _msg, _suppPkgs)      \
{                                                                         \
   U16 i;                                                                 \
   if ((_suppPkgs)->numComp.pres == NOTPRSNT)                             \
   {                                                                      \
      (_suppPkgs)->numComp.pres = PRSNT_NODEF;                            \
      (_suppPkgs)->numComp.val = 0;                                       \
   }                                                                      \
   MG_ACC_GETMEM((_suppPkgs)->pkgName, ((_numComp) * sizeof(MgPkgName *)),\
      &((_msg)->memCp));                                                  \
   for (i = 0; i < (_numComp); i++)                                       \
   {                                                                      \
      (_suppPkgs)->pkgName[i] = NULLP;                                    \
      MG_ACC_GETMEM(((_suppPkgs)->pkgName[i]), sizeof(MgPkgName),         \
         &((_msg)->memCp));                                               \
   }                                                                      \
}


#define MG_ACC_FILL_LOCAL_CONN_OPT(_param, _optType, _optVal)             \
{                                                                         \
   MgLclConnOpts       *_opt;                                             \
   MgLclConnOptSet     *_optSet;                                          \
                                                                          \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_LCL_CONNOPTS;                     \
                                                                          \
   _optSet = &((_param)->t.lclConnOptSet);                                \
                                                                          \
   if (_optSet->numComp.pres == NOTPRSNT)                                 \
   {                                                                      \
      _optSet->numComp.pres = PRSNT_NODEF;                                \
      _optSet->numComp.val  = 0;                                          \
   }                                                                      \
                                                                          \
   _opt = &(_optSet->lclConnOpt[_optSet->numComp.val++]);                 \
                                                                          \
   _opt->valType.pres = PRSNT_NODEF;                                      \
   _opt->valType.val  = (_optType);                                       \
                                                                          \
   switch(_optType)                                                       \
   {                                                                      \
      case MGT_LCL_CONNOPT_PKTZ_PERIOD:                                   \
      {                                                                   \
         cmMemcpy((U8 *)&(_opt->t.pktzPeriod),                            \
                  (CONSTANT U8 *)&(_optVal), sizeof(MgPktzPeriod));       \
      }                                                                   \
      break;                                                              \
                                                                          \
      case MGT_LCL_CONNOPT_BW:                                            \
      {                                                                   \
         cmMemcpy((U8 *)&(_opt->t.mgBw),                                  \
                  (CONSTANT U8 *)&(_optVal), sizeof(MgBw));               \
      }                                                                   \
      break;                                                              \
                                                                          \
      case MGT_LCL_CONNOPT_ALGO_NAME:                                     \
      {                                                                   \
         TknStr32   *_algoName;                                           \
         U16        _numEnt;                                              \
                                                                          \
         if (_opt->t.algoNameSet.numComp.pres == NOTPRSNT)                \
         {                                                                \
            _opt->t.algoNameSet.numComp.pres = PRSNT_NODEF;               \
            _opt->t.algoNameSet.numComp.val  = 0;                         \
         }                                                                \
         _numEnt   = _opt->t.algoNameSet.numComp.val++;                   \
         _algoName = (_opt->t.algoNameSet.algoName[_numEnt]);             \
         cmMemcpy((U8 *)_algoName, (CONSTANT U8 *) &(_optVal),            \
                  sizeof(TknStr32));                                      \
      }                                                                   \
      break;                                                              \
                                                                          \
      case MGT_LCL_CONNOPT_ECHO_CAN:                                      \
      {                                                                   \
         cmMemcpy((U8 *)&(_opt->t.ecancel), (CONSTANT U8 *)&(_optVal),    \
                  sizeof(TknU8));                                       \
      }                                                                   \
      break;                                                              \
                                                                          \
      case MGT_LCL_CONNOPT_SIL_SUPP:                                      \
      {                                                                   \
         cmMemcpy((U8 *)&(_opt->t.silSupp), (CONSTANT U8 *)&(_optVal),    \
                  sizeof(TknU8));                                       \
      }                                                                   \
      break;                                                              \
                                                                          \
      case MGT_LCL_CONNOPT_GAIN_CTRL:                                     \
      {                                                                   \
         cmMemcpy((U8 *)&(_opt->t.gainCtrl),(CONSTANT U8 *)&(_optVal),    \
                  sizeof(MgGainCtrl));                                    \
      }                                                                   \
      break;                                                              \
                                                                          \
      case MGT_LCL_CONNOPT_TYPE_SRVC:                                     \
      {                                                                   \
         cmMemcpy((U8 *)&(_opt->t.typeOfSrvc), (CONSTANT U8 *)&(_optVal), \
                  sizeof(TknU16));                                        \
      }                                                                   \
      break;                                                              \
                                                                          \
      case MGT_LCL_CONNOPT_RSRC_RESV:                                     \
      {                                                                   \
         cmMemcpy((U8 *)&(_opt->t.rsrcResv), (CONSTANT U8 *)&(_optVal),   \
                  sizeof(TknU8));                                         \
      }                                                                   \
      break;                                                              \
                                                                          \
      case MGT_LCL_CONNOPT_TYPE_OF_NET:                                   \
      {                                                                   \
         cmMemcpy((U8 *)&(_opt->t.typeOfNetwork),                         \
                  (CONSTANT U8 *)&(_optVal), sizeof(TknU8));              \
      }                                                                   \
      break;                                                              \
                                                                          \
      case MGT_LCL_CONNOPT_ENCRYPT_INFO:                                  \
      {                                                                   \
         MgEncryptInfo   *_eInfo = (MgEncryptInfo *) &(_optVal);          \
                                                                          \
         _opt->t.encryptInfo.pres.pres = PRSNT_NODEF;                     \
         MG_ACC_INIT_TOKEN_VALUE(&(_opt->t.encryptInfo.encryptMethod),    \
                                 _eInfo->encryptMethod.val);              \
         MG_ACC_INIT_TKNSTROSXL(&(_opt->t.encryptInfo.encryptKey),        \
                                _eInfo->encryptKey.val,                   \
                                _eInfo->encryptKey.len);                  \
      }                                                                   \
      break;                                                              \
                                                                          \
      case MGT_LCL_CONNOPT_SUPP_MODES:                                    \
      {                                                                   \
         TknU8 *_mode;                                                    \
         U16   _numEnt;                                                   \
                                                                          \
         _numEnt   = _opt->t.suppModes.numComp.val++;                     \
         _mode     = _opt->t.suppModes.mode[_numEnt];                     \
         cmMemcpy((U8 *)_mode, (CONSTANT U8 *) &(_optVal), sizeof(TknU8));\
      }                                                                   \
      break;                                                              \
                                                                          \
      case MGT_LCL_CONNOPT_SUPP_PKGS:                                     \
      {                                                                   \
         MgPkgName *_pkgName;                                             \
         U16       _numEnt;                                               \
                                                                          \
         _numEnt   = _opt->t.suppPkgs.numComp.val++;                      \
         _pkgName  = _opt->t.suppPkgs.pkgName[_numEnt];                   \
         cmMemcpy((U8 *)_pkgName, (CONSTANT U8 *) &(_optVal),             \
            sizeof(MgPkgName));                                           \
      }                                                                   \
      break;                                                              \
                                                                          \
      default:                                                            \
      break;                                                              \
   }                                                                      \
}

#define MG_ACC_INIT_CONN_MODE(_param, _connMode)                          \
{                                                                         \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_CONN_MODE;                        \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_param)->t.connMode), _connMode);           \
}

#define MG_ACC_INIT_RQSTD_EVNT_SET(_numComp, _msg, _rqstdEvntSet)         \
{                                                                         \
   U16 i;                                                                 \
   if ((_rqstdEvntSet)->numComp.pres == NOTPRSNT)                         \
   {                                                                      \
      (_rqstdEvntSet)->numComp.pres = PRSNT_NODEF;                        \
      (_rqstdEvntSet)->numComp.val = 0;                                   \
   }                                                                      \
   MG_ACC_GETMEM((_rqstdEvntSet)->rqstdEvnt,                              \
      ((_numComp) * sizeof(MgRqstdEvnt *)), &((_msg)->memCp));            \
   /* Note: Each requested event is assigned independently */             \
}
   
#define MG_ACC_FILL_RQSTD_EVNT_SET(_param, _rqstdEvnt)                    \
{                                                                         \
   MgRqstdEvntSet     *_rqstdEvntSet;                                     \
                                                                          \
   if (_rqstdEvnt != NULLP)                                               \
   {                                                                      \
      (_param)->paramType.pres = PRSNT_NODEF;                             \
      (_param)->paramType.val  = MGT_PARAM_RQSTD_EVENT;                   \
                                                                          \
      _rqstdEvntSet = &((_param)->t.rqstdEvntSet);                        \
                                                                          \
      if (_rqstdEvntSet->numComp.pres == NOTPRSNT)                        \
      {                                                                   \
         _rqstdEvntSet->numComp.pres = PRSNT_NODEF;                       \
         _rqstdEvntSet->numComp.val  = 0;                                 \
      }                                                                   \
                                                                          \
      _rqstdEvntSet->rqstdEvnt[_rqstdEvntSet->numComp.val++] = _rqstdEvnt;\
   }                                                                      \
}

#define MG_ACC_FILL_EVNT_NAME(_evntName, _pkgId, _pkgName, _descType,     \
                              _evnt, _connId)                             \
{                                                                         \
   if ((_evntName) != NULLP)                                              \
   {                                                                      \
      MG_ACC_INIT_TOKEN_VALUE(&(_evntName)->pres, 1);                     \
      MG_ACC_INIT_TOKEN_VALUE(&(_evntName)->pkgName.pkgId, (_pkgId));     \
      if ((_pkgId) == MGT_MGCP_PKG_UNKNOWN)                               \
      {                                                                   \
         U8 _len;                                                         \
         if ((_pkgName) != NULLP)                                         \
         {                                                                \
            _len = cmStrlen(_pkgName);                                    \
         }                                                                \
         else                                                             \
         {                                                                \
            _len = 0;                                                     \
         }                                                                \
         MG_ACC_INIT_TKNSTROSXL(&(_evntName)->pkgName.name, (_pkgName),   \
            _len);                                                        \
      }                                                                   \
      MG_ACC_INIT_TOKEN_VALUE(&(_evntName)->eventDesc.descType, (_descType)); \
      switch (_descType)                                                  \
      {                                                                   \
         case MGT_DESC_EVENT_ALL: default:                                \
         break;                                                           \
                                                                          \
         case MGT_DESC_EVENT_ID:                                          \
         {                                                                \
            MG_ACC_INIT_TKNSTROSXL(&(_evntName)->eventDesc.t.eventId,     \
               (_evnt));                                                  \
         }                                                                \
         break;                                                           \
                                                                          \
         case MGT_DESC_EVENT_RANGE:                                       \
         {                                                                \
            MG_ACC_INIT_TKNSTROSXL(&(_evntName)->eventDesc.t.eventRange,  \
               (_evnt));                                                  \
         }                                                                \
         break;                                                           \
                                                                          \
         case MGT_DESC_EVENT_KNOWN:                                       \
         {                                                                \
            MG_ACC_INIT_TOKEN_VALUE(&(_evntName)->eventDesc.t.eventKnown, \
               (_evnt));                                                  \
         }                                                                \
         break;                                                           \
      }                                                                   \
      if ((_connId) != NULLP)                                             \
      {                                                                   \
         U8 _len;                                                         \
         _len = (U8)cmStrlen(_connId);                                    \
         MG_ACC_INIT_TKNSTR(&(_evntName)->connId, (_connId), _len);       \
      }                                                                   \
   }                                                                      \
}


#define MG_ACC_FILL_RQSTD_EVNT(_evnt, _evntName, _actn)                   \
{                                                                         \
   MgRqstdActnSet   *_actnSet;                                            \
                                                                          \
   (_evnt)->pres.pres = PRSNT_NODEF;                                      \
                                                                          \
   cmMemcpy((U8 *)&((_evnt)->evntName), (CONSTANT U8 *)(_evntName),       \
            sizeof(MgEvntName));                                          \
                                                                          \
   _actnSet = &((_evnt)->rqstdActnSet);                                   \
                                                                          \
   MG_ACC_FILL_RQSTD_ACTN_SET(_actnSet, _actn);                           \
}

#define MG_ACC_INIT_RQSTD_ACTN_SET(_numComp, _msg, _rqstdActnSet)         \
{                                                                         \
   U16 i;                                                                 \
   if ((_rqstdActnSet)->numComp.pres == NOTPRSNT)                         \
   {                                                                      \
      (_rqstdActnSet)->numComp.pres = PRSNT_NODEF;                        \
      (_rqstdActnSet)->numComp.val = 0;                                   \
   }                                                                      \
   MG_ACC_GETMEM((_rqstdActnSet)->rqstdActn,                              \
      ((_numComp) * sizeof(MgRqstdActn *)), &((_msg)->memCp));            \
   for (i = 0; i < (_numComp); i++)                                       \
   {                                                                      \
      (_rqstdActnSet)->rqstdActn[i] = NULLP;                              \
      MG_ACC_GETMEM((_rqstdActnSet)->rqstdActn[i], sizeof(MgRqstdActn),   \
         &((_msg)->memCp));                                               \
   }                                                                      \
}

#define MG_ACC_FILL_RQSTD_ACTN_SET(_actnSet, _actn)                       \
{                                                                         \
   if (_actnSet->numComp.pres == NOTPRSNT)                                \
   {                                                                      \
      _actnSet->numComp.pres = PRSNT_NODEF;                               \
      _actnSet->numComp.val  = 0;                                         \
   }                                                                      \
   _action = (_actnSet->rqstdActn[_actnSet->numComp.val++]);              \
                                                                          \
   cmMemcpy((U8 *)_action, (CONSTANT U8 *) _actn, sizeof(MgRqstdActn));   \
}

#define MG_ACC_INIT_EMBED_ACTN(_numComp, _msg, _embdActn)                 \
{                                                                         \
   U16 i;                                                                 \
   if ((_embdActn)->numComp.pres == NOTPRSNT)                             \
   {                                                                      \
      (_embdActn)->numComp.pres = PRSNT_NODEF;                            \
      (_embdActn)->numComp.val = 0;                                       \
   }                                                                      \
   MG_ACC_GETMEM((_embdActn)->rqstdEmbed,                                 \
      (_numComp) * sizeof(MgRqstEmbedType *), &((_msg)->memCp));          \
   for (i = 0; i < (_numComp); i++)                                       \
   {                                                                      \
      (_embdActn)->rqstdEmbed[i] = NULLP;                                 \
      MG_ACC_GETMEM((_embdActn)->rqstdEmbed[i], sizeof(MgRqstEmbedType),  \
         &((_msg)->memCp));                                               \
   }                                                                      \
}

#define MG_ACC_FILL_EMBED_ACTN(_embdActn, _embdType)                      \
{                                                                         \
   if ((_embdActn)->numComp.pres == NOTPRSNT)                             \
   {                                                                      \
      (_embdActn)->numComp.pres = PRSNT_NODEF;                            \
      (_embdActn)->numComp.val  = 0;                                      \
   }                                                                      \
                                                                          \
   cmMemcpy((U8 *)((_embdActn)->rqstdEmbed[(_embdActn)->numComp.val++]),  \
            (CONSTANT U8 *)_embdType, sizeof(MgRqstEmbedType));           \
}

#define MG_ACC_FILL_RQSTD_ACTION(_rqstdActn, _actionType)                 \
{                                                                         \
   MG_ACC_INIT_TOKEN_VALUE(&((_rqstdActn)->actionType), _actionType);     \
}

#define MG_ACC_FILL_RQST_EMBD_TYPE(_embdType, _typeValue)                 \
{                                                                         \
   MG_ACC_INIT_TOKEN_VALUE(&((_embdType)->embdRqstType), _typeValue);     \
}

#define MG_ACC_INIT_SGNL_RQST_SET(_param, _rqstSet, _rqst)                \
{                                                                         \
   if (_param != NULLP)                                                   \
   {                                                                      \
      (_param)->paramType.pres = PRSNT_NODEF;                             \
      (_param)->paramType.val  = MGT_PARAM_SIG_RQST;                      \
   }                                                                      \
                                                                          \
   if ((_rqstSet)->numComp.pres == NOTPRSNT)                              \
   {                                                                      \
      (_rqstSet)->numComp.pres = PRSNT_NODEF;                             \
      (_rqstSet)->numComp.val  = 0;                                       \
   }                                                                      \
                                                                          \
   (_rqstSet)->signalRqst[(_rqstSet)->numComp.val++] = _rqst;             \
}

#define MG_ACC_INIT_OBSEVNT_SET(_param, _rqstSet, _rqst)                  \
{                                                                         \
   if (_param != NULLP)                                                   \
   {                                                                      \
      (_param)->paramType.pres = PRSNT_NODEF;                             \
      (_param)->paramType.val  = MGT_PARAM_OBS_EVENT;                     \
   }                                                                      \
                                                                          \
   if ((_rqstSet)->numComp.pres == NOTPRSNT)                              \
   {                                                                      \
      (_rqstSet)->numComp.pres = PRSNT_NODEF;                             \
      (_rqstSet)->numComp.val  = 0;                                       \
   }                                                                      \
                                                                          \
   (_rqstSet)->signalRqst[(_rqstSet)->numComp.val++] = _rqst;             \
}

#define MG_ACC_INIT_PARAM_TYPE_SET(_paramSet, _paramType, _value, _len)   \
{                                                                         \
   MgEvntParamType   *_param;                                             \
                                                                          \
   if ((_paramSet)->numComp.pres == NOTPRSNT)                             \
   {                                                                      \
      (_paramSet)->numComp.pres = PRSNT_NODEF;                            \
      (_paramSet)->numComp.val  = 0;                                      \
   }                                                                      \
                                                                          \
   _param = &((_paramSet)->evntParam[(_paramSet)->numComp.val++]);        \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_param)->eventParamType), _paramType);      \
   MG_ACC_INIT_TKNSTROSXL(&((_param)->t.paramStr), _value, _len);         \
}

#define MG_ACC_INIT_DIGIT_MAP(_param, _value, _len)                       \
{                                                                         \
   if (_param != NULLP)                                                   \
   {                                                                      \
      (_param)->paramType.pres = PRSNT_NODEF;                             \
      (_param)->paramType.val  = MGT_PARAM_DGT_MAP;                       \
                                                                          \
      MG_ACC_FILL_DIGIT_MAP(&((_param)->t.dgtMap), _value, _len);         \
   }                                                                      \
                                                                          \
}

#define MG_ACC_FILL_DIGIT_MAP(_dgtMap, _value, _len)                      \
{                                                                         \
   TknStrOSXL   *_tkn;                                                    \
                                                                          \
   if ((_dgtMap)->numComp.pres == NOTPRSNT)                               \
   {                                                                      \
      (_dgtMap)->numComp.pres = PRSNT_NODEF;                              \
      (_dgtMap)->numComp.val  = 0;                                        \
   }                                                                      \
                                                                          \
   _tkn = &((_dgtMap)->dgtStr[(_dgtMap)->numComp.val++]);                 \
   MG_ACC_INIT_TKNSTROSXL(_tkn, _value, _len);                            \
}

#define MG_ACC_INIT_OBSERVED_EVNTS(_param)                                \
{                                                                         \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_OBS_EVENT;                        \
}

#define MG_ACC_INIT_CONPARAM_SET(_param, _conParamType, _value)           \
{                                                                         \
   MgConnParamSet   *_conParamSet;                                        \
   MgConnParam      *_conParam;                                           \
                                                                          \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_CONN_PARAM;                       \
                                                                          \
   _conParamSet = &((_param)->t.connParamSet);                            \
                                                                          \
   if (_conParamSet->numComp.pres == NOTPRSNT)                            \
   {                                                                      \
      _conParamSet->numComp.pres = PRSNT_NODEF;                           \
      _conParamSet->numComp.val  = 0;                                     \
   }                                                                      \
                                                                          \
   if (_conParamType != MGT_PARAM_CONN_PARAM_NONSTD)                      \
   {                                                                      \
      _conParam = &(_conParamSet->connParam[_conParamSet->numComp.val++]);\
      MG_ACC_INIT_TOKEN_VALUE(&(_conParam->paramType), _conParamType);    \
                                                                          \
      MG_ACC_INIT_TOKEN_VALUE(&(_conParam->t.octetsSent), _value);        \
   }                                                                      \
}

#define MG_ACC_INIT_REASON_CODE(_param, _tknVal, _value, _len)            \
{                                                                         \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_REASON;                           \
                                                                          \
                                                                          \
   (_param)->t.reasonCode.pres.pres = PRSNT_NODEF;                        \
   MG_ACC_INIT_TOKEN_VALUE(&((_param)->t.reasonCode.code), _tknVal);      \
                                                                          \
   if (_value != NULLP)                                                   \
      MG_ACC_INIT_TKNSTROSXL(&((_param)->t.reasonCode.param),             \
                             _value, _len);                               \
}

#define MG_ACC_INIT_DNAME(_dname, _type, _addr, _name)                    \
{                                                                         \
   (_dname)->nameType = _type;                                            \
                                                                          \
   if (_type == MGT_DNAME_NAME)                                           \
   {                                                                      \
      cmMemcpy((U8 *)((_dname)->t.name), (CONSTANT U8 *)_name,            \
               CM_DNS_DNAME_LEN);                                         \
   }                                                                      \
   else                                                                   \
      cmMemcpy((U8 *)&((_dname)->t.netAddr), (CONSTANT U8 *)_addr,        \
               sizeof(CmNetAddr));                                        \
}

#define MG_ACC_INIT_EPNAME(_param, _lclNameStr, _lclNameLen,_dnameStr,    \
                           _dnameLen, _endPointType)                      \
{                                                                         \
   MgEPName   *_epName;                                                   \
                                                                          \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = _endPointType;                              \
                                                                          \
   _epName = &((_param)->t.specificEpId);                                 \
   _epName->pres.pres = PRSNT_NODEF;                                      \
                                                                          \
   MG_ACC_INIT_TKNSTROSXL(&(_epName->lclName), _lclNameStr, _lclNameLen); \
   MG_ACC_INIT_TKNSTROSXL(&(_epName->domainName), _dnameStr, _dnameLen);  \
}

#define MG_ACC_INIT_SCND_CONNID(_param, _value, _len)                     \
{                                                                         \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_SCND_CONNID;                      \
                                                                          \
   MG_ACC_INIT_TKNSTR(&((_param)->t.scndConnId), _value, _len);           \
}

#define MG_ACC_INIT_RQSTD_INFO(_param, _value)                            \
{                                                                         \
   MgRqstdInfo   *_rqstdInfo;                                             \
   TknU8         *_tkn;                                                   \
                                                                          \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_RQSTD_INFO;                       \
                                                                          \
   _rqstdInfo = &((_param)->t.rqstdInfo);                                 \
                                                                          \
   if (_rqstdInfo->numComp.pres == NOTPRSNT)                              \
   {                                                                      \
      _rqstdInfo->numComp.pres = PRSNT_NODEF;                             \
      _rqstdInfo->numComp.val  = 0;                                       \
   }                                                                      \
                                                                          \
   _tkn = &(_rqstdInfo->infoCode[_rqstdInfo->numComp.val++]);             \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(_tkn, _value);                                 \
}

#define MG_ACC_INIT_QRNT_HANDLING(_param, _value)                         \
{                                                                         \
   MgQrntHandling *_qrntHdl;                                              \
   TknU8          *_tkn;                                                  \
                                                                          \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_QRNT_HANDLING;                    \
                                                                          \
   _qrntHdl =  &((_param)->t.qrntHandling);                               \
                                                                          \
   if (_qrntHdl->numComp.pres == NOTPRSNT)                                \
   {                                                                      \
      _qrntHdl->numComp.pres = PRSNT_NODEF;                               \
      _qrntHdl->numComp.val  = 0;                                         \
   }                                                                      \
                                                                          \
   _tkn = &(_qrntHdl->ctrl[_qrntHdl->numComp.val++]);                     \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(_tkn, _value);                                 \
}

#define MG_ACC_INIT_RESTART_METHOD(_param, _value)                        \
{                                                                         \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_RSTRT_METHOD;                     \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_param)->t.rstrtMethod), _value);           \
}

#define MG_ACC_INIT_RESTART_DELAY(_param, _value)                         \
{                                                                         \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_RSTRT_DELAY;                      \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_param)->t.rstrtDelay), _value);            \
}

#define MG_ACC_INIT_DETECT_EVNT(_param, _evntName)                        \
{                                                                         \
   MgDetectEvent   *_detEvnt;                                             \
                                                                          \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_DETECT_EVENT;                     \
                                                                          \
   _detEvnt = &((_param)->t.detectEvnt);                                  \
                                                                          \
   if (_detEvnt->numComp.pres == NOTPRSNT)                                \
   {                                                                      \
      _detEvnt->numComp.pres = PRSNT_NODEF;                               \
      _detEvnt->numComp.val  = 0;                                         \
   }                                                                      \
                                                                          \
   _detEvnt->evnt[_detEvnt->numComp.val++] = _evntName;                   \
}

#define MG_ACC_FILL_CONN_PARAM_NONSTD_EXTN(_extn, _memCp)                 \
{                                                                         \
   U8      *_name;                                                        \
   U8      *_value;                                                       \
   U8      _nameLen;                                                      \
   U8      _valueLen;                                                     \
                                                                          \
   _nameLen  = (U8)cmStrlen((CONSTANT U8 *)("Nsdext"));                   \
   _valueLen = (U8)cmStrlen((CONSTANT U8 *)("91547789"));                 \
                                                                          \
   MG_ACC_GETMEM(_name, _nameLen, _memCp);                                \
   MG_ACC_GETMEM(_value,_valueLen,_memCp);                                \
                                                                          \
   cmMemcpy(_name, (CONSTANT U8 *)("NonStdExtnName"), _nameLen);          \
   cmMemcpy(_value, (CONSTANT U8 *)("91547789"), _valueLen);              \
                                                                          \
   (_extn)->pres.pres = PRSNT_NODEF;                                      \
                                                                          \
   MG_ACC_INIT_TKNSTROSXL(&((_extn)->extnName), _name, _nameLen);         \
   MG_ACC_INIT_TKNSTROSXL(&((_extn)->extnVal), _value, _valueLen);        \
   (_extn)->type.pres = PRSNT_NODEF;                                      \
   (_extn)->type.val =  2;                                                \
}

#define MG_ACC_FILL_NONSTD_EXTN(_extn, _memCp)                            \
{                                                                         \
   U8      *_name;                                                        \
   U8      *_value;                                                       \
   U8      _nameLen;                                                      \
   U8      _valueLen;                                                     \
                                                                          \
   _nameLen  = (U8)cmStrlen((CONSTANT U8 *)("Nsdext"));                   \
   _valueLen = (U8)cmStrlen((CONSTANT U8 *)("NonStdExtnVal"));            \
                                                                          \
   MG_ACC_GETMEM(_name, _nameLen, _memCp);                                \
   MG_ACC_GETMEM(_value,_valueLen,_memCp);                                \
                                                                          \
   cmMemcpy(_name, (CONSTANT U8 *)("NonStdExtnName"), _nameLen);          \
   cmMemcpy(_value, (CONSTANT U8 *)("NonStdExtnVal"), _valueLen);         \
                                                                          \
   (_extn)->pres.pres = PRSNT_NODEF;                                      \
                                                                          \
   MG_ACC_INIT_TKNSTROSXL(&((_extn)->extnName), _name, _nameLen);         \
   MG_ACC_INIT_TKNSTROSXL(&((_extn)->extnVal), _value, _valueLen);        \
   (_extn)->type.pres = PRSNT_NODEF;                                      \
   (_extn)->type.val =  1;                                                \
}

#define MG_ACC_INIT_NONSTD_EXTN(_param, _memCp)                           \
{                                                                         \
   (_param)->paramType.pres = PRSNT_NODEF;                                \
   (_param)->paramType.val  = MGT_PARAM_NON_STD;                          \
   MG_ACC_FILL_NONSTD_EXTN(&((_param)->t.nonStdExtn), _memCp);            \
}

/* SDP Related Macros */
#define MG_ACC_INIT_SDP_ORIG(_orig, _usr, _usrLen, _sessId, _sessVer,     \
                           _netType, _addrType, _addrStr, _addrLen)       \
{                                                                         \
   (_orig)->pres.pres = PRSNT_NODEF;                                      \
                                                                          \
   MG_ACC_INIT_TKNSTROSXL(&((_orig)->usrName), _usr, _usrLen);            \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_orig)->sessId), _sessId);                  \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_orig)->sessVer), _sessVer);                \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_orig)->netType), _netType);                \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_orig)->addrType), _addrType);              \
                                                                          \
   MG_ACC_INIT_TKNSTROSXL(&((_orig)->sdpAddr), _addrStr, _addrLen);       \
}

#define MG_ACC_INIT_SDP_EMAIL_SET(_set, _value, _len)                     \
{                                                                         \
   TknStrOSXL   *_email;                                                  \
                                                                          \
   if ((_set)->numComp.pres == NOTPRSNT)                                  \
   {                                                                      \
      (_set)->numComp.pres = PRSNT_NODEF;                                 \
      (_set)->numComp.val  = 0;                                           \
   }                                                                      \
                                                                          \
   _email = &((_set)->email[(_set)->numComp.val++]);                      \
                                                                          \
   MG_ACC_INIT_TKNSTROSXL(_email, _value, _len);                          \
}
                                                                          \
#define MG_ACC_INIT_SDP_PHONE_SET(_set, _value, _len)                     \
{                                                                         \
   TknStrOSXL   *_phone;                                                  \
                                                                          \
   if ((_set)->numComp.pres == NOTPRSNT)                                  \
   {                                                                      \
      (_set)->numComp.pres = PRSNT_NODEF;                                 \
      (_set)->numComp.val  = 0;                                           \
   }                                                                      \
                                                                          \
   _phone = &((_set)->phone[(_set)->numComp.val++]);                      \
                                                                          \
   MG_ACC_INIT_TKNSTROSXL(_phone, _value, _len);                          \
}

#define MG_ACC_INIT_SDP_TIME(_sdpTime)                                    \
{                                                                         \
   (_sdpTime)->pres.pres = PRSNT_NODEF;                                   \
                                                                          \
   (_sdpTime)->sdpOpTimeSet.numComp.pres = NOTPRSNT;                      \
   (_sdpTime)->sdpOpTimeSet.numComp.val  = 0;                             \
                                                                          \
   (_sdpTime)->zoneAdjSet.numComp.pres = NOTPRSNT;                        \
   (_sdpTime)->zoneAdjSet.numComp.val  = 0;                               \
}

#define MG_ACC_INIT_SDP_OPTIME_SET(_set, _startTime, _stopTime,           \
                                   _typedTimeVal, _typedTimeUnit)         \
{                                                                         \
   CmSdpOpTime   *_optTime;                                               \
                                                                          \
   if ((_set)->numComp.pres == NOTPRSNT)                                  \
   {                                                                      \
      (_set)->numComp.pres = PRSNT_NODEF;                                 \
      (_set)->numComp.val  = 0;                                           \
   }                                                                      \
                                                                          \
   if (cmGetMem(&(msg->memCp), sizeof(CmSdpOpTime),                       \
                (Ptr *) &(_optTime)) != ROK)                              \
      RETVALUE(RFAILED);                                                  \
   cmMemset((U8 *)(_optTime), (U8)0,  (PTR)(sizeof(CmSdpOpTime)));        \
                                                                          \
    (_set)->sdpOpTime[(_set)->numComp.val] = _optTime;                    \
    (_set)->numComp.val++;                                                \
                                                                          \
    MG_ACC_INIT_SDP_OPTIME(_optTime, _startTime, _stopTime, _typedTimeVal,\
                          _typedTimeUnit);                                \
}

#define MG_ACC_INIT_SDP_OPTIME(_optTime, _startTime, _stopTime,           \
                                   _typedTimeVal, _typedTimeUnit)         \
{                                                                         \
   U16   _len;                                                            \
   (_optTime)->pres.pres = PRSNT_NODEF;                                   \
   (_len) = cmStrlen(_startTime);                                         \
   MG_ACC_INIT_TKNSTR(&((_optTime)->startTime), _startTime, (_len));      \
   (_len) = cmStrlen(_stopTime);                                          \
                                                                          \
   MG_ACC_INIT_TKNSTR(&((_optTime)->stopTime), _stopTime, (_len));        \
                                                                          \
   MG_ACC_INIT_REP_FIELD_SET(&((_optTime)->repFieldSet), _typedTimeVal,   \
                             _typedTimeUnit);                             \
}

#define MG_ACC_INIT_REP_FIELD_SET(_set, _typedTimeVal, _typedTimeUnit)    \
{                                                                         \
   CmSdpRepField  *_field;                                                \
                                                                          \
   if ((_set)->numComp.pres == NOTPRSNT)                                  \
   {                                                                      \
      (_set)->numComp.pres = PRSNT_NODEF;                                 \
      (_set)->numComp.val  = 0;                                           \
   }                                                                      \
                                                                          \
   _field = &((_set)->repField[(_set)->numComp.val++]);                   \
                                                                          \
   MG_ACC_INIT_SDP_REP_FIELD(_field, _typedTimeVal, _typedTimeUnit);      \
}

#define MG_ACC_INIT_SDP_REP_FIELD(_field, _typedTimeVal, _typedTimeUnit)  \
{                                                                         \
   (_field)->pres.pres = PRSNT_NODEF;                                     \
                                                                          \
                                                                          \
   MG_ACC_INIT_SDP_TYPED_TIME(&((_field)->repInterval), _typedTimeVal,    \
                              _typedTimeUnit);                            \
                                                                          \
   MG_ACC_INIT_SDP_TYPED_TIME(&((_field)->actvDur), _typedTimeVal,        \
                              _typedTimeUnit);                            \
                                                                          \
   MG_ACC_INIT_SDP_TYPED_TIME_SET(&((_field)->offsetList),                \
                                   _typedTimeVal, _typedTimeUnit);        \
}

#define MG_ACC_INIT_SDP_TYPED_TIME_SET(_timeSet, _val, _unit)             \
{                                                                         \
   CmSdpTypedTime   *_typedTime;                                          \
                                                                          \
   if ((_timeSet)->numComp.pres == NOTPRSNT)                              \
   {                                                                      \
      (_timeSet)->numComp.pres = PRSNT_NODEF;                             \
      (_timeSet)->numComp.val  = 0;                                       \
   }                                                                      \
                                                                          \
   _typedTime = &((_timeSet)->typedTime[(_timeSet)->numComp.val++]);      \
                                                                          \
   MG_ACC_INIT_SDP_TYPED_TIME(_typedTime, _val, _unit);                   \
}
 
#define MG_ACC_INIT_SDP_TYPED_TIME(_ttime, _val, _unit)                   \
{                                                                         \
   U16   _length;                                                         \
   (_ttime)->pres.pres = PRSNT_NODEF;                                     \
                                                                          \
   (_length) = cmStrlen(_val);                                            \
   MG_ACC_INIT_TKNSTR(&((_ttime)->val), _val, _length);                   \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_ttime)->unit), (U8)_unit);                 \
}
 
#define MG_ACC_INIT_SDP_ZONE_ADJSET(_zoneSet, _time, _typedTime, _unit)   \
{                                                                         \
   CmSdpZoneAdj   *_zoneAdj;                                              \
                                                                          \
   if ((_zoneSet)->numComp.pres == NOTPRSNT)                              \
   {                                                                      \
      (_zoneSet)->numComp.pres = PRSNT_NODEF;                             \
      (_zoneSet)->numComp.val  = 0;                                       \
   }                                                                      \
                                                                          \
   _zoneAdj = &((_zoneSet)->zoneAdj[(_zoneSet)->numComp.val++]);          \
                                                                          \
   MG_ACC_INIT_SDP_ZONE_ADJ(_zoneAdj, _time, _typedTime, _unit);          \
}
 
#define MG_ACC_INIT_SDP_ZONE_ADJ(_zoneAdj, _time, _typedTime, _unit)      \
{                                                                         \
   U16   _len;                                                            \
   (_zoneAdj)->pres.pres = PRSNT_NODEF;                                   \
                                                                          \
   (_len) = cmStrlen(_time);                                              \
   MG_ACC_INIT_TKNSTR(&((_zoneAdj)->time), _time, _len);                  \
                                                                          \
   MG_ACC_INIT_SDP_TYPED_TIME(&((_zoneAdj)->typedTime),_typedTime, _unit);\
}

#define MG_ACC_INIT_SDP_MEDIA_DESC(_mediaDesc, _info, _infoLen)           \
{                                                                         \
   (_mediaDesc)->pres.pres = PRSNT_NODEF;                                 \
                                                                          \
   MG_ACC_INIT_TKNSTROSXL(&((_mediaDesc)->info), _info, _infoLen);        \
}

#define MG_ACC_INIT_SDP_MEDIA_FIELD(_field, _mediaType, _port, _portInt,  \
                                    _proto, _protoLen, _fmtVal, _fmtLen)  \
{                                                                         \
   (_field)->pres.pres = PRSNT_NODEF;                                     \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_field)->mediaType), _mediaType);           \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_field)->port), _port);                     \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_field)->portInt), _portInt);               \
                                                                          \
   MG_ACC_INIT_TKNSTR(&((_field)->proto), _proto, _protoLen);             \
                                                                          \
   MG_ACC_INIT_SDP_FMT_SET(&((_field)->fmtSet), _fmtVal, _fmtLen);        \
}

#define MG_ACC_INIT_SDP_FMT_SET(_set, _fmtVal, _fmtLen)                   \
{                                                                         \
   CmSdpFmt     *_fmt;                                                    \
                                                                          \
   if ((_set)->numComp.pres == NOTPRSNT)                                  \
   {                                                                      \
      (_set)->numComp.pres = PRSNT_NODEF;                                 \
      (_set)->numComp.val  = 0;                                           \
   }                                                                      \
                                                                          \
   _fmt = &((_set)->fmtInfo[(_set)->numComp.val++]);                      \
                                                                          \
   MG_ACC_INIT_SDP_FMT(_fmt, _fmtVal, _fmtLen);                           \
}

#define MG_ACC_INIT_SDP_FMT(_fmt, _value, _len)                           \
{                                                                         \
   MG_ACC_INIT_TKNSTROSXL(_fmt, _value, len);                             \
}

#define MG_ACC_INIT_CONN_SET(_set, _netType, _addrType, _addr, _addrLen)  \
{                                                                         \
   CmSdpConn   *_conn;                                                    \
                                                                          \
   if ((_set)->numComp.pres == NOTPRSNT)                                  \
   {                                                                      \
      (_set)->numComp.pres = PRSNT_NODEF;                                 \
      (_set)->numComp.val  = 0;                                           \
   }                                                                      \
                                                                          \
   _conn = &((_set)->infoSet[(_set)->numComp.val++]);                     \
                                                                          \
   MG_ACC_INIT_SDP_CONN(_conn, _netType, _addrType, _addr, _addrLen);     \
}

#define MG_ACC_INIT_SDP_CONN(_conn, _netType, _addrType, _addr, _addrLen) \
{                                                                         \
   (_conn)->pres.pres = PRSNT_NODEF;                                      \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_conn)->netType), _netType);                \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_conn)->addrType), _addrType);              \
                                                                          \
   MG_ACC_INIT_TKNSTROSXL(&((_conn)->sdpAddr), _addr, _addrLen);          \
}

#define MG_ACC_INIT_SDP_BW_SET(_set, _bwType, _bwTypeLen, _bWidth)        \
{                                                                         \
   CmSdpBw   *_bw;                                                        \
                                                                          \
   if ((_set)->numComp.pres == NOTPRSNT)                                  \
   {                                                                      \
      (_set)->numComp.pres = PRSNT_NODEF;                                 \
      (_set)->numComp.val  = 0;                                           \
   }                                                                      \
                                                                          \
   _bw = &((_set)->sdpBw[(_set)->numComp.val++]);                         \
                                                                          \
   MG_ACC_INIT_SDP_BW(_bw, _bwType, _bwTypeLen, _bWidth);                 \
}

#define MG_ACC_INIT_SDP_BW(_bw, _bwType, _bwTypeLen, _bWidth)             \
{                                                                         \
   (_bw)->pres.pres = PRSNT_NODEF;                                        \
                                                                          \
   MG_ACC_INIT_TKNSTROSXL(&((_bw)->bwType), _bwType, _bwTypeLen);         \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_bw)->bWidth), _bWidth);                    \
}
 
#define MG_ACC_INIT_SDP_KEYTYPE(_sdpKey, _keyType, _data, _dataLen)       \
{                                                                         \
   (_sdpKey)->pres.pres = PRSNT_NODEF;                                    \
                                                                          \
   MG_ACC_INIT_TOKEN_VALUE(&((_sdpKey)->keyType), _keyType);              \
                                                                          \
   MG_ACC_INIT_TKNSTROSXL(&((_sdpKey)->key_data), _data, _dataLen);       \
}

#define MG_ACC_INIT_SDP_ATTR_SET(_attrSet, _attrType, _typeLen, _attrVal, \
                                 _valueLen)                               \
{                                                                         \
   CmSdpAttr    *_attr;                                                   \
                                                                          \
   if ((_attrSet)->numComp.pres == NOTPRSNT)                              \
   {                                                                      \
      (_attrSet)->numComp.pres = PRSNT_NODEF;                             \
      (_attrSet)->numComp.val  = 0;                                       \
   }                                                                      \
                                                                          \
   _attr = &((_attrSet)->attr[(_attrSet)->numComp.val++]);                \
                                                                          \
   MG_ACC_INIT_SDP_ATTR(_attr, _attrType, _typeLen, _attrVal, _valueLen); \
}
 
#define MG_ACC_INIT_SDP_ATTR(_attr, _attrType, _typeLen, _attrVal, _len)  \
{                                                                         \
   (_attr)->pres.pres = PRSNT_NODEF;                                      \
                                                                          \
   MG_ACC_INIT_TKNSTR(&((_attr)->attrType), _attrType, _typeLen);         \
                                                                          \
   MG_ACC_INIT_TKNSTR(&((_attr)->attrVal), _attrVal, _len);               \
}


#endif /* ifdef MG */
#endif /* __MGMACROH__ */
 
/********************************************************************30**
 
         End of file:     mg_macro.h@@/main/5 - Wed Mar 30 07:52:04 2005
 
*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
 
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bbk  1. Initial release.
/main/2      ---      dw   1. Release 1.2
/main/3      ---      ra   1. GCP 1.3 release
/main/4      ---      ka   1. Changes for Release v 1.4
/main/5      ---      pk   1. GCP 1.5 release
*********************************************************************91*/
