/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Mgcp hash defines file

     Type:     C header file

     Desc:     hash defines for mgcp packages

     File:     mgcp_pdb.h

     Sid:      mgcp_pdb.h@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:52:48 2005

     Prg:      ra

*********************************************************************21*/

#ifndef __MGCP_PDB_H__
#define __MGCP_PDB_H__

#ifdef GCP_MGCP 


#ifdef  GCP_PKG_MGCP_ANNC_SERVER

#define    MGT_MGCP_PKG_A_RQ_EV_SYM_OPER_COMPLT           0
#define    MGT_MGCP_PKG_A_RQ_EV_SYM_OPER_FAIL             1
#define    MGT_MGCP_PKG_A_SG_RQ_SYM_PLAY_AN_ANNC          0

#endif  /* GCP_PKG_MGCP_ANNC_SERVER */


#ifdef  GCP_PKG_MGCP_ATM


/*
*     Local Connection Options  ->
*/

#define   MGT_MGCP_CO_PKG_ATM_CONN_TYPE   1
#define   MGT_MGCP_CO_PKG_ATM_VC_BRR_TYPE   2
#define   MGT_MGCP_CO_PKG_ATM_ENABLE_PATH_SET_UP   3
#define   MGT_MGCP_CO_PKG_ATM_CONN_ELMNT_ID   4
#define   MGT_MGCP_CO_PKG_ATM_APPLI   5
#define   MGT_MGCP_CO_PKG_ATM_SUB_CHNL_CNT   6
#define   MGT_MGCP_CO_PKG_ATM_PART_FILL   7
#define   MGT_MGCP_CO_PKG_ATM_CLK_REC_TYPE   8
#define   MGT_MGCP_CO_PKG_ATM_FEC_ENABLE   9
#define   MGT_MGCP_CO_PKG_ATM_PROF_LST_TYPE   10
#define   MGT_MGCP_CO_PKG_ATM_SIMPL_CPS   11
#define   MGT_MGCP_CO_PKG_ATM_COMB_USE_TMR   12
#define   MGT_MGCP_CO_PKG_ATM_SRVC_ACCESS_PT   13
#define   MGT_MGCP_CO_PKG_ATM_CKT_MODE   14
#define   MGT_MGCP_CO_PKG_ATM_FRAME_MOD_ENABLE   15
#define   MGT_MGCP_CO_PKG_ATM_GENER_PCM_SETNG   16
#define   MGT_MGCP_CO_PKG_ATM_TX_ERR_DETECT   17
#define   MGT_MGCP_CO_PKG_ATM_SSAR_REASSEM_TMR   18
#define   MGT_MGCP_CO_PKG_ATM_VOICE_CODEC_SELEC   19
#define   MGT_MGCP_CO_PKG_ATM_DATA_CODEC_SELEC   20
#define   MGT_MGCP_CO_PKG_ATM_FAX_CODEC_SELEC   21
#define   MGT_MGCP_CO_PKG_ATM_CODEC_CFG   22
#define   MGT_MGCP_CO_PKG_ATM_ISUP_USR_INFO   23
#define   MGT_MGCP_CO_PKG_ATM_ATM_TRANSF_CAPAB   24
#define   MGT_MGCP_CO_PKG_ATM_ATC_SUB_TYPE   25
#define   MGT_MGCP_CO_PKG_ATM_QOS_CLS   26
#define   MGT_MGCP_CO_PKG_ATM_BROAD_BND_CONN_ORI_BRR_CLS   27
#define   MGT_MGCP_CO_PKG_ATM_ET_E_TMG_RQD   28
#define   MGT_MGCP_CO_PKG_ATM_SUSCEP_TO_CLIP   29
#define   MGT_MGCP_CO_PKG_ATM_USR_PLN_CONN_CFG   30
#define   MGT_MGCP_CO_PKG_ATM_ATM_QOS_PARMS_FORWRD   31
#define   MGT_MGCP_CO_PKG_ATM_ATM_QOS_PARMS_BCKWRD   32
#define   MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_FORWRD_CLP_IND   33
#define   MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_FORWRD_CLP_ZERO   34
#define   MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_BCKWRD_CLP_IND   35
#define   MGT_MGCP_CO_PKG_ATM_ATM_TRF_DESC_BCKWRD_CLP_ZERO   36
#define   MGT_MGCP_CO_PKG_ATM_ABR_PARMS_FORWRD   37
#define   MGT_MGCP_CO_PKG_ATM_ABR_PARMS_BCKWRD   38
#define   MGT_MGCP_CO_PKG_ATM_ABR_CONN_SETUP_PARMS   39
#define   MGT_MGCP_CO_PKG_ATM_STRUCT_SIZE   40
#define   MGT_MGCP_CO_PKG_ATM_CBR_RATE   41
#define   MGT_MGCP_CO_PKG_ATM_FOR_MAX_CPCS_SDU_SIZE   42
#define   MGT_MGCP_CO_PKG_ATM_BCK_MAX_CPCS_SDU_SIZE   43
#define   MGT_MGCP_CO_PKG_ATM_FOR_MAX_AAL2_CPS_SDU_SIZE   44
#define   MGT_MGCP_CO_PKG_ATM_BCK_MAX_AAL2_CPS_SDU_SIZE   45
#define   MGT_MGCP_CO_PKG_ATM_FOR_MAX_FRAME_BLK_SIZE   46
#define   MGT_MGCP_CO_PKG_ATM_BCK_MAX_FRAME_BLK_SIZE   47
#define   MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSSAR_SDU_SIZE   48
#define   MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSSAR_SDU_SIZE   49
#define   MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSCOP_SDU_SIZE   50
#define   MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSCOP_SDU_SIZE   51
#define   MGT_MGCP_CO_PKG_ATM_FOR_MAX_SSCOP_UU_SIZE   52
#define   MGT_MGCP_CO_PKG_ATM_BCK_MAX_SSCOP_UU_SIZE   53
#define    MGT_MGCP_PKG_ATM_RQ_EV_SYM_BRR_PATH_SETUP1    0
#define    MGT_MGCP_PKG_ATM_RQ_EV_SYM_BRR_PATH_SETUP2    1
#define    MGT_MGCP_PKG_ATM_RQ_EV_SYM_USED_CODEC_CHNGD    2
#define    MGT_MGCP_PKG_ATM_RQ_EV_SYM_PCKTZN_PERIOD    3
#define    MGT_MGCP_PKG_ATM_RQ_EV_SYM_PROF_ELMNT    4
#define    MGT_MGCP_PKG_ATM_RQ_EV_SYM_CELL_LOSS    5
#define    MGT_MGCP_PKG_ATM_RQ_EV_SYM_PCKT_LOSS_THRES    6
#define    MGT_MGCP_PKG_ATM_RQ_EV_SYM_OPER_FAIL    7
#define    MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_C_A_S    0
#define    MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_D_T_M_F_TONE    1
#define    MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_TONE    2
#define    MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_R1_TONE    3
#define    MGT_MGCP_PKG_ATM_SG_RQ_SYM_ENABLE_M_F_R2_TONE    4

#endif  /* GCP_PKG_MGCP_ATM */


#ifdef  GCP_PKG_MGCP_DTMF_DLPL_BASPBX

#define    MGT_MGCP_PKG_B_L_RQ_EV_SYM_OFFHOOK    0
#define    MGT_MGCP_PKG_B_L_RQ_EV_SYM_FLASH_HOOK    1
#define    MGT_MGCP_PKG_B_L_RQ_EV_SYM_ONHOOK    2
#define    MGT_MGCP_PKG_B_L_RQ_EV_SYM_OPER_COMPLT    3
#define    MGT_MGCP_PKG_B_L_RQ_EV_SYM_OPER_FAIL    4
#define    MGT_MGCP_PKG_B_L_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_PKG_B_L_SG_RQ_SYM_BUSY_TONE    0
#define    MGT_MGCP_PKG_B_L_SG_RQ_SYM_DIAL_TONE    1
#define    MGT_MGCP_PKG_B_L_SG_RQ_SYM_RELEASE    2
#define    MGT_MGCP_PKG_B_L_SG_RQ_SYM_RINGING    3
#define    MGT_MGCP_PKG_B_L_SG_RQ_SYM_REORDER_TONE    4
#define    MGT_MGCP_PKG_B_L_SG_RQ_SYM_RINGBACK_TONE    5



#define    MGT_MGCP_PKG_B_L_SG_RQ_EVNT_KNOWN    4

#endif  /* GCP_PKG_MGCP_DTMF_DLPL_BASPBX */




#ifdef  GCP_PKG_MGCP_CNTRY_SPEC_TONE

#define    MGT_MGCP_PKG_C_S_T_RQ_EV_SYM_OPER_COMPLT    0
#define    MGT_MGCP_PKG_C_S_T_RQ_EV_SYM_OPER_FAIL    1
#define    MGT_MGCP_PKG_C_S_T_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ACCEPTANCE_TONE    0
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_BUSY_TONES2    1
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_BUSY_TONES3    2
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_CNFRMN_TONE_I_I    3
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_CONGES_TONES2    4
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_CONGES_TONES3    5
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_DIAL_TONES2    6
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OTHER_DIAL_TONES3    7
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES1    8
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES2    9
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SECOND_DIAL_TONES3    10
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_EXEC_OVER_RIDE_TONE    11
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_END_OF3_PARTY_SERV    12
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_FACILITIES_TONE    13
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_LINE_LOCKOUT    14
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_NUM_UNOBTAINABLE_I_I    15
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_OFFERING_TONE    16
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG2    17
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG3    18
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_PAYPHONE_RECOG4    19
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_QUEUE_TONE    20
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_REFUSAL_TONE    21
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ROUTE_TONE1    22
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_ROUTE_TONE2    23
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE2    24
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE3    25
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_RINGING_TONE4    26
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_SRVC_ACTIVTD_TONE    27
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_VALID_TONE    28
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE1    29
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE2    30
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WAITING_TONE3    31
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_END_OR_PERIOD    32
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_P_I_P_TONE    33
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_TONE_OPER1    34
#define    MGT_MGCP_PKG_C_S_T_SG_RQ_SYM_WARNING_TONE_OPER2    35



#define    MGT_MGCP_PKG_C_S_T_SG_RQ_EVNT_KNOWN    4

#endif  /* GCP_PKG_MGCP_CNTRY_SPEC_TONE */




#ifdef  GCP_PKG_MGCP_DTMF

#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF0    0
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF1    1
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF2    2
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF3    3
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF4    4
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF5    5
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF6    6
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF7    7
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF8    8
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF9    9
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_POUND    10
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_STAR    11
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_A    12
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_B    13
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_C    14
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_D    15
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_LONG_DUR_IND    16
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_DTMF_TONE_DUR    17
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_WILDCARD_MATCH    18
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_OPER_COMPLT    19
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_OPER_FAIL    20
#define    MGT_MGCP_PKG_D_RQ_EV_SYM_INTERDGT_TMR    21
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF0    0
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF1    1
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF2    2
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF3    3
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF4    4
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF5    5
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF6    6
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF7    7
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF8    8
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF9    9
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_POUND    10
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_STAR    11
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_A    12
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_B    13
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_C    14
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_D    15
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_TONE_DUR    16
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_DTMF_OO_SIG    17
#define    MGT_MGCP_PKG_D_SG_RQ_SYM_INTERDGT_TMR    18

#endif  /* GCP_PKG_MGCP_DTMF */




#ifdef  GCP_PKG_MGCP_FXO_LSG_ANALOG

#define    MGT_MGCP_PKG_D_O_RQ_EV_SYM_CALLER_ID    0
#define    MGT_MGCP_PKG_D_O_RQ_EV_SYM_OPER_COMPLT    1
#define    MGT_MGCP_PKG_D_O_RQ_EV_SYM_OPER_FAIL    2
#define    MGT_MGCP_PKG_D_O_RQ_EV_SYM_RELEASE_CALL    3
#define    MGT_MGCP_PKG_D_O_RQ_EV_SYM_RINGING    4
#define    MGT_MGCP_PKG_D_O_RQ_EV_SYM_RELEASE_COMPLT    5
#define    MGT_MGCP_PKG_D_O_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_PKG_D_O_SG_RQ_SYM_OFFHOOK    0
#define    MGT_MGCP_PKG_D_O_SG_RQ_SYM_HOOK_FLASH    1
#define    MGT_MGCP_PKG_D_O_SG_RQ_SYM_ONHOOK    2
#define    MGT_MGCP_PKG_D_O_SG_RQ_SYM_CALL_SETUP    3



#define    MGT_MGCP_PKG_D_O_SG_RQ_EVNT_KNOWN    4

#endif  /* GCP_PKG_MGCP_FXO_LSG_ANALOG */




#ifdef  GCP_PKG_MGCP_DTMF_DIAL_PULSE

#define    MGT_MGCP_PKG_D_T_RQ_EV_SYM_CALL_ANSWER    0
#define    MGT_MGCP_PKG_D_T_RQ_EV_SYM_BLOCK    1
#define    MGT_MGCP_PKG_D_T_RQ_EV_SYM_OPER_COMPLT    2
#define    MGT_MGCP_PKG_D_T_RQ_EV_SYM_OPER_FAIL    3
#define    MGT_MGCP_PKG_D_T_RQ_EV_SYM_RELEASE_CALL    4
#define    MGT_MGCP_PKG_D_T_RQ_EV_SYM_RESUME_CALL    5
#define    MGT_MGCP_PKG_D_T_RQ_EV_SYM_RELEASE_COMPLT    6
#define    MGT_MGCP_PKG_D_T_RQ_EV_SYM_CALL_SETUP    7
#define    MGT_MGCP_PKG_D_T_RQ_EV_SYM_SUSPEND_CALL    8
#define    MGT_MGCP_PKG_D_T_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_PKG_D_T_SG_RQ_SYM_CALL_ANSWER    0
#define    MGT_MGCP_PKG_D_T_SG_RQ_SYM_BLOCK    1
#define    MGT_MGCP_PKG_D_T_SG_RQ_SYM_BUSY_TONE    2
#define    MGT_MGCP_PKG_D_T_SG_RQ_SYM_DIAL_TONE    3
#define    MGT_MGCP_PKG_D_T_SG_RQ_SYM_RELEASE_CALL    4
#define    MGT_MGCP_PKG_D_T_SG_RQ_SYM_RESUME_CALL    5
#define    MGT_MGCP_PKG_D_T_SG_RQ_SYM_RELEASE_COMPLT    6
#define    MGT_MGCP_PKG_D_T_SG_RQ_SYM_REORDER_TONE    7
#define    MGT_MGCP_PKG_D_T_SG_RQ_SYM_RINGBACK_TONE    8
#define    MGT_MGCP_PKG_D_T_SG_RQ_SYM_CALL_SETUP    9
#define    MGT_MGCP_PKG_D_T_SG_RQ_SYM_SUSPEND_CALL    10



#define    MGT_MGCP_PKG_D_T_SG_RQ_EVNT_KNOWN    4

#endif  /* GCP_PKG_MGCP_DTMF_DIAL_PULSE */




#ifdef  GCP_PKG_MGCP_GENERIC_MEDIA

#define    MGT_MGCP_PKG_G_RQ_EV_SYM_FAX_TONE_DETECT    0
#define    MGT_MGCP_PKG_G_RQ_EV_SYM_LONG_DUR_CONN    1
#define    MGT_MGCP_PKG_G_RQ_EV_SYM_MODEM_DETECT    2
#define    MGT_MGCP_PKG_G_RQ_EV_SYM_OPER_COMPLT    3
#define    MGT_MGCP_PKG_G_RQ_EV_SYM_OPER_FAIL    4
#define    MGT_MGCP_PKG_G_RQ_EV_SYM_RINGBACK_TONE    5
#define    MGT_MGCP_PKG_G_RQ_EV_SYM_PATTERN_DETECT    6
#define    MGT_MGCP_PKG_G_SG_RQ_SYM_CONFIRM_TONE    0
#define    MGT_MGCP_PKG_G_SG_RQ_SYM_CONGESTION_TONE    1
#define    MGT_MGCP_PKG_G_SG_RQ_SYM_INTERCEPT_TONE    2
#define    MGT_MGCP_PKG_G_SG_RQ_SYM_PREEMPTION_TONE    3
#define    MGT_MGCP_PKG_G_SG_RQ_SYM_RINGBACK_TONE    4
#define    MGT_MGCP_PKG_G_SG_RQ_SYM_RINGBACK    5
#define    MGT_MGCP_PKG_G_SG_RQ_SYM_PATTERN_DETECT    6

#endif  /* GCP_PKG_MGCP_GENERIC_MEDIA */
 



#ifdef  GCP_PKG_MGCP_HANDSET_EMUL

#define    MGT_MGCP_PKG_H_RQ_EV_SYM_ADSI_DISPLAY    0
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_ANSWER_TONE    1
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_BUSY_TONE    2
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_CALLER_ID    3
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_DIAL_TONE    4
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_ERROR_TONE    5
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_OFF_HOOK_TRANS    6
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_ON_HOOK_TRANS    7
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_FLASH_HOOK    8
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_TONE_ON_HOLD    9
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_MSG_WAITNG_IND    10
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_OPER_COMPLT    11
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_OFF_HOOK_WARNING_TONE    12
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_REPORT_FAIL    13
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_RINGING    14
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING0    15
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING1    16
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING2    17
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING3    18
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING4    19
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING5    20
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING6    21
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCTIVE_RINGING7    22
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_REORDER_TONE    23
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_RINGSPLASH    24
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_STUTTER_DIALTONE    25
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_SIT_TONE    26
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_ALERTING_TONE    27
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_VIS_MSG_WAITNG_IND    28
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_CALL_WAITNG_TONE    29
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_RECORDER_WARNING_TONE    30
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_CALLING_CARD_SERV_TONE    31
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_PROMPT_TONE    32
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_NETWORK_BUSY    33
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_DISTINCT_TONE_PATTERN    34
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_LINE_SIDE_ANSWER_SUP    35
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_NETWORK_DIS_CONN    36
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL1    37
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL2    38
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL3    39
#define    MGT_MGCP_PKG_H_RQ_EV_SYM_ALTERNATIVE_CALL4    40
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_ADSI_DISPLAY    0
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_ANSWER_TONE    1
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_BUSY_TONE    2
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_CALLER_ID    3
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_DIAL_TONE    4
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_ERROR_TONE    5
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_OFF_HOOK_TRANS    6
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_ON_HOOK_TRANS    7
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_FLASH_HOOK    8
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_TONE_ON_HOLD    9
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_MSG_WAITNG_IND    10
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_OFF_HOOK_WARNING_TONE    11
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_RINGING    12
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING0    13
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING1    14
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING2    15
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING3    16
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING4    17
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING5    18
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING6    19
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCTIVE_RINGING7    20
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_REORDER_TONE    21
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_RINGSPLASH    22
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_STUTTER_DIALTONE    23
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_SIT_TONE    24
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_ALERTING_TONE    25
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_VIS_MSG_WAITNG_IND    26
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_CALL_WAITNG_TONE    27
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_RECORDER_WARNING_TONE    28
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_CALLING_CARD_SERV_TONE    29
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_PROMPT_TONE    30
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_NETWORK_BUSY    31
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_DISTINCT_TONE_PATTERN    32
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_LINE_SIDE_ANSWER_SUP    33
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_NETWORK_DIS_CONN    34
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL1    35
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL2    36
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL3    37
#define    MGT_MGCP_PKG_H_SG_RQ_SYM_ALTERNATIVE_CALL4    38

#endif  /* GCP_PKG_MGCP_HANDSET_EMUL */

 


#ifdef  GCP_PKG_MGCP_LINE

#define    MGT_MGCP_PKG_L_RQ_EV_SYM_ANSWER_TONE    0
#define    MGT_MGCP_PKG_L_RQ_EV_SYM_ERROR_TONE    1
#define    MGT_MGCP_PKG_L_RQ_EV_SYM_OFF_HOOK_TRANS    2
#define    MGT_MGCP_PKG_L_RQ_EV_SYM_ON_HOOK_TRANS    3
#define    MGT_MGCP_PKG_L_RQ_EV_SYM_FLASH_HOOK    4
#define    MGT_MGCP_PKG_L_RQ_EV_SYM_OPER_COMPLT    5
#define    MGT_MGCP_PKG_L_RQ_EV_SYM_OPER_FAIL    6
#define    MGT_MGCP_PKG_L_RQ_EV_SYM_PROMPT_TONE    7
#define    MGT_MGCP_PKG_L_RQ_EV_SYM_NETWORK_BUSY    8
#define    MGT_MGCP_PKG_L_RQ_EV_SYM_DISTINCT_TONE_PATTERN    9
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_ADSI_DISPLAY    0
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_ANSWER_TONE    1
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_BUSY_TONE    2
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_CALLER_ID    3
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_DIAL_TONE    4
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_ERROR_TONE    5
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_ON_HOLD_TONE    6
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_LINE_SIDE_ANSWER_SUP    7
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_MSG_WAITNG_IND    8
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_NETWORK_DIS_CONN  9
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_OFF_HOOK_WARNING_TONE    10
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_RINGING    11
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING0    12
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING1    13
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING2    14
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING3    15
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING4    16
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING5    17
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING6    18
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCTIVE_RINGING7    19
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_REORDER_TONE    20
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_RINGSPLASH    21
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_SPECIAL_INFO_TONE    22
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_STUTTER_DIALTONE    23
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_ALERTING_TONE    24
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_VISUAL_MSG    25
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_CALL_WAITNG_TONE    26
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL1    27
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL2    28
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL3    29
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_ALTERNATIVE_CALL4    30
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_RECORDER_WARNING_TONE    31
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_CALLING_CARD_SERVICE_TONE    32
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_PROMPT_TONE    33
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_NETWORK_BUSY    34
#define    MGT_MGCP_PKG_L_SG_RQ_SYM_DISTINCT_TONE_PATTERN    35

#endif  /* GCP_PKG_MGCP_LINE */



#ifdef  GCP_PKG_MGCP_NAM_MF_GRP_DE

#define    MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_ANSWER    0
#define    MGT_MGCP_PKG_M_D_RQ_EV_SYM_ACK_WINK    1
#define    MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_BLOCK    2
#define    MGT_MGCP_PKG_M_D_RQ_EV_SYM_INFO_DGTS    3
#define    MGT_MGCP_PKG_M_D_RQ_EV_SYM_OPER_COMPLT    4
#define    MGT_MGCP_PKG_M_D_RQ_EV_SYM_OPER_FAIL    5
#define    MGT_MGCP_PKG_M_D_RQ_EV_SYM_RELEASE_CALL    6
#define    MGT_MGCP_PKG_M_D_RQ_EV_SYM_RESUME_CALL    7
#define    MGT_MGCP_PKG_M_D_RQ_EV_SYM_RELEASE_COMPLT    8
#define    MGT_MGCP_PKG_M_D_RQ_EV_SYM_CALL_SETUP    9
#define    MGT_MGCP_PKG_M_D_RQ_EV_SYM_SUSPEND_CALL    10
#define    MGT_MGCP_PKG_M_D_RQ_EV_SYM_START_WINK    11
#define    MGT_MGCP_PKG_M_D_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_ANSWER    0
#define    MGT_MGCP_PKG_M_D_SG_RQ_SYM_ACK_WINK    1
#define    MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_BLOCK    2
#define    MGT_MGCP_PKG_M_D_SG_RQ_SYM_BUSY_TONE    3
#define    MGT_MGCP_PKG_M_D_SG_RQ_SYM_CONTINUE_WINK    4
#define    MGT_MGCP_PKG_M_D_SG_RQ_SYM_INFO_DGTS    5
#define    MGT_MGCP_PKG_M_D_SG_RQ_SYM_RELEASE_CALL    6
#define    MGT_MGCP_PKG_M_D_SG_RQ_SYM_RESUME_CALL    7
#define    MGT_MGCP_PKG_M_D_SG_RQ_SYM_RELEASE_COMPLETE    8
#define    MGT_MGCP_PKG_M_D_SG_RQ_SYM_REORDER_TONE    9
#define    MGT_MGCP_PKG_M_D_SG_RQ_SYM_RINGBACK_TONE    10
#define    MGT_MGCP_PKG_M_D_SG_RQ_SYM_CALL_SETUP    11
#define    MGT_MGCP_PKG_M_D_SG_RQ_SYM_SUSPEND_CALL    12



#define    MGT_MGCP_PKG_M_D_SG_RQ_EVNT_KNOWN    4

#endif  /* GCP_PKG_MGCP_NAM_MF_GRP_DE */




#ifdef  GCP_PKG_MGCP_FGD_OP_SR_SIGOUT

#define    MGT_MGCP_PKG_M_O_RQ_EV_SYM_CALL_ANSWER    0
#define    MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_COMPLT    1
#define    MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_FAIL    2
#define    MGT_MGCP_PKG_M_O_RQ_EV_SYM_OPER_RINGBACK    3
#define    MGT_MGCP_PKG_M_O_RQ_EV_SYM_REVERSE_MAKE_BUSY    4
#define    MGT_MGCP_PKG_M_O_RQ_EV_SYM_RELEASE_CALL    5
#define    MGT_MGCP_PKG_M_O_RQ_EV_SYM_RELEASE_COMPLETE    6
#define    MGT_MGCP_PKG_M_O_RQ_EV_SYM_START_WINK    7
#define    MGT_MGCP_PKG_M_O_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_PKG_M_O_SG_RQ_SYM_OPER_RECALL    0
#define    MGT_MGCP_PKG_M_O_SG_RQ_SYM_RELEASE_CALL    1
#define    MGT_MGCP_PKG_M_O_SG_RQ_SYM_RESUME_CALL    2
#define    MGT_MGCP_PKG_M_O_SG_RQ_SYM_RELEASE_COMPLETE    3
#define    MGT_MGCP_PKG_M_O_SG_RQ_SYM_CALL_SETUP    4
#define    MGT_MGCP_PKG_M_O_SG_RQ_SYM_SUSPEND_CALL    5



#define    MGT_MGCP_PKG_M_O_SG_RQ_EVNT_KNOWN    4

#endif  /* GCP_PKG_MGCP_FGD_OP_SR_SIGOUT */




#ifdef  GCP_PKG_MGCP_MF_WINKSTART

#define    MGT_MGCP_PKG_M_S_RQ_EV_SYM_CALL_ANSWER    0
#define    MGT_MGCP_PKG_M_S_RQ_EV_SYM_BLOCK    1
#define    MGT_MGCP_PKG_M_S_RQ_EV_SYM_INFO_DGTS    2
#define    MGT_MGCP_PKG_M_S_RQ_EV_SYM_OPER_COMPLT    3
#define    MGT_MGCP_PKG_M_S_RQ_EV_SYM_OPER_FAIL    4
#define    MGT_MGCP_PKG_M_S_RQ_EV_SYM_RELEASE_CALL    5
#define    MGT_MGCP_PKG_M_S_RQ_EV_SYM_RESUME_CALL    6
#define    MGT_MGCP_PKG_M_S_RQ_EV_SYM_RELEASE_COMPLETE    7
#define    MGT_MGCP_PKG_M_S_RQ_EV_SYM_CALL_SETUP    8
#define    MGT_MGCP_PKG_M_S_RQ_EV_SYM_SUSPEND_CALL    9
#define    MGT_MGCP_PKG_M_S_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_PKG_M_S_SG_RQ_SYM_CALL_ANSWER    0
#define    MGT_MGCP_PKG_M_S_SG_RQ_SYM_BLOCK    1
#define    MGT_MGCP_PKG_M_S_SG_RQ_SYM_BUSY_TONE    2
#define    MGT_MGCP_PKG_M_S_SG_RQ_SYM_RELEASE_CALL    3
#define    MGT_MGCP_PKG_M_S_SG_RQ_SYM_RESUME_CALL    4
#define    MGT_MGCP_PKG_M_S_SG_RQ_SYM_RELEASE_COMPLETE    5
#define    MGT_MGCP_PKG_M_S_SG_RQ_SYM_REORDER_TONE    6
#define    MGT_MGCP_PKG_M_S_SG_RQ_SYM_RINGBACK_TONE    7
#define    MGT_MGCP_PKG_M_S_SG_RQ_SYM_CALL_SETUP    8
#define    MGT_MGCP_PKG_M_S_SG_RQ_SYM_SUSPEND_CALL    9



#define    MGT_MGCP_PKG_M_S_SG_RQ_EVNT_KNOWN    4

#endif  /* GCP_PKG_MGCP_MF_WINKSTART */




#ifdef  GCP_PKG_MGCP_RTP

#define    MGT_MGCP_PKG_R_RQ_EV_SYM_ICMP_UNREACHABLE    0
#define    MGT_MGCP_PKG_R_RQ_EV_SYM_RTP_OR_RTCP_TIMEOUT    1
#define    MGT_MGCP_PKG_R_RQ_EV_SYM_USED_CODEC_CHNGD    2
#define    MGT_MGCP_PKG_R_RQ_EV_SYM_SAMPL_RATE_CHNGD    3
#define    MGT_MGCP_PKG_R_RQ_EV_SYM_JITTER_BUFF_SIZE_CHNGD    4
#define    MGT_MGCP_PKG_R_RQ_EV_SYM_PCKT_LOSS_EXCEEDED    5
#define    MGT_MGCP_PKG_R_RQ_EV_SYM_QUALITY_ALERT    6
#define    MGT_MGCP_PKG_R_RQ_EV_SYM_CONTINUITY_TONE    7
#define    MGT_MGCP_PKG_R_RQ_EV_SYM_CONTINUITY_TEST    8
#define    MGT_MGCP_PKG_R_RQ_EV_SYM_OPER_COMPLT    9
#define    MGT_MGCP_PKG_R_RQ_EV_SYM_OPER_FAIL    10
#define    MGT_MGCP_PKG_R_RQ_EV_SYM_MEDIA_START    11
#define    MGT_MGCP_PKG_R_SG_RQ_SYM_CONTINUITY_TONE    0
#define    MGT_MGCP_PKG_R_SG_RQ_SYM_CONTINUITY_TEST    1

#endif  /* GCP_PKG_MGCP_RTP */

 


#ifdef  GCP_PKG_MGCP_RES_RESERV

#define    MGT_MGCP_PKG_R_E_S_RQ_EV_SYM_RESOURCE_LOST    0
#define    MGT_MGCP_PKG_R_E_S_RQ_EV_SYM_RESOURCE_ERROR    1
#define    MGT_MGCP_PKG_R_E_S_RQ_EV_EVNT_KNOWN    4

#endif  /* GCP_PKG_MGCP_RES_RESERV */




#ifdef  GCP_PKG_MGCP_SCRIPT

#define    MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_OPER_COMPLT    0
#define    MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_OPER_FAIL    1
#define    MGT_MGCP_PKG_SCRIPT_RQ_EV_SYM_INTERMEDIATE_RES    2
#define    MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_JAVA_SCRIPT    0
#define    MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_PERL_SCRIPT    1
#define    MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_T_C_L_SCRIPT    2
#define    MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_X_M_L_SCRIPT    3
#define    MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_LOAD_AND_RUN_V_X_M_L_DOC    4
#define    MGT_MGCP_PKG_SCRIPT_SG_RQ_SYM_INTERMEDIATE_RES    5

#endif  /* GCP_PKG_MGCP_SCRIPT */
 


#ifdef  GCP_PKG_MGCP_SIGLST

#define    MGT_MGCP_PKG_S_L_RQ_EV_SYM_OPER_COMPLT    0
#define    MGT_MGCP_PKG_S_L_RQ_EV_SYM_OPER_FAIL    1
#define    MGT_MGCP_PKG_S_L_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_PKG_S_L_SG_RQ_SYM_SIG_LST    0



#define    MGT_MGCP_PKG_S_L_SG_RQ_EVNT_KNOWN    4

#endif  /* GCP_PKG_MGCP_SIGLST */




#ifdef  GCP_PKG_MGCP_SUPPL_SRVS_TONE

#define    MGT_MGCP_PKG_S_S_T_RQ_EV_SYM_OPER_COMPLT    0
#define    MGT_MGCP_PKG_S_S_T_RQ_EV_SYM_OPER_FAIL    1
#define    MGT_MGCP_PKG_S_S_T_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CONFERENCE_DEPART    0
#define    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CONFERENCE_JOIN    1
#define    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_COMFORT_TONE    2
#define    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_CALLER_WAITING_TONE    3
#define    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_NEGATIVE_IND    4
#define    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_NUMBER_UNOBTAINABLE    5
#define    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_PAYPHONE_RECOG    6
#define    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_PAY_TONE    7
#define    MGT_MGCP_PKG_S_S_T_SG_RQ_SYM_ON_HOLD_TONE    8



#define    MGT_MGCP_PKG_S_S_T_SG_RQ_EVNT_KNOWN    4

#endif  /* GCP_PKG_MGCP_SUPPL_SRVS_TONE */




#ifdef  GCP_PKG_MGCP_TRUNK

#define    MGT_MGCP_PKG_T_RQ_EV_SYM_CONTINUITY_TONE    0
#define    MGT_MGCP_PKG_T_RQ_EV_SYM_CONTINUITY_TEST    1
#define    MGT_MGCP_PKG_T_RQ_EV_SYM_NEW_MILLIWATT_TONE    2
#define    MGT_MGCP_PKG_T_RQ_EV_SYM_NEWEST_MILLIWATT_TONE    3
#define    MGT_MGCP_PKG_T_RQ_EV_SYM_OPER_COMPLT    4
#define    MGT_MGCP_PKG_T_RQ_EV_SYM_REPORT_FAILURE    5
#define    MGT_MGCP_PKG_T_RQ_EV_SYM_OLD_MILLIWATT_TONE    6
#define    MGT_MGCP_PKG_T_RQ_EV_SYM_REORDER_TONE    7
#define    MGT_MGCP_PKG_T_RQ_EV_SYM_SPECIAL_INFO_TONE    8
#define    MGT_MGCP_PKG_T_RQ_EV_SYM_TEST_LINE    9
#define    MGT_MGCP_PKG_T_RQ_EV_SYM_TEST_PATTERN    10
#define    MGT_MGCP_PKG_T_RQ_EV_SYM_NO_CIRCUIT    11
#define    MGT_MGCP_PKG_T_RQ_EV_SYM_ANSWER_SUPERVIS    12
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TONE    0
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TEST    1
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_LOOPBACK    2
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_NEW_MILLIWATT_TONE    3
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_NEWEST_MILLIWATT_TONE    4
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_OLD_MILLIWATT_TONE    5
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_QUIET_TERMINATION    6
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_REORDER_TONE    7
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_SPECIAL_INFO_TONE    8
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_TEST_LINE    9
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_TEST_PATTERN    10
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_NO_CIRCUIT    11
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_ANSWER_SUPERVIS    12
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_BLOCKING    13
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_BUSY    14
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_CONTINUITY_TRSPDR    15
#define    MGT_MGCP_PKG_T_SG_RQ_SYM_PERM_SIG_TONE    16

#endif  /* GCP_PKG_MGCP_TRUNK */




#ifdef  GCP_PKG_MGCP_FAX


/*
*     Local Connection Options  ->
*/

#define   MGT_MGCP_CO_PKG_FXR_FAX_HNDLNG   1

/*
*     Connection Parameter  ->
*/

#define   MGT_MGCP_CP_PKG_FXR_NUM_FAX_PGS_SENT   1
#define   MGT_MGCP_CP_PKG_FXR_NUM_FAX_PGS_RCVD   2
#define    MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_GW_CNTRLD_FAX    0
#define    MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_NO_SP_FAX_HNDLNG    1
#define    MGT_MGCP_PKG_F_X_R_RQ_EV_SYM_T38_FAX_RELAY    2
#define    MGT_MGCP_PKG_F_X_R_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_CO_PKG_F_X_R_FAX_HNDLNG    1
#define    MGT_MGCP_CP_PKG_PKG_F_X_R_NUM_FAX_PGS_SENT    1
#define    MGT_MGCP_CP_PKG_PKG_F_X_R_NUM_FAX_PGS_RCVD    2

#endif   /* GCP_PKG_MGCP_FAX */


#ifdef  GCP_PKG_MGCP_ISUP_TRUNK

#define    MGT_MGCP_PKG_I_T_RQ_EV_SYM_CONTINUITY_TONE1    0
#define    MGT_MGCP_PKG_I_T_RQ_EV_SYM_CONTINUITY_TONE2    1
#define    MGT_MGCP_PKG_I_T_RQ_EV_SYM_FAX_TONE    2
#define    MGT_MGCP_PKG_I_T_RQ_EV_SYM_LONG_DUR_CONN    3
#define    MGT_MGCP_PKG_I_T_RQ_EV_SYM_MEDIA_START    4
#define    MGT_MGCP_PKG_I_T_RQ_EV_SYM_MODEM_TONE    5
#define    MGT_MGCP_PKG_I_T_RQ_EV_SYM_OPER_COMPLT    6
#define    MGT_MGCP_PKG_I_T_RQ_EV_SYM_OPER_FAIL    7
#define    MGT_MGCP_PKG_I_T_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_PKG_I_T_SG_RQ_SYM_CONTINUITY_TONE1    0
#define    MGT_MGCP_PKG_I_T_SG_RQ_SYM_CONTINUITY_TONE2    1
#define    MGT_MGCP_PKG_I_T_SG_RQ_SYM_REORDER_TONE    2
#define    MGT_MGCP_PKG_I_T_SG_RQ_SYM_RINGBACK_TONE    3



#define    MGT_MGCP_PKG_I_T_SG_RQ_EVNT_KNOWN    4

#endif  /* GCP_PKG_MGCP_ISUP_TRUNK */




#ifdef  GCP_PKG_MGCP_MF

#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF0    0
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF1    1
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF2    2
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF3    3
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF4    4
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF5    5
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF6    6
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF7    7
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF8    8
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF9    9
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_WILD_CARD_MATCH    10
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_INTERDIG_TMR    11
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K0_OR_KP    12
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K1    13
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_K2    14
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S0_OR_ST    15
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S1    16
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S2    17
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_MF_S3    18
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_WINK    19
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_WINK_OFF    20
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_INCOMING_SEIZURE    21
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_RET_SEIZURE    22
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_UNSEIZE_CKT    23
#define    MGT_MGCP_PKG_M_RQ_EV_SYM_RPT_FAILURE    24
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF0    0
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF1    1
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF2    2
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF3    3
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF4    4
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF5    5
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF6    6
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF7    7
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF8    8
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF9    9
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_INTERDIG_TMR    10
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K0_OR_KP    11
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K1    12
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_K2    13
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S0_OR_ST    14
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S1    15
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S2    16
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_MF_S3    17
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_WINK    18
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_WINK_OFF    19
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_INCOMING_SEIZURE    20
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_RET_SEIZURE    21
#define    MGT_MGCP_PKG_M_SG_RQ_SYM_UNSEIZE_CKT    22

#endif  /* GCP_PKG_MGCP_MF */
 


#ifdef  GCP_PKG_MGCP_MF_TERM_PROTO

#define    MGT_MGCP_PKG_M_T_RQ_EV_SYM_INFO_DGTS    0
#define    MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_COMPLT    1
#define    MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_FAIL    2
#define    MGT_MGCP_PKG_M_T_RQ_EV_SYM_OPER_INTRPT    3
#define    MGT_MGCP_PKG_M_T_RQ_EV_SYM_RELEASE_CALL    4
#define    MGT_MGCP_PKG_M_T_RQ_EV_SYM_RELEASE_COMPLETE    5
#define    MGT_MGCP_PKG_M_T_RQ_EV_SYM_CALL_SETUP    6
#define    MGT_MGCP_PKG_M_T_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_PKG_M_T_SG_RQ_SYM_CALL_ANSWER    0
#define    MGT_MGCP_PKG_M_T_SG_RQ_SYM_BUSY_TONE    1
#define    MGT_MGCP_PKG_M_T_SG_RQ_SYM_HOOK_FLASH    2
#define    MGT_MGCP_PKG_M_T_SG_RQ_SYM_PERM_SIG_TONE    3
#define    MGT_MGCP_PKG_M_T_SG_RQ_SYM_RELEASE_CALL    4
#define    MGT_MGCP_PKG_M_T_SG_RQ_SYM_RESUME_CALL    5
#define    MGT_MGCP_PKG_M_T_SG_RQ_SYM_RELEASE_COMPLETE    6
#define    MGT_MGCP_PKG_M_T_SG_RQ_SYM_REORDER_TONE    7
#define    MGT_MGCP_PKG_M_T_SG_RQ_SYM_SUSPEND_CALL    8



#define    MGT_MGCP_PKG_M_T_SG_RQ_EVNT_KNOWN    4

#endif  /* GCP_PKG_MGCP_MF_TERM_PROTO */




#ifdef  GCP_PKG_MGCP_NAS_DATAOUT

/*
*     Local Connection Options  ->
*/

#define   MGT_MGCP_CO_PKG_NAO_DATA_USR_HNDL   1
#define    MGT_MGCP_PKG_N_A_O_RQ_EV_SYM_OUT_CALL_REQ    0
#define    MGT_MGCP_PKG_N_A_O_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_CO_PKG_N_A_O_DATA_USR_HNDL    1

#endif  /* GCP_PKG_MGCP_NAS_DATAOUT */



#ifdef  GCP_PKG_MGCP_BASIC_NAS

/*
*     Local Connection Options  ->
*/

#define   MGT_MGCP_CO_PKG_NAS_CALLD_PARTY_NUM   1
#define   MGT_MGCP_CO_PKG_NAS_CALLNG_PARTY_NUM   2
#define   MGT_MGCP_CO_PKG_NAS_BRR_TYPE   3

/*
*     Connection Mode  ->
*/

#define   MGT_MGCP_CONN_MODE_PKG_NAS_EXTN_NAME_DATA   1

#define    MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_AUTH_SUCCD    0
#define    MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_AUTH_DENIED    1
#define    MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_CALL_REQ    2
#define    MGT_MGCP_PKG_N_A_S_RQ_EV_SYM_NAS_FAIL    3
#define    MGT_MGCP_PKG_N_A_S_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_CO_PKG_N_A_S_CALLD_PARTY_NUM    1
#define    MGT_MGCP_CO_PKG_N_A_S_CALLNG_PARTY_NUM    2
#define    MGT_MGCP_CO_PKG_N_A_S_BRR_TYPE    3
#define    MGT_MGCP_CM_PKG_N_A_S_VAL_DATA    1

#endif  /* GCP_PKG_MGCP_BASIC_NAS */


#ifdef  GCP_PKG_MGCP_ADSI

#define    MGT_MGCP_PKG_S_SG_RQ_SYM_ADSI_DISPLAY    0

#endif /* GCP_PKG_MGCP_ADSI */


/* addition of new packages -
   Audio server packages - BAU & AAU
 */

#ifdef GCP_PKG_MGCP_AU_SRVR

#define    MGT_MGCP_PKG_B_A_U_RQ_EV_SYM_OPER_COMPLT    0
#define    MGT_MGCP_PKG_B_A_U_RQ_EV_SYM_OPER_FAIL      1
#define    MGT_MGCP_PKG_B_A_U_RQ_EV_EVNT_KNOWN         4

#define    MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_MNG_AUDIO      0
#define    MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_ANNC      1
#define    MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_COLLECT   2
#define    MGT_MGCP_PKG_B_A_U_SG_RQ_SYM_PLAY_RECORD    3

#define    MGT_MGCP_PKG_B_A_U_SG_RQ_EVNT_KNOWN         4

#endif /* GCP_PKG_MGCP_AU_SRVR */
     
/*
 * [TEL]: Definitions for Display XML Package
 */
#ifdef GCP_PKG_MGCP_DISPLAY_XML

#define    MGT_MGCP_PKG_X_M_L_RQ_EV_SYM_XML_DATA    0
#define    MGT_MGCP_PKG_X_M_L_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_PKG_X_M_L_SG_RQ_SYM_XML_DATA    0
#define    MGT_MGCP_PKG_X_M_L_SG_RQ_EVNT_KNOWN    4

#endif /* GCP_PKG_MGCP_DISPLAY_XML */

/*
 * [TEL]: Definitions for Feature Key Package 
 */
#ifdef GCP_PKG_MGCP_FEATURE_KEY

#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY1    0
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY2    1
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY3    2
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY4    3
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY5    4
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY6    5
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY7    6
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY8    7
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY9    8
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY10    9
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY11    10
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY12    11
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY13    12
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY14    13
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY15    14
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY16    15
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY17    16
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY18    17
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY19    18
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY20    19
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY21    20
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY22    21
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY23    22
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY24    23
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY25    24
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY26    25
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY27    26
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY28    27
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY29    28
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY30    29
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY31    30
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY32    31
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY33    32
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY34    33
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY35    34
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY36    35
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY37    36
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY38    37
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY39    38
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY40    39
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY41    40
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY42    41
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY43    42
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY44    43
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY45    44
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY46    45
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY47    46
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY48    47
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY49    48
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY50    49
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY51    50
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY52    51
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY53    52
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY54    53
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY55    54
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY56    55
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY57    56
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY58    57
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY59    58
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY60    59
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY61    60
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY62    61
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY63    62
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY64    63
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY65    64
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY66    65
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY67    66
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY68    67
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY69    68
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY70    69
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY71    70
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY72    71
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY73    72
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY74    73
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY75    74
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY76    75
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY77    76
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY78    77
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY79    78
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY80    79
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY81    80
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY82    81
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY83    82
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY84    83
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY85    84
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY86    85
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY87    86
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY88    87
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY89    88
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY90    89
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY91    90
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY92    91
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY93    92
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY94    93
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY95    94
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY96    95
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY97    96
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY98    97
#define    MGT_MGCP_PKG_K_Y_RQ_EV_SYM_FEATURE_KEY99    98
#define    MGT_MGCP_PKG_K_Y_RQ_EV_EVNT_KNOWN    4
#define    MGT_MGCP_PKG_K_Y_SG_RQ_SYM_KEY_STATE    0
#define    MGT_MGCP_PKG_K_Y_SG_RQ_SYM_SET_LABEL    1
#define    MGT_MGCP_PKG_K_Y_SG_RQ_EVNT_KNOWN    4

#endif /* GCP_PKG_MGCP_FEATURE_KEY */

/*
 * [TEL]: Definitions for Business Phone Package
 */
#ifdef  GCP_PKG_MGCP_BUS_PHONE

#define    MGT_MGCP_PKG_B_P_SG_RQ_SYM_FRC_OFF_HK    0
#define    MGT_MGCP_PKG_B_P_SG_RQ_SYM_FRC_ON_HK    1
#define    MGT_MGCP_PKG_B_P_SG_RQ_SYM_BEEP    2
#define    MGT_MGCP_PKG_B_P_SG_RQ_EVNT_KNOWN    4

#endif /* GCP_PKG_MGCP_BUS_PHONE */

/*
 * [TEL]: Definitions for Base Package
 */
#ifdef  GCP_PKG_MGCP_BASE 

#define   MGT_MGCP_PKG_B_EP_PST_EVTS   1
#define   MGT_MGCP_PKG_B_EP_NOT_FN_ST   2
#define    MGT_MGCP_PKG_B_RQ_EV_SYM_EM_RQNT_FAIL    0
#define    MGT_MGCP_PKG_B_RQ_EV_SYM_OBS_EVTS_FUL    1
#define    MGT_MGCP_PKG_B_RQ_EV_SYM_QRTIN_BUF_OF    2

#endif /* GCP_PKG_MGCP_BASE */

#endif /* GCP_MGCP */
#endif /* __MGCP_PDB_H__*/
 



/********************************************************************30**

         End of file:     mgcp_pdb.h@@/main/mgcp_rel_1.5_mnt/1 - Wed Apr 27 11:52:48 2005

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      ra   1. GCP 1.3 release
/main/1    mg003.103  ra   1. Addition of support for Packet Cable Audio
                              Server packges - BAU & AAU. New hash defines
                              added.
/main/2      ---     TEL   1. Added Hash defines for the following 
                              MGCP packages.
                              1. Base package. 
                              2. Business phone package. 
                              3. Feature Key package. 
                              4. Display XML package. 
/main/2      ---      ka   1. Changes for Release v 1.4
/main/3      ---      pk   1. GCP 1.5 release
           mg002.105  ps   1. Removed patch reference for 1.3
*********************************************************************91*/
