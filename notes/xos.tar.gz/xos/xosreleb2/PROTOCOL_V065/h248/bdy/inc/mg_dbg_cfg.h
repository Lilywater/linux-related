/**********************************************************************

    Name:   mgco_cfg.h - Debug print for the GCP

    Type:   C include file

    Desc:   #define and macros for the GCP layer Debug print

    File:   mgco_cfg.h

    Sid:    mgco_cfg.h - 2006/04/04

    Created by: changdawei

**********************************************************************/

#ifndef _MGCO_CFG_H_
#define _MGCO_CFG_H_
/*-------------------------include file(s)------------------------------*/
/*  #include "sysInsidePub.h" */


/*--------Extern Functions------------------------*/
#ifdef __cplusplus
extern "C" {
#endif

extern VOID mgcoPrintMgCb(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern VOID mgcoPrintSSAPLst(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern VOID mgcoPrintPeerLst(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern VOID mgcoPrintTSAPLst(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern VOID mgcoPrintGenCfg(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern VOID mgcoPrintPeerLstSts(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
extern VOID showTraceLevel(CLI_ENV *pCliEnv);
extern VOID mgSetTraceLevel(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);

#ifdef __cplusplus
}
#endif

#endif /* _MGCO_CFG_H_ */

