/*************************************************
  Copyright (C), 2006-0405, XINWEI Co., Ltd.
  File name:  sipapi.h
  Module:	sip Stack Api
  Author:  chendh
  Version: 1.0
  Created on : 2006-07-05
  Description:
	This files define MAC used by compiling stack.
  
  Modify History:
		1. Date:        Author:         Modification:
*************************************************/

#ifndef __SIP_MAC_H__
#define __SIP_MAC_H__

#ifdef WIN32

#define CPU		PENTIUM
#define WIN32
#define SM
#define SM_SS7
#define HI
#define HI_REL_1_4
#define CMINETFLATBUF
#define LCHIMILHI
#define LCLHI
#define LCSMHIMILHI
#define HI_MULTI_THREADED
#define LCHIUIHIT
#define LCHIT
#define TUCL_OAM_DISABLED
#define SO
#define CMFILE_REORG_1
#define SO_USE_UDP_SRVR
#define CM_NAPTR
#define CM_SDP_V_2
#define CM_SDP_V_3
#define CM_ABNF_V_1_2
#define SO_USE_MD5
#define HI_REL_1_4
#define CM_INET2
#define SO_SUCFG_SUPPORT
#define SO_UA
#define LWLCSOUISOT
#define LWLCSVLISOT
#define LCSOLIHIT
#define LCHIUIHIT
#define DEBUGP
#define CMINETDBG
#define CM_ABNF_DBG
#define CP_UA_IF_TYPE_SAG
#define WIN32
#define ANSI
#define NS
#define SS_OLD_THREAD
#define SS
#define WIN32_LEAN_AND_MEAN
#define NOGDI
#define SS_DRVR_SUPPORT
#define NOFILESYS
#define CMFILE_REORG_1
#define CONSTDIO
#define XW_SS
#define DEBUG
#define NEED_TRI_SSI
#define _DEBUG
#define _MBCS
/* #define CP_MASS_MEM*/

#else
/* linux */
#define UNIX 
#define ANSI 
#define SS_MT
#define SS
#define SS_LINUX 
#define SUNOS 
#define I86HM 
#define STDIO_INCLD 
#define _REENTRANT 
#define _POSIX_C_SOURCE=199309L 
#define __EXTENSIONS__ 
#define SS_DRVR_SUPPORT 
#define NOFILESYS  
#define CMFILE_REORG_1 
#define CONSTDIO  
#define DEBUGP 
#define SM 
#define SM_SS7    
#define HI 
#define CMINETDBG 
#define HI_REL_1_4  
#define CMINETFLATBUF 
#define LCHIMILHI 
#define LCLHI 
#define LCSMHIMILHI 
#define HI_MULTI_THREADED 
#define LCHIUIHIT #define LCHIT 
#define TUCL_OAM_DISABLED    
#define SO 
#define CMFILE_REORG_1 
#define SO_USE_UDP_SRVR 
#define CM_NAPTR 
#define CM_SDP_V_3 
#define CM_ABNF_V_1_2 
#define SO_USE_MD5 
#define HI_REL_1_4 
#define CM_INET2  
#define SO_SUCFG_SUPPORT 
#define LWLCSOUISOT 
#define LWLCSVLISOT 
#define LCSOLIHIT 
#define LCHIUIHIT     
#define DEBUGP 
#define CMINETDBG 
#define CM_ABNF_DBG              
#define LINUX 
#define XW_SS 
#define CP_PRODUCT=XW_SS 
#define DEBUG 
#define NEED_TRI_SSI 
#define SM #define SM_SS7    
#define HI 
#define CMINETDBG 
#define HI_REL_1_4  
#define CMINETFLATBUF 
#define LCHIMILHI 
#define LCLHI 
#define LCSMHIMILHI 
#define HI_MULTI_THREADED 
#define LCHIUIHIT 
#define LCHIT 
#define TUCL_OAM_DISABLED    
#define CMFILE_REORG_1 
#define SO_USE_UDP_SRVR 
#define CM_NAPTR 
#define CM_SDP_V_2 
#define CM_ABNF_V_1_2 
#define SO_USE_MD5 
#define HI_REL_1_4 
#define CM_INET2  
#define SO_SUCFG_SUPPORT 
#define SO_UA       
#define LWLCSOUISOT 
#define LWLCSVLISOT 
#define LCSOLIHIT 
#define LCHIUIHIT     
#define DEBUGP 
#define CMINETDBG 
#define CM_ABNF_DBG

#endif


#endif/*__SIP_MAC_H__*/



