/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SIP Layer

     Type:     C include file

     Desc:     Defines required by SIP

     File:     so.h

     Sid:      so.h@@/main/4 - Tue Apr 20 12:45:47 2004

     Prg:      wvdl

*********************************************************************21*/

#ifndef __SOH__
#define __SOH__

/* The folling fucntions and structures has been redefined due to the existance of the same fucntion in other common file */
#ifdef CM_XTREE
/* Function renamed due to patch so007.102 */
#define CmRdxTreeEnt CmXRdxTreeEnt
#define CmRdxTreeCp CmXRdxTreeCp
#define CmRdxListEnt CmXRdxListEnt
#define CmRdxTreeNodeEnt CmXRdxTreeNodeEnt
#define CmRdxTreeNode CmXRdxTreeNode
#define cmRdxTreeInit cmXRdxTreeInit  
#define cmRdxTreeDeinit cmXRdxTreeDeinit
#define cmRdxTreeInsert cmXRdxTreeInsert
#define cmRdxTreeFind cmXRdxTreeFind
#define cmRdxTreeFindAll cmXRdxTreeFindAll
#define cmRdxTreeDeletePtr cmXRdxTreeDeletePtr
#define cmRdxTreeDeleteKey cmXRdxTreeDeleteKey
#endif

/* Layer name */
#define SOLAYERNAME     "SIP_LAYER"

/* Determine offset of member in structure */
#define SO_OFFSET_OF(type, member)     ((PTR)(&(((type *) 0)->member)))

/**********************************************************************/
/* Defines used in core & common functions                            */
/**********************************************************************/


/* Direction of a message */
#define SO_USER                   1    /* From Service User */
#define SO_REMOTE                 2    /* From Remote       */
#define SO_INTERNAL               3    /* Internal Request  */
#define SO_OTHER                  4    /* Other internal requests */

#define SO_CLIENT                 1  /* call role */
#define SO_SERVER                 2  /* call role */

#define SO_DFLT_MAX_FWDS          70

/* Connection Id Define */
#define SO_CONNID_NOTUSED         0    /* Unused Conn Id */

/* invalid HIT connection identifiers */
#define SO_INV_HIT_CONNID      0            /* Invalid Connection Id */
#define SO_MAX_HIT_CONNID      0x7FFFFFFF   /* Max Connection Id     */

/* Call handle ranges for SIP  */
#define SO_CALLHDL_NOTUSED       0x00000000
#define SO_CALLHDL_MIN           0x00000001
#define SO_CALLHDL_MAX           0x7fffffff



#define SO_NEXTHOP_REQURI   1
#define SO_NEXTHOP_ROUTE    2

/* status code types - value corresponds to first status code digit */
#define SO_STACODE_TYPE_INFORM    1    /* SIP Informational status code */
#define SO_STACODE_TYPE_SUCCESS   2    /* SIP Success status code */
#define SO_STACODE_TYPE_REDIR     3    /* SIP Redirect status code */
#define SO_STACODE_TYPE_CLERR     4    /* SIP Client Error status code */
#define SO_STACODE_TYPE_SRVERR    5    /* SIP Server Error status code */
#define SO_STACODE_TYPE_GLFAIL    6    /* SIP Global Failure status code */

/* status codes */
#define SO_STACODE_TRYING            100    /* SIP Trying status code */

/*-------  Call  States ----------------*/
#define SO_CALL_CREATEDBY_NONE       0x00   /* Unused */
#define SO_CALL_CREATEDBY_INVITE     0x01   /* INVITE session */
#define SO_CALL_CREATEDBY_REFER      0x02   /* REFER session */
#define SO_CALL_CREATEDBY_SUBSCRIBE  0x04   /* SUBSCRIBE session */
#define SO_CALL_CREATEDBY_NOTIFY     0x08   /* NOTIFY session(non-std subsc)*/
#define SO_CALL_CREATEDBY_REGISTER   0x10   /* REGISTER related */

/* so017.201: Return value of functions */
#define SO_DLG_CREATE     1
#define SO_DLG_MATCH      2
#define SO_DLG_NOMATCH    3

/*--------- Call Leg States ------------*/

#define SO_MAX_DLG_STATES 9

#define SO_CLEG_STATE_NONE           0
#define SO_CLEG_STATE_INITIAL        1
#define SO_CLEG_STATE_PROCEEDING     2
#define SO_CLEG_STATE_EARLY          3
#define SO_CLEG_STATE_ACK_PEND       4
#define SO_CLEG_STATE_ACTIVE         5
#define SO_CLEG_STATE_MODIFY         6
#define SO_CLEG_STATE_MODIFY_ACK     7
#define SO_CLEG_STATE_TERMINATED     8

#ifdef SO_EVENT
#define SO_CLEG_NOTIFY_CIM          9
#endif /* SO_EVENT */
#define SO_CLEG_STATE_ERROR         10
#define SO_CLEG_STATE_IGNORE        11 /* so029.201 : Added state to ignore
                                       cases like retransmitted ACK's etc */

/* Start value for CSeq */
#define SO_CSEQ_START      1   /* Start value for outgoing requests   */
#define SO_CSEQ_NONE_RECD  0   /* Initial value for incoming requests */
#define SO_CSEQ_NOTUSED    0

/* Unused Value for RSeq */
#define SO_RSEQ_NOTUSED    0   /* Invalid Rseq */

/* Maximum size of cache key (used for static buffers) */
#define SO_CACHEKEY_SIZE        500

/* Default SIP port */
#define SO_PORT_DEFAULT         5060

/* so035.201: Default port for TLS transport is 5061 */
/* Default SIP TLS port */
#define SO_PORT_TLS_DEFAULT     5061


/* Events defines */
#ifdef  SO_REFER
#define SO_INT_EVENT_PACK_NAME_1     "refer" /* Name of internal 
                                                event package*/
#endif /*  SO_REFER */
#ifdef SO_EVENT

#define SO_EVNT_PKG_UNDEF            0x00    /* The evnt pkg 
                                                is un-determined */
#define SO_EVNT_PKG_STD              0x02    /* The event package 
                                                is standard,
                                                starts at 2 to allow RFAILED
                                                as return value */
#define SO_EVNT_PKG_NON_STD          0x04    /* The evnt pkg is 
                                                non-standard  */
#define SO_EVNT_PKG_NON_SUPRT        0x08    /* The evnt pkg is not 
                                                supported */

#define SO_SUBSCRIBER                   1    /* used to id the subscriber*/
#define SO_NOTIFIER                     2    /* used to id the notifier */

#endif /* SO_EVENT */


#ifdef SO_SESSTIMER
#define SO_CALLROLE_UAC              0x01
#define SO_CALLROLE_UAS              0x02
#endif /* SO_SESSTIMER */

/* Escape character used in URIs */
#define SO_URI_ESCAPE_CHAR            '%'

/* recursion states */
#define SO_NO_RECURSION                 0    /* not in recursion */
#define SO_RECURSION_ON                 1    /* Recursion in Progress */

/* Message Type */
#define SO_MSG_INVITE                   0
#define SO_MSG_INVITE_RECURSION         1
#define SO_MSG_CANCEL                   2
#define SO_MSG_PRACK                    3
#define SO_MSG_INFO                     4
#define SO_MSG_ACK                      5
#define SO_MSG_UAC_BYE                  6
#define SO_MSG_UAS_BYE                  7
#define SO_MSG_UPDATE                   8
#define SO_MSG_CIM                      9
#define SO_MSG_OTHER                    10


#define SO_RSP_PROV_RSP_NOTAG           0
#define SO_RSP_PROV_RSP_TAG             1
#define SO_RSP_2XX                      2
#define SO_RSP_ERR                      3



/* Mandatory Header Defines */

#define SO_MND_CALLID      0x00000001
#define SO_MND_CSEQ        0x00000002
#define SO_MND_FROM        0x00000004
#define SO_MND_TO          0x00000008

#ifdef SO_EVENT
#define SO_MND_EVENT       0x00000010
#endif /* SO_EVENT */

/* These headers may be duplicated */
#define SO_MND_VIA         0x80000000
#define SO_MND_CONTACT     0x40000000
#ifdef SO_EVENT
#define SO_MND_ALLOW_EVENT 0x20000000
#endif /* SO_EVENT */

/* Method sum for "standard" methods */
#define SO_MNDSUM_STD      SO_MND_CALLID | SO_MND_CSEQ |\
                                 SO_MND_TO |SO_MND_FROM | SO_MND_VIA

/* Method sums for special methods */
#define SO_MNDSUM_INVITE   SO_MND_CALLID | SO_MND_CSEQ |\
                                 SO_MND_TO |SO_MND_FROM | SO_MND_VIA

#define SO_MNDSUM_EVENT    SO_MND_CALLID | SO_MND_CSEQ |\
                                 SO_MND_TO |SO_MND_FROM | SO_MND_VIA|\
                                 SO_MND_EVENT

/* MIME boundary indicator */
#define SO_MIME_PARM_BOUNDARY  "boundary"

/*so028.201: Multiple Refers in a dialog*/
/*Max Len of String Converted from Integer*/
#define SO_MAX_UINTSZ_UA    20
                                 


/**********************************************************************/
/* defines used in MultiThreaded Encoder/Decoder                      */
/**********************************************************************/
#define SO_NUM_ED_INST           2

#define SO_ENCODE                0
#define SO_DECODE                1

#define SO_ENCODE_NONE           0
#define SO_ENCODE_OK             1
#define SO_ENCODE_NOK            2

#define SO_DECODE_NONE           0
#define SO_DECODE_OK             1
#define SO_DECODE_NOK            2

#define SO_HDR_OK_BODY_OK           0
#define SO_HDR_OK_BODY_NOK          1
#define SO_HDR_OK_BODY_INCMP        2
#define SO_HDR_OK_AFTER_TRUNC       3
#define SO_HDR_NOK_AFTER_TRUNC      4
#define SO_MAND_HDR_MISS            5
/* so001.102: added new define */
#define SO_VERSION_NOT_SUPPORT      6
/* so003.102: added new define */
#define SO_HDR_CRLF_MISS            7

#define SO_SENDOFF               1
#define SO_ENC_SDP               2

#define SO_DATA_IND              11

/**********************************************************************/
/* SIP Timer defines                                                  */
/**********************************************************************/

#define SO_TMR_CACHE_REGISTER        1 /* Registration cache entries       */
#define SO_TMR_CACHE_REGISTER_RETRY  2 /* Registration cache retry-after   */
#define SO_TMR_CACHE_DNS_SRV         3 /* DNS SRV cache entries         */
#define SO_TMR_CACHE_DNS_A           4 /* DNS A cache entries              */
#define SO_TMR_CACHE_DNS_NAPTR       5 /* DNS NAPTR cache entries         */

#ifdef SO_AAAA
#define SO_TMR_CACHE_DNS_AAAA        6 /* DNS AAAA cache entries          */
#endif

#define SO_TMR_ENTITY_CONTROL        7 /* Entity control - enable/disable  */
#define SO_TMR_DNS_LOOKUP            8 /* DNS lookup                       */


#ifdef SO_UA
#define SO_TMR_EXPIRES              9  /* EXPIRY TIMER */
#define SO_TMR_1XX_RETX             10 /* Reliable Rsp Retx timer */
#define SO_TMR_1XX_EXPIRY           11 /* 1xx Retx expiry */
#define SO_TMR_2XX_RETX             12 /* 2xx Retransmission Timer */
#define SO_TMR_2XX_EXPIRY           13 /* 2xx Retransmission Timer */
#define SO_TMR_UA_CONTACT_EXP       14 /* Registration timeouts at UA      */
#endif

#define SO_TMR_CANCEL               15 /* CANCEL timer */

#define SO_TMR_MULTICAST_RSP        16 /* multicast reponse delay timer    */

#ifdef SO_SESSTIMER
#define SO_TMR_SESSION_TIMER        17 /* Session timer */
#endif

#ifdef SO_NS
#define SO_TMR_LCS_SEARCH           20  /* User location service            */
#endif /* SO_NS */


#ifdef SO_EVENT
#define SO_TMR_SUBSC_EXP            18 /* Subscription duration is over at
                                          subscriber  */
#define SO_TMR_NOTIFY_EXP           19 /*  Subscription duration is over at
                                           notifier  */
enum
{
   SO_SUBSCRIPTION_STATE_NULL,         /* subscription null */
   SO_SUBSCRIPTION_STATE_PENDING,      /* subscription pending */
   SO_SUBSCRIPTION_STATE_ACTIVE,       /* subscription active */
   SO_SUBSCRIPTION_STATE_TERMINATED,   /* subscription terminated */
   SO_SUBSCRIPTION_STATE_INVALID       /* invalid subscription */
};

enum 
{
   SO_SUBSC_TYPE_REFER,         /* type is refer */
   SO_SUBSC_TYPE_SUBSC,         /* type is subscribe */
   SO_SUBSC_TYPE_NOTIFY,        /* type is notify */
   SO_SUBSC_TYPE_INVALID        /* invalid subscribe type */
};

enum
{
   SO_SUBSC_FSM_INIT,           /* initial state */
   SO_SUBSC_FSM_202,            /* sending/receiving 202 */
   SO_SUBSC_FSM_NEUTRAL,        /* sending/receiving 200 */
   SO_SUBSC_FSM_NOTIFY_NO200,   /* pending state */
   SO_SUBSC_FSM_NOTIFY,         /* active state */
   SO_SUBSC_FSM_REFRESH,        /* refresh state */
   SO_SUBSC_FSM_NOTIFY_REFRESH,   /* refresh state */
   SO_SUBSC_FSM_TIMEOUT,        /* timeout occured */
   SO_SUBSC_FSM_NOTIFY_TIMEOUT, /* timeout occured */
   SO_SUBSC_FSM_TERMINATE,      /* terminate pending state */
   SO_SUBSC_FSM_TERMINATE_DONE, /* final terminate state */
   SO_SUBSC_FSM_INVALID         /* invalid state */
};

#endif

#define SOTMR_BASE_TCM     0x0040   /* TCM timers        */
#define SO_TMR_TCM_BND          (SOTMR_BASE_TCM + 1) /* Bind Timer Id      */
#define SO_TMR_TCM_IDLE         (SOTMR_BASE_TCM + 2) /* Idle Timer Id      */
#define SO_TMR_TCM_CONNECTION   (SOTMR_BASE_TCM + 3) /* Connection Timer   */
/* so010.201: Fix to guard opening of tpt srv with a timer */
#define SO_TMR_TCM_OPEN_SRV     (SOTMR_BASE_TCM + 4) /* Server open control
                                                        timer */


#define SOTMR_BASE_TRANS   0x0060   /* Transaction timers */
#define SO_TMR_TRANS_A          (SOTMR_BASE_TRANS + 1)
#define SO_TMR_TRANS_B          (SOTMR_BASE_TRANS + 2)
#define SO_TMR_TRANS_D          (SOTMR_BASE_TRANS + 3)
#define SO_TMR_TRANS_E          (SOTMR_BASE_TRANS + 4)
#define SO_TMR_TRANS_F          (SOTMR_BASE_TRANS + 5)
#define SO_TMR_TRANS_G          (SOTMR_BASE_TRANS + 6)
#define SO_TMR_TRANS_H          (SOTMR_BASE_TRANS + 7)
#define SO_TMR_TRANS_I          (SOTMR_BASE_TRANS + 8)
#define SO_TMR_TRANS_J          (SOTMR_BASE_TRANS + 9)
#define SO_TMR_TRANS_K          (SOTMR_BASE_TRANS + 10)
#define SO_TMR_TRANS_NATTMR     (SOTMR_BASE_TRANS + 11)



#define SOTMR_EVNT_IDXMASK       0xFF00
#define SOTMR_EVNT_MODMASK       0x00F0
#define SOTMR_EVNT_EVNTMASK      0x000F

/* defines for the action parameter in soSchedTmr */
#define TMR_START                1
#define TMR_STOP                 2
#define TMR_RESTART              3

/* Timer values in relation to layer timer resolution of 100 MS */
#define SO_TMRVAL_1_S                          10
#define SO_TMRVAL_1MIN      (60 * SO_TMRVAL_1_S)
#define SO_TMRVAL_10MIN     (10 * SO_TMRVAL_1MIN)
#define SO_TMRVAL_30MIN     (30 * SO_TMRVAL_1MIN)
#define SO_TMRVAL_300MIN    (300 * SO_TMRVAL_1MIN)
#define SO_TMRVAL_1_HOUR    (2 * SO_TMRVAL_30MIN)

/* 32s timer for maintaining state at end of transaction */
#define SO_TMRVAL_SIP_32S       (32 * SO_TMRVAL_1_S)

/* Timer value for closing connection to DNS server = 1 minute */
#define SO_TMRVAL_DNS_INACTIVE  SO_TMRVAL_1MIN

/* Timeout for requests sent on reliable transport */
#define SO_TMRVAL_SIP_RELIABLE_TIMEOUT  (3 * SO_TMRVAL_1MIN)

/* Margin of notification for remote registration timeouts = 5 seconds */
/* so004.201: Adjust timer value to notify _before_ expiry */
#define SO_TMRVAL_REMREG_ACTION (32 * SO_TMRVAL_1_S)

/* Margin of notification for subscription timeouts at subscriber = 10 seconds*/
#define SO_TMRVAL_SUBSC_ACTION (10 * SO_TMRVAL_1_S)

/* Margin of notification for subscription timeouts at notifier = 5 seconds */
#define SO_TMRVAL_NOTIF_ACTION (5 * SO_TMRVAL_1_S)

/* Timer value in seconds used to process timeouts for searches */
#define SO_TMRVAL_LCS_EXTLCS   (10 * SO_TMRVAL_1_S)

/* Entity disable timer value = 1 second */
#define SO_TMRVAL_ENT_DIS     SO_TMRVAL_1_S



/**********************************************************************/
/* defines related to TCM */
/**********************************************************************/
/* TCP/UDP connection timer - time to allow for connection setup */
#define SO_TMRVAL_CONNECT   (15 * SO_TMRVAL_1_S)

#define SO_MAX_BNDRETRY            3              /* Max Bind Retries       */
#define SOTMR_MAX_IDLE_RETRY       5              /* Max Idle Retries       */
#define SOTMR_MAX_CONNECTION_RETRY 5              /* Max Connection Retries */
#define SO_LISTEN_QSIZE            5              /* Listen Q Size          */
#define SO_TPT_CLNT_ABORTIND       3              /* Abort Indication       */

/* types of connections */
#define  SO_SOCK_NONE              0
#define  SO_SOCK_SRV               1
#define  SO_SOCK_CLNT              2

/* Actions posssible on transport server (in fn soTptProcessTsapServers) */
#define SO_TCM_TPTSRV_CLOSE        1
#define SO_TCM_TPTSRV_OPEN         2
#define SO_TCM_TPTSRV_DISABLE      3
#define SO_TCM_TPTSRV_FREE         4

/* Client connection state */
#define SO_TPTCLIENT_ENA  1
#define SO_TPTCLIENT_DIS  2

#define SO_TPTADDR_HL_BINS         128 

/* local defines */
#define BCD_TO_ASCII(c)  \
  (((c) <= 9) ? (c) + '0' : (((c) >= 10 && (c) <= 15) ? 'A' + (c) - 10 : '?'))



/* defines for transport interface function return values */
#define SO_TPT_MULTI_THREADED_ENC   SOT_ERR_MAX + 1
#define SO_TPT_MULTI_THREADED_DEC   SOT_ERR_MAX + 2
#define SO_TPT_TRANSPORT_CHANGED    SOT_ERR_MAX + 3
#define SO_TPT_MSG_NOT_COMPLETE     SOT_ERR_MAX + 4

/* defines for tcmConn Type SoTcmConn->tcmConnType */
#define SO_TRANS      1
#define SO_DIALOG     2
#define SO_UNKNOWN    3
#define SO_NOCALLBACK 4

/* Multicast TTL */
#define SO_MULTICAST_TTL           1

#define SO_NS_DIS_TIME             8  /* time to wait for graceful disable */


/* so027.201 : Changes for SIP TLS support, this is to compile the code
 * with TUCL 1.4
 */
#ifndef HI_SRVC_TLS
#define HI_SRVC_TLS              11
#endif




/* Timer queue sizes */
#define SO_TQ100MS_SZ             128   /* Size of 100 ms timer queue */
#define SO_TQ1MIN_SZ               32   /* Size of 1 min timer queue */
#define SO_TQ30MIN_SZ             128   /* Size of 30  min timer queue */

/* Timer constants */                   /* system tick = 100ms    */
#ifdef SO_INSURE
/* allow to run on VERY slow machine / Insure */
#define SO_TIMERES_100MS          10     /* system ticks per 100ms */
#define SO_TIMERES_1MIN           600    /* system ticks per 1min  */
#define SO_TIMERES_30MIN          18000  /* system ticks per 30min */
#else /* SO_INSURE */
/* normal execution */
#define SO_TIMERES_100MS          1     /* system ticks per 100ms */
#define SO_TIMERES_1MIN           600   /* system ticks per 1min  */
#define SO_TIMERES_30MIN          18000 /* system ticks per 30min */
#endif /* SO_INSURE */

/* DNS constants */
#define SO_DNS_REQUESTIDLSTSZ     300    /* max number of simultanious
                                          * dns queries */

#define SO_MCAST_TYPE_IPV4        1
#define SO_MCAST_TYPE_IPV6        2

#define SO_DNS_A_TTL_MIN  SO_TMRVAL_1_S          /* Minimum DNS ttl          */
#define SO_DNS_A_TTL_MAX  (24*SO_TMRVAL_1_HOUR)  /* Maximum DNS ttl (24 hrs) */

/* Cache thresholds and Maximums */
#define SO_CACHE_ENTRIES_PER_NODE 10    /* The number of entries per node
                                           for the radix tree */

/* OPTIONS Method Headers */
#define SO_HDR_ACCEPT_TYPE         "application"
#define SO_HDR_ACCEPT_TYPE_LEN     11
#define SO_HDR_ACCEPT_SUBTYPE      "sdp"
#define SO_HDR_ACCEPT_SUBTYPE_LEN  3
#define SO_HDR_ACCEPT_LANGUAGE     "en"
#define SO_HDR_ACCEPT_LANGUAGE_LEN 2

/* SIP Option tags */
#define SO_OPTIONTAG_100REL      ((U8 *) "100rel")
#define SO_OPTIONTAG_100REL_LEN  6

#ifdef SO_PATH_ROUTE
#define SO_OPTIONTAG_PATH      ((U8 *) "Path")
#define SO_OPTIONTAG_PATH_LEN  4
#endif /* SO_PATH_ROUTE */

#ifdef SO_SESSTIMER
#define SO_OPTIONTAG_TIMER       ((U8 *) "timer")
#define SO_OPTIONTAG_TIMER_LEN   5
#endif /* SO_SESSTIMER */

/* so038.201: Fix for precondition */
#ifdef SO_RFC_3312
#define SO_OPTIONTAG_PRECOND ((U8 *) "precondition")
#define SO_OPTIONTAG_PRECOND_LEN  12
#endif /* SO_RFC_3312 */


#ifdef SO_TLS
#define SO_TLS_NONE              0
#define SO_TLS_USER              1
#define SO_TLS_DNS               2
#endif /* SO_TLS */

/* Macros for memory allocation and alarms */

#define SO_GEN_SMEM_ALARM                                                \
{                                                                        \
   Mem alarmMem;                                                         \
   alarmMem.pool   = soCb.init.pool;                                     \
   alarmMem.region = soCb.init.region;                                   \
   soGenStaInd (STGEN, LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL, \
                LCM_CAUSE_UNKNOWN, LSO_PAR_MEM, &alarmMem);              \
}

#define SO_ZERO(_buf, _size)                                         \
{                                                                    \
   cmMemset((U8 *)(_buf), 0, _size);                                 \
}

#define SOALLOC(_buf, _size)\
{\
   if (SGetSBuf(soCb.init.region, soCb.init.pool, (Data **) _buf,    \
                (Size) _size) == ROK)                                \
   {                                                                 \
      cmMemset((U8 *)(*_buf), 0, _size);                             \
   }                                                                 \
   else                                                              \
   {                                                                 \
      (*_buf) = NULLP;                                               \
      SO_GEN_SMEM_ALARM;                                             \
   }                                                                 \
}

#define SOALLOC_NOALARM(_buf, _size)\
{\
   if (SGetSBuf(soCb.init.region, soCb.init.pool, (Data **) _buf,    \
   (Size) _size) == ROK)                                             \
   {                                                                 \
      cmMemset((U8 *)(*_buf), 0, _size);                             \
   }                                                                 \
   else                                                              \
   {                                                                 \
      (*_buf) = NULLP;                                               \
   }                                                                 \
}

#define SOMSGALLOC(_buf)\
{\
   if (SGetMsg(soCb.init.region, soCb.init.pool, (Buffer **) _buf) == ROK) \
   {                                                                       \
      cmMemset((U8 *)(*_buf), 0, sizeof(Buffer));                          \
   }                                                                       \
   else                                                                    \
   {                                                                       \
      (*_buf) = NULLP;                                                     \
      SO_GEN_SMEM_ALARM;                                                   \
   }                                                                       \
}

#define SOFREE(_buf, _size)\
{\
   (Void) SPutSBuf(soCb.init.region, soCb.init.pool, (Data *) _buf, \
   (Size) _size);\
   (_buf) = NULLP;\
}

#define DURATIONINSECS(d)                          \
   ((d.days*24+d.hours)*3600+d.mins*60+d.secs)

/* Check for presence of SDP in a message */
#define SO_CHK_SDP(_evnt, _sdpPres)                          \
{                                                            \
   SoContentTypeHdr  *contentType;                           \
   _sdpPres = FALSE;                                         \
                                                             \
   if (_evnt->sipBody.bodyType.pres != NOTPRSNT)             \
   {                                                         \
     if ((soCmFindHdrChoice(_evnt, (U8 **)&contentType,      \
                  SO_HEADER_ENT_CONTENTTYPE)) == ROK)        \
     {                                                       \
       if (SO_CMP_TKN_LIT(&_evnt->sipBody.bodyType,          \
                          SOT_BODYTYPE_SINGLEPART) == TRUE)  \
       {                                                     \
         if (SO_CMP_TKN_LIT(                                 \
            &_evnt->sipBody.u.singlePart.bodySinglePartType, \
            SOT_BODYSINGLEPART_SDP) == TRUE)                 \
         {                                                   \
           _sdpPres = TRUE;                                  \
         }                                                   \
       }                                                     \
     }                                                       \
   }                                                         \
}


#define SO_DLG_UPDATE_EVENT_LEGID(_evnt, _legId)             \
{                                                            \
  _evnt->callLegId = _legId;                                  \
}


#define SO_FREE_MBUF(_mBufPtr)                               \
{                                                            \
  (Void) SPutMsg(*_mBufPtr);                                 \
  *_mBufPtr = NULLP;                                         \
}

#define SO_TCM_SERVER_MCAST(t)                                    \
(((t)->localAddr.type == CM_TPTADDR_IPV4) &&                      \
((t)->localAddr.u.ipv4TptAddr.address == CM_INET_INADDR_ANY) ?    \
    TRUE : FALSE)


#define SO_TCM_ZERO_BASED_ADDR(addr)                 \
{                                                    \
    CmTptAddr     _key;                              \
                                                     \
    cmMemset ((U8 *) &(_key), 0, sizeof (CmTptAddr));\
                                                     \
    (_key).type    =  (addr)->type;                  \
                                                     \
    if ((addr)->type == CM_NETADDR_IPV4)             \
       cmMemcpy ((U8 *)&((_key).u.ipv4TptAddr),      \
                 (U8 *)&((addr)->u.ipv4TptAddr),     \
                 sizeof (CmIpv4TptAddr));            \
                                                     \
    else if ((addr)->type == CM_NETADDR_IPV6)        \
       cmMemcpy ((U8 *)&((_key).u.ipv6TptAddr),      \
                 (U8 *)&((addr)->u.ipv6TptAddr),     \
                 sizeof (CmIpv6TptAddr));            \
                                                     \
    cmMemcpy ((U8 *) (addr),                         \
              (U8 *)&(_key),                         \
              sizeof (CmTptAddr));                   \
}


/*----- Update DNS queryCb in DNS module ------*/
#define SO_DNS_UPDATE_QUERYCB(qCb)                      \
{                                                       \
  ((SoDnsQueryCb *)(qCb))->usrCtxt.queryCb = (PTR)(qCb);\
}


/*--------------------------------------------------------------------
                 SIP Cache Types
 ---------------------------------------------------------------------*/
enum
{
   SO_CACHE_DNS_A,                  /* DNS "A" entry */
   SO_CACHE_DNS_SRV,                /* DNS SRV entry */
   SO_CACHE_REM_USER_REG,           /* Remote User Registration */
   SO_CACHE_LOC_USER_REG,           /* Local User Registration */
   SO_CACHE_MCAST_REG,              /* Multicast Cache */
   SO_CACHE_DNS_NAPTR               /* DNS NAPTR entry */
};

/*--------------------------------------------------------------------
                 SIP TcmConn Types
 ---------------------------------------------------------------------*/
enum
{
   SO_CLEG_RQST_IN_RSP_OUT,         /* Part of CLegCb */
   SO_CLEG_RQST_OUT_RSP_IN,         /* Part of CLegCb */
   SO_MSG_TCM_CONN                  /* Part of soMsgCb */
};

#ifdef DEBUGP

#define SO_INV_ENTID           0xFFFF

#define SO_DBGMASK_EVNT        (DBGMASK_LYR << 0)
#define SO_DBGMASK_LI_MBUF     (DBGMASK_LYR << 1)
#define SO_DBGMASK_CL          (DBGMASK_LYR << 2)
#define SO_DBGMASK_ABNF_DEC    (DBGMASK_LYR << 3)
#define SO_DBGMASK_ABNF_ENC    (DBGMASK_LYR << 4)
#define SO_DBGMASK_DNS         (DBGMASK_LYR << 5)
#define SO_DBGMASK_NS          (DBGMASK_LYR << 6)
#define SO_DBGMASK_UA          (DBGMASK_LYR << 7)
#define SO_DBGMASK_MH          (DBGMASK_LYR << 8)
#define SO_DBGMASK_ACNT        (DBGMASK_LYR << 9)
#define SO_DBGMASK_CORE        (DBGMASK_LYR << 10)
#define SO_DBGMASK_TCM         (DBGMASK_LYR << 11)
#define SO_DBGMASK_TRANS       (DBGMASK_LYR << 12)
#define SO_DBGMASK_DLG         (DBGMASK_LYR << 13)
#define SO_DBGMASK_ERR         (DBGMASK_LYR << 14)

/* get Duration in Seconds */
#define DURATIONINSECONDS(duration)                                 \
   ((duration.days*24+duration.hours)*3600+duration.mins*60+duration.secs)

#define DEBUG_PRNT(_entId, _ent, _inst, _layerName, _prntBuf, _dbgMask, \
                   _msgClass, _arg)                                     \
{                                                                       \
   if ((_dbgMask & (_msgClass)) | (soCb.init.dbgMask & (_msgClass)))  \
   {                                                                    \
      if (_entId != SO_INV_ENTID)                                       \
         sprintf(_prntBuf, "[%s 0x%x:%x] %s:%d Module Entity Id %d ",   \
                 _layerName, _ent, _inst, __FILE__, __LINE__, _entId);  \
      else                                                              \
         sprintf(_prntBuf, "[%s 0x%x:%x] %s:%d ",                       \
                 _layerName, _ent, _inst, __FILE__, __LINE__);          \
      SPrint(_prntBuf);                                                 \
      sprintf _arg;                                                     \
      SPrint(_prntBuf);                                                 \
   }                                                                    \
}

#define SODBGP_SO(_msgClass, _arg)                                       \
 {                                                                    \
     DEBUG_PRNT (SO_INV_ENTID, soCb.init.ent, soCb.init.inst, SOLAYERNAME,\
                 soCb.init.prntBuf, soCb.init.dbgMask,            \
                 _msgClass, _arg);                                    \
 }                                                                    \

#else
#define DEBUG_PRNT(_entId, _ent, _inst, _layerName, _prntBuf, _dbgMask, \
                   _msgClass, _arg)
#define SODBGP_SO(_msgClass, _arg)
#endif

#define BRANCH_MAGSTR    "z9hG4bK"
#define BRANCH_MAGSTR_SZ 7


/* so038.201:  Moved variable within () */
#define SO_TCM_UDP_TRANSPORT(transport) (((transport) == LSO_TPTPROT_UDP) || ((transport)  == LSO_TPTPROT_UDP_PRIOR))

#define SO_TCM_TCP_TRANSPORT(transport) (((transport) == LSO_TPTPROT_TCP))

#define SO_TCM_TLS_TRANSPORT(transport) (((transport) == LSO_TPTPROT_TLS_TCP))


#endif /* __SOH__ */

/********************************************************************30**

         End of file:     so.h@@/main/4 - Tue Apr 20 12:45:47 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision History:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---     ms   1. initial release.
/main/4+   so004.201 up   1. Adjust timer value to notify _before_ expiry
/main/4+   so010.201 ab   1. Fix to guard opening of tpt srv with a timer
/main/4+   so017.201 ps   1. New macros for function return values
/main/4+   so027.201 ab   1. Changes for SIP TLS support.
/main/4+   so028.201 ad   1. Multiple Refers in a dialog.
/main/4+   so029.201 ss   1. Added CLeg state Ignore
/main/4+   so035.201 ng   1. Added SO_PORT_TLS_DEFAULT for TLS transport.(ab)
/main/4+   so038.201 ng   1. Add precondition to list of options supportted 
                             if RFC3312 falg is defined
                     ng   2. Moved variable within () for macro
*********************************************************************91*/
