#ifndef __SO_BINDH__
#define __SO_BINDH__

extern void soBndHiReq(void);


#endif /*__SO_BINDH__*/