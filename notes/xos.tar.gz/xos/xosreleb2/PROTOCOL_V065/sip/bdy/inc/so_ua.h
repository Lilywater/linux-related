/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SIP  - User Agent (UA)

     Type:    C include file

     Desc:    Defines required by UA

     File:    so_ua.h

     Sid:      so_ua.h@@/main/4 - Tue Apr 20 12:47:29 2004

     Prg:     op

*********************************************************************21*/

#ifndef __SOUAH__
#define __SOUAH__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#define   CIM       1       /* messages carried by CIM      */
#define   CONN      2       /* messages carried by CSP      */
#define   MOD       3       /* messages carried by Modify   */
#define   CNST      4       /* messages carried by CnStReq  */

#define SO_UA_DEL_CONTACT(_cLeg, _contactCb)                    \
{                                                               \
   soSchedTmr(_contactCb, SO_TMR_UA_CONTACT_EXP,                \
              TMR_STOP, NOTUSED);                               \
   if (_contactCb->cLegLstNode.node != NULLP)                   \
   {                                                            \
      cmLListDelFrm(&(_cLeg->regInfo.pendContactLst),           \
                   &(_contactCb->cLegLstNode));                 \
      _contactCb->cLegLstNode.node = NULLP;                     \
   }                                                            \
                                                                \
   cmHashListDelete(&_cLeg->regInfo.contactLst, (PTR) _contactCb); \
   if (_contactCb->key != NULLP)                                \
   {                                                            \
      SOFREE(_contactCb->key, _contactCb->keyLength);           \
   }                                                            \
   if (_contactCb->storedReq != NULLP)                          \
   {                                                            \
     (Void)soCmFreeEvent(_contactCb->storedReq);                \
   }                                                            \
   if (_cLeg->regInfo.numRegContacts != 0)                      \
      _cLeg->regInfo.numRegContacts--;                          \
   SOFREE(_contactCb, sizeof(SoRegContactCb));                  \
}


#define SO_UA_CLEAR_CNCTLST(_tranCb)                            \
{                                                               \
    SoRegContactCb *_contactCb;                                 \
    CmLList        *_curNode;                                   \
                                                                \
   _curNode = cmLListFirst(&_tranCb->contactLst);               \
   while (_curNode != NULLP)                                    \
   {                                                            \
     _contactCb = (SoRegContactCb *)(cmLListNode(_curNode));    \
     _curNode  = _curNode->next;                                \
     _contactCb->tranCb = NULLP;                                \
     cmLListDelFrm(&_tranCb->contactLst, &_contactCb->tranllNode); \
   }                                                            \
}

#define SO_UA_CHK_RSP_FOR_CONTACTS(_hdrSeq , _found)            \
{                                                               \
   U16 _i;                                                      \
   SoHeader   *_curHdr;                                         \
                                                                \
   for (_i = 0; _i < (_hdrSeq)->numComp.val; _i++)              \
   {                                                            \
      _curHdr = (_hdrSeq)->header[_i];                          \
      if (SO_CMP_TKN_LIT(&_curHdr->headerType, SO_HEADER_GEN_CONTACT) != TRUE) \
         continue;                                              \
      else                                                      \
      {                                                         \
         _found = TRUE;                                         \
         break;                                                 \
      }                                                         \
   }                                                            \
}

/*-- so014.201: Do not initialize userPtr Value --*/
#ifndef SO_EVENT  
#define SO_FILL_USER_CTXT(_userCtxt, _saveMsg, _intMsg)       \
{                                                             \
  _userCtxt.saveMsg = _saveMsg;                              \
  _userCtxt.intMsg  = _intMsg;                               \
  _userCtxt.queryCb = NULLP;                                 \
}
#else
#define SO_FILL_USER_CTXT(_userCtxt, _saveMsg, _intMsg)       \
{                                                             \
  _userCtxt.saveMsg = _saveMsg;                              \
  _userCtxt.intMsg  = _intMsg;                               \
  _userCtxt.queryCb = NULLP;                                 \
  _userCtxt.subscCb = NULLP;                                 \
}
#endif


/* Store the 2xx buffer & start reqd timers for an outgoing
   2xx response */
#define SO_PRC_OUT_2XX_INFO(_cLeg, _mBuf)                     \
{                                                             \
   _cLeg->rspCb.rspMsg = _mBuf;                               \
   _cLeg->rspCb.tmrVal = soCb.reCfg.tmrReTxCfg.t1;            \
   soSchedTmr(_cLeg, SO_TMR_2XX_RETX, TMR_START, _cLeg->rspCb.tmrVal); \
   soSchedTmr(_cLeg, SO_TMR_2XX_EXPIRY, TMR_START, _cLeg->rspCb.tmrVal*64); \
}


/* Store CSeq in the Ack Cb */
#define SO_UA_STORE_ACK_CSEQ(_cLeg, _evnt, _ret)                \
{                                                            \
  SoCSeq     *_cSeq;                                         \
  _ret = soCmFindHdrChoice(_evnt, (U8 **) &_cSeq,            \
                           SO_HEADER_GEN_CSEQ);              \
  if (_ret == ROK)                                           \
  {                                                          \
    _cLeg->ackCb.cSeqVal = _cSeq->cSeqVal.val;                \
  }                                                          \
}


/* Deletion of call & Call Leg */
#define SO_UA_DEL_CALL_CTXT(_cLeg, _call, _ret)      \
{                                                    \
  soDlgDeleteCleg(_call, _cLeg);                     \
  soCoreChkAndDelCall(_call);                        \
  RETVALUE(_ret);                                    \
}


/* Send Error Response & Return */
/* 
 * so012.201: SO_UA_SEND_ERR_RSP  should only be called when dialog state
 *            change is not desired. Error response sent using this macro
 *            will not result in any dialog state change.
 */
 
/* 
 * so031.201: Added transCb in the argument of teh functionsoDlgSendResponse.
 */
 
#define SO_UA_SEND_ERR_RSP(_cLeg, _transCb, _evnt, _statusCode, _extStatusCode) \
{                                                      \
   S16 _ret;                                           \
   SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,      \
        " [Dialog] Sending Error Response \n"));       \
   if (_cLeg != NULLP)                                 \
   {                                                   \
      if (_cLeg->clegState == SO_CLEG_STATE_NONE)      \
         _cLeg->clegState = SO_CLEG_STATE_INITIAL;     \
                                                       \
     /* Mark that dialog state change is not desired */\
      _cLeg->noStateUpd = TRUE;                        \
      _ret = soDlgSendResponse(_cLeg, _transCb, _evnt, _statusCode, \
                            _extStatusCode);           \
      _cLeg->noStateUpd = FALSE;                       \
      if (_ret != ROK)                                 \
         RETVALUE(RFAILED);                            \
   }                                                   \
   else                                                \
   {                                                   \
     if (soDlgSendRspNoCleg(_transCb, _evnt, _statusCode, \
                            _extStatusCode) != ROK)    \
     {                                                 \
         RETVALUE(RFAILED);                            \
     }                                                 \
   }                                                   \
                                                       \
   soCmFreeEvent(_evnt);                               \
   RETVALUE(ROK);                                      \
}
    
/* so015.201: Clear event context for Registration also */
/* so035.201: Clear event context for Subbsribe */
#define SO_UA_CLEAR_STORED_EVNT(_cLeg, _evnt)           \
{                                                       \
   CmLList           *curNode;                          \
   PTR               curItem;                           \
   SoRegContactCb    *pendContact;                      \
                                                        \
   if (_cLeg->sentInvite == _evnt)                      \
      _cLeg->sentInvite = NULLP;                        \
   else if (_cLeg->pendingCancel == _evnt)              \
      _cLeg->pendingCancel = NULLP;                     \
   if ((_evnt->eventType.val == SOT_ET_SUBSCRIBE) ||      \
        (_evnt->eventType.val == SOT_ET_REFER))           \
   {                                                     \
      curNode = cmLListFirst(&_cLeg->subscCb.subCp);                  \
      while (curNode != (CmLList *)NULLP)                  \
      {                                                    \
         SoSubNode         *subsc = (SoSubNode *)cmLListNode(curNode);      \
         curNode  = curNode->next;                         \
         if(subsc->event == _evnt)                         \
           subsc->event = NULLP;                           \
      }                                                    \
   }                                                    \
   if (_evnt->eventType.val == SOT_ET_REGISTER)         \
   {                                                    \
      curNode = cmLListFirst (&_cLeg->regInfo.pendContactLst);\
      while (curNode != (CmLList *)NULLP)               \
      {                                                 \
        curItem  = cmLListNode (curNode);               \
        curNode  = curNode->next;                       \
        pendContact = (SoRegContactCb *)curItem;        \
        if (pendContact->storedReq == _evnt)            \
        {                                               \
          pendContact->storedReq = NULLP;               \
        }                                               \
      }                                                 \
   }                                                    \
}

/* so024.201 Macro for clearing contact Cbs in a CLeg */
#define SO_UA_CLEAR_CONTACTS(_cLeg, _evnt)              \
{                                                       \
   SoHeaderSeq       *hdrSeq;                           \
   SoHeader          *curHdr;                           \
   SoContact         *contactHdr;                       \
   SoContactItem     *contactItem;                      \
   SoAddrSpec        *contactAddr;                      \
   SoRegContactCb    *contactCb;                        \
   U8                *key;                              \
   U16               keyLen;                            \
   U16               i;                                 \
   U32               cItem;                             \
                                                        \
   hdrSeq = &_evnt->t.request.request;                  \
   for (i=0; i<hdrSeq->numComp.val; i++)                \
   {                                                    \
      curHdr = hdrSeq->header[i];                       \
      if (SO_CMP_TKN_LIT(&curHdr->headerType,           \
          SO_HEADER_GEN_CONTACT) != TRUE)               \
         continue;                                      \
                                                        \
      contactHdr = &curHdr->t.contact;                  \
                                                        \
      for (cItem=0;                                     \
           cItem<SO_GET_NUM_COMP(&contactHdr->contactItems.numComp);\
           cItem++)                                     \
      {                                                 \
         contactCb = NULLP;                             \
         contactItem = contactHdr->contactItems.contactItem[cItem];\
         SO_ADDRSPEC_FROM_ADDRCH(contactAddr, &contactItem->contactAddrChoice);\
         if (soUtlCalcAddrKey(contactAddr, &key, &keyLen) != ROK)\
            continue;                                   \
         cmHashListFind(&_cLeg->regInfo.contactLst,     \
               (U8*)key, (U16)keyLen,0,(PTR*)&contactCb);\
                                                        \
         if (contactCb != NULLP)                        \
         {                                              \
            cmHashListDelete (&_cLeg->regInfo.contactLst,\
                  (PTR) contactCb);                     \
            cmLListDelFrm(&(_cLeg->regInfo.pendContactLst),\
                       &(contactCb->cLegLstNode));      \
            SOFREE(contactCb, sizeof(SoRegContactCb));  \
            _cLeg->regInfo.numRegContacts--;            \
         }                                              \
         SOFREE(key, keyLen);                           \
      }                                                 \
   }                                                    \
}


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __SOUAH__ */


/********************************************************************30**

         End of file:     so_ua.h@@/main/4 - Tue Apr 20 12:47:29 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/4      ---      ms   1. initial release.
/main/4+   so012.201  ps   1. Macro SO_UA_SEND_ERR_RSP changed to stop
                              dlg state change while sending error rsp.
/main/4+   so014.201  ps   1. ReqURI/route for INVITE saved in transaction to
                              be used for CANCEL Request.
/main/4+   so015.201  ps   1. Clear event context for Registration during
                              transaction timeout.
/main/4+   so016.201  ab   1. Macro for clearing contact Cbs in a CLeg
/main/4+   so031.201  aj   1. Added transCb in the argument of function 
                              soDlgSendResponse.
/main/4+   so035.201  ng   1. Clear event context for Subbsribe
*********************************************************************91*/
