/*************************************************
  Copyright (C), 2006-0405, XINWEI Co., Ltd.
  File name:  sipapi.h
  Module:	sip Stack Api
  Author:  chendh
  Version: 1.0
  Created on : 2006-04-05
  Description:
	This files supplies data structures and functions for SIP Stack user.
  
  Modify History:
		1. Date:        Author:         Modification:
*************************************************/

#ifndef __SIP_APIH__
#define __SIP_APIH__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <assert.h>
#ifdef SS_VXWORKS
#include <taskLib.h>
#endif
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "cm_inet.h"       /* common INET defines */
#include "cm_tpt.h"        /* common transport defines */
#include "hit.h"           /* HI layer */
#include "cm_sdp.h"        /* SDP related constants */
#include "cm_dns.h"         /* common DNS libraru defines */
#include "sot.h"           /* SOT defines */
#include "so.h"            /* defines and macros for SIP */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer typedefs */
#include "ssi.x"           /* system services typedefs */

#include "cm_inet.x"       /* common INET */
#include "cm_lib.x"        /* common library */

#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_tpt.x"        /* common transport types */
#include "cm_sdp.x"        /* SDP related types */
#include "sot.x"           /* SOT types */


/* �ж�ָ���Ƿ�Ϸ� */
#define SIP_API_CHKPTR(_ptr)   \
{		\
	if(_ptr == NULLP)	\
	{	\
		assert(0);	\
		RETVALUE(RFAILED);	\
	}	\
}

/* �����ڴ� */
/* ALLOCATE cmMemset */
#define SIP_API_GETMEM(_ptr, _len, _memCp)                                 \
{                                                                         \
   if(_len > 0) \
   { \
	   if (cmGetMem((_memCp), (_len), (Ptr *)&(_ptr)) != ROK)                 \
	   {		\
	        RETVALUE(RFAILED);                                  \
	   }		\
   } \
}

/* ��鷵��ֵ */
#define SIP_API_CHK_RETVALUE(_ret)                          \
{                                                        \
    if(ROK != _ret)                                  \
    {                                                    \
    	MGDBGP(DBGMASK_UI,(soCb.init.prntBuf,			\
			"(Line: %d, File: %s)\n", __LINE__, __FILE__));	\
    }                                                    \
    if(RFAILED == _ret)			\
    {	\
        RETVALUE(_ret);                                  \
    }	\
}

/* ��ʼ��TOKENֵ*/
/* macro to initialise TknU8 , TknS16, TknU16, TknU32...etc.  */
#define SIP_API_INIT_TOKEN_VALUE(_tkn, _val)                               \
{                                                                         \
   (_tkn)->pres = PRSNT_NODEF;                                            \
   (_tkn)->val  = (_val);                                                 \
}


/*    	printf(" (Line: %d,Function: %s File: %s)\n", __LINE__, __FUNCTION__,__FILE__);	\*/
/*    	taskSuspend(0);		\*/
/*    	assert(0);		\*/

/* ����TOKEN�͵��ַ���*/
#define SIP_API_ALLOC_TKNSTR(_tkn, _val, _len, _memCp)                              \
{                                                                         \
	if(_len > 0)								\
	{				\
	   (_tkn)->pres = PRSNT_NODEF;                                            \
	   (_tkn)->len  = (U8)(_len);                                             \
	   SIP_API_GETMEM((_tkn)->val, _len+1, _memCp);			\
	   cmMemcpy((U8 *)(_tkn)->val, (CONSTANT U8 *)(_val), (_len));	\
	}		\
}


/* �����ַ���*/
#ifdef USE_OLD_STR_COPY_CONVERTION
#define SIP_API_ALLOC_STR(_str, _val, _len, _memCp)	\
{													\
	MG_API_GETMEM(_str, _len+1, _memCp);	\
	cmMemcpy(_str, (CONSTANT U8 *)(_val), (_len));	\
}
#else
#define SIP_API_ALLOC_STR(_str, _val, _len, _memCp)	\
{													\
	_str = _val;	\
}
#endif

/* ����ָ������*/
#define SIP_API_ALLOC_PTR_ARRAY(_array, _num, _sizeElm, _memCp)		\
{															\
	U8	_idx; 												\
	Size _arraySize;										\
	_arraySize = _num * (sizeof(PTR));								\
	SIP_API_GETMEM(_array, _arraySize, _memCp );			\
	for(_idx = 0; _idx < _num; _idx++)								\
	{														\
	      SIP_API_GETMEM( _array[_idx], _sizeElm, _memCp);	\
	}													\
}

/*����������ʹ��ָ���������в�������*/
#define SIP_API_ALLOC_PARMLIST(_inList, _outList, _num, _unitSize, _funcPtr, _msg)	\
{	\
	U16 _size;		\
	U16 _index;	\
	S16 _rc;	\
	_size = num * (sizeof(PTR));		\
	SIP_API_GETMEM(_outList, _size, &((_msg)->memCp));		\
	_size = _unitSize;		\
	for(_index = 0; _index < _num; _index++)	\
	{	\
		SIP_API_GETMEM( (_outList)[i], _size, &((_msg)->memCp));	\
		_rc = (*(_funcPtr))((_inList)[i], (_outList)[i], _msg);	\
		SIP_API_CHK_RETVALUE(rc);		\
	}		\
	RETVALUE(_rc);	\
}

/* ����SDP�ṹ*/
#ifdef SIP_API_USE_TOKEN_SDP2
#define SIP_API_ALLOC_MSG(_accMsg, _stackMsg)	\
{	\
}
#endif

/*��ʼ��POST�ṹ*/
EXTERN PUBLIC Void InitMuPst(Pst *mu);

/*���ջ�Ļ���*/
EXTERN PUBLIC S16 muCheckStackActive(SpId spId);

/*�����¼��ṹ*/
EXTERN PUBLIC S16 mgAllocEventMem(Ptr *memPtr,Size memSize);

/*�ͷ���Ϣ�ṹ*/
EXTERN PUBLIC Void muFreeMgcoMsg(MgMgcoMsg   *msg);

#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif



