/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SIP Layer

     Type:     C include file

     Desc:     Defines required by SIP layer

     File:     so_cm.h

     Sid:      so_cm.h@@/main/4 - Tue Apr 20 12:46:02 2004

     Prg:      dg

*********************************************************************21*/


#ifndef __SO_CMH__
#define __SO_CMH__

/* Entity type */
#define SO_ENT_UA LSO_ENT_UA
#define SO_ENT_NS LSO_ENT_NS

/* Hash size */
#define SO_HASH_SZ 16

/* IPV4 string size */
#define SO_IPV4_STRSIZE 16

/* Defines the anonymous string */
#define SO_ANONYMOUS "Anonymous"

/* Status code type devisor */
#define SO_STATUS_INTERVAL 100

/* Granularity of dynamic ** array allocation */
#define SO_DYNLIST_GRANULARITY 1

/* ASCII codes for CR and LF */
#define SO_ASCII_CR  13  /* carriage return */
#define SO_ASCII_LF  10  /* line feed       */
#define SO_ASCII_SP  32  /* space           */
#define SO_ASCII_TB  9   /* tab             */

/* CRLF CRLF not found in message */
#define SO_MH_NO_CRLF 0

#define SO_CM_START_YEAR   2000         /* Year from which dates are calc'ed  */
#define SO_CM_START_MONTH  1            /* Month from which dates are calc'ed */
#define SO_CM_START_WKDAY  SO_WKDAY_SAT /* Jan 1, 2000 was a Saturday         */
#define SO_CM_DAYS_IN_WEEK 7            /* Days in week                       */

#define SO_CM_SEC_IN_MIN   60           /* Seconds in month                   */
#define SO_CM_SEC_IN_HOUR    3600      /* Seconds in hour                    */
#define SO_CM_SEC_IN_DAY     86400     /* Seconds in day                     */
#define SO_CM_SEC_IN_MONTH   2592000   /* 30*24*60*60 */
#define SO_CM_SEC_IN_YEAR    31536000  /* 365*24*60*60 */
/* so019.201: Change the offset unit to one hour*/
#define SO_CM_SEC_IN_OFFSET_UNIT 60*60  /* Seconds in unit of GMT offset      */

/* Invalid header types */
#define SO_REQUESTHEADER_INVALID    0   /* Invalid request header  */
#define SO_RESPONSEHEADER_INVALID   0   /* Invalid response header */

/* Maximum number of mandatory headers */
#define SO_MAX_MND_HDR   10

/* Convert hex digit to decimal */
#define SO_GET_HEX_NIBBLE(hx)\
((hx >= 'a' && hx <= 'f') ? (hx - 'a' + 10) :\
((hx >= 'A' && hx <= 'F') ? (hx - 'A' + 10) :\
(hx - '0')))


#define SO_LOWERCASE(_ch)\
((_ch >= 'A' && _ch <= 'Z')? _ch + ('a' - 'A') : _ch)

#define SO_NEXT_UDP_ADDR(_sys)                                                \
{                                                                             \
   ((_sys)->currentUdpAddr =                                                  \
      (U16)(((_sys)->currentUdpAddr + 1) % ((_sys)->nmbTptAddr)));            \
}

#define SO_NEXT_TCP_ADDR(_sys)                                                \
{                                                                             \
   ((_sys)->currentTcpAddr =                                                  \
      (U16)(((_sys)->currentTcpAddr + 1) % ((_sys)->nmbTptAddr)));            \
}

#define SO_NEXT_SSAP_IDX(_sys)                                                \
{                                                                             \
   ((_sys)->currentSSap =                                                     \
      (U16)(((_sys)->currentSSap + 1) % ((_sys)->nmbSSap)));                  \
}

/* _evnt == NULL means heap allocation */
#define SO_CPY_HOST(_dst, _src, _evnt, ret)                                \
{                                                                          \
   (ret) = ROK;                                                            \
   if ((_src)->hostType.pres == PRSNT_NODEF)                               \
   {                                                                       \
      (_dst)->hostType = (_src)->hostType;                                 \
      if (SO_CMP_TKN_LIT(&((_src)->hostType), SO_HOST_HOSTNAME) == TRUE)   \
      {                                                                    \
         SO_FILL_TKNSTROSXL(&((_dst)->t.hostName),                         \
                           (_src)->t.hostName.val,                         \
                           (_src)->t.hostName.len,                         \
                           _evnt, ret);                                    \
      }                                                                    \
      else if (SO_CMP_TKN_LIT(                                             \
         &((_src)->hostType), SO_HOST_IPV4ADDRESS) == TRUE)                \
      {                                                                    \
         SO_FILL_TKNU8(&((_dst)->t.ipv4Address.pres), PRSNT_NODEF)         \
         SO_FILL_TKNU8(&((_dst)->t.ipv4Address.adr1),                      \
                        (_src)->t.ipv4Address.adr1.val);                   \
         SO_FILL_TKNU8(&((_dst)->t.ipv4Address.adr2),                      \
                        (_src)->t.ipv4Address.adr2.val);                   \
         SO_FILL_TKNU8(&((_dst)->t.ipv4Address.adr3),                      \
                        (_src)->t.ipv4Address.adr3.val);                   \
         SO_FILL_TKNU8(&((_dst)->t.ipv4Address.adr4),                      \
                        (_src)->t.ipv4Address.adr4.val);                   \
      }                                                                    \
      else if (SO_CMP_TKN_LIT(                                             \
         &((_src)->hostType), SO_HOST_IPV6REFERENCE) == TRUE)              \
      {                                                                    \
         SO_FILL_TKNSTROSXL(&((_dst)->t.ipv6Reference),                    \
                           (_src)->t.ipv6Reference.val,                    \
                           (_src)->t.ipv6Reference.len,                    \
                           _evnt, ret);                                    \
      }                                                                    \
   }                                                                       \
}

#define SO_ADD_MSG_TO_TRAN(_msg, _tranCb)                                     \
{                                                                             \
   (_msg)->tranCb = _tranCb;                                                  \
   (Void) soCmResizeList((PTR *)&(_tranCb)->msgCbLst, &(_tranCb)->nmbMsg,     \
            (U16) ((_tranCb)->nmbMsg + 1));                                   \
   (_tranCb)->msgCbLst[(_tranCb)->nmbMsg - 1] = _msg;                         \
}


#define SO_FILL_TKNU8(a,val1) \
{\
   (a)->pres = PRSNT_NODEF;\
   (a)->val  = (U8)val1;\
}

#define SO_FILL_TKNU16(a,val1) {\
   (a)->pres = PRSNT_NODEF;\
   (a)->val  = (U16)(val1);\
}

#define SO_FILL_TKNU32(a,val1) {\
   (a)->pres = PRSNT_NODEF;\
   (a)->val  = (U32)(val1);\
}

/* use this macro for .numComp fields in SIP sequences */
#define SO_FILL_NUM_COMP(a,val1) {\
   if (val1 == 0)\
   {\
      (a)->pres = NOTPRSNT;\
      (a)->val  = (U16)(0);\
   }\
   else\
   {\
      (a)->pres = PRSNT_NODEF;\
      (a)->val  = (U16)(val1);\
   }\
}

/* use this macro for .numComp fields in SIP sequences */
#define SO_GET_NUM_COMP(a) \
   ((U16)(((a)->pres != NOTPRSNT) ? (a)->val : 0))

/* should pass this macro val1 = NOTPRSNT or PRSNT_NODEF */
#define SO_FILL_TKNPRES(a,val1) \
{\
   (a)->pres = val1;\
   (a)->val  = 0;  \
}

/* Allocates and fills a TKNSTROSXL
 * If _evnt == NULL an SOALLOC is performed from the local heap,
 * otherwise cmGetMem is used to allocate as part of an event-
 * structure.
 */
#define SO_FILL_TKNSTROSXL(a, val1, LEN, _evnt, ret)\
{\
   U8 FTSB_i         = 0;\
   ret               = ROK;\
   (a)->pres         = PRSNT_NODEF;\
   (a)->len          = LEN;\
   (a)->val          = NULLP;\
   if (_evnt == (SoEvnt *)NULLP)\
   {\
      SOALLOC(&((a)->val), LEN);\
   }\
   else\
   {\
      (Void) cmGetMem(&(_evnt)->memCp, (Size)(LEN*sizeof((a)->val[0])),\
                        (Ptr *)(&((a)->val)));\
   }\
   if ((a)->val == NULLP)\
       ret = RFAILED;\
                     \
   else\
   for (FTSB_i=0; FTSB_i < LEN; FTSB_i++)\
   {\
      (a)->val[FTSB_i] = (val1)[FTSB_i];\
   }\
}

/* Allocates an empty TKNSTROSXL
 * If _evnt == NULL an SOALLOC is performed from the local heap,
 * otherwise cmGetMem is used to allocate as part of an event-
 * structure.
 */
#define SO_NEW_TKNSTROSXL(a, LEN, _evnt)\
{\
   SoEvnt *FTSB_evnt = _evnt;\
   (a)->pres         = PRSNT_NODEF;\
   (a)->len          = LEN;\
   if (FTSB_evnt != (SoEvnt *)NULLP)\
   {\
      (Void) cmGetMem(&(_evnt)->memCp, (Size)((a)->len*sizeof((a)->val[0])),\
                        (Ptr *)(&((a)->val)));\
   }\
   else\
   {\
      SOALLOC(&((a)->val), LEN);\
   }\
}

/* if evnt == NULLP SOALLOC is used, otherwise cmGetMem */
#define SO_COPY_TKNSTROSXL(dst, src, evnt)                  \
{                                                           \
   SoEvnt *_evnt = evnt;                                    \
   if (_evnt != (SoEvnt *)NULLP)                            \
   {                                                        \
      (Void) cmGetMem(&(evnt)->memCp,                       \
         (Size)((src)->len), (Ptr *)(&((dst)->val)));       \
   }                                                        \
   else                                                     \
   {                                                        \
      SOALLOC(&((dst)->val), (src)->len);                   \
   }                                                        \
   (Void) cmMemcpy (( U8 *)((dst)->val), (U8 *)(src)->val,  \
                   (PTR) (src)->len);                       \
   (dst)->pres = PRSNT_NODEF;                               \
   (dst)->len  = (src)->len;                                \
}


/* Fills a TknStr16 up to a given length from srcStr */
/* Implicitly assumes len1 <= 16. */

#define SO_FILL_TKNSTR16(dscId,srcStr,len1)        \
{                                                  \
   U8 FTS16i      = 0;                             \
   (dscId)->pres  = PRSNT_NODEF;                   \
   (dscId)->len   = len1;                          \
                                                   \
   for (FTS16i = 0; FTS16i < len1; FTS16i++)       \
   {                                               \
      (dscId)->val[FTS16i] = srcStr[FTS16i];       \
   }                                               \
}

#define SO_FILL_TKNSTR32(dscId,srcStr,len1)        \
{                                                  \
   U8 FTS16i      = 0;                             \
   (dscId)->pres  = PRSNT_NODEF;                   \
   (dscId)->len   = len1;                          \
   for (FTS16i = 0; FTS16i < len1; FTS16i++)       \
   {                                               \
      (dscId)->val[FTS16i] = srcStr[FTS16i];       \
   }                                               \
}

#define SO_FILL_TKNSTR16X(dscId,srcStr,len1)       \
{                                                  \
   U8 FTS16i      = 0;                             \
   (dscId)->pres  = PRSNT_NODEF;                   \
   (dscId)->len   = 16;                            \
                                                   \
   for (FTS16i=0; FTS16i < len1; FTS16i++)         \
   {                                               \
      (dscId)->val[FTS16i] = srcStr[FTS16i];       \
   }                                               \
                                                   \
   for (FTS16i=len1; FTS16i < 16; FTS16i++)        \
   {                                               \
      (dscId)->val[FTS16i] = ' ';                  \
   }                                               \
}

/* Compare macros for comparing two tokens */
#define SO_CMP_TKN(a1,a2)                          \
(((a1)->pres == PRSNT_NODEF) &&                    \
((a2)->pres == PRSNT_NODEF) &&                     \
((a1)->val == (a2)->val))

#define SO_CMP_TKNSTR(a1, a2)                      \
(((a1)->pres == PRSNT_NODEF) &&                    \
((a2)->pres == PRSNT_NODEF) &&                     \
((a1)->len == (a2)->len) &&                        \
(!cmStrncmp((a1)->val, (a2)->val, (a1)->len)))


/* Compare macros for comparing tokens with literals */
#define SO_CMP_TKN_LIT(a,val1)                     \
(((a)->pres == PRSNT_NODEF) && ((a)->val == val1))

#define SO_CMP_TKNSTR_LIT(a, srcStr, len1)         \
(((a)->pres == PRSNT_NODEF) &&                     \
((a)->len == len1) &&                              \
(!cmMemcmp((a)->val, srcStr, len1)))

/* so041.201: compare macro for comparing tokens ignoring difference in case */
#define SO_CMP_TKNSTR_CAS(a, srcStr, len1)         \
(((a)->pres == PRSNT_NODEF) &&                     \
((a)->len == len1) &&                              \
(!soCmStrcasecmp((a)->val, srcStr)))

/* Compare macros for IPv4 */
#define SO_CMP_IPV4(a1, a2)                                                    \
(((a1)->pres.pres == PRSNT_NODEF) &&                                           \
 ((a2)->pres.pres == PRSNT_NODEF) &&                                           \
 (SO_CMP_TKN((&(a1)->adr1),(&(a2)->adr1))) &&                                  \
 (SO_CMP_TKN((&(a1)->adr2),(&(a2)->adr2))) &&                                  \
 (SO_CMP_TKN((&(a1)->adr3),(&(a2)->adr3))) &&                                  \
 (SO_CMP_TKN((&(a1)->adr4),(&(a2)->adr4))))

/* Indeterminate event structure macros -- may return NULLP */
#define SO_MADDR_FROM_VIA(v, x, i)                                             \
{                                                                              \
   v = (SoHost *) NULLP;                                                       \
   if (SO_GET_NUM_COMP(&(x)->viaItem[0]->viaParams.numComp) != 0)              \
   {                                                                           \
      if ((x)->viaItem[0]->viaParams.viaParam[i]->viaParamType.pres            \
          == PRSNT_NODEF)                                                      \
      {                                                                        \
         if ((x)->viaItem[0]->viaParams.viaParam[i]->viaParamType.val          \
             == SO_VIAPARAM_MADDR)                                             \
         {                                                                     \
            v = &(x)->viaItem[0]->viaParams.viaParam[i]->t.maddr;              \
         }                                                                     \
      }                                                                        \
   }                                                                           \
}


#define SO_RECEIVED_FROM_VIA(v, x, i)                                          \
{                                                                              \
   v = (SoHost *) NULLP;                                                       \
   if (SO_GET_NUM_COMP(&(x)->viaItem[0]->viaParams.numComp) != 0)              \
   {                                                                           \
      if ((x)->viaItem[0]->viaParams.viaParam[i]->viaParamType.pres            \
          == PRSNT_NODEF)                                                      \
      {                                                                        \
         if ((x)->viaItem[0]->viaParams.viaParam[i]->viaParamType.val          \
             == SO_VIAPARAM_RECEIVED)                                          \
         {                                                                     \
            v = &(x)->viaItem[0]->viaParams.viaParam[i]->t.received;           \
         }                                                                     \
      }                                                                        \
   }                                                                           \
}

/*-------- Get Request Method in CSEQ Header ----------*/
#define SO_METHOD_FROM_CSEQ(met, cSeq)                     \
{                                                          \
   if ((cSeq)->method.type.val == SO_METHOD_METHODSTD)     \
       (met) =  (cSeq)->method.t.std.val;                  \
   else                                                    \
       (met) =  SOT_ET_UNKNOWN;                            \
}




#define SO_ADDRSPEC_FROM_ADDRCH(v, x)                                          \
{                                                                              \
   v = (SoAddrSpec *)NULLP;                                                    \
                                                                               \
   if ((x) != (SoAddrCh *)NULLP)                                               \
   {                                                                           \
      if (SO_CMP_TKN_LIT(&(x)->addrChType, SO_ADDRCH_NAMEADDR))                \
      {                                                                        \
         if ((x)->t.nameAddr.pres.pres == PRSNT_NODEF)                         \
         {                                                                     \
            v = &((x)->t.nameAddr.addrSpec);                                   \
         }                                                                     \
      }                                                                        \
      else if (SO_CMP_TKN_LIT(&(x)->addrChType, SO_ADDRCH_ADDRSPEC))           \
      {                                                                        \
         v = &((x)->t.addrSpec);                                               \
      }                                                                        \
   }                                                                           \
}

#define SO_HOSTPORT_FROM_ADDRSPEC(v, x)                                        \
{                                                                              \
   v = (SoHostPort *)NULLP;                                                    \
                                                                               \
   if (x != (SoAddrSpec *)NULLP)                                               \
   {                                                                           \
      if ((SO_CMP_TKN_LIT(&(x)->addrSpecType, SO_ADDRSPEC_SIPURL)) ||          \
          (SO_CMP_TKN_LIT(&(x)->addrSpecType, SO_ADDRSPEC_SIPSURL)) ||         \
          (SO_CMP_TKN_LIT(&(x)->addrSpecType, SO_ADDRSPEC_IMURL)))             \
      {                                                                        \
         if ((x)->t.sipUrl.pres.pres == PRSNT_NODEF)                           \
         {                                                                     \
            if ((x)->t.sipUrl.hostPort.pres.pres == PRSNT_NODEF)               \
            {                                                                  \
               v = &((x)->t.sipUrl.hostPort);                                  \
            }                                                                  \
         }                                                                     \
      }                                                                        \
   }                                                                           \
}

#define SO_SIPURL_FROM_ADDRSPEC(v, x)                                          \
{                                                                              \
   v = (SoSipUrl *)NULLP;                                                      \
                                                                               \
   if (x != (SoAddrSpec *)NULLP)                                               \
   {                                                                           \
      if ((SO_CMP_TKN_LIT(&(x)->addrSpecType, SO_ADDRSPEC_SIPURL))  ||         \
          (SO_CMP_TKN_LIT(&(x)->addrSpecType, SO_ADDRSPEC_SIPSURL)) ||         \
          (SO_CMP_TKN_LIT(&(x)->addrSpecType, SO_ADDRSPEC_IMURL)))             \
      {                                                                        \
         if ((x)->t.sipUrl.pres.pres == PRSNT_NODEF)                           \
         {                                                                     \
            v = &((x)->t.sipUrl);                                              \
         }                                                                     \
      }                                                                        \
   }                                                                           \
}

/* User from SIP URL */
#define SO_USER_FROM_SIPURL(v, x)                                              \
{                                                                              \
   v = (TknStrOSXL *)NULLP;                                                    \
   if (x != (SoSipUrl *)NULLP)                                                 \
   {                                                                           \
      if ((x)->pres.pres == PRSNT_NODEF)                                       \
      {                                                                        \
         if ((x)->userInfo.pres.pres == PRSNT_NODEF)                           \
         {                                                                     \
            {                                                                  \
               if ((x)->userInfo.userType.value.pres == PRSNT_NODEF)            \
               {                                                               \
                  v = &(x)->userInfo.userType.value;                            \
               }                                                               \
            }                                                                  \
         }                                                                     \
      }                                                                        \
   }                                                                           \
}

/* User type from SIP URL */
#define SO_USERTYPE_FROM_SIPURL(v, x)                                          \
{                                                                              \
   v = (TknU8 *)NULLP;                                                         \
   if ((x)->pres.pres == PRSNT_NODEF)                                          \
   {                                                                           \
      if ((x)->userInfo.pres.pres == PRSNT_NODEF)                              \
      {                                                                        \
         {                                                                     \
            v = &(x)->userInfo.userType.userType;                              \
         }                                                                     \
      }                                                                        \
   }                                                                           \
}

/* Password from SIP URL */
#define SO_PASSWORD_FROM_SIPURL(v, x)                                          \
{                                                                              \
   v = (TknStrOSXL *)NULLP;                                                    \
   if (x != (SoSipUrl *)NULLP)                                                 \
   {                                                                           \
      if ((x)->pres.pres == PRSNT_NODEF)                                       \
      {                                                                        \
         if ((x)->userInfo.pres.pres == PRSNT_NODEF)                           \
         {                                                                     \
            if ((x)->userInfo.password.pres == PRSNT_NODEF)                    \
            {                                                                  \
               v = &(x)->userInfo.password;                                    \
            }                                                                  \
         }                                                                     \
      }                                                                        \
   }                                                                           \
}

/* retrieve string from address extension */
#define SO_TKNSTR_FROM_GENERICPARAM(v, x)                                      \
{                                                                              \
   v = (TknStrOSXL *)NULLP;                                                    \
                                                                               \
   if (x != (SoParameter *)NULLP)                                              \
   {                                                                           \
      if ((x)->pres.pres == PRSNT_NODEF)                                       \
      {                                                                        \
         if((x)->paramVal.valueType.pres == PRSNT_NODEF)                       \
         {                                                                     \
            v = &(x)->paramVal.value;                                          \
         }                                                                     \
      }                                                                        \
   }                                                                           \
}

/* Descriptor-part from absolute URI */
#define SO_DESCPART_FROM_ABSURI(v, x)                                          \
{                                                                              \
   v = (TknStrOSXL *)NULLP;                                                    \
   if ((x)->pres.pres == PRSNT_NODEF)                                          \
   {                                                                           \
      if ((x)->absUriDesc.pres == PRSNT_NODEF)                                 \
      {                                                                        \
         v = &(x)->absUriDesc;                                                 \
      }                                                                        \
   }                                                                           \
}

/* Scheme-part from absolute URI */
#define SO_SCHEME_FROM_ABSURI(v, x)                                            \
{                                                                              \
   v = (TknStrOSXL *)NULLP;                                                    \
   if ((x)->pres.pres == PRSNT_NODEF)                                          \
   {                                                                           \
      if ((x)->scheme.pres == PRSNT_NODEF)                                     \
      {                                                                        \
         v = &(x)->scheme;                                                     \
      }                                                                        \
   }                                                                           \
}

#define SO_HOSTTYPE_FROM_HOSTPORT(v, x)                                        \
{                                                                              \
   v = (TknU8 *)NULLP;                                                         \
   if (x != (SoHostPort *)NULLP)                                               \
   {                                                                           \
      if ((x)->pres.pres == PRSNT_NODEF)                                       \
      {                                                                        \
         if ((x)->host.hostType.pres == PRSNT_NODEF)                           \
         {                                                                     \
            v = &((x)->host.hostType);                                         \
         }                                                                     \
      }                                                                        \
   }                                                                           \
}

#define SO_HOSTNAME_FROM_HOSTPORT(v, x)                                        \
{                                                                              \
                                                                               \
   v = (TknStrOSXL *)NULLP;                                                    \
                                                                               \
   if (x != (SoHostPort *)NULLP)                                               \
   {                                                                           \
      if ((x)->pres.pres == PRSNT_NODEF)                                       \
      {                                                                        \
         if (SO_CMP_TKN_LIT(&(x)->host.hostType, SO_HOST_HOSTNAME))            \
         {                                                                     \
            if ((x)->host.t.hostName.pres == PRSNT_NODEF)                      \
            {                                                                  \
               v = &((x)->host.t.hostName);                                    \
            }                                                                  \
         }                                                                     \
      }                                                                        \
   }                                                                           \
}

#define SO_IPV4ADDRESS_FROM_HOSTPORT(v, x)                                     \
{                                                                              \
                                                                               \
   v = (SoIpv4Address *)NULLP;                                                 \
                                                                               \
   if (x != (SoHostPort *)NULLP)                                               \
   {                                                                           \
      if ((x)->pres.pres == PRSNT_NODEF)                                       \
      {                                                                        \
         if (SO_CMP_TKN_LIT(&(x)->host.hostType, SO_HOST_IPV4ADDRESS))         \
         {                                                                     \
            v = &((x)->host.t.ipv4Address);                                    \
         }                                                                     \
      }                                                                        \
   }                                                                           \
}

#define SO_IPV6ADDRESS_FROM_HOSTPORT(v, x)                                     \
{                                                                              \
                                                                               \
   v = (TknStrOSXL *)NULLP;                                                    \
                                                                               \
   if (x != (SoHostPort *)NULLP)                                               \
   {                                                                           \
      if ((x)->pres.pres == PRSNT_NODEF)                                       \
      {                                                                        \
         if (SO_CMP_TKN_LIT(&(x)->host.hostType, SO_HOST_IPV6REFERENCE))       \
         {                                                                     \
            v = &((x)->host.t.ipv6Reference);                                  \
         }                                                                     \
      }                                                                        \
   }                                                                           \
}

/* Get status code */
#define SO_STAT_CODE_FROM_RSP(v, x)                                            \
{                                                                              \
   v = (TknU16 *)NULLP;                                                        \
                                                                               \
   if ((x)->statusLine.pres.pres == PRSNT_NODEF)                               \
   {                                                                           \
      if ((x)->statusLine.statusCode.pres == PRSNT_NODEF)                      \
      {                                                                        \
         v = &((x)->statusLine.statusCode);                                    \
      }                                                                        \
   }                                                                           \
}
/* Determine if message is a request/response */
#define SO_MSGTYPE_REQ(a)\
   (SO_CMP_TKN_LIT(&(a)->sipMessageType,\
      SO_SIPMESSAGE_REQUEST))

#define SO_MSGTYPE_RSP(a)\
   (SO_CMP_TKN_LIT(&(a)->sipMessageType,\
      SO_SIPMESSAGE_RESPONSE))

/* Determine if DateTime is set ( non-zero ) */
#define SO_DATETIME_SET(a)\
     (((a)->month!=0)||\
      ((a)->day!=0)||\
      ((a)->year!=0)||\
      ((a)->hour!=0)||\
      ((a)->min!=0)||\
      ((a)->sec!=0)||\
      ((a)->tenths!=0))


/* Extended SIP error codes / descriptions */

#define SO_EXTRSP_NONE                0
#define SO_EXTRSP_RESOURCES_LOW       1
#define SO_EXTRSP_INVMETHOD_REG_ONLY  2
#define SO_EXTRSP_DISABLED            3
#define SO_EXTRSP_REMREG_FAIL         4
#define SO_EXTRSP_3RDPARTY            5
#define SO_EXTRSP_REQURI_MISMATCH     6


/*-------- Extract CSEQ Header from  event -------*/
#define SO_GET_CSEQ_FROM_EVENT(evnt, cSeq)                                   \
{                                                                            \
  if (soCmFindHdrChoice ((evnt), (U8 **) &(cSeq), SO_HEADER_GEN_CSEQ) != ROK)\
  {                                                                          \
          SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,                     \
                "\n No CSEQ Found  \n"));                                    \
          RETVALUE (RFAILED);                                                \
  }                                                                          \
}


/*--------- Extract VIA Header from event --------*/
#define SO_GET_VIA_FROM_EVENT(evnt, via)                            \
{                                                                   \
  if (soCmFindHdrChoice ((evnt), (U8 **) &(via), SO_HEADER_GEN_VIA) != ROK)\
          RETVALUE (RFAILED);                                       \
}


/*--- Extract CALL Identifier Header from event --*/
#define SO_GET_CALLID_FROM_EVENT(evnt, callId)                      \
{                                                                   \
 if (soCmFindHdrChoice((evnt), (U8 **) &(callId), SO_HEADER_GEN_CALLID) != ROK)\
        RETVALUE (RFAILED);                                         \
}


/*--------- Extract "TO" Header from event -------*/
#define SO_GET_TOHDR_FROM_EVENT(evnt, to)                              \
{                                                                      \
 if (soCmFindHdrChoice((evnt), (U8 **) &(to), SO_HEADER_GEN_TO) != ROK)\
        RETVALUE (RFAILED);                                            \
}

/*-------- Extract "FROM" Header from event ------*/
#define SO_GET_FROMHDR_FROM_EVENT(evnt, from)                            \
{                                                                        \
 if (soCmFindHdrChoice((evnt), (U8 **) &(from), SO_HEADER_GEN_FROM) != ROK)\
        RETVALUE (RFAILED);                                              \
}

#endif /* __SO_CMH__ */

/********************************************************************30**

         End of file:     so_cm.h@@/main/4 - Tue Apr 20 12:46:02 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision History:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---     ms   1. initial release.
/main/4+  so019.201  sg   1. Change the offset unit to one hour.
/main/4+  so041.201  ng   1. Compare macro for comparing strings ignoring 
                             difference in case
*********************************************************************91*/
