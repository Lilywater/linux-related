/**********************************************************************

    Name:   so_nms.h 

    Type:   C include file

    Desc:   

    File:   so_nms.h

    Sid:    

    Created by: 

**********************************************************************/


#ifndef _SO_NMS_H_
#define _SO_NMS_H_


#ifdef __cplusplus
extern "C" {
#endif
/*--------------------------------------------------------*/

/*--------------------------------------------------------*/



EXTERN S16 soNmsRecvInitCfg(tb_record* prow);
EXTERN S16 soNmsCfgMsg();
EXTERN unsigned char soInitCfgCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow);
EXTERN VOID soResetCfgData( );


#ifdef __cplusplus
}
#endif



#endif

