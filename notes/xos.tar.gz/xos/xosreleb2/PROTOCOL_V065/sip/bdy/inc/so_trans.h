/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/
/********************************************************************20**

     Name:    SIP - external interface - portable

     Type:    C source file

     Desc:    Transaction layer 

     File:    so_trans.h

     Sid:      so_trans.h@@/main/2 - Tue Apr 20 12:47:20 2004

     Prg:     ps 

*********************************************************************21*/
/*------------- Invite/NonInvite Client Transaction States ----------------*/

enum
{
  SO_TRANS_CLIENT_IDLE       =  0,
  SO_TRANS_CLIENT_CALLING    =  1, /* Only for Invite Client     */
  SO_TRANS_CLIENT_TRYING     =  1, /* Only for Non Invite Client */
  SO_TRANS_CLIENT_PROCEEDING =  2,
  SO_TRANS_CLIENT_COMPLETED  =  3,
  SO_TRANS_CLIENT_TERMINATED =  4
};


#define SO_TRANS_MAX_CLIENT_STATES   5 /* Total Client States        */


/*----------------- Invite Server Transaction States ---------------------*/

/*-- so017.201: Added completed state to wait for retx INVITE --*/
enum
{
  SO_TRANS_INV_SERVER_IDLE       =  0,
  SO_TRANS_INV_SERVER_PROCEEDING =  1,
  SO_TRANS_INV_SERVER_COMPLETED  =  2,
  SO_TRANS_INV_SERVER_CONFIRMED  =  3,
  SO_TRANS_INV_SERVER_AFTER_2XX  =  4,
  SO_TRANS_INV_SERVER_TERMINATED =  5
};

/*--------------- NON Invite Server Transaction States -------------------*/

enum
{
  SO_TRANS_NON_INV_SERVER_IDLE        = 0,
  SO_TRANS_NON_INV_SERVER_TRYING      = 1, /* Only for Non Invite Client */
  SO_TRANS_NON_INV_SERVER_PROCEEDING  = 2, 
  SO_TRANS_NON_INV_SERVER_COMPLETED   = 3,
  SO_TRANS_NON_INV_SERVER_TERMINATED  = 4
};


#define SO_TRANS_MAX_INV_SERVER_STATES     6 /* Total Server States        */
#define SO_TRANS_MAX_NONINV_SERVER_STATES  5 /* Total Server States        */

/*------------------------- Transaction Types ----------------------------*/

enum
{
  SO_TRANS_INV_CLIENT     = 1,
  SO_TRANS_NON_INV_CLIENT = 2,
  SO_TRANS_INV_SERVER     = 3,
  SO_TRANS_NON_INV_SERVER = 4
};


/*--------------- CLIENT Transaction State m/c Triggers ------------------*/

#define SO_TRANS_REQ_FROM_USER      0  /*----- SIP user sends request ----*/
#define SO_TRANS_1XX_FROM_PEER      1  /*---- 1XX response from peer -----*/
/*---- Specific to invite client ----*/
#define SO_TRANS_2XX_FROM_PEER      2  /*----- 2XX response from peer ----*/
#define SO_TRANS_3_6XX_FROM_PEER    3  /*--- 3XX-6XX response from peer --*/
#define SO_TRANS_TIMER_A_EXPIRES    4  /*-- Invite Client Timer A Fires --*/
#define SO_TRANS_TIMER_B_EXPIRES    5  /*-- Invite Client Timer B Fires --*/
#define SO_TRANS_TIMER_D_EXPIRES    6  /*-- Invite Client Timer D Fires --*/
#define SO_TRANS_TIMER_NAT_EXPIRES  7  /*- Invite Client Nat Timer Fires -*/

/*-- Specific to non invite client --*/
#define SO_TRANS_2_6XX_FROM_PEER    2  /*---- Final response from peer ---*/
#define SO_TRANS_TIMER_E_EXPIRES    3  /* Non-Invite Client Timer E Fires */
#define SO_TRANS_TIMER_F_EXPIRES    4  /* Non-Invite Client Timer F Fires */
#define SO_TRANS_TIMER_K_EXPIRES    5  /* Non-Invite Client Timer K Fires */

/*-------------- SERVER Transaction State m/c Triggers -------------------*/
/*-- so017.201:TimerJ is applicable for both Inv and NonInv Transaction --*/ 

#define SO_TRANS_REQ_FROM_PEER      0  /*- Request indication from transport -*/
#define SO_TRANS_1XX_FROM_USER      1  /*-- 1XX response from SIP user ---*/
#define SO_TRANS_TIMER_J_EXPIRES    2  /* Inv/NonInv Server Timer J Fires */
/*---- Specific to invite server ----*/
#define SO_TRANS_2XX_FROM_USER      3  /*-- 2XX response from SIP user ---*/
#define SO_TRANS_3_6XX_FROM_USER    4  /* 3XX-6XX response from SIP user -*/
#define SO_TRANS_TIMER_G_EXPIRES    5  /*- Invite Server Timer G Fires ---*/
#define SO_TRANS_ACK_FROM_PEER      6  /*-- ACK message from transport ---*/
#define SO_TRANS_TIMER_H_EXPIRES    7  /*- Invite Server Timer H Fires ---*/
#define SO_TRANS_TIMER_I_EXPIRES    8  /*- Invite Server Timer I Fires ---*/
/*-- Specific to non invite server --*/
#define SO_TRANS_2_6XX_FROM_USER    3  /*-- Final response from SIP user --*/


/*------------ Error Code Returned in SoDlgErrInd primitive -------------*/
#define SO_TRANS_TIMEOUT        1 /* No response from peer               */
#define SO_TRANS_NO_ACK         2 /* No ACK rom peer for 3-6xx respose   */
#define SO_TRANS_REQ_ENC_FAILED 3 /* Reqeuest Encoding failed 
                                     (multithreaded encoder only)        */
#define SO_TRANS_RSP_ENC_FAILED 4 /* Response Encoding failed 
                                     (multithreaded encoder only)        */
#define SO_TRANS_ERROR          5 /* Error in tranaction processing      */


/*---- uaType field in function soTxnUaCreateTrans ----*/
enum
{
  SO_UAC =  1,
  SO_UAS =  2
};

/*------- Method Mask In Transaction Identifier -------*/
#define SO_TRANSID_METHOD_MASK 0x00FF0000

/*--- Allocate transaction id in transaction Cb ---*/
/*
 * Transaction ID Format is as follows
 * <4th octet as 0x00>
 * <3rd octet as transaction method>
 * <2nd and 1st octet as running integer>
 */
#define SO_TXN_AllOC_TRANSID(transId, method, entityCb)      \
{                                                            \
    (transId) = (entityCb)->nextTransId;                     \
    (transId) &= ~SO_TRANSID_METHOD_MASK;                    \
    (transId) |= (U32)((U8)(method) << 16);                  \
                                                             \
    (entityCb)->nextTransId++;                               \
                                                             \
    if ((entityCb)->nextTransId == 0xFFFF)                   \
         (entityCb)->nextTransId = 1;                        \
}

/*---- Update transaction id in transaction Cb ----*/
#define SO_TXN_UPDATE_TRANSID(transCb, transId)              \
{                                                            \
    (transCb)->transId = (transId);                          \
}

/*--- so017.201: Macro to check if TCB is active --*/
#define SO_TXN_ISALIVE(eventType, transCb)                       \
   /*                                                            \
    * For INVITE server transaction, we have added new state to  \
    * wait for retransmitted  INVITE for 200 O.K. This state is  \
    * not specified in RFC 3261. It is done in our implementat-  \
    * ion to make dialog matching rules simpler.                 \
    * For all practicle purpose,  the INVITE server transaction  \
    * does not exist in this new state except for retransmitted  \
    * INVITE request.                                            \
    */                                                           \
    ((((eventType) != SOT_ET_INVITE) &&                          \
      ((transCb)->transState == SO_TRANS_INV_SERVER_AFTER_2XX)) ? FALSE : TRUE)


/*----- Update DNS queryCb in transaction Cb ------*/
#define SO_TXN_UPDATE_QUERYCB(transCb, qCb)                  \
{                                                            \
    (transCb)->userContext.queryCb = (PTR)(qCb);             \
}

/*------- Get DNS queryCb in transaction Cb -------*/
#define SO_TXN_GET_QUERYCB(transCb) (transCb)->userContext.queryCb

/*
 * so026.201:
 * Macro to delete reference of TCB from corresponding
 * subscription control block, if present.
 */
#ifdef SO_EVENT     
#define SO_TXN_DEL_SUBS_REF(transCb)                       \
{                                                          \
    if (((transCb)->userContext.subscCb) != NULLP)         \
    {                                                      \
       (transCb)->userContext.subscCb->refCount -- ;       \
       SODBGP_SO (SO_DBGMASK_TRANS, (soCb.init.prntBuf,    \
          "\n[TRANS ] Delete Subscription. "               \
          "Type (%d), RefCount (%d)\n",                    \
          (transCb)->userContext.subscCb->type,            \
          (transCb)->userContext.subscCb->refCount));      \
    }                                                      \
}
#endif

/*
 * Macro to delete event structure from TCB. The event is
 * deleted ONLY IF user has NOT requested to save   event
 * structure.
 */   
#define SO_TXN_DEL_EVENT(transCb, evnt)                    \
{                                                          \
    if ((evnt))                                            \
       if (!((transCb)->userContext.saveMsg))              \
       {                                                   \
          soCmFreeEvent ((evnt));                          \
          (evnt) = NULLP;                                  \
       }                                                   \
}






/*----- Macro to delete encoded message buffer --------*/
#define SO_TXN_DEL_MBUF(mBuf)                              \
{                                                          \
    if ((mBuf))                                            \
    {                                                      \
       SPutMsg ((mBuf));                                   \
       (mBuf) = NULLP;                                     \
    }                                                      \
}

/*----- Macro to delete DNS Query Control Block -------*/
#define SO_TXN_DEL_QUERYCB(transCb)                        \
{                                                          \
    if ((transCb)->userContext.queryCb)                    \
    {                                                      \
      (Void) soDnsLookupRel ((transCb)->userContext.queryCb);\
      (transCb)->userContext.queryCb  = NULLP;             \
    }                                                      \
}

/*-------- Update Call Leg Information in TCB ---------*/
#define SO_TXN_UPDATE_CLEG(transCb, cLeg)                  \
{                                                          \
    (transCb)->cLeg  = (PTR)(cLeg);                        \
}

/*------ Transaction Control Block Debug Prints -------*/
#define SO_TXN_DEBUG_PRINT(transCb)                            \
{                                                              \
  SODBGP_SO (SO_DBGMASK_TRANS, (soCb.init.prntBuf, "\n[TRANS]" \
             " --TransType(%d), State(%d), Id(%lx),"           \
             " Transport(%d), CSeq(%lu), Method(%d)-- \n",     \
             (transCb)->transType, (transCb)->transState,      \
             (transCb)->transId,(transCb)->transport,          \
             (transCb)->transCSeq, (transCb)->transMethod))    \
}

/*--------- Insert VIA Header in response event -------*/
#define SO_TXN_ADD_VIA_IN_EVENT(evnt, via)                 \
{                                                          \
  SoVia *tVia;                                             \
  S16   ret1;                                              \
  ret1 = soCmFindHdrChoice ((evnt), (U8 **) &(tVia),       \
                             SO_HEADER_GEN_VIA);           \
  if (ret1 != ROK)                                         \
  {                                                        \
    ret1 = soCmCreateHdrChoice ((evnt),(U8 **) &(tVia),    \
                                SO_HEADER_GEN_VIA);        \
    if (ret1 != ROK)                                       \
       RETVALUE (SOT_ERR_UNKNOWN);                         \
                                                           \
    ret1 = soUtlCpySoVia (tVia, (via), &evnt->memCp);      \
    if (ret1 != ROK)                                       \
       RETVALUE (SOT_ERR_UNKNOWN);                         \
  }                                                        \
}

/*----- Update Extension Method in Transaction Cb -----*/
#define SO_TXN_FILL_EXT_METHOD(_transCb, _cSeq)            \
{                                                          \
  if ((_cSeq->pres.pres != NOTPRSNT) &&                    \
      (_cSeq->method.type.pres != NOTPRSNT) &&             \
      (_cSeq->method.type.val== SO_METHOD_EXTENSIONMETHOD))\
  {                                                        \
     ret = soUtlCpyTknStrOSXL(&_transCb->extMethod,        \
                              &_cSeq->method.t.ext,        \
                              NULLP);                      \
     if (ret != ROK)                                       \
       RETVALUE(RFAILED);                                  \
  }                                                        \
}
/********************************************************************30**

         End of file:     so_trans.h@@/main/2 - Tue Apr 20 12:47:20 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/2      ---      ps   1. Changed copyright header.
/main/2+   so017.201  ps   1. Dialog matching procedure modified.This include
                              adding new state in invite server transaction.
/main/2+   so026.201  ps   1. Subcription control block should be deleted
                              only after ists last reference to TCB is
                              removed.
*********************************************************************91*/
