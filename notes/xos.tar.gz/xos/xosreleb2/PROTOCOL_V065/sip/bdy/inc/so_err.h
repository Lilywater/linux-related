/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SIP Layer error file.

     Type:     C include file

     Desc:     Error Hash Defines required by SO layer

     File:     so_err.h

     Sid:      so_err.h@@/main/4 - Tue Apr 20 12:46:34 2004

     Prg:      ps

*********************************************************************21*/

#ifndef __SOERRH__
#define __SOERRH__


#define SOLOGINVSEL \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,            \
                  __FILE__, __LINE__,                                   \
                  ERRCLS_DEBUG, ESO322,                                 \
                  0, "Invalid selector");

#define SOLOGERROR(errCls, errCode, errVal, errDesc)                    \
        SLogError(soCb.init.ent, soCb.init.inst,                        \
                  soCb.init.procId, __FILE__, __LINE__,                 \
                  (ErrCls)errCls, (ErrCode)errCode,                     \
                  (ErrVal)errVal, errDesc)

#define   ESOBASE     0
#define   ERRSO       (ESOBASE   +0)    /* reserved */

#define   ESO001      (ERRSO +    1)    /*      so_cl.c: 441 */
#define   ESO002      (ERRSO +    2)    /*      so_cl.c: 622 */
#define   ESO003      (ERRSO +    3)    /*      so_cl.c: 629 */
#define   ESO004      (ERRSO +    4)    /*      so_cl.c: 636 */
#define   ESO005      (ERRSO +    5)    /*      so_cl.c: 712 */
#define   ESO006      (ERRSO +    6)    /*      so_cl.c: 798 */
#define   ESO007      (ERRSO +    7)    /*      so_cl.c: 810 */
#define   ESO008      (ERRSO +    8)    /*      so_cl.c: 890 */
#define   ESO009      (ERRSO +    9)    /*      so_cl.c: 907 */
#define   ESO010      (ERRSO +   10)    /*      so_cl.c:1175 */
#define   ESO011      (ERRSO +   11)    /*      so_cl.c:1359 */
#define   ESO012      (ERRSO +   12)    /*      so_cl.c:1838 */
#define   ESO013      (ERRSO +   13)    /*      so_cl.c:2129 */
#define   ESO014      (ERRSO +   14)    /*      so_cl.c:2169 */
#define   ESO015      (ERRSO +   15)    /*      so_cl.c:2200 */
#define   ESO016      (ERRSO +   16)    /*      so_cl.c:2226 */
#define   ESO017      (ERRSO +   17)    /*      so_cl.c:2249 */
#define   ESO018      (ERRSO +   18)    /*      so_cl.c:2261 */
#define   ESO019      (ERRSO +   19)    /*      so_cl.c:2272 */
#define   ESO020      (ERRSO +   20)    /*      so_cl.c:2324 */
#define   ESO021      (ERRSO +   21)    /*      so_cl.c:2387 */
#define   ESO022      (ERRSO +   22)    /*      so_cl.c:2721 */
#define   ESO023      (ERRSO +   23)    /*      so_cl.c:2730 */
#define   ESO024      (ERRSO +   24)    /*      so_cl.c:2772 */
#define   ESO025      (ERRSO +   25)    /*      so_cl.c:2784 */
#define   ESO026      (ERRSO +   26)    /*      so_cl.c:2798 */
#define   ESO027      (ERRSO +   27)    /*      so_cl.c:2812 */
#define   ESO028      (ERRSO +   28)    /*      so_cl.c:2866 */
#define   ESO029      (ERRSO +   29)    /*      so_cl.c:2876 */
#define   ESO030      (ERRSO +   30)    /*      so_cl.c:2905 */
#define   ESO031      (ERRSO +   31)    /*      so_cl.c:2918 */
#define   ESO032      (ERRSO +   32)    /*      so_cl.c:2931 */
#define   ESO033      (ERRSO +   33)    /*      so_cl.c:2944 */
#define   ESO034      (ERRSO +   34)    /*      so_cl.c:2991 */
#define   ESO035      (ERRSO +   35)    /*      so_cl.c:3001 */
#define   ESO036      (ERRSO +   36)    /*      so_cl.c:3047 */
#define   ESO037      (ERRSO +   37)    /*      so_cl.c:3075 */
#define   ESO038      (ERRSO +   38)    /*      so_cl.c:3201 */
#define   ESO039      (ERRSO +   39)    /*      so_cl.c:3507 */
#define   ESO040      (ERRSO +   40)    /*      so_cl.c:3577 */
#define   ESO041      (ERRSO +   41)    /*      so_cl.c:3644 */
#define   ESO042      (ERRSO +   42)    /*      so_cl.c:3716 */
#define   ESO043      (ERRSO +   43)    /*      so_cl.c:3749 */
#define   ESO044      (ERRSO +   44)    /*      so_cl.c:3798 */
#define   ESO045      (ERRSO +   45)    /*      so_cl.c:3855 */
#define   ESO046      (ERRSO +   46)    /*      so_cl.c:3933 */
#define   ESO047      (ERRSO +   47)    /*      so_cl.c:3943 */
#define   ESO048      (ERRSO +   48)    /*      so_cl.c:4035 */
#define   ESO049      (ERRSO +   49)    /*      so_cl.c:4045 */
#define   ESO050      (ERRSO +   50)    /*      so_cl.c:4114 */
#define   ESO051      (ERRSO +   51)    /*      so_cl.c:4245 */
#define   ESO052      (ERRSO +   52)    /*      so_cl.c:4255 */
#define   ESO053      (ERRSO +   53)    /*      so_cl.c:4363 */
#define   ESO054      (ERRSO +   54)    /*      so_cl.c:4373 */
#define   ESO055      (ERRSO +   55)    /*      so_cl.c:4451 */
#define   ESO056      (ERRSO +   56)    /*      so_cl.c:4688 */
#define   ESO057      (ERRSO +   57)    /*      so_cl.c:4698 */
#define   ESO058      (ERRSO +   58)    /*      so_cl.c:4852 */
#define   ESO059      (ERRSO +   59)    /*      so_cl.c:4862 */

#define   ESO060      (ERRSO +   60)    /*      so_cm.c: 296 */
#define   ESO061      (ERRSO +   61)    /*      so_cm.c:1830 */
#define   ESO062      (ERRSO +   62)    /*      so_cm.c:2182 */
#define   ESO063      (ERRSO +   63)    /*      so_cm.c:2216 */
#define   ESO064      (ERRSO +   64)    /*      so_cm.c:2232 */
#define   ESO065      (ERRSO +   65)    /*      so_cm.c:2323 */
#define   ESO066      (ERRSO +   66)    /*      so_cm.c:2333 */
#define   ESO067      (ERRSO +   67)    /*      so_cm.c:2487 */
#define   ESO068      (ERRSO +   68)    /*      so_cm.c:2556 */
#define   ESO069      (ERRSO +   69)    /*      so_cm.c:2804 */
#define   ESO070      (ERRSO +   70)    /*      so_cm.c:2873 */
#define   ESO071      (ERRSO +   71)    /*      so_cm.c:2927 */
#define   ESO072      (ERRSO +   72)    /*      so_cm.c:2939 */
#define   ESO073      (ERRSO +   73)    /*      so_cm.c:2966 */
#define   ESO074      (ERRSO +   74)    /*      so_cm.c:3056 */
#define   ESO075      (ERRSO +   75)    /*      so_cm.c:3392 */
#define   ESO076      (ERRSO +   76)    /*      so_cm.c:3559 */
#define   ESO077      (ERRSO +   77)    /*      so_cm.c:3996 */

#define   ESO078      (ERRSO +   78)    /*     so_dns.c:2304 */
#define   ESO079      (ERRSO +   79)    /*     so_dns.c:2421 */
#define   ESO080      (ERRSO +   80)    /*     so_dns.c:3578 */
#define   ESO081      (ERRSO +   81)    /*     so_dns.c:4394 */
#define   ESO082      (ERRSO +   82)    /*     so_dns.c:4402 */
#define   ESO083      (ERRSO +   83)    /*     so_dns.c:4410 */
#define   ESO084      (ERRSO +   84)    /*     so_dns.c:5520 */

#define   ESO085      (ERRSO +   85)    /*      so_ed.c:1365 */
#define   ESO086      (ERRSO +   86)    /*      so_ed.c:1489 */
#define   ESO087      (ERRSO +   87)    /*      so_ed.c:3016 */
#define   ESO088      (ERRSO +   88)    /*      so_ed.c:3402 */
#define   ESO089      (ERRSO +   89)    /*      so_ed.c:3444 */

#define   ESO090      (ERRSO +   90)    /*   so_ex_ms.c: 224 */
#define   ESO091      (ERRSO +   91)    /*   so_ex_ms.c: 311 */
#define   ESO092      (ERRSO +   92)    /*   so_ex_ms.c: 351 */
#define   ESO093      (ERRSO +   93)    /*   so_ex_ms.c: 377 */
#define   ESO094      (ERRSO +   94)    /*   so_ex_ms.c: 397 */
#define   ESO095      (ERRSO +   95)    /*   so_ex_ms.c: 428 */
#define   ESO096      (ERRSO +   96)    /*   so_ex_ms.c: 441 */

#define   ESO097      (ERRSO +   97)    /*     so_lcs.c: 651 */

#define   ESO098      (ERRSO +   98)    /*      so_li.c: 187 */
#define   ESO099      (ERRSO +   99)    /*      so_li.c: 200 */
#define   ESO100      (ERRSO +  100)    /*      so_li.c: 220 */
#define   ESO101      (ERRSO +  101)    /*      so_li.c: 234 */
#define   ESO102      (ERRSO +  102)    /*      so_li.c: 268 */
#define   ESO103      (ERRSO +  103)    /*      so_li.c: 297 */
#define   ESO104      (ERRSO +  104)    /*      so_li.c: 376 */
#define   ESO105      (ERRSO +  105)    /*      so_li.c: 390 */
#define   ESO106      (ERRSO +  106)    /*      so_li.c: 403 */
#define   ESO107      (ERRSO +  107)    /*      so_li.c: 453 */
#define   ESO108      (ERRSO +  108)    /*      so_li.c: 477 */
#define   ESO109      (ERRSO +  109)    /*      so_li.c: 489 */
#define   ESO110      (ERRSO +  110)    /*      so_li.c: 560 */
#define   ESO111      (ERRSO +  111)    /*      so_li.c: 572 */
#define   ESO112      (ERRSO +  112)    /*      so_li.c: 584 */
#define   ESO113      (ERRSO +  113)    /*      so_li.c: 596 */
#define   ESO114      (ERRSO +  114)    /*      so_li.c: 618 */
#define   ESO115      (ERRSO +  115)    /*      so_li.c: 623 */
#define   ESO116      (ERRSO +  116)    /*      so_li.c: 655 */
#define   ESO117      (ERRSO +  117)    /*      so_li.c: 676 */
#define   ESO118      (ERRSO +  118)    /*      so_li.c: 746 */
#define   ESO119      (ERRSO +  119)    /*      so_li.c: 758 */
#define   ESO120      (ERRSO +  120)    /*      so_li.c: 771 */
#define   ESO121      (ERRSO +  121)    /*      so_li.c: 818 */
#define   ESO122      (ERRSO +  122)    /*      so_li.c: 855 */
#define   ESO123      (ERRSO +  123)    /*      so_li.c: 864 */
#define   ESO124      (ERRSO +  124)    /*      so_li.c: 929 */
#define   ESO125      (ERRSO +  125)    /*      so_li.c: 940 */
#define   ESO126      (ERRSO +  126)    /*      so_li.c: 952 */
#define   ESO127      (ERRSO +  127)    /*      so_li.c:1102 */
#define   ESO128      (ERRSO +  128)    /*      so_li.c:1115 */
#define   ESO129      (ERRSO +  129)    /*      so_li.c:1129 */
#define   ESO130      (ERRSO +  130)    /*      so_li.c:1143 */

#define   ESO131      (ERRSO +  131)    /*      so_mi.c: 272 */
#define   ESO132      (ERRSO +  132)    /*      so_mi.c: 467 */
#define   ESO133      (ERRSO +  133)    /*      so_mi.c: 749 */
#define   ESO134      (ERRSO +  134)    /*      so_mi.c:1648 */
#define   ESO135      (ERRSO +  135)    /*      so_mi.c:1676 */
#define   ESO136      (ERRSO +  136)    /*      so_mi.c:1782 */
#define   ESO137      (ERRSO +  137)    /*      so_mi.c:2449 */
#define   ESO138      (ERRSO +  138)    /*      so_mi.c:2467 */
#define   ESO139      (ERRSO +  139)    /*      so_mi.c:2487 */
#define   ESO140      (ERRSO +  140)    /*      so_mi.c:2506 */
#define   ESO141      (ERRSO +  141)    /*      so_mi.c:2529 */
#define   ESO142      (ERRSO +  142)    /*      so_mi.c:2552 */
#define   ESO143      (ERRSO +  143)    /*      so_mi.c:2663 */
#define   ESO144      (ERRSO +  144)    /*      so_mi.c:3267 */
#define   ESO145      (ERRSO +  145)    /*      so_mi.c:3550 */
#define   ESO146      (ERRSO +  146)    /*      so_mi.c:4625 */
#define   ESO147      (ERRSO +  147)    /*      so_mi.c:4752 */
#define   ESO148      (ERRSO +  148)    /*      so_mi.c:4836 */
#define   ESO149      (ERRSO +  149)    /*      so_mi.c:4860 */
#define   ESO150      (ERRSO +  150)    /*      so_mi.c:4873 */
#define   ESO151      (ERRSO +  151)    /*      so_mi.c:5004 */
#define   ESO152      (ERRSO +  152)    /*      so_mi.c:5924 */
#define   ESO153      (ERRSO +  153)    /*      so_mi.c:5942 */
#define   ESO154      (ERRSO +  154)    /*      so_mi.c:6119 */
#define   ESO155      (ERRSO +  155)    /*      so_mi.c:6171 */
#define   ESO156      (ERRSO +  156)    /*      so_mi.c:6248 */
#define   ESO157      (ERRSO +  157)    /*      so_mi.c:6334 */
#define   ESO158      (ERRSO +  158)    /*      so_mi.c:6443 */
#define   ESO159      (ERRSO +  159)    /*      so_mi.c:6540 */

#define   ESO160      (ERRSO +  160)    /*      so_ns.c: 664 */

#define   ESO161      (ERRSO +  161)    /*     so_tcm.c: 381 */
#define   ESO162      (ERRSO +  162)    /*     so_tcm.c: 559 */
#define   ESO163      (ERRSO +  163)    /*     so_tcm.c: 566 */
#define   ESO164      (ERRSO +  164)    /*     so_tcm.c: 735 */
#define   ESO165      (ERRSO +  165)    /*     so_tcm.c: 879 */
#define   ESO166      (ERRSO +  166)    /*     so_tcm.c: 885 */
#define   ESO167      (ERRSO +  167)    /*     so_tcm.c:1009 */
#define   ESO168      (ERRSO +  168)    /*     so_tcm.c:1114 */
#define   ESO169      (ERRSO +  169)    /*     so_tcm.c:1244 */
#define   ESO170      (ERRSO +  170)    /*     so_tcm.c:1251 */
#define   ESO171      (ERRSO +  171)    /*     so_tcm.c:1353 */
#define   ESO172      (ERRSO +  172)    /*     so_tcm.c:1419 */
#define   ESO173      (ERRSO +  173)    /*     so_tcm.c:1487 */
#define   ESO174      (ERRSO +  174)    /*     so_tcm.c:1535 */
#define   ESO175      (ERRSO +  175)    /*     so_tcm.c:1653 */
#define   ESO176      (ERRSO +  176)    /*     so_tcm.c:1728 */
#define   ESO177      (ERRSO +  177)    /*     so_tcm.c:1800 */
#define   ESO178      (ERRSO +  178)    /*     so_tcm.c:1874 */
#define   ESO179      (ERRSO +  179)    /*     so_tcm.c:1968 */
#define   ESO180      (ERRSO +  180)    /*     so_tcm.c:2051 */
#define   ESO181      (ERRSO +  181)    /*     so_tcm.c:2104 */
#define   ESO182      (ERRSO +  182)    /*     so_tcm.c:2199 */
#define   ESO183      (ERRSO +  183)    /*     so_tcm.c:2253 */
#define   ESO184      (ERRSO +  184)    /*     so_tcm.c:2501 */
#define   ESO185      (ERRSO +  185)    /*     so_tcm.c:2563 */
#define   ESO186      (ERRSO +  186)    /*     so_tcm.c:2639 */
#define   ESO187      (ERRSO +  187)    /*     so_tcm.c:3072 */
#define   ESO188      (ERRSO +  188)    /*     so_tcm.c:3220 */
#define   ESO189      (ERRSO +  189)    /*     so_tcm.c:3345 */
#define   ESO190      (ERRSO +  190)    /*     so_tcm.c:3413 */
#define   ESO191      (ERRSO +  191)    /*     so_tcm.c:3501 */
#define   ESO192      (ERRSO +  192)    /*     so_tcm.c:3628 */
#define   ESO193      (ERRSO +  193)    /*     so_tcm.c:3740 */
#define   ESO194      (ERRSO +  194)    /*     so_tcm.c:3873 */
#define   ESO195      (ERRSO +  195)    /*     so_tcm.c:3998 */
#define   ESO196      (ERRSO +  196)    /*     so_tcm.c:4076 */
#define   ESO197      (ERRSO +  197)    /*     so_tcm.c:4171 */
#define   ESO198      (ERRSO +  198)    /*     so_tcm.c:4296 */
#define   ESO199      (ERRSO +  199)    /*     so_tcm.c:4424 */
#define   ESO200      (ERRSO +  200)    /*     so_tcm.c:4562 */
#define   ESO201      (ERRSO +  201)    /*     so_tcm.c:4632 */
#define   ESO202      (ERRSO +  202)    /*     so_tcm.c:4813 */
#define   ESO203      (ERRSO +  203)    /*     so_tcm.c:4895 */
#define   ESO204      (ERRSO +  204)    /*     so_tcm.c:4978 */
#define   ESO205      (ERRSO +  205)    /*     so_tcm.c:5060 */
#define   ESO206      (ERRSO +  206)    /*     so_tcm.c:5140 */
#define   ESO207      (ERRSO +  207)    /*     so_tcm.c:5238 */
#define   ESO208      (ERRSO +  208)    /*     so_tcm.c:5346 */
#define   ESO209      (ERRSO +  209)    /*     so_tcm.c:5431 */
#define   ESO210      (ERRSO +  210)    /*     so_tcm.c:5535 */
#define   ESO211      (ERRSO +  211)    /*     so_tcm.c:5623 */
#define   ESO212      (ERRSO +  212)    /*     so_tcm.c:5731 */
#define   ESO213      (ERRSO +  213)    /*     so_tcm.c:6038 */

#define   ESO214      (ERRSO +  214)    /*     so_tmr.c: 324 */
#define   ESO215      (ERRSO +  215)    /*     so_tmr.c: 338 */
#define   ESO216      (ERRSO +  216)    /*     so_tmr.c: 466 */
#define   ESO217      (ERRSO +  217)    /*     so_tmr.c: 557 */
#define   ESO218      (ERRSO +  218)    /*     so_tmr.c: 600 */
#define   ESO219      (ERRSO +  219)    /*     so_tmr.c: 862 */

#define   ESO220      (ERRSO +  220)    /*   so_trans.c: 476 */
#define   ESO221      (ERRSO +  221)    /*   so_trans.c: 596 */
#define   ESO222      (ERRSO +  222)    /*   so_trans.c: 692 */
#define   ESO223      (ERRSO +  223)    /*   so_trans.c: 853 */
#define   ESO224      (ERRSO +  224)    /*   so_trans.c:1007 */
#define   ESO225      (ERRSO +  225)    /*   so_trans.c:1089 */
#define   ESO226      (ERRSO +  226)    /*   so_trans.c:1187 */
#define   ESO227      (ERRSO +  227)    /*   so_trans.c:1194 */
#define   ESO228      (ERRSO +  228)    /*   so_trans.c:1364 */
#define   ESO229      (ERRSO +  229)    /*   so_trans.c:1571 */
#define   ESO230      (ERRSO +  230)    /*   so_trans.c:1679 */
#define   ESO231      (ERRSO +  231)    /*   so_trans.c:1798 */
#define   ESO232      (ERRSO +  232)    /*   so_trans.c:1937 */
#define   ESO233      (ERRSO +  233)    /*   so_trans.c:2017 */
#define   ESO234      (ERRSO +  234)    /*   so_trans.c:2151 */
#define   ESO235      (ERRSO +  235)    /*   so_trans.c:2232 */
#define   ESO236      (ERRSO +  236)    /*   so_trans.c:2354 */
#define   ESO237      (ERRSO +  237)    /*   so_trans.c:2463 */
#define   ESO238      (ERRSO +  238)    /*   so_trans.c:2573 */
#define   ESO239      (ERRSO +  239)    /*   so_trans.c:2698 */
#define   ESO240      (ERRSO +  240)    /*   so_trans.c:2787 */
#define   ESO241      (ERRSO +  241)    /*   so_trans.c:2848 */
#define   ESO242      (ERRSO +  242)    /*   so_trans.c:2952 */
#define   ESO243      (ERRSO +  243)    /*   so_trans.c:3014 */
#define   ESO244      (ERRSO +  244)    /*   so_trans.c:3163 */
#define   ESO245      (ERRSO +  245)    /*   so_trans.c:3223 */
#define   ESO246      (ERRSO +  246)    /*   so_trans.c:3307 */
#define   ESO247      (ERRSO +  247)    /*   so_trans.c:3386 */
#define   ESO248      (ERRSO +  248)    /*   so_trans.c:3466 */
#define   ESO249      (ERRSO +  249)    /*   so_trans.c:3528 */
#define   ESO250      (ERRSO +  250)    /*   so_trans.c:3605 */
#define   ESO251      (ERRSO +  251)    /*   so_trans.c:3715 */
#define   ESO252      (ERRSO +  252)    /*   so_trans.c:3842 */
#define   ESO253      (ERRSO +  253)    /*   so_trans.c:3921 */
#define   ESO254      (ERRSO +  254)    /*   so_trans.c:3986 */
#define   ESO255      (ERRSO +  255)    /*   so_trans.c:4119 */
#define   ESO256      (ERRSO +  256)    /*   so_trans.c:4175 */
#define   ESO257      (ERRSO +  257)    /*   so_trans.c:4230 */
#define   ESO258      (ERRSO +  258)    /*   so_trans.c:4309 */
#define   ESO259      (ERRSO +  259)    /*   so_trans.c:4389 */
#define   ESO260      (ERRSO +  260)    /*   so_trans.c:4473 */
#define   ESO261      (ERRSO +  261)    /*   so_trans.c:4532 */
#define   ESO262      (ERRSO +  262)    /*   so_trans.c:4644 */
#define   ESO263      (ERRSO +  263)    /*   so_trans.c:4716 */
#define   ESO264      (ERRSO +  264)    /*   so_trans.c:4799 */
#define   ESO265      (ERRSO +  265)    /*   so_trans.c:4855 */
#define   ESO266      (ERRSO +  266)    /*   so_trans.c:4917 */
#define   ESO267      (ERRSO +  267)    /*   so_trans.c:4999 */
#define   ESO268      (ERRSO +  268)    /*   so_trans.c:5063 */
#define   ESO269      (ERRSO +  269)    /*   so_trans.c:5142 */
#define   ESO270      (ERRSO +  270)    /*   so_trans.c:5233 */
#define   ESO271      (ERRSO +  271)    /*   so_trans.c:5335 */
#define   ESO272      (ERRSO +  272)    /*   so_trans.c:5394 */
#define   ESO273      (ERRSO +  273)    /*   so_trans.c:5462 */
#define   ESO274      (ERRSO +  274)    /*   so_trans.c:5577 */
#define   ESO275      (ERRSO +  275)    /*   so_trans.c:5645 */
#define   ESO276      (ERRSO +  276)    /*   so_trans.c:5702 */
#define   ESO277      (ERRSO +  277)    /*   so_trans.c:5785 */
#define   ESO278      (ERRSO +  278)    /*   so_trans.c:5845 */
#define   ESO279      (ERRSO +  279)    /*   so_trans.c:5930 */
#define   ESO280      (ERRSO +  280)    /*   so_trans.c:5988 */
#define   ESO281      (ERRSO +  281)    /*   so_trans.c:6077 */
#define   ESO282      (ERRSO +  282)    /*   so_trans.c:6129 */
#define   ESO283      (ERRSO +  283)    /*   so_trans.c:6244 */
#define   ESO284      (ERRSO +  284)    /*   so_trans.c:6408 */
#define   ESO285      (ERRSO +  285)    /*   so_trans.c:6490 */

#define   ESO286      (ERRSO +  286)    /*      so_ui.c:1095 */
#define   ESO287      (ERRSO +  287)    /*      so_ui.c:1103 */
#define   ESO288      (ERRSO +  288)    /*      so_ui.c:1189 */
#define   ESO289      (ERRSO +  289)    /*      so_ui.c:1197 */
#define   ESO290      (ERRSO +  290)    /*      so_ui.c:2053 */
#define   ESO291      (ERRSO +  291)    /*      so_ui.c:2260 */
#define   ESO292      (ERRSO +  292)    /*      so_ui.c:2361 */
#define   ESO293      (ERRSO +  293)    /*      so_ui.c:2489 */
#define   ESO294      (ERRSO +  294)    /*      so_ui.c:2611 */
#define   ESO295      (ERRSO +  295)    /*      so_ui.c:2715 */
#define   ESO296      (ERRSO +  296)    /*      so_ui.c:2826 */
#define   ESO297      (ERRSO +  297)    /*      so_ui.c:2927 */
#define   ESO298      (ERRSO +  298)    /*      so_ui.c:3030 */
#define   ESO299      (ERRSO +  299)    /*      so_ui.c:3135 */
#define   ESO300      (ERRSO +  300)    /*      so_ui.c:3253 */
#define   ESO301      (ERRSO +  301)    /*      so_ui.c:3359 */
#define   ESO302      (ERRSO +  302)    /*      so_ui.c:3516 */
#define   ESO303      (ERRSO +  303)    /*      so_ui.c:3656 */

#define   ESO304      (ERRSO +  304)    /*   sogenutl.c:2064 */
#define   ESO305      (ERRSO +  305)    /*   sogenutl.c:2078 */
#define   ESO306      (ERRSO +  306)    /*   sogenutl.c:2206 */
#define   ESO307      (ERRSO +  307)    /*   sogenutl.c:2302 */
#define   ESO308      (ERRSO +  308)    /*   sogenutl.c:2392 */
#define   ESO309      (ERRSO +  309)    /*   sogenutl.c:2557 */
#define   ESO310      (ERRSO +  310)    /*   sogenutl.c:2674 */
#define   ESO311      (ERRSO +  311)    /*   sogenutl.c:2753 */
#define   ESO312      (ERRSO +  312)    /*   sogenutl.c:2792 */
#define   ESO313      (ERRSO +  313)    /*   sogenutl.c:2861 */
#define   ESO314      (ERRSO +  314)    /*   sogenutl.c:3023 */
#define   ESO315      (ERRSO +  315)    /*   sogenutl.c:3100 */
#define   ESO316      (ERRSO +  316)    /*   sogenutl.c:3437 */
#define   ESO317      (ERRSO +  317)    /*   sogenutl.c:3543 */
#define   ESO318      (ERRSO +  318)    /*   sogenutl.c:3548 */

#define   ESO319      (ERRSO +  319)    /*   sohdrutl.c:2106 */
#define   ESO320      (ERRSO +  320)    /*   sohdrutl.c:2188 */
#define   ESO321      (ERRSO +  321)    /*   sohdrutl.c:3116 */
#define   ESO322      (ERRSO +  322)    /*   so_err.h:96     */
#define   ESO324      (ERRSO +  324)    /*   so_ua.c:13505 : so029.201  */
#define   ESO325      (ERRSO +  325)   /* so_ui.c: ccpu00061562 */  

#define   ESOXXX      (ERRSO +  323)    /*     general error */

#endif /* __SOERRH__ */



/********************************************************************30**

         End of file:     so_err.h@@/main/4 - Tue Apr 20 12:46:34 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---     ms   1. initial release.
/main/4   so029.201  ss   1. Added Error code
/main/4   so031.201  aj   1. Added Error code
*********************************************************************91*/
