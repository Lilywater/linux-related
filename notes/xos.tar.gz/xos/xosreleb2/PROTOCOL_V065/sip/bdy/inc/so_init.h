#ifndef __SO_INITH__
#define __SO_INITH__
PUBLIC S16 sip_init_fun(SSTskId soTskId);

#endif  /*__SO_INITH__*/