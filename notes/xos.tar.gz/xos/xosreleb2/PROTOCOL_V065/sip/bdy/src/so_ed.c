/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/
/********************************************************************20**
 
     Name:     SIP - multithreading Functions
 
     Type:     C source file
  
     Desc:     C Source Code for multithreading module
 
     File:     so_ed.c
  
     Sid:      so_ed.c@@/main/3 - Tue Apr 20 12:46:29 2004
  
     Prg:      MC
  
*********************************************************************21*/
 

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_inet.h"       /* common socket library */
#include "cm_tpt.h"        /* common transport library */
#include "cm_dns.h"        /* common DNS                   */
#include "hit.h"           /* HIT interface defines */
#include "lso.h"           /* SIP layer management */
#include "sot.h"           /* SIP upper interface */
#include "so.h"            /* SIP layer */
#include "so_cm.h"         /* SIP common files */
#include "so_err.h"        /* SIP errors */
#include "cm_hash.h"       /* common hash lists */
#include "cm_llist.h"      /* common linked list */
#include "cm_tkns.h"       /* common tokens library */
#include "cm_sdp.h"        /* common sdp library */
#include "cm_mblk.h"       /* common memory block library */
#include "cm_dns.h"        /* common dns library */
#include "cm_abnf.h"       /* common abnf library */

/* header/extern include files (.x) */
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_inet.x"       /* common socket library */
#include "cm_hash.x"       /* common hash list */
#include "cm_xtree.x"      /* common radix tree */
#include "cm_llist.x"      /* common linked list */
#include "cm5.x"           /* common functions */
#include "cm_lib.x"        /* common library functions */
#include "cm_tkns.x"       /* common tokens library */
#include "cm_tpt.x"        /* common transport library */
#include "cm_mblk.x"       /* common memory block library */
#include "cm_sdp.x"        /* common sdp library */
#include "cm_dns.x"        /* common dns library */
#include "cm_abnf.x"       /* common abnf library */
#include "so_rx.x"         /* SIP abnf library */
#include "cm_sdpdb.x"      /* common sdp library */
#include "lso.x"           /* SIP layer management */
#include "sot.x"           /* SIP upper interface */
#include "so_tcm.x"        /* SIP TCM module */
#include "so.x"            /* SIP layer */
#include "so_utl.x"        /* SIP Utility functions */
#include "so_cm.x"         /* SIP common files */
#include "so_ed.x"         /* SIP encoder/decoder functions */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* MIME boundary indicator */
#define SO_MH_MIME_PARM_BOUNDARY  "boundary"

PRIVATE S16 soPrcContentLength ARGS ((
                          SoEvnt  *evnt,
                          U32     len ));


/* SIP Version Supported */
PRIVATE U8  soSipVersion[] = "2.0";
#define     SO_SIP_VERSION_LEN   (sizeof(soSipVersion)-1)

#ifdef SO_ABNF_MT_LIB

#define  EMEDXXX     EMEDBASE


PUBLIC S16 soCreateEDInst  ARGS((
Inst      nmbEDThreads,
Inst      firstEDInst,
Ent       ent        
));

PRIVATE S16 soPstDecodeMsgReq   ARGS((
U32              prot,
Ptr              event,
Buffer           *mBuf,
CmAbnfElmDef     *elmDef,
Ptr              usrCxt,
CmMemListCp      *memCp 
));

PRIVATE S16 soPstEncodeMsgReq   ARGS((
U32              prot,   
Ptr              event, 
Buffer           *mBuf,
CmAbnfElmDef     *elmDef, 
Ptr              usrCxt, 
Mem              *mem,  
U8               source
));

PRIVATE S16 cmPkEncodeMsgReq  ARGS((
Pst            *pst,   
U32            protVar, 
U8             *event, 
Buffer         *encBuf, 
CmAbnfElmDef   *elmDef,
Mem            *mem,  
Ptr            usrCxt
));

PRIVATE S16 cmPkDecodeMsgReq  ARGS((
Pst            *pst,   
U32            protVar,
U8             *event, 
Buffer         *decBuf,
CmAbnfElmDef   *elmDef,
CmMemListCp    *memCp,
Ptr            usrCxt
));

PUBLIC S16 cmUnpkMedDecCfm  ARGS((
MedDecCfm  func,    
Pst        *pst,   
Buffer     *mBuf  
));

PUBLIC S16 cmUnpkMedEncCfm  ARGS((
MedEncCfm  func, 
Pst        *pst,
Buffer     *mBuf
));

PUBLIC S16 soSndDecodeMsgReq  ARGS((
U32              prot,           
U8               source,        
Buffer           *mBuf,        
Ptr              event,       
CmMemListCp      *memCp,     
CmAbnfElmDef     *elmDef,   
SoTptServerCb    *serverCb,
SoTptClientCb    *clientCb,
CmTptAddr        *srcAddr
));

PUBLIC S16 soRcvdDecodeMsgReq ARGS((
Pst              *pst,
U32              protVar,      
U8               *message,      
Buffer           *mBuf,         
CmAbnfElmDef     *elmDef,       
CmMemListCp      *memCp,        
Ptr              usrCxt
));

PUBLIC S16 soRcvDecodeMsgCfm ARGS((
U32              prot,          
Ptr              evnt,         
Buffer           *mBuf,       
U32              numDecBytes,
CmAbnfErr        *err,      
Ptr              usrCxt    
));

PUBLIC S16 soRcvdEncodeMsgReq ARGS((
Pst              *pst,       
U32              protVar,      
U8               *event,
Buffer           *mBuf,
CmAbnfElmDef     *elmDef,
Mem              *abnfMem,   
Ptr              usrCxt
));

PUBLIC S16 soRcvEncodeMsgCfm  ARGS((
U32              prot,            
Ptr              event,          
Buffer           *mBuf,         
CmAbnfErr        *err,         
Ptr              usrCxt       
));

PUBLIC Void soDeAlloc      ARGS((
U8               *buf,       
Size             size       
));

PRIVATE Void soFreeDecRsrc ARGS((
SoStoreList    *node,      
SoStoreDecReq  *txnBuf    
));

PRIVATE Void soFreeEncRsrc ARGS((
SoStoreList    *node,    
SoStoreEncReq  *txnBuf  
));

#endif

PUBLIC S16 soSipEncodeReq  ARGS((
U32           protVar,
SoEntCb       *entCb,
U8            *event,
Buffer        **mBuf,
CmAbnfElmDef  *elmDef,
Mem           *abnfMem,   
CmAbnfErr     *err));

/*---- so019.201: Added parameter to pass entitiy Cb ----*/
PUBLIC S16 soSipDecodeReq  ARGS((
U32           protVar,      
SoEntCb       *entCb,
U8            **message,      
Buffer        **mBuf,         
CmAbnfElmDef  *elmDef,       
CmMemListCp   *memCp,        
U16           *numDecBytes,  
CmAbnfDecOff  *offset,       
CmAbnfErr     *err,
U16           *sipError,
Bool          decSDP
));

#ifndef CM_SDP_OPAQUE
/*chendh*/PUBLIC S16 soDecodeSDP         ARGS((SoBody            *sipBody,
                                      Buffer            *mBuf));
#endif /* CM_SDP_OPAQUE */

PRIVATE S16 soDecodeMultipart   ARGS((SoEvnt            *evnt,
                                      SoContentTypeHdr  *contentType,
                                      Buffer            **mBuf,
                                      Bool              decSDP));

PRIVATE S16 soEncodeMultipart   ARGS((SoBody            *body,
                                      TknStrOSXL        *boundary,
                                      Buffer            *mBuf));

PRIVATE S16 soGetMimeBoundary   ARGS((SoContentTypeHdr  *contentType,
                                      TknStrOSXL        **boundary));

PRIVATE S16 soFindMimeBoundary  ARGS((Buffer            *mBuf,
                                      TknStrOSXL        *boundary,
                                      MsgLen            *startPos,
                                      MsgLen            *endPos));

PRIVATE S16 soSetSinglePartBuf ARGS((SoBody            *sipBody,
                                      Buffer            *mBuf));

/* so020:201 : function added */
PRIVATE S16 soSetSingleBodyPartBuf ARGS (( SoBody       *sipBody,
                                             MsgLen       bodyLen,
                                             Buffer       **mBuf) );

PRIVATE S16 soTruncMsgToGood    ARGS((Buffer            *mBuf,
                                      U16               errPos));

PRIVATE S16 soGetContentLen     ARGS((SoEvnt            *evnt,
                                      U32               *contentLen));
                                       
 
PRIVATE S16 soMakeCmpct         ARGS((SoEvnt            *evnt));

PRIVATE S16 soChckVerNumber     ARGS((SoEvnt            *rxEvent));

PRIVATE S16 soChckCSeq          ARGS((SoEvnt            *rxEvent));

#ifdef SO_ABNF_MT_LIB

/*
*
*       Fun:   soDeAlloc
*
*       Desc:  This function returns a static memory buffer to 
*              the buffer pool.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PUBLIC Void soDeAlloc
(
U8               *buf,               /* Static Buffer to be freed */
Size             size                /* Size of Buffer */
)
#else
PUBLIC Void soDeAlloc (buf, size)
U8               *buf;               /* Static Buffer to be freed */
Size             size;               /* Size of Buffer */
#endif
{

   TRC2(mgDeAlloc)

   if ((buf == NULLP) || (size <= 0) )
      RETVOID;

   cmMemset (buf, 0, size);

   /* Free the memory */
   SPutSBuf (soCb.init.region, soCb.init.pool, buf, size);

   RETVOID;

} /* end of soDeAlloc */


/*
*
*       Fun:   soFreeDecRsrc
*
*       Desc:  This function frees decode resource.
*
*       Ret:   void
*
*       Notes: None
*
*       File:  so_ed.c
*
*/
#ifdef ANSI
PRIVATE Void soFreeDecRsrc
(
SoStoreList    *node,               /* node in store list */
SoStoreDecReq  *txnBuf             /* stored encode req */
)
#else
PRIVATE Void soFreeDecRsrc(node, txnBuf)
SoStoreList    *node;               /* node in store list */
SoStoreDecReq  *txnBuf;             /* stored encode req */
#endif
{
   TRC2(soFreeDecRsrc)
   /* free user context */

   if(txnBuf)                                        
   {                                                    
      soDeAlloc((U8 *)txnBuf, sizeof(SoStoreDecReq));
   }                                                    
   if(node)                                           
   {                                                    
      soDeAlloc((U8 *)node, sizeof(SoStoreList));    
   }                                                    

   RETVOID;

} /* soFreeDecRsrc*/

/*
*
*       Fun:   soFreeEncRsrc
*
*       Desc:  This function frees encode resource.
*
*       Ret:   void
*
*       Notes: None
*
*       File:  so_ed.c
*
*/
#ifdef ANSI
PRIVATE Void soFreeEncRsrc
(
SoStoreList    *node,               /* node in store list */
SoStoreEncReq  *txnBuf              /* stored encode req */
)
#else
PRIVATE Void soFreeEncRsrc(node, txnBuf)
SoStoreList    *node;               /* node in store list */
SoStoreEncReq  *txnBuf;             /* stored encode req */
#endif
{
   TRC2(soFreeEncRsrc)
   /* free user context */

   /* free node */
   if(node)
      soDeAlloc(((U8 *)node), sizeof(SoStoreList));

   /* free txnBuf buffer */
   soUtlDelTknStrOSXL (&txnBuf->branchId);

   if(txnBuf)
      soDeAlloc((U8 *)txnBuf, sizeof(SoStoreEncReq));

   RETVOID;

} /* soFreeEncRsrc*/


/*
*
*       Fun:   soCreateEDInst
*
*
*       Desc:  This function registers the multiple ED tasks, 
*              calls SCreateSTsk, attaches the instances to the threads
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  so_ed.c
*
*/
#ifdef ANSI
PUBLIC S16 soCreateEDInst 
(
Inst      nmbEDThreads,           /* number of ED instances */
Inst      firstEDInst,            /* first ED instance */
Ent       ent                     /* Entity */
)
#else
PUBLIC S16 soCreateEDInst(nmbEDThreads, firstEDInst, ent)
Inst      nmbEDThreads;           /* number of ED instances */
Inst      firstEDInst;            /* first ED instance */
Ent       ent;                    /* Entity */
#endif
{
   SSTskId     *instAr=NULLP;     /* task id array */ 
   Inst        tmpInst;           /* temp instance */
   Bool        deregInst;         /* whether to deregister ?? */
   Inst        cnt;               /* counter */
   S16         ret;               /* ret value */

   TRC2(soCreateEDInst)
  
   /* Initialisations */
   deregInst = FALSE;
   
   /* tight coupling case */
   if (nmbEDThreads == 0)
      RETVALUE(ROK);
    
   /* Allocate memory for the task id array */
   if (SGetSBuf(soCb.init.region, soCb.init.pool, 
         (U8 **)&instAr, (nmbEDThreads * sizeof(SSTskId))) != ROK)
      RETVALUE(RFAILED);
   
   /* Initialise the buffer */
   cmMemset (instAr, 0, (nmbEDThreads * sizeof(SSTskId)));

   /* Register all ED tasks with SSI starting with firstEDInst. */
   tmpInst = firstEDInst;
   for (cnt = 0; ((cnt < nmbEDThreads) && !deregInst); cnt++)
   {
      /* All ED instances will have cmAbnfActvTsk as activate function */
      ret = SRegTTsk(ent, tmpInst, TTNORM, PRIOR0, 
                     NULLP, soActvTsk);
      if (ret != ROK)
      {
         deregInst = TRUE;
         break;
      }
      tmpInst++;
   }
  
   for (cnt = 0; ((cnt < nmbEDThreads) && !deregInst); cnt++)
   {
      /* Create the systerm tasks (threads) */
      ret = SCreateSTsk (PRIOR0, &instAr[cnt]);
      if (ret != ROK)
      {
         deregInst = TRUE;
         break;
      }
   }
   
   tmpInst = firstEDInst;
   /* Attach all the registered tasks with system tasks */
   for (cnt = 0; ((cnt < nmbEDThreads) && !deregInst); cnt++)
   {
      ret = SAttachTTsk (ent, tmpInst, instAr[cnt]);
      if (ret != ROK)
      {
         deregInst = TRUE;
         break;
      }
      tmpInst += 1;
   }

   if (deregInst)
   {
      /* Not able to attach the tapa tasks to the system tasks */
      /* Remove all the system threads and deregister all tapa tasks 
       * registered earlier */
      tmpInst = firstEDInst;
      for (cnt = 0; cnt < nmbEDThreads; cnt++)
      {
         SDestroySTsk(instAr[cnt]);
         SDeregTTsk(ent, tmpInst);
         tmpInst ++;
      }
      /* Free the memory */
      SPutSBuf (soCb.init.region, soCb.init.pool, 
         (U8 *)instAr, (nmbEDThreads * sizeof(SSTskId)));
      RETVALUE(RFAILED);
   }
   
   soCb.tskIdAr = instAr;

   RETVALUE(ROK);
} /* end of soCreateEDInst */



/*
*
*    Fun:    cmPkEncodeMsgReq
*
*    Desc:    pack the primitive Encode Req
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_ed.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkEncodeMsgReq
(
Pst            *pst,           /* post structure */
U32            protVar,        /* protocol variant */
U8             *event,         /* event structure */
Buffer         *encBuf,          /* encoded buffer */
CmAbnfElmDef   *elmDef,        /* root of database tree */
Mem            *mem,           /* memory region/pool */ 
Ptr            usrCxt          /* user context */
)
#else
PRIVATE S16 cmPkEncodeMsgReq(pst, protVar, event, encBuf, elmDef, mem, usrCxt)
Pst            *pst;           /* post structure */
U32            protVar;        /* protocol variant */
U8             *event;         /* event structure */
Buffer         *encBuf;        /* encoded buffer */
CmAbnfElmDef   *elmDef;        /* root of database tree */
Mem            *mem;           /* memory region/pool */ 
Ptr            usrCxt;         /* user context */
#endif
{
    S16        ret1;
    Buffer     *mBuf;

    TRC3(cmPkEncodeMsgReq)

    mBuf = NULLP;

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)EMEDXXX, (ErrVal)0, "SGetMsg() failed");
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(SPkU32, protVar, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(cmPkPtr, (PTR)event, mBuf, EMEDXXX, pst); 
    CMCHKPKLOG(cmPkPtr, (PTR)encBuf, mBuf, EMEDXXX, pst); 
    CMCHKPKLOG(cmPkPtr, (PTR)elmDef, mBuf, EMEDXXX, pst); 
    /* Now pack error->idNum and error->code */
    CMCHKPKLOG(cmPkRegion, mem->region, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(cmPkPool, mem->pool, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(cmPkPtr, (PTR)usrCxt, mBuf, EMEDXXX, pst); 
    
    pst->event = (Event) EVTMEDENCREQ;
    RETVALUE(SPstTsk(pst,mBuf));

} /* end of function cmPkEncodeMsgReq */



/*
*
*    Fun:    cmPkMedDecReq
*
*    Desc:    pack the primitive Decode Req
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_ed.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkDecodeMsgReq
(
Pst            *pst,           /* post structure */
U32            protVar,        /* protocol variant */
U8             *event,         /* event structure */
Buffer         *decBuf,        /* encoded buffer */
CmAbnfElmDef   *elmDef,        /* root of database tree */
CmMemListCp    *memCp,         /* memory region/pool */ 
Ptr            usrCxt          /* user context */
)
#else
PRIVATE S16 cmPkDecodeMsgReq(pst, protVar, event, decBuf, elmDef, memCp, usrCxt)
Pst            *pst;           /* post structure */
U32            protVar;        /* protocol variant */
U8             *event;         /* event structure */
Buffer         *decBuf;        /* encoded buffer */
CmAbnfElmDef   *elmDef;        /* root of database tree */
CmMemListCp    *memCp;         /* memory region/pool */ 
Ptr            usrCxt;         /* user context */
#endif
{
    S16        ret1;
    Buffer     *mBuf;

    TRC3(cmPkDecodeMsgReq)

    mBuf = NULLP;

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                 __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                 (ErrVal)EMEDXXX, (ErrVal)0, "SGetMsg() failed");
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(SPkU32, protVar, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(cmPkPtr, (PTR)event, mBuf, EMEDXXX, pst); 
    CMCHKPKLOG(cmPkPtr, (PTR)decBuf, mBuf, EMEDXXX, pst); 
    CMCHKPKLOG(cmPkPtr, (PTR)elmDef, mBuf, EMEDXXX, pst); 
    CMCHKPKLOG(cmPkPtr, (PTR)memCp, mBuf, EMEDXXX, pst); 
    CMCHKPKLOG(cmPkPtr, (PTR)usrCxt, mBuf, EMEDXXX, pst); 
    
    pst->event = (Event) EVTMEDDECREQ;
    RETVALUE(SPstTsk(pst,mBuf));

} /* end of function cmPkDecodeMsgReq */



/*
*
*       Fun:   cmUnpkMedDecCfm
*
*       Desc:  Unpack Dec Cfm
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  so_ed.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMedDecCfm
(
MedDecCfm  func,                    /* function */
Pst        *pst,                    /* post structure */
Buffer     *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkMedDecCfm(func, pst, mBuf)
MedDecCfm  func;                    /* function */
Pst        *pst;                    /* post structure */
Buffer     *mBuf;                   /* message buffer */
#endif
{

   U32            protVar;          /* protocol variant */
   U16            numDecBytes;      /* no. of decoded bytes */
   Ptr            event=NULLP;      /* Ignore event structure */
   Buffer         *decBuf;          /* Buffer */
   Ptr            usrCxt;           /* user context */
   CmAbnfErr      err;              /* error */
    
   TRC3(cmUnpkMedDecCfm)
   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&event, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&usrCxt, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(SUnpkU16,    &err.idNum, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(SUnpkU16,    &err.code, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&decBuf, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(SUnpkU16,    &numDecBytes, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(SUnpkU32,   &protVar, mBuf, EMEDXXX, pst);

   SPutMsg(mBuf);

   /* call the primitive */
   (*func)(protVar, event, decBuf, numDecBytes, &err, usrCxt);

   RETVALUE(ROK);

} /* end of cmUnpkMedDecCfm */




/*
*
*       Fun:   cmUnpkMedEncCfm
*
*       Desc:  Unpack Encode Cfm
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  so_ed.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMedEncCfm
(
MedEncCfm  func,                    /* function */
Pst        *pst,                    /* post structure */
Buffer     *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkMedEncCfm(func, pst, mBuf)
MedEncCfm  func;                    /* function */
Pst        *pst;                    /* post structure */
Buffer     *mBuf;                   /* message buffer */
#endif
{

   U32            protVar;          /* protocol variant */
   Buffer         *encBuf;          /* Buffer */
   Ptr            usrCxt;           /* user context */
   CmAbnfErr      err;              /* error */
   U8             *event;           /* event */
    
   TRC3(cmUnpkMedEncCfm)
   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&usrCxt, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(SUnpkU16,    &err.idNum, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(SUnpkU16,    &err.code, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&encBuf, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(SUnpkU32,   &protVar, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&event, mBuf, EMEDXXX, pst);

   SPutMsg(mBuf);

   /* call the primitive */
   (*func)(protVar, event, encBuf, &err, usrCxt);

   RETVALUE(ROK);

} /* end of cmUnpkMedEncCfm */


/*
*
*       Fun:   soPstDecodeMsgReq
*
*       Desc:  This function post decode request to one of ED instances 
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  so_ed.c
*
*/
#ifdef ANSI
PRIVATE S16 soPstDecodeMsgReq
(
U32              prot,              /* protocol variant */
Ptr              event,             /* event structure */
Buffer           *mBuf,             /* Buffer */
CmAbnfElmDef     *elmDef,           /* elmDef */   
Ptr              usrCxt,           /* user context */
CmMemListCp      *memCp            /* mem list cp */
)
#else
PRIVATE S16 soPstDecodeMsgReq(prot, event, mBuf, elmDef, usrCxt, memCp)
U32              prot;              /* protocol variant */
Ptr              event;             /* event structure */
Buffer           *mBuf;             /* Buffer */
CmAbnfElmDef     *elmDef;           /* elmDef */   
Ptr              usrCxt;           /* user context */
CmMemListCp      *memCp;            /* mem list cp */
#endif
{
   S16         ret;               /* ret value */

   TRC2(soPstDecodeMsgReq)
   /* initialize post structure */
   soCb.edPst.event = EVTMEDDECREQ;
   soCb.edPst.dstInst = soCb.nxtEDInst++;
   /* if nxtEDInst is more then last ED inst no then wrap it */
   if(soCb.nxtEDInst >= soCb.lastEDInst)
      soCb.nxtEDInst = soCb.init.inst + 1;
    
   /* now call fn which will post msg to ED instances */
   ret = cmPkDecodeMsgReq(&soCb.edPst, prot, (U8 *)event, mBuf, elmDef, 
              memCp, (Ptr)usrCxt );
   if(ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* soPstDecodeMsgReq */




/*
*
*       Fun:   soPstEncMsgReq
*
*       Desc:  This function post encode request to one of ED instances and
*       starts timer.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  so_ed.c
*
*/
#ifdef ANSI
PRIVATE S16 soPstEncodeMsgReq
(
U32              prot,              /* protocol variant */
Ptr              event,             /* event structure */
Buffer           *mBuf,             /* Buffer */
CmAbnfElmDef     *elmDef,           /* elmDef */   
Ptr              usrCxt,           /* user context */
Mem              *mem,              /* mem list cp */
U8               source            /* Source; Internal or User ??*/
)
#else
PRIVATE S16 soPstEncodeMsgReq(prot, event, mBuf, elmDef, usrCxt, mem, source)
U32              prot;              /* protocol variant */
Ptr              event;             /* event structure */
Buffer           *mBuf;             /* Buffer */
CmAbnfElmDef     *elmDef;           /* elmDef */   
Ptr              usrCxt;           /* user context */
Mem              *mem;              /* mem list */
U8               source;            /* Source; Internal or User ??*/
#endif
{
   S16         ret;               /* ret value */

   TRC2(soPstEncodeMsgReq)
   /* initialize post structure */
   soCb.edPst.event = EVTMEDENCREQ;
   soCb.edPst.dstInst = soCb.nxtEDInst;

   /* Source in not User..then don't update nxtEDInst */ 
   /* if nxtEDInst is more then last ED inst no then wrap it */
   soCb.nxtEDInst++;
   if(soCb.nxtEDInst >= soCb.lastEDInst)
      soCb.nxtEDInst = soCb.init.inst + 1;
    
   /* now call fn which will post msg to ED instances */
   ret = cmPkEncodeMsgReq(&soCb.edPst, prot, (U8 *)event, mBuf, elmDef, 
              mem, (Ptr)usrCxt );
   if(ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* soPstEncodeMsgReq */

/*
*
*       Fun:   soSndDecodeMsgReq
*
*       Desc:  This function sends decode request to one of ED instances.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: 
*
*       File:  so_ed.c
*
*/
#ifdef ANSI
PUBLIC S16 soSndDecodeMsgReq
(
U32              prot,       /* protocol variant                         */
U8               source,     /* source req                               */
Buffer           *mBuf,      /* buffer to be decoded                     */
Ptr              event,      /* event structure                          */
CmMemListCp      *memCp,     /* mem list Cp                              */
CmAbnfElmDef     *elmDef,    /* root of database tree                    */
SoTptServerCb    *serverCb,   /* Server connection that received message  */
SoTptClientCb    *clientCb,   /* Client connection (For TCP Only)         */
CmTptAddr        *srcAddr     /* Source IP address                        */
)
#else
PUBLIC S16 soSndDecodeMsgReq(prot, source, mBuf, event, memCp, elmDef, serverCb, clientCb,srcAddr)
U32              prot;       /* protocol variant                         */
U8               source;     /* source req                               */
Buffer           *mBuf;      /* buffer to be decoded                     */
Ptr              event;      /* event structure                          */
CmMemListCp      *memCp;     /* mem list Cp                              */
CmAbnfElmDef     *elmDef;    /* root of database tree                    */
SoTptServerCb    *serverCb;   /* Server connection that received message  */
SoTptClientCb    *clientCb;   /* Client connection (For TCP Only)         */
CmTptAddr        *srcAddr;    /* Source IP address                        */
#endif
{
   S16           ret;               /* ret value */
   SoStoreList   *node;             /* list */
   SoStoreDecReq *txnBuf;           /* info will be stored here */
   U32           decSDP;            /* indicating whether to decode SDP */
   SoEntCb       *entCb;
   
   TRC2(soSndDecodeMsgReq)
   
  /*
   * This fucntion will deallocate mBuf in failure cases or the pointer to
   * mBuf will be send to decoding thread.
   */

   if(serverCb)
      entCb = serverCb->entCb;
   else
      entCb = clientCb->serverCb->entCb;

   /* get memory for node */
   if(SGetSBuf(soCb.init.region, soCb.init.pool, (U8 **)&node, sizeof(SoStoreList)) != ROK)
   {
      RETVALUE(RFAILED);
   }
   /* get memory for txnBuf */ 
   if(SGetSBuf(soCb.init.region, soCb.init.pool, (U8 **)&txnBuf, sizeof(SoStoreDecReq)) != ROK)
   {
      SPutSBuf (soCb.init.region, soCb.init.pool, (U8 *)node, sizeof(SoStoreList));
      RETVALUE(RFAILED);
   }

   /* initialize all the variables */
   cmMemset ((U8 *)node  , 0, sizeof (SoStoreList));
   cmMemset ((U8 *)txnBuf, 0, sizeof (SoStoreDecReq));

   cmMemcpy ((U8 *)&(txnBuf->srcAddr), 
             (U8 *)srcAddr, 
             sizeof (CmTptAddr));

   /* initialize txnBuf & node Ptr & usrCxt */
   txnBuf->prot = prot;
   txnBuf->source = source;
   txnBuf->event = event;

   soPrcInitTcmConn (&txnBuf->tcmConn, SO_UNKNOWN, NULLP);
   txnBuf->tcmConn.clientCb = clientCb;
   txnBuf->tcmConn.serverCb = serverCb;

   txnBuf->status = SO_DECODE_NONE;

   /*----- Update node and insert in the link list -----*/
   node->infoType = SO_DECODE;
   node->info     = (Ptr)txnBuf;

   cmLListNode (&node->nodeEnt) = (PTR) node;
   cmLListAdd2Tail (&soCb.soEDList, &node->nodeEnt);

  /*
   * store the decSDP as the highest bit in U32 prot variable
   * to avoid abnf common interface change  in  multithreaded
   * encoder/decoder.  When unPack  prot, we take decSDP from 
   * highest big in prot
   */
   decSDP = ((U32) (entCb)->reCfg.decodeSDP)<<31;

   ret = soPstDecodeMsgReq (prot|decSDP<<30, (Ptr)event, 
                            mBuf, elmDef, (Ptr)node, memCp);
   if (ret != ROK) 
   {
      cmLListDelFrm (&soCb.soEDList, &node->nodeEnt);
      soFreeDecRsrc (node, txnBuf);
      RETVALUE (ret);
   }

   RETVALUE (ROK);

} /* soSndDecodeMsgReq */


/*
*
*       Fun:   soSndEncodeMsgReq
*
*       Desc:  This function sends enccode request to one of ED instances.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  so_ed.c
*
*/
#ifdef ANSI
PUBLIC S16 soSndEncodeMsgReq
(
U32              prot,      /* protocol variant */
U8               source,    /* source; Internal or User */
SoEntCb          *entCb,    /* entity control block      */
Ptr              msg,       /* Message/Event Control Block */
Buffer           *mBuf,     /* Message buffer */
CmAbnfElmDef     *elmDef,   /* message defintion */
Mem              *abnfMem,  /* Memory: region/pool */
SoSSapCb         *sSapCb,    /* Service User Sap                            */
CmTptAddr        *destAddr,  /* Destination IP-address/port to send request */
TknStrOSXL       *branchId,  /* Branch Id to be added in VIA item */
SoTcmConn        *tcmConn,   /* TCP/UDP connection information  (Updated)   */
Bool             modifyTransport
)
#else
PUBLIC S16 soSndEncodeMsgReq(prot, source, entCb, msg, mBuf, elmDef, 
                             abnfMem, sSapCb, destAddr, branchId,
                             tcmConn, modifyTransport)
U32              prot;      /* protocol variant */
U8               source;    /* source; Internal or User */
SoEntCb          *entCb;    /* entity control block      */
Ptr              msg;       /* Message/Event Control Block */
Buffer           *mBuf;     /* Message buffer */
CmAbnfElmDef     *elmDef;   /* message defintion */
Mem              *abnfMem;  /* Memory: region/pool */
SoSSapCb         *sSapCb;    /* Service User Sap                            */
CmTptAddr        *destAddr;  /* Destination IP-address/port to send request */
TknStrOSXL       *branchId;  /* Branch Id to be added in VIA item */
SoTcmConn        *tcmConn;   /* TCP/UDP connection information  (Updated)   */
Bool             modifyTransport;
#endif
{
   SoStoreList   *node;     /* list */
   SoStoreEncReq *txnBuf;   /* info will be stored here */
   S16           ret;       /* return value */

   TRC2(soSndEncodeMsgReq)

   ret = ROK;

   /* get memory for node */
   if(SGetSBuf(abnfMem->region, abnfMem->pool, (U8 **)&node, sizeof(SoStoreList)) != ROK)
      RETVALUE(RFAILED);
   /* get memory for txnBuf */ 
   if(SGetSBuf(abnfMem->region, abnfMem->pool, (U8 **)&txnBuf, sizeof(SoStoreEncReq)) != ROK)
   {
      SPutSBuf (abnfMem->region, abnfMem->pool, (U8 *)node, sizeof(SoStoreList));
      RETVALUE(RFAILED);
   }

   /* initialize all the variables */
   cmMemset ((U8 *)node  , 0, sizeof (SoStoreList));
   cmMemset ((U8 *)txnBuf, 0, sizeof (SoStoreEncReq));

   /* initialize txnBuf & node Ptr & usrCxt */
   txnBuf->prot   = prot;
   txnBuf->source = source;
   txnBuf->entity = entCb;
   txnBuf->sSapCb = sSapCb;
   txnBuf->msg    = msg;
   txnBuf->mBuf   = mBuf;
   txnBuf->status = SO_ENCODE_NONE;

   cmMemcpy ((U8 *)&(txnBuf->destAddr), (U8 *)destAddr, sizeof (CmTptAddr));

   soPrcInitTcmConn (&txnBuf->tcmConn, tcmConn->tcmConnType, tcmConn->residePtr);

   txnBuf->tcmConn.serverCb    = tcmConn->serverCb;
   txnBuf->tcmConn.clientCb    = tcmConn->clientCb;
   txnBuf->modifyTransport     = modifyTransport;

   if(branchId)
      ret = soUtlCpyTknStrOSXL (&txnBuf->branchId,
                                branchId,
                                NULLP);
   if (ret != ROK)
        RETVALUE (SOT_ERR_UNKNOWN);

   /*----- Update node and insert in the link list -----*/
   node->infoType = SO_ENCODE;
   node->info     = (Ptr)txnBuf;

   cmLListNode (&node->nodeEnt) = (PTR) node;
   cmLListAdd2Tail (&soCb.soEDList, &node->nodeEnt);

   ret = soPstEncodeMsgReq (prot  , (Ptr)msg, mBuf, 
                            elmDef, node    , abnfMem,
                            source);
   if (ret != ROK)
   {
      cmLListDelFrm (&soCb.soEDList, &node->nodeEnt);
      soFreeEncRsrc (node, txnBuf);
      RETVALUE (RFAILED);
   }

   RETVALUE (ROK);

} /* soSndEncodeMsgReq */


/*
*
*       Fun:   soRcvEncodeMsgReq
*
*       Desc:  process SIP encode request received, encoding message
*              and send a confirmation
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  so_ed.c
*
*/
#ifdef ANSI
PUBLIC S16 soRcvEncodeMsgReq
(
Pst           *pst,       /* post structure */
U32           protVar,    /* protocol and variant */
U8            *event,     /* pointer to the event structure */
Buffer        *mBuf,      /* Message buffer */
CmAbnfElmDef  *elmDef,    /* message defintion */
Mem           *memReg,    /* Memory: region/pool */
Ptr           usrCxt      /* user context */
)
#else
PUBLIC S16 soRcvEncodeMsgReq(pst, protVar, event, mBuf, elmDef, memReg, usrCxt)
Pst           *pst;       /* post structure */
U32           protVar;    /* protocol and variant */
U8            *event;     /* pointer to the event structure */
Buffer        *mBuf;      /* Message buffer */
CmAbnfElmDef  *elmDef;    /* message defintion */
Mem           *memReg;    /* Memory: region/pool */
Ptr           usrCxt;     /* user context */
#endif
{
   CmAbnfErr     err;         /* error */
   S16           ret;         /* return value */
   SoStoreEncReq *txnEncBuf;  /* encode Buffer */
   SoEntCb       *entCb;      /* entitity control block */
   
   TRC2(soRcvEncodeMsgReq)
   
   /* getting the information of the node */ 
   txnEncBuf = (SoStoreEncReq *)((SoStoreList *)usrCxt)->info;

   entCb = txnEncBuf->entity;
      
   /* Initialization */
   (Void) cmMemset((U8 *)&err, 0, sizeof(CmAbnfErr));

   /* call sip internal function for Encoding Header and Body */
   ret = soSipEncodeReq(protVar, entCb, event, &mBuf, elmDef, memReg, &err);

   /* send cfm back */
   cmAbnfEncCfm(pst, protVar, event, mBuf, &err, usrCxt);

   RETVALUE(ret);
} /* soRcvEncodeMsgReq */



/*
*
*       Fun:   soRcvDecodeMsgReq
*
*       Desc:  process SIP Decode request received, decoding the message
*              and send a confirmation
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  so_ed.c
*
*/
#ifdef ANSI
PUBLIC S16 soRcvDecodeMsgReq
(
Pst           *pst,       /* post structure */
U32           protVar,    /* protocol and variant */
U8            *event,     /* pointer to the event structure */
Buffer        *mBuf,      /* Message buffer */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmMemListCp   *memCp,     /* Memory Control Pointer */
Ptr           usrCxt      /* user context */
)
#else
PUBLIC S16 soRcvDecodeMsgReq(pst, protVar, event, mBuf, elmDef, memCp, usrCxt)
Pst           *pst;       /* post structure */
U32           protVar;    /* protocol and variant */
U8            *event;     /* pointer to the event structure */
Buffer        *mBuf;      /* Message buffer */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmMemListCp   *memCp;     /* Memory Control Pointer */
Ptr           usrCxt;     /* user context */
#endif
{
   U16             numDecBytes;       /* no of decoded bytes */
   MsgLen          numDecBytesCfm;       /* no of decoded bytes */
   CmAbnfErr       err;               /* error */
   CmAbnfDecOff    offset;            /* DBUF offset information */
   S16             ret;     /* return value */
   Bool            decSDP;            /* whether to decode SDP or not */ 
   U32             localProt;         /* take the SDP protocol version 
                                         out of protVar which combined
                                         decSDP and SDP version */

  /*----- so019.201: Extract entityCb from user context ------*/
   SoEntCb         *entCb; /* Entity Control Block            */
   SoTptServerCb   *serverCb;
   SoTptClientCb   *clientCb;
   SoStoreList     *node;
   SoStoreDecReq   *txnBuf;

   TRC2(soRcvDecodeMsgReq)

   /* Initialization */
   numDecBytes = 0;
   numDecBytesCfm = 0;
   cmMemset((U8 *)&offset, 0, sizeof(CmAbnfDecOff));
   cmMemset((U8 *)&err, 0, sizeof(CmAbnfErr));

   decSDP = (U8)(protVar >> 31);
   localProt = (protVar & 0x3fffffff);

  /*----- so019.201: Extract entityCb from user context ------*/
  /* ---- so033.201: Fix for compilation error with  SO_ABNF_MT_LIB falg*/
   node     = (SoStoreList *)usrCxt;    
   txnBuf   = (SoStoreDecReq *)node->info;
   clientCb = txnBuf->tcmConn.clientCb;
   serverCb = txnBuf->tcmConn.serverCb;

   if(serverCb)
      entCb = serverCb->entCb;
   else
      entCb = clientCb->serverCb->entCb;

   /* call sip internal function for Decoding Header and Body */
   ret = soSipDecodeReq(localProt, entCb, &event, &mBuf, elmDef, memCp, 
                          &numDecBytes, &offset, &err, &(err.idNum),
                          decSDP);

   /* send Decode cfm back */
   cmAbnfDecCfm(pst, protVar, event, mBuf, &numDecBytesCfm, &err, usrCxt);

   RETVALUE(ret);
} /* soRcvDecodeMsgReq */


/*
*
*       Fun:   soRcvDecodeMsgCfm
*
*       Desc:  This function process decode cfm rcved from ED instance.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  so_ed.c
*
*/
#ifdef ANSI
PUBLIC S16 soRcvDecodeMsgCfm
(
U32              prot,              /* protocol variant */
Ptr              evnt,              /* Ignore */
Buffer           *mBuf,             /* buffer to be decoded */
U32              numDecBytes,       /* no of decoded bytes */
CmAbnfErr        *err,              /* error */
Ptr              usrCxt             /* user context */
)
#else
PUBLIC S16 soRcvDecodeMsgCfm(prot, evnt, mBuf, numDecBytes, err, usrCxt)
U32              prot;              /* protocol variant */
Ptr              evnt;              /* Ignore */
Buffer           *mBuf;             /* buffer to be decoded */
U32              numDecBytes;       /* no of decoded bytes */
CmAbnfErr        *err;              /* error */
Ptr              usrCxt;               /* user context */
#endif
{
   SoStoreList   *node;
   SoStoreDecReq *txnBuf;
   S16           ret;
   SoEntCb       *entCb;

   TRC2 (soRcvDecodeMsgCfm)

#if (ERRCLASS & ERRCLS_DEBUG)
   if((usrCxt == NULLP) ||
      (((SoStoreList *)usrCxt)->infoType != SO_DECODE) ||
      (err    == NULLP) ||
      ((err->code == CM_ABNF_ERR_NONE) && (mBuf == NULLP)))
   {
      SOLOGERROR (ERRCLS_DEBUG, ESO085, (ErrVal)0,
                  "soRcvDecodeMsgCfm: parameter NULLP \n");
      RETVALUE (RFAILED);
   }
#endif

   /*-------------- Decoder Thread returned ---------------*/

   /*------------- Get the decoding context ---------------*/ 

   node         = (SoStoreList *)usrCxt;
   txnBuf       = node->info;
   txnBuf->mBuf = mBuf;
   txnBuf->event= evnt;
   entCb        = txnBuf->tcmConn.serverCb->entCb;

   if (err->code != CM_ABNF_ERR_NONE)
   {
      SODBGP_SO (SO_DBGMASK_ABNF_ENC, (soCb.init.prntBuf,
                 "soRcvDecodeMsgCfm: Decode failed: Error code=%d idNum=%d\n",
                 err->code, err->idNum));

      soTptDecodeCallBack(entCb, FALSE,
                          NULLP,
                          NULLP,
                          NULLP,
                          NULLP,
                          txnBuf->mBuf);
     RETVALUE (ROK);
   }

   /*----------- Check if decoding is incomplete ----------*/ 
   if ((txnBuf->tcmConn.clientCb) &&
       (txnBuf->tcmConn.clientCb->serverCb->tptProt
         == LSO_TPTPROT_TCP) &&
       (err->idNum == SO_HDR_OK_BODY_INCMP))
   {
      /*--- Save the received message and quit decoding ---*/
      txnBuf->tcmConn.clientCb->partialMsg = mBuf;
#ifdef DEBUGP
      SODBGP_SO (SO_DBGMASK_TCM, (soCb.init.prntBuf,
              "soTptDecodeMsg: Incomplete Body, waiting for"
              "the rest of the msg!!\n"));
#endif
      RETVALUE (ROK);
   }
   
   ret = soPrcRcvdDataFromABNF(&txnBuf->mBuf,
                                entCb, 
                                txnBuf->tcmConn.serverCb,
                                txnBuf->tcmConn.clientCb,
                               &txnBuf->srcAddr,
                                (U8 *)txnBuf->event,
                                err->idNum);

   /*--------------- invoke callback function -------------*/
   if(ret == ROK)
   {
      soTptDecodeCallBack(entCb, TRUE,
                          txnBuf->tcmConn.serverCb,
                          txnBuf->tcmConn.clientCb,
                          &txnBuf->srcAddr,
                          (SoEvnt *)txnBuf->event,
                          txnBuf->mBuf);
   }
   
   cmLListDelFrm (&soCb.soEDList, &node->nodeEnt);
   soFreeDecRsrc (node, txnBuf);
   
   /*-------------- shutdown in progress? ----------------*/
   if ((soCb.shutdownInProgress) && (cmLListLen (&soCb.soEDList) == 0))
      (Void)soShutdown();

   RETVALUE (ROK);

} /* soRcvDecodeMsgCfm */


/*
*
*       Fun:   soRcvEncodeMsgCfm
*
*       Desc:  This function process encode cfm rcved from ED instance.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  so_ed.c
*
*/
#ifdef ANSI
PUBLIC S16 soRcvEncodeMsgCfm
(
U32              prot,              /* protocol variant */
Ptr              event,             /* event structure  */
Buffer           *mBuf,             /* encoded Buffer   */
CmAbnfErr        *err,              /* error            */
Ptr              usrCxt             /* user context     */
)
#else
PUBLIC S16 soRcvEncodeMsgCfm(prot, event, mBuf, err, usrCxt)
U32              prot;              /* protocol variant */
Ptr              event;             /* event structure  */
Buffer           *mBuf;             /* encoded buffer   */
CmAbnfErr        *err;              /* error            */
Ptr              usrCxt;            /* user context     */
#endif
{
   SoStoreList   *node;
   SoStoreEncReq *txnBuf;
   SoSSapCb      *ssap;
   SoEntCb       *entCb;
   Bool          success;
   
   TRC2(soRcvEncodeMsgCfm)
   
#if (ERRCLASS & ERRCLS_DEBUG)
   if((usrCxt == NULLP) ||
      (((SoStoreList *)usrCxt)->infoType != SO_ENCODE) ||
      (err    == NULLP) ||
      ((err->code == CM_ABNF_ERR_NONE) && (mBuf == NULLP)))
   {
      SOLOGERROR (ERRCLS_DEBUG, ESO086, (ErrVal)0,
                  "soRcvEncodeMsgCfm: parameter NULLP \n");
      RETVALUE (RFAILED);
   }
#endif

   /*-------------- Encoder Thread returned ---------------*/

   /*------------- Get the encoding context ---------------*/ 

   node         = (SoStoreList *)usrCxt;
   txnBuf       = node->info;
   txnBuf->mBuf = mBuf;

   success  = TRUE;
   entCb    = txnBuf->entity;
   ssap     = txnBuf->sSapCb;

   if (err->code != CM_ABNF_ERR_NONE)
   {
      success = FALSE;

      SODBGP_SO (SO_DBGMASK_ABNF_ENC, (soCb.init.prntBuf,
                 "soRcvEncodeMsgCfm: Encode failed: Error code=%d idNum=%d\n",
                 err->code, err->idNum));
   }

   /*------ invoke call back function ------*/
   if (txnBuf->source == SO_TPT_REQUEST)
   {
        soTptEncodeReqCallBack (entCb,
                                ssap,
                                success,
                               &txnBuf->destAddr,
                                (SoEvnt *)txnBuf->msg,
                                txnBuf->modifyTransport,
                               &txnBuf->branchId,
                               &txnBuf->tcmConn,
                                txnBuf->mBuf);
   }
   else
   {
        soTptEncodeRspCallBack (entCb,
                                (SoEvnt *)txnBuf->msg,  
                                success,
                               &txnBuf->destAddr,  
                               &txnBuf->tcmConn,
                                txnBuf->mBuf);
   }

   cmLListDelFrm (&soCb.soEDList, &node->nodeEnt);
   soFreeEncRsrc (node, txnBuf);
   
   /*-------------- shutdown in progress? ----------------*/
   if ((soCb.shutdownInProgress) && (cmLListLen (&soCb.soEDList) == 0))
      (Void)soShutdown();

   RETVALUE (ROK);

} /* soRcvEncodeMsgCfm */


#endif /* SO_ABNF_MT_LIB */


/*
*
*       Fun:   soFindMimeBoundary
*
*       Desc:  This function locates the next MIME boundary in the message
*              supplied.  It outputs the position of the start of the boundary,
*              and the position of the end of the boundary (including any white
*              space after the boundary).
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PRIVATE S16   soFindMimeBoundary
(
Buffer            *mBuf,        /* pointer to buffer   */
TknStrOSXL        *boundary,    /* pointer to boundary */
MsgLen            *startPos,    /* start of boundary   */
MsgLen            *endPos       /* end of boundary     */
)
#else
PRIVATE S16   soFindMimeBoundary(mBuf, boundary, startPos, endPos)
Buffer            *mBuf;        /* pointer to buffer   */
TknStrOSXL        *boundary;    /* pointer to boundary */
MsgLen            *startPos;    /* start of boundary   */
MsgLen            *endPos;      /* end of boundary     */
#endif
{
   MsgLen   msgLen;     /* length of data in message buffer   */
   Data     msgByte;    /* one byte of the message to examine */
   MsgLen   i;          /* counter for message data           */
   U8       *msgSeg;    /* Message segment                    */
   MsgLen   msgSegLen;  /* length of message segment examined */
   S16      ret;        /* value returned by function calls   */

   TRC2(soFindMimeBoundary);

   if (boundary->len == 0)
   {
      RETVALUE(RFAILED);
   }

   /* Initialize output values */
   if (startPos != (MsgLen *)NULLP)
   {
      *startPos = NULLD;
   }

   if (endPos != (MsgLen *)NULLP)
   {
      *endPos = NULLD;
   }

   /* Allocate memory for message segment to compare to boundary */
   SOALLOC(&msgSeg, boundary->len);

   if (msgSeg == NULLP)
   {
      RETVALUE(RFAILED);
   }

   /* Get message length */
   ret = SFndLenMsg(mBuf, &msgLen);
   if (ret != ROK)
   {
      SOFREE(msgSeg, boundary->len);
      RETVALUE(RFAILED);
   }

   for (i = 0; i < msgLen; i++)
   {
      ret = SExamMsg(&msgByte, mBuf, i);
      if (ret != ROK)
      {
         SOFREE(msgSeg, boundary->len);
         RETVALUE(ret);
      }

      if (msgByte == boundary->val[0])
      {
         /* This may be the beginning of the boundary - copy into msgSeg */
         ret = SCpyMsgFix(mBuf, i, boundary->len, msgSeg, &msgSegLen);
         if (ret != ROK)
         {
            SOFREE(msgSeg, boundary->len);
            RETVALUE(RFAILED);
         }

         /* Compare msgSeg to boundary */
         if (SO_CMP_TKNSTR_LIT(boundary, msgSeg, msgSegLen) == TRUE)
         {
            msgByte = SO_ASCII_CR;

            while ((msgByte == SO_ASCII_CR) || (msgByte == SO_ASCII_LF))
            {
               /* Check for CRLF and white space */
               ret = SExamMsg(&msgByte, mBuf, (MsgLen)(i + msgSegLen));
               if (ret != ROK)
               {
                  SOFREE(msgSeg, boundary->len);
                  RETVALUE(ret);

               }

               if ((msgByte == SO_ASCII_CR) ||
                   (msgByte == SO_ASCII_LF) ||
                   (msgByte == SO_ASCII_TB) ||
                   (msgByte == SO_ASCII_SP))
               {
                  msgSegLen++;
               }
            }

            /* Set output values */
            if (startPos != (MsgLen *)NULLP)
            {
               *startPos = i;
            }

            if (endPos != (MsgLen *)NULLP)
            {
               *endPos = i + msgSegLen;
            }

            SOFREE(msgSeg, boundary->len);
            RETVALUE(ROK);
         }
      }
   }

   SOFREE(msgSeg, boundary->len);
   RETVALUE(RFAILED);

} /* end of soFindMimeBoundary */


/*
*
*       Fun:   soGetMimeBoundary
*
*       Desc:  This function locates the multipart MIME boundary
*              specifier in the content-type header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PRIVATE S16   soGetMimeBoundary
(
SoContentTypeHdr  *contentType,  /* content type header */
TknStrOSXL        **boundary     /* pointer to boundary */
)
#else
PRIVATE S16   soGetMimeBoundary(contentType, boundary)
SoContentTypeHdr  *contentType; /* content type header */
TknStrOSXL        **boundary;   /* pointer to boundary */
#endif
{
   U16                i;            /* counter for MIME parts                */

   TRC2(soGetMimeBoundary);

   (*boundary) = (TknStrOSXL *) NULLP;

   for (i = 0; i < SO_GET_NUM_COMP(&contentType->parameters.numComp); i++)
   {
      /* Check parameter type */
      if(SO_CMP_TKNSTR_LIT(&contentType->parameters.parameter[i]->token,
                           (U8 *)SO_MH_MIME_PARM_BOUNDARY,
                           sizeof(SO_MH_MIME_PARM_BOUNDARY) - 1) == TRUE)
      {
         (*boundary) = &contentType->parameters.parameter[i]->paramVal.value;
         if ((*boundary)->pres == NOTPRSNT)
         {
            RETVALUE(RFAILED);
         }
         else
         {
            RETVALUE(ROK);
         }
      }
   }

   RETVALUE(RFAILED);
} /* end of soGetMimeBoundary */


/*
*
*       Fun:   soSetSinglePartBuf
*
*       Desc:  This function is used to decode SDP data with a Msg Buffer
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PRIVATE S16   soSetSinglePartBuf
(
SoBody       *sipBody,     /* Pointer to body into which to decode buffer */
Buffer       *mBuf         /* Incoming data     */
)
#else
PRIVATE S16   soSetSinglePartBuf(sipBody, mBuf)
SoBody       *sipBody;     /* Pointer to body into which to decode buffer */
Buffer       *mBuf;        /* Incoming data     */
#endif
{
   S16 ret;

   ret = ROK;

   TRC2(soSetSinglePartBuf);

   /* Set body type to single-part */
   SO_FILL_TKNU8(&sipBody->bodyType,
                 SOT_BODYTYPE_SINGLEPART);

   /* Set single-part type to STR */
   SO_FILL_TKNU8(&sipBody->u.singlePart.bodySinglePartType,
                 SOT_BODYSINGLEPART_STR);

   /* copy the message body      */
   ret = SCpyMsgMsg(mBuf,
                    soCb.init.region,
                    soCb.init.pool,
                    &sipBody->u.singlePart.s.str.val);
   if (ret == ROK)
      /* Set presence flag of TknBuf str */
      sipBody->u.singlePart.s.str.pres = PRSNT_NODEF;

   RETVALUE (ret);

} /* end of soSetSinglePartBuf */

/* so020:201 : New function */
/*
*
*       Fun:   soSetSingleBodyPartBuf
*
*       Desc:  This function is used to decode SDP body part using 
*              content length with a Msg Buffer
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PRIVATE S16   soSetSingleBodyPartBuf
(
SoBody       *sipBody,     /* Pointer to body into which to decode buffer */
MsgLen       bodyLen,      /* count of bytes in message body        */
Buffer       **mBuf         /* Incoming data     */
)
#else
PRIVATE S16   soSetSingleBodyPartBuf(sipBody, bodyLen, mBuf)
SoBody       *sipBody;     /* Pointer to body into which to decode buffer */
MsgLen       bodyLen;      /* count of bytes in message body        */
Buffer       **mBuf;        /* Incoming data     */
#endif
{
   S16      ret;
   MsgLen   msgLen;     /* length of data in message buffer      */

   ret = ROK;

   TRC2(soSetSingleBodyPartBuf);

   /* Split mBuf into two sections - one for this 
      body part and one for the rest of the "main" message.  
    */
   SFndLenMsg (*mBuf, &msgLen);

   if (bodyLen <= msgLen)
   {
      /*------ Set body type to single-part -------*/
       SO_FILL_TKNU8(&sipBody->bodyType, SOT_BODYTYPE_SINGLEPART);
      
      /*------- Set single-part type to STR -------*/
       SO_FILL_TKNU8(&sipBody->u.singlePart.bodySinglePartType,
                     SOT_BODYSINGLEPART_STR);
      
      /*----------- copy the message body ---------*/
       ret = SCpyMsgMsg (*mBuf,
                         soCb.init.region,
                         soCb.init.pool,
                         &sipBody->u.singlePart.s.str.val);
       if (ret != ROK)
          RETVALUE (ret);
      
       sipBody->u.singlePart.s.str.pres = PRSNT_NODEF;
      
       if (msgLen > bodyLen)
       {
        /*---- Remove Extra Bytes From Message ----*/
        /*------ so021.201: Removed warning -------*/
         ret = SRemPstMsgMult (NULLP,
                              (MsgLen)(msgLen - bodyLen),
                              sipBody->u.singlePart.s.str.val);
         if (ret != ROK)
           RETVALUE (ret);

       }

      /*----- Remove Extra Bytes From Message -----*/
       ret = SRemPreMsgMult (NULLP, bodyLen, *mBuf);
         if (ret != ROK)
           RETVALUE (ret);

       RETVALUE (ROK);
   }

   RETVALUE (RFAILED);

} /* end of soSetSingleBodyPartBuf */



/*
*
*       Fun:   soTruncMsgToGood
*
*       Desc:  This function truncates a message after the last
*              successfully decoded header occurs.
*
*       Ret:   ROK        success
*              RFAILED    failure - no previous header found
*
*       Notes: CRLF marks the end of a SIP header.
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PRIVATE S16 soTruncMsgToGood
(
Buffer *mBuf,      /* message buffer to scan */
U16    errPos      /* position of Error in mBuf - 0 if not present */
)
#else
PRIVATE S16 soTruncMsgToGood(mBuf, errPos)
Buffer *mBuf;       /* message buffer to scan */
U16    errPos;      /* position of Error in mBuf - 0 if not present */
#endif
{
   MsgLen   msgLen;     /* length of data in message buffer   */
   Data     msgByte;    /* one byte of the message to examine */
   MsgLen   i;          /* counter for message data           */
   S16      ret;        /* value returned by function calls   */

   TRC2(soTruncMsgToGood);

   ret = SFndLenMsg(mBuf, &msgLen);
   if (ret != ROK)
   {
      RETVALUE(ret);
   }
   if (errPos>msgLen-2)
   {
      RETVALUE(RFAILED);
   }

   for (i = errPos; i>0; i--)
   {
      ret = SExamMsg(&msgByte, mBuf, i);
      if (ret != ROK)
      {
         RETVALUE(ret);
      }
      if (msgByte == SO_ASCII_LF)
      {
         ret = SExamMsg(&msgByte, mBuf, (S16)(i - 1));
         if ((msgByte == SO_ASCII_CR) && (ret == ROK))
         {
            SRepMsg(SO_ASCII_CR, mBuf, (MsgLen)(i+1));
            SRepMsg(SO_ASCII_LF, mBuf, (MsgLen)(i+2));
            /* mBuf->t.msg.msgLen = i+3;*/
            RETVALUE(ROK);
         }
      }
   }

   RETVALUE(RFAILED);
} /* end of soTruncMsgToGood */


/*
*
*       Fun:   soGetContentLen
*
*       Desc:  This function gets the content length (U32) from an event
*              structure in a message control block.
*              This is used to check that the entire message has been received.
*
*       Ret:   ROK        Content-Len present
*              RFAILED    Content-Len NOT present
*
*       Notes: contentLen returns the value found in the content-length header.
*              A value of zero is used to indicate that no content-length header
*              was found or that the content-length value was zero.
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PRIVATE S16 soGetContentLen
(
SoEvnt  *evnt,       /* Message CB from which to get content length      */
U32      *contentLen    /* content length value to be returned              */
)
#else
PRIVATE S16 soGetContentLen(evnt, contentLen)
SoEvnt  *evnt;       /* Message CB from which to get content length      */
U32      *contentLen;   /* content length value to be returned              */
#endif
{
   TknU32    *cntLenHdr;  /* content length header */
   S16       ret;         /* return value */

   TRC2(soGetContentLen);

   /* Find header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &cntLenHdr,
                                 SO_HEADER_ENT_CONTENTLENGTH);
   
   if (ret == ROK)
   {
      if (cntLenHdr->pres == PRSNT_NODEF)
      {
         *contentLen = cntLenHdr->val;
         RETVALUE(ROK);
      }
   }

   *contentLen = 0;
   RETVALUE(RFAILED);
} /* end of soGetContentLen */


/*
*
*       Fun:   soCnvrtCmpct
*
*       Desc:  This function changes decoded header types from the compact form
*              to the full form for use by the layer.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PUBLIC S16 soCnvrtCmpct
(
SoEvnt      *evnt        /* SIP message to convert */
)
#else
PUBLIC S16 soCnvrtCmpct(evnt)
SoEvnt      *evnt;       /* SIP message to convert */
#endif
{
   TknU8        *hdrType; /* local pointer to header type */
   U32          i;        /* Index into headers           */
   SoHeaderSeq  *hdrSeq;  /* Headers to convert           */

   TRC2(soCnvrtCmpct);

   /* Check message type */
   if (SO_MSGTYPE_REQ(evnt) == TRUE)
   {
      hdrSeq = &evnt->t.request.request;
   }
   else
   {
      hdrSeq = &evnt->t.response.response;
   }

   for (i = 0; i < SO_GET_NUM_COMP(&hdrSeq->numComp); i++)
   {
      hdrType = &hdrSeq->header[i]->headerType;
      if (hdrType->pres != PRSNT_NODEF)
      {
         SODBGP_SO(SO_DBGMASK_MH, (soCb.init.prntBuf,
                 "\nsoCnvrtCmpct: Header type not present.\n"));
         RETVALUE(RFAILED);
      }
      switch (hdrType->val)
      {
         case SO_HEADER_GEN_CALLIDI:
            hdrType->val = SO_HEADER_GEN_CALLID;
            break;
         case SO_HEADER_GEN_CONTACTM:
            hdrType->val = SO_HEADER_GEN_CONTACT;
            break;
         case SO_HEADER_GEN_FROMF:
            hdrType->val = SO_HEADER_GEN_FROM;
            break;
         case SO_HEADER_GEN_TOT:
            hdrType->val = SO_HEADER_GEN_TO;
            break;
         case SO_HEADER_GEN_VIAV:
            hdrType->val = SO_HEADER_GEN_VIA;
            break;
         case SO_HEADER_GEN_SUBJECTS:
            hdrType->val = SO_HEADER_GEN_SUBJECT;
            break;
         case SO_HEADER_ENT_CONTENTENCODINGE:
            hdrType->val = SO_HEADER_ENT_CONTENTENCODING;
            break;
         case SO_HEADER_ENT_CONTENTLENGTHL:
            hdrType->val = SO_HEADER_ENT_CONTENTLENGTH;
            break;
         case SO_HEADER_ENT_CONTENTTYPEC:
            hdrType->val = SO_HEADER_ENT_CONTENTTYPE;
            break;
         case SO_HEADER_GEN_SUPPORTEDK:
            hdrType->val = SO_HEADER_GEN_SUPPORTED;
            break;
#ifdef SO_SESSTIMER
         case SO_HEADER_GEN_SESSION_EXPIRESX:
            hdrType->val = SO_HEADER_GEN_SESSION_EXPIRES;
            break;
#endif
#ifdef  SO_REFER
         case SO_HEADER_REQ_REFERTOR:
            hdrType->val = SO_HEADER_REQ_REFERTO;
            break;
         case SO_HEADER_REQ_REFERBYB:
            hdrType->val = SO_HEADER_REQ_REFERBY;
            break;
#endif
      }
   }
   RETVALUE(ROK);
} /* end of soCnvrtCmpct */

/*
*
*       Fun:   soMakeCmpct
*
*       Desc:  This function changes header types to their compact equivalents
*              before encoding.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: This function does exactly the opposite of soCnvrtCmpct.
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PRIVATE S16 soMakeCmpct
(
SoEvnt      *evnt        /* SIP message to convert */
)
#else
PRIVATE S16 soMakeCmpct(evnt)
SoEvnt      *evnt;       /* SIP message to convert */
#endif
{
   TknU8        *hdrType;       /* local pointer to header type        */
   U32          i;              /* Index into headers                  */
   SoHeaderSeq  *hdrSeq;        /* Headers to convert                  */

   TRC2(soMakeCmpct);

   /* Check message type */
   if (SO_MSGTYPE_REQ(evnt) == TRUE)
   {
      hdrSeq = &evnt->t.request.request;
   }
   else
   {
      hdrSeq = &evnt->t.response.response;
   }


   for (i = 0; i < SO_GET_NUM_COMP(&hdrSeq->numComp); i++)
   {
      hdrType = &hdrSeq->header[i]->headerType;
      if (hdrType->pres != PRSNT_NODEF)
      {
         SODBGP_SO(SO_DBGMASK_MH, (soCb.init.prntBuf,
                 "\nsoMakeCmpct: Header type not present.\n"));
         RETVALUE(RFAILED);
      }
      switch (hdrType->val)
      {
         case SO_HEADER_GEN_CALLID:
            hdrType->val = SO_HEADER_GEN_CALLIDI;
            break;
         case SO_HEADER_GEN_CONTACT:
            hdrType->val = SO_HEADER_GEN_CONTACTM;
            break;
         case SO_HEADER_GEN_FROM:
            hdrType->val = SO_HEADER_GEN_FROMF;
            break;
         case SO_HEADER_GEN_TO:
            hdrType->val = SO_HEADER_GEN_TOT;
            break;
         case SO_HEADER_GEN_VIA:
            hdrType->val = SO_HEADER_GEN_VIAV;
            break;
         case SO_HEADER_GEN_SUBJECT:
            hdrType->val = SO_HEADER_GEN_SUBJECTS;
            break;
         case SO_HEADER_ENT_CONTENTENCODING:
            hdrType->val = SO_HEADER_ENT_CONTENTENCODINGE;
            break;
         case SO_HEADER_ENT_CONTENTLENGTH:
            hdrType->val = SO_HEADER_ENT_CONTENTLENGTHL;
            break;
         case SO_HEADER_ENT_CONTENTTYPE:
            hdrType->val = SO_HEADER_ENT_CONTENTTYPEC;
            break;
            /*---- so021.201: Compact form for Session Expires -----*/
#ifdef SO_SESSTIMER
         case SO_HEADER_GEN_SESSION_EXPIRES:
            hdrType->val = SO_HEADER_GEN_SESSION_EXPIRESX;
            break;
#endif
#ifdef  SO_REFER
         case SO_HEADER_REQ_REFERTO:
            hdrType->val = SO_HEADER_REQ_REFERTOR;
            break;
         case SO_HEADER_REQ_REFERBY:
            hdrType->val = SO_HEADER_REQ_REFERBYB;
            break;
#endif

      }
   }
   RETVALUE(ROK);
} /* end of soMakeCmpct */


/*
*
*       Fun:   soChckCSeq
*
*       Desc:  Checks to see if the method in the request line corresponds to
*              the method CSeq header.  If there is no method in the CSeq
*              header, this function copies it from the request line.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PRIVATE S16 soChckCSeq
(
SoEvnt     *rxEvent      /* SIP event          */
)
#else
PRIVATE S16 soChckCSeq(rxEvent)
SoEvnt     *rxEvent;      /* SIP event          */
#endif
{
   SoCSeq      *cseq;      /* local pointer to CSeq header  */
   S16         ret;        /* value returned by function calls */

   TRC2(soChckCSeq);

   if (SO_CMP_TKN_LIT(&rxEvent->sipMessageType,
      SO_SIPMESSAGE_REQUEST) != TRUE)
   {
      /* We only need to check requests */
      RETVALUE(ROK);
   }

   /* Find CSeq header */
   ret = soCmFindHdrChoice(rxEvent, (U8 **)&cseq,
                           SO_HEADER_GEN_CSEQ);
   if (ret != ROK)
   {
      /* No CSeq header */
      RETVALUE(RFAILED);
   }

   /* If cSeq method is not present, set it to the value in the request line */
   if (cseq->method.type.pres == NOTPRSNT)
   {
      SO_FILL_TKNU8(&cseq->method.type,
                    rxEvent->t.request.requestLine.method.type.val);
      switch (rxEvent->t.request.requestLine.method.type.val)
      {
         case SO_METHOD_METHODSTD:
            SO_FILL_TKNU8(&cseq->method.t.std,
                          rxEvent->t.request.requestLine.method.t.std.val);

            break;

         case SO_METHOD_EXTENSIONMETHOD:
            ret = soUtlCpyTknStrOSXL(&cseq->method.t.ext,
                                  &rxEvent->t.request.requestLine.method.t.ext,
                                  &rxEvent->memCp);
            if (ret != ROK)
            {
               RETVALUE(RFAILED);
            }
            break;

         default:
            RETVALUE(RFAILED);
            break;
      }

      RETVALUE(ROK);
   }

   if (SO_CMP_TKN(&cseq->method.type,
                  &rxEvent->t.request.requestLine.method.type) != TRUE)
   {
      /* Method types differ */
      RETVALUE(RFAILED);
   }

   if (SO_CMP_TKN_LIT(&cseq->method.type, SO_METHOD_METHODSTD) == TRUE)
   {
      if (SO_CMP_TKN(&cseq->method.t.std,
                     &rxEvent->t.request.requestLine.method.t.std) == TRUE)
      {
         /* Methods the same */
         RETVALUE(ROK);
      }
   }
   else if (SO_CMP_TKN_LIT(&cseq->method.type,
                           SO_METHOD_EXTENSIONMETHOD) == TRUE)
   {
      if (soUtlCmpTknStrOSXL(&cseq->method.t.ext,
            &rxEvent->t.request.requestLine.method.t.ext,
            FALSE) == TRUE)
      {
         /* Methods the same */
         RETVALUE(ROK);
      }
   }

   RETVALUE(RFAILED);
} /* end of soChckCSeq */


/*****************************************************************************
*
*       Fun  : soChckVerNumber
*
*       Desc : Validate SIP version Number
*
*       Ret  : ROK
*              RFAILED
*
*       Notes: Case insensitive comparison possible if specified
*
*
*       File:  so_cm.c
*
*****************************************************************************/
#ifdef ANSI
PRIVATE S16 soChckVerNumber
(
SoEvnt     *rxEvent      /* SIP event          */
)
#else
PRIVATE S16 soChckVerNumber(rxEvent)
SoEvnt     *rxEvent;     /* SIP event          */
#endif
{
   U8       *str;
   U16      len;
   U32      i;    /* Counter */

   TRC2(soChckVerNumber)


   if (rxEvent->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
   {
      len = rxEvent->t.request.requestLine.sipVersion.len;
      str = rxEvent->t.request.requestLine.sipVersion.val;
   }
   else if (rxEvent->sipMessageType.val == SO_SIPMESSAGE_RESPONSE)
   {
      len = rxEvent->t.response.statusLine.sipVersion.len;
      str = rxEvent->t.response.statusLine.sipVersion.val;
   }
   else
   {
      RETVALUE(RFAILED);
   }

   if (len != SO_SIP_VERSION_LEN)
   {
      RETVALUE(RFAILED);
   }
   for (i=0; i < SO_SIP_VERSION_LEN; i++)
   {
      if (str[i] != soSipVersion[i])
      {
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);
}/* soChckVerNumber */


/*
*
*       Fun:   soChkCrlf
*
*       Desc:  This function scans a message buffer for two CRLF's in a row.
*              It is used to check whether all SIP headers have been received.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: CRLF CRLF marks the end of the SIP headers.
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PUBLIC S16 soChkCrlf
(
Buffer *mBuf,       /* message buffer to scan */
U16    *crlfPos     /* position of CRLF CRLF in mBuf - 0 if not present */
)
#else
PUBLIC S16 soChkCrlf(mBuf, crlfPos)
Buffer *mBuf;       /* message buffer to scan */
U16    *crlfPos;    /* position of CRLF CRLF in mBuf - 0 if not present */
#endif
{
   MsgLen   msgLen;     /* length of data in message buffer   */
   Data     msgByte;    /* one byte of the message to examine */
   MsgLen   i;          /* counter for message data           */

   TRC2(soChkCrlf);

   /* Initialize crlf */
   *crlfPos = SO_MH_NO_CRLF;

   if (SFndLenMsg(mBuf, &msgLen) != ROK)
   {
      RETVALUE(RFAILED);
   }

   for (i = 0; i < (msgLen - 3); i++)
   {
      if (SExamMsg(&msgByte, mBuf, i) != ROK)
      {
         RETVALUE(RFAILED);
      }

      if (msgByte == SO_ASCII_CR)
      {
         /* Check for CRLF CRLF */
         if (SExamMsg(&msgByte, mBuf, (S16)(i + 1)) != ROK)
         {
            RETVALUE(RFAILED);
         }
         if (msgByte == SO_ASCII_LF)
         {
            if (SExamMsg(&msgByte, mBuf, (S16)(i + 2)) != ROK)
            {
               RETVALUE(RFAILED);
            }
            if (msgByte == SO_ASCII_CR)
            {
               if (SExamMsg(&msgByte, mBuf, (S16)(i + 3)) != ROK)
               {
                  RETVALUE(RFAILED);
               }
               if (msgByte == SO_ASCII_LF)
               {
                  /* CRLF CRLF found - this indicates end of headers */
                  *crlfPos = i + 3;
                  RETVALUE(ROK);
               }
            }
         }
      }
   }

   RETVALUE(ROK);
} /* end of soChkCrlf */


/*
*
*       Fun:   soEncodeMultipart
*
*       Desc:  This function is used to encode multipart MIME data
*              into a Msg Buffer.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PRIVATE S16   soEncodeMultipart
(
SoBody            *body,        /* New message control block for message */
TknStrOSXL        *boundary,    /* Multipart boundary */
Buffer            *mBuf         /* Incoming data     */
)
#else
PRIVATE S16   soEncodeMultipart(body, boundary, mBuf)
SoBody            *body;        /* New message control block for message */
TknStrOSXL        *boundary;    /* Multipart boundary */
Buffer            *mBuf;        /* Incoming data     */
#endif
{
   U16                i;          /* counter for headers                   */
   S16                ret;        /* value returned by function calls      */
   CmAbnfErr          err;        /* ABNF module error structure           */
   SoBodyMultiPartElm *bodyElm;   /* local pointer to current body element */
#ifndef CM_SDP_OPAQUE   
   Buffer             *sdpBuf;    /* Buffer into which to encode SDP       */
#endif
   Mem                abnfMem;    /* Memory structure to pass to ABNF      */
   Buffer             *hdrBuf;    /* Buffer into which to encode headers   */
   U8                 *CRLFStr   = (U8 *)"\r\n";
   U8                 *hyphenStr = (U8 *)"--";
   Buffer             *tempBuf;   /* Buffer for copying singlepart bodies  */   

   TRC2(soEncodeMultipart);

   /* Initialize abnfMem */
   abnfMem.region = soCb.init.region;
   abnfMem.pool   = soCb.init.pool;

   /* Loop through the parts in the event structure */
   for (i = 0; i < SO_GET_NUM_COMP(&body->u.multiPart.numComp);
        i++)
   {
      /* Add the MIME boundary */
      ret = SAddPstMsgMult(hyphenStr, 2, mBuf);
      if (ret != ROK)
         RETVALUE(RFAILED);

      ret = SAddPstMsgMult((U8 *)boundary->val, boundary->len, mBuf);
      if (ret != ROK)
         RETVALUE(RFAILED);

      ret = SAddPstMsgMult(CRLFStr, 2, mBuf);
      if (ret != ROK)
         RETVALUE(RFAILED);

      ret = SGetMsg(soCb.init.region, soCb.init.pool, &hdrBuf);
      if (ret != ROK)
         RETVALUE(RFAILED);

      /* Set bodyElm pointer */
      bodyElm = body->u.multiPart.bodyElm[i];

      /* Check the MIME part type */

      /* Initialize err */
      (Void) cmMemset((U8 *)&err, 0, sizeof(CmAbnfErr));

      /* It is possible there is no header when 
       * encoding text/plain. For this case we just need to 
       * encode one more CRLF. Also, no header implifies the 
       * body type is singlepart string. We should add the 
       * protection to make it is singlepart string.
       */
      /* Call ABNF Encode function */
      if(bodyElm->hdrSeq.numComp.pres == PRSNT_NODEF && 
         bodyElm->hdrSeq.numComp.val > 0)
      {
         ret = cmAbnfEncPduMsg(CM_ABNF_PROT_SIP,
                               (U8 *)&bodyElm->hdrSeq,
                               hdrBuf, &soMsgDefHeaderList, &abnfMem, &err);
         if (ret != ROK)
         {
#ifdef DEBUGP
            if (soCb.init.dbgMask & SO_DBGMASK_ABNF_ENC)
            {
               (Void) soUtlPrntMsg(hdrBuf,
                                  "Multipart body encode FAILED", FALSE, 0);
               SODBGP_SO(SO_DBGMASK_ABNF_ENC, (soCb.init.prntBuf,
              "soEncodeMultipart: Encode failed: Error code=%d idNum=%d\n",
                 err.code, err.idNum));
            }
#endif
            SPutMsg(hdrBuf);
            RETVALUE(RFAILED);
         }

         /* Concatenate and free hdrBuf */
         ret = SCatMsg(mBuf, hdrBuf, M1M2);
         SPutMsg(hdrBuf);
         if (ret != ROK)
            RETVALUE(RFAILED);
      }
      else
      {
         if((SO_CMP_TKN_LIT(&bodyElm->body->bodyType, SOT_BODYTYPE_MULTIPART)
            == TRUE) || 
            SO_CMP_TKN_LIT(&bodyElm->body->u.singlePart.bodySinglePartType,
                           SOT_BODYSINGLEPART_STR) != TRUE)
            RETVALUE(RFAILED);
      }
      
      /* add CRLF to separate the hdr and body. */
      ret = SAddPstMsgMult(CRLFStr, 2, mBuf);
      if (ret != ROK)
         RETVALUE(RFAILED);
      
      /* Check the body type */
      if (SO_CMP_TKN_LIT(&bodyElm->body->bodyType, SOT_BODYTYPE_MULTIPART)
            == TRUE)
      {
         /* Encode multipart body */
         ret = soEncodeMultipart(bodyElm->body, boundary, mBuf);
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }

        /*--- so041.201: Added the code that adds the CRLF after a multipart body --*/
         ret = SAddPstMsgMult(CRLFStr, 2, mBuf);
         if (ret != ROK)
             RETVALUE(RFAILED);
      }
      else
      {
#ifndef CM_SDP_OPAQUE         
         /* Encode single part body */
         if (SO_CMP_TKN_LIT(&bodyElm->body->u.singlePart.bodySinglePartType,
                            SOT_BODYSINGLEPART_SDP) == TRUE)
         {
            /* Allocate message for SDP buffer */
            ret = SGetMsg(soCb.init.region, soCb.init.pool, (Buffer **) &sdpBuf);
            if (ret != ROK)
               RETVALUE(RFAILED);

            /* Initialize err */
            (Void) cmMemset((U8 *)&err, 0, sizeof(CmAbnfErr));

            /* Call ABNF encode function */
            ret = cmAbnfEncPduMsg(CM_ABNF_PROT_SDP,
                               (U8 *)&bodyElm->body->u.singlePart.s.sdp->sdp,
                               sdpBuf, &cmMsgDefSdp, &abnfMem, &err);
            if (ret != ROK)
            {
#ifdef DEBUGP
               if (soCb.init.dbgMask & SO_DBGMASK_ABNF_ENC)
               {
                  (Void) soUtlPrntMsg(sdpBuf,
                                     "SDP body encode FAILED!!", FALSE, 0);
                  SODBGP_SO(SO_DBGMASK_ABNF_ENC, (soCb.init.prntBuf,
                       "soEncodeMultiPart: Encode failed: Error \
                       code=%d idNum=%d\n", err.code, err.idNum));
               }
#endif
               SPutMsg(sdpBuf);
               RETVALUE(RFAILED);
            }
#ifdef DEBUGP
            if (soCb.init.dbgMask & SO_DBGMASK_ABNF_ENC)
            {
               (Void) soUtlPrntMsg(sdpBuf, "Encoded SDP body", FALSE, 0);
            }
#endif
            /* Add final CRLF */
            ret = SAddPstMsgMult(CRLFStr, 2, sdpBuf);
            if (ret != ROK)
            {
               SPutMsg(sdpBuf);
               RETVALUE(RFAILED);
            }

            ret = SCatMsg(mBuf, sdpBuf, M1M2);
            SPutMsg(sdpBuf);
            if (ret != ROK)
               RETVALUE(RFAILED);
         }
         else
#endif /* CM_SDP_OPAQUE */
         {
            if (SO_CMP_TKN_LIT(&bodyElm->body->u.singlePart.bodySinglePartType,
                               SOT_BODYSINGLEPART_STR) == TRUE)
            {
               if (bodyElm->body->u.singlePart.s.str.pres != NOTPRSNT)
               {
                  /* Copy body str - but ensure single part body  
                   * is kept for retransmissions.  This means copy to new 
                   * message, then append to message so far. */

                  ret = SCpyMsgMsg(bodyElm->body->u.singlePart.s.str.val,
                                soCb.init.region, soCb.init.pool,
                                &tempBuf);
                  if (ret != ROK)
                  {
                     SPutMsg(tempBuf);
                     RETVALUE(RFAILED);
                  }

                  ret = SAddPstMsgMult(CRLFStr, 2, tempBuf);

                  if (ret != ROK) 
                  {
                     SPutMsg(tempBuf);
                     RETVALUE(RFAILED);
                  }

                  ret = SCatMsg(mBuf, tempBuf, M1M2);
                  SPutMsg(tempBuf);
                  if (ret != ROK)
                  {
                     RETVALUE(RFAILED);
                  }                  
               }
            }
         }
      }
   }

   /* The last boundary needs to be encoded as CRLF--BOUNDARY--CRLF */
   /*--- so041.201: Deleted the code that added the First CRLF for the last
	Boundary. The reason being, our encoding logic works in the following fashion
	1. Add Boundary
	2. Add Header
	3. Add CRLF
	4. Add Body
	5. Add CRLF
	6. Loop for more body elements
	7. Add CRLF 
	8. Add final boundary
	9. Add CRLF
	Due to step 7 we were adding an additional CRLF, hence its removal was needed ---*/

   ret = SAddPstMsgMult(hyphenStr, 2, mBuf);
   if (ret != ROK)
          RETVALUE(RFAILED);
   
   /* Add final unique boundary */
   ret = SAddPstMsgMult((U8 *)boundary->val, boundary->len, mBuf);
   if (ret != ROK)
          RETVALUE(RFAILED);
   

   ret = SAddPstMsgMult(hyphenStr, 2, mBuf);
   if (ret != ROK)
          RETVALUE(RFAILED);
   

   ret = SAddPstMsgMult(CRLFStr, 2, mBuf);
   if (ret != ROK)
          RETVALUE(RFAILED);
   

   RETVALUE(ROK);
} /* end of soEncodeMultipart */


/*
*
*       Fun:   soSipEncodeReq
*
*       Desc:  SIP Encode Request 
*
*       Ret:   ROK/RFAILED
*
*       Notes: 
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PUBLIC S16   soSipEncodeReq
(
U32           protVar,    /* protocol and variant */
SoEntCb       *entCb,     /* Entity Control Block  */
U8            *message,   /* pointer to the event structure */
Buffer        **mBuf,      /* Message buffer */
CmAbnfElmDef  *elmDef,    /* message defintion */
Mem           *abnfMem,   /* Memory: region/pool */
CmAbnfErr     *err        /* error */
)
#else
PUBLIC S16 soSipEncodeReq(protVar, entCb, message, mBuf, elmDef, abnfMem, err)
U32           protVar;    /* protocol and variant */
SoEntCb       *entCb;     /* Entity Control Block  */
U8            *message;   /* pointer to the event structure */
Buffer        **mBuf;      /* Message buffer */
CmAbnfElmDef  *elmDef;    /* message defintion */
Mem           *abnfMem;   /* Memory: region/pool */
CmAbnfErr     *err;       /* error */
#endif
{
   SoEvnt              *evnt;        /* soEvnt structure */
   S16                 ret;          /* return value */
   Buffer              *hdrBuf;      /* Message buffer for header             */
   Buffer              *bodyBuf;     /* Message buffer for body part          */
   MsgLen              bodyLen,msgLen;      /* length of SDP body                    */
   TknStrOSXL          *boundary;    /* local pointer to MIME boundary        */
   SoContentTypeHdr    *contentType; /* Local pointer to content-type header  */

   TRC2(soSipEncodeReq);
   
   msgLen = 0;

   if (protVar != CM_ABNF_PROT_SIP_ANY) 
   {
      ret = cmAbnfEncPduMsg(protVar, message, *mBuf, elmDef, abnfMem, err);
   }
   else 
   {
      /* get Message Control Block pointer */
      evnt = (SoEvnt *)message;

      /* Initialize bodyBuf to NULL */
      bodyBuf = (Buffer *) NULLP;

      /* Encode SDP part if required */
   
      /* Check for multipart MIME */
      if (SO_CMP_TKN_LIT(&evnt->sipBody.bodyType,
                         SOT_BODYTYPE_MULTIPART) == TRUE)
      {
         /* Allocate message for SDP buffer */
         ret = SGetMsg(abnfMem->region, abnfMem->pool, (Buffer **) &bodyBuf);
         if (ret != ROK)
         {
            evnt->t.errEvnt.errCode = SOT_ERR_RSRC;
            RETVALUE(RFAILED);
         }
   
         ret = soCmFindHdrChoice(evnt, (U8 **)&contentType,
                                 SO_HEADER_ENT_CONTENTTYPE);
         if (ret != ROK)
         {
            evnt->t.errEvnt.errCode = SOT_ERR_CONTENTTYPE_NOTFOUND;
            RETVALUE(SOT_ERR_CONTENTTYPE_NOTFOUND);
         }
   
         /* Get MIME boundary from content-type header */
         ret = soGetMimeBoundary(contentType, &boundary);
         if (ret != ROK)
         {
            evnt->t.errEvnt.errCode = SOT_ERR_MIMEBNDRY_NOTFOUND;
            RETVALUE(SOT_ERR_MIMEBNDRY_NOTFOUND);
         }
   
         /* Encode Multipart MIME */
         ret = soEncodeMultipart(&evnt->sipBody, boundary, bodyBuf);
         if (ret != ROK)
         {
            evnt->t.errEvnt.errCode  = SOT_ERR_ENC;

           /*---- so019.201: Update Error Statistics -----*/
            entCb->errSts.sipEncFail++;
            soCb.sts.errSts.sipEncFail++;
            
            RETVALUE(SOT_ERR_ENC);
         }
   
#ifdef DEBUGP
         (Void) soUtlPrntMsg(bodyBuf, "soSipEncodeReq: Multipart MIME encoded",
                         FALSE, 0);
#endif /* DEBUGP */
      }

      /* Check for SDP part */
#ifndef CM_SDP_OPAQUE
      if (SO_CMP_TKN_LIT(&evnt->sipBody.bodyType,
                         SOT_BODYTYPE_SINGLEPART) == TRUE)
      {
         if (SO_CMP_TKN_LIT(
            &evnt->sipBody.u.singlePart.bodySinglePartType,
                            SOT_BODYSINGLEPART_SDP) == TRUE)
         {
            /* Allocate message for SDP buffer */
            ret = SGetMsg(abnfMem->region, abnfMem->pool, (Buffer **) &bodyBuf);
       if (ret != ROK)
            {
               evnt->t.errEvnt.errCode = SOT_ERR_RSRC;
               RETVALUE(RFAILED);
            }
   
            /* Initialize err */
            (Void) cmMemset((U8 *)err, 0, sizeof(CmAbnfErr));
   
            /* Call ABNF encode function */
            ret = cmAbnfEncPduMsg(CM_ABNF_PROT_SDP,
                   (U8 *)&evnt->sipBody.u.singlePart.s.sdp->sdp,
                   bodyBuf, &cmMsgDefSdp, abnfMem, err);
            if (ret != ROK)
            {
#ifdef DEBUGP
               if (soCb.init.dbgMask & SO_DBGMASK_ABNF_ENC)
               {
                  (Void) soUtlPrntMsg(bodyBuf,
                                     "SDP body encode FAILED!!", FALSE, 0);
                  SODBGP_SO(SO_DBGMASK_ABNF_ENC, (soCb.init.prntBuf,
                       "soSipEncodeReq: Encode failed: Error code=%d idNum=%d\n",
                       err->code, err->idNum));
               }
#endif /* DEBUGP */
               evnt->t.errEvnt.errCode = SOT_ERR_ENC;

              /*---- so019.201: Update Error Statistics -----*/
               entCb->errSts.sipEncFail++;
               soCb.sts.errSts.sipEncFail++;
             
               RETVALUE(SOT_ERR_ENC);
            }
#ifdef DEBUGP
            if (soCb.init.dbgMask & SO_DBGMASK_ABNF_ENC)
            {
               (Void) soUtlPrntMsg(bodyBuf, "Encoded SDP body", FALSE, 0);
            }
#endif /* DEBUGP */
         }
         else
#endif /* CM_SDP_OPAQUE  */
         {
            /* Check if we have a string for message body */
            if (SO_CMP_TKN_LIT(&evnt->sipBody.bodyType,
                               SOT_BODYTYPE_SINGLEPART) == TRUE)
            {
               if (SO_CMP_TKN_LIT(
                  &evnt->sipBody.u.singlePart.bodySinglePartType,
                  SOT_BODYSINGLEPART_STR) == TRUE)
               {
                  if (evnt->sipBody.u.singlePart.s.str.pres != NOTPRSNT)
                  {
                     /* Set bodyBuf */
                     ret = SCpyMsgMsg(
                        evnt->sipBody.u.singlePart.s.str.val,
                        abnfMem->region, abnfMem->pool,
                        &bodyBuf);
                     if (ret != ROK)
                     {
                       evnt->t.errEvnt.errCode  = SOT_ERR_RSRC;
                        RETVALUE(SOT_ERR_RSRC);
                     }
                  }
               }
#ifdef DEBUGP
               if (soCb.init.dbgMask & SO_DBGMASK_ABNF_ENC)
               {
                  (Void) soUtlPrntMsg(bodyBuf, "Encoded SDP body from string",
                                     FALSE, 0);
               }
#endif /* DEBUGP */
            }
         }
#ifndef CM_SDP_OPAQUE
      }
#endif /* CM_SDP_OPAQUE */

      /* Compute body length */
      if (bodyBuf != NULLP)
         SFndLenMsg(bodyBuf, &bodyLen);
      else
         bodyLen =0;
   
      /* Add content-length header */
      ret = soPrcContentLength(evnt, bodyLen);
      if (ret != ROK)
      {
         evnt->t.errEvnt.errCode = SOT_ERR_ADD_HDR_FAILED;
         RETVALUE(SOT_ERR_ADD_HDR_FAILED);
      }

      /* Allocate memory for mBuf */
      if ( SGetMsg(abnfMem->region, abnfMem->pool, (Buffer **) &hdrBuf)!=ROK )
      {
         evnt->t.errEvnt.errCode = SOT_ERR_RSRC;
         RETVALUE(SOT_ERR_RSRC);
      }
   
      /* Check if it is necessary to use compact header form */
      if (entCb->reCfg.useCompact) 
         /* Convert headers to compact form */
         (Void) soMakeCmpct(evnt);
   
      /* Initialize err */
      (Void) cmMemset((U8 *)err, 0, sizeof(CmAbnfErr));
   
      /* Call ABNF encode function */
      ret = cmAbnfEncPduMsg(CM_ABNF_PROT_SIP, (U8 *)&evnt->sipMessageType,
                            hdrBuf, &soMsgDefSipMessage, abnfMem, err);
      if (ret != ROK)
      {
#ifdef DEBUGP
         if (soCb.init.dbgMask & SO_DBGMASK_ABNF_ENC)
         {
            (Void) soUtlPrntMsg(hdrBuf, "Encoded SIP message", FALSE, 0);
         }
         SODBGP_SO(SO_DBGMASK_ABNF_ENC, (soCb.init.prntBuf,
              "soSipEncodeReq: Encode failed: Error code=%d idNum=%d\n",
              err->code, err->idNum));
#endif
         evnt->t.errEvnt.errCode = SOT_ERR_ENC;
        
         if (entCb->reCfg.useCompact) 
            (Void) soCnvrtCmpct (evnt);

        /*---- so019.201: Update Error Statistics -----*/
         entCb->errSts.sipEncFail++;
         soCb.sts.errSts.sipEncFail++;

         RETVALUE(SOT_ERR_ENC);
      }
   
      /*-- Convert header from "compact" form to "long" form --*/
      if (entCb->reCfg.useCompact) 
         (Void) soCnvrtCmpct (evnt);

      /* Add message body to message header part if necessary */
      if (bodyBuf != (Buffer *)NULLP)
      {
         if ( SCatMsg(hdrBuf, bodyBuf, M1M2)!=ROK )
         {
            evnt->t.errEvnt.errCode = SOT_ERR_RSRC;
            RETVALUE(SOT_ERR_RSRC);
         }
         SPutMsg(bodyBuf);
      }

      /* return the Encoded Buffer */
      *mBuf = hdrBuf;
#ifdef DEBUGP
      SFndLenMsg(*mBuf, &msgLen);
      if (soCb.init.dbgMask & SO_DBGMASK_ABNF_ENC)
      {
         (Void) soUtlPrntMsg(*mBuf, "soSipEncodeReq: Message encoded", FALSE,
                            msgLen);
      }
#endif /* DEBUGP */
   }

   RETVALUE(ret);

} /* soSipEncodeReq */


/*
*
*       Fun:   soPrcContentLength
*
*       Desc:  This checks for the presence of a Content Length header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PRIVATE S16 soPrcContentLength
(
SoEvnt  *evnt,  /* SIP Event structure */
U32     len     /* Content length      */
)
#else
PRIVATE S16 soPrcContentLength(evnt, len)
SoEvnt  *evnt;  /* SIP Event structure */
U32     len;    /* Content length      */
#endif
{
   TknU32  *contentLength;   /* Pointer to content-length header */
   S16     ret;              /* value returned by function calls */

   TRC2(soPrcContentLength);

   /* Find header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &contentLength,
                              SO_HEADER_ENT_CONTENTLENGTH);
   if (ret != ROK)
   {
      if ( soCmCreateHdrChoice(evnt, (U8 **)&contentLength,
         SO_HEADER_ENT_CONTENTLENGTH)!=ROK )
      {
         RETVALUE(RFAILED);
      }
   }

   SO_FILL_TKNU32(contentLength, len);

   RETVALUE(ROK);

} /* end of soPrcContentLength */







#ifndef CM_SDP_OPAQUE 
/*
*
*       Fun:   soDecodeSDP
*
*       Desc:  This function is used to decode SDP data with a Msg Buffer
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
/*chendh*/PUBLIC S16   soDecodeSDP
(
SoBody       *sipBody,     /* Pointer to body into which to decode buffer */
Buffer       *mBuf         /* Incoming data     */
)
#else
/*chendh*/PUBLIC S16   soDecodeSDP(sipBody, mBuf)
SoBody       *sipBody;     /* Pointer to body into which to decode buffer */
Buffer       *mBuf;        /* Incoming data     */
#endif
{
   MsgLen             numSdpBytes;  /* Number of SDP bytes decoded by ABNF   */
   CmAbnfErr          err;          /* ABNF module error structure           */
   CmAbnfDecOff       decOff;       /* ABNF offset structure                 */
   S16                ret;          /* value returned by function calls      */

   TRC2(soDecodeSDP);

#ifdef DEBUGP
   if (soCb.init.dbgMask & SO_DBGMASK_ABNF_DEC)
   {
      SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                "soDecodeSDP: Decode SDP Message. Source buffer:"));
      SPrntMsg(mBuf, 0, 0);
   }
#endif /* DEBUGP */

   /* Set body type to single-part */
   SO_FILL_TKNU8(&sipBody->bodyType,
                 SOT_BODYTYPE_SINGLEPART);

   /* Set single-part type to SDP */
   SO_FILL_TKNU8(&sipBody->u.singlePart.bodySinglePartType,
                 SOT_BODYSINGLEPART_SDP);

   /* Allocate memory for SDP event structure */
   ret = soCmCreateSdpEvent(&sipBody->u.singlePart.s.sdp);
   if (ret != ROK)
   {
      SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
         "soDecodeSDP: soCmCreateSdpEvent failed to create an SDP Event structure.\n"));
      soGenStaInd(STSIPENT, LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL,
            LSO_PAR_MEM, LSO_PAR_NONE, (Ptr)NULLP );
      RETVALUE(RFAILED);
   }

   /* Attempt to decode SDP part */
   (Void) cmMemset((U8 *)&decOff, 0, sizeof(CmAbnfDecOff));
   (Void) cmMemset((U8 *)&err, 0, sizeof(CmAbnfErr));
   ret = cmAbnfDecPduMsg(CM_ABNF_PROT_SDP,
                  &sipBody->u.singlePart.s.sdp->memCp,
                  (U8 *)&sipBody->u.singlePart.s.sdp->sdp,
                  mBuf,
                  &cmMsgDefSdp, &numSdpBytes, &decOff, &err);
   if (ret == ROK)
   {
#ifdef DEBUGP
      if (soCb.init.dbgMask & SO_DBGMASK_ABNF_DEC)
      {
         (Void) soUtlPrntMsg(mBuf, "soDecodeSDP: SDP decoded", TRUE,
                            (MsgLen)(numSdpBytes));
      }
#endif /* DEBUGP */
      /* Buffer with more than one message */
      /* Subtract one from number of bytes to make it zero based */
      /* and Advance mbuf over decoded part */
      numSdpBytes--;
      ret = SRemPreMsgMult(NULLP, numSdpBytes, mBuf);
      if (ret != ROK)
        RETVALUE (RFAILED);
   }
   else
   {
      SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                "soDecodeSDP: SDP decode failed: Error=%d, Element=%d",
                err.code, err.idNum));
#ifdef DEBUGP
      if (soCb.init.dbgMask & SO_DBGMASK_ABNF_DEC)
      {
         (Void) soUtlPrntMsg(mBuf, "soDecodeSDP: SDP decode error", TRUE,

                            (MsgLen)(numSdpBytes));
      }
#endif /* DEBUGP */
   }

   RETVALUE(ret);
} /* end of soDecodeSDP */
#endif /* CM_SDP_OPAQUE */


/*
*
*       Fun:   soDecodeMultipart
*
*       Desc:  This function is used to decode multipart MIME data
*              from a Msg Buffer.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PRIVATE S16   soDecodeMultipart
(
SoEvnt            *evnt,        /* New message control block for message */
SoContentTypeHdr  *contentType, /* content type header */
Buffer            **mBuf,       /* Incoming data     */
Bool              decSDP        /* decode SDP or not */
)
#else
PRIVATE S16   soDecodeMultipart(evnt, contentType, mBuf, decSDP)
SoEvnt           *evnt;       /* New message control block for message */
SoContentTypeHdr  *contentType; /* content type header */
Buffer            **mBuf;       /* Incoming data     */
Bool              decSDP;       /* decode SDP or not */
#endif
{
   U16                i;            /* counter for headers                   */
   S16                ret;          /* value returned by function calls      */
   CmAbnfErr          err;          /* ABNF module error structure           */
   SoContentTypeHdr   *mimeCntType; /* Content type of attachment            */
   CmAbnfDecOff       decOff;       /* ABNF offset structure                 */
   TknStrOSXL         *boundary;    /* local pointer to MIME boundary        */
   SoBodyMultiPartElm *bodyElm;     /* local pointer to current body element */
   MsgLen             startPos;     /* Start position of boundary            */
   MsgLen             endPos;       /* End position of boundary              */
   MsgLen             numSipBytes;  /* Number of SIP bytes decoded by ABNF   */
   TknU16             *numComp;     /* Number of MIME parts                  */
   Buffer             *mainBuf;     /* Local pointer to main message buffer  */
   Buffer             *mimeBuf;     /* Local pointer to MIME part buffer     */
   Txt                trailStr[5];  /* Trailing string in single part buffer */
   S16                trimLen;      /* Length to trim off single part buffer */

   TRC2(soDecodeMultipart);

   sprintf(trailStr, "\r\n--");
   trimLen = cmStrlen((U8 *)trailStr);
   
   /* Get MIME boundary from content-type header */
   ret = soGetMimeBoundary(contentType, &boundary);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* Set body type to multi-part */
   SO_FILL_TKNU8(&evnt->sipBody.bodyType,
                 SOT_BODYTYPE_MULTIPART);

   /* Find the first MIME boundary */
   ret = soFindMimeBoundary(*mBuf, boundary, &startPos, &endPos);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* Remove the first MIME boundary from the buffer */
   ret = SRemPreMsgMult(NULLP, endPos, *mBuf);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* set local numComp pointer */
   numComp = &evnt->sipBody.u.multiPart.numComp;

   /* Loop through MIME attachments */
   while (soFindMimeBoundary(*mBuf, boundary, &startPos, &endPos) == ROK)
   {
      /* Split mBuf into two sections - one for this MIME part and one for the
       * rest of the "main" message.  mBuf will then contain only this MIME
       * part.
       */
      mainBuf = (Buffer *)NULLP;
      ret = SSegMsg(*mBuf, startPos, &mainBuf);
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

      /* Set pointer to MIME part buffer */
      mimeBuf = *mBuf;

      /* Set mBuf to point to rest of buffer */
      *mBuf = mainBuf;

      /* Remove the MIME boundary from mimeBuf */
      ret = SRemPreMsgMult(NULLP, (MsgLen)(endPos - startPos), *mBuf);
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

      /* Increment numComp */
      SO_FILL_TKNU16(numComp, SO_GET_NUM_COMP(numComp) + 1);

      /* Check that we don't overshoot the size of the array */
      if (SO_GET_NUM_COMP(numComp) > SOT_MAX_MIME_ELM)
      {
         RETVALUE(RFAILED);
      }

      /* Allocate memory for MIME part */
      ret = cmGetMem(&evnt->memCp,
                     sizeof(SoBodyMultiPartElm),
                     (Ptr *)&evnt->sipBody.u.multiPart.bodyElm[
                        SO_GET_NUM_COMP(numComp) - 1]);
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

      /* Set local pointer to bodyElm */
      bodyElm = evnt->sipBody.u.multiPart.bodyElm[
         SO_GET_NUM_COMP(&evnt->sipBody.u.multiPart.numComp) - 1];

      /* Initialize the headers to NULL */
      cmMemset((U8 *)&bodyElm->hdrSeq, 0, sizeof(SoHeaderSeq));

      /* Try and decode */
      (Void) cmMemset((U8 *)&decOff, 0, sizeof(CmAbnfDecOff));
      (Void) cmMemset((U8 *)&err, 0, sizeof(CmAbnfErr));

      /* Call ABNF decode function */
      ret = cmAbnfDecPduMsg(CM_ABNF_PROT_SIP, &evnt->memCp,
         (U8 *)&bodyElm->hdrSeq, mimeBuf, &soMsgDefHeaderList,
         &numSipBytes, &decOff, &err);

      if (ret != ROK)
      {
#ifdef DEBUGP
         if (soCb.init.dbgMask & SO_DBGMASK_ABNF_DEC)
         {
            (Void) soUtlPrntMsg(mimeBuf,
                               "soDecodeMultipart: ERROR in message decode ---",
                               TRUE, (MsgLen)(numSipBytes));
         }
#endif /* DEBUGP */
         SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                   "soDecodeMultipart: SIP decode failed: Error=%d, Element=%d",
                   err.code, err.idNum));
         RETVALUE(RFAILED);
      }

      /* Advance mimeBuf over decoded part */
      ret = SRemPreMsgMult(NULLP, (MsgLen)(numSipBytes + 1), mimeBuf);
      if (ret != ROK)
        RETVALUE (RFAILED);


      /* We must only attempt to decode SDP if there is a Content-Type header
       * set to subtype == SDP.
       */

      /* Locate contentType header in MIME headers */
      mimeCntType = (SoContentTypeHdr *)NULLP;
      for (i = 0; i < SO_GET_NUM_COMP(&bodyElm->hdrSeq.numComp); i++)
      {
         if (SO_CMP_TKN_LIT(&bodyElm->hdrSeq.header[i]->headerType,
                            SO_HEADER_ENT_CONTENTTYPE) == TRUE)
         {
            /* Set content type pointer */
            mimeCntType = &bodyElm->hdrSeq.header[i]->t.contentType;
            break;
         }
      }

      if (mimeCntType == (SoContentTypeHdr *)NULLP)
      {
         /* No contentType header - this is an error */
         RETVALUE(RFAILED);
      }

      /* Allocate memory for the message body */
      ret = cmGetMem(&evnt->memCp,
                     sizeof(SoBody),
               (Ptr *)&bodyElm->body);
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

      if (SO_CMP_TKN_LIT(&mimeCntType->subType.valueType,
                         SO_MEDIA_SUBTYPE_SDP) == TRUE)
      {
#ifndef CM_SDP_OPAQUE
         if (decSDP)
         {
            ret = soDecodeSDP(bodyElm->body, mimeBuf);
            if (ret != ROK)
               RETVALUE(RFAILED);
         }
         else
#endif /* CM_SDP_OPAQUE */
         {
            /* remove trailing "CRLF--" from buffer */
            ret = SRemPstMsgMult(NULLP, trimLen, mimeBuf);
            if (ret != ROK)
            {
               RETVALUE(RFAILED);
            }         
            ret = soSetSinglePartBuf(bodyElm->body, mimeBuf);
            if (ret != ROK)
               RETVALUE(RFAILED);
         }
      }
      else if (SO_CMP_TKN_LIT(&mimeCntType->type.valueType,
                            SO_MEDIA_TYPE_MULTIPART) == TRUE)
      {
         /* set the body element's type to multipart */
         SO_FILL_TKNU8(&bodyElm->body->bodyType,
                       SOT_BODYTYPE_MULTIPART);         
         ret = soDecodeMultipart(evnt, mimeCntType, &mimeBuf, decSDP);
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
      }
      else
      {
         /* remove trailing "CRLF--" from buffer */
         ret = SRemPstMsgMult(NULLP, trimLen, mimeBuf);
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
         
         ret = soSetSinglePartBuf(bodyElm->body, mimeBuf);
         if (ret != ROK)
            RETVALUE(RFAILED);
      }

      /* Free this MIME part */
      SPutMsg(mimeBuf);
   }

   RETVALUE(ROK);
} /* end of soDecodeMultipart */


/*
*
*       Fun:   soSipDecodeReq
*
*       Desc:  SIP Decode Request 
*
*       Ret:   ROK/RFAILED
*
*       Notes: 
*
*       File:  so_ed.c
*
*/

/*---- so019.201: Added parameter to pass entitiy Cb ----*/
#ifdef ANSI
PUBLIC S16   soSipDecodeReq
(
U32           protVar,       /* protocol and variant */
SoEntCb       *entCb,        /* Entity Control Block */
U8            **message,      /* pointer to the event structure */
Buffer        **mBuf,         /* Message buffer */
CmAbnfElmDef  *elmDef,       /* message defintion */
CmMemListCp   *memCp,        /* Memory Control Pointer */
U16           *numDecBytes,  /* Number of decoded Bytes */
CmAbnfDecOff  *decOff,       /* DBUF offset information */
CmAbnfErr     *err,          /* error */
U16           *sipError,     /* SIP Specific error */
Bool          decSDP         /* TcmConn structure */
)
#else
PUBLIC S16 soSipDecodeReq(protVar, entCb, message, mBuf, elmDef, memCp, 
                          numDecBytes, decOff, err, sipError, decSDP)
U32           protVar;       /* protocol and variant */
SoEntCb       *entCb;        /* Entity Control Block */
U8            **message;      /* pointer to the event structure */
Buffer        **mBuf;         /* Message buffer */
CmAbnfElmDef  *elmDef;       /* message defintion */
CmMemListCp   *memCp;        /* Memory Control Pointer */
U16           *numDecBytes;  /* Number of decoded Bytes */
CmAbnfDecOff  *decOff;       /* DBUF offset information */
CmAbnfErr     *err;          /* error */
U16           *sipError;     /* SIP Specific error */
Bool          decSDP;        /* TcmConn structure */
#endif
{

   MsgLen             numSipBytes;  /* Number of SIP bytes decoded by ABNF   */
   MsgLen             numSdpBytes;  /* Number of SDP bytes decoded by ABNF   */
   U32                contentLen;   /* length of message body                */
   MsgLen             msgLen;       /* count of bytes in total message       */
   MsgLen             bodyLen;      /* count of bytes in message body        */
   S16                ret;          /* value returned by function calls      */
   SoContentTypeHdr   *contentType; /* Local pointer to content-type header  */
   SoEvnt             *rxEvent;     /* Received event                        */
   MsgLen             tmpLen;

#ifdef SO_CALEA
   MsgLen             totalMsgLen;
   MsgLen             totalLen;
#endif


   TRC2(soSipDecodeReq);

   /* Initialisation */
   (Void) cmMemset((U8 *)decOff, 0, sizeof(CmAbnfDecOff));
   (Void) cmMemset((U8 *)err, 0, sizeof(CmAbnfErr));
   *numDecBytes = 0;
   
#ifdef SO_CALEA
   totalMsgLen   = 0;
   totalLen      = 0;
#endif

   if (protVar != CM_ABNF_PROT_SIP_ANY)
   {
      ret = cmAbnfDecPduMsg(protVar, memCp, *message, *mBuf, 
                            elmDef, (MsgLen *)numDecBytes, decOff, err);
      RETVALUE(ret);
   }
   else 
   {
      ret = SFndLenMsg(*mBuf, &msgLen);
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

#ifdef SO_CALEA
      totalLen = msgLen;
#endif
      
      if (soCmCreateEvent(&rxEvent, SOT_ET_UNKNOWN) != ROK)
      {
#ifdef DEBUGP
         SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                   "soSipDecodeReq: soCmCreateEvent failed to create a "
                   "SIP Event structure\n"));
#endif /* DEBUGP */
         soGenStaInd(STSIPENT, LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL,
                     LSO_PAR_MEM, LSO_PAR_NONE, (Ptr)NULLP );
         RETVALUE(RFAILED);
      }

#ifdef SO_CALEA
     /*----- Allocate message buffer for saving RAW message -----*/
      ret = SAddMsgRef ((*mBuf),
                        soCb.init.region,
                        soCb.init.pool,
                        &rxEvent->rawMsg);
      if (ret != ROK)
      {
          SODBGP_SO (SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf, "\n[ED] "
                      "Cannot Add Message Reference For SO_CALEA\n"));
          RETVALUE (RFAILED);
      }
#endif

      /* Call ABNF decode function */
      ret = cmAbnfDecPduMsg(CM_ABNF_PROT_SIP, &rxEvent->memCp,
         (U8 *)&rxEvent->sipMessageType, *mBuf, &soMsgDefSipMessage,
         &numSipBytes, decOff, err);

      if (ret != ROK)
      {
#ifdef DEBUGP
         if (soCb.init.dbgMask & SO_DBGMASK_ABNF_DEC)
         {
            (Void) soUtlPrntMsg(*mBuf,
                               "soSipDecodeReq: ERROR in message decode -------",
                               TRUE, (MsgLen)(numSipBytes));
         }
         SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                   "soSipDecodeReq: SIP decode failed: Error=%d, Element=%d",
                   err->code, err->idNum));
#endif /* DEBUGP */
       
        /*---- so019.201: Update Error Statistics -----*/
         entCb->errSts.sipDecFail++;
         soCb.sts.errSts.sipDecFail++;
   
         /* The problem of the ES not having anything populated
         if the DECODE fails...
         First Fixup the msg so that it might decode!
         (so that we can get info about the sender)*/
         soTruncMsgToGood(*mBuf, numSipBytes);
#ifdef DEBUGP
         (Void) soUtlPrntMsg(*mBuf,
                            "soSipDecodeReq: Truncated message -------",
                            TRUE, 9999 );
#endif /* DEBUGP */
         /* Destroy previous Event structure, then build a fresh one */
         (Void) soCmFreeEvent(rxEvent);
         if (soCmCreateEvent(&rxEvent, SOT_ET_UNKNOWN) != ROK)
         {
#ifdef DEBUGP
            SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                       "soSipDecodeReq: soCmCreateEvent failed to create an SIP Event structure\n"));
#endif /* DEBUGP */
            soGenStaInd(STSIPENT, LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL,
                        LSO_PAR_MEM, LSO_PAR_NONE, (Ptr)NULLP );
            RETVALUE(RFAILED);
         }
   
#ifdef SO_CALEA
       /*----- Allocate message buffer for saving RAW message -----*/
         ret = SAddMsgRef ((*mBuf),
                        soCb.init.region,
                        soCb.init.pool,
                        &rxEvent->rawMsg);
         if (ret != ROK)
         {
             SODBGP_SO (SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf, "\n[ED] "
                         "Cannot Add Message Reference For SO_CALEA\n"));
             RETVALUE (RFAILED);
         }
#endif

         /* Try and decode */
         (Void) cmMemset((U8 *)decOff, 0, sizeof(CmAbnfDecOff));
         (Void) cmMemset((U8 *)err, 0, sizeof(CmAbnfErr));
         numSipBytes = 0;
         ret = cmAbnfDecPduMsg(CM_ABNF_PROT_SIP, &rxEvent->memCp,
            (U8 *)&rxEvent->sipMessageType, *mBuf, &soMsgDefSipMessage,
            &numSipBytes, decOff, err);
   
         if (ret == ROK)
         {
            /* Ok it decoded, so we might be able to send an error back
               to the sender */
            *numDecBytes = numSipBytes;
            *sipError = SO_HDR_OK_AFTER_TRUNC;
            *message = (U8 *)rxEvent;
            RETVALUE(ROK);
         }
         else
         {
            /* Could not get info to send error, just drop the event structure
               and move on! */
            (Void) soCmFreeEvent(rxEvent);
            *numDecBytes = numSipBytes;
            *sipError = SO_HDR_NOK_AFTER_TRUNC;
            RETVALUE(ROK);
         }

      } /* End of if (decoding failure) */

#ifdef DEBUGP
      if (soCb.init.dbgMask & SO_DBGMASK_ABNF_DEC)
      {
         (Void) soUtlPrntMsg(*mBuf, "soSipDecodeReq: Message decoded", TRUE,
                            (MsgLen)(numSipBytes));
      }
#endif /* DEBUGP */
   
      tmpLen = numSipBytes;

      /* Subtract one from number of bytes to make it zero based */
      numSipBytes--;
   
      /* Check SIP version: only "SIP/2.0" allowed */
      if (soChckVerNumber(rxEvent) != ROK)
      {
         *numDecBytes = numSipBytes;
         *sipError = SO_VERSION_NOT_SUPPORT;
         *message = (U8 *)rxEvent;
         RETVALUE(ROK);
      }
   
      /* Check CSeq method corresponds to SIP method */
      if (soChckCSeq(rxEvent) != ROK)
      {
         *numDecBytes = numSipBytes;
         *sipError = SO_MAND_HDR_MISS;
         *message = (U8 *)rxEvent;
         RETVALUE(ROK);
      }
   
     
      /* Decoding complete - Convert compact form header types to full form */
      (Void) soCnvrtCmpct(rxEvent);

#ifdef SO_CALEA
        /*------- Copy the SIP Message as RAW Message ---------*/
       totalMsgLen += numSipBytes;
#endif
  
      /* Get Content Length */
      if (soGetContentLen(rxEvent, &contentLen) == ROK)
      {
         /* specified body len (as per RFC) */
         bodyLen = contentLen;
   
         if (bodyLen > (msgLen-numSipBytes))
         {
            /* Whole body not present - message incomplete.
             * Must store message segment and wait for rest of message.
             */
#ifdef DEBUGP
            SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                             "soSipDecodeReq: Incomplete body received\n"));
#endif /* DEBUGP */
            *numDecBytes = numSipBytes;
            *sipError = SO_HDR_OK_BODY_INCMP;
            *message = (U8 *)rxEvent;
            RETVALUE(ROK);
         }
      }
      else
      {
         /* Not in Message so default to rest of message (as per RFC) */
         bodyLen = msgLen-numSipBytes;
      }
   
      numSdpBytes = 0;

#ifdef SO_CALEA
        /*------- Copy the SIP Message as RAW Message ---------*/
       totalMsgLen += bodyLen;
#endif
 
      /* Do we have a message body?? */
      if (bodyLen > 0)
      {
         /* Advance mbuf over decoded part */

         ret = SRemPreMsgMult(NULLP, numSipBytes, *mBuf);
         if (ret != ROK)
            RETVALUE (RFAILED);

         /* We must only attempt to decode SDP if there is a Content-Type 
          * header set to subtype == SDP. */
         ret = soCmFindHdrChoice(rxEvent, (U8 **)&contentType,
                                 SO_HEADER_ENT_CONTENTTYPE);
         if (ret == ROK)
         {
            if (SO_CMP_TKN_LIT(&contentType->subType.valueType,
                               SO_MEDIA_SUBTYPE_SDP) == TRUE)
            {
#ifndef CM_SDP_OPAQUE
              /*check if decSDP is TRUE, call soDecodeSDP to 
 *            decode SDP, otherwise, take it as string*/
               if (decSDP)
               {
                  ret = soDecodeSDP(&rxEvent->sipBody, *mBuf);
                  if (ret != ROK)
                  {
#ifdef DEBUGP
                     SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                                     "soSipDecodeReq: SDP failed to decode\n"));
#endif
                    /*---- so019.201: Update Error Statistics -----*/
                     entCb->errSts.sdpDecFail++;
                     soCb.sts.errSts.sdpDecFail++;
   
                     *sipError = SO_HDR_OK_BODY_NOK;
                     *message = (U8 *)rxEvent;
                     RETVALUE(ROK);
                  }
               }
               else
#endif /* CM_SDP_OPAQUE */
               {
                    ret = soSetSinglePartBuf(&rxEvent->sipBody, *mBuf);
                    if (ret != ROK)
                    {
                        *sipError = SO_HDR_OK_BODY_NOK;
                        *message = (U8 *)rxEvent;
                        RETVALUE(ROK);
                    }
                   /* Advance mBuf over decoded part */
                  /* so032.201: modified from msgLen to bodyLen for concatenated SIP messages */

                   ret = SRemPreMsgMult (NULLP, (MsgLen)(bodyLen), *mBuf);
                   if (ret != ROK)
                     RETVALUE (RFAILED);
               }
            }
            else
            {
               /* Accounting */
   
               if (SO_CMP_TKN_LIT(&contentType->type.valueType,
                                     SO_MEDIA_TYPE_MULTIPART) == TRUE)
               {
                  ret = soDecodeMultipart(rxEvent, contentType, mBuf, decSDP);
                  if (ret != ROK)
                  {
#ifdef DEBUGP
                     SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                                      "soSipDecodeReq: Multipart body failed to decode\n"));
#endif
                     *sipError = SO_HDR_OK_BODY_NOK;
                     *message = (U8 *)rxEvent;
                     RETVALUE(ROK);
                  }
                  else
                  {
                      /* Advance mBuf over decoded part */
                      SFndLenMsg (*mBuf, &msgLen);
                      ret = SRemPreMsgMult (NULLP, (MsgLen)(msgLen), *mBuf);
                      if (ret != ROK)
                        RETVALUE (RFAILED);

                  }
               }
               else
               {
               /* so020.201: Passing bodyLen so that only required bytes
                *            are deteted from mBuf */
                  ret = soSetSingleBodyPartBuf (&rxEvent->sipBody, bodyLen, mBuf);
                  if (ret != ROK)
                  {
                      *sipError = SO_HDR_OK_BODY_NOK;
                      *message = (U8 *)rxEvent;
                      RETVALUE(ROK);
                  }
               }
            }
         }
      } /* End of if (decode body) */

      else
      {
         if (msgLen > tmpLen)
            ret = SRemPreMsgMult(NULLP, (MsgLen)(numSipBytes), *mBuf);
         else   
            /* Advance mbuf over decoded part */
            ret = SRemPreMsgMult(NULLP, (MsgLen)(numSipBytes), *mBuf);

         if (ret != ROK)
           RETVALUE (RFAILED);
      }

      *sipError = SO_HDR_OK_BODY_OK;
      *message = (U8 *)rxEvent;

#ifdef SO_CALEA
     /*----------- Copy the SIP Message as RAW Message ------------*/
      if (totalMsgLen < totalLen)
      {
#ifdef DEBUGP
         SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                   "soSipDecodeReq: RAW MSG: Removing Rest Of Bytes \n"));
#endif
         ret = SRemPstMsgMult (NULLP, 
                              (MsgLen)(totalLen - totalMsgLen),
                               rxEvent->rawMsg);
         if (ret != ROK)
           RETVALUE (RFAILED);
      }
#endif

      RETVALUE(ROK);
   }

} /* soSipDecodeReq */


/*
*
*       Fun:   soPrcRcvdDataFromABNF
*
*       Desc:  Processing Data after receving confirmation from ABNF
*
*       Ret:   Nothing
*
*       Notes: ROK:     decoding sucess
*              RFAILED: decoding sucess for first TCP message but failure for
*                       second TCP message
*              RIGNORE: decoding error, returning error message to peer, no
*                       further action at this side
*
*       File:  so_ed.c
*
*/

#ifdef ANSI
PUBLIC S16   soPrcRcvdDataFromABNF
(
Buffer        **mBuf,          /* message Buffer                           */
SoEntCb       *entCb,         /* Entity Control Block                     */
SoTptServerCb *serverCb,      /* Server connection that received message  */
SoTptClientCb *clientCb,      /* Client connection (For TCP Only)         */
CmTptAddr     *srcAddr,       /* Source IP address                        */
U8            *msg,           /* Pointer to soEvent Structure         */
U16           soErr           /* error                                    */
)
#else
PUBLIC S16   soPrcRcvdDataFromABNF(mBuf, entCb,serverCb,clientCb,srcAddr,msg, soErr)
Buffer        **mBuf;          /* message control Block                    */
SoEntCb       *entCb;         /* Entity Control Block                     */
SoTptServerCb *serverCb;      /* Server connection that received message  */
SoTptClientCb *clientCb;      /* Client connection (For TCP Only)         */
CmTptAddr     *srcAddr;       /* Source IP address                        */
U8            *msg;           /* Pointer to soEvent Structure         */
U16           soErr;          /* error */
#endif
{
   S16         ret;          /* value returned by function calls      */
   S16         sndErrMsg;    /* Send error response                   */
   SoEvnt      *evnt;  

   TRC2(soPrcRcvdDataFromABNF);

   /* so012.201: Init send error response */
   sndErrMsg = FALSE;
   evnt = (SoEvnt *)msg;

   /* so012.201: Send error response only for Requests */
   if ((evnt != NULLP) &&
       (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST))
   {
      sndErrMsg = TRUE; 

      /* so012.201: Do not send response for ACK */
      if ((evnt->t.request.requestLine.pres.pres != NOTPRSNT) &&
          (evnt->t.request.requestLine.method.type.val == SO_METHOD_METHODSTD) &&
          (evnt->t.request.requestLine.method.t.std.val== SO_METHODSTD_ACK))
         sndErrMsg = FALSE;
   }

   switch(soErr)
   {
      case SO_HDR_OK_AFTER_TRUNC :
      case SO_MAND_HDR_MISS :
      case SO_HDR_OK_BODY_NOK :
         /* Ok it decoded, so we might be able to send an error back
            to the sender */

         /* so012.201: Send error response for Requests */
         if (sndErrMsg == TRUE)
            (Void) soTptReturnError(entCb,  clientCb, serverCb,
                                (SoEvnt *)msg, SOT_RSP_400_BAD_REQUEST);
         /* Free buffer - no longer needed */
         RETVALUE(RIGNORE);
      break;
      
      case SO_VERSION_NOT_SUPPORT :
         /* so012.201: Send error response for Requests */
         if (sndErrMsg == TRUE)
            (Void) soTptReturnError(entCb,  clientCb, serverCb,
                                 (SoEvnt *)msg, SOT_RSP_505_VERSION_UNSUPPORTED);
         RETVALUE(RIGNORE);
      break;
      
      case SO_HDR_OK_BODY_INCMP :
         if (clientCb && clientCb->serverCb->tptProt == LSO_TPTPROT_TCP) /* TPTPROT */
         {
            /* Whole body not present - message incomplete. */
            /* so036.201: returning anything other that ROK means *
               calling function will deallocate event structure   */
            /* Do nothing */
         }
         else
         {
            /* Free buffer - no longer needed */
            /* Ok it decoded, so we might be able to send 
             * an error back to the sender */

            /* so012.201: Send error response for Requests */
            if (sndErrMsg == TRUE)
               (Void) soTptReturnError(entCb, clientCb, serverCb,
                                   (SoEvnt *)msg, SOT_RSP_400_BAD_REQUEST);
         }
         RETVALUE(RIGNORE);
      break;
      case SO_HDR_OK_BODY_OK : /*no error*/
         break;
      default:
         /* Free buffer - no longer needed */
         /* so036.201: returning anything other that ROK means *
            calling function will deallocate event structure   */
         RETVALUE(RIGNORE);
      break;
   }
     
   ret = soCmSetEvntType((SoEvnt *)msg);
   if (ret != ROK)
   {
#ifdef DEBUGP
      SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                       "soPrcRcvdDataFromABNF: soCmSetEvntType failed.\n"));
#endif

      /* so012.201: Send error response for Requests */
      if (sndErrMsg == TRUE)
         (Void) soTptReturnError(entCb,  clientCb, serverCb, (SoEvnt *)msg, SOT_RSP_400_BAD_REQUEST);

      RETVALUE(RIGNORE);
   }

  /* Check if all the required mandatory headers are present */
  ret = soUtlChckMandHdrs((SoEvnt *)msg);

  if (ret != ROK)
  {
#ifdef DEBUGP
      SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                       "soPrcRcvdDataFromABNF:  Mandatory headers Missing\n"));
#endif
      if (sndErrMsg == TRUE)
         (Void) soTptReturnError(entCb,  clientCb, serverCb, (SoEvnt *)msg, SOT_RSP_400_BAD_REQUEST);

      RETVALUE(RIGNORE);
  }


   RETVALUE(ROK);
} /* end of soPrcRcvdDataFromABNF */


#ifdef __cplusplus
}
#endif /* __cplusplus */


/********************************************************************30**

         End of file:     so_ed.c@@/main/3 - Tue Apr 20 12:46:29 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision History:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/3      ---    MC      1. Initial release.
/main/3+    so012.201 up    2. Send error response for badly formed 
                               requests
/main/3+    so019.201 ps    1. Added enitityCb parameter in soSipDecodeReq
                            2. Update error statistics
/main/3+    so020.201 ss    1. Correctly decoding the body part of SIP
                               message.
/main/3+    so021.201 ad    1. Added missing compact form for Session 
                               Expires and REFER.                               
                      ps    2. Removed warning.
/main/4+    so032.201 ng    1. modified from msgLen to bodyLen for concatenated SIP messages
/main/4+    so033.201 ng    1. Fix for compilation error with  SO_ABNF_MT_LIB falg
/main/4+    so036.201 ng    1. Changes for SO_CALEA
/main/4+    so041.201 sm    1. Deleted the code adding an extra CRLF in soEncodeMultipart
*********************************************************************91*/
