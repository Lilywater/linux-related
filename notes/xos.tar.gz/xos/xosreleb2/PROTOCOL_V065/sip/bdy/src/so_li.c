/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SIP Lower Interface

     Type:    C source file

     Desc:    Transport Connection Manager lower interface primitives

     File:    so_li.c

     Sid:      so_li.c@@/main/6 - Tue Apr 20 14:19:02 2004

     Prg:     cl

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "cst.h"           /* Compression module defines      */
#include "so.h"            /* SIP layer defines               */
#include "so_trans.h"      /* Transaction module defines      */
#include "so_err.h"        /* SIP error defines               */
#include "so_cm.h"         /* SIP layer utility functions     */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lso.x"           /* Layer management SIP            */
#include "sot.x"           /* SOT interface defines           */
#include "cst.x"           /* Compression module defines      */
#include "so_tcm.x"        /* Transport module structures     */
#include "so.x"            /* SIP layer structures            */
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* SIP layer utility functions     */
#include "so_cm.x"         /* SIP layer common functions      */
#include "so_dns.x"        /* SIP DNS library                 */


/* local function definition */


/*
*
*       Fun:   SoLiHitBndCfm
*
*       Desc:  Bind confirm
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to
*              ack the bind request from the service user.
*
*       File:  so_li.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitBndCfm
(
Pst   *pst,      /* post structure */
SuId  suId,      /* service user SAP identifier */
U8    status     /* bind status */
)
#else
PUBLIC S16 SoLiHitBndCfm(pst, suId, status)
Pst   *pst;      /* post structure */
SuId  suId;      /* service user SAP identifier */
U8    status;    /* bind status */
#endif
{
   S16          retVal;         /* return value */
   SoTSapCb     *tsapCb;        /* Control block */

   TRC3(SoLiHitBndCfm)

   SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,
              "SoLiHitBndCfm(pst, suId(%d), status(%d)\n", suId, status));

   UNUSED(pst);

   if (soCb.init.cfgDone != TRUE)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO098, (ErrVal) suId,
                 "SoLiHitBndCfm: General configuration not done");
#endif

      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_BNDCFM,
                   LCM_CAUSE_INV_STATE, LSO_PAR_SAP, (Ptr )&suId);

      RETVALUE(RFAILED);
   }

   if (soCb.soTSapCbLst[suId] == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO099, (ErrVal) suId,
                 "SoLiHitBndCfm: : Invalid suId");
#endif /* ERRCLASS & ERRCLS_INT_PAR */

      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_BNDCFM,
                   LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr) &suId);

      RETVALUE(RFAILED);
   }


   tsapCb = soCb.soTSapCbLst[suId];

   switch (tsapCb->state)
   {
      case LSO_TSAP_UBNDDIS: /* fall through */
      case LSO_TSAP_BNDENA:  /* fall through */
      case LSO_TSAP_BNDDIS:
         /* Spurious - log & ignore */
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO100, (ErrVal) tsapCb->state,
            "SoLiHitBndCfm: Invalid TSAP state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         break;

      case LSO_TSAP_WAIT_BNDENA:
         if (tsapCb->reCfg.bndTmCfg.enb == TRUE)
         {
            /* Stop timer */
            retVal = soSchedTmr(tsapCb,
               SO_TMR_TCM_BND, TMR_STOP, NOTUSED);
#if (ERRCLASS & ERRCLS_DEBUG)
            if (retVal != ROK)
            {
               SOLOGERROR(ERRCLS_DEBUG, ESO101, (ErrVal) retVal,
                       "SoLiHitBndCfm: timer stop failed\n");
            }
#endif /* ERRCLASS & ERRCLS_DEBUG */
         }
         /* Check status of bind cfm */
         if (status == CM_BND_OK)
         {
            /* Bind successful */
            tsapCb->state = LSO_TSAP_BNDENA;

            soGenStaInd(STTSAP, LCM_CATEGORY_INTERNAL, LCM_EVENT_BND_OK,
                        LSO_CAUSE_SAP_BNDENA, LSO_PAR_SAP, (Ptr) &suId);
            soSendLmCntrlCfm(&tsapCb->cfmPst,
               LCM_PRIM_OK, LCM_REASON_NOT_APPL,
               &tsapCb->ctrlHdr);
            soTptProcessTsapServers(tsapCb, SO_TCM_TPTSRV_OPEN);
         }
         else
         {
            /* Bind failed */
            tsapCb->state = LSO_TSAP_UBNDDIS;
            soSendLmCntrlCfm(&tsapCb->cfmPst,
               LCM_PRIM_NOK, LCM_REASON_NOT_APPL,
               &tsapCb->ctrlHdr);
         }
         break;

      case LSO_TSAP_WAIT_BNDDIS:
         retVal = soSchedTmr(tsapCb,
            SO_TMR_TCM_BND, TMR_STOP, NOTUSED);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (retVal != ROK)
         {
            SOLOGERROR(ERRCLS_DEBUG, ESO102, (ErrVal) retVal,
                       "SoLiHitBndCfm: timer stop failed\n");
         }
#endif /* ERRCLASS & ERRCLS_DEBUG */
         /* Check status of bind cfm */
         if (status == CM_BND_OK)
         {
            /* Bind successful */
            tsapCb->state = LSO_TSAP_BNDDIS;

            soGenStaInd(STTSAP, LCM_CATEGORY_INTERNAL, LCM_EVENT_BND_OK,
                        LSO_CAUSE_SAP_BNDDIS, LSO_PAR_SAP, (Ptr) &suId);

            soSendLmCntrlCfm(&tsapCb->cfmPst,
               LCM_PRIM_OK, LCM_REASON_NOT_APPL,
               &tsapCb->ctrlHdr);
         }
         else
         {
            /* Bind failed */
            tsapCb->state = LSO_TSAP_UBNDDIS;
            soSendLmCntrlCfm(&tsapCb->cfmPst,
               LCM_PRIM_NOK, LCM_REASON_NOT_APPL,
               &tsapCb->ctrlHdr);
         }
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO103, (ErrVal) tsapCb->state,
            "SoLiHitBndCfm: Invalid TSAP state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         soSendLmCntrlCfm(&tsapCb->cfmPst,
            LCM_PRIM_NOK, LCM_REASON_INVALID_STATE,
            &tsapCb->ctrlHdr);
         RETVALUE(RFAILED);
         break;
   }

   RETVALUE(ROK);
} /* end of SoLiHitBndCfm */


/*
*
*       Fun:   SoLiHitConCfm
*
*       Desc:  Connect confirm
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to
*              ack the HitServOpenReq or HitConReq primitives.
*
*       File:  so_li.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitConCfm
(
Pst             *pst,              /* post structure */
SuId            suId,              /* service user SAP identifier */
UConnId         suConnId,          /* service user connection id */
UConnId         spConnId,          /* service provider connection id */
CmTptAddr       *localAddr         /* local transport address */
)
#else
PUBLIC S16 SoLiHitConCfm(pst, suId, suConnId, spConnId, localAddr)
Pst             *pst;              /* post structure */
SuId            suId;              /* service user SAP identifier */
UConnId         suConnId;          /* service user connection id */
UConnId         spConnId;          /* service provider connection id */
CmTptAddr       *localAddr;        /* local transport address */
#endif
{
   SoTptClientCb  *clientCb;      /* common tpt connection control block */
   SoTptServerCb  *serverCb;            /* server control block */
   U8             sockType;          /* type of socket */
   U8             tptState;          /* transport state */
   S16            retVal;

   TRC3(SoLiHitConCfm)

   clientCb = NULLP;
   serverCb       = NULLP;
   sockType    = SO_SOCK_NONE;

#ifdef DEBUGP
   {
      U16   port;
      Txt   addr[2 * CM_IPV6ADDR_SIZE + 1];

      soCmGetPortAndAscAddr (localAddr, &port, addr);

      SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,
                 "SoLiHitConCfm(pst, suId(%d), suConnId(%ld), spConnId(%ld),"
                 "localAddr.type(%d), localAddr.port(%d), localAddr.address(%s))\n",
                 suId, suConnId, spConnId, localAddr->type, port, addr));
   }
#endif

   UNUSED(pst);


   if (soCb.soTSapCbLst == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO104, (ErrVal) suId,
                 "SoLiHitConCfm: : Invalid suId - no tsapCb list");
#endif

      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_CONCFM,
                   LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr) &suId);

      RETVALUE(RFAILED);
   }


   if (soCb.soTSapCbLst[suId] == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO105, (ErrVal) suId,
                 "SoLiHitConCfm: : Invalid suId");
#endif

      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_CONCFM,
                   LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr) &suId);

      RETVALUE(RFAILED);
   }

   if (localAddr == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO106, (ErrVal) ERRZERO,
                 "SoLiHitConCfm: Invalid parameter");
#endif

      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_CONCFM,
                   LCM_CAUSE_INV_PAR_VAL, LSO_PAR_SAP, (Ptr) &suId);

      RETVALUE(RFAILED);
   }


   if(soCb.soTSapCbLst[suId]->state != LSO_TSAP_BNDENA)
      RETVALUE(RFAILED);

   tptState = LSO_TPTSRV_DIS;


   /* Is this the cfm one gets from an open server or a connection req*/
   if (suConnId < soCb.maxTptSrv)
   {
      serverCb = soCb.allSrvCbLst[suConnId];
      if(serverCb == NULLP)
         RETVALUE(RFAILED);

      tptState = serverCb->state;
      sockType = SO_SOCK_SRV;

      /* so010.201, so035.201: Fix to guard opening of transport  *
       *    server with a timer.                                  *
       *                                                          *
       * (1): Stop the gaurd timer used for server retry          *
       * (2): Reset the retry count to initial value              */

      if (serverCb->opnSrvTmr.enb == TRUE)
      {
         serverCb->opnSrvCurRetryCnt = serverCb->opnSrvRetryCnt ;

         retVal = soSchedTmr(serverCb, SO_TMR_TCM_OPEN_SRV,
                             TMR_STOP, NOTUSED);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (retVal != ROK)
         {
            SOLOGERROR(ERRCLS_DEBUG, ESO108, (ErrVal) retVal,
                       "SoLiHitConCfm: timer stop failed\n");
         }
#endif
      }
   }
   else if((clientCb =
            soTptCheckClientCb (suId, HI_USER_CON_ID, suConnId)) != NULLP)
   {
      tptState = clientCb->state;
      sockType = SO_SOCK_CLNT;
   }

   switch (tptState)
   {
      case LSO_TPTSRV_DIS:
         /*
          * our earlier DiscReq might have got lost or crossed or this
          * ConCfm is spurious
          */
         soTptIssueDiscReq (soCb.soTSapCbLst[suId],
                            HI_PROVIDER_CON_ID,
                            spConnId,
                            SO_SOCK_NONE);
         RETVALUE(RFAILED);

      case LSO_TPTSRV_ENA:

#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO107, (ErrVal) suConnId,
                    "SoLiHitConCfm: Received HitConCfm in CONNECTED tptState ");
#endif
         RETVALUE(RFAILED);

      case LSO_TPTSRV_WAIT_ENA:

         if (sockType == SO_SOCK_SRV)
         {
            /* Indicate new open server to LMI */
            soMiTptSrvOpenInd(serverCb);
            /* update the control block with the new state etc.*/
            serverCb->state    = LSO_TPTSRV_ENA;
            serverCb->spConnId = spConnId;

         }
         else
         {
             /* stop connection timer */
             retVal = soSchedTmr(clientCb, SO_TMR_TCM_CONNECTION,
                                 TMR_STOP, NOTUSED);
#if (ERRCLASS & ERRCLS_DEBUG)
            if (retVal != ROK)
            {
               SOLOGERROR(ERRCLS_DEBUG, ESO108, (ErrVal) retVal,
                          "SoLiHitConCfm: timer stop failed\n");
            }
#endif

            /* update the control block with the new state etc.*/
            (Void) soTptProcHitConCfm (suId, spConnId, clientCb, localAddr);
         }
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO109, (ErrVal) tptState,
                    "SoLiHitConCfm: Invalid tptState in control block");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of SoLiHitConCfm */



/*
*
*       Fun:   SoLiHitConInd
*
*       Desc:  Connection indication
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to
*              notify SIP of the incoming connection
*              SIP responds by issuing HitConRsp.
*
*       File:  so_li.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitConInd
(
Pst            *pst,          /* post structure */
SuId           suId,          /* service user SAP identifier */
UConnId        srvSuConnId,   /* service user server connection id */
UConnId        spConnId,      /* service provider connection identifier */
CmTptAddr      *peerAddr      /* transport address */
)
#else
PUBLIC S16 SoLiHitConInd(pst, suId, srvSuConnId, spConnId, peerAddr)
Pst            *pst;          /* post structure */
SuId           suId;          /* service user SAP identifier */
UConnId        srvSuConnId;   /* service user server connection id */
UConnId        spConnId;      /* service provider connection identifier */
CmTptAddr      *peerAddr;     /* transport address */
#endif
{
   SoTSapCb       *tsapCb;       /* TSAP control block */
   SoTptServerCb  *serverCb;     /* transport server control block */
   SoTptClientCb  *clientCb;    /* transport connection control block */
   S16            retVal;        /* return value */

   TRC3(SoLiHitConInd);

   UNUSED(pst);

#ifdef DEBUGP
   {
      U16   port;
      Txt   addr[2 * CM_IPV6ADDR_SIZE + 1];

      soCmGetPortAndAscAddr (peerAddr, &port, addr);

      SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,
         "SoLiHitConInd(pst, suId(%d), srvSuConnId(%ld), spConnId(%ld),"
         "peerAddr.type(%d), peerAddr.port(%d), peerAddr.address(%s))\n",
         suId, srvSuConnId, spConnId, peerAddr->type, port, addr));
   }
#endif

   if (suId >= soCb.cfg.maxNmbTSaps)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO110, (ErrVal) suId,
                 "SoLiHitConInd: : Invalid suId");
#endif
      
      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_CONIND,
                   LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr) &suId);
      RETVALUE(RFAILED);
   }

   if (soCb.soTSapCbLst[suId] == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO111, (ErrVal) suId,
                 "SoLiHitConInd: : Invalid suId");
#endif

      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_CONIND,
                   LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr) &suId);
      RETVALUE(RFAILED);
   }

   if (srvSuConnId >= soCb.maxTptSrv)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO112, (ErrVal) srvSuConnId,
                 "SoLiHitConInd: : Invalid srvSuConnId");
#endif
      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_CONIND,
                   LCM_CAUSE_INV_SUID, LSO_PAR_CONNID, (Ptr) &srvSuConnId);
      RETVALUE(RFAILED);
   }


   if (peerAddr == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO113, (ErrVal) ERRZERO,
                 "SoLiHitConInd: Invalid peerAddr passed");
#endif

      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_CONIND,
                   LCM_CAUSE_INV_PAR_VAL, LSO_PAR_SAP, (Ptr) &suId);

      RETVALUE(RFAILED);
   }

   tsapCb = soCb.soTSapCbLst[suId];

   if(tsapCb->state != LSO_TSAP_BNDENA)
      RETVALUE(RFAILED);

   serverCb = soCb.allSrvCbLst[srvSuConnId];

   if ((serverCb == NULLP) || (serverCb->state != LSO_TPTSRV_ENA))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      if (serverCb == NULLP)
      {
         SOLOGERROR(ERRCLS_DEBUG, ESO114, (ErrVal) 0,
                    "SoLiHitConInd: Invalid event received (NULL serverCb)");
      }
      else
      {
         SOLOGERROR(ERRCLS_DEBUG, ESO115, (ErrVal) serverCb->state,
                    "SoLiHitConInd: Invalid event received");
      }
#endif
      soTptIssueDiscReq (tsapCb, HI_PROVIDER_CON_ID, spConnId, SO_SOCK_CLNT);

      RETVALUE(RFAILED);
   }

   /*------- Allocate client control block (CCB) ---------*/
   if (soTptAllocClientCb (tsapCb, &serverCb->localAddr, peerAddr, &clientCb) != ROK)
   {
      soTptIssueDiscReq (tsapCb, HI_PROVIDER_CON_ID, spConnId, SO_SOCK_CLNT);
      RETVALUE(RFAILED);
   }

   /* This is connection indication, update state and spConnId */
   clientCb->state      = LSO_CLIENT_ENA;
   clientCb->spConnId   = spConnId;
   clientCb->retryCount = 0;
   clientCb->tsapCb     = tsapCb;
   clientCb->serverCb   = serverCb;

   soTptIdleTmr (clientCb, TMR_START);

   /*-- Insert CCB into tsap's suConnId based hash list --*/
   retVal = cmHashListInsert (&tsapCb->suConnIdHlCp, (PTR) clientCb,
                              (U8 *)&clientCb->suConnId,
                              sizeof (ConnId));
   if (retVal != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO116, (ErrVal) retVal,
                 "SoLiHitConInd: Hashlist insertion failed\n");
#endif
      
      SOFREE (clientCb, sizeof (SoTptClientCb));

      soTptIssueDiscReq (tsapCb, HI_PROVIDER_CON_ID, spConnId, SO_SOCK_CLNT);

      RETVALUE(RFAILED);
   }

   /*-- Insert CCB in tsap's remote addr based hash list -*/

   SO_TCM_ZERO_BASED_ADDR (&clientCb->remoteAddr);

   retVal = cmHashListInsert (&tsapCb->tptAddrHlCp,
                              (PTR ) clientCb,
                              (U8 *)&clientCb->remoteAddr,
                              sizeof (CmTptAddr));
   if (retVal != ROK)
   {
      SOLOGERROR (ERRCLS_DEBUG, ESO117, (ErrVal) 0,
         "SoLiHitConInd: cmHashListInsert tptAddr failed\n");

      cmHashListDelete (&tsapCb->suConnIdHlCp, (PTR)clientCb);
      SOFREE (clientCb, sizeof (SoTptClientCb));

      soTptIssueDiscReq (tsapCb, HI_PROVIDER_CON_ID, spConnId, SO_SOCK_CLNT);
      RETVALUE(RFAILED);
   }

   (Void) SoLiHitConRsp (&tsapCb->liPst,
                         clientCb->tsapCb->cfg.spId,
                         clientCb->suConnId,
                         clientCb->spConnId);

   RETVALUE(ROK);

} /* end of SoLiHitConInd */


/*
*
*       Fun:   SoLiHitDiscInd
*
*       Desc:  Disconnect indication
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to
*              indicate that the client or server connection is down
*
*       File:  so_li.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitDiscInd
(
Pst           *pst,        /* post structure */
SuId          suId,        /* service user SAP identifier */
U8            choice,      /* type of connection identifier */
UConnId       connId,      /* connection identifier suConnId or spConnId */
Reason        reason       /* disconnect reason */
)
#else
PUBLIC S16 SoLiHitDiscInd(pst, suId, choice, connId, reason)
Pst           *pst;        /* post structure */
SuId          suId;        /* service user SAP identifier */
U8            choice;      /* type of connection identifier */
UConnId       connId;      /* connection identifier suConnId or spConnId */
Reason        reason;      /* disconnect reason */
#endif
{
   SoTSapCb       *tsapCb;    /* TSAP control block */
   SoTptClientCb  *clientCb;    /* transport connection control block */
   SoTptServerCb  *serverCb;  /* server control block */
   State          prevState;  /* Current Server state                 */
  /*--- so022.201: The local variable is no longer required ---*/

   TRC3(SoLiHitDiscInd);

   SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,
      "SoLiHitDiscInd(pst, suId(%d), choice(%d), connId(%ld),"
      "reason(%d)\n", suId, choice, connId, reason));

   UNUSED(pst);


   if (suId >= soCb.cfg.maxNmbTSaps)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO118, (ErrVal) suId,
                 "SoLiHitDiscInd: : Invalid suId");
#endif /* ERRCLASS & ERRCLS_INT_PAR */

      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_DISCIND,
                   LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr) &suId);
      RETVALUE(RFAILED);
   }

   if (soCb.soTSapCbLst[suId] == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO119, (ErrVal) suId,
                 "SoLiHitDiscInd: : Invalid suId");
#endif /* ERRCLASS & ERRCLS_INT_PAR */

      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_CONIND,
                   LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr) &suId);

      RETVALUE(RFAILED);
   }

   if (choice != HI_PROVIDER_CON_ID && choice != HI_USER_CON_ID)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO120, (ErrVal) choice,
                 "SoLiHitDiscInd: Invalid choice value");
#endif /* ERRCLASS & ERRCLS_INT_PAR */

      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_DISCIND,
                   LCM_CAUSE_INV_PAR_VAL, LSO_PAR_CONNID, (Ptr) &choice);

      RETVALUE(RFAILED);
   }

   tsapCb = soCb.soTSapCbLst[suId];

   if(tsapCb->state != LSO_TSAP_BNDENA)
      RETVALUE(RFAILED);
   /*
    * Assumption being TUCL never comes back with PROVIDER_CON_ID
    * for server connections. Otherwise, soTptCheckClientCb has to
    * be changed a little.
    */
   if (connId < soCb.maxTptSrv)
   {
      serverCb = soCb.allSrvCbLst[connId];
   }
   else
   {
      serverCb = NULLP;
   }

   if ((choice == HI_USER_CON_ID) && (serverCb != NULLP))
   {
      /* this is a server connection */
      if (serverCb->state == LSO_TPTSRV_DIS)
         RETVALUE(RFAILED);

      /* so035.201: Reset the server state to disconnected and    *
       *   inform any users of the server.                        */

      prevState       = serverCb->state; /* Saving current state  */
      serverCb->state = LSO_TPTSRV_DIS;

      (Void) soTptDelAllServerContext (serverCb, TRUE);

      /* so032.201, so035.201: If server open retry feature is NOT *
       *   enabled, simply inform the event to LM. LM should       *
       *   initiate control request primitive to reopen the server */
       if (serverCb->opnSrvTmr.enb == FALSE)
           soMiTptSrvCloseInd (serverCb, FALSE);
        
      /* so010.201, so021.201, so035.201: If the server retry      *
       *   feature is enabled, then try to open the server again   *
       *   if retry count permits.                                 */
  
      /* CASE 1: If the server open sequence is pending, i.e,      *
       * DiscInd() is received after issuing ServOpenReq() to open *
       * server connection, then server open gaurd timer MUSt also *
       * be running. Server open retry will be attempted when the  *
       * timer expires. We don't have to do anything here.         */

      /* CASE 2: If the server open sequence is NOT pending, i.e,  *
       * DiscInd() is received when server is already in connected *
       * state, then we need to initiate opening of the server.    */
    
      /* Fix to guard opening of tpt srv with a timer              */

       else   /* Server Open Retry Is Enabled                      */
       { 
           if (prevState != LSO_TPTSRV_WAIT_ENA) /* Case 2 Above   */
           {
                RETVALUE (soTptOpenServer (serverCb));
           }
       }

      RETVALUE(ROK);
   }

   if ((clientCb = soTptCheckClientCb (suId, choice, connId)) != (SoTptClientCb *) NULLP)
   {
      switch (clientCb->state)
      {
         case LSO_CLIENT_DIS:
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO121, (ErrVal) connId,
                       "SoLiHitDiscInd: Received HitDiscInd in NULL tptState ");
#endif
            RETVALUE(RFAILED);

         case LSO_CLIENT_WAIT_ENA:
         /* retry a number of times before declaring the connection dead. */
            if (clientCb->retryCount > SOTMR_MAX_CONNECTION_RETRY)
            {
               clientCb->state = LSO_CLIENT_DIS;
               
               soTptFreeClient (clientCb, TRUE);
            }
            else
            {
               clientCb->retryCount++;
               /* so038.201: Added to check for UDP prior tranport */
               /* so041.201 : Added to check for TLS transoprt*/
               SoLiHitConReq(&tsapCb->liPst,
                             clientCb->tsapCb->cfg.spId,
                             clientCb->suConnId,
                             &clientCb->remoteAddr,
                             &clientCb->localAddr,
                             &tsapCb->reCfg.tPar,
                             (U8)(clientCb->serverCb->tptProt == LSO_TPTPROT_UDP ?
                                HI_SRVC_UDP : 
                                (clientCb->serverCb->tptProt == LSO_TPTPROT_UDP_PRIOR ? 
                                HI_SRVC_UDP_PRIOR : 
                                clientCb->serverCb->tptProt == LSO_TPTPROT_TLS_TCP ?  HI_SRVC_TLS:
                                HI_SRVC_TCP
                                )));
            }
            break;

         case LSO_CLIENT_ENA:

            clientCb->state = LSO_CLIENT_DIS;

            /* stop call signalling idle timer if it is running */
            /* so007.201: Timers Are Stopped In Delete Function */
            /* so021.201: Removing code to check return value   */

            soTptFreeClient (clientCb, TRUE);
            break;

         default:
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO123, (ErrVal) clientCb->state,
                       "SoLiHitConCfm: Invalid tptState in control block");
#endif
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /* end of SoLiHitDiscInd */


/*
*
*       Fun:   SoLiHitDatInd
*
*       Desc:  Data indication
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to
*              forward received data (TCP) to SIP
*
*       File:  so_li.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitDatInd
(
Pst     *pst,        /* post structure */
SuId    suId,        /* service user SAP identifier */
UConnId suConnId,    /* service user connection identifier */
Buffer  *mBuf        /* message buffer */
)
#else
PUBLIC S16 SoLiHitDatInd(pst, suId, suConnId, mBuf)
Pst     *pst;        /* post structure */
SuId    suId;        /* service user SAP identifier */
UConnId suConnId;    /* service user connection identifier */
Buffer  *mBuf;       /* message buffer */
#endif
{
#ifdef SO_COMPRESS
   SoCompContext  compContext;
#endif
   SoTptClientCb  *clientCb;     /* transport connection control block */
   MsgLen         len;         /* message length */

   TRC3(SoLiHitDatInd)

   SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,
              "SoLiHitDatInd(pst, suId(%d), suConnId(%ld), mBuf(%p)\n",
              suId, suConnId, (Void *)mBuf));

#ifdef DEBUGP
   if (soCb.init.dbgMask & SO_DBGMASK_LI_MBUF)
   {
      SPrntMsg (mBuf, 0, 0);
   }
#endif

   UNUSED(pst);

   if ((suId >= soCb.cfg.maxNmbTSaps) || (suId < 0))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO124, (ErrVal) suId,
                 "SoLiHitDatInd: : Invalid suId");
#endif
      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_DATIND,
                   LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr) &suId);
      RETVALUE(RFAILED);
   }

   if (soCb.soTSapCbLst[suId] == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO125, (ErrVal) suId,
                 "SoLiHitDatInd: : Invalid suId");
#endif
      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_DATIND,
                   LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr )&suId);
      RETVALUE(RFAILED);
   }


   if (mBuf == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO126, (ErrVal) ERRZERO,
                 "SoLiHitDatInd: Invalid mBuf passed");
#endif
      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_DATIND,
                   LCM_CAUSE_INV_PAR_VAL, LSO_PAR_SAP, (Ptr) &suId);
      RETVALUE(RFAILED);
   }

   if(soCb.soTSapCbLst[suId]->state != LSO_TSAP_BNDENA)
         RETVALUE(RFAILED);

   if ((clientCb = soTptCheckClientCb (suId, HI_USER_CON_ID, suConnId)) 
                                             == (SoTptClientCb *)NULLP)
   {
      SPutMsg (mBuf);
      soTptIssueDiscReq (soCb.soTSapCbLst[suId],
                         HI_USER_CON_ID, suConnId, SO_SOCK_CLNT);
   }
   else
   {
      if (clientCb->state != LSO_CLIENT_ENA)
      {
         (Void) SPutMsg(mBuf);
         RETVALUE(RFAILED);
      }

      (Void) SFndLenMsg (mBuf, &len);
      soCb.soTSapCbLst[suId]->sts.bytesRx += len;

     /* restart the idle timer */
     soTptIdleTmr(clientCb, TMR_RESTART);

     soGenTrcInd(STTSAP, suId,
        NOTUSED, LSO_TRC_EVENT_RX, mBuf);

#ifdef SO_UA
#ifdef SO_COMPRESS
     /*
      * Before providing data to transport module, perform SIP sign-
      * aling decompression (if configured to do so).
      * NOTE: Data will be provided to transport module, ones decom-
      *       pressor module returns success (in fn SoLiCstDecompre-
      *       ssCfm)
      */
     if ((clientCb->serverCb->entCb->entityType == LSO_ENT_UA) &&
         (clientCb->serverCb->entCb->s.ua.reCfg.sigCompSupp))
     {
       /*------------- Save The Context Of clientCb --------------*/
        compContext.choice          = SO_COMP_CONTEXT_CLIENT;
        compContext.t.client.connId = clientCb->suConnId;
        cmMemcpy ((U8 *)&compContext.t.client.peerAddr,
                  (U8 *)&clientCb->remoteAddr,
                  sizeof (CmTptAddr)); 

        compContext.tSapId  = suId;

       /*---- Finally, send the message to Decompressor module ---*/

        SoLiCstDecompressReq (&soCb.cfg.compPst,/* Decompressor Module's Id */
                              mBuf,             /* Msg To Be Decompressed   */
                              (Ptr)&compContext);/*Context To Be Returned
                                                   by Decompressor Module   */
     }  /* End of if (Decompression required) */

     else
#endif
#endif
     {
       /*----- Send the received message to transport module -----*/
        (Void) soTptGetMsg (clientCb->serverCb->entCb,
                            clientCb->serverCb,
                            clientCb,
                           &clientCb->remoteAddr,
                            mBuf);
     }  /* End of else (No decompression required) */
   }

   RETVALUE(ROK);
} /* end of SoLiHitDatInd */


/*
*
*       Fun:   SoLiHitUDatInd
*
*       Desc:  Unit data indication
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to
*              forward received datagram (UDP) to SIP
*
*       File:  so_li.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitUDatInd
(
Pst            *pst,        /* post structure */
SuId           suId,        /* service user SAP identifier */
UConnId        suConnId,    /* service user server connection identifier */
CmTptAddr      *srcAddr,    /* transport address */
CmTptAddr      *remAddr,    /* transport address */
CmIpHdrParm    *ipHdrParm,
Buffer         *mBuf        /* message buffer */
)
#else
PUBLIC S16 SoLiHitUDatInd(pst, suId, suConnId, srcAddr, remAddr, ipHdrParm, mBuf)
Pst            *pst;        /* post structure */
SuId           suId;        /* service user SAP identifier */
UConnId        suConnId;    /* service user connection identifier */
CmTptAddr      *srcAddr;    /* transport address */
CmTptAddr      *remAddr;    /* transport address */
CmIpHdrParm    *ipHdrParm;
Buffer         *mBuf;       /* message buffer */
#endif
{
   SoTptServerCb  *serverCb;
   SoTptClientCb  *clientCb;
   MsgLen         len;
   SoTSapCb       *tsapCb;
#ifdef SO_COMPRESS
   SoCompContext  compContext;
#endif

   TRC3(SoLiHitUDatInd);

#ifdef DEBUGP
   {
      U16   port;
      Txt   addr[2 * CM_IPV6ADDR_SIZE + 1];

      soCmGetPortAndAscAddr (srcAddr, &port, addr);

      SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,
                 "SoLiHitUDatInd(pst, suId(%d), suConnId(%ld), "
                 "srcAddr.type(%d), srcAddr.port(%d), srcAddr.address(%s))\n",
                 suId, suConnId, srcAddr->type, port, addr));

      if (soCb.init.dbgMask & SO_DBGMASK_LI_MBUF)
         SPrntMsg (mBuf, 0, 0);
   }
#endif

   UNUSED(pst);

   if ((suId >= soCb.cfg.maxNmbTSaps) || (suId < 0))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO127, (ErrVal) suId,
                 "SoLiHitUDatInd: : Invalid suId");
#endif
      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_UDATIND,
                   LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr) &suId);
      if (mBuf)
         SPutMsg (mBuf);
      RETVALUE(RFAILED);
   }

   if (soCb.soTSapCbLst[suId] == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO128, (ErrVal) suId,
                 "SoLiHitUDatInd: : Invalid suId");
#endif
      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_UDATIND,
                   LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr) &suId);
      if (mBuf)
         SPutMsg (mBuf);

      RETVALUE(RFAILED);
   }

   if (srcAddr == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO129, (ErrVal) ERRZERO,
                 "SoLiHitUDatInd: Invalid srcAddr");
#endif
      if (mBuf)
         SPutMsg (mBuf);

      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_UDATIND,
                   LCM_CAUSE_INV_PAR_VAL, LSO_PAR_CONNID, (Ptr) &suConnId);
      RETVALUE(RFAILED);
   }

   if (mBuf == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO130, (ErrVal) ERRZERO,
                 "SoLiHitUDatInd: Invalid mBuf");
#endif
      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_UDATIND,
                   LCM_CAUSE_INV_PAR_VAL, LSO_PAR_SAP, (Ptr) &suId);
      RETVALUE(RFAILED);
   }

   tsapCb = soCb.soTSapCbLst[suId];

   if (tsapCb->state != LSO_TSAP_BNDENA)
   {
      (Void) SPutMsg (mBuf);
      RETVALUE(RFAILED);
   }


   /* Is it plain from unconnected server or from a connected udp socket */
   if (suConnId < soCb.maxTptSrv)
   {
      serverCb = soCb.allSrvCbLst[suConnId];
      if (serverCb == NULLP)
      {
         (Void) SPutMsg(mBuf);
         soTptIssueDiscReq (tsapCb, HI_USER_CON_ID, suConnId, SO_SOCK_SRV);
         RETVALUE(RFAILED);
      }
      if (serverCb->state != LSO_TPTSRV_ENA)
      {
         (Void) SPutMsg(mBuf);
         RETVALUE(RFAILED);
      }
      clientCb    = NULLP;
   }
   else
   {
      /* Not directly from listner, must be from a connection then */
      if ((clientCb = soTptCheckClientCb (suId,
                                          HI_USER_CON_ID,
                                          suConnId)) == NULLP)
      {
         SPutMsg (mBuf);
         soTptIssueDiscReq (soCb.soTSapCbLst[suId],
                            HI_USER_CON_ID, suConnId, SO_SOCK_CLNT);
         RETVALUE(RFAILED);
      }
      else
      {
         /* restart the idle timer */
         soTptIdleTmr(clientCb, TMR_RESTART);
         serverCb = clientCb->serverCb;
      }
   }

   (Void) SFndLenMsg (mBuf, &len);
   tsapCb->sts.bytesRx += len;

   soGenTrcInd(STTSAP, suId, NOTUSED, LSO_TRC_EVENT_RX, mBuf);

#ifdef SO_DNS 
   /* Answer to a dns request  */
    /* so038.201: replaced with macro to check for UDP transport */
   if ((SO_TCM_UDP_TRANSPORT(serverCb->tptProt )) &&
       (serverCb == soCb.dnsSrvCb))
   {
#ifdef DEBUGP   
      if(soCb.init.dbgMask & SO_DBGMASK_DNS)
      {
         SODBGP_SO(SO_DBGMASK_DNS, (soCb.init.prntBuf,
                   "\n--Incoming DNS response--\n"));
         SPrntMsg(mBuf,0,0);
      }      
#endif
      
      /* Call dns function to process message   */
      cmDnsPrcDnsRsp(soCb.dnsCb, srcAddr, mBuf);
      /* This will eventually call the registered receive function
           - soRcvDnsResponse */
      (Void) SPutMsg(mBuf);
   }

   else
#endif
   {
#ifdef SO_UA
#ifdef SO_COMPRESS
     /*
      * Before providing data to transport module, perform SIP sign-
      * aling decompression (if configured to do so).
      * NOTE: Data will be provided to transport module, ones decom-
      *       pressor module returns success (in fn SoLiCstDecompre-
      *       ssCfm)
      */
     if ((serverCb->entCb->entityType == LSO_ENT_UA) &&
         (serverCb->entCb->s.ua.reCfg.sigCompSupp))
     {
        if (clientCb)
        {
           /*----------- Save The Context Of clientCb ------------*/
            compContext.choice          = SO_COMP_CONTEXT_CLIENT;
            compContext.t.client.connId = clientCb->suConnId;
            cmMemcpy ((U8 *)&compContext.t.client.peerAddr,
                      (U8 *)srcAddr,
                      sizeof (CmTptAddr)); 
        }

        else
        {
           /*----------- Save The Context Of serverCb ------------*/
            compContext.choice          = SO_COMP_CONTEXT_SERVER;
            compContext.t.server.connId = serverCb->suConnId;
            cmMemcpy ((U8 *)&compContext.t.server.peerAddr, 
                      (U8 *)srcAddr,
                      sizeof (CmTptAddr)); 
        }

        compContext.tSapId  = suId;


       /*---- Finally, send the message to Decompressor module ---*/

        SoLiCstDecompressReq (&soCb.cfg.compPst,/* Decompressor Module's Id */
                              mBuf,             /* Msg To Be Decompressed   */
                              (Ptr)&compContext);/*Context To Be Returned
                                                   by Decompressor Module   */
     }  /* End of if (Decompression required) */

     else
#endif
#endif
     {
       /*----- Send the received message to transport module -----*/
        (Void) soTptGetMsg (serverCb->entCb,
                            serverCb,
                            clientCb, 
                            srcAddr,
                            mBuf); 
     }  /* End of else (No decompression required) */
   }

   RETVALUE(ROK);

} /* end of SoLiHitUDatInd */


/*
*
*       Fun:   SoLiHitDiscCfm
*
*       Desc:  Disconnect confirm
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to
*              confirm the disconnect request from SIP
*
*       File:  so_li.c
*
*/

/*----------- so029.201: SIP Layer should handle DiscCfm ---------*/
#ifdef ANSI
PUBLIC S16 SoLiHitDiscCfm
(
Pst     *pst,        /* post structure                                    */
SuId    suId,        /* service user SAP identifier                       */
U8      choice,      /* type of connection identifier                     */
UConnId connId,      /* connection identifier either suConnId or spConnId */
Action  action       /* action                                            */
)
#else
PUBLIC S16 SoLiHitDiscCfm(pst, suId, choice, connId, action)
Pst     *pst;        /* post structure                                    */
SuId    suId;        /* service user SAP identifier                       */
U8      choice;      /* type of connection identifier                     */
UConnId connId;      /* connection identifier either suConnId or spConnId */
Action  action;      /* action                                            */
#endif
{
   /*so031.201: To remove the warning*/

   SoTSapCb       *tsapCb;    /* TSAP control block                 */
   SoTptClientCb  *clientCb;  /* transport connection control block */
   SoTptServerCb  *serverCb;  /* server control block               */

   TRC3(SoLiHitDiscCfm);

   SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,
              "SoLiHitDiscCfm(pst, suId(%d), choice(%d), connId(%ld),"
              " action(%d)\n", suId, choice, connId, action));

   UNUSED (pst);

  /*------------- First, Validate Primitive Parameters -----------*/

   if (suId >= soCb.cfg.maxNmbTSaps)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR (ERRCLS_INT_PAR, ESO118, (ErrVal) suId,
                  "SoLiHitDiscCfm: : Invalid suId");
#endif
      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_DISCIND,
                   LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr) &suId);
      RETVALUE (RFAILED);
   }

   if (soCb.soTSapCbLst[suId] == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR (ERRCLS_INT_PAR, ESO119, (ErrVal) suId,
                 "SoLiHitDiscCfm: : Invalid suId");
#endif
      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_DISCIND,
                   LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr) &suId);

      RETVALUE (RFAILED);
   }

   if (choice != HI_PROVIDER_CON_ID && choice != HI_USER_CON_ID)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR (ERRCLS_INT_PAR, ESO120, (ErrVal) choice,
                 "SoLiHitDiscCfm: Invalid choice value");
#endif

      soGenStaInd (STTSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_HIT_DISCIND,
                   LCM_CAUSE_INV_PAR_VAL, LSO_PAR_CONNID, (Ptr) &choice);

      RETVALUE (RFAILED);
   }


  /*-------------------- Find the Transport SAP ------------------*/

   tsapCb = soCb.soTSapCbLst[suId];

   if ((tsapCb == NULLP) || (tsapCb->state != LSO_TSAP_BNDENA))
      RETVALUE (RFAILED);

  /*--- Find the client/server connection being disconnected -----*/

  /* It is assumed that TUCL never comes back with                *
   * PROVIDER_CON_ID for server connections. Otherwise,           *
   * soTptCheckClientCb has to be changed a little.               */
  
   if (connId < soCb.maxTptSrv)
      serverCb = soCb.allSrvCbLst[connId];
   else
      serverCb = NULLP;
   
   if ((choice == HI_USER_CON_ID) && (serverCb != NULLP))
   {
      /*------------- We found the server connection -------------*/
      if (serverCb->state == LSO_TPTSRV_DIS)
         RETVALUE (RFAILED);

      /*----------------- Reset Server State ---------------------*/
      serverCb->state = LSO_TPTSRV_DIS;

      (Void)soTptDelAllServerContext (serverCb, TRUE);

      /*  Send alarm to layer manager. When the condition is      *
       *  resolved, Layer manager should enable the server again. */
      soMiTptSrvCloseInd (serverCb, FALSE);

      RETVALUE (ROK);
   }

   if ((clientCb = soTptCheckClientCb (suId, choice, connId)) != (SoTptClientCb *) NULLP)
   {

      /*-------- Found Client connection being disconnected ------*/

      switch (clientCb->state)
      {
         case LSO_CLIENT_DIS:
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR (ERRCLS_DEBUG, ESO121, (ErrVal) connId,
                 "SoLiHitDiscCfm: Received HitDiscCfm in NULL tptState ");
#endif
            RETVALUE (RFAILED);

         case LSO_CLIENT_WAIT_ENA:
         
            /* Retry certain number of times before declaring the  *
             * connection dead.                                    */
            if (clientCb->retryCount > SOTMR_MAX_CONNECTION_RETRY)
            {
               clientCb->state = LSO_CLIENT_DIS;
               
               soTptFreeClient (clientCb, TRUE);
            }
            else
            {
               clientCb->retryCount ++;

               /* so038.201: replaced with macro to check for UDP transport */
               /* so041.201: Added UDP prior check conditiona & Changes for SIP TLS support */
               SoLiHitConReq (&tsapCb->liPst            ,
                              clientCb->tsapCb->cfg.spId,
                              clientCb->suConnId        ,
                              &clientCb->remoteAddr     ,
                              &clientCb->localAddr      ,
                              &serverCb->tPar           ,/* not sure about this. pls check */
                              (U8)(clientCb->serverCb->tptProt == LSO_TPTPROT_UDP ?
                              HI_SRVC_UDP : 
                              (clientCb->serverCb->tptProt == LSO_TPTPROT_UDP_PRIOR ? 
                              HI_SRVC_UDP_PRIOR : 
                              clientCb->serverCb->tptProt == LSO_TPTPROT_TLS_TCP ?  HI_SRVC_TLS:
                              HI_SRVC_TCP
                              )));
            }

            break;

         case LSO_CLIENT_ENA:

            clientCb->state = LSO_CLIENT_DIS;

            soTptFreeClient (clientCb, TRUE);

            break;

         default:
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO123, (ErrVal) clientCb->state,
                  "SoLiHitConCfm: Invalid tptState in control block");
#endif
            RETVALUE(RFAILED);
      }
   }

   RETVALUE (ROK);

} /* end of SoLiHitDiscCfm */


/*
*
*       Fun:   SoLiHitFlcInd
*
*       Desc:  Flow control indication
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This primitive is invoked by HIT service provider to
*              indicate SIP to start/stop flow control of data
*
*       File:  so_li.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitFlcInd
(
Pst     *pst,        /* post structure */
SuId    suId,        /* service user SAP identifier */
UConnId suConId,     /* service user connection Id */
Reason  reason       /* reason */
)
#else
PUBLIC S16 SoLiHitFlcInd(pst, suId, suConId, reason)
Pst     *pst;        /* post structure */
SuId    suId;        /* service user SAP identifier */
UConnId suConId;     /* service user connection Id */
Reason  reason;      /* reason */
#endif
{
   TRC3(SoLiHitFlcInd)

   SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,
              "SoLiHitFlcInd(pst, suId(%d), reason(%d)\n", suId, reason));

   /* This primitive is ignored in SIP */

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConId);
   UNUSED(reason);

   RETVALUE(ROK);
} /* end of SoLiHitFlcInd */



#ifdef SO_COMPRESS

/*----------- Inteface To Compressor/Decompressor Module -----------*/

/*
*
*       Fun:   SoLiCstCompressCfm
*
*       Desc:  Compressor Module Returning Success/Failure Of Compres-
*              sion
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: 
*
*       File:  so_li.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiCstCompressCfm
(
Pst    *pst,       /* post structure              */
Bool   success,    /* Compression Successful!     */
Buffer *compMsg,   /* Compressed Message(if compression was successful) */
Buffer *unCompMsg, /* Original Message(if compression was unsuccessful) */
Ptr    compContext /* Context provided in SoLiCstCompressReq function   */
)
#else
PUBLIC S16 SoLiCstCompressCfm (pst, success, compMsg, unCompMsg, compContext)
Pst    *pst;       /* post structure              */
Bool   success;    /* Compression Successful!     */
Buffer *compMsg;   /* Compressed Message(if compression was successful) */
Buffer *unCompMsg; /* Original Message(if compression was unsuccessful) */
Ptr    compContext; /* Context provided in SoLiCstCompressReq function   */
#endif
{
   SoTptClientCb  *clientCb;
   SoTptServerCb  *serverCb;
   CmTptAddr      *destAddr;
   SoCompContext  *connContext;

   TRC3 (SoLiCstCompressCfm)

   SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,
              "SoLiCstCompressCfm: Successful (%d) \n", success));

   UNUSED (pst);
   destAddr    = NULLP;
   clientCb    = NULLP;
   serverCb    = NULLP;
   connContext = (SoCompContext *)compContext;

   if (success)
   {
      if (compMsg == NULLP)
       /*------ Incorrect parameter passed. Drop the message ------*/
       goto SOLICSTCOMPRESSCFM;
   }

   else 
   {
     if (unCompMsg == NULLP)
       /*------ Incorrect parameter passed. Drop the message ------*/
       goto SOLICSTCOMPRESSCFM;
   }

   if (!(connContext))
       /*------ Incorrect parameter passed. Drop the message ------*/
       goto SOLICSTCOMPRESSCFM;

   if ((connContext->tSapId >= soCb.cfg.maxNmbTSaps) || 
       (connContext->tSapId < 0))
        /*------ Incorrect transport SAP Id. Drop the message ------*/
        goto SOLICSTCOMPRESSCFM;

   if ((soCb.soTSapCbLst[connContext->tSapId]        == NULLP)  ||
       (soCb.soTSapCbLst[connContext->tSapId]->state != LSO_TSAP_BNDENA))
        /*------ Incorrect transport SAP Id. Drop the message ------*/
        goto SOLICSTCOMPRESSCFM;

   if (connContext->choice == SO_COMP_CONTEXT_CLIENT)
   {
      clientCb = soTptCheckClientCb (connContext->tSapId,
                                     HI_USER_CON_ID,
                                     connContext->t.client.connId);
      if (clientCb == NULLP)
        /*--- Client Connection does not exist. Drop the message ---*/
        goto SOLICSTCOMPRESSCFM;

      serverCb = clientCb->serverCb;

      destAddr =  &connContext->t.client.peerAddr;
   }
   else
   {
      if (connContext->t.server.connId >= soCb.maxTptSrv)
        /*-- Incorrect Server Connection identifier.Drop message ---*/
        goto SOLICSTCOMPRESSCFM;

      serverCb =  soCb.allSrvCbLst[connContext->t.server.connId];
      if (serverCb == NULLP)
        /*--- Server Connection does not exist. Drop the message ---*/
        goto SOLICSTCOMPRESSCFM;

      destAddr =  &connContext->t.server.peerAddr;
   }


  /*-- If Compression is success, send compressed message to TUCL --*/
  if (success)
     soTptSendMsgToTUCL (serverCb, clientCb, destAddr, compMsg);

  /* 
   * If Compression is not success, send original uncompressed message
   * to TUCL
   */
  else
     soTptSendMsgToTUCL (serverCb, clientCb, destAddr, unCompMsg);

   RETVALUE (ROK);

SOLICSTCOMPRESSCFM:
   
  SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,
             "\nSoLiCstCompressCfm Error:  compMsg (%p),"
             "unCompMsg (%p) \n", (Void *)compMsg, (Void *)unCompMsg));

  if (compMsg)
    (Void) SPutMsg (compMsg);

  if (unCompMsg)
    (Void) SPutMsg (unCompMsg);

  RETVALUE (RFAILED);


} /* end of SoLiCstCompressCfm */


/*
*
*       Fun:   SoLiCstDecompressCfm
*
*       Desc:  DeCompressor Module Returning Success/Failure Of Decom-
*              pression.
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: 
*
*       File:  so_li.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiCstDecompressCfm
(
Pst    *pst,       /* post structure              */
Bool   success,    /* Decompression Successful!   */
Buffer *unCompMsg, /* Decompressed Message (if decompression was successful)*/
                   /* Original Message (if compression was unsuccessful)    */
Ptr    compContext /* Context provided in SoLiCstCompressReq function       */
)
#else
PUBLIC S16 SoLiCstDecompressCfm (pst, success, unCompMsg, compContext)
Pst    *pst;       /* post structure              */
Bool   success;    /* Decompression Successful!   */
Buffer *unCompMsg; /* Decompressed Message (if decompression was successful)*/
                   /* Original Message (if compression was unsuccessful)    */
Ptr    compContext;/* Context provided in SoLiCstCompressReq function       */
#endif
{
   SoTptClientCb  *clientCb;
   SoTptServerCb  *serverCb;
   SoCompContext  *connContext;

   TRC3 (SoLiCstDecompressCfm)

   SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,
             "SoLiCstDecompressCfm: Successful (%d) \n", success));

   UNUSED (pst);

   clientCb    = NULLP;
   serverCb    = NULLP;
   connContext = (SoCompContext *)compContext;

   if (!success)
        /*-- Decompressor module was unable to decompress message --*/
        /*--------------- This Message Will Be Dropped -------------*/
        goto SOLICSTDECOMPRESSCFM;
    
   if ((unCompMsg   == NULLP) ||
       (connContext == (Void *)NULLP))
        /*------ Incorrect parameter passed. Drop the message ------*/
        goto SOLICSTDECOMPRESSCFM;

   if ((connContext->tSapId >= soCb.cfg.maxNmbTSaps) || 
       (connContext->tSapId < 0))
        /*------ Incorrect transport SAP Id. Drop the message ------*/
        goto SOLICSTDECOMPRESSCFM;

   if ((soCb.soTSapCbLst[connContext->tSapId]        == NULLP)  ||
       (soCb.soTSapCbLst[connContext->tSapId]->state != LSO_TSAP_BNDENA))
        /*------ Incorrect transport SAP Id. Drop the message ------*/
        goto SOLICSTDECOMPRESSCFM;

   if (connContext->choice == SO_COMP_CONTEXT_CLIENT)
   {
     clientCb = soTptCheckClientCb (connContext->tSapId,
                                    HI_USER_CON_ID,
                                    connContext->t.client.connId);
     if (clientCb == NULLP)
        /*--- Client Connection does not exist. Drop the message ---*/
        goto SOLICSTDECOMPRESSCFM;

     /*--- Finally,send uncompressed message to transport module ---*/
     (Void) soTptGetMsg (clientCb->serverCb->entCb,
                         clientCb->serverCb,
                         clientCb,
                         &connContext->t.client.peerAddr,
                         unCompMsg);
   }
   else
   {
      if (connContext->t.server.connId >= soCb.maxTptSrv)
        /*-- Incorrect Server Connection identifier.Drop message ---*/
        goto SOLICSTDECOMPRESSCFM;

      serverCb =  soCb.allSrvCbLst[connContext->t.server.connId];
      if (serverCb == NULLP)
        /*-- Incorrect Server Connection identifier.Drop message ---*/
        goto SOLICSTDECOMPRESSCFM;

     /*--- Finally,send uncompressed message to transport module ---*/
      (Void) soTptGetMsg (serverCb->entCb,
                          serverCb,
                          NULLP, 
                         &connContext->t.client.peerAddr,
                         unCompMsg);
   }

   RETVALUE (ROK);

SOLICSTDECOMPRESSCFM:
   
  SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,
             "\nSoLiCstDeCompressCfm Error:  unCompMsg (%p)\n", 
             (Void *)unCompMsg));

  if (unCompMsg)
    (Void) SPutMsg (unCompMsg);

  RETVALUE (RFAILED);

} /* end of SoLiCstDecompressCfm */

#endif /* SO_COMPRESS */




/********************************************************************30**

         End of file:     so_li.c@@/main/6 - Tue Apr 20 14:19:02 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/6      ---     
/main/6+   so007.201  ps   1. Stopping all clientCb timers during 
                              deletion.
/main/6+   so010.201  ab   1. Fix to guard opening of tpt srv with a timer
/main/6+   so021.201  ab   1. Try to reopen transport server on connection
                              being closed by peer.
                      ps   2. Removed warning.
/main/6+   so022.201  ps   1. Removed warning of unused local variable.
/main/6+   so029.201  ps   1. Added handling of DiscCfm primitive.
/main/6+   so031.201  aj   1. To remove the warning.
/main/6+   so032.201  ng   1. If retry feature is not enabled, send alarm
/main/6+   so035.201  ng   1. Reset the retry of server connection ones
                              all retry is done. Also localized checking
                              of retry count at one place.(ps)
 /main/6+   so038.201  ng  1. Added to check for UDP prior tranport
 /main/6+   so041.201  ng  1. Changes for SIP TLS support when calling soLiHitConReq
*********************************************************************91*/
