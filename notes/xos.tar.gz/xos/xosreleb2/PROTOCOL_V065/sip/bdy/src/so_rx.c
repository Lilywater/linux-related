/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Regular expression function for SIP message.

     Type:     C source file

     Desc:     Definition for regular expression funtion for decoding
               SIP message.

     File:     so_rx.c

     Sid:      so_rx.c@@/main/4 - Tue Apr 20 12:47:01 2004

     Prg:      jvn, sc, tn, ja

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* environment options       */
#include "envdep.h"        /* environment dependent     */
#include "envind.h"        /* environment independent   */
#include "gen.h"           /* general layer             */
#include "ssi.h"           /* system services           */
#include "cm_mblk.h"       /* Header file               */
#include "cm_tkns.h"       /* common token structures   */
#include "cm_abnf.h"       /* ABNF header file          */
#include "cm_inet.h"       /* Inet header file          */
#include "cm_tpt.h"        /* Transport  header file    */
#include "sot.h"           /* SIP upper interface       */


/* header/extern include files (.x) */
#include "gen.x"           /* general layer                     */
#include "ssi.x"           /* system services                   */
#include "cm_mblk.x"       /* Header file                       */
#include "cm_tkns.x"       /* common token structures           */
#include "cm_abnf.x"       /* ABNF header file                  */
#include "cm_inet.x"       /* Inet header file                  */
#include "cm_tpt.x"        /* Transport  header file            */
#include "cm_abndb.x"      /* Common database elemet definition */
#include "so_rx.x"         /* Sip regular expressions           */


/********************************************************
Global Defines local to module
*********************************************************/
PRIVATE S16 soRegExpStrCmp   ARGS((
              CmAbnfDecCp *decCp,
              Bool        tknCons,
              U8          **memPtr,
              U16         *len,
              Txt         *compareStr,
              U16         compareLen,
              Bool        caseInsensitive));


/* so038: Added the function for moving the expires,q,tags as the 
 * contact params in stead of Url Parameters*/
PRIVATE S16 soRegExpCheckUrlParameters ARGS ((
   CmAbnfDecCp *cp, Bool tknCons, U8 **mem, U16 *len));
/*
*
*       Fun:   soChTransportParam
*
*       Desc:  Description for the array of Transport Parameter Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChTransportParam[] =
{
   "udp",      /* SO_TRANSPORTPARAM_UDP   */
   "tcp",      /* SO_TRANSPORTPARAM_TCP   */
   "sctp",     /* SO_TRANSPORTPARAM_SCTP  */
   "tls",      /* SO_TRANSPORTPARAM_TLS   */
   NULL
}; /* End of soChTransportParam */


/*
*
*       Fun:   soChUserParam
*
*       Desc:  Description for the array of User Param Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChUserParam[] =
{
   "phone",    /* SO_USERPARAM_PHONE   */
   "ip",       /* SO_USERPARAM_IP      */
   NULL
};


/*
*
*       Fun:   soChUrlParam
*
*       Desc:  Description for the array of Url Parameter Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChUrlParam[] =
{
   "transport",  /* SO_URLPARAMETER_TRANSPORTPARAM */
   "user",       /* SO_URLPARAMETER_USERPARAM      */
   "method",     /* SO_URLPARAMETER_METHOD         */
   "ttl",        /* SO_URLPARAMETER_TTLPARAM       */
   "maddr",      /* SO_URLPARAMETER_MADDRHOST      */
   "lr",         /* SO_URLPARAMETER_LRPARAM        */
#ifdef SO_PINT
   "tsp",        /* SO_URLPARAMETER_TSPDOMAIN      */
#else
   "",           /* SO_URLPARAMETER_TSPDOMAIN      */
#endif /* SO_PINT */
#ifdef SO_ENUM
   "phone-context", /* SO_URLPARAMETER_PHONECONTEXT */
   "isub",          /* SO_URLPARAMETER_ISUB        */
   "postd",         /* SO_URLPARAMETER_POSTD       */
#else
   "",              /* SO_URLPARAMETER_PHONECONTEXT */
   "",              /* SO_URLPARAMETER_ISUB        */
   "",              /* SO_URLPARAMETER_POSTD       */
#endif /* SO_ENUM */
   "comp",
   NULL
};

/*
*
*       Fun:   soChMethod
*
*       Desc:  Description for the array of Method Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChMethod[] =
{
   "INVITE",         /* SO_METHODSTD_INVITE     */
   "ACK",            /* SO_METHODSTD_ACK        */
   "OPTIONS",        /* SO_METHODSTD_OPTIONS    */
   "BYE",            /* SO_METHODSTD_BYE        */
   "CANCEL",         /* SO_METHODSTD_CANCEL     */
   "REGISTER",       /* SO_METHODSTD_REGISTER   */
   "INFO",           /* SO_METHODSTD_INFO       */
   "COMET",          /* SO_METHODSTD_COMET      */
   "PRACK",          /* SO_METHODSTD_PRACK      */
   "REFER",          /* SO_METHODSTD_REFER      */
   "SUBSCRIBE",      /* SO_METHODSTD_SUBSCRIBE  */
   "NOTIFY",         /* SO_METHODSTD_NOTIFY     */
   "MESSAGE",         /* SO_METHODSTD_MESSAGE    */
   "UPDATE",         /* SO_METHODSTD_UPDATE     */
   NULL
};


/*
*
*       Fun:   soChWkDay
*
*       Desc:  Description for the array of Weekday Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChWkDay[] =
{
   "Mon",   /* SO_WKDAY_MON */
   "Tue",   /* SO_WKDAY_TUE */
   "Wed",   /* SO_WKDAY_WED */
   "Thu",   /* SO_WKDAY_THU */
   "Fri",   /* SO_WKDAY_FRI */
   "Sat",   /* SO_WKDAY_SAT */
   "Sun",   /* SO_WKDAY_SUN */
   NULL
};


/*
*
*       Fun:   soChMonth
*
*       Desc:  Description for the array of Month Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChMonth[] =
{
   "Jan",   /* SO_MONTH_JAN */
   "Feb",   /* SO_MONTH_FEB */
   "Mar",   /* SO_MONTH_MAR */
   "Apr",   /* SO_MONTH_APR */
   "May",   /* SO_MONTH_MAY */
   "Jun",   /* SO_MONTH_JUN */
   "Jul",   /* SO_MONTH_JUL */
   "Aug",   /* SO_MONTH_AUG */
   "Sep",   /* SO_MONTH_SEP */
   "Oct",   /* SO_MONTH_OCT */
   "Nov",   /* SO_MONTH_NOV */
   "Dec",   /* SO_MONTH_DEC */
   NULL
};


/*
*
*       Fun:   soChAction
*
*       Desc:  Description for the array of Action Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChAction[] =
{
   "proxy",       /* SO_ACTION_PROXY      */
   "redirect",    /* SO_ACTION_REDIRECT   */
   NULL
};


/*
*
*       Fun:   soChContactParamStd
*
*       Desc:  Description for the array of Standard Contact Parameter Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChContactParamStd[] =
{
   "q",                 /* SO_CONTACTPARAMSTD_Q        */
   "action",            /* SO_CONTACTPARAMSTD_ACTION   */
   "expires",           /* SO_CONTACTPARAMSTD_EXPIRES  */
   NULL
};

#ifdef SO_CALLERPREF

/*
*
*       Fun:   soChRequestDispositionValStd
*
*       Desc:  Description for the array of Request Disposition union
*
*       Ret:   Array indices
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChRequestDispositionValStd_FL_OLD[] =
{
   "proxy-feature",     /* SO_REQUESTDISP_PROXY_FEATURE */      
   "cancel-feature",    /* SO_REQUESTDISP_CANCEL_FEATURE */      
   "fork-feature",      /* SO_REQUESTDISP_FORK_FEATURE */      
   "recurse-feature",   /* SO_REQUESTDISP_RECURSE_FEATURE */      
   "parallel-feature",  /* SO_REQUESTDISP_PARALLEL_FEATURE */      
   "queue-feature",     /* SO_REQUESTDISP_QUEUE_FEATURE */      
   NULL
};

PUBLIC Txt *soChRequestDispositionValStd[] =
{
   /* SO_REQUESTDISP_PROXY_FEATURE */      
   "proxy",             /* SO_ACTION_PROXY      */
   "redirect",          /* SO_ACTION_REDIRECT   */

   /* SO_REQUESTDISP_CANCEL_FEATURE */
   "cancel",            /* SO_REQUESTDISP_CANCEL_CANCEL */      
   "no-cancel",         /* SO_REQUESTDISP_CANCEL_NOCANCEL */      

   /* SO_REQUESTDISP_FORK_FEATURE */
   "fork",              /* SO_REQUESTDISP_FORK_FORK */      
   "no-fork",           /* SO_REQUESTDISP_FORK_NOFORK */      

                        /* SO_REQUESTDISP_RECURSE_FEATURE */
   "recurse",           /* SO_REQUESTDISP_RECURSE_RECURSE */
   "no-recurse",        /* SO_REQUESTDISP_RECURSE_NORECURSE */ 

   /* SO_REQUESTDISP_PARALLEL_FEATURE */
   "parallel",          /* SO_REQUESTDISP_PARALLEL_PARALLEL */
   "sequential",        /* SO_REQUESTDISP_PARALLEL_SEQUENTIAL */ 

   /* SO_REQUESTDISP_QUEUE_FEATURE */
   "queue",             /* SO_REQUESTDISP_QUEUE_QUEUE */
   "no-queue",          /* SO_REQUESTDISP_QUEUE_NOQUEUE */ 
   NULL
};

/*
*
*       Fun:   soChCancelValStd
*
*       Desc:  Description for the array of cancel  
*
*       Ret:   Array indices
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChCancelValStd[] =
{
   "cancel",             /* SO_REQUESTDISP_CANCEL_CANCEL */      
   "no-cancel",          /* SO_REQUESTDISP_CANCEL_NOCANCEL */      
   NULL
};

/*
*
*       Fun:   soChForkValStd
*
*       Desc:  Description for the array of fork features  
*
*       Ret:   Array indices
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChForkValStd[] =
{
   "fork",             /* SO_REQUESTDISP_FORK_FORK */      
   "no-fork",          /* SO_REQUESTDISP_FORK_NOFORK */      
   NULL
};

/*
*
*       Fun:   soChRecurseValStd
*
*       Desc:  Description for the array of recurse features  
*
*       Ret:   Array indices
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChRecurseValStd[] =
{
   "recurse",             /* SO_REQUESTDISP_RECURSE_RECURSE */
   "no-recurse",          /* SO_REQUESTDISP_RECURSE_NORECURSE */ 
   NULL
};

/*
*
*       Fun:   soChParallelValStd
*
*       Desc:  Description for the array of parallel features  
*
*       Ret:   Array indices
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChParallelValStd[] =
{
   "parallel",             /* SO_REQUESTDISP_PARALLEL_PARALLEL */
   "sequential",           /* SO_REQUESTDISP_PARALLEL_SEQUENTIAL */ 
   NULL
};

/*
*
*       Fun:   soChQueueValStd
*
*       Desc:  Description for the array of queue features  
*
*       Ret:   Array indices
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChQueueValStd[] =
{
   "queue",                /* SO_REQUESTDISP_QUEUE_QUEUE */
   "no-queue",             /* SO_REQUESTDISP_QUEUE_NOQUEUE */ 
   NULL
};
#endif /* SO_CALLERPREF */

/*
*
*       Fun:   soChCallInfoPurpose
*
*       Desc:  Description for the array of Call Information Purpose Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChCallInfoPurpose[] =
{
   "icon",     /* SO_CALLINFOPURPOSE_ICON */
   "info",     /* SO_CALLINFOPURPOSE_INFO */
   "card",     /* SO_CALLINFOPURPOSE_CARD */
   NULL
};

/*
*
*       Fun:   soChContactParam
*
*       Desc:  Description for the array of Contact Parameter Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChContactParam[] =
{
   "q",           /* SO_CONTACTPARAM_STD */
   "action",      /* SO_CONTACTPARAM_STD */
   "expires",     /* SO_CONTACTPARAM_STD */

   "audio",       /* SO_CONTACTPARAM_FEAT_PARAM */      
   "automata",    /* SO_CONTACTPARAM_FEAT_PARAM */      
   "class",       /* SO_CONTACTPARAM_FEAT_PARAM */      
   "duplex",      /* SO_CONTACTPARAM_FEAT_PARAM */      
   "data",        /* SO_CONTACTPARAM_FEAT_PARAM */      
   "control",     /* SO_CONTACTPARAM_FEAT_PARAM */      
   "mobility",    /* SO_CONTACTPARAM_FEAT_PARAM */      
   "description", /* SO_CONTACTPARAM_FEAT_PARAM */      
   "events",      /* SO_CONTACTPARAM_FEAT_PARAM */      
   "priority",    /* SO_CONTACTPARAM_FEAT_PARAM */      
   "methods",     /* SO_CONTACTPARAM_FEAT_PARAM */      
   "schemes",     /* SO_CONTACTPARAM_FEAT_PARAM */      
   "application", /* SO_CONTACTPARAM_FEAT_PARAM */      
   "video",       /* SO_CONTACTPARAM_FEAT_PARAM */      
   "language",    /* SO_CONTACTPARAM_FEAT_PARAM */      
   "type",        /* SO_CONTACTPARAM_FEAT_PARAM */      
   "isfocus",     /* SO_CONTACTPARAM_FEAT_PARAM */      
   "actor",       /* SO_CONTACTPARAM_FEAT_PARAM */      
   "text",        /* SO_CONTACTPARAM_FEAT_PARAM */      
   NULL
};

/*
*
*       Fun:   soChHandlingParmStd
*
*       Desc:  Description for the array of Standard Handling parameter Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChHandlingParmStd[] =
{
   "optional",    /* SO_HANDLINGPARMVALSTD_OPTIONAL */
   "required",    /* SO_HANDLINGPARMVALSTD_REQUIRED */
   NULL
};


/*
*
*       Fun:   soChContentCoding
*
*       Desc:  Description for the array of Content Coding Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChContentCoding[] =
{
   "gzip",        /* SO_CONTENTCODINGCH_GZIP       */
   "compress",    /* SO_CONTENTCODINGCH_COMPRESS   */
   "deflate",     /* SO_CONTENTCODINGCH_DEFLATE    */
   "identity",    /* SO_CONTENTCODINGCH_IDENTITY   */
   NULL
};


/*
*
*       Fun:   soChInfoParam
*
*       Desc:  Description for the array of Info Param Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChInfoParam[] =
{
   "purpose",  /* SO_INFOPARAM_PURPOSE */
   NULL
};

/*
*
*       Fun:   soChTransportStd
*
*       Desc:  Description for the array of Standard Transport Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChTransportStd[] =
{
   "UDP",   /* SO_TRANSPORTSTD_UDP */
   "TCP",   /* SO_TRANSPORTSTD_TCP */
   "SCTP",  /* SO_TRANSPORTSTD_SCTP */
   "TLS",   /* SO_TRANSPORTSTD_TLS */
   NULL
};


/*
*
*       Fun:   soChViaParam
*
*       Desc:  Description for the array of Via Parameter Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
/* so007.201: Changes for rport support */
PUBLIC Txt *soChViaParam[] =
{
   "ttl",        /* SO_VIAPARAM_VIATTL    */
   "maddr",      /* SO_VIAPARAM_MADDR     */
   "received",   /* SO_VIAPARAM_RECEIVED  */
   "branch",     /* SO_VIAPARAM_VIABRANCH */
#ifdef SO_NAT
   "rport",      /* SO_VIAPARAM_VIAPORT   */
#else
   "",           /* SO_VIAPARAM_VIAPORT   */
#endif
   "comp",       /* SO_VIAPARAM_COMP      */
   NULL
};


/*
*
*       Fun:   soChProtocolName
*
*       Desc:  Description for the array of Protocol Name Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChProtocolName[] =
{
   "SIP",    /* SO_PROTOCOLNAME_SIP */
   NULL
};


/*
*
*       Fun:   soChPriority
*
*       Desc:  Description for the array of Priority Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChPriority[] =
{
   "emergency",      /* SO_PRIORITY_EMERGENCY   */
   "urgent",         /* SO_PRIORITY_URGENT      */
   "normal",         /* SO_PRIORITY_NORMAL      */
   "non-urgent",     /* SO_PRIORITY_NONURGENT   */
   NULL
};

/*
*
*       Fun:   soChDispositionType
*
*       Desc:  Description for the array of Disposition Type Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChDispositionType[] =
{
   "session",     /* SO_DISP_TYPE_SESSION */
   "render",      /* SO_DISP_TYPE_RENDER  */
   "icon",        /* SO_DISP_TYPE_ICON    */
   "alert",       /* SO_DISP_TYPE_ALERT   */
   NULL           /* Extn */
};


/*
*
*       Fun:   soChHeader
*
*       Desc:  Description for the array of Header Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChHeader[] =
{
   "Accept",                 /* SO_HEADER_GEN_ACCEPT              */
   "Accept-Encoding",        /* SO_HEADER_GEN_ACCEPTENCODING      */
   "Accept-Language",        /* SO_HEADER_GEN_ACCEPTLANGUAGE      */
   "Alert-Info",             /* SO_HEADER_GEN_ALERTINFO           */
   "Allow",                  /* SO_HEADER_GEN_ALLOW               */
   "Also",                   /* SO_HEADER_REQ_ALSO                */
   "Authorization",          /* SO_HEADER_REQ_AUTHORIZATION       */
   "Call-ID",                /* SO_HEADER_GEN_CALLID              */
   "i",                      /* SO_HEADER_GEN_CALLIDI             */
   "Call-Info",              /* SO_HEADER_GEN_CALLINFO            */
   "Contact",                /* SO_HEADER_GEN_CONTACT             */
   "m",                      /* SO_HEADER_GEN_CONTACTM            */
   "Content-Disposition",    /* SO_HEADER_ENT_CONTENTDISPOSITION  */
   "Content-Encoding",       /* SO_HEADER_ENT_CONTENTENCODING     */
   "e",                      /* SO_HEADER_ENT_CONTENTENCODINGE    */
   "Content-Language",       /* SO_HEADER_ENT_CONTENTLANGUAGE     */
   "Content-Length",         /* SO_HEADER_ENT_CONTENTLENGTH       */
   "l",                      /* SO_HEADER_ENT_CONTENTLENGTHL      */
   "Content-Type",           /* SO_HEADER_ENT_CONTENTTYPE         */
   "c",                      /* SO_HEADER_ENT_CONTENTTYPEC        */
   "CSeq",                   /* SO_HEADER_GEN_CSEQ                */
   "Date",                   /* SO_HEADER_GEN_DATE                */
   "Encryption",             /* SO_HEADER_GEN_ENCRYPTION          */
   "Error-Info",             /* SO_HEADER_RSP_ERRORINFO           */
   "Expires",                /* SO_HEADER_GEN_EXPIRES             */
   "From",                   /* SO_HEADER_GEN_FROM                */
   "f",                      /* SO_HEADER_GEN_FROMF               */
   "In-Reply-To",            /* SO_HEADER_REQ_INREPLYTO           */
   "Max-Forwards",           /* SO_HEADER_REQ_MAXFORWARDS         */
   "MIME-version",           /* SO_HEADER_ENT_MIMEVERSION         */
   "Organization",           /* SO_HEADER_GEN_ORGANIZATION        */
   "Priority",               /* SO_HEADER_REQ_PRIORITY            */
   "Proxy-Authenticate",     /* SO_HEADER_RSP_PROXYAUTHENTICATE   */
   "Proxy-Authorization",    /* SO_HEADER_REQ_PROXYAUTHORIZATION  */
   "Proxy-Require",          /* SO_HEADER_REQ_PROXYAUTHORIZATION  */
   "Record-Route",           /* SO_HEADER_GEN_PROXYREQUIRE        */   
   "Require",                /* SO_HEADER_GEN_RECORDROUTE         */
   "Response-Key",            /* SO_HEADER_GEN_REQUIRE             */
   "Retry-After",            /* SO_HEADER_REQ_RESPONSEKEY         */
   "Route",                  /* SO_HEADER_RSP_RETRYAFTER          */
   "Server",                 /* SO_HEADER_REQ_ROUTE               */
   "Subject",                /* SO_HEADER_RSP_SERVER              */
   "s",                      /* SO_HEADER_GEN_SUBJECT             */
   "Supported",              /* SO_HEADER_GEN_SUPPORTED           */
   "k",                      /* SO_HEADER_GEN_SUPPORTEDK          */
   "Timestamp",              /* SO_HEADER_GEN_TIMESTAMP           */
   "To",                     /* SO_HEADER_GEN_TO                  */
   "t",                      /* SO_HEADER_GEN_TOT                 */
   "Unsupported",            /* SO_HEADER_RSP_UNSUPPORTED         */
   "User-Agent",             /* SO_HEADER_GEN_USERAGENT           */
   "Via",                    /* SO_HEADER_GEN_VIA                 */
   "v",                      /* SO_HEADER_GEN_VIAV                */
   "RAck",                   /* SO_HEADER_GEN_RACK                */
   "RSeq",                   /* SO_HEADER_GEN_RSEQ                */
   "Warning",                /* SO_HEADER_GEN_WARNING             */
   "WWW-Authenticate",       /* SO_HEADER_GEN_WWWAUTHENTICATE     */
   "Event",                  /* SO_HEADER_REQ_EVENT               */
   "o",                      /* SO_HEADER_REQ_EVENTO              */
   "Allow-Events",           /* SO_HEADER_GEN_ALLOW_EVENTS        */
   "u",                      /* SO_HEADER_GEN_ALLOW_EVENTSU       */
   "Subscription-Expires",   /* SO_HEADER_REQ_SUBSCRIPTION_EXPIRES*/
   "Refer-To",               /* SO_HEADER_REQ_REFERTO             */
   "Referred-By",            /* SO_HEADER_REQ_REFERBY             */
   "r",                      /* SO_HEADER_REQ_REFERTOR            */
   "b",                      /* SO_HEADER_REQ_REFERBYB            */
   "Replaces",               /* SO_HEADER_REQ_REPLACES            */
   "Session-Expires",        /* SO_HEADER_GEN_SESSION_EXPIRES     */
   "x",                      /* SO_HEADER_GEN_SESSION_EXPIRESX    */
   "Min-SE",                 /* SO_HEADER_GEN_MINSE               */
   "Request-Disposition",    /* SO_HEADER_REQ_REQUESTDISPOSITION  */
   "d",                      /* SO_HEADER_REQ_REQUESTDISPOSITIOND */
   "Accept-Contact",         /* SO_HEADER_REQ_ACCEPT_CONTACT      */
   "a",                      /* SO_HEADER_REQ_ACCEPT_CONTACTA     */
   "Reject-Contact",         /* SO_HEADER_REQ_REJECT_CONTACT      */
   "j",                      /* SO_HEADER_REQ_REJECT_CONTACTJ     */
   NULL
};


/*
*
*       Fun:   soChAddrSpec
*
*       Desc:  Description for the array of Address Spec Request URI Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChAddrSpec[] =
{
   "sip:",        /* SO_ADDRSPEC_SIPURL */  

#ifdef SO_TLS                              
   "sips:",        /* SO_ADDRSPEC_SIPSURL */  
#else
   "",             /* None */ 
#endif /* SO_TLS */

#ifdef SO_ENUM                            
   "tel:",        /* SO_ADDRSPEC_TELURL */ 
#else
   "",            /* None */
#endif /* SO_ENUM */

#ifdef SO_INSTMSG
   "im:",         /* SO_ADDRSPEC_IMURL */
#else
   "",            /* None */
#endif /* SO_INSTMSG */

   NULL,
};

/*
*
*       Fun:   soAddrSpecSIP
*
*       Desc:  Description for the array of SIP Protocol Name Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soAddrSpecSIP[] =
{
   "sip:",    /* SO_PROTOCOLNAME_SIP */
   NULL
};

#ifdef SO_ENUM                              /*   element, to stay in step  */ 
/*
*
*       Fun:   soAddrSpecTEL
*
*       Desc:  Description for the array of SIP Protocol Name Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soAddrSpecTEL[] =
{
   "tel:",    /* SO_PROTOCOLNAME_SIP */
   NULL
};
#endif /* SO_ENUM */
#ifdef SO_INSTMSG
/*
*
*       Fun:   soAddrSpecIM
*
*       Desc:  Description for the array of IM Protocol Name Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soAddrSpecIM[] =
{
   "im:",    /* SO_PROTOCOLNAME_SIP */
   NULL
};
#endif /* SO_INSTMSG */

/*
*
*       Fun:   soChContentTypeType
*
*       Desc:  Description for the array of ContentType Type Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChContentTypeType[] =
{
   "text",          /* SO_MEDIATYPE_TEXT         */
   "image",         /* SO_MEDIATYPE_IMAGE        */
   "audio",         /* SO_MEDIATYPE_AUDIO        */
   "video",         /* SO_MEDIATYPE_VIDEO        */
   "application",   /* SO_MEDIATYPE_APPLICATION  */
   "message",       /* SO_MEDIATYPE_MESSAGE      */
   "multipart",     /* SO_MEDIATYPE_MULTIPART    */
   NULL             /* Extension */
}; /* End of soChContentTypeType */


/*
*
*       Fun:   soChMediaSubType
*
*       Desc:  Description for the array of ContentType SubType Choices
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChMediaSubType[] =
{
   "mixed",   /* SO_MEDIA_SUBTYPE_MIXED   */
   "SDP",     /* SO_MEDIA_SUBTYPE_SDP     */
   "ISUP",    /* SO_MEDIA_SUBTYPE_ISUP    */
   "QSIG",    /* SO_MEDIA_SUBTYPE_QSIG    */
   "SIPFRAG", /* SO_MEDIA_SUBTYPE_SIPFRAG */
   "simple-message-summary", /* SO_MEDIA_SUBTYPE_SMS */
   NULL       /* Extension */
}; /* End of soChMediaSubType */

#ifdef SO_EVENT
#ifdef SO_REFER
/*
*
*       Fun:   soChReplacesParamType
*
*       Desc:  Description for the array of replaces params 
*
*       Ret:   Array indice
*
*       Notes: None
*
*       File:  so_rx
*
*/
PUBLIC Txt *soChReplacesParamType[] =
{
   "to-tag",   /* SO_REPLACES_PARAMTYPE_TOTAG   */
   "from-tag", /* SO_REPLACES_PARAMTYPE_FROMTAG */
   "early-only", /* SO_REPLACES_PARAMTYPE_EARLYONLY */
   NULL
}; /* End of soChReplacesParamType */
#endif /* SO_REFER */
#endif /* SO_EVENT */


/*
*
*       Fun:   soAbnfDecChkLen
*
*       Desc:  calls ABNF macro 
*
*       Ret:   Bool
*
*
*       Notes: None
*
*       File:  so_rx
*
*/

#ifdef ANSI
PRIVATE Bool soAbnfDecChkLen
(
U16         *len,              /* length of the string returned  */
U16         yyDecode           /* Number of characters decoded  */
)
#else
PRIVATE Bool soAbnfDecChkLen(len, yyDecode)
U16         *len;               /* length of the string returned  */
U16         yyDecode;           /* Number of characters decoded  */
#endif   /*ANSI*/
{
   RETVALUE(CM_ABNF_DEC_CHKLEN(len, yyDecode));
}  /* End of soAbnfDecChkLen */

/*
*
*       Fun:   soAbnfDecChcpy
*
*       Desc:  calls ABNF macro 
*
*       Ret:   Void
*
*
*       Notes: None
*
*       File:  so_rx
*
*/

#ifdef ANSI
PRIVATE Void soAbnfDecChcpy
(
U8          **mem,              /* memory pointer                 */
S16         theCh               /* length of the string returned  */
)
#else
PRIVATE Void soAbnfDecChcpy(mem, theCh)
U8          **mem;              /* memory pointer                 */
S16         theCh;              /* length of the string returned  */
#endif   /*ANSI*/
{
   CM_ABNF_DEC_CHCPY(mem, theCh);
}  /* End of soAbnfDecChcpy */

/*
*
*       Fun:   soAbnfDecret
*
*       Desc:  calls ABNF macro 
*
*       Ret:   Void
*
*
*       Notes: None
*
*       File:  so_rx
*
*/

#ifdef ANSI
PRIVATE S16 soAbnfDecret
(
CmAbnfDecCp *decCp,             /* Decode control point           */
S16          yyRet,              /* memory pointer                 */
U16         Decode,              /* memory pointer                 */
Bool        tknCons,               /* length of the string returned  */
U16         *len              /* length of the string returned  */
)
#else
PRIVATE S16 soAbnfDecret(decCp, yyRet, Decode, tknCons, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
S16          yyRet;              /* memory pointer                 */
U16         Decode;              /* memory pointer                 */
Bool        tknCons;               /* length of the string returned  */
U16         *len;               /* length of the string returned  */
#endif   /*ANSI*/
{
   CM_ABNF_DECRET(decCp, yyRet, Decode, tknCons, len);
}  /* End of soAbnfDecret */

/*
*
*       Fun:   soAbnfDecCspStrXl
*
*       Desc:  calls ABNF macro 
*
*       Ret:   S8
*
*
*       Notes: None
*
*       File:  so_rx
*
*/

#ifdef ANSI
PRIVATE S8 soAbnfDecCspStrXl
(
CmAbnfDecCp *decCp,             /* Decode control point           */
U8          **mem,              /* memory pointer                 */
U16         *len,              /* length of the string returned  */
U16         yyDecode   /* Number of characters decoded  */
)
#else
PRIVATE S8 soAbnfDecCspStrXl(decCp, mem, len, yyDecode)
CmAbnfDecCp *decCp;             /* Decode control point           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
U16         yyDecode;   /* Number of characters decoded  */
#endif   /*ANSI*/
{
   CM_ABNF_DEC_CSPSTRXL(decCp, mem, len, yyDecode);
   RETVALUE(ROK);
}  /* End of soAbnfDecCspStrXl */


/*
*
*       Fun:   soRegExpStrCmp
*
*       Desc:  Compares string to specific value
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: This function is used for regular expression for the ABNF
*              parser to compare the input to a fixed string
*
*              The string to compare must always be specified as a lower case
*              string if case insensitive comparisons are to be made
*
*       File:  so_rx
*
*/

#ifdef ANSI
PRIVATE S16 soRegExpStrCmp
(
CmAbnfDecCp *decCp,          /* Decode control point            */
Bool        tknCons,         /* Token to be comsumed            */
U8          **memPtr,        /* memory pointer                  */
U16         *len,            /* length of string to be returned */
Txt         *compareStr,     /* String to look for              */
U16         compareLen,      /* Length of string to check       */
Bool        caseInsensitive  /* Case sensitivity of comparison  */
)
#else
PRIVATE S16 soRegExpStrCmp(decCp, tknCons, memPtr, len, compareStr,
                         compareLen, caseInsensitive)
CmAbnfDecCp *decCp;          /* Decode control point            */
Bool        tknCons;         /* Token to be comsumed            */
U8          **memPtr;        /* memory pointer                  */
U16         *len;            /* length of string to be returned */
Txt         *compareStr;     /* String to look for              */
U16         compareLen;      /* Length of string to check       */
Bool        caseInsensitive; /* Case sensitivity of comparison  */
#endif
{
   S16   theCh;             /* The actual character from the text message   */
   U8    compareCh;         /* The character used to compare                */
   U16   DeCode;            /* Number of characters decoded                 */
   U16   i;                 /* Index in string                              */

   TRC2(soRegExpStrCmp);

   DeCode = 0;

   for (i=0; i<compareLen; i++)
   {
      /* Compare next character against current character in string */
      if (i == 0)
         theCh = cmAbnfGetChar(decCp->offset);
      else
      {
         theCh = cmAbnfGetNxtChar( decCp->offset, decCp->numBytes );
         ++DeCode;
      }

      compareCh = compareStr[0];
      if (caseInsensitive == TRUE)
      {
         if ((compareCh>='A') && (compareCh<='Z'))
            compareCh = compareCh + ('a' - 'A');
         if ((theCh>='A') && (theCh<='Z'))
            theCh = theCh + ('a' - 'A');
      }
      if ((theCh != compareCh) || (theCh < 0))
      {
         /* Failed*/
         RETVALUE(soAbnfDecret( decCp, -1, DeCode, tknCons, len ));
      }
      /* Matching character, continue to next one */
      compareStr++;
   }
   /* Matching string - advance to next characer to decode */
   theCh = cmAbnfGetNxtChar( decCp->offset, decCp->numBytes );
   ++DeCode;
   RETVALUE(soAbnfDecret( decCp, 0, DeCode, tknCons, len ));
} /* soRegExpStrCmp */


/*
*
*       Fun:   soRegExpChoiceCmp
*
*       Desc:  Compares string to one of few choice values
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: This function is used for regular expression for the ABNF
*              parser to compare the input to one of a few possible fixed
*              string values
*
*              The string to compare must always be specified as a lower case
*              string if case insensitive comparisons are to be made
*
*              The return value is the index of the string in the array of
*              possible string values, starting at 1
*
*              THIS FUNCTION ASSUMES THAT THERE WILL NOT BE MORE THAN 100
*              CHOICES 
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpChoiceCmp
(
CmAbnfDecCp *decCp,          /* Decode control point            */
Bool        tknCons,         /* Token to be comsumed            */
U8          **memPtr,        /* memory pointer                  */
U16         *len,            /* length of string to be returned */
Txt         **strChoices,    /* Array of strings to check       */
Bool        caseInsensitive, /* Case sensitivity of comparison  */
Bool        allowToken       /* Allow generic token as well     */
)
#else
PUBLIC S16 soRegExpChoiceCmp(decCp, tknCons, memPtr, len, strChoices,
                         caseInsensitive, allowToken)
CmAbnfDecCp *decCp;          /* Decode control point            */
Bool        tknCons;         /* Token to be comsumed            */
U8          **memPtr;        /* memory pointer                  */
U16         *len;            /* length of string to be returned */
Txt         **strChoices;    /* Array of strings to check       */
Bool        caseInsensitive; /* Case sensitivity of comparison  */
Bool        allowToken;      /* Allow generic token as well     */
#endif
{
   S16   theCh;             /* The character from the text message          */
   S16   compareCh;         /* The character used to compare with           */
   S16   ReturnCode;        /* Return value                                 */
   U16   yyDecode;          /* Number of characters decoded                 */
   Txt   theStr[SO_MAX_KEYWORD_LEN];  /* store the str we are searching for */
   Bool  kwComplete = FALSE; /* ctl to know when we have complete srch str  */
   S16   iKw;
   U32   iChr, iLen;        /* Index in string                              */
   S16   delimCh;      /* The char  that delimited the token in the stream  */
   /* so008.201: Changes to handle long junk strings */
   Bool srchKwList = TRUE;  /* Weather to search keyword list or not */

   TRC2(soRegExpChoiceCmp);

   ReturnCode = RNOK;
   yyDecode   = 0;
   theCh      = 0;
   iLen = 0;
   
   /* Get the Keyword/Token */
   while( !kwComplete)
   {
      if (iLen == 0)
      {
         theCh = cmAbnfGetChar(decCp->offset);
         /* so005.102 */
         if ((theCh == '\n')||(theCh == '\r')||(theCh < 0))
         {
            ReturnCode = RNOK;
            goto yyErr;
         }
      }
      else
      {
         if(soAbnfDecChkLen(len, yyDecode))
            goto yyErr;
         soAbnfDecChcpy(memPtr, theCh);
         theCh = cmAbnfGetNxtChar( decCp->offset, decCp->numBytes );
         /* so002.102: check return value in case of there is no 
          *            end of line: \r\n */
         if (theCh < 0)
            goto yyErr;         
         ++yyDecode;
      }
      
      /* If current character is a delimiter then we have the complete Token/Keyword */
      if ((theCh == ' ')||(theCh == ';')||(theCh == ',')||(theCh == '\"')||
          (theCh == ':')||(theCh == '=')||(theCh == '>')||(theCh == '/')||
          (theCh == '\n')||(theCh == '\r')||(theCh == '\t'))
      {
         theStr[iLen++] = 0;
         kwComplete = TRUE;
      }
      /* so008.201: Changes to handle long junk strings */
      else if (SO_MAX_KEYWORD_LEN == iLen)
      {
         /* No token/keyowrd found, junk value, list of keywords should not be searched */
         srchKwList = FALSE;
         for (iKw=0;strChoices[iKw]!=NULL;iKw++);
         break;
      }
      else
      {
         theStr[iLen++] = (S8)theCh;
      }
   }
   delimCh = theCh;
   
   /* so008.201: Changes to handle long junk strings */
   if (TRUE == srchKwList)
   {
      /* Search the list of Keywords */
      for (iKw=0;TRUE;iKw++)
      {
         if ( strChoices[iKw]==NULL )
         {
            break;
         }
         else
         {
            iChr = 0;
            while(TRUE)
            {
               theCh = theStr[iChr];
               compareCh = strChoices[iKw][iChr];
               if (caseInsensitive == TRUE)
               {
                  if ((compareCh>='A') && (compareCh<='Z'))
                         compareCh = compareCh + ('a' - 'A');
                  if ((theCh>='A') && (theCh<='Z'))
                         theCh = theCh + ('a' - 'A');
               }
      
               /* Do we have end of String and Keyword ?? */
               if ((theCh==0)&&(compareCh==0)) 
               {
                  /* We matched all the way so we have a MATCH! */
                  if (soAbnfDecCspStrXl(decCp, memPtr, len, yyDecode) != ROK)
                         return (-1);
                  RETVALUE(soAbnfDecret( decCp, (S16)(iKw + 1), yyDecode, tknCons, len));
               }
            
               /* Do we have end of String (but not end of keyword in table)? */
               if ((theCh==0)&&
                  /* If the delim char in the stream = the last char 
                        in keyword table then we also have a match */
                  (delimCh==compareCh))
               {
                  /* We matched all the way so we have a MATCH! */
                  if (soAbnfDecCspStrXl(decCp, memPtr, len, yyDecode) != ROK)
                         return (-1);
                  RETVALUE(soAbnfDecret( decCp, (S16)(iKw + 1), yyDecode, tknCons, len));
               }

               /* 1st failure and we abort, and move onto next keyword */
               if (theCh != compareCh)
                  break;
      
               iChr++;
            }
         }
      }
   } /* if (TRUE == srchKwList) */
   
   /* We did not find the Keyword */
   if(allowToken == TRUE)
   {
      ReturnCode = iKw+1;
      if (soAbnfDecCspStrXl(decCp, memPtr, len, yyDecode) != ROK) 
           return (-1);
      RETVALUE(soAbnfDecret(decCp, ReturnCode, yyDecode, FALSE, len));
   }
   else
      ReturnCode = RNOK;
   RETVALUE(soAbnfDecret( decCp, ReturnCode, yyDecode, tknCons, len ));
      
yyErr:
   RETVALUE(soAbnfDecret( decCp, RNOK, yyDecode, tknCons, len ));
} /* soRegExpChoiceCmp */


/*
*
*       Fun:   soRegExpEatSpaces
*
*       Desc:  "Eat" spaces 
*
*       Ret:   Nonthing
*
*
*       Notes: None
*
*       File:  so_rx
*
*/

#ifdef ANSI
PRIVATE Void soRegExpEatSpaces
(
CmAbnfDecCp *decCp,             /* Decode control point           */
U16         *yyDecode           /* Number of characters decoded   */
)
#else
PRIVATE Void soRegExpEatSpaces(decCp, yyDecode)
CmAbnfDecCp *decCp;             /* Decode control point           */
U16         *yyDecode;          /* Number of characters decoded   */
#endif   /*ANSI*/
{
   S16         yych;            /* Character                      */

   TRC2(soRegExpEatSpaces);

   yych = cmAbnfGetChar(decCp->offset);
   while (yych==' ')
      {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      (*yyDecode)++;
      }
}  /* End of soRegExpEatSpaces */


/*
*
*       Fun:   soRegExpNumeric
*
*       Desc:  Numeric chars regular expression 
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: None
*
*       File:  so_rx
*
*/

#ifdef ANSI
PRIVATE S8 soRegExpNumeric
(
Bool        mustHave,           /* must have at least one char    */
U16         atMost,             /* not more than n digits         */
CmAbnfDecCp *decCp,             /* Decode control point           */
U8          **mem,              /* memory pointer                 */
U16         *len,               /* length of the string returned  */
U16         *yyDecode           /* Number of characters decoded   */
)
#else
PRIVATE S8 soRegExpNumeric ( mustHave, atMost, decCp, mem, len, yyDecode)
Bool        mustHave;           /* must have at least one char    */
U16         atMost;             /* not more than n digits         */
CmAbnfDecCp *decCp;             /* Decode control point           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
U16         *yyDecode;          /* Number of characters decoded   */
#endif   /*ANSI*/
{
   S16      yych;       /* Character                      */
   Bool     haveAtleastOneChar;

   TRC2(soRegExpNumeric);

   haveAtleastOneChar = FALSE;
   yych = cmAbnfGetChar(decCp->offset);
   if (atMost==0) 
   {
      atMost = 9999; /* no limit ! */
   }
   while (
          (atMost>0) &&
          ((yych>='0') && (yych<='9'))
          )
   {
      haveAtleastOneChar = TRUE;
      if (soAbnfDecChkLen(len,*yyDecode))
         RETVALUE(RFAILED);
   
      soAbnfDecChcpy(mem,yych);
   
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      (*yyDecode)++;
      atMost--;
   }
      
   if (mustHave && !haveAtleastOneChar)
      RETVALUE(RFAILED);
   else
      RETVALUE(ROK);
}  /* End of soRegExpNumeric */


/*
*
*       Fun:   soRegExpAlphaNumericSpecial
*
*       Desc:  Alpha Numeric, & Special chars regular expression 
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: None
*
*       File:  so_rx
*
*/

#ifdef ANSI
PRIVATE S8 soRegExpAlphaNumericSpecial
(
Txt         *strCh,             /* Array of special chars to check*/
U16         atMost,             /* not more than n digits         */
Bool        mustHave,           /* must have at least one char    */
CmAbnfDecCp *decCp,             /* Decode control point           */
U8          **mem,              /* memory pointer                 */
U16         *len,               /* length of the string returned  */
U16         *yyDecode           /* Number of characters decoded   */
)
#else
PRIVATE S8 soRegExpAlphaNumericSpecial(strCh, atMost, mustHave, decCp,
                                        mem, len, yyDecode)
Txt         *strCh;             /* Array of special chars to check*/
U16         atMost;             /* not more than n digits         */
Bool        mustHave;           /* must have at least one char    */
CmAbnfDecCp *decCp;             /* Decode control point           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
U16         *yyDecode;          /* Number of characters decoded   */
#endif   /*ANSI*/
{
   S16      yych;       /* Character                      */
   Bool     haveAtleastOneChar;

   TRC2(soRegExpAlphaNumericSpecial);

   haveAtleastOneChar = FALSE;
   yych = cmAbnfGetChar(decCp->offset);
   if (atMost==0) 
   {
      atMost = 9999; /* no limit ! */
   }
   while ((atMost>0) &&
         (((yych>='0') && (yych<='9')) ||
         ((yych>='A') && (yych<='Z')) ||
         ((yych>='a') && (yych<='z')) ||
         (strCh==NULL?FALSE:strchr(strCh, yych)!=NULL)))
   {
      haveAtleastOneChar = TRUE;
      if (soAbnfDecChkLen(len,*yyDecode))
         RETVALUE(RFAILED);
   
      soAbnfDecChcpy(mem,yych);
   
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      (*yyDecode)++;
      atMost--;
   }
      
   if (mustHave && !haveAtleastOneChar)
      RETVALUE(RFAILED);
   else
      RETVALUE(ROK);
}  /* End of soRegExpAlphaNumericSpecial */




/*
*
*       Fun:   soRegExpMetaOpenSqrBr
*
*       Desc:  Regular Expression for Meta Open Square Bracket
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Determines whether "[" is present
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMetaOpenSqrBr
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **memPtr,   /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaOpenSqrBr(decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **memPtr;   /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   theCh;      /* The character to be compared  */
   S16   ReturnCode; /* Return value                  */
   U16   DeCode;     /* Number of characters decoded  */

   TRC2(soRegExpMetaOpenSqrBr);

   /* Initialize variables */
   ReturnCode = RNOK;
   DeCode     = 0;

   theCh = cmAbnfGetChar( decCp->offset );

   switch(theCh)
   {
      case '[': goto nextChar1;
      default: goto ErrorReturn;
   }
nextChar1:
   theCh = cmAbnfGetNxtChar( decCp->offset, decCp->numBytes );
   ++DeCode;
   ReturnCode = ROK;

ErrorReturn:
   RETVALUE(soAbnfDecret( decCp, ReturnCode, DeCode, tknCons, len ));
} /* End of soRegExpMetaOpenSqrBr */

/*
*
*       Fun:   soRegExpMetaCloseSqrBr
*
*       Desc:  Regular Expression for Meta Close Square Bracket
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Determines whether "]" is present
*
*       File:  so_rx.c
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMetaCloseSqrBr
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **memPtr,   /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaCloseSqrBr( decCp, tknCons, memPtr, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **memPtr;   /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   theCh;      /* The character being evaluated    */
   S16   ReturnCode; /* Return value                     */
   U16   DeCode;     /* Number of characters decoded     */

   TRC2(soRegExpMetaCloseSqrBr);

   /* Initialize local variables */
   ReturnCode = RNOK;
   DeCode     = 0;

   theCh = cmAbnfGetChar( decCp->offset );

   switch(theCh)
   {
   case ']': goto nextChar1;
   default: goto ErrorReturn;
   }
nextChar1:
   theCh = cmAbnfGetNxtChar( decCp->offset, decCp->numBytes );
   ++DeCode;
   ReturnCode = ROK;

ErrorReturn:
   RETVALUE(soAbnfDecret( decCp, ReturnCode, DeCode, tknCons, len ));
} /* End of soRegExpMetaCloseSqrBr */

/*
*
*       Fun:   soRegExpMetaAmpersand
*
*       Desc:  Regular Expression for Meta Ampersand 
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Determines whether "&" is present
*
*       File:  so_rx.c
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMetaAmpersand
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **memPtr,   /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaAmpersand( decCp, tknCons, memPtr, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **memPtr;   /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   theCh;      /* The character being evaluated    */
   S16   ReturnCode; /* Return value                     */
   U16   DeCode;     /* Number of characters decoded     */

   TRC2(soRegExpMetaAmpersand);

   /* Initialize local variables */
   ReturnCode = RNOK;
   DeCode     = 0;

   theCh = cmAbnfGetChar( decCp->offset );

   switch(theCh)
   {
   case '&': goto nextChar1;
   default: goto ErrorReturn;
   }
nextChar1:
   theCh = cmAbnfGetNxtChar( decCp->offset, decCp->numBytes );
   ++DeCode;
   ReturnCode = ROK;

ErrorReturn:
   RETVALUE(soAbnfDecret( decCp, ReturnCode, DeCode, tknCons, len ));

} /* End of soRegExpMetaAmpersand */

/*
*
*       Fun:   soRegExpPhone
*
*       Desc:  Regular Expression for phone
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Determines whether "phone" is present
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpPhone
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **memPtr,   /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpPhone( decCp, tknCons, memPtr, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **memPtr;   /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   TRC2(soRegExpPhone);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, memPtr, len, "phone", 5, FALSE));

} /* End of soRegExpPhone */


/*
*
*       Fun:   soRegExpIp
*
*       Desc:  Regular Expression for ip
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Determines whether "ip" is present
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpIp
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **memPtr,   /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpIp( decCp, tknCons, memPtr, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **memPtr;   /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{

   TRC2(soRegExpIp);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, memPtr, len, "ip", 2, FALSE));

} /* End of soRegExpIp */

/*
*
*       Fun:   soRegExpMetaEqual
*
*       Desc:  Regular Expression for Meta Equal
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Determines whether "=" is present
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMetaEqual
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **memPtr,   /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaEqual( decCp, tknCons, memPtr, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **memPtr;   /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   TRC2(soRegExpMetaEqual);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, memPtr, len, "=", 1, FALSE));
} /* End of soRegExpMetaEqual */

/*
*
*       Fun:   soRegExpMetaColon
*
*       Desc:  Regular Expression for Meta Colon
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Determines whether ":" is present
*
*       File:  so_rx
*
*/
/********************************************************
Regular Expression Parser: MetaColon
*********************************************************/
#ifdef ANSI
PUBLIC S16 soRegExpMetaColon
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaColon( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yych;       /* Character to be decoded          */
   S16   yyRet;      /* Return value                     */
   U16   yyDecode;   /* Number of characters decoded     */

   TRC2(soRegExpMetaColon);

   /* Initialize local variables */
   yyRet    = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == ':')
   {
      if(soAbnfDecChkLen(len, yyDecode))
         RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;

      while ((yych == ' ') || (yych == '\t'))
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

} /* End of soRegExpMetaColon */


/*
*
*       Fun:   soRegExpMetaColonLineBreak
*
*       Desc:  Regular Expression for Meta Colon
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Determines whether ":" is present
*
*       File:  so_rx
*
*/
/********************************************************
Regular Expression Parser: MetaColonLineBreak
*********************************************************/
#ifdef ANSI
PUBLIC S16 soRegExpMetaColonLineBreak
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaColonLineBreak( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yych;       /* Character to be decoded          */
   S16   yyRet;      /* Return value                     */
   U16   yyDecode;   /* Number of characters decoded     */

   TRC2(soRegExpMetaColonLineBreak);

   /* Initialize local variables */
   yyRet    = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\r')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\n')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == ':')
   {
      if(soAbnfDecChkLen(len, yyDecode))
         RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;

      while ((yych == ' ') || (yych == '\t'))
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      if (yych == '\r')
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      if (yych == '\n')
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      while ((yych == ' ') || (yych == '\t'))
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

} /* End of soRegExpMetaColonLineBreak */

/*
*
*       Fun:   soRegExpMetaColonNoSpace
*
*       Desc:  Regular Expression for Meta Colon
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Determines whether ":" is present
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMetaColonNoSpace
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaColonNoSpace( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   TRC2(soRegExpMetaColonNoSpace);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, mem, len, ":", 1, FALSE));
}  /* End of soRegExpMetaColonNoSpace */

/*
*
*       Fun:   soRegExpMetaAt
*
*       Desc:  Regular Expression for Meta At
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Determines whether "@" is present
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMetaAt
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **memPtr,   /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaAt( decCp, tknCons, memPtr, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **memPtr;   /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{

   TRC2(soRegExpMetaAt);

   RETVALUE (soRegExpStrCmp(decCp, tknCons, memPtr, len, "@", 1, FALSE));

} /* End of soRegExpMetaAt */


/*
*
*       Fun:   soRegExpMetaSemiColon
*
*       Desc:  Regular Expression for Semi-Colon
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Determines whether ";" is present
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMetaSemiColon
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaSemiColon( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yych;       /* Character to be decoded          */
   S16   yyRet;      /* Return value                     */
   U16   yyDecode;   /* Number of characters decoded     */

   TRC2(soRegExpMetaSemiColon);

   /* Initialize local variables */
   yyRet    = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\r')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\n')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == ';')
   {
      if(soAbnfDecChkLen(len, yyDecode))
         RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;

      while ((yych == ' ') || (yych == '\t'))
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      if (yych == '\r')
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      if (yych == '\n')
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      while ((yych == ' ') || (yych == '\t'))
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

} /* End of soRegExpMetaSemiColon */


/*
*
*       Fun:   soRegExpMetaDNLws
*
*       Desc:  Description for the regular expression MetaDNLws
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMetaDNLws
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 soRegExpMetaDNLws(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 ret;

   TRC2(soRegExpMetaDNLws)

   ret = soRegExpMetaLws(decCp, tknCons, mem, len);

   RETVALUE(ROK);
} /* soRegExpMetaDNLws */

/* so023.201 Changes for allowing a space between colon and header value */

/*
*
*       Fun:   soRegExpMetaOptSwsDec
*
*       Desc:  Description for the regular expression MetaOptSwsDec
*              
*                 WSP = [ \t];
*                 CRLF = [\r]  [\n];
*                 LWS1 = (WSP)* CRLF;
*                 LWS = (LWS1)? (WSP)+;
*              
*                 LWS        {return(1);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: This func is hand Modified. See below "so023.201" for details.
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMetaOptSwsDec
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 soRegExpMetaOptSwsDec(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   
   U16 yyWspBeforeCrlf = 0;

   TRC2(soRegExpMetaLws)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '\t':   case ' ':   yyWspBeforeCrlf = 1; goto yy3;
   case '\r':   goto yy6;
   default:   goto yyErr;
   }
yy3:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':   case ' ':   goto yy3;
   case '\r':   goto yy6;
   default:   goto yy5;
   }
yy5:
   {
      yyret = 1;
      goto yyReturn;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   goto yy7;
   default:   
      if (yyWspBeforeCrlf)
      {
         cmAbnfDecOffset(decCp, 1);
         yydecode -=1;
         goto yy5;
      }
      else
      {
         goto yyErr;
      }
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':   case ' ':   goto yy8;
   default:   
      if (yyWspBeforeCrlf)
      {
         cmAbnfDecOffset(decCp, 2);
         yydecode -=2;
         goto yy5;
      }
      else
      {
         goto yyErr;
      }
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':   case ' ':   goto yy8;
   default:   goto yy5;
   }



yyReturn:

yyErr:

   /* so023.201: this RE should not return RFAILED even if the LWS is not
    * parsed because LWS is optional. This RE is called from a DB
    * element which is of META type & is mandatory. During decoding
    * this element accepts an optional LWS. However even if the LWS is
    * not found, it should still pass the decoding. During encoding
    * since the element is mandatory it will encode the space in the
    * buffer.
    */
   if (yyret == -1)
   {
      tknCons = FALSE;
      yyret = 1;
   }

   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* soRegExpMetaOptSwsDec */





/*
*
*       Fun:   soRegExpMetaLws
*
*       Desc:  Description for the regular expression MetaLws
*              
*                 WSP = [ \t];
*                 CRLF = [\r]  [\n];
*                 LWS1 = (WSP)* CRLF;
*                 LWS = (LWS1)? (WSP)+;
*              
*                 LWS        {return(1);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMetaLws
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 soRegExpMetaLws(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   
   U16 yyWspBeforeCrlf = 0;

   TRC2(soRegExpMetaLws)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '\t':   case ' ':   yyWspBeforeCrlf = 1; goto yy3;
   case '\r':   goto yy6;
   default:   goto yyErr;
   }
yy3:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':   case ' ':   goto yy3;
   case '\r':   goto yy6;
   default:   goto yy5;
   }
yy5:
   {
      yyret = 1;
      goto yyReturn;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   goto yy7;
   default:   
      if (yyWspBeforeCrlf)
      {
         cmAbnfDecOffset(decCp, 1);
         yydecode -=1;
         goto yy5;
      }
      else
      {
         goto yyErr;
      }
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':   case ' ':   goto yy8;
   default:   
      if (yyWspBeforeCrlf)
      {
         cmAbnfDecOffset(decCp, 2);
         yydecode -=2;
         goto yy5;
      }
      else
      {
         goto yyErr;
      }
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':   case ' ':   goto yy8;
   default:   goto yy5;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* soRegExpMetaLws */

/*
*
*       Fun:   soRegExpTelUserName
*
*       Desc:  Description for the regular expression User Name
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: User = ( unreserved | escaped | "&" | "=" | "+" | "$" | "," |
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpTelUserName
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpTelUserName (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 yyRet;     /* Return value                           */
   U16 yyDecode;  /* Number of characters decoded           */

   TRC2(soRegExpTelUserName);

   /* Initialize local variables */
   yyDecode = 0;
   yyRet = RNOK;

   if ( soRegExpAlphaNumericSpecial (
            "`~_;?!$&\'+,=#%()*-./|^{}[]\\<\"", /* so028.201 : changed to decode phone-context value */
            0, FALSE, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));

}  /* End of soRegExpTelUserName */

/*
*
*       Fun:   soRegExpMetaQuestionMark
*
*       Desc:  Regular Expression for Meta Questionmark
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Determines whether "?" is present
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMetaQuestionMark
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **memPtr,   /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaQuestionMark( decCp, tknCons, memPtr, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **memPtr;   /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{

   TRC2(soRegExpMetaQuestionMark);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, memPtr, len, "?", 1, FALSE));

} /* End of soRegExpMetaQuestionMark */

/*
*
*       Fun:   soRegExpIpv6address
*
*       Desc:  Description for the regular expression IP version 6 Address
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: None
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpIpv6Address
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpIpv6Address (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif   /*ANSI*/
{
   S16   yyRet;      /* Return value                   */
   U16   yyDecode;   /* Number of characters decoded   */

   TRC2(soRegExpIpv6Address);

    /* Initializing local variables */
   yyDecode = 0;
   yyRet = RNOK;

   if ( soRegExpAlphaNumericSpecial (
            "_!,$&+;?.:",  /* include these special chars */
            0,TRUE, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpIpv6Address */


/*
*
*       Fun:   soRegExpOtherHandling
*
*       Desc:  Description for the regular expression Other Handling
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpOtherHandling
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpOtherHandling (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;  /* Number of characters decoded  */

   TRC2(soRegExpOtherHandling);

   /* Initializing local variables */
   yyDecode = 0;
   yyRet = RNOK;

   soRegExpEatSpaces(decCp, &yyDecode);
   if ( soRegExpAlphaNumericSpecial (
            "_!%*-.+`\'~",  /* include these special chars */
            0, FALSE, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpOtherHandling */


/*
*
*       Fun:   soRegExpTokenHostling
*
*       Desc:  Description for the regular expression Token Host
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpTokenHost
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpTokenHost (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;  /* Number of characters decoded  */

   TRC2(soRegExpTokenHost);

   /* Initializing local variables */
   yyDecode = 0;
   yyRet = RNOK;

   soRegExpEatSpaces(decCp, &yyDecode);
   if ( soRegExpAlphaNumericSpecial (
            "_!%*-.+`\'~[]:",  /* include these special chars */
            0, FALSE, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpTokenHost */

/*
*
*       Fun:   soRegExpHostName
*
*       Desc:  Description for the regular expression Host Name
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: HostName = *(domainlabel ".") TopLabel ["."]
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpHostName
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpHostName (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;  /* Number of characters decoded  */

   TRC2(soRegExpHostName);

   /* Initialize local variables */
   yyDecode = 0;
   yyRet = RNOK;

   if ( soRegExpAlphaNumericSpecial (
            "-",  /* include these special chars */
            1, TRUE, decCp, mem, len, &yyDecode)==ROK )
   {
      if ( soRegExpAlphaNumericSpecial (
               "-.",  /* include these special chars */
               0, FALSE, decCp, mem, len, &yyDecode)==ROK )
      {
         yyRet = ROK;
         if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
            return (-1);
      }
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpHostName */


/*
*
*       Fun:   soRegExpHName
*
*       Desc:  Description for the regular expression HName
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: HName = 1*(hnunreserved | unreserved | escaped)
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpHName
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpHName (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif   /* ANSI */
{
   S16   yyRet;      /* Return value                           */
   U16   yyDecode;   /* Number of characters decoded           */

   TRC2(soRegExpHName);

   /* Initialize local variables */
   yyDecode = 0;
   yyRet = RNOK;
   if ( soRegExpAlphaNumericSpecial (
            "-_.!~*'()%[]/?:+$",  /* include these special chars */
            0, TRUE, decCp, mem, len, &yyDecode)==ROK )
   {
         yyRet = ROK;
         if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
            return (-1);
   }
   
   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpHName */


/*
*
*       Fun:   soRegExpTransportParamChoice
*
*       Desc:  Description for the regular expression Transport Parameter
*              Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: TransportParam = ( "udp" | "tcp" | "sctp" | "tls" | OtherTransport )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpTransportParamChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpTransportParamChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{

   TRC2(soRegExpTransportParamChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChTransportParam,
            TRUE, TRUE));

}

/*
*
*       Fun:   soRegExpUserParamChoice
*
*       Desc:  Description for the regular expression User Parameter Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: UserParam = ( "phone" | "ip" | OtherUser )
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpUserParamChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpUserParamChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{

   TRC2(soRegExpUserParamChoice);

   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChUserParam,
            TRUE, TRUE));     

}  /* End of soRegExpUserParamChoice */


/*
*
*       Fun:   soRegExpPasswordText
*
*       Desc:  Description for the Password Regular Expression
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: PasswordText = *( unreserved | escaped | "&" | "=" | "+" | "$" |
*
*       File:  soTest_rx.c
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpPasswordText
(
CmAbnfDecCp *decCp,     /* Decode control point          */
Bool        tknCons,    /* Token to be consumed          */
U8          **mem,      /* Memory pointer                */
U16         *len        /* Length of the string returned */
)
#else
PUBLIC S16 soRegExpPasswordText (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;     /* Decode control point          */
Bool        tknCons;    /* Token to be consumed          */
U8          **mem;      /* Memory pointer                */
U16         *len;       /* Length of the string returned */
#endif   /* ANSI */
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpPasswordText);

   /* Initialize local variables */
   yyDecode = 0;
   yyRet = RNOK;

   if ( soRegExpAlphaNumericSpecial (
            "%&=+$,;?-_.!~*\'()",  /* include these special chars */
            0, FALSE, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpPasswordText */


/*
*
*       Fun:   soRegExpTtl
*
*       Desc:  Description for the regular expression Ttl
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Ttl = 1*3( DIGIT )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpTtl
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpTtl (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpTtl);
    
   /* Initialize local variables */
   yyDecode = 0;
   yyRet = RNOK;

   if ( soRegExpNumeric (TRUE, 3, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpTtl */


/*
*
*       Fun:   soRegExpUserName
*
*       Desc:  Description for the regular expression User Name
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: User = ( unreserved | escaped | "&" | "=" | "+" | "$" | "," |
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpUserName
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpUserName (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 yyRet;     /* Return value                           */
   U16 yyDecode;  /* Number of characters decoded           */

   TRC2(soRegExpUserName);

   /* Initialize local variables */
   yyDecode = 0;
   yyRet = RNOK;
   /* so008.102: add more speical chars */
   if ( soRegExpAlphaNumericSpecial (
            "-_.!~*'()&=+$,;?/:%",                /* Previous : "`~_;?!$&\'+,=#%()*-.:/|^{}[]\\<>\"", */
            0, FALSE, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));

}  /* End of soRegExpUserName */


/* 
 * so020.201: Modified regular  expression  to  change it character 
 *   comparison instead of string comparison. 
 *   
 *   Some of the SIP nodes usually provide loose routing indication
 *   using "lr=on" and not "lr". Althought "lr=on" is not according
 *   to specification,  we need to support it to interop with those
 *   nodes.
 *
 *   The requirement here is to decode "lr=on" parameter, but treat 
 *   it as if "lr" is received.  Basically  we need to ignore "=on" 
 *   part of it.  Please note that no change in SoEvnt structure is
 *   done.
 */
/* 
 * so029.201: Modified regular  expression  to  change it character 
 *   comparison instead of string comparison. 
 *   
 *   Some of the SIP nodes usually provide loose routing indication
 *   using "lr=true" and not "lr". Althought "lr=true" is not according
 *   to specification,  we need to support it to interop with those
 *   nodes.
 *
 *   The requirement here is to decode "lr=true" parameter, but treat 
 *   it as if "lr" is received.  Basically  we need to ignore "=true" 
 *   part of it.  Please note that no change in SoEvnt structure is
 *   done.
 */

/*
*
*       Fun:   soRegExpUrlParameterChoice
*
*       Desc:  Description for the regular expression UrlParameterChoice
*  
*     [Tt][Rr][Aa][Nn][Ss][Pp][Oo][Rr][Tt]/[ \t\r\n>;,=?]  { return(SO_URLPARAMETER_TRANSPORTPARAM); }
*     [Uu][Ss][Ee][Rr]/[ \t\r\n>;,=?]        { return(SO_URLPARAMETER_USERPARAM); }
*     [Mm][Ee][Tt][Hh][Oo][Dd]/[ \t\r\n>;,=?]  { return(SO_URLPARAMETER_METHOD); }
*     [Tt][Tt][Ll]/[ \t\r\n>;,=?]            { return(SO_URLPARAMETER_TTLPARAM); }
*     [Mm][Aa][Dd][Dd][Rr]/[ \t\r\n>;,=?]    { return(SO_URLPARAMETER_MADDRHOST); }
*     [Ll][Rr]/[ \t\r\n>;,=?]                { return(SO_URLPARAMETER_LRPARAM); }
*     [Ll][Rr]"="[Oo][Nn]/[ \t\r\n>;,=?]     { return(SO_URLPARAMETER_LRPARAM); }
*     [Ll][Rr]"="[Tt][Rr][Uu][Ee]/[ \t\r\n>;,=?]     { return(SO_URLPARAMETER_LRPARAM); }
*  
*     [Tt][Ss][Pp]/[ \t\r\n>;,=?]        {
*  #ifdef SO_PINT
*                             return(SO_URLPARAMETER_TSPDOMAIN);
*  #else
*                             return(SO_URLPARAMETER_OTHERPARAM);
*  #endif
*                                        }
*  
*     [Pp][Hh][Oo][Nn][Ee]"-"[Cc][Oo][Nn][Tt][Ee][Xx][Tt]/[ \t\r\n>;,=?] {
*  #ifdef SO_ENUM
*                           return(SO_URLPARAMETER_PHONECONTEXT);
*  #else
*                           return(SO_URLPARAMETER_OTHERPARAM);
*  #endif
*                           }
*  
*     [Ii][Ss][Uu][Bb]/[ \t\r\n>;,=?]      {
*  #ifdef SO_ENUM
*                                  return(SO_URLPARAMETER_ISUB);
*  #else
*                                  return(SO_URLPARAMETER_OTHERPARAM);
*  #endif
*                                          }
*  
*     [Pp][Oo][Ss][Tt][Dd]/[ \t\r\n>;,=?]  {
*  #ifdef SO_ENUM
*                                  return(SO_URLPARAMETER_POSTD);
*  #else
*                                  return(SO_URLPARAMETER_OTHERPARAM);
*  #endif
*                                          }
*  
*     [Cc][Oo][Mm][Pp]/[ \t\r\n>;,=?]      { return(SO_URLPARAMETER_COMP); }
*  
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpUrlParameterChoice
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 soRegExpUrlParameterChoice(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   /* Return anything else as other parameter */
   S16 yyret = SO_URLPARAMETER_OTHERPARAM;
   U16 yydecode = 0;
   

   TRC2(soRegExpUrlParameterChoice)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy9;
   case 'I':   case 'i':   goto yy8;
   case 'L':   case 'l':   goto yy6;
   case 'M':   case 'm':   goto yy5;
   case 'P':   case 'p':   goto yy7;
   case 'T':   case 't':   goto yy3;
   case 'U':   case 'u':   goto yy4;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy68;
   case 'S':   case 's':   goto yy66;
   case 'T':   case 't':   goto yy67;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy61;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy48;
   case 'E':   case 'e':   goto yy49;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy40;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy21;
   case 'O':   case 'o':   goto yy20;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy15;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ';':   case '=':
   case '>':
   case '?':   goto yy13;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = SO_URLPARAMETER_COMP;
      goto yyReturn;
    }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy16;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy17;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ';':   case '=':
   case '>':
   case '?':   goto yy18;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_ENUM
                                
      yyret = SO_URLPARAMETER_ISUB;
      goto yyReturn;
   
#else
                                
      yyret = SO_URLPARAMETER_OTHERPARAM;
      goto yyReturn;
   
#endif
                                        }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy35;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy22;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy24;
   default:   goto yyErr;
   }
yy24:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy25;
   default:   goto yyErr;
   }
yy25:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy26;
   default:   goto yyErr;
   }
yy26:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy27;
   default:   goto yyErr;
   }
yy27:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy28;
   default:   goto yyErr;
   }
yy28:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy29;
   default:   goto yyErr;
   }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy30;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy31;
   default:   goto yyErr;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy32;
   default:   goto yyErr;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ';':   case '=':
   case '>':
   case '?':   goto yy33;
   default:   goto yyErr;
   }
yy33:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_ENUM
                         
      yyret = SO_URLPARAMETER_PHONECONTEXT;
      goto yyReturn;
   
#else
                         
      yyret = SO_URLPARAMETER_OTHERPARAM;
      goto yyReturn;
   
#endif
                         }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy36;
   default:   goto yyErr;
   }
yy36:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy37;
   default:   goto yyErr;
   }
yy37:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ';':   case '=':
   case '>':
   case '?':   goto yy38;
   default:   goto yyErr;
   }
yy38:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_ENUM
                                
      yyret = SO_URLPARAMETER_POSTD;
      goto yyReturn;
   
#else
                                
      yyret = SO_URLPARAMETER_OTHERPARAM;
      goto yyReturn;
   
#endif
                                        }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ';':   case '>':
   case '?':   goto yy41;
   case '=':   goto yy43;
   default:   goto yyErr;
   }
yy41:      (++yydecode);

yy42:   
   (--yydecode);
   { 
      yyret = SO_URLPARAMETER_LRPARAM;
      goto yyReturn;
    }
yy43:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy44;
/*so029.201: Supporting lr=true*/   
   case 'T':   case 't':   goto yy83;                           
   default:   goto yy42;
   }
/*so029.201: Supporting lr=true*/   
yy83:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy84;
   default:   goto yyErr;
   }
yy84:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy85;
   default:   goto yyErr;
   }
yy85:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy45;
   default:   goto yyErr;
   }   
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy45;
   default:   goto yyErr;
   }
yy45:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ';':   case '=':
   case '>':
   case '?':   goto yy46;
   default:   goto yyErr;
   }
yy46:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = SO_URLPARAMETER_LRPARAM;
      goto yyReturn;
    }
yy48:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy56;
   default:   goto yyErr;
   }
yy49:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy50;
   default:   goto yyErr;
   }
yy50:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy51;
   default:   goto yyErr;
   }
yy51:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy52;
   default:   goto yyErr;
   }
yy52:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy53;
   default:   goto yyErr;
   }
yy53:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ';':   case '=':
   case '>':
   case '?':   goto yy54;
   default:   goto yyErr;
   }
yy54:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = SO_URLPARAMETER_METHOD;
      goto yyReturn;
    }
yy56:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy57;
   default:   goto yyErr;
   }
yy57:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy58;
   default:   goto yyErr;
   }
yy58:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ';':   case '=':
   case '>':
   case '?':   goto yy59;
   default:   goto yyErr;
   }
yy59:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = SO_URLPARAMETER_MADDRHOST;
      goto yyReturn;
    }
yy61:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy62;
   default:   goto yyErr;
   }
yy62:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy63;
   default:   goto yyErr;
   }
yy63:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ';':   case '=':
   case '>':
   case '?':   goto yy64;
   default:   goto yyErr;
   }
yy64:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = SO_URLPARAMETER_USERPARAM;
      goto yyReturn;
    }
yy66:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy81;
   default:   goto yyErr;
   }
yy67:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy78;
   default:   goto yyErr;
   }
yy68:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy69;
   default:   goto yyErr;
   }
yy69:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy70;
   default:   goto yyErr;
   }
yy70:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy71;
   default:   goto yyErr;
   }
yy71:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy72;
   default:   goto yyErr;
   }
yy72:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy73;
   default:   goto yyErr;
   }
yy73:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy74;
   default:   goto yyErr;
   }
yy74:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy75;
   default:   goto yyErr;
   }
yy75:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ';':   case '=':
   case '>':
   case '?':   goto yy76;
   default:   goto yyErr;
   }
yy76:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = SO_URLPARAMETER_TRANSPORTPARAM;
      goto yyReturn;
    }
yy78:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ';':   case '=':
   case '>':
   case '?':   goto yy79;
   default:   goto yyErr;
   }
yy79:      (++yydecode);

       
   (--yydecode);
   { 
      yyret = SO_URLPARAMETER_TTLPARAM;
      goto yyReturn;
    }
yy81:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case ',':   case ';':   case '=':
   case '>':
   case '?':   goto yy82;
   default:   goto yyErr;
   }
yy82:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_PINT
                           
      yyret = SO_URLPARAMETER_TSPDOMAIN;
      goto yyReturn;
   
#else
                           
      yyret = SO_URLPARAMETER_OTHERPARAM;
      goto yyReturn;
   
#endif
                                      }



yyReturn:

yyErr:
   /* so021.201: we do not have to consume the strings for unknown
    *            parameter. So for such cases set tknCons as FALSE. */
   if (SO_URLPARAMETER_OTHERPARAM == yyret)
      tknCons = FALSE;

   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* soRegExpUrlParameterChoice */


/*
*
*       Fun:   soRegExpHeaderExt
*
*       Desc:  Description for the regular expression Header Extension
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Determines whether Header Extension is present
*
*       File:  soRegExpHeaderExt
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpHeaderExt
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpHeaderExt (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   TRC2(soRegExpHeaderExt);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, mem, len, "&", 1, FALSE));

}  /* End of soRegExpHeaderExt */

#ifdef SO_ENUM
/*
*
*       Fun:   soRegExpTelUrlOpt2
*
*       Desc:  Description for the regular expression Tel Url Option 2
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Determines whether TelUserInfoAt is present
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpTelUrlOpt2
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpTelUrlOpt2 (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 yych;      /* Character to be decoded                */
   S16 yyRet;     /* Return value                           */
   U16 yyDecode;  /* Number of characters decoded           */

   /* Initializing local variables */
   yyDecode = 0;
   yyRet = RNOK;

   if ( soRegExpAlphaNumericSpecial (
            "_?!$&\'+,=#%()*-.:",  /* include these special chars */
            0, FALSE, decCp, mem, len, &yyDecode)==ROK )
   {
      yych = cmAbnfGetChar(decCp->offset);
      if (( yych == ' ' ) || ( yych == ';' ) || 
          ( yych == '\r') || ( yych == '>'))
      {
         yyRet = ROK;
         if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
            return (-1);
      }
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));

}  /* End of soRegExpTelUrlOpt2 */
#endif /* SO_ENUM */

/*
*
*       Fun:   soRegExpUserInfo
*
*       Desc:  Description for the regular expression Sip Url Option 2
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Determines whether UserInfoAt is present
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpUserInfo
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpUserInfo (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 yych;      /* Character to be decoded                */
   S16 yyRet;     /* Return value                           */
   U16 yyDecode;  /* Number of characters decoded           */

   /* Initializing local variables */
   yyDecode = 0;
   yyRet = RNOK;
   /* so008.102: add more speical chars */
   if ( soRegExpAlphaNumericSpecial (
            "-_.!~*'()&=+$,;?/:%",     /* #" from dtmf-digit : Previous : "`~_;?!$&\'+,=#%()*-.:/|^{}[]\\<>\"", */
            0, FALSE, decCp, mem, len, &yyDecode)==ROK )
   {
      yych = cmAbnfGetChar(decCp->offset);
      if ( yych == '@' ) 
      {
         yyRet = ROK;
         if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
            return (-1);
      }
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));

}  /* End of soRegExpUserInfo */

#ifdef SO_EVENT
#ifdef SO_REFER
/*
*
*       Fun:   soRegExpReplacesParam
*
*       Desc:  Description for the regular expression to check Replaces header
*              type
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: 
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpReplacesParam
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpReplacesParam(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;  

   TRC2(soRegExpReplacesParam);

   /* Initialize local variable */
   s = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChReplacesParamType,
                           TRUE, TRUE);   

   RETVALUE(s);
}  /* End of soRegExpReplacesParam */

#endif /* SO_REFER */
#endif /* SO_EVENT */

/* so038: Added the function for moving the expires,q,tags as the 
 * contact params in stead of Url Parameters*/

/*
*
*       Fun:   soRegExpCheckUrlParameters
*
*       Desc:  Description for the regular expression CheckUrlParameters
*                 SEM = [;];
*                 TAG = (SEM [tT][aA][gG]);
*                 EXP = (SEM [eE][xX][pP][iI][rR][eE][sS]);
*                 QVAL = (SEM [qQ]); 
*              
*                 ( TAG | EXP | QVAL)  {return(ROK);} 
*                 
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PRIVATE S16 soRegExpCheckUrlParameters
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PRIVATE S16 soRegExpCheckUrlParameters(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif

{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(soRegExpCheckUrlParameters)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case ';':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy6;
   case 'Q':   case 'q':   goto yy4;
   case 'T':   case 't':   goto yy7;
   default:   goto yyErr;
   }
yy4:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

{
      yyret = ROK;
      goto yyReturn;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy9;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy8;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy4;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy11;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy12;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy13;
   default:   goto yyErr;
   }
yy13:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy4;
   default:   goto yyErr;
   }



yyReturn:
   CM_ABNF_DEC_CSPSTRXL(decCp, mem, len, yydecode);

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* soRegExpCheckUrlParameters */

/*
*
*       Fun:   soRegExpUrlParameters
*
*       Desc:  Description for the regular expression Url Parameters
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Determines whether UrlParameters are present
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpUrlParameters
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpUrlParameters (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   TRC2(soRegExpUrlParameters);

   /* so038: Added the function for moving the expires,q,tags as the 
    * contact params in stead of Url Parameters*/
   yyRet = soRegExpCheckUrlParameters(decCp,tknCons , mem, len);
   if(yyRet != ROK)
   {
      if (soRegExpStrCmp(decCp, TRUE, mem, len, ";", 1, TRUE) == ROK)
      {
         /* Handle the consumed ';' */
         yyDecode++;

         soRegExpEatSpaces(decCp, &yyDecode);

         yyRet = ROK;
      }
   }
   else
      yyRet = RNOK ;

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpUrlParameters */


/*
*
*       Fun:   soRegExpSipUrlOpt5
*
*       Desc:  Description for the regular expression Sip Url Option 5
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Determines whether Headers are present
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpSipUrlOpt5
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpSipUrlOpt5 (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   TRC2(soRegExpSipUrlOpt5);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, mem, len, "?", 1, FALSE));

}  /* End of soRegExpSipUrlOpt5 */


/*
*
*       Fun:   soRegExpAddrTypeChoice
*
*       Desc:  ipaddress discrimination
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: Ipv4Address | Ipv6Address
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpAddrTypeChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **memPtr,           /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpAddrTypeChoice (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **memPtr;           /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif   /* ANSI */
{
   S16   yych;             /* Character to be decoded       */
   S16   yyRet    = SO_HOST_IPV4ADDRESS;  /* Return value   */
   U16   yyDecode = 0;     /* Number of characters decoded  */

   TRC2(soRegExpAddrTypeChoice);

   yych = cmAbnfGetChar(decCp->offset);

   while (!((yych == '\t') || (yych == '\r') || (yych == '\n') ||
          (yych == ' ') || (yych == ';') || (yych == ',')))
   {
      if (((yych >= 'a') && (yych <= 'f')) ||
          ((yych >= 'A') && (yych <= 'F')) ||
          (yych == ':'))
      {
         yyRet = SO_HOST_IPV6REFERENCE;  /* its an IPv6address */
         break;
      }

      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));

}  /* End of soRegExpAddrTypeChoice */

/*
*
*       Fun:   soRegExpHostChoice
*
*       Desc:  Description for the regular expression Host discrimination
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: Host = HostName | Ipv4Address | Ipv6Address
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpHostChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **memPtr,           /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpHostChoice (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **memPtr;           /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif   /* ANSI */
{
   S16   yych;                /* Character to be decoded       */
   S16   yyRet    = RNOK;  /* Return value                  */
   U16   yyDecode = 0;     /* Number of characters decoded  */
   U16   yyNumDig = 0;     /* Number of DIGIT s */
   U16   yyNumOcc = 0;     /* Number of occurance of 1*3DIGIT s */

   TRC2(soRegExpHostChoice);

   yych = cmAbnfGetChar(decCp->offset);

   if (yych == '[')
   {
      yyRet = SO_HOST_IPV6REFERENCE;
      goto yyReturn;
   }
   else
   {

      while (yyNumOcc < 3)
      {
         yyNumDig = 0;

         while ((yych >= '0') && (yych <= '9'))
         {
            yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
            yyDecode++;
            yyNumDig++;
         }

         if ((yych == '.') && (yyNumDig >= 1) && (yyNumDig <= 3))
         {
            yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
            yyDecode++;
            yyNumOcc++;
         }
         else
         {
            yyRet = SO_HOST_HOSTNAME;
            goto yyReturn;
         }

      }


     yyNumDig = 0;

     while ((yych >= '0') && (yych <= '9'))
     {
        yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
        yyDecode++;
        yyNumDig++;
     }

     /* so038.201 : Added "," in the regular expression for Host */
     if (((yych == ':') || (yych == ';') || (yych == '?') ||
          (yych == '>') || (yych == ' ') || (yych == ',') || (yych == '\t') ||
          (yych == '\r') || (yych == '\n'))
         && (yyNumDig >= 1) && (yyNumDig <= 3))
     {
        yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
        yyRet = SO_HOST_IPV4ADDRESS;
        yyDecode++;
     }
     else
     {
        yyRet = SO_HOST_HOSTNAME;
        goto yyReturn;
     }

   }

yyReturn:

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));

}  /* End of soRegExpHostChoice */


/*
*
*       Fun:   soSipRegExpPPort
*
*       Desc:  Description for the regular expression Port
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: PPort = 1*(DIGIT)
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpPPort
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpPPort (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 yyRet;     /* Return value                  */
   U16 yyDecode;  /* Number of characters decoded  */

   TRC2(soRegExpPPort);

   /* Initialize local variables */
   yyDecode = 0;
   yyRet = RNOK;

   if ( soRegExpNumeric (TRUE, 0, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
} /* soSipRegExpPort */


/*
*
*       Fun:   soRegExpMetaDot
*
*       Desc:  Description for the regular expression Meta Dot
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Determines whether "." is present
*
*       File:  so_rx.c
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMetaDot
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **memPtr,   /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaDot( decCp, tknCons, memPtr, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **memPtr;   /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   TRC2(soRegExpMetaDot);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, memPtr, len, ".", 1, FALSE));

} /* End of soRegExpMetaDot */

/*
*
*       Fun:   soRegExpMethodStdChoice
*
*       Desc:  Description for the regular expression Method text
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: MethodStd = ("INVITE" | "ACK" | "OPTIONS" | "BYE" | "CANCEL" |
*                          "REGISTER" | "INFO" | "COMET" | "PRACK" | "REFER" )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMethodStdChoice
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMethodStdChoice ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif   /* ANSI */
{
   /* so002.102 */
   S16 ret;

   TRC2(soRegExpMethodStdChoice);

   ret = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChMethod,
            FALSE, FALSE);

#ifndef SO_INSTMSG
   if (ret == SO_METHODSTD_MESSAGE)
      ret = SO_METHODSTD_MAX;
#endif  /* SO_INSTMSG */

/* so005.102: related changes with SO_EVENT flag */
#ifndef SO_EVENT
   if ((ret == SO_METHODSTD_SUBSCRIBE) || (ret == SO_METHODSTD_NOTIFY))
      ret = SO_METHODSTD_MAX;
#endif  /* SO_EVENT */

   RETVALUE(ret);
}  /* End of soRegExpMethodStdChoice */


/*
*
*       Fun:   soRegExpWkDayChoice
*
*       Desc:  Description for the regular expression Weekday Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: WkDay = ("Mon" | "Tue" | "Wed" | "Thu" | "Fri" | "Sat" | "Sun")
*
*       File:  so_rx.c
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpWkDayChoice
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpWkDayChoice ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   TRC2(soRegExpWkDayChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChWkDay,
            FALSE, FALSE));

}  /* End of soRegExpWkDayChoice */


/*
*
*       Fun:   soRegExpMetaComma
*
*       Desc:  Description for the regular expression Meta Comma
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Determines whether "," is present
*
*       File:  so_rx.c
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMetaComma
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaComma ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yych;       /* Character to be decoded          */
   S16   yyRet;      /* Return value                     */
   U16   yyDecode;   /* Number of characters decoded     */

   TRC2(soRegExpMetaComma);

   /* Initialize local variables */
   yyRet    = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\r')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\n')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == ',')
   {
      if(soAbnfDecChkLen(len, yyDecode))
         RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;

      while ((yych == ' ') || (yych == '\t'))
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      if (yych == '\r')
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      if (yych == '\n')
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      while ((yych == ' ') || (yych == '\t'))
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

   /* so001.102: eat the space before comma */
   /*
   soRegExpAllSpaceEater(decCp, tknCons, mem, len);

   ret = soRegExpStrCmp(decCp, tknCons, mem, len, ",", 1, FALSE);

   */
   /* so001.102: eat the space after comma */
   /*
   soRegExpAllSpaceEater(decCp, tknCons, mem, len); 

   RETVALUE(ret);

   */




}  /* End of soRegExpMetaComma */


/*
*
*       Fun:   soRegExpMetaSpace
*
*       Desc:  Description for the regular expression Meta Space
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Determines whether " " is present
*
*       File:  so_rx.c
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMetaSpace
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaSpace ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   TRC2(soRegExpMetaSpace);

   soRegExpSpaceEater (decCp, tknCons, mem, len);

   if ((soRegExpStrCmp(decCp, tknCons, mem, len, "\t", 1, FALSE) == ROK) ||
       (soRegExpStrCmp(decCp, tknCons, mem, len, " ", 1, FALSE) == ROK))
      RETVALUE(ROK);

   RETVALUE(RNOK);
}  /* End of soRegExpMetaSpace */

/*
*
*       Fun:   soRegExpDay
*
*       Desc:  Description for the regular expression Day
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Day = 2 DIGIT
*
*       File:  so_rx.c
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpDay
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpDay ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpDay);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpNumeric (TRUE, 2, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpDay */


/*
*
*       Fun:   soRegExpMonthChoice
*
*       Desc:  Description for the regular expression Month Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: month = ("Jan" | "Feb" | "Mar" | "Apr" | "May" | "Jun" | "Jul" |
*                       "Aug" | "Sep" | "Oct" | "Nov" | "Dec" )
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMonthChoice
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMonthChoice ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   TRC2(soRegExpMonthChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChMonth,
            FALSE, FALSE));

}  /* End of soRegExpMonthChoice */


/*
*
*       Fun:   soRegExpYear
*
*       Desc:  Description for the regular expression Year
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: year = 4 DIGIT
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpYear
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpYear ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yyRet;      /* Return Value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpYear);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpNumeric (TRUE, 4, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpYear */


/*
*
*       Fun:   soRegExpHr
*
*       Desc:  Description for the regular expression Hour
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: hr = 2 DIGIT
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpHr
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpHr ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpPPort);

   /* Initialize local variables */
   yyDecode = 0;
   yyRet = RNOK;

   if ( soRegExpNumeric (TRUE, 2, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /*End of soRegExpHr */


/*
*
*       Fun:   soRegExpMn
*
*       Desc:  Description for the regular expression Minutes
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: mn = 2 DIGIT
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMn
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMn ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpMn);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpNumeric (TRUE, 2, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpMn */


/*
*
*       Fun:   soRegExpSec
*
*       Desc:  Description for the regular expression Seconds
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: sec = 2 DIGITS
*
*       File:  so_rx.c
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpSec
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpSec ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpSec);

   /* Initialize the local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpNumeric (TRUE, 2, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpSec */



/*
*
*       Fun:   soRegExpGMT
*
*       Desc:  Description for the regular expression GMT
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Determines whether "GMT" is present
*
*       File:  so_rx.c
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpGMT
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpGMT ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   TRC2(soRegExpGMT);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, mem, len, "GMT", 3, FALSE));

}  /* End of soRegExpGMT */


/*
*
*       Fun:   soRegExpUserAgentListChoice
*
*       Desc:  Description for the regular expression soRegExpUserAgentListChoice
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpUserAgentListChoice
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 soRegExpUserAgentListChoice(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpUserAgentListChoice);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   /* Need to check if another Product/Comment is present 
      1. If (not End of Header) : Product/Comment
      3. Else : End of Header */

   if (yych != '\r')
   {
      if ((yych != '\t') && ((yych != ' ')))
      {
         /* This is the case when SWS was not added from Comment and 
         LWS is eaten by comment as SWS. Go back one step. */
         yyDecode++;
      }
      /* Not end of Header, return ROK */
      yyRet = ROK;
   }
   else
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;

      if (yych != '\n')
      {
         /* Not end of Header, return ROK */
         yyRet = ROK;
      }
      else
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;

         if ((yych == ' ') || (yych == '\t'))
         {
            /* LWS present, return ROK */
            yyRet = ROK;
         }
      }
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
} /* soRegExpUserAgentListChoice */


/* so006.102: New Function to verify that end of headers has reached. */

/*
*
*       Fun:   soRegExpNotMetaCRLF
*
*       Desc:  Description for the regular expression NotMetaCRLF
*              
*                      a=[\r\n];
*                      (a)(a)     {return(-1);}
*                      (a)        {return(-1);}
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpNotMetaCRLF
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 soRegExpNotMetaCRLF(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = 1;
   U16 yydecode = 0;
   

   TRC2(soRegExpNotMetaCRLF)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '\n':   case '\r':   goto yy3;

   /*
    * If the text string has ended, return an error
    */
   case -1:   yyret = -1;   /* fall through */
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   case '\r':   goto yy5;

   /*
    * If the text string has ended, return an error
    */
   case -1:   yyret = -1;   /* fall through */
   default:   goto yy4;
   }
yy4:
   {
      yyret = -1;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = -1;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* soRegExpNotMetaCRLF */

/*
*
*       Fun:   soRegMetaCRLF
*
*       Desc:  Description for the regular expression Meta CRLF
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Checks for "\n", "\r" and combinations thereof
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMetaCRLF
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaCRLF ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yych;    /* Character to be decoded       */
   S16   yyRet;   /* Return value                  */
   U16   yyDecode;/* Number of characters decoded  */

   TRC2(soRegExpMetaCRLF);

   /* Initialize local variables */
   yyDecode = 0;
   yyRet = RNOK;

   yych = cmAbnfGetChar(decCp->offset);

   while ((yych==' ') || (yych == '\t'))
   {
      if(soAbnfDecChkLen(len, yyDecode))
        RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\n')
   {
      if(soAbnfDecChkLen(len, yyDecode))
        RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
      if (yych == '\r')
      {
         if(soAbnfDecChkLen(len, yyDecode))
           RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }
      if(soAbnfDecChkLen(len, yyDecode))
        RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }
   else if (yych == '\r')
   {
      if(soAbnfDecChkLen(len, yyDecode))
        RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
      if (yych == '\n')
      {
         if(soAbnfDecChkLen(len, yyDecode))
           RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         /* so005.102 */
         if (yych != -1)
            yyDecode++;
      }
      if(soAbnfDecChkLen(len, yyDecode))
        RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpMetaCRLF */


/*
*
*       Fun:   soRegExpMethodChoice
*
*       Desc:  Description for the regular expression Method Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: Method = MethodStd | ExtensionMethod
*
*       File:  so_rx.c
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMethodChoice
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMethodChoice ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yyRet;   /* Return value */

   TRC2(soRegExpMethodChoice);

   /* Initialize local variables */
   yyRet = RNOK;

   yyRet = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChMethod,
                              FALSE, TRUE);

   /* so002.102 */
#ifndef SO_INSTMSG
   if (yyRet == SO_METHODSTD_MESSAGE)
      yyRet = SO_METHODSTD_MAX;
#endif /* SO_INSTMSG */

/* so005.102: related changes with SO_EVENT flag */
#ifndef SO_EVENT
   if ((yyRet == SO_METHODSTD_SUBSCRIBE) || (yyRet == SO_METHODSTD_NOTIFY))
      yyRet = SO_METHODSTD_MAX;
#endif  /* SO_EVENT */

#ifndef SO_REFER
   if (yyRet == SO_METHODSTD_REFER) 
      yyRet = SO_METHODSTD_MAX;
#endif  /* SO_REFER */

#ifndef SO_RFC_3262
   if (yyRet == SO_METHODSTD_PRACK)
      yyRet = SO_METHODSTD_MAX;
#endif  /* SO_EVENT */

#ifndef SO_UPDATE
   if (yyRet == SO_METHODSTD_UPDATE)
      yyRet = SO_METHODSTD_MAX;
#endif  /* SO_UPDATE */

   if(yyRet < SO_METHODSTD_MAX)
      yyRet = SO_METHOD_METHODSTD;
   else
      yyRet = SO_METHOD_EXTENSIONMETHOD;

   RETVALUE(yyRet);

}  /* End of soRegExpMethodChoice */


/*
*
*       Fun:   soRegExpFrac
*
*       Desc:  Description for the regular expression Fraction
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Frac = 0*3(DIGIT)
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpFrac
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpFrac ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpFrac);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpNumeric (TRUE, 3, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpFrac */


/*
*
*       Fun:   soRegExpMetaDQuote
*
*       Desc:  Description for the regular expression Double quote
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Checks for """
*
*       File:  so_rx.c
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpMetaDQuote
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpMetaDQuote ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   TRC2(soRegExpMetaDQuote);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, mem, len, "\"", 1, FALSE));

}  /* End of soRegExpMetaDQuote */


/*
*
*       Fun:   soRegExpPName
*
*       Desc:  Description for the regular expression pName
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: pName = 1*( hnunreserved | unreserved | escaped )
*
*       File:  so_rx.c
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpPName
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpPName ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpPName);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   /* so013.102: add "_" in regular expression for pname */
   if ( soRegExpAlphaNumericSpecial (
            "[]/:&+$-_.!~*'%()",  /* include these special chars */
            1, TRUE, decCp, mem, len, &yyDecode)==ROK )
   {
      if ( soRegExpAlphaNumericSpecial (
               "[]/:&+$-_.!~*'%()",  /* include these special chars */
               0, FALSE, decCp, mem, len, &yyDecode)==ROK )
      {
         yyRet = ROK;
         if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
            return (-1);
      }
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpPName */



/*
*
*       Fun:   soRegExpQuotedStr
*
*       Desc:  Description for the regular expression QuotedStr
*              
*                 DQUOTE = ["];
*                 CRLF =  "\r\n";
*                 WSP  =  [ \t];
*                 LWS  =  ((WSP)* CRLF)? (WSP)+;
*              
*                 UT8C       =  [\200-\277];
*              
*                 UT8NASC   =           ([\300-\337]  UT8C) |
*                                       ([\340-\357]  UT8C UT8C) |
*                                       ([\360-\367]  UT8C UT8C UT8C) |
*                                       ([\370-\373]  UT8C UT8C UT8C UT8C) |
*                                       ([\374-\375]  UT8C UT8C UT8C UT8C UT8C);
*              
*                 qdtext         =  LWS | [\041] | [\043-\133] | [\0135-\176] | UT8NASC;
*              
*                 QuotedPair1  =  "\\";
*                 QuotedPair2  =  ( [\000-\011] | [\013-\014] | [\016-\177] );
*                 QuotedPair   =  (QuotedPair1) (QuotedPair2);
*              
*                 QuotedString  =  DQUOTE (qdtext | QuotedPair)* DQUOTE;
*              
*                 QuotedString     {return(1);}
*              
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpQuotedStr
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 soRegExpQuotedStr(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   U8  yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(soRegExpQuotedStr)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '"':   goto yy3;
   default:   goto yyErr;
   }
yy3:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':   case ' ':
   case '!':   case '#':
   case '$':
   case '%':
   case '&':
   case '\'':
   case '(':
   case ')':
   case '*':
   case '+':
   case ',':
   case '-':
   case '.':
   case '/':
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':
   case ':':
   case ';':
   case '<':
   case '=':
   case '>':
   case '?':
   case '@':
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':
   case '{':
   case '|':
   case '}':
   case '~':   goto yy3;
   case '\r':   goto yy5;
   case '"':   goto yy12;
   case '\\':   goto yy11;
   case (U8)('\300'):
   case (U8)('\301'):
   case (U8)('\302'):
   case (U8)('\303'):
   case (U8)('\304'):
   case (U8)('\305'):
   case (U8)('\306'):
   case (U8)('\307'):
   case (U8)('\310'):
   case (U8)('\311'):
   case (U8)('\312'):
   case (U8)('\313'):
   case (U8)('\314'):
   case (U8)('\315'):
   case (U8)('\316'):
   case (U8)('\317'):
   case (U8)('\320'):
   case (U8)('\321'):
   case (U8)('\322'):
   case (U8)('\323'):
   case (U8)('\324'):
   case (U8)('\325'):
   case (U8)('\326'):
   case (U8)('\327'):
   case (U8)('\330'):
   case (U8)('\331'):
   case (U8)('\332'):
   case (U8)('\333'):
   case (U8)('\334'):
   case (U8)('\335'):
   case (U8)('\336'):
   case (U8)('\337'):   goto yy6;
   case (U8)('\340'):
   case (U8)('\341'):
   case (U8)('\342'):
   case (U8)('\343'):
   case (U8)('\344'):
   case (U8)('\345'):
   case (U8)('\346'):
   case (U8)('\347'):
   case (U8)('\350'):
   case (U8)('\351'):
   case (U8)('\352'):
   case (U8)('\353'):
   case (U8)('\354'):
   case (U8)('\355'):
   case (U8)('\356'):
   case (U8)('\357'):   goto yy7;
   case (U8)('\360'):
   case (U8)('\361'):
   case (U8)('\362'):
   case (U8)('\363'):
   case (U8)('\364'):
   case (U8)('\365'):
   case (U8)('\366'):
   case (U8)('\367'):   goto yy8;
   case (U8)('\370'):
   case (U8)('\371'):
   case (U8)('\372'):
   case (U8)('\373'):   goto yy9;
   case (U8)('\374'):
   case (U8)('\375'):   goto yy10;
   default:   goto yyErr;
   }
yy5:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   goto yy24;
   default:   goto yyErr;
   }
yy6:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy3;
   default:   goto yyErr;
   }
yy7:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy23;
   default:   goto yyErr;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy21;
   default:   goto yyErr;
   }
yy9:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy18;
   default:   goto yyErr;
   }
yy10:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy14;
   default:   goto yyErr;
   }
yy11:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\000'):
   case (U8)('\001'):
   case (U8)('\002'):
   case (U8)('\003'):
   case (U8)('\004'):
   case (U8)('\005'):
   case (U8)('\006'):
   case '\a':
   case '\b':
   case '\t':   case '\v':
   case '\f':   case (U8)('\016'):
   case (U8)('\017'):
   case (U8)('\020'):
   case (U8)('\021'):
   case (U8)('\022'):
   case (U8)('\023'):
   case (U8)('\024'):
   case (U8)('\025'):
   case (U8)('\026'):
   case (U8)('\027'):
   case (U8)('\030'):
   case (U8)('\031'):
   case (U8)('\032'):
   case (U8)('\033'):
   case (U8)('\034'):
   case (U8)('\035'):
   case (U8)('\036'):
   case (U8)('\037'):
   case ' ':
   case '!':
   case '"':
   case '#':
   case '$':
   case '%':
   case '&':
   case '\'':
   case '(':
   case ')':
   case '*':
   case '+':
   case ',':
   case '-':
   case '.':
   case '/':
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':
   case ':':
   case ';':
   case '<':
   case '=':
   case '>':
   case '?':
   case '@':
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':
   case '\\':
   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':
   case '{':
   case '|':
   case '}':
   case '~':
   case (U8)('\177'):   goto yy3;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = 1;
      goto yyReturn;
   }
yy14:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy15;
   default:   goto yyErr;
   }
yy15:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy16;
   default:   goto yyErr;
   }
yy16:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy17;
   default:   goto yyErr;
   }
yy17:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy3;
   default:   goto yyErr;
   }
yy18:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy19;
   default:   goto yyErr;
   }
yy19:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy20;
   default:   goto yyErr;
   }
yy20:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy3;
   default:   goto yyErr;
   }
yy21:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy22;
   default:   goto yyErr;
   }
yy22:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy3;
   default:   goto yyErr;
   }
yy23:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case (U8)('\200'):
   case (U8)('\201'):
   case (U8)('\202'):
   case (U8)('\203'):
   case (U8)('\204'):
   case (U8)('\205'):
   case (U8)('\206'):
   case (U8)('\207'):
   case (U8)('\210'):
   case (U8)('\211'):
   case (U8)('\212'):
   case (U8)('\213'):
   case (U8)('\214'):
   case (U8)('\215'):
   case (U8)('\216'):
   case (U8)('\217'):
   case (U8)('\220'):
   case (U8)('\221'):
   case (U8)('\222'):
   case (U8)('\223'):
   case (U8)('\224'):
   case (U8)('\225'):
   case (U8)('\226'):
   case (U8)('\227'):
   case (U8)('\230'):
   case (U8)('\231'):
   case (U8)('\232'):
   case (U8)('\233'):
   case (U8)('\234'):
   case (U8)('\235'):
   case (U8)('\236'):
   case (U8)('\237'):
   case (U8)('\240'):
   case (U8)('\241'):
   case (U8)('\242'):
   case (U8)('\243'):
   case (U8)('\244'):
   case (U8)('\245'):
   case (U8)('\246'):
   case (U8)('\247'):
   case (U8)('\250'):
   case (U8)('\251'):
   case (U8)('\252'):
   case (U8)('\253'):
   case (U8)('\254'):
   case (U8)('\255'):
   case (U8)('\256'):
   case (U8)('\257'):
   case (U8)('\260'):
   case (U8)('\261'):
   case (U8)('\262'):
   case (U8)('\263'):
   case (U8)('\264'):
   case (U8)('\265'):
   case (U8)('\266'):
   case (U8)('\267'):
   case (U8)('\270'):
   case (U8)('\271'):
   case (U8)('\272'):
   case (U8)('\273'):
   case (U8)('\274'):
   case (U8)('\275'):
   case (U8)('\276'):
   case (U8)('\277'):   goto yy3;
   default:   goto yyErr;
   }
yy24:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':   case ' ':   goto yy3;
   default:   goto yyErr;
   }



yyReturn:
   CM_ABNF_DEC_CSPSTRXL(decCp, mem, len, yydecode);

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* soRegExpQuotedStr */


/*
*
*       Fun:   soRegExpUserTypeChoice
*
*       Desc:  Description for the regular expression User Type Choice
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: UserType = ( User | Telephonesubscriber )
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpUserTypeChoice
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpUserTypeChoice ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpUserTypeChoice);

   yyRet = RNOK;
   yyDecode = 0;
   /* so008.102: add more speical chars */
   if ( soRegExpAlphaNumericSpecial (
            "-_.!~*'()&=+$,;?/:%",        /* Previous : "`~_;?!$&\'+,=#%()*-./|^{}[]\\<>\"", */
            1, TRUE, decCp, mem, len, &yyDecode)==ROK )
   {
      if ( soRegExpAlphaNumericSpecial (
            "-_.!~*'()&=+$,;?/:%",        /* Previous : "`~_;?!$&\'+,=#%()*-./|^{}[]\\<>\"", */
               0, FALSE, decCp, mem, len, &yyDecode)==ROK )
      {
         yyRet = SO_USERTYPE_USER;
         if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
            return (-1);
      }
   }   

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpUserTypeChoice */


/*
*
*       Fun:   soRegExpQVInt
*
*       Desc:  Description for the regular expression Q Value Integer
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: QVInt = "0" | "1"
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpQVInt
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpQVInt ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yych;       /* Character to be decoded          */
   S16   yyRet;      /* Return Value                     */
   U16   yyDecode;   /* Number of characters decoded     */

   TRC2(soRegExpQVInt);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   switch(yych)
   {
      case '0':
      case '1': goto yy1;
      default : goto yyErr;
   }

yy1:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   yyRet = ROK;
   goto yyReturn;

yyReturn:
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

yyErr:
   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpQVInt */

/*
*
*       Fun:   soRegExpGenericParamOptChoice
*
*       Desc:  Description for the regular expression Generic Parameter
*              Optional Choice
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Distinguish between quoted string and a token
*
*       Notes: None
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpGenericParamOptChoice
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpGenericParamOptChoice ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpGenericParamOptChoice);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   while ((yych == ' ') || (yych == '\t'))
   {  
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\r')
   {  
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\n')
   {  
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   while ((yych == ' ') || (yych == '\t'))
   {  
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '"')
   {
      if(soAbnfDecChkLen(len, yyDecode))
          RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

      yyRet = SO_PARAMVAL_QUOTEDSTR;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }
   else 
   {
      if(soAbnfDecChkLen(len, yyDecode))
          RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

      yyRet = SO_PARAMVAL_TOKEN;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpGenericParamOptChoice */


/*
*
*       Fun:   soRegExpActionChoice
*
*       Desc:  Description for the regular expression Action Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: Action = ("proxy" | "redirect")
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpActionChoice
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpActionChoice ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   TRC2(soRegExpActionChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChAction,
            FALSE, FALSE));

}  /* End of soRegExpActionChoice */

/*
*
*       Fun:   soRegExpExtensionMethod
*
*       Desc:  Description for the regular expression Extension Method
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: ExtensionMethod = token
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpExtensionMethod
(
CmAbnfDecCp *decCp,     /* Decode control point             */
Bool        tknCons,    /* Token to be comsumed             */
U8          **mem,      /* memory pointer                   */
U16         *len        /* length of string to be returned  */
)
#else
PUBLIC S16 soRegExpExtensionMethod ( decCp, tknCons, mem, len )
CmAbnfDecCp *decCp;     /* Decode control point             */
Bool        tknCons;    /* Token to be comsumed             */
U8          **mem;      /* memory pointer                   */
U16         *len;       /* length of string to be returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpExtensionMethod);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpAlphaNumericSpecial (
            "_-.!%*+~`'",  /* include these special chars */
            0, TRUE, decCp, mem, len, &yyDecode)==ROK )
   {
         yyRet = ROK;
         if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
            return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpExtensionMethod */

/*
*
*       Fun:   soRegExpDisplayNameRep
*
*       Desc:  Description for the regular expression Display Name Repetition
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Determines whether DisplayName is present
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpDisplayNameRep
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpDisplayNameRep (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16   yyRet;      /* Return value                   */
   U16   yyDecode;   /* Number of characters decoded   */

   TRC2(soRegExpDisplayNameRep);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   soRegExpEatSpaces(decCp, &yyDecode);
   if ( soRegExpAlphaNumericSpecial (
            "-.!%*_'`+~",  /* include these special chars */
            1, TRUE, decCp, mem, len, &yyDecode)==ROK )
   {
      if ( soRegExpAlphaNumericSpecial (
               "-.!%*_'`+~",  /* include these special chars */
               0, FALSE, decCp, mem, len, &yyDecode)==ROK )
      {
         yyRet = ROK;
         if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
            return (-1);
      }
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* soRegExpDisplayNameRep */


/*
*
*       Fun:   soRegExpScheme
*
*       Desc:  Description for the regular expression Scheme
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Scheme = ALPHA * (ALPHA | DIGIT | "+" | "-" | "." )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpScheme
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpScheme (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpScheme);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   if (((yych>='A') && (yych<='Z')) || ((yych>='a') && (yych<='z')))
   {
      if(soAbnfDecChkLen(len, yyDecode))
         RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
     
      if ( soRegExpAlphaNumericSpecial (
               "+-.",  /* include these special chars */
               0, FALSE, decCp, mem, len, &yyDecode)==ROK )
      {
         yyRet = ROK;
         if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
            return (-1);
      }
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpScheme */


/*
*
*       Fun:   soRegExpContactParamStdChoice
*
*       Desc:  Description for the regular expression Standard Contact
*              parameter choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: ContactParamStd = ( QValStd | ActionStd | ExpireStd )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpContactParamStdChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpContactParamStdChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   TRC2(soRegExpContactParamStdChoice);
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChContactParamStd,
            TRUE, FALSE));    

}  /* End of soRegExpContactParamStdChoice */

/*
*
*       Fun:   soRegExpAbsUriDesc
*
*       Desc:  Description for the regular expression Absolute Uri Description
*              Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: AbsUriDesc = ( HierPart | OpaquePart )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpAbsUriDesc
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpAbsUriDesc (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yyRet;      /* Return value                     */
   U16   yyDecode;   /* Number of characters decoded     */

   TRC2 (soRegExpAbsUriDesc);

   /* Initialize local variables */
   yyRet = RNOK; 
   yyDecode = 0;

   if ( soRegExpAlphaNumericSpecial (
            "-_.!~*'()&=+$,;?/:%@[]",      /* "-_.!~*'()&=+$,;?/:%@" "~%!$&\'()*+,-._:;=?@",  include these special chars */
            0, TRUE, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpAbsUriDesc */


/*
*
*       Fun:   soRegExpValueChoice
*
*       Desc:  Description for the regular expression Value Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: value = token | quotedStr
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpValueChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpValueChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpValueChoice);

   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   if (yych == '"')
   {
      if(soAbnfDecChkLen(len, yyDecode))
          RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

      yyRet = SO_VALUE_QUOTEDSTR;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }
   else 
   {
      if(soAbnfDecChkLen(len, yyDecode))
          RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

      yyRet = SO_VALUE_TOKEN;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpValueChoice */

#ifdef SO_CALLERPREF
/*
*
*       Fun:   soRegExpRequestDispositionChoice
*
*       Desc:  Description for the regular expression Request-Disposition type 
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: 
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpRequestDispositionChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpRequestDispositionChoice(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 retVal;

   TRC2(soRegExpRequestDispositionChoice);
    
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   retVal = soRegExpChoiceCmp(decCp, tknCons, mem, len, 
            soChRequestDispositionValStd, TRUE, FALSE);    

   if(retVal > 0)
   {
       retVal = (retVal+1)/2;
   }
   RETVALUE(retVal);

}  /* End of soRegExpContentCodingChChoice */

/*
*
*       Fun:   soRegExpProxyChoice
*
*       Desc:  Description for the regular expression proxy-feature type 
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: 
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpProxyChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpProxyChoice(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   TRC2(soRegExpProxyChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, 
            soChAction, FALSE, FALSE));

}  /* End of soRegExpProxyChoice */

/*
*
*       Fun:   soRegExpCancelChoice
*
*       Desc:  Description for the regular expression cancel-feature type 
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: 
*
*       File:  so_rx
*/
#ifdef ANSI
PUBLIC S16 soRegExpCancelChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpCancelChoice(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   TRC2(soRegExpCancelChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, 
            soChCancelValStd, FALSE, FALSE));

}  /* End of soRegExpCancelChoice */

/*
*
*       Fun:   soRegExpForkChoice
*
*       Desc:  Description for the regular expression fork-feature type 
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: 
*
*       File:  so_rx
*/
#ifdef ANSI
PUBLIC S16 soRegExpForkChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpForkChoice(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   TRC2(soRegExpForkChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, 
            soChForkValStd, FALSE, FALSE));

}  /* End of soRegExpForkChoice */

/*
*
*       Fun:   soRegExpRecurseChoice
*
*       Desc:  Description for the regular expression recurse-feature type 
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: 
*
*       File:  so_rx
*/
#ifdef ANSI
PUBLIC S16 soRegExpRecurseChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpRecurseChoice(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   TRC2(soRegExpRecurseChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, 
            soChRecurseValStd, FALSE, FALSE));

}  /* End of soRegExpRecurseChoice */

/*
*
*       Fun:   soRegExpParallelChoice
*
*       Desc:  Description for the regular expression parallel-feature type 
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: 
*
*       File:  so_rx
*/
#ifdef ANSI
PUBLIC S16 soRegExpParallelChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpParallelChoice(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   TRC2(soRegExpParallelChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, 
            soChParallelValStd, FALSE, FALSE));

}  /* End of soRegExpParallelChoice */

/*
*
*       Fun:   soRegExpQueueChoice
*
*       Desc:  Description for the regular expression queue-feature type 
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: 
*
*       File:  so_rx
*/
#ifdef ANSI
PUBLIC S16 soRegExpQueueChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpQueueChoice(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   TRC2(soRegExpQueueChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, 
            soChQueueValStd, FALSE, FALSE));

}  /* End of soRegExpQueueChoice */
#endif /* SO_CALLERPREF */

/*
*
*       Fun:   soRegExpCallInfoPurposeChoice
*
*       Desc:  Description for the regular expression Call Information
*              Purpose Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: CallInfoPurpose = "purpose=" ("icon" | "info" | "card" |
*                                            PurposeExt )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpCallInfoPurposeChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpCallInfoPurposeChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   TRC2(soRegExpCallInfoPurposeChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChCallInfoPurpose,
            FALSE, TRUE));

}  /* End of soRegExpCallInfoPurposeChoice */

/*
*
*       Fun:   soRegExpDisplayNameChoice
*
*       Desc:  Description for the regular expression Display Name choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: DisplayName = *(token) | quotedStr
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpDisplayNameChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpDisplayNameChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpDisplayNameChoice);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   if (yych == '"')
   {
      if(soAbnfDecChkLen(len, yyDecode))
          RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

      yyRet = 2;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }
   else 
   {
      if(soAbnfDecChkLen(len, yyDecode))
          RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

      yyRet = 1;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpDisplayNameChoice */


/*
*
*       Fun:   soRegExpContactParamChoice
*
*       Desc:  Description for the regular expression Contact Parameter Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: ContactParam = ( ContactParamStd | ContactExtension )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpContactParamChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpContactParamChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 ret;

   TRC2(soRegExpContactParamChoice);

   /* Initialize local variable */
   ret = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   ret = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChContactParam,
            TRUE, TRUE);      
   
   if (ret == RNOK)
   {
      if (len)
      {
         cmAbnfDecOffset((decCp), (*len));
         *len = 0;
      }
      RETVALUE(SO_CONTACTPARAM_EXTN);
   }

   if ((ret >=1) && (ret <=3))
   {
      ret = SO_CONTACTPARAM_STD;
   }
#ifdef SO_CALLERPREF
   else if ((ret >=4) && (ret <=22))
   {
      ret = SO_CONTACTPARAM_FEAT;
   }
#endif /* SO_CALLERPREF */
   else
   {
      ret = SO_CONTACTPARAM_EXTN;
   }

   RETVALUE(ret);

}  /* End of soRegExpContactParamChoice */


/*
*
*       Fun:   soRegExpMetaForwardSlash
*
*       Desc:  Description for the regular expression Meta Forward Slash
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Check for "/"
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMetaForwardSlash
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpMetaForwardSlash (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpMetaForwardSlash);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\r')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\n')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '/')
   {
      if(soAbnfDecChkLen(len, yyDecode))
         RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;

      while ((yych == ' ') || (yych == '\t'))
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      if (yych == '\r')
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      if (yych == '\n')
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      while ((yych == ' ') || (yych == '\t'))
      {
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }

      yyRet = 0;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

}  /* End of soRegExpMetaForwardSlash */



/*
*
*       Fun:   soRegExpMetaStar
*
*       Desc:  Description for the regular expression Meta Star
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Checks for "*"
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMetaStar
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpMetaStar (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   TRC2(soRegExpMetaStar);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, mem, len, "*", 1, FALSE));

}  /* End of soRegExpMetaStar */

/*
*
*       Fun:   soRegExpMetaLeftAngleBracket
*
*       Desc:  Description for the regular expression Meta Left AngleBracket
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Checks for "<"
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMetaLeftAngleBracket
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpMetaLeftAngleBracket (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   TRC2(soRegExpMetaLeftAngleBracket);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, mem, len, "<", 1, FALSE));

}  /* End of soRegExpMetaLeftAngleBracket */

/*
*
*       Fun:   soRegExpHandlingParmValstdChoice
*
*       Desc:  Description for the regular expression Handling parameter
*              Standard choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: HandlingParmValstd = ("optional" | "required")
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpHandlingParmValstdChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpHandlingParmValstdChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpHandlingParmValstdChoice);

   /* Initialize local variable */
   s = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */  
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChHandlingParmStd,
                           TRUE, FALSE);     
   
   RETVALUE(s);
}  /* End of soRegExpHandlingParmValstdChoice */


/*
*
*       Fun:   soRegExpMetaRightAngleBracket
*
*       Desc:  Description for the regular expression Meta Right Angle Bracket
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Checks for ">"
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMetaRightAngleBracket
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpMetaRightAngleBracket (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   TRC2(soRegExpMetaRightAngleBracket);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, mem, len, ">", 1, FALSE));

}  /* End of soRegExpMetaRightAngleBracket */

/*
*
*       Fun:   soRegExpContentCodingChChoice
*
*       Desc:  Description for the regular expression Content Coding Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: ContentCoding = (("gzip" | "compress" | "deflate" | "identity")
*                               | ExtensionToken)
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpContentCodingChChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpContentCodingChChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   TRC2(soRegExpContentCodingChChoice);
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */
   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChContentCoding,
            TRUE, FALSE));    
   
}  /* End of soRegExpContentCodingChChoice */

/*
*
*       Fun:   soRegExpInfoParamChoice
*
*       Desc:  Description for the regular expression Info parameter choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: InfoParam = CallInfoPurpose | GenericParam
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpInfoParamChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpInfoParamChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpInfoParamChoice);

   /* Initialize local variable */
   s = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChInfoParam,
                           TRUE, TRUE);     
   
   RETVALUE(s);
}  /* End of soRegExpInfoParamChoice */

/*
*
*       Fun:   soRegExpSIP
*
*       Desc:  Description for the regular expression SIP
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Checks for "SIP"
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpSIP
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpSIP (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   TRC2(soRegExpSIP);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, mem, len, "SIP", 3, FALSE));

}  /* End of soRegExpSIP */

/*
*
*       Fun:   soRegExpSIPFS
*
*       Desc:  Description for the regular expression SIP
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Checks for "SIP/"
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpSIPFS
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpSIPFS (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   TRC2(soRegExpSIPFS);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, mem, len, "SIP/", 4, TRUE));

}  /* End of soRegExpSIPFS */


/*
*
*       Fun:   soRegExpTransportStdChoice
*
*       Desc:  Description for the regular expression Standard Transport Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: TransportStd = "UDP" | "TCP" | "udp" | "tcp"
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpTransportStdChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpTransportStdChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   TRC2(soRegExpTransportStdChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChTransportStd,
            TRUE, FALSE));

}  /* End of soRegExpTransportStdChoice */


/*
*
*       Fun:   soRegExpViaParamChoice
*
*       Desc:  Description for the regular expression Via parameter choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: ViaParam = "hidden" | ViaTtl | ViaMaddr | ViaReceived |
*                         ViaBranch | ViaExtension
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpViaParamChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpViaParamChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   /* so007.201: Changes for rport support */
   S16 ret;   /* Return value */

   TRC2(soRegExpViaParamChoice);

   /* Initialize local variable */
   ret = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */
   ret = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChViaParam,
            TRUE, TRUE);     
   
   RETVALUE(ret);
}  /* End of soRegExpViaParamChoice */


/*
*
*       Fun:   soRegExpHandlingParmValChoice
*
*       Desc:  Description for the regular expression Handling parameter value
*              Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: HandlingParmVal = (HandlingParmValstd | OtherHandling)
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpHandlingParmValChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpHandlingParmValChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yyRet;      /* Return value                  */

   TRC2(soRegExpHandlingParmValChoice);

   yyRet = RNOK;

   /* so030.201: 
    * Checking case insensitiveness of Parameter */
   yyRet = soRegExpChoiceCmp(decCp, tknCons, mem, len, 
                        soChHandlingParmStd, TRUE, TRUE); 
   if ( yyRet == RNOK )
      RETVALUE(RNOK);
   else if ( yyRet > SO_HANDLINGPARMVALSTD_REQUIRED )
      RETVALUE(SO_DISP_PARAM_HANDLING_NONSTD);
   else RETVALUE(SO_DISP_PARAM_HANDLING_STD);

}  /* End of soRegExpHandlingParmValChoice */


/*
*
*       Fun:   soRegExpMediaRangeValChoice
*
*       Desc:  Description for the regular expression MediaRangeValChoice
*              
*              
*                mtype = [a-zA-Z0-9-.!%*_+`'~]+;
*              
*                [*][ \t\r\n]*[/][ \t\r\n]*[*]               {return(1);}
*                mtype[ \t\r\n]*[/][ \t\r\n]*[*]             {return(2);}
*                mtype[ \t\r\n]*[/][ \t\r\n]*mtype           {return(3);}
*              
*              
*              
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMediaRangeValChoice
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 soRegExpMediaRangeValChoice(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(soRegExpMediaRangeValChoice)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '!':   case '%':   case '\'':   case '+':   case '-':
   case '.':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   case '~':   goto yy4;
   case '*':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '!':   case '%':   case '\'':   case '*':
   case '+':   case '-':
   case '.':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   case '~':   goto yy4;
   default:   goto yy16;
   }
yy4:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   goto yy6;
   case '!':   case '%':   case '\'':   case '*':
   case '+':   case '-':
   case '.':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   case '~':   goto yy4;
   case '/':   goto yy8;
   default:   goto yyErr;
   }
yy6:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   goto yy6;
   case '/':   goto yy8;
   default:   goto yyErr;
   }
yy8:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   goto yy8;
   case '!':   case '%':   case '\'':   case '+':   case '-':
   case '.':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   case '~':   goto yy12;
   case '*':   goto yy10;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '!':   case '%':   case '\'':   case '*':
   case '+':   case '-':
   case '.':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   case '~':   goto yy12;
   default:   goto yy11;
   }
yy11:
   {
      yyret = 2;
      goto yyReturn;
   }
yy12:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '!':   case '%':   case '\'':   case '*':
   case '+':   case '-':
   case '.':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   case '~':   goto yy12;
   default:   goto yy14;
   }
yy14:
   {
      yyret = 3;
      goto yyReturn;
   }
yy15:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy16:   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   goto yy15;
   case '/':   goto yy17;
   default:   goto yyErr;
   }
yy17:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   goto yy17;
   case '!':   case '%':   case '\'':   case '+':   case '-':
   case '.':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   case '~':   goto yy12;
   case '*':   goto yy19;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '!':   case '%':   case '\'':   case '*':
   case '+':   case '-':
   case '.':   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   case '~':   goto yy12;
   default:   goto yy20;
   }
yy20:
   {
      yyret = 1;
      goto yyReturn;
   }





yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* soRegExpMediaRangeValChoice */


/*
*
*       Fun:   soRegExpParameters
*
*       Desc:  Description for the regular expression Parameters
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Searches for >>SWS ";" SWS "q" SWS "="<< If this pattern is
*              found then it implies accept-param since the first accept-param
*              is started with "q" SWS "="
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpParameters
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpParameters (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpParameters);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   /* SWS */
   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\r')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\n')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   switch(yych)
   {
      case ';': goto yy1;
      default : goto yyErr;
   }

yy1:

   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;

   /* SWS */

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\r')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\n')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   goto yy2;

yy2:
   switch(yych)
   {
      case 'q': goto yy3;
      default : goto yy4;
   }

yy3:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;

   /* SWS */

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\r')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\n')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   switch(yych)
   {
      case '=': goto yyErr;
      default : goto yy4;
   }

yy4:
   yyRet = 0;
   goto yyReturn;

yyReturn:
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

yyErr:
   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

}  /* End of soRegExpParameters */


/*
*
*       Fun:   soRegExpContentCodingChoice
*
*       Desc:  Description for the regular expression Content Coding Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Makes a choice between standard Content coding and ContentCoding
*              Extension
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpContentCodingChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpContentCodingChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 ret;

   TRC2(soRegExpContentCodingChoice);
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */
   ret = soRegExpChoiceCmp(decCp, tknCons, mem, len, 
                        soChContentCoding, TRUE, TRUE); 
   if (ret < 0)
      RETVALUE(RNOK);
   else if ( ret > 4 )
      RETVALUE(2);
   else RETVALUE(1);
      
}  /* End of soRegExpContentCodingChoice */


/*
*
*       Fun:   soRegExpAddrChChoice
*
*       Desc:  Description for the regular expression Contact Address-choice
*              Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: ContactAddrChoice = ( NameAddr | AddrSpec )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpAddrChChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpAddrChChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpAddrChChoice);

   /* Initialize local variables */
   yyRet = 2;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   if (yych == '"')
   {
      yyRet = 1;
      goto yyReturn;
   }

   while ((yych != -1) && (yych != ':'))
   {
      if (yych == '<')
      {
         yyRet = 1;
         goto yyReturn;
      }

      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

yyReturn:

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpAddrChChoice */


/*
*
*       Fun:   soRegExpProtocolNameChoice
*
*       Desc:  Description for the regular expression Protocol Name Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: ProtocolName = "SIP" | ProtocolExt
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpProtocolNameChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpProtocolNameChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   TRC2(soRegExpProtocolNameChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChProtocolName,
            FALSE, TRUE));

}  /* End of soRegExpProtocolNameChoice */


/*
*
*       Fun:   soRegExpTransportChoice
*
*       Desc:  Description for the regular expression Transport Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: Transport = TransportStd | TransportExt
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpTransportChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpTransportChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16  yyRet;

   TRC2(soRegExpTransportChoice);

   yyRet = soRegExpChoiceCmp(decCp, tknCons, mem, len, 
                        soChTransportStd, TRUE, TRUE);
   if ( yyRet < 0 )
      RETVALUE(RNOK);
   else if ( yyRet < 5)
      RETVALUE(SO_TRANSPORT_TRANSPORTSTD);
   else RETVALUE(SO_TRANSPORT_TRANSPORTEXT);
      

}  /* End of soRegExpTransportChoice */


/*
*
*       Fun:   soRegExpComment
*
*       Desc:  Description for the regular expression Comment
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Comment = "(" *(ctext | quotedpair) ")"
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpComment
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpComment (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */
   S16   flag;       /* Flag for end of comment       */

   Bool yySlash = FALSE;
   TRC2(soRegExpComment);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   switch(yych)
   {
      case '(': goto yya;
      default : goto yyErr;
   }

yya:
   flag = 1;
   goto yy1;

yy1:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   goto yy2;

yy2:
   while (yych != -1)
   {
      if(yych == '(')
      {
         if (yySlash != TRUE)
            flag++;
         yySlash = FALSE;
      }
      else if(yych == ')')
      {
         if (yySlash != TRUE)
            flag--;
         yySlash = FALSE;
      }
      else if ((yych == '\\') && (yySlash == FALSE))
         yySlash = TRUE;
      else 
         yySlash = FALSE;

      if(flag == (S16) 0)
         goto yy3;

      /* Removed check for range limit, everything between 
       * the brackets will be taken as comment for optimisation
      */
      /*
      if ((yych<0x20)||(yych>253))
         if (!((yych == '\r') || (yych == '\n') || (yych == '\t') || (yych == ' ')))
            goto yyErr;
      */

      if(soAbnfDecChkLen(len, yyDecode))
         goto yyErr;
      soAbnfDecChcpy(mem, yych);

      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

yy3:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   yyRet = 0;
   goto yyReturn;

yyReturn:
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

yyErr:
   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpComment */

/*
*
*       Fun:   soRegExpCodingsChoice
*
*       Desc:  Description for the regular expression Codings Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: Codings = ( ContentCoding | "*" )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpCodingsChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpCodingsChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpCodingsChoice);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   if (yych == '*')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
      if ((yych == '\r') || (yych == '\n') || (yych == '\t') ||
          (yych == ' ') || (yych == ';') || (yych == ','))
      {
         yyRet = 2;
      }
      else
      {
         yyRet = 1;
      }
   }
   else
   {
      yyRet = 1;
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpCodingsChoice */


/*
*
*       Fun:   soRegExpLanguageRange
*
*       Desc:  Description for the regular expression Language range
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: LanguageRange  = ( ( 1*8(ALPHA) *( "-" 1*8(ALPHA) ) ) | "*" )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpLanguageRange
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpLanguageRange (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded        */
   S16   yyRet;      /* Return value                   */
   U16   yyDecode;   /* Number of characters decoded   */
   S8    num;        /* Number of Characters           */

   TRC2(soRegExpLanguageRange);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;
   num = 0;

   yych = cmAbnfGetChar(decCp->offset);
  
   if (yych == '*') goto yy1;
   else if (((yych>='A') && (yych<='Z')) || 
            ((yych>='a') && (yych<='z'))) 
      goto yy2;
   else goto yyErr;

yy1:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   yyRet = 0;
   goto yyReturn;

yy2:
   for(num=0;num<8;num++)
   {
      if(soAbnfDecChkLen(len, yyDecode))
         goto yyErr;
      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;

      if(yych == '-')
         goto yy3;
      if((yych < 65)||(yych > 90))
      {
         if((yych < 97)||(yych > 122))
         {
            yyRet = 0;
            goto yyReturn;
         }
      }
   }

yy3:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   goto yy2;

yyReturn:
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

yyErr:
   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpLanguageRange */


PUBLIC Txt *soChAddrPar[] =
{
   "tag",
   NULL
}; /* End of soChRefresherPar  */


/*
*
*       Fun:   soRegExpAddrParamChoice
*
*       Desc:  Description for the regular expression Address Parameter Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: AddrParam = TagParam | GenericParam
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpAddrParamChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpAddrParamChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpAddrParamChoice);

   /* Initialize local variable */
   s = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChAddrPar,
                           TRUE, TRUE);      
   
   RETVALUE(s);
}  /* End of soRegExpAddrParamChoice */

/*
*
*       Fun:   soRegExpSentByChoice
*
*       Desc:  Description for the regular expression Sent By Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: SentBy = HostPort | ConcealedHost
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpSentByChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpSentByChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpSentByChoice);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpAlphaNumericSpecial (
            "-.!%*_\'~[",  /* include these special chars */
            0, TRUE, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = 1;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpSentByChoice */

/*
*
*       Fun:   soRegExpViaComment
*
*       Desc:  Description for the regular expression Via Comment
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Checks for "("
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpViaComment
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpViaComment (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   TRC2(soRegExpViaComment);

   RETVALUE(soRegExpStrCmp(decCp, tknCons, mem, len, "(", 1, FALSE));

}  /* End of soRegExpViaComment */


PUBLIC Txt *soChDispTypePar[] =
{
   "handling",
   NULL
}; /* End of soChDispTypePar  */

/*
*
*       Fun:   soRegExpDispositionParamChoice
*
*       Desc:  Description for the regular expression Disposition Param Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: DispositionParam = ( HandlingParm | Parameter )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpDispositionParamChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpDispositionParamChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpDispositionParamChoice);

   /* Initialize local variable */
   s = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChDispTypePar,
                           TRUE, TRUE);      
   
   RETVALUE(s);
}  /* End of soRegExpDispositionParamChoice */


PUBLIC Txt *soChRetryPar[] =
{
   "duration",
   NULL
}; /* End of soChRetryPar  */

/*
*
*       Fun:   soRegExpRetryParamChoice
*
*       Desc:  Description for the regular expression Retry parameter Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: RetryParam = RetryDuration | GenericParam
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpRetryParamChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpRetryParamChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpRetryParamChoice)

   /* Initialize local variable */
   s = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChRetryPar,
                           TRUE, TRUE);      
   
   RETVALUE(s);
}  /* End of soRegExpRetryParamChoice */


/*
*
*       Fun:   soRegExpWarnCode
*
*       Desc:  Description for the regular expression Warn Code
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: WarnCode = 3*3(DIGIT)
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpWarnCode
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpWarnCode (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */
   U16   atMost;             /* not more than n digits         */

   TRC2(soRegExpWarnCode);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;
   atMost = 3;

   yych = cmAbnfGetChar(decCp->offset);

   while ((atMost>0) &&
          ((yych>='0') && (yych<='9')))
   {
      if (soAbnfDecChkLen(len,yyDecode))
         RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
   
      soAbnfDecChcpy(mem,yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      (yyDecode)++;
      atMost--;
   }
      
   if (atMost == 0)
   {
      yyRet = 0;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpWarnCode */


/*
*
*       Fun:   soRegExpWarnAgent
*
*       Desc:  Description for the regular expression Warn Agent Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: WarnAgent = HostPort| Pseudonym
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpWarnAgent
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpWarnAgent (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;  /* Number of characters decoded  */

   TRC2(soRegExpWarnAgent);

   /* Initializing local variables */
   yyDecode = 0;
   yyRet = RNOK;

   soRegExpEatSpaces(decCp, &yyDecode);
   if ( soRegExpAlphaNumericSpecial (
            "_!%*-.+`\'~[]:",  /* include these special chars */
            0, FALSE, decCp, mem, len, &yyDecode)==ROK )
   {  
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK)
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpWarnAgent */

/*
*
*       Fun:   soRegExpProdcomChoice
*
*       Desc:  Description for the regular expression Product Comment Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: Prodcom = (Product | Comment )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpProdcomChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpProdcomChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of decoded characters  */

   TRC2(soRegExpProdcomChoice);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   /* If token, it is a product rule, else it is a comment rule */
   if ((((yych>='0') && (yych<='9')) ||
        ((yych>='A') && (yych<='Z')) ||
        ((yych>='a') && (yych<='z')) ||
        (strchr("-.!%*_+`\'~", yych)!=NULL)))
   {
      if(soAbnfDecChkLen(len, yyDecode))
         RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
      yyRet = 1;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }
   else
      yyRet = 2;

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpProdcomChoice */

/*
*
*       Fun:   soRegExpSubjectTxt
*
*       Desc:  Description for the regular expression Subject Text
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: SubjectTxt = *(TEXTUTF8TRIM)
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpSubjectTxt
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpSubjectTxt (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */
   U16   num;        /* Number of characters          */
   U16   i;          /* Counter                       */

   TRC2(soRegExpSubjectTxt);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;
   num = 0;

   yych = cmAbnfGetChar(decCp->offset);

yy0:
   num++;
   if((yych >= 0x20)&&(yych <= 0x7e))
      goto yy1;
   if((yych >= 0xc0)&&(yych <= 0xdf))
      goto yy2;
   if((yych >= 0xe0)&&(yych <= 0xef))
      goto yy3;
   if((yych >= 0xf0)&&(yych <= 0xf7))
      goto yy4;
   if((yych >= 0xf8)&&(yych <= 0xfb))
      goto yy5;
   if((yych >= 0xfc)&&(yych <= 0xfd))
      goto yy6;
   if(num > 1)
   {
      switch(yych)
      {
         case ' ':
         case '\t': goto yy1;
         default  : goto yy7;
      }
   }

   goto yy7;

yy1:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   goto yy0;

yy2:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;

   if((yych >= 0x80)&&(yych <= 0xbf))
   {
      if(soAbnfDecChkLen(len, yyDecode))
         goto yyErr;
      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }
   else
      goto yy7;

   goto yy0;

yy3:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;

   for (i=0; i<2; i++)
   {
      if((yych >= 0x80)&&(yych <= 0xbf))
      {
         if(soAbnfDecChkLen(len, yyDecode))
            goto yyErr;
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }
      else
         goto yy7;
   }

   goto yy0;

yy4:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   
   for (i=0; i<3; i++)
   {
      if((yych >= 0x80)&&(yych <= 0xbf))
      {
         if(soAbnfDecChkLen(len, yyDecode))
            goto yyErr;
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }
      else
         goto yy7;
   }

   goto yy0;

yy5:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;

   for (i=0; i<4; i++)
   {
      if((yych >= 0x80)&&(yych <= 0xbf))
      {
         if(soAbnfDecChkLen(len, yyDecode))
            goto yyErr;
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }
      else
         goto yy7;
   }

   goto yy0;

yy6:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;

   for (i=0; i<5; i++)
   {
      if((yych >= 0x80)&&(yych <= 0xbf))
      {
         if(soAbnfDecChkLen(len, yyDecode))
            goto yyErr;
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }
      else
         goto yy7;
   }

   goto yy0;

yy7:
   yyRet = 0;
   goto yyReturn;

yyReturn:
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

yyErr:
   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpSubjectTxt */


/*
*
*       Fun:   soRegExpLanguageTag
*
*       Desc:  Description for the regular expression LanguageTag
*              
*                 [a-zA-Z]+ ( "-" [a-zA-Z]+ )*          {return(1);}
*              
*              
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpLanguageTag
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 soRegExpLanguageTag(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(soRegExpLanguageTag)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy3;
   default:   goto yyErr;
   }
yy3:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy6;
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy3;
   default:   goto yy5;
   }
yy5:
   {
      yyret = 1;
      goto yyReturn;
   }
yy6:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yyErr;
   }
yy7:   
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy6;
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto yy7;
   default:   goto yy5;
   }





yyReturn:
   CM_ABNF_DEC_CSPSTRXL(decCp, mem, len, yydecode);

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* soRegExpLanguageTag */

/*
*
*       Fun:   soRegExpContactDescChoice
*
*       Desc:  Description for the regular expression Contact Descriptor Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: ContactDesc = ("*" | ContactItems)
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpContactDescChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpContactDescChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpContactDescChoice);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   if (yych == '*')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;

      if ((yych == ' ') || (yych == '\t') || (yych == '\n') || (yych == '\r'))
      {
         if(soAbnfDecChkLen(len, yyDecode))
            RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
   
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
         yyRet = 1;
         if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
            return (-1);
      }
      else
      {
         if(soAbnfDecChkLen(len, yyDecode))
            RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

         yyRet = 2;
         if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
            return (-1);
      }
   }
   else 
   {
      if(soAbnfDecChkLen(len, yyDecode))
         RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

      yyRet = 2;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpContactDescChoice */


/*
*
*       Fun:   soRegExpAddrParams
*
*       Desc:  Description for the regular expression AddrParams
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: AddrParams = *( ";" AddrParam )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpAddrParams
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpAddrParams (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */
   U16   spaces;     /* Number of spaces found        */

   TRC2(soRegExpAddrParams);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;
   spaces = 0;

   yych = cmAbnfGetChar(decCp->offset);

yy0:
   if (yych == ';')
      goto yy2;

   if ((yych != ' ') && (yych != '\t'))
      goto yyErr;

   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   spaces++;
   goto yy0;

yy2:
   yyRet = 0;
   goto yyReturn;

yyReturn:
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

yyErr:
   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpAddrParams */


/*
*
*       Fun:   soRegExpMimeVersionVal
*
*       Desc:  Description for the regular expression MIME-version value
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: MimeVersionVal = NaturalValue "." NaturalValue
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMimeVersionVal
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpMimeVersionVal (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpMimeVersionVal);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpNumeric (TRUE, 0, decCp, mem, len, &yyDecode)==ROK )
   {
      yych = cmAbnfGetChar(decCp->offset);

      if (yych == '.')
      {
          if(soAbnfDecChkLen(len, yyDecode))
             RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
 
          soAbnfDecChcpy(mem, yych);
          yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
          yyDecode++;
          yyRet = soRegExpNumeric (FALSE, 0, decCp, mem, len, &yyDecode);
      }
      yyRet = 0;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpMimeVersionVal */

/*
*
*       Fun:   soRegExpOrganizationVal
*
*       Desc:  Description for the regular expression Organization Value
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: OrganizationVal = *(TEXTUTF8TRIM)
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpOrganizationVal
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpOrganizationVal (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */
   U16   num;        /* Number of characters          */
   U16   i;          /* Counter                       */

   TRC2(soRegExpOrganizationVal);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;
   num = 0;

   yych = cmAbnfGetChar(decCp->offset);

yy0:
   num++;
   if((yych >= 0x21)&&(yych <= 0x7e))
      goto yy1;
   if((yych >= 0xc0)&&(yych <= 0xdf))
      goto yy2;
   if((yych >= 0xe0)&&(yych <= 0xef))
      goto yy3;
   if((yych >= 0xf0)&&(yych <= 0xf7))
      goto yy4;
   if((yych >= 0xf8)&&(yych <= 0xfb))
      goto yy5;
   if((yych >= 0xfc)&&(yych <= 0xfd))
      goto yy6;
   if(num > 1)
   {
      switch(yych)
      {
         case ' ':
         case '\t': goto yy1;
         default  : goto yy7;
      }
   }

yy1:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   goto yy0;

yy2:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;

   if((yych >= 0x80)&&(yych <= 0xbf))
   {
      if(soAbnfDecChkLen(len, yyDecode))
         goto yyErr;
      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }
   else
      goto yyErr;

   goto yy0;

yy3:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;

   for (i=0; i<2; i++)
   {
      if((yych >= 0x80)&&(yych <= 0xbf))
      {
         if(soAbnfDecChkLen(len, yyDecode))
            goto yyErr;
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }
      else
         goto yyErr;
   }

   goto yy0;

yy4:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;

   for (i=0; i<3; i++)
   {
      if((yych >= 0x80)&&(yych <= 0xbf))
      {
         if(soAbnfDecChkLen(len, yyDecode))
            goto yyErr;
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }
      else
         goto yyErr;
   }

   goto yy0;

yy5:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;

   for (i=0; i<4; i++)
   {
      if((yych >= 0x80)&&(yych <= 0xbf))
      {
         if(soAbnfDecChkLen(len, yyDecode))
            goto yyErr;
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }
      else
         goto yyErr;
   }

   goto yy0;

yy6:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;

   for (i=0; i<5; i++)
   {
      if((yych >= 0x80)&&(yych <= 0xbf))
      {
         if(soAbnfDecChkLen(len, yyDecode))
            goto yyErr;
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
      }
      else
         goto yyErr;
   }

   goto yy0;

yy7:
   yyRet = 0;
   goto yyReturn;

yyReturn:
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

yyErr:
   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpOrganizationVal */


/*
*
*       Fun:   soRegExpPriorityChoice
*
*       Desc:  Description for the regular expression Priority Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: Priority = ( "emergency" | "urgent" | "normal" | "non-urgent" |
*                           OtherPriority )
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpPriorityChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpPriorityChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   TRC2(soRegExpPriorityChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChPriority,
            FALSE, TRUE));

}  /* End of soRegExpPriorityChoice */


/*
*
*       Fun:   soRegExpResponseKeyVal
*
*       Desc:  Description for the regular expression Response key value
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: ResponseKeyVal = KeyScheme 1*SP 1# KeyParam CRLF
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpResponseKeyVal
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpResponseKeyVal (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpResponseKeyVal);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpAlphaNumericSpecial (
         "-.!%*_\'=\";~",  /* include these special chars */
         1, TRUE, decCp, mem, len, &yyDecode)==ROK )
   {
      if ( soRegExpAlphaNumericSpecial (
            "-.!%*_\'=\"; ~",  /* include these special chars */
            0, FALSE, decCp, mem, len, &yyDecode)==ROK )
      {
         yyRet = 0;
         if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
            return (-1);
      }
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpResponseKeyVal */


/*
*
*       Fun:   soRegExpDispositionTypeChoice
*
*       Desc:  Description for the regular expression Content Disposition Type
*              Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: DispositionType = ("session" | "render" | DispositionTypeExt)
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpDispositionTypeChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpDispositionTypeChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   TRC2(soRegExpDispositionTypeChoice);
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChDispositionType,
            TRUE, TRUE));    

}  /* End of soRegExpDispositionTypeChoice */


/*
*
*       Fun:   soRegExpResponseNum
*
*       Desc:  Description for the regular expression Response Number
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: ResponseNum = 1*DIGIT
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpResponseNum
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpResponseNum (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpResponseNum);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpNumeric (TRUE, 0, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = 0;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpResponseNum */


/*
*
*       Fun:   soRegExpCSeqNum
*
*       Desc:  Description for the regular expression CSeq Number
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: CSeqNum = 1*DIGIT
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpCSeqNum
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpCSeqNum (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpCSeqNum);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpNumeric (TRUE, 0, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = 0;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpCSeqNum */

/*
*
*       Fun:   soRegExpRetryAfterComment
*
*       Desc:  Description for the regular expression Retry-After Comment
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Checks for "("
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpRetryAfterComment
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpRetryAfterComment (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpRetryAfterComment);

   /* Initialize local variables */
   yyRet = RNOK; 
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\r')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\n')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '(')
   {
      if(soAbnfDecChkLen(len, yyDecode))
         RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;

      yyRet = 0;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK)
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpRetryAfterComment */

/*
*
*       Fun:   soRegExpVersionVal
*
*       Desc:  Description for the regular expression Version value
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: VersionVal = 1*(DIGIT) "." 1*(DIGIT)
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpVersionVal
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpVersionVal (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpVersionVal);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpNumeric (TRUE, 0, decCp, mem, len, &yyDecode)==ROK )
   {
      yych = cmAbnfGetChar(decCp->offset);

      if (yych == '.')
      {
          if(soAbnfDecChkLen(len, yyDecode))
             RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
 
          soAbnfDecChcpy(mem, yych);
          yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
          yyDecode++;
          yyRet = soRegExpNumeric (FALSE, 0, decCp, mem, len, &yyDecode);
      }
      yyRet = 0;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpVersionVal */



/*
*
*       Fun:   soRegExpEncryption
*
*       Desc:  Description for the regular expression Encryption
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Encryption = "Encryption:" EncryptionScheme 1*SP
*                           # EncryptionParams CRLF
*
*       File:  so_rx
*
*/
#ifdef ANSI
PUBLIC S16 soRegExpEncryption
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpEncryption (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpEncryption);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpAlphaNumericSpecial (
         "-.!%*_\'=\";~",  /* include these special chars */
         1, TRUE, decCp, mem, len, &yyDecode)==ROK )
   {
      if ( soRegExpAlphaNumericSpecial (
            "-.!%*_\'=\"; ~",  /* include these special chars */
            0, FALSE, decCp, mem, len, &yyDecode)==ROK )
      {
         yyRet = 0;
         if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
            return (-1);
      }
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpEncryption */


/*
*
*       Fun:   soRegExpHeaderChoice
*
*       Desc:  Description for the regular expression Header Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: A choice between all possible headers
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpHeaderChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpHeaderChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 ret;   /* Return value */

   TRC2(soRegExpHeaderChoice)

   /* Initialize local variable */
   ret = RNOK;

   /* so006.102: Calling an optimized function to compare given header */
                     
   ret = soRegExpCompareHeader (decCp, tknCons, mem, len);

   /* If the return value is RNOK, this must be a generic header */
   if (ret == RNOK)
   {
      RETVALUE(SO_HEADER_GEN_EXTENSION);
   }
   
   /* If any header not supported, return GenExtension */
   /* Move it CompareHeader later for optimization */
    
   soRegExpAllSpaceEater (decCp, tknCons, mem, len);

   RETVALUE(ret);

}  /* End of soRegExpHeaderChoice */


/*
*
*       Fun:   soRegExpReasonPhrase
*
*       Desc:  Description for the regular expression Reason Phrase
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: ReasonPhrase = *(TEXTUTF8TRIM)
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpReasonPhrase
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpReasonPhrase (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */
   Bool  haveAtleastOneChar;

   TRC2(soRegExpReasonPhrase);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   haveAtleastOneChar = FALSE;
   yych = cmAbnfGetChar(decCp->offset);

   while ((yych>=0) && (yych<=253) && 
         (yych != 10) && (yych != 13))
   {
      haveAtleastOneChar = TRUE;
      if (soAbnfDecChkLen(len,yyDecode))
         RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
   
      soAbnfDecChcpy(mem,yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }
      
   if (haveAtleastOneChar)
   {   
      if(soAbnfDecChkLen(len, yyDecode))
         RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

      yyRet = 0;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpReasonPhrase */


/*
*
*       Fun:   soRegExpStatusCode
*
*       Desc:  Description for the regular expression Status Code
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: StatusCode = DIGIT3
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpStatusCode
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpStatusCode (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpStatusCode);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   if ( soRegExpNumeric (TRUE, 0, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpStatusCode */


/*
*
*       Fun:   soRegExpSipMessageChoice
*
*       Desc:  Description for the regular expression Message Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: SipMessage = Request | Response
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpSipMessageChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpSipMessageChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpSipMessageChoice);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   soRegExpEatSpaces(decCp, &yyDecode);

   yych = cmAbnfGetChar(decCp->offset);
   if (yych == 'S')
   {
      if(soAbnfDecChkLen(len, yyDecode))
         RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));

      soAbnfDecChcpy(mem, yych);
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
      if (yych == 'I')
      {
         if(soAbnfDecChkLen(len, yyDecode))
            RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
   
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode++;
         if (yych == 'P')
         {
            if(soAbnfDecChkLen(len, yyDecode))
               RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
      
            soAbnfDecChcpy(mem, yych);
            yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
            yyDecode++;
            if (yych == '/')
            {
               if(soAbnfDecChkLen(len, yyDecode))
                  RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
         
               soAbnfDecChcpy(mem, yych);
               yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
               yyDecode++;

               yyRet = 2;
               if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
                  return (-1);

               RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
            }
         }
      }
   }

   yyRet = 1;
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpSipMessageChoice */


/*
*
*       Fun:   soRegExpCallIdVal
*
*       Desc:  Description for the regular expression Call ID value
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: callid = token [ "@" token ]
*
*       token = 1*(alphanum |"-"|"."|"!"|"%"|"*"|"_"|"+"|""|"~")
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpCallIdVal
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpCallIdVal (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded      */
   S16   yyRet;      /* Return value                 */
   U16   yyDecode;   /* Number of characters decoded */
   U8    atState;
   /* atState is used as follows:
         0 = not allowed, start of message
         1 = allowed, after 1st valid character
         2 = found, must at least find one valid token after this
         3 = found at with valid character after this
      Valid callIds must end in atState of 1 ot 3
    */

   TRC2(soRegExpCallIdVal);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;
   atState  = 0;

   yych = cmAbnfGetChar(decCp->offset);

yy0:
   if (((yych>='0') && (yych<='9')) ||
      ((yych>='A') && (yych<='Z')) ||
      ((yych>='a') && (yych<='z')) ||
      (strchr("-.!%*_+\'~`()<>:\"/[]?{}\\", yych)!=NULL))
   {
      if (atState == 2)
        atState = 3; /* Found valid tokenChar after @ */
      goto yy1;
   }
   else if (yych == '@') 
   {
      if (atState == 1)
      {
         atState = 2; /* No more allowed */
         goto yy1;
      }
       else
          goto yyErr;
   }
   else goto yyEnd;

yy1:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   if (atState == 0)
      atState = 1;
   goto yy0;

yyEnd:
   if ((atState == 1) || (atState == 3))
   {
      yyRet = 0;
      goto yyReturn;
   }
   /* so008.201: Handle extra junk chars in CallId header */
   else
   {
      goto yyErr;
   }
yyReturn:
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

yyErr:
   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpCallIdVal */


/*
*
*       Fun:   soRegExpSpaceEater
*
*       Desc:  Description for the regular expression Space Eater
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Eats space and leaves one intact
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpSpaceEater
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpSpaceEater (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */
   S8    flag;       /* Flag                          */

   TRC2(soRegExpCallIdVal);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;
   flag = 0;

   yych = cmAbnfGetChar(decCp->offset);

   while(!flag)
   {
      if((yych == ' ')||(yych == '\t'))
      {
         if(soAbnfDecChkLen(len, yyDecode))
            goto yyErr;
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode ++;
      }
      else
         flag = 1;
   }

   if (yyDecode > 0)
   {
      yyDecode = 1;
      yyRet = RNOK;
   }
   else
      yyRet = 0;

   goto yyReturn;

yyReturn:
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

yyErr:
   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpSpaceEater */


/*
*
*       Fun:   soRegExpAllSpaceEater
*
*       Desc:  Description for the regular expression All Space Eater
*
*       Ret:   < 0 failure
*              = 0  success
*
*       Notes: Destroys all space
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpAllSpaceEater
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpAllSpaceEater (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */
   S8    flag;       /* Flag                          */

   TRC2(soRegExpCallIdVal);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;
   flag = 0;

   yych = cmAbnfGetChar(decCp->offset);

   while(!flag)
   {
      if((yych == ' ')||(yych == '\t'))
      {
         if(soAbnfDecChkLen(len, yyDecode))
            goto yyErr;
         soAbnfDecChcpy(mem, yych);
         yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
         yyDecode ++;
      }
      else
         flag = 1;
   }

   if (yyDecode > 0)
   {
      yyDecode = 0;
      yyRet = RNOK;
   }
   else
      yyRet = 0;

   goto yyReturn;

yyReturn:
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

yyErr:
   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpAllSpaceEater */


/*
*
*       Fun:   soRegExpExtension
*
*       Desc:  Description for the regular expression Extension
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Unknown header
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpExtension
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpExtension (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpExtension);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

yy1:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   if (yych == EOF)
      goto yyErr;
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   goto yy2;

yy2:
   switch(yych)
   {
      case '\n':
      case '\r': goto yy3;
      default  : goto yy1;
   }

yy3:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   yyRet = 0;
   goto yyReturn;

yyReturn:
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

yyErr:
   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
} /* End of soRegExpExtension */


/*
*
*       Fun:   soRegExpAddrSpec
*
*       Desc:  Description for the regular expression Address Spec Request Uri
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: Request URI
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpAddrSpec
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpAddrSpec (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 ret;   /* Return value */

   TRC2(soRegExpAddrSpec);

   /* Initialize local variable */
   ret = RNOK;

   ret = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChAddrSpec,
            FALSE, TRUE);

   RETVALUE(ret);
}  /* End of soRegExpAddrSpec */


/*
*
*       Fun:   soRegExpLinewrap
*
*       Desc:  Description for the regular expression Linewrap
*
*       Ret:   < 0 failure
*              = 0  success
*
*
*       Notes: Removes linewrapping if it is present
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpLineWrap
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpLineWrap (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpLineWrap);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

yy0:
   if(yych == '\r')
      goto yy1;
   if((yych == ' ')||(yych == '\t'))
      goto yy2;
   else
      goto yyErr;

yy1:
   if(soAbnfDecChkLen(len, yyDecode))
         goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   goto yy3;

yy2:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   goto yy0;

yy3:
   if(yych == '\n')
      goto yy4;
   else
      goto yyErr;

yy4:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   goto yy5;

yy5:
   /* must have at least one space or TAB for this to be a linewrap 
      - else error. */
   if((yych == ' ')||(yych == '\t'))
      goto yy6;
   else
      goto yyErr;

yy6:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   yyDecode++;
   goto yy7;

yy7:
   if((yych == ' ')||(yych == '\t'))
      goto yy6;
   else
   {
      yyRet = 0;
      goto yyReturn;
   }

yyReturn:
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

yyErr:
   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpLineWrap */


/*
*
*       Fun:   soRegExpMediaTypeChoice
*
*       Desc:  Description for the regular expression ContentType Type Choice
*              Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: None
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMediaTypeChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpMediaTypeChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{

   TRC2(soRegExpMediaTypeChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChContentTypeType,
            TRUE, TRUE));

} /* End of soRegExpMediaTypeChoice */


/*
*
*       Fun:   soRegExpMediaSubTypeChoice
*
*       Desc:  Description for the regular expression ContentType Type Choice
*              Choice
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: None
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMediaSubTypeChoice
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpMediaSubTypeChoice (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{

   TRC2(soRegExpMediaSubTypeChoice);

   RETVALUE(soRegExpChoiceCmp(decCp, tknCons, mem, len, soChMediaSubType,
           TRUE, TRUE));

} /* End of soRegExpMediaSubTypeChoice */


/*
*
*       Fun:   soRegExpSubjectVal
*
*       Desc:  Description for the regular expression Subject Val
*
*       Ret:   < 0 failure
*              > 0  success
*
*
*       Notes: Determines whether there is a subject value
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpSubjectVal
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpSubjectVal (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded       */
   S16   yyRet;      /* Return value                  */
   U16   yyDecode;   /* Number of characters decoded  */

   TRC2(soRegExpSubjectVal);

   /* Initialize local variables */
   yyRet = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   goto yy0;

yy0:
   switch(yych)
   {
      case '\n':
      case '\r': goto yyErr;
      default  : goto yy1;
   }

yy1:
   if(soAbnfDecChkLen(len, yyDecode))
      goto yyErr;
   soAbnfDecChcpy(mem, yych);
   yyRet = 0;
   goto yyReturn;

yyReturn:
   if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
      return (-1);

yyErr:
   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpSubjectVal */


/*
 *
 *       Fun:   soMsgRegExpEvntTokenNoDot
 *
 *       Desc:  Description for the regular expression EvntTokenNoDot
 *              
 *              
 *                 DIGIT   = [0-9];
 *                 ALPHA   = [A-Za-z];
 *              
 *                 ALPHANUM = DIGIT | ALPHA;
 *              
 *                 TOKENNODOT = (ALPHANUM | "-" | "!")+;
 *                                  actually "!%*_+`\'~-"
 *                 (TOKENNODOT)    {return(1);} 
 *       Ret:  < 0 failure
 *             > 0 success
 *
 *       Notes: none
 *
 *       File:  {FileName}
 *
 */
 
#ifdef ANSI
PUBLIC S16 soMsgRegExpEvntTokenNoDot
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 soMsgRegExpEvntTokenNoDot(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{

   S16 yyRet;     /* Return value                           */
   U16 yyDecode;  /* Number of characters decoded           */
   
   TRC2(soMsgRegExpEvntTokenNoDot);
   
   /* Initialize local variables */
   yyDecode = 0;
   yyRet = RNOK;
   
   if ( soRegExpAlphaNumericSpecial (
            "!%*_+`\'~-",  /* include these special chars */
            0, FALSE, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = 1;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }
   
   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
} /* soMsgRegExpEvntTokenNoDot */


/*
*
*       Fun:   soRegExpCompareHeader
*
*       Desc:  Description for the regular expression CompareHeader
*  
*  [Aa][cC][cC][eE][pP][tT]/[ \t;,:=>/\r\n\"]                 {return(SO_HEADER_GEN_ACCEPT);}
*  [Aa][cC][cC][eE][pP][tT][-][Ee][nN][cC][oO][dD][iI][nN][gG]/[ \t;,:=>/\r\n\"]        {return(SO_HEADER_GEN_ACCEPTENCODING);}
*  [Aa][cC][cC][eE][pP][tT][-][Ll][aA][nN][gG][uU][aA][gG][eE]/[ \t;,:=>/\r\n\"]        {return(SO_HEADER_GEN_ACCEPTLANGUAGE);}
*  [Aa][lL][eE][rR][tT][-][Ii][nN][fF][oO]/[ \t;,:=>/\r\n\"]             {return(SO_HEADER_GEN_ALERTINFO);}
*  [Aa][lL][lL][oO][wW]/[ \t;,:=>/\r\n\"]                  {return(SO_HEADER_GEN_ALLOW);}
*  [Aa][lL][sS][oO]/[ \t;,:=>/\r\n\"]                   {return(SO_HEADER_REQ_ALSO);}
*  [Aa][uU][tT][hH][oO][rR][iI][zZ][aA][tT][iI][oO][nN]/[ \t;,:=>/\r\n\"]          {return(SO_HEADER_REQ_AUTHORIZATION);}
*  
*  [Aa][uU][tT][hH][Ee][Nn][Tt][Ii][Cc][Aa][Tt][Ii][Oo][Nn][-][Ii][Nn][Ff][Oo]/[ \t;,:=>/\r\n\"]          {return(SO_HEADER_REQ_AUTHENTICATIONINFO);}
*  
*  [Cc][aA][lL][lL][-][Ii][Dd]/[ \t;,:=>/\r\n\"]                {return(SO_HEADER_GEN_CALLID);}
*  [iI]/[ \t;,:=>/\r\n\"]                      {return(SO_HEADER_GEN_CALLID);}
*  [Cc][aA][lL][lL][-][Ii][nN][fF][oO]/[ \t;,:=>/\r\n\"]              {return(SO_HEADER_GEN_CALLINFO);}
*  [Cc][oO][nN][tT][aA][cC][tT]/[ \t;,:=>/\r\n\"]                {return(SO_HEADER_GEN_CONTACT);}
*  [mM]/[ \t;,:=>/\r\n\"]                      {return(SO_HEADER_GEN_CONTACT);}
*  [Cc][oO][nN][tT][eE][nN][tT][-][Dd][iI][sS][pP][oO][sS][iI][tT][iI][oO][nN]/[ \t;,:=>/\r\n\"]    {return(SO_HEADER_ENT_CONTENTDISPOSITION);}
*  [Cc][oO][nN][tT][eE][nN][tT][-][Ee][nN][cC][oO][dD][iI][nN][gG]/[ \t;,:=>/\r\n\"]       {return(SO_HEADER_ENT_CONTENTENCODING);}
*  [eE]/[ \t;,:=>/\r\n\"]                      {return(SO_HEADER_ENT_CONTENTENCODING);}
*  [Cc][oO][nN][tT][eE][nN][tT][-][Ll][aA][nN][gG][uU][aA][gG][eE]/[ \t;,:=>/\r\n\"]       {return(SO_HEADER_ENT_CONTENTLANGUAGE);}
*  [Cc][oO][nN][tT][eE][nN][tT][-][Ll][eE][nN][gG][tT][hH]/[ \t;,:=>/\r\n\"]         {return(SO_HEADER_ENT_CONTENTLENGTH);}
*  [lL]/[ \t;,:=>/\r\n\"]                      {return(SO_HEADER_ENT_CONTENTLENGTH);}
*  [Cc][oO][nN][tT][eE][nN][tT][-][Tt][yY][pP][eE]/[ \t;,:=>/\r\n\"]           {return(SO_HEADER_ENT_CONTENTTYPE);}
*  [cC]/[ \t;,:=>/\r\n\"]                      {return(SO_HEADER_ENT_CONTENTTYPE);}
*  [Cc][Ss][eE][qQ]/[ \t;,:=>/\r\n\"]                   {return(SO_HEADER_GEN_CSEQ);}
*  [Dd][aA][tT][eE]/[ \t;,:=>/\r\n\"]                   {return(SO_HEADER_GEN_DATE);}
*  [Ee][nN][cC][rR][yY][pP][tT][iI][oO][nN]/[ \t;,:=>/\r\n\"]             {return(SO_HEADER_GEN_ENCRYPTION);}
*  [Ee][rR][rR][oO][rR][-][Ii][nN][fF][oO]/[ \t;,:=>/\r\n\"]             {return(SO_HEADER_RSP_ERRORINFO);}
*  [Ee][xX][pP][iI][rR][eE][sS]/[ \t;,:=>/\r\n\"]                {return(SO_HEADER_GEN_EXPIRES);}
*  [Ff][rR][oO][mM]/[ \t;,:=>/\r\n\"]                   {return(SO_HEADER_GEN_FROM);}
*  [fF]/[ \t;,:=>/\r\n\"]                      {return(SO_HEADER_GEN_FROM);}
*  [Ii][nN][-][Rr][eE][pP][lL][yY][-][Tt][oO]/[ \t;,:=>/\r\n\"]            {return(SO_HEADER_REQ_INREPLYTO);}
*  
*  [Mm][aA][xX][-][Ff][oO][rR][wW][aA][rR][dD][sS]/[ \t;,:=>/\r\n\"]           {return(SO_HEADER_REQ_MAXFORWARDS);}
*  [Mm][Ii][Mm][Ee][-][vV][eE][rR][sS][iI][oO][nN]/[ \t;,:=>/\r\n\"]           {return(SO_HEADER_ENT_MIMEVERSION);}
*  [Mm][Ii][Nn][-][Ee][Xx][Pp][Ii][Rr][Ee][Ss]/[ \t;,:=>/\r\n\"]           {return(SO_HEADER_GEN_MINEXPIRES);}
*  
*  [Oo][rR][gG][aA][nN][iI][zZ][aA][tT][iI][oO][nN]/[ \t;,:=>/\r\n\"]           {return(SO_HEADER_GEN_ORGANIZATION);}
*  [Pp][rR][iI][oO][rR][iI][tT][yY]/[ \t;,:=>/\r\n\"]               {return(SO_HEADER_REQ_PRIORITY);}
*  [Pp][rR][oO][xX][yY][-][Aa][uU][tT][hH][eE][nN][tT][iI][cC][aA][tT][eE]/[ \t;,:=>/\r\n\"]     {return(SO_HEADER_RSP_PROXYAUTHENTICATE);}
*  [Pp][rR][oO][xX][yY][-][Aa][uU][tT][hH][oO][rR][iI][zZ][aA][tT][iI][oO][nN]/[ \t;,:=>/\r\n\"]    {return(SO_HEADER_REQ_PROXYAUTHORIZATION);}
*  [Pp][rR][oO][xX][yY][-][Rr][eE][qQ][uU][iI][rR][eE]/[ \t;,:=>/\r\n\"]          {return(SO_HEADER_GEN_PROXYREQUIRE);}
*  [Rr][eE][cC][oO][rR][dD][-][Rr][oO][uU][tT][eE]/[ \t;,:=>/\r\n\"]           {return(SO_HEADER_GEN_RECORDROUTE);}
*  [Rr][eE][qQ][uU][iI][rR][eE]/[ \t;,:=>/\r\n\"]                {return(SO_HEADER_GEN_REQUIRE);}
*  [Rr][eE][sS][pP][oO][nN][sS][eE][-][Kk][eE][yY]/[ \t;,:=>/\r\n\"]           {return(SO_HEADER_REQ_RESPONSEKEY);}
*  [Rr][eE][tT][rR][yY][-][Aa][fF][tT][eE][rR]/[ \t;,:=>/\r\n\"]            {return(SO_HEADER_RSP_RETRYAFTER);}
*  [Rr][oO][uU][tT][eE]/[ \t;,:=>/\r\n\"]                  {return(SO_HEADER_REQ_ROUTE);}
*  [Rr][Ee][Pp][Ll][Yy][-][Tt][Oo]/[ \t;,:=>/\r\n\"]                  {return(SO_HEADER_GEN_REPLYTO);}
*  [Ss][eE][rR][vV][eE][rR]/[ \t;,:=>/\r\n\"]                 {return(SO_HEADER_RSP_SERVER);}
*  [Ss][uU][bB][jJ][eE][cC][tT]/[ \t;,:=>/\r\n\"]                {return(SO_HEADER_GEN_SUBJECT);}
*  [sS]/[ \t;,:=>/\r\n\"]                      {return(SO_HEADER_GEN_SUBJECT);}
*  [Ss][uU][pP][pP][oO][rR][tT][eE][dD]/[ \t;,:=>/\r\n\"]              {return(SO_HEADER_GEN_SUPPORTED);}
*  [kK]/[ \t;,:=>/\r\n\"]                      {return(SO_HEADER_GEN_SUPPORTED);}
*  [Tt][iI][mM][eE][sS][tT][aA][mM][pP]/[ \t;,:=>/\r\n\"]              {return(SO_HEADER_GEN_TIMESTAMP);}
*  [Tt][oO]/[ \t;,:=>/\r\n\"]                     {return(SO_HEADER_GEN_TO);}
*  [tT]/[ \t;,:=>/\r\n\"]                      {return(SO_HEADER_GEN_TO);}
*  [Uu][nN][sS][uU][pP][pP][oO][rR][tT][eE][dD]/[ \t;,:=>/\r\n\"]            {return(SO_HEADER_RSP_UNSUPPORTED);}
*  [Uu][sS][eE][rR][-][Aa][gG][eE][nN][tT]/[ \t;,:=>/\r\n\"]             {return(SO_HEADER_GEN_USERAGENT);}
*  [Vv][iI][aA]/[ \t;,:=>/\r\n\"]                    {return(SO_HEADER_GEN_VIA);}
*  [vV]/[ \t;,:=>/\r\n\"]                      {return(SO_HEADER_GEN_VIA);}
*  [Rr][Aa][cC][kK]/[ \t;,:=>/\r\n\"]                   {
*  #ifdef SO_RFC_3262
*                                      return(SO_HEADER_GEN_RACK);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [Rr][Ss][eE][qQ]/[ \t;,:=>/\r\n\"]                   {
*  #ifdef SO_RFC_3262
*                                      return(SO_HEADER_GEN_RSEQ);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [Ww][aA][rR][nN][iI][nN][gG]/[ \t;,:=>/\r\n\"]                {return(SO_HEADER_GEN_WARNING);}
*  [Ww][Ww][Ww][-][Aa][uU][tT][hH][eE][nN][tT][iI][cC][aA][tT][eE]/[ \t;,:=>/\r\n\"]       {return(SO_HEADER_GEN_WWWAUTHENTICATE);}
*  [Ee][vV][eE][nN][tT]/[ \t;,:=>/\r\n\"]                  {
*  #ifdef SO_EVENT
*                                      return(SO_HEADER_REQ_EVENT);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [oO]/[ \t;,:=>/\r\n\"]                      {
*  #ifdef SO_EVENT
*                                      return(SO_HEADER_REQ_EVENT);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [Aa][lL][lL][oO][wW][-][Ee][vV][eE][nN][tT][sS]/[ \t;,:=>/\r\n\"]           {
*  #ifdef SO_EVENT
*                                      return(SO_HEADER_GEN_ALLOW_EVENTS);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [uU]/[ \t;,:=>/\r\n\"]                      {
*  #ifdef SO_EVENT
*                                      return(SO_HEADER_GEN_ALLOW_EVENTSU);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [Rr][eE][fF][eE][rR][-][Tt][oO]/[ \t;,:=>/\r\n\"]               {
*  #ifdef SO_REFER
*                                      return(SO_HEADER_REQ_REFERTO);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [Rr][eE][fF][eE][rR][rR][eE][dD][-][Bb][yY]/[ \t;,:=>/\r\n\"]            {
*  #ifdef SO_REFER
*                                      return(SO_HEADER_REQ_REFERBY);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [rR]/[ \t;,:=>/\r\n\"]                      {
*  #ifdef SO_REFER
*                                      return(SO_HEADER_REQ_REFERTO);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [bB]/[ \t;,:=>/\r\n\"]                      {
*  #ifdef SO_REFER
*                                      return(SO_HEADER_REQ_REFERBY);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [Rr][eE][pP][lL][aA][cC][eE][sS]/[ \t;,:=>/\r\n\"]               {
*  #ifdef SO_REFER
*                                      return(SO_HEADER_REQ_REPLACES);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [Ss][eE][sS][sS][iI][oO][nN][-][Ee][xX][pP][iI][rR][eE][sS]/[ \t;,:=>/\r\n\"]        {
*  #ifdef SO_SESSTIMER
*                                      return(SO_HEADER_GEN_SESSION_EXPIRES);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [xX]/[ \t;,:=>/\r\n\"]                      {
*  #ifdef SO_SESSTIMER
*                                      return(SO_HEADER_GEN_SESSION_EXPIRESX);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [Mm][iI][nN][-][Ss][Ee]/[ \t;,:=>/\r\n\"]                 {
*  #ifdef SO_SESSTIMER
*                                      return(SO_HEADER_GEN_MINSE);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [Rr][eE][qQ][uU][eE][sS][tT][-][Dd][iI][sS][pP][oO][sS][iI][tT][iI][oO][nN]/[ \t;,:=>/\r\n\"]    {
*  #ifdef SO_CALLERPREF
*                                      return(SO_HEADER_REQ_REQUESTDISPOSITION);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [dD]/[ \t;,:=>/\r\n\"]                      {
*  #ifdef SO_CALLERPREF
*                                      return(SO_HEADER_REQ_REQUESTDISPOSITIOND);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [Aa][cC][cC][eE][pP][tT][-][Cc][oO][nN][tT][aA][cC][tT]/[ \t;,:=>/\r\n\"]         {
*  #ifdef SO_CALLERPREF
*                                      return(SO_HEADER_REQ_ACCEPT_CONTACT);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [aA]/[ \t;,:=>/\r\n\"]                      {
*  #ifdef SO_CALLERPREF
*                                      return(SO_HEADER_REQ_ACCEPT_CONTACTA);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [Rr][eE][jJ][eE][cC][tT][-][Cc][oO][nN][tT][aA][cC][tT]/[ \t;,:=>/\r\n\"]         {return(SO_HEADER_REQ_REJECT_CONTACT);}
*  [jJ]/[ \t;,:=>/\r\n\"]                      {return(SO_HEADER_REQ_REJECT_CONTACTJ);}
*  
*  [Aa][nN][oO][nN][yY][mM][iI][tT][yY]/[ \t;,:=>/\r\n\"]                 {return(SO_HEADER_ANONMY);}
*  [Rr][Pp][Ii][Dd][-][Pp][rR][iI][vV][aA][cC][yY]/[ \t;,:=>/\r\n\"]      {return(SO_HEADER_RPID_PRIV);}
*  [Rr][eE][mM][oO][tT][eE][-][Pp][aA][rR][tT][yY][-][Ii][Dd]/[ \t;,:=>/\r\n\"]   {return(SO_HEADER_REM_PARTY_ID);}
*  
*  [Ss][Uu][Bb][Ss][Cc][Rr][Ii][Pp][Tt][Ii][Oo][Nn][-][Ss][Tt][Aa][Tt][Ee]/[ \t;,:=>/\r\n\"]   {
*  #ifdef SO_EVENT
*                                      return(SO_HEADER_SUBSC_STATE);
*  #else
*                                      return(RNOK);
*  #endif
*                                                       }
*  [Ss][Ee][Cc][Uu][Rr][Ii][Tt][Yy][-][Cc][Ll][Ii][Ee][Nn][Tt]/[ \t;,:=>/\r\n\"]   {return(SO_HEADER_SEC_CLIENT);}
*  [Ss][Ee][Cc][Uu][Rr][Ii][Tt][Yy][-][Ss][Ee][Rr][Vv][Ee][Rr]/[ \t;,:=>/\r\n\"]   {return(SO_HEADER_SEC_SERVER);}
*  [Ss][Ee][Cc][Uu][Rr][Ii][Tt][Yy][-][Vv][Ee][Rr][Ii][Ff][Yy]/[ \t;,:=>/\r\n\"]   {return(SO_HEADER_SEC_VERIFY);}
*  
*  [Rr][Ee][Aa][Ss][Oo][Nn]/[ \t;,:=>/\r\n\"]   {return(SO_HEADER_GEN_REASON);}
*  
*  [Pp][-][Mm][Ee][Dd][Ii][Aa][-][Aa][Uu][Tt][Hh][Oo][Rr][Ii][Zz][Aa][Tt][Ii][Oo][Nn]/[ \t;,:=>/\r\n\"]   {return(SO_HEADER_GEN_PMEDIAAUTHORIZATION);}
*  
*  [Pp][Rr][Ii][Vv][Aa][Cc][Yy]/[ \t;,:=>/\r\n\"]   {return(SO_HEADER_GEN_PRIVACY);}
*  
*  [Pp][-][Aa][Ss][Ss][Ee][Rr][Tt][Ee][Dd][-][Ii][Dd][Ee][Nn][Tt][Ii][Tt][Yy]/[ \t;,:=>/\r\n\"]   {return(SO_HEADER_GEN_PASSERTEDID);}
*  [Pp][-][Pp][Rr][Ee][Ff][Ee][Rr][Rr][Ee][Dd][-][Ii][Dd][Ee][Nn][Tt][Ii][Tt][Yy]/[ \t;,:=>/\r\n\"]   {return(SO_HEADER_GEN_PPREFERREDID);}
*  [Ss][Ee][Rr][Vv][Ii][Cc][Ee][-][Rr][Oo][Uu][Tt][Ee]/[ \t;,:=>/\r\n\"]   {return(SO_HEADER_GEN_SERVICEROUTE);}
*  [Pp][Aa][Tt][Hh]/[ \t;,:=>/\r\n\"]   {return(SO_HEADER_GEN_PATH);}
*  
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpCompareHeader
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 soRegExpCompareHeader(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(soRegExpCompareHeader)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy3;
   case 'B':   case 'b':   goto yy20;
   case 'C':   case 'c':   goto yy4;
   case 'D':   case 'd':   goto yy9;
   case 'E':   case 'e':   goto yy7;
   case 'F':   case 'f':   goto yy10;
   case 'I':   case 'i':   goto yy5;
   case 'J':   case 'j':   goto yy22;
   case 'K':   case 'k':   goto yy15;
   case 'L':   case 'l':   goto yy8;
   case 'M':   case 'm':   goto yy6;
   case 'O':   case 'o':   goto yy11;
   case 'P':   case 'p':   goto yy12;
   case 'R':   case 'r':   goto yy13;
   case 'S':   case 's':   goto yy14;
   case 'T':   case 't':   goto yy16;
   case 'U':   case 'u':   goto yy17;
   case 'V':   case 'v':   goto yy18;
   case 'W':   case 'w':   goto yy19;
   case 'X':   case 'x':   goto yy21;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy682;
   case 'C':   case 'c':   goto yy684;
   case 'L':   case 'l':   goto yy685;
   case 'N':   case 'n':   goto yy681;
   case 'U':   case 'u':   goto yy686;
   default:   goto yyErr;
   }
yy4:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy604;
   case 'A':   case 'a':   goto yy607;
   case 'O':   case 'o':   goto yy606;
   case 'S':   case 's':   goto yy603;
   default:   goto yyErr;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy590;
   case 'N':   case 'n':   goto yy589;
   default:   goto yyErr;
   }
yy6:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy548;
   case 'A':   case 'a':   goto yy547;
   case 'I':   case 'i':   goto yy546;
   default:   goto yyErr;
   }
yy7:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy512;
   case 'N':   case 'n':   goto yy511;
   case 'R':   case 'r':   goto yy510;
   case 'V':   case 'v':   goto yy508;
   case 'X':   case 'x':   goto yy509;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy506;
   default:   goto yyErr;
   }
yy9:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy499;
   case 'A':   case 'a':   goto yy501;
   default:   goto yyErr;
   }
yy10:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy492;
   case 'R':   case 'r':   goto yy494;
   default:   goto yyErr;
   }
yy11:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy477;
   case 'R':   case 'r':   goto yy479;
   default:   goto yyErr;
   }
yy12:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy359;
   case 'A':   case 'a':   goto yy358;
   case 'R':   case 'r':   goto yy360;
   default:   goto yyErr;
   }
yy13:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy204;
   case 'A':   case 'a':   goto yy207;
   case 'E':   case 'e':   goto yy202;
   case 'O':   case 'o':   goto yy208;
   case 'P':   case 'p':   goto yy203;
   case 'S':   case 's':   goto yy206;
   default:   goto yyErr;
   }
yy14:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy104;
   case 'E':   case 'e':   goto yy102;
   case 'U':   case 'u':   goto yy103;
   default:   goto yyErr;
   }
yy15:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy100;
   default:   goto yyErr;
   }
yy16:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy85;
   case 'I':   case 'i':   goto yy88;
   case 'O':   case 'o':   goto yy87;
   default:   goto yyErr;
   }
yy17:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy60;
   case 'N':   case 'n':   goto yy63;
   case 'S':   case 's':   goto yy62;
   default:   goto yyErr;
   }
yy18:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy54;
   case 'I':   case 'i':   goto yy56;
   default:   goto yyErr;
   }
yy19:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy30;
   case 'W':   case 'w':   goto yy29;
   default:   goto yyErr;
   }
yy20:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy27;
   default:   goto yyErr;
   }
yy21:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy25;
   default:   goto yyErr;
   }
yy22:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy23;
   default:   goto yyErr;
   }
yy23:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_REQ_REJECT_CONTACTJ;
      goto yyReturn;
   }
yy25:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_SESSTIMER
                                    
      yyret = SO_HEADER_GEN_SESSION_EXPIRESX;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy27:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_REFER
                                    
      yyret = SO_HEADER_REQ_REFERBY;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy29:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy38;
   default:   goto yyErr;
   }
yy30:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy31;
   default:   goto yyErr;
   }
yy31:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy32;
   default:   goto yyErr;
   }
yy32:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy33;
   default:   goto yyErr;
   }
yy33:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy34;
   default:   goto yyErr;
   }
yy34:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy35;
   default:   goto yyErr;
   }
yy35:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy36;
   default:   goto yyErr;
   }
yy36:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_WARNING;
      goto yyReturn;
   }
yy38:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy39;
   default:   goto yyErr;
   }
yy39:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy40;
   default:   goto yyErr;
   }
yy40:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy41;
   default:   goto yyErr;
   }
yy41:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy42;
   default:   goto yyErr;
   }
yy42:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy43;
   default:   goto yyErr;
   }
yy43:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy44;
   default:   goto yyErr;
   }
yy44:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy45;
   default:   goto yyErr;
   }
yy45:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy46;
   default:   goto yyErr;
   }
yy46:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy47;
   default:   goto yyErr;
   }
yy47:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy48;
   default:   goto yyErr;
   }
yy48:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy49;
   default:   goto yyErr;
   }
yy49:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy50;
   default:   goto yyErr;
   }
yy50:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy51;
   default:   goto yyErr;
   }
yy51:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy52;
   default:   goto yyErr;
   }
yy52:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_WWWAUTHENTICATE;
      goto yyReturn;
   }
yy54:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_VIA;
      goto yyReturn;
   }
yy56:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy57;
   default:   goto yyErr;
   }
yy57:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy58;
   default:   goto yyErr;
   }
yy58:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_VIA;
      goto yyReturn;
   }
yy60:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_EVENT
                                    
      yyret = SO_HEADER_GEN_ALLOW_EVENTSU;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy62:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy75;
   default:   goto yyErr;
   }
yy63:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy64;
   default:   goto yyErr;
   }
yy64:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy65;
   default:   goto yyErr;
   }
yy65:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy66;
   default:   goto yyErr;
   }
yy66:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy67;
   default:   goto yyErr;
   }
yy67:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy68;
   default:   goto yyErr;
   }
yy68:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy69;
   default:   goto yyErr;
   }
yy69:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy70;
   default:   goto yyErr;
   }
yy70:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy71;
   default:   goto yyErr;
   }
yy71:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy72;
   default:   goto yyErr;
   }
yy72:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy73;
   default:   goto yyErr;
   }
yy73:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_RSP_UNSUPPORTED;
      goto yyReturn;
   }
yy75:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy76;
   default:   goto yyErr;
   }
yy76:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy77;
   default:   goto yyErr;
   }
yy77:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy78;
   default:   goto yyErr;
   }
yy78:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy79;
   default:   goto yyErr;
   }
yy79:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy80;
   default:   goto yyErr;
   }
yy80:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy81;
   default:   goto yyErr;
   }
yy81:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy82;
   default:   goto yyErr;
   }
yy82:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy83;
   default:   goto yyErr;
   }
yy83:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_USERAGENT;
      goto yyReturn;
   }
yy85:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_TO;
      goto yyReturn;
   }
yy87:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy98;
   default:   goto yyErr;
   }
yy88:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy89;
   default:   goto yyErr;
   }
yy89:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy90;
   default:   goto yyErr;
   }
yy90:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy91;
   default:   goto yyErr;
   }
yy91:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy92;
   default:   goto yyErr;
   }
yy92:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy93;
   default:   goto yyErr;
   }
yy93:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy94;
   default:   goto yyErr;
   }
yy94:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy95;
   default:   goto yyErr;
   }
yy95:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy96;
   default:   goto yyErr;
   }
yy96:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_TIMESTAMP;
      goto yyReturn;
   }
yy98:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_TO;
      goto yyReturn;
   }
yy100:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_SUPPORTED;
      goto yyReturn;
   }
yy102:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy141;
   case 'R':   case 'r':   goto yy139;
   case 'S':   case 's':   goto yy140;
   default:   goto yyErr;
   }
yy103:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy106;
   case 'P':   case 'p':   goto yy107;
   default:   goto yyErr;
   }
yy104:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_SUBJECT;
      goto yyReturn;
   }
yy106:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'J':   case 'j':   goto yy117;
   case 'S':   case 's':   goto yy116;
   default:   goto yyErr;
   }
yy107:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy108;
   default:   goto yyErr;
   }
yy108:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy109;
   default:   goto yyErr;
   }
yy109:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy110;
   default:   goto yyErr;
   }
yy110:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy111;
   default:   goto yyErr;
   }
yy111:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy112;
   default:   goto yyErr;
   }
yy112:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy113;
   default:   goto yyErr;
   }
yy113:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy114;
   default:   goto yyErr;
   }
yy114:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_SUPPORTED;
      goto yyReturn;
   }
yy116:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy123;
   default:   goto yyErr;
   }
yy117:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy118;
   default:   goto yyErr;
   }
yy118:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy119;
   default:   goto yyErr;
   }
yy119:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy120;
   default:   goto yyErr;
   }
yy120:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy121;
   default:   goto yyErr;
   }
yy121:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_SUBJECT;
      goto yyReturn;
   }
yy123:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy124;
   default:   goto yyErr;
   }
yy124:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy125;
   default:   goto yyErr;
   }
yy125:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy126;
   default:   goto yyErr;
   }
yy126:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy127;
   default:   goto yyErr;
   }
yy127:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy128;
   default:   goto yyErr;
   }
yy128:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy129;
   default:   goto yyErr;
   }
yy129:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy130;
   default:   goto yyErr;
   }
yy130:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy131;
   default:   goto yyErr;
   }
yy131:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy132;
   default:   goto yyErr;
   }
yy132:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy133;
   default:   goto yyErr;
   }
yy133:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy134;
   default:   goto yyErr;
   }
yy134:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy135;
   default:   goto yyErr;
   }
yy135:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy136;
   default:   goto yyErr;
   }
yy136:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy137;
   default:   goto yyErr;
   }
yy137:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_EVENT
                                    
      yyret = SO_HEADER_SUBSC_STATE;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy139:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy186;
   default:   goto yyErr;
   }
yy140:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy172;
   default:   goto yyErr;
   }
yy141:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy142;
   default:   goto yyErr;
   }
yy142:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy143;
   default:   goto yyErr;
   }
yy143:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy144;
   default:   goto yyErr;
   }
yy144:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy145;
   default:   goto yyErr;
   }
yy145:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy146;
   default:   goto yyErr;
   }
yy146:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy147;
   default:   goto yyErr;
   }
yy147:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy150;
   case 'S':   case 's':   goto yy149;
   case 'V':   case 'v':   goto yy148;
   default:   goto yyErr;
   }
yy148:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy165;
   default:   goto yyErr;
   }
yy149:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy158;
   default:   goto yyErr;
   }
yy150:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy151;
   default:   goto yyErr;
   }
yy151:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy152;
   default:   goto yyErr;
   }
yy152:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy153;
   default:   goto yyErr;
   }
yy153:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy154;
   default:   goto yyErr;
   }
yy154:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy155;
   default:   goto yyErr;
   }
yy155:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy156;
   default:   goto yyErr;
   }
yy156:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_SEC_CLIENT;
      goto yyReturn;
   }
yy158:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy159;
   default:   goto yyErr;
   }
yy159:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy160;
   default:   goto yyErr;
   }
yy160:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy161;
   default:   goto yyErr;
   }
yy161:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy162;
   default:   goto yyErr;
   }
yy162:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy163;
   default:   goto yyErr;
   }
yy163:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_SEC_SERVER;
      goto yyReturn;
   }
yy165:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy166;
   default:   goto yyErr;
   }
yy166:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy167;
   default:   goto yyErr;
   }
yy167:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy168;
   default:   goto yyErr;
   }
yy168:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy169;
   default:   goto yyErr;
   }
yy169:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy170;
   default:   goto yyErr;
   }
yy170:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_SEC_VERIFY;
      goto yyReturn;
   }
yy172:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy173;
   default:   goto yyErr;
   }
yy173:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy174;
   default:   goto yyErr;
   }
yy174:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy175;
   default:   goto yyErr;
   }
yy175:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy176;
   default:   goto yyErr;
   }
yy176:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy177;
   default:   goto yyErr;
   }
yy177:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy178;
   default:   goto yyErr;
   }
yy178:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy179;
   default:   goto yyErr;
   }
yy179:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy180;
   default:   goto yyErr;
   }
yy180:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy181;
   default:   goto yyErr;
   }
yy181:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy182;
   default:   goto yyErr;
   }
yy182:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy183;
   default:   goto yyErr;
   }
yy183:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy184;
   default:   goto yyErr;
   }
yy184:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_SESSTIMER
                                    
      yyret = SO_HEADER_GEN_SESSION_EXPIRES;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy186:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy187;
   case 'I':   case 'i':   goto yy188;
   default:   goto yyErr;
   }
yy187:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy199;
   default:   goto yyErr;
   }
yy188:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy189;
   default:   goto yyErr;
   }
yy189:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy190;
   default:   goto yyErr;
   }
yy190:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy191;
   default:   goto yyErr;
   }
yy191:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy192;
   default:   goto yyErr;
   }
yy192:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy193;
   default:   goto yyErr;
   }
yy193:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy194;
   default:   goto yyErr;
   }
yy194:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy195;
   default:   goto yyErr;
   }
yy195:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy196;
   default:   goto yyErr;
   }
yy196:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy197;
   default:   goto yyErr;
   }
yy197:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_SERVICEROUTE;
      goto yyReturn;
   }
yy199:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy200;
   default:   goto yyErr;
   }
yy200:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_RSP_SERVER;
      goto yyReturn;
   }
yy202:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy242;
   case 'C':   case 'c':   goto yy234;
   case 'F':   case 'f':   goto yy239;
   case 'J':   case 'j':   goto yy240;
   case 'M':   case 'm':   goto yy241;
   case 'P':   case 'p':   goto yy238;
   case 'Q':   case 'q':   goto yy235;
   case 'S':   case 's':   goto yy236;
   case 'T':   case 't':   goto yy237;
   default:   goto yyErr;
   }
yy203:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy222;
   default:   goto yyErr;
   }
yy204:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_REFER
                                    
      yyret = SO_HEADER_REQ_REFERTO;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy206:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy218;
   default:   goto yyErr;
   }
yy207:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy214;
   default:   goto yyErr;
   }
yy208:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy209;
   default:   goto yyErr;
   }
yy209:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy210;
   default:   goto yyErr;
   }
yy210:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy211;
   default:   goto yyErr;
   }
yy211:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy212;
   default:   goto yyErr;
   }
yy212:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_REQ_ROUTE;
      goto yyReturn;
   }
yy214:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy215;
   default:   goto yyErr;
   }
yy215:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy216;
   default:   goto yyErr;
   }
yy216:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_RFC_3262
                                    
      yyret = SO_HEADER_GEN_RACK;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy218:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Q':   case 'q':   goto yy219;
   default:   goto yyErr;
   }
yy219:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy220;
   default:   goto yyErr;
   }
yy220:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_RFC_3262
                                    
      yyret = SO_HEADER_GEN_RSEQ;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy222:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy223;
   default:   goto yyErr;
   }
yy223:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy224;
   default:   goto yyErr;
   }
yy224:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy225;
   default:   goto yyErr;
   }
yy225:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy226;
   default:   goto yyErr;
   }
yy226:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy227;
   default:   goto yyErr;
   }
yy227:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy228;
   default:   goto yyErr;
   }
yy228:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy229;
   default:   goto yyErr;
   }
yy229:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy230;
   default:   goto yyErr;
   }
yy230:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy231;
   default:   goto yyErr;
   }
yy231:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy232;
   default:   goto yyErr;
   }
yy232:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_RPID_PRIV;
      goto yyReturn;
   }
yy234:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy347;
   default:   goto yyErr;
   }
yy235:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy324;
   default:   goto yyErr;
   }
yy236:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy313;
   default:   goto yyErr;
   }
yy237:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy303;
   default:   goto yyErr;
   }
yy238:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy290;
   default:   goto yyErr;
   }
yy239:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy275;
   default:   goto yyErr;
   }
yy240:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy262;
   default:   goto yyErr;
   }
yy241:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy248;
   default:   goto yyErr;
   }
yy242:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy243;
   default:   goto yyErr;
   }
yy243:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy244;
   default:   goto yyErr;
   }
yy244:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy245;
   default:   goto yyErr;
   }
yy245:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy246;
   default:   goto yyErr;
   }
yy246:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_REASON;
      goto yyReturn;
   }
yy248:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy249;
   default:   goto yyErr;
   }
yy249:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy250;
   default:   goto yyErr;
   }
yy250:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy251;
   default:   goto yyErr;
   }
yy251:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy252;
   default:   goto yyErr;
   }
yy252:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy253;
   default:   goto yyErr;
   }
yy253:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy254;
   default:   goto yyErr;
   }
yy254:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy255;
   default:   goto yyErr;
   }
yy255:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy256;
   default:   goto yyErr;
   }
yy256:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy257;
   default:   goto yyErr;
   }
yy257:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy258;
   default:   goto yyErr;
   }
yy258:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy259;
   default:   goto yyErr;
   }
yy259:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy260;
   default:   goto yyErr;
   }
yy260:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_REM_PARTY_ID;
      goto yyReturn;
   }
yy262:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy263;
   default:   goto yyErr;
   }
yy263:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy264;
   default:   goto yyErr;
   }
yy264:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy265;
   default:   goto yyErr;
   }
yy265:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy266;
   default:   goto yyErr;
   }
yy266:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy267;
   default:   goto yyErr;
   }
yy267:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy268;
   default:   goto yyErr;
   }
yy268:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy269;
   default:   goto yyErr;
   }
yy269:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy270;
   default:   goto yyErr;
   }
yy270:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy271;
   default:   goto yyErr;
   }
yy271:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy272;
   default:   goto yyErr;
   }
yy272:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy273;
   default:   goto yyErr;
   }
yy273:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_REQ_REJECT_CONTACT;
      goto yyReturn;
   }
yy275:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy276;
   default:   goto yyErr;
   }
yy276:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy278;
   case 'R':   case 'r':   goto yy277;
   default:   goto yyErr;
   }
yy277:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy283;
   default:   goto yyErr;
   }
yy278:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy279;
   default:   goto yyErr;
   }
yy279:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy280;
   default:   goto yyErr;
   }
yy280:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy281;
   default:   goto yyErr;
   }
yy281:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_REFER
                                    
      yyret = SO_HEADER_REQ_REFERTO;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy283:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy284;
   default:   goto yyErr;
   }
yy284:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy285;
   default:   goto yyErr;
   }
yy285:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'B':   case 'b':   goto yy286;
   default:   goto yyErr;
   }
yy286:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy287;
   default:   goto yyErr;
   }
yy287:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy288;
   default:   goto yyErr;
   }
yy288:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_REFER
                                    
      yyret = SO_HEADER_REQ_REFERBY;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy290:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy292;
   case 'Y':   case 'y':   goto yy291;
   default:   goto yyErr;
   }
yy291:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy298;
   default:   goto yyErr;
   }
yy292:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy293;
   default:   goto yyErr;
   }
yy293:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy294;
   default:   goto yyErr;
   }
yy294:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy295;
   default:   goto yyErr;
   }
yy295:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy296;
   default:   goto yyErr;
   }
yy296:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_REFER
                                    
      yyret = SO_HEADER_REQ_REPLACES;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy298:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy299;
   default:   goto yyErr;
   }
yy299:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy300;
   default:   goto yyErr;
   }
yy300:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy301;
   default:   goto yyErr;
   }
yy301:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_REPLYTO;
      goto yyReturn;
   }
yy303:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy304;
   default:   goto yyErr;
   }
yy304:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy305;
   default:   goto yyErr;
   }
yy305:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy306;
   default:   goto yyErr;
   }
yy306:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy307;
   default:   goto yyErr;
   }
yy307:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy308;
   default:   goto yyErr;
   }
yy308:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy309;
   default:   goto yyErr;
   }
yy309:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy310;
   default:   goto yyErr;
   }
yy310:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy311;
   default:   goto yyErr;
   }
yy311:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_RSP_RETRYAFTER;
      goto yyReturn;
   }
yy313:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy314;
   default:   goto yyErr;
   }
yy314:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy315;
   default:   goto yyErr;
   }
yy315:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy316;
   default:   goto yyErr;
   }
yy316:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy317;
   default:   goto yyErr;
   }
yy317:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy318;
   default:   goto yyErr;
   }
yy318:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'K':   case 'k':   goto yy319;
   default:   goto yyErr;
   }
yy319:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy320;
   default:   goto yyErr;
   }
yy320:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy321;
   default:   goto yyErr;
   }
yy321:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy322;
   default:   goto yyErr;
   }
yy322:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_REQ_RESPONSEKEY;
      goto yyReturn;
   }
yy324:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy326;
   case 'I':   case 'i':   goto yy325;
   default:   goto yyErr;
   }
yy325:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy343;
   default:   goto yyErr;
   }
yy326:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy327;
   default:   goto yyErr;
   }
yy327:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy328;
   default:   goto yyErr;
   }
yy328:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy329;
   default:   goto yyErr;
   }
yy329:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy330;
   default:   goto yyErr;
   }
yy330:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy331;
   default:   goto yyErr;
   }
yy331:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy332;
   default:   goto yyErr;
   }
yy332:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy333;
   default:   goto yyErr;
   }
yy333:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy334;
   default:   goto yyErr;
   }
yy334:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy335;
   default:   goto yyErr;
   }
yy335:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy336;
   default:   goto yyErr;
   }
yy336:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy337;
   default:   goto yyErr;
   }
yy337:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy338;
   default:   goto yyErr;
   }
yy338:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy339;
   default:   goto yyErr;
   }
yy339:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy340;
   default:   goto yyErr;
   }
yy340:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy341;
   default:   goto yyErr;
   }
yy341:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_CALLERPREF
                                    
      yyret = SO_HEADER_REQ_REQUESTDISPOSITION;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy343:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy344;
   default:   goto yyErr;
   }
yy344:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy345;
   default:   goto yyErr;
   }
yy345:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_REQUIRE;
      goto yyReturn;
   }
yy347:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy348;
   default:   goto yyErr;
   }
yy348:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy349;
   default:   goto yyErr;
   }
yy349:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy350;
   default:   goto yyErr;
   }
yy350:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy351;
   default:   goto yyErr;
   }
yy351:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy352;
   default:   goto yyErr;
   }
yy352:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy353;
   default:   goto yyErr;
   }
yy353:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy354;
   default:   goto yyErr;
   }
yy354:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy355;
   default:   goto yyErr;
   }
yy355:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy356;
   default:   goto yyErr;
   }
yy356:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_RECORDROUTE;
      goto yyReturn;
   }
yy358:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy473;
   default:   goto yyErr;
   }
yy359:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy414;
   case 'M':   case 'm':   goto yy413;
   case 'P':   case 'p':   goto yy415;
   default:   goto yyErr;
   }
yy360:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy361;
   case 'O':   case 'o':   goto yy362;
   default:   goto yyErr;
   }
yy361:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy401;
   case 'V':   case 'v':   goto yy400;
   default:   goto yyErr;
   }
yy362:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy363;
   default:   goto yyErr;
   }
yy363:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy364;
   default:   goto yyErr;
   }
yy364:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy365;
   default:   goto yyErr;
   }
yy365:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy366;
   case 'R':   case 'r':   goto yy367;
   default:   goto yyErr;
   }
yy366:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy376;
   default:   goto yyErr;
   }
yy367:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy368;
   default:   goto yyErr;
   }
yy368:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Q':   case 'q':   goto yy369;
   default:   goto yyErr;
   }
yy369:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy370;
   default:   goto yyErr;
   }
yy370:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy371;
   default:   goto yyErr;
   }
yy371:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy372;
   default:   goto yyErr;
   }
yy372:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy373;
   default:   goto yyErr;
   }
yy373:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy374;
   default:   goto yyErr;
   }
yy374:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_PROXYREQUIRE;
      goto yyReturn;
   }
yy376:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy377;
   default:   goto yyErr;
   }
yy377:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy378;
   default:   goto yyErr;
   }
yy378:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy379;
   case 'O':   case 'o':   goto yy380;
   default:   goto yyErr;
   }
yy379:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy391;
   default:   goto yyErr;
   }
yy380:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy381;
   default:   goto yyErr;
   }
yy381:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy382;
   default:   goto yyErr;
   }
yy382:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy383;
   default:   goto yyErr;
   }
yy383:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy384;
   default:   goto yyErr;
   }
yy384:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy385;
   default:   goto yyErr;
   }
yy385:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy386;
   default:   goto yyErr;
   }
yy386:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy387;
   default:   goto yyErr;
   }
yy387:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy388;
   default:   goto yyErr;
   }
yy388:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy389;
   default:   goto yyErr;
   }
yy389:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_REQ_PROXYAUTHORIZATION;
      goto yyReturn;
   }
yy391:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy392;
   default:   goto yyErr;
   }
yy392:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy393;
   default:   goto yyErr;
   }
yy393:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy394;
   default:   goto yyErr;
   }
yy394:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy395;
   default:   goto yyErr;
   }
yy395:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy396;
   default:   goto yyErr;
   }
yy396:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy397;
   default:   goto yyErr;
   }
yy397:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy398;
   default:   goto yyErr;
   }
yy398:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_RSP_PROXYAUTHENTICATE;
      goto yyReturn;
   }
yy400:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy408;
   default:   goto yyErr;
   }
yy401:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy402;
   default:   goto yyErr;
   }
yy402:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy403;
   default:   goto yyErr;
   }
yy403:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy404;
   default:   goto yyErr;
   }
yy404:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy405;
   default:   goto yyErr;
   }
yy405:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy406;
   default:   goto yyErr;
   }
yy406:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_REQ_PRIORITY;
      goto yyReturn;
   }
yy408:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy409;
   default:   goto yyErr;
   }
yy409:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy410;
   default:   goto yyErr;
   }
yy410:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy411;
   default:   goto yyErr;
   }
yy411:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_PRIVACY;
      goto yyReturn;
   }
yy413:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy453;
   default:   goto yyErr;
   }
yy414:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy435;
   default:   goto yyErr;
   }
yy415:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy416;
   default:   goto yyErr;
   }
yy416:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy417;
   default:   goto yyErr;
   }
yy417:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy418;
   default:   goto yyErr;
   }
yy418:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy419;
   default:   goto yyErr;
   }
yy419:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy420;
   default:   goto yyErr;
   }
yy420:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy421;
   default:   goto yyErr;
   }
yy421:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy422;
   default:   goto yyErr;
   }
yy422:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy423;
   default:   goto yyErr;
   }
yy423:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy424;
   default:   goto yyErr;
   }
yy424:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy425;
   default:   goto yyErr;
   }
yy425:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy426;
   default:   goto yyErr;
   }
yy426:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy427;
   default:   goto yyErr;
   }
yy427:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy428;
   default:   goto yyErr;
   }
yy428:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy429;
   default:   goto yyErr;
   }
yy429:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy430;
   default:   goto yyErr;
   }
yy430:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy431;
   default:   goto yyErr;
   }
yy431:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy432;
   default:   goto yyErr;
   }
yy432:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy433;
   default:   goto yyErr;
   }
yy433:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_PPREFERREDID;
      goto yyReturn;
   }
yy435:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy436;
   default:   goto yyErr;
   }
yy436:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy437;
   default:   goto yyErr;
   }
yy437:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy438;
   default:   goto yyErr;
   }
yy438:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy439;
   default:   goto yyErr;
   }
yy439:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy440;
   default:   goto yyErr;
   }
yy440:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy441;
   default:   goto yyErr;
   }
yy441:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy442;
   default:   goto yyErr;
   }
yy442:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy443;
   default:   goto yyErr;
   }
yy443:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy444;
   default:   goto yyErr;
   }
yy444:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy445;
   default:   goto yyErr;
   }
yy445:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy446;
   default:   goto yyErr;
   }
yy446:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy447;
   default:   goto yyErr;
   }
yy447:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy448;
   default:   goto yyErr;
   }
yy448:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy449;
   default:   goto yyErr;
   }
yy449:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy450;
   default:   goto yyErr;
   }
yy450:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy451;
   default:   goto yyErr;
   }
yy451:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_PASSERTEDID;
      goto yyReturn;
   }
yy453:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy454;
   default:   goto yyErr;
   }
yy454:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy455;
   default:   goto yyErr;
   }
yy455:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy456;
   default:   goto yyErr;
   }
yy456:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy457;
   default:   goto yyErr;
   }
yy457:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy458;
   default:   goto yyErr;
   }
yy458:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy459;
   default:   goto yyErr;
   }
yy459:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy460;
   default:   goto yyErr;
   }
yy460:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy461;
   default:   goto yyErr;
   }
yy461:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy462;
   default:   goto yyErr;
   }
yy462:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy463;
   default:   goto yyErr;
   }
yy463:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy464;
   default:   goto yyErr;
   }
yy464:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy465;
   default:   goto yyErr;
   }
yy465:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy466;
   default:   goto yyErr;
   }
yy466:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy467;
   default:   goto yyErr;
   }
yy467:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy468;
   default:   goto yyErr;
   }
yy468:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy469;
   default:   goto yyErr;
   }
yy469:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy470;
   default:   goto yyErr;
   }
yy470:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy471;
   default:   goto yyErr;
   }
yy471:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_PMEDIAAUTHORIZATION;
      goto yyReturn;
   }
yy473:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy474;
   default:   goto yyErr;
   }
yy474:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy475;
   default:   goto yyErr;
   }
yy475:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_PATH;
      goto yyReturn;
   }
yy477:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_EVENT
                                    
      yyret = SO_HEADER_REQ_EVENT;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy479:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy480;
   default:   goto yyErr;
   }
yy480:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy481;
   default:   goto yyErr;
   }
yy481:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy482;
   default:   goto yyErr;
   }
yy482:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy483;
   default:   goto yyErr;
   }
yy483:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy484;
   default:   goto yyErr;
   }
yy484:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy485;
   default:   goto yyErr;
   }
yy485:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy486;
   default:   goto yyErr;
   }
yy486:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy487;
   default:   goto yyErr;
   }
yy487:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy488;
   default:   goto yyErr;
   }
yy488:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy489;
   default:   goto yyErr;
   }
yy489:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy490;
   default:   goto yyErr;
   }
yy490:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_ORGANIZATION;
      goto yyReturn;
   }
yy492:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_FROM;
      goto yyReturn;
   }
yy494:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy495;
   default:   goto yyErr;
   }
yy495:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy496;
   default:   goto yyErr;
   }
yy496:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy497;
   default:   goto yyErr;
   }
yy497:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_FROM;
      goto yyReturn;
   }
yy499:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_CALLERPREF
                                    
      yyret = SO_HEADER_REQ_REQUESTDISPOSITIOND;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy501:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy502;
   default:   goto yyErr;
   }
yy502:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy503;
   default:   goto yyErr;
   }
yy503:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy504;
   default:   goto yyErr;
   }
yy504:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_DATE;
      goto yyReturn;
   }
yy506:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_ENT_CONTENTLENGTH;
      goto yyReturn;
   }
yy508:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy541;
   default:   goto yyErr;
   }
yy509:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy534;
   default:   goto yyErr;
   }
yy510:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy524;
   default:   goto yyErr;
   }
yy511:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy514;
   default:   goto yyErr;
   }
yy512:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_ENT_CONTENTENCODING;
      goto yyReturn;
   }
yy514:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy515;
   default:   goto yyErr;
   }
yy515:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy516;
   default:   goto yyErr;
   }
yy516:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy517;
   default:   goto yyErr;
   }
yy517:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy518;
   default:   goto yyErr;
   }
yy518:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy519;
   default:   goto yyErr;
   }
yy519:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy520;
   default:   goto yyErr;
   }
yy520:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy521;
   default:   goto yyErr;
   }
yy521:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy522;
   default:   goto yyErr;
   }
yy522:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_ENCRYPTION;
      goto yyReturn;
   }
yy524:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy525;
   default:   goto yyErr;
   }
yy525:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy526;
   default:   goto yyErr;
   }
yy526:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy527;
   default:   goto yyErr;
   }
yy527:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy528;
   default:   goto yyErr;
   }
yy528:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy529;
   default:   goto yyErr;
   }
yy529:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy530;
   default:   goto yyErr;
   }
yy530:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy531;
   default:   goto yyErr;
   }
yy531:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy532;
   default:   goto yyErr;
   }
yy532:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_RSP_ERRORINFO;
      goto yyReturn;
   }
yy534:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy535;
   default:   goto yyErr;
   }
yy535:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy536;
   default:   goto yyErr;
   }
yy536:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy537;
   default:   goto yyErr;
   }
yy537:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy538;
   default:   goto yyErr;
   }
yy538:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy539;
   default:   goto yyErr;
   }
yy539:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_EXPIRES;
      goto yyReturn;
   }
yy541:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy542;
   default:   goto yyErr;
   }
yy542:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy543;
   default:   goto yyErr;
   }
yy543:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy544;
   default:   goto yyErr;
   }
yy544:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_EVENT
                                    
      yyret = SO_HEADER_REQ_EVENT;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy546:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy562;
   case 'N':   case 'n':   goto yy563;
   default:   goto yyErr;
   }
yy547:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy550;
   default:   goto yyErr;
   }
yy548:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_CONTACT;
      goto yyReturn;
   }
yy550:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy551;
   default:   goto yyErr;
   }
yy551:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy552;
   default:   goto yyErr;
   }
yy552:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy553;
   default:   goto yyErr;
   }
yy553:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy554;
   default:   goto yyErr;
   }
yy554:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy555;
   default:   goto yyErr;
   }
yy555:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy556;
   default:   goto yyErr;
   }
yy556:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy557;
   default:   goto yyErr;
   }
yy557:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy558;
   default:   goto yyErr;
   }
yy558:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy559;
   default:   goto yyErr;
   }
yy559:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy560;
   default:   goto yyErr;
   }
yy560:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_REQ_MAXFORWARDS;
      goto yyReturn;
   }
yy562:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy578;
   default:   goto yyErr;
   }
yy563:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy564;
   default:   goto yyErr;
   }
yy564:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy565;
   case 'S':   case 's':   goto yy566;
   default:   goto yyErr;
   }
yy565:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'X':   case 'x':   goto yy570;
   default:   goto yyErr;
   }
yy566:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy567;
   default:   goto yyErr;
   }
yy567:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy568;
   default:   goto yyErr;
   }
yy568:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_SESSTIMER
                                    
      yyret = SO_HEADER_GEN_MINSE;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy570:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy571;
   default:   goto yyErr;
   }
yy571:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy572;
   default:   goto yyErr;
   }
yy572:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy573;
   default:   goto yyErr;
   }
yy573:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy574;
   default:   goto yyErr;
   }
yy574:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy575;
   default:   goto yyErr;
   }
yy575:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy576;
   default:   goto yyErr;
   }
yy576:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_MINEXPIRES;
      goto yyReturn;
   }
yy578:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy579;
   default:   goto yyErr;
   }
yy579:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy580;
   default:   goto yyErr;
   }
yy580:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy581;
   default:   goto yyErr;
   }
yy581:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy582;
   default:   goto yyErr;
   }
yy582:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy583;
   default:   goto yyErr;
   }
yy583:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy584;
   default:   goto yyErr;
   }
yy584:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy585;
   default:   goto yyErr;
   }
yy585:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy586;
   default:   goto yyErr;
   }
yy586:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy587;
   default:   goto yyErr;
   }
yy587:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_ENT_MIMEVERSION;
      goto yyReturn;
   }
yy589:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy592;
   default:   goto yyErr;
   }
yy590:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_CALLID;
      goto yyReturn;
   }
yy592:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy593;
   default:   goto yyErr;
   }
yy593:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy594;
   default:   goto yyErr;
   }
yy594:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy595;
   default:   goto yyErr;
   }
yy595:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy596;
   default:   goto yyErr;
   }
yy596:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy597;
   default:   goto yyErr;
   }
yy597:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy598;
   default:   goto yyErr;
   }
yy598:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy599;
   default:   goto yyErr;
   }
yy599:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy600;
   default:   goto yyErr;
   }
yy600:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy601;
   default:   goto yyErr;
   }
yy601:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_REQ_INREPLYTO;
      goto yyReturn;
   }
yy603:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy677;
   default:   goto yyErr;
   }
yy604:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_ENT_CONTENTTYPE;
      goto yyReturn;
   }
yy606:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy620;
   default:   goto yyErr;
   }
yy607:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy608;
   default:   goto yyErr;
   }
yy608:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'L':   case 'l':   goto yy609;
   default:   goto yyErr;
   }
yy609:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy610;
   default:   goto yyErr;
   }
yy610:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy611;
   default:   goto yyErr;
   }
yy611:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy612;
   case 'N':   case 'n':   goto yy613;
   default:   goto yyErr;
   }
yy612:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy618;
   default:   goto yyErr;
   }
yy613:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy614;
   default:   goto yyErr;
   }
yy614:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy615;
   default:   goto yyErr;
   }
yy615:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy616;
   default:   goto yyErr;
   }
yy616:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_CALLINFO;
      goto yyReturn;
   }
yy618:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_CALLID;
      goto yyReturn;
   }
yy620:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy621;
   default:   goto yyErr;
   }
yy621:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy622;
   case 'E':   case 'e':   goto yy623;
   default:   goto yyErr;
   }
yy622:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy673;
   default:   goto yyErr;
   }
yy623:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy624;
   default:   goto yyErr;
   }
yy624:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy625;
   default:   goto yyErr;
   }
yy625:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy626;
   default:   goto yyErr;
   }
yy626:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy627;
   case 'E':   case 'e':   goto yy628;
   case 'L':   case 'l':   goto yy629;
   case 'T':   case 't':   goto yy630;
   default:   goto yyErr;
   }
yy627:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy661;
   default:   goto yyErr;
   }
yy628:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy652;
   default:   goto yyErr;
   }
yy629:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy637;
   case 'E':   case 'e':   goto yy636;
   default:   goto yyErr;
   }
yy630:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy631;
   default:   goto yyErr;
   }
yy631:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy632;
   default:   goto yyErr;
   }
yy632:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy633;
   default:   goto yyErr;
   }
yy633:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy634;
   default:   goto yyErr;
   }
yy634:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_ENT_CONTENTTYPE;
      goto yyReturn;
   }
yy636:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy646;
   default:   goto yyErr;
   }
yy637:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy638;
   default:   goto yyErr;
   }
yy638:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy639;
   default:   goto yyErr;
   }
yy639:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy640;
   default:   goto yyErr;
   }
yy640:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy641;
   default:   goto yyErr;
   }
yy641:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy642;
   default:   goto yyErr;
   }
yy642:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy643;
   default:   goto yyErr;
   }
yy643:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy644;
   default:   goto yyErr;
   }
yy644:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_ENT_CONTENTLANGUAGE;
      goto yyReturn;
   }
yy646:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy647;
   default:   goto yyErr;
   }
yy647:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy648;
   default:   goto yyErr;
   }
yy648:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy649;
   default:   goto yyErr;
   }
yy649:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy650;
   default:   goto yyErr;
   }
yy650:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_ENT_CONTENTLENGTH;
      goto yyReturn;
   }
yy652:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy653;
   default:   goto yyErr;
   }
yy653:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy654;
   default:   goto yyErr;
   }
yy654:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy655;
   default:   goto yyErr;
   }
yy655:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy656;
   default:   goto yyErr;
   }
yy656:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy657;
   default:   goto yyErr;
   }
yy657:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy658;
   default:   goto yyErr;
   }
yy658:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy659;
   default:   goto yyErr;
   }
yy659:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_ENT_CONTENTENCODING;
      goto yyReturn;
   }
yy661:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy662;
   default:   goto yyErr;
   }
yy662:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy663;
   default:   goto yyErr;
   }
yy663:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy664;
   default:   goto yyErr;
   }
yy664:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy665;
   default:   goto yyErr;
   }
yy665:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy666;
   default:   goto yyErr;
   }
yy666:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy667;
   default:   goto yyErr;
   }
yy667:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy668;
   default:   goto yyErr;
   }
yy668:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy669;
   default:   goto yyErr;
   }
yy669:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy670;
   default:   goto yyErr;
   }
yy670:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy671;
   default:   goto yyErr;
   }
yy671:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_ENT_CONTENTDISPOSITION;
      goto yyReturn;
   }
yy673:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy674;
   default:   goto yyErr;
   }
yy674:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy675;
   default:   goto yyErr;
   }
yy675:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_CONTACT;
      goto yyReturn;
   }
yy677:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Q':   case 'q':   goto yy678;
   default:   goto yyErr;
   }
yy678:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy679;
   default:   goto yyErr;
   }
yy679:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_CSEQ;
      goto yyReturn;
   }
yy681:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy781;
   default:   goto yyErr;
   }
yy682:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_CALLERPREF
                                    
      yyret = SO_HEADER_REQ_ACCEPT_CONTACTA;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy684:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy745;
   default:   goto yyErr;
   }
yy685:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy717;
   case 'L':   case 'l':   goto yy718;
   case 'S':   case 's':   goto yy719;
   default:   goto yyErr;
   }
yy686:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy687;
   default:   goto yyErr;
   }
yy687:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'H':   case 'h':   goto yy688;
   default:   goto yyErr;
   }
yy688:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy690;
   case 'O':   case 'o':   goto yy689;
   default:   goto yyErr;
   }
yy689:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy707;
   default:   goto yyErr;
   }
yy690:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy691;
   default:   goto yyErr;
   }
yy691:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy692;
   default:   goto yyErr;
   }
yy692:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy693;
   default:   goto yyErr;
   }
yy693:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy694;
   default:   goto yyErr;
   }
yy694:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy695;
   default:   goto yyErr;
   }
yy695:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy696;
   default:   goto yyErr;
   }
yy696:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy697;
   default:   goto yyErr;
   }
yy697:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy698;
   default:   goto yyErr;
   }
yy698:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy699;
   default:   goto yyErr;
   }
yy699:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy700;
   default:   goto yyErr;
   }
yy700:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy701;
   default:   goto yyErr;
   }
yy701:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy702;
   default:   goto yyErr;
   }
yy702:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy703;
   default:   goto yyErr;
   }
yy703:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy704;
   default:   goto yyErr;
   }
yy704:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy705;
   default:   goto yyErr;
   }
yy705:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_REQ_AUTHENTICATIONINFO;
      goto yyReturn;
   }
yy707:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy708;
   default:   goto yyErr;
   }
yy708:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Z':   case 'z':   goto yy709;
   default:   goto yyErr;
   }
yy709:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy710;
   default:   goto yyErr;
   }
yy710:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy711;
   default:   goto yyErr;
   }
yy711:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy712;
   default:   goto yyErr;
   }
yy712:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy713;
   default:   goto yyErr;
   }
yy713:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy714;
   default:   goto yyErr;
   }
yy714:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy715;
   default:   goto yyErr;
   }
yy715:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_REQ_AUTHORIZATION;
      goto yyReturn;
   }
yy717:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'R':   case 'r':   goto yy736;
   default:   goto yyErr;
   }
yy718:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy723;
   default:   goto yyErr;
   }
yy719:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy720;
   default:   goto yyErr;
   }
yy720:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy721;
   default:   goto yyErr;
   }
yy721:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_REQ_ALSO;
      goto yyReturn;
   }
yy723:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'W':   case 'w':   goto yy724;
   default:   goto yyErr;
   }
yy724:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy726;
   case '-':   goto yy725;
   default:   goto yyErr;
   }
yy725:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy728;
   default:   goto yyErr;
   }
yy726:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_ALLOW;
      goto yyReturn;
   }
yy728:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'V':   case 'v':   goto yy729;
   default:   goto yyErr;
   }
yy729:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy730;
   default:   goto yyErr;
   }
yy730:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy731;
   default:   goto yyErr;
   }
yy731:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy732;
   default:   goto yyErr;
   }
yy732:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'S':   case 's':   goto yy733;
   default:   goto yyErr;
   }
yy733:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy734;
   default:   goto yyErr;
   }
yy734:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_EVENT
                                    
      yyret = SO_HEADER_GEN_ALLOW_EVENTS;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy736:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy737;
   default:   goto yyErr;
   }
yy737:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '-':   goto yy738;
   default:   goto yyErr;
   }
yy738:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy739;
   default:   goto yyErr;
   }
yy739:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy740;
   default:   goto yyErr;
   }
yy740:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'F':   case 'f':   goto yy741;
   default:   goto yyErr;
   }
yy741:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy742;
   default:   goto yyErr;
   }
yy742:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy743;
   default:   goto yyErr;
   }
yy743:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_ALERTINFO;
      goto yyReturn;
   }
yy745:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy746;
   default:   goto yyErr;
   }
yy746:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'P':   case 'p':   goto yy747;
   default:   goto yyErr;
   }
yy747:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy748;
   default:   goto yyErr;
   }
yy748:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy749;
   case '-':   goto yy751;
   default:   goto yyErr;
   }
yy749:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_ACCEPT;
      goto yyReturn;
   }
yy751:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy752;
   case 'E':   case 'e':   goto yy754;
   case 'L':   case 'l':   goto yy753;
   default:   goto yyErr;
   }
yy752:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy773;
   default:   goto yyErr;
   }
yy753:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy764;
   default:   goto yyErr;
   }
yy754:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy755;
   default:   goto yyErr;
   }
yy755:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy756;
   default:   goto yyErr;
   }
yy756:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'O':   case 'o':   goto yy757;
   default:   goto yyErr;
   }
yy757:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'D':   case 'd':   goto yy758;
   default:   goto yyErr;
   }
yy758:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy759;
   default:   goto yyErr;
   }
yy759:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy760;
   default:   goto yyErr;
   }
yy760:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy761;
   default:   goto yyErr;
   }
yy761:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy762;
   default:   goto yyErr;
   }
yy762:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_ACCEPTENCODING;
      goto yyReturn;
   }
yy764:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy765;
   default:   goto yyErr;
   }
yy765:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy766;
   default:   goto yyErr;
   }
yy766:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'U':   case 'u':   goto yy767;
   default:   goto yyErr;
   }
yy767:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy768;
   default:   goto yyErr;
   }
yy768:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'G':   case 'g':   goto yy769;
   default:   goto yyErr;
   }
yy769:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'E':   case 'e':   goto yy770;
   default:   goto yyErr;
   }
yy770:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy771;
   default:   goto yyErr;
   }
yy771:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_GEN_ACCEPTLANGUAGE;
      goto yyReturn;
   }
yy773:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy774;
   default:   goto yyErr;
   }
yy774:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy775;
   default:   goto yyErr;
   }
yy775:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'A':   case 'a':   goto yy776;
   default:   goto yyErr;
   }
yy776:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'C':   case 'c':   goto yy777;
   default:   goto yyErr;
   }
yy777:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy778;
   default:   goto yyErr;
   }
yy778:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy779;
   default:   goto yyErr;
   }
yy779:      (++yydecode);

       
   (--yydecode);
   {
#ifdef SO_CALLERPREF
                                    
      yyret = SO_HEADER_REQ_ACCEPT_CONTACT;
      goto yyReturn;
   
#else
                                    
      yyret = RNOK;
      goto yyReturn;
   
#endif
                                                     }
yy781:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'N':   case 'n':   goto yy782;
   default:   goto yyErr;
   }
yy782:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy783;
   default:   goto yyErr;
   }
yy783:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'M':   case 'm':   goto yy784;
   default:   goto yyErr;
   }
yy784:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'I':   case 'i':   goto yy785;
   default:   goto yyErr;
   }
yy785:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'T':   case 't':   goto yy786;
   default:   goto yyErr;
   }
yy786:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case 'Y':   case 'y':   goto yy787;
   default:   goto yyErr;
   }
yy787:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\t':
   case '\n':   case '\r':   case ' ':   case '"':   case ',':   case '/':   case ':':
   case ';':   case '=':
   case '>':   goto yy788;
   default:   goto yyErr;
   }
yy788:      (++yydecode);

       
   (--yydecode);
   {
      yyret = SO_HEADER_ANONMY;
      goto yyReturn;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* soRegExpCompareHeader */

/*
*
*       Fun:   soRegExpQ
*
*       Desc:  Description for the regular expression Q
*              
*                 "q"   {return(1);}
*              
*              
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpQ
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 soRegExpQ(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(soRegExpQ)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'q':   goto yy3;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);

   {
      yyret = 1;
      goto yyReturn;
   }





yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* soRegExpQ */


/*
*
*       Fun:   soRegExpQorOther
*
*       Desc:  Description for the regular expression QorOther
*              
*                 any  = [\000-\160] | [\162-\377];
*              
*                 "q" SWS "=" SWS   {return(SO_QVALUE_TYPE);}
*                 any               {return(SO_GENERIC_PARAM_TYPE);}
*              
*              
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpQorOther
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 soRegExpQorOther(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yyDecode = 0;
   

   TRC2(soRegExpQorOther)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case 'q':   goto yy2;
   default:    goto yy4;
   }

yy2:      (++yyDecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);


   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\r')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\n')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }


   if (yych == '=')
   {
      yyret = SO_QVALUE_TYPE;
      goto yyReturn;
   }

yy4:      (++yyDecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   {
      yyret = SO_GENERIC_PARAM_TYPE;
      goto yyReturn;
   }


yyReturn:

   CM_ABNF_DECRET(decCp, yyret, yyDecode, tknCons, len);
} /* soRegExpQorOther */


/* BEGIN: Three new headers support */



PUBLIC Txt *soChPrivacyTag[] =
{
   "ipaddr",    /* SO_PRIVACY_TAG_IP_ADDR */
   "off",       /* SO_PRIVACY_TAG_OFF     */
   NULL         /* SO_PRIVACY_TAG_TOKEN   */
};


/*
*
*       Fun:   soRegExpprivacyTag
*
*       Desc:  Description for the regular expression 
*              Privacy Tag
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: privacy-tag = ("ipaddr" | "off" | token);
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpprivacyTag
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpprivacyTag (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpprivacyTag);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChPrivacyTag,
                           FALSE, TRUE);

   RETVALUE(s);
}  /* End of soRegExpprivacyTag */


/* so017.201 : changed id_type to id-type as per spec */
PUBLIC Txt *soChRpiTokType[] =
{
   "screen",     /* SO_RPI_SCREEN */
   "party",      /* SO_RPI_PTY_TYPE */
   "id-type",    /* SO_RPI_ID_TYPE */
   "privacy",    /* SO_RPI_PRIVACY */
   NULL          /* SO_RPI_OTHER_RPI_TOKEN */
};


/* so017.201 : changed id_type to id-type as per spec */
/*
*
*       Fun:   soRegExpRpiTokType
*
*       Desc:  Description for the regular expression 
*              Rpi-token-type
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: rpi-token-type = ("screen" | "party" | "id-type" |
*                                "privacy" | other-rpi-token);
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpRpiTokType
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpRpiTokType (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpRpiTokType);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChRpiTokType,
                           FALSE, TRUE);

   RETVALUE(s);
}  /* End of soRegExpRpiTokType */




PUBLIC Txt *soChOtherRpiTokenVal[] =
{
   "ordinary",             /* SO_OTHER_RPI_TOK_VAL_ORD  */
   "residential",          /* SO_OTHER_RPI_TOK_VAL_RES  */
   "business",             /* SO_OTHER_RPI_TOK_VAL_BUS  */
   "priority",             /* SO_OTHER_RPI_TOK_VAL_PRI  */
   "hotel",                /* SO_OTHER_RPI_TOK_VAL_HOT  */
   "failure",              /* SO_OTHER_RPI_TOK_VAL_FAIL  */
   "hospital",             /* SO_OTHER_RPI_TOK_VAL_HOSP  */
   "prison",               /* SO_OTHER_RPI_TOK_VAL_PRISON  */
   "police",               /* SO_OTHER_RPI_TOK_VAL_POL  */
   "test",                 /* SO_OTHER_RPI_TOK_VAL_TST  */
   "payphone",             /* SO_OTHER_RPI_TOK_VAL_PAY_PH  */
   "coin",                 /* SO_OTHER_RPI_TOK_VAL_COIN  */
   "payphone-public",      /* SO_OTHER_RPI_TOK_VAL_PUB_PAY_PH  */
   "payphone-private",     /* SO_OTHER_RPI_TOK_VAL_PRIV_PAY_PH  */
   "coinless",             /* SO_OTHER_RPI_TOK_VAL_COINLESS  */
   "restrict",             /* SO_OTHER_RPI_TOK_VAL_RESTRCT  */
   "coin-restrict",        /* SO_OTHER_RPI_TOK_VAL_COIN_RESTRCT  */
   "coinless-restrict",    /* SO_OTHER_RPI_TOK_VAL_COINLESS_RESTRCT  */
   "reserved",             /* SO_OTHER_RPI_TOK_VAL_RESERVE  */
   "operator",             /* SO_OTHER_RPI_TOK_VAL_OPR  */
   "trans-freephone",      /* SO_OTHER_RPI_TOK_VAL_FREE_PH  */
   "isdn-res",             /* SO_OTHER_RPI_TOK_VAL_ISDN_RES  */
   "isdn-bus",             /* SO_OTHER_RPI_TOK_VAL_ISDN_BUS  */
   "unknown",              /* SO_OTHER_RPI_TOK_VAL_UNK  */
   "emergency",            /* SO_OTHER_RPI_TOK_VAL_EMG  */
   "not-applicable",       /* SO_OTHER_RPI_TOK_VAL_NON_APP  */
   "cellular-ordinary",    /* SO_OTHER_RPI_TOK_VAL_CELL_ORD  */
   "cellular-roaming",     /* SO_OTHER_RPI_TOK_VAL_CELL_ROAM  */
   NULL
};


/*
*
*       Fun:   soRegExpOtherRpiTokenVal
*
*       Desc:  Description for the regular expression 
*              Rpi-token-value
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: rpi-token-value
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpOtherRpiTokenVal
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpOtherRpiTokenVal (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpOtherRpiTokenVal);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChOtherRpiTokenVal,
                           FALSE, TRUE);

   RETVALUE(s + 2);
}  /* End of soRegExpOtherRpiTokenVal */





PUBLIC Txt *soChOtherRpiTokenType[] =
{
   "np",    /* SO_OTHER_RPI_TOK_TYP_NP  */
   "-",     /* SO_OTHER_RPI_TOK_TYP_HYP_TOK  */
   NULL     /* SO_OTHER_RPI_TOK_TYP_TOKEN */
};


/*
*
*       Fun:   soRegExpOtherRpiTokenType
*
*       Desc:  Description for the regular expression 
*              other-rpi-token-type
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: other-rpi-token-type = ("np" | "-" token | token);
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpOtherRpiTokenType
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpOtherRpiTokenType (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpOtherRpiTokenType);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChOtherRpiTokenType,
                           FALSE, TRUE);

   RETVALUE(s);
}  /* End of soRegExpOtherRpiTokenType */





PUBLIC Txt *soChRpiPrivElmVal[] =
{
   "network",    /* SO_RPI_PRV_ELM_VAL_NW  */
   NULL          /* SO_RPI_PRV_ELM_VAL_TOKEN */
};


/*
*
*       Fun:   soRegExpRpiPrivElmVal
*
*       Desc:  Description for the regular expression 
*              rpi-priv-element-value
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: rpi-priv-element-value = ("network" | token);
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpRpiPrivElmVal
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpRpiPrivElmVal (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpRpiPrivElmVal);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChRpiPrivElmVal,
                           FALSE, TRUE);

   RETVALUE(s);
}  /* End of soRegExpRpiPrivElmVal */





PUBLIC Txt *soChRpiPrivElmType[] =
{
   "full",    /* SO_RPI_PRV_ELM_TYP_FULL  */
   "name",    /* SO_RPI_PRV_ELM_TYP_NAME  */
   "uri",     /* SO_RPI_PRV_ELM_TYP_URI  */
   "off",     /* SO_RPI_PRV_ELM_TYP_OFF  */
   NULL       /* SO_RPI_PRV_ELM_TYP_TOKEN */
};


/*
*
*       Fun:   soRegExpRpiPrivElmType
*
*       Desc:  Description for the regular expression 
*              rpi-priv-element-type
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: rpi-priv-element-type = ("full" | "name" | "uri" | "off" |
*                                       token);
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpRpiPrivElmType
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpRpiPrivElmType (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpRpiPrivElmType);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChRpiPrivElmType,
                           FALSE, TRUE);

   RETVALUE(s);
}  /* End of soRegExpRpiPrivElmType */




PUBLIC Txt *soChRpiIdTypeVal[] =
{
   "subscriber",    /* SO_RPI_ID_TYPE_SUBS  */
   "user",          /* SO_RPI_ID_TYPE_USER  */
   "term",          /* SO_RPI_ID_TYPE_TERM  */
   NULL             /* SO_RPI_ID_TYPE_TOKEN */
};


/*
*
*       Fun:   soRegExpRpiIdTypeVal
*
*       Desc:  Description for the regular expression 
*              rpi-id-type-value
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: rpi-id-type-value = ("subscriber" | "user" | "term" | token);
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpRpiIdTypeVal
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpRpiIdTypeVal (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpRpiIdTypeVal);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChRpiIdTypeVal,
                           FALSE, TRUE);

   RETVALUE(s);
}  /* End of soRegExpRpiIdTypeVal */




PUBLIC Txt *soChRpiPtyTypeVal[] =
{
   "calling",    /* SO_RPI_PTY_TYPE_CALLING  */
   "called",     /* SO_RPI_PTY_TYPE_CALLED  */
   NULL          /* SO_RPI_PTY_TYPE_TOKEN  */
};


/*
*
*       Fun:   soRegExpRpiPtyTypeVal
*
*       Desc:  Description for the regular expression 
*              rpi-pty-type-value
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: rpi-pty-type = ("calling" | "called" | token);
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpRpiPtyTypeVal
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpRpiPtyTypeVal (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpRpiPtyTypeVal);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChRpiPtyTypeVal,
                           FALSE, TRUE);

   RETVALUE(s);
}  /* End of soRegExpRpiPtyTypeVal */




PUBLIC Txt *soChRpiScreenVal[] =
{
   "no",     /* SO_RPI_SCREEN_NO  */
   "yes",    /* SO_RPI_SCREEN_YES  */
   NULL
};


/*
*
*       Fun:   soRegExpRpiScreenVal
*
*       Desc:  Description for the regular expression 
*              rpi-screen-value
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: rpi-screen-value = ("no" | "yes");
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpRpiScreenVal
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpRpiScreenVal (decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpRpiScreenVal);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChRpiScreenVal,
                           FALSE, FALSE);

   RETVALUE(s);
}  /* End of soRegExpRpiScreenVal */


/*
*
*       Fun:   soRegExpMetaSwsDQuote
*
*       Desc:  Description for the regular expression 
*              
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes:   SWS '"'
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMetaSwsDQuote
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpMetaSwsDQuote(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded          */
   S16   yyRet;      /* Return value                     */
   U16   yyDecode;   /* Number of characters decoded     */

   TRC2(soRegExpMetaSwsDQuote);

   /* Initialize local variables */
   yyRet    = 0;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\r')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\n')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }


   if (yych == '"')
   {
      yyRet = 1;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));


}  /* End of soRegExpMetaSwsDQuote */





/*
*
*       Fun:   soRegExpMetaSwsEqual
*
*       Desc:  Description for the regular expression 
*              
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes:    SWS "="
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMetaSwsEqual
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpMetaSwsEqual(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yych;       /* Character to be decoded          */
   S16   yyRet;      /* Return value                     */
   U16   yyDecode;   /* Number of characters decoded     */

   TRC2(soRegExpMetaSwsEqual);

   /* Initialize local variables */
   yyRet    = RNOK;
   yyDecode = 0;

   yych = cmAbnfGetChar(decCp->offset);

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\r')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   if (yych == '\n')
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }

   while ((yych == ' ') || (yych == '\t'))
   {
      yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
      yyDecode++;
   }


   if (yych == '=')
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret(decCp, yyRet, yyDecode, tknCons, len));


}  /* End of soRegExpMetaSwsEqual */

PUBLIC Txt *soChRfByOrGenPar[] =
{
   "cid",
   NULL
}; /* End of RfByOrGen  */


/*
*
*       Fun:   soRegExpRfByOrGenPar
*
*       Desc:  Description for the regular expression RfByOrGenPar
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpRfByOrGenPar
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpRfByOrGenPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpRfByOrGenPar);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChRfByOrGenPar,
                           FALSE, TRUE);

   RETVALUE(s);
}  /* End of soRegExpRfByOrGenPar */


PUBLIC Txt *soChSubExpReason[] =
{
   "deactivated",
   "probation",
   "rejected",
   "timeout",
   "giveup",
   "noresource",
   NULL
}; /* End of SubExpReason  */



/*
*
*       Fun:   soRegExpSubExpReason
*
*       Desc:  Description for the regular expression SubExpReason
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: SubExpReason
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpSubExpReason
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpSubExpReason(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpSubExpReason);

   /* Initialize local variable */
   s = RNOK;

   /* so030.201: 
    * Checking case insensitiveness of Parameter */
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChSubExpReason,
                           TRUE, TRUE);     
   
   RETVALUE(s);
}  /* End of soRegExpSubExpReason */



PUBLIC Txt *soChSubStateVal[] =
{
   "active",
   "pending",
   "terminated",
   NULL
}; /* End of SubStateVal   */


/*
*
*       Fun:   soRegExpSubStateVal
*
*       Desc:  Description for the regular expression SubStateVal
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: SubStateValue
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpSubStateVal
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpSubStateVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpSubStateVal);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChSubStateVal,
                           FALSE, TRUE);

   RETVALUE(s);
}  /* End of soRegExpSubStateVal */




PUBLIC Txt *soChSubExpPar[] =
{
   "reason",
   "expires",
   "retry-after",
   NULL
}; /* End of SubExpPar  */


/*
*
*       Fun:   soRegExpSubExpPar
*
*       Desc:  Description for the regular expression SubExpPar
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpSubExpPar
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpSubExpPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpSubExpPar);

   /* Initialize local variable */
   s = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChSubExpPar,
                           TRUE, TRUE);      
   
   RETVALUE(s);
}  /* End of soRegExpSubExpPar */


PUBLIC Txt *soChSecMechName[] =
{
   "digest",
   "tls",
   "ipsec-ike",
   "ipsec-man",
   NULL
}; /* End of soChSecMechName  */


/*
*
*       Fun:   soRegExpMechName
*
*       Desc:  Description for the regular expression soRegExpMechName
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMechName
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpMechName(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpMechName);

   /* Initialize local variable */
   s = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChSecMechName,
                           TRUE, TRUE);      
   
   RETVALUE(s);
}  /* End of soRegExpMechName */


PUBLIC Txt *soChSecMechPar[] =
{
   "q",
   "d-alg",
   "d-qop",
   "d-ver",
   NULL
}; /* End of soChSecMechPar  */


/*
*
*       Fun:   soRegExpMechPar
*
*       Desc:  Description for the regular expression soRegExpMechPar
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpMechPar
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpMechPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpMechPar);

   /* Initialize local variable */
   s = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChSecMechPar,
                           TRUE, TRUE);       
   
   RETVALUE(s);
}  /* End of soRegExpMechPar */


PUBLIC Txt *soChReasonPar[] =
{
   "cause",
   "text",
   NULL
}; /* End of soChReasonPar  */


/*
*
*       Fun:   soRegExpReasonPar
*
*       Desc:  Description for the regular expression soRegExpReasonPar
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpReasonPar
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpReasonPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   s = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChReasonPar,
                           TRUE, TRUE);     
   
   RETVALUE(s);
}  /* End of soRegExpReasonPar */


/*
*
*       Fun:   soRegExpPMediaAuthTkn
*
*       Desc:  Description for the regular expression soRegExpPMediaAuthTkn
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpPMediaAuthTkn
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpPMediaAuthTkn(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16   yyRet;      /* Return value                   */
   U16   yyDecode;   /* Number of characters decoded   */

   TRC2(soRegExpIpv6Address);

    /* Initializing local variables */
   yyDecode = 0;
   yyRet = RNOK;

   if ( soRegExpAlphaNumericSpecial (
            "",  /* include these special chars */
            0,TRUE, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpPMediaAuthTkn */


PUBLIC Txt *soChPrivValPar[] =
{
   "header",
   "session",
   "user",
   "none",
   "critical",
   "id",
   NULL
}; /* End of soChPrivValPar  */


/*
*
*       Fun:   soRegExpPrivVal
*
*       Desc:  Description for the regular expression soRegExpPrivVal
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpPrivVal
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpPrivVal(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpPrivVal);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChPrivValPar,
                           FALSE, TRUE);

   RETVALUE(s);
}  /* End of soRegExpPrivVal */


/* RFC 2806 : Tel URL */
#ifdef SO_ENUM
/*
*
*       Fun:   soRegExpTelPhoneContext
*
*       Desc:  Description for the regular expression soRegExpTelPhoneContext
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpTelPhoneContext
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpTelPhoneContext(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 yyRet;     /* Return value                           */
   U16 yyDecode;  /* Number of characters decoded           */

   TRC2(soRegExpTelPhoneContext);

   /* Initialize local variables */
   yyDecode = 0;
   yyRet = RNOK;

   if ( soRegExpAlphaNumericSpecial (
            "+-.()*#%",
            0, FALSE, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));

}  /* End of soRegExpTelPhoneContext */


/*
*
*       Fun:   soRegExpTelLocNum
*
*       Desc:  Description for the regular expression soRegExpTelLocNum
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpTelLocNum
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpTelLocNum(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 yyRet;     /* Return value                           */
   U16 yyDecode;  /* Number of characters decoded           */

   TRC2(soRegExpTelLocNum);

   /* Initialize local variables */
   yyDecode = 0;
   yyRet = RNOK;

   if ( soRegExpAlphaNumericSpecial (
            "-.()*#",
            0, FALSE, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));

}  /* End of soRegExpTelLocNum */


/*
*
*       Fun:   soRegExpTelNum
*
*       Desc:  Description for the regular expression soRegExpTelNum
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpTelNum
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpTelNum(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 yyRet;     /* Return value                           */
   U16 yyDecode;  /* Number of characters decoded           */

   TRC2(soRegExpTelNum);

   /* Initialize local variables */
   yyDecode = 0;
   yyRet = RNOK;

   if ( soRegExpAlphaNumericSpecial ( "-.()",
            0, TRUE, decCp, mem, len, &yyDecode)==ROK )
   {
      yyRet = ROK;
      if (soAbnfDecCspStrXl(decCp, mem, len, yyDecode) != ROK) 
         return (-1);
   }

   RETVALUE(soAbnfDecret (decCp, yyRet, yyDecode, tknCons, len));
}  /* End of soRegExpTelNum */


PUBLIC Txt *soChTelNumPar[] =
{
   "isub",
   "postd",
   "phone-context",
   "tsp",
   "rn",
   "npdi",
   "cic",
   NULL
}; /* End of soChPrivValPar  */


/*
*
*       Fun:   soRegExpTelNumPar
*
*       Desc:  Description for the regular expression soRegExpTelNumPar
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpTelNumPar
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpTelNumPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 s;

   TRC2(soRegExpTelNumPar);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChTelNumPar,
                           FALSE, TRUE);

   RETVALUE(s);
}  /* End of soRegExpTelNumPar */


/*
*
*       Fun:   soRegExpTelUrl
*
*       Desc:  Description for the regular expression soRegExpTelUrl
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpTelUrl
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpTelUrl(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif
{
   S16 yyRet;

   TRC2(soRegExpTelUrl);

   /* Initialize local variable */
   yyRet = 2;

   if (soRegExpStrCmp(decCp, tknCons, mem, len, "+", 1, FALSE) == ROK)
      yyRet = 1;

   RETVALUE(yyRet);
}  /* End of soRegExpTelUrl */


#endif

#ifdef SO_SESSTIMER
PUBLIC Txt *soChSessExpPar[] =
{
   "refresher",
   NULL
}; /* End of soChSessExpPar  */


/*
*
*       Fun:   soRegExpSessExpPar
*
*       Desc:  Description for the regular expression soRegExpSessExpPar
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpSessExpPar
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpSessExpPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpSessExpPar);

   /* Initialize local variable */
   s = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChSessExpPar,
                           TRUE, TRUE);           
   
   RETVALUE(s);
}  /* End of soRegExpSessExpPar */

PUBLIC Txt *soChRefresherPar[] =
{
   "uac",
   "uas",
   NULL
}; /* End of soChRefresherPar  */


/*
*
*       Fun:   soRegExpRefresherPar
*
*       Desc:  Description for the regular expression soRegExpRefresherPar
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpRefresherPar
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpRefresherPar(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpRefresherPar);

   /* Initialize local variable */
   s = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChRefresherPar,
                           TRUE, TRUE);      

   RETVALUE(s);
}  /* End of soRegExpRefresherPar */

#endif /* SO_SESSTIMER */

#ifdef SO_CALLERPREF

PUBLIC Txt *soChFeatPar[] =
{
   "audio",       /* SO_CONTACTPARAM_FEAT_PARAM */
   "automata",    /* SO_CONTACTPARAM_FEAT_PARAM */
   "class",       /* SO_CONTACTPARAM_FEAT_PARAM */
   "duplex",      /* SO_CONTACTPARAM_FEAT_PARAM */
   "data",        /* SO_CONTACTPARAM_FEAT_PARAM */      
   "control",     /* SO_CONTACTPARAM_FEAT_PARAM */
   "mobility",    /* SO_CONTACTPARAM_FEAT_PARAM */      
   "description", /* SO_CONTACTPARAM_FEAT_PARAM */
   "events",      /* SO_CONTACTPARAM_FEAT_PARAM */
   "priority",    /* SO_CONTACTPARAM_FEAT_PARAM */      
   "methods",     /* SO_CONTACTPARAM_FEAT_PARAM */      
   "schemes",     /* SO_CONTACTPARAM_FEAT_PARAM */      
   "application", /* SO_CONTACTPARAM_FEAT_PARAM */      
   "video",       /* SO_CONTACTPARAM_FEAT_PARAM */
   "language",    /* SO_CONTACTPARAM_FEAT_PARAM */
   "type",        /* SO_CONTACTPARAM_FEAT_PARAM */      
   "isfocus",     /* SO_CONTACTPARAM_FEAT_PARAM */      
   "actor",       /* SO_CONTACTPARAM_FEAT_PARAM */      
   "text",        /* SO_CONTACTPARAM_FEAT_PARAM */      
   NULL
}; /* End of soChFeatPar  */

 
/*
*
*       Fun:   soRegExpFeatParam
*
*       Desc:  Description for the regular expression soRegExpFeatParam
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpFeatParam
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpFeatParam(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpFeatParam);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChFeatPar,
                           FALSE, TRUE);

   RETVALUE(s);
}  /* End of soRegExpFeatParam */


PUBLIC Txt *soChAcPar[] =
{
   "",           /* SO_ACCEPTCONTACT_PAR_FP    */
   "require",    /* SO_ACCEPTCONTACT_REQUIRE   */
   "explicit",   /* SO_ACCEPTCONTACT_EXPLICIT  */
   NULL
}; /* End of soChAcPar  */

/*
*
*       Fun:   soRegExpAcParam
*
*       Desc:  Description for the regular expression soRegExpAcParam
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpAcParam
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpAcParam(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpAcParam);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpFeatParam(decCp, FALSE, mem, len);

   if ((s == RNOK) || (s == SO_FEAT_PAR_EXTN))
   {   
      s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChAcPar, FALSE, TRUE);
   }
   else   
   {   
      s = SO_ACCEPTCONTACT_PAR_FP;
   }

   RETVALUE(s);
}  /* End of soRegExpAcParam */

/*
*
*       Fun:   soRegExpRcParam
*
*       Desc:  Description for the regular expression soRegExpRcParam
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpRcParam
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpRcParam(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpRcParam);

   /* Initialize local variable */
   s = RNOK;

   s = soRegExpFeatParam(decCp, FALSE, mem, len);

   if ((s == RNOK) || (s == SO_FEAT_PAR_EXTN))
   {   
      s = SO_REJECTCONTACT_PAR_EXTN;
   }
   else   
   {   
      s = SO_REJECTCONTACT_PAR_FP;
   }

   RETVALUE(s);
}  /* End of soRegExpRcParam */

#endif /* SO_CALLERPREF */


PUBLIC Txt *soChCompPar[] =
{
   "sigcomp",       /* SO_COMP_SIGCOMP */
   NULL
}; /* End of soChFeatPar  */


/*
*
*       Fun:   soRegExpCompParam
*
*       Desc:  Description for the regular expression soRegExpCompParam
*
*       Ret:   < 0 failure
*              > 0  success
*
*       Notes: Other = token
*
*       File:  so_rx
*
*/

#ifdef ANSI
PUBLIC S16 soRegExpCompParam
(
CmAbnfDecCp *decCp,             /* Decode control point           */
Bool        tknCons,            /* Token to be consumed           */
U8          **mem,              /* memory pointer                 */
U16         *len                /* length of the string returned  */
)
#else
PUBLIC S16 soRegExpCompParam(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;             /* Decode control point           */
Bool        tknCons;            /* Token to be consumed           */
U8          **mem;              /* memory pointer                 */
U16         *len;               /* length of the string returned  */
#endif

{
   S16 s;

   TRC2(soRegExpCompParam);

   /* Initialize local variable */
   s = RNOK;
   
   /* so030.201: 
    * Checking case insensitiveness of Parameter */ 
   s = soRegExpChoiceCmp(decCp, tknCons, mem, len, soChCompPar,
                           TRUE, TRUE);       
   
   RETVALUE(s);
}  /* End of soRegExpCompParam */

/********************************************************************30**

         End of file:     so_rx.c@@/main/4 - Tue Apr 20 12:47:01 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**


*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---      ms   1. initial release.
/main/1+    so002.11  us   1. miscellaneous.
/main/1+    so003.101 scc  1. missing allowable chars for CallId
/main/1+    so007.101 hd   1. UTF8 fix, decrease the loop limit by one. 
                              The decoder was expecting one character 
                              too many, compared to the specification.
/main/1+    so011.101 hd   1. Make soRegExpLineWrap() as strict as 
                              the specification.
                           2. Fix definition of Record-Route header,
                              it was missing the "-"
                      us   3. miscellaneous.                              
/main/1+    so014.101 bdu  1. Add several missing chars.
/main/1+    so020.101 bdu  1. Modified soRegExpChoiceCmp to fix decoding 
                              issues.
/main/1+    so021.101 pk   1. Modified soRegExpChoiceCmp function to
                              fix decoding errors.
/main/1+    so025.101 yj   1. Added NAT support
/main/2      ---      us   1. support for tel URL decoding added.
                      us   2. TEL URL handling related changes.
                      cy   3. Changed copyright header.
/main/2+    so001.102 cvp  1. Misc bug fixes.
                      mc   2. global function reorg.
/main/2+    so002.102 bdu  1. change for lr parameter.
                      hd   2. Addition: Check return value in case of 
                              there is no end of line: \r\n. 
            so005.102 hd   1. Addition: SO_EVENT_HDR related changes.
                      bdu  2. Fixed decoding check for CRLF
            so006.102 ps   1. New functions to optimize header comparison
                              and finding end of SIP headers.
            so008.102 bdu  1. add more speical chars.
            so009.102 zmc  1. add more speical chars.
                      pk   2. Changes from short form to long form for 
                              header names.
            so013.102 zmc  1. Fix the bug in PName and PValue 
                              expression checking
            so014.102 pg   1. SO_EVENT has been replaced with SO_EVENT_HDR flag.
                              If SO_EVENT has been defined then SO_EVENT_HDR has been
                              defined as well.
/main/4      ---      ms   1. Release for 2.1.
/main/4+    so001.201 up   1. Added new regExp for soRegExpMetaDNLws
/main/4+    so007.201 up   1. Changes for rport support 
/main/4+    so008.201 ab   1. Modified soRegExpChoiceCmp to fix decoding issues to
                              to handle long string junk characters.
/main/4+    so017.201 pk   1. Changed id_type to id-type for RpId as 
                              per spec
/main/4+    so020.201 ps   1. Change to recognize "lr=on" parameter and ignore
                              the "=on" part of it.
/main/4+    so021.201 ps   1. Corrected error in decoding of unknown parameters
/main/4+    so023.201 ab   1. Changes to allow space after colon while encoding.
/main/4+    so028.201 ss   1. Changed to decode phone-context value
/main/4+    so029.201 ad   1. Change to recognize "lr=true" parameter and ignore
                              the "=true" part of it. 
/main/4+    so030.201 ss   1. Change to compare case-insensitivity of parameter. 
/main/4+    so038.201 aj   1. Added the function for moving the expires,q,tags as the
                              contact params in stead of Url Parameters
                           2. Added "," in the regular expression for Host
                              
                           
*********************************************************************91*/
