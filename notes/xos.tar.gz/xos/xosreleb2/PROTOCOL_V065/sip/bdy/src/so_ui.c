/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    Sip  Upper Interface

     Type:    C source file

     Desc:    C source code for SIP's Upper Interface

     File:    po_ui.c

     Sid:      so_ui.c@@/main/5 - Tue Apr 20 12:47:34 2004

     Prg:     wh

*********************************************************************21*/

/*
 *
 *  TAPA Primitives
 *                              SU       SIP
 *      SoUiSotBndReq             -------->
 *      SoUiSotBndCfm             <--------
 *      SoUiSotUBndReq            -------->
 *
 *  Session Management Primitives
 *                              SU       SIP
 *    Initiate new session
 *      SoUiSotConReq             -------->
 *      SoUiSotConCfm             <--------
 *      SoUiSotConInd             <--------
 *      SoUiSotConRsp             -------->
 *    Session status (call progress, ACK, etc)
 *      SoUiSotCnStReq            -------->
 *      SoUiSotCnStInd            <--------
 *      SoUiSotAckReq             -------->
 *      SoUiSotAckInd             <--------
 *      SoUiSotCancelReq          -------->
 *      SoUiSotCancelInd          <--------
 *    Modify existing session
 *      SoUiSotModReq             -------->
 *      SoUiSotModCfm             <--------
 *      SoUiSotModInd             <--------
 *      SoUiSotModRsp             -------->
 *    Terminate session
 *      SoUiSotRelReq             -------->
 *      SoUiSotRelCfm             <--------
 *      SoUiSotRelInd             <--------
 *      SoUiSotRelRsp             -------->
 *
 *  Call Associated Primitives    
 *      SoUiSotCAMReq             -------->
 *      SoUiSotCAMCfm             <--------
 *      SoUiSotCAMInd             <--------
 *      SoUiSotCAMRsp             -------->
 *      
 *  Call Independent Primitives
 *                              SU       SIP
 *      SoUiSotCIMReq             -------->
 *      SoUiSotCIMCfm             <--------
 *      SoUiSotCIMInd             <--------
 *      SoUiSotCIMRsp             -------->
 *
 *
 */


/* header include files (.h) */
#include "envopt.h"         /* environment options          */
#include "envdep.h"         /* environment dependent        */
#include "envind.h"         /* environment independent      */
#include "gen.h"            /* general layer                */
#include "ssi.h"            /* system services              */
#include "cm_hash.h"        /* common hash list             */
#include "cm_llist.h"       /* common linked list           */
#include "cm_tpt.h"         /* common transport             */
#include "cm_tkns.h"        /* common tokens                */
#include "cm_sdp.h"         /* common SDP                   */
#include "cm_dns.h"         /* common DNS                   */
#include "cm_mblk.h"        /* common memory allocation     */
#include "cm_abnf.h"       /* common abnf */
#include "cm_dns.h"         /* common DNS                   */
#include "sot.h"            /* SOT interface                */
#include "lso.h"            /* layer management, SIP        */
#include "so.h"             /* SIP layer defines            */
#include "so_trans.h"       /* SIP transaction related structures */
#include "so_err.h"         /* SIP error defines            */
#include "so_cm.h"          /* SIP layer utility functions  */

#ifdef CP_OAM_SUPPORT
#include "su_cfg.h"
#include "so_cfg.h"
#include "sm.h"
#include "oam_interface.h"
#include "so_nms.h"
#include "xosshell.h"
#include "cp_tab_def.h"
#endif

#ifdef SSI_WITH_CLI_ENABLED
#include "clishell.h"
#endif

/* header/extern include files (.x) */
#include "gen.x"            /* general layer                */
#include "ssi.x"            /* system services              */
#include "cm5.x"            /* common timer module          */
#include "cm_lib.x"         /* common library               */
#include "cm_llist.x"       /* common link list             */
#include "cm_hash.x"        /* common hash list             */
#include "cm_llist.x"       /* common linked list           */
#include "cm_tkns.x"        /* common tokens                */
#include "cm_tpt.x"         /* common transport             */
#include "cm_xtree.x"       /* common radix tree            */
#include "cm_dns.x"         /* common DNS                   */
#include "cm_mblk.x"        /* common memory allocation     */
#include "cm_sdp.x"         /* common SDP                   */
#include "cm_abnf.x"       /* common abnf library */
#include "cm_dns.x"         /* common DNS                   */
#include "sot.x"            /* SOT interface                */
#include "lso.x"            /* layer management SIP         */
#include "so_tcm.x"             /* SIP layer structures         */
#include "so.x"             /* SIP layer structures         */
#include "so_trans.x"       /* SIP transaction related structures */
#include "so_utl.x"         /* utility functions            */
#include "so_cm.x"          /* SIP layer utility functions  */
#include "so_ua.x"          /* interface between UI and UA  */
/*#include "so_core.x"    */    /* SIP layer core functions     */
#include "so_cl.x"          /* SIP cache                    */
#include "so_lcs.x"         /* Location services            */

#ifdef CP_OAM_SUPPORT
#include "su_cfg.x"
#include "so_oam.x"
#include "so_cfg.x"
#include "sm.x"
#endif

#ifdef SSI_WITH_CLI_ENABLED
#include "so_dbg.x"
#endif

/* local defines */

EXTERN U32 g_soDbgMask;

#define SOUI_LOGERROR(err,val,msg)      \
{                                       \
      SOLOGERROR(ERRCLS_DEBUG, err,     \
                 (ErrVal) val,          \
                 msg);                  \
}

/*--- so015.201: Macro To Print UI Primitive Parameters ---*/
#define SO_UI_PRNT_OUT(_prim, _suId, _spConnId, _suConnId, _event)      \
{                                                                       \
   SODBGP_SO (DBGMASK_UI, (soCb.init.prntBuf,                           \
               "\n\n SSAP(%d) <-- %s -- SIP: EVENT(%s)  spConnId(%ld)  "\
               "suConnId(%ld)  CallLegId(%lx)  TransId(%lx) \n",        \
               _suId, _prim,                                            \
               soSOTEventDescrip[_event->eventType.val - 1],            \
               _spConnId, _suConnId,                                    \
               _event->callLegId   ,                                    \
               _event->transId));                                       \
}

#define SO_UI_PRNT_IN(_prim, _suId, _spConnId, _suConnId, _event)       \
{                                                                       \
   SODBGP_SO (DBGMASK_UI, (soCb.init.prntBuf,                           \
               "\n\n SSAP(%d) -- %s --> SIP: EVENT(%s)  spConnId(%ld)  "\
               "suConnId(%ld)  CallLegId(%lx)  TransId(%lx) \n",        \
               _suId, _prim,                                            \
               soSOTEventDescrip[_event->eventType.val - 1],            \
               _spConnId, _suConnId,                                    \
               _event->callLegId   ,                                    \
               _event->transId));                                       \
}

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

EXTERN Txt *soSOTErrorDescrip[SOT_ERR_UNKNOWN+1];
EXTERN Txt *soSOTEventDescrip[];

#ifdef __cplusplus
}
#endif /* __cplusplus */


PUBLIC Txt *soSOTEventDescrip[]=
{
   "INVITE",
   "ACK",
   "OPTIONS",
   "BYE",
   "CANCEL",
   "REGISTER",
   "INFO",
   "CONMET",
   "PRACK",
   "REFER",
   "SUBSCRIBE",
   "NOTIFY",
   "MESSAGE",
   "UPDATE",
   "PROGRESS",
   "TRYING",
   "RINGING",
   "FORWARDING",
   "QUEUED",
   "REDIRECT",
   "INTERNAL_ERROR",
   "OK",
   "REG_TIMEOUT",
   "LOC REQUEST",
   "MODIFY",
   "STATUS",
   "UNKNOWN",
   "REGISTER_LOC",
   "SIP_ERROR",
   "REFRESH_TIMER_EXPIRED",
   "SESSTIMER_EXPIRED",
   "SUBSCRIPTION_TIMER_EXPIRED",
   "AUDIT REQUEST",
   "REFRESH INDICATION",
   "EVENT MAX"
};

PUBLIC Txt *soSOTErrorDescrip[SOT_ERR_UNKNOWN+1]=
{  
   "No Error",
   "Timeout error",
   "Encoding error",
   "Resource error",
   "Invalid Entity for request",
   "Invalid request for this primitive",
   "Invalid eventType for this primitive",
   "Non-IP address, but no DNS available",
   "INVITE request expected",
   "User must be locally registered",
   "User unavailable at the moment",
   "No Registrar Adr configured for this entity",
   "Invite Request build failed",
   "Register Request build failed",
   "Transport server could not be selected",
   "DNS Lookup has failed",
   "Error while added a SIP header to a message",
   "CALL not found for this Call-Id",
   "Call Leg already exists",
   "Call Leg not found",
   "Transaction not found",
   "Could not create/locate Transaction",
   "Require header failed to add to msg",
   "RSEQ could not be added to msg",
   "Local Reg is for 3rd Party",
   "Local Reg has failed",
   "Disable/Delete SSAP",
   "Disable/Delete Entity",
   "Error in sending SIP message",
   "Error while adding Record-Route header",
   "Invalid Contact header (*, expires)",
   "Invalid primitive in this call leg state",
   "Required CONTENTTYPE header not found",
   "MIME Boundary value not found",
   "CallId not specified",
   "Via header not matching with correct transport server",
   "Another registration in Progress",
   "CSeq number is not acceptable",
   "Reliable prov rsp not supported",
   "Invalid event",
   "Invalid SSAP",
   "Invalid Entity",
   "Invalid Entity State",
   "Invalid SSAP State",
   "Subscribe timeout",
   "Refer timeout",
   "Invalid callid ",
   "INVALID Header",
   "Unsuported method",
   "Additional call legs for a forked call being cleared ",
   "Expires Timer timeout ",
   "Cancel Timer Expiry ",
   "Answer pending for offer sent earlier",
   "Offer Required",
   "Mandatory Header Error",
   "Maximum value of error code",
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   "UnKnown"
};

/* local function definitions */

PRIVATE S16 soUiValidatePrimitive  ARGS((SpId     spId,
                                         U8       primitiveType,
                                         SoEvnt   *evnt,
                                         SoSSapCb **ssapCb));

PRIVATE S16 soUiCheckEvnt          ARGS((SoEvnt   *soEvnt));

PRIVATE Void soUiFillErrEvnt       ARGS((SoEvnt   **errEvnt, 
                                         SoEvnt   *evnt, 
                                         U32      legId,
                                         U8       evntType,
                                         U16       errorType, 
                                         Bool     callCleared));
#ifdef SO_REL_1_2_INF
PRIVATE S16 soWrapOutInf           ARGS((Pst      *pst, 
                                         U8       primType,
                                         SpId     spId, 
                                         UConnId  *ptrSpConnId, 
                                         UConnId  *ptrSuConnId, 
                                         SoEvnt   *soEvnt));

 /* so009.201 : Added new parameter suConnId to function call */
PRIVATE S16 soWrapIncomingInf      ARGS((U8       primitiveType,
                                         UConnId  suConnId,
                                         Ptr      context,
                                         SoEvnt   *soEvnt));

PRIVATE S16 soWrapErrInd           ARGS((SoSSapCb *ssapCb, 
                                         UConnId  suConnId, 
                                         UConnId  spConnId,
                                         U8       evntType,
                                         Bool     requestMsg,
                                         SoEvnt   *errEvnt));

PRIVATE S16 soWrapTmrRefresh        ARGS((Pst      *pst, 
                                          SuId     suId,
                                          UConnId  spConnId, 
                                          UConnId  suConnId, 
                                          SoEvnt   *soEvnt,
                                          U8       tmrType));

 /* so019.201 : Change the return type to 32-bit UConnId */
PRIVATE UConnId soWrapFindConnId    ARGS((SpId     spId,
                                          SoEvnt   *evnt));

#endif /* SO_REL_1_2_INF */

#ifndef SO_REL_1_2_INF

PRIVATE S16 soUiFillRegRefreshInfo ARGS((SoEvnt      *reqEvnt,
                                         SoEvnt      *refreshEvnt
                                         ));
#ifdef SO_UA
/* ccpu00062158 */
PRIVATE S16 soUiFillSSAPCallInfo   ARGS((Pst      *pst,
                                         SoEvnt   **evnt,
                                         SoSSapCb *ssap, 
                                         SoEntCb  *ent));

PRIVATE S16 soUiFillCallInfo       ARGS((SoAuditInfo *callInfo,
                                         SoCallCb *call));
#endif /* SO_UA */
#endif


#ifdef SO_REL_1_2_INF

/*****************************************************************************
*
*      Fun:   soWrapOutInf
*
*      Desc:  Wrapper function for Rel 1.2 interface. If interface 
*             changes in new release, call the new one. Otherwise return
*             ROKDNA.
*
*      Ret:   ROKDNA : no wrapper function needed
*             
*
*      Notes: 
*      File:  so_ua.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soWrapOutInf
(
Pst            *pst,            /* post structure */
U8             primType,        /* Primitive Type */
SpId           spId,            /* service provider SAP identifier */
UConnId        *ptrSpConnId,    /* SP connection Id ptr */
UConnId        *ptrSuConnId,    /* SU connection Id ptr*/
SoEvnt         *soEvnt          /* SIP messages event structure */
)
#else
PRIVATE S16 soWrapOutInf(pst, primType, spId, ptrSpConnId, ptrSuConnId, soEvnt)
Pst            *pst;            /* post structure */
U8             primType;        /* Primitive Type */
SpId           spId;            /* service provider SAP identifier */
UConnId        *ptrSpConnId;    /* SP connection Id ptr */
UConnId        *ptrSuConnId;    /* SU connection Id ptr*/
SoEvnt         *soEvnt;         /* SIP messages event structure */
#endif
{
   S16            ret;          /* value returned by function calls */
   UConnId        suConnId;     /* Service User connId */
   UConnId        spConnId;     /* Service User connId */
   
   TRC3(soWrapOutInf);

   ret = ROKDNA;
   suConnId = *ptrSuConnId;
   spConnId = *ptrSpConnId;

   switch(primType)
   {
      case EVTSOTCIMREQ:                  /* CIM request */
         if ((soEvnt->eventType.val == SOT_ET_MESSAGE) ||
             (soEvnt->eventType.val == SOT_ET_OPTIONS))
            ret = SoUiSotCAMReq(pst, spId, spConnId, suConnId, soEvnt);
         break;
      
      case EVTSOTCIMRSP:
         /*
          * In SIP 2.1 release, methods like  OPTION and MESSAGE
          * are part of CAM primitive. These methods can be used
          * both within and outside a dialog.
          * So for these methods, invoke CAMRsp primitive.
          */

        /* If no suconnId & spConnId are present 
           connId identifying the call */
         spConnId = soWrapFindConnId(spId, soEvnt);
         *ptrSpConnId = spConnId;
      
         if ((soEvnt->eventType.val == SOT_ET_MESSAGE) ||
             (soEvnt->eventType.val == SOT_ET_OPTIONS))
         {
           /* When mapping CIM to CAM, we need to find the 
              connId identifying the call leg */
            ret = SoUiSotCAMRsp(pst, spId, spConnId, suConnId, soEvnt);
         }
         break;
     
      case EVTSOTCNSTREQ:                 /* connection status request */
         if(soEvnt->eventType.val == SOT_ET_ACK)
            ret = SoUiSotAckReq(pst, spId, spConnId, suConnId, soEvnt);
         break;
         
      case EVTSOTRELREQ:                  /* release request */
         if(soEvnt->sipMessageType.val == SO_SIPMESSAGE_RESPONSE)
         {
            if((soEvnt->eventType.val == SOT_ET_STATUS) ||
               (soEvnt->eventType.val == SOT_ET_REDIRECT) ||
               (soEvnt->eventType.val == SOT_ET_INVITE))
            {
               soEvnt->eventType.val = SOT_ET_INVITE;
               /* ConRsp is used to Tx final response for Invite */
               ret = SoUiSotConRsp(pst, spId, spConnId, suConnId, soEvnt);
            }
         }
         else
         {
            if(soEvnt->eventType.val == SOT_ET_CANCEL)
               ret = SoUiSotCancelReq(pst, spId, spConnId, suConnId, soEvnt);
            else if(soEvnt->eventType.val == SOT_ET_REFER)
               ret = SoUiSotCAMReq(pst, spId, spConnId, suConnId, soEvnt);
         }
         break;
         
      case EVTSOTRELRSP:                  /* release response */
         if (soEvnt->t.response.statusLine.statusCode.val == 
             SOT_RSP_487_REQ_TERMINATED)
               /* ConRsp is used to Tx final response for Invite */
              ret = SoUiSotConRsp(pst, spId, spConnId, suConnId, soEvnt);
         break;

      case EVTSOTMODREQ:
         soEvnt->eventType.val = SOT_ET_INVITE;
         break;

      case EVTSOTCONREQ:
      case EVTSOTCONRSP:
      case EVTSOTMODRSP:
         break;

      default:
         /* other primitives do not need wrap */
         ret = ROKDNA;
   }

   RETVALUE(ret);
}


 /* so009.201 : Added new parameter suConnId to function call */


/*****************************************************************************
*
*      Fun:   soWrapIncomingInf
*
*      Desc:  Wrapper function for Rel 1.2 interface. If interface 
*             changes in new release, call the new one. Otherwise return
*             ROKDNA.
*
*      Ret:   ROKDNA : no wrapper function needed
*             
*
*      Notes: 
*      File:  so_ua.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soWrapIncomingInf
(
U8             primitiveType,
UConnId        suConnId,    /* Service User Conn Id */
Ptr            context, 
SoEvnt         *soEvnt          /* SIP messages event structure */
)
#else
PRIVATE S16 soWrapIncomingInf(primitiveType, suConnId, context, soEvnt)
U8             primitiveType;
UConnId        suConnId;    /* Service User Conn Id */
Ptr            context; 
SoEvnt         *soEvnt;         /* SIP messages event structure */
#endif
{
   S16         ret;          /* value returned by function calls */
   U16         eventType;    /* Local Event Type */
   U16         responseCode;      /* response code                */
   U16         responseClass;     /* response class               */

   TRC3(soWrapIncomingInf);
 
   ret = ROKDNA;
   eventType = soEvnt->eventType.val;
   
   if (soEvnt->sipMessageType.val == SO_SIPMESSAGE_RESPONSE)
   {
      responseCode = soEvnt->t.response.statusLine.statusCode.val;
      responseClass = responseCode/100; 
      
      if(responseClass == SO_STACODE_TYPE_REDIR)
         soEvnt->eventType.val = SOT_ET_REDIRECT;
      
      else if(responseClass == SO_STACODE_TYPE_GLFAIL ||
                responseClass == SO_STACODE_TYPE_SRVERR ||
                responseClass == SO_STACODE_TYPE_CLERR)
                soEvnt->eventType.val = SOT_ET_SIP_ERROR;
      
      else if(responseClass == SO_STACODE_TYPE_SUCCESS)
                soEvnt->eventType.val = SOT_ET_OK;

      else
      {
        switch(responseCode)
        {
          case SOT_RSP_180_RINGING:
            soEvnt->eventType.val = SOT_ET_RINGING;
            break;
            
          case SOT_RSP_181_FORWARDED:
            soEvnt->eventType.val = SOT_ET_FORWARDING;
            break;
            
          case SOT_RSP_182_QUEUED:
            soEvnt->eventType.val = SOT_ET_QUEUED;
            break;
            
          case SOT_RSP_183_SESSION_PROGRESS:
            soEvnt->eventType.val = SOT_ET_PROGRESS;
            break;
            
          case SOT_RSP_100_TRYING:
            soEvnt->eventType.val = SOT_ET_TRYING;
            break;
            
          default:
            soEvnt->eventType.val = SOT_ET_STATUS;
            break;
        }
        
      }
   } /* If response */

   switch(primitiveType)
   {
      case EVTSOTCONCFM:
         /* so009.201 : Added new parameter suConnId to function call */
        if ((soEvnt->sipMessageType.val == SO_SIPMESSAGE_RESPONSE) &&
            (responseClass != SO_STACODE_TYPE_SUCCESS))
        {
          if (responseCode == SOT_RSP_487_REQ_TERMINATED)
            ret = soUiRelCfm(suConnId, (SoCallCb *)context, soEvnt);
          else
            ret = soUiRelInd(suConnId, (SoCallCb *)context, soEvnt);
        }
        break;
     case EVTSOTACKIND:
        /* so009.201 : Added new parameter suConnId to function call */
       ret = soUiCnStInd(suConnId, (SoCallCb *)context, soEvnt);
       break;
     case EVTSOTCANCELIND:      
       ret = soUiRelInd(suConnId, (SoCallCb *)context, soEvnt);
       break;
     case EVTSOTCAMIND:
       if(eventType == SOT_ET_OPTIONS || eventType == SOT_ET_MESSAGE)
         ret = soUiCIMInd((((SoCallCb *)(context))->ssapCb), 
                          SOT_CONNID_NOTUSED,
                          SOT_CONNID_NOTUSED, soEvnt);
       break;
     case EVTSOTCAMCFM:
       if(eventType == SOT_ET_OPTIONS ||
          eventType == SOT_ET_MESSAGE)
         ret = soUiCIMCfm((((SoCallCb *)(context))->ssapCb), SOT_CONNID_NOTUSED,
                          SOT_CONNID_NOTUSED, soEvnt);
       break;
      
     case EVTSOTMODIND:
       soEvnt->eventType.val = SOT_ET_MODIFY;
       break;
            
     case EVTSOTMODCFM:
       soEvnt->eventType.val = SOT_ET_OK;
       break;
          
      default:
        ret = ROKDNA;
   }

   RETVALUE(ret);
}


/*****************************************************************************
*
*      Fun:   soWrapErrInd
*
*      Desc:  Wrapper function for Rel 1.2 interface. If interface 
*             changes in new release, call the new one. Otherwise return
*             ROKDNA.
*
*      Ret:   
*             
*
*      Notes: 
*      File:  so_ua.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soWrapErrInd
(
SoSSapCb    *ssapCb,    /* SSAP control block */
UConnId     suConnId,   /* Service user connection ID    */
UConnId     spConnId,   /* SIP internal connection ID    */
U8          primType,   /* Primitive Type                */
Bool        requestMsg, /* Orig msg was request/ not     */
SoEvnt      *errEvnt    /* Event received                */
)
#else
PRIVATE S16 soWrapErrInd(ssapCb, suConnId, spConnId, primType, 
                         requestMsg, errEvnt)
SoSSapCb    *ssapCb;     /* SSAP control block */
UConnId     suConnId;    /* Service user connection ID    */
UConnId     spConnId;    /* SIP internal connection ID    */
U8          primType;    /* Primitive Type                */
Bool        requestMsg;  /* Orig msg was request/ not     */
SoEvnt      *errEvnt;       /* Event received */
#endif
{
   TRC3(soWrapErrInd);
 

   /*- so017.201: For stateless proxy, always pass error in CIMInd() -*/
   if (ssapCb->sys->entityType == LSO_ENT_NS)
   {
#ifdef SO_NS
       (Void) SoUiSotCIMInd (&ssapCb->pst, ssapCb->suId, errEvnt);
       RETVALUE (ROK);
#endif
   }

   switch(primType)
   {
      case SOT_ET_CANCEL:
      case SOT_ET_BYE:
         (Void) SoUiSotRelCfm(&ssapCb->pst, ssapCb->suId, suConnId, 
                             spConnId, errEvnt);
         break;
      
      case SOT_ET_INVITE:
#ifdef SO_REL_1_2_INF
      /* so024.201 : Check if this is Re-Invite Error Ind. Call ModCfm in this case. */
      /* Try to Locate Call */
      {
         SoCallCb    *call;
         SoCLegCb    *cLeg;

         soCoreLocateSuCallCtxt(ssapCb, errEvnt, suConnId, spConnId, &call, &cLeg);
         /* so025.201 : This may happen before call leg is created */
         if (cLeg != NULLP)
         {
            if((cLeg->clegState == SO_CLEG_STATE_MODIFY_ACK) || 
                  (cLeg->clegState == SO_CLEG_STATE_MODIFY) )
            {
               (Void) SoUiSotModCfm(&ssapCb->pst, ssapCb->suId, suConnId, spConnId ,errEvnt);
               break;
            }
         }
      }
#endif
      case SOT_ET_INFO:
      case SOT_ET_PRECON_MET:
      case SOT_ET_ACK:
      case SOT_ET_PRACK:
         (Void) SoUiSotRelInd(&ssapCb->pst, ssapCb->suId, suConnId, spConnId,
                       SOT_RELTYPE_LOCAL,errEvnt);
         break;
      case SOT_ET_REGISTER:
      case SOT_ET_UNKNOWN:
      case SOT_ET_OPTIONS:
      case SOT_ET_MESSAGE:
        if (requestMsg == TRUE)
        {
          (Void) SoUiSotCIMCfm (&ssapCb->pst, ssapCb->suId, errEvnt);
        }
        else
        {
          (Void) SoUiSotCIMInd (&ssapCb->pst, ssapCb->suId, errEvnt);
        }
        break;
      case SOT_ET_REFER:
      case SOT_ET_SUBSCRIBE:
      case SOT_ET_NOTIFY:
        if (requestMsg == TRUE)
        {
          (Void) SoUiSotCAMCfm (&ssapCb->pst, ssapCb->suId, suConnId, 
                               spConnId, errEvnt);
        }
        else
        {
          (Void) SoUiSotCAMInd (&ssapCb->pst, ssapCb->suId, suConnId, 
                               spConnId, errEvnt);
        }
        break;

      /* so006.201: Check for SOT_ET_INT_SESSTIMER_EXPD */
      case SOT_ET_INT_SESSTIMER_EXPD:
         errEvnt->eventType.val = SOT_ET_INT_REFRESHTMR_EXPD;
         (Void) SoUiSotRelInd(&ssapCb->pst, ssapCb->suId, suConnId, spConnId,
                              SOT_ET_INT_REFRESHTMR_EXPD,errEvnt);
        break;

      default:
         /* so004.201: call correct primitive for NS */
          (Void) SoUiSotRelInd(&ssapCb->pst, ssapCb->suId, suConnId, spConnId,
                        SOT_RELTYPE_LOCAL,errEvnt);
          break;
   }
   
   RETVALUE (ROK);
}




/*****************************************************************************
*
*      Fun:   soWrapTmrRefresh
*
*      Desc:  Wrapper function for Rel 1.2 interface. If interface 
*             changes in new release, call the new one. 
*
*      Ret:   
*             
*
*      Notes: 
*      File:  so_ua.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soWrapTmrRefresh
(
Pst            *pst,            /* post structure */
SuId           suId,            /* service provider SAP identifier */
UConnId        spConnId,        /* SP connection Id */
UConnId        suConnId,        /* SU connection Id */
SoEvnt         *soEvnt,         /* SIP messages event structure */
U8             tmrType          /* Expired Timer Type */
)
#else
PRIVATE S16 soWrapTmrRefresh(pst, suId, spConnId, suConnId, soEvnt, tmrType)
Pst            *pst;            /* post structure */
SuId           suId;            /* service provider SAP identifier */
UConnId        spConnId;        /* SP connection Id */
UConnId        suConnId;        /* SU connection Id */
SoEvnt         *soEvnt;         /* SIP messages event structure */
U8             tmrType;         /* Expired Timer Type */
#endif
{
   TRC3(soWrapTmrRefresh);

   switch (tmrType)
   {
     case SOT_ET_REG_TMO:
       soEvnt->eventType.val = SOT_ET_REG_TMO;
      /* 
       * so015.201: Print values as decimal to make it consistent with
       *            prints in other places.
       */
       SO_UI_PRNT_OUT ("SoUiSotCIMInd", suId, spConnId, suConnId, soEvnt);

       (Void) SoUiSotCIMInd (pst, suId, soEvnt);
 
       break;
#ifdef SO_EVENT
     case SOT_ET_SUBSC_TMO:
       soEvnt->eventType.val = SOT_ET_SUBSC_TMO;
      /* 
       * so015.201: Print values as decimal to make it consistent with
       *            prints in other places.
       */
       SO_UI_PRNT_OUT ("SoUiSotCAMInd", suId, spConnId, suConnId, soEvnt);

       (Void) SoUiSotCAMInd (pst, suId, suConnId, spConnId, soEvnt);
       break;
#endif /* SO_EVENT */

#ifdef SO_SESSTIMER
     case SOT_ET_INT_SESSTIMER_EXPD:
       soEvnt->eventType.val = SOT_ET_INT_REFRESHTMR_EXPD;
      /* 
       * so015.201: Print values as decimal to make it consistent with
       *            prints in other places.
       */
       SO_UI_PRNT_OUT ("SoUiSotCAMInd", suId, spConnId, suConnId, soEvnt);

       (Void) SoUiSotCAMInd (pst, suId, suConnId, spConnId, soEvnt);
       break;
#endif
   }

   RETVALUE (ROK);
}



/*****************************************************************************
*
*      Fun:   soWrapFindConnId
*
*      Desc:  Wrapper function for Rel 1.2 interface. This function
*             tries to find the connId (spConnId) corresponding to
*             a call for a CIM or a CAM request.
*             When sending a CIMInd the layer sends the spConnId in the
*             srcTranCb field. The user is expected to pass this value back
*             If for some reason the user doesnot do do, the layer will try
*             to identify the call etc based on the transId.
*
*
*      Ret:   
*             
*
*      Notes: 
*      File:  so_ua.c
*
******************************************************************************/
#ifdef ANSI
 /* so019.201 : Change the return type to 32-bit UConnId */
PRIVATE UConnId soWrapFindConnId
(
SpId           spId,        /* Service Provider Id */
SoEvnt         *evnt        /* SIP messages event structure */
)
#else
PRIVATE UConnId soWrapFindConnId(spId, evnt)
SpId           spId;        /* Service Provider Id */
SoEvnt         *evnt;       /* SIP messages event structure */
#endif
{
  S16          ret;
  SoEntCb      *ent;
  SoTransCb    *transCb;   /* Transaction Cb */
  SoCLegCb     *cLeg;      /* Call Leg Cb */
  SoSSapCb     *ssap;      /* SSAP cb */

  TRC2(soWrapFindConnId);

  if (evnt->srcTranCb != SOT_CONNID_NOTUSED)
  {
    /* so019.201 : Cast to 32-bit UConnId */
    RETVALUE ((UConnId)evnt->srcTranCb);
  }

  ssap = soCb.soSSapCbLst[spId];
  if (ssap == NULLP)
    RETVALUE (SOT_CONNID_NOTUSED);

  ent     = ssap->sys;
  transCb = NULLP;

  if (ent->entityType == LSO_ENT_NS)
    RETVALUE (SOT_CONNID_NOTUSED);

  /* so019.201 : Use the size of 32-bit UConnId */
  ret = cmHashListFind (&ent->transLst,
                       (U8  *) &evnt->transId,
                       (U16  ) sizeof(UConnId),
                       0,
                       (PTR *) &transCb);

  if ((ret == ROK) && (transCb))
  {
     cLeg = (SoCLegCb *)transCb->cLeg;
     if ((cLeg != NULLP) && (cLeg->call != NULLP))
     {
       evnt->callLegId = cLeg->legId;
       RETVALUE (cLeg->call->spConnId);
     } 
  }

  RETVALUE (SOT_CONNID_NOTUSED);
}

#endif /* SO_REL_1_2_INF */

#ifdef SO_EVENT


/*****************************************************************************
*
*      Fun:   soUiSubscFillErrEvnt
*
*      Desc:  This function fills the content of an error event.
*
*      Ret:   RETVOID
*
*      Notes:
*
*      File:  po_ui.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE Void soUiSubscFillErrEvnt
(
SoEvnt      **errEvnt,      /* Error event                       */ 
TknStrOSXL  *subId,          /* Event received                    */
U32         legId,          /* Call Leg Id                       */
U8          evntType,       /* Type of primitive encounter error */
U16         errorType,      /* Type of error                     */
Bool        callCleared     /* Whether call is released          */
)
#else
PRIVATE Void soUiSubscFillErrEvnt(errEvnt, subId, legId, evntType,
                            errorType, callCleared)
SoEvnt      **errEvnt;      /* Error event                       */
TknStrOSXL  *subId;          /* Event received                    */
U32         legId;          /* Leg Id                            */
U8          evntType;       /* Type of primitive encounter error */
U16         errorType;      /* Type of error                     */
Bool        callCleared;    /* Whether call is released          */
#endif
{
   SoEvnt   *errorEvnt;
   
   TRC2(soUiSubscFillErrEvnt);
   
   errorEvnt = *errEvnt;
   /* fill in error detail */
   errorEvnt->eventType.val = SOT_ET_ERROR;
   errorEvnt->callLegId = legId;
      
   errorEvnt->sipMessageType.pres = PRSNT_NODEF;
   errorEvnt->sipMessageType.val  = SO_SIPMESSAGE_ERROR;

   errorEvnt->t.errEvnt.errCode = errorType;
#ifndef SO_REL_1_2_INF
   errorEvnt->t.errEvnt.callCleared = callCleared;
   errorEvnt->t.errEvnt.eventType   = evntType;

   switch(errorEvnt->t.errEvnt.errCode)
   {
      case SOT_ERR_SUBSC_TMO:
         soUtlCpyTknStrOSXL(&errorEvnt->t.errEvnt.t.subscId, 
                               subId, &errorEvnt->memCp); 
         break;
#ifdef SO_REFER         
      case SOT_ERR_REFER_TMO:         
         soUtlCpyTknStrOSXL(&errorEvnt->t.errEvnt.t.referId, 
                               subId, &errorEvnt->memCp); 
         break;
#endif /* SO_REFER */         
   }
#endif /* SO_REL_1_2_INF */   

   RETVOID;

} /* soUiSubscFillErrEvnt */


#endif /* SO_EVENT */


/*****************************************************************************
*
*      Fun:   soUiFillErrEvnt
*
*      Desc:  This function fills the content of an error event.
*
*      Ret:   RETVOID
*
*      Notes:
*
*      File:  po_ui.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE Void soUiFillErrEvnt
(
SoEvnt      **errEvnt,      /* Error event                       */ 
SoEvnt      *evnt,          /* Event received                    */
U32         legId,          /* Call Leg Id                       */
U8          evntType,       /* Type of primitive encounter error */
U16         errorType,      /* Type of error                     */
Bool        callCleared     /* Whether call is released          */
)
#else
PRIVATE Void soUiFillErrEvnt(errEvnt, evnt, legId, evntType,
                            errorType, callCleared)
SoEvnt      **errEvnt;      /* Error event                       */
SoEvnt      *evnt;          /* Event received                    */
U32         legId;          /* Leg Id                            */
U8          evntType;       /* Type of primitive encounter error */
U16         errorType;      /* Type of error                     */
Bool        callCleared;    /* Whether call is released          */
#endif
{
   SoEvnt   *errorEvnt;
   
   TRC2(soUiFillErrEvnt);
   
   errorEvnt = *errEvnt;
   /* fill in error detail */
   errorEvnt->eventType.val = SOT_ET_ERROR;
   errorEvnt->callLegId = legId;
      
   if(evnt != NULLP)
   {
      errorEvnt->transId   = evnt->transId;
      errorEvnt->srcTranCb = evnt->srcTranCb;
      errorEvnt->dstTranCb = NOTUSED;
   }
   
   errorEvnt->sipMessageType.pres = PRSNT_NODEF;
   errorEvnt->sipMessageType.val  = SO_SIPMESSAGE_ERROR;

   errorEvnt->t.errEvnt.errCode = errorType;
#ifndef SO_REL_1_2_INF
   errorEvnt->t.errEvnt.callCleared = callCleared;
   errorEvnt->t.errEvnt.eventType   = evntType;

#ifdef SO_UA
#ifdef SO_EVENT   
   switch(errorEvnt->t.errEvnt.errCode)
   {
      case SOT_ERR_SUBSC_TMO:
         soCpySubscId(evnt, &errorEvnt->t.errEvnt.t.subscId, 
                       &evnt->memCp);
         break;
#ifdef SO_REFER         
      case SOT_ERR_REFER_TMO:         
            soCpySubscId(evnt, &errorEvnt->t.errEvnt.t.referId, 
                         &evnt->memCp);
         break;
#endif /* SO_REFER */
   }
#endif /* SO_EVENT */
#endif /* SO_UA */
#endif /* SO_REL_1_2_INF */   

   RETVOID;

} /* soUiFillErrEvnt */


/*****************************************************************************
*
*      Fun:   soUiErrInd
*
*      Desc:  This function isssues an ErrInd to the user for all local errors
*
*      Ret:   RETVOID
*
*      Notes:
*
*      File:  po_ui.c
*
******************************************************************************/
#ifdef SO_REL_1_2_INF
#ifdef ANSI
PUBLIC Void soUiErrInd
(
SoSSapCb    *ssapCb,    /* SSAP control block */
UConnId     suConnId,   /* Service user connection ID    */
UConnId     spConnId,   /* SIP internal connection ID    */
SoEvnt      *evnt,      /* Event received                */
U32         legId,      /* Call Leg Id                   */
U8          evntType,   /* Primitive Type                */
U16         errorType,  /* Type of error                 */
Bool        callCleared,
Bool        internalMsg
)
#else
PUBLIC Void soUiErrInd(ssapCb, suConnId, spConnId, evnt, legId,
                       evntType, errorType, callCleared, internalMsg)
SoSSapCb    *ssapCb;     /* SSAP control block */
UConnId     suConnId;    /* Service user connection ID    */
UConnId     spConnId;    /* SIP internal connection ID    */
SoEvnt      *evnt;       /* Event received                */
U32         legId;       /* Call Leg Id                   */
U8          evntType;    /* Primitive Type                */
U16         errorType;   /* Type of error            */
Bool        callCleared;
Bool        internalMsg;
#endif
#else
#ifdef ANSI
PUBLIC Void soUiErrInd
(
SoSSapCb    *ssapCb,    /* SSAP control block */
UConnId     suConnId,   /* Service user connection ID    */
UConnId     spConnId,   /* SIP internal connection ID    */
SoEvnt      *evnt,      /* Event received                */
U32         legId,      /* Call Leg Id                   */
U8          evntType,   /* Primitive Type                */
U16         errorType,  /* Type of error                 */
Bool        callCleared
)
#else
PUBLIC Void soUiErrInd(ssapCb, suConnId, spConnId, evnt, legId,
                       evntType, errorType, callCleared)
SoSSapCb    *ssapCb;     /* SSAP control block */
UConnId     suConnId;    /* Service user connection ID    */
UConnId     spConnId;    /* SIP internal connection ID    */
SoEvnt      *evnt;       /* Event received                */
U32         legId;       /* Call Leg Id                   */
U8          evntType;    /* Primitive Type                */
U16         errorType;   /* Type of error            */
Bool        callCleared;
#endif
#endif
{
   SoEvnt      *errEvnt;   /* error event send to SU        */
#ifdef SO_REL_1_2_INF
   Bool        requestMsg; /* Request Message */
#endif

   TRC2(soUiErrInd);

   SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
                 " soUiErrInd Send To Service User"));

   /* allocate memory for the error event */
   if (soCmCreateEvent(&errEvnt, SOT_ET_ERROR) != ROK)
   {
      /* could not get memory for the errEvnt,
      raise an alarm, cleanup and return */
      soGenStaInd(STSIPENT, LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL,
                  LSO_PAR_MEM, LSO_PAR_NONE, (Ptr)NULLP );
      /* so038.201: Delete the event */
      if (evnt != NULLP)
      {     
         soCmFreeEvent(evnt);
      }   

#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR (ERRCLS_DEBUG, ESO287, (ErrVal) 0,
                 " soUiErrInd Out of Resource");
#endif
      RETVOID;
   }

   soUiFillErrEvnt(&errEvnt, evnt, legId, evntType, errorType, 
                   callCleared);

   /* 
    * so015.201: Print values as decimal to make it consistent with
    *            prints in other places.
    */
    SO_UI_PRNT_OUT ("SoUiSotErrInd", ssapCb->suId, spConnId, suConnId, errEvnt);
    SODBGP_SO (DBGMASK_UI, (soCb.init.prntBuf, "\nError Code(%d, %s)\n",
               errorType , soSOTErrorDescrip[errorType]));
  

#ifdef SO_REL_1_2_INF
   requestMsg = TRUE;

   if ((evnt != NULLP) && 
       (evnt->sipMessageType.val == SO_SIPMESSAGE_RESPONSE))
     requestMsg = FALSE;

   /* so025.201 : For 1.2 interface pass if internal message */
   if (evnt != NULLP && 
       evnt->eventType.val == SOT_ET_REGISTER && 
       internalMsg == TRUE)
      requestMsg = FALSE;
#endif

   /* Delete the event */
   if (evnt != NULLP)
   {     
     soCmFreeEvent(evnt);
   }   

#ifdef SO_REL_1_2_INF
   soWrapErrInd(ssapCb, suConnId, spConnId, evntType, requestMsg, errEvnt);
#else
   SoUiSotErrInd(&ssapCb->pst, ssapCb->suId, suConnId, spConnId, errEvnt);
#endif

   RETVOID;
} /* soUiErrInd */

#ifdef SO_EVENT

#ifdef ANSI
PUBLIC Void soUiSubscErrInd
(
SoSSapCb    *ssapCb,    /* SSAP control block */
UConnId     suConnId,   /* Service user connection ID    */
UConnId     spConnId,   /* SIP internal connection ID    */
SoEvnt      *evnt,      /* Event received                */
TknStrOSXL  *subId,     /* subscription ID               */
U32         legId,      /* Call Leg Id                   */
U8          evntType,   /* Primitive Type                */
U16         errorType,  /* Type of error                 */
Bool        callCleared
)
#else
PUBLIC Void soUiSubscErrInd(ssapCb, suConnId, spConnId, evnt, subId, legId,
                       evntType, errorType, callCleared)
SoSSapCb    *ssapCb;     /* SSAP control block */
UConnId     suConnId;    /* Service user connection ID    */
UConnId     spConnId;    /* SIP internal connection ID    */
SoEvnt      *evnt;       /* Event received                */
TknStrOSXL  *subId;      /* subscription ID               */
U32         legId;       /* Call Leg Id                   */
U8          evntType;    /* Primitive Type                */
U16         errorType;   /* Type of error            */
Bool        callCleared;
#endif
{
   SoEvnt      *errEvnt;   /* error event send to SU        */
#ifdef SO_REL_1_2_INF
   Bool        requestMsg; /* Request Message */
#endif

   TRC2(soUiSubscErrInd);

   SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
                 " soUiSubscErrInd Send To Service User"));

   /* allocate memory for the error event */
   if (soCmCreateEvent(&errEvnt, SOT_ET_ERROR) != ROK)
   {
      /* could not get memory for the errEvnt,
      raise an alarm, cleanup and return */
      soGenStaInd(STSIPENT, LCM_CATEGORY_RESOURCE, LCM_EVENT_SMEM_ALLOC_FAIL,
                  LSO_PAR_MEM, LSO_PAR_NONE, (Ptr)NULLP );

      /* 
       * so015.201: Print values as decimal to make it consistent with
       *            prints in other places.
       */
      SODBGP_SO(DBGMASK_UI, (soCb.init.prntBuf,
                          "\nSSAP %2d/%2d <-soUiSubscErrInd--SIP  spConn=%ld "
                          "suConn=%ld Out of Resources\n",
                          ssapCb->suId, ssapCb->sapId, spConnId, suConnId));
      /* so038.201: Delete the event */
      if (evnt != NULLP)
      {     
         soCmFreeEvent(evnt);
      }   

#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR (ERRCLS_DEBUG, ESO289, (ErrVal) 0,
                 " soUiSubscErrInd Out of Resource");
#endif
      RETVOID;
   }

  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotErrInd", ssapCb->suId, spConnId, suConnId, errEvnt);
   SODBGP_SO (DBGMASK_UI, (soCb.init.prntBuf, "\nError Code(%d, %s)\n",
              errorType , soSOTErrorDescrip[errorType]));

   if(evnt)
      soUiFillErrEvnt(&errEvnt, evnt, legId, evntType, errorType, 
                   callCleared);
   else if(subId)
      soUiSubscFillErrEvnt(&errEvnt, subId, legId, evntType, errorType, 
                   callCleared);
   

#ifdef SO_REL_1_2_INF
   requestMsg = TRUE;

   if ((evnt != NULLP) && 
       (evnt->sipMessageType.val == SO_SIPMESSAGE_RESPONSE))
     requestMsg = FALSE;
#endif

   /* Delete the event */
   if (evnt != NULLP)
   {     
     soCmFreeEvent(evnt);
   }   

#ifdef SO_REL_1_2_INF
   soWrapErrInd(ssapCb, suConnId, spConnId, evntType, requestMsg, errEvnt);
#else
   SoUiSotErrInd(&ssapCb->pst, ssapCb->suId, suConnId, spConnId, errEvnt);
#endif

   RETVOID;
} /* soUiSubscErrInd */

#endif /* SO_EVENT */




/*****************************************************************************
*
*      Fun:   soUiCheckEvnt
*
*      Desc:  Checks parameters incoming event
*
*      Ret:   ROK / RFAILED
*             ssapCb
*
*      Notes: Performs checking on parameters common to all incoming SOT
*             primitives.
*
*      File:  so_ua.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soUiCheckEvnt
(
SoEvnt      *evnt          /* Received event                         */
)
#else
PRIVATE S16 soUiCheckEvnt(evnt)
SoEvnt      *evnt;         /* Received event                          */
#endif
{
   SoRequestLine *reqLine;       /* message request line */
#ifdef SO_REL_1_2_INF
   U16           staCode; 
#endif
   S16           ret;            /* return Value */

   TRC2(soUiCheckEvnt);
   
   if (evnt == (SoEvnt *) NULLP)
      goto SOUICHECKEVNT;

#ifndef SO_REL_1_2_INF
   /*------------ SIP 2.1 Inteface being used ------------*/

     /*------ SIP User MUST fill event type ------*/
     if (evnt->eventType.pres == NOTPRSNT)
         goto SOUICHECKEVNT;

     /*-- SIP User MUST also fill message type ---*/
     if (evnt->sipMessageType.pres == NOTPRSNT)
         goto SOUICHECKEVNT;
     /* 
      * SIP User MUST always fill StatusLine for SIP
      * RESPONSE messages.
      */
     if (evnt->sipMessageType.val == SO_SIPMESSAGE_RESPONSE)
     {
       if (evnt->t.response.statusLine.pres.pres == NOTPRSNT)
         goto SOUICHECKEVNT;

       /* so006.201: Set reason phrase if not already set by user */
       if ((evnt->t.response.statusLine.statusCode.pres != NOTPRSNT) &&
           (evnt->t.response.statusLine.reasonPhrase.pres == NOTPRSNT))
       {
         ret = soCmGetSIPCodes(evnt->t.response.statusLine.statusCode.val, 0,
                               &evnt->t.response.statusLine,
                               evnt);
         if (ret != ROK)
           goto SOUICHECKEVNT;
       }

       /* 
        *Fill SIP Version Info,if NOT already present
        */
       if (evnt->t.response.statusLine.sipVersion.pres == NOTPRSNT)
       {
         SO_FILL_TKNSTROSXL(&evnt->t.response.statusLine.
                            sipVersion, soCb.cfg.protVer,
                            cmStrlen((U8 *)soCb.cfg.protVer), evnt, ret);
         if (ret != ROK)
           goto SOUICHECKEVNT;

       }
     } /* end of if (SIP Response Message) */

#else
   /*------------ SIP 1.2 Inteface being used ------------*/

     /*--- Check if user has filled event type ---*/
     if(evnt->eventType.pres == NOTPRSNT)
     {
        if (evnt->sipMessageType.pres == NOTPRSNT)
           goto SOUICHECKEVNT;
 
        switch (evnt->sipMessageType.val)
        {
           case SO_SIPMESSAGE_REQUEST:
             /*
              * Try to fill event type from SIP requestLine.
              * In this case SIP user MUST fill the request
              * line.
              */

             if((evnt->t.request.requestLine.method.type.pres != PRSNT_NODEF)||
                (evnt->t.request.requestLine.method.t.std.pres!= PRSNT_NODEF))
               goto SOUICHECKEVNT;
            
             if (evnt->t.request.requestLine.method.type.val != 
                 SO_METHOD_METHODSTD)
             {
                 SO_FILL_TKNU8(&evnt->eventType, SOT_ET_UNKNOWN);
             }
             else
             {
                 SO_FILL_TKNU8(&evnt->eventType, 
                            evnt->t.request.requestLine.method.t.std.val);
             }

            break;
            
         case SO_SIPMESSAGE_RESPONSE:
             /*
              * For Response messages, no event type and no
              * status line means incomplete response mess-
              * age information.
              */

             if((evnt->t.response.statusLine.pres.pres == NOTPRSNT) ||
                (evnt->t.response.statusLine.statusCode.pres == NOTPRSNT))
                goto SOUICHECKEVNT;

            break;
            
         case SO_SIPMESSAGE_AUDIT:
            SO_FILL_TKNU8(&evnt->eventType, SOT_ET_AUDIT);
            break;
            
         default:   
            goto SOUICHECKEVNT;
            break;
        } /* End of switch (message type) */

     } /* End of if (event Type is NOT filled) */
   
    /* set sipMessageType if not filled by user */
     else if (evnt->sipMessageType.pres == NOTPRSNT)
     {
        /* Set according to eventType */
         switch (evnt->eventType.val)
         {
            case SOT_ET_PROGRESS:      /* Fall through */
            case SOT_ET_RINGING:       /* Fall through */
            case SOT_ET_FORWARDING:    /* Fall through */
            case SOT_ET_QUEUED:        /* Fall through */
            case SOT_ET_REDIRECT:      /* Fall through */
            case SOT_ET_OK:            /* Fall through */
            case SOT_ET_STATUS:
               SO_FILL_TKNU8(&evnt->sipMessageType, SO_SIPMESSAGE_RESPONSE);
               break;

            case SOT_ET_OPTIONS:       /* Fall through */
            case SOT_ET_REGISTER:      /* Fall through */
            case SOT_ET_INVITE:        /* Fall through */
            case SOT_ET_MODIFY:        /* Fall through */
            case SOT_ET_ACK:           /* Fall through */
            case SOT_ET_BYE:           /* Fall through */
            case SOT_ET_CANCEL:        /* Fall through */
            case SOT_ET_INFO:          /* Fall through */
            case SOT_ET_PRACK:         /* Fall through */
            case SOT_ET_PRECON_MET:    /* Fall through */
#ifdef  SO_REFER
            case SOT_ET_REFER:         /* Fall through */
#endif
#ifdef  SO_EVENT
            case SOT_ET_SUBSCRIBE:     /* Fall through */
            case SOT_ET_NOTIFY:        /* Fall through */
#endif
#ifdef  SO_INSTMSG
            case SOT_ET_MESSAGE:
#endif
               SO_FILL_TKNU8(&evnt->sipMessageType, SO_SIPMESSAGE_REQUEST);
               break;
            case SOT_ET_AUDIT:
               SO_FILL_TKNU8(&evnt->sipMessageType, SO_SIPMESSAGE_AUDIT);
               break;

            default:
               goto SOUICHECKEVNT;
               break;
         } /* End of switch (event type) */
     }  /* End of else if (message type NOT present) */

   /*--- FOR SIP RESPONSE Messages, fill complete Status Line ---*/
     if (evnt->sipMessageType.val == SO_SIPMESSAGE_RESPONSE)
     {
       evnt->t.response.pres.pres = PRSNT_NODEF;
      
       if((evnt->t.response.statusLine.pres.pres == NOTPRSNT) ||
          (evnt->t.response.statusLine.statusCode.pres == NOTPRSNT))
       {
         if (evnt->eventType.pres == NOTPRSNT)
            goto SOUICHECKEVNT;

         /* Set according to eventType */
         switch (evnt->eventType.val)
         {
           case SOT_ET_PROGRESS: 
             staCode = SOT_RSP_183_SESSION_PROGRESS;
             break;

           case SOT_ET_RINGING: 
             staCode = SOT_RSP_180_RINGING;
             break;
           case SOT_ET_FORWARDING:
             staCode = SOT_RSP_181_FORWARDED;
             break;
           case SOT_ET_QUEUED:
             staCode = SOT_RSP_182_QUEUED;
             break;
           case SOT_ET_TRYING:
             staCode = SOT_RSP_100_TRYING;
             break;
           case SOT_ET_OK:   
             staCode = SOT_RSP_200_OK;
             break;
           default:
            goto SOUICHECKEVNT;

         } /* End of switch (eventType) */

         evnt->t.response.pres.pres = PRSNT_NODEF;
         evnt->t.response.statusLine.pres.pres = PRSNT_NODEF;

        /*------ so018.201: Fill Reason Phrase in all cases ------*/
         SO_FILL_TKNU16 (&evnt->t.response.statusLine.statusCode, staCode);
       }

       /*- so018.201: Fill Reason Phrase, if NOT already present -*/
       if (evnt->t.response.statusLine.reasonPhrase.pres == NOTPRSNT)
       {
          ret = soCmGetSIPCodes(evnt->t.response.statusLine.statusCode.val, 0,
                                &evnt->t.response.statusLine,
                                evnt);
          if (ret != ROK)
            goto SOUICHECKEVNT;
       }

       /*- Fill SIP Version Info, if NOT already present -*/
       if (evnt->t.response.statusLine.sipVersion.pres == NOTPRSNT)
       {
         SO_FILL_TKNSTROSXL(&evnt->t.response.statusLine.
                            sipVersion, soCb.cfg.protVer,
                            cmStrlen((U8 *)soCb.cfg.protVer), evnt, ret);
         if (ret != ROK)
           goto SOUICHECKEVNT;
       }

       /* 
        * For SIP Response messages, SIP 1.2 user is not  required
        * to fill "request method"  in event type  field. But  the
        * primitive mapping between 1.2 and 2.1 requires the event
        * Type to contain the "request method".
        * For response message, "request method" can be  extracted 
        * from transactionID. Transaction ID contains "request me-
        * thod" in its third byte.
        */
        evnt->eventType.val = (U8)((evnt->transId & SO_TRANSID_METHOD_MASK) >> 16);

     } /* End of else (SIP Response Message) */


#endif /* SO_REL_1_2_INF */
 
   /*--- Following code is common for both 1.2 and 2.1 release ---*/

   /*--- FOR SIP REQUEST Messages, fill complete Request Line ----*/
     if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
     {
       evnt->t.request.pres.pres = PRSNT_NODEF;

       if((evnt->t.request.requestLine.method.type.pres != PRSNT_NODEF)||
          (evnt->t.request.requestLine.method.t.std.pres!= PRSNT_NODEF))
       {
         if (evnt->eventType.val != SOT_ET_UNKNOWN)
         {
           reqLine = &evnt->t.request.requestLine;
           reqLine->pres.pres = PRSNT_NODEF;
           reqLine->method.type.pres  = PRSNT_NODEF;       
           reqLine->method.type.val   = SO_METHOD_METHODSTD;
           reqLine->method.t.std.pres = PRSNT_NODEF;
           reqLine->method.t.std.val  = evnt->eventType.val;
           SO_FILL_TKNSTROSXL(&evnt->t.request.requestLine.sipVersion, 
                              soCb.cfg.protVer,
                              cmStrlen((U8 *)soCb.cfg.protVer), evnt, ret);
           if (ret != ROK)
             goto SOUICHECKEVNT;

         }
         else
         {
             goto SOUICHECKEVNT;
         }
       } /* End of if (request line is not present) */

     } /* End of if (SIP Request Message) */

      /*so036.201: Changes for CALEA */
#ifdef SO_CALEA
     /* Set Raw Msg to NULLP, RawMsg is given to application from stack *
      * Application should never fill up rawMsg                         */
     if (evnt->rawMsg != NULLP)
     {
        SPutMsg (evnt->rawMsg);
        evnt->rawMsg = NULLP;
     }
#endif

     RETVALUE(SOT_ERR_NOERR);

SOUICHECKEVNT:

     SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
                 "soUiCheckEvnt: Incorrect Event Data\n"));

     RETVALUE(SOT_ERR_INV_EVNT);
   
}


/*****************************************************************************
*
*      Fun:   soUiValidatePrimitive
*
*      Desc:  Checks parameters for incoming SOT primitive
*
*      Ret:   ROK / RFAILED
*             ssapCb
*
*      Notes: Performs checking on parameters common to all incoming SOT
*             primitives.
*             If all checks pass, ssapCb is returned
*             Error primitive and/or alarm generated when primitive fails
*             This function must be used for all SOT primitives except
*             bind request.
*
*      File:  so_ua.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soUiValidatePrimitive
(
SpId        spId,          /* Incoming spId                          */
U8          primitiveType, /* Type of primitive                      */
SoEvnt      *evnt,         /* Received event                         */
SoSSapCb    **ssapCb       /* SSAP control block (only if return ROK)*/
)
#else
PRIVATE S16 soUiValidatePrimitive(spId, primitiveType, evnt, ssapCb)
SpId        spId;          /* Incoming spId                           */
U8          primitiveType; /* Type of primitive                       */
SoEvnt      *evnt;         /* Received event                          */
SoSSapCb    **ssapCb;      /* SSAP control block (only if return ROK) */
#endif
{
   U16         alarmEvnt;  /* event causing alarm generation */
   SoEntCb     *ent;

   TRC2(soUiValidatePrimitive);
   
   switch(primitiveType)
   {
      case EVTSOTCIMREQ:                  /* CIM request */
         alarmEvnt = LSO_EVENT_SOT_CIMREQ;
         break;
      case EVTSOTCIMRSP:                  /* CIM response */
         alarmEvnt = LSO_EVENT_SOT_CIMRSP;
         break;
      case EVTSOTCONREQ:                  /* connection request */
         alarmEvnt = LSO_EVENT_SOT_CONREQ;
         break;
      case EVTSOTCONRSP:                  /* connection response */
         alarmEvnt = LSO_EVENT_SOT_CONRSP;
         break;
      case EVTSOTCNSTREQ:                 /* connection status request */
         alarmEvnt = LSO_EVENT_SOT_CNSTREQ; 
         break;
      case EVTSOTRELREQ:                  /* release request */
         alarmEvnt = LSO_EVENT_SOT_RELREQ;
         break;
         
      case EVTSOTRELRSP:                  /* release response */
         alarmEvnt = LSO_EVENT_SOT_RELRSP;
         break;
         
      case EVTSOTMODREQ:                  /* modify request */
         alarmEvnt = LSO_EVENT_SOT_MODREQ;
         break;
         
      case EVTSOTMODRSP:                  /* nodify response */
         alarmEvnt = LSO_EVENT_SOT_MODRSP;
         break;
      case EVTSOTCAMREQ:
         alarmEvnt = LSO_EVENT_SOT_CAMREQ;/* CAM request */
         break;
         
      case EVTSOTCAMRSP:
         alarmEvnt = LSO_EVENT_SOT_CAMRSP;/* CAM response */
         break;

#ifndef SO_REL_1_2_INF
      case EVTSOTACKREQ:    /* ACK Req */
         alarmEvnt = LSO_EVENT_SOT_ACKREQ;
         break;
      case EVTSOTCANCELREQ:  /* Cancel Req */
         alarmEvnt = LSO_EVENT_SOT_CANCELREQ;
         break;
      case EVTSOTAUDITREQ: /* Audit Request */
         alarmEvnt = LSO_EVENT_SOT_AUDITREQ;
         break;
#endif /* SO_REL_1_2_INF */

      default:
         /* should hopefully never get here */
         alarmEvnt = LCM_EVENT_LYR_SPECIFIC;
         break;

   }
      
   if ((spId >= (SpId)soCb.cfg.maxNmbSSaps) || (spId < 0))
   {
      soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, alarmEvnt,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
      RETVALUE(SOT_ERR_INV_SSAP);
   }

   /* Check if ssap is valid */
   (*ssapCb) = soCb.soSSapCbLst[spId];
   if ((*ssapCb) == (SoSSapCb *) NULLP)
   {
      soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, alarmEvnt,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
      RETVALUE(SOT_ERR_INV_SSAP);
   }

   /* Check if ssap is enabled */
   if ((*ssapCb)->state != LSO_SSAP_BNDENA)
   {
      /* Not bound and enabled */
      soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, alarmEvnt,
                  LSO_CAUSE_SAP_BNDDIS, LSO_PAR_SAP, (Ptr)&spId);
      RETVALUE(SOT_ERR_SSAP_STATE);
   }

   ent = (*ssapCb)->sys;
   if (ent == NULLP)
   {
      /* Entity has been deleted since configuration, don't bind */
      soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, alarmEvnt,
                  LSO_CAUSE_INV_ENTID, LSO_PAR_ENT,(Ptr)&(*ssapCb)->cfg.entId);
      RETVALUE(SOT_ERR_INV_ENT);
   }
   if (ent->curState != LSO_ENT_ENABLED)
   {
      soGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, alarmEvnt,
                  LCM_CAUSE_INV_STATE, LSO_PAR_ENT, &ent->entId);
      RETVALUE(SOT_ERR_ENT_STATE);
   }

   RETVALUE(SOT_ERR_NOERR);
} /* soUiValidatePrimitive */


#ifndef SO_REL_1_2_INF
#ifdef SO_UA
/*****************************************************************************
*
*      Fun:   soUiFillCallInfo
*
*      Desc:  This function fills informaiton pertaining to a specified call 
*             into the audit repsonse.
*
*      Ret:   ROK / RFAILED
*
*      Notes: If call was started by CIM or by REGISTER, return error. The 
*             reason is that these calls are created by the layer for 
*             internal use and not valid as far as user is concerned.
*
*      File:  so_ua.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soUiFillCallInfo
(
SoAuditInfo *callInfo,     /* Audit Information   */ 
SoCallCb    *call          /* call control block  */
)
#else
PRIVATE S16 soUiFillCallInfo(callInfo, call)
SoAuditInfo *callInfo;     /* Audit Information   */
SoCallCb    *call;         /* call control block  */
#endif
{
   SoCLegCb    *cLeg;
   U16         numCallLegs;
   CmLListCp *lCp;
   CmLList   *tmp;
   
   TRC2(soUiFillCallInfo);
   
   /* initialize local variables*/

   cLeg = NULLP;
   numCallLegs = 0;
   
   if (call->sessCreatedBy != SOT_ET_REGISTER)
      callInfo->sessionStartedBy = call->sessCreatedBy;
   else
      RETVALUE(SOT_ERR_CALL_NOTFOUND);

   lCp = &call->cLegLst;
   tmp = lCp->first;
   while(tmp != NULLP)
   {
      cLeg = (SoCLegCb *)cmLListNode(tmp);
      callInfo->cLegInfo[numCallLegs].cLegId = cLeg->legId;
      callInfo->cLegInfo[numCallLegs].cLegState = cLeg->clegState;
      numCallLegs++;

      tmp = tmp->next;
   };

   callInfo->numCallLegs = numCallLegs;

   RETVALUE(SOT_ERR_NOERR);
}
#endif 
#endif

#ifndef SO_REL_1_2_INF


/*****************************************************************************
*
*      Fun:   soUiFillRegRefreshInfo
*
*      Desc:  This function fills informaiton pertaining a registration request
*             This information is sent to the user when the refresh timer
*             for Registration has expired adn when the layer is not cfgd
*             to perform auto refreshes.
*
*      Ret:   ROK / RFAILED
*
*      Notes: 
*
*      File:  so_ua.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soUiFillRegRefreshInfo
(
SoEvnt      *reqEvnt,     /* Received event             */
SoEvnt      *refreshEvnt  /* Registration Refresh Event */
)
#else
PRIVATE S16 soUiFillRegRefreshInfo(reqEvnt, refreshEvnt)
SoEvnt      *reqEvnt;     /* Received event             */
SoEvnt      *refreshEvnt; /* Registration Refresh Event */
#endif
{
  SoRegRefreshInfo   *regInfo;  /* Registration info */
  SoAddress          *to;       /* To header         */
  SoAddress          *from;     /* From Header       */
  SoContact          *contact;  /* Contact Header    */
  TknStrOSXL         *callId;   /* CallId            */
  S16                ret; 
   
  TRC2(soUiFillRegRefreshInfo);

  to = NULLP;
  from = NULLP;

  regInfo = &refreshEvnt->t.refreshEvnt.t.regInfo;

  /* Find the contact from the stored event */
  if (soCmFindHdrChoice(reqEvnt, (U8 **) &contact,
                        SO_HEADER_GEN_CONTACT) != ROK)
    RETVALUE(RFAILED);


  ret = soUtlCpySoContactItem(&regInfo->contactItem, 
                        contact->contactItems.contactItem[0], &refreshEvnt->memCp);
  if (ret != ROK)
    RETVALUE(RFAILED);
  
   /* Find From header in the event structure */
   ret = soCmFindHdrChoice(reqEvnt, (U8 **)&from,
                               SO_HEADER_GEN_FROM);
   /* From not found */
   if (ret != ROK)
     RETVALUE(RFAILED);

   ret = soUtlCpySoAddress(&regInfo->from,
                           from,
                           &refreshEvnt->memCp);
   if (ret != ROK)
     RETVALUE(RFAILED);

   /* Find From header in the event structure */
   ret = soCmFindHdrChoice(reqEvnt, (U8 **) &to,
                               SO_HEADER_GEN_TO);
   /* TO not found */
   if (ret != ROK)
     RETVALUE(RFAILED);

   ret = soUtlCpySoAddress(&regInfo->to,
                           to,
                           &refreshEvnt->memCp);
   if (ret != ROK)
     RETVALUE(RFAILED);

   ret = soCmFindHdrChoice(reqEvnt, (U8 **) &callId, SO_HEADER_GEN_CALLID);
   
   if (ret != ROK)
     RETVALUE(RFAILED);

   ret = soUtlCpyTknStrOSXL(&regInfo->callId,
                            callId,
                            &refreshEvnt->memCp);

   if (ret != ROK)
     RETVALUE(RFAILED);

   ret = soUtlCpySoAddrSpec(&regInfo->regAddr, 
                            &reqEvnt->t.request.requestLine.addrSpec,
                            &refreshEvnt->memCp);
   if (ret != ROK)
     RETVALUE(RFAILED);

   RETVALUE(ROK);
}


#ifdef SO_UA

/*****************************************************************************
*
*      Fun:   soUiFillSSAPCallInfo
*
*      Desc:  This function fills informaiton pertaining to all calls on 
*             specified SSAP into the audit repsonse.
*
*      Ret:   ROK / RFAILED
*
*      Notes: 
*
*      File:  so_ua.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soUiFillSSAPCallInfo
(
Pst         *pst,          /* post structure */
/* ccpu00062158 */
SoEvnt      **evnt,        /* Received event                             */
SoSSapCb    *ssap,         /* SSAP control block                         */
SoEntCb     *ent           /* entity control block associated with SSAP  */
)
#else
PRIVATE S16 soUiFillSSAPCallInfo(pst,evnt,ssap, ent)
Pst         *pst;          /* post structure */
/* ccpu00062158 */
SoEvnt      **evnt;         /* Received event                             */
SoSSapCb    *ssap;         /* SSAP control block                         */
SoEntCb     *ent;           /* entity control block associated with SSAP */
#endif
{
   SoSSapInfo  *ssapInfo;
   SoCallCb    *call;
   SoEvnt      *auditCfmEvnt;
   S16         ret;
   SoAuditInfo *callInfo;

   TRC2(soUiFillSSAPCallInfo);

   /* Initialize local variables */
   /* ccpu00062158 */
   auditCfmEvnt = *evnt;
   ssapInfo = &(auditCfmEvnt->t.auditEvnt.auditInfo.ssapInfo);
   call = NULLP;
   
   if(ssap->sapId != ssapInfo->spId) 
      RETVALUE(SOT_ERR_INV_SSAP);

   ssapInfo->numCalls = 0;
   while (cmHashListGetNext(&ent->callIdLst, (PTR)call, (PTR *)&call) ==ROK)
   {
      if(call->ssapCb == ssap)
      {
         callInfo = &ssapInfo->callInfo[ssapInfo->numCalls];

         if ((callInfo->callId.pres == NOTPRSNT) ||
             (callInfo->callId.len == 0))
         {
           if (soUtlCpyTknStrOSXL(&callInfo->callId, 
                              &call->callId, &auditCfmEvnt->memCp)!= ROK)
             RETVALUE(SOT_ERR_RSRC);

         }

         ret = soUiFillCallInfo(callInfo, call);
         if(ret == ROK)
            ssapInfo->numCalls++;

         if(ssapInfo->numCalls >= SO_MAX_CALLS)
         {
            auditCfmEvnt->t.auditEvnt.moreAudit = TRUE;
            SoUiSotAuditCfm(&ssap->pst,ssap->suId, auditCfmEvnt);
            /*allocate new memory for more audit cfms */
            /* ccpu00062158 */
            if(soCmCreateEvent(&auditCfmEvnt, SOT_ET_AUDIT)!= ROK)
               RETVALUE(SOT_ERR_RSRC);
            
            /* set sip message type to Audit */
            /* ccpu00062158 */
            auditCfmEvnt->sipMessageType.pres = PRSNT_NODEF;
            auditCfmEvnt->sipMessageType.val = SO_SIPMESSAGE_AUDIT;
            auditCfmEvnt->t.auditEvnt.moreAudit = FALSE;
            auditCfmEvnt->t.auditEvnt.auditType = SOT_AUDIT_SSAP;
            ssapInfo =&(auditCfmEvnt->t.auditEvnt.auditInfo.ssapInfo);
            ssapInfo->spId = ssap->sapId;
            ssapInfo->numCalls = 0;
         
         }
      }
   }

   /* If all auditCfms have been sent out*/
   if(ssapInfo->numCalls ==0)
   {
      /* ccpu00062158 */

      (Void) soCmFreeEvent(auditCfmEvnt);
      auditCfmEvnt = NULLP;
   }
    
    /* ccpu00062158 */

   /* set the return event pointer since the event that was passed in may
      already have been sent to application.
   */      
   *evnt = auditCfmEvnt;


   RETVALUE(ROK);
} /* soUiFillSSAPCallInfo */
#endif /* SO_UA */
#endif


/*****************************************************************************
*
*      Fun:   SoUiSotBndReq
*
*      Desc:  This function binds the SIP service user to the
*             SIP layer.
*
*             The first parameter is used for its selector field
*             (pst->selector) to route the primitive from the
*             service user to SIP. It is also used to convey the
*             service users's processor id, entity id and instance id
*             to be stored by the SIP layer.
*
*             The second parameter, suId, indicates the upper layer SAP
*             number from which the primitive arrived.
*
*             The third parameter, spId, indicates the SIP SAP
*             number on which the primitive arrived.
*
*             SIP will register this new service user i.e. its
*             processor, entity and instance id, and will associate the
*             service user SAP id (suId) with its own SAP id (spId).
*             The service user corresponds to a border element.
*
*      Ret:   ROK     - bind successful
*             RFAILED - bind unsuccessful
*
*      Notes: Prior to binding, the specified SAP should have been
*             configured (and thereby allocated and initialized) by
*             layer management.
*
*      File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 SoUiSotBndReq
(
Pst    *pst,                /* post structure */
SuId   suId,                /* service user SAP id */
SpId   spId                 /* service provider SAP id */
)
#else
PUBLIC S16 SoUiSotBndReq(pst, suId, spId)
Pst    *pst;                /* post structure */
SuId   suId;                /* service user SAP id */
SpId   spId;                /* service provider SAP id */
#endif
{
   SoSSapCb  *ssap;         /* SSAP received the message */
   Pst       tmpPst;        /* Temporary post structure */

   TRC3(SoUiSotBndReq)

   SODBGP_SO(DBGMASK_UI, (soCb.init.prntBuf,
                          "\nSU SSAP %2d--SoUiSotBindReq->SIP\n",
                          spId));

   /* Initialize pst
    * This is used to return a CM_BIND_NOK
    */
   tmpPst.prior       = pst->prior;
   tmpPst.route       = pst->route;
   tmpPst.selector    = pst->selector;
   tmpPst.region      = soCb.init.region;
   tmpPst.pool        = soCb.init.pool;
   tmpPst.srcProcId   = soCb.init.procId;
   tmpPst.srcEnt      = soCb.init.ent;
   tmpPst.srcInst     = soCb.init.inst;
   tmpPst.event       = EVTNONE;
   tmpPst.dstProcId   = pst->srcProcId;
   tmpPst.dstEnt      = pst->srcEnt;
   tmpPst.dstInst     = pst->srcInst;

   if ((spId >= (SpId)soCb.cfg.maxNmbSSaps) || (spId < 0))
   {
      soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_SOT_BNDREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP,(Ptr)&spId);
      SoUiSotBndCfm(&tmpPst,suId,CM_BND_NOK);
      RETVALUE(RFAILED);
   }

   if (suId < 0)
   {
      soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_SOT_BNDREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&suId);
      SoUiSotBndCfm(&tmpPst,suId,CM_BND_NOK);
      RETVALUE(RFAILED);
   }

   ssap = soCb.soSSapCbLst[spId];

   if (ssap == (SoSSapCb *) NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR (ERRCLS_DEBUG, ESO290, (ErrVal) 0,
                  "\nSoUiSotBndReq():SSap not configured\n");
#endif
      soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_SOT_BNDREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP,(Ptr)&spId);
      SoUiSotBndCfm(&tmpPst,suId,CM_BND_NOK);
      RETVALUE(RFAILED);
   }

   if (ssap->state == LSO_SSAP_BNDENA)
   {
      /* SAP is already bound, return OK */
      SoUiSotBndCfm(&ssap->pst,suId,CM_BND_OK);
      RETVALUE(ROK);
   }

   /* Perform bind */
   /* Link to entity control block */
   ssap->sys = soCb.entLst[ssap->cfg.entId];

   if (ssap->sys == NULLP)
   {
      /* Entity has been deleted since configuration, don't bind */
      soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_SOT_BNDREQ,
                  LSO_CAUSE_INV_ENTID, LSO_PAR_ENT,(Ptr)&ssap->cfg.entId);
      SoUiSotBndCfm(&tmpPst,suId,CM_BND_NOK);
      RETVALUE(ROK);
   }

   /* copy bind configuration parameters in cb */
   ssap->suId          = suId;
   ssap->pst.dstProcId = pst->srcProcId;
   ssap->pst.dstEnt    = pst->srcEnt;
   ssap->pst.dstInst   = pst->srcInst;

#ifdef CP_UA_IF_TYPE_SS
   tmpPst.selector    = ssap->pst.selector;
#endif /* CP_UA_IF_TYPE_SS */

   /* Change state appropriately */
   ssap->state = LSO_SSAP_BNDENA;

   soGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, LCM_EVENT_BND_OK,
               LSO_CAUSE_SAP_BNDENA, LSO_PAR_SAP, (Ptr)&spId);

   SoUiSotBndCfm(&tmpPst,suId,CM_BND_OK);

   RETVALUE(ROK);
} /* SoUiSotBndReq */


/*****************************************************************************
*
*      Fun:   SoUiSotUbndReq
*
*      Desc:  This function unbinds the SIP service
*             user from the SIP layer.
*
*      Ret:   ROK     - unbind successful
*             RFAILED - unbind unsuccessful
*
*      Notes: None
*
*      File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 SoUiSotUbndReq
(
Pst    *pst,             /* post structure */
SpId   spId,             /* service provider SAP id */
Reason reason            /* reason for unbinding */
)
#else
PUBLIC S16 SoUiSotUbndReq(pst, spId, reason)
Pst    *pst;             /* post structure */
SpId   spId;             /* service provider SAP id */
Reason reason;           /* reason for unbinding */
#endif
{
   SoSSapCb     *ssap;   /* SSAP received the message */

   TRC3(SoUiSotUbndReq)

   UNUSED(pst);
   UNUSED(reason);

   SODBGP_SO(DBGMASK_UI, (soCb.init.prntBuf,
                          "\nSU SSAP %2d--SoUiSotUbndReq->SIP\n",
                          spId));

   if ((spId >= (SpId)soCb.cfg.maxNmbSSaps) || (spId < 0))
   {
      soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_SOT_BNDREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP,(Ptr) &spId);
      RETVALUE(RFAILED);
   }


   ssap = soCb.soSSapCbLst[spId];

   if (ssap == (SoSSapCb *) NULLP)
   {
      soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, LSO_EVENT_SOT_UBNDREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
      RETVALUE(RFAILED);
   }

   if (ssap->state == LSO_SSAP_UBNDDIS)
   {
      /* Already disabled and unbound */
      RETVALUE(ROK);
   }

   ssap->state = LSO_SSAP_UBNDDIS;

   soGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, LSO_EVENT_UBND_OK,
               LSO_CAUSE_SAP_UBNDDIS, LSO_PAR_SAP, (Ptr) &spId);


   RETVALUE(ROK);
} /* SoUiSotUbndReq */


/*****************************************************************************
*
*      Fun:   SoUiSotConReq
*
*      Desc:  Used to create and send an INVITE
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes: For UA & NS processing is different, call
*                UAConReq/NSConReq
*
*      File:  po_ui.c
*
*****************************************************************************/
#ifdef ANSI
PUBLIC S16 SoUiSotConReq
(
Pst            *pst,        /* post structure */
SpId           spId,        /* service provider SAP identifier */
UConnId        suConnId,    /* SU connection Id */
SoEvnt         *soEvnt      /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotConReq(pst, spId, suConnId, soEvnt)
Pst            *pst;        /* post structure */
SpId           spId;        /* service provider SAP identifier */
UConnId        suConnId;    /* SU connection Id */
SoEvnt         *soEvnt;     /* SIP messages event structure */
#endif
{
   S16          ret;        /* value returned by function calls */
   SoSSapCb     *ssap;      /* SSAP received the message */


   TRC3(SoUiSotConReq);

   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_CONREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, SOT_CONNID_NOTUSED, soEvnt, 
                 soEvnt->callLegId, soEvnt->eventType.val, 
                 ret, TRUE, FALSE);
#else
      soUiErrInd(ssap, suConnId, SOT_CONNID_NOTUSED, soEvnt, 
                 soEvnt->callLegId, soEvnt->eventType.val, 
                 ret, TRUE);
#endif
      RETVALUE(RFAILED);
   }

   ret = soUiValidatePrimitive(spId, EVTSOTCONREQ, soEvnt,&ssap);
   
   if(ret == SOT_ERR_NOERR)
   {
     /* 
      * so015.201: Print values as decimal to make it consistent with
      *            prints in other places.
      */
      SO_UI_PRNT_IN ("SoUiSotConReq", ssap->suId, (U32)SOT_CONNID_NOTUSED, suConnId, soEvnt);

      /* check event type, only Invite is allowed */
      if(soEvnt->eventType.val != SOT_ET_INVITE)
         ret = SOT_ERR_INVITE_EXPECTED;
   }
   
   if(ret == SOT_ERR_NOERR)
   {
      /* Distribute to UA/NS */
      switch (ssap->sys->entityType)
      {
#ifdef SO_UA
         case LSO_ENT_UA:
            ret = soUaInviteReq(ssap, soEvnt, suConnId);
            break;
#endif /* SO_UA */
         default:
            ret = SOT_ERR_ENT_INVALID;
#if (ERRCLASS & ERRCLS_DEBUG)
         /* Invalid condition - send error indication */
         SOLOGERROR(ERRCLS_DEBUG, ESO291,
                    (ErrVal) ssap->sys->entityType,
                    "SoUiSotConReq(): Invalid Entity type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      }
   }
      
   if(ret != SOT_ERR_NOERR)
   {

    /* Added for ccpu00061562 */

    if(ret == SOT_ERR_INV_SSAP)
    {
     #if (ERRCLASS & ERRCLS_DEBUG)

      SOLOGERROR (ERRCLS_DEBUG, ESO325, (ErrVal) 0,
                  "\nSoUiSotConReq():SSap not configured\n");
    #endif

     RETVALUE(RFAILED);

   }
     
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, SOT_CONNID_NOTUSED, soEvnt, 
                 soEvnt->callLegId, soEvnt->eventType.val,
                 ret, TRUE, FALSE);
#else
      soUiErrInd(ssap, suConnId, SOT_CONNID_NOTUSED, soEvnt, 
                 soEvnt->callLegId, soEvnt->eventType.val,
                 ret, TRUE);
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
   
} /* SoUiSotConReq */


/*****************************************************************************
*
*      Fun:   SoUiSotConRsp
*
*      Desc:  Used to process 2xx-6xx final responses for Invite from the user
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes: Distribute to NwsConReq/UACConReq
*
*      File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 SoUiSotConRsp
(
Pst            *pst,            /* post structure */
SpId           spId,            /* service provider SAP identifier */
UConnId        spConnId,        /* SP connection Id */
UConnId        suConnId,        /* SU connection Id */
SoEvnt         *soEvnt          /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotConRsp(pst, spId, spConnId, suConnId, soEvnt)
Pst            *pst;            /* post structure */
SpId           spId;            /* service provider SAP identifier */
UConnId        spConnId;        /* SP connection Id */
UConnId        suConnId;        /* SU connection Id */
SoEvnt         *soEvnt;         /* SIP messages event structure */
#endif
{
   S16            ret;           /* value returned by function calls */
   SoSSapCb       *ssap;        /* SSAP received the message */

   TRC3(SoUiSotConRsp);

   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == (SoSSapCb *) NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_CONREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, TRUE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, TRUE);
#endif
      RETVALUE(RFAILED);
   }
 
   ret = soUiValidatePrimitive(spId, EVTSOTCONRSP, soEvnt,&ssap);
   if ( ret == SOT_ERR_NOERR)
   {
     /* 
      * so015.201: Print values as decimal to make it consistent with
      *            prints in other places.
      */
      SO_UI_PRNT_IN ("SoUiSotConRsp", ssap->suId, spConnId, suConnId, soEvnt);
   }

   if ( ret == SOT_ERR_NOERR)
   {
      /* Distribute to UA/NS */
      switch (ssap->sys->entityType)
      {
#ifdef SO_UA
         case LSO_ENT_UA:
            ret = soUaConRsp(ssap, soEvnt, spConnId, suConnId);
            break;
#endif /* SO_UA */
         default:
            ret = SOT_ERR_ENT_INVALID;
#if (ERRCLASS & ERRCLS_DEBUG)
            /* Invalid condition - send error indication */
            SOLOGERROR(ERRCLS_DEBUG, ESO292,
                    (ErrVal) ssap->sys->entityType,
                    "SoUiSotConRsp(): Invalid Entity type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      }
   }

   if (ret!= SOT_ERR_NOERR)
   {

   /* Added for ccpu00061562 */
 
    if(ret == SOT_ERR_INV_SSAP)
    {
     #if (ERRCLASS & ERRCLS_DEBUG)

      SOLOGERROR (ERRCLS_DEBUG, ESO325, (ErrVal) 0,
                  "\nSoUiSotConRsp():SSap not configured\n");
    #endif

     RETVALUE(RFAILED);

   }
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
   
} /* SoUiSotConRsp */


/*****************************************************************************
*
*      Fun:   SoUiSotCnStReq
*
*      Desc:  This function is used to process 1xx responses, INFO,COMET
*             PRACK messages from the user.
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes:
*
*      File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 SoUiSotCnStReq
(
Pst            *pst,            /* post structure */
SpId           spId,            /* service provider SAP identifier */
UConnId        spConnId,        /* SP connection Id */
UConnId        suConnId,        /* SU connection Id */
SoEvnt         *soEvnt          /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotCnStReq(pst, spId, spConnId, suConnId, soEvnt)
Pst            *pst;            /* post structure */
SpId           spId;            /* service provider SAP identifier */
UConnId        spConnId;        /* SP connection Id */
UConnId        suConnId;        /* SU connection Id */
SoEvnt         *soEvnt;         /* SIP messages event structure */
#endif
{
   S16            ret;          /* value returned by function calls */
   SoSSapCb       *ssap;        /* SSAP received the message */
   U8             primType;     /* Primitive Type */

   TRC3(SoUiSotCnStReq);

   primType = EVTSOTCNSTREQ;

   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == (SoSSapCb *) NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_CNSTREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }
      
   
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

#ifdef SO_REL_1_2_INF
   ret = soWrapOutInf(pst, primType, spId, &spConnId, &suConnId, soEvnt);
   if (ret != ROKDNA)
       RETVALUE(ret);
#endif

   ret = soUiValidatePrimitive(spId, primType, soEvnt,&ssap);
   if( ret == SOT_ERR_NOERR)
   {
     /* 
      * so015.201: Print values as decimal to make it consistent with
      *            prints in other places.
      */
      SO_UI_PRNT_IN ("SoUiSotCnStReq", ssap->suId, spConnId, suConnId, soEvnt);

      /* user fills in eventType, validate it */
      if(soEvnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST) 
      {  
         if((soEvnt->eventType.val != SOT_ET_INFO)&&
            (soEvnt->eventType.val != SOT_ET_PRECON_MET)&&
            (soEvnt->eventType.val != SOT_ET_PRACK))
         {

            if(soEvnt->eventType.val ==  SOT_ET_ACK)
            {
               ret = SoUiSotAckReq(pst, spId, spConnId, suConnId, soEvnt);
               RETVALUE(ret);
            }

            ret = SOT_ERR_INV_ETYPE;
         }
      }
   }

   if( ret == SOT_ERR_NOERR)
   {
      /* Distribute to UA/NS */
      switch (ssap->sys->entityType)
      {
#ifdef SO_UA
         case LSO_ENT_UA:
            ret = soUaCnStReq(ssap, soEvnt, spConnId, suConnId);
            break;
#endif /* SO_UA */
         default:
            ret = SOT_ERR_ENT_INVALID;
#if (ERRCLASS & ERRCLS_DEBUG)
            /* Invalid condition - send error indication */
            SOLOGERROR(ERRCLS_DEBUG, ESO293,
                    (ErrVal) ssap->sys->entityType,
                    "SoUiSotCnStReq(): Invalid Entity type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      }
   }

   if (ret!= SOT_ERR_NOERR)
   {
    /* Added for ccpu00061562 */

    if(ret == SOT_ERR_INV_SSAP)
    {
     #if (ERRCLASS & ERRCLS_DEBUG)

      SOLOGERROR (ERRCLS_DEBUG, ESO325, (ErrVal) 0,
                  "\nSoUiSotCnStReq():SSap not configured\n");
    #endif

     RETVALUE(RFAILED);

   }
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
   
} /* SoUiSotCnStReq */


/*****************************************************************************
*
*      Fun:   SoUiSotRelReq
*
*      Desc:  This function is used to process an outgoing BYE from the
*             user.
*             This function is also used to clear the SIP call context
*             locally (without sending outgoing BYE message).
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes:
*
*      File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 SoUiSotRelReq
(
Pst            *pst,            /* post structure */
SpId           spId,            /* service provider SAP identifier */
UConnId        spConnId,        /* SP connection Id */
UConnId        suConnId,        /* SU connection Id */
SoEvnt         *soEvnt          /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotRelReq(pst, spId, spConnId, suConnId, soEvnt)
Pst            *pst;            /* post structure */
SpId           spId;            /* service provider SAP identifier */
UConnId        spConnId;        /* SP connection Id */
UConnId        suConnId;        /* SU connection Id */
SoEvnt         *soEvnt;         /* SIP messages event structure */
#endif
{
   S16            ret;          /* value returned by function calls */
   SoSSapCb       *ssap;        /* SSAP received the message */
   U8             primType;     /* Primitive Type */

   TRC3(SoUiSotRelReq);
   
   primType = EVTSOTRELREQ;

   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == (SoSSapCb *) NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_RELREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }
    
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, TRUE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, TRUE);
#endif
      RETVALUE(RFAILED);
   }

#ifdef SO_REL_1_2_INF
   ret = soWrapOutInf(pst, primType, spId, &spConnId, &suConnId, soEvnt);
   if (ret != ROKDNA)
       RETVALUE(ret);
#endif
  
   ret = soUiValidatePrimitive(spId, primType, soEvnt,&ssap);
   if( ret == SOT_ERR_NOERR)
   {
     /* 
      * so015.201: Print values as decimal to make it consistent with
      *            prints in other places.
      */
      SO_UI_PRNT_IN ("SoUiSotRelReq", ssap->suId, spConnId, suConnId, soEvnt);

      /* Check event type, only BYE is allowed */
      if ((soEvnt->eventType.val != SOT_ET_BYE) &&
          (soEvnt->eventType.val != SOT_ET_LOCAL_REL))
         ret = SOT_ERR_INV_ETYPE;
   }

   if( ret == SOT_ERR_NOERR)
   {
      /* Distribute to UA/NS */
      switch (ssap->sys->entityType)
      {
#ifdef SO_UA
         case LSO_ENT_UA:
            if (soEvnt->eventType.val == SOT_ET_BYE)
               ret = soUaByeReq(ssap, soEvnt, spConnId, suConnId);
            else 
            {
               (Void) soUaLocalRel (ssap, soEvnt, spConnId, suConnId);
               soCmFreeEvent (soEvnt);
            }
            break;
#endif /* SO_UA */
         default:
            ret = SOT_ERR_ENT_INVALID;
#if (ERRCLASS & ERRCLS_DEBUG)
            /* Invalid condition - send error indication */
            SOLOGERROR(ERRCLS_DEBUG, ESO294,
                       (ErrVal) ssap->sys->entityType,
                       "SoUiSotRelReq(): Invalid Entity type");
#endif
      }
   }

   if (ret != SOT_ERR_NOERR)
   {
    /* Added for ccpu00061562 */

    if(ret == SOT_ERR_INV_SSAP)
    {
     #if (ERRCLASS & ERRCLS_DEBUG)

      SOLOGERROR (ERRCLS_DEBUG, ESO325, (ErrVal) 0,
                  "\nSoUiSotRelReq():SSap not configured\n");
    #endif

     RETVALUE(RFAILED);

   }
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, TRUE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, TRUE);
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
   
} /* SoUiSotRelReq */


/*****************************************************************************
*
*      Fun:   SoUiSotRelRsp
*
*      Desc:  This function is used to process 2xx for a BYE from the user.
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes:
*
*      File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 SoUiSotRelRsp
(
Pst            *pst,            /* post structure */
SpId           spId,            /* service provider SAP identifier */
UConnId        spConnId,        /* SP connection Id */
UConnId        suConnId,        /* SU connection Id */
SoEvnt         *soEvnt          /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotRelRsp(pst, spId, spConnId, suConnId, soEvnt)
Pst            *pst;            /* post structure */
SpId           spId;            /* service provider SAP identifier */
UConnId        spConnId;        /* SP connection Id */
UConnId        suConnId;        /* SU connection Id */
SoEvnt         *soEvnt;         /* SIP messages event structure */
#endif
{
   SoSSapCb       *ssap;        /* SSAP received the message */
   S16            ret;          /* value returned by function calls */

   TRC3(SoUiSotRelRsp);

   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == (SoSSapCb *) NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_RELRSP,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, TRUE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, TRUE);
#endif
      RETVALUE(RFAILED);
   }
      
#ifdef SO_REL_1_2_INF
   ret = soWrapOutInf (pst, EVTSOTRELRSP, spId, &spConnId, &suConnId, soEvnt);
   if (ret != ROKDNA)
       RETVALUE(ret);
#endif

   ret = soUiValidatePrimitive(spId, EVTSOTRELRSP, soEvnt,&ssap);
   if( ret == SOT_ERR_NOERR)
   {
     /* 
      * so015.201: Print values as decimal to make it consistent with
      *            prints in other places.
      */
      SO_UI_PRNT_IN ("SoUiSotRelRsp", ssap->suId, spConnId, suConnId, soEvnt);
   }

   if( ret == SOT_ERR_NOERR)
   {
      /* Distribute to UA/NS */
      switch (ssap->sys->entityType)
      {
#ifdef SO_UA
         case LSO_ENT_UA:
            ret = soUaByeRsp(ssap, soEvnt, spConnId, suConnId);
            break;
#endif /* SO_UA */
         default:
            ret = SOT_ERR_ENT_INVALID;
#if (ERRCLASS & ERRCLS_DEBUG)
         /* Invalid condition - send error indication */
            SOLOGERROR(ERRCLS_DEBUG, ESO295,
                       (ErrVal) ssap->sys->entityType,
                       "SoUiSotRelRsp(): Invalid Entity type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      }
   }

   if (ret != SOT_ERR_NOERR)
   {
    /* Added for ccpu00061562 */

    if(ret == SOT_ERR_INV_SSAP)
    {
     #if (ERRCLASS & ERRCLS_DEBUG)

      SOLOGERROR (ERRCLS_DEBUG, ESO325, (ErrVal) 0,
                  "\nSoUiSotRelRsp():SSap not configured\n");
    #endif

     RETVALUE(RFAILED);

   }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, TRUE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, TRUE);
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* SoUiSotRelRsp */


/*****************************************************************************
*
*      Fun:   SoUiSotModReq
*
*      Desc:  This function is used to process Re-Invite from the user.
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes:
*
*      File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 SoUiSotModReq
(
Pst            *pst,            /* post structure */
SpId           spId,            /* service provider SAP identifier */
UConnId        spConnId,        /* SP connection Id */
UConnId        suConnId,        /* SU connection Id */
SoEvnt         *soEvnt          /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotModReq(pst, spId, spConnId, suConnId, soEvnt)
Pst            *pst;            /* post structure */
SpId           spId;            /* service provider SAP identifier */
UConnId        spConnId;        /* SP connection Id */
UConnId        suConnId;        /* SU connection Id */
SoEvnt         *soEvnt;         /* SIP messages event structure */
#endif
{
   SoSSapCb       *ssap;      /* SSAP received the message */
   S16            ret;        /* value returned by function calls */

   TRC3(SoUiSotModReq);

   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == (SoSSapCb *) NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_MODREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

#ifdef SO_REL_1_2_INF
   ret = soWrapOutInf (pst, EVTSOTMODREQ, spId, &spConnId, &suConnId,soEvnt);
   if (ret != ROKDNA)
       RETVALUE(ret);
#endif

   ret = soUiValidatePrimitive(spId, EVTSOTMODREQ, soEvnt,&ssap);
   
   if(ret == SOT_ERR_NOERR)
   {
     /* 
      * so015.201: Print values as decimal to make it consistent with
      *            prints in other places.
      */
      SO_UI_PRNT_IN ("SoUiSotModReq", ssap->suId, spConnId, suConnId, soEvnt);

      /* check event type, only INVITE is allowed */
      if(soEvnt->eventType.val != SOT_ET_INVITE)
         ret = SOT_ERR_INVITE_EXPECTED;
   }
   
   if(ret == SOT_ERR_NOERR)
   {
      /* Distribute to UA/NS */
      switch (ssap->sys->entityType)
      {
#ifdef SO_UA
         case LSO_ENT_UA:
            ret = soUaModReq(ssap, soEvnt, spConnId, suConnId);
            break;
#endif /* SO_UA */
         default:
            ret = SOT_ERR_ENT_INVALID;
#if (ERRCLASS & ERRCLS_DEBUG)
            /* Invalid condition - send error indication */
            SOLOGERROR(ERRCLS_DEBUG, ESO296,
                       (ErrVal) ssap->sys->entityType,
                       "SoUiSotModReq(): Invalid Entity type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      }
   }

   if (ret != SOT_ERR_NOERR)
   {
    /* Added for ccpu00061562 */

    if(ret == SOT_ERR_INV_SSAP)
    {
     #if (ERRCLASS & ERRCLS_DEBUG)

      SOLOGERROR (ERRCLS_DEBUG, ESO325, (ErrVal) 0,
                  "\nSoUiSotModReq():SSap not configured\n");
    #endif

     RETVALUE(RFAILED);

   }
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
   
} /* SoUiSotModReq */


/*****************************************************************************
*
*      Fun:   SoUiSotModRsp
*
*      Desc:  This function is used to process response for RE-Invite 
*             from the user.
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes:
*
*      File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 SoUiSotModRsp
(
Pst            *pst,                /* post structure */
SpId           spId,                /* service provider SAP identifier */
UConnId        spConnId,            /* SP connection Id */
UConnId        suConnId,            /* SU connection Id */
SoEvnt         *soEvnt              /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotModRsp(pst, spId, spConnId, suConnId, soEvnt)
Pst            *pst;                /* post structure */
SpId           spId;                /* service provider SAP identifier */
UConnId        spConnId;            /* SP connection Id */
UConnId        suConnId;            /* SU connection Id */
SoEvnt         *soEvnt;             /* SIP messages event structure */
#endif
{
   SoSSapCb     *ssap;            /* SSAP received the message */
   S16          ret;              /* value returned by function calls */

   TRC3(SoUiSotModRsp);

   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == (SoSSapCb *) NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_MODRSP,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }
 

   ret = soUiValidatePrimitive(spId, EVTSOTMODRSP, soEvnt,&ssap);
   if(ret == SOT_ERR_NOERR)
   {
     /* 
      * so015.201: Print values as decimal to make it consistent with
      *            prints in other places.
      */
     SO_UI_PRNT_IN ("SoUiSotModRsp", ssap->suId, spConnId, suConnId, soEvnt);
   } 
   
   if(ret == SOT_ERR_NOERR)
   {
      /* Distribute to UA/NS */
      switch (ssap->sys->entityType)
      {
#ifdef SO_UA
         case LSO_ENT_UA:
            ret = soUaConRsp(ssap, soEvnt, spConnId, suConnId);
            break;
#endif /* SO_UA */
         default:
            ret = SOT_ERR_ENT_INVALID;
#if (ERRCLASS & ERRCLS_DEBUG)
            /* Invalid condition - send error indication */
            SOLOGERROR(ERRCLS_DEBUG, ESO297,
                    (ErrVal) ssap->sys->entityType,
                    "SoUiSotModRsp(): Invalid Entity type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      }
   }
   
   if (ret != SOT_ERR_NOERR)
   {
    /* Added for ccpu00061562 */

    if(ret == SOT_ERR_INV_SSAP)
    {
     #if (ERRCLASS & ERRCLS_DEBUG)

      SOLOGERROR (ERRCLS_DEBUG, ESO325, (ErrVal) 0,
                  "\nSoUiSotModRsp():SSap not configured\n");
    #endif

     RETVALUE(RFAILED);

   }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val,ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val,ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
   
} /* SoUiSotModRsp */

/*****************************************************************************
*
*      Fun:   SoUiSotAckReq
*
*      Desc:  This function is used to process Ack for an Invite from the user.
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes:
*
*      File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 SoUiSotAckReq
(
Pst            *pst,            /* post structure */
SpId           spId,            /* service provider SAP identifier */
UConnId        spConnId,        /* SP connection Id */
UConnId        suConnId,        /* SU connection Id */
SoEvnt         *soEvnt          /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotAckReq(pst, spId, spConnId, suConnId, soEvnt)
Pst            *pst;            /* post structure */
SpId           spId;            /* service provider SAP identifier */
UConnId        spConnId;        /* SP connection Id */
UConnId        suConnId;        /* SU connection Id */
SoEvnt         *soEvnt;         /* SIP messages event structure */
#endif
{
   SoSSapCb       *ssap;      /* SSAP received the message */
   S16            ret;        /* value returned by function calls */

   TRC3(SoUiSotAckReq);

   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == (SoSSapCb *) NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_ACKREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   ret = soUiValidatePrimitive(spId, EVTSOTACKREQ, soEvnt,&ssap);
   
   if(ret == SOT_ERR_NOERR)
   {
     /* 
      * so015.201: Print values as decimal to make it consistent with
      *            prints in other places.
      */
      SO_UI_PRNT_IN ("SoUiSotAckReq", ssap->suId, spConnId, suConnId, soEvnt);

      /* check event type, only ACK is allowed */
      if(soEvnt->eventType.val != SOT_ET_ACK)
         ret = SOT_ERR_INV_ETYPE;
   }
   
   if(ret == SOT_ERR_NOERR)
   {
      /* Distribute to UA/NS */
      switch (ssap->sys->entityType)
      {
#ifdef SO_UA
         case LSO_ENT_UA:
            ret = soUaAckReq(ssap, soEvnt, spConnId, suConnId);
            break;
#endif /* SO_UA */
         default:
            ret = SOT_ERR_ENT_INVALID;
#if (ERRCLASS & ERRCLS_DEBUG)
            /* Invalid condition - send error indication */
            SOLOGERROR(ERRCLS_DEBUG, ESO298,
                       (ErrVal) ssap->sys->entityType,
                       "SoUiSotModReq(): Invalid Entity type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      }
   }

   if (ret != SOT_ERR_NOERR)
   {
    /* Added for ccpu00061562 */

    if(ret == SOT_ERR_INV_SSAP)
    {
     #if (ERRCLASS & ERRCLS_DEBUG)

      SOLOGERROR (ERRCLS_DEBUG, ESO325, (ErrVal) 0,
                  "\nSoUiSotAckReq():SSap not configured\n");
    #endif

     RETVALUE(RFAILED);

   }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
   
} /* SoUiSotAckReq */


/*****************************************************************************
*
*      Fun:   SoUiSotCancelReq
*
*      Desc:  This function is used to process Cancel from the user.
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes:
*
*      File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 SoUiSotCancelReq
(
Pst            *pst,            /* post structure */
SpId           spId,            /* service provider SAP identifier */
UConnId        spConnId,        /* SP connection Id */
UConnId        suConnId,        /* SU connection Id */
SoEvnt         *soEvnt          /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotCancelReq(pst, spId, spConnId, suConnId, soEvnt)
Pst            *pst;            /* post structure */
SpId           spId;            /* service provider SAP identifier */
UConnId        spConnId;        /* SP connection Id */
UConnId        suConnId;        /* SU connection Id */
SoEvnt         *soEvnt;         /* SIP messages event structure */
#endif
{
   SoSSapCb       *ssap;      /* SSAP received the message */
   S16            ret;        /* value returned by function calls */

   TRC3(SoUiSotCancelReq);

   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == (SoSSapCb *) NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_CANCELREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif

      RETVALUE(RFAILED);
   }

   ret = soUiValidatePrimitive(spId, EVTSOTCANCELREQ, soEvnt,&ssap);
   
   if(ret == SOT_ERR_NOERR)
   {
     /* 
      * so015.201: Print values as decimal to make it consistent with
      *            prints in other places.
      */
      SO_UI_PRNT_IN ("SoUiSotCancelReq", ssap->suId, spConnId, suConnId, soEvnt);

      /* check event type, only CANCEL is allowed */
      if(soEvnt->eventType.val != SOT_ET_CANCEL)
         ret = SOT_ERR_INV_ETYPE;
   }
   
   if(ret == SOT_ERR_NOERR)
   {
      /* Distribute to UA/NS */
      switch (ssap->sys->entityType)
      {
#ifdef SO_UA
         case LSO_ENT_UA:
            ret = soUaCancelReq(ssap, soEvnt, spConnId, suConnId);
            break;
#endif /* SO_UA */
         default:
            ret = SOT_ERR_ENT_INVALID;
#if (ERRCLASS & ERRCLS_DEBUG)
            /* Invalid condition - send error indication */
            SOLOGERROR(ERRCLS_DEBUG, ESO299,
                       (ErrVal) ssap->sys->entityType,
                       "SoUiSotModReq(): Invalid Entity type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      }
   }

   if (ret != SOT_ERR_NOERR)
   {
    /* Added for ccpu00061562 */

    if(ret == SOT_ERR_INV_SSAP)
    {
     #if (ERRCLASS & ERRCLS_DEBUG)

      SOLOGERROR (ERRCLS_DEBUG, ESO325, (ErrVal) 0,
                  "\nSoUiSotCancelReq():SSap not configured\n");
    #endif

     RETVALUE(RFAILED);

   }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
   
} /* SoUiSotCancelReq */





/*****************************************************************************
*
*      Fun:   SoUiSotCAMReq
*
*      Desc:  The service user issues this primitive to initiate the following
*             - OPTION messages
*             - REFER messages
*             - SUBSCRIBE messages
*             - NOTIFY messages
*             - UPDATE messages
*             - MESSAGE messages
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes: 
*
*      File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 SoUiSotCAMReq
(
Pst            *pst,            /* post structure */
SpId           spId,            /* service provider SAP identifier */
UConnId        spConnId,        /* SP connection Id */
UConnId        suConnId,        /* SU connection Id */
SoEvnt         *soEvnt          /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotCAMReq(pst, spId, spConnId, suConnId, soEvnt)
Pst            *pst;            /* post structure */
SpId           spId;            /* service provider SAP identifier */
UConnId        spConnId;        /* SP connection Id */
UConnId        suConnId;        /* SU connection Id */
SoEvnt         *soEvnt;         /* SIP messages event structure */
#endif
{
   SoSSapCb       *ssap;      /* SSAP received the message */
   S16            ret;        /* value returned by function calls */

   TRC3(SoUiSotCAMReq);

   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == (SoSSapCb *) NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_CAMREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   ret = soUiValidatePrimitive(spId, EVTSOTCAMREQ, soEvnt,&ssap);
   if(ret == SOT_ERR_NOERR)
   {
     /* 
      * so015.201: Print values as decimal to make it consistent with
      *            prints in other places.
      */
      SO_UI_PRNT_IN ("SoUiSotCAMReq", ssap->suId, spConnId, suConnId, soEvnt);

      /* Check event type */
      if ((soEvnt->eventType.val != SOT_ET_OPTIONS) &&
          (soEvnt->eventType.val != SOT_ET_REFER) &&
          (soEvnt->eventType.val != SOT_ET_SUBSCRIBE) &&
          (soEvnt->eventType.val != SOT_ET_NOTIFY) &&
          (soEvnt->eventType.val != SOT_ET_UPDATE) &&
          (soEvnt->eventType.val != SOT_ET_MESSAGE))
         ret = SOT_ERR_INV_ETYPE;
   }
   
   if(ret == SOT_ERR_NOERR)
   {
      switch (ssap->sys->entityType)
      {
#ifdef SO_UA
         case LSO_ENT_UA:
            ret = soUaCAMReq(ssap, soEvnt, spConnId, suConnId);
            break;
#endif /* SO_UA */

         default:
            ret = SOT_ERR_ENT_INVALID;
#if (ERRCLASS & ERRCLS_DEBUG)
            /* Invalid condition - send error indication */
            SOLOGERROR(ERRCLS_DEBUG, ESO300,
                       (ErrVal) ssap->sys->entityType,
                       "SoUiSotCAMReq(): Invalid Entity type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      }
   }

   if (ret != SOT_ERR_NOERR)
   {
    /* Added for ccpu00061562 */

    if(ret == SOT_ERR_INV_SSAP)
    {
     #if (ERRCLASS & ERRCLS_DEBUG)

      SOLOGERROR (ERRCLS_DEBUG, ESO325, (ErrVal) 0,
                  "\nSoUiSotCAMReq():SSap not configured\n");
    #endif

     RETVALUE(RFAILED);

   }
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* SoUiSotCAMReq */


/*****************************************************************************
*
*      Fun:   SoUiSotCAMRsp
*
*      Desc:  The service user issues this primitive to reply to the following
*             messages -
*             - OPTIONS messages
*             - REFER messages
*             - SUBSCRIBE messages
*             - NOTIFY messages
*             - UPDATE messages
*             - MESSAGE messages
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes: 
*
*      File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 SoUiSotCAMRsp
(
Pst            *pst,            /* post structure */
SpId           spId,            /* service provider SAP identifier */
UConnId        spConnId,        /* SP connection Id */
UConnId        suConnId,        /* SU connection Id */
SoEvnt         *soEvnt          /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotCAMRsp(pst, spId, spConnId, suConnId, soEvnt)
Pst            *pst;            /* post structure */
SpId           spId;            /* service provider SAP identifier */
UConnId        spConnId;        /* SP connection Id */
UConnId        suConnId;        /* SU connection Id */
SoEvnt         *soEvnt;         /* SIP messages event structure */
#endif
{
   SoSSapCb       *ssap;      /* SSAP received the message */
   S16            ret;        /* value returned by function calls */

   TRC3(SoUiSotCAMRsp);

   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == (SoSSapCb *) NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_CONREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   ret = soUiValidatePrimitive(spId, EVTSOTCAMRSP, soEvnt,&ssap);
   if(ret == SOT_ERR_NOERR)
   {
     /* 
      * so015.201: Print values as decimal to make it consistent with
      *            prints in other places.
      */
      SO_UI_PRNT_IN ("SoUiSotCAMRsp", ssap->suId, spConnId, suConnId, soEvnt);
   } 

   if(ret == SOT_ERR_NOERR)
   {
      switch (ssap->sys->entityType)
      {
#ifdef SO_UA
         case LSO_ENT_UA:
            ret = soUaCAMRsp(ssap, soEvnt, spConnId, suConnId);
            break;
#endif /* SO_UA */

         default:
            ret = SOT_ERR_ENT_INVALID;
#if (ERRCLASS & ERRCLS_DEBUG)
               /* Invalid condition - send error indication */
               SOLOGERROR(ERRCLS_DEBUG, ESO301,
                    (ErrVal) ssap->sys->entityType,
                    "SoUiSotCAMRsp(): Invalid Entity type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      }
   }

   if (ret != SOT_ERR_NOERR)
   {
    /* Added for ccpu00061562 */

    if(ret == SOT_ERR_INV_SSAP)
    {
     #if (ERRCLASS & ERRCLS_DEBUG)

      SOLOGERROR (ERRCLS_DEBUG, ESO325, (ErrVal) 0,
                  "\nSoUiSotCAMRsp():SSap not configured\n");
    #endif

     RETVALUE(RFAILED);

   }
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, suConnId, spConnId, soEvnt, soEvnt->callLegId,
                 soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* SoUiSotCAMRsp */





/*****************************************************************************
*
*      Fun:   SoUiSotCIMReq
*
*      Desc: This primitive is used to process the follwoing call independent
*            messages:
*            - REGISTER messages
*            - UNKNOWN messages
*            - MESSAGE messages
*            - NOTIFY messages
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes:
*
*      File:  po_ui.c
*
*****************************************************************************/
#ifdef SO_REL_1_2_INF
#ifdef ANSI
PUBLIC S16 SoUiSotCIMReq
(
Pst           *pst,         /* post structure */
SpId          spId,         /* service provider SAP identifier */
SoEvnt        *soEvnt       /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotCIMReq (pst, spId, soEvnt)
Pst           *pst;         /* post structure */
SpId          spId;         /* service provider SAP identifier */
SoEvnt        *soEvnt;      /* SIP messages event structure */
#endif
#else
#ifdef ANSI
PUBLIC S16 SoUiSotCIMReq
(
Pst           *pst,         /* post structure */
SpId          spId,         /* service provider SAP identifier */
UConnId       spConnId,     /* SP connection Id */
UConnId       suConnId,     /* SU connection Id */
SoEvnt        *soEvnt       /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotCIMReq (pst, spId,spConnId,suConnId, soEvnt)
Pst           *pst;         /* post structure */
SpId          spId;         /* service provider SAP identifier */
UConnId       spConnId;     /* SP connection Id */
UConnId       suConnId;     /* SU connection Id */
SoEvnt        *soEvnt;      /* SIP messages event structure */
#endif
#endif /* SO_REL_1_2_INF */
{
   SoSSapCb     *ssap;      /* SSAP received the message */
   S16          ret;        /* value returned by function calls */
   U8           primType;   /* Primitive Type */
#ifdef SO_REL_1_2_INF
   UConnId       spConnId;     /* SP connection Id */
   UConnId       suConnId;     /* SU connection Id */
#endif

   TRC3(SoUiSotCIMReq);

   primType = EVTSOTCIMREQ;
#ifdef SO_REL_1_2_INF
   spConnId = SOT_CONNID_NOTUSED;  
   suConnId = SOT_CONNID_NOTUSED;
#endif

   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == (SoSSapCb *) NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_CIMREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, SOT_CONNID_NOTUSED, SOT_CONNID_NOTUSED, 
                 soEvnt, soEvnt->callLegId, soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, SOT_CONNID_NOTUSED, SOT_CONNID_NOTUSED, 
                 soEvnt, soEvnt->callLegId, soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   ret = soUiValidatePrimitive(spId, primType, soEvnt,&ssap);

#ifdef SO_REL_1_2_INF
   if ((ret == SOT_ERR_NOERR) &&
       (ssap->sys->entityType != LSO_ENT_NS))
   {
     if (soWrapOutInf (pst, primType, spId, &spConnId, &suConnId, soEvnt) != ROKDNA)
       RETVALUE (ret);
   }
#endif

   if(ret == SOT_ERR_NOERR)
   {
      SO_UI_PRNT_IN ("SoUiSotCIMReq", ssap->suId, spConnId, suConnId, soEvnt);

      /* Check that correct event type is set */
      if ((ssap->sys->entityType != LSO_ENT_NS) &&
          (soEvnt->eventType.val != SOT_ET_REGISTER_LOC)&&
          (soEvnt->eventType.val != SOT_ET_REGISTER)&&
          (soEvnt->eventType.val != SOT_ET_MESSAGE)&&
          (soEvnt->eventType.val != SOT_ET_UNKNOWN)&&
          /* so009.201 : To support INFO outside a call */
          (soEvnt->eventType.val != SOT_ET_INFO) &&
          (soEvnt->eventType.val != SOT_ET_NOTIFY))
         ret = SOT_ERR_INV_ETYPE;
   }
 

   if(ret == SOT_ERR_NOERR)
   {
      /* Distribute to UA/NS */
      switch (ssap->sys->entityType)
      {
#ifdef SO_NS
         case LSO_ENT_NS:
            ret = soNsCIMReq(ssap, soEvnt);
            break;
#endif /* SO_NS */
#ifdef SO_UA
         case LSO_ENT_UA:
            ret = soUaCIMReq(ssap, soEvnt, spConnId,suConnId);
            break;
#endif /* SO_UA */
      default:
            ret = SOT_ERR_ENT_INVALID;
#if (ERRCLASS & ERRCLS_DEBUG)
            /* Invalid condition - send error indication */
            SOLOGERROR(ERRCLS_DEBUG, ESO302,
                    (ErrVal) ssap->sys->entityType,
                    "SoUiSotCIMReq(): Invalid Entity type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      }
   }

   if (ret != SOT_ERR_NOERR)
   {
    /* Added for ccpu00061562 */

    if(ret == SOT_ERR_INV_SSAP)
    {
     #if (ERRCLASS & ERRCLS_DEBUG)

      SOLOGERROR (ERRCLS_DEBUG, ESO325, (ErrVal) 0,
                  "\nSoUiSotCIMReq():SSap not configured\n");
    #endif

     RETVALUE(RFAILED);

   }
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, SOT_CONNID_NOTUSED, SOT_CONNID_NOTUSED, 
                 soEvnt, soEvnt->callLegId, soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, SOT_CONNID_NOTUSED, SOT_CONNID_NOTUSED, 
                 soEvnt, soEvnt->callLegId, soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of SoUiSotCIMReq */





/*****************************************************************************
*
*      Fun:   SoUiSotCIMRsp
*
*      Desc: This primitive is used to process responses to call independent
*            requests
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes:
*
*      File:  po_ui.c
*
*****************************************************************************/
#ifdef SO_REL_1_2_INF
#ifdef ANSI
PUBLIC S16 SoUiSotCIMRsp
(
Pst           *pst,         /* post structure */
SpId          spId,         /* service provider SAP identifier */
SoEvnt        *soEvnt       /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotCIMRsp (pst, spId, soEvnt)
Pst           *pst;         /* post structure */
SpId          spId;         /* service provider SAP identifier */
SoEvnt        *soEvnt;      /* SIP messages event structure */
#endif
#else /* SO_REL_1_2_INF */
#ifdef ANSI
PUBLIC S16 SoUiSotCIMRsp
(
Pst           *pst,         /* post structure */
SpId          spId,         /* service provider SAP identifier */
UConnId       spConnId,     /* SP connection Id */
UConnId       suConnId,     /* SU connection Id */
SoEvnt        *soEvnt       /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotCIMRsp (pst, spId, spConnId, suConnId, soEvnt)
Pst           *pst;         /* post structure */
SpId          spId;         /* service provider SAP identifier */
UConnId       spConnId;     /* SP connection Id */
UConnId       suConnId;     /* SU connection Id */
SoEvnt        *soEvnt;      /* SIP messages event structure */
#endif
#endif /* SO_REL_1_2_INF */
{
   SoSSapCb       *ssap;    /* SSAP received the message */
   S16            ret;      /* value returned by function calls */
#ifdef SO_REL_1_2_INF
   UConnId       spConnId;     /* SP connection Id */
   UConnId       suConnId;     /* SU connection Id */
#endif
   TRC3(SoUiSotCIMRsp);

#ifdef SO_REL_1_2_INF
   spConnId = SOT_CONNID_NOTUSED;
   suConnId = SOT_CONNID_NOTUSED;
#endif
   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == (SoSSapCb *) NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_CIMRSP,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, SOT_CONNID_NOTUSED, SOT_CONNID_NOTUSED, 
                 soEvnt, soEvnt->callLegId, soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, SOT_CONNID_NOTUSED, SOT_CONNID_NOTUSED, 
                 soEvnt, soEvnt->callLegId, soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

#ifdef SO_REL_1_2_INF
   ret = soWrapOutInf(pst, EVTSOTCIMRSP, spId, &spConnId, &suConnId,soEvnt);
   if (ret != ROKDNA)
     RETVALUE(ret);
#endif
 
   ret = soUiValidatePrimitive(spId, EVTSOTCIMRSP, soEvnt,&ssap);
   if(ret == SOT_ERR_NOERR)
   {
      SO_UI_PRNT_IN ("SoUiSotCIMRsp", ssap->suId, spConnId, suConnId, soEvnt);
   }

   if(ret == SOT_ERR_NOERR)
   {
      /* Distribute to UA/NS */
      switch (ssap->sys->entityType)
      {


#ifdef SO_UA
         case LSO_ENT_UA:
           ret = soUaCIMRsp(ssap, soEvnt, spConnId, suConnId); 
            break;
#endif /* SO_UA */

#ifdef SO_NS
         case LSO_ENT_NS:
           ret = soNsCIMRsp(ssap, soEvnt); 
            break;
#endif /* SO_UA */

         default:
            ret = SOT_ERR_ENT_INVALID;
#if (ERRCLASS & ERRCLS_DEBUG)
            /* Invalid condition - send error indication */
            SOLOGERROR(ERRCLS_DEBUG, ESO303,
                    (ErrVal) ssap->sys->entityType,
                    "SoUiSotCIMRsp(): Invalid Entity type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      }
   }

   if (ret != SOT_ERR_NOERR)
   {
    /* Added for ccpu00061562 */

    if(ret == SOT_ERR_INV_SSAP)
    {
     #if (ERRCLASS & ERRCLS_DEBUG)

      SOLOGERROR (ERRCLS_DEBUG, ESO325, (ErrVal) 0,
                  "\nSoUiSotCIMRsp():SSap not configured\n");
    #endif

     RETVALUE(RFAILED);

   }
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, SOT_CONNID_NOTUSED, SOT_CONNID_NOTUSED, 
                 soEvnt, soEvnt->callLegId, soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, SOT_CONNID_NOTUSED, SOT_CONNID_NOTUSED, 
                 soEvnt, soEvnt->callLegId, soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
   
} /* SoUiSotCIMRsp */

#ifndef SO_REL_1_2_INF
#ifdef SO_UA
/*****************************************************************************
*
*      Fun:   SoUiSotAuditReq
*
*      Desc:  This function is used to process audit request from the user.
*             User can request an audit for a paricular call or for all calls
*             on a SSAP.
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes:
*
*      File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 SoUiSotAuditReq
(
Pst            *pst,            /* post structure */
SpId           spId,            /* service provider SAP identifier */
SoEvnt         *soEvnt          /* SIP messages event structure */
)
#else
PUBLIC S16 SoUiSotAuditReq(pst, spId, soEvnt)
Pst            *pst;            /* post structure */
SpId           spId;            /* service provider SAP identifier */
SoEvnt         *soEvnt;         /* SIP messages event structure */
#endif
{
   SoSSapCb       *ssap;      /* SSAP received the message */
   S16            ret;        /* value returned by function calls */
   SoEvnt         *sndEvnt;   /* evnt to be returned to the user */
   TknStrOSXL     *callId;    /* call identifier */
   SoCallCb       *callCb;    /* call control block */ 
   SoEvnt         *errEvnt; 
   
   TRC3(SoUiSotAuditReq);

   ret = soUiCheckEvnt(soEvnt);
   if (ret!= SOT_ERR_NOERR)
   {
      /* Check if ssap is valid */
      ssap = soCb.soSSapCbLst[spId];
      if (ssap == (SoSSapCb *) NULLP)
      {
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERFACE, 
                     LSO_EVENT_SOT_AUDITREQ,
                  LCM_CAUSE_INV_SAP, LSO_PAR_SAP, (Ptr)&spId);
         RETVALUE(RFAILED);
      }

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, SOT_CONNID_NOTUSED, SOT_CONNID_NOTUSED, 
                 soEvnt, soEvnt->callLegId, soEvnt->eventType.val, ret, FALSE, FALSE);
#else
      soUiErrInd(ssap, SOT_CONNID_NOTUSED, SOT_CONNID_NOTUSED, 
                 soEvnt, soEvnt->callLegId, soEvnt->eventType.val, ret, FALSE);
#endif
      RETVALUE(RFAILED);
   }

   ret = soUiValidatePrimitive(spId, EVTSOTAUDITREQ, soEvnt,&ssap);
   
   if (ret == SOT_ERR_NOERR)
   {
     if (ssap->sys->entityType != LSO_ENT_UA)
      ret = SOT_ERR_ENT_INVALID;
   }

   if(ret == SOT_ERR_NOERR)
   {
      SO_UI_PRNT_IN ("SoUiSotAuditReq", ssap->suId, (U32)SOT_CONNID_NOTUSED, (U32)SOT_CONNID_NOTUSED, soEvnt);

      /* check event type, only AUDIT is allowed */
      if(soEvnt->sipMessageType.val != SO_SIPMESSAGE_AUDIT)
         ret = SOT_ERR_INV_ETYPE;
      
      if(ret == SOT_ERR_NOERR)
      {
         soEvnt->t.auditEvnt.moreAudit = FALSE;
         if(soEvnt->t.auditEvnt.auditType == SOT_AUDIT_CALL)
         {
            callId = &soEvnt->t.auditEvnt.auditInfo.callInfo.callId;

            if((callId->pres == NOTPRSNT) || (callId->val == NULLP))
               ret = SOT_ERR_CALLID_NOTSPECIFIED;
            else
            {
               /* so032.201 Pass event type to locate call control block */
               callCb = soCoreLocateCallCb(ssap->sys, SOT_CONNID_NOTUSED, 
                         SOT_CONNID_NOTUSED, callId, SOT_ET_UNKNOWN);

               if(callCb == NULLP)
                  ret = SOT_ERR_CALL_NOTFOUND;
               else
                  ret = soUiFillCallInfo(&soEvnt->t.auditEvnt.auditInfo.callInfo,
                                         callCb);
            
               sndEvnt = soEvnt;
            }
         }
         else if(soEvnt->t.auditEvnt.auditType == SOT_AUDIT_SSAP)
         {
            /* ccpu00062158 */
            ret = soUiFillSSAPCallInfo(pst, &soEvnt, ssap, ssap->sys);
            sndEvnt = soEvnt;
         }
      }
   }
   
   if (ret != SOT_ERR_NOERR)
   {
      soUiFillErrEvnt(&errEvnt,soEvnt, soEvnt->callLegId, 
                      EVTSOTAUDITREQ, ret, FALSE);
      soCmFreeEvent(soEvnt);
      sndEvnt = errEvnt;
   }

   if(sndEvnt != NULLP)
      SoUiSotAuditCfm(&ssap->pst,ssap->suId, sndEvnt);

   RETVALUE(ROK);
   
} /* SoUiSotAuditReq */
#endif /* SO_UA */
#endif /* SO_REL_1_2_INF */

/*********************************************************************************
 * Primitives from SIP to the service user
 ********************************************************************************/


/*
 *
 *       Fun:   soUiConInd
 *
 *       Desc:  This function is used to process an incoming INVITE 
 *              message and pass it to the user.
 *
 *       Ret:   ROK     - successful
 *              RFAILED - unsuccessful
 *
 *       Notes: 
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soUiConInd
(
SoCallCb    *callCb,     /* call control block */ 
SoEvnt      *evnt        /* Message to send to service user */
)
#else
PUBLIC S16 soUiConInd (callCb, evnt)
SoCallCb    *callCb;     /* call control block */ 
SoEvnt      *evnt;       /* Message to send to service user */
#endif
{
   SoSSapCb     *ssap;      /* ssap */
   
   TRC2(soUiConInd);

   ssap = callCb->ssapCb;

  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotConInd" , ssap->suId, callCb->spConnId, (U32)SOT_CONNID_NOTUSED, evnt);

   (Void) SoUiSotConInd (&ssap->pst, ssap->suId, callCb->spConnId, evnt);

   RETVALUE(ROK);
   
} /* soUiConInd */


/*
 *
 *       Fun:   soUiConCfm
 *
 *       Desc:  This function is used to process incoming final responses
 *              to Invite and pass to the user.
 *
 *       Ret:    None
 *
 *       Notes:  We inherit the MsgCb, and must destroy it when done with.
 *
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soUiConCfm
(
UConnId     suConnId,    /* Service User Conn Id */
SoCallCb    *callCb,     /* call control block */ 
SoEvnt      *evnt        /* Message to send to service user */
)
#else
PUBLIC S16 soUiConCfm (suConnId, callCb, evnt)
UConnId     suConnId;    /* Service User Conn Id */
SoCallCb    *callCb;     /* call control block */ 
SoEvnt      *evnt;       /* Message to send to service user */
#endif
{
   SoSSapCb     *ssap;      /* ssap */
#ifdef SO_REL_1_2_INF
   S16          ret;
#endif

   TRC2(soUiConCfm);

#ifdef SO_REL_1_2_INF
   /* so009.201 : Added new parameter */
   ret = soWrapIncomingInf(EVTSOTCONCFM,suConnId, (Ptr)callCb, evnt);
   if(ret != ROKDNA)
      RETVALUE(ret);
#endif

   ssap = callCb->ssapCb;

  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotConCfm" , ssap->suId, callCb->spConnId, suConnId, evnt);

   (Void) SoUiSotConCfm (&ssap->pst, ssap->suId, suConnId, callCb->spConnId, evnt);

   RETVALUE (ROK);

} /* soUiConCfm */



/* so009.201 : Added new parameter suConnId to function call */

/*
 *
 *       Fun:   SoUiCnStInd
 *
 *       Desc: This function is used to process incoming 1xxresponse/INFO
 *              message and pass to the user.
 *
 *       Ret:   NROK     - successful
 *              RFAILED - unsuccessful
 *
 *       Notes:  
 *
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soUiCnStInd
(
UConnId     suConnId,    /* Service User Conn Id */
SoCallCb    *callCb,     /* call control block */ 
SoEvnt      *evnt        /* Message to send to service user */
)
#else
PUBLIC S16 soUiCnStInd (suConnId, callCb, evnt)
UConnId     suConnId;    /* Service User Conn Id */
SoCallCb    *callCb;     /* call control block */ 
SoEvnt      *evnt;       /* Message to send to service user */
#endif
{
   SoSSapCb     *ssap;      /* ssap */
#ifdef SO_REL_1_2_INF
   S16          ret;
#endif

   TRC2(soUiCnStInd);

#ifdef SO_REL_1_2_INF
   /* so009.201 : Added new parameter suConnId to function call */
   ret = soWrapIncomingInf(EVTSOTCNSTIND,suConnId, (Ptr)callCb, evnt);
   if(ret != ROKDNA)
      RETVALUE(ret);
#endif
   ssap = callCb->ssapCb;

  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotCnStInd" , ssap->suId, callCb->spConnId, suConnId, evnt);

   (Void) SoUiSotCnStInd (&ssap->pst, ssap->suId, suConnId, callCb->spConnId, evnt);

   RETVALUE(ROK);
   
} /* soUiCnStInd */


/* so009.201 : Added new parameter suConnId to function call */

/*
 *
 *       Fun:   soUiAckInd
 *
 *       Desc:  This function is used to process incoming ACK
 *              message and pass it to the user.
 *
 *       Ret:    
 *       
 *       Notes:  
 *
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soUiAckInd
(
UConnId     suConnId,    /* Service User Conn Id */
SoCallCb    *callCb,     /* call control block */ 
SoEvnt      *evnt        /* Message to send to service user */
)
#else
PUBLIC S16 soUiAckInd (suConnId, callCb, evnt)
UConnId     suConnId;    /* Service User Conn Id */
SoCallCb    *callCb;     /* call control block */ 
SoEvnt      *evnt;       /* Message to send to service user */
#endif
{
   SoSSapCb     *ssap;      /* ssap */
#ifdef SO_REL_1_2_INF
   S16          ret;
#endif

   TRC2(soUiAckInd);

#ifdef SO_REL_1_2_INF
   /* so009.201 : Added new parameter suConnId to function call */
   ret = soWrapIncomingInf(EVTSOTACKIND, suConnId, (Ptr)callCb, evnt);
   if(ret != ROKDNA)
      RETVALUE(ret);
#endif
   
   ssap = callCb->ssapCb;

  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotAckInd", ssap->suId, callCb->spConnId, suConnId, evnt);
   
#ifndef SO_REL_1_2_INF
   (Void) SoUiSotAckInd(&ssap->pst, ssap->suId, suConnId, callCb->spConnId, evnt);
#endif

   RETVALUE(ROK);
   
} /* soUiAckInd */



/* so009.201 : Added new parameter suConnId to function call */

/*
 *
 *       Fun:   soUiCancelInd
 *
 *       Desc:  This function is used to process incoming CANCEL
 *              message and pass it to the user.
 *
 *       Ret:   
 *
 *       Notes:  
 *
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soUiCancelInd
(
UConnId     suConnId,    /* Service User Conn Id */
SoCallCb    *callCb,     /* call control block */ 
SoEvnt      *evnt        /* Message to send to service user */
)
#else
PUBLIC S16 soUiCancelInd (suConnId, callCb, evnt)
UConnId     suConnId;    /* Service User Conn Id */
SoCallCb    *callCb;     /* call control block */ 
SoEvnt      *evnt;       /* Message to send to service user */
#endif
{
   SoSSapCb     *ssap;      /* ssap */
#ifdef SO_REL_1_2_INF
   S16          ret;
#endif

   TRC2(SoUiCancelInd);

#ifdef SO_REL_1_2_INF
   /* so009.201 : Added new parameter suConnId to function call */
   ret = soWrapIncomingInf(EVTSOTCANCELIND,suConnId, (Ptr)callCb, evnt);
   if(ret != ROKDNA)
      RETVALUE(ret);
#endif
   
   ssap = callCb->ssapCb;

  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotCancelInd" , ssap->suId, callCb->spConnId, suConnId, evnt);

#ifndef SO_REL_1_2_INF
   (Void) SoUiSotCancelInd (&ssap->pst, ssap->suId, suConnId, callCb->spConnId, evnt);
#endif

   RETVALUE(ROK);
   
} /* soUiCancelInd */


/* so009.201 : Added new parameter suConnId to function call */


/*
 *
 *       Fun:   soUiModInd
 *
 *       Desc:  This function is used to process an incoming re-Invite mssage
 *              and pass it to the user.
 *
 *       Ret:   ROK     - successful
 *              RFAILED - unsuccessful
 *
 *       Notes:  
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soUiModInd
(
UConnId     suConnId,    /* Service User Conn Id */
SoCallCb    *callCb,     /* call control block */ 
SoEvnt      *evnt        /* Message to send to service user */
)
#else
PUBLIC S16 soUiModInd (suConnId, callCb, evnt)
UConnId     suConnId;    /* Service User Conn Id */
SoCallCb    *callCb;     /* call control block */ 
SoEvnt      *evnt;       /* Message to send to service user */
#endif
{
   SoSSapCb     *ssap;      /* ssap */
#ifdef SO_REL_1_2_INF
   S16          ret;
#endif

   TRC2(SoUiModInd);

#ifdef SO_REL_1_2_INF
   /* so009.201 : Added new parameter suConnId to function call */
   ret = soWrapIncomingInf (EVTSOTMODIND,suConnId, (Ptr)callCb, evnt);
   if(ret != ROKDNA)
      RETVALUE(ret);
#endif
   ssap = callCb->ssapCb;
   
  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotModInd" , ssap->suId, callCb->spConnId, suConnId, evnt);

   (Void) SoUiSotModInd (&ssap->pst, ssap->suId, suConnId, callCb->spConnId, evnt);

   RETVALUE(ROK);
   
} /* soUiModInd */


/* so009.201 : Added new parameter suConnId to function call */

/*
 *
 *       Fun:   soUiModCfm
 *
 *       Desc:   This function is used to process repsonse to incoming Re-Invite
 *               and pass it to the user.
 *
 *       Ret:    None
 *
 *       Notes:  
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soUiModCfm
(
UConnId     suConnId,    /* Service User Conn Id */
SoCallCb    *callCb,     /* call control block */ 
SoEvnt      *evnt        /* Message to send to service user */
)
#else
PUBLIC S16 soUiModCfm (suConnId, callCb, evnt)
UConnId     suConnId;    /* Service User Conn Id */
SoCallCb    *callCb;      /* call control block */ 
SoEvnt      *evnt;        /* Message to send to service user */
#endif
{
   SoSSapCb     *ssap;      /* ssap */
#ifdef SO_REL_1_2_INF
   S16          ret;
#endif

   TRC2(soUiModCfm);

#ifdef SO_REL_1_2_INF
   /* so009.201 : Added new parameter suConnId to function call */
   ret = soWrapIncomingInf(EVTSOTMODCFM,suConnId, (Ptr)callCb, evnt);
   if(ret != ROKDNA)
      RETVALUE(ret);
#endif
   ssap = callCb->ssapCb;
   
  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotModCfm" , ssap->suId, callCb->spConnId, suConnId, evnt);

   (Void) SoUiSotModCfm (&ssap->pst, ssap->suId, suConnId, callCb->spConnId, evnt);

   RETVALUE(ROK);
} /* soUiModCfm */


/*
 *
 *       Fun:   soUiCIMInd
 *
 *       Desc:  This function is to process incoming Call Independent messages
 *               and pass to the user.
 *
 *       Ret:    None
 *
 *       Notes: 
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soUiCIMInd
(
SoSSapCb    *ssap,       /* SSAP control block */ 
UConnId     suConnId,    /* SU connection Id */
UConnId     spConnId,    /* SP connection Id */
SoEvnt      *evnt        /* Message to send to service user */
)
#else
PUBLIC S16 soUiCIMInd(ssap, suConnId,spConnId, evnt)
SoSSapCb    *ssap;       /* SSAP control block */ 
SoEvnt      *evnt;       /* Message to send to service user */
UConnId     suConnId;    /* SU connection Id */
UConnId     spConnId;    /* SP connection Id */
#endif
{
#ifdef SO_REL_1_2_INF
   S16          ret;
#endif
   
   TRC2(soUiCIMInd);

#ifdef SO_REL_1_2_INF
   ret = soWrapIncomingInf(EVTSOTCIMIND,0, (Ptr)ssap, evnt);
   if(ret != ROKDNA)
      RETVALUE(ret);
#endif
 
  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotCIMInd" , ssap->suId, spConnId, suConnId, evnt);

#ifdef SO_REL_1_2_INF
   (Void) SoUiSotCIMInd (&ssap->pst, ssap->suId, evnt);
#else
   (Void) SoUiSotCIMInd (&ssap->pst, ssap->suId, suConnId, spConnId, evnt);
#endif
   
   RETVALUE(ROK);
   
} /* soUiCIMInd */


/*
 *
 *       Fun:   soUiCIMCfm
 *
 *       Desc:  This function is used to processs incoming Call Independent
 *              message responses and pass to the user.
 *
 *       Ret:    None
 *
 *       Notes:  
 *
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soUiCIMCfm
(
SoSSapCb    *ssap,        /* ssap */
UConnId     suConnId,     /* SU connection Id */
UConnId     spConnId,     /* SP connection Id */
SoEvnt      *evnt         /* Message to send to service user */
)
#else
PUBLIC S16 soUiCIMCfm (ssap, suConnId,spConnId,evnt)
SoSSapCb    *ssap;        /* ssap */
UConnId     suConnId;     /* SU connection Id */
UConnId     spConnId;     /* SP connection Id */
SoEvnt      *evnt;        /* Message to send to service user */
#endif
{
#ifdef SO_REL_1_2_INF
   S16          ret;
#endif
   
   TRC2(soUiCIMCfm);

#ifdef SO_REL_1_2_INF
   ret = soWrapIncomingInf(EVTSOTCIMCFM,0, (Ptr)ssap, evnt);
   if(ret != ROKDNA)
      RETVALUE(ret);
#endif

   SO_UI_PRNT_OUT ("SoUiSotCIMCfm", ssap->suId, spConnId, suConnId, evnt);

#ifdef SO_REL_1_2_INF
   (Void) SoUiSotCIMCfm (&ssap->pst, ssap->suId, evnt);
#else
   (Void) SoUiSotCIMCfm (&ssap->pst, ssap->suId, suConnId, spConnId, evnt);
#endif

   RETVALUE(ROK);
} /* soUiCIMCfm */




/*
 *
 *       Fun:   soRefreshInd
 *
 *       Desc:  Send a timeout indication to the upper user for
 *              sessiont timer, subscribe timer
 *
 *       Ret:    None
 *
 *       Notes: 
 *
 *       Notes:  
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soRefreshInd
(
SoCLegCb    *legCb,         /* Leg control block */
SoEvnt      *soEvnt,
U8          type
)
#else
PUBLIC S16 soRefreshInd (legCb, soEvnt, type)
SoCLegCb    *legCb;        /* Leg control block */
SoEvnt      *soEvnt;
U8          type;
#endif
{
   Pst         *uiPst;
   SoSSapCb    *ssapCb;
   SuId        suId;
   SpId        spId;
   UConnId     suConnId;
   UConnId     spConnId;
   S16         ret;
   SoEvnt      *evnt;

   TRC2(soRefreshInd);

   ret = ROK;

   /* Create a new event */
   ret = soCmCreateEvent(&evnt, SOT_ET_REFRESH);

   if (ret != ROK)
   {
      SO_GEN_SMEM_ALARM;
      RETVALUE(RFAILED);
   }

#ifndef SO_REL_1_2_INF

   evnt->t.refreshEvnt.type = type;
   switch(type)
   {
      case SOT_ET_REG_TMO:
         if (soUiFillRegRefreshInfo(soEvnt, evnt) != ROK)
         {
            soCmFreeEvent(evnt);
                 RETVALUE(RFAILED);
         }
         break;
#ifdef SO_UA
#ifdef SO_EVENT         
      case SOT_ET_SUBSC_TMO:
         if(soCpySubscId(soEvnt, &evnt->t.errEvnt.t.subscId, &evnt->memCp) != ROK)
         {
            soCmFreeEvent(evnt);
            RETVALUE(RFAILED);
         }
#endif /* SO_EVENT */         
#endif /* SO_UA */
   }
#endif

   /* Initialise the other structures of the new event */
   evnt->sipMessageType.pres = PRSNT_NODEF;
   evnt->sipMessageType.val = SO_SIPMESSAGE_REFRESH;
   evnt->sipBody.bodyType.pres = NOTPRSNT;

   if (soEvnt != NULLP)
     evnt->transId = soEvnt->transId;
   else
     evnt->transId = 0;

   evnt->callLegId = legCb->legId;
   evnt->srcTranCb = 0;
   evnt->dstTranCb = 0;
   
   ssapCb = legCb->call->ssapCb;

   /* Initialise all other fields required for mod ind */
   /* so009.201 :Changed to userConnId from suConnId in call Cb */
   suConnId = legCb->userConnId;
   spConnId = legCb->call->spConnId;
   
   uiPst = &ssapCb->pst;
   suId = ssapCb->suId;
   spId = ssapCb->sapId;

#ifdef SO_REL_1_2_INF
   /* so001.201: Fix incorrect spConnId, suConnId */
   ret = soWrapTmrRefresh(uiPst, suId, spConnId, suConnId, evnt, type);
#else

  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotRefreshInd", suId, spConnId, suConnId, evnt);

   (Void) SoUiSotRefreshInd (uiPst    , suId, suConnId, spConnId, evnt);
#endif /* SO_REL_1_2_INF */

   RETVALUE(ret);

} /* end of soRefreshInd */



/* so009.201 : Added new parameter suConnId to function call */

/*
 *
 *       Fun:   soUiCAMInd
 *
 *       Desc:
 *
 *       Ret:    None
 *
 *       Notes:  We inherit the MsgCb, and must destroy it when done with.
 *
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soUiCAMInd
(
UConnId     suConnId,    /* Service User Conn Id */
SoCallCb    *callCb,     /* call control block */ 
SoEvnt      *evnt        /* Message to send to service user */
)
#else
PUBLIC S16 soUiCAMInd (suConnId, callCb, evnt)
UConnId     suConnId;    /* Service User Conn Id */
SoCallCb    *callCb;      /* call control block */ 
SoEvnt      *evnt;        /* Message to send to service user */
#endif
{
   SoSSapCb     *ssap;      /* ssap */
#ifdef SO_REL_1_2_INF
   S16          ret;
#endif

   TRC2(soUiCAMInd);

#ifdef SO_REL_1_2_INF
   /* so009.201 : Added new parameter suConnId to function call */
   ret = soWrapIncomingInf(EVTSOTCAMIND,suConnId, (Ptr)callCb, evnt);
   if(ret != ROKDNA)
      RETVALUE(ret);
#endif
   ssap = callCb->ssapCb;

  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotCAMInd" , ssap->suId, callCb->spConnId, suConnId, evnt);

   /* Give indication to service user */
   (Void) SoUiSotCAMInd (&ssap->pst, ssap->suId, suConnId, callCb->spConnId, evnt);

   RETVALUE(ROK);
} /* soUiCAMInd */


/* so009.201 : Added new parameter suConnId to function call */


/*
 *
 *       Fun:   soUiCAMCfm
 *
 *       Desc:  This function is used to process incoming Call associated 
 *              message responses and pass to the user.
 *
 *       Ret:    None
 *
 *       Notes:  
 *
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soUiCAMCfm
(
UConnId     suConnId,    /* Service User Conn Id */
SoCallCb    *callCb,     /* call control block */ 
SoEvnt      *evnt        /* Message to send to service user */
)
#else
PUBLIC S16 soUiCAMCfm (suConnId, callCb, evnt)
UConnId     suConnId;    /* Service User Conn Id */
SoCallCb    *callCb;     /* call control block */ 
SoEvnt      *evnt;       /* Message to send to service user */
#endif
{
   SoSSapCb     *ssap;      /* ssap */
#ifdef SO_REL_1_2_INF
   S16          ret;
#endif

   TRC2(soUiCAMCfm);

#ifdef SO_REL_1_2_INF
   /* so009.201 : Added new parameter suConnId to function call */
   ret = soWrapIncomingInf(EVTSOTCAMCFM,suConnId, (Ptr)callCb, evnt);
   if(ret != ROKDNA)
      RETVALUE(ret);
#endif

   ssap = callCb->ssapCb;
   
  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotCAMCfm" , ssap->suId, callCb->spConnId, suConnId, evnt);

   (Void) SoUiSotCAMCfm (&ssap->pst, ssap->suId, suConnId, callCb->spConnId, evnt);

   RETVALUE(ROK);

} /* soUiCAMCfm */


/* so009.201 : Added new parameter suConnId to function call */

/*
 *
 *       Fun:   soUiRelInd
 *
 *       Desc:  This function is used to process invoming BYE message and pass
 *              it to the user.
 *
 *       Ret:   ROK     - successful
 *              RFAILED - unsuccessful
 *
 *       Notes:  
 *
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soUiRelInd
(
UConnId     suConnId,    /* Service User Conn Id */
SoCallCb    *callCb,     /* call control block */ 
SoEvnt      *evnt        /* Message to send to service user */
)
#else
PUBLIC S16 soUiRelInd (suConnId, callCb, evnt)
UConnId     suConnId;    /* Service User Conn Id */
SoCallCb    *callCb;     /* call control block */ 
SoEvnt      *evnt;       /* Message to send to service user */
#endif
{
   SoSSapCb     *ssap;      /* ssap */
   U8           relType;

   TRC2(soUiRelInd);

   ssap = callCb->ssapCb;

   /* Set the relType */
   if (evnt->eventType.val == SOT_ET_REDIRECT)
      relType = SOT_RELTYPE_REDIRECT;
   else 
      relType = SOT_RELTYPE_REMOTE;

  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotRelInd", ssap->suId, callCb->spConnId, suConnId, evnt);

#ifdef SO_REL_1_2_INF
   (Void) SoUiSotRelInd(&ssap->pst, ssap->suId, suConnId, callCb->spConnId, relType, evnt);
#else   
   (Void) SoUiSotRelInd(&ssap->pst, ssap->suId, suConnId, callCb->spConnId, evnt);
#endif
   
   RETVALUE(ROK);
   
} /* soUiRelInd */


/* so009.201 : Added new parameter suConnId to function call */

/*
 *
 *       Fun:   soUiRelCfm
 *
 *       Desc:   This function is used to process a response to incoming BYE
 *               and pass it to the user.
 *
 *       Ret:    None
 *
 *       Notes:  
 *
 *       File:  po_ui.c
 *
 */
#ifdef ANSI
PUBLIC S16 soUiRelCfm
(
UConnId     suConnId,    /* Service User Conn Id */
SoCallCb    *callCb,     /* call control block */ 
SoEvnt      *evnt        /* Message to send to service user */
)
#else
PUBLIC S16 soUiRelCfm (suConnId, callCb, evnt)
UConnId     suConnId,    /* Service User Conn Id */
SoCallCb    *callCb;     /* call control block */ 
SoEvnt      *evnt;       /* Message to send to service user */
#endif
{
   SoSSapCb     *ssap;      /* ssap */
#ifdef SO_REL_1_2_INF
   S16          ret;
#endif
   
   TRC2(soUiRelCfm);

   ssap = callCb->ssapCb;
 
#ifdef SO_REL_1_2_INF
   /* so009.201 : Added new parameter suConnId to function call */
   ret = soWrapIncomingInf (EVTSOTRELCFM,suConnId, (Ptr)callCb, evnt);
   if(ret != ROKDNA)
      RETVALUE(ret);
#endif

  /* 
   * so015.201: Print values as decimal to make it consistent with
   *            prints in other places.
   */
   SO_UI_PRNT_OUT ("SoUiSotRelCfm" , ssap->suId, callCb->spConnId, suConnId, evnt);

   (Void) SoUiSotRelCfm (&ssap->pst, ssap->suId, suConnId, callCb->spConnId, evnt);

   RETVALUE(ROK);
} /* soUiRelCfm */

#ifdef SO_CALEA

/*
 *
 *       Fun:   soUiRawMessage
 *
 *       Desc:  This function is used to send a raw message to application
 *
 *       Ret:   ROK     - always
 *
 *       Notes: 
 *
 *       File:  so_ui.c
 *
 */
#ifdef ANSI
PUBLIC Void soUiRawMessage
(
SoLeaUserCtxt  *leaCtxt,         /* LEA User Context              */
Buffer         *mBuf             /* Message Buffer in text format  */
)
#else
PUBLIC Void soUiRawMessage (leaCtxt, mBuf)
SoLeaUserCtxt  *leaCtxt,         /* LEA User Context              */
Buffer         *mBuf             /* Message Buffer in text format  */
#endif
{
   TRC2(soUiRawMessage);

   (Void) SoUiSotRawMsg (&leaCtxt->sSapCb->pst,
                         leaCtxt->sSapCb->suId,
                         leaCtxt->suConnId,
                         leaCtxt->spConnId,
                         leaCtxt->transId,
                         leaCtxt->callLegId,
                         leaCtxt->messageId,
                         leaCtxt->eventType,
                         leaCtxt->sipMessageType,
                         mBuf);

   RETVOID;
   
} /* SoUiSotRawMsg */
#endif


/*****************************************************************************
*
*     Fun:   soActvInit
*
*     Desc:  Invoked by system services to initialize the SIP
*            protocol layer.
*
*            The first and second parameters (entity, instance)
*            specify the entity and instance id.
*
*            The third parameter (region) specifies the memory region
*            to be used to allocate structures and buffers.
*
*            The fourth parameter (reason) specifies the reason for
*            calling this initialization function.
*
*            Allowable values for parameters are specified in ssi.h.
*
*     Ret:   ROK   - ok
*
*     Notes: None
*
*     File:  po_ui.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 soActvInit
(
Ent    ent,                 /* entity */
Inst   inst,                /* instance */
Region region,              /* region */
Reason reason               /* reason */
)
#else
PUBLIC S16 soActvInit(ent, inst, region, reason)
Ent    ent;                 /* entity */
Inst   inst;                /* instance */
Region region;              /* region */
Reason reason;              /* reason */
#endif
{
#ifdef SSI_WITH_CLI_ENABLED
#ifdef CP_UA_IF_TYPE_SS
	S32 retPrtl;
	S32 retSt;
#endif
#endif /* SSI_WITH_CLI_ENABLED */

   TRC3(soActvInit);

#ifdef SSI_WITH_CLI_ENABLED
#ifdef CP_UA_IF_TYPE_SS

	retPrtl = XOS_RegistCmdPrompt( SYSTEM_MODE, "prtl",  "Э��ģʽ", "�޲���" );

	retSt = XOS_RegistCmdPrompt( retPrtl, "sip", "sip Э��", "�޲���" );

	XOS_RegistCommand(retSt,
		              soPrintSoCb,
					  "showsocb",
					  "��ӡ���ƿ�",
					  "�޲���\r\n");

	XOS_RegistCommand(retSt,
		              soPrintSapCb,
					  "showsapcb",
					  "��ӡSAP���ƿ�",
					  "�޲���\r\n");

	XOS_RegistCommand(retSt,
		              soPrintGenStatic,
					  "showgensta",
					  "��ӡͳ����Ϣ",
					  "�޲���\r\n");

	XOS_RegistCommand(retSt,
		              soPrintMemInfo,
					  "showmem",
					  "��ӡ�ڴ�bucket��Ϣ",
					  "�޲���\r\n");

#ifdef DEBUGP
	XOS_RegistCommand(retSt,
		              soSetTraceLevel,
					  "setdbgmask",
					  "����Э��ջ���Կ���",
					  "dbgMask|help\r\n");

	XOS_RegistCommand(retSt,
		              soShowTraceLevel,
					  "showdbgmask",
					  "��ʾЭ��ջ���Կ���",
					  "�޲���\r\n");
#endif /* DEBUGP */

#endif /* CP_UA_IF_TYPE_SS */
#endif /* SSI_WITH_CLI_ENABLED */

   /* initialize soCb to all zero */
   (Void) cmMemset((U8 *) &soCb, 0, sizeof(soCb));

   /* initialize task configuration parameters */
   soCb.init.ent     = ent;           /* entity */
   soCb.init.inst    = inst;          /* instance */
   soCb.init.region  = region;        /* static region */
   soCb.init.pool    = 0;             /* static pool */
   soCb.init.reason  = reason;        /* reason */
   soCb.init.cfgDone = FALSE;         /* configuration done */
   soCb.init.acnt    = FALSE;         /* disable accounting */
   soCb.init.usta    = TRUE;          /* enable unsolicited status */
   soCb.init.trc     = FALSE;         /* enable trace */
   soCb.init.procId  = SFndProcId();  /* processor id */

   /* Initialize maxBlkSize for pack/unpacking before genCfg */
   soCb.cfg.maxBlkSize = 2530;

#ifdef SIP_DEBUG
   soCb.init.dbgMask = g_soDbgMask;
#endif

   RETVALUE(ROK);
} /* soActvInit */


/********************************************************************30**

         End of file:     so_ui.c@@/main/5 - Tue Apr 20 12:47:34 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/5      ---    ms        1. Release for 2.1.
/main/5+  so001.201 up        1. Fixed incorrect spConnId, suConnId prblm
/main/5+  so004.201 up        1. Call correct primitive for NS
/main/5+  so005.201 up        1. Fix compilation error
/main/5+  so006.201 up        1. Check for SOT_ET_INT_SESSTIMER_EXPD for 
                                 session expiry.
                              2. Set reason phrase if not already set by user.
/main/5+  so009.201 pk        1. Added new parameter userConnId in cLeg.
                                 Changes related userConnId.
                              2. Changes to support INFO outside a call.
/main/5+  so015.201 ps        1. Print values as decimal to make it consistent
                                 with prints in other places.
/main/5+  so017.201 sg        1. Distribute the error between NS and UA.
/main/5+  so018.201 ps        1. Set Reason Phrase if not already set by user.
/main/5+  so019.201 sg        1. Change the function soWrapFindConnId return
                                 type to 32-bit UConnID.
/main/5+  so024.201 ss        1. Call appropriate primitive in case of 
                                 Re-INVITE timeout
/main/5+  so025.201 ab        1. For 1.2 interface pass if internal message
                              2. In soWrapErrInd, call leg may not be present
                                 cheking for call leg existence.
/main/5+  so031.201 aj        1. For ccpu00061562
                              2. For ccpu00062158 
/main/5+  so032.201 ng        1. Pass event type to locate call control block(ab)
/main/5+  so036.201 ng        1. Changes for SO_CALEA
/main/5+  so038.201  ng       1. Fix for memory leak. Delete the event if there 
                                 is an error and function is returned.
*********************************************************************91*/
