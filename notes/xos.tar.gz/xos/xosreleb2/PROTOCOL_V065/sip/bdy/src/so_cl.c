/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SIP Cache Library

     Type:     C Source file

     Desc:     SIP cache library routines

               The cache library routines are used to keep a memory database
               of resolved dns queries and received REGISTER requests.
               Although the data structures and concepts are similar, in some
               cases the data received in REGISTER requests are just cached,
               whereas in other cases this data is stored in a semi-permanent
               database. When REGISTER requests are just cached it is referred
               to as a cache. When REGISTER requests are stored semi-
               permanently it is referred to as a registry.

               The basic data structure used to store cache data is a
               compressed multiway radix tree. This data structure is
               optimized for retrieval of text keys. This is well suited to
               the requirements since all keys are text fields, such as
                  user@domain.com,  domain.com, host.domain.com

               All cache entries have an associated time to live. This means
               that a timer is set when every entry is added to the cache.
               Every entry can therefore expire individually, in which case
               it is removed from the cache.

               Basic Cache Managemement Routines
               =================================
               1. Initialize cache
               2. Deinitialize cache
               3. Clear cache data
               4. Clear cache statistics
               5. Timer expire for entry

               Data Handling Routines
               ======================
               1. Add entry to cache
               2. Remove entry from cache

               SIP Message Processing
               ======================
               1. Process REGISTER request
               2. Normalize key from REGISTER request

     File:     so_cl.c

     Sid:      so_cl.c@@/main/4 - Tue Apr 20 12:45:53 2004

     Prg:      tn

*********************************************************************21*/


/* header include files (.h) */

/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "so.h"            /* SIP layer defines               */
#include "so_trans.h"      /* Transaction module defines      */
#include "so_err.h"        /* SIP error defines               */
#include "so_cm.h"         /* SIP layer utility functions     */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lso.x"           /* Layer management SIP            */
#include "sot.x"           /* SOT interface defines           */
#include "so_tcm.x"        /* Transport module structures     */
#include "so.x"            /* SIP layer structures            */
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* SIP layer utility functions     */
#include "so_cm.x"         /* SIP layer common functions      */
#include "so_dns.x"        /* SIP DNS library                 */
#include "so_cl.x"         /* SIP cache */

/* Maximum size of cache key */
#define SO_CACHEKEY_SIZE         500

/* Macro to increment the number of entries and track the
   peak number of entreis */
#define INC_NMBENTRIES(_cacheCb)\
{\
   _cacheCb->nmbEntries++;\
   if (_cacheCb->nmbEntries > _cacheCb->peakEntries)\
      _cacheCb->peakEntries = _cacheCb->nmbEntries;\
}

/* These two CHKCACHECB macros are used in cache functions which can be
   associated with a cacheCb or just used for temporary entries */
#define CHKCACHECB_ALLOCMEM(_cacheCb, _buf, _size, _ret)\
{\
   _ret = ROK;\
   if (_cacheCb != NULLP)\
   {\
      if (cacheAllocMem(_cacheCb, _buf, _size) != ROK)\
         _ret = RFAILED;\
   }\
   else\
   {\
      SOALLOC(_buf, _size);\
      if (_buf == NULLP)\
         RETVALUE(RFAILED);\
   }\
} /* CHKCACHECB_ALLOCMEM */

#define CHKCACHECB_FREEMEM(_cacheCb, _buf, _size)\
{\
      if (cacheCb != NULLP)\
      {\
         cacheFreeMem(_cacheCb, _buf, _size);\
      }\
      else\
      {\
         SOFREE(_buf, _size);\
      }\
}

#ifdef SO_DNS 
/* private Function prototypes */
PRIVATE S16 soFreeCacheDnsACb    ARGS((SoCacheCb    *cacheCb,
                                       SoClDnsAEnt  *entry));

PRIVATE S16 soFreeCacheDnsSrvCb  ARGS((SoCacheCb      *cacheCb,
                                       SoClDnsSrvEnt  *entry));

PRIVATE S16 cacheCpyTknStrOSXL   ARGS((TknStrOSXL   *dstTknStrOSXL,
                                       TknStrOSXL   *srcTknStrOSXL,
                                       SoCacheCb    *cacheCb));

PRIVATE S16 freeDnsAAnswerRec  ARGS ((
                    SoCacheCb          *cacheCb,
                    SoClDnsAAnswerRec  *delEntry,
                    Bool               checkMain));

PRIVATE S16 freeDnsSrvAnswerRec ARGS ((
                    SoCacheCb          *cacheCb,
                    SoDnsSrvAnswerRec  *delEntry,
                    Bool               checkMain));

PRIVATE S16 soFreeCacheDnsNaptrCb  ARGS((SoCacheCb      *cacheCb,
                                       SoClDnsNaptrEnt  *entry));

PRIVATE S16 cacheDelSoAddress    ARGS((SoAddress    *delSoAddr,
                                       SoCacheCb    *cacheCb));

PRIVATE S16 freeDnsNaptrAnswerRec ARGS ((
                    SoCacheCb          *cacheCb,
                    SoDnsNaptrAnswerRec  *delEntry));
EXTERN   CmAbnfElmDef   soMsgDefFrom;
#endif

PRIVATE S16 soClAddAccept ARGS((SoCacheCb *cacheCb, SoEvnt *evnt,
                                SoClRegEnt *entry,
                                Bool *invAction));

PRIVATE S16 soClAddAcceptLanguage ARGS ((SoCacheCb *cacheCb,
                                   SoEvnt    *evnt,
                                   SoClRegEnt *entry,
                                   Bool  *invAction));

PRIVATE S16 soClAddAcceptEncoding ARGS ((SoCacheCb     *cacheCb,
                                         SoEvnt        *evnt,
                                         SoClRegEnt    *entry,
                                         Bool          *invAction));

PRIVATE Void soClStartContactTmr  ARGS((SoCacheCb         *cacheCb,
                                        SoClRegContactEnt *cntEntry,
                                        U32               expVal));

PRIVATE S16 soClAddContact       ARGS((SoCacheCb     *cacheCb,
                                       SoClRegEnt    *entry,
                                       SoContactItem *newContact,
                                       TknU32        *expiry,
                                       Bool          *invAction));

PRIVATE S16 delContactEntry      ARGS((SoCacheCb         *cacheCb,
                                       SoClRegContactEnt *entry,
                                       U8                checkParent));

PRIVATE S16 cacheDelTknStrOSXL   ARGS((TknStrOSXL   *delTknStrOSXL,
                                       SoCacheCb    *cacheCb));

PRIVATE S16 cacheAllocMem        ARGS((SoCacheCb    *cacheCb,
                                       Ptr          *buf,
                                       U32          memSize));
PRIVATE S16 cacheFreeMem         ARGS((SoCacheCb    *cacheCb,
                                       Ptr          buf,
                                       U32          memSize));
PRIVATE S16 cacheCheckMem        ARGS((SoCacheCb    *cacheCb,
                                       S32          *newSize,
                                       Bool         allowFree));

#ifdef SO_DNS 
/*
*
*       Fun:   cacheCpyTknStrOSXL
*
*       Desc:  Copies a TknStrOSXL structure and checks
*              cache memory usage
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 cacheCpyTknStrOSXL
(
TknStrOSXL   *dstTknStrOSXL,
TknStrOSXL   *srcTknStrOSXL,
SoCacheCb    *cacheCb         /* Cache control block */
)
#else
PRIVATE S16 cacheCpyTknStrOSXL (dstTknStrOSXL, srcTknStrOSXL,  cacheCb)
TknStrOSXL   *dstTknStrOSXL;
TknStrOSXL   *srcTknStrOSXL;
SoCacheCb    *cacheCb;        /* Cache control block */
#endif
{
   S32   tmpSize;
   S16   ret;

   TRC2(cacheCpyTknStrOSXL);

   tmpSize = cacheCb->memUsed +
      (sizeof(U8) * srcTknStrOSXL->len);

   ret = cacheCheckMem(cacheCb, &tmpSize, TRUE);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   ret = soUtlCpyTknStrOSXL(dstTknStrOSXL, srcTknStrOSXL, NULLP);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   cacheCb->memUsed = tmpSize;

   RETVALUE(ROK);
} /* cacheCpyTknStrOSXL */
#endif /* SO_DNS */

/*
*
*       Fun:   cacheDelTknStrOSXL
*
*       Desc:  Deletes a TknStrOSXL structure and checks
*              cache memory usage
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 cacheDelTknStrOSXL
(
TknStrOSXL   *delTknStrOSXL,
SoCacheCb    *cacheCb         /* Cache control block */
)
#else
PRIVATE S16 cacheDelTknStrOSXL (delTknStrOSXL,  cacheCb)
TknStrOSXL   *delTknStrOSXL;
SoCacheCb    *cacheCb;        /* Cache control block */
#endif
{
   S32   tmpSize;

   TRC2(cacheDelTknStrOSXL);

   tmpSize = cacheCb->memUsed -
      (sizeof(U8) * delTknStrOSXL->len);

   cacheCheckMem(cacheCb, &tmpSize, FALSE);

   soUtlDelTknStrOSXL(delTknStrOSXL);

   cacheCb->memUsed = tmpSize;

   RETVALUE(ROK);
} /* cacheDelTknStrOSXL */






/*
*
*       Fun:   soClFindUser
*
*       Desc:  Searches cache/registry for user
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClFindUser
(
SoCacheCb     *cb,         /* Cache control block */
SoAddrSpec    *reqAddr,    /* Request URI to resolve */
SoClRegEnt    **regEntry,  /* Entry stored in cache */
U16           *findCount   /* Number of matches found */
)
#else
PUBLIC S16 soClFindUser (cb, reqAddr, regEntry, findCount)
SoCacheCb     *cb;         /* Cache control block */
SoAddrSpec    *reqAddr;    /* Request URI to resolve */
SoClRegEnt    **regEntry;  /* Entry stored in cache */
U16           *findCount; /* Number of matches found */
#endif
{
   S16          ret;       /* Return value */
   U8           keyBuffer[SO_CACHEKEY_SIZE];   /*Temporary buffer for key */
   U16          keyLength; /* Key length */

   TRC2(soClFindUser);

   /* Input checks: Message must be request, with register method */
   if ((cb == NULLP) || (reqAddr == NULLP) || (findCount == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO001, ERRZERO,
                 "soClFindUser: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }


   ret = soClNormalizeCacheKey(reqAddr,keyBuffer,&keyLength);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* Check if it is already in databse */
   ret = cmRdxTreeFindAll(&cb->rdxCp,keyBuffer,keyLength,
      (PTR *)regEntry, findCount);
   if (ret != ROK) 
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* soClFindUser */


/*
 *
 *       Fun:    soClCopyContactIntoReqUri
 *
 *       Desc:   Copy contact as reqURI into msg
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:
 *
 *       File:   so_cl.c
 *
 */

#ifdef ANSI
PUBLIC S16 soClCopyContactIntoReqUri
(
SoEvnt             *evnt,       /* Original event           */
SoClRegContactEnt  *contact     /* Contact to use as reqURI */
)
#else
PUBLIC S16 soClCopyContactIntoReqUri(evnt, contact)
SoEvnt             *evnt;       /* Original event           */
SoClRegContactEnt  *contact;    /* Contact to use as reqURI */
#endif
{
   SoRequestLine   *reqLine;  /* request line       */
   SoAddrSpec      *srcAddr;  /* source address     */
   U16             i;         /* counter            */
   SoContactParam  *cPar;     /* Contact parameter  */
   SoUrlParameter  *urlPar;   /* URL parameter      */
   S16             ret;       /* return value       */

   TRC2(soClCopyContactIntoReqUri);

   reqLine = &evnt->t.request.requestLine;

   if (contact->contact.contactAddrChoice.addrChType.val == SO_ADDRCH_NAMEADDR)
   {
      srcAddr = &contact->contact.contactAddrChoice.t.nameAddr.addrSpec;
   }
   else
   {
      srcAddr = &contact->contact.contactAddrChoice.t.addrSpec;
   }

   ret = soUtlCpySoAddrSpec(&reqLine->addrSpec, srcAddr, &evnt->memCp);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* Copy transport parameter */
   for (i = 0; i < SO_GET_NUM_COMP(&contact->contact.contactParams.numComp);
        i++)
   {
      /* Set local pointer */
      cPar = contact->contact.contactParams.contactParam[i];
      if (SO_CMP_TKN_LIT(&cPar->contactParamType,
         SO_CONTACTPARAM_STD) == FALSE)
      {
         if (soUtlCmpTknStrOSXLCi(&cPar->t.genericParam.token, 
                                 (U8 *)"Transport",
                                 9) == ROK)
         {
            ret = soCmGrowList(
               (Void ***)&reqLine->addrSpec.t.sipUrl.urlParameters.urlParameter,
               sizeof(SoUrlParameter),
               &reqLine->addrSpec.t.sipUrl.urlParameters.numComp,
               evnt);

            if (ret != ROK)
            {
               RETVALUE(RFAILED);
            }

            urlPar = reqLine->addrSpec.t.sipUrl.urlParameters.urlParameter[
               SO_GET_NUM_COMP(
                  &reqLine->addrSpec.t.sipUrl.urlParameters.numComp) - 1];

            SO_FILL_TKNU8(&urlPar->urlParameterType,
                          SO_URLPARAMETER_TRANSPORTPARAM);

            /* Check to see if this is TCP */
            if (soUtlCmpTknStrOSXLCi(&cPar->t.genericParam.paramVal.value,
                                  (U8 *)"tcp", 3) == ROK)
            {
               SO_FILL_TKNU8(&urlPar->t.transportParam.transportParamType,
                             SO_TRANSPORT_TCP);
            }
            else if (soUtlCmpTknStrOSXLCi(&cPar->t.genericParam.paramVal.value,
                      (U8 *)"udp", 3) == ROK)
            {
               SO_FILL_TKNU8(&urlPar->t.transportParam.transportParamType,
                             SO_TRANSPORT_UDP);

            }
         }
      }
   }

   RETVALUE(ROK);
} /* soClCopyContactIntoReqUri */


/*
*
*       Fun:   soClPrcRegistryEntry
*
*       Desc:  Processes SIP REGISTER message relating to cache
*
*       Ret:   ROK/RFAILED
*
*       Notes: This function processes a REGISTER message associated with
*              a specific cache/registry
*              Depending on the message it can add/remove or disable the
*              registry entry.
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClPrcRegistryEntry
(
SoCacheCb    *cb,          /* Cache control block */
SoEvnt       *regEvnt,     /* Register Message */
Bool         locEntry,     /* Local entry */
SoClRegEnt   **newEntry,   /* Pointer to current cache entry */
SoAddress    *addrEntry,   /* Address to be inserted into list */
Bool         *invAction,   /* Failure due to invalid action */
U32          *itemsAdded   /* Number of entries added */
)
#else
PUBLIC S16 soClPrcRegistryEntry(cb, regEvnt, locEntry, newEntry, addrEntry, 
                                invAction,itemsAdded)
SoCacheCb    *cb;          /* Cache control block */
SoEvnt       *regEvnt;     /* Register Message */
Bool         locEntry;     /* Local entry */
SoClRegEnt   **newEntry;   /* Pointer to current cache entry */
SoAddress    *addrEntry;   /* Address to be inserted into list */
Bool         *invAction;   /* Failure due to invalid action */
U32          *itemsAdded;  /* Number of entries added */
#endif
{
   SoAddrSpec     *tmpAddr;          /* Address spec part of address */
   U16            keyLength;         /* Length of cache key */
   U8             keyBuffer[SO_CACHEKEY_SIZE]; /*Temporary buffer for key */
   S16            ret;               /* Return value */

   TRC2(soClPrcRegistryEntry);

#if (ERRCLASS & ERRCLS_DEBUG)
   if ((cb == NULLP) || (regEvnt == NULLP))
   {
      SOLOGERROR(ERRCLS_DEBUG, ESO002, ERRZERO,
                 "soProcessRegistryEntry: NULL parameter");
      RETVALUE(RFAILED);
   }

   if (regEvnt->sipMessageType.val != SO_SIPMESSAGE_REQUEST)
   {
      SOLOGERROR(ERRCLS_DEBUG, ESO003, (ErrVal) NULLD,
                 "soProcessRegistryEntry: Invalid message");
      RETVALUE(RFAILED);
   }

   if (addrEntry == NULLP)
   {
      SOLOGERROR(ERRCLS_DEBUG, ESO004, ERRZERO,
                 "soProcessRegistryEntry: No To/From header");
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   if (invAction != NULLP)
   {
      (*invAction) = FALSE;
   }

   if (itemsAdded != NULLP)
   {
      (*itemsAdded)   = 0;
   }

   /* Get main cache entry */
   /* Insert new entry into cache
        Key = To address */
   SO_ADDRSPEC_FROM_ADDRCH(tmpAddr, &addrEntry->addrCh);

   ret = soClNormalizeCacheKey(tmpAddr, keyBuffer, &keyLength);
   if (ret != ROK)
   {
      SODBGP_SO(SO_DBGMASK_CL, (soCb.init.prntBuf,
                "soProcessRegistryEntry: Could not normalize To address\n"));
      RETVALUE(RFAILED);
   }

   ret = soClUpdateCacheContacts(cb, keyBuffer, keyLength, locEntry, regEvnt,
                                 newEntry, invAction, itemsAdded);

   RETVALUE(ret);
} /* soClPrcRegEntry */


/*
*
*       Fun:   soClNormalizeCacheKey
*
*       Desc:  Creates normalized version of key for a register cache entry
*
*       Ret:   ROK/RFAILED
*
*       Notes: Converts to lower case, expands only minimum control characters
*              Key consists of following:
*                     sip:user@host:port (sip url, password not included)
*                 or  scheme:uri  (non-sip uri)
*              Always zero-terminates string (zero terminator incl in length)
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClNormalizeCacheKey
(
SoAddrSpec       *addr,           /* URI to convert to key */
U8               *newKey,         /* String output for new cache key */
U16              *keyLength       /* Length of new key */
)
#else
PUBLIC S16 soClNormalizeCacheKey (addr, newKey, keyLength)
SoAddrSpec       *addr;           /* URI to convert to key */
U8               *newKey;         /* String output for new cache key */
U16              *keyLength;      /* Length of new key */
#endif
{
   S16         ret;        /* Return value */

   TRC2(soClNormalizeCacheKey);

   /* The incoming message must be a REGISTER request */
   if ((addr == NULLP) || (newKey == NULLP) || (keyLength == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO005, ERRZERO,
                 "soClNormalizeCacheKey: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   ret = soCmNormAddr(newKey, addr, keyLength);

   if (ret == ROK)
   {
      /* Force terminating zero, add to length */
      newKey[(*keyLength)++] = 0;
   }

   RETVALUE(ret);

} /* soClNormalizeCacheKey */





/*
*
*       Fun:   soClUpdateCacheContacts
*
*       Desc:  Updates cache based on message containing Contacts
*
*       Ret:   ROK
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClUpdateCacheContacts
(
SoCacheCb    *cacheCb,        /* Cache control block */
U8           *key,            /* Precalculated cache key */
U16          keyLength,       /* Key length */
Bool         locEntry,        /* Local entry */
SoEvnt       *evnt,           /* Event Cb */
SoClRegEnt   **entry,         /* Cache entry which was updated */
Bool         *invAction,      /* Failure due to invalid action */
U32          *itemsAdded      /* Entries added */
)
#else
PUBLIC S16 soClUpdateCacheContacts (cacheCb, key, keyLength, locEntry,
                                    evnt, entry, invAction, itemsAdded)
SoCacheCb    *cacheCb;        /* Cache control block */
U8           *key;            /* Precalculated cache key */
U16          keyLength;       /* Key length */
Bool         locEntry;        /* Local entry */
SoEvnt       *evnt;           /* Event Cb */
SoClRegEnt   **entry;         /* Cache entry which was updated */
Bool         *invAction;      /* Failure due to invalid action */
U32          *itemsAdded;     /* Entries added */
#endif
{
   SoClRegEnt     *mainEntry;        /* Main cache entry */
   S16            ret;               /* Return value */
   S16            ret1;              /* Return value */
   U16            k;
   SoContact      *contactHdr;       /* Contact header part of message */
   U32            j;                 /* Counter */
   S32            cItem;             /* Counter for contact items */
   U32            contactsFound;     /* How many contacts found */
   TknU32         *expiresHdr;       /* Expires header */
   SoRetryAfter   *retryAfterHdr;    /* Retry-After header */
   U32            retryAfterHdrVal;  /* Retry-After header value */
   U32            retryAfterDuration;/* Duration with RetryAfter */
   TknU32         expiresVal;        /* Expires header value */
   SoHeaderSeq    *hdrSeq;           /* Sequence of headers */
   U16            findCount;         /* Number of entries found */
   SoRetryParam   *rParam;           /* Retry parameter */
   SoContactItem  *contactItem;      /* Single contact item to process */
   S32            tmpSize;

   TRC2(soClUpdateCacheContacts);

   /* Input checks: Message must be request, with register method */
   if ((cacheCb == NULLP) || (evnt == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO006, ERRZERO,
                 "soClUpdateCacheContacts: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

#if (ERRCLASS & ERRCLS_DEBUG)
   /* This must be a register-type cache */
   if ((cacheCb->cacheType == SO_CACHE_DNS_A) ||
       (cacheCb->cacheType == SO_CACHE_DNS_SRV)
       || (cacheCb->cacheType == SO_CACHE_DNS_NAPTR))
   {
      SOLOGERROR(ERRCLS_DEBUG, ESO007, cacheCb->cacheType,
                 "soClUpdateCacheContacts: Invalid cache type");
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   if (invAction != NULLP)
   {
      (*invAction) = FALSE;
   }
   if (itemsAdded != NULLP)
   {
      (*itemsAdded)   = 0;
   }


   /* Extract expires header if required */
   expiresVal.pres = NOTPRSNT;
   expiresVal.val  = 0;
   soCmFindHdrChoice(evnt, (U8 **)&expiresHdr, SO_HEADER_GEN_EXPIRES);
   if (expiresHdr != NULLP)
   {
      /* Calculate seconds till expiry */
      expiresVal.pres = PRSNT_NODEF;
      if (expiresHdr->pres != NOTPRSNT)
         expiresVal.val = expiresHdr->val;
      else
         expiresVal.val = 0;

      if ((expiresVal.val > cacheCb->maxExpTm) &&
          (cacheCb->maxExpTm != 0))
      {
         expiresVal.val = cacheCb->maxExpTm;
      }
   }

   soCmFindHdrChoice(evnt, (U8 **)&retryAfterHdr,
                     SO_HEADER_RSP_RETRYAFTER);

   if (retryAfterHdr == NULLP)
   {
      retryAfterHdrVal = 0;
      retryAfterDuration = 0;
   }
   else
   {
      if (retryAfterHdr->retryAfterTime.pres != NOTPRSNT)
         retryAfterHdrVal = retryAfterHdr->retryAfterTime.val;
      else
         retryAfterHdrVal = 0;

      retryAfterDuration = 0;
      /* Scan retryAfter paramters for "duration" */
      for (j = 0;
           j < SO_GET_NUM_COMP(&retryAfterHdr->retryParams.numComp);
           j++)
      {
         rParam = retryAfterHdr->retryParams.retryParam[j];
         if (rParam != NULLP)
         {
            if (SO_CMP_TKN_LIT(&rParam->retryParamType,
               SO_RETRYPARAM_DURATION) == TRUE)
            {
               if (rParam->t.retryDuration.pres == PRSNT_NODEF)
                  retryAfterDuration = rParam->t.retryDuration.val;
               break;
            }
         }
      }
   }

   /* Get main cache entry */

   /* Check if it is already in database */
   ret = cmRdxTreeFindAll(&cacheCb->rdxCp, key, keyLength,
                          (PTR *)&mainEntry, &findCount);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      /* Cache failed */
      SOLOGERROR(ERRCLS_DEBUG, ESO008, ERRZERO,
                 "soClUpdateCacheContacts: cmRdxTreeFindAll failed");
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   if (findCount != 0)
   {
      SODBGP_SO(SO_DBGMASK_CL, (soCb.init.prntBuf,
                                "\nsoClUpdateCacheContacts\n-------------- "
                                "Found cache entry. Key = <%s>\n",
                                key));

      if (mainEntry->localEntry != locEntry)
      {
         /* Conflict - local value different */
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO009, (ErrVal) mainEntry->localEntry,
                 "soClUpdateCacheContacts: localFlag may not change");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         RETVALUE(RFAILED);
      }
   }
   else
   {
      SODBGP_SO(SO_DBGMASK_CL, (soCb.init.prntBuf,
                                "\nsoClUpdateCacheContacts\n-------------- "
                                "Add cache entry. Key = <%s>\n",
                                key));

      /* At this point we must add the entry to the cache/registry
       * 1. Allocate new registry entry control block + space for key
       * 2. Copy key into control block
       * 3. Add new entry to cache
       */
      ret = cacheAllocMem(cacheCb, (Ptr *)&mainEntry, sizeof(SoClRegEnt));
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

      /* Now allocate buffer for new key */
      ret = cacheAllocMem(cacheCb, (Ptr *)&mainEntry->key, keyLength);
      if (ret != ROK)
      {
         cacheFreeMem(cacheCb, mainEntry, sizeof(SoClRegEnt));
         RETVALUE(RFAILED);
      }

      /* Now initialize new entry before adding it */
      mainEntry->cacheCb    = cacheCb;
      mainEntry->localEntry = locEntry;
      mainEntry->keyLength  = keyLength;
      cmMemcpy(mainEntry->key, key, keyLength);

      soCmInitTimer(&mainEntry->retryAfterTmr);
      cmLListInit(&mainEntry->listContacts);

      /* Add into radix tree */
      ret = cmRdxTreeInsert(&cacheCb->rdxCp, (PTR)mainEntry, mainEntry->key,
         mainEntry->keyLength, FALSE);
      if (ret != ROK)
      {
         cacheFreeMem(cacheCb, (Ptr *)&mainEntry->key, keyLength);
         cacheFreeMem(cacheCb, (Ptr *)mainEntry, sizeof(SoClRegEnt));
         RETVALUE(RFAILED);
      }

      /* Check cache memory usage with new Rdx Tree entry */
      tmpSize = 0;
      ret = cacheCheckMem(cacheCb, &tmpSize, TRUE);
      if (ret != ROK)
      {
         cmRdxTreeDeletePtr(&cacheCb->rdxCp, (PTR)mainEntry);
         cacheFreeMem(cacheCb, (Ptr *)&mainEntry->key, keyLength);
         cacheFreeMem(cacheCb, (Ptr *)mainEntry, sizeof(SoClRegEnt));
         RETVALUE(RFAILED);
      }

      INC_NMBENTRIES(cacheCb);

      /* Add into linked list */
      cmLListNode(&(mainEntry->llNode)) = (PTR) mainEntry;
      cmLListAdd2Tail(&cacheCb->listCp, &(mainEntry->llNode));
   }

   /* At this point we have main cache entry, now we can process
    * the contact headers one by one
    */

   /* Process all Contact header fields */
   contactsFound = 0;
   if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
      hdrSeq = &evnt->t.request.request;
   else if (evnt->sipMessageType.val == SO_SIPMESSAGE_RESPONSE)
      hdrSeq = &evnt->t.response.response;

   ret1 = ROK;
   k = 0;

   do
   {
      ret1 = soCmFindHdrStrtChIndex(evnt, (U8 **)&contactHdr, k, &k,
                                    SO_HEADER_GEN_CONTACT);
      if (ret1 != ROK)
         break;

      /* increment to get the next available header */
      k++;
                           
      if (SO_CMP_TKN_LIT(&contactHdr->contactDescType,
         SO_CONTACTDESC_METASTAR) == TRUE)
      {
         /* Only single allowed, and only to remove all
          * with Expires header value = 0 */
         if (contactsFound != 0)
         {
            /* Already some previously processed */
#if (ERRCLASS & ERRCLS_DEBUG)
            SODBGP_SO(SO_DBGMASK_CL, (soCb.init.prntBuf,
                      "soClUpdateCacheContacts: Contact * and other "
                      "contact headers found"));
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
            RETVALUE(RFAILED);
         }

         if (expiresHdr == NULLP)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SODBGP_SO(SO_DBGMASK_CL, (soCb.init.prntBuf,
                      "soClUpdateCacheContacts: Contact * only valid"
                      "with Expires 0"));
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
            RETVALUE(RFAILED);
         }

         if (expiresVal.val != 0)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SODBGP_SO(SO_DBGMASK_CL, (soCb.init.prntBuf,
                      "soClUpdateCacheContacts: Contact * only"
                      "valid with Expires 0"));
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
            RETVALUE(RFAILED);
         }

         /* OK, delete all registrations for this entry
          * If retryAfter specified, just flag main entry as unavailable
          */
         if (retryAfterHdrVal != 0)
         {
            /* Flag unavailable, set timer, return */
            mainEntry->tempUnavail = TRUE;
            mainEntry->retryAfter  = retryAfterHdrVal;
            SGetSysTime(&(mainEntry->timeStarted));
            soSchedTmr(mainEntry, SO_TMR_CACHE_REGISTER_RETRY,
               TMR_RESTART, (retryAfterHdrVal * SO_TMRVAL_1_S));
            if (entry != NULLP)
               (*entry) = mainEntry;

            RETVALUE(ROK);
         }

         soClFreeCacheRegCb(cacheCb, mainEntry);
         if (entry != NULLP)
            (*entry) = NULLP;
         RETVALUE(ROK);
      }

      /* Non - * contact header, process all contact items in header */
      for (cItem = 0;
           cItem < SO_GET_NUM_COMP(&contactHdr->contactItems.numComp);
           cItem++)
      {
         contactItem = contactHdr->contactItems.contactItem[cItem];
         /* Expires specified, use value from header */
         ret = soClAddContact(cacheCb, mainEntry, contactItem,
                              &expiresVal, invAction);
         if ((ret == ROK) && (itemsAdded != NULLP))
            (*itemsAdded)++;
         if (ret != ROK)
         {
            /* If contact items already exist then this entry should be left */
            if (cItem == 0)
            {
               /* In this case there are no other contact entries
                  so the radix tree entry can be removed */
               soClFreeCacheRegCb(cacheCb, mainEntry);
               if (entry != NULLP)
                  (*entry) = NULLP;
            }
            RETVALUE(RFAILED);
         }
      }
   } while (ret1 == ROK);

   if (cacheCb->cacheType == SO_CACHE_LOC_USER_REG)
   {
      soClAddAccept(cacheCb, evnt, mainEntry, invAction);
      soClAddAcceptEncoding(cacheCb, evnt, mainEntry, invAction);
      soClAddAcceptLanguage(cacheCb, evnt, mainEntry, invAction);
   }

   /* Check if any entries remaining in main entry */
   if (cmLListLen(&mainEntry->listContacts) == 0)
   {
      /* It is now empty, delete main entry as well */
      soClFreeCacheRegCb(cacheCb, mainEntry);
      if (entry != NULLP)
         (*entry) = NULLP;

      RETVALUE(ROK);
   }

   /* Entry processed: Check if overall expire needs to be set due to Expire
    * header
    */
   if ((expiresVal.pres != NOTPRSNT) &&
       (mainEntry->tempUnavail == FALSE))
   {
      /* Remove globally after "Expires" time */
      if (expiresVal.val != 0)
      {
         soSchedTmr(mainEntry, SO_TMR_CACHE_REGISTER_RETRY,
            TMR_STOP, (expiresVal.val * SO_TMRVAL_1_S));
         soSchedTmr(mainEntry, SO_TMR_CACHE_REGISTER_RETRY,
            TMR_START, (expiresVal.val * SO_TMRVAL_1_S));
      }
   }

   if (entry != NULLP)
      (*entry) = mainEntry;

   RETVALUE(ROK);
} /* soClUpdateCacheContacts */

/*
*
*       Fun:   soClCreateRegEntry
*
*       Desc:  Create a registry entry based on a list of ContactItems
*
*       Ret:   ROK
*
*       Notes: If cacheCb is NULL, this is just used as a temporary cache
*              entry (i.e. to return a result), so no memory tracking is
*              done
*              rspMsg = response message from external location services
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClCreateRegEntry
(
SoCacheCb    *cacheCb,        /* Cache control block */
U8           *key,            /* Precalculated cache key */
U16          keyLength,       /* Key length */
SoClRegEnt   **entry,         /* Cache entry which was updated */
SoEvnt       *rspEvnt         /* Message containing contacts */
)
#else
PUBLIC S16 soClCreateRegEntry (cacheCb, key, keyLength, entry, rspEvnt)
SoCacheCb    *cacheCb;        /* Cache control block */
U8           *key;            /* Precalculated cache key */
U16          keyLength;       /* Key length */
SoClRegEnt   **entry;         /* Cache entry which was updated */
SoEvnt      *rspEvnt;         /* Message containing contacts */
#endif
{
   S16            ret;
   U32            i;            /* Counter */
   U32            hdrNum;
   SoContactItems *contactList; /* List of contact items */
   SoContactItem  *oneContact;  /* Single contact */
   SoContact      *contactHdr;  /* Contact header in message */
   SoHeader       *sipHdr;      /* Single SIP header from message */
   SoHeaderSeq    *hdrSeq;      /* Header sequence to add to reg. */

   TRC2(soClCreateRegEntry);

   if ((key == NULLP) || (entry == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO010, ERRZERO,
                 "soClCreateRegEntry: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   CHKCACHECB_ALLOCMEM(cacheCb, (Ptr *)entry, sizeof(SoClRegEnt), ret);
   if (ret != ROK)
      RETVALUE(RFAILED);

   soCmInitTimer(&(*entry)->retryAfterTmr);
   cmLListInit(&(*entry)->listContacts);

   if (rspEvnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
   {
      hdrSeq = &rspEvnt->t.request.request;
   }
   else
   {
      hdrSeq = &rspEvnt->t.response.response;
   }

   /* Copy key into cache entry */
   CHKCACHECB_ALLOCMEM(cacheCb, (Ptr *)&(*entry)->key, keyLength, ret);
   if (ret != ROK)
   {
      CHKCACHECB_FREEMEM(cacheCb, entry, sizeof(SoClRegEnt));
      RETVALUE(RFAILED);
   }

   cmMemcpy((*entry)->key, key, keyLength);
   (*entry)->keyLength = keyLength;
   /* Find responseHeaderCh element with required header field */
   for (hdrNum = 0; hdrNum < SO_GET_NUM_COMP(&hdrSeq->numComp); hdrNum++)
   {
      sipHdr = hdrSeq->header[hdrNum];

      if (sipHdr->headerType.val == SO_HEADER_GEN_CONTACT)
      {
         contactHdr = &sipHdr->t.contact;
         contactList = &contactHdr->contactItems;
         for (i = 0; i < contactList->numComp.val; i++)
         {
            /* Add one contact to cache - after checking
               if it is already there */
            oneContact = contactList->contactItem[i];
            soClAddContact(NULLP, (*entry), oneContact, NULLP, NULLP);
         }
      }
   }

   RETVALUE(ROK);

} /* soClCreateRegEntry */



/*
*
*       Fun:   delContactEntry
*
*       Desc:  Frees individual contact entry in list of registry entry
*
*       Ret:   ROK
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 delContactEntry
(
SoCacheCb         *cacheCb,        /* Cache control block */
SoClRegContactEnt *entry,          /* entry to free */
U8                checkParent      /* Check for last entry in parent list */
)
#else
PRIVATE S16 delContactEntry (cacheCb, entry, checkParent)
SoCacheCb         *cacheCb;        /* Cache control block */
SoClRegContactEnt *entry;          /* entry to free */
U8                checkParent;     /* Check for last entry in parent list */
#endif
{
   SoClRegEnt  *parentEntry;       /* Main cache entry */
   S32         tmpSize;

   TRC2(delContactEntry);

   parentEntry = entry->mainEntry;

   if (parentEntry != NULLP)
   {
      /* Remove from main linked list */
      cmLListDelFrm(&parentEntry->listContacts, &entry->llNode);
   }

   /* Stop expiry timer if it is running */
   soSchedTmr(entry, SO_TMR_CACHE_REGISTER, TMR_STOP, NOTUSED);

   /* Free memory for entry */
   SODBGP_SO(SO_DBGMASK_CL, (soCb.init.prntBuf,
                             "\ndelContactEntry\n-------------- Delete contact "
                             "entry. Contact = <%s>\n",
      entry->contactStr.val));

   if (cacheCb != NULLP)
   {
      cacheDelTknStrOSXL(&entry->contactStr, cacheCb);

   /* Free SoContactItem from cache memory */
      tmpSize = 0;
      soSizeOfSoContactItem(&entry->contact, (U32 *)&tmpSize);
      tmpSize = cacheCb->memUsed - (tmpSize - sizeof(SoContactItem));
      cacheCheckMem(cacheCb, &tmpSize, FALSE);
      soUtlDelSoContactItem(&entry->contact);
      cacheCb->memUsed = tmpSize;

      cacheFreeMem(cacheCb, entry, sizeof(SoClRegContactEnt));
   }
   else
   {
      soUtlDelTknStrOSXL(&entry->contactStr);
      soUtlDelSoContactItem(&entry->contact);
      SOFREE(entry, sizeof(SoClRegContactEnt));
   }

   if ((checkParent == TRUE) && (parentEntry != NULLP))
   {
      /* Check if there are any entries left in parent list */
      if (cmLListLen(&parentEntry->listContacts) == 0)
      {
         /* It is now empty, delete main entry as well */
         soClFreeCacheRegCb(cacheCb, parentEntry);
      }
   }

   RETVALUE(ROK);

} /* delContactEntry */


/*
*
*       Fun:   soClFreeCacheRegCb
*
*       Desc:  Frees memory for REGISTER cache entry
*
*       Ret:   ROK
*
*       Notes: It is valid to call this function with a NULL cache control
*              block. In that case the entry was a temporary entry and was
*              never part of a cache.
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClFreeCacheRegCb
(
SoCacheCb    *cacheCb,        /* Cache control block */
SoClRegEnt   *entry           /* Cache entry to free */
)
#else
PUBLIC S16 soClFreeCacheRegCb (cacheCb, entry)
SoCacheCb    *cacheCb;        /* Cache control block */
SoClRegEnt   *entry;          /* Cache entry to free */
#endif
{
   CmLList      *curNode;   /* Current node when scanning all items */
   PTR          curItem;    /* Current item */
   S32          tmpSize;
   S32          acceptSize;
   S32          accEncSize;
   S32          accLanSize;

   TRC2(soClFreeCacheRegCb);

   /* The incoming message must be a REGISTER request */
   if (entry == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO011, (ErrVal) NULLD,
                 "soClFreeCacheRegCb: NULL entry");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   /* Stop timer which might be running */
   soSchedTmr(entry, SO_TMR_CACHE_REGISTER_RETRY,
               TMR_STOP, NOTUSED);

   /* Free individual entries - scan list */
   curNode = cmLListFirst(&entry->listContacts);
   while (curNode != NULL)
   {
      curItem  = curNode->node;
      curNode  = curNode->next;
      delContactEntry(cacheCb, (SoClRegContactEnt *)curItem, FALSE);
   }

   if (cacheCb != NULL)
   {
      soSizeOfSoAccept(&entry->acceptHdr, (U32 *)&acceptSize);
      acceptSize -= sizeof(SoAccept);
      soSizeOfSoAcceptEncoding(&entry->accEncHdr, (U32 *)&accEncSize);
      accEncSize -= sizeof(SoAcceptEncoding);
      soSizeOfSoAcceptLanguage(&entry->accLanHdr, (U32 *)&accLanSize);
      accLanSize -= sizeof(SoAcceptLanguage);
      tmpSize = cacheCb->memUsed - (acceptSize + accEncSize + accLanSize);
      cacheCheckMem(cacheCb, &tmpSize, FALSE);
      cacheCb->memUsed = tmpSize;
   }
   soUtlDelSoAccept(&entry->acceptHdr);
   soUtlDelSoAcceptEncoding(&entry->accEncHdr);
   soUtlDelSoAcceptLanguage(&entry->accLanHdr);

   if (cacheCb != NULLP)
   {
      /* Remove from cache itself */
      /* Remove from tree */
      (Void) cmRdxTreeDeletePtr(&cacheCb->rdxCp, (PTR)entry);

      cacheCb->nmbEntries--;

      /* Remove from linked list */
      cmLListDelFrm(&cacheCb->listCp, &entry->llNode);
   }

   SODBGP_SO(SO_DBGMASK_CL, (soCb.init.prntBuf,
      "\nsoClFreeCacheRegCb\n-------------- Delete cache entry. Key = <%s>\n",
      entry->key));

   /* Free key memory */
   if (entry->keyLength > 0)
   {
      CHKCACHECB_FREEMEM(cacheCb, entry->key, entry->keyLength);
   }

   /* Free memory for entry itself */
   CHKCACHECB_FREEMEM(cacheCb, entry, sizeof(SoClRegEnt));

   RETVALUE(ROK);
} /* soClFreeCacheRegCb */




/*
*
*       Fun:   soClAddAccept
*
*       Desc:  Adds an accept header to existing contact registry entry. The the
*              registry entry already contains data for an accept header then
*              the old header is deleted and the new on added.
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 soClAddAccept
(
SoCacheCb     *cacheCb,    /* Cache control block */
SoEvnt        *evnt,       /* Event Cb */
SoClRegEnt    *entry,      /* Cache entry */
Bool          *invAction   /* Failure reaon - invalid action */
)
#else
PRIVATE S16 soClAddAccept (cacheCb, evnt, entry, invAction)
SoCacheCb     *cacheCb;    /* Cache control block */
SoEvnt        *evnt;       /* Event Cb */
SoClRegEnt    *entry;      /* Cache entry */
Bool          *invAction;  /* Failure reaon - invalid action */
#endif
{
   S32                 tmpSize;
   SoAccept            *acceptHdr;
   S16                 ret;

   TRC2(soClAddAccept);

   /* Extract parameters for contact item */
   if (invAction != NULLP)
      (*invAction) = FALSE;

   ret = soCmFindHdrChoice(evnt, (U8 **)&acceptHdr, SO_HEADER_GEN_ACCEPT);
   if (ret == ROK)
   {
      if ((entry->acceptHdr.numComp.pres != NOTPRSNT) &&
          (entry->acceptHdr.numComp.val != NULLD))
      {
         if (cacheCb != NULLP)
         {
            tmpSize = 0;
            ret = soSizeOfSoAccept(&entry->acceptHdr, (U32 *)&tmpSize);
            if (ret == ROK)
            {
               tmpSize = cacheCb->memUsed - (tmpSize - sizeof(SoAccept));
               ret = cacheCheckMem(cacheCb, &tmpSize, TRUE);
               if (ret == OK)
               {
                  soUtlDelSoAccept(&entry->acceptHdr);
                  cmMemset((U8 *)&entry->acceptHdr, NULLD, sizeof(SoAccept));
                  cacheCb->memUsed = tmpSize;
               }
            }
         }
         else
         {
            soUtlDelSoAccept(&entry->acceptHdr);
            cmMemset((U8 *)&entry->acceptHdr, NULLD, sizeof(SoAccept));
         }
      }
      if (ret != ROK)
         RETVALUE(ret);

      if (cacheCb != NULLP)
      {
         tmpSize = 0;
         ret = soSizeOfSoAccept(acceptHdr, (U32 *)&tmpSize);
         if (ret == ROK)
         {
            tmpSize = cacheCb->memUsed + (tmpSize - sizeof(SoAccept));
            ret = cacheCheckMem(cacheCb, &tmpSize, TRUE);
            if (ret == ROK)
            {
               ret = soUtlCpySoAccept(&entry->acceptHdr, acceptHdr, NULLP);
               if (ret == ROK)
               {
                  cacheCb->memUsed = tmpSize;
               }
               RETVALUE(ret);
            }
         }
      }
      else
      {
         ret = soUtlCpySoAccept(&entry->acceptHdr, acceptHdr, NULLP);
      }
   }

   RETVALUE(ROK);
} /* soClAddAcept */

/*
*
*       Fun:   soClAddAcceptLanguage
*
*       Desc:  Adds an accept header to existing contact registry entry. The the
*              registry entry already contains data for an acceptLanguage header
*              then the old header is deleted and the new on added.
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 soClAddAcceptLanguage
(
SoCacheCb     *cacheCb,    /* Cache control block */
SoEvnt        *evnt,       /* Event Cb */
SoClRegEnt    *entry,      /* Cache entry */
Bool          *invAction   /* Failure reaon - invalid action */
)
#else
PRIVATE S16 soClAddAcceptLanguage (cacheCb, evnt, entry, invAction)
SoCacheCb     *cacheCb;    /* Cache control block */
SoEvnt        *evnt;       /* Event Cb */
SoClRegEnt    *entry;      /* Cache entry */
Bool          *invAction;  /* Failure reaon - invalid action */
#endif
{
   S32                 tmpSize;
   SoAcceptLanguage    *acceptLanguage;
   S16                 ret;

   TRC2(soClAddAcceptLanguage);

   /* Extract parameters for contact item */
   if (invAction != NULLP)
      (*invAction) = FALSE;

   ret = soCmFindHdrChoice(evnt, (U8 **)&acceptLanguage,
                           SO_HEADER_GEN_ACCEPTLANGUAGE);
   if (ret == ROK)
   {
      if ((entry->accLanHdr.numComp.pres != NOTPRSNT) &&
          (entry->accLanHdr.numComp.val != NULLD))
      {
         if (cacheCb != NULLP)
         {
            tmpSize = 0;
            ret = soSizeOfSoAcceptLanguage(&entry->accLanHdr, (U32 *)&tmpSize);
            if (ret == ROK)
            {
               tmpSize = cacheCb->memUsed -
                  (tmpSize - sizeof(SoAcceptLanguage));
               ret = cacheCheckMem(cacheCb, &tmpSize, TRUE);
               if (ret == OK)
               {
                  soUtlDelSoAcceptLanguage(&entry->accLanHdr);
                  cmMemset((U8 *)&entry->accLanHdr, NULLD,
                           sizeof(SoAcceptLanguage));
                  cacheCb->memUsed = tmpSize;
               }
            }
         }
         else
         {
            soUtlDelSoAcceptLanguage(&entry->accLanHdr);
            cmMemset((U8 *)&entry->accLanHdr, NULLD, sizeof(SoAcceptLanguage));
         }
      }
      if (ret != ROK)
         RETVALUE(ret);

      if (cacheCb != NULLP)
      {
         tmpSize = 0;
         ret = soSizeOfSoAcceptLanguage(acceptLanguage, (U32 *)&tmpSize);
         if (ret == ROK)
         {
            tmpSize = cacheCb->memUsed + (tmpSize - sizeof(SoAcceptLanguage));
            ret = cacheCheckMem(cacheCb, &tmpSize, TRUE);
            if (ret == ROK)
            {
               ret = soUtlCpySoAcceptLanguage(&entry->accLanHdr,
                                           acceptLanguage,
                                           NULLP);
               if (ret == ROK)
               {
                  cacheCb->memUsed = tmpSize;
               }
               RETVALUE(ret);
            }
         }
      }
      else
      {
         ret = soUtlCpySoAcceptLanguage(&entry->accLanHdr, acceptLanguage, NULLP);
      }
   }

   RETVALUE(ROK);
} /* soClAddAceptLanguage */

/*
*
*       Fun:   soClAddAcceptEncoding
*
*       Desc:  Adds an accept header to existing contact registry entry. The the
*              registry entry already contains data for an acceptEncoding header
*              then the old header is deleted and the new on added.
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 soClAddAcceptEncoding
(
SoCacheCb     *cacheCb,    /* Cache control block */
SoEvnt        *evnt,       /* Event Cb */
SoClRegEnt    *entry,      /* Cache entry */
Bool          *invAction   /* Failure reaon - invalid action */
)
#else
PRIVATE S16 soClAddAcceptEncoding (cacheCb, evnt, entry, invAction)
SoCacheCb     *cacheCb;    /* Cache control block */
SoEvnt        *evnt;       /* Event Cb */
SoClRegEnt    *entry;      /* Cache entry */
Bool          *invAction;  /* Failure reaon - invalid action */
#endif
{
   S32                 tmpSize;
   SoAcceptEncoding    *acceptEncoding;
   S16                 ret;

   TRC2(soClAddAcceptEncoding);

   /* Extract parameters for contact item */
   if (invAction != NULLP)
      (*invAction) = FALSE;

   ret = soCmFindHdrChoice(evnt, (U8 **)&acceptEncoding,
                           SO_HEADER_GEN_ACCEPTENCODING);
   if (ret == ROK)
   {
      if ((entry->accEncHdr.numComp.pres != NOTPRSNT) &&
          (entry->accEncHdr.numComp.val != NULLD))
      {
         if (cacheCb != NULLP)
         {
            tmpSize = 0;
            ret = soSizeOfSoAcceptEncoding(&entry->accEncHdr, (U32 *)&tmpSize);
            if (ret == ROK)
            {
               tmpSize = cacheCb->memUsed -
                  (tmpSize - sizeof(SoAcceptEncoding));
               ret = cacheCheckMem(cacheCb, &tmpSize, TRUE);
               if (ret == OK)
               {
                  soUtlDelSoAcceptEncoding(&entry->accEncHdr);
                  cmMemset((U8 *)&entry->accEncHdr, NULLD,
                           sizeof(SoAcceptEncoding));
                  cacheCb->memUsed = tmpSize;
               }
            }
         }
         else
         {
            soUtlDelSoAcceptEncoding(&entry->accEncHdr);
            cmMemset((U8 *)&entry->accEncHdr, NULLD, sizeof(SoAcceptEncoding));
         }
      }
      if (ret != ROK)
         RETVALUE(ret);

      if (cacheCb != NULLP)
      {
         tmpSize = 0;
         ret = soSizeOfSoAcceptEncoding(acceptEncoding, (U32 *)&tmpSize);
         if (ret == ROK)
         {
            tmpSize = cacheCb->memUsed + (tmpSize - sizeof(SoAcceptEncoding));
            ret = cacheCheckMem(cacheCb, &tmpSize, TRUE);
            if (ret == ROK)
            {
               ret = soUtlCpySoAcceptEncoding(&entry->accEncHdr,
                                           acceptEncoding,
                                           NULLP);
               if (ret == ROK)
               {
                  cacheCb->memUsed = tmpSize;
               }
               RETVALUE(ret);
            }
         }
      }
      else
      {
         ret = soUtlCpySoAcceptEncoding(&entry->accEncHdr, acceptEncoding,
                                     NULLP);
      }
   }

      RETVALUE(ROK);
} /* soClAddAceptEncoding */

/*
*
*       Fun:   soClAddContact
*
*       Desc:  Adds single contact entry to existing contact registry
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 soClAddContact
(
SoCacheCb     *cacheCb,    /* Cache control block */
SoClRegEnt    *entry,      /* Cache entry */
SoContactItem *newContact, /* New contact to add */
TknU32        *expiry,     /* Expire value */
Bool          *invAction   /* Failure reaon - invalid action */
)
#else
PRIVATE S16 soClAddContact (cacheCb, entry, newContact, expiry, invAction)
SoCacheCb     *cacheCb;    /* Cache control block */
SoClRegEnt    *entry;      /* Cache entry */
SoContactItem *newContact; /* New contact to add */
TknU32        *expiry;     /* Expiry time for entry */
Bool          *invAction;  /* Failure reaon - invalid action */
#endif
{
   CmLList             *curNode;       /* Current node in list */
   PTR                 curItem;        /* Current item */
   SoClRegContactEnt   *newContactEnt; /* New contact entry in cache */
   SoClRegContactEnt   *curContactEnt; /* Current entry in list */
   TknStrOSXL          strContact;     /* String version of contact */
   SoAddrSpec          *cntAddr;       /* Contact address */
   S16                 ret;            /* Return value */
   U8                  keyBuffer[SO_CACHEKEY_SIZE];   /*Temporary buffer for
                                                        cache key */
   TknU8               action;         /* From contact param */
   TknU32              contactExpiry;  /* From contact param */
   SoQValue            contactQ;       /* From contact param */
   U32                 j;              /* Counter */
   SoContactParam      *cPar;          /* Contact item parameter */
   Bool                domainMatch;    /* Entry is for this domain */
   S32                 tmpSize;        /* Used to track memory usage */
   TknU32              *contactExp;    /* Contact parameter for expiry */

   TRC2(soClAddContact);

   /* Extract parameters for contact item */
   if (invAction != NULLP)
      (*invAction) = FALSE;

   action.pres = NOTPRSNT;
   if (expiry == NULLP)
      contactExpiry.pres = NOTPRSNT;
   else
   {
      contactExpiry.pres = expiry->pres;
      contactExpiry.val  = expiry->val;
   }

   contactQ.pres.pres = NOTPRSNT;
   for (j = 0;
        j < SO_GET_NUM_COMP(&newContact->contactParams.numComp);
        j++)
   {
      cPar = newContact->contactParams.contactParam[j];
      if (cPar != NULLP)
      {
         if (SO_CMP_TKN_LIT(&cPar->contactParamType,
            SO_CONTACTPARAM_STD) == TRUE)
         {
            switch (cPar->t.contactParamStd.contactParamStdType.val)
            {
               case SO_CONTACTPARAMSTD_Q:
                  cmMemcpy((U8 *)&contactQ,
                     (U8 *)&cPar->t.contactParamStd.t.qValue,
                     sizeof(SoQValue));
                  break;
               case SO_CONTACTPARAMSTD_ACTION:
                  action.pres = PRSNT_NODEF;
                  action.val = cPar->t.contactParamStd.t.action.val;
                  break;
               case SO_CONTACTPARAMSTD_EXPIRES:
                  contactExp = &cPar->t.contactParamStd.t.contactParExpires;
                  /* Convert datetime to delta seconds */
                  contactExpiry.pres = PRSNT_NODEF;
                  if (contactExp->pres != NOTPRSNT)
                     contactExpiry.val = contactExp->val;
                  else
                     contactExpiry.val = 0;

                  break;
               default:
#if (ERRCLASS & ERRCLS_DEBUG)
                  SOLOGERROR(ERRCLS_DEBUG, ESO012,
                             (ErrVal) cPar->t.contactParamStd.\
                                contactParamStdType.val,
                             "soClAddContact: invalid contactParamStdType");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
                  break;
            }
         }
      }
   }

   if (action.pres == PRSNT_NODEF)
   {
      /* Make sure it is same as main entry */
      if (entry->action.pres == NOTPRSNT)
      {
         entry->action = action;
      }
      else
      {
         if (entry->action.val != action.val)
         {
            /* Cannot add entry with different action */
#if (ERRCLASS & ERRCLS_DEBUG)
            SODBGP_SO(SO_DBGMASK_CL, (soCb.init.prntBuf,
               "\nsoClAddContact: -----  Invalid action in contact = %d\n",
               action.val));
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
            if (invAction != NULLP)
               (*invAction) = TRUE;
            RETVALUE(RFAILED);
         }
      }
   }

   /* Check expiry against given expiry */
   if (expiry != NULLP)
   {
      if (expiry->pres != NOTPRSNT)
      {
         /* Limit expire time for this contact to value given */
         if (contactExpiry.val > expiry->val)
            contactExpiry.val = expiry->val;
      }
   }

   /* Must zero structure - used to compare to existing entries */
   cmMemset((U8 *)&strContact, 0, sizeof(TknStrOSXL));

   SO_ADDRSPEC_FROM_ADDRCH(cntAddr, &newContact->contactAddrChoice);
   /* Create text version of contact address */
   ret = soClNormalizeCacheKey(cntAddr, keyBuffer, &strContact.len);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   CHKCACHECB_ALLOCMEM(cacheCb, (Ptr *)&strContact.val, strContact.len, ret);
   if (ret != ROK)
      RETVALUE(RFAILED);

   strContact.pres = PRSNT_NODEF;

   cmMemcpy(strContact.val, keyBuffer, strContact.len);
   curNode = cmLListFirst(&entry->listContacts);

   while (curNode != NULL)
   {
      curItem  = cmLListNode(curNode);
      curNode  = curNode->next;
      curContactEnt = (SoClRegContactEnt *)curItem;
      if (soUtlCmpTknStrOSXL(&strContact, &curContactEnt->contactStr, TRUE)
         == TRUE)
      {
         /* Existing entry, update paramters only */
         /* Check if expires value is specified and zero - delete entry */
         if ((contactExpiry.pres == PRSNT_NODEF) &&
             (contactExpiry.val == 0))
         {
            /* Delete entry - do not delete parent entry from here */
            delContactEntry(cacheCb, curContactEnt, FALSE);
         }
         else
         {
            /* Just update params - change expiry, what else? */
            /* Restart timer with new value */
            soSchedTmr(curContactEnt, SO_TMR_CACHE_REGISTER, TMR_STOP, 
               NOTUSED);
            soClStartContactTmr(cacheCb, curContactEnt, contactExpiry.val);
         }

         /* Free mem not required any more */
         CHKCACHECB_FREEMEM(cacheCb, strContact.val, strContact.len);
         RETVALUE(ROK);
      }
   }
   /* At this point we know no entry exists, add a new one */
   CHKCACHECB_ALLOCMEM(cacheCb, (Ptr *)&newContactEnt,
                       sizeof(SoClRegContactEnt), ret);
   if (ret != ROK)
   {
      CHKCACHECB_FREEMEM(cacheCb, strContact.val, strContact.len);
      RETVALUE(RFAILED);
   }

   /* Initialize fields */
   newContactEnt->mainEntry = entry;
   cmLListAdd2Tail(&entry->listContacts, &newContactEnt->llNode);
   newContactEnt->llNode.node = (PTR)newContactEnt;

   cmMemcpy((U8 *)&newContactEnt->contactStr,
            (U8 *) &strContact,
            sizeof(TknStrOSXL));

   if (cacheCb != NULLP)
   {
      tmpSize = 0;
      ret = soSizeOfSoContactItem(newContact, (U32 *)&tmpSize);
      if (ret == ROK)
      {
         tmpSize = cacheCb->memUsed + (tmpSize - sizeof(SoContactItem));
         ret = cacheCheckMem(cacheCb, &tmpSize, TRUE);
         if (ret == ROK)
         {
            ret = soUtlCpySoContactItem(&newContactEnt->contact,
                                        newContact,
                                        NULLP);
            if (ret == ROK)
            {
               cacheCb->memUsed = tmpSize;
            }
         }

      }
   }
   else
   {
      ret = soUtlCpySoContactItem(&newContactEnt->contact, newContact, NULLP);
   }
   /* On failure of any of the above steps do error handling */
   if (ret != ROK)
   {
      if (cacheCb != NULLP)
      {
         cmLListDelFrm(&entry->listContacts, &newContactEnt->llNode);
         cacheFreeMem(cacheCb, strContact.val, strContact.len);
         cacheFreeMem(cacheCb, newContactEnt, sizeof(SoClRegContactEnt));
      }
      else
      {
         cmLListDelFrm(&entry->listContacts, &newContactEnt->llNode);
         SOFREE(strContact.val, strContact.len);
         SOFREE(newContactEnt, sizeof(SoClRegContactEnt));
      }
      RETVALUE(RFAILED);
   }

   if (contactExpiry.pres == NOTPRSNT)
      newContactEnt->ttl = 0;
   else
      newContactEnt->ttl = contactExpiry.val;

   newContactEnt->localContact = FALSE;
   if (cacheCb != NULLP)
   {
      soCmChkDomain(cntAddr, cacheCb->owner,
         &newContactEnt->localContact, &domainMatch);
   }

   soCmInitTimer(&newContactEnt->expireTmr);

   SODBGP_SO(SO_DBGMASK_CL, (soCb.init.prntBuf,
      "\nsoClAddContact\n-------------- Add contact entry. Contact = <%s>\n",
      newContactEnt->contactStr.val));

   soClStartContactTmr(cacheCb, newContactEnt, newContactEnt->ttl);

   RETVALUE(ROK);
} /* soClAddContact */


/*
*
*       Fun:   soClStartContactTmr
*
*       Desc:  Starts timer for contact entry
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE Void soClStartContactTmr
(
SoCacheCb         *cacheCb,   /* Cache control block          */
SoClRegContactEnt *cntEntry,  /* Contact entry to start timer */
U32               expVal      /* Timer value                  */
)
#else
PRIVATE Void soClStartContactTmr (cacheCb, cntEntry, expVal)
SoCacheCb         *cacheCb;   /* Cache control block          */
SoClRegContactEnt *cntEntry;  /* Contact entry to start timer */
U32               expVal;     /* Timer value                  */
#endif
{

   TRC2(soClStartContactTmr);

   if (cacheCb == NULLP)
      RETVOID;

   if (expVal == 0)
   {
      expVal = cacheCb->dfltExpTm;
   }
   if ((expVal == 0) ||
       (expVal > cacheCb->maxExpTm))
   {
      expVal = cacheCb->maxExpTm;
   }

   cntEntry->ttl = expVal;
   SGetSysTime(&cntEntry->expTimeStarted);

   if (expVal != 0)
   {
      soSchedTmr(cntEntry, SO_TMR_CACHE_REGISTER,
         TMR_START, (expVal * SO_TMRVAL_1_S));
   }

   RETVOID;

} /* soClStartContactTmr */





/*
*
*       Fun:   cacheCheckMem
*
*       Desc:  Checks amount of memory allocated
*
*       Ret:   ROK/RFAILED
*
*       Notes: Generates alarm if alarm threshold is exceeded,
*              returns an error and generates an alarm is the
*              maximum memory is exceed and generates and alarm
*              if memory allocation falls below lower allarm
*              threshold.
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 cacheCheckMem
(
SoCacheCb    *cacheCb,        /* Cache control block */
S32          *newSize,        /* Memory size to allocate */
Bool         allowFree        /* May attempt to free memory */
)
#else
PRIVATE S16 cacheCheckMem (cacheCb, newSize, allowFree)
SoCacheCb    *cacheCb;        /* Cache control block */
S32          *newSize;        /* Memory size to allocate */
Bool         allowFree;       /* May attempt to free memory */
#endif
{
   CmLList      *curNode;      /* Current node when scanning all items */
   PTR          curItem;       /* Current item */
   U32          deltaSize;     /* size by which the new size is greater than
                                  the cacheCb->memUsed size */
   S32          totalMemUsed;  /* The total cache memory used:
                                  cacheCb->memUsed + cacheCb->rdxCp.memUsed */
   SoRegInf     regPar;        /* used for alarm sending */

   TRC2(cacheCheckMem);

   totalMemUsed = cacheCb->rdxCp.memUsed + *newSize;

#if (ERRCLASS & ERRCLS_DEBUG)
   /* The incoming message must be a REGISTER request */
   if (cacheCb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO013, ERRZERO,
                 "cacheCheckMem: NULL cache control block");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   switch (cacheCb->cacheType)
   {
      case SO_CACHE_MCAST_REG:
      case SO_CACHE_DNS_A:
      case SO_CACHE_DNS_SRV:
      case SO_CACHE_DNS_NAPTR:
         if ((totalMemUsed >= cacheCb->maxMemory) &&
             (allowFree == TRUE))
         {
            deltaSize = *newSize - cacheCb->memUsed;

            /* Generate further alarm and return failure value */
            curNode = cmLListFirst(&cacheCb->listCp);

            /* We won't delete the last item in the cache since
               it is proably the item we a re busy adding */
            while ((totalMemUsed >= cacheCb->maxMemory) &&
                   (curNode->next != NULLP))
            {
               curItem = curNode->node;
               curNode = curNode->next;
               if (soClDelEntryPtr(cacheCb, curItem) != ROK)
               {
                  RETVALUE(RFAILED);
               }
               *newSize     = cacheCb->memUsed + deltaSize;
               totalMemUsed = cacheCb->rdxCp.memUsed + *newSize;
            }

            if ((curNode == cmLListFirst(&cacheCb->listCp)) &&
                (curNode->next == NULLP))
            {
#if (ERRCLASS & ERRCLS_INT_PAR)
               SOLOGERROR(ERRCLS_INT_PAR, ESO014, ERRZERO,
                          "cacheCheckMem: No cache entries available to free");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
               RETVALUE(RFAILED);
            }
         }
         break;

      case SO_CACHE_REM_USER_REG:
      case SO_CACHE_LOC_USER_REG:
         if (cacheCb->memAlarmOn != 0)
         {
            if (cacheCb->warningAlarm == FALSE)
            {
               /* No alarm yet, check if alarm should be generated */
               if (totalMemUsed >= cacheCb->memAlarmOn)
               {
                  cacheCb->warningAlarm = TRUE;

                  if (cacheCb->cacheType == SO_CACHE_LOC_USER_REG)
                  {
                     regPar.type  = LSO_LOC_USR_REG;
                  }
                  else
                  {
                     regPar.type  = LSO_REM_USR_REG;
                  }
                  regPar.entId = cacheCb->owner->entId;

                  /* Generate cache alarm - memory threshold reached */
                  soGenStaInd(STSIPENT,
                              LCM_CATEGORY_RESOURCE,
                              LSO_EVENT_REG_WARN_ON,
                              LCM_CAUSE_UNKNOWN,
                              LSO_PAR_REG,
                              &regPar);
               }
            }
            else
            {
               /* Alarm has been generated, should it be cleared? */
               if (totalMemUsed <= cacheCb->memAlarmOff)
               {
                  cacheCb->warningAlarm = FALSE;

                  if (cacheCb->cacheType == SO_CACHE_LOC_USER_REG)
                  {
                     regPar.type  = LSO_LOC_USR_REG;
                  }
                  else
                  {
                     regPar.type  = LSO_REM_USR_REG;
                  }
                  regPar.entId = cacheCb->owner->entId;

                  /* Generate cache alarm - memory threshold reached */
                  soGenStaInd(STSIPENT,
                              LCM_CATEGORY_RESOURCE,
                              LSO_EVENT_REG_WARN_OFF,
                              LCM_CAUSE_UNKNOWN,
                              LSO_PAR_REG,
                              &regPar);
               }
            }
         }

         if ((totalMemUsed >= cacheCb->maxMemory) && (allowFree == TRUE))
         {
            if (cacheCb->cacheType == SO_CACHE_LOC_USER_REG)
            {
               regPar.type  = LSO_LOC_USR_REG;
            }
            else
            {
               regPar.type  = LSO_REM_USR_REG;
            }
            regPar.entId = cacheCb->owner->entId;

            /* Generate cache alarm - registry memory full */
            soGenStaInd(STSIPENT,
                        LCM_CATEGORY_RESOURCE,
                        LSO_EVENT_REG_FULL,
                        LCM_CAUSE_UNKNOWN,
                        LSO_PAR_REG,
                        &regPar);

            RETVALUE(RFAILED);
         }
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO018, (ErrVal) cacheCb->cacheType,
                    "cacheCheckMem: cacheType is invalid");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         RETVALUE(RFAILED);
         break;
   }

   if (*newSize < 0)
   {
      /* Will go to negative value */
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO019, (ErrVal) totalMemUsed,
                 "cacheCheckMem: Invalid memUsed value");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      /* Continue and reset to zero */
      *newSize = 0;
   }

   if (totalMemUsed > cacheCb->peakMem)
   {
      cacheCb->peakMem = totalMemUsed;
   }

   RETVALUE(ROK);
} /* cacheCheckMem */

/*
*
*       Fun:   cacheAllocMem
*
*       Desc:  Allocates memory for data stored in cache
*
*       Ret:   ROK/RFAILED
*
*       Notes: Generates alarm if alarm threshold is exceeded
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 cacheAllocMem
(
SoCacheCb    *cacheCb,        /* Cache control block */
Ptr          *buf,            /* Pointer to memory buffer pointer */
U32          memSize          /* Memory size to allocate */
)
#else
PRIVATE S16 cacheAllocMem (cacheCb, buf, memSize)
SoCacheCb    *cacheCb;        /* Cache control block */
Ptr          *buf;            /* Pointer to memory buffer pointer */
U32          memSize;         /* Memory size to allocate */
#endif
{
   S16         ret;        /* Return value */
   S32         newSize;    /* New memory used after allocation */

   TRC2(cacheAllocMem);

   /* The incoming message must be a REGISTER request */
   if (cacheCb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO020, ERRZERO,
                 "cacheAllocMem: NULL cache control block");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   newSize = cacheCb->memUsed + memSize;
   ret = cacheCheckMem(cacheCb, &newSize, TRUE);
   if (ret == ROK)
   {
      SOALLOC(buf, memSize);
      /* Update the memory size only if memory was succesfully allocated */
      if (*buf != NULLP)
      {
         /* Keep track of new allocation */
         cacheCb->memUsed = newSize;
      }
      else
      {
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ret);
} /* cacheAllocMem */


/*
*
*       Fun:   cacheFreeMem
*
*       Desc:  Frees memory for data stored in cache
*
*       Ret:   ROK
*
*       Notes: Generates alarm if memory level goes below alarm threshold
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 cacheFreeMem
(
SoCacheCb    *cacheCb,        /* Cache control block */
Ptr          buf,             /* Memory buffer pointer */
U32          memSize          /* Memory size to allocate */
)
#else
PRIVATE S16 cacheFreeMem (cacheCb, buf, memSize)
SoCacheCb    *cacheCb;        /* Cache control block */
Ptr          buf;             /* Memory buffer pointer */
U32          memSize;         /* Memory size to allocate */
#endif
{
   S32         newSize;    /* New memory used after allocation */

   TRC2(cacheFreeMem);

   /* The incoming message must be a REGISTER request */
   if (cacheCb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO021, ERRZERO,
                 "cacheFreeMem: NULL cache control block");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   newSize = cacheCb->memUsed - memSize;
   cacheCheckMem(cacheCb, &newSize, FALSE);
   cacheCb->memUsed = newSize;

   SOFREE(buf, memSize);

   RETVALUE(ROK);
} /* cacheFreeMem */


/*
*
*       Fun:   soClContactHdrFromCacheEntry
*
*       Desc:  Fill contact header from cache entry
*
*       Ret:   ROK/RFAILED
*
*       Notes: "Expires" header is also created and set to the earliest 
*              expiration value of all the contacts if "addExpire" is
*              set to TRUE 
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClContactHdrFromCacheEntry
(
SoEvnt          *evnt,            /* Event Cb */
SoClRegEnt      *cacheEntry,      /* Cache entry from which to set contacts */
Bool            addAll,           /* Add all contacts */
Bool            addExpire         /* Add expire header */
)
#else
PUBLIC S16 soClContactHdrFromCacheEntry(evnt, cacheEntry, addAll, addExpire)
SoEvnt          *evnt;            /* Event Cb */
SoClRegEnt      *cacheEntry;      /* Cache entry from which to set contacts */
Bool            addAll;           /* Add all contacts */
Bool            addExpire;        /* Add expire header */
#endif
{
   U32               contactCount; /* Count of contact items     */
   SoContact         *cHdr;        /* Contact header to fill in  */
   U32               expVal;       /* Earliest expires value     */
   TknU32            *expires;     /* Pointer to expire header   */
   S16               ret;          /* Return value               */

   TRC2(soClContactHdrFromCacheEntry);

   /* Allocate array of contact items */
   contactCount = cmLListLen(&cacheEntry->listContacts);
   if (contactCount == 0)
      RETVALUE(RFAILED);

   if (addAll == FALSE)
   {
      /* Only use 1 */
      contactCount = 1;
   }

   if (soCmCreateHdrChoice(evnt, (U8 **)&cHdr,
       SO_HEADER_GEN_CONTACT) != ROK)
   {
      RETVALUE(RFAILED);
   }

   cHdr->pres.pres = PRSNT_NODEF;
   cHdr->contactDescType.pres = PRSNT_NODEF;
   cHdr->contactDescType.val  = SO_CONTACTDESC_CONTACTITEMS;
   expVal = 0;

   if (soClFillContactItems(&cHdr->contactItems, cacheEntry, addAll, &expVal,
      &evnt->memCp) != ROK)
   {
      RETVALUE(RFAILED);
   }

   if ((addExpire == TRUE) && (expVal != 0))
   {
      /* Add/update Expires header */
      /* Find header in message */
      ret = soCmFindHdrChoice(evnt, (U8 **) &expires,
                              SO_HEADER_GEN_EXPIRES);
      if (ret != ROK)
      {
         /* create expires */
         if (soCmCreateHdrChoice(evnt, (U8 **) &expires,
               SO_HEADER_GEN_EXPIRES) != ROK)
         {
            RETVALUE(RFAILED);
         }
      }
      /* Set expires type and value */
      SO_FILL_TKNU32(expires, expVal);
   }

   RETVALUE(ROK);
} /* soClContactHdrFromCacheEntry */




/*
*
*       Fun:   soClFillContactItems
*
*       Desc:  Fill contactItems from cache entry
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClFillContactItems
(
SoContactItems  *cItems,          /* Contact items to fill                  */
SoClRegEnt      *cacheEntry,      /* Cache entry from which to set contacts */
Bool            addAll,           /* Add all contacts                       */
U32             *expVal,          /* Minimum expiry value (in delta-sec)    */
CmMemListCp     *memCp            /* Memory control point for new alloc     */
)
#else
PUBLIC S16 soClFillContactItems(cItems, cacheEntry, addAll, expVal, memCp)
SoContactItems  *cItems;          /* Contact items to fill                  */
SoClRegEnt      *cacheEntry;      /* Cache entry from which to set contacts */
Bool            addAll;           /* Add all contacts                       */
U32             *expVal;          /* Minimum expiry value (in delta-sec)    */
CmMemListCp     *memCp;           /* Memory control point for new alloc     */
#endif
{
   U32               i;            /* Counter                     */
   U32               j;            /* Contact parameter counter   */
   U32               contactCount; /* Count of contact items      */
   CmLList           *curNode;     /* Current node in list        */
   PTR               curItem;      /* Current item                */
   SoClRegContactEnt *cRegItem;    /* Single contact from cache   */
   U32               contExp;      /* Single contact expiry value */
   U32               nowTime;      /* Current timestamp           */
   SoContactItem     *cItem;       /* Single contact item         */
   TknU32            *expParam;    /* Expiry parameter            */
   SoContactParam    *cPar;        /* Contact item parameter      */

   TRC2(soClFillContactItems);

   contactCount = cmLListLen(&cacheEntry->listContacts);
   if (contactCount == 0)
      RETVALUE(RFAILED);

   if (expVal != NULLP)
      (*expVal) = 0;

   cItems->numComp.pres = PRSNT_NODEF;
   cItems->numComp.val  = contactCount;

   /* Allocate memory for array of contact items */
   if (memCp == NULLP)
   {
      SOALLOC(&cItems->contactItem, sizeof(SoContactItem *) * contactCount);
      if (cItems->contactItem == NULLP)
      {
         RETVALUE(RFAILED);
      }
   }
   else
   {
      if (cmGetMem(memCp, sizeof(SoContactItem *) * contactCount,
         (Ptr *)&cItems->contactItem) != ROK)
      {
         RETVALUE(RFAILED);
      }
   }
   /* Now we can scan through list of items, copying one by one */
   curNode = cmLListFirst(&cacheEntry->listContacts);
   i = 0;
   while ((curNode != (CmLList *) NULLP) && (i < contactCount))
   {
      curItem  = cmLListNode(curNode);
      curNode  = curNode->next;
      cRegItem = (SoClRegContactEnt *)curItem;
      if (memCp == NULLP)
      {
         SOALLOC(&cItems->contactItem[i], sizeof(SoContactItem));
         if (cItems->contactItem[i] == NULLP)
         {
            RETVALUE(RFAILED);
         }
      }
      else
      {
         if (cmGetMem(memCp, sizeof(SoContactItem),
            (Ptr *)&cItems->contactItem[i]) != ROK)
         {
            RETVALUE(RFAILED);
         }
      }
      if (soUtlCpySoContactItem(cItems->contactItem[i],
         &cRegItem->contact, memCp) != ROK)
      {
         RETVALUE(RFAILED);
      }
      if (expVal != NULLP)
      {
         /* Update expiry value */
         SGetSysTime(&nowTime);

         if (nowTime > cRegItem->expTimeStarted)
            contExp = nowTime - cRegItem->expTimeStarted;
         else
            contExp = cRegItem->expTimeStarted - nowTime;
         /* Convert to seconds */
         contExp = contExp  / 10;
         /* retryTm = elapsed, subtract from original retryTime */
         if (contExp > cRegItem->ttl)
         {
            /* oops, must never happen, use default of 0 */
            contExp = 0;
         }
         else
         {
            contExp = cRegItem->ttl - contExp;
         }
         if (contExp != 0)
         {
            if ((contExp < (*expVal)) || ((*expVal) == 0))
            {            
               (*expVal) = contExp;
            }
            /* Find expires parameter in newly copied contact item and update */
            cItem = cItems->contactItem[i];
            for (j = 0;
                 j < SO_GET_NUM_COMP(&cItem->contactParams.numComp);
                 j++)
            {
               cPar = cItem->contactParams.contactParam[j];
               if (cPar != NULLP)
               {
                  if ((SO_CMP_TKN_LIT(&cPar->contactParamType,
                                     SO_CONTACTPARAM_STD) == TRUE) 
                                     &&
                      (cPar->t.contactParamStd.contactParamStdType.val == 
                        SO_CONTACTPARAMSTD_EXPIRES))
                  {
                     /* Set to delta seconds and update */
                     expParam = &cPar->t.contactParamStd.t.contactParExpires;
                     /* Set expires type and value */
                     SO_FILL_TKNU32(expParam, contExp);
                     break;
                  }
               }
            }
         }
      }
      i++;
   }

   RETVALUE(ROK);
} /* soClFillContactItems */





/****************************************************************************
                  Routines for managing cache
****************************************************************************/

/*
*
*       Fun:   soClCacheInit
*
*       Desc:  This function is used to initialize a cache control block
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClCacheInit
(
SoCacheCb *cb,       /* Cache control block */
Pool      pool,      /* Memory pool to use for cache */
Region    region,    /* Memory region to use for cache */
U8        cType,     /* Type of cache */
U16       entriesPerNode,   /* Number of entries per tree node */
Size      maxMem,    /* Maximum memory to allocate for cache */
Size      alarmMem,  /* Memory level at which alarm is issued */
Size      alarmOffMem, /* Difference between alarm on & off levels */
U32       dfltExpTm, /* Default expiry time */
U32       maxExpTm,  /* Maximum expiry time */
SoEntCb   *owner     /* Pointer to entity */
)
#else
PUBLIC S16 soClCacheInit (cb, pool, region, cType, entriesPerNode, maxMem,
                     alarmMem, alarmOffMem, dfltExpTm, maxExpTm, owner)
SoCacheCb *cb;       /* Cache control block */
Pool      pool;      /* Memory pool to use for cache */
Region    region;    /* Memory region to use for cache */
U8        cType;     /* Type of cache */
U16       entriesPerNode;   /* Number of entries per tree node */
Size      maxMem;    /* Maximum memory to allocate for cache */
Size      alarmMem;  /* Memory level at which alarm is issued */
Size      alarmOffMem; /* Difference between alarm on & off levels */
U32       dfltExpTm; /* Default expiry time */
U32       maxExpTm;  /* Maximum expiry time */
SoEntCb   *owner;    /* Pointer to entity */
#endif
{
   S16   ret;     /* Return value */
   U16   offset;  /* Hash list entry offset */
#ifdef SO_DNS 
   Bool  alwDup;  /* Allow duplicate entries */
#endif /* SO_DNS */

   TRC2(soClCacheInit);

   /* Check parameters */
   if (cb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO022, ERRZERO,
                 "soClCacheInit: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }
   /* Check parameters */
   if (cb->cacheOK != FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO023, ERRZERO,
                 "soClCacheInit: Cache already initialized");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   cb->cacheOK      = TRUE;
   cb->cacheType    = cType;
   cb->nmbEntries   = 0;
   cb->peakEntries  = 0;
   cb->memUsed      = 0;
   cb->peakMem      = 0;
   cb->owner        = owner;
   cb->warningAlarm = FALSE;

   soClCacheMemSzCheck((Size *)&cb->maxMemory, maxMem);

   /* Use soClCacheReConfig to confgiure the reconfigurable
      parameters for the first time */
   soClCacheReConfig(cb, alarmMem, alarmOffMem, dfltExpTm, maxExpTm);

   switch (cb->cacheType)
   {
#ifdef SO_DNS 
      case SO_CACHE_DNS_A:
         offset = (U16)SO_OFFSET_OF(SoClDnsSrvEnt,rdxEnt);
         alwDup = FALSE;
         break;
      case SO_CACHE_DNS_SRV:
         offset = (U16)SO_OFFSET_OF(SoClDnsAEnt,rdxEnt);
         alwDup = FALSE;
         break;
      case SO_CACHE_DNS_NAPTR:
         offset = (U16)SO_OFFSET_OF(SoClDnsNaptrEnt, rdxEnt);
         alwDup = FALSE;
         break;
#endif /* SO_DNS */
      case SO_CACHE_REM_USER_REG:
         if (owner == NULLP)
         {
            /* Check parameters */
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO024, ERRZERO,
               "soClCacheInit: NULL owner entity");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
            RETVALUE(RFAILED);
         }
         offset = (U16)SO_OFFSET_OF(SoClRegEnt,rdxEnt);
         break;
      case SO_CACHE_LOC_USER_REG:
         if (owner == NULLP)
         {
            /* Check parameters */
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO025, ERRZERO,
               "soClCacheInit: NULL owner entity");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
            RETVALUE(RFAILED);
         }
         offset = (U16)SO_OFFSET_OF(SoClRegEnt,rdxEnt);
         break;

      case SO_CACHE_MCAST_REG:
         offset = (U16)SO_OFFSET_OF(SoClRegEnt,rdxEnt);
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO026, (ErrVal) cb->cacheType,
                    "soClCacheInit: cacheType is invalid");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

         cb->cacheOK = FALSE;
         RETVALUE(RFAILED);
         break;
   }

   ret = cmRdxTreeInit(&cb->rdxCp, region, pool, entriesPerNode, 
                       (U16)offset, FALSE);
   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO027, ERRZERO,
                 "soClCacheInit: Radix tree init failed");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      cb->cacheOK = FALSE;
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of soClCacheInit */





/*
*
*       Fun:   soClCacheReConfig
*
*       Desc:  This function is used to re-configure a cache control block
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClCacheReConfig
(
SoCacheCb *cb,         /* Cache control block */
Size      alarmOnMem,  /* Memory level at which alarm is issued */
Size      alarmOffMem, /* Difference between alarm on & off levels */
U32       dfltExpTm,   /* Default expiry time */
U32       maxExpTm     /* Maximum expiry time */
)
#else
PUBLIC S16 soClCacheReConfig (cb, alarmOnMem, alarmOffMem,
                              dfltExpTm, maxExpTm)
SoCacheCb *cb;         /* Cache control block */
Size      alarmOnMem;  /* Memory level at which alarm is issued */
Size      alarmOffMem; /* Difference between alarm on & off levels */
U32       dfltExpTm;   /* Default expiry time */
U32       maxExpTm;    /* Maximum expiry time */
#endif
{

   TRC2(soClCacheReConfig);

   /* Check parameters */
   if (cb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO028, ERRZERO,
                 "soClCacheReConfig: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   /* Check cache is initialized */
   if (cb->cacheOK != TRUE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO029, ERRZERO,
                 "soClCacheReConfig: Cache not initialized");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   cb->dfltExpTm = dfltExpTm;
   cb->maxExpTm  = maxExpTm;

   switch (cb->cacheType)
   {
#ifdef SO_DNS 
      case SO_CACHE_DNS_A:
      case SO_CACHE_DNS_SRV:
      case SO_CACHE_DNS_NAPTR:
#endif /* SO_DNS */
      case SO_CACHE_MCAST_REG:
         cb->memAlarmOn  = NULLD;
         cb->memAlarmOff = NULLD;
         break;

      case SO_CACHE_LOC_USER_REG:
         cb->dfltExpTm   = NULLD;
         cb->maxExpTm    = NULLD;
      case SO_CACHE_REM_USER_REG:
         /* Check upper alarm threshold range */
         if (alarmOnMem < 0)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            SOLOGERROR(ERRCLS_INT_PAR, ESO030, (ErrVal) alarmOnMem,
                       "soClCacheReConfig: uppper cache memory threshold "
                       "is negative");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
            cb->memAlarmOn = NULLD;
         }
         else
            cb->memAlarmOn = alarmOnMem;

         /* If there is a configuration problem then turn off these alarms */
         if (alarmOnMem < alarmOffMem)
         {
#if (ERRCLASS & ERRCLS_INT_PAR)
            SOLOGERROR(ERRCLS_INT_PAR, ESO031, (ErrVal) alarmOffMem,
                       "soClCacheReConfig: lower alarm theshold is greater "
                       "then the upper threshold");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
            cb->memAlarmOn  = NULLD;
            cb->memAlarmOff = NULLD;
         }
         else
         {
            /* Check lower alram threshold range */
            if (alarmOffMem < 0)
            {
#if (ERRCLASS & ERRCLS_INT_PAR)
               SOLOGERROR(ERRCLS_INT_PAR, ESO032, (ErrVal) alarmOffMem,
                          "soClCacheReConfig: lower cache memory threshold "
                          "is negative");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
               cb->memAlarmOff = NULLD;
            }
            else
               cb->memAlarmOff = alarmOffMem;
         }
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO033, (ErrVal) cb->cacheType,
                    "soClCacheReConfig: cacheType is invalid");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         RETVALUE(RFAILED);
         break;
   }

   RETVALUE(ROK);
} /* soClCacheReConfig */





/*
*
*       Fun:   soClCacheMemSzCheck
*
*       Desc:  This function is used to do range checking on the cache memory
*              size being set
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClCacheMemSzCheck
(
Size      *memSize,   /* Pointer to memory size value to set */
Size      maxMem      /* Maximum memory to allocate for cache */
)
#else
PUBLIC S16 soClCacheMemSzCheck (memSize, maxMem)
Size      *memSize;    /* Pointer to memory size value to set */
Size      maxMem;      /* Maximum memory to allocate for cache */
#endif
{
   TRC2(soClCacheMemSzCheck);

   /* Check maxMem range */
   if (maxMem <= 0)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO034, (ErrVal) maxMem,
                 "soClCacheMemSzCheck: maximum cache memory size is invalid");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      *memSize = LSO_CACHE_DFLT_MEM_SIZE;
   }
   else
   {
      if (maxMem < LSO_CACHE_MIN_MEM_SIZE)
      {
#if (ERRCLASS & ERRCLS_INT_PAR)
      SOLOGERROR(ERRCLS_INT_PAR, ESO035, (ErrVal) maxMem,
                 "soClCacheMemSzCheck: maximum cache memory size is too small");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         *memSize = LSO_CACHE_MIN_MEM_SIZE;
      }
      else
         *memSize = maxMem;
   }

   RETVALUE(ROK);
} /* soClCacheMemSzCheck */



/*
*
*       Fun:   soClDelEntryPtr
*
*       Desc:  Deletes cache entry
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClDelEntryPtr
(
SoCacheCb     *cb,         /* Cache control block */
PTR           cacheEntry   /* Entry to delete */
)
#else
PUBLIC S16 soClDelEntryPtr (cb, cacheEntry)
SoCacheCb     *cb;         /* Cache control block */
PTR           cacheEntry;  /* Entry to delete */
#endif
{
   TRC2(soClDelEntryPtr);

   /* Input checks: Message must be request, with register method */
   if ((cb == NULLP) || (cacheEntry == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO036, ERRZERO,
                 "soClDelEntryPtr: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   /* Now free cache block itself */
   switch (cb->cacheType)
   {
#ifdef SO_DNS 
      case SO_CACHE_DNS_A:
         /* Free memory */
         soFreeCacheDnsACb(cb, (SoClDnsAEnt *)cacheEntry);
         break;
      case SO_CACHE_DNS_SRV:
         soFreeCacheDnsSrvCb(cb, (SoClDnsSrvEnt *)cacheEntry);
         break;
      case SO_CACHE_DNS_NAPTR:
         soFreeCacheDnsNaptrCb(cb, (SoClDnsNaptrEnt *)cacheEntry);
         break;
#endif /* SO_DNS */
      case SO_CACHE_REM_USER_REG:
      case SO_CACHE_LOC_USER_REG:
      case SO_CACHE_MCAST_REG:
         soClFreeCacheRegCb(cb, (SoClRegEnt *)cacheEntry);
         break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO037, cb->cacheType,
                    "soClDelEntryPtr: Invalid Cache Type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         break;
   }

   RETVALUE(ROK);
} /* soClDelEntryPtr */

/*
*
*       Fun:   soClRegTimer
*
*       Desc:  Registry entry timer function
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC Void soClRegTimer
(
SoClRegContactEnt     *regContEnt       /* Entry which expired */
)
#else
PUBLIC Void soClRegTimer (regContEnt)
SoClRegContactEnt     *regContEnt;      /* Entry which expired */
#endif
{

   TRC2(soClRegTimer);

   delContactEntry(regContEnt->mainEntry->cacheCb, regContEnt, TRUE);

   RETVOID;

} /* soClRegTimer */


/*
*
*       Fun:   soClRegRetryTimer
*
*       Desc:  Registry entry timer function
*
*       Ret:   ROK/RFAILED
*
*       Notes: Used for "Retry-After"
*              If tempUnavail == TRUE, entry is now available
*                 we must restart timer if duration <> 0
*              If tempUnavail == FALSE, it means it is end of "duration",
*                 we must delete complete entry
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC Void soClRegRetryTimer
(
SoClRegEnt     *entry       /* Entry which expired */
)
#else
PUBLIC Void soClRegRetryTimer (entry)
SoClRegEnt     *entry;      /* Entry which expired */
#endif
{

   TRC2(soClRegRetryTimer);

   if (entry->tempUnavail == TRUE)
   {
      entry->tempUnavail = FALSE;
      /* Restart timer if "duration" was set */
      if (entry->duration != 0)
      {
         /* Restart timer */
         soSchedTmr((Ptr)entry, SO_TMR_CACHE_REGISTER_RETRY,
            TMR_START, (entry->duration * SO_TMRVAL_1_S));
      }
   }
   else
   {
      /* "duration" expired, remove entry completely */
      soClFreeCacheRegCb(entry->cacheCb, entry);
   }

   RETVOID;
} /* soClRegRetryTimer */

#ifdef SO_DNS 
#ifdef SO_ENUM

/*
*
*       Fun:   soClDnsNaptrTimer
*
*       Desc:  DNS Naptr entry in cache expired
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC Void soClDnsNaptrTimer
(
SoDnsNaptrAnswerRec     *entry       /* Entry which expired */
)
#else
PUBLIC Void soClDnsNaptrTimer (entry)
SoDnsNaptrAnswerRec     *entry;      /* Entry which expired */
#endif
{
   TRC2(soClDnsNaptrTimer);

   if (entry->mainEntry->cacheCb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO038, ERRZERO,
                 "soClDnsNaptrTimer: NULL cache control block");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVOID;
   }

   freeDnsNaptrAnswerRec(entry->mainEntry->cacheCb,
                       (SoDnsNaptrAnswerRec *)entry);

   RETVOID;

} /* soClDnsNaptrTimer */

#endif

/*
*
*       Fun:   soClDnsSrvTimer
*
*       Desc:  DNS Srv entry in cache expired
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC Void soClDnsSrvTimer
(
SoDnsSrvAnswerRec     *entry       /* Entry which expired */
)
#else
PUBLIC Void soClDnsSrvTimer (entry)
SoDnsSrvAnswerRec     *entry;      /* Entry which expired */
#endif
{
   TRC2(soClDnsSrvTimer);

   /* so008.102: add one more param */
   freeDnsSrvAnswerRec(entry->mainEntry->cacheCb,
                       (SoDnsSrvAnswerRec *)entry,
                       TRUE);

   RETVOID;

} /* soClDnsSrvTimer */

/*
*
*       Fun:   soClDnsATimer
*
*       Desc:  Cache entry for DNS A record expired
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC Void soClDnsATimer
(
SoClDnsAAnswerRec     *entry       /* Entry which expired */
)
#else
PUBLIC Void soClDnsATimer (entry)
SoClDnsAAnswerRec     *entry;      /* Entry which expired */
#endif
{
   TRC2(soClDnsATimer);

   /* so008.102: Changed the last param to TRUE */
   freeDnsAAnswerRec(entry->mainEntry->cacheCb,
                     (SoClDnsAAnswerRec *)entry,
                     TRUE);

   RETVOID;

} /* soClDnsATimer */

/*
*
*       Fun:   freeDnsAAnswerRec
*
*       Desc:  Frees memory for DNS A Answer record
*
*       Ret:   ROK
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 freeDnsAAnswerRec
(
SoCacheCb          *cacheCb,  /* Cache control block */
SoClDnsAAnswerRec  *delEntry, /* Entry to delete */
Bool               checkMain  /* Check main entry to see if it is last one */
)
#else
PRIVATE S16 freeDnsAAnswerRec (cacheCb, delEntry, checkMain)
SoCacheCb          *cacheCb;  /* Cache control block */
SoClDnsAAnswerRec  *delEntry; /* Entry to delete */
Bool               checkMain; /* Check main entry to see if it is last one */
#endif
{
   SoClDnsAEnt  *parentEntry;

   TRC2(freeDnsAAnswerRec);

   parentEntry = delEntry->mainEntry;

   /* Stop expiry timer if it is running */
   soSchedTmr(delEntry, SO_TMR_CACHE_DNS_A, TMR_STOP, NOTUSED);

   /* so008.102 */
   /* Remove from main linked list */
   if (parentEntry != NULLP)
      cmLListDelFrm(&parentEntry->listCp, &delEntry->llNode);
   cacheFreeMem(cacheCb, delEntry, sizeof(SoClDnsAAnswerRec));

   if ((checkMain == TRUE) && (parentEntry != NULLP))
   {
      /* Check if there are any entries left in parent list */
      if (cmLListLen(&parentEntry->listCp) == 0)
      {
         /* It is now empty, delete main entry as well */
         soFreeCacheDnsACb(cacheCb, parentEntry);
      }
   }

   RETVALUE(ROK);

} /* freeDnsAAnswerRec */



/*
*
*       Fun:   freeDnsSrvAnswerRec
*
*       Desc:  Frees memory for DNS Srv Answer record
*
*       Ret:   ROK
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 freeDnsSrvAnswerRec
(
SoCacheCb          *cacheCb,  /* Cache control block */
SoDnsSrvAnswerRec  *delEntry,  /* Entry to delete */
Bool               checkMain  /* so008.102: Check main entry */
)
#else
PRIVATE S16 freeDnsSrvAnswerRec (cacheCb, delEntry, checkMain)
SoCacheCb          *cacheCb;  /* Cache control block */
SoDnsSrvAnswerRec  *delEntry; /* Entry to delete */
Bool               checkMain; /* so008.102: Check main entry */
#endif
{
   /* so008.102: add new variable */
   SoClDnsSrvEnt *parentEntry;

   TRC2(freeDnsSrvAnswerRec);

   parentEntry = delEntry->mainEntry;

   /* Stop expiry timer if it is running */
   soSchedTmr(delEntry, SO_TMR_CACHE_DNS_SRV, TMR_STOP, NOTUSED);

   cacheDelTknStrOSXL(&delEntry->srvResult, cacheCb);

   /* so008.102 : Added Deletion of entry fom link list */
   if (parentEntry != NULLP)
      cmLListDelFrm (&delEntry->mainEntry->listCp, &delEntry->llNode);
   cacheFreeMem(cacheCb, delEntry, sizeof(SoDnsSrvAnswerRec));

   if ((checkMain == TRUE) && (parentEntry != NULLP))
   {
      if(parentEntry->listCp.count == 0)
      {
         soFreeCacheDnsSrvCb(cacheCb, parentEntry);
      }
   }

   RETVALUE(ROK);

} /* freeDnsSrvAnswerRec */

/*
*
*       Fun:   freeDnsNaptrAnswerRec
*
*       Desc:  Frees memory for DNS Naptr Answer record
*
*       Ret:   ROK
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 freeDnsNaptrAnswerRec
(
SoCacheCb          *cacheCb,  /* Cache control block */
SoDnsNaptrAnswerRec  *delEntry  /* Entry to delete */
)
#else
PRIVATE S16 freeDnsNaptrAnswerRec (cacheCb, delEntry)
SoCacheCb          *cacheCb;  /* Cache control block */
SoDnsNaptrAnswerRec  *delEntry; /* Entry to delete */
#endif
{
   CmLList             *curNode;     /* Current node in list    */
   PTR                 curItem;      /* Current item            */
   SoDnsNaptrAnswerRec *answerRec;   /* Temporary pointer */

   TRC2(freeDnsNaptrAnswerRec);

   /* Stop expiry timer if it is running */
   soSchedTmr(delEntry, SO_TMR_CACHE_DNS_NAPTR, TMR_STOP, NOTUSED);

   curNode = cmLListFirst(&delEntry->mainEntry->listCp);
   while (curNode != NULLP)
   {
      curItem = cmLListNode(curNode);
      answerRec = (SoDnsNaptrAnswerRec*)curItem;
      if ((answerRec->normNaptrResult.len == 
            delEntry->normNaptrResult.len) &&
           (answerRec->normNaptrResult.len != 0))
      {
         if (cmStrncmp(answerRec->normNaptrResult.val,
               delEntry->normNaptrResult.val,
               answerRec->normNaptrResult.len) == 0)
         {
            cmLListDelFrm (&delEntry->mainEntry->listCp, curNode);
            break;
         }
      }
      curNode = curNode->next;
   }

   if (delEntry != NULLP)
   {
      if(delEntry->normNaptrResult.pres == PRSNT_NODEF)
         cacheDelTknStrOSXL(&delEntry->normNaptrResult, cacheCb);
      if(delEntry->naptrResult.pres.pres == PRSNT_NODEF)
         cacheDelSoAddress(&delEntry->naptrResult, cacheCb);
   }

   cacheFreeMem(cacheCb, delEntry, sizeof(SoDnsNaptrAnswerRec));

   RETVALUE(ROK);

} /* freeDnsNaptrAnswerRec */


/*
*
*       Fun:   soFreeCacheDnsACb
*
*       Desc:  Frees memory for DNS A cache entry
*
*       Ret:   ROK
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 soFreeCacheDnsACb
(
SoCacheCb    *cacheCb,        /* Cache control block */
SoClDnsAEnt  *entry           /* Cache entry to free */
)
#else
PRIVATE S16 soFreeCacheDnsACb (cacheCb, entry)
SoCacheCb    *cacheCb;        /* Cache control block */
SoClDnsAEnt  *entry;          /* Cache entry to free */
#endif
{
   CmLList      *curNode;   /* Current node when scanning all items */
   PTR          curItem;    /* Current item */

   TRC2(soFreeCacheDnsACb);

   /* The incoming message must be a REGISTER request */
   if (cacheCb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO039, ERRZERO,
                 "soFreeCacheDnsACb: NULL cache control block");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   /* Scan list of detail entries linked to main entry - delete all */

   /* Free individual entries - scan list */
   curNode = cmLListFirst(&entry->listCp);
   while (curNode != NULLP)
   {
      curItem  = curNode->node;
      curNode  = curNode->next;
      freeDnsAAnswerRec(cacheCb, (SoClDnsAAnswerRec *)curItem, FALSE);
   }

   /* Remove from tree */
   (Void) cmRdxTreeDeletePtr(&cacheCb->rdxCp, (PTR)entry);

   cacheCb->nmbEntries--;

   /* Remove from linked list */
   cmLListDelFrm(&cacheCb->listCp, &entry->llNode);

   /* Free key memory */
   cacheDelTknStrOSXL(&entry->hostName, cacheCb);

   /* Free memory for entry itself */
   cacheFreeMem(cacheCb, entry, sizeof(SoClDnsAEnt));

   RETVALUE(ROK);
} /* soFreeCacheDnsACb */


/*
*
*       Fun:   soFreeCacheDnsSrvCb
*
*       Desc:  Frees memory for DNS SRV cache entry
*
*       Ret:   ROK
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 soFreeCacheDnsSrvCb
(
SoCacheCb      *cacheCb,        /* Cache control block */
SoClDnsSrvEnt  *entry           /* Cache entry to free */
)
#else
PRIVATE S16 soFreeCacheDnsSrvCb (cacheCb, entry)
SoCacheCb      *cacheCb;        /* Cache control block */
SoClDnsSrvEnt  *entry;          /* Cache entry to free */
#endif
{
   CmLList      *curNode;   /* Current node when scanning all items */
   PTR          curItem;    /* Current item */

   TRC2(soFreeCacheDnsSrvCb);

   /* The incoming message must be a REGISTER request */
   if (cacheCb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO040, ERRZERO,
                 "soFreeCacheDnsSrvCb: NULL cache control block");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   /* Remove from tree */
   (Void) cmRdxTreeDeletePtr(&cacheCb->rdxCp, (PTR)entry);

   cacheCb->nmbEntries--;

   /* Remove from linked list */
   cmLListDelFrm(&cacheCb->listCp, &entry->llNode);

   /* Free key memory */
   cacheDelTknStrOSXL(&entry->hostName, cacheCb);

   /* Free list of srv results */
   curNode = cmLListFirst(&entry->listCp);
   while (curNode != NULL)
   {
      curItem  = curNode->node;
      curNode  = curNode->next;
      /* so008.102: add one more param */
      freeDnsSrvAnswerRec(cacheCb, (SoDnsSrvAnswerRec *)curItem, FALSE);
   }

   /* Free memory for entry itself */
   cacheFreeMem(cacheCb, entry, sizeof(SoClDnsSrvEnt));

   RETVALUE(ROK);
} /* soFreeCacheDnsSrvCb */

/*
*
*       Fun:   soFreeCacheDnsNaptrCb
*
*       Desc:  Frees memory for DNS NAPTR cache entry
*
*       Ret:   ROK
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 soFreeCacheDnsNaptrCb
(
SoCacheCb      *cacheCb,        /* Cache control block */
SoClDnsNaptrEnt  *entry           /* Cache entry to free */
)
#else
PRIVATE S16 soFreeCacheDnsNaptrCb (cacheCb, entry)
SoCacheCb      *cacheCb;        /* Cache control block */
SoClDnsNaptrEnt  *entry;          /* Cache entry to free */
#endif
{
   CmLList      *curNode;   /* Current node when scanning all items */
   PTR          curItem;    /* Current item */

   TRC2(soFreeCacheDnsNaptrCb);

   if (cacheCb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO041, ERRZERO,
                 "soFreeCacheDnsNaptrCb: NULL cache control block");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   /* Remove from tree */
   (Void) cmRdxTreeDeletePtr(&cacheCb->rdxCp, (PTR)entry);

   cacheCb->nmbEntries--;

   /* Remove from linked list */
   cmLListDelFrm(&cacheCb->listCp, &entry->llNode);

   /* Free key memory */ 
   cacheDelTknStrOSXL(&entry->hostName, cacheCb);

   /* Free list of srv results */
   curNode = cmLListFirst(&entry->listCp);
   while (curNode != NULLP)
   {
      curItem  = curNode->node;
      curNode  = curNode->next;
      freeDnsNaptrAnswerRec(cacheCb, (SoDnsNaptrAnswerRec *)curItem);
   }

   /* Free memory for entry itself */
   cacheFreeMem(cacheCb, entry, sizeof(SoClDnsNaptrEnt));

   RETVALUE(ROK);
} /* soFreeCacheDnsNaptrCb */
#endif /* SO_DNS */





/*
*
*       Fun:   soClCacheDeinit
*
*       Desc:  This function is used to deinitialize a cache control block
*
*       Ret:   ROK/RFAILED
*
*       Notes: Iterates through all items in cache, freeing memory allocated
*              and then frees tree control point
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClCacheDeinit
(
SoCacheCb *cb        /* Cache control block */
)
#else
PUBLIC S16 soClCacheDeinit (cb)
SoCacheCb *cb;       /* Cache control block */
#endif
{
   S16          ret;        /* Return value */
   CmLList      *curNode;   /* Current node when scanning all items */
   PTR          curItem;    /* Current item */

   TRC2(soClCacheDeinit);

   /* Check parameters */
   if (cb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO042, ERRZERO,
                 "soClCacheDeinit: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   if (cb->cacheOK == FALSE)
   {
      /* Already deinitialized */
      RETVALUE(ROK);
   }

   /* Iterate through all items in cache, free them, then
    * deinitialize the radix tree
    */

   curNode = cmLListFirst(&cb->listCp);
   while (curNode != NULL)
   {
      curItem = curNode->node;
      curNode  = curNode->next;
      soClDelEntryPtr(cb, curItem);
   }

   cb->nmbEntries   = 0;
   cb->peakEntries  = 0;
   cb->memUsed      = 0;
   cb->peakMem      = 0;

   ret = cmRdxTreeDeinit(&cb->rdxCp);
   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO043, ERRZERO,
                 "soClCacheDeinit: Radix tree deinit failed");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   cb->cacheOK = FALSE;

   RETVALUE(ROK);
} /* end of soClCacheDeinit */






/*
*
*       Fun:   soClCacheClear
*
*       Desc:  This function clears all cache entries
*
*       Ret:   ROK/RFAILED
*
*       Notes: Iterates through all items in cache, freeing memory allocated
*
*       File:  so_cl
*
*/

#ifdef ANSI
PUBLIC S16 soClCacheClear
(
SoCacheCb *cb        /* Cache control block */
)
#else
PUBLIC S16 soClCacheClear (cb)
SoCacheCb *cb;       /* Cache control block */
#endif
{
   CmLList      *curNode;   /* Current node when scanning all items */
   PTR          curItem;    /* Current item */

   TRC2(soClCacheClear);

   /* The incoming message must be a REGISTER request */
   if (cb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO044, ERRZERO,
                 "soClCacheClear: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   /* Iterate through all items in cache, remove from cache */

   curNode = cmLListFirst(&cb->listCp);
   while (curNode != NULL)
   {
      curItem  = curNode->node;
      curNode  = curNode->next;
      /* Remove curItem */
      soClDelEntryPtr(cb, curItem);
   }

   RETVALUE(ROK);
} /* end of soClCacheClear */


#ifdef SO_DNS 
/*
*
*       Fun:   soClAddDnsARecord
*
*       Desc:  Add data record to existing DnsA cache entry
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/
#ifdef ANSI
PUBLIC S16 soClAddDnsARecord
(
SoClDnsAEnt  *cacheEntry, /* Existing cache entry */
CmNetAddr    *tptAddr,    /* Transport network address  */
U32          ttl          /* Expiry time for entry */
)
#else
PUBLIC S16 soClAddDnsARecord (cacheEntry, tptAddr, ttl)
SoClDnsAEnt  *cacheEntry; /* Existing cache entry */
CmNetAddr    *tptAddr;    /* Transport network address  */
U32          ttl;         /* Expiry time for entry */
#endif
{
   SoClDnsAAnswerRec  *newEntry; /* New entry to add */

   TRC2(soClAddDnsARecord);

   /* Input checks: Message must be request, with register method */
   if ((cacheEntry == NULLP) || (tptAddr == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO045, ERRZERO,
                 "soClAddDnsARecord: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   /* Limit ttl to valid range */
   if (ttl < SO_DNS_A_TTL_MIN)
   {
      ttl = SO_DNS_A_TTL_MIN;
   }
   if (ttl > SO_DNS_A_TTL_MAX)
   {
      ttl = SO_DNS_A_TTL_MAX;
   }


   if (cacheAllocMem(cacheEntry->cacheCb, (Ptr *)&newEntry,
                     sizeof(SoClDnsAAnswerRec))
       != ROK)
      RETVALUE(RFAILED);

   /* Initialize fields of new entry */
   newEntry->llNode.node = (PTR)newEntry;
   cmMemcpy((U8 *)&newEntry->ipAddress, (U8 *)tptAddr, sizeof(CmNetAddr));
   soCmInitTimer(&newEntry->expireTmr);
   newEntry->mainEntry = cacheEntry;
   newEntry->ttl       = ttl;

   /* Insert at end of list in main entry */
   cmLListAdd2Tail(&cacheEntry->listCp, &newEntry->llNode);
   newEntry->llNode.node = (PTR)newEntry;

   /* Start timer */

   soSchedTmr(newEntry, SO_TMR_CACHE_DNS_A, TMR_START, 
         (newEntry->ttl * SO_TMRVAL_1_S));

   RETVALUE(ROK);
} /* soClAddDnsARecord */


/*
*
*       Fun:   soClAddDnsAEntry
*
*       Desc:  Adds new dns A cache entry to cache
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/
#ifdef ANSI
PUBLIC S16 soClAddDnsAEntry
(
SoCacheCb    *cacheCb,   /* Cache control block */
TknStrOSXL   *hostName,  /* Host name provided */
SoClDnsAEnt  **newEntry  /* Pointer to new entry */
)
#else
PUBLIC S16 soClAddDnsAEntry (cacheCb, hostName, newEntry)
SoCacheCb    *cacheCb;   /* Cache control block */
TknStrOSXL   *hostName;  /* Host name provided */
SoClDnsAEnt  **newEntry; /* Pointer to new entry */
#endif
{
   S16                ret;       /* Return value */
   S32                tmpSize;

   TRC2(soClAddDnsAEntry);

   /* Input checks: Message must be request, with register method */
   if ((cacheCb == NULLP) || (hostName == NULLP) || (newEntry == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO046, ERRZERO,
                 "soClAddDnsAEntry: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   /* This must be a DNS a record cache */
   if (cacheCb->cacheType != SO_CACHE_DNS_A)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO047, (ErrVal) cacheCb->cacheType,
                 "soClAddDnsAEntry: Invalid cache type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   ret = cacheAllocMem(cacheCb, (Ptr *)newEntry, sizeof(SoClDnsAEnt));
   if (ret != ROK)
      RETVALUE(RFAILED);


   /* Initialize fields in cache entry */
   cmLListInit(&((*newEntry)->listCp));
   /* Copy to new control block and add to radix tree */
   ret = cacheCpyTknStrOSXL(&((*newEntry)->hostName), hostName, cacheCb);
   if (ret != ROK)
   {
      cacheFreeMem(cacheCb, (*newEntry), sizeof(SoClDnsAEnt));
      RETVALUE(RFAILED);
   }

   /* Initialize new entry */
   (*newEntry)->cacheCb     = cacheCb;
   (*newEntry)->llNode.node = (PTR)(*newEntry);

   ret = cmRdxTreeInsert(&cacheCb->rdxCp,
                         (PTR)(*newEntry),
                         (*newEntry)->hostName.val,
                         (*newEntry)->hostName.len,
                         FALSE);
   if (ret != ROK)
   {
      cacheDelTknStrOSXL(&((*newEntry)->hostName), cacheCb);
      cacheFreeMem(cacheCb, newEntry, sizeof(SoClDnsAEnt));
      RETVALUE(RFAILED);
   }

   /* Check cache memory usage with new Rdx Tree entry */
   tmpSize = 0;
   ret = cacheCheckMem(cacheCb, &tmpSize, TRUE);
   if (ret != ROK)
   {
      cmRdxTreeDeletePtr(&cacheCb->rdxCp, (PTR)(*newEntry));
      cacheDelTknStrOSXL(&((*newEntry)->hostName), cacheCb);
      cacheFreeMem(cacheCb, newEntry, sizeof(SoClDnsAEnt));
      RETVALUE(RFAILED);
   }

   INC_NMBENTRIES(cacheCb)

   cmLListAdd2Tail(&cacheCb->listCp, &((*newEntry)->llNode));
   (*newEntry)->llNode.node = (PTR)(*newEntry);

   RETVALUE(ROK);
} /* soClAddDnsAEntry */


/*
*
*       Fun:   soClFindDnsAEntry
*
*       Desc:  Searches cache for Dns A entry
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/
#ifdef ANSI
PUBLIC S16 soClFindDnsAEntry
(
SoCacheCb     *cb,        /* Cache control block */
TknStrOSXL    *hostName,  /* Host name to search for */
SoClDnsAEnt   **result    /* Search result */
)
#else
PUBLIC S16 soClFindDnsAEntry (cb, hostName, result)
SoCacheCb     *cb;        /* Cache control block */
TknStrOSXL    *hostName;  /* Host name to search for */
SoClDnsAEnt   **result;   /* Search result */
#endif
{
   S16           ret;       /* Return value */

   TRC2(soClFindDnsAEntry);

   /* Input checks: Message must be request, with register method */
   if ((cb == NULLP) || (hostName == NULLP) || (result == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO048, ERRZERO,
                 "soClFindDnsAEntry: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

/* This must be a DNS SRV record cache */
   if (cb->cacheType != SO_CACHE_DNS_A)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO049, (ErrVal) cb->cacheType,
                 "soClFindDnsAEntry: Invalid cache type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   ret = cmRdxTreeFind(&cb->rdxCp,hostName->val,hostName->len,(PTR *)result);
   if ((ret != ROK) || ((*result) == NULLP))
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* soClFindDnsAEntry */


/*
*
*       Fun:   soClAddDnsSrvAnsEntry
*
*       Desc:  Adds new answer entry to DNS SRV cache
*
*       Ret:   ROK/RFAILED
*
*       Notes: Must have valid cache entry to use this function
*              Adds it according to prioriy. Lowest is first in list
*
*       File:  so_cl
*
*/
#ifdef ANSI
PUBLIC S16 soClAddDnsSrvAnsEntry
(
SoClDnsSrvEnt  *mainEntry,      /* Main cache entry for original SRV query */
TknStrOSXL     *target,         /* Result of SRV lookup */
U16            priority,        /* Priority */
U16            weight,          /* Weight */
U16            port,            /* Port number of resultand lookup */
U32            ttl,             /* Expiry time for entry */
U8             protocol,        /* Protocol for entry */
Bool           haveAddress,     /* Flag to indicate if address available */
CmNetAddr      physicalAddr     /* Physical address - if available */
)
#else
PUBLIC S16 soClAddDnsSrvAnsEntry (mainEntry, target, priority, weight, port,
                                  ttl,protocol, haveAddress,physicalAddr)
SoClDnsSrvEnt  *mainEntry;      /* Main cache entry for original SRV query */
TknStrOSXL     *target;         /* Result of SRV lookup */
U16            priority;        /* Priority */
U16            weight;          /* Weight */
U16            port;            /* Port number of resultand lookup */
U32            ttl;             /* Expiry time for entry */
U8             protocol;        /* Protocol for entry */
Bool           haveAddress;     /* Flag to indicate if address available */
CmNetAddr      physicalAddr;    /* Physical address - if available */
#endif
{
   S16               ret;           /* Return value                 */
   SoDnsSrvAnswerRec *newEntry;     /* New answer record            */
   SoDnsSrvAnswerRec *curEntry;     /* Current Entry                */
   CmLListCp         *cp;           /* List control point           */
   U16               tmrTtl;        /* TTL timer for answer record  */

   TRC2(soClAddDnsSrvAnsEntry);

   /* Parameter checks */
   if ((mainEntry == NULLP) || (target == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO050, ERRZERO,
                 "soClAddDnsSrvAnsEntry: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   /* so032.201: Do not put into cache if already there */
   cp = &mainEntry->listCp;
   for (cp->crnt = cp->first; cp->crnt != NULLP; cp->crnt = cp->crnt->next)
   {
      curEntry = (SoDnsSrvAnswerRec*)cp->crnt->node;

      if (curEntry->priority  == priority &&
          curEntry->weight    == weight &&
          curEntry->port      == port &&
          curEntry->protocol  == protocol &&
          curEntry->ttl       == ttl &&
          soUtlCmpTknStrOSXL(&curEntry->srvResult, target, FALSE))
      {
         if (curEntry->validAddress == TRUE && haveAddress == TRUE)
         {
          if (cmMemcmp((U8*)&curEntry->ipAddress, (U8*)&physicalAddr,
                   sizeof(CmNetAddr)))
            RETVALUE(ROK);
         }
         else if (curEntry->validAddress == FALSE && haveAddress == FALSE)
            RETVALUE(ROK);
      }
   }

   /* add  entry in SRV record linked list */
   /* assuming the the node is the first entry in the struct */
   /* if thats not the case we must start using the node inside llnode */
   ret = cacheAllocMem(mainEntry->cacheCb,
                       (Ptr *)&newEntry,
                       sizeof(SoDnsSrvAnswerRec));
   if (ret != ROK)
      RETVALUE(RFAILED);


   /* Find the the entry with priority just bigger than new one and insert */
   cp = &mainEntry->listCp;
   for (cp->crnt = cp->first; cp->crnt != NULLP; cp->crnt = cp->crnt->next)
   {
       SoDnsSrvAnswerRec *crnt = (SoDnsSrvAnswerRec*)cp->crnt->node;
      if (priority < crnt->priority)
      {
         break;
      }
   }
   if (cp->crnt == NULLP)
   {
      cmLListAdd2Tail(&mainEntry->listCp, &newEntry->llNode);
   }
   else
   {
      cmLListInsCrnt(cp,&newEntry->llNode);
   }
   newEntry->llNode.node = (PTR)newEntry;

   ret = cacheCpyTknStrOSXL(&newEntry->srvResult, target, mainEntry->cacheCb);
   if (ret != ROK)
   {
      cacheFreeMem(mainEntry->cacheCb, (Ptr *)newEntry,
                   sizeof(SoDnsSrvAnswerRec));
      RETVALUE(RFAILED);
   }

   newEntry->llNode.node  = (PTR)newEntry;
   newEntry->mainEntry    = mainEntry;
   newEntry->priority     = priority;
   newEntry->weight       = weight;
   newEntry->port         = port;
   newEntry->protocol     = protocol;
   newEntry->validAddress = haveAddress;
   if (newEntry->validAddress == TRUE)
   {
      /* Copy address itself */
      cmMemcpy((U8 *)&newEntry->ipAddress,
               (U8 *)&physicalAddr, sizeof(CmNetAddr));
   }

   newEntry->ttl         = ttl;

   soCmInitTimer(&newEntry->expireTimer);

   if (newEntry->ttl != 0)
   {
      /* Start timer */
      tmrTtl = (U16)ttl;
      soSchedTmr(newEntry, SO_TMR_CACHE_DNS_SRV, TMR_START, 
              (tmrTtl * SO_TMRVAL_1_S));
   }

   RETVALUE(ROK);

} /* soClAddDnsSrvAnsEntry */


/*
*
*       Fun:   soClAddDnsSrvEntry
*
*       Desc:  Adds new entry to DNS SRV cache
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/
#ifdef ANSI
PUBLIC S16 soClAddDnsSrvEntry
(
SoCacheCb      *cb,             /* Cache control block */
TknStrOSXL     *hostName,       /* Host name provided */
TknStrOSXL     *target,         /* Result of SRV lookup */
U16            priority,        /* Priority */
U16            weight,          /* Weight */
U16            port,            /* Port number of resultand lookup */
U32            ttl,             /* Expiry time for entry */
U8             protocol,        /* Protocol for entry */
SoClDnsSrvEnt  **newCacheEntry, /* New cache entry */
Bool           haveAddress,     /* Flag to indicate if address available */
CmNetAddr      physicalAddr     /* Physical address - if available */
)
#else
PUBLIC S16 soClAddDnsSrvEntry (cb, hostName, target, priority,weight, port,
                               ttl,protocol, newCacheEntry, haveAddress,
                               physicalAddr)
SoCacheCb      *cb;             /* Cache control block */
TknStrOSXL     *hostName;       /* Host name provided */
TknStrOSXL     *target;         /* Result of SRV lookup */
U16            priority;        /* Priority */
U16            weight;          /* Weight */
U16            port;            /* Port number of resultand lookup */
U32            ttl;             /* Expiry time for entry */
U8             protocol;        /* Protocol for entry */
SoClDnsSrvEnt  **newCacheEntry; /* New cache entry */
Bool           haveAddress;     /* Flag to indicate if address available */
CmNetAddr      physicalAddr;    /* Physical address - if available  */
#endif
{
   S16           ret;       /* Return value */
   SoClDnsSrvEnt *tmpEntry; /* Main cache entry */
   U16           findCount; /* How many entries (should be max 1) */
   S32           tmpSize;

   TRC2(soClAddDnsSrvEntry);

   /* Check input parameters */
   if ((cb == NULLP) || (hostName == NULLP) || (target == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO051, ERRZERO,
                 "soClAddDnsSrvEntry: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

/* This must be a DNS SRV record cache */
   if (cb->cacheType != SO_CACHE_DNS_SRV)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO052, (ErrVal) cb->cacheType,
                 "soClAddDnsSrvEntry: Invalid cache type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   /* Initialize return value */
   (*newCacheEntry) = NULLP;

   /* See if entry already in cache */
   ret = cmRdxTreeFindAll(&cb->rdxCp, hostName->val, hostName->len,
                          (PTR *)&tmpEntry, &findCount);
   if ((ret != ROK) || (findCount<1))
   {
      /* Add new entry */
      ret = cacheAllocMem(cb, (Ptr *)&tmpEntry, sizeof(SoClDnsSrvEnt));
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }
      /* Initialize new entry */
      tmpEntry->cacheCb = cb;
      /* Copy to new control block and add to radix tree */
      ret = cacheCpyTknStrOSXL(&tmpEntry->hostName, hostName, cb);
      if (ret != ROK)
      {
         cacheFreeMem(cb, tmpEntry, sizeof(SoClDnsSrvEnt));
         RETVALUE(RFAILED);
      }
      /* Initialize list of data entries */
      cmLListInit(&tmpEntry->listCp);
      /* Insert into radix tree */
      ret = cmRdxTreeInsert(&cb->rdxCp,(PTR)tmpEntry, tmpEntry->hostName.val,
                            tmpEntry->hostName.len, FALSE);
      if (ret != ROK)
      {
         cacheDelTknStrOSXL(&tmpEntry->hostName, cb);
         cacheFreeMem(cb, tmpEntry, sizeof(SoClDnsSrvEnt));
         RETVALUE(RFAILED);
      }

      /* Check cache memory usage with new Rdx Tree entry */
      tmpSize = 0;
      ret = cacheCheckMem(cb, &tmpSize, TRUE);
      if (ret != ROK)
      {
         cmRdxTreeDeletePtr(&cb->rdxCp, (PTR)tmpEntry);
         cacheDelTknStrOSXL(&tmpEntry->hostName, cb);
         cacheFreeMem(cb, tmpEntry, sizeof(SoClDnsSrvEnt));
         RETVALUE(RFAILED);
      }

      INC_NMBENTRIES(cb)

      /* Insert into linked list */
      cmLListAdd2Tail(&cb->listCp, &tmpEntry->llNode);
      tmpEntry->llNode.node = (PTR)tmpEntry;
      (*newCacheEntry) = tmpEntry;
   }
   else
   {
      /* Use existing entry */
      (*newCacheEntry) = tmpEntry;
   }

   /* add individual entry */
   ret = soClAddDnsSrvAnsEntry(tmpEntry, target, priority, weight,  port, ttl,
                               protocol, haveAddress, physicalAddr);

   RETVALUE(ret);
} /* soClAddDnsSrvEntry */


/*
*
*       Fun:   soClFindDnsSrvEntry
*
*       Desc:  Searches cache for Dns SRV entry
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/
#ifdef ANSI
PUBLIC S16 soClFindDnsSrvEntry
(
SoCacheCb     *cb,        /* Cache control block */
TknStrOSXL    *hostName,  /* Host name to search for */
SoClDnsSrvEnt **result    /* Search result */
)
#else
PUBLIC S16 soClFindDnsSrvEntry (cb, hostName, result)
SoCacheCb     *cb;        /* Cache control block */
TknStrOSXL    *hostName;  /* Host name to search for */
SoClDnsSrvEnt **result;   /* Search result */
#endif
{
   S16           ret;       /* Return value */

   TRC2(soClFindDnsSrvEntry);

   /* Input checks: Message must be request, with register method */
   if ((cb == NULLP) || (hostName == NULLP) || (result == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO053, ERRZERO,
                 "soClFindDnsSrvEntry: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

/* This must be a DNS SRV record cache */
   if (cb->cacheType != SO_CACHE_DNS_SRV)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO054, (ErrVal) cb->cacheType,
                 "soClFindDnsSrvEntry: Invalid cache type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   ret = cmRdxTreeFind(&cb->rdxCp,hostName->val,hostName->len,(PTR *)result);
   if ((ret != ROK) || ((*result) == NULLP))
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* soClFindDnsSrvEntry */


/*
*
*       Fun:   soClAddDnsNaptrAnsEntry
*
*       Desc:  Adds new answer entry to DNS NAPTR cache
*
*       Ret:   ROK/RFAILED
*
*       Notes: Must have valid cache entry to use this function
*              Adds it according to prioriy. Lowest is first in list
*
*       File:  so_cl
*
*/
#ifdef ANSI
PUBLIC S16 soClAddDnsNaptrAnsEntry
(
SoClDnsNaptrEnt  *mainEntry,      /* Main cache entry for original SRV query */
TknStrOSXL     *target,         /* Result of NAPTR lookup */
U16            order,           /* Order */
U16            preference,      /* Preference */
U32            ttl,             /* Expiry time for entry */
Bool           isNaptrU         /* is naptr U? */
)
#else
PUBLIC S16 soClAddDnsNaptrAnsEntry (mainEntry, target, order, preference,
                                  ttl, isNaptrU)
SoClDnsNaptrEnt  *mainEntry;    /* Main cache entry for original SRV query */
TknStrOSXL     *target;         /* Result of NAPTR lookup */
U16            order;           /* Order */
U16            preference;      /* Preference */
U32            ttl;             /* Expiry time for entry */
Bool           isNaptrU;        /* is naptr U? */
#endif
{
   S16               ret;           /* Return value                 */
   SoDnsNaptrAnswerRec *newEntry;   /* New answer record            */
   CmLListCp         *cp;           /* List control point           */
   U32               tmrTtl;        /* TTL timer for answer record  */
   U8                buf[256];      /* Buffer to hold the result    */
   U8                separator;     /* Separator character in Regular 
                                       Expression field */
   U16               indx;          /* Temporary array index        */
   U16               bufIdx;        /* Index into buffer where next character 
                                       is to be placed */
   SoAddrEvnt        *addrEvent;    /* Event structure into which the result
                                       will be decoded */
   MsgLen            numSipBytes;   /* Number of SDP bytes decoded by ABNF   */
   Buffer            *mBuf;
   CmAbnfErr         err;           /* ABNF module error structure           */
   CmAbnfDecOff      decOff;        /* ABNF offset structure                 */
   Mem               eventMem;      /* Memory to use for event               */
   U32               tmpSize;       /* Temporary size                        */
   SoDnsNaptrAnswerRec *crnt;       /* Temporary pointer to structure        */
   
   TRC2(soClAddDnsNaptrAnsEntry);

   /* Parameter checks */
   if ((mainEntry == NULLP) || (target == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO055, ERRZERO,
                 "soClAddDnsNaptrAnsEntry: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   if(isNaptrU)
   {
      separator = target->val[0];
      indx = 1;
      bufIdx = 0;
      buf[bufIdx++] = ':';
      while (target->val[indx++] != separator);
      while (target->val[indx] != separator)
      {
         buf[bufIdx++] = target->val[indx];
         indx++;
      }
      buf[bufIdx++] = '\r';
      buf[bufIdx++] = '\n';
      buf[bufIdx++] = '\0';
      ret = SGetMsg(soCb.init.region, soCb.init.pool, &mBuf);
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }
      (Void)SAddPstMsgMult((U8*)buf, cmStrlen((U8*)buf), mBuf);

      addrEvent = NULLP;
      eventMem.region = soCb.init.region;
      eventMem.pool = soCb.init.pool;

      /* Allocate memory for event structure */
      ret = cmAllocEvnt(sizeof(SoAddrEvnt), soCb.cfg.maxBlkSize , &eventMem,
                    (Ptr *)&addrEvent);
      if (ret != ROK)
      {
         SO_GEN_SMEM_ALARM;
         RETVALUE(RFAILED);
      }

      /* Try and decode */
      (Void) cmMemset((U8 *)&decOff, 0, sizeof(CmAbnfDecOff));
      (Void) cmMemset((U8 *)&err, 0, sizeof(CmAbnfErr));
      /* Call ABNF decode function */
      ret = cmAbnfDecPduMsg(CM_ABNF_PROT_SIP, &addrEvent->memCp,
            (U8 *)&addrEvent->addr, mBuf, &soMsgDefFrom,
            &numSipBytes, &decOff, &err);
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

      SPutMsg(mBuf);
      /* add  entry in NAPTR record linked list */
      ret = cacheAllocMem(mainEntry->cacheCb,
                          (Ptr *)&newEntry,
                          sizeof(SoDnsNaptrAnswerRec));
      if (ret != ROK)
         RETVALUE(RFAILED);

      if (soUtlCpySoAddress(&newEntry->naptrResult, 
             &addrEvent->addr, NULLP) != ROK)
      {
    cacheFreeMem(mainEntry->cacheCb,newEntry,sizeof(SoDnsNaptrAnswerRec));
         cmFreeMem((Ptr)addrEvent);
         RETVALUE(RFAILED);
      }
      cmFreeMem((Ptr)addrEvent);

      tmpSize = 0;
      soSizeOfSoAddress (&newEntry->naptrResult, &tmpSize);
      mainEntry->cacheCb->memUsed  += tmpSize;

      /* Find the the entry with priority just bigger than new one and insert */
      cp = &mainEntry->listCp;
   } /* end of isNaptrU */
   else
   {
      /* we also need to allocate mem for NAPTRS */
      ret = cacheAllocMem(mainEntry->cacheCb,
                          (Ptr *)&newEntry,
                          sizeof(SoDnsNaptrAnswerRec));
      if (ret != ROK)
         RETVALUE(RFAILED);
      /* here soAddress is not present so that no 
       * need to calculate the tmpSize */
      cp = &mainEntry->listCp;
   }
   /* common part for both naptr s and naptr u */
   for (cp->crnt = cp->first; cp->crnt != NULLP; cp->crnt = cp->crnt->next)
   {
      crnt = (SoDnsNaptrAnswerRec*)cp->crnt->node;
      if (order< crnt->order)
      {
         break;
      }
      else
      {
         if ((order == crnt->order) && (preference < crnt->preference))
         {
            break;
         }
      }
   }
   if (cp->crnt == NULLP)
   {
      cmLListAdd2Tail(&mainEntry->listCp, &newEntry->llNode);
   }
   else
   {
      cmLListInsCrnt(cp,&newEntry->llNode);
   }
   newEntry->llNode.node = (PTR)newEntry;

   if(isNaptrU)
   {
      if (soCmNormAddress((U8 *)NULLP, &newEntry->naptrResult, 
          &newEntry->normNaptrResult.len, FALSE) != ROK)
      {
    cmLListDelFrm(cp, &newEntry->llNode);
    cacheFreeMem(mainEntry->cacheCb,newEntry,sizeof(SoDnsNaptrAnswerRec));
         RETVALUE(RFAILED);
      }

      /* Allocate memory for normalised address */
      ret = cacheAllocMem(mainEntry->cacheCb, 
                (Ptr *)&newEntry->normNaptrResult.\
                          val, newEntry->normNaptrResult.len);
      if (ret != ROK)
      {
    cmLListDelFrm(cp, &newEntry->llNode);
    cacheFreeMem(mainEntry->cacheCb,newEntry,sizeof(SoDnsNaptrAnswerRec));
         RETVALUE(RFAILED);
      }

      /* Set present flag */
      newEntry->normNaptrResult.pres = PRSNT_NODEF;

      /* Normalize address */
      if (soCmNormAddress(newEntry->normNaptrResult.val, 
           &newEntry->naptrResult, 
                          &newEntry->normNaptrResult.len, FALSE) != ROK) 
      {
         cacheFreeMem(mainEntry->cacheCb, newEntry->normNaptrResult.val, 
                      newEntry->normNaptrResult.len);
    cmLListDelFrm(cp, &newEntry->llNode);
    cacheFreeMem(mainEntry->cacheCb,newEntry,sizeof(SoDnsNaptrAnswerRec));
         RETVALUE(RFAILED);
      }
   }
   else
   {
      newEntry->normNaptrResult.len =  target->len;
      /* Allocate memory for normalised address */
      ret = cacheAllocMem(mainEntry->cacheCb, 
                (Ptr *)&newEntry->normNaptrResult.val,
                          newEntry->normNaptrResult.len);
      if (ret != ROK)
         RETVALUE(RFAILED);

      /* Set present flag */
      newEntry->normNaptrResult.pres = PRSNT_NODEF;
      cmMemcpy(newEntry->normNaptrResult.val, target->val, 
          newEntry->normNaptrResult.len);
   }

   newEntry->llNode.node  = (PTR)newEntry;
   newEntry->mainEntry    = mainEntry;
   newEntry->order        = order;
   newEntry->preference   = preference;
   newEntry->flag         = isNaptrU;
   newEntry->ttl         = ttl;

   soCmInitTimer(&newEntry->expireTimer);

   if (newEntry->ttl != 0)
   {
      /* Start timer */
      tmrTtl = (U16)ttl;
      soSchedTmr(newEntry, SO_TMR_CACHE_DNS_NAPTR, TMR_START, 
             (tmrTtl * SO_TMRVAL_1_S));
   }

   RETVALUE(ROK);

} /* soClAddDnsNaptrAnsEntry */

/*
*
*       Fun:   soClAddDnsNaptrEntry
*
*       Desc:  Adds new entry to DNS NAPTR cache
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/
#ifdef ANSI
PUBLIC S16 soClAddDnsNaptrEntry
(
SoCacheCb      *cb,             /* Cache control block */
TknStrOSXL     *hostName,       /* Host name provided */
TknStrOSXL     *target,         /* Result of NAPTR lookup */
U16            order,           /* Order */
U16            preference,      /* Preference */
U32            ttl,             /* Expiry time for entry */
SoClDnsNaptrEnt  **newCacheEntry, /* New cache entry */
Bool           isNaptrU         /* is NAPTRU? */
)
#else
PUBLIC S16 soClAddDnsNaptrEntry (cb, hostName, target, order, preference,
                               ttl, newCacheEntry, isNaptrU)
SoCacheCb      *cb;             /* Cache control block */
TknStrOSXL     *hostName;       /* Host name provided */
TknStrOSXL     *target;         /* Result of NAPTR lookup */
U16            order;           /* Order */
U16            preference;      /* Preference */
U32            ttl;             /* Expiry time for entry */
SoClDnsNaptrEnt  **newCacheEntry; /* New cache entry */
Bool           isNaptrU;        /* is NAPTRU? */
#endif
{
   S16           ret;          /* Return value            */
   SoClDnsNaptrEnt *tmpEntry;  /* Main cache entry        */
   U16           findCount;    /* How many entries (should be max 1) */
   S32           tmpSize;      /* Temporary size variable */

   TRC2(soClAddDnsNaptrEntry);

   /* Check input parameters */
   if ((cb == NULLP) || (hostName == NULLP) || (target == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO056, ERRZERO,
                 "soClAddDnsNaptrEntry: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

/* This must be a DNS NAPTR record cache */
   if (cb->cacheType != SO_CACHE_DNS_NAPTR)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO057, (ErrVal) cb->cacheType,
                 "soClAddDnsNaptrEntry: Invalid cache type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   /* Initialize return value */
   (*newCacheEntry) = NULLP;

   /* See if entry already in cache */
   ret = cmRdxTreeFindAll(&cb->rdxCp, hostName->val, hostName->len,
                          (PTR *)&tmpEntry, &findCount);
   if ((ret != ROK) || (findCount<1))
   {
      /* Add new entry */
      ret = cacheAllocMem(cb, (Ptr *)&tmpEntry, sizeof(SoClDnsNaptrEnt));
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }
      SO_ZERO(tmpEntry, sizeof(SoClDnsNaptrEnt));
      /* Initialize new entry */
      tmpEntry->cacheCb = cb;
      /* Copy to new control block and add to radix tree */
      ret = cacheCpyTknStrOSXL(&tmpEntry->hostName, hostName, cb);
      if (ret != ROK)
      {
         cacheFreeMem(cb, tmpEntry, sizeof(SoClDnsNaptrEnt));
         RETVALUE(RFAILED);
      }
      /* Initialize list of data entries */
      cmLListInit(&tmpEntry->listCp);
      /* Insert into radix tree */
      ret = cmRdxTreeInsert(&cb->rdxCp,(PTR)tmpEntry, tmpEntry->hostName.val,
                            tmpEntry->hostName.len, FALSE);
      if (ret != ROK)
      {
         cacheDelTknStrOSXL(&tmpEntry->hostName, cb);
         cacheFreeMem(cb, tmpEntry, sizeof(SoClDnsNaptrEnt));
         RETVALUE(RFAILED);
      }

      /* Check cache memory usage with new Rdx Tree entry */
      tmpSize = 0;
      ret = cacheCheckMem(cb, &tmpSize, TRUE);
      if (ret != ROK)
      {
         cmRdxTreeDeletePtr(&cb->rdxCp, (PTR)tmpEntry);
         cacheDelTknStrOSXL(&tmpEntry->hostName, cb);
         cacheFreeMem(cb, tmpEntry, sizeof(SoClDnsNaptrEnt));
         RETVALUE(RFAILED);
      }

      INC_NMBENTRIES(cb)

      /* Insert into linked list */
      cmLListAdd2Tail(&cb->listCp, &tmpEntry->llNode);
      tmpEntry->llNode.node = (PTR)tmpEntry;
      (*newCacheEntry) = tmpEntry;
   }
   else
   {
      /* Use existing entry */
      (*newCacheEntry) = tmpEntry;
   }

   /* save naptr type */
   (*newCacheEntry)->flag = isNaptrU;
   /* add individual entry */
   ret = soClAddDnsNaptrAnsEntry(tmpEntry, target, order, preference, 
                       ttl, isNaptrU);

   RETVALUE(ret);
} /* soClAddDnsNaptrEntry */


/*
*
*       Fun:   cacheDelSoAddress
*
*       Desc:  Deletes a SoAddress structure and checks
*              cache memory usage
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/

#ifdef ANSI
PRIVATE S16 cacheDelSoAddress
(
SoAddress    *delSoAddr,
SoCacheCb    *cacheCb         /* Cache control block */
)
#else
PRIVATE S16 cacheDelSoAddress (delSoAddr,  cacheCb)
SoAddress    *delSoAddr;
SoCacheCb    *cacheCb;        /* Cache control block */
#endif
{
   U32   tmpSize;

   TRC2(cacheDelSoAddress);
  
   tmpSize = 0;
   soSizeOfSoAddress (delSoAddr, &tmpSize);
   cacheCb->memUsed -= tmpSize;
   if (soUtlDelSoAddress(delSoAddr) != ROK)
   {
      cacheCb->memUsed += tmpSize;
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK); 
}


/*
*
*       Fun:   soClFindDnsNaptrEntry
*
*       Desc:  Searches cache for Dns NAPTR entry
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cl
*
*/
#ifdef ANSI
PUBLIC S16 soClFindDnsNaptrEntry
(
SoCacheCb     *cb,        /* CacheNAPTR control block */
TknStrOSXL    *hostName,  /* Telephone number to search for */
SoClDnsNaptrEnt **result    /* Search result */
)
#else
PUBLIC S16 soClFindDnsNaptrEntry (cb, hostName, result)
SoCacheCb     *cb;        /* Cache control block */
TknStrOSXL    *hostName;  /* Host NAPTR to search for */
SoClDnsNaptrEnt **result;   /* Search result */
#endif
{
   S16           ret;       /* Return value */

   TRC2(soClFindDnsNaptrEntry);

   /* Input checks: Message must  be request, with register method */
   if ((cb == NULLP) || (hostName == NULLP) || (result == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO058, ERRZERO,
                 "soClFindDnsNaptrEntry: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

/* This must be a DNS NAPTR record cache */
   if (cb->cacheType != SO_CACHE_DNS_NAPTR)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO059, (ErrVal) cb->cacheType,
                 "soClFindDnsNaptrEntry: Invalid cache type");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }
  
   ret = cmRdxTreeFind(&cb->rdxCp,hostName->val,hostName->len,(PTR *)result);
   if ((ret != ROK) || ((*result) == NULLP))
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* soClFindDnsNaptrEntry */
#endif /* SO_DNS */

/****************************************************************************
                  DNS related cache functions 
****************************************************************************/


/********************************************************************30**

         End of file:     so_cl.c@@/main/4 - Tue Apr 20 12:45:53 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**


*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/4      ---      ms   1. initial release.
/main/4     so032.201 ng   1. Do not put a recprd into cache if already
                              there(ms)
*********************************************************************91*/

