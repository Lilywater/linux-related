/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SIP Portable Management Interface

     Type:     C source file

     Desc:     C source code for SIP Layer
               portable Management Interface

     File:     so_ptmi.c

     Sid:      so_ptmi.c@@/main/4 - Tue Apr 20 12:46:55 2004

     Prg:      wvdl

*********************************************************************21*/

/*

The following functions are provided in this file:
   SoMiLsoCfgCfm                - condifuration confirm
   SoMiLsoCntrlCfm              - control confirm
   SoMiLsoStaCfm                - status confirm
   SoMiLsoStsCfm                - statistics confirm
   SoMiLsoAcntCfm               - accounting confirm
   SoMiLsoStaInd                - status indication
   SoMiLsoAcntInd               - accounting indication
   SoMiLsoTrcInd                - trace indication

It should be noted that not all of these functions may be required
by a particular layer management service user.

*/


/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "so.h"            /* SIP layer defines               */
#include "so_trans.h"      /* Transaction module defines      */
#include "so_err.h"        /* SIP error defines               */
#include "so_cm.h"         /* SIP layer utility functions     */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lso.x"           /* Layer management SIP            */
#include "sot.x"           /* SOT interface defines           */
#include "so_tcm.x"        /* Transport module structures     */
#include "so.x"            /* SIP layer structures            */
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* SIP layer utility functions     */
#include "so_cm.x"         /* SIP layer common functions      */
#include "so_dns.x"        /* SIP DNS library                 */

/* local defines */
#define SO_MAX_MILSO_SEL         2       /* maximum no. selectors */

#ifndef LCSOMILSO
#define PTSOMILSO
#else
#ifndef SM
#define PTSOMILSO
#else
#endif
#endif

/* forward references */
#ifdef PTSOMILSO
PRIVATE S16 PtMiLsoCfgCfm    ARGS((Pst             *pst,
                                   SoMngmt         *cfg));
PRIVATE S16 PtMiLsoCntrlCfm  ARGS((Pst             *pst,
                                   SoMngmt         *cntrl));
PRIVATE S16 PtMiLsoStaCfm    ARGS((Pst             *pst,
                                   SoMngmt         *sta));
PRIVATE S16 PtMiLsoStsCfm    ARGS((Pst             *pst,
                                   SoMngmt         *sts));
PRIVATE S16 PtMiLsoStaInd    ARGS((Pst             *pst,
                                   SoMngmt         *sta));
PRIVATE S16 PtMiLsoTrcInd    ARGS((Pst             *pst,
                                   SoMngmt         *trc,
                                   Buffer          *mBuf));
#ifdef LSO_ACNT                                   
PRIVATE S16 PtMiLsoAcntCfm   ARGS((Pst             *pst,
                                   SoMngmt         *acnt));
PRIVATE S16 PtMiLsoAcntInd   ARGS((Pst             *pst,
                                   SoMngmt         *acnt));
#endif /* LSO_ACNT */
#endif /* PTSOMILSO */
#if (defined(SO_FTHA) && (!(defined(SH))))
PRIVATE S16 PtMiShtCntrlCfm  ARGS((Pst             *pst,
                                   ShtCntrlCfmEvnt *cfmInfo));
#endif

/* Primitive Mapping Tables */

PUBLIC LsoCfgCfm SoMiLsoCfgCfmMt [SO_MAX_MILSO_SEL] =
{
#ifdef LCSOMILSO
   cmPkLsoCfgCfm,      /* 0 - loosely coupled (default mechanism) */
#else
   PtMiLsoCfgCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLsoCfgCfm,        /* 1 - tightly coupled, stack manager */
#else
   PtMiLsoCfgCfm,        /* 1 - tightly coupled, portable */
#endif
};


PUBLIC LsoCntrlCfm SoMiLsoCntrlCfmMt [SO_MAX_MILSO_SEL] =
{
#ifdef LCSOMILSO
   cmPkLsoCntrlCfm,      /* 0 - loosely coupled (default mechanism) */
#else
   PtMiLsoCntrlCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLsoCntrlCfm,        /* 1 - tightly coupled, stack manager */
#else
   PtMiLsoCntrlCfm,        /* 1 - tightly coupled, portable */
#endif
};


PUBLIC LsoStaCfm SoMiLsoStaCfmMt [SO_MAX_MILSO_SEL] =
{
#ifdef LCSOMILSO
   cmPkLsoStaCfm,      /* 0 - loosely coupled (default mechanism) */
#else
   PtMiLsoStaCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLsoStaCfm,        /* 1 - tightly coupled, stack manager */
#else
   PtMiLsoStaCfm,        /* 1 - tightly coupled, portable */
#endif
};

PUBLIC LsoStsCfm SoMiLsoStsCfmMt [SO_MAX_MILSO_SEL] =
{
#ifdef LCSOMILSO
   cmPkLsoStsCfm,      /* 0 - loosely coupled (default mechanism) */
#else
   PtMiLsoStsCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLsoStsCfm,        /* 1 - tightly coupled, stack manager */
#else
   PtMiLsoStsCfm,        /* 1 - tightly coupled, portable */
#endif
};

PUBLIC LsoStaInd SoMiLsoStaIndMt [SO_MAX_MILSO_SEL] =
{
#ifdef LCSOMILSO
   cmPkLsoStaInd,      /* 0 - loosely coupled (default mechanism) */
#else
   PtMiLsoStaInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLsoStaInd,        /* 1 - tightly coupled, stack manager */
#else
   PtMiLsoStaInd,        /* 1 - tightly coupled, portable */
#endif
};

PUBLIC LsoTrcInd SoMiLsoTrcIndMt [SO_MAX_MILSO_SEL] =
{
#ifdef LCSOMILSO
   cmPkLsoTrcInd,      /* 0 - loosely coupled (default mechanism) */
#else
   PtMiLsoTrcInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLsoTrcInd,        /* 1 - tightly coupled, stack manager */
#else
   PtMiLsoTrcInd,        /* 1 - tightly coupled, portable */
#endif
};

#ifdef LSO_ACNT
PUBLIC LsoAcntCfm SoMiLsoAcntCfmMt [SO_MAX_MILSO_SEL] =
{
#ifdef LCSOMILSO
   cmPkLsoAcntCfm,      /* 0 - loosely coupled (default mechanism) */
#else
   PtMiLsoAcntCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLsoAcntCfm,        /* 1 - tightly coupled, stack manager */
#else
   PtMiLsoAcntCfm,        /* 1 - tightly coupled, portable */
#endif
};

PUBLIC LsoAcntInd SoMiLsoAcntIndMt [SO_MAX_MILSO_SEL] =
{
#ifdef LCSOMILSO
   cmPkLsoAcntInd,      /* 0 - loosely coupled (default mechanism) */
#else
   PtMiLsoAcntInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLsoAcntInd,        /* 1 - tightly coupled, stack manager */
#else
   PtMiLsoAcntInd,        /* 1 - tightly coupled, portable */
#endif
};
#endif /* LSO_ACNT */

#ifdef SO_FTHA
PUBLIC ShtCntrlCfm SoMiShtCntrlCfmMt[SO_MAX_MILSO_SEL] =
{
   cmPkShtCntrlCfm,     /* 0 - loosely coupled (default mechanism) */
#ifdef SH
   ShMiShtCntrlCfm,       /* 1 - tightly coupled, stack manager */
#else
   PtMiShtCntrlCfm,       /* 1 - tightly coupled, portable */
#endif
};
#endif /* SO_FTHA */



/* Primitive Mapping Dispatching Functions */

/**********************************************************
*
*       Fun:   Configuration Confirm
*
*       Desc:  This function confirms a configuration request
*
*       Ret:   ROK - ok
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 SoMiLsoCfgCfm
(
Pst     *pst,                    /* post structure */
SoMngmt *cfg                     /* management structure */
)
#else
PUBLIC S16 SoMiLsoCfgCfm (pst, cfg)
Pst     *pst;                    /* post structure */      
SoMngmt *cfg;                    /* management structure */
#endif
{
   TRC3(SoMiLsoCfgCfm)

   (*SoMiLsoCfgCfmMt[pst->selector])(pst, cfg);

   RETVALUE(ROK);
} /* SoMiLsoCfgCfm */


/**********************************************************
*
*       Fun:   Control Confirm
*
*       Desc:  This function confirms a control request
*
*       Ret:   ROK - ok
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 SoMiLsoCntrlCfm
(
Pst     *pst,                    /* post structure */      
SoMngmt *cntrl                   /* management structure */
)
#else
PUBLIC S16 SoMiLsoCntrlCfm (pst, cntrl)
Pst     *pst;                    /* post structure */      
SoMngmt *cntrl;                  /* management structure */
#endif
{
   TRC3(SoMiLsoCntrlCfm)

   (*SoMiLsoCntrlCfmMt[pst->selector])(pst, cntrl);

   RETVALUE(ROK);
}/* SoMiLsoCntrlCfm */


/**********************************************************
*
*       Fun:   Status Confirn
*
*       Desc:  This function confirms a status request
*
*       Ret:   ROK - ok
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 SoMiLsoStaCfm
(
Pst     *pst,                    /* post structure */      
SoMngmt *sta                     /* management structure */
)
#else
PUBLIC S16 SoMiLsoStaCfm (pst, sta)
Pst     *pst;                    /* post structure */      
SoMngmt *sta;                    /* management structure */
#endif
{
   TRC3(SoMiLsoStaCfm)

   (*SoMiLsoStaCfmMt[pst->selector])(pst, sta);

   RETVALUE(ROK);
}/* SoMiLsoStaCfm */


/**********************************************************
*
*       Fun:   Status Indication
*
*       Desc:  This function sends alarm information
*
*       Ret:   ROK - ok
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 SoMiLsoStaInd
(
Pst     *pst,                    /* post structure */      
SoMngmt *sta                     /* management structure */
)
#else
PUBLIC S16 SoMiLsoStaInd (pst, sta)
Pst     *pst;                    /* post structure */      
SoMngmt *sta;                    /* management structure */
#endif
{
   TRC3(SoMiLsoStaInd);

#ifdef DEBUGP
   /* Debug printing for outgoing status indication */
   if (soCb.init.dbgMask & DBGMASK_MI)
   {
      Txt          alInfo[100];     /* Info text buffer */
      SoAlarmInfo  *info;           /* Pointer to actual info struc */
      
      info = &sta->t.usta.alarmInfo;

      switch (info->alarmType)
      {
         case LSO_PAR_NONE:
            sprintf(alInfo,"No info");
            break;
         case LSO_PAR_MEM: 
            sprintf(alInfo,"Mem pool=%d, Region=%d",info->v.mem.pool,
               info->v.mem.region);
            break;
         case LSO_PAR_SAP:
            if (sta->hdr.elmId.elmnt == STSSAP)
            {
               sprintf(alInfo,"SSAP=%d",info->v.sapId);
            }
            else
            {
               sprintf(alInfo,"TSAP=%d",info->v.sapId);
            }
            break;
         case LSO_PAR_ENT:
            sprintf(alInfo,"Entity=%d",info->v.entId);
            break;
         case LSO_PAR_TPTSRV:
            sprintf(alInfo,"TptSrvId=%ld",info->v.tptSrvId);
            break;
         case LSO_PAR_CONNID:
            sprintf(alInfo,"ConnId=%ld",info->v.connId);
            break;
         case LSO_PAR_TPTADDR:
            sprintf(alInfo,"TptAddr=%p",(Void *)&info->v.tptAddr);
            break;
         case LSO_PAR_TPTPARM:
            sprintf(alInfo,"Tpt Param=%p",(Void *)&info->v.tptParm);
            break;
         case LSO_PAR_REG:
            sprintf(alInfo,"Registry=%d, entity=%d",
               info->v.reg.type, info->v.reg.entId);
            break;
         case LSO_PAR_VAL:
            sprintf(alInfo,"Value=%lx",info->v.val);
            break;
         case LSO_PAR_CHOICE:
            sprintf(alInfo,"Choice=%lx",info->v.val);
            break;
         case LSO_PAR_STATUS:
            sprintf(alInfo,"Status=%lx",info->v.val);
            break;
         case LSO_PAR_REASON:
            sprintf(alInfo,"Reason=%lx",info->v.val);
            break;
         default:
            sprintf(alInfo,"Invalid type = %d", info->alarmType);
            break;
      }

      sprintf(soCb.init.prntBuf, "SM <---StaInd--- SIP: elmt=%d cat=%d "
              "evnt=%d cause=%d info: %s\n",
              sta->hdr.elmId.elmnt, sta->t.usta.alarm.category, 
              sta->t.usta.alarm.event,
              sta->t.usta.alarm.cause,alInfo);
      SPrint(soCb.init.prntBuf);
   }
#endif /* DEBUGP */

   (*SoMiLsoStaIndMt[pst->selector])(pst, sta);

   RETVALUE(ROK);
}/* SoMiLsoStaInd */


/**********************************************************
*
*       Fun:   Statistics Confirm
*
*       Desc:  This function confirms a statistics request
*
*       Ret:   ROK - ok
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 SoMiLsoStsCfm
(
Pst     *pst,                    /* post structure */      
SoMngmt *sts                     /* management structure */
)
#else
PUBLIC S16 SoMiLsoStsCfm (pst, sts)
Pst     *pst;                    /* post structure */      
SoMngmt *sts;                    /* management structure */
#endif
{
   TRC3(SoMiLsoStsCfm)

   (*SoMiLsoStsCfmMt[pst->selector])(pst, sts);

   RETVALUE(ROK);
}/* SoMiLsoStsCfm */


/**********************************************************
*
*       Fun:   Trace indication
*
*       Desc:  This function sends PDU trace information
*
*       Ret:   ROK - ok
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 SoMiLsoTrcInd
(
Pst     *pst,                    /* post structure */      
SoMngmt *trc,                    /* management structure */
Buffer  *mBuf                    /* message buffer */
)
#else
PUBLIC S16 SoMiLsoTrcInd (pst, trc, mBuf)
Pst     *pst;                    /* post structure */      
SoMngmt *trc;                    /* management structure */
Buffer  *mBuf;                   /* message buffer */
#endif
{
   TRC3(SoMiLsoTrcInd)

   (*SoMiLsoTrcIndMt[pst->selector])(pst, trc, mBuf);

   RETVALUE(ROK);
}/* SoMiLsoTrcInd */

#ifdef LSO_ACNT

/**********************************************************
*
*       Fun:   Accounting confirm
*
*       Desc:  This function confirms an accounting request
*
*       Ret:   ROK - ok
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 SoMiLsoAcntCfm
(
Pst     *pst,                    /* post structure */      
SoMngmt *acnt                    /* management structure */
)
#else
PUBLIC S16 SoMiLsoAcntCfm (pst, acnt)
Pst     *pst;                    /* post structure */      
SoMngmt *acnt;                   /* management structure */
#endif
{
   TRC3(SoMiLsoAcntCfm)

   (*SoMiLsoAcntCfmMt[pst->selector])(pst, acnt);

   RETVALUE(ROK);
}/* SoMiLsoAcntCfm */


/**********************************************************
*
*       Fun:   Accounting indication
*
*       Desc:  This function sends accounting information
*
*       Ret:   ROK - ok
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 SoMiLsoAcntInd
(
Pst     *pst,                    /* post structure */      
SoMngmt *acnt                    /* management structure */
)
#else
PUBLIC S16 SoMiLsoAcntInd (pst, acnt)
Pst     *pst;                    /* post structure */      
SoMngmt *acnt;                   /* management structure */
#endif
{
   TRC3(SoMiLsoAcntInd)

   (*SoMiLsoAcntIndMt[pst->selector])(pst, acnt);

   RETVALUE(ROK);
}/* SoMiLsoAcntInd */
#endif /* LSO_ACNT */

#ifdef SO_FTHA

/**********************************************************
*
*       Fun:   System Agent Control Confirm
*
*       Desc:  This function sends System Agent Control Confirm
*
*       Ret:   ROK - ok
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 SoMiShtCntrlCfm
(
Pst             *pst,            /* post structure */      
ShtCntrlCfmEvnt *cfmInfo         /* system agent control confirm event */
)
#else
PUBLIC S16 SoMiShtCntrlCfm (pst, cfmInfo)
Pst             *pst;            /* post structure */      
ShtCntrlCfmEvnt *cfmInfo;        /* system agent control confirm event */
#endif
{
   TRC3(SoMiShtCntrlCfm)

   (*SoMiShtCntrlCfmMt[pst->selector])(pst, cfmInfo);

   RETVALUE(ROK);
}/* SoMiShtCntrlCfm */
#endif /* SO_FTHA */

#ifdef PTSOMILSO
/* Portable Stub Functions */


/**********************************************************
*
*       Fun:   PtMiLsoCfgCfm
*
*       Desc:  Portable version of LsoCfgCfm primitive
*
*       Ret:   RFAILED
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PRIVATE S16 PtMiLsoCfgCfm
(
Pst     *pst,                    /* post structure */      
SoMngmt *cfg                     /* management structure */
)
#else
PRIVATE S16 PtMiLsoCfgCfm (pst, cfg)
Pst     *pst;                    /* post structure */      
SoMngmt *cfg;                    /* management structure */
#endif
{
   TRC3(PtMiLsoCfgCfm)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(cfg);

   RETVALUE(RFAILED);
} /* PtMiLsoCfgCfm */


/**********************************************************
*
*       Fun:   PtMiLsoCntrlCfm
*
*       Desc:  Portable version of LsoCntrlCfm primitive
*
*       Ret:   RFAILED
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PRIVATE S16 PtMiLsoCntrlCfm
(
Pst     *pst,                    /* post structure */      
SoMngmt *cntrl                   /* management structure */
)
#else
PRIVATE S16 PtMiLsoCntrlCfm (pst, cntrl)
Pst     *pst;                    /* post structure */      
SoMngmt *cntrl;                  /* management structure */
#endif
{
   TRC3(PtMiLsoCntrlCfm)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(cntrl);

   RETVALUE(RFAILED);
} /* PtMiLsoCntrlCfm */


/**********************************************************
*
*       Fun:   PtMiLsoStaCfm
*
*       Desc:  Portable version of LsoStaCfm primitive
*
*       Ret:   RFAILED
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PRIVATE S16 PtMiLsoStaCfm
(
Pst     *pst,                    /* post structure */      
SoMngmt *sta                     /* management structure */
)
#else
PRIVATE S16 PtMiLsoStaCfm (pst, sta)
Pst     *pst;                    /* post structure */      
SoMngmt *sta;                    /* management structure */
#endif
{
   TRC3(PtMiLsoStaCfm)

   SOLOGINVSEL;   
   UNUSED(pst);
   UNUSED(sta);

   RETVALUE(RFAILED);
} /* PtMiLsoStaCfm */


/**********************************************************
*
*       Fun:   PtMiLsoStaInd
*
*       Desc:  Portable version of LsoStaInd primitive
*
*       Ret:   RFAILED
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PRIVATE S16 PtMiLsoStaInd
(
Pst     *pst,                    /* post structure */      
SoMngmt *usta                    /* management structure */
)
#else
PRIVATE S16 PtMiLsoStaInd (pst, usta)
Pst     *pst;                    /* post structure */      
SoMngmt *usta;                   /* management structure */
#endif
{
   TRC3(PtMiLsoStaInd)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(usta);

   RETVALUE(RFAILED);
} /* PtMiLsoStaInd */


/**********************************************************
*
*       Fun:   PtMiLsoStsCfm
*
*       Desc:  Portable version of LsoStsCfm primitive
*
*       Ret:   RFAILED
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PRIVATE S16 PtMiLsoStsCfm
(
Pst     *pst,                    /* post structure */      
SoMngmt *sts                     /* management structure */
)
#else
PRIVATE S16 PtMiLsoStsCfm (pst, sts)
Pst     *pst;                    /* post structure */      
SoMngmt *sts;                    /* management structure */
#endif
{
   TRC3(PtMiLsoStsCfm)
   
   SOLOGINVSEL;   
   UNUSED(pst);
   UNUSED(sts);

   RETVALUE(RFAILED);
} /* PtMiLsoStsCfm */


/**********************************************************
*
*       Fun:   PtMiLsoTrcInd
*
*       Desc:  Portable version of LsoTrcInd primitive
*
*       Ret:   RFAILED
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PRIVATE S16 PtMiLsoTrcInd
(
Pst     *pst,                    /* post structure */      
SoMngmt *trc,                    /* management structure */
Buffer  *mBuf                    /* message buffer */
)
#else
PRIVATE S16 PtMiLsoTrcInd (pst, trc, mBuf)
Pst     *pst;                    /* post structure */      
SoMngmt *trc;                    /* management structure */
Buffer *mBuf;                    /* message buffer */
#endif
{
   TRC3(PtMiLsoTrcInd)

   SOLOGINVSEL;   
   UNUSED(pst);
   UNUSED(trc);
   UNUSED(mBuf);

   RETVALUE(RFAILED);
} /* PtMiLsoTrcInd */

#ifdef LSO_ACNT

/**********************************************************
*
*       Fun:   PtMiLsoAcntCfm
*
*       Desc:  Portable version of LsoAcntCfm primitive
*
*       Ret:   RFAILED
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PRIVATE S16 PtMiLsoAcntCfm
(
Pst     *pst,                    /* post structure */      
SoMngmt *acnt                    /* management structure */
)
#else
PRIVATE S16 PtMiLsoAcntCfm (pst, acnt)
Pst     *pst;                    /* post structure */      
SoMngmt *acnt;                   /* management structure */
#endif
{
   TRC3(PtMiLsoAcntCfm)

   SOLOGINVSEL;   
   UNUSED(pst);
   UNUSED(acnt);

   RETVALUE(RFAILED);
} /* PtMiLsoAcntCfm */


/**********************************************************
*
*       Fun:   PtMiLsoAcntInd
*
*       Desc:  Portable version of LsoAcntInd primitive
*
*       Ret:   RFAILED
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PRIVATE S16 PtMiLsoAcntInd
(
Pst     *pst,                    /* post structure */      
SoMngmt *acnt                    /* management structure */
)
#else
PRIVATE S16 PtMiLsoAcntInd (pst, acnt)
Pst     *pst;                    /* post structure */      
SoMngmt *acnt;                   /* management structure */
#endif
{
   TRC3(PtMiLsoAcntInd)

   SOLOGINVSEL;   
   UNUSED(pst);
   UNUSED(acnt);

   RETVALUE(RFAILED);
} /* PtMiLsoAcntInd */
#endif /* LSO_ACNT */
#endif /* PTSOMILSO */

#ifdef SO_FTHA

/**********************************************************
*
*       Fun:   PtMiShtCntrlCfm
*
*       Desc:  Portable version of ShtCntrlCfm primitive
*
*       Ret:   RFAILED
*
*       Notes: none
*
*       File:  so_ptmi.c
*
**********************************************************/
#ifdef ANSI
PRIVATE S16 PtMiShtCntrlCfm
(
Pst             *pst,            /* post structure */      
ShtCntrlCfmEvnt *cfmInfo         /* system agent control confirm event */
)
#else
PRIVATE S16 PtMiShtCntrlCfm (pst, cfmInfo)
Pst             *pst;            /* post structure */      
ShtCntrlCfmEvnt *cfmInfo;        /* system agent control confirm event */
#endif
{
   TRC3(PtMiShtCntrlCfm)

   SOLOGINVSEL;   
   UNUSED(pst);
   UNUSED(cfmInfo);

   RETVALUE(RFAILED);
} /* PtMiShtCntrlCfm */
#endif /* SO_FTHA */


/********************************************************************30**

         End of file:     so_ptmi.c@@/main/4 - Tue Apr 20 12:46:55 2004

*********************************************************************31*/

/********************************************************************40**

        notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        revision history:

*********************************************************************61*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---     ms   1. initial release.
*********************************************************************91*/
