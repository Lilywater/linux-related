/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Transport Layer 

     Type:     C include file

     Desc:     Source Code 

     File:     so_tcm.c

     Sid:      so_tcm.c@@/main/4 - Tue Apr 20 12:47:08 2004

     Prg:      ps

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "cst.h"           /* Compression module defines      */
#include "so.h"            /* SIP layer defines               */
#include "so_trans.h"      /* Transaction module defines      */
#include "so_err.h"        /* SIP error defines               */
#include "so_cm.h"         /* SIP layer utility functions     */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lso.x"           /* Layer management SIP            */
#include "sot.x"           /* SOT interface defines           */
#include "cst.x"           /* Compression Interface defines   */
#include "so_tcm.x"        /* Transport module structures     */
#include "so.x"            /* SIP layer structures            */
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* SIP layer utility functions     */
#include "so_cm.x"         /* SIP layer common functions      */
#include "so_dns.x"        /* SIP DNS library                 */
#include "so_ed.x"         /* Encode/Decode library           */



/*------------------ Private functions  ----------------------*/

PRIVATE S16 soTptHandleReqInd  ARGS ((
                                 SoEntCb       *entCb,
                                 SoEvnt        *request,
                                 SoTptServerCb *serverCb,
                                 SoTptClientCb *clientCb,
                                 CmTptAddr     *srcAddr ));

PRIVATE S16 soTptHandleRspInd  ARGS ((
                                 SoEntCb       *entCb,
                                 SoEvnt        *response,
                                 SoTptServerCb *serverCb,
                                 SoTptClientCb *clientCb ));

PRIVATE S16 soPrcUpdateTcmConnServer  ARGS ((
                                 SoTcmConn     *tcmConn,
                                 SoTptServerCb *serverCb ));

PRIVATE S16 soPrcUpdateTcmConnClient  ARGS ((
                                 SoTcmConn     *tcmConn,
                                 SoTptClientCb *clientCb ));

PRIVATE S16 soTptUpdateViaHeader  ARGS ((
                                 SoEntCb       *entCb,
                                 SoSSapCb      *sSapCb,
                                 SoEvnt        *request,
                                 CmTptAddr     *destAddr,
                                 U8            transport,
                                 TknStrOSXL    *branchId,
                                 SoTptServerCb **serverCb,
                                 SoTptClientCb **clientCb ));

PRIVATE SoViaItem *soTptViaValidateAndSelConn  ARGS ((
                                 SoEntCb       *entCb,
                                 SoVia         *via,
                                 CmTptAddr     *destAddr,
                                 U8            transport,
                                 SoTptServerCb **serverCb,
                                 SoTptClientCb **clientCb ));

PRIVATE S16 soTptAddBranchIdInVIA  ARGS ((
                                 SoViaItem     *viaItem,
                                 TknStrOSXL    *branchId,
                                 SoEvnt        *request ));

PRIVATE S16 soTptSelectClientForRsp  ARGS ((
                                 SoEntCb       *entCb,
                                 SoSSapCb      *sSapCb,
                                 SoVia         *via,
                                 SoTcmConn     *tcmConn,
                                 CmTptAddr     *destAddr,
                                 SoTptServerCb **serverCb,
                                 SoTptClientCb **clientCb ));

PRIVATE S16 soTptGetDestAddrFromVia  ARGS ((
                                 SoViaItem   *viaItem,
                                 CmTptAddr   *destAddr ));

PRIVATE S16 soTptAddReceivedParamToVia  ARGS ((
                                 SoEvnt        *request,
                                 SoVia         *via,
                                 SoTcmConn     *tcmConn,
                                 CmTptAddr     *srcAddr ));

PRIVATE S16 soTptAllocClientConnId  ARGS ((
                                 SoTSapCb  *tsapCb,
                                 UConnId   *clientConnId ));

/* so027.201: Changes for SIP TLS support */
#ifdef SO_TLS
PRIVATE S16 soTptOpenClient  ARGS ((
                                 SoEntCb       *entCb,
                                 SoSSapCb      *ssapCb,
                                 SoTptServerCb *serverCb,
                                 CmTptAddr     *destAddr,
                                 U8            transport,
                                 SoTptClientCb **clientCb ));
#else
PRIVATE S16 soTptOpenClient  ARGS ((
                                 SoEntCb       *entCb,
                                 SoTptServerCb *serverCb,
                                 CmTptAddr     *destAddr,
                                 U8            transport,
                                 SoTptClientCb **clientCb ));
#endif

PRIVATE S16 soTptDelAllClientContext  ARGS ((
                                 SoTptClientCb *clientCb,
                                 Bool          informUser));

/*so036.201: Changes for CALEA */
#ifdef SO_CALEA
PRIVATE S16 soTptSendMsg  ARGS ((
                                 SoTptServerCb  *serverCb,
                                 SoTptClientCb  *clientCb,
                                 CmTptAddr      *destAddr,
                                 Bool           sigCompSupp,
                                 SoLeaUserCtxt  *leaCtxt,
                                 Buffer         *mBuf ));
#else
PRIVATE S16 soTptSendMsg  ARGS ((
                                 SoTptServerCb  *serverCb,
                                 SoTptClientCb  *clientCb,
                                 CmTptAddr      *destAddr,
                                 Bool           sigCompSupp,
                                 Buffer         *mBuf ));
#endif

#ifdef SO_COMPRESS
PRIVATE S16 soTptSendMsgToCompressor  ARGS ((
                                 SoTptServerCb  *serverCb,
                                 SoTptClientCb  *clientCb,
                                 CmTptAddr      *destAddr,
                                 Buffer         *mBuf ));
#endif

PRIVATE S16 soTptUdpServerDatReq  ARGS ((
                                 SoTptServerCb  *serverCb,
                                 CmTptAddr      *destAddr,
                                 Buffer         *mBuf ));

#ifndef SO_USE_UDP_SRVR 
PRIVATE S16 soTptUdpClientDatReq  ARGS ((
                                 SoTptClientCb  *clientCb,
                                 Buffer         *mBuf ));
#endif

PRIVATE S16 soTptTcpClientDatReq  ARGS ((
                                 SoTptClientCb  *clientCb,
                                 Buffer         *mBuf ));

PRIVATE S16  soTptEncodeMsg  ARGS ((
                                 SoEntCb      *entCb,
                                 SoSSapCb     *sSapCb,
                                 U8           type, 
                                 SoEvnt       *evnt,
                                 CmTptAddr    *destAddr,
                                 TknStrOSXL   *branchId,
                                 Bool         modifyTransport,
                                 SoTcmConn    *tcmConn,
                                 Buffer       **mBuf));

PRIVATE S16 soTptDecodeMsg   ARGS ((
                                 SoEntCb       *entCb,
                                 SoTptServerCb *serverCb,
                                 SoTptClientCb *clientCb,
                                 CmTptAddr     *srcAddr,
                                 Buffer        **mBuf,
                                 SoEvnt        **soEvnt));

PRIVATE S16 soTptMergeStream  ARGS ((
                                 SoTptClientCb *clientCb,
                                 Buffer        *mBuf));

#ifdef SO_COMPRESS
PRIVATE S16 soTptChkNextHopCompSupp ARGS((
                                 SoEntCb       *entCb,
                                 SoEvnt        *request));
                                 
PRIVATE S16 soTptChkPrevHopCompSupp ARGS((
                                 SoEntCb       *entCb,
                                 SoVia         *via));

PRIVATE S16 soTptAddCompSupport   ARGS ((
                                 SoEntCb       *entCb,
                                 SoViaItem     *viaItem,
                                 SoEvnt        *request ));
#endif

#ifdef SO_NAT
PRIVATE S16 soTptAddRportInVIA ARGS ((
                                 SoViaItem     *viaItem, 
                                 SoEvnt        *request));
#endif

#ifdef SO_CALEA

#define SO_GET_CONNECTION_ID(_spConnId, _suConnId, _tcmConn)      \
{                                                                 \
      (_spConnId)    = 0;                                         \
      (_suConnId)    = 0;                                         \
                                                                  \
      if ((_tcmConn)->tcmConnType == SO_TPT_TCMCONN_USER_TRANS)   \
      {                                                           \
        /*-- Get call connection identifier using transCb --*/    \
         SoTransCb  *_tCb = ((SoTransCb *)(_tcmConn)->residePtr); \
         if ((_tCb)->cLeg != NULLP)                               \
         {                                                        \
            SoCLegCb  *_cCb = ((SoCLegCb *)(_tCb)->cLeg);         \
            (_spConnId)     = (_cCb)->call->spConnId;             \
            (_suConnId)     = (_cCb)->userConnId;                 \
         }                                                        \
      }                                                           \
                                                                  \
      if ((_tcmConn)->tcmConnType == SO_TPT_TCMCONN_USER_DIALOG)  \
      {                                                           \
        /*-- Get call connection identifier using cLegCb  --*/    \
         SoCLegCb *_cCb = ((SoCLegCb *)(_tcmConn)->residePtr);    \
         (_spConnId)    = (_cCb)->call->spConnId;                 \
         (_suConnId)    = (_cCb)->userConnId;                     \
      }                                                           \
}

#define SO_FILL_LEA_CTXT(_lc, _ssap, _spConnId, _suConnId, _evnt) \
{                                                                 \
   (_lc)->sSapCb           = _ssap;                               \
   (_lc)->spConnId         = _spConnId;                           \
   (_lc)->suConnId         = _suConnId;                           \
   (_lc)->transId          = _evnt->transId;                      \
   (_lc)->callLegId        = _evnt->callLegId;                    \
   (_lc)->messageId        = _evnt->messageId;                    \
   (_lc)->eventType        = _evnt->eventType.val;                \
   (_lc)->sipMessageType   = _evnt->sipMessageType.val;           \
}
#endif


/*******************************************************************
*
*       Fun:   soTptSendInitialReq
*
*       Notes: This function is  invoked by user to send initial(i.e
*              not encoded) SIP request message. 
*
*              tcmConn  structure provided MUST be  part of the user
*              control block (e.g, transCb->tcmConn etc).
*
*              Caller can provide branchId as  NULLP if there  is no
*              need to add branchId in TOP VIA element (like ACK for
*              2XX response).
*
*              IMP: Both branchId and tcmConn should NOT be from st-
*                   ack. They should be part of control block.  This
*                   requirement comes due to multithreaded encoder.
*
*       Ret:   ROK on success. In this case mBuf will point to enco-
*              ded request message. tcmConn will contain information
*              of client and server connection used to send this re-
*              quest.
*
*              SO_TPT_TRANSPORT_CHANGED. This return value, in addi-
*              tion to success, indicates that transport was changed
*              from UDP to TCP due to message size constraints. Cal-
*              ler should take appropriate action, if required.
*             
*              SO_TPT_MULTI_THREADED_ENC if multithreaded encoder is
*              used. In this case mBuf is not updated.
*              
*              If failure, return SIP user related error code.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC S16 soTptSendInitialReq
(
SoEntCb      *entCb,     /* Entity Control Block                        */
SoSSapCb     *sSapCb,    /* Service User SAP Cb                         */
CmTptAddr    *destAddr,  /* Destination IP-address/port to send request */
U8           transport,  /* transport portocol is UDP or TCP            */
SoEvnt       *request,   /* SIP Request message to be sent              */
Bool         modifyTransport,  /* Switch to TCP for larger messages     */
TknStrOSXL   *branchId,  /* Branch Id to be added in VIA item           */
SoTcmConn    *tcmConn,   /* TCP/UDP connection information  (Updated)   */
Buffer       **mBuf      /* Encoded Request Message         (Updated)   */
)
#else
PUBLIC S16 soTptSendInitialReq (entCb, sSapCb,  destAddr, transport,
                                request, modifyTransport, branchId,
                                tcmConn, mBuf)
SoEntCb      *entCb;     /* Entity Control Block                        */
SoSSapCb     *sSapCb;    /* Service User SAP Cb                         */
CmTptAddr    *destAddr;  /* Destination IP-address/port to send request */
U8           transport;  /* transport portocol is UDP or TCP            */
SoEvnt       *request;   /* SIP Request message to be sent              */
Bool         modifyTransport;  /* Switch to TCP for larger messages     */
TknStrOSXL   *branchId;  /* Branch Id to be added in VIA item           */
SoTcmConn    *tcmConn;   /* TCP/UDP connection information  (Updated)   */
Buffer       **mBuf;     /* Encoded Request Message         (Updated)   */
#endif
{
   S16             ret;
   MsgLen          msgLen;
   U16             mtu;
   SoTptServerCb   *serverCb;
   SoTptClientCb   *clientCb;
#ifdef SO_CALEA
   SoLeaUserCtxt   leaCtxt;
   SoLeaUserCtxt   *leaCtxtPtr;
   UConnId         suConnId;
   UConnId         spConnId;
#endif

   TRC2(soTptSendInitialReq);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (entCb && sSapCb && destAddr && request && tcmConn && mBuf))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO161, (ErrVal) 0, "soTptSendInitialReq: "
                 "Invalid parameter");
      RETVALUE (SOT_ERR_UNKNOWN);
    }
#endif

    (*mBuf) = NULLP;

   /*
    * STEP 1:
    * Update VIA header in message. For VIA updation, we need  to first
    * select server and client connection. This is because sent-by fie-
    * ld in VIA will contains server address.
    * Also since we try to reuse any  existing client connection, first
    * find such connection as it will provide  server connection  also.
    */
    ret = soTptUpdateViaHeader (entCb,/* Entity Control block       */
                           sSapCb,    /* Service user SAP Cb        */
                           request,   /* Request msg                */
                           destAddr,  /* Remote Address and port    */
                           transport, /* TCP or UDP                 */
                           branchId,  /* BranchId to be added in VIA*/
                           &serverCb, /* Selected Server Connection */
                           &clientCb  /* Selected Client Connection */
                    );
    if (ret != ROK)
      RETVALUE (ret);

   /*
    * STEP 2:
    * Above  step will  also select client and server connection to be 
    * used. Now, insert tcmConn in ServerCb and ClientCb linklist.This
    * will result in mapping  between clienCb/serverCb and all users (
    * transCb/cLegCb) using this clientCb/serverCb.  This mapping will
    * be used in case the client/server connection terminates.
    */
    soPrcUpdateTcmConn (tcmConn, clientCb, serverCb);

#if SO_COMPRESS
    /*--- Check If next hop node supports signalling compression ---*/
    tcmConn->sigCompSupp = soTptChkNextHopCompSupp (entCb, request); 
#else
    tcmConn->sigCompSupp = FALSE;
#endif

   /*
    * STEP 3:
    * ENCODE the request message.If Multithreaded encoder is used, en-
    * coding will NOT be finished.
    */
    ret = soTptEncodeMsg (entCb, sSapCb,
                          SO_TPT_REQUEST, /* Encode request */
                          request, /* Request to be encoded */
                          destAddr,
                          branchId,
                          modifyTransport,
                          tcmConn, /* selected client/server*/
                          mBuf);   /* Encoded Message       */
    if (ret == SO_TPT_MULTI_THREADED_ENC)
       RETVALUE (ret);

    else if (ret != ROK)
       RETVALUE (SOT_ERR_UNKNOWN);

   /*
    * STEP 4:
    * If UDP is used, check if we need to switch to TCP  due to  large
    * essage size constraint.
    */
    mtu = soCb.cfg.mtu;
    (Void) SFndLenMsg ((*mBuf), &msgLen);

    if ((transport == LSO_TPTPROT_UDP) &&  /* Trasport is UDP      */
        (modifyTransport)              &&  /* Can modify transport */
        (msgLen > (mtu - 200)))/* Msg Size within 200 bytes of MTU */
    {
         /*------- First deallocate message buffer --------*/
         (Void) SPutMsg (*mBuf);

         /*-------- Delete TOP VIA header element ---------*/
         (Void) soUtlDelTopViaElement (request);

         /*--- Send request message using new transport ---*/
         ret = soTptSendInitialReq (entCb, sSapCb, destAddr,
                                    LSO_TPTPROT_TCP,
                                    request,  FALSE, 
                                    branchId, tcmConn, 
                                    mBuf);
         /*
          * NOTE: Passing modifyTransport as  FALSE in above  function
          *       should stop the recursion.
          */
         if (ret == ROK)
           /*
            * Inform user  that everything  is O.K  but transport  was
            * changed.
            */
           RETVALUE (SO_TPT_TRANSPORT_CHANGED);

         else
           RETVALUE (ret);
    } /* End of if (transport change is required) */
         
        
   /*------------ STEP 5:  Send the request message ----------------*/

#ifdef SO_CALEA

   /*------------ so037.201: Check for SSAP Validity. --------------*/

    leaCtxtPtr = NULLP;

    if (sSapCb)
    {
       SO_GET_CONNECTION_ID (spConnId, suConnId, tcmConn);
       
       SO_FILL_LEA_CTXT (&leaCtxt, sSapCb, spConnId, suConnId, request)
      
       leaCtxtPtr  = &leaCtxt;
    }
                        
    ret = soTptSendMsg (serverCb, clientCb, destAddr,
                        tcmConn->sigCompSupp, leaCtxtPtr, *mBuf);
#else
    ret = soTptSendMsg (serverCb, clientCb, destAddr,
                        tcmConn->sigCompSupp, *mBuf);
#endif
    if (ret != ROK)
    {
       (Void) SPutMsg (*mBuf); *mBuf = NULLP;
       RETVALUE (SOT_ERR_UNKNOWN);
    }

   RETVALUE (ROK);

} /* soTptSendInitialReq */




/*******************************************************************
*
*       Fun:   soTptEncodeReqCallBack
*
*       Notes: This function is invoked only in case of Multithread-
*              ed encoder. It will be invoked when mutithreaded enc-
*              oder returns after encoding SIP request message.
*              This function invokes user specific callback function
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC S16 soTptEncodeReqCallBack
(
SoEntCb       *entCb,     /* Entity Control Block                        */
SoSSapCb      *sSapCb,    /* Service User SAP Cb                         */
Bool          success,    /* Encoding successful or failure              */
CmTptAddr     *destAddr,  /* Destination IP-address/port to send request */
SoEvnt        *request,   /* SIP Request message to be sent              */
Bool          modifyTransport,  /* Switch to TCP for larger messages     */
TknStrOSXL    *branchId,  /* Branch Id to be added in VIA item           */
SoTcmConn     *tcmConn,   /* Selected client/server connection           */
Buffer        *mBuf       /* Encoded Request Message                     */
)
#else
PUBLIC S16 soTptEncodeReqCallBack (entCb, sSapCb,  success,  destAddr, 
                                   request, modifyTransport, branchId,
                                   tcmConn, mBuf)
SoEntCb       *entCb;     /* Entity Control Block                        */
SoSSapCb      *sSapCb;    /* Service User SAP Cb                         */
Bool          success;    /* Encoding successful or failure              */
CmTptAddr     *destAddr;  /* Destination IP-address/port to send request */
SoEvnt        *request;   /* SIP Request message to be sent              */
Bool          modifyTransport;  /* Switch to TCP for larger messages     */
TknStrOSXL    *branchId;  /* Branch Id to be added in VIA item           */
SoTcmConn     *tcmConn;   /* Selected client/server connection           */
Buffer        *mBuf;      /* Encoded Request Message                     */
#endif
{
   S16          ret;
   MsgLen       msgLen;
   U16          mtu;
   U8           transport;
#ifdef SO_CALEA
   SoLeaUserCtxt   leaCtxt;
   SoLeaUserCtxt   *leaCtxtPtr;
   UConnId         suConnId;
   UConnId         spConnId;
#endif

   TRC2(soTptEncodeReqCallBack);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (entCb && destAddr && request && tcmConn))
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO162, (ErrVal) 0, "soTptEncodeReqCallBack:"
                 " Invalid parameter");
      RETVALUE (RFAILED);
    }

    if ((success) && (mBuf == NULLP))
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO163, (ErrVal) 0, "soTptEncodeReqCallBack:"
                 " Invalid mBuf parameter");
      RETVALUE (RFAILED);
    }
#endif

    transport = tcmConn->serverCb->tptProt;

   /*
    * STEP 1:
    * If encoding was successful and UDP is used, check if we need to
    * switch to TCP due to large message size constraint.
    */
    mtu    = soCb.cfg.mtu;
    msgLen = 0;
    if (mBuf) (Void) SFndLenMsg (mBuf, &msgLen);

    if ((success)                      &&/* Successful encoding    */
        (transport == LSO_TPTPROT_UDP) &&/* Trasport is UDP        */
        (modifyTransport)              &&/* Can modify transport   */
        (msgLen > (mtu - 200)))/* Msg Size within 200 bytes of MTU */
    {
         /*------- First deallocate message buffer --------*/
         (Void) SPutMsg (mBuf); mBuf = NULLP;

         /*-------- Delete TOP VIA header element ---------*/
         (Void) soUtlDelTopViaElement (request);

         ret = soTptSendInitialReq (entCb,  sSapCb,
                                    destAddr,
                                    LSO_TPTPROT_TCP,
                                    request, FALSE, 
                                    branchId,tcmConn, 
                                    &mBuf);
         /*
          * NOTE: Passing modifyTransport as  FALSE in above  function
          *       should stop the recursion.
          *       Also it is O.K to pass mBuf from stack as for multi-
          *       threaded encoder, user will get mBuf in call back f-
          *       unction only.
          */
         if (ret == SO_TPT_MULTI_THREADED_ENC)
           /*------ This must be true ------*/
           RETVALUE (ROK);
         else
         {
           /*
            * All failures should be indicated to user in callback fn.
            */
           (Void) SPutMsg (mBuf);
           success = FALSE;
         }
    } /* End of if (transport change is required)      */
    
   /*---------------- NO Transport change required -----------------*/
    else if (success)
    {
        /*- STEP 2: For successful encoding, send request message --*/

#ifdef SO_CALEA

      /*----------- so037.201: Check for SSAP Validity. ------------*/

       leaCtxtPtr = NULLP;

       if (sSapCb)
       {
          SO_GET_CONNECTION_ID (spConnId, suConnId, tcmConn);
          
          SO_FILL_LEA_CTXT (&leaCtxt, sSapCb, spConnId, suConnId, request);
      
          leaCtxtPtr  = &leaCtxt;
       }
          
       ret = soTptSendMsg (tcmConn->serverCb, tcmConn->clientCb,
                           destAddr, tcmConn->sigCompSupp,
                           leaCtxtPtr, mBuf);
#else
       ret = soTptSendMsg (tcmConn->serverCb, tcmConn->clientCb,
                           destAddr, tcmConn->sigCompSupp, mBuf);
#endif
         if (ret != ROK)
         {
           /*
            * Although Message could NOT be sent,  we  need  to inform
            * user anyways.
            */
            (Void) SPutMsg (mBuf);
            success = FALSE;
         }
    } /* End of else (no transport change is required) */

#ifdef SO_UA

   /*------ Inform user whether encoding was successful or not -----*/
    if (tcmConn->tcmConnType == SO_TPT_TCMCONN_USER_TRANS)
    {
       /*-- Transport layer is user --*/
       /*
        * This  fn must deallocate mBuf
        * if not required.
        */
       (Void) soTxnEncodeReqCallBack (tcmConn->residePtr,
                                      transport,
                                      mBuf,
                                      success);
    }

    else if (tcmConn->tcmConnType == SO_TPT_TCMCONN_USER_DIALOG)
    {
       /*--- Dialog layer is user ----*/
       /*
        * This  fn must deallocate mBuf
        * if not required.
        */
       (Void) soDlgEncodeReqCallBack (tcmConn->residePtr,
                                      request,
                                      transport,
                                      mBuf,
                                      success);
    }
    else 
#endif
    {
      /*- No one to pass the result --*/
      if (mBuf) (Void) SPutMsg (mBuf);
      (Void) soCmFreeEvent (request);
    }

   RETVALUE (ret);

} /* soTptEncodeReqCallBack */




/*******************************************************************
*
*       Fun:   soTptSendReTransReq
*
*       Notes: This function is  invoked by user  for retransmitting
*              SIP request message. User MUST pass  valid mBuf  that
*              will contain the encoded message.
*              User MUST pass valid tcmConn  structure that contains
*              pointer to client and server connection  used to sent
*              initial request message. Please note that tcmConn MU-
*              ST contain valid server connection used to send inti-
*              al request message (client connection may  be NULLP).
*
*              tcmConn  structure provided MUST be  part of the user
*              control block (e.g, transCb->tcmConn etc).
*
*       Ret:   ROK on success. In this case tcmConn will contain up-
*              dated information regarding client connection used to
*              send this message.
*
*              SOT_ERR_UNKNOWN on error
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC S16 soTptSendReTransReq
(
SoEntCb      *entCb,     /* Entity Control Block                        */
CmTptAddr    *destAddr,  /* Destination IP-address/port to send request */
SoTcmConn    *tcmConn,   /* TCP/UDP connection information (Updated)    */
Buffer       *mBuf       /* Encoded Request Message                     */
)
#else
PUBLIC S16 soTptSendReTransReq (entCb, destAddr, tcmConn, mBuf)
SoEntCb      *entCb;     /* Entity Control Block                        */
CmTptAddr    *destAddr;  /* Destination IP-address/port to send request */
SoTcmConn    *tcmConn;   /* TCP/UDP connection information (Updated)    */
Buffer       *mBuf;      /* Encoded Request Message                     */
#endif
{
   S16             ret;
   SoTptClientCb   *clientCb;

   TRC2(soTptSendReTransReq);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (entCb && destAddr && tcmConn && mBuf))
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO164, (ErrVal) 0, "soTptSendReTransReq: "
                 "Invalid parameter");
      RETVALUE (SOT_ERR_UNKNOWN);
    }
#endif

   /*- For retransmission, original server connection must be valid -*/
    if (tcmConn->serverCb == NULLP)
    {
        SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
               "\nsoTptSendReTransReq: No Server Connection \n"));

        RETVALUE (SOT_ERR_UNKNOWN);
    }

   /*
    * STEP 1:
    * Check if the client connection specified by user in tcmConn is s-
    * till active. If yes, use the connection to send the retransmitted
    * request.
    */
    if ((tcmConn->clientCb) &&
        (tcmConn->clientCb->state == SO_TPT_CLIENT_ACTIVE))
    {
#ifdef SO_CALEA
       ret = soTptSendMsg (tcmConn->serverCb, tcmConn->clientCb,
                           destAddr, tcmConn->sigCompSupp,
                           NULLP, mBuf);
#else
       ret = soTptSendMsg (tcmConn->serverCb, tcmConn->clientCb,
                           destAddr, tcmConn->sigCompSupp, mBuf);
#endif
       if (ret != ROK)
        RETVALUE (SOT_ERR_UNKNOWN);

       /*---- We are done now ---*/
       RETVALUE (ROK);
    }

   /*
    * STEP 2:
    * Since the original client connection  is no longer active, open a
    * new client connection. 
    * NOTE: sent-by address in VIA indicates the server connection used
    *       to send original request (it is this server connection peer
    *       will use to sent response back). So when we open new client
    *       connection here, we must use the same old server connection.
    */
   /* so027.201: Changes for SIP TLS support */
    ret = soTptOpenClient (entCb,
#ifdef SO_TLS
                           NULLP,
#endif
                           tcmConn->serverCb,/* original Server Conn */
                           destAddr,         /* Remote address       */
                           tcmConn->serverCb->tptProt,/* TCP or UDP  */
                           &clientCb         /* New Client Connection*/
                          );
    if (ret != ROK)
       RETVALUE (SOT_ERR_UNKNOWN);

    /*--------- Insert tcmConn in the new clientCb link list --------*/
     soPrcUpdateTcmConn (tcmConn, clientCb, tcmConn->serverCb);

   /*------ STEP 3:  Finally, send request on new connection --------*/
#ifdef SO_CALEA
    ret = soTptSendMsg (tcmConn->serverCb, tcmConn->clientCb,
                        destAddr, tcmConn->sigCompSupp,
                        NULLP, mBuf);
#else
    ret = soTptSendMsg (tcmConn->serverCb, tcmConn->clientCb,
                        destAddr, tcmConn->sigCompSupp, mBuf);
#endif
    if (ret != ROK)
       RETVALUE (SOT_ERR_UNKNOWN);

   RETVALUE (ROK);

} /* soTptSendReTransReq */




/*******************************************************************
*
*       Fun:   soTptSendRsp
*
*       Notes: This function is invoked by user for sending both in-
*              itial (valid response pointer) and retransmitted (va-
*              lid mBuf pointer)  SIP response message.  For initial
*              response user must pass valid response pointer and f-
*              or retransmitted request user must pass valid mBuf p-
*              ointer.
*
*              Please note that tcmConn MUST contain valid server c-
*              onnection on which request wass received. This requi-
*              rement comes due to UDP  transport where this  server
*              connection will be used to send response  (no need to
*              select new server connection).
*
*              For  retransmitted  response  user  can  pass tcmConn
*              structure that contains pointer to  client connection
*              used on which request was received (or previous resp-
*              onse message was sent).
*
*              User MUST provide VIA received in request  message as
*              it will used to select transport client connection.
*
*              tcmConn  structure provided MUST be  part of the user
*              control block (e.g, transCb->tcmConn etc).
*
*       Ret:   ROK on success. In this case tcmConn will contain up-
*              dated information regarding client connection used to
*              send this message.
*
*              SO_TPT_MULTI_THREADED_ENC if multithreaded encoder is
*              used. In this case mBuf is not updated.
*              
*              If failure, return SIP user related error code.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC S16 soTptSendRsp
(
SoEntCb      *entCb,     /* Entity Control Block                        */
SoSSapCb     *sSapCb,    /* Service User SAP Cb                         */
SoVia        *via,       /* VIA header of corresponding request message */
SoEvnt       *response,  /* SIP Response message to be sent             */
Buffer       **mBuf,     /* Encoded response Message                    */
SoTcmConn    *tcmConn    /* TCP/UDP connection information (Updated)    */
)
#else
PUBLIC S16 soTptSendRsp (entCb, sSapCb, via, response, mBuf, tcmConn)
SoEntCb      *entCb;     /* Entity Control Block                        */
SoSSapCb     *sSapCb;    /* Service User SAP Cb                         */
SoVia        *via;       /* VIA header of corresponding request message */
SoEvnt       *response;  /* SIP Response message to be sent             */
Buffer       **mBuf;     /* Encoded response Message                    */
SoTcmConn    *tcmConn;   /* TCP/UDP connection information (Updated)    */
#endif
{
   S16             ret;
   CmTptAddr       destAddr;
   SoTptServerCb   *serverCb;
   SoTptClientCb   *clientCb;
#ifdef SO_CALEA
   SoLeaUserCtxt   leaCtxt;
   SoLeaUserCtxt   *leaCtxtPtr;
   UConnId         suConnId;
   UConnId         spConnId;
#endif

   TRC2(soTptSendRsp);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (entCb && via && tcmConn))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO165, (ErrVal) 0, "soTptSendRsp: "
                 "Invalid parameter");
      RETVALUE (SOT_ERR_UNKNOWN);
    }
    if (! (response || *mBuf))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO166, (ErrVal) 0, "soTptSendRsp: "
                 "Both response and mBuf are NULLP");
      RETVALUE (SOT_ERR_UNKNOWN);
    }
#endif

   /*
    * STEP 1:
    * Add VIA Header in  the response  message (if not already present)
    */
    if (response)
      SO_TXN_ADD_VIA_IN_EVENT (response, via);

   /*
    * STEP 2:
    * Select Client connection  that will be used for sending  response
    */
    ret = soTptSelectClientForRsp (entCb,     /* Entity Control Block*/
                                   sSapCb,    /* Service User SAP    */
                                   via,       /* VIA in request msg  */
                                   tcmConn,   /* current conn used   */
                                   &destAddr, /* destination address */
                                   &serverCb, /* selected server conn*/
                                   &clientCb);/* selected client conn*/ 
    if (ret != ROK)
       RETVALUE (ret);
 
   /*
    * STEP 3:
    * Now  insert  tcmConn in  ServerCb  and  ClientCb  linklist. This
    * will result in mapping  between clienCb/serverCb and all users (
    * transCb/cLegCb) using this clientCb/serverCb.  This mapping will
    * be used in case the client/server connection terminates.
    */
    soPrcUpdateTcmConn (tcmConn, clientCb, serverCb);

#ifdef SO_COMPRESS
    /*- Check If previous hop node supports signalling compression -*/
    tcmConn->sigCompSupp = soTptChkPrevHopCompSupp (entCb, via);
#else
    tcmConn->sigCompSupp = FALSE;
#endif

   /*
    * STEP 4:
    * If NOT already done (first response), ENCODE response message.If
    * Multithreaded encoder is used, encoding will NOT be finished.
    */
    if (response != NULLP) /* First Response */
    {
       ret = soTptEncodeMsg (entCb, sSapCb,
                             SO_TPT_RESPONSE, /* Encode response*/
                             response, /* Response to be encoded*/
                             &destAddr,/* destination address   */
                             NULLP,    /* branchId not used     */
                             FALSE,    /* Param NOT Used        */
                             tcmConn,  /* selected client/server*/
                             mBuf);    /* Encoded Message       */
       if (ret == SO_TPT_MULTI_THREADED_ENC)
          RETVALUE (ret);

       else if (ret != ROK)
          RETVALUE (SOT_ERR_UNKNOWN);
    }

   /*------------ STEP 5:  Send the response message ---------------*/

#ifdef SO_CALEA
   /*--------- If response is NULLP => retransmitted message -------*/
   /*------------- so037.201: Check for SSAP Validity. -------------*/

    leaCtxtPtr = NULLP;

    if ((response != NULLP) && (sSapCb))
    {
       SO_GET_CONNECTION_ID (spConnId, suConnId, tcmConn);

       SO_FILL_LEA_CTXT (&leaCtxt, sSapCb, spConnId, suConnId, response);

       leaCtxtPtr = &leaCtxt;
    }
    ret = soTptSendMsg (serverCb, clientCb, &destAddr,
                        tcmConn->sigCompSupp, leaCtxtPtr, (*mBuf));
#else
    ret = soTptSendMsg (serverCb, clientCb, &destAddr,
                        tcmConn->sigCompSupp, (*mBuf));
#endif
       if (ret != ROK)
       RETVALUE (SOT_ERR_UNKNOWN);

    RETVALUE(ROK);

} /* soTptSendRsp */




/*******************************************************************
*
*       Fun:   soTptEncodeRspCallBack
*
*       Notes: This function is invoked only in case of Multithread-
*              ed encoder. It will be invoked when mutithreaded enc-
*              oder returns after encoding SIP response message.
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC S16 soTptEncodeRspCallBack
(
SoEntCb       *entCb,     /* Entity Control Block                        */
SoEvnt        *response,  /* Response event                              */
Bool          success,    /* Encoding successful or failure              */
CmTptAddr     *destAddr,  /* Destination IP-address/port to send response*/
SoTcmConn     *tcmConn,   /* Selected client/server connection           */
Buffer        *mBuf       /* Encoded Response Message                    */
)
#else
PUBLIC S16 soTptEncodeRspCallBack (entCb, response, success, destAddr, tcmConn, mBuf)
SoEntCb       *entCb;     /* Entity Control Block                        */
SoEvnt        *response;  /* Response event                              */
Bool          success;    /* Encoding successful or failure              */
CmTptAddr     *destAddr;  /* Destination IP-address/port to send response*/
SoTcmConn     *tcmConn;   /* Selected client/server connection           */
Buffer        *mBuf;      /* Encoded Request Message                     */
#endif
{
   S16             ret;
#ifdef SO_CALEA
   SoSSapCb        *ssap;
   SoLeaUserCtxt   leaCtxt;
   UConnId         suConnId;
   UConnId         spConnId;
#endif

   TRC2(soTptEncodeRspCallBack);

#if (ERRCLASS & ERRCLS_DEBUG)
    if ((tcmConn == NULLP) ||
        ((success) && (mBuf == NULLP)))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO167, (ErrVal) 0, "soTptEncodeRspCallBack: "
                 "Invalid parameter");
      RETVALUE (RFAILED);
    }

#endif

   /*-- STEP 1: If encoding was successful, send response message --*/
    if (success)
    {
#ifdef SO_CALEA
      ssap = NULLP;

      (Void) soCmFindSSap (&ssap, tcmConn->serverCb);

       SO_GET_CONNECTION_ID (spConnId, suConnId, tcmConn);

       SO_FILL_LEA_CTXT (&leaCtxt, ssap, spConnId, suConnId, response);

       ret = soTptSendMsg (tcmConn->serverCb, tcmConn->clientCb,
                          destAddr, tcmConn->sigCompSupp,
                          &leaCtxt, mBuf);
#else
       ret = soTptSendMsg (tcmConn->serverCb, tcmConn->clientCb,
                          destAddr, tcmConn->sigCompSupp, mBuf);
#endif
      if (ret != ROK)
      {
         /*
          * Although Message could NOT be sent, we need to inform user
          * anyways.
          */
          (Void) SPutMsg (mBuf);
          success = FALSE;
      }
    }

#ifdef SO_UA 
   /*------ Inform user whether encoding was successful or not -----*/
    if (tcmConn->tcmConnType == SO_TPT_TCMCONN_USER_TRANS)
    {
       /*- Transaction layer is user -*/
       /*
        * This  fn must deallocate mBuf
        * and event  if  not  required.
        */
       (Void) soTxnEncodeRspCallBack (tcmConn->residePtr,/* TCB     */
                                      response, /* Response event   */
                                      mBuf,     /* Encoded Response */
                                      success);
    }
    else
#endif
    {
      /*- No one to pass the result --*/
      if (mBuf) (Void) SPutMsg (mBuf);
    }

   RETVALUE (ROK);

} /* soTptEncodeRspCallBack */



/*******************************************************************
*
*       Fun:   soTptGetMsg
*
*       Notes: This function handles message received from peer node.
*              It decodes message and pass request/response to appr-
*              opriate transaction or dialog layer entity.
*
*       Ret:   ROK on success.
*
*              SO_TPT_MULTI_THREADED_DEC, if multithreaded encoder is
*              used.
*              
*              RFAILED on error.
*
*       Note:  This function is also responsible for deallocating m-
*              essage buffer.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC S16 soTptGetMsg
(
SoEntCb       *entCb,     /* Entity Control Block                     */
SoTptServerCb *serverCb,  /* Server connection that received message  */
SoTptClientCb *clientCb,  /* Client connection (For TCP Only)         */
CmTptAddr     *srcAddr,   /* Source IP address                        */
Buffer        *mBuf       /* Received message                         */
)
#else
PUBLIC S16 soTptGetMsg (entCb, serverCb, clientCb, srcAddr, mBuf)
SoEntCb       *entCb;     /* Entity Control Block                     */
SoTptServerCb *serverCb;  /* Server connection that received message  */
SoTptClientCb *clientCb;  /* Client connection (For TCP Only)         */
CmTptAddr     *srcAddr;   /* Source IP address                        */
Buffer        *mBuf;      /* Received message                         */
#endif
{
   S16      ret;
   SoEvnt   *evnt;
   MsgLen   msgLen;

   TRC2 (soTptGetMsg);

   ret = ROK;
   evnt = NULLP;

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (entCb && serverCb && srcAddr && mBuf))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO168, (ErrVal) 0, "soTptGetMsg: "
                 "Invalid parameter");
      RETVALUE (RFAILED);
    }
#endif

    evnt = NULLP;

   /*--------------- STEP 1: Decode the message --------------------*/

    ret = soTptDecodeMsg (entCb,
                          serverCb,/* Server Connection */
                          clientCb,/* Client Connection */
                          srcAddr, /* Source address    */
                          &mBuf,   /* Encoded Message   */
                          &evnt);  /* Decoded Message   */
                        
    if (ret == SO_TPT_MULTI_THREADED_DEC)
      /*------------ Decoding done by a seperate thread ------------*/
        RETVALUE (ROK);

    else if (ret == SO_TPT_MSG_NOT_COMPLETE)
      /*------------ We Need To Wait For Rest Of Message -----------*/
      RETVALUE (ROK);

    else if (ret != ROK)
    {
       /* so003.201 : Added check to release event in case of failure */
       if (evnt != NULLP)
          (Void) soCmFreeEvent (evnt);
       goto SOTPTGETMSG;
    }

#if 0
   /*-------- STEP 2: Pass RAW SIP Message to SIP Application --------*/
   ret = SAddMsgRef (mBuf, soCb.init.region, soCb.init.pool, &evnt->rawMsg);
   if (ret != ROK)
   {
       SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, "\n[TCM] Cannot Add"
                  "Message Reference For SO_CALEA\n"));
       RETVALUE (RFAILED);
   }
#endif

    if (SO_CMP_TKN_LIT (&evnt->sipMessageType, SO_SIPMESSAGE_REQUEST) == TRUE)
    {
       /*--------- Handle SIP Request Message ----------*/
        ret = soTptHandleReqInd (entCb, evnt, serverCb, clientCb, srcAddr);
    }

    else
    {
       /*--------- Handle SIP Response Message ---------*/
        ret = soTptHandleRspInd (entCb, evnt, serverCb, clientCb);
    }
      
    if (ret != ROK)
    {
       if (SO_CMP_TKN_LIT(&evnt->sipMessageType, SO_SIPMESSAGE_REQUEST) == TRUE)
       {
         SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, "\n[TCM] Request Processing Failed\n"));
       }
       else
       {
         SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, "\n[TCM] Response Processing Failed\n"));
       }

       /*-- Delete Event Structure in case of failure --*/
       (Void) soCmFreeEvent (evnt);
       evnt = NULLP;
    }
   
   /*-- STEP 3: For TCP is there more SIP messages to be decoded! --*/

   /* so027.201: Changes for SIP TLS support */
   if ((clientCb)  && (clientCb->serverCb->tptProt == LSO_TPTPROT_TCP ||
                       clientCb->serverCb->tptProt == LSO_TPTPROT_TLS_TCP))
   {
     ret = SFndLenMsg (mBuf, &msgLen);
     if (ret != ROK)
        goto SOTPTGETMSG;

     if (msgLen != 0)
     {
       /*------------ Recurse To Process Next Message --------------*/
        (Void) soTptGetMsg (entCb, serverCb, clientCb, srcAddr, mBuf);
        RETVALUE (ROK);
     }
   }

  /*-------------- Finally Delete The Message Buffer ---------------*/

SOTPTGETMSG:
   SPutMsg (mBuf);

   RETVALUE (ROK);

} /* soTptGetMsg */



/*******************************************************************
*
*       Fun:   soTptDecodeCallBack
*
*       Notes: This function is invoked only in case of Multithread-
*              ed decoder. It will be invoked when mutithreaded dec-
*              oder returns after decoding SIP message.
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC S16 soTptDecodeCallBack
(
SoEntCb       *entCb,     /* Entity Control Block                     */
Bool          success,    /* Decoding successful or failure           */
SoTptServerCb *serverCb,  /* Server connection that received message  */
SoTptClientCb *clientCb,  /* Client connection (For TCP Only)         */
CmTptAddr     *srcAddr,   /* Source IP address                        */
SoEvnt        *evnt,      /* Decode SIP message                       */
Buffer        *mBuf       /* Received message                         */
)
#else
PUBLIC S16 soTptDecodeCallBack (entCb,   success, serverCb, clientCb, 
                                srcAddr, evnt, mBuf)
SoEntCb       *entCb;     /* Entity Control Block                     */
Bool          success;    /* Decoding successful or failure           */
SoTptServerCb *serverCb;  /* Server connection that received message  */
SoTptClientCb *clientCb;  /* Client connection (For TCP Only)         */
CmTptAddr     *srcAddr;   /* Source IP address                        */
SoEvnt        *evnt;      /* Decode SIP message                       */
Buffer        *mBuf;      /* Received message                         */
#endif
{
   S16      ret;
   MsgLen   msgLen;

   TRC2(soTptDecodeCallBack);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (success && !(entCb && serverCb && srcAddr && evnt))
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO169, (ErrVal) 0, "soTptDecodeCallBack: "
                 "Invalid parameter");
      RETVALUE (RFAILED);
    }

    if (!mBuf)
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO170, (ErrVal) 0, "soTptDecodeCallBack: "
                 "Invalid event parameter");
      RETVALUE (RFAILED);
    }
#endif

   /*----------- If decoding not successful, do noting -------------*/
    if (!success)
        goto SOTPTDECODECALLBACK;

   /*------- STEP 1: Pass SIP Message to appropriate entity --------*/

    if (SO_CMP_TKN_LIT (&evnt->sipMessageType, SO_SIPMESSAGE_REQUEST) == TRUE)
    {
       /*--------- Handle SIP Request Message ----------*/
        ret = soTptHandleReqInd (entCb, evnt, serverCb, clientCb, srcAddr);
    }

    else
    {
       /*--------- Handle SIP Response Message ---------*/
        ret = soTptHandleRspInd (entCb, evnt, serverCb, clientCb);
    }
      
    if (ret != ROK)
    {
       if (SO_CMP_TKN_LIT(&evnt->sipMessageType, SO_SIPMESSAGE_REQUEST) == TRUE)
       {
         SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, "\n[TCM] Request Processing Failed\n"));
       }
       else
       {
         SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, "\n[TCM] Response Processing Failed\n"));
       }

       /*-- Delete Event Structure in case of failure --*/
       (Void) soCmFreeEvent (evnt);
    }

   /*-- STEP 2: For TCP is there more SIP messages to be decoded! --*/

   /* so027.201: Changes for SIP TLS support */
   if ((clientCb)  && (clientCb->serverCb->tptProt == LSO_TPTPROT_TCP ||
                       clientCb->serverCb->tptProt == LSO_TPTPROT_TLS_TCP))
   {
     ret = SFndLenMsg (mBuf, &msgLen);
     if (ret != ROK)
        goto SOTPTDECODECALLBACK;

     if (msgLen != 0)
     {
       /*------------ Recurse To Process Next Message --------------*/
        (Void) soTptGetMsg (entCb, serverCb, clientCb, srcAddr, mBuf);
        RETVALUE (ROK);
     }
   }

  /*-------------- Finally Delete The Message Buffer ---------------*/

SOTPTDECODECALLBACK:
   SPutMsg (mBuf);

   RETVALUE (ROK);

} /* soTptDecodeCallBack */



/*******************************************************************
*
*       Fun:   soPrcUpdateTcmConn
*
*       Notes: This function is used to add context of tcmConn stru-
*              cture to given server and client connection. This fu-
*              nction inserts block containing  tcmConn structure in
*              link list  in server control block and client control
*              block.
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC Void soPrcUpdateTcmConn
(
SoTcmConn     *tcmConn,   /* control block to be inserted in hash list */
SoTptClientCb *clientCb,  /* Client connection                         */
SoTptServerCb *serverCb   /* Server connection                         */
)
#else
PUBLIC Void soPrcUpdateTcmConn (tcmConn, clientCb, serverCb)
SoTcmConn     *tcmConn;   /* control block to be inserted in hash list */
SoTptClientCb *clientCb;  /* Client connection                         */
SoTptServerCb *serverCb;  /* Server connection                         */
#endif
{
   TRC2(soPrcUpdateTcmConn);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (tcmConn))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO171, (ErrVal) 0, "soPrcUpdateTcmConn: "
                 "Invalid parameter");
      RETVOID;
    }
#endif

    if (tcmConn->tcmConnType == SO_UNKNOWN)
    {
      /* 
       * Only save the client and server information. Must not ent-
       * er tcmConn in client and server linke list.
       */
      tcmConn->clientCb = clientCb;
      tcmConn->serverCb = serverCb;
      RETVOID;
    }

  /*
   * Insert block containing tcmConn structure in client control bl-
   * ock link list SoTptClientCb->tcmConnLst.
   */
   (Void) soPrcUpdateTcmConnClient (tcmConn, clientCb);

  /*
   * Insert block containing tcmConn structure in server control bl-
   * ock link list SoTptServerCb->tcmConnLst.
   */
  (Void) soPrcUpdateTcmConnServer (tcmConn, serverCb);

  RETVOID;

} /* soPrcUpdateTcmConn */


/*******************************************************************
*
*       Fun:   soPrcDelTcmConn
*
*       Notes: This function is used to delete context of tcmConn s-
*              tructure from  server  and   client  connection. This
*              function removes block  containing  tcmConn structure
*              from link list in server control block and client co-
*              ntrol block.
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC Void soPrcDelTcmConn
(
SoTcmConn  *tcmConn    /* control block to be inserted in hash list */
)
#else
PUBLIC Void soPrcDelTcmConn (tcmConn)
SoTcmConn  *tcmConn;   /* control block to be inserted in hash list */
#endif
{
   TRC2(soPrcDelTcmConn);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (tcmConn))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO172, (ErrVal) 0, "soPrcDelTcmConn: "
                 "Invalid parameter");
      RETVOID;
    }
#endif

   if (tcmConn->tcmConnType == SO_UNKNOWN)
      RETVOID;

  /*
   * Remove  block containing  tcmConn structure from client control
   * block link list SoTptClientCb->tcmConnLst.
   */
   if (tcmConn->clientCb != NULLP)
      cmLListDelFrm (&tcmConn->clientCb->tcmConnLst, &tcmConn->clientCbEnt);

   tcmConn->clientCb = NULLP;

  /*
   * Remove  block containing  tcmConn structure from server control
   * block link list SoTptServerCb->tcmConnLst.
   */
   if (tcmConn->serverCb != NULLP)
      cmLListDelFrm (&tcmConn->serverCb->tcmConnLst, &tcmConn->serverCbEnt);

   tcmConn->serverCb = NULLP;

   RETVOID;

} /* soPrcDelTcmConn */




/*******************************************************************
*
*       Fun:   soPrcInitTcmConn
*
*       Desc:  Initializes TCM connection control block
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC Void soPrcInitTcmConn
(
SoTcmConn     *tcmConn,
U8            tcmConnType,
PTR           residePtr
)
#else
PUBLIC Void soPrcInitTcmConn(tcmConn, tcmConnType, residePtr)
SoTcmConn     *tcmConn;
U8            tcmConnType;
PTR           residePtr;
#endif
{

   TRC2(soPrcInitTcmConn);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (tcmConn))
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO173, (ErrVal) 0, "soPrcInitTcmConn: "
                 "Invalid parameter");
      RETVOID;
    }
#endif

   tcmConn->clientCb      = NULLP;
   tcmConn->serverCb      = NULLP;
   tcmConn->tcmConnType   = tcmConnType;
   tcmConn->residePtr     = residePtr;

   RETVOID;
} /* soPrcInitTcmConn */


/***************************************************************
*
*       Fun:   soTptOpenServer
*
*       Notes: This function is used to open transport server c-
*              onnection. This function  invokes  HitServOpenReq 
*              to open transport server.
*
*       Ret:   ROK   on success
*              RFAILED on error
*
*       File:  so_tcm.c
*
***************************************************************/
#ifdef ANSI
PUBLIC S16 soTptOpenServer
(
SoTptServerCb *serverCb /* Server connection control block */
)
#else
PUBLIC S16 soTptOpenServer (serverCb)
SoTptServerCb *serverCb;/* Server connection control block */
#endif
{
   CmIcmpFilter   nullFilter; /* TUCL 1.3 ICMP filter */
   SoTSapCb       *tsapCb; 
   U8             hitTptProt; /* TUCL protocol type   */
   /* so010.201: Fix to guard opening of tpt srv with a timer */
   S16            retVal;

   TRC2(soTptOpenServer)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (serverCb))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO174, (ErrVal) 0, "soTptOpenServer:"
                " Invalid parameter");
     RETVALUE (RFAILED);
   }
#endif
 
  /*---------- Step 1: Perform basic error checkings -------------*/

  /*------- Server must not be disabled -------*/
   if (serverCb->state != LSO_TPTSRV_DIS)
   {
      SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
                 "soTptOpenServer: serverCb in invalid state\n"));
      RETVALUE (RFAILED);
   }

  /*--- TSAP used must be bound and enabled ---*/
   tsapCb = serverCb->tsapCb;

   if (tsapCb->state != LSO_TSAP_BNDENA)
   {
      soGenStaInd (STTSAP,
                   LCM_CATEGORY_INTERNAL,
                   LSO_EVENT_TPTSRV_ENA, 
                   LSO_CAUSE_SAP_BNDDIS, 
                   LSO_PAR_SAP, 
                   (Ptr)&tsapCb->cfg.tSapId);
      RETVALUE (RFAILED);
   }

  /*- Stateless Proxy need not use TCP server -*/
#ifdef SO_NS
   if ((serverCb->entCb     != NULLP)              &&
       (serverCb->tptProt   == LSO_TPTPROT_TCP)    &&
       (serverCb->entCb->entityType == LSO_ENT_NS) &&
       (serverCb->entCb->s.ns.reCfg.proxyReCfg.
                   prxState ==  LSO_PRX_STATELESS))
   {
      SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
           "soTptOpenServer: TCP Conn For Stateless Proxy\n"));

      RETVALUE (RFAILED);
   }
#endif

  /*--------- Step 2: Decide the transport to be used ------------*/

   (Void)cmMemset((U8 *)&nullFilter, 0, sizeof (CmIcmpFilter));
   nullFilter.type = CM_ICMP_NO_FILTER;

   switch(serverCb->tptProt)
   {
      case LSO_TPTPROT_TCP :
          hitTptProt = HI_SRVC_TCP;
          break;
      case LSO_TPTPROT_UDP :
          hitTptProt = HI_SRVC_UDP;
          break;
      case LSO_TPTPROT_UDP_PRIOR :
          hitTptProt = HI_SRVC_UDP_PRIOR;
          break;
#ifdef SO_TLS
      case LSO_TPTPROT_TLS_TCP :
          /* so027.201: Changes for SIP TLS support */
          hitTptProt = HI_SRVC_TLS; 
          break;
#endif
      default:
          hitTptProt = HI_SRVC_UDP;
   }

  /*-- Step 3: Change state and send Server open request to TUCL--*/

   /* so010.201: Fix to guard opening of tpt srv with a timer */
   if (serverCb->opnSrvTmr.enb == TRUE)
   {
      if (serverCb->opnSrvCurRetryCnt-- >= 0)
      {

         /* Start a timer before sending open server request */
         retVal = soSchedTmr(serverCb, SO_TMR_TCM_OPEN_SRV, TMR_START,
                             serverCb->opnSrvTmr.val);
         if (retVal != ROK)
         {
            /* Generate an alarm here */
            RETVALUE(retVal);
         }
      }
      /* Unable to open, no more retries */
      else
      {
        /* so035.201: Unable to open server connection as maximum  *
         *            retries as reached. Inform this event to LM  *
         *            and reset the current retry count.           */
                   
         soMiTptSrvCloseInd (serverCb, FALSE);

         serverCb->opnSrvCurRetryCnt =  serverCb->opnSrvRetryCnt ;

         RETVALUE (ROK);
      }
   }
   
    serverCb->state = LSO_TPTSRV_WAIT_ENA;
   (Void) SoLiHitServOpenReq (&tsapCb->liPst,
                              tsapCb->cfg.spId,
                              serverCb->suConnId,
                              &serverCb->localAddr,
                              &serverCb->tPar,
                              &nullFilter,
                              hitTptProt);
   RETVALUE(ROK);

} /* end of soTptOpenServer */


/***************************************************************
*
*       Fun:   soTptCloseServer
*
*       Notes: This  function  is used  to close transport server
*              connection. This function  invokes  HitDiscReq  to 
*              to close transport server. This function  will NOT
*              delete server control block.
*
*       Ret:   None
*
*       File:  so_tcm.c
*
***************************************************************/
#ifdef ANSI
PUBLIC Void soTptCloseServer
(
SoTptServerCb *serverCb /* Server connection control block */
)
#else
PUBLIC Void soTptCloseServer (serverCb)
SoTptServerCb *serverCb;/* Server connection control block */
#endif
{
   U8           choice;
   ConnId       connId;
   SoTSapCb     *tsapCb;

   TRC2(soTptCloseServer);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (serverCb))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO175, (ErrVal) 0, "soTptCloseServer:"
                " Invalid parameter");
     RETVOID;
   }
#endif
 
  /*--- If server is already disabled, do nothing ---*/
   if (serverCb->state == LSO_TPTSRV_DIS)
      RETVOID;

  /*--------- TSAP state must be enabled. -----------*/
   tsapCb = serverCb->tsapCb;

   if (tsapCb->state != LSO_TSAP_BNDENA)
      RETVOID;

  /*--- Choose btw suConnId/spConnId for DiscReq ----*/
   if (serverCb->state == LSO_TPTSRV_WAIT_ENA)
   {
      choice = HI_USER_CON_ID;
      connId = serverCb->suConnId;
   }
   else
   {
      choice = HI_PROVIDER_CON_ID;
      connId = serverCb->spConnId;
   }

  /* so010.201: Fix to guard opening of tpt srv with a timer */
  /*--- Stop any running timers ---------------------*/
   if (serverCb->opnSrvTmr.enb == TRUE)
   {
      (Void) soSchedTmr(serverCb, SO_TMR_TCM_OPEN_SRV,
                        TMR_STOP, NOTUSED);
   }

  /*--- Disconnect server by sending TUCL DiscReq ---*/
   soTptIssueDiscReq (tsapCb, choice, connId, SO_SOCK_SRV);

  /*------- Change server state to DISABLED ---------*/
   serverCb->state = LSO_TPTSRV_DIS;
   
   RETVOID;

} /* end of soTptCloseServer */




/****************************************************************
*
*   Fun:  soTptCloseClient

*   Desc: This function is used to close a client (TCP/UDP) conn-
*         ection.It also dealloacates transport client connection
*         control block (CCB).
*         informUser indicates whether transaction or dialog lay-
*         er should be informed about the connection  going down.
*
*   Ret:   None
*
*   File:  so_tcm.c
*
****************************************************************/
#ifdef ANSI
PUBLIC Void soTptCloseClient
(
SoTptClientCb  *clientCb, /* Client Control Block    */
Bool           informUser /* Inform users or not     */
)
#else
PUBLIC Void soTptCloseClient (clientCb, informUser)
SoTptClientCb  *clientCb; /* Client Control Block    */
Bool           informUser;/* Inform users or not     */
#endif
{
   Buffer    *mBuf;

   TRC2 (soTptCloseClient)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (clientCb))
   {
     SOLOGERROR(ERRCLS_DEBUG, ESO176, (ErrVal) 0, "soTptCloseClient: "
                "Invalid parameter");
     RETVOID;
   }
#endif
   
   /*----- STEP 1: Stop running timers and dequeue messages ------*/
   if (clientCb->state == LSO_CLIENT_ENA)  
   {
      /*---- so007.201: Timers Are Stopped In Delete Function ----*/

      while (SDequeueFirst (&mBuf, &clientCb->bufQ) == ROK)
          SPutMsg (mBuf);

      SFlushQueue (&clientCb->bufQ);
   }

   /*------- STEP 2: Send disconnect request to TUCL Later -------*/
   if (clientCb->state != LSO_CLIENT_DIS) 
   {
       soTptIssueDiscReq (clientCb->tsapCb, 
                          HI_USER_CON_ID, 
                          clientCb->suConnId,
                          SO_SOCK_CLNT);
   }

   /*---------- STEP 3: Delete client control block. -------------*/
    soTptFreeClient (clientCb, informUser);

   RETVOID;

} /* soTptCloseClient */



/*******************************************************************
*
*       Fun:   soTptProcTmrExpiry
*
*       Desc:  Process expiry of all timers related to transport mo-
*              dule. This function is invoked by TMR module dispatch
*              a timer expiry.
*
*       Ret:   None
*
*       Notes:
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC Void soTptProcTmrExpiry
(
Ptr           cb,        /* Control block */
S16           tmrEvnt    /* Timer event   */
)
#else
PUBLIC Void soTptProcTmrExpiry (cb, tmrEvnt)
Ptr           cb;        /* Control block */
S16           tmrEvnt;   /* Timer event   */
#endif
{
   S16             ret;
   SoTSapCb        *tsapCb;
   SoTptClientCb   *clientCb;
   /* so010.201: Fix to guard opening of tpt srv with a timer */
   SoTptServerCb   *serverCb;

   TRC2(soTptProcTmrExpiry);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (cb))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO177, (ErrVal) 0, "soTptProcTmrExpiry:"
                " Invalid parameter");
     RETVOID;
   }
#endif

   clientCb = (SoTptClientCb *)cb;

  /*--------------- Switch based on timer expired ----------------*/
   switch (tmrEvnt)
   {
      case SO_TMR_TCM_IDLE:

         /*------- Client Connection's IDLE Timer Expired --------*/
         SODBGP_SO (SO_DBGMASK_MH, (soCb.init.prntBuf, 
                    "soTptProcTmrExpiry: Idle Timer Expired \n"));

         /*------------ Close The Client Connection --------------*/
         /*
          * NOTE: IDLE timer expirt is NOT an  error case,  so users
          *       of this client connection need not take any action.
          */
         (Void) soTptCloseClient (clientCb, FALSE);
         break;

      case SO_TMR_TCM_CONNECTION:

         /*------- Client Connection's Wait Timer Expired --------*/
         /* 
          * Waited long enough for client connection to complete,now
          * close the client connection.
          * NOTE: This indicates  failure to open  client connection
          *       to destination, so users of this client connection 
          *       MUST be informed to take appropriate action.
          */

          if (clientCb->state != LSO_CLIENT_ENA)
             (Void) soTptCloseClient (clientCb, TRUE);
         break;

      case SO_TMR_TCM_BND:

         /*--------- TSAP's Bind/Unbind Timer Expired ------------*/
         tsapCb = (SoTSapCb *)cb;

         /*---------- Retry Bind attempt, if required ------------*/
         if ((tsapCb->state == LSO_TSAP_WAIT_BNDENA) &&
             (++tsapCb->bndRetryCnt <= SO_MAX_BNDRETRY))
         {
               /*---------- Issue bind request again -------------*/
               ret = soSchedTmr (tsapCb, SO_TMR_TCM_BND, TMR_START,
                                 tsapCb->reCfg.bndTmCfg.val);
               if (ret != ROK)
                   RETVOID;

               (Void) SoLiHitBndReq (&tsapCb->liPst,
                                     tsapCb->cfg.tSapId,
                                     tsapCb->cfg.spId);
         }
         else
         {
               /*--- Maximum retries exceeded configured value ---*/
               /*------ Inform Layer Manager About Failure -------*/

               tsapCb->state = LSO_TSAP_UBNDDIS;
               
               soSendLmCntrlCfm (&soCb.init.lmPst,
                                 LCM_PRIM_NOK,
                                 LCM_REASON_NOT_APPL,
                                 &tsapCb->ctrlHdr);
         }
         break;

      /* so010.201: Fix to guard opening of tpt srv with a timer */
      case SO_TMR_TCM_OPEN_SRV:

         /* Find the server control block */
         serverCb = (SoTptServerCb *)cb;

        /* so035.201: Server open gaurd timer is started only when *
         *            server opening has to be retried.            */

         if (serverCb->state == LSO_TPTSRV_DIS)
         {
            /* Retry to open the transport server */
            (Void) soTptOpenServer (serverCb);
            RETVOID;
         }
         break;

      default:
         SOLOGERROR (ERRCLS_DEBUG, ESO178, (ErrVal) tmrEvnt,
               "soTptProcTmrExpiry: Invalid timer event\n");
         break;
    
   } /* End of switch (timer event) */

   RETVOID;

} /* soTptProcTmrExpiry */




/*******************************************************************
*       Fun:   soTptIssueDiscReq
*
*       Desc:  Issue HitDiscReq
*
*       Ret:   RETVOID
*
*       Notes: This is an internal support function  that  issues an
*              HitDiscReq.
*
*       File:  so_tcm.c
*
*******************************************************************/
#ifdef ANSI
PUBLIC Void soTptIssueDiscReq
(
SoTSapCb           *tsapCb,   /* transport SAP control block   */
U8                 choice,    /* type of connection identifier */
UConnId            connId,    /* connection identifier         */
U8                 sockType   /* socket type (client or server)*/
)
#else
PUBLIC Void soTptIssueDiscReq (tsapCb, choice, connId, sockType)
SoTSapCb           *tsapCb;   /* transport SAP control block   */
U8                 choice;    /* type of connection identifier */
UConnId            connId;    /* connection identifier         */
U8                 sockType;  /* socket type (client or server)*/
#endif
{
   CmTptParam      tptParam;

   TRC2(soTptIssueDiscReq);

   tptParam.type = CM_TPTPARAM_NOTPRSNT;

   if (tsapCb->state == LSO_TSAP_BNDENA)
   {
      (Void) SoLiHitDiscReq (&tsapCb->liPst, tsapCb->cfg.spId, choice,
                             connId, HI_CLOSE, &tptParam);
   }
   RETVOID;
} /* end of soTptIssueDiscReq */



/*******************************************************************
*
*       Fun:   soTptProcessTsapServers
*
*       Desc:  Processes all transport servers on specified TSAP. T-
*              his function is used to open/close all transport ser-
*              vers on the given TSAP.
*
*       Ret:   If success, number of servers processed.
*              If failure, RFAILED.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC S16 soTptProcessTsapServers
(
SoTSapCb  *tsapCb,     /* TSAP control block        */
U8        srvAction    /* Type of action to perform */
)
#else
PUBLIC S16 soTptProcessTsapServers (tsapCb, srvAction)
SoTSapCb  *tsapCb;     /* TSAP control block        */
U8        srvAction;   /* Type of action to perform */
#endif
{
   U16            i;
   SoTptServerCb  *serverCb; 
   U16            processed;

   TRC2(soTptProcessTsapServers);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (tsapCb))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO179, (ErrVal) 0, "soTptProcessTsapServers: "
                "Invalid parameter");
     RETVALUE (RFAILED);
   }
#endif

  /*----- For each configured transport server ..... -----*/
   processed = 0;

   for (i = 0; i < soCb.maxTptSrv; i++)
   {
      if ((serverCb = soCb.allSrvCbLst[i]) == NULLP)
         continue;

      if (serverCb->tsapCb != tsapCb)
         continue;

      /*----- Perform required action on the server ------*/
       switch (srvAction)
       {
          case SO_TCM_TPTSRV_CLOSE:

               if (serverCb->state != LSO_TPTSRV_DIS)
               {
                  /*---------- CLOSE this server ---------*/
                  (Void) soTptCloseServer (serverCb);

                 /*-------- Inform Layer manager --------*/
                  soMiTptSrvCloseInd (serverCb, TRUE);

                  processed++;
               }
               break;

          case SO_TCM_TPTSRV_DISABLE:
              /*
               * Just flag server as disabled and do not is-
               * sue discReq.  This  option  is used only if 
               * TUCL has crashed
               */
               (Void) soTptDelAllServerContext (serverCb, TRUE);
               serverCb->state = LSO_TPTSRV_DIS;
          
               /* 
                * Inidicate transport server being closed by
                * layer manager.
                */
               soMiTptSrvCloseInd (serverCb, TRUE);
               processed++;

               break;

          case SO_TCM_TPTSRV_OPEN:
          
              /*------------ OPEN this server ------------*/
               if (soTptOpenServer (serverCb) != ROK)
                   RETVALUE (RFAILED);

               processed++;
               break;

          case SO_TCM_TPTSRV_FREE:
              /* 
               * Close transport server if open and free co-
               * ntrol block and memory 
               */
               if (serverCb->state != LSO_TPTSRV_DIS)
               {
                  /*---------- CLOSE this server ---------*/
                  (Void) soTptCloseServer (serverCb);

                 /*-------- Inform Layer manager --------*/
                  soMiTptSrvCloseInd (serverCb, TRUE);

                  processed++;
               }

               soTptFreeServer(serverCb);
               soCb.allSrvCbLst[i] = NULLP;

               break;

          default:
               SOLOGERROR (ERRCLS_DEBUG, ESO180, srvAction,
                "soTptProcessTsapServers: Invalid action");
               RETVALUE (RFAILED);

       } /* End of switch (action) */

   } /* End of For (all transport server) */


   RETVALUE (processed);

} /* soTptProcessTsapServers */



/******************************************************************
*
*       Fun:   soTptProcessEntServer
*
*       Desc:  Processes all transport servers  on specified entity.
*              This function is used to open/close all transport se-
*              rvers on the given TSAP.
*
*       Ret:   If success, number of servers processed.
*              If failure, RFAILED.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC S16 soTptProcessEntServer
(
SoEntCb   *entCb,      /* Entity control block                 */
U8        srvAction,   /* Type of action to perform            */
Bool      *someOpen    /* At least one server is actually open */
)
#else
PUBLIC S16 soTptProcessEntServer (entCb, srvAction, someOpen)
SoEntCb   *entCb;      /* Entity control block                 */
U8        srvAction;   /* Type of action to perform            */
Bool      *someOpen;   /* At least one server is actually open */
#endif
{
   U16            i;          /* Counter */
   SoTptServerCb  *serverCb;  /* Transport server to close */
   U16            processed;  /* Number of entries processed */

   TRC2(soTptProcessEntServer);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (entCb))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO181, (ErrVal) 0, "soTptProcessEntServer: "
                "Invalid parameter");
     RETVALUE (RFAILED);
   }
#endif

   if (someOpen != NULLP)
      *someOpen = FALSE;

  /*----- For each configured transport server ..... -----*/
   processed = 0;

   for (i = 0; i < soCb.maxTptSrv; i++)
   {
      if ((serverCb = soCb.allSrvCbLst[i]) == NULLP)
         continue;

      if (serverCb->entCb != entCb)
         continue;

      /*----- Perform required action on the server ------*/
       switch (srvAction)
       {
          case SO_TCM_TPTSRV_CLOSE:

               if (serverCb->state != LSO_TPTSRV_DIS)
               {
                  /*---------- CLOSE this server ---------*/
                  (Void) soTptCloseServer (serverCb);

                 /*-------- Inform Layer manager --------*/
                  soMiTptSrvCloseInd (serverCb, TRUE);

                  processed++;
               }
               break;

          case SO_TCM_TPTSRV_DISABLE:

              /*
               * Just flag server as disabled and do not is-
               * sue discReq.  This  option  is used only if 
               * TUCL has crashed
               */
               (Void) soTptDelAllServerContext (serverCb, TRUE);
               serverCb->state = LSO_TPTSRV_DIS;
          
               /* 
                * Inidicate transport server being closed by
                * layer manager.
                */
               soMiTptSrvCloseInd (serverCb, TRUE);
               processed++;

               break;

          case SO_TCM_TPTSRV_OPEN:

              /*------------ OPEN this server ------------*/

               if (serverCb->state == LSO_TPTSRV_ENA)
               {
                  if (someOpen != NULLP) *someOpen = TRUE;
               }
               else
               {
                  if (soTptOpenServer (serverCb) != ROK)
                     RETVALUE (RFAILED);
               }

               processed++;
               break;

          case SO_TCM_TPTSRV_FREE:
              /* 
               * Close transport server if open and free co-
               * ntrol block and memory 
               */
               if (serverCb->state != LSO_TPTSRV_DIS)
               {
                 /*-------- Inform Layer manager --------*/
                  soMiTptSrvCloseInd (serverCb, TRUE);

                 /*---------- CLOSE this server ---------*/
                  (Void) soTptCloseServer (serverCb);

                  processed++;
               }

               soTptFreeServer(serverCb);
               soCb.allSrvCbLst[i] = NULLP;

               break;

          default:
               SOLOGERROR (ERRCLS_DEBUG, ESO182, srvAction,
                 "soTptProcessEntServers: Invalid action");
               RETVALUE (RFAILED);

       } /* End of switch (action) */

   } /* End of For (all transport server) */


   RETVALUE (processed);

} /* soTptProcessEntServer */




/*******************************************************************
*
*       Fun:   soTptProcHitConCfm
*
*       Desc:  Handle connection confirmation for client connection.
*
*       Ret:   None
*
*       Notes:
*
*       File:  so_tcm.c
*
*******************************************************************/
#ifdef ANSI
PUBLIC Void soTptProcHitConCfm
(
SuId            suId,        /* TSAP Identifier                */
UConnId         spConnId,    /* spConnId of connection         */
SoTptClientCb   *clientCb,   /* Client Control Block           */
CmTptAddr       *localAddr   /* local IP address of connection */
)
#else
PUBLIC Void soTptProcHitConCfm (suId, spConnId, clientCb, localAddr)
SuId            suId;        /* TSAP Identifier                */
UConnId         spConnId;    /* spConnId of connection         */
SoTptClientCb   *clientCb;   /* Client Control Block           */
CmTptAddr       *localAddr;  /* local IP address of connection */
#endif
{
   Buffer       *mBuf;
   S16          ret; 
   UConnId      suConnId;

   TRC2(soTptProcHitConCfm);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (clientCb && localAddr))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO183, (ErrVal) 0, "soTptProcHitConCfm: "
                "Invalid parameter");
     RETVOID;
   }
#endif

   ret                = ROK;
   clientCb->state    = LSO_CLIENT_ENA;
   clientCb->spConnId = spConnId;

   (Void)cmMemcpy ((U8 *)&clientCb->localAddr,
                   (CONSTANT U8 *)  localAddr, sizeof (CmTptAddr));

   soCmInitTimer (&clientCb->tmrNode);
   soTptIdleTmr (clientCb, TMR_START); 

   while (SDequeueFirst (&mBuf, &clientCb->bufQ) == ROK)
   {
     suConnId = clientCb->suConnId;

     ret = soTptSendMsgToTUCL (clientCb->serverCb, 
                               clientCb,
                               &clientCb->remoteAddr,
                               mBuf);

     if ((ret == RFAILED) ||
         ((clientCb = soTptCheckClientCb (suId, 
                                          HI_USER_CON_ID,
                                          suConnId)) == NULLP) ||
         (clientCb->state != LSO_CLIENT_ENA))
     {
        if (clientCb)
           SFlushQueue (&clientCb->bufQ);
       
        break;
     }
   }

   RETVOID;

} /* end of soTptProcHitConCfm */



/*******************************************************************
*       Fun:   soTptCheckClientCb
*
*       Desc:  Get a transport client connection control block (TCB)
*              This function is called when message is received from
*              lower layer.
*
*       Ret:   TCB,   if present
*              NULLP, if absent
*
*       Notes: None
*
*       File:  so_tcm.c
*
**********************************************************/
#ifdef ANSI
PUBLIC SoTptClientCb *soTptCheckClientCb
(
SuId        suId,      /* TSAP Id                       */
U8          choice,    /* type of connection identifier */
UConnId     connId     /* connection identifier         */
)
#else
PUBLIC SoTptClientCb *soTptCheckClientCb (suId, choice, connId)
SuId        suId;      /* TSAP Id                       */
U8          choice;    /* type of connection identifier */
UConnId     connId;    /* connection identifier         */
#endif
{
   S16           ret; 
   SoTptClientCb *clientCb;

   TRC2 (soTptCheckClientCb);

   ret      = ROK;
   clientCb = NULLP;

   /*
    * If TUCL connection identifier is provided, scan whole hash li-
    * st to find corresponsding client control block.
    */
    if (choice == HI_PROVIDER_CON_ID)
    {
      while ((ret = (cmHashListGetNext (&soCb.soTSapCbLst[suId]->suConnIdHlCp,
                                 (PTR)clientCb, 
                                 (PTR *)&clientCb))) == ROK)
      {
         if (clientCb->spConnId == connId)
            break;
      }
    }

   /*
    * If SIP connection identifier is  provided, find  corresponding
    * client control block by directly indexing in the hash list.
    */
    else
    {
       ret = cmHashListFind (&soCb.soTSapCbLst[suId]->suConnIdHlCp,
                             (U8 *)&connId, 
                             sizeof (ConnId),
                             0, 
                             (PTR *)&clientCb);
    }

    if (ret != ROK)
    {
        /*-- No client connection exists --*/
         SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
                    "soTptCheckClientCb: HashListGetNext failed"));
         clientCb = NULLP;
    }

    RETVALUE (clientCb);

} /* end of soTptCheckClientCb  */




/*******************************************************************
*
*       Fun:   soTptFreeServer
*
*       Desc:  Frees memory for transport server
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_tcm.c
*
*******************************************************************/
#ifdef ANSI
PUBLIC Void soTptFreeServer 
(
SoTptServerCb  *serverCb     /* Transport server to free */
)
#else
PUBLIC Void soTptFreeServer (serverCb)
SoTptServerCb  *serverCb;    /* Transport server to free */
#endif
{
   U32            i, j, k;
   Bool           ssapFound;
   SoTptServerCb  *tmpServerCb;

   TRC2(soTptFreeServer);

   /*
    * STEP 1: If any transaction  entity is using server connection,
    *         inform  them  that connection is going down.
    */
   (Void) soTptDelAllServerContext (serverCb, TRUE);

   /*
    * STEP 2: Remove service user SAP's associated with this transp-
    *         ort server.
    */
   /*----- For each sap associated with this server ..... --------*/
   for (i = 0; i < serverCb->nmbSSap; i++)
   {
      /*----- Verify if this SAP is used by any other server ----*/
      for (j = 0, ssapFound = FALSE; j < soCb.maxTptSrv; j++)
      {
         tmpServerCb = soCb.allSrvCbLst[j];
         if ((tmpServerCb        != NULLP)    && 
             (tmpServerCb        != serverCb) &&
             (tmpServerCb->entCb == serverCb->entCb))
         {
            for (k = 0; k < LSO_TPTSRV_MAX_SSAP; k++)
                if (serverCb->sSapLst[i] == tmpServerCb->sSapLst[k])
                {
                     ssapFound = TRUE; break;
                }
         }

         if (ssapFound == TRUE)
            break;

      } /* End of for (each transport server) */

     /*
      * If this SSAP is NOT being used by another server, remove the
      * context of the SSAP for the entity control block.
      */
      if (ssapFound == FALSE)
      {
         for (k = 0; k < LSO_MAX_SSAP_PER_ENTITY; k++)
            if (soCb.soSSapCbLst[serverCb->sSapLst[i]] == 
                                    serverCb->entCb->soSSapCbLst[k])
            {
                serverCb->entCb->soSSapCbLst[k] = NULLP;
                --serverCb->entCb->nmbSSap;
                break;
            }
      }

   } /* End of for (each sap in serverCb) */

   /*
    * STEP 3: Finally free server control block and  any  associated
    *         memory.
    */
   soUtlDelTknStrOSXL (&serverCb->hostName);
   SOFREE (serverCb, sizeof (SoTptServerCb));

   RETVOID;

} /* soTptFreeServer */



/*******************************************************************
*
*       Fun:   soTptFreeClient
*
*       Desc:  Frees memory for client connection.
*
*       Ret:   None
*
*       Notes:
*
*       File:  so_tcm.c
*
*******************************************************************/
#ifdef ANSI
PUBLIC Void soTptFreeClient 
(
SoTptClientCb *clientCb, /* Client connection to free */
Bool          informUser /* Inform users or not       */
)
#else
PUBLIC Void soTptFreeClient (clientCb, informUser)
SoTptClientCb *clientCb; /* Client connection to free */
Bool          informUser;/* Inform users or not       */
#endif
{

   TRC2(soTptFreeClient);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (clientCb))
   {
     SOLOGERROR(ERRCLS_DEBUG, ESO184, (ErrVal) 0, "soTptFreeClient: "
                "Invalid parameter");
     RETVOID;
   }
#endif
   
   /*
    * STEP 1: If any transaction or core entity is using client con-
    *         nection,  inform  them  that connection is going down.  
    */
   (Void) soTptDelAllClientContext (clientCb, informUser);

   /*---------- STEP 2: Dellocate other elements of CCB ----------*/
   cmHashListDelete (&clientCb->tsapCb->tptAddrHlCp,  (PTR)clientCb);
   cmHashListDelete (&clientCb->tsapCb->suConnIdHlCp, (PTR)clientCb);

   if (clientCb->partialMsg != NULLP)
      (Void) SPutMsg (clientCb->partialMsg);

   /*------- so007.201: STEP 3: Stop Any Running Timers ----------*/
   (Void) soSchedTmr (clientCb, SO_TMR_TCM_IDLE, TMR_STOP, NOTUSED); 
   (Void) soSchedTmr (clientCb, SO_TMR_TCM_CONNECTION, TMR_STOP, NOTUSED);

   SOFREE (clientCb, sizeof (SoTptClientCb));

   RETVOID;

} /* soTptFreeClient */


/***************************************************************
*
*       Fun:   soTptIdleTmr
*
*       Notes: This function starts/stops IDLE timer for client
*              connection connection. IDLE timer is  statred to 
*              define  inactivity period  of client connection. 
*              Client  connection  will  be closed if the timer
*              expires.
*
*       Ret:   ROK   on success
*              RFAILED on error
*
*       File:  so_tcm.c
*
***************************************************************/
#ifdef ANSI
PUBLIC S16 soTptIdleTmr
(
SoTptClientCb  *clientCb,  /* Transport connection for idle timer */
Action         tmrAction   /* Timer action                        */
)
#else
PUBLIC S16 soTptIdleTmr(clientCb, tmrAction)
SoTptClientCb  *clientCb;  /* Transport connection for idle timer */
Action         tmrAction;  /* Timer action                        */
#endif
{
   S16      ret;
   U32      tmrVal;

   TRC2(soTptIdleTmr);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (clientCb))
   {
     SOLOGERROR(ERRCLS_DEBUG, ESO185, (ErrVal) 0, "soTptIdleTmr: "
                "Invalid parameter");
   }
#endif
 
   if (clientCb->serverCb->entCb != NULLP)
   {
      tmrVal = clientCb->serverCb->entCb->reCfg.tptInActvTmr;

#ifdef SO_TLS
      /* If tptProt is TLS, use tptInActvTmr value instead */
      if (clientCb->serverCb->tptProt == LSO_TPTPROT_TLS_TCP)
         tmrVal = clientCb->serverCb->entCb->reCfg.tlsInActvTmr;
#endif

      ret = soSchedTmr (clientCb, SO_TMR_TCM_IDLE, tmrAction,
              tmrVal);
   }
   else
   {
      ret = soSchedTmr (clientCb, SO_TMR_TCM_IDLE, tmrAction,
                        SO_TMRVAL_DNS_INACTIVE);
   }

   if (ret != ROK)
   {
      SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
                  "soTptIdleTmr: timer function failed\n"));
      RETVALUE (RFAILED);
   }

   RETVALUE (ROK);

} /* soTptIdleTmr */

 
/*********************************************************************
*
*       Fun:   soTptAllocClientCb
*
*       Desc:  Allocate and initialize the common transport connection
*              control block
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This support function is used  to initialize the common
*              transport connection control block.
*
*       File:  so_tcm.c
*
*********************************************************************/
#ifdef ANSI
PUBLIC S16 soTptAllocClientCb
(
SoTSapCb       *tsapCb,     /* Transport SAP to be used  */
CmTptAddr      *localAddr,  /* local transport address   */
CmTptAddr      *remoteAddr, /* remote transport address  */
SoTptClientCb  **clientCb /* client connection control block (returned) */
)
#else
PUBLIC S16 soTptAllocClientCb (tsapCb, localAddr, remoteAddr, clientCb)
SoTSapCb       *tsapCb;    /* Transport SAP to be used  */
CmTptAddr      *localAddr; /* local transport address   */
CmTptAddr      *remoteAddr;/* remote transport address  */
SoTptClientCb  **clientCb;/* client connection control block (returned) */
#endif
{
   S16            ret;
   SoTptClientCb  *lclClientCb;

   TRC2(soTptAllocClientCb);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (tsapCb && remoteAddr && clientCb))
   {
     SOLOGERROR(ERRCLS_DEBUG, ESO186, (ErrVal) 0, "soTptAllocClientCb: "
                "Invalid parameter");
   }
#endif

  /*------------- Allocate client control block (CCB) ------------*/
   SOALLOC((Data **)&lclClientCb, sizeof(SoTptClientCb));
   /* so038.201: Added error check condition */
   if( lclClientCb == NULLP)
      RETVALUE (RFAILED);

  /*--------------- Set initial state as disabled ----------------*/
   lclClientCb->state = LSO_CLIENT_DIS;

  /*-------------- Copy local address, if specified --------------*/
   if (localAddr)
      (Void) cmMemcpy ((U8 *) &lclClientCb->localAddr, 
                       (CONSTANT U8 *) localAddr,
                       sizeof(CmTptAddr));

  /*----------------- Copy remote entity address -----------------*/
   (Void) cmMemcpy ((U8 *) &lclClientCb->remoteAddr,
                    (CONSTANT U8 *) remoteAddr,
                    sizeof(CmTptAddr));

  /*------ Allocate connection ID for the client connection ------*/
   ret = soTptAllocClientConnId (tsapCb, &lclClientCb->suConnId);
   if (ret != ROK)
   {
      SOFREE (lclClientCb, sizeof(SoTptClientCb));
      RETVALUE (RFAILED);
   }

   /*--- Initialize other fields of CCB ---*/

   lclClientCb->spConnId = SO_INV_HIT_CONNID;

   if (SInitQueue (&lclClientCb->bufQ) != NULLP)
   {
      SOFREE (lclClientCb, sizeof(SoTptClientCb));
      RETVALUE (RFAILED);
   }

   soCmInitTimer (&lclClientCb->tmrNode);
   soCmInitTimer (&lclClientCb->connTmrNode);

   cmLListInit (&lclClientCb->tcmConnLst);

   /*--- return allocated CCB to caller ---*/

   (*clientCb) = lclClientCb;

   RETVALUE (ROK);

} /* end of soTptAllocClientCb */





/*-------------------- PRIVATE FUNCTIONS --------------------------*/


/*
*
*       Fun:   soTptEncodeMsg
*
*       Desc:  This function is used to encode and send messages.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_tcm.c
*
*/

#ifdef ANSI
PRIVATE S16   soTptEncodeMsg
(
SoEntCb      *entCb,     /* Entity Control Block                       */
SoSSapCb     *sSapCb,    /* Service User SAP Cb                        */
U8           type,       /* encode request/response                    */
SoEvnt       *evnt,      /* SIP Request message to be sent             */
CmTptAddr    *destAddr,  /* Destination IP-address/port to send request*/
TknStrOSXL   *branchId,  /* Branch Id to be added in VIA item          */
Bool         modifyTransport,  /* Switch to TCP for larger messages    */
SoTcmConn    *tcmConn,   /* TCP/UDP connection information  (Updated)  */
Buffer       **mBuf      /* Encoded Request Message         (Updated)  */
)
#else
PRIVATE S16   soTptEncodeMsg(entCb, sSapCb, type, evnt, destAddr,
                             branchId, modifyTransport, tcmConn, mBuf)
SoEntCb      *entCb;     /* Entity Control Block                       */
SoSSapCb     *sSapCb;    /* Service User SAP Cb                        */
U8           type;       /* encode request/response                    */
SoEvnt       *evnt;      /* SIP Request message to be sent             */
CmTptAddr    *destAddr;  /* Destination IP-address/port to send request*/
TknStrOSXL   *branchId;  /* Branch Id to be added in VIA item          */
Bool         modifyTransport;  /* Switch to TCP for larger messages    */
SoTcmConn    *tcmConn;   /* TCP/UDP connection information  (Updated)  */
Buffer       **mBuf;     /* Encoded Request Message         (Updated)  */
#endif
{
   S16         ret;
   CmAbnfErr   err;
   Mem         abnfMem;

   TRC2(soTptEncodeMsg);

   abnfMem.region = soCb.init.region;
   abnfMem.pool = soCb.init.pool;
   (Void) cmMemset ((U8 *)&err, 0, sizeof (CmAbnfErr));
   
#ifdef SO_ABNF_MT_LIB
   if (soCb.cfg.nmbEDThreads > 0)
   {
     /*------ Send Event To Mutithreaded Encoder For Encoding ------*/
      ret = soSndEncodeMsgReq ((U32)CM_ABNF_PROT_SIP_ANY, 
                               type, 
                               entCb,
                               (Ptr)evnt,
                               (Buffer *)NULLP, 
                               (CmAbnfElmDef *)NULLP,
                               &abnfMem,
                               sSapCb, 
                               destAddr,
                               branchId, 
                               tcmConn,
                               modifyTransport);
      if (ret != ROK)
         RETVALUE (RFAILED);
      else
         RETVALUE (SO_TPT_MULTI_THREADED_ENC);
   }

   else
#endif
   {
     /*-------------------- Encode SIP Message  --------------------*/
     
      ret = soSipEncodeReq ((U32)CM_ABNF_PROT_SIP_ANY,
                             entCb, 
                             (U8 *)evnt, 
                             mBuf, 
                             (CmAbnfElmDef *)NULLP, 
                             &abnfMem,
                             &err);

      if ((ret != ROK) || (err.code != CM_ABNF_ERR_NONE))
      {
         SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
         "soTptEncodeMsg: Encode failed: ErrorCode(%d)\tIdNum(%d)\n",
         err.code, err.idNum));

         RETVALUE (RFAILED);
      }
   }

   RETVALUE (ROK);

} /* soTptEncodeMsg */


/*******************************************************************
*
*       Fun:   soTptMergeStream
*
*       Notes: This  function   handles  message  received  via  TCP.
*              It detects incomplete message and merge them together.
*
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptMergeStream
(
SoTptClientCb *clientCb,  /* Client connection (For TCP Only)         */
Buffer        *mBuf       /* Received message                         */
)
#else
PRIVATE S16 soTptMergeStream (clientCb, mBuf)
SoTptClientCb *clientCb;  /* Client connection (For TCP Only)         */
Buffer        *mBuf;      /* Received message                         */
#endif
{
   U16     crlfPos;

   TRC2 (soTptMergeStream);

  /*
   * For TCP as transport, it is  possible  that complete SIP  message
   * will not be received on one SoUiHitDatInd primitive.This function
   * finds if the SIP message is incompete. If Yes, it saves this mBuf,
   * till subsequent part of SIP message arrives in next SoUiHitDatInd.
   */
   
   if (clientCb->partialMsg != NULLP)
   {
     /*
      * We have earlier received partial SIP message. This one must be
      * subsequent part of  that message. So concatenate this one with
      * previously received part.
      */
      if (SCatMsg (mBuf, clientCb->partialMsg, M2M1) != ROK)
      {
         (Void) SPutMsg (mBuf);
         RETVALUE (RFAILED);
      }

      /*-------- Free memory for first (incomplete) message --------*/
      (Void) SPutMsg (clientCb->partialMsg);
      clientCb->partialMsg = NULLP;
   }

  /*--------- Next Verify That SIP Message Is Now Complete ---------*/
   if (soChkCrlf (mBuf, &crlfPos) != ROK)
      RETVALUE (RFAILED);
   
   if (crlfPos == SO_MH_NO_CRLF)
   {
      /*
       * SIP Message Is Still Not Complete.We Have To Wait For Rest Of
       * Message Part.
       */
      clientCb->partialMsg = mBuf;
#ifdef DEBUGP
      SODBGP_SO (SO_DBGMASK_TCM, (soCb.init.prntBuf,
                 "soTptMergeStream: No CRLF, waiting for the rest"
                 " of the msg!!\n"));
#endif
      RETVALUE (SO_TPT_MSG_NOT_COMPLETE);
   }
   
   RETVALUE (ROK);
}


/*******************************************************************
*
*       Fun:   soTptDecodeMsg
*
*       Notes: This function handles message received from peer node.
*              It decodes message and pass request/response to appr-
*              opriate transaction or dialog layer entity.
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptDecodeMsg
(
SoEntCb       *entCb,       /* Entity Control Block                   */
SoTptServerCb *serverCb,    /* Server connection that received message  */
SoTptClientCb *clientCb,    /* Client connection (For TCP Only)       */
CmTptAddr     *srcAddr,     /* Source IP address                      */
Buffer        **mBuf,       /* Received message                       */
SoEvnt        **soEvnt      /* Decoded message                        */
)
#else
PRIVATE S16 soTptDecodeMsg (entCb, serverCb, clientCb, srcAddr, mBuf, soEvnt)
SoEntCb       *entCb;     /* Entity Control Block                     */
SoTptServerCb *serverCb;  /* Server connection that received message  */
SoTptClientCb *clientCb;  /* Client connection (For TCP Only)         */
CmTptAddr     *srcAddr;   /* Source IP address                        */
Buffer        **mBuf;       /* Received message                       */
SoEvnt        **soEvnt;
#endif
{
   MsgLen          msgLen;       /* count of bytes in total message */
   S16             ret;
   U16             numDecBytes;  /* no of decoded bytes */
   CmAbnfErr       err;          /* error */
   CmAbnfDecOff    offset;       /* DBUF offset information */
   CmAbnfElmDef    soMsgDefSipMessage;

   TRC2(soTptDecodeMsg);

   ret         = ROK;
   numDecBytes = 0;
   cmMemset ((U8 *)&offset, 0, sizeof (CmAbnfDecOff));
   cmMemset ((U8 *)&err   , 0, sizeof (CmAbnfErr));

  /*
   * STEP 1:
   * If message was received on TCP, check and proceed with decoding
   * only if complete SIP message is received.
   */
   /* so027.201: Changes for SIP TLS support */
   if (clientCb && (clientCb->serverCb->tptProt == LSO_TPTPROT_TCP ||
                    clientCb->serverCb->tptProt == LSO_TPTPROT_TLS_TCP))
   {
      /*--- Merge With The previously Received Part (if there) ----*/
       ret = soTptMergeStream (clientCb, *mBuf);

       if (ret == SO_TPT_MSG_NOT_COMPLETE)
         /*---------- We Need To Wait For Rest Of Message ---------*/
         RETVALUE (SO_TPT_MSG_NOT_COMPLETE);

       else if (ret != ROK)
         RETVALUE (RFAILED);
   }

   /*----------- Check length of message before decoding -----------*/
   if (SFndLenMsg (*mBuf, &msgLen) != ROK)
      RETVALUE (RFAILED);

   if (clientCb)
      clientCb->tsapCb->sts.bytesRx += msgLen;
   else
      serverCb->tsapCb->sts.bytesRx += msgLen;

#ifdef SO_ABNF_MT_LIB
   if (soCb.cfg.nmbEDThreads > 0)
   {
     /*------ Send Event To Mutithreaded Encoder For Decoding ------*/
      ret = soSndDecodeMsgReq (CM_ABNF_PROT_SIP_ANY, 
                               SO_DATA_IND, *mBuf,
                               (Ptr)NULLP, 
                               (CmMemListCp *)NULLP,
                               &soMsgDefSipMessage,
                               serverCb,
                               clientCb,
                               srcAddr);
      if (ret != ROK)
         RETVALUE (RFAILED);

      RETVALUE (SO_TPT_MULTI_THREADED_DEC);
   }
   else
#endif
   {
     /*-------------------- Decode SIP Message  --------------------*/
     /*---- so019.201: Pass EntityCb Parameter -----*/
      ret = soSipDecodeReq ((U32)CM_ABNF_PROT_SIP_ANY, 
                            entCb,
                            (U8 **)soEvnt, 
                            mBuf, 
                            &soMsgDefSipMessage,
                            (CmMemListCp *)NULLP, 
                            &numDecBytes, 
                            &offset, 
                            &err,
                            &(err.idNum),
                            entCb->reCfg.decodeSDP);
      if (ret != ROK)
         RETVALUE (RFAILED);

     /* 
      * If message was received on TCP, check that SIP body (if pre-
      * sent) was complete. If not, save the  message  and  wait for 
      * rest of message to arrive.
      */
      /* so027.201: Changes for SIP TLS support */
     if ((clientCb) && 
         (clientCb->serverCb->tptProt == LSO_TPTPROT_TCP ||
          clientCb->serverCb->tptProt == LSO_TPTPROT_TLS_TCP ) &&
         (err.idNum                   == SO_HDR_OK_BODY_INCMP))
     {
         /*------ Save the received message and quit decoding -----*/
         clientCb->partialMsg = *mBuf;
#ifdef DEBUGP
         SODBGP_SO (SO_DBGMASK_TCM, (soCb.init.prntBuf,
                    "soTptDecodeMsg: Incomplete Body, waiting for the rest"
                    " of the msg!!\n"));
#endif

         if (*soEvnt != NULLP)
            (Void) soCmFreeEvent (*soEvnt);

         RETVALUE (SO_TPT_MSG_NOT_COMPLETE);
     }
      
     /*------- Take Appropriate action, if decoding failed --------*/
      ret = soPrcRcvdDataFromABNF (mBuf,
                                   entCb,
                                   serverCb,
                                   clientCb, 
                                   srcAddr, 
                                   (U8 *)(*soEvnt),
                                   err.idNum);
      if (ret != ROK)
         RETVALUE (RFAILED);
   }
   
   RETVALUE (ROK);

} /* soTptDecodeMsg */




/*******************************************************************
*
*       Fun:   soTptHandleReqInd
*
*       Notes: This  function  handles SIP  request message received
*              from peer node.
*              It searches for server  transaction control block and
*              passes the request to appropriate entity.
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptHandleReqInd
(
SoEntCb       *entCb,     /* Entity Control Block                     */
SoEvnt        *request,   /* SIP Request message received             */
SoTptServerCb *serverCb,  /* Server connection that received message  */
SoTptClientCb *clientCb,  /* Client connection (For TCP Only)         */
CmTptAddr     *srcAddr    /* Source IP address                        */
)
#else
PRIVATE S16 soTptHandleReqInd (entCb, request, serverCb, clientCb, srcAddr)
SoEntCb       *entCb;     /* Entity Control Block                     */
SoEvnt        *request;   /* SIP Request message received             */
SoTptServerCb *serverCb;  /* Server connection that received message  */
SoTptClientCb *clientCb;  /* Client connection (For TCP Only)         */
CmTptAddr     *srcAddr;   /* Source IP address                        */
#endif
{
   S16          ret;
   SoVia        *via;
   SoTcmConn    tcmConn;
   SoTransCb    *transCb;
   SoCLegCb     *cLegCb;

   TRC2 (soTptHandleReqInd);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (entCb && request && serverCb && srcAddr))
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO187, (ErrVal) 0, "soTptHandleReqInd: "
                  "Invalid parameter");
      RETVALUE (RFAILED);
    }
#endif

   /*--- Store received client/server connection info in tcmConn ----*/
   transCb = (SoTransCb *) NULLP;
   cLegCb  = (SoCLegCb  *) NULLP;

   (Void) cmMemset ((U8 *)&tcmConn, 0, sizeof (SoTcmConn));
   tcmConn.clientCb = clientCb;
   tcmConn.serverCb = serverCb;

   SO_GET_VIA_FROM_EVENT (request, via);

   /*
    * STEP 1:
    * If sent-by field in TOP VIA header is not IP address, add "recei-
    * ved" parameter in VIA header containing sender's IP address.
    */
    if (soTptAddReceivedParamToVia (request, via, &tcmConn, srcAddr) != ROK)
        RETVALUE (RFAILED);
 
#ifdef SO_NS
    /*- STEP 2: For Stateless NS, Just Give Request To Core Layer --*/
    if ((entCb->entityType == LSO_ENT_NS) &&
        (entCb->s.ns.reCfg.proxyReCfg.prxState == LSO_PRX_STATELESS))
   {
      RETVALUE (soNsIncReq (entCb, request, &tcmConn));
   }
#endif /* SO_NS */

#ifdef SO_UA

   /*------------ Processing For UA and Stateful Proxy -------------*/

   /*-- STEP 2: Locate Server transaction(section 17.2.3 RFC 3261)--*/

    ret = soTxnMatchServerTrans (
                          entCb,   /* SIP Entity control block      */
                          request, /* SIP Request message received  */
                          &tcmConn,/* Client/Server information     */
                          via,     /* VIA header received message   */
                          &transCb /* TCB  (returned)               */
                          ); /*- so017.201: cLeg arguement removed -*/
    if (ret != ROK)
    {
        SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                   "\n[TCM] Server Transaction Matching Failed\n"));
        RETVALUE (RFAILED);
    }

   /*
    * If Transaction Control Block (TCB) is found, pass request to the
    * trasaction.
    */
    if (transCb)
    {
       /* 
        * Either retransmission or ACK for NON  2xx Response. Pass the
        * request to transaction.
        */
        ret = soTxnUaIncReq  (transCb, request, &tcmConn);

    } /* End of if (TCB Found) */
   /*
    * If NO TCB it indicates it is either NEW Request or ACK for 2xx (
    * INVITE) response.
    */
    else
    {
       /*----------- If ACK pass to dialog layer directly ----------*/
        if (SO_CMP_TKN_LIT (&request->eventType, SOT_ET_ACK))
        {
          /*- so017.201: cLeg arguement removed -*/
           ret = soDlgIncAck (entCb, request);
        }
       /* 
        * Else, its a new request.  Create a new transaction  and pass
        * request to newly created transaction.
        */
        else
        {
           transCb = soTxnUaCreateTrans (entCb, SO_UAS, request, (PTR) cLegCb, NULLP);
           if (transCb == NULLP)
                RETVALUE (RFAILED);

           ret = soTxnUaIncReq  (transCb, request, &tcmConn);
        }
    } /* End of else (NO TCB Found) */

#endif /* SO_UA */

    RETVALUE (ret);

} /* soTptHandleReqInd */



/*******************************************************************
*
*       Fun:   soTptHandleRspInd
*
*       Notes: This  function  handles SIP response message received
*              from peer node.
*              It searches for client  transaction control block and
*              passes the request to that transaction.
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptHandleRspInd
(
SoEntCb       *entCb,     /* Entity Control Block                     */
SoEvnt        *response,  /* SIP Response message received            */
SoTptServerCb *serverCb,  /* Server connection that received message  */
SoTptClientCb *clientCb   /* Client connection (For TCP Only)         */
)
#else
PRIVATE S16 soTptHandleRspInd (entCb, response, serverCb, clientCb)
SoEntCb       *entCb;     /* Entity Control Block                     */
SoEvnt        *response;  /* SIP Response message received            */
SoTptServerCb *serverCb;  /* Server connection that received message  */
SoTptClientCb *clientCb;  /* Client connection (For TCP Only)         */
#endif
{
   S16             ret;
   SoVia           *via;
   SoViaItem       *viaItem;
   SoTcmConn       tcmConn;
   SoTransCb       *transCb;

   TRC2 (soTptHandleRspInd);

   ret = ROK;
   via = NULLP;
   viaItem = NULLP;
   transCb = NULLP;

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (entCb && response && serverCb))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO188, (ErrVal) 0, "soTptHandleRspInd: "
                 "Invalid parameter");
      RETVALUE (RFAILED);
    }
#endif

   transCb = NULLP;

   /*--- Store received client/server connection info in tcmConn ----*/
   (Void) cmMemset ((U8 *)&tcmConn, 0, sizeof (SoTcmConn));
   tcmConn.clientCb = clientCb;
   tcmConn.serverCb = serverCb;

   /*
    * STEP 1:
    * Verify that TOP VIA  header element  corresponds to one of  local
    * server. Compare VIA sent-by host prot value against all of confi-
    * gured servers.  There  should  be atleast one server indicated by
    * VIA sent-by part.
    */
    SO_GET_VIA_FROM_EVENT (response, via);

    if (SO_GET_NUM_COMP (&via->numComp) < 1)
        RETVALUE (RFAILED);
      
    viaItem = via->viaItem[0];
       
    if (soCmpViaWithCfgServer (entCb, viaItem) == NULLP)
        RETVALUE (RFAILED);

#ifdef SO_NS
    /*- STEP 2: For Stateless NS, Just Give Response To Core Layer --*/
    if ((entCb->entityType == LSO_ENT_NS) &&
        (entCb->s.ns.reCfg.proxyReCfg.prxState == LSO_PRX_STATELESS))
   {
      /* 
       * For general case, delete TOP Via element of receiving the re-
       * sponse.
       * For NAT support, we still need  to keep  the top via in order
       * to know which transport server received the correspond reque-
       * st.
       */
#ifndef SO_NAT      
      (Void) soUtlDelTopViaElement (response);
#endif      
      RETVALUE (soNsIncRsp (entCb, response, &tcmConn));
   }
#endif

#ifdef SO_UA
   /*------------ Processing For UA and Stateful Proxy -------------*/

   /*-- STEP 2: Locate Client transaction(section 17.1.3 RFC 3261) --*/

    ret = soTxnMatchClientTrans (
                          entCb,    /* SIP Entity control block      */
                          response, /* SIP Response message received */
                          via,      /* VIA header receivded message  */
                          &transCb  /* TCB  (returned)               */
          );
    if (ret != ROK)
        RETVALUE (RFAILED);

   /*
    * If Transaction Control Block (TCB) is found,pass response to the
    * trasaction.
    */
    if (transCb)
    {
       /*------------- Response to existing transaction. -----------*/
        ret = soTxnUaIncRsp (transCb, response);
    } /* End of if (TCB Found) */
   /*
    * If NO TCB it may be either [1st] 2xx response (multiple or retr-
    * ansmitted or , [2nd] junk response.In either case pass the resp-
    * onse to dialog layer.
    */
    else
    {
        ret = soDlgIncRspFromTpt (entCb, response);
    } /* End of else (NO TCB Found) */

#endif /* SO_UA */

    RETVALUE (ret);

} /* soTptHandleRspInd */



/*******************************************************************
*
*       Fun:   soPrcUpdateTcmConnServer
*
*       Notes: This function is used to add context of tcmConn stru-
*              cture to given server connection. This function inse-
*              rts block containing tcmConn structure in linklist in
*              server control block.
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       Notes:
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soPrcUpdateTcmConnServer
(
SoTcmConn     *tcmConn,   /* control block to be inserted in hash list */
SoTptServerCb *serverCb   /* Server connection                         */
)
#else
PRIVATE S16 soPrcUpdateTcmConnServer (tcmConn, serverCb)
SoTcmConn     *tcmConn;   /* control block to be inserted in hash list */
SoTptServerCb *serverCb;  /* Server connection                         */
#endif
{
   TRC2(soPrcUpdateTcmConnServer);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (tcmConn))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO189, (ErrVal) 0, "soPrcUpdateTcmConnServer: "
                 "Invalid parameter");
      RETVALUE (RFAILED);
    }
#endif

   /* 
    * First, check if tcmConn is already  part of some server
    * control block link list.
    */
    if (tcmConn->serverCb != NULLP)
      cmLListDelFrm (&tcmConn->serverCb->tcmConnLst, &tcmConn->serverCbEnt);

   /*---------- Update server context in tcmConn ----------*/
    tcmConn->serverCb = serverCb;
   
   /*---- Return, if no server connection is specified ----*/
    if (serverCb)
    {
      /* 
       * Finally, insert tcmConn structure in server  control
       * block link list.
       */
       cmLListNode (&tcmConn->serverCbEnt) = (PTR) tcmConn;
       cmLListAdd2Tail (&serverCb->tcmConnLst, &tcmConn->serverCbEnt);
    }

   RETVALUE (ROK);

} /* soPrcUpdateTcmConnServer */



/*******************************************************************
*
*       Fun:   soPrcUpdateTcmConnClient
*
*       Notes: This function is used to add context of tcmConn stru-
*              cture to given client connection. This function inse-
*              rts block containing tcmConn structure in linklist in 
*              client control block.
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       Notes:
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soPrcUpdateTcmConnClient
(
SoTcmConn     *tcmConn,   /* control block to be inserted in hash list */
SoTptClientCb *clientCb   /* Client connection                         */
)
#else
PRIVATE S16 soPrcUpdateTcmConnClient (tcmConn, clientCb)
SoTcmConn     *tcmConn;   /* control block to be inserted in hash list */
SoTptClientCb *clientCb;  /* Client connection                         */
#endif
{
   TRC2(soPrcUpdateTcmConnClient);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (tcmConn))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO190, (ErrVal) 0, "soPrcUpdateTcmConnClient: "
                 "Invalid parameter");
      RETVALUE (RFAILED);
    }
#endif

   /* 
    * First, check if tcmConn is already  part of some client
    * control block link list.
    */
    if (tcmConn->clientCb != NULLP)
      cmLListDelFrm (&tcmConn->clientCb->tcmConnLst, &tcmConn->clientCbEnt);

   /*---------- Update client context in tcmConn ----------*/
    tcmConn->clientCb = clientCb;
   
   /*---- Return, if no client connection is specified ----*/
    if (clientCb)
    {
      /* 
       * Finally, insert tcmConn structure in client  control
       * block link list.
       */
       cmLListNode (&tcmConn->clientCbEnt) = (PTR) tcmConn;
       cmLListAdd2Tail (&clientCb->tcmConnLst, &tcmConn->clientCbEnt);
    }

    RETVALUE (ROK);

} /* soPrcUpdateTcmConnClient */





/*******************************************************************
*
*       Fun:   soTptUpdateViaHeader
*
*       Notes: The function is used to add appropriate VIA header to
*              a request message.  The function  also selects client 
*              and server connections to be  used  based on selected
*              VIA header.
*              If the VIA is already present, it will be validated.
*
*       Ret:   ROK on success.In this case clientCb and serverCb will
*              be updated.
*              
*              If failure, return SIP user related error code.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptUpdateViaHeader
(
SoEntCb       *entCb,    /* Entity Control Block                        */
SoSSapCb      *sSapCb,   /* Service User SAP Cb                         */
SoEvnt        *request,  /* SIP Request message to be sent (Updated)    */
CmTptAddr     *destAddr, /* Destination IP-address/port to send request */
U8            transport, /* transport portocol is UDP or TCP            */
TknStrOSXL    *branchId, /* Branch Id to be added in VIA item           */
SoTptServerCb **serverCb,/* Server connection (returned)                */ 
SoTptClientCb **clientCb /* Client connection (returned)                */
)
#else
PRIVATE S16 soTptUpdateViaHeader (entCb, sSapCb, request, destAddr, 
                                  transport, branchId, serverCb, clientCb)
SoEntCb       *entCb;    /* Entity Control Block                        */
SoSSapCb      *sSapCb;   /* Service User SAP Cb                         */
SoEvnt        *request;  /* SIP Request message to be sent  (Updated)   */
CmTptAddr     *destAddr; /* Destination IP-address/port to send request */
U8            transport; /* transport portocol is UDP or TCP            */
TknStrOSXL    *branchId; /* Branch Id to be added in VIA item           */
SoTptServerCb **serverCb;/* Server connection (returned)                */ 
SoTptClientCb **clientCb;/* Client connection (returned)                */
#endif
{
   S16       ret;
   SoVia     *via;
   SoViaItem *viaItem;

   TRC2(soTptUpdateViaHeader);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (!entCb)
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO191, (ErrVal) 0, "soTptUpdateViaHeader:"
                 " Invalid parameter");
      RETVALUE (SOT_ERR_UNKNOWN);
    }
#endif

   /*
    * Check if  user  has  already  inserted  VIA header in request. 
    * NOTE: AT UA side user is allowed to insert its  own VIA header
    *       but at NS side user is NOT allowed to insert VIA header.
    * NOTE: If NAT is used, then VIA  header will  be  provded at NS 
    *       side too.
    */

    if ((soCmFindHdrChoice (request, (U8 **) &via, SO_HEADER_GEN_VIA) == ROK)
#if (!(defined (SO_NAT)) || !(defined (SO_USE_UDP_SRVR)))
       && (entCb->entityType == LSO_ENT_UA)
#endif
      )
    {
       /*- Select server and client connection based on VIA info -*/
       viaItem = soTptViaValidateAndSelConn (entCb, via, destAddr,
                                   transport, serverCb, clientCb);
       if (viaItem == NULLP)
           RETVALUE (SOT_ERR_VIA_INVALID);
    }

    else
    {
       /*--------------- VIA header NOT present. -----------------*/

       /*---- Step 1:  Select Transport Server ---*/

        ret = soTptSelectServer (entCb, sSapCb, transport, serverCb);
        if (ret != ROK)
           RETVALUE (ret);

       /*---- Step 2: Open client connection  ----*/
       /* so027.201: Changes for SIP TLS support */
        ret = soTptOpenClient (entCb,
#ifdef SO_TLS
                               sSapCb,
#endif
                               *serverCb, /* Server Connection     */
                               destAddr,  /* Remote address        */
                               (*serverCb)->tptProt,/* TCP or UDP  */
                               clientCb   /* New Client Connection */
                              );
        if (ret != ROK)
           RETVALUE (ret);

       /*-- Step 3: Add VIA in request messagge --*/
        viaItem = soTptAddVia (entCb, request, *serverCb);
        if (viaItem == NULLP)
           RETVALUE (SOT_ERR_UNKNOWN);

    } /* End of else (VIA Not present in request) */
           
    /*-- ADD branchId parameter to TOP VIA Item --*/
    if (soTptAddBranchIdInVIA (viaItem, branchId, request) != ROK)
        RETVALUE (SOT_ERR_UNKNOWN);

#if SO_COMPRESS
    /*--- ADD compression supported identifier ---*/
    if (soTptAddCompSupport (entCb, viaItem, request) != ROK)
        RETVALUE (SOT_ERR_UNKNOWN);
#endif

#ifdef SO_NAT
    /* 
     * if we are  configured to send  requests  with
     * rport parameter,we should add rport parameter
     */
    if ((entCb->addRportByDflt == TRUE) &&
        (soTptAddRportInVIA (viaItem, request) != ROK))
         RETVALUE (SOT_ERR_UNKNOWN);
#endif

   RETVALUE (ROK);

} /* soTptUpdateViaHeader */




/*******************************************************************
*
*       Fun:   soTptViaValidateAndSelConn
*
*       Notes: The function is used to validate VIA header in reque-
*              st message.  VIA is correct,  if it contains  sent-by
*              indicating one of open servers. If VIA is correct,the 
*              function  also selects client  and server connections
*              based on VIA selected VIA header.
*
*       Ret:   viaItem on success.  viaItem points to TOP VIA header
*              element.
*              NULLP on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE SoViaItem *soTptViaValidateAndSelConn
(
SoEntCb       *entCb,    /* Entity Control Block                        */
SoVia         *via,      /* VIA header in request message               */
CmTptAddr     *destAddr, /* Destination IP-address/port to send request */
U8            transport, /* transport portocol is UDP or TCP            */
SoTptServerCb **serverCb,/* Server connection (returned)                */ 
SoTptClientCb **clientCb /* Client connection (returned)                */
)
#else
PRIVATE SoViaItem *soTptViaValidateAndSelConn (entCb, via, destAddr, transport, serverCb, clientCb)
SoEntCb       *entCb;    /* Entity Control Block                        */
SoVia         *via;      /* VIA header in request message               */
CmTptAddr     *destAddr; /* Destination IP-address/port to send request */
U8            transport; /* transport portocol is UDP or TCP            */
SoTptServerCb **serverCb;/* Server connection (returned)                */ 
SoTptClientCb **clientCb;/* Client connection (returned)                */
#endif
{
   S16         ret;
   SoViaItem   *viaItem;

   TRC2(soTptViaValidateAndSelConn);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (entCb && via && destAddr && serverCb && clientCb))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO192, (ErrVal) 0, "soTptViaValidateAndSelConn: "
                 "Invalid parameter");
      RETVALUE (NULLP);
    }
#endif

    (*serverCb) = NULLP;
    (*clientCb) = NULLP;

    /*-------- Extract the TOP VIA header element ---------*/
      if (SO_GET_NUM_COMP (&via->numComp) < 1)
        RETVALUE (NULLP);
      
      viaItem = via->viaItem[0];

    /*
     * If the protocol  specified  in VIA header by SU is  NOT
     * same as one provided by transaction user (dialog layer)
     * , simply overwrite the one provided by SU.
     */
    SO_FILL_TKNU8 (&viaItem->sentProtocol.transport.type,  SO_EXTVAL_STD);
    SO_FILL_TKNU8 (&viaItem->sentProtocol.transport.t.std, transport);
 
    /*
     * Compare VIA sent-by host port value against all of the
     * configured servers. There should be atleast one server
     * indicated by hostPort part.
     */
     (*serverCb) = soCmpViaWithCfgServer (entCb, viaItem);

    /*
     * If not matching server connection found, it indicates
     * VIA header field is not correct.
     */
     if (*serverCb == NULLP)
     {
       SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
              "\nsoTptViaSelConn: Wrong VIA specified by SU.\n"));

       RETVALUE (NULLP);
     }

    /*
     * Finally open client connection based on the server c-
     * onnection.
     */
     /* so027.201: Changes for SIP TLS support */
     ret = soTptOpenClient (entCb,
#ifdef SO_TLS
                            NULLP,
#endif
                            *serverCb,/* Server Connection     */
                            destAddr, /* Remote address        */
                            (*serverCb)->tptProt,/* TCP or UDP */
                            clientCb   /* New Client Connection*/
                            );
     if (ret != ROK)
     {
       (*serverCb) = NULLP;
       RETVALUE (NULLP);
     }

     RETVALUE (viaItem);

} /* soTptViaValidateAndSelConn */




/*******************************************************************
*
*       Fun:   soTptSelectServer
*
*       Notes: The function is used to  select transport  server for
*              outgoing request message. For outgoing request, tran-
*              sport server is required to fill VIA header.
*
*              Transport server is selected based on round robin fa-
*              shion among all possible servers.
*
*       Ret:   ROK on success. In this case serverCb is updated.
*              SOT_ERR_UNKNOWN on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC S16 soTptSelectServer
(
SoEntCb       *entCb,    /* Entity Control Block                   */
SoSSapCb      *sSapCb,   /* Service User SAP Cb                    */
U8            transport, /* Transport protocol to be used (TCP/UDP)*/
SoTptServerCb **serverCb /* Server connection (returned)           */ 
)
#else
PUBLIC S16 soTptSelectServer (entCb, sSapCb, transport, serverCb)
SoEntCb       *entCb;    /* Entity Control Block                   */
SoSSapCb      *sSapCb;   /* Service User SAP Cb                    */
U8            transport; /* Transport protocol to be used (TCP/UDP)*/
SoTptServerCb **serverCb;/* Server connection (returned)           */ 
#endif
{
   U16            i, j;
   U16            *idx;
   SoTptServerCb  *tempServerCb;
   /* so027.201: Changes for SIP TLS support */
#ifdef SO_TLS
   Bool           checkTlsContextId = TRUE;
#endif /* SO_TLS */

   TRC2(soTptSelectServer);

   i   = 0;
   idx = NULLP;
   tempServerCb = NULLP;

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (entCb && serverCb))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO193, (ErrVal) 0, "soTptSelectServer: "
                 "Invalid parameter");
      RETVALUE (SOT_ERR_UNKNOWN);
    }
#endif

    (*serverCb) = NULLP;

    /* 
     * Select transport server  belonging to this  entity and
     * for the transport protocol. Selection is done based on
     * round robin fashion,starting from last selected server
     */ 

     if (transport == LSO_TPTPROT_UDP)
         idx = &entCb->currentUDPSrv;
#ifdef SO_TLS
     else if (transport == LSO_TPTPROT_TLS_TCP)
         idx = &entCb->currentTLSSrv;
#endif
     else
         idx = &entCb->currentTCPSrv;

   /* so027.201: Changes for SIP TLS support */
#ifdef SO_TLS
     if (transport == LSO_TPTPROT_TLS_TCP && sSapCb != NULLP &&
         sSapCb->cfg.tlsCtxId == LSO_TLS_DEFAULT_CTX)
         checkTlsContextId = FALSE;
#endif /* SO_TLS */

     /*-- For Each Server in system --*/
     while (i < soCb.maxTptSrv)
     {
        if ((*idx) == soCb.maxTptSrv) (*idx) = 0;

        tempServerCb = soCb.allSrvCbLst[*idx];

        (*idx) += 1;
        if ((tempServerCb == NULLP) ||
           /* Server does belongs not to entity  */
            (tempServerCb->entCb != entCb) ||
           /*      Server is not enabled         */
            (tempServerCb->state != LSO_TPTSRV_ENA) ||
           /*      Ignore multicast server       */
            (SO_TCM_SERVER_MCAST (tempServerCb) == TRUE) || 
           /* Server protocol must match         */
            ((transport == LSO_TPTPROT_UDP) && !(SO_TCM_UDP_TRANSPORT (tempServerCb->tptProt)))  ||
            ((transport == LSO_TPTPROT_TCP) && !(SO_TCM_TCP_TRANSPORT (tempServerCb->tptProt)))  ||
            ((transport == LSO_TPTPROT_TLS_TCP) && !(SO_TCM_TLS_TRANSPORT (tempServerCb->tptProt))))
        {
           /*--- This server is no match. Check next one --*/
           i++;
           continue;
        }

       /*-- Verify that this server serves the given sSap -*/
        if (sSapCb != NULLP)
        {
           for (j = 0; j < tempServerCb->nmbSSap; j++)
             if (tempServerCb->sSapLst[j] == sSapCb->sapId)
                break;

          if (j == tempServerCb->nmbSSap)
          {
             /*- This server is no match. Check next one --*/
             i++;
             continue;
          }
        }

   /* so027.201: Changes for SIP TLS support */
#ifdef SO_TLS
        if (checkTlsContextId == TRUE)
        {
           if (i == soCb.maxTptSrv - 1)
           {
              i = 0;
              checkTlsContextId = FALSE;
           }

           /* See if tls context id matches */
           if (transport == LSO_TPTPROT_TLS_TCP)
           {
              if (sSapCb && 
                 (tempServerCb->tPar.u.tlsParam.ctxId != sSapCb->cfg.tlsCtxId))
              {
                 i++;
                 continue;
              }
           }
        }
#endif /* SO_TLS */

       /* 
        * Found the matching server  connection  and thus the
        * VIA field is also verified.
        */
        (*serverCb) = tempServerCb;
        break;
                              
     } /* End of while (each server connection) */

     /*
      * If not matching server connection found, it indicates
      * incorrect configuration.
      */
     if (*serverCb == NULLP)
     {
         SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
               "\nsoTptSelectServer: NO Valid Transport Server\n"));

         RETVALUE (SOT_ERR_TPTSRVR_SELECT);
     }

     RETVALUE (ROK);

} /* soTptSelectServer */



/*******************************************************************
*
*       Fun:   soTptAddVia
*
*       Notes: The  function  is used to add local node's VIA header 
*              in a outgoing request message. Transport server is u-
*              sed to fill VIA header.
*
*       Ret:   viaItem on success.  viaItem points to TOP VIA header
*              element.
*              NULLP on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC SoViaItem *soTptAddVia
(
SoEntCb       *entCb,    /* Entity Control Block                  */
SoEvnt        *request,  /* SIP Request message to be sent        */
SoTptServerCb *serverCb  /* Server connection                     */ 
)
#else
PUBLIC SoViaItem *soTptAddVia (entCb, request, serverCb)
SoEntCb       *entCb;    /* Entity Control Block                  */
SoEvnt        *request;  /* SIP Request message to be sent        */
SoTptServerCb *serverCb; /* Server connection                     */ 
#endif
{ 
   S16             ret;
   U16             i;
   SoVia           *via;
   SoViaItem       *viaItem;
   SoHostPortType  *sentBy;
   SoSentProtocol  *sentProt;
   U16             viaComp;

   TRC2(soTptAddVia);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (entCb && request && serverCb))
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO194, (ErrVal) 0,  "soTptAddVia: "
                 "Invalid parameter");
      RETVALUE (NULLP);
    }
#endif

   /*-- Find and if required, add VIA header in event structure --*/
   /*
    * NOTE: In case of UA, no VIA header will be present. But in ca-
    *       se of NA, VIA header will be present and we need  to add
    *       one more viaitem on top.
    */
#ifdef SO_NS
    ret = soCmFindHdrChoice (request, (U8 **) &via,
                             SO_HEADER_GEN_VIA);
    if (ret != ROK)
    {
#endif
      /*---- No Via headers, must create one ----*/
       ret = soCmCreateHdrChoice (request, 
                                  (U8 **) &via,
                                  SO_HEADER_GEN_VIA);
       if (ret != ROK)
         RETVALUE (NULLP);
#ifdef SO_NS
    }
#endif

   /*----- Grow event structure to add viaItem in VIA header -----*/
    ret = soCmGrowList ((Void ***)&via->viaItem,
                        sizeof (SoViaItem),
                        &via->numComp,
                        request);
    if (ret != ROK)
      RETVALUE (NULLP);

   /*--- Save newly allocated pointer ---*/
    viaComp = SO_GET_NUM_COMP (&via->numComp);
    viaItem = via->viaItem[viaComp - 1];

   /*--- Move other viaItems down the list (Valid for NS Only) ---*/
    for (i = (U16)(viaComp - 1); i > 0; i--)
       via->viaItem[i] = via->viaItem[i - 1];

   /* New Via Item must be the first in the list -  index is zero */
    via->viaItem[0] = viaItem;

   /*--- Finally, fill all elements of newly created VIA Item ----*/

    (Void) cmMemset ((U8 *)viaItem, 0, (PTR)sizeof (SoViaItem));

    SO_FILL_TKNU8 (&viaItem->pres, PRSNT_NODEF);

    /*-- Fill Sent-By value using server address --*/
     sentBy = &viaItem->sentBy;
     SO_FILL_TKNU8 (&sentBy->type,            SO_SENTBY_HOSTPORT);
     SO_FILL_TKNU8 (&sentBy->t.hostPort.pres, PRSNT_NODEF);

     ret = soCmTptAddrToHostPort (&sentBy->t.hostPort,
                                  &serverCb->localAddr,
                                  request);
     if (ret != ROK)
       RETVALUE (NULLP);

    /*-- Add SIP/2.0/[UDP|TCP] in SoSentProtocol --*/
     sentProt = &viaItem->sentProtocol;
     SO_FILL_TKNU8 (&sentProt->pres, PRSNT_NODEF);
     SO_FILL_TKNU8 (&sentProt->protocolName.protocolNameType,
                    SO_PROTOCOLNAME_SIP);

     SO_FILL_TKNSTROSXL (&sentProt->protocolVersion, soCb.cfg.protVer,
                         cmStrlen ((U8 *)soCb.cfg.protVer),  request, ret);
     if (ret != ROK)
       RETVALUE (NULLP);

     SO_FILL_TKNU8 (&sentProt->transport.type,  SO_EXTVAL_STD);

     if (SO_TCM_UDP_TRANSPORT (serverCb->tptProt))
       SO_FILL_TKNU8 (&sentProt->transport.t.std, LSO_TPTPROT_UDP)
     else
       SO_FILL_TKNU8 (&sentProt->transport.t.std, serverCb->tptProt)


     RETVALUE (viaItem);

} /* soTptAddVia */


#ifdef SO_NAT

/*******************************************************************
*
*       Fun:   soTptAddRportInVIA
*
*       Notes: The  function  is used to add rport in viaItem.
*
*       Ret:   ROK on success.
*              SOT_ERR_UNKNOWN on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptAddRportInVIA
(
SoViaItem     *viaItem,  /* VIA item pointer                   */
SoEvnt        *request   /* SIP Request message to be sent     */
)
#else
PRIVATE S16 soTptAddRportInVIA (viaItem, request)
SoViaItem     *viaItem;  /* VIA item pointer                   */
SoEvnt        *request;  /* SIP Request message to be sent     */
#endif
{ 
   S16        ret;
   U16        vpComp;
   Bool       alreadyPres;
   U8         i;

   TRC2 (soTptAddRportInVIA);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (viaItem && request))
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO195, (ErrVal) 0,  
                  "soTptAddRportInVIA: Invalid parameter");
      RETVALUE (SOT_ERR_UNKNOWN);
    }
#endif

   alreadyPres = FALSE;

   /*---- Do nothing if "rPort" parameter is already present -----*/

   vpComp = SO_GET_NUM_COMP (&viaItem->viaParams.numComp);

   for (i = 0; i < vpComp;  i++)
   {
      if (SO_CMP_TKN_LIT (&viaItem->viaParams.viaParam[i]->
               viaParamType, SO_VIAPARAM_VIARPORT) == TRUE)
      RETVALUE (ROK);
   }

   /*------------- Add "rPort" parameter is Via Item -------------*/

   ret = soCmGrowList ((Void ***)&viaItem->viaParams.viaParam,
                       sizeof (SoViaParam),
                       &viaItem->viaParams.numComp,
                       request);
   if (ret != ROK)
      RETVALUE (SOT_ERR_UNKNOWN);

   vpComp = SO_GET_NUM_COMP (&viaItem->viaParams.numComp);

   SO_FILL_TKNU8 (&viaItem->viaParams.viaParam[vpComp - 1]->
                  viaParamType, SO_VIAPARAM_VIARPORT);
   
   viaItem->viaParams.viaParam[vpComp - 1]->t.viaRport.pres = NOTPRSNT;
   
   RETVALUE (ROK);

} /* soTptAddRportInVIA */

#endif /* SO_NAT */


/*******************************************************************
*
*       Fun:   soTptAddBranchIdInVIA
*
*       Notes: The  function  is used to add branchId in viaItem.
*
*       Ret:   ROK on success.
*              SOT_ERR_UNKNOWN on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptAddBranchIdInVIA
(
SoViaItem     *viaItem,  /* VIA item pointer                   */
TknStrOSXL    *branchId, /* Branch Id to be added in VIA item  */
SoEvnt        *request   /* SIP Request message to be sent     */
)
#else
PRIVATE S16 soTptAddBranchIdInVIA (viaItem, branchId, request)
SoViaItem     *viaItem;  /* VIA item pointer                   */
TknStrOSXL    *branchId; /* Branch Id to be added in VIA item  */
SoEvnt        *request;  /* SIP Request message to be sent     */
#endif
{ 
   S16        ret;
   U16        vpComp;
   TknStrOSXL *tempBranchId;

   TRC2(soTptAddBranchIdInVIA);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (viaItem && request))
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO196, (ErrVal) 0,  "soTptAddBranchIdInVIA: "
                 "Invalid parameter");
      RETVALUE (SOT_ERR_UNKNOWN);
    }
#endif

     if (branchId == NULLP)
        RETVALUE (ROK);

    /*--------- Fill branch Id in VIA Item parameter ---------*/

     /*-- Add SoViaBranch structure to the via's parameters --*/

      ret = soCmGrowList ((Void ***)&viaItem->viaParams.viaParam,
                          sizeof (SoViaParam),
                          &viaItem->viaParams.numComp,
                          request);
      if (ret != ROK)
        RETVALUE (SOT_ERR_UNKNOWN);

     /*----------- Now fill SoViaBranch structure ------------*/

      vpComp = SO_GET_NUM_COMP (&viaItem->viaParams.numComp);

      SO_FILL_TKNU8(
         &viaItem->viaParams.viaParam[vpComp - 1]->viaParamType,
         SO_VIAPARAM_VIABRANCH);

      tempBranchId =
          &viaItem->viaParams.viaParam[vpComp - 1]->t.viaBranch;

      ret = soUtlCpyTknStrOSXL (tempBranchId,
                                branchId,
                                &request->memCp);
      if (ret != ROK)
        RETVALUE (SOT_ERR_UNKNOWN);

     RETVALUE (ROK);

} /* soTptAddBranchIdInVIA */





/*******************************************************************
*
*       Fun:   soTptSelectClientForRsp
*
*       Notes: This function finds the client connection to send the
*              response message. tcmConn field may contain the clie-
*              nt connection on  which initial request was received. 
*
*       Ret:   ROK on success. In this case clientCb and serverCb p-
*              ointers are updated. Also destination node address is
*              updated.
*
*              If failure, return SIP user related error code.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptSelectClientForRsp
(
SoEntCb       *entCb,    /* Entity Control Block           */
SoSSapCb      *sSapCb,   /* Service User SAP Cb            */
SoVia         *via,      /* VIA header of response message */
SoTcmConn     *tcmConn,  /* TCP/UDP connection information */
CmTptAddr     *destAddr, /* Destination address (returned) */
SoTptServerCb **serverCb,/* Server connection (returned)   */
SoTptClientCb **clientCb /* Client connection (returned)   */
)
#else
PRIVATE S16 soTptSelectClientForRsp (entCb, sSapCb, via, tcmConn, 
                                     destAddr, serverCb, clientCb)
SoEntCb       *entCb;    /* Entity Control Block           */
SoSSapCb      *sSapCb;   /* Service User SAP Cb            */
SoVia         *via;      /* VIA header of response message */
SoTcmConn     *tcmConn;  /* TCP/UDP connection information */
CmTptAddr     *destAddr; /* Destination address (returned) */
SoTptServerCb **serverCb;/* Server connection (returned)   */
SoTptClientCb **clientCb;/* Client connection (returned)   */
#endif
{
   S16        ret;
   U8         transport;
   SoViaItem  *viaItem;

   TRC2(soTptSelectClientForRsp);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (via && tcmConn && clientCb && serverCb))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO197, (ErrVal) 0, "soTptSelectClientForRsp: "
                 "Invalid parameter");
      RETVALUE (SOT_ERR_UNKNOWN);
    }
#endif

    (*clientCb) = NULLP;
    (*serverCb) = NULLP;
    (Void) cmMemset ((U8 *)destAddr, 0, sizeof (CmTptAddr));

   /*----------------- Extract TOP VIA element -------------------*/
    if (SO_GET_NUM_COMP (&via->numComp) < 1)
       RETVALUE (SOT_ERR_VIA_INVALID);
      
    viaItem = via->viaItem[0];
       
   /*
    * First select server connection to sent response. This is requ-
    * ONLY for UDP transport where the server  connection is used to
    * send response.
    */

#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
    /*
     * For NAT support, we must use the server connnection that rec-
     * eived corresponding request for this response. 
     */
    if(tcmConn->serverCb == NULLP)
       RETVALUE (RFAILED);
#endif

    if (tcmConn->serverCb)
       /* Can use server connection on which request was received */
       (*serverCb) = tcmConn->serverCb;
    else
    {
       /* 
        * LM might have deleted original server,  simply select  any
        * available server.
        */
       transport = viaItem->sentProtocol.transport.t.std.val;
       
       ret = soTptSelectServer (entCb, sSapCb, transport, serverCb);
       if (ret != ROK)
          RETVALUE (ret);
    }

   /*
    * If the client connection on which request message was received
    * (or on which previous response was send)  is  still  open, use 
    * that connection.
    */
    if ((tcmConn->clientCb) && (tcmConn->serverCb) &&
        (tcmConn->clientCb->state == SO_TPT_CLIENT_ACTIVE))
    {
      (*clientCb) = tcmConn->clientCb;
      /*--- NO Need to update destination address ---*/
      RETVALUE (ROK);
    }

   /*
    * Original client connection is no longer active. Find the dest-
    * ination address from "received"  parameter  of TOP  VIA header
    * elememt. Then open client connection to this destination.
    */
    ret = soTptGetDestAddrFromVia (viaItem, destAddr);
    if (ret != ROK)
      RETVALUE (ret);

    /* so027.201: Changes for SIP TLS support */
    ret = soTptOpenClient (entCb,
#ifdef SO_TLS
                           sSapCb,
#endif
                           (*serverCb),/* Server Conn           */
                           destAddr,   /* Remote address/port   */
                           (*serverCb)->tptProt,/* TCP or UDP   */
                           clientCb);  /* New Client Connection */
    if (ret != ROK)
      RETVALUE (ret);

    RETVALUE (ROK);

} /* soTptSelectClientForRsp */



/*******************************************************************
*
*       Fun:   soTptGetDestAddrFromVia
*
*       Notes: This function gets destination address from "received"
*              parameter of viaItem. This address is converted to Tp-
*              tAddr format and returned to caller.
*
*       Ret:   ROK on success. In this case destAddr is updated.
*              SOT_ERR_UNKNOWN on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptGetDestAddrFromVia
(
SoViaItem   *viaItem,  /* TOP VIA header of response message            */
CmTptAddr   *destAddr  /* Destination addr in received param (returned) */
)
#else
PRIVATE S16 soTptGetDestAddrFromVia (viaItem, destAddr)
SoViaItem   *viaItem;  /* TOP VIA header of response message            */
CmTptAddr   *destAddr; /* Destination addr in received param (returned) */
#endif
{
   S16        ret;
   U16        i;
   U32        port;
   SoHost     *received;
   SoViaParam *viaParam; 
#if (defined(SO_NAT) && defined(SO_USE_UDP_SRVR))
   Bool       maddrPres;
   U32        rport;
#endif

   TRC2(soTptGetDestAddrFromVia);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (viaItem && destAddr))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO198, (ErrVal) 0, "soTptGetDestAddrFromVia: "
                 "Invalid parameter");
      RETVALUE (SOT_ERR_UNKNOWN);
    }
#endif

   received  = NULLP;
#if (defined(SO_NAT) && defined(SO_USE_UDP_SRVR))
   maddrPres = FALSE;
   rport     = 0;
#endif

  /*------ Find the port to be used from VIA hostPort field ------*/
  /*------ so018.201: Default action is TRUE for NAT as well -----*/
   (port) = SO_PORT_DEFAULT;

#ifdef SO_TLS
  /* so035.201: Default port in case of TLS is 5061 */
   if ((viaItem->sentProtocol.pres.pres != NOTPRSNT) &&
       (viaItem->sentProtocol.transport.type.pres != NOTPRSNT) &&
       (viaItem->sentProtocol.transport.type.val == SO_TRANSPORT_TRANSPORTSTD))
   {
      if (viaItem->sentProtocol.transport.t.std.val == LSO_TPTPROT_TLS_TCP)
         (port) = SO_PORT_TLS_DEFAULT;
   }
#endif

   if (viaItem->sentBy.t.hostPort.port.pres != NOTPRSNT)
       port = viaItem->sentBy.t.hostPort.port.val;

  /*---------- Find the "received" parameter in viaItem  ---------*/
  /*-- If NAT is used, also find  "mcast" and "rport" parameter --*/
   for (i = 0; i < SO_GET_NUM_COMP (&viaItem->viaParams.numComp); i++)
   {
      viaParam = viaItem->viaParams.viaParam[i];

      if (SO_CMP_TKN_LIT (&viaParam->viaParamType,
                          SO_VIAPARAM_RECEIVED) == TRUE)
         received = &viaParam->t.received;

#if (defined(SO_NAT) && defined(SO_USE_UDP_SRVR))
      if (SO_CMP_TKN_LIT (&viaParam->viaParamType,
                          SO_VIAPARAM_MADDR) == TRUE)
         maddrPres = TRUE;

      if (SO_CMP_TKN_LIT (&viaParam->viaParamType,
                          SO_VIAPARAM_VIARPORT) == TRUE)
         rport = viaParam->t.viaRport.val;
#endif
   }

#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
   /*------------------ NAT Feature In Required ------------------*/
   /*
    * If NAT Is Required, we must send  response  to the IP  address
    * listed in "received" and"rport", only if all of the below con-
    * ditions are met
    *        transport is UDP
    *        there is no Via maddr
    *        there is both "received" and "rport" parameter
    */
    if ((!maddrPres) &&
        (received)   &&
        (rport)      &&
        (viaItem->sentProtocol.transport.t.std.val == LSO_TPTPROT_UDP))
        port = rport;
  
   /* 
    * so018.201: Redundant check removed. Port for NAT, if required,
    * will be calculated in above "if" statement.
    */
#endif

   if (received == NULLP)
   {
     /* 
      * No received parameter in VIA header.It implies hostPort part
      * of VIA MUST have the destination IP address.
      */
      received = &viaItem->sentBy.t.hostPort.host;
   }
  
  /*----- Convert host port to Transport (tpt) address format ----*/
   ret = soCmHostPortToTptAddr (received, port, destAddr);
   if (ret != ROK)
      RETVALUE (SOT_ERR_UNKNOWN);


   RETVALUE (ROK);

} /* soTptGetDestAddrFromVia */




/*******************************************************************
*
*       Fun:   soTptAddReceivedParamToVia
*
*       Notes: This function used to add "received" parameter in top
*              VIA element. The "received" parameter contains source 
*              IP address of node that send the request.
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptAddReceivedParamToVia
(
SoEvnt        *request,   /* SIP Request message received             */
SoVia         *via,       /* VIA in request message                   */
SoTcmConn     *tcmConn,   /* TCP/UDP connection information           */
CmTptAddr     *srcAddr    /* Source IP address                        */
)
#else
PRIVATE S16 soTptAddReceivedParamToVia (request, via, tcmConn, srcAddr)
SoEvnt        *request;   /* SIP Request message received             */
SoVia         *via;       /* VIA in request message                   */
SoTcmConn     *tcmConn;   /* TCP/UDP connection information           */
CmTptAddr     *srcAddr;   /* Source IP address                        */
#endif
{
   S16           ret;
   SoViaItem     *viaItem;
   SoHostPort    remHostPort;
   U16           vpComp;
#if (defined(SO_NAT) && defined(SO_USE_UDP_SRVR))
   U16           i;
#endif   

   TRC2 (soTptAddReceivedParamToVia);

#if (ERRCLASS & ERRCLS_DEBUG)
     if (! (request && via && tcmConn && srcAddr))
     {
       SOLOGERROR (ERRCLS_DEBUG, ESO199, (ErrVal) 0, 
               "soTptAddReceivedParamToVia: Invalid parameter");
       RETVALUE (RFAILED);
    }
#endif

    cmMemset ((U8 *)&remHostPort, 0, (PTR)sizeof (SoHostPort));

    ret = soCmTptAddrToHostPort (&remHostPort, srcAddr, NULLP);
    if (ret != ROK)
       RETVALUE (RFAILED);
    
    /*-------- Extract the TOP VIA header element ---------*/

     if (SO_GET_NUM_COMP (&via->numComp) < 1)
       RETVALUE (RFAILED);
      
     viaItem = via->viaItem[0];

    /*--------- Verify that VIA Item is correct -----------*/
     if (SO_CMP_TKN_LIT (&viaItem->sentBy.type, SO_SENTBY_HOSTPORT) != TRUE)
     {
        SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
          "soTptAddReceivedParamToVia: Concealed host not supported\n"));
        RETVALUE (RFAILED);
     }
     
    
    /*
     * Check if we need to add "recived" parameter."received"
     * parameter is added if (1st) sent-by field contains do-
     * main name or (2nd)  IP address in sent-by is different
     * from the source address from which request message was 
     * received.
     */
#ifndef SO_NAT
     /*-- Compare sent-by with source address --*/
      ret = soCmCompareHost (&remHostPort.host, 
                             &viaItem->sentBy.t.hostPort.host);
      if (ret == ROK)
      {
        (Void) soUtlDelSoHostPort (&remHostPort);
        RETVALUE (ROK);
      }

     /*---- sent-by not same as source addr. ----*/
#endif

     /*-- we need to add "received" paramter. ---*/
     /*
      * NOTE: For NAT is used, we always add recei-
      * ved parameter.
      */
      ret = soCmGrowList ((Void ***) &viaItem->viaParams.viaParam,
                           sizeof (SoViaParam),
                           &viaItem->viaParams.numComp,
                           request);
      if (ret != ROK)
      {
        (Void) soUtlDelSoHostPort (&remHostPort);
         RETVALUE (RFAILED);
      }

      vpComp = SO_GET_NUM_COMP (&viaItem->viaParams.numComp);

      SO_FILL_TKNU8(
           &viaItem->viaParams.viaParam[vpComp - 1]->viaParamType,
           SO_VIAPARAM_RECEIVED);

      SO_CPY_HOST (&viaItem->viaParams.viaParam[vpComp - 1]->t.received,
                   &remHostPort.host,
                   request, ret);
      if (ret != ROK)
      {
        (Void) soUtlDelSoHostPort (&remHostPort);
         RETVALUE (RFAILED);
      }

     (Void) soUtlDelSoHostPort (&remHostPort);

#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
    /* 
     * If NAt is used, and VIA element contains "rport" paramete-
     * r with no value, set its value to the source addr port
     */

     vpComp = SO_GET_NUM_COMP (&viaItem->viaParams.numComp);

     for (i = 0; i < vpComp;  i++)
       if (SO_CMP_TKN_LIT(
             &viaItem->viaParams.viaParam[i]->viaParamType,
             SO_VIAPARAM_VIARPORT) == TRUE)
       {
          SO_FILL_TKNU32 (&viaItem->viaParams.viaParam[i]->t.
                          viaRport, remHostPort.port.val);
       }
#endif

     RETVALUE (ROK);

} /* soTptAddReceivedParamToVia */




/*******************************************************************
*
*       Fun:   soCmpViaWithCfgServer
*
*       Notes: The function is used to compare sent-by  value of VIA
*              header against all configured servers. 
*
*       Ret:   serverCb on success.
*              NULLP on error.
*
*       File:  so_tcm.c
*
*******************************************************************/
#ifdef ANSI
PUBLIC SoTptServerCb *soCmpViaWithCfgServer
(
SoEntCb       *entCb,    /* Entity Control Block   */
SoViaItem     *viaItem   /* TOP VIA Header Item    */
)
#else
PUBLIC SoTptServerCb *soCmpViaWithCfgServer (entCb, viaItem)
SoEntCb       *entCb;    /* Entity Control Block   */
SoViaItem     *viaItem;  /* TOP VIA Header Item    */
#endif
{
   SoTptServerCb  *serverCb;
   SoHostPort     *viaHostPort;

   TRC2 (soCmpViaWithCfgServer);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (entCb && viaItem))
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO200, (ErrVal) 0, "soCmpViaWith"
                  "CfgServer: Invalid parameter");
      RETVALUE (NULLP);
    }
#endif

    /*---- VIA hostprot in hidden format not supported ----*/
      if (SO_CMP_TKN_LIT (&viaItem->sentBy.type,
                          SO_SENTBY_HOSTPORT) != TRUE)
         RETVALUE (NULLP);
        
    /* 
     * Compare VIA sent-by host prot value against all of the
     * configured servers. There should be atleast one server
     * indicated by hostPort part.
     */
     viaHostPort = &viaItem->sentBy.t.hostPort;

     serverCb = soUtlAddrWithCfgServer(entCb, 
                                viaHostPort, 
                                viaItem->sentProtocol.transport.t.std.val); 
     RETVALUE (serverCb);

} /* soCmpViaWithCfgServer */



/****************************************************************
*
*   Fun:  soTptOpenClient

*   Desc: This function opens TCP connection to a remote address.
*         It allocates transport  client connection control block
*         (CCB) and sends HitConReq to TUCL.
*
*   Ret:   ROK   on success
*           RFAILED on error
*
*   File:  so_tcm.c
*
****************************************************************/
/* so027.201: Changes for SIP TLS support */
#ifdef SO_TLS
#ifdef ANSI
PRIVATE S16 soTptOpenClient
(
SoEntCb        *entCb,     /* Entity Control Block           */
SoSSapCb       *ssapCb,    /* Associated SSAP Cb             */
SoTptServerCb  *serverCb,  /* Transport Server Control Block */
CmTptAddr      *destAddr,  /* Peer Transport Address         */
U8             transport,  /* Transport is TCP or UDP        */
SoTptClientCb  **clientCb  /* Client Control Block (returned)*/
)
#else
PRIVATE S16 soTptOpenClient (entCb, serverCb, destAddr, 
                             transport, clientCb)
SoEntCb       *entCb;     /* Entity Control Block           */
SoSSapCb      *ssapCb;    /* Associated SSAP Cb             */
SoTptServerCb *serverCb;  /* Transport Server Control Block */
CmTptAddr     *destAddr;  /* Peer Transport Address         */
U8            transport;  /* Transport is TCP or UDP        */
SoTptClientCb **clientCb; /* Client Control Block (returned)*/
#endif
#else
#ifdef ANSI
PRIVATE S16 soTptOpenClient
(
SoEntCb        *entCb,     /* Entity Control Block           */
SoTptServerCb  *serverCb,  /* Transport Server Control Block */
CmTptAddr      *destAddr,  /* Peer Transport Address         */
U8             transport,  /* Transport is TCP or UDP        */
SoTptClientCb  **clientCb  /* Client Control Block (returned)*/
)
#else
PRIVATE S16 soTptOpenClient (entCb, serverCb, destAddr, 
                             transport, clientCb)
SoEntCb       *entCb;     /* Entity Control Block           */
SoTptServerCb *serverCb;  /* Transport Server Control Block */
CmTptAddr     *destAddr;  /* Peer Transport Address         */
U8            transport;  /* Transport is TCP or UDP        */
SoTptClientCb **clientCb; /* Client Control Block (returned)*/
#endif
#endif /* SO_TLS */
{
   S16            ret;
   SoTSapCb       *tsapCb;
   SoTptClientCb  *lclClientCb;
   CmTptParam     tPar;
   /* so027.201: Changes for SIP TLS support */
#ifdef SO_TLS
   U16            i;
#endif /* SO_TLS */


   TRC2 (soTptOpenClient)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (entCb && serverCb && destAddr && clientCb))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO201, (ErrVal) 0, "soTptOpenClient: "
                "Invalid parameter");
     RETVALUE (SOT_ERR_UNKNOWN);
   }
#endif

  (*clientCb) = NULLP;

#ifdef SO_USE_UDP_SRVR 
  /*
   * If Connected UDP is not required, then there is no need to ope-
   * n client connection. In such case, server connection will be u-
   * sed sent messages.
   */
   if (SO_TCM_UDP_TRANSPORT (transport))
      RETVALUE (ROK);
#endif

  /*-------------- Verify tsap is bound and enabled --------------*/
   tsapCb = serverCb->tsapCb;

   if (tsapCb->state != LSO_TSAP_BNDENA)
       RETVALUE (SOT_ERR_UNKNOWN);

  /*
   * Step 1: If there is any client connection  already in existance
   *   towards the given destination, reuse that  client connection.
   */
   SO_TCM_ZERO_BASED_ADDR (destAddr);

   /* so027.201, so038.201: For TLS transport, select transport    *
    *    server that has same TLS context identifier as the SAP    *
    *    in which call is initiated.                               */
#ifdef SO_TLS
   if (ssapCb && SO_TCM_TLS_TRANSPORT (transport))
   {
      i=0;

      while (cmHashListFind (&tsapCb->tptAddrHlCp,
                             (U8*) destAddr,
                             sizeof(CmTptAddr),
                             i++, (PTR *)clientCb) == ROK)
      {
         if ((*clientCb)->serverCb->tPar.u.tlsParam.ctxId ==
              ssapCb->cfg.tlsCtxId)
         {
           /* so034.201 : if the clientCb is found, return */
           if ((*clientCb)->state != SO_TPTCLIENT_DIS)
           {
               SODBGP_SO (SO_DBGMASK_TCM, (soCb.init.prntBuf,
                          "soTptOpenClient: Re-Using Client Connection "
                          "suConnId (%d), Protocol(%d)\n",
                          (*clientCb)->suConnId,
                          (*clientCb)->serverCb->tptProt));

               RETVALUE (ROK);
           }
         }
      }
   }
   else
#endif
   {
       ret = cmHashListFind (&tsapCb->tptAddrHlCp,
                             (U8 *) destAddr,
                             sizeof (CmTptAddr),
                             0,
                             (PTR *)clientCb);
       if ((ret == ROK) && ((*clientCb)->state != SO_TPTCLIENT_DIS))
       {
          SODBGP_SO (SO_DBGMASK_TCM, (soCb.init.prntBuf,
                     "soTptOpenClient: Re-Using Client Connection "
                     "suConnId (%d), Protocol(%d)\n",
                     (*clientCb)->suConnId,
                     (*clientCb)->serverCb->tptProt));

          RETVALUE (ROK);
       }
   }

  /*--------- Step 2: Finally, open the client connection. -------*/

   /*------- Allocate client control block (CCB) ---------*/
   ret = soTptAllocClientCb (tsapCb, NULLP, destAddr, &lclClientCb);
   if (ret != ROK)
     RETVALUE (SOT_ERR_UNKNOWN);

   /*-- Insert CCB into tsap's suConnId based hash list --*/
   ret = cmHashListInsert (&tsapCb->suConnIdHlCp,
                           (PTR ) lclClientCb, 
                           (U8 *) &lclClientCb->suConnId,
                           sizeof (ConnId));
   if (ret != ROK)
   {
      SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
         "soTptOpenClient: cmHashListInsert soConnId failed\n"));

      SOFREE (lclClientCb, sizeof (SoTptClientCb));
      RETVALUE (SOT_ERR_UNKNOWN);
   }

   /*-- Insert CCB in tsap's remote addr based hash list -*/
   ret = cmHashListInsert (&tsapCb->tptAddrHlCp,
                           (PTR ) lclClientCb,
                           (U8 *)&lclClientCb->remoteAddr,
                           sizeof (CmTptAddr));
   if (ret != ROK)
   {
      SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
         "soTptOpenClient: cmHashListInsert tptAddr failed\n"));

      cmHashListDelete (&tsapCb->suConnIdHlCp, (PTR)lclClientCb);
      SOFREE (lclClientCb, sizeof (SoTptClientCb));

      RETVALUE (SOT_ERR_UNKNOWN);
   }

   /*-------------- Initialize CCB elements --------------*/
   lclClientCb->tsapCb      = tsapCb;
   lclClientCb->serverCb    = serverCb;
   lclClientCb->state       = LSO_CLIENT_WAIT_ENA;
   lclClientCb->retryCount  = 0;

   /*----- Start Client connection timer. It is used -----*/
   /*----- to limit client connection retry attempts -----*/

   lclClientCb->tmrNode.soCbPtr    = (PTR)lclClientCb;
   ret = soSchedTmr ((Ptr) lclClientCb,
                     SO_TMR_TCM_CONNECTION,
                     TMR_START,
                     SO_TMRVAL_CONNECT);

   if (ret != ROK)
   {
      SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
         "soTptOpenClient: can't start timer\n"));

      cmHashListDelete (&tsapCb->suConnIdHlCp, (PTR)lclClientCb);
      cmHashListDelete (&tsapCb->tptAddrHlCp,  (PTR)lclClientCb);
      SOFREE (lclClientCb, sizeof (SoTptClientCb));

      RETVALUE (SOT_ERR_UNKNOWN);
   }
 
   /*--- Set source port to 0 for outgoing  connection ---*/
    lclClientCb->localAddr.u.ipv4TptAddr.port = 0;

   /*------- Finally update return value and send --------*/
   /*--------- connection open request to TUCL -----------*/
   (*clientCb) = lclClientCb;

   cmMemcpy((U8 *)&tPar, 
            (CONSTANT U8 *)&tsapCb->reCfg.tPar, sizeof(CmTptParam));

   SODBGP_SO (SO_DBGMASK_TCM, (soCb.init.prntBuf,
              "soTptOpenClient: Opening New Client Connection "
              "suConnId (%d), Protocol(%d)\n",
              lclClientCb->suConnId,
              serverCb->tptProt));

#ifdef SO_TLS
   /*--- For TLS connection, build Session Id and send ---*/
   /* so027.201: Changes for SIP TLS support */
   if (serverCb->tptProt == LSO_TPTPROT_TLS_TCP)
   {
      (Void)cmMemset ((U8 *)&tPar, 0, sizeof (CmTptParam));
      cmMemcpy((U8 *)&tPar, 
            (CONSTANT U8 *)&serverCb->tPar, sizeof(CmTptParam));
   }

#endif
   /* so027.201: Changes for SIP TLS support */
   /* so041.201: Added UDP prior check condition & moved SoLiHitConReq outside 
    *  SO_TLS flag 
    */
   SoLiHitConReq (&tsapCb->liPst,
           tsapCb->cfg.spId,
           lclClientCb->suConnId,
           destAddr,
           &lclClientCb->localAddr,
           &tPar,
           (U8)(serverCb->tptProt == LSO_TPTPROT_UDP ? HI_SRVC_UDP : 
                serverCb->tptProt == LSO_TPTPROT_UDP_PRIOR ? HI_SRVC_UDP_PRIOR : 
               serverCb->tptProt == LSO_TPTPROT_TLS_TCP ?  HI_SRVC_TLS 
               : HI_SRVC_TCP));
   RETVALUE (ROK);

} /* end of soTptOpenClient */




/*******************************************************************
*
*       Fun:   soTptDelAllClientContext
*
*       Notes: This function is called when client connection is be-
*              ing removed. It deletes context of all the users usi-
*              ng client connection and also informs those users.
*              informUser indicates whether transaction or dialog l-
*              ayer should be informed about the connection going d-
*              own.
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptDelAllClientContext
(
SoTptClientCb *clientCb,  /* Client connection being closed     */
Bool          informUser /* Inform users of this connection!    */
)
#else
PRIVATE S16 soTptDelAllClientContext (clientCb, informUser)
SoTptClientCb *clientCb;  /* Client connection being closed     */
Bool          informUser;/* Inform users of this connection!    */
#endif
{
   CmLListCp    *lCp;  
   SoTcmConn    *tcmConn;
   CmLList      *lstEnt;

   TRC2 (soTptDelAllClientContext);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (!clientCb)
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO202, (ErrVal) 0, "soTptDelAllClient"
                  "Context: Invalid parameter");
      RETVALUE (RFAILED);
    }
#endif
   /*
    * Client connection is being closed. So inform  all users that are
    * currently using client connection. Users (transaction or dialog)
    * will decide how to handle connection failure. Generally, connec-
    * tion failure ONLY during initial stages should be considered fa-
    * ilure.   
    */
   lCp     = &clientCb->tcmConnLst;
   tcmConn = (SoTcmConn *) CM_LLIST_FIRST_NODE (lCp, lstEnt); 

   /*-- For each user using this client connection --*/
   for (; tcmConn ;)
   {
      /*-- Remove user from client connection list --*/
      cmLListDelFrm (lCp, &tcmConn->clientCbEnt);
      tcmConn->clientCb = NULLP;

#ifdef SO_UA
      /* Inform user about client connection failure */
      if (informUser)
      {
        if (tcmConn->tcmConnType == SO_TRANS)
        {
           /*-- User is transacion layer --*/
           (Void) soTxnClientConnFailure (tcmConn->residePtr);
        }
        /* 
         * If User is dialog layer,do nothing as dialog
         * layer does't maintain client context.
         */
      }
#endif

      tcmConn = (SoTcmConn *) CM_LLIST_FIRST_NODE (lCp, lstEnt);
   }

   RETVALUE(ROK);

} /* end of soTptDelAllClientContext */


/*-- so021.201: Function made PUBLIC to be used by other modules --*/
/*******************************************************************
*
*       Fun:   soTptDelAllServerContext
*
*       Notes: This function is called when server connection is be-
*              ing removed. It deletes context of all the users usi-
*              ng server connection and also informs those users.
*
*       Ret:   ROK on success.
*              RFAILED on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC Void soTptDelAllServerContext
(
SoTptServerCb *serverCb, /* Server connection being closed     */
Bool          informUser /* Inform users of this connection!   */
)
#else
PUBLIC Void soTptDelAllServerContext (serverCb, informUser)
SoTptServerCb *serverCb; /* Server connection being closed     */
Bool          informUser;/* Inform users of this connection!   */
#endif
{
   CmLListCp    *lCp;
   SoTcmConn    *tcmConn;
   CmLList      *lstEnt;

   TRC2(soTptDelAllServerContext);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (serverCb))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO203, (ErrVal) 0, "soTptDelAllServerContext:"
                " Invalid parameter");
     RETVOID; 
   }
#endif

   /*
    * server connection is being closed. So inform  all users that are
    * currently using server connection.
    * NOTE: A server  closing  indicates that all current transactions 
    *       that  have indiated  this server connection in VIA header,
    *       must be deleted.  Response for those transactions will not
    *       be received until this server is opened again.
    *       Also note that this affects only transaction layer and not
    *       core/dialog layer. 
    */
   lCp     = &serverCb->tcmConnLst;
   tcmConn = (SoTcmConn *) CM_LLIST_FIRST_NODE (lCp, lstEnt); 

   /*-- For each user using this client connection --*/
   for (; tcmConn ;)
   {
      /*-- Remove user from client connection list --*/
      cmLListDelFrm (lCp, &tcmConn->serverCbEnt);
      tcmConn->serverCb = NULLP;
#ifdef SO_UA
      /* Inform user about client connection failure */
      if (tcmConn->tcmConnType == SO_TRANS)
      {
         /*-- User is transacion layer --*/
         (Void) soTxnServerConnFailure (tcmConn->residePtr);
      }
#endif
      tcmConn = (SoTcmConn *) CM_LLIST_FIRST_NODE (lCp, lstEnt);
   }

   RETVOID; 

} /* end of soTptDelAllServerContext */



/*******************************************************************
*
*       Fun:   soTptSendMsg 
*
*       Desc:  This function is sed to send a SIP Message.
*
*       Ret:   ROK   on success
*              RFAILED on error
*
*       Notes:
*              
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef SO_CALEA
#ifdef ANSI
PRIVATE S16 soTptSendMsg
(
SoTptServerCb  *serverCb,   /* Server Connection Control Block (SCB) */
SoTptClientCb  *clientCb,   /* Client Connection Control Block (CCB) */
CmTptAddr      *destAddr,   /* Destination IP-address/port           */
Bool           sigCompReqd, /* Is Signaling Compression Required     */
SoLeaUserCtxt  *leaCtxt,    /* LEA User Context                      */
Buffer         *mBuf        /* Data buffer to be sent                */
)
#else
PRIVATE S16 soTptSendMsg (serverCb, clientCb, destAddr, sigCompReqd,
                          leaCtxt, mBuf)
SoTptServerCb  *serverCb;   /* Server Connection Control Block (SCB) */
SoTptClientCb  *clientCb;   /* Client Connection Control Block (CCB) */
CmTptAddr      *destAddr;   /* Destination IP-address/port           */
Bool           sigCompReqd; /* Is Signaling Compression Required     */
SoLeaUserCtxt  *leaCtxt;    /* LEA User Context                      */
Buffer         *mBuf;       /* Data buffer to be sent                */
#endif
#else
#ifdef ANSI
PRIVATE S16 soTptSendMsg
(
SoTptServerCb  *serverCb,   /* Server Connection Control Block (SCB) */
SoTptClientCb  *clientCb,   /* Client Connection Control Block (CCB) */
CmTptAddr      *destAddr,   /* Destination IP-address/port           */
Bool           sigCompReqd, /* Is Signaling Compression Required     */
Buffer         *mBuf        /* Data buffer to be sent                */
)
#else
PRIVATE S16 soTptSendMsg (serverCb, clientCb, destAddr, sigCompReqd,
                          leaCtxt, mBuf)
SoTptServerCb  *serverCb;   /* Server Connection Control Block (SCB) */
SoTptClientCb  *clientCb;   /* Client Connection Control Block (CCB) */
CmTptAddr      *destAddr;   /* Destination IP-address/port           */
Bool           sigCompReqd; /* Is Signaling Compression Required     */
Buffer         *mBuf;       /* Data buffer to be sent                */
#endif
#endif /* SO_CALEA */
{
   S16           ret;
   Buffer        *sendBuf;

   TRC2 (soTptSendMsg);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (serverCb && destAddr && mBuf))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO204, (ErrVal) 0, "soTptSendMsg: "
                "Invalid parameter");
     RETVALUE (RFAILED);
   }
#endif

   /*------- Make a copy (i.e, add reference) of message buffer ----*/
   ret = SAddMsgRef (mBuf, soCb.init.region, soCb.init.pool, &sendBuf);
   if (ret != ROK)
      RETVALUE (RFAILED);

#ifdef SO_CALEA
   /*------ Send encoded message to application, if applicable -----*/
   if (leaCtxt != NULLP)
   {
      Buffer        *leaBuf;

      ret = SAddMsgRef (mBuf, soCb.init.region, soCb.init.pool, &leaBuf);
      if (ret != ROK)
         RETVALUE (RFAILED);

    /*- Application will use this RAW message for lawful intercept -*/
      (Void)soUiRawMessage (leaCtxt, leaBuf);
   }
#endif

   /* 
    * If the outgoing message needs to be compressed, send the message
    * to compressor module. NOTE that the message will be send to TUCL
    * module on getting response from compressor module (in fn SoLiCm-
    * pCompressCfm)
    */
#ifdef SO_COMPRESS
   if (sigCompReqd)
      ret = soTptSendMsgToCompressor (serverCb, clientCb, destAddr, sendBuf);

   /*- If no compression is required, send  message to TUCL module -*/
   else
#endif
   {
      ret = soTptSendMsgToTUCL (serverCb, clientCb, destAddr, sendBuf);
   }

   RETVALUE (ret);

} /* end of soTptSendMsg */


/*******************************************************************
*
*       Fun:   soTptSendMsgToTUCL 
*
*       Desc:  This function sends SIP message on given  connection.
*
*              For TCP and connected UDP, clientCb  should be valid.
*              In such case,  client connection will be used to send
*              message.
*
*              For simple UDP, there  will  be no client connection.
*              server connection will be used to send message. In s-
*              uch a case, destAddr parameter must be valid.
*
*       Ret:   ROK   on success
*              RFAILED on error
*
*       Notes: For TCP and connected UDP,  if  the  connection is in 
*              "active" state, just forward  the data  packet to the
*              lower interface.  Otherwise,  queues data packet. The
*              queued packets will be sent ones connection is estbl-
*              ished.
*              
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC S16 soTptSendMsgToTUCL
(
SoTptServerCb  *serverCb,   /* Server Connection Control Block (SCB) */
SoTptClientCb  *clientCb,   /* Client Connection Control Block (CCB) */
CmTptAddr      *destAddr,   /* Destination IP-address/port           */
Buffer         *mBuf        /* Data buffer to be sent                */
)
#else
PUBLIC S16 soTptSendMsgToTUCL (serverCb, clientCb, destAddr, mBuf)
SoTptServerCb  *serverCb;   /* Server Connection Control Block (SCB) */
SoTptClientCb  *clientCb;   /* Client Connection Control Block (CCB) */
CmTptAddr      *destAddr;   /* Destination IP-address/port           */
Buffer         *mBuf;       /* Data buffer to be sent                */
#endif
{
   S16           ret;

   TRC2 (soTptSendMsgToTUCL);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (serverCb && destAddr && mBuf))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO205, (ErrVal) 0, "soTptSendMsgToTUCL: "
                "Invalid parameter");
     RETVALUE (RFAILED);
   }
#endif

   /*------- Is it UDP message ? ---------*/
   if (SO_TCM_UDP_TRANSPORT (serverCb->tptProt))
   {
#ifdef SO_USE_UDP_SRVR 
    /*
     * If Connected UDP is not required, then there will be NO  client
     * connection. Use server connection to send messages.Only in this
     * case destAddr parameter is required.
     */
     ret = soTptUdpServerDatReq (serverCb, destAddr, mBuf);
#else
    /*
     * For Connected UDP use the client connection to send the message.
     */
     ret = soTptUdpClientDatReq (clientCb, mBuf);
#endif
   }

   /*------ Is must be TCP message --------*/
   else
     /*---- Use the client connection to send the message. ---*/
     ret = soTptTcpClientDatReq (clientCb, mBuf);

   if (ret != ROK)
     /*--- Delete the message reference ---*/
     SPutMsg (mBuf);

   RETVALUE (ret);

} /* end of soTptSendMsgToTUCL */



#ifdef SO_COMPRESS

/*******************************************************************
*
*       Fun:   soTptSendMsgToCompressor 
*
*       Desc:  This function sends SIP message to compressor module
*              for signaling compression.
*
*       Ret:   ROK   on success
*              RFAILED on error
*
*       Notes:
*              
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptSendMsgToCompressor
(
SoTptServerCb  *serverCb,   /* Server Connection Control Block (SCB) */
SoTptClientCb  *clientCb,   /* Client Connection Control Block (CCB) */
CmTptAddr      *destAddr,   /* Destination IP-address/port           */
Buffer         *mBuf        /* Data buffer to be sent                */
)
#else
PRIVATE S16 soTptSendMsgToCompressor (serverCb, clientCb, destAddr, mBuf)
SoTptServerCb  *serverCb;   /* Server Connection Control Block (SCB) */
SoTptClientCb  *clientCb;   /* Client Connection Control Block (CCB) */
CmTptAddr      *destAddr;   /* Destination IP-address/port           */
Buffer         *mBuf;       /* Data buffer to be sent                */
#endif
{
   SoCompContext compContext;

   TRC2 (soTptSendMsgToCompressor);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (serverCb && destAddr && mBuf))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO206, (ErrVal) 0, "soTptSendMsgTo"
                 "Compressor: Invalid parameter");
     RETVALUE (RFAILED);
   }
#endif

   /*------- Is it UDP message ? ---------*/
   if (SO_TCM_UDP_TRANSPORT (serverCb->tptProt))
   {
#ifdef SO_USE_UDP_SRVR 
    /*---------- Save The Context Of ServerCb and DestAddr ---------*/
     compContext.tSapId          = serverCb->tsapCb->cfg.tSapId;
     compContext.choice          = SO_COMP_CONTEXT_SERVER;
     compContext.t.server.connId = serverCb->suConnId;
     cmMemcpy ((U8 *)&compContext.t.server.peerAddr,
               (U8 *)destAddr,
                sizeof (CmTptAddr));
#else
    /*--------------- Save The Context Of clientCb -----------------*/
     compContext.tSapId          = clientCb->tsapCb->cfg.tSapId;
     compContext.choice          = SO_COMP_CONTEXT_CLIENT;
     compContext.t.client.connId = clientCb->suConnId;
     cmMemcpy ((U8 *)&compContext.t.client.peerAddr, 
               (U8 *)destAddr,
               sizeof (CmTptAddr)); 
#endif
   }

   else
   {
    /*-------- For TCP transport, save context  of clientCb --------*/
     compContext.tSapId          = clientCb->tsapCb->cfg.tSapId;
     compContext.choice          = SO_COMP_CONTEXT_CLIENT;
     compContext.t.server.connId = clientCb->suConnId;
     cmMemcpy ((U8 *)&compContext.t.client.peerAddr,
               (U8 *)destAddr,
               sizeof (CmTptAddr));
   }

   /*------- Finally, send the message to compressor module --------*/

   SoLiCstCompressReq (&soCb.cfg.compPst, /* Cmpressor Module's Id */
                        mBuf,             /* Msg To Be Compressed  */
                        &compContext);    /* Context To Be Returned
                                             By Compressor Module  */
   RETVALUE (ROK);

} /* end of soTptSendMsgToCompressor */

#endif



#ifndef SO_USE_UDP_SRVR 

/*******************************************************************
*
*       Fun:   soTptUdpClientDatReq 
*
*       Desc:  This function  sends data on connectedd UDP client c-
*              onnection to remote element.
*
*       Ret:   ROK   on success
*              RFAILED on error
*
*       Notes: If the connection is in "active" state,  just forward
*              the data packet to the lower interface via HitUDatReq.
*              Otherwise, queue data packet. The queued packets will
*              be sent ones connection is established.
*              
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptUdpClientDatReq
(
SoTptClientCb  *clientCb,   /* Client Connection Control Block (CCB) */
Buffer         *mBuf        /* Data buffer to be sent                */
)
#else
PRIVATE S16 soTptUdpClientDatReq (clientCb, mBuf)
SoTptClientCb  *clientCb;   /* Client Connection Control Block (CCB) */
Buffer         *mBuf;       /* Data buffer to be sent                */
#endif
{
   SuId         tsapId;
   MsgLen       len;
   CmIpHdrParm  ipHdrParm;
#ifdef HI_REL_1_4
   CmTptParam   tPar;
#endif

   TRC2(soTptUdpClientDatReq);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (clientCb && mBuf))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO207, (ErrVal) 0, "soTptUdpClientDatReq: "
                "Invalid parameter");
     RETVALUE (RFAILED);
   }
#endif

   (Void)cmMemset ((U8 *)&ipHdrParm, 0, sizeof (CmIpHdrParm));

   tsapId = clientCb->tsapCb->cfg.tSapId;

  /*------------ Check TSAP State (is should be bound) -----------*/
   if (soCb.soTSapCbLst[tsapId]->state != LSO_TSAP_BNDENA)
         RETVALUE (RFAILED);

  /*------ If Client connection is NOT active, queue message -----*/
   if (clientCb->state != SO_TPTCLIENT_ENA)
   {
      SQueueLast ((Buffer *)mBuf, &clientCb->bufQ);
      RETVALUE (ROK);
   }

  /*------ If Client connection is active, send the message ------*/
   
  /*------ restart the idle timer ------*/
   soTptIdleTmr (clientCb, TMR_RESTART);

  /*------ update TSAP statistics ------*/
   (Void) SFndLenMsg (mBuf, &len);
   soCb.soTSapCbLst[tsapId]->sts.bytesTx += len;

  /*------ generate message trace ------*/
   soGenTrcInd (STTSAP, tsapId, NOTUSED, LSO_TRC_EVENT_TX, mBuf);

  /*- TUCL REL 1.4 transport parameter -*/
#ifdef HI_REL_1_4
   tPar.type = CM_TPTPARAM_NOTPRSNT;
#endif

  /*--- TUCL REL 1.3 header parameter --*/
   ipHdrParm.type = CM_HDRPARM_NOTPRSNT;

  /*-------- Send message to TUCL ------*/
#ifdef HI_REL_1_4
      SoLiHitUDatReq (&clientCb->tSapCb->liPst,
                       clientCb->tSapCb->cfg.spId,
                       clientCb->spConnId,
                      &clientCb->remoteAddr,
                      &clientCb->serverCb->localAddr,
                      &ipHdrParm, 
                      &tPar, 
                      mBuf);
#else
      SoLiHitUDatReq (&clientCb->tsapCb->liPst,
                       clientCb->tsapCb->cfg.spId,
                       clientCb->spConnId,
                      &clientCb->remoteAddr,
                      &clientCb->serverCb->localAddr,
                      &ipHdrParm,
                      mBuf);
#endif

   RETVALUE (ROK);

} /* soTptUdpClientDatReq */

#endif



/*******************************************************************
*
*       Fun:   soTptTcpClientDatReq 
*
*       Desc:  This function  sends data on TCP client connection to
*              remote element.
*
*       Ret:   ROK   on success
*              RFAILED on error
*
*       Notes: If the connection is in "active" state,  just forward
*              the data packet to the lower interface via HitDatReq.
*              Otherwise, queue data packet. The queued packets will
*              be sent ones connection is established.
*              
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptTcpClientDatReq
(
SoTptClientCb  *clientCb,   /* Client Connection Control Block (CCB) */
Buffer         *mBuf        /* Data buffer to be sent                */
)
#else
PRIVATE S16 soTptTcpClientDatReq (clientCb, mBuf)
SoTptClientCb  *clientCb;   /* Client Connection Control Block (CCB) */
Buffer         *mBuf;       /* Data buffer to be sent                */
#endif
{
   SuId     tsapId;
   MsgLen   len;

   TRC2(soTptTcpClientDatReq);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (clientCb && mBuf))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO208, (ErrVal) 0, "soTptTcpClientDatReq: "
                "Invalid parameter");
     RETVALUE (RFAILED);
   }
#endif

   tsapId = clientCb->tsapCb->cfg.tSapId;

  /*------------ Check TSAP State (is should be bound) -----------*/
   if (soCb.soTSapCbLst[tsapId]->state != LSO_TSAP_BNDENA)
         RETVALUE (RFAILED);

  /*------ If Client connection is NOT active, queue message -----*/
   if (clientCb->state != SO_TPTCLIENT_ENA)
         SQueueLast ((Buffer *)mBuf, &clientCb->bufQ);

  /*------ If Client connection is active, send the message ------*/
   else
   {
      /*-- restart the idle timer --*/
      soTptIdleTmr (clientCb, TMR_RESTART);

      /*-- update TSAP statistics --*/
      (Void) SFndLenMsg (mBuf, &len);
      soCb.soTSapCbLst[tsapId]->sts.bytesTx += len;

      /*-- generate message trace --*/
      soGenTrcInd(STTSAP, tsapId, NOTUSED, LSO_TRC_EVENT_TX, mBuf);

      /*-- Finally, sent to TUCL ---*/
      (Void) SoLiHitDatReq (&soCb.soTSapCbLst[tsapId]->liPst,
                            soCb.soTSapCbLst[tsapId]->cfg.spId,
                            clientCb->spConnId,
                            mBuf);
   }

   RETVALUE (ROK);

} /* end of soTptTcpClientDatReq */


#ifdef SO_USE_UDP_SRVR 

/*******************************************************************
*
*       Fun:   soTptUdpServerDatReq 
*
*       Desc:  This function sends data using UDP server  connection
*              to remote element.
*
*       Ret:   ROK   on success
*              RFAILED on error
*
*       Notes: 
*              
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptUdpServerDatReq
(
SoTptServerCb  *serverCb,   /* Server Connection Control Block (SCB) */
CmTptAddr      *destAddr,   /* Destination IP-address/port           */
Buffer         *mBuf        /* Data buffer to be sent                */
)
#else
PRIVATE S16 soTptUdpServerDatReq (serverCb, destAddr, mBuf)
SoTptServerCb  *serverCb;   /* Server Connection Control Block (SCB) */
CmTptAddr      *destAddr;   /* Destination IP-address/port           */
Buffer         *mBuf;       /* Data buffer to be sent                */
#endif
{
   SuId         tsapId;
   MsgLen       len;
   CmIpHdrParm  ipHdrParm;
#ifdef HI_REL_1_4
   CmTptParam   tPar;
#endif

   TRC2(soTptUdpServerDatReq);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (serverCb && destAddr && mBuf))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO209, (ErrVal) 0, "soTptUdpServerDatReq: "
                "Invalid parameter");
     RETVALUE (RFAILED);
   }
#endif

   (Void)cmMemset ((U8 *)&ipHdrParm, 0, sizeof (CmIpHdrParm));

   tsapId = serverCb->tsapCb->cfg.tSapId;

  /*------------ Check TSAP State (is should be bound) -----------*/
   if (soCb.soTSapCbLst[tsapId]->state != LSO_TSAP_BNDENA)
         RETVALUE (RFAILED);

  /*------ If Server connection is NOT active, return failure ----*/
   if (serverCb->state != LSO_TPTSRV_ENA)
         RETVALUE (RFAILED);

  /*------ If Server connection is active, send the message ------*/
   
  /*------ update TSAP statistics ------*/
   (Void) SFndLenMsg (mBuf, &len);
   soCb.soTSapCbLst[tsapId]->sts.bytesTx += len;

  /*------ generate message trace ------*/
   soGenTrcInd (STTSAP, tsapId, NOTUSED, LSO_TRC_EVENT_TX, mBuf);

  /*- TUCL REL 1.4 transport parameter -*/
#ifdef HI_REL_1_4
   tPar.type = CM_TPTPARAM_NOTPRSNT;
#endif

  /*--- TUCL REL 1.3 header parameter --*/
   ipHdrParm.type = CM_HDRPARM_NOTPRSNT;

  /*-------- Send message to TUCL ------*/
#ifdef HI_REL_1_4
      SoLiHitUDatReq (&serverCb->tsapCb->liPst,
                       serverCb->tsapCb->cfg.spId,
                       serverCb->spConnId,
                       destAddr,
                      &serverCb->localAddr,
                      &ipHdrParm, 
                      &tPar, 
                      mBuf);
#else
      SoLiHitUDatReq (&serverCb->tsapCb->liPst,
                       serverCb->tsapCb->cfg.spId,
                       serverCb->spConnId,
                       destAddr,
                      &serverCb->localAddr,
                      &ipHdrParm,
                      mBuf);
#endif

   RETVALUE (ROK);

} /* soTptUdpServerDatReq */

#endif

#ifdef SO_DNS
/*******************************************************************
*
*       Fun:   soTptUdpSendDnsReq 
*
*       Desc:  This function sends data using DNS UDP server
*              to remote element.
*
*       Ret:   ROK   on success
*              RFAILED on error
*
*       Notes: 
*              
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC S16 soTptUdpSendDnsReq
(
SoTptServerCb  *serverCb,   /* Server Connection Control Block (SCB) */
CmTptAddr      *destAddr,   /* Destination IP-address/port           */
Buffer         *mBuf        /* Data buffer to be sent                */
)
#else
PUBLIC S16 soTptUdpSendDnsReq (serverCb, destAddr, mBuf)
SoTptServerCb  *serverCb;   /* Server Connection Control Block (SCB) */
CmTptAddr      *destAddr;   /* Destination IP-address/port           */
Buffer         *mBuf;       /* Data buffer to be sent                */
#endif
{
   SuId         tsapId;
   MsgLen       len;
   CmIpHdrParm  ipHdrParm;
#ifdef HI_REL_1_4
   CmTptParam   tPar;
#endif

   TRC2(soTptUdpSendDnsReq);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (serverCb && destAddr && mBuf))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO210, (ErrVal) 0, "soTptUdpSendDnsReq: "
                "Invalid parameter");
     RETVALUE (RFAILED);
   }
#endif

   (Void)cmMemset ((U8 *)&ipHdrParm, 0, sizeof (CmIpHdrParm));

   tsapId = serverCb->tsapCb->cfg.tSapId;

   if (soCb.soTSapCbLst[tsapId]->state != LSO_TSAP_BNDENA)
         RETVALUE (RFAILED);

   if (serverCb->state != LSO_TPTSRV_ENA)
         RETVALUE (RFAILED);

   
   (Void) SFndLenMsg (mBuf, &len);
   soCb.soTSapCbLst[tsapId]->sts.bytesTx += len;

   soGenTrcInd (STTSAP, tsapId, NOTUSED, LSO_TRC_EVENT_TX, mBuf);

#ifdef HI_REL_1_4
   tPar.type = CM_TPTPARAM_NOTPRSNT;
#endif

   ipHdrParm.type = CM_HDRPARM_NOTPRSNT;

#ifdef HI_REL_1_4
      SoLiHitUDatReq (&serverCb->tsapCb->liPst,
                       serverCb->tsapCb->cfg.spId,
                       serverCb->spConnId,
                       destAddr,
                      &serverCb->localAddr,
                      &ipHdrParm, 
                      &tPar, 
                      mBuf);
#else
      SoLiHitUDatReq (&serverCb->tsapCb->liPst,
                       serverCb->tsapCb->cfg.spId,
                       serverCb->spConnId,
                       destAddr,
                      &serverCb->localAddr,
                      &ipHdrParm,
                      mBuf);
#endif

   RETVALUE (ROK);

} /* soTptUdpSendDnsReq */
#endif /* SO_DNS */


/*********************************************************************
*
*       Fun:  soTptAllocClientConnId
*
*       Desc: Allocate connection identifier for new client connection.
*             This connection id is used to uniquely identify client c-
*             onnection within SIP stack.
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       File:  so_tcm.c
*
*********************************************************************/
#ifdef ANSI
PRIVATE S16 soTptAllocClientConnId
(
SoTSapCb  *tsapCb,      /* Transport SAP to be used                */
UConnId   *clientConnId /* client connection identifier (returned) */
)
#else
PRIVATE S16 soTptAllocClientConnId (tsapCb, clientConnId)
SoTSapCb  *tsapCb;      /* Transport SAP to be used                */
UConnId   *clientConnId;/* client connection identifier (returned) */
#endif
{
   S16          ret;
   UConnId      lclConnId;
   SoTptClientCb *entry;

   TRC2(soTptAllocClientConnId);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (tsapCb && clientConnId))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO211, (ErrVal) 0, "soTptAllocClien"
                 "tConnId: Invalid parameter");
   }
#endif
 
  /*
   * Client  Connection  identifiers   are  allocated   from   range
   * (soCb.maxTptSrv..SO_MAX_HIT_CONND).TSap vairable suConnIdSeqNum
   * is used to store available connection id. New Connection id are
   * allocated by incrementing the value of this  variable. But ones
   * we have reached max value, we  need to search  tsap's hash list
   * suConnIdHlCp (indexed based on client connection id) to find an
   * unused connection identifier.
   */

   if (tsapCb->maxConnIdReached == FALSE)
   {
     /*
      * Wrap around of connection id has NOT occured.Simply allocate
      * by incrementing tsap's suConnIdSeqNum.
      */
      (*clientConnId) = tsapCb->suConnIdSeqNum;

      if (++tsapCb->suConnIdSeqNum >= SO_MAX_HIT_CONNID)
         /*--- MAX Value reached. Wrap Around ---*/
         tsapCb->maxConnIdReached = TRUE;

      RETVALUE (ROK);
   }

  /*
   * Wrap around of connection id has occured. Allocate new connect-
   * ion by serching free entry in tsap's hash list suConnIdHlCp.
   */

   for (lclConnId = soCb.maxTptSrv; lclConnId < SO_MAX_HIT_CONNID; lclConnId++)
   {
       ret = cmHashListFind (&tsapCb->suConnIdHlCp, 
                             (U8 *)&lclConnId,
                             sizeof (UConnId),
                             0, 
                             (PTR *)&entry);
       if (ret != ROK)
       {
           /*-- Free connection id found --*/
           (*clientConnId) = lclConnId;
           RETVALUE (ROK);
       }
   }

   SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
               "soTptAllocClientConnId: out of connection identifiers\n"));

   RETVALUE (RFAILED);

} /* end of soTptAllocClientConnId */




/*
*
*       Fun:   soTptReturnError
*
*       Desc:  This function sends a SIP error message to sender for
*              a mal-formed Message.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_tcm.c
*
*/

#ifdef ANSI
PUBLIC S16 soTptReturnError
(
SoEntCb        *entCb,       /* Entity control block    */
SoTptClientCb  *clientCb,    /* Client connection       */
SoTptServerCb  *serverCb,    /* Server connection       */
SoEvnt         *rxEvnt,      /* Received event          */
U16            statusCode    /* Status code to return   */
)
#else
PUBLIC S16 soTptReturnError (entCb, clientCb, serverCb, rxEvnt, statusCode)
SoEntCb        *entCb;       /* Entity control block    */
SoTptClientCb  *clientCb;    /* Client connection       */
SoTptServerCb  *serverCb;    /* Server connection       */
SoEvnt         *rxEvnt;      /* Received event          */
U16            statusCode;   /* Status code to return   */
#endif
{
  S16        ret;
  SoTcmConn  tcmConn;
  SoEvnt     *errEvnt;
  SoVia      *rxVia;
  SoAddress  *to;
  Buffer     *mBuf;
  TknStrOSXL  *tag;    /* so028.201 tag string */

  TRC2 (soTptReturnError);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (entCb && rxEvnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO212, (ErrVal) 0, "soTptReturnError: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }
#endif
   mBuf = NULLP;

   /* so028.201 */
   SO_GET_VIA_FROM_EVENT    (rxEvnt, rxVia);
   ret = soUtlBuildErrRsp(&errEvnt, rxEvnt, statusCode, SO_EXTRSP_NONE);

   /* so039.201: Added error check condition */
   if (ret != ROK)
   {
      SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
               "\nsoTptReturnError Cannot Build Response Event"));
      RETVALUE(RFAILED);
   }

   SO_GET_TOHDR_FROM_EVENT  (errEvnt, to);
   ret = soCmGetAddrParam((U8 **)&tag, to, SO_ADDRPARAM_TAGPARAM);
   if (ret != ROK)
   {
      /* Generate local tag */
      ret = soCmGenLocalTag(errEvnt, NULLP, to);
      if (ret != ROK)
         RETVALUE(RFAILED);
   }
   /* Tag already present, just continue */

  /*----- STEP 2: Send the error message to origination node -----*/
    soPrcInitTcmConn (&tcmConn, SO_UNKNOWN, NULLP);
    tcmConn.clientCb = clientCb;
    tcmConn.serverCb = serverCb;

    ret = soTptSendRsp (entCb, NULLP, rxVia, errEvnt, &mBuf, &tcmConn);

    if (ret == SO_TPT_MULTI_THREADED_ENC)
        /*
         * Encoding not finished YET. The rest of functionality for
         * this  state  will  be  done  in  the  callback function.
         */
         RETVALUE (ROK);

    if (ret != ROK)
         goto SOTPTRETURN_FAILURE;

    if (mBuf)
      SPutMsg (mBuf);

SOTPTRETURN_FAILURE:

    (Void) soCmFreeEvent (errEvnt);

     RETVALUE (ret);

} /* end of soTptReturnError */


#ifdef SO_COMPRESS

/*
*
*       Fun:   soTptChkNextHopCompSupp
*
*       Desc:  This function checks if the peer node supports signalling
*              compression.
*
*       Ret:   TRUE/FALSE
*
*       Notes: None
*
*       File:  so_tcm.c
*
*/

#ifdef ANSI
PRIVATE S16   soTptChkNextHopCompSupp
(
SoEntCb   *entCb,      /* Entity Control Block           */
SoEvnt    *request     /* SIP Event Structure            */
)
#else
PRIVATE S16   soTptChkNextHopCompSupp (entCb, request)
SoEntCb   *entCb;      /* Entity Control Block           */
SoEvnt    *request;    /* SIP Event Structure            */
#endif
{
  S16             ret;
  U16             hdrIdx;
  U16             i;
  SoRoute         *route;
  SoAddrSpec      *addrSpec;
  SoUrlParameter  *urlParam;
  SoUrlParameters *urlParameters;

   TRC2(soTptChkNextHopCompSupp);

#ifdef SO_UA
   if ((entCb->entityType             == LSO_ENT_NS) ||
       (entCb->s.ua.reCfg.sigCompSupp == FALSE))
     /*----- Our Stack Does Not Support Signaling Compression ----*/
     RETVALUE (FALSE);
#else
     /*----- Our Stack Does Not Support Signaling Compression ----*/
     RETVALUE (FALSE);
#endif

   /*-------- STEP 1: Find Next Hop Node For This Request --------*/
   /*
    * If the request contains "route" header, top "route" header el-
    * ment is our Next hop node. Else, "request-URI" contains our n-
    * ext hop node.
    */
    ret = soCmFindHdrChIndex (request, (U8 **) &route, &hdrIdx,
                              SO_HEADER_REQ_ROUTE);
    if (ret == ROK)
    {
     /*--- TOP Route Header Is Our Next Hop Node ---*/
      addrSpec  = &route->route[0]->nameAddr.addrSpec;
    }
    else
    {
     /*-- Request-URI Indicates Our Next Hop Node --*/
      addrSpec = &request->t.request.requestLine.addrSpec;
    }

    if ((addrSpec->addrSpecType.val != SO_ADDRSPEC_SIPURL ) &&
        (addrSpec->addrSpecType.val != SO_ADDRSPEC_SIPSURL) &&
        (addrSpec->addrSpecType.val != SO_ADDRSPEC_IMURL)) 
       /*---- Not the format to support sigComp ----*/
        RETVALUE (FALSE);

   /* STEP 2:Find If Next Hop Node Supports Signaling Compression */

    urlParameters = &addrSpec->t.sipUrl.urlParameters;

    for (i = 0; i < SO_GET_NUM_COMP (&urlParameters->numComp); i++)
    {
      urlParam = urlParameters->urlParameter[i];

      if (SO_CMP_TKN_LIT (&urlParam->urlParameterType,
                          SO_URLPARAMETER_COMP) == TRUE)
         /*- Next Hop node supports signaling compression -*/
          RETVALUE (TRUE);
    }

   RETVALUE (FALSE);

} /* soTptChkNextHopCompSupp */


/*
*
*       Fun:   soTptChkPrevHopCompSupp
*
*       Desc:  This function checks if the previous hop node supports
*              signalling compression.
*
*       Ret:   TRUE/FALSE
*
*       Notes: None
*
*       File:  so_tcm.c
*
*/

#ifdef ANSI
PRIVATE S16   soTptChkPrevHopCompSupp
(
SoEntCb  *entCb,  /* Entity Control Block  */
SoVia    *via     /* Via Header            */
)
#else
PRIVATE S16   soTptChkPrevHopCompSupp (entCb, via)
SoEntCb  *entCb;  /* Entity Control Block  */
SoVia    *via;    /* Via Header            */
#endif
{
   U16         i;
   SoViaParams *viaParams;
   SoViaParam  *viaParam;

   TRC2(soTptChkPrevHopCompSupp);

#ifdef SO_UA
   if ((entCb->entityType             == LSO_ENT_NS) ||
       (entCb->s.ua.reCfg.sigCompSupp == FALSE))
     /*----- Our Stack Does Not Support Signaling Compression ----*/
     RETVALUE (FALSE);
#else
     /*----- Our Stack Does Not Support Signaling Compression ----*/
     RETVALUE (FALSE);
#endif

   /*-- Find If Previous Hop Node Supports Signaling Compression -*/

    viaParams = &via->viaItem[0]->viaParams;

    for (i = 0; i < SO_GET_NUM_COMP (&viaParams->numComp); i++)
    {
      viaParam = viaParams->viaParam[i];

      if (SO_CMP_TKN_LIT (&viaParam->viaParamType,
                          SO_VIAPARAM_VIACOMP) == TRUE)
         /*--- Prevous Hop node supports signaling compression ---*/
          RETVALUE (TRUE);
    }

   RETVALUE (FALSE);

} /* soTptChkPrevHopCompSupp */


/*******************************************************************
*
*       Fun:   soTptAddCompSupport
*
*       Notes: The  function is used to  add compression support, if
*              configured.
*
*       Ret:   ROK on success.
*              SOT_ERR_UNKNOWN on error.
*
*       File:  so_tcm.c
*
*******************************************************************/

#ifdef ANSI
PRIVATE S16 soTptAddCompSupport
(
SoEntCb       *entCb,    /* Entity Control Block               */
SoViaItem     *viaItem,  /* VIA item pointer                   */
SoEvnt        *request   /* SIP Request message to be sent     */
)
#else
PRIVATE S16 soTptAddCompSupport (entCb, viaItem, request)
SoEntCb       *entCb;    /* Entity Control Block               */
SoViaItem     *viaItem;  /* VIA item pointer                   */
SoEvnt        *request;  /* SIP Request message to be sent     */
#endif
{ 
   S16        ret;
   U16        vpComp;
   U16        i;

   TRC2(soTptAddCompSupport);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (entCb && viaItem && request))
    {
      SOLOGERROR (ERRCLS_DEBUG, ESO213, (ErrVal) 0,  "soTptAddCompSupport: "
                 "Invalid parameter");
      RETVALUE (SOT_ERR_UNKNOWN);
    }
#endif

    /*- Do we need to add support for signaling compression! -*/
#ifdef SO_UA
     if ((entCb->entityType             == LSO_ENT_NS)  ||
         (entCb->s.ua.reCfg.sigCompSupp == FALSE))
        RETVALUE (ROK);
#else
        RETVALUE (ROK);
#endif

    /*--------------- Check if already present  --------------*/

     for (i = 0; i < SO_GET_NUM_COMP (&viaItem->viaParams.numComp); i++)
     {
       if (SO_CMP_TKN_LIT (&viaItem->viaParams.viaParam[i]->viaParamType,
                           SO_VIAPARAM_VIACOMP) == TRUE)
           RETVALUE (ROK);
     }

    /*-------- Add "sigComp" parameter in VIA header ---------*/

      ret = soCmGrowList ((Void ***)&viaItem->viaParams.viaParam,
                          sizeof (SoViaParam),
                          &viaItem->viaParams.numComp,
                          request);
      if (ret != ROK)
        RETVALUE (SOT_ERR_UNKNOWN);

      vpComp = SO_GET_NUM_COMP (&viaItem->viaParams.numComp);

      SO_FILL_TKNU8(
         &viaItem->viaParams.viaParam[vpComp - 1]->viaParamType,
         SO_VIAPARAM_VIACOMP);

      SO_FILL_TKNU8(
         &viaItem->viaParams.viaParam[vpComp - 1]->t.comp.valueType,
         SO_COMP_SIGCOMP);

     RETVALUE (ROK);

} /* soTptAddCompSupport */


#endif  /* SO_COMPRESS */


/********************************************************************30**

         End of file:     so_tcm.c@@/main/4 - Tue Apr 20 12:47:08 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/4      ---      ps   1. Changed copyright header.
/main/4+   so003.201  up   1. Added check to release event for failure.
/main/4+   so007.201  ps   1. Stopping all clientCb timers during 
                              deletion.
/main/4+   so010.201  ab   1. Fix to guard opening of tpt srv with a timer
/main/4+   so017.201  ps   1. Dialog matching procedure modified.
/main/4+   so018.201  ps   1. Modified check for NAT rport, if NAT is not
                              required.
/main/4+    so019.201 ps    1. Added enitityCb parameter in soSipDecodeReq
/main/4+    so021.201 ab   1. Function soTptDelAllServerContext made PUBLIC 
/main/4+    so027.201 ab   1. Changes for SIP TLS support
/main/4+    so028.201 ss   1. Changed to use common function for building
                              error response.
/main/4+    so034.201 ng   1. Changed OpenClient for TLS based on ctxId(ss)
/main/4+    so035.201 ng   1. Changed default port to 5061 in case of TLS.(ab)
                      ng   2. Reset the retry of server connection ones
                              all retry is done.Also localized checking
                              of retry count at one place.(ps)
/main/4+    so036.201 ng   1. Changes for SO_CALEA
/main/4+    so037.201 ng   1. Check for SSAP Validity
/main/4+    so038.201 ng   1. Corrected logic for selecting TLS transport
                              server
/main/4+    so038.201  ng  1. Added error check condition
/main/4+    so039.201  ng  1. Added error check condition in soTptReturnError
/main/4+    so041.201  ng  1. Replaced with macro to check for transport - UDP 
                              and priority UDP
 *********************************************************************91*/
