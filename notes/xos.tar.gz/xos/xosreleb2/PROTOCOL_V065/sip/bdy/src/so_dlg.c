/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SIP Dialog Module File

     Type:    C source file

     Desc:    Code for SIP User Agent

     File:    po_dlg.c

     Sid:      so_dlg.c@@/main/2 - Tue Apr 20 12:46:21 2004

     Prg:     pk

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"         /* environment options          */
#include "envdep.h"         /* environment dependent        */
#include "envind.h"         /* environment independent      */
#include "gen.h"            /* general layer                */
#include "ssi.h"            /* system services              */
#include "cm_llist.h"       /* common library               */
#include "cm_hash.h"        /* common hash list             */
#include "cm_tpt.h"         /* common transport             */
#include "cm_tkns.h"        /* common tokens                */
#include "cm_sdp.h"         /* common SDP                   */
#include "cm_mblk.h"        /* common memory allocation     */
#include "cm_abnf.h"        /* common abnf library          */
#include "cm_dns.h"         /* common DNS                   */
#include "sot.h"            /* SOT interface                */
#include "lso.h"            /* layer management, SIP        */
#include "so.h"             /* SIP layer defines            */
#include "so_trans.h"       /* SIP transaction related structures */
#include "so_err.h"         /* SIP error defines            */
#include "so_cm.h"          /* SIP layer utility functions  */
#include "so_ua.h"          /* interface between UI and UA  */

/* header/extern include files (.x) */
#include "gen.x"            /* general layer                */
#include "ssi.x"            /* system services              */
#include "cm5.x"            /* common timer module          */
#include "cm_lib.x"         /* common library               */
#include "cm_llist.x"       /* common link list             */
#include "cm_hash.x"        /* common hash list             */
#include "cm_tkns.x"        /* common tokens                */
#include "cm_tpt.x"         /* common transport             */
#include "cm_xtree.x"       /* common radix tree            */
#include "cm_mblk.x"        /* common memory allocation     */
#include "cm_sdp.x"         /* common SDP                   */
#include "cm_abnf.x"        /* common abnf library          */
#include "cm_dns.x"         /* common DNS                   */
#include "sot.x"            /* SOT interface                */
#include "lso.x"            /* layer management SIP         */
#include "so_tcm.x"         /* TCM defines                  */
#include "so.x"             /* SIP layer structures         */
#include "so_trans.x"       /* SIP transaction related structures */
#include "so_cm.x"          /* SIP layer utility functions  */
#include "so_dns.x"         /* SIP DNS functions            */
#include "so_utl.x"         /* SIP utility functions        */
#include "so_cl.x"          /* SIP cache functions          */
#include "so_lcs.x"         /* SIP Location Services        */
#ifdef SO_UA
#include "so_ua.x"          /* SIP UA functions             */
#endif



#ifdef SO_UA
/************************************************************
            Dialog State Machine
************************************************************/

PRIVATE SoCLegCb *soDlgInitCLeg  ARGS ((
                         SoCallCb   *callCb,
                         SoEvnt     *evnt,
                         U8         direction));


PRIVATE Void soDlgDelStoredHdrs ARGS((SoCLegCb   *cLeg));



PRIVATE Void soDlgDelRspInfo ARGS((Ptr       usrPtr,
                                   Bool      provRsp,
                                   SoRspCb   *rspCb));
PRIVATE Void soDlgDelAckCb ARGS((SoCLegCb   *cLeg));


#ifdef SO_SESSTIMER
PRIVATE Void soDlgDelSessTmrCb  ARGS((SoCLegCb   *cLeg));
#endif

#ifdef SO_RFC_3262
PRIVATE Void soDlgDelRelProvRspCb ARGS((SoProvRspCb   *provRspCb));
#endif

#ifdef SO_UA
PRIVATE Void soDlgDelRegInfo  ARGS((SoCLegCb   *cLeg));
#endif

PRIVATE S16 soDlgUpdOutClegInfo  ARGS ((
                         SoCLegCb   *cLeg,
                         SoEvnt     *evnt,
                         SoAddress  *to,
                         SoAddress  *from,
                         U32        cSeqVal,
                         U8         direction));

PRIVATE S16 soDlgUpdIncClegInfo  ARGS ((
                         SoCLegCb   *cLeg,
                         SoEvnt     *evnt,
                         SoAddress   *to,
                         SoAddress   *from,
                         U32         cSeqVal)); 


PRIVATE S16 soDlgChkMandUaOutReqHdr  ARGS ((
                         SoCLegCb   *cLeg,
                         SoEvnt     *evnt));

PRIVATE S16 soDlgFindNextHopAddr  ARGS ((
                         SoCLegCb   *cLeg,
                         SoAddrSpec **reqAddr));

PRIVATE S16 soDlgFindCancelNextHopAddr  ARGS ((
                         SoTransCb  *transCb,
                         SoAddrSpec *reqAddr));

PRIVATE S16 soDlgChkMandUaOutRspHdr  ARGS ((SoCLegCb   *cLeg,
                                            SoEvnt     *evnt,
                                            SoTransCb  *transCb
                                            ));

PRIVATE S16 soDlgUpdState  ARGS ((
                         SoCLegCb     *cLeg,
                         SoEvnt       *evnt,
                         U8           direction));

PRIVATE S16 soDlgUpdReqState ARGS ((
                       SoCLegCb     *cLeg,
                       SoEvnt       *evnt,
                       U8           direction));

PRIVATE S16 soDlgUpdRspState ARGS ((
                       SoCLegCb     *cLeg,
                       SoEvnt       *evnt,
                       U8           direction)); 

#ifdef SO_COMPRESS
PRIVATE S16 soDlgRetryTrans ARGS ((
                       SoCLegCb     *cLeg,
                       SoEvnt       *evnt,
                       CmTptAddr    *destAddr,
                       U8           transport,
                       SoUserCtxt   *userCtxt));
#endif /* SO_COMPRESS */
                  
PRIVATE S16 soDlgChkMandUaIncHdr ARGS ((SoEntCb    *ent,
                                        SoCLegCb  *cLeg,
                                        SoEvnt     *evnt
                                      ));

PRIVATE S16 soDlgChkDfltInPrx ARGS ((
                         SoEntCb     *ent,
                         SoTransCb   *transCb,
                         SoEvnt      *evnt));

PRIVATE S16 soDlgStoreIncRoute ARGS ((
                         SoCLegCb   *cLeg,
                         SoEvnt     *evnt));

/* so012.201: Store outgoing route information */
PRIVATE S16 soDlgStoreOutRoute ARGS ((
                         SoCLegCb   *cLeg,
                         SoEvnt     *evnt));


PRIVATE S16 soDlgUpdReqURI ARGS ((SoCLegCb   *cLeg,
                                  SoEvnt     *evnt,
                                  U8         direction));


PRIVATE S16 soDlgPrcUaOutReq ARGS((SoUserCtxt *userCtxt,
                                   CmTptAddr  *tptAddr,
                                   U8         tptProt
                                   ));

PRIVATE Void soDlgDnsRspCallBack ARGS ((
                          PTR          userCtxt,
                          U8           queryType,
                          CmTptAddr    *tptAddr, 
                          U8           tptProt,  
                          SoAddress    *addr));  


#ifdef SO_TLS
/* so035.201: Puting TLS related function definition in one place */
PRIVATE S16 soDlgSetTlsInfo               ARGS((SoCLegCb     *cLeg,
                                                SoEvnt       *evnt));

PRIVATE S16 soDlgChkIncReqTlsInfo         ARGS((SoCLegCb     *cLeg,  
                                                SoEvnt       *evnt));

PRIVATE S16 soDlgChkIncRspTlsInfo         ARGS((SoCLegCb     *cLeg,  
                                                SoEvnt       *evnt));

PRIVATE S16 soDlgChkOutTlsInfo            ARGS((SoCLegCb     *cLeg,  
                                                SoEvnt       *evnt));

PRIVATE S16 soDlgChkUpdTlsInfo            ARGS((SoCLegCb     *cLeg,  
                                                SoEvnt       *evnt,  
                                                U8           secure));

/* so027.201: Changes for SIP TLS support */
PRIVATE S16 soDlgFindTlsCancelNextHopAddr ARGS((SoTransCb  *transCb,
                                                SoAddrSpec *reqAddr));

/* so035.201: soDlgResetTlsInfo not required, removed from code */
#else
/* so027.201: Changes for SIP TLS support */
PRIVATE S16 soDlgChkOutReqHdr             ARGS ((SoEvnt *evnt));
#endif /* SO_TLS */

/* so012.201: New Function To Find Error Code To Be Send In State Check
              Failure Cases. */
PRIVATE S16 soDlgFindStatusCode ARGS((U8         eventType,
                                      U8         clegState));

/*--- so014.201: Functions to add "UserAgent"/"Server" header ---*/
/*----- so015.201: Functions to add "UserAgent" made Public -----*/
PRIVATE S16 soDlgPrcServer    ARGS ((SoCLegCb   *cLeg,
                                     SoEvnt     *evnt));


/* Request State Machine */

/* Array fields - [MSG_TYPE][DIALOG_STATE] */
PRIVATE U8 soDlgUaReqFsm[][SO_MAX_DLG_STATES] =
{
  /* INVITE */
  {
      SO_CLEG_STATE_INITIAL, /* SO_CLEG_STATE_NONE       */
      /* so027.201: Transition from initial to initial should
                    be allowed to handle DNS cases */
      SO_CLEG_STATE_INITIAL, /* SO_CLEG_STATE_INITIAL    */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_PROCEEDING */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_EARLY      */
      SO_CLEG_STATE_ERROR ,  /* SO_CLEG_STATE_ACK_PEND   */
      SO_CLEG_STATE_MODIFY , /* SO_CLEG_STATE_ACTIVE     */ 
      SO_CLEG_STATE_ERROR ,  /* SO_CLEG_STATE_MODIFY     */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_MODIFY_ACK */
      SO_CLEG_STATE_ERROR    /* SO_CLEG_STATE_TERMINATED */
  },

  /* Recursion INVITE */
  {
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_NONE       */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_INITIAL    */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_PROCEEDING */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_EARLY      */
      SO_CLEG_STATE_ERROR ,  /* SO_CLEG_STATE_ACK_PEND   */
      SO_CLEG_STATE_ERROR ,  /* SO_CLEG_STATE_ACTIVE     */ 
      SO_CLEG_STATE_ERROR ,  /* SO_CLEG_STATE_MODIFY     */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_MODIFY_ACK */
      SO_CLEG_STATE_INITIAL    /* SO_CLEG_STATE_TERMINATED */
  },

  /* Cancel*/
  {
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_NONE       */
      SO_CLEG_STATE_INITIAL,    /* SO_CLEG_STATE_INITIAL    */
      SO_CLEG_STATE_PROCEEDING, /* SO_CLEG_STATE_PROCEEDING */
      SO_CLEG_STATE_EARLY,      /* SO_CLEG_STATE_EARLY      */
      SO_CLEG_STATE_ERROR ,     /* SO_CLEG_STATE_ACK_PEND   */
      SO_CLEG_STATE_ERROR ,     /* SO_CLEG_STATE_ACTIVE     */ 
     /*-- so014.201: Allow CANCEL For RE-INVITE Request --*/
      SO_CLEG_STATE_MODIFY,     /* SO_CLEG_STATE_MODIFY     */
      SO_CLEG_STATE_ERROR,      /* SO_CLEG_STATE_MODIFY_ACK */
      SO_CLEG_STATE_ERROR       /* SO_CLEG_STATE_TERMINATED */
  },

  /* PRACK */
  {
      SO_CLEG_STATE_ERROR,      /* SO_CLEG_STATE_NONE       */
      SO_CLEG_STATE_INITIAL,    /* SO_CLEG_STATE_INITIAL    */
      SO_CLEG_STATE_PROCEEDING, /* SO_CLEG_STATE_PROCEEDING */
      SO_CLEG_STATE_EARLY,      /* SO_CLEG_STATE_EARLY      */
      SO_CLEG_STATE_ERROR,      /* SO_CLEG_STATE_ACK_PEND   */
      SO_CLEG_STATE_ERROR,      /* SO_CLEG_STATE_ACTIVE     */ 
      SO_CLEG_STATE_MODIFY,     /* SO_CLEG_STATE_MODIFY     */
      SO_CLEG_STATE_ERROR,      /* SO_CLEG_STATE_MODIFY_ACK */
      SO_CLEG_STATE_ERROR       /* SO_CLEG_STATE_TERMINATED */
  },

  /* INFO*/
  {
     /* so009.201 : To support INFO outside a call */
      SO_CLEG_STATE_INITIAL,    /* SO_CLEG_STATE_NONE       */
      SO_CLEG_STATE_INITIAL,    /* SO_CLEG_STATE_INITIAL    */
      SO_CLEG_STATE_PROCEEDING, /* SO_CLEG_STATE_PROCEEDING */
      SO_CLEG_STATE_EARLY,      /* SO_CLEG_STATE_EARLY      */
      SO_CLEG_STATE_ACK_PEND ,  /* SO_CLEG_STATE_ACK_PEND   */
      SO_CLEG_STATE_ACTIVE,     /* SO_CLEG_STATE_ACTIVE     */ 
      SO_CLEG_STATE_MODIFY,     /* SO_CLEG_STATE_MODIFY     */
      SO_CLEG_STATE_MODIFY_ACK, /* SO_CLEG_STATE_MODIFY_ACK */
      SO_CLEG_STATE_ERROR       /* SO_CLEG_STATE_TERMINATED */
  },

  /* ACK*/
  {
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_NONE       */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_INITIAL    */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_PROCEEDING */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_EARLY      */
      SO_CLEG_STATE_ACTIVE , /* SO_CLEG_STATE_ACK_PEND   */
      SO_CLEG_STATE_IGNORE,  /* so029.201 : SO_CLEG_STATE_ACTIVE     */
      SO_CLEG_STATE_ERROR ,  /* SO_CLEG_STATE_MODIFY     */
      SO_CLEG_STATE_ACTIVE,  /* SO_CLEG_STATE_MODIFY_ACK */
      SO_CLEG_STATE_TERMINATED  /* SO_CLEG_STATE_TERMINATED */
  },

  /* BYE (Outgoing on the UAC side/ Incoming on the uAS side)*/
  {
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_NONE       */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_INITIAL    */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_PROCEEDING */
      SO_CLEG_STATE_TERMINATED, /* SO_CLEG_STATE_EARLY      */
      SO_CLEG_STATE_TERMINATED, /* SO_CLEG_STATE_ACK_PEND   */
      SO_CLEG_STATE_TERMINATED, /* SO_CLEG_STATE_ACTIVE     */ 
      SO_CLEG_STATE_TERMINATED, /* SO_CLEG_STATE_MODIFY     */
      SO_CLEG_STATE_TERMINATED, /* SO_CLEG_STATE_MODIFY_ACK */
      SO_CLEG_STATE_TERMINATED  /* SO_CLEG_STATE_TERMINATED */
  },

  /* BYE (Incoming on the UAC side/ Outgoing on the uAS side)*/
  {
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_NONE       */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_INITIAL    */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_PROCEEDING */
      SO_CLEG_STATE_ERROR,   /* SO_CLEG_STATE_EARLY      */
      SO_CLEG_STATE_TERMINATED, /* SO_CLEG_STATE_ACK_PEND   */
      SO_CLEG_STATE_TERMINATED, /* SO_CLEG_STATE_ACTIVE     */ 
      SO_CLEG_STATE_TERMINATED, /* SO_CLEG_STATE_MODIFY     */
      SO_CLEG_STATE_TERMINATED, /* SO_CLEG_STATE_MODIFY_ACK */
      SO_CLEG_STATE_TERMINATED  /* SO_CLEG_STATE_TERMINATED */
  },

  /* UPDATE messages */
  {
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_NONE       */
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_INITIAL    */
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_PROCEEDING */
      SO_CLEG_STATE_EARLY,     /* SO_CLEG_STATE_EARLY      */
      SO_CLEG_STATE_ACK_PEND,  /* SO_CLEG_STATE_ACK_PEND   */
      SO_CLEG_STATE_ACTIVE,    /* SO_CLEG_STATE_ACTIVE     */ 
      SO_CLEG_STATE_MODIFY,    /* SO_CLEG_STATE_MODIFY     */
      SO_CLEG_STATE_MODIFY_ACK,/* SO_CLEG_STATE_MODIFY_ACK */
      SO_CLEG_STATE_TERMINATED /* SO_CLEG_STATE_TERMINATED */
   },

   /* CIM messages */
   {
      SO_CLEG_STATE_INITIAL,   /* SO_CLEG_STATE_NONE       */
      SO_CLEG_STATE_INITIAL,   /* SO_CLEG_STATE_INITIAL    */
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_PROCEEDING */
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_EARLY      */
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_ACK_PEND   */
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_ACTIVE     */ 
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_MODIFY     */
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_MODIFY_ACK */
      SO_CLEG_STATE_ERROR      /* SO_CLEG_STATE_TERMINATED */
   },

   /* OTHER*/
   {
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_NONE       */
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_INITIAL    */
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_PROCEEDING */
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_EARLY      */
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_ACK_PEND   */
      SO_CLEG_STATE_ACTIVE,    /* SO_CLEG_STATE_ACTIVE     */ 
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_MODIFY     */
      SO_CLEG_STATE_ERROR,     /* SO_CLEG_STATE_MODIFY_ACK */
      SO_CLEG_STATE_ERROR      /* SO_CLEG_STATE_TERMINATED */
   }
};


/* Array Fields - [MSG_TYPE][DIALOG_STATE] */
PRIVATE U8  soDlgUaRspFsm[][SO_MAX_DLG_STATES] =
{
   /* 1xx - No Tag */
   {
       SO_CLEG_STATE_ERROR,        /* SO_CLEG_STATE_NONE       */
       SO_CLEG_STATE_PROCEEDING,   /* SO_CLEG_STATE_INITIAL    */
       SO_CLEG_STATE_PROCEEDING,   /* SO_CLEG_STATE_PROCEEDING */
       SO_CLEG_STATE_ERROR,        /* SO_CLEG_STATE_EARLY      */
       SO_CLEG_STATE_ERROR,        /* SO_CLEG_STATE_ACK_PEND   */
       SO_CLEG_STATE_ERROR ,       /* SO_CLEG_STATE_ACTIVE     */ 
       SO_CLEG_STATE_MODIFY,       /* SO_CLEG_STATE_MODIFY     */
       SO_CLEG_STATE_ERROR,        /* SO_CLEG_STATE_MODIFY_ACK */
       SO_CLEG_STATE_ERROR         /* SO_CLEG_STATE_TERMINATED */
   },

   /* 1xx - With Tag */
   {
       SO_CLEG_STATE_ERROR,        /* SO_CLEG_STATE_NONE       */
       SO_CLEG_STATE_EARLY,        /* SO_CLEG_STATE_INITIAL    */
       SO_CLEG_STATE_EARLY,        /* SO_CLEG_STATE_PROCEEDING */
       SO_CLEG_STATE_EARLY,        /* SO_CLEG_STATE_EARLY      */
       SO_CLEG_STATE_ERROR,        /* SO_CLEG_STATE_ACK_PEND   */
       SO_CLEG_STATE_ERROR,        /* SO_CLEG_STATE_ACTIVE     */ 
       SO_CLEG_STATE_MODIFY,       /* SO_CLEG_STATE_MODIFY     */
       SO_CLEG_STATE_ERROR,        /* SO_CLEG_STATE_MODIFY_ACK */
       SO_CLEG_STATE_ERROR         /* SO_CLEG_STATE_TERMINATED */
   },

   /* 2xx */
   {
      SO_CLEG_STATE_ERROR,      /* SO_CLEG_STATE_NONE       */
      SO_CLEG_STATE_ACK_PEND,   /* SO_CLEG_STATE_INITIAL    */
      SO_CLEG_STATE_ACK_PEND,   /* SO_CLEG_STATE_PROCEEDING */
      SO_CLEG_STATE_ACK_PEND,   /* SO_CLEG_STATE_EARLY      */
      SO_CLEG_STATE_ACK_PEND,   /* SO_CLEG_STATE_ACK_PEND   */
      SO_CLEG_STATE_ERROR,      /* SO_CLEG_STATE_ACTIVE     */ 
      SO_CLEG_STATE_MODIFY_ACK, /* SO_CLEG_STATE_MODIFY     */
      SO_CLEG_STATE_MODIFY_ACK, /* SO_CLEG_STATE_MODIFY_ACK */
      SO_CLEG_STATE_ERROR       /* SO_CLEG_STATE_TERMINATED */
   },     
   /* 3xx-6xx*/
   {
      SO_CLEG_STATE_ERROR,      /* SO_CLEG_STATE_NONE       */
      SO_CLEG_STATE_TERMINATED, /* SO_CLEG_STATE_INITIAL    */
      SO_CLEG_STATE_TERMINATED, /* SO_CLEG_STATE_PROCEEDING */
      SO_CLEG_STATE_TERMINATED, /* SO_CLEG_STATE_EARLY      */
      SO_CLEG_STATE_ERROR,      /* SO_CLEG_STATE_ACK_PEND   */
      SO_CLEG_STATE_ERROR,      /* SO_CLEG_STATE_ACTIVE     */ 
      SO_CLEG_STATE_ACTIVE,     /* SO_CLEG_STATE_MODIFY     */
      SO_CLEG_STATE_ERROR,      /* SO_CLEG_STATE_MODIFY_ACK */
      SO_CLEG_STATE_ERROR       /* SO_CLEG_STATE_TERMINATED */
   }
};


/************************************************************
                  Dialog Module Functions
************************************************************/

/*
*
*       Fun:   soDlgCreateCLeg
*
*       Desc:  This function creates a new CLeg and initializes the
*              structure.
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PUBLIC SoCLegCb *soDlgCreateCleg
(
SoCallCb   *callCb,    /* Call Cb */
SoEvnt     *evnt,      /* Event Cb */      
U8         direction   /* Direction - From User/ From Remote */
)
#else
PUBLIC SoCLegCb *soDlgCreateCleg(callCb, evnt, direction)
SoCallCb   *callCb;    /* Call Cb */
SoEvnt     *evnt;      /* Event Cb */      
U8         direction;  /* Direction - From User/ From Remote */
#endif
{
  S16         ret;
  SoCLegCb    *cLeg;   /* Call Leg Cb */
  SoAddress   *to;     /* To Address */
  SoAddress   *from;   /* From Address */
  SoCSeq      *cSeq;   /* CSeq  */
  U32         cSeqVal; /* CSeq Val */

  TRC2(soDlgCreateCleg);

   /* Check for message type before creating the call leg  */
   if ((evnt->eventType.val != SOT_ET_INVITE) &&
       (evnt->eventType.val != SOT_ET_REGISTER) &&
       (evnt->eventType.val != SOT_ET_MESSAGE) &&
       (evnt->eventType.val != SOT_ET_UNKNOWN) &&
       (evnt->eventType.val != SOT_ET_SUBSCRIBE) &&
       (evnt->eventType.val != SOT_ET_REFER) &&
       (evnt->eventType.val != SOT_ET_OPTIONS) &&
       (evnt->eventType.val != SOT_ET_UPDATE) &&
       /* so009.201 : To support INFO outside a call */
       (evnt->eventType.val != SOT_ET_INFO) &&
       (evnt->eventType.val != SOT_ET_NOTIFY))
     RETVALUE(NULLP);

  /* Allocate memory & initialize parametrs of the new call leg */
  cLeg = soDlgInitCLeg (callCb, evnt, direction);
  if (cLeg == NULLP)
    RETVALUE(NULLP);

  /* Find "to" header in message */
  if ((ret = soCmFindHdrChoice(evnt, (U8 **) &to, SO_HEADER_GEN_TO)) != ROK)
  {
    soDlgDeleteCleg(callCb, cLeg);
    RETVALUE(NULLP);
  }

  /* Find "from" header in message */
  if ((ret = soCmFindHdrChoice(evnt, (U8 **) &from, SO_HEADER_GEN_FROM)) 
      != ROK)
  {
    soDlgDeleteCleg(callCb, cLeg);
    RETVALUE(NULLP);
  }
  
  /* Initialize CSeq */
  ret = soCmFindHdrChoice(evnt, (U8 **) &cSeq, SO_HEADER_GEN_CSEQ);
  if ((ret != ROK) || (cSeq == NULLP))
  {
    cSeqVal = SO_CSEQ_START;
  }
  else
    cSeqVal = cSeq->cSeqVal.val;

  /* Initialize caleg infor based on direction */
  if (direction == SO_USER)
  {
    
    ret = soDlgUpdOutClegInfo(cLeg, evnt, to, from, cSeqVal,
                              direction);
    /*-- so033.201 : save the dialog creating CSeq Number in case 
         CSeq header is not present in the request --*/
     cLeg->storedHdrs.dlgCreateCSeq  = cSeqVal;
  }
  else
  {
    if ((ret != ROK) || (cSeq == NULLP))
    {
      soDlgDeleteCleg(callCb, cLeg);
      RETVALUE(NULLP);
    }

 /*- so017.201: Update dialog creating CSeq,it is used during dialog match -*/
  if (cSeq)
    cLeg->storedHdrs.dlgCreateCSeq  = cSeq->cSeqVal.val;
    
    ret = soDlgUpdIncClegInfo(cLeg, evnt, to, from, cSeqVal);
  }

  if (ret != ROK)
  {
    soDlgDeleteCleg(callCb, cLeg);
    RETVALUE(NULLP);
  }

  /* Update the ack tcmconn */
  soPrcInitTcmConn (&cLeg->ackCb.tcmConn, 
                    SO_TPT_TCMCONN_USER_DIALOG,
                    (PTR) cLeg);

#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
  /* so033.201: Initialize the client/server connection  *
   *            information                              */
   soPrcInitTcmConn (&cLeg->rspCb.tcmConn,
                     SO_TPT_TCMCONN_USER_DIALOG, 
                     (PTR) cLeg);
#endif
			
  SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
   "\n[Dialog] DIALOG Created => Entity(%d)  Call(%ld) CallLeg(%lx)",
   callCb->ent->entId, callCb->spConnId, cLeg->legId));

  RETVALUE(cLeg);

} /* soDlgCreateCleg */





/*
*
*       Fun:   soDlgDeleteCleg
*
*       Desc:  This function deletes Call Leg 
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soDlgDeleteCleg 
(
SoCallCb   *callCb,    /* Call Cb */
SoCLegCb   *cLeg       /* Call leg Cb */      
)
#else
PUBLIC Void soDlgDeleteCleg(callCb, cLeg)
SoCallCb   *callCb;    /* Call Cb */
SoCLegCb   *cLeg;      /* Call leg Cb */      
#endif
{
   SoTransCb   *transCb;   /* Transaction cb */

   TRC2(soDlgDeleteCleg);

   if (cLeg == NULLP)
     RETVOID;

   SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
   "\n[Dialog] DIALOG Deleted => Entity (%d)  Call (%ld) Dialog (%lx) \n",
   callCb->ent->entId, callCb->spConnId, cLeg->legId));

   transCb = NULLP;

   /* Delete cleg from callcb */
   /* so011.201: Support to handle REGISTER message at UAC. The 
      feature has been added under the flag SO_XX_UA_PRC_REGISTER. */
#ifdef SO_XX_UA_PRC_REGISTER
   if ((callCb->sessCreatedBy != SOT_ET_REGISTER) || 
       (cLeg->role == SO_SERVER))
#else
   if (callCb->sessCreatedBy != SOT_ET_REGISTER)
#endif
   {
     cmLListDelFrm(&callCb->cLegLst, &cLeg->llNode);
   }
   else
   {
     cmHashListDelete(&callCb->regCLegLst, (PTR)cLeg);
   }

   /* Delete All Transactions */
   while (cmHashListGetNext(&cLeg->tranCbLst, (PTR) NULLP,
                            (PTR *) &transCb) == ROK)
   {
     soTxnDeleteTrans(transCb);
   }
   cmHashListDeinit (&cLeg->tranCbLst);
   
   /* Delete the Stored Headers */
   soDlgDelStoredHdrs(cLeg);

   /* Delete AckCb */
   soDlgDelAckCb(cLeg);

   /* Delete Recursion cb */
   soDlgDelRecurseCb(cLeg);


   /* Delete Response Related info */
   soDlgDelRspInfo((Ptr)cLeg, FALSE, &cLeg->rspCb);

   /* Stop the Expires timer, if it is running */
   soSchedTmr(cLeg, SO_TMR_EXPIRES, TMR_STOP, NOTUSED);

   /* Stop cancel timer  */
   soSchedTmr(cLeg, SO_TMR_CANCEL, TMR_STOP, NOTUSED);

   /* Free pending cancel event, if present */
   if (cLeg->pendingCancel != NULLP)
     soCmFreeEvent(cLeg->pendingCancel);

   /* Free Pending Invite , if any */
   if (cLeg->sentInvite != NULLP)
     soCmFreeEvent(cLeg->sentInvite);

   if (cLeg->sentRsp != NULLP)
     SPutMsg(cLeg->sentRsp);


#ifdef SO_SESSTIMER
   /* Delete Session Timer Cb */
   soDlgDelSessTmrCb(cLeg);
#endif /* SO_SESSTIMER */

#ifdef SO_EVENT
   /* Delete Subscription cb */
   soDlgDelSubscCb(cLeg);
#endif /* SO_EVENT */


#ifdef SO_RFC_3262
   soDlgDelRelProvRspInfo(cLeg);
#endif /* SO_RFC_3262 */

#ifdef SO_UA
   soDlgDelRegInfo(cLeg);
#endif /* SO_UA */

   SOFREE(cLeg, sizeof(SoCLegCb));

   RETVOID;

} /* soDlgDeleteCleg */




/*
*
*       Fun:   soDlgFindCLegFromSu
*
*       Desc:  This function finds cleg based on cLegId.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC SoCLegCb *soDlgFindCLegFromSu
(
SoCallCb   *callCb,    /* Call Cb */
U32        cLegId      /* CLeg Id */
)
#else
PUBLIC SoCLegCb *soDlgFindCLegFromSu(callCb, cLegId)
SoCallCb   *callCb;    /* Call Cb */
U32        cLegId;     /* CLeg Id */
#endif
{
  CmLList    *curNode;    /* Current node in list         */
  PTR        curItem;     /* Current item                 */
  SoCLegCb   *cLeg;       /* Temp Call Leg control block  */
  Bool       found;       /* CLeg found/ not              */

  TRC2(soDlgFindCLegFromSu);

  found = FALSE;

  /* Look thru list in call cb */
  curNode = cmLListFirst(&callCb->cLegLst);
  while (curNode != NULLP)
  {
     curItem  = cmLListNode(curNode);
     curNode  = curNode->next;
     cLeg     = (SoCLegCb *)curItem;
      
     /* Look for matching call leg Id */
     if (cLeg->legId == cLegId)
     {
       found = TRUE;
       break;
     }
  }

  if (found == TRUE)
     RETVALUE(cLeg);
  else
     RETVALUE(NULLP);
} /* soDlgFindCLegFromSu */





/*
*
*       Fun:   soDlgUaOutReq
*
*       Desc:  Function processes outgoing requests.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC S16 soDlgUaOutReq
(
SoCLegCb   *cLeg,      /* Call Leg cb */
SoUserCtxt *userCtxt,  /* User Context */
SoEvnt     *evnt       /* Event Cb */
)
#else
PUBLIC S16 soDlgUaOutReq(cLeg, userCtxt, evnt)
SoCLegCb   *cLeg;      /* Call Leg cb */
SoUserCtxt *userCtxt;  /* User Context */
SoEvnt     *evnt;      /* Event Cb */
#endif
{
  S16         ret;       /* Return Value */
  SoAddrSpec  *reqAddr;   /* Address of next hop */
  SoAddrSpec  cancelDest; /* Address of next hop for CANCEL Req */
  CmTptAddr   tptAddr;   /* Resolved addr incase of direct ip */
  U8          tptProt;   /* tpt protocol */
  PTR         queryCb;   /* Query Cb     */
  U8          queryType; /* query type   */
  SoTransCb   *transCb;
  U16         eventType; /* Event Type   */

  TRC2(soDlgUaOutReq);

  queryCb = NULLP;

  cmMemset ((U8 *)&cancelDest, 0, sizeof (SoAddrSpec));

  eventType = evnt->eventType.val;

  /* Fill all mandatory headers */
  ret = soDlgChkMandUaOutReqHdr(cLeg, evnt);
  if (ret != SOT_ERR_NOERR)
    RETVALUE(ret);

#ifdef SO_TLS
   /* Update TLS info if SV requested for it */
   soDlgChkUpdTlsInfo(cLeg, evnt, SO_TLS_USER);
#else
   /* so027.201: Changes for SIP TLS support */
   ret = soDlgChkOutReqHdr(evnt);
   if (ret != ROK)
      RETVALUE(ret);
#endif

  /* Find out the address of the next hop */

  /*
   * so014.201: Finding out next hop address fo CANCEL method
   *   is treated  differently from other methods. For CANCEL
   *   method, we can directly find the IP/Port from the cor-
   *   responding INVITE transaction. Whereas for other requ-
   *   est,  it will be either requestURI or top route header
   *   element.
   */
   if (evnt->eventType.val != SOT_ET_CANCEL)
   {
     if (soDlgFindNextHopAddr (cLeg, &reqAddr) != ROK)
        RETVALUE (RFAILED);
   }
   else
   {
/* so027.201: Changes for SIP TLS support */
#ifdef SO_TLS
     if (cLeg->secure == SO_TLS_USER)
     {
        if (soDlgFindTlsCancelNextHopAddr ((SoTransCb *)userCtxt->userPtr,
                                     &cancelDest) != ROK)
           RETVALUE(RFAILED);
     }
     else
     {
#endif
     if (soDlgFindCancelNextHopAddr ((SoTransCb *)userCtxt->userPtr,
                                     &cancelDest) != ROK)
        RETVALUE (RFAILED);
/* so027.201: Changes for SIP TLS support */
#ifdef SO_TLS
     }
#endif

     userCtxt->userPtr = NULLP;
     reqAddr           = &cancelDest;
   }
  

  /* Store event in userCtxt, so that it will be available
     if there is a DNS call back */

  userCtxt->evnt = evnt;

  /* Create a new transaction for all requests except ACK */
  if (evnt->eventType.val != SOT_ET_ACK)
  {
    transCb = soTxnUaCreateTrans(cLeg->call->ssapCb->sys, SO_UAC, 
                               evnt, (PTR)cLeg, userCtxt);
    if (transCb == NULLP)
    {
      RETVALUE(SOT_ERR_RSRC);
    }

    /* Insert Transaction into call leg list */
    ret = cmHashListInsert(&cLeg->tranCbLst, (PTR) (transCb),
                           (U8 *) &transCb->transId,
                           sizeof(U32));
    if (ret != ROK)
    {
      /* Event will get deleted from UI layer */
      transCb->evnt = NULLP;

      /* Set the call leg ptr to NULLP else the txn layer
         will try to delete the txn from the cleg hash list.
         But since the hash list insertion failed, the 
         hash list del may corrupt the list */
      transCb->cLeg = NULLP;
      soTxnDeleteTrans(transCb);
      RETVALUE (SOT_ERR_RSRC);
    }
    
    /* Store the transCb in the userCtxt */
    userCtxt->userPtr = (PTR)transCb;
  }
  else
  {
    /* If it is an ACK store cleg infor in userctxt for later use */
     userCtxt->userPtr = (PTR)cLeg;
  }

  /* if the DNS module has issued a query to the DNS (async case),
     return from here. The message will be sent out from the 
     call Back function */

  ret = soDnsCheckAddr((PTR) userCtxt, reqAddr, &tptAddr,
                       &tptProt, &queryType, soDlgDnsReqCallBack,
                       &queryCb);

  /* If DNS query fails, return error */
  if (ret == RFAILED)
  {
    if(evnt->eventType.val != SOT_ET_ACK)
    {
       /* Event will get deleted from UI layer */
       transCb->evnt = NULLP;
       soTxnDeleteTrans(transCb);
    }

    RETVALUE(SOT_ERR_DNS_FAILED);
  }

  /* return value of  ROKDNA indicates that DNS query is required */
  if (ret == ROKDNA)
  {    
     /* Save the context of DNS queryCb */
     if (evnt->eventType.val != SOT_ET_ACK)
        SO_TXN_UPDATE_QUERYCB (transCb, queryCb)
     else
        cLeg->ackCb.dnsQuery  = queryCb;

    /* rest of functionality will be done after DNS module returns */
     RETVALUE(SOT_ERR_NOERR);
  }

  /* If the message originally contained a IP address or if a match
     was found in the cache send out the message */
  if (ret == ROK)
  {
    ret = soDlgPrcUaOutReq(userCtxt, &tptAddr, tptProt);

    (Void) soUtlDelSoHostPort (&cancelDest.t.sipUrl.hostPort);
  }

  if (ret != ROK)
  {
    /* In case of errors we need to clean up the trans */
    if (evnt->eventType.val != SOT_ET_ACK)
    {
      /* If the request was already passed onto the
         transaction layer and the error was returned from that
         layer, then it implies that tha transaction layer would
         have deleted thetransaction already. In such cases the
         userPtr is set to NULLP so make sure that this is not
         the case befre we release transaction again */

      if (userCtxt->userPtr != NULLP)
      {
        /* Event will get deleted from UI layer */
        transCb->evnt = NULLP;
        soTxnDeleteTrans(transCb);
      }
    }
  }
  else
  {
    /* Update Statistics */
    soUtlUpdOutReqSts(cLeg->call->ent, eventType);
  }

  RETVALUE(ret);

} /* soDlgUaOutReq */




/*
*
*       Fun:   soDlgUaOutRsp
*
*       Desc:  This function handles an INVITE from the Remote End
*
*       Notes: 
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC S16 soDlgUaOutRsp
(
SoCLegCb   *cLeg,    /* Cleg Cb */
SoEvnt     *evnt,    /* Event  */
SoTransCb  *transCb  /* Transaction Cb */
)
#else
PUBLIC S16 soDlgUaOutRsp(cLeg, evnt, transCb)
SoCLegCb   *cLeg;     /* Cleg Cb */
SoEvnt     *evnt;     /* Event  */
SoTransCb  *transCb;  /* Transaction Cb */
#endif
{
  S16       ret;           /* Retrun Value */
  Buffer    *mBuf;         /* Buffer */
  U8        responseClass; /* Response Class */
  U8        prevCLegState; /* old cal leg State(for roll
                                back in case of failure */

  TRC2(soDlgUaOutRsp);

  /* Get the transaction associated with the response */
  if (transCb == NULLP)
  {
    transCb = soDlgLocateRspTran(cLeg, evnt);
    if (transCb == NULLP)
    {
      RETVALUE(SOT_ERR_TRAN_NOTFOUND);
    }
  }

  /* Check for Mandatory response header */
  ret = soDlgChkMandUaOutRspHdr(cLeg, evnt,transCb);

  if (ret != SOT_ERR_NOERR)
    RETVALUE(ret);

  /* Update Dialog State */
  prevCLegState = cLeg->clegState;

  /* Update the state for INVITE related transactions */

  /* 
   * so012.201: In some cases dialog state needs to be updated
   *            while sending INVITE message. If dialog  state
   *            update  is  not  desired,  caller  should  set 
   *            noStateUpd as TRUE.
   */
  if ((evnt->eventType.val == SOT_ET_INVITE) && (cLeg->noStateUpd == FALSE))
  {
    ret = soDlgUpdState(cLeg, evnt, SO_REMOTE);
    if (ret != ROK)
      RETVALUE(SOT_ERR_CLEGSTATE_INVALID);
  }

  responseClass = (evnt->t.response.statusLine.statusCode.val)/100;

   SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
      "\n[Dialog] Outgoing (%d) Response Sent to Transaction:"
      " Call: %ld, CallLeg: %lx",
      evnt->t.response.statusLine.statusCode.val, 
      cLeg->call->spConnId, cLeg->legId));

  /* Pass message to transaction layer for further processing */
  ret = soTxnUaOutRsp(transCb, evnt,
                      (responseClass), (SoUserCtxt *)NULLP, 
                      (PTR)cLeg, &mBuf);

  if ((ret == ROK) && (mBuf != NULLP))
    cLeg->sentRsp = mBuf; 

  /* if procedure fails, get call leg back to previous state */
  if (ret != ROK)
    cLeg->clegState = prevCLegState;
  else
  {
    /* Update Statistics */
    soUtlUpdOutRspSts(cLeg->call->ent, responseClass);
  }

  RETVALUE(ret);
} /* soDlgUaOutRsp */


/*
*
*       Fun:   soDlgChkAndDelCLeg
*
*       Desc:  Check Call leg State and delete, if required.
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soDlgChkAndDelCLeg
(
SoCLegCb   *cLeg          /* Call Leg Cb */
)
#else
PUBLIC S16 soDlgChkAndDelCLeg(cLeg)
SoCLegCb   *cLeg;         /* Call Leg Cb */
#endif                              
{

  U16      findCount;     /* Number of entries in 
                             the transaction list */
  SoCallCb *callCb;

  TRC3(soDlgChkAndDelCLeg);
  
#ifdef SO_EVENT
  if(soDlgChkAndDelSubscNode(cLeg) != ROK)
    RETVALUE(ROKDNA);
#endif /* SO_EVENT */

  /* so006.201: Check if it is REGISTER cLeg */
  if ((cLeg->call->sessCreatedBy == SOT_ET_REGISTER)
     && (cLeg->regInfo.numRegContacts != 0))
     RETVALUE(ROKDNA);

  /* If call is in initial/ terminated state and there are no
     pending transactions, delete the call leg */
  if ((cLeg->clegState == SO_CLEG_STATE_TERMINATED) ||
      (cLeg->clegState == SO_CLEG_STATE_INITIAL) ||
      (cLeg->clegState == SO_CLEG_STATE_NONE)
#ifdef SO_UA
      || ((cLeg->call->sessCreatedBy == SOT_ET_REGISTER) 
      && (cLeg->regInfo.numRegContacts == 0))
#endif /* SO_UA */
      )
  {
    findCount = CM_HASH_NMBENT(&cLeg->tranCbLst);
    if (findCount != 0)
      RETVALUE(ROKDNA);
  } 
  else
    RETVALUE(ROKDNA);

  callCb = cLeg->call;

  /* Delete Call Leg */
  soDlgDeleteCleg(cLeg->call, cLeg);

  /* Delete Call if Required */
  if (callCb != NULLP)
    soCoreChkAndDelCall(callCb);


  RETVALUE(ROK);
}




#ifdef SO_EXT_OFFER_ANS
/*
*
*       Fun:   soDlgChkOfferAns
*
*       Desc:  Checks for offer-answer exchange 
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC S16 soDlgChkOfferAns
(
SoCLegCb   *cLeg,       /* Cleg Cb */
SoEvnt     *evnt,       /* Event  */
U8         msgType,     /* Message Type */
U8         direction    /* Direction of message */
)
#else
PUBLIC S16 soDlgChkOfferAns(cLeg, evnt, msgType, direction)
SoCLegCb   *cLeg;       /* Cleg Cb */
SoEvnt     *evnt;       /* Event  */
U8         msgType;     /* Message Type */
U8         direction;   /* Direction of message */
#endif
{
  S16      ret;       /* Return Value */
  Bool     sdpPres;   /* TRUE if SDP is present */
    
  TRC2(soDlgChkOfferAns);

  ret      = SOT_ERR_NOERR;
  sdpPres  = FALSE;

  /* Check if SDP is present in the message */
  SO_CHK_SDP(evnt, sdpPres);

  /* If SDP not present in the message & there was a pending offer
     that was not answered, return error. A pending
     offer should always be answered in a subsequent message */
  if (sdpPres == FALSE) 
  {
    if (cLeg->offerAnsCb.pendingOffer == TRUE)
      RETVALUE(SOT_ERR_ANSWER_PENDING);
    else
    {
      /* If there was no pending offer & it is the first reliable 
         response then return error, cause t needs to contain an offer */
      if (evnt->sipMessageType.val != SO_SIPMESSAGE_RESPONSE)
        RETVALUE(SOT_ERR_NOERR);

      if (cLeg->offerAnsCb.initOfferDone != TRUE)
      {
        RETVALUE(SOT_ERR_OFFER_REQUIRED);
      }
      /* so033.201: Offer-answer in Subsequent Provisional/Normal Response*/
      else
      {
        /* This leg will hit if offer-answer is already done once and
         * provisional/normal response is coming without a SDP.*/
        RETVALUE(SOT_ERR_NOERR);
      }
        
    }
  }

 
  /* If this is a new offer, initialize all values */
  if (cLeg->offerAnsCb.pendingOffer == FALSE)
  {
    cLeg->offerAnsCb.direction = direction;
    cLeg->offerAnsCb.pendingOffer = TRUE;
    cLeg->offerAnsCb.msgType = evnt->sipMessageType.val;
  }
  else
  {
    /* If the direction of this message is the same as
       that of the pending offer, it implies that the 
       SDP isnt the answer to the pending offer. So
       reject the message. A new offer cannot be sent when 
       there is a pending offer */

    if (cLeg->offerAnsCb.direction == direction)
      RETVALUE(SOT_ERR_ANSWER_PENDING);

    /* The offer answer draft says that if a offer was received
       in a request then the answer should be in the 
       corresponding response and vice versa. The check below 
       ensures that */
     if (cLeg->offerAnsCb.msgType == evnt->sipMessageType.val)
       RETVALUE(SOT_ERR_ANSWER_PENDING);      

    /* If it is a new pending offer, reset all the values */
    cLeg->offerAnsCb.pendingOffer = FALSE;

    /* If this is is the ending of the first offer/answer exchange tag
       mark it in the offer ans cb */
    if (cLeg->offerAnsCb.initOfferDone == FALSE)
      cLeg->offerAnsCb.initOfferDone = TRUE;
  }

  RETVALUE(SOT_ERR_NOERR);
}

#endif /* SO_EXT_OFFER_ANS */



/************************************************************
              Transaction Module Interface Functions
************************************************************/


/*
*
*       Fun:   soDlgUaIncReq
*
*       Desc:  This function handles new request received from transaction
*              layer.
*
*       Notes: 
*
*       File:  so_dlg.c
*
*/
#ifdef ANSI
PUBLIC S16 soDlgUaIncReq
(
SoEntCb   *ent,      /* Entity Cb      */
SoEvnt    *evnt,     /* Event Cb       */
SoTransCb *transCb,  /* Transaction cb */
SoTcmConn *tcmConn   /* Server Info    */
)
#else
PUBLIC S16 soDlgUaIncReq(ent, evnt, transCb, tcmConn)
SoEntCb   *ent;      /* Entity Cb      */
SoEvnt    *evnt;     /* Event Cb       */
SoTransCb *transCb;  /* Transaction cb */
SoTcmConn *tcmConn;  /* Server Info    */
#endif
{
  S16          ret;
  U16          eventType;
  SoCallCb     *callCb;  /* Call Cb  */
  SoCLegCb     *cLeg;    /* Call Leg */
  SoSSapCb     *sSapCb;  /* User Sap */
  SoCSeq       *cSeq ; /*CSeq header field */
  U32          cSeqVal;
  SoTransCb *prevTransCb = NULLP;  /* so039.201: Transaction cb */
  SoTransCb *curTransCb = NULLP;  /* so039.201: Transaction cb */

  TRC2(soDlgUaIncReq);

  callCb   = NULLP;
  cLeg     = NULLP;
  sSapCb   = NULLP;
  cSeq     = NULLP;  

  /* 
   * so017.201
   * This function is called by transaction layer whenever new request
   * is received from peer.
   */

   /*--------- Locate the dialog to which request belongs ----------*/
    ret = soCoreReqMatchDialog (ent, evnt, &callCb, &cLeg);

   /*---- Further action depends upon return type ----*/
    switch (ret)
    {
       case SO_DLG_CREATE:
            /*------- Dialog Creating Request Received --------*/ 

            /*---- If Needed, Create Call Context ----*/
             if (callCb == NULLP)
             {
                 /*------ Select Service User SAP ----*/
                 (Void) soCmFindSSap (&sSapCb, tcmConn->serverCb);
                 
                 /* 
                  * so020.201: Check if there is enough resource,
                  *  return 503 when stack runs low on resources.
                  *
                  * so037.201: While sending error responses,pass
                  * call leg as NULLP to  make  sure that its not
                  * updated in transaction.
                  */
                 cLeg = NULLP;

                 if (soUtlChkRes(evnt, SO_REMOTE) != ROK)
                   SO_UA_SEND_ERR_RSP (cLeg, transCb, evnt,
                                       SOT_RSP_503_SERVICE_UNAVAIL,
                                       SO_EXTRSP_NONE);
                 
                 /*---- Create Call Control Block ----*/
                 if (sSapCb != NULLP)
                   callCb = soCoreCreateCallCb (sSapCb, ent, SO_CONNID_NOTUSED, 
                                                evnt  , SO_REMOTE);

                 if (!callCb)
                   SO_UA_SEND_ERR_RSP (cLeg, transCb, evnt,
                                       SOT_RSP_481_CLEG_TRAN_NOT_EXIST,
                                       SO_EXTRSP_NONE);
             }

            /*------- Create New Dialog Context ------*/
             cLeg = soDlgCreateCleg (callCb, evnt, SO_REMOTE);
             if (!cLeg)
               SO_UA_SEND_ERR_RSP (cLeg, transCb, evnt,
                                   SOT_RSP_481_CLEG_TRAN_NOT_EXIST,
                                   SO_EXTRSP_NONE);
          break;

       case SO_DLG_MATCH :
            /*------- Request Belongs To Existing Dialog ------*/ 
    
          /* so031.201 Check for the Incoming CSeq Number per 12.2.2 section
            of RFC 3261.Incoming CSeq should be greater than the stored CSeq.*/
            
            ret = soCmFindHdrChoice(evnt, (U8 **) &cSeq, SO_HEADER_GEN_CSEQ);
            cSeqVal = cSeq->cSeqVal.val;
            if(cSeq != NULLP)
            {
               if ((evnt->eventType.val != SOT_ET_ACK) &&
                  (evnt->eventType.val != SOT_ET_CANCEL))
               {
                  if(cLeg->storedHdrs.cSeqHiRx >= cSeqVal)
                  {
                     SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                              "\n[Dialog] Incoming CSeq is less than"
                              " the stored remote CSeq"));
                     /* so035.201, so037.201: Modified cLeg to     *
                      * tranCb->cLeg. Passing callLeg as NULLP to  *
                      * ensure that its not updated in transcation */
                     cLeg = NULLP;
                     SO_UA_SEND_ERR_RSP  (cLeg, transCb, evnt,
                                          SOT_RSP_500_SRV_INT_ERROR,
                                          SO_EXTRSP_NONE);
                  }
                  else
                  {
                     cLeg->storedHdrs.cSeqHiRx = cSeqVal ;
                  }
               }
            }

          break;

       case SO_DLG_NOMATCH :
            /*---------- Incorrect Request Received -----------*/ 
             cLeg = NULLP;
             SO_UA_SEND_ERR_RSP (cLeg, transCb, evnt,
                                 SOT_RSP_481_CLEG_TRAN_NOT_EXIST,
                                 SO_EXTRSP_NONE);
          break;

    } /* End of switch (dialog matching result) */

  SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
    "\n[Dialog] %s Request Received: Call(%ld), CallLeg(%lx), State(%d)",
    soSOTEventDescrip[evnt->eventType.val - 1], cLeg->call->spConnId,
    cLeg->legId, cLeg->clegState));

  /* Update call leg pointer in transaction */
  SO_TXN_UPDATE_CLEG(transCb, cLeg);

  /* Update legId in Event */
  SO_DLG_UPDATE_EVENT_LEGID(evnt, cLeg->legId);


  /* Insert transcb into the transaction list in call leg */
  ret = cmHashListInsert(&cLeg->tranCbLst,
                         (PTR)transCb, (U8 *) &transCb->transId,
                         sizeof(U32));
  if (ret != ROK)
  {
    SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
        "\n[Dialog] Cannot Insert TransCb in Dialog HashList"));

   /* so037.201:Remove context of callLeg from the transaction */
    transCb->cLeg = NULLP;

    SO_UA_SEND_ERR_RSP(((SoCLegCb *)transCb->cLeg), transCb, evnt,SOT_RSP_500_SRV_INT_ERROR,
                       SO_EXTRSP_NONE);
  }

 /* Check if all the required mandatory headers have been rcvd */
  ret = soDlgChkMandUaIncHdr(ent, cLeg, evnt);
  if (ret != SOT_RSP_NONE)
  {
    SO_UA_SEND_ERR_RSP(cLeg, transCb, evnt, ret,SO_EXTRSP_NONE);
  }

  /* Store the incoming Via */
  if (evnt->eventType.val == SOT_ET_INVITE)
  { 
    if (soUtlPrcStoreVia (&cLeg->rspCb.rcvdVia, evnt) != ROK)
    {
      SO_UA_SEND_ERR_RSP(cLeg, transCb, evnt, SOT_RSP_400_BAD_REQUEST, 
                         SO_EXTRSP_NONE);
    }
  }
   
#ifdef SO_TLS
   /* For TLS call, check if transport is TLS end to end */
   /* In case of non secure call, this function will return ROKDNA */
   ret = soDlgChkIncReqTlsInfo(cLeg, evnt);
   if (ret == ROK)
   {
      /* Mark CallLeg as secure */
      cLeg->secure = SO_TLS_USER;
   }
   else if (ret == RFAILED)
   {
     SO_UA_SEND_ERR_RSP(cLeg, transCb, evnt, SOT_RSP_400_BAD_REQUEST, 
                       SO_EXTRSP_NONE);
   }
#endif

   /* Check if UA is cfgd to receive messages from the default proxy
      only. If yes and if the message was received from some other 
      node, return error */
   if (ent->s.ua.reCfg.dfltPrxCfg.rcvDfltPrxOnly == TRUE)
   {
     ret = soDlgChkDfltInPrx(ent, transCb, evnt);

     if (ret == ROKDNA)
       RETVALUE(ROK);

     if (ret != ROK)
     {
       SO_UA_SEND_ERR_RSP(cLeg, transCb, evnt,SOT_RSP_305_USE_PROXY, 
                          SO_EXTRSP_NONE);
     }
   }

   eventType = evnt->eventType.val;

   /* Update Statistics */
   soUtlUpdInReqSts(cLeg->call->ent, eventType);

   ret = soDlgPrcUaIncReq(transCb, evnt);
   if (ret != ROK)
     goto SODLGUAINCREQ_FAILED;
   
   RETVALUE (ROK);

   /* In case of any error encountered during this procedure,
      delete transaction and if reqd delete cleg & call */

SODLGUAINCREQ_FAILED:
    /* so039.201: Go through the Txn list and delete Txn only if it is not 
       deleted in transaction module */
    while (cmHashListGetNext(&cLeg->tranCbLst, 
             (PTR)prevTransCb,
             (PTR *) &curTransCb) == ROK)
    {
       if (curTransCb == transCb)
       {
          soTxnDeleteTrans(transCb);
          break;/* so041.201: Added break here.*/
       }
    }

    if (cLeg != NULLP)
    {
      soDlgChkAndDelCLeg(cLeg);    

      SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
               "\n[Dialog] %s Request Dropped: Call: %ld, CallLeg: %lx",
               soSOTEventDescrip[evnt->eventType.val - 1], 
               cLeg->call->spConnId, cLeg->legId));
    }

  RETVALUE(ret);
} /* soDlgUaIncReq */





/*
*
*       Fun:   soDlgUaIncRsp
*
*       Desc:  Processes an incoming response.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC S16 soDlgUaIncRsp
(
SoEntCb    *ent,      /* Entity Cb   */
SoEvnt     *evnt,     /* Event Cb    */
SoCLegCb   *cLeg,     /* Call Leg Cb */
SoUserCtxt *userCtxt 
)
#else
PUBLIC S16 soDlgUaIncRsp(ent, evnt, cLeg, userCtxt)
SoEntCb    *ent;      /* Entity Cb   */
SoEvnt     *evnt;     /* Event Cb    */
SoCLegCb   *cLeg;     /* Call Leg Cb */ 
SoUserCtxt *userCtxt;
#endif
{
  S16      ret;           /* Return Value      */
  U16      responseClass; /* Response Class    */
  U16      eventType;     /* Received Rsp Type */
  SoCLegCb *rspCLeg;      /* Call Leg Cb       */ 
  SoCLegCb *tmpCLeg, *origCLeg;/* Temp call leg*/

  TRC3(soDlgUaIncRsp);

  ret           = ROK;
  origCLeg      = cLeg;
  responseClass = 0;

  /* 
   * so017.201
   * This function is called by transaction layer whenever new response
   * is received from peer.
   */
  /*- When response is received from transaction,callLeg must exist -*/
    if (!cLeg)
      RETVALUE (RFAILED);

  /*---------- Locate the dialog to which response belongs ----------*/
    ret = soCoreRspMatchDialog (ent, evnt, cLeg->call, &cLeg, &tmpCLeg);

   /*---- Further action depends upon return type ----*/
    switch (ret)
    {
       case SO_DLG_CREATE:
            /*------- Dialog Creating Response Received -------*/
            /*- Multiple 1xx/2xx for dialog creating requests -*/

            /*--- Create New Dialog Context, Using Old One ----*/
             ret = soDlgCreateCLegFromCLeg (origCLeg, &rspCLeg, evnt);
             if (ret != ROK)
               RETVALUE (ret);

             cLeg = rspCLeg;

          break;

       case SO_DLG_MATCH :
            /*------- Request Belongs To Existing Dialog ------*/
          break;

       case SO_DLG_NOMATCH :
            /*---------- Incorrect Response Received ----------*/ 

            /* so030.201: Send ErrInd to App in case of dialog match fail */
            
            (Void) soDlgErrInd (origCLeg, SO_TRANS_ERROR, evnt, userCtxt);

            /* so033.201 : Returning FAIL will cause TCM to free the event 
               again */
             RETVALUE (ROK);
          break;

    } /* End of switch (dialog matching result) */

  /* Check for mandatory headers in the received message */
  ret = soDlgChkMandUaIncHdr(ent, cLeg, evnt);
  if (ret !=  SOT_RSP_NONE)
    goto SODLGUAINCRSP_CLEANUP;

  /* Update legId in Event */
  SO_DLG_UPDATE_EVENT_LEGID(evnt, cLeg->legId);

  /* Update the state for INVITE related transactions */
  if (evnt->eventType.val == SOT_ET_INVITE)
  {
    ret = soDlgUpdState(cLeg, evnt, SO_REMOTE);
    if (ret != ROK)
      goto SODLGUAINCRSP_CLEANUP;
  }

#ifdef SO_TLS
   /* Check if transport is TLS end to end */
  /* so35.201: Check for secure call info only incase of secure call */
   if (cLeg->secure == SO_TLS_USER)
   {
      ret = soDlgChkIncRspTlsInfo(cLeg, evnt);
      if (ret != ROK)
         goto SODLGUAINCRSP_CLEANUP;
   }
#endif

  responseClass = evnt->t.response.statusLine.statusCode.val/100;

  if ((responseClass < SO_STACODE_TYPE_SUCCESS) && 
      (evnt->eventType.val != SOT_ET_INVITE)
#ifdef SO_1XX_PASS
     /*--- so013.201: Pass 1XX Response To User ---*/ 
      && ((evnt->eventType.val == SOT_ET_CANCEL) ||
          (evnt->eventType.val == SOT_ET_BYE))
#endif
    )
  {
    (Void) soCmFreeEvent(evnt);
     RETVALUE(ROK);
  }

#ifdef SO_EXT_OFFER_ANS
  if (responseClass >SO_STACODE_TYPE_SUCCESS)
    cLeg->offerAnsCb.pendingOffer = FALSE;
#endif

  SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
             "\n[Dialog] %d Response to %s Received: "
             "Call(%ld), CallLeg(%lx)",
             evnt->t.response.statusLine.statusCode.val, 
             soSOTEventDescrip[evnt->eventType.val - 1],
             cLeg->call->spConnId, cLeg->legId));

  eventType = evnt->eventType.val;

  switch (evnt->eventType.val)
  {
    case SOT_ET_INVITE:
      ret = soUaInviteCfm(cLeg, evnt);
      break;
    case SOT_ET_CANCEL:
      ret = soUaCancelCfm(cLeg, evnt);
      break;
    case SOT_ET_BYE:
      ret = soUaByeCfm(cLeg, evnt);
      break;
    case SOT_ET_INFO:
      ret = soUaInfoCfm(cLeg, evnt);
      break;
    case SOT_ET_OPTIONS:
      ret = soUaOptionsCfm(cLeg, evnt);
      break;
    case SOT_ET_REGISTER:
      ret = soUaRegisterCfm(cLeg, evnt,userCtxt);
      break;
    case SOT_ET_UNKNOWN:
      ret = soUaUnknownCfm(cLeg, evnt);
      break;
    case SOT_ET_PRECON_MET:
      ret = soUaCometCfm(cLeg, evnt);
      break;
#ifdef SO_RFC_3262
    case SOT_ET_PRACK:
      ret = soUaPrackCfm(cLeg, evnt);
      break;
#endif
#ifdef SO_INSTMSG
     case SOT_ET_MESSAGE:
       ret = soUaMessageCfm(cLeg, evnt);
       break;
#endif
#ifdef SO_UPDATE
     case SOT_ET_UPDATE:
       ret = soUaUpdateCfm(cLeg, evnt);
       break;
#endif
#ifdef SO_EVENT
    case SOT_ET_SUBSCRIBE:
      ret = soUaSubscCfm(cLeg, evnt, userCtxt);
      break;
    case SOT_ET_NOTIFY:
      ret = soUaNotifyCfm(cLeg->call->ssapCb, 
                          cLeg, evnt, userCtxt);
      break;
#ifdef SO_REFER
    case SOT_ET_REFER:
      ret = soUaReferCfm(cLeg, evnt, userCtxt);
      break;
#endif /* SO_REFER */
#endif /* SO_EVENT */
  }

  if (ret == ROK)
  {
    /* Update Statistics */
    soUtlUpdInRspSts(cLeg->call->ent, responseClass);
  }

  SODLGUAINCRSP_CLEANUP:

    /*-- so026.201: ROKDNA indicates call may be already deleted --*/
     if ((ret != ROKDNA) && (responseClass >= SO_STACODE_TYPE_SUCCESS))
     {
       /* If a call leg needs to be deleted we need to make sure
          that the call leg was infact created by the method
          for which this rsp was received. The exception to
          this is a BYE, which can delete an INVITE txn */

       /*--- so009.201: Either BYE or EventType ----*/
       if ((eventType == SOT_ET_BYE) ||
           (cLeg->call->sessCreatedBy == eventType))
         soDlgChkAndDelCLeg(cLeg);
     }

     if ((ret != ROKDNA) && (ret != ROK))
     {
       SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
         "\n[Dialog] %d Response to %s Dropped: Call: %ld, CallLeg: %lx",
         evnt->t.response.statusLine.statusCode.val, 
         soSOTEventDescrip[evnt->eventType.val - 1],
         cLeg->call->spConnId, cLeg->legId));

          /* so035.201: Removed code to Send ErrInd to App in case of error match fail */

          /* so035.201: Modify to RETVALUE(ret); from so033 */
            
         RETVALUE(ret);
     }
     
     RETVALUE(ROK);
}





/*
*
*       Fun:   soDlgErrRspAck
*
*       Desc:  Processes an ACK received for a Error (3xx-6xx)
*              response.
*
*       Notes: 
*
*       File:  
*
*/
#ifdef ANSI
PUBLIC Void soDlgErrRspAck
(
SoCLegCb  *cLeg      /* Call Leg */
)
#else
PUBLIC Void soDlgErrRspAck(cLeg)
SoCLegCb  *cLeg;      /* Call Leg */
#endif
{
  SoCallCb     *callCb;
  TRC2(soDlgErrRspAck);

  /* Nothing needs to be done for a 3xx-6xx msg ACK */
  if (cLeg == NULLP)
    RETVOID;
  
  callCb = cLeg->call;

  SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
         "\n[Dialog] 3xx-6xx ACK received: Call: %ld, CallLeg: %lx",
          cLeg->call->spConnId, cLeg->legId));

  /* Delete the Call & The Call Leg */
  soDlgChkAndDelCLeg(cLeg);
    
  RETVOID;
}






/*****************************************************************************
*
*       Fun  : soDlgRmvTransCtxt
*
*       Desc : Function to remove TRanscation context from the call leg
*          
*
*       Ret  : ROK it is in. 
*              RFAILED not in. 
*
*       Notes: 
*
*
*       File:  po_dlg.c
*
*****************************************************************************/
#ifdef ANSI
PUBLIC Void soDlgRmvTransContext
(
SoCLegCb    *cLeg,     /* Call Leg cb */
SoTransCb   *transCb   /* Transaction cb */
)
#else
PUBLIC Void soDlgRmvTransContext(cLeg, transCb)
SoCLegCb    *cLeg;     /* Call Leg cb */
SoTransCb   *transCb;  /* Transaction cb */
#endif
{
  TRC3(soDlgRmvTransContext);
 
  /* Remove Transaction from call leg */
  (Void) cmHashListDelete(&cLeg->tranCbLst,(PTR) transCb);

  RETVOID;
}


/************************************************************
              Transport Module Interface Functions
************************************************************/


/**********************************************************************
*
*       Fun  : soDlgIncAck
*
*       Desc : Handles an incoming INVITE Ack
*
*       Ret  : ROK it is in. 
*              RFAILED not in. 
*
*       Notes: 
*
*
*       File:  so_dlg.c
*
**********************************************************************/

/*- so017.201: call leg will never be provided by transaction layer --*/

#ifdef ANSI
PUBLIC S16 soDlgIncAck
(
SoEntCb     *ent,       /* Ent Cb */
SoEvnt      *evnt       /* Event cb */
)
#else
PUBLIC S16 soDlgIncAck (ent, evnt)
SoEntCb     *ent;       /* Ent Cb */
SoEvnt      *evnt;      /* Event Cb */
#endif
{
  S16        ret;
  SoCLegCb   *cLeg;
  SoCallCb   *call;
  U8         prevCLegState;

   TRC3(soDlgIncAck);

   cLeg = NULLP;
   call = NULLP;

  /* 
   * so017.201
   * This function is called by transport layer whenever ACK for 2xx
   * response is received from peer.
   */
   /*------ Locate the dialog to which ACK request belongs -------*/
   ret = soCoreReqMatchDialog (ent, evnt, &call, &cLeg);

   if (ret != SO_DLG_MATCH)
     /*-- Dialog should always be found for ACK Request --*/
     RETVALUE (RFAILED);

   SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
     "\n[Dialog] INVITE ACK received: Call(%ld), CallLeg(%lx), State(%d)",
     cLeg->call->spConnId, cLeg->legId, cLeg->clegState));

   /* Update legId in Event */
   SO_DLG_UPDATE_EVENT_LEGID(evnt, cLeg->legId);

   /* Update the call leg State */
   prevCLegState = cLeg->clegState;

   ret = soDlgUpdState(cLeg, evnt, SO_REMOTE);

   /* so029.201 : This is the case of retransmitted ACK's. 
      No debug prints to be printed */
   if (ret == ROKDNA)
   {
      (Void) soCmFreeEvent (evnt);
      RETVALUE (ROK);
   }

   if (ret != SOT_ERR_NOERR)
   {
        SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                   "\n[Dialog] State Update For ACk Failed"));
        RETVALUE(RFAILED);
   }

   /* Send ACK to Core layer */
   ret = soUaAckInd(cLeg, evnt);

   if (ret != ROK)
   {
     cLeg->clegState = prevCLegState;

     SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                "\n[Dialog] Failed in processing ACK message"));
     RETVALUE(ret);
   }

   RETVALUE(ret);
} /* soDlgIncAck */





/*****************************************************************************
*
*       Fun  : soDlgIncRspFromTpt
*
*       Desc : Processes a Incoming 2xx response from Transport. The respnse
*              will come directly to the dialog layer from the transport layer
*              for two reasons - It is a retransmission of a 2xx response or
*              if we are receiving multiple forked responses.
*
*       Ret  : ROK it is in. 
*              RFAILED not in. 
*
*       Notes: 
*
*
*       File:  so_dlg.c
*
*****************************************************************************/
#ifdef ANSI
PUBLIC S16 soDlgIncRspFromTpt
(
SoEntCb   *ent,        /* Ent Cb */
SoEvnt    *evnt        /* Event  */
)
#else
PUBLIC S16 soDlgIncRspFromTpt(ent, evnt)
SoEntCb   *ent;        /* Ent Cb */
SoEvnt    *evnt;       /* Event  */
#endif
{
   S16        ret;        /* Return value of function   */
   U16        responseClass;    /* Response Type        */
   SoCLegCb   *cLeg;      /* Call Leg Cb                */
   SoCLegCb   *partialCLeg;/* Partially matched call leg */
   
   TRC3(soDlgIncRspFromTpt);

   ret           = ROK;
   cLeg          = NULLP;
   partialCLeg   = NULLP;
   responseClass = evnt->t.response.statusLine.statusCode.val/100;

  /*
   * so017.201: This function is called by transport module when it
   * receives a response that cannot be mapped to any clint transa-
   * ction.
   */

  /*
   * This function  will  handle multiple final response for dialog
   * creating request (due to downstream forking). All other respo-
   * nse are dropped.
   */
   if ((evnt->eventType.val != SOT_ET_INVITE) ||
       (responseClass       != SO_STACODE_TYPE_SUCCESS))
   {
     (Void) soCmFreeEvent (evnt);
     RETVALUE (ROK);
   }

  /*-------- Locate the dialog to which response belongs --------*/
   ret = soCoreRspMatchDialog (ent, evnt, NULLP, &cLeg, &partialCLeg);

  /*---- Further action depends upon return type ----*/
   switch (ret)
    {
       case SO_DLG_CREATE:
            /*------- Dialog Creating Response Received -------*/
            /*- Multiple 1xx/2xx for dialog creating requests -*/

            /*--- Create New Dialog Context, Using Old One ----*/
             if (partialCLeg)
                ret = soDlgCreateCLegFromCLeg (partialCLeg, &cLeg, evnt);
             else
                RETVALUE (RFAILED);

             if (ret != ROK)
                RETVALUE (ret);

             SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf,
               "\n[Dialog]: Forked 2xx response received: Call(%ld), "
               "CallLeg(%lx) ",
                cLeg->call->spConnId, cLeg->legId));
      
            /*--------- Update State Of New Call Leg ----------*/
             ret = soDlgUpdState (cLeg, evnt, SO_REMOTE);
             if (ret == ROK)
            /*--------- Send Response To Core Layer -----------*/
                ret = soUaInviteCfm (cLeg, evnt);

             if (ret != ROK)
             {
               soDlgDeleteCleg (cLeg->call, cLeg);
               RETVALUE (RFAILED);
             }

          break;

       case SO_DLG_MATCH :
            /*------- Request Belongs To Existing Dialog ------*/
            /* 
             * If response belongs to existing dialog, it implies
             * that it is a retransmitted 2xx. In such a case re-
             * transmit ACK request, if there was one.
             */
             SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
                   "\n[Dialog]: Re-transmitted 2xx response received :"
                   " Call(%ld), CallLeg(%lx)",
                    cLeg->call->spConnId, cLeg->legId));
          
             /*- so009.201: Callleg should be in active state -*/
              if ((cLeg->clegState  == SO_CLEG_STATE_ACTIVE) &&
                  (cLeg->ackCb.mBuf != NULLP))
              {
                  SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
                    "\n[Dialog]: Re-transmitting ACK for dup 2xx : "
                    "Call(%ld), CallLeg(%ld)",
                    cLeg->call->spConnId, cLeg->legId));
          
                 /*------------ Retransmit ACK ----------------*/
                  (Void) soTptSendReTransReq (ent,
                                            &cLeg->ackCb.tptAddr,
                                            &cLeg->ackCb.tcmConn,
                                            cLeg->ackCb.mBuf);
              }
                
             /*---------- so013.201: Release Event ------------*/
              (Void) soCmFreeEvent(evnt);       
              
          break;

       case SO_DLG_NOMATCH :
            /*---------- Incorrect Response Received ----------*/ 
             RETVALUE (RFAILED);
          break;

    } /* End of switch (dialog matching result) */

   RETVALUE (ROK);

} /* soDlgIncRspFromTpt */


/************************************************************
                  Dialog Module Support Functions
************************************************************/

/*
*
*       Fun:   soDlgDeleteAllTxn
*
*       Desc:  Deletes all transactions except BYE transaction
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soDlgDeleteAllTxn
(
SoCLegCb   *cLeg      /* Call Leg */
)
#else
PUBLIC Void soDlgDeleteAllTxn(cLeg)
SoCLegCb   *cLeg;     /* Call Leg */
#endif
{
  SoTransCb   *transCb;       /* Transaction cb */
  SoTransCb   *prevTransCb;   /* Previous netry in hash list */


  TRC2(soDlgDeleteAllTxn);

  prevTransCb = NULLP;

  /* Go through the list and delete all transactions */
  while (cmHashListGetNext(&cLeg->tranCbLst, 
                           (PTR)prevTransCb,
                           (PTR *) &transCb) == ROK)
  {    
    
    if (transCb->transMethod != SOT_ET_BYE)
    {
      soTxnDeleteTrans(transCb);
    }
    else
      prevTransCb = transCb;
  }


  RETVOID;
} 

/* so029.201 : function added to close all pending txn */
/*
*
*       Fun:   soDlgCloseAllPendingTxn
*
*       Desc:  Closes all transactions except BYE transaction
*               Written as part of the solution for ccpu00061209
*
*       Notes:
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soDlgCloseAllPendingTxn
(
SoCLegCb   *cLeg      /* Call Leg */
)
#else
PUBLIC Void soDlgCloseAllPendingTxn(cLeg)
SoCLegCb   *cLeg;     /* Call Leg */
#endif
{
  SoTransCb   *transCb;       /* Transaction cb */
  SoTransCb   *nextTransCb;   /* Previous netry in hash list */


  TRC2(soDlgCloseAllPendingTxn);

  nextTransCb = NULLP;

  /* so041.201 : Modified the logic to go through the hash list. 
   * Before closing transaction get the next hash list entity, since  
   * transaction is deleted for TCP/TLS
   */
  if (cmHashListGetNext(&cLeg->tranCbLst, NULLP, 
         (PTR *)&transCb) != ROK)
     RETVOID;

  /* Go through the list and delete all transactions */
  while (transCb)
  {
     cmHashListGetNext(&cLeg->tranCbLst,
           (PTR)transCb,
           (PTR *) &nextTransCb);


     if (transCb->transMethod != SOT_ET_BYE)
     {
        /* so038.201 : modified function to move Closing pending Trans to the 
           trans module */
        soTxnClosePendingTrans(transCb);
     }

     transCb = nextTransCb;
     nextTransCb = NULLP;
  }
  RETVOID;
}

/*
*
*       Fun:   soDlgDelAckCb
*
*       Desc:  Deletes the ACk related information in call leg
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PRIVATE Void soDlgDelAckCb
(
SoCLegCb   *cLeg       /* Call leg Cb */      
)
#else
PRIVATE Void soDlgDelAckCb(cLeg)
SoCLegCb   *cLeg;      /* Call leg Cb */      
#endif
{
  SoAckCb  *ackCb;   /* ACK cb */

  TRC2(soDlgDelAckCb);
        
  ackCb = &cLeg->ackCb;

  /* so006.201 : Added deletion of new branchid param */
  /*------------ Delete branch ID paraemter -----------*/
  soUtlDelTknStrOSXL (&ackCb->branchId);

  /* delete Stored ack */
  if (ackCb->mBuf != NULLP)
    SPutMsg(ackCb->mBuf);

  soPrcDelTcmConn (&ackCb->tcmConn);

  /* Delete Query Cb */
#ifdef SO_DNS
  if (ackCb->dnsQuery != NULLP)
    (Void)soDnsLookupRel (ackCb->dnsQuery);
#endif

  RETVOID;

} /* soDlgDelAckCb */




/*
*
*       Fun:   soDlgDelRecurseCb
*
*       Desc:  Deletes the Recursion related information in call leg
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soDlgDelRecurseCb
(
SoCLegCb   *cLeg       /* Call leg Cb */      
)
#else
PUBLIC Void soDlgDelRecurseCb(cLeg)
SoCLegCb   *cLeg;      /* Call leg Cb */      
#endif
{
  SoRecurseCb  *recurseCb;   /* Recurse cb */
  SoRecurseContact *recContact; /* Recursion Contacts */
  CmLList    *curNode;       /* Current node in list  */
  PTR        curItem;        /* Current item          */

  TRC2(soDlgDelRecurseCb);
        
  recurseCb = &cLeg->recurseCb;


  /* Destroy all call legs in call */
  curNode = cmLListFirst(&recurseCb->recContactLst);
  while (curNode != NULLP)
  {
    curItem  = cmLListNode(curNode);
    curNode  = curNode->next;
    recContact = (SoRecurseContact *)curItem;
    cmLListDelFrm(&recurseCb->recContactLst, &recContact->contactNode);
    
    /* Delet the contact Item */
    soUtlDelSoContactItem(recContact->contact);
    SOFREE(recContact->contact, sizeof(SoContactItem));
    SOFREE(recContact, sizeof(SoRecurseContact));
  }

  RETVOID;

} /* soDlgDelRecurseCb */




/*
*
*       Fun:   soDlgDelRspInfo
*
*       Desc:  Deletes response cb
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PRIVATE Void soDlgDelRspInfo
(
Ptr       usrPtr,    /* User ptr */
Bool      provRsp,   /* 1xx rsp / not */
SoRspCb   *rspCb     /* Response Cb */
)
#else
PRIVATE Void soDlgDelRspInfo(usrPtr, provRsp, rspCb)
Ptr       usrPtr;    /* User ptr */
Bool      provRsp;   /* 1xx rsp / not */
SoRspCb   *rspCb;    /* Response Cb */
#endif
{
  S16       ret;       /* Return Value */

  TRC2(soDlgDelRspInfo);


  /* Stop all response timers */
  /* If this is called in the context of a cleg stop 2xx timers
     else stop provisional rsp timers */
  if (provRsp == FALSE)
  {
    soSchedTmr(usrPtr, SO_TMR_2XX_RETX, TMR_STOP, NOTUSED);
    soSchedTmr(usrPtr, SO_TMR_2XX_EXPIRY, TMR_STOP, NOTUSED);
  }
  else
  {
    soSchedTmr(usrPtr, SO_TMR_1XX_RETX, TMR_STOP, NOTUSED);
    soSchedTmr(usrPtr, SO_TMR_1XX_EXPIRY, TMR_STOP, NOTUSED);
  }


  /* Release Buffer */
  if (rspCb->rspMsg != NULLP)
    SPutMsg(rspCb->rspMsg);

  /* Delete the stored Via */
  ret = soUtlDelSoVia(&rspCb->rcvdVia);

#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
  /* so033.201: De-Initialize  client/server connection  *
   *            information                              */
  soPrcDelTcmConn (&rspCb->tcmConn);
#endif


  RETVOID;

} /* soDlgDelRspInfo */




/*
*
*       Fun:   soDlgDelStoredHdrs
*
*       Desc:  Deletes Stored Hdrs
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PRIVATE Void soDlgDelStoredHdrs
(
SoCLegCb   *cLeg       /* Call leg Cb */      
)
#else
PRIVATE Void soDlgDelStoredHdrs(cLeg)
SoCLegCb   *cLeg;      /* Call leg Cb */      
#endif
{

  SoCLegHdrs   *cLegHdrs;  /* Call Leg Headers */

  TRC2(soDlgDelStoredHdrs);

  cLegHdrs = &cLeg->storedHdrs;

  /* Delete Local & Remote Address */
  soUtlDelSoAddress(&cLegHdrs->remoteAddr);
  soUtlDelSoAddress(&cLegHdrs->localAddr);

  /* Delete Normaized Address */
  soUtlDelTknStrOSXL(&cLegHdrs->normRemoteAddr);
  soUtlDelTknStrOSXL(&cLegHdrs->normLocalAddr);

  /* Delete Stored Tags */
  soUtlDelTknStrOSXL(&cLegHdrs->remoteTag);
  soUtlDelTknStrOSXL(&cLegHdrs->localTag);

  /* Delete Request URI & Remote Target URI */
  soUtlDelSoAddress(&cLegHdrs->remoteTrgtURI);
  soUtlDelSoAddrSpec(&cLegHdrs->reqURI);
  soUtlDelSoAddrSpec(&cLegHdrs->origReqURI);

  /* so011.201: Add deletion for origRoute */
  /* Delete Route & Record Route */
  soUtlDelSoRoute(&cLegHdrs->route);

  soUtlDelSoRoute(&cLegHdrs->recordRoute);

  soUtlDelSoContact(&cLegHdrs->localTrgtURI);

  /* Remove Allow header */
  soUtlDelSoAllow(&cLegHdrs->peerAllow);

  RETVOID;

} /* soDlgDelStoredHdrs */





#ifdef SO_SESSTIMER
/*
*
*       Fun:   soDlgDelSessTmrCb
*
*       Desc:  Deletes Session Timer  Cb
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PRIVATE Void soDlgDelSessTmrCb
(
SoCLegCb   *cLeg       /* Call leg Cb */      
)
#else
PRIVATE Void soDlgDelSessTmrCb(cLeg)
SoCLegCb   *cLeg;      /* Call leg Cb */      
#endif
{
  TRC2(soDlgDelSessTmrCb);

  /* Stop Session Timer */
  soSchedTmr(cLeg, SO_TMR_SESSION_TIMER, TMR_STOP, NOTUSED); 


} /* soDlgDelSessTmrCb */

#endif /* SO_SESSTIMER */




#ifdef SO_RFC_3262
/*
*
*       Fun:   soDlgDelRelProvRspInfo
*
*       Desc:  Deletes Reliable Provisonal Response
*              info in the call leg
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PRIVATE Void soDlgDelRelProvRspCb
(
SoProvRspCb   *provRspCb   /* provisional Response Cb */
)
#else
PRIVATE Void soDlgDelRelProvRspCb(provRspCb)
SoProvRspCb   *provRspCb;   /* provisional Response Cb */
#endif
{

  TRC2(soDlgDelRelProvRspCb);

  /* Free the stored prov rsp Info */
  if (provRspCb->evnt != NULLP)
    soCmFreeEvent(provRspCb->evnt);

  provRspCb->cLeg = NULLP;

  soDlgDelRspInfo((Ptr)provRspCb, TRUE, &provRspCb->rspCb);

  RETVOID;
}




/*
*
*       Fun:   soDlgDelRelProvRspInfo
*
*       Desc:  Deletes Reliable Provisonal Response
*              info in the call leg
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soDlgDelRelProvRspInfo
(
SoCLegCb   *cLeg       /* Call leg Cb */      
)
#else
PUBLIC Void soDlgDelRelProvRspInfo(cLeg)
SoCLegCb   *cLeg;      /* Call leg Cb */      
#endif
{
  SoRelProvRspInfo *relProvRspInfo;
  CmLList          *curNode;         /* Current node in list  */
  SoProvRspCb      *tmpProvRspCb;    /* prov Rsp Cb */

  TRC2(soDlgDelRelProvRspInfo);

  relProvRspInfo = &cLeg->relProvRspInfo;

  if (relProvRspInfo->pend2xxEvnt != NULLP)
  {
    soCmFreeEvent(relProvRspInfo->pend2xxEvnt);

   /*---- so041.201: Reset the pointer value -----------------------*/
    relProvRspInfo->pend2xxEvnt = NULLP;
  }

  /* Clear all pending 1xx cbs */
  if (cmLListLen(&relProvRspInfo->pendProvRspLst) != 0)
  {     
    curNode = cmLListFirst(&relProvRspInfo->pendProvRspLst);
    while (curNode != NULLP)
    {      
      tmpProvRspCb    = (SoProvRspCb *)curNode->node;
      curNode  = curNode->next; 
      cmLListDelFrm(&relProvRspInfo->pendProvRspLst, 
                    &tmpProvRspCb->pendLstNode);
      soDlgDelRelProvRspCb(tmpProvRspCb);
      SOFREE(tmpProvRspCb, sizeof(SoProvRspCb));
    }
  }

  /* Delete provrsp cb in the list */
  while (cmHashListGetNext(&relProvRspInfo->provRspCbLst, 
                           (PTR) NULLP,
                            (PTR *) &tmpProvRspCb) == ROK)
  {
    cmHashListDelete (&relProvRspInfo->provRspCbLst,
                      (PTR) tmpProvRspCb);
    soDlgDelRelProvRspCb(tmpProvRspCb);
    SOFREE(tmpProvRspCb, sizeof(SoProvRspCb));
  }

  cmHashListDeinit (&relProvRspInfo->provRspCbLst);

} /* soDlgDelRelProvRspInfo */

#endif /* SO_RFC_3262 */




#ifdef SO_UA

/*
*
*       Fun:   soDlgDelRegInfo
*
*       Desc:  Deletes Reistrtion elated info from call leg
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PRIVATE Void soDlgDelRegInfo
(
SoCLegCb   *cLeg       /* Call leg Cb */      
)
#else
PRIVATE Void soDlgDelRegInfo(cLeg)
SoCLegCb   *cLeg;      /* Call leg Cb */      
#endif
{

  SoRegInfo        *regInfo;     /* Registration info cb */
  CmLList          *curNode;     /* Current node in list  */
  SoRegContactCb   *tmpContact;  /* Reg contact */

  TRC2(soDlgDelRegInfo);

  regInfo = &cLeg->regInfo;

  /* Clear all pending 1xx cbs */
  if (cmLListLen(&regInfo->pendContactLst) != 0)
  {     
    curNode = cmLListFirst(&regInfo->pendContactLst);
    while (curNode != NULLP)
    {      
      tmpContact = (SoRegContactCb *)curNode->node;
      curNode    = curNode->next; 
      SO_UA_DEL_CONTACT(cLeg, tmpContact);
    }
  }

  /* Delete provrsp cb in the list */
  while (cmHashListGetNext(&regInfo->contactLst, 
                           (PTR) NULLP,
                            (PTR *) &tmpContact) == ROK)
  {
    SO_UA_DEL_CONTACT(cLeg, tmpContact);
  }
  cmHashListDeinit (&regInfo->contactLst);

  if ((regInfo->regAddrKey != NULLP) && 
      (regInfo->regAddrKeyLen != 0))
  {
    SOFREE(regInfo->regAddrKey,regInfo->regAddrKeyLen);
  }

  RETVOID;
} /* soDlgDelRegInfo */

#endif /* SO_UA */



#ifdef SO_EVENT
/*
*
*       Fun:   soDlgDelSubscCb
*
*       Desc:  This function delete all subsc/refer node
*
*       Notes: 
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC Void soDlgDelSubscCb
(
SoCLegCb     *cLeg    /* Call Leg Cb */
)
#else
PUBLIC Void soDlgDelSubscCb(cLeg) 
SoCLegCb     *cLeg;   /* Call Leg Cb */
#endif
{
   SoSubscCb     *cb;
   CmLList       *curNode;
   SoSubNode     *subsc;
   
   TRC3(soDlgDelSubscCb);
  
   cb = &cLeg->subscCb;
   
   curNode = cmLListFirst(&cb->subCp);
   while (curNode != (CmLList *)NULLP)
   {
      subsc   = (SoSubNode *)cmLListNode(curNode);
      curNode  = curNode->next;
      cmLListDelFrm(&cb->subCp, &subsc->node);
      if(subsc->event != NULLP)
         soCmFreeEvent(subsc->event);
      soUtlDelTknStrOSXL(&subsc->subId);
      SOFREE(subsc, sizeof(SoSubNode));
   }
}

/*
*
*       Fun:   soDlgDelCurSubscNode
*
*       Desc:  This function delete current subsc/refer node
*
*       Notes: 
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC Void soDlgDelCurSubscNode
(
SoSubNode     *node
)
#else
PUBLIC Void soDlgDelCurSubscNode(node) 
SoSubNode     *node;
#endif
{
   SoCLegCb      *cLeg;
   
   TRC3(soDlgDelCurSubscNode);
  
   cLeg = node->cLeg;

  /*---- so026.201: Do not delete block, if it is referenced by others ----*/

   node->state = SO_SUBSC_FSM_TERMINATE_DONE;

   if (node->refCount != 0)
   {
      SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
      "\n[Dialog] Subcription Not Yet Deleted => Call (%ld) "
      "Dialog (%lx), Type (%d) State (%d) RefCount (%d)\n",
      cLeg->call->spConnId, cLeg->legId, node->type, node->state, node->refCount));

      RETVOID;
   }

  /*---- so025.201: Added Debug Prints ----*/
   SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
   "\n[Dialog] Subcription Deleted => Call (%ld) Dialog (%lx), Type (%d) \n",
   cLeg->call->spConnId, cLeg->legId, node->type));

   cmLListDelFrm(&cLeg->subscCb.subCp, &node->node);
   if(node->event != NULLP)
      soCmFreeEvent(node->event);
   soUtlDelTknStrOSXL(&node->subId);
   SOFREE(node, sizeof(SoSubNode));

   /*----- so025.201: Check if dialog needs to be deleted ----*/
   if (cLeg->subscCb.subCp.count == 0)
   {
      soDlgChkAndDelCLeg (cLeg);
   }
}

/*
*
*       Fun:   soDlgChkAndDelSubscNode
*
*       Desc:  Check subscribe node state and delete the terminated subsc nodes.
*
*       Notes:  
*
*
*       File:  so_dlg.c
*
*/
#ifdef ANSI
PUBLIC S16 soDlgChkAndDelSubscNode
(
SoCLegCb   *cLeg          /* Call Leg Cb */
)
#else
PUBLIC S16 soDlgChkAndDelSubscNode(cLeg)
SoCLegCb   *cLeg;         /* Call Leg Cb */
#endif                              
{
  SoSubNode *subsc;
  CmLList   *lstEnt;

  TRC3(soDlgChkAndDelSubscNode);
  
  if(cLeg->subscCb.subCp.count)
  {
     lstEnt = cmLListFirst(&cLeg->subscCb.subCp);
     while(lstEnt)
     {
        subsc = (SoSubNode *)cmLListNode(lstEnt);

       /* so026.201: Delete Subscription Control Block, if its     *
        *                                                          *
        *    (1st). Its state is termiante done, AND               *
        *    (2nd). It has no transaction references.              *
        *                                                          */
        lstEnt = lstEnt->next;
        if ((subsc->state == SO_SUBSC_FSM_TERMINATE_DONE) &&
            (subsc->refCount == 0))
        {
            SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
            "\n[Dialog] Subcription Deleted => Call (%ld) Dialog (%lx), Type (%d) \n",
            cLeg->call->spConnId, cLeg->legId, subsc->type));
           
            cmLListDelFrm(&cLeg->subscCb.subCp, &subsc->node);

            if(subsc->event != NULLP)
               soCmFreeEvent(subsc->event);

            soUtlDelTknStrOSXL(&subsc->subId);

            SOFREE(subsc, sizeof(SoSubNode));
        }
     }
     if(cLeg->subscCb.subCp.count)
        RETVALUE(RFAILED);
  }
  RETVALUE(ROK);
}


#endif /* SO_EVENT */


/*
*
*       Fun:   soDlgUpdRecordRoute
*
*       Desc:  This function copies a record-route header from one message
*              to another.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PRIVATE S16 soDlgUpdRecordRoute
(
SoCLegCb   *cLeg,    /* Cleg Cb */
SoEvnt     *evnt     /* Event  */
)
#else
PRIVATE S16 soDlgUpdRecordRoute(cLeg, evnt)
SoCLegCb   *cLeg;    /* Cleg Cb */
SoEvnt     *evnt;    /* Event  */
#endif
{
   SoRoute           *recordRoute;     /* Record route structure in message   */
   SoHeaderSeq       *hdrSeq;          /* Header sequence to search           */
   SoHeader          *hdr;             /* Header to check                     */
   SoRouteSeq        *rrItem;          /* Record route structure in message   */
   SoRoute           *storeRRoute;     /* Local pointer to dst record route   */
   U16               rrComp;           /* Number of record-routes in message  */
   U16               i;                /* Index of headers                    */
   U16               j;                /* Index of via header                 */

   U16               totalRRoute;      /* Total Vias to be copied             */
   U16               numHdr;           /* Total Headers                       */
   S16               routeCnt;         /* Via Cntr                            */

   TRC2(soDlgUpdRecordRoute);

   /* Set local storeRRoute pointer */
   storeRRoute = &cLeg->storedHdrs.recordRoute;

   /* If Record-Route already here, do nothing */
   if (SO_GET_NUM_COMP(&storeRRoute->numComp) != 0)
      RETVALUE(ROK);

   if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
      hdrSeq = &evnt->t.request.request;
   else
      hdrSeq = &evnt->t.response.response;

   /*------ STEP 1 : Find total Record-Route in the message -------*/
   totalRRoute = 0;
   numHdr = SO_GET_NUM_COMP(&hdrSeq->numComp);
   for (i = 0; i < numHdr; i++)  
   {
      hdr = hdrSeq->header[i];
      if (SO_CMP_TKN_LIT(&hdr->headerType, SO_HEADER_GEN_RECORDROUTE) == TRUE)
      {
         recordRoute = &hdr->t.recordRoute;
         totalRRoute += SO_GET_NUM_COMP(&recordRoute->numComp);
      }
   }

   if (totalRRoute == 0)
      RETVALUE(ROK);

   /*------ STEP 2 : Allocate memory for array of pointer -------*/
   if (soUtlCpyGetMem((Ptr*)&(storeRRoute->route), (U16)(sizeof(Ptr)*(totalRRoute)), NULLP) != ROK)
      goto soUtlCpyErr0;

   /*------ STEP 3 : Copy all Record-Route items -------*/
   routeCnt = 0;
   for (i = 0; i < numHdr; i++)
   {
      hdr = hdrSeq->header[i];
      /* Check for Via header */
      if (SO_CMP_TKN_LIT(&hdr->headerType, SO_HEADER_GEN_RECORDROUTE) == TRUE)
      {
         recordRoute = &hdr->t.recordRoute;
         rrComp = SO_GET_NUM_COMP(&recordRoute->numComp);

         for (j = 0; j < rrComp; j++)
         {
            rrItem = recordRoute->route[j];

            if (soUtlCpyGetMem((Ptr*)&(storeRRoute->route[routeCnt]), sizeof(SoRouteSeq), NULLP) != ROK)
               goto soUtlCpyErr1;
            if (soUtlCpySoRouteSeq(storeRRoute->route[routeCnt], rrItem, NULLP) != ROK)
               goto soUtlCpyErr2;

            routeCnt++;
         }
      }
   }

   /* Everything passed, set numComp */
   storeRRoute->numComp.pres = PRSNT_NODEF;
   storeRRoute->numComp.val = totalRRoute;

   RETVALUE(ROK);

soUtlCpyErr2 :
   SOFREE(storeRRoute->route[routeCnt], sizeof(SoRouteSeq));

soUtlCpyErr1 :
   for (routeCnt = routeCnt-1;routeCnt >= 0; routeCnt--)
   {
      soUtlDelSoRouteSeq(storeRRoute->route[routeCnt]);
      SOFREE(storeRRoute->route[routeCnt], sizeof(SoRouteSeq));
   }
   SOFREE(storeRRoute->route, sizeof(Ptr)*(totalRRoute));

soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /* soDlgUpdRecordRoute */


/*
*
*       Fun:   soDlgStoreIncRoute
*
*       Desc:  Stores route information into call leg
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgStoreIncRoute
(
SoCLegCb   *cLeg,     /* Call Leg */
SoEvnt     *evnt      /* Event Cb */ 
)
#else
PRIVATE S16 soDlgStoreIncRoute(cLeg, evnt)
SoCLegCb   *cLeg;     /* Call Leg */
SoEvnt     *evnt;     /* Event Cb */ 
#endif
{
   SoHeaderSeq       *hdrSeq;          /* Header sequence to search           */
   SoHeader          *hdr;             /* Header to check                     */
   SoRoute           *recordRoute;     /* Record route structure in message   */
   SoRouteSeq        *rrItem;          /* Record route item in message        */
   S16               i;                /* Index of headers                    */
   S16               j;                /* Index of via header                 */
   S16               hdrStart;         /* Start value for header counter      */
   S16               hdrEnd;           /* End value for header counter        */
   S16               seqStart;         /* Start value for seq counter         */
   S16               seqEnd;           /* End value for seq counter           */
   S16               dir;              /* Increment/decrement counter         */
   S16               ret;              /* value returned by function calls    */
   Bool              requestMsg;       /* Incoming Request/ response          */
   SoRoute           *storedRoute;     /* Route stored in the call Leg */

   U16               totalRoute;       /* Total Routes to be copied          */
   U16               numHdr;           /* Total Headers                      */
   S16               routeCnt;         /* Route Cntr                         */

   TRC2(soDlgStoreIncRoute);

   requestMsg = FALSE;

   if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
   { 
      hdrSeq = &evnt->t.request.request;
      requestMsg = TRUE;
      /* unpack record route in same order */
      hdrStart = 0;
      hdrEnd   = SO_GET_NUM_COMP(&hdrSeq->numComp);
      dir      = 1;
   }
   else
   {
      /* Unpack header in Reverse Order */
      hdrSeq = &evnt->t.response.response;
      hdrStart = SO_GET_NUM_COMP(&hdrSeq->numComp) - 1;
      hdrEnd   = -1;
      dir      = -1;
   }

   /*------ STEP 1 : Find total RecordRoute in the message -------*/
   /* Find the record route header as Route in call leg */
   totalRoute = 0;
   numHdr = SO_GET_NUM_COMP(&hdrSeq->numComp);
   for (i = 0; i < numHdr; i ++)
   {
      hdr = hdrSeq->header[i];
      if (SO_CMP_TKN_LIT(&hdr->headerType, SO_HEADER_GEN_RECORDROUTE) == TRUE)
      {
         recordRoute = &hdr->t.recordRoute;
         totalRoute += SO_GET_NUM_COMP(&recordRoute->numComp);
      }
   }

   if (totalRoute == 0)
   /* so013.201: If no rec-route in inc rsp, del stored route */
   {
      (Void)soUtlDelSoRoute(&cLeg->storedHdrs.route);
      RETVALUE(ROK);
   }

   /* Resize the Route Array stored in the call leg */
   storedRoute = &cLeg->storedHdrs.route;

   /* Delete any existing route elements */
   ret = soUtlDelSoRoute(storedRoute);

   if (ret != ROK)
      RETVALUE(RFAILED);

   /*------ STEP 2 : Allocate memory for array of pointer -------*/
   if (soUtlCpyGetMem((Ptr*)&(storedRoute->route), (U16)(sizeof(Ptr)*(totalRoute)), NULLP) != ROK)
      goto soUtlCpyErr0;

   /*------ STEP 3 : Copy all RouteSeqs -------*/
   /* depending on direction, the route header will be copied, either
      in normal / reverse order */

   routeCnt = 0;
   for (i = hdrStart; i != hdrEnd; i += dir)
   {
      hdr = hdrSeq->header[i];
      if (SO_CMP_TKN_LIT(&hdr->headerType, SO_HEADER_GEN_RECORDROUTE) == TRUE)
      {
         /* Init counters */
         seqStart = 0;

         recordRoute = &hdr->t.recordRoute;
         seqEnd = SO_GET_NUM_COMP(&recordRoute->numComp);

         /* If it is a response, copy backwards */
         if (requestMsg == FALSE)
         {
            seqStart = seqEnd - 1;
            seqEnd   = -1;
         }

         /* Copy Contents of Record Route into call leg */
         for (j = seqStart; j != seqEnd; j += dir)
         {
            rrItem = recordRoute->route[j];

            if (soUtlCpyGetMem((Ptr*)&(storedRoute->route[routeCnt]), sizeof(SoRouteSeq), NULLP) != ROK) 
               goto soUtlCpyErr1;
            if (soUtlCpySoRouteSeq(storedRoute->route[routeCnt], rrItem, NULLP) != ROK) 
               goto soUtlCpyErr2;

            routeCnt++;
         }
      } 
   } 

   /* Everything passed, set numComp */
   storedRoute->numComp.pres = PRSNT_NODEF;
   storedRoute->numComp.val = totalRoute;

   /* For responses we will need to store record route also in the
      call leg */
   /* so001.201: Save the record route for request message at UAS
                 This value will be updated in response message */
   if (requestMsg == TRUE)
      ret = soDlgUpdRecordRoute(cLeg, evnt);

   RETVALUE(ret);

soUtlCpyErr2 :
   SOFREE(storedRoute->route[routeCnt], sizeof(SoRouteSeq));

soUtlCpyErr1 :
   for (routeCnt = routeCnt-1;routeCnt >= 0; routeCnt--)
   {
      soUtlDelSoRouteSeq(storedRoute->route[routeCnt]);
      SOFREE(storedRoute->route[routeCnt], sizeof(SoRouteSeq));
   }
   SOFREE(storedRoute->route, sizeof(Ptr)*(totalRoute));

soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /* soDlgStoreIncRoute */


/* so012.201: Store the route sequence for outgoing calls */
/*
*
*       Fun:   soDlgStoreOutRoute
*
*       Desc:  Stores route information into outgoing call
*              leg
*
*       Notes:  
*
*
*       File:  so_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgStoreOutRoute
(
SoCLegCb   *cLeg,     /* Call Leg */
SoEvnt     *evnt      /* Event Cb */ 
)
#else
PRIVATE S16 soDlgStoreOutRoute(cLeg, evnt)
SoCLegCb   *cLeg;     /* Call Leg */
SoEvnt     *evnt;     /* Event Cb */ 
#endif
{
   SoHeaderSeq       *hdrSeq;          /* Header sequence to search           */
   SoHeader          *hdr;             /* Header to check                     */
   SoRoute           *route;           /* Route structure in message   */
   SoRouteSeq        *rItem;           /* Route item in message        */
   S16               i;                /* Index of headers                    */
   S16               j;                /* Index of via header                 */
   S16               hdrStart;         /* Start value for header counter      */
   S16               hdrEnd;           /* End value for header counter        */
   S16               seqStart;         /* Start value for seq counter         */
   S16               seqEnd;           /* End value for seq counter           */
   S16               dir;              /* Increment/decrement counter         */
   S16               ret;              /* value returned by function calls    */
   SoRoute           *storedRoute;     /* Route stored in the call Leg */

   U16               totalRoute;       /* Total Routes to be copied          */
   U16               numHdr;           /* Total Headers                      */
   S16               routeCnt;         /* Route Cntr                         */

   TRC2(soDlgStoreOutRoute);


   if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
   { 
      hdrSeq = &evnt->t.request.request;
      /* unpack route in same order */
      hdrStart = 0;
      hdrEnd   = SO_GET_NUM_COMP(&hdrSeq->numComp);
      dir      = 1;
   }
   else
   {
      /* This function is only for outgoing requests */
      RETVALUE(RFAILED);
   }

   /*------ STEP 1 : Find total Route in the event ---------*/
   /* Find the route headers in call leg */
   totalRoute = 0;
   numHdr = SO_GET_NUM_COMP(&hdrSeq->numComp);
   for (i = 0; i < numHdr; i ++)
   {
      hdr = hdrSeq->header[i];
      if (SO_CMP_TKN_LIT(&hdr->headerType, SO_HEADER_REQ_ROUTE) == TRUE)
      {
         route = &hdr->t.route;
         totalRoute += SO_GET_NUM_COMP(&route->numComp);
      }
   }

   if (totalRoute == 0)
      RETVALUE(ROK);

   /* Resize the Route Array stored in the call leg */
   storedRoute = &cLeg->storedHdrs.route;

   /* Delete any existing route elements */
   ret = soUtlDelSoRoute(storedRoute);

   if (ret != ROK)
      RETVALUE(RFAILED);

   /*------ STEP 2 : Allocate memory for array of pointer -------*/
   if (soUtlCpyGetMem((Ptr*)&(storedRoute->route), (U16)(sizeof(Ptr)*(totalRoute)), NULLP) != ROK)
      goto soUtlCpyErr0;

   /*------ STEP 3 : Copy all RouteSeqs -------*/

   routeCnt = 0;
   for (i = hdrStart; i != hdrEnd; i += dir)
   {
      hdr = hdrSeq->header[i];
      if (SO_CMP_TKN_LIT(&hdr->headerType, SO_HEADER_REQ_ROUTE) == TRUE)
      {
         /* Init counters */
         seqStart = 0;

         route = &hdr->t.route;
         seqEnd = SO_GET_NUM_COMP(&route->numComp);

         /* Copy Contents of Route into call leg */
         for (j = seqStart; j != seqEnd; j += dir)
         {
            rItem = route->route[j];

            if (soUtlCpyGetMem((Ptr*)&(storedRoute->route[routeCnt]), sizeof(SoRouteSeq), NULLP) != ROK) 
               goto soUtlCpyErr1;
            if (soUtlCpySoRouteSeq(storedRoute->route[routeCnt], rItem, NULLP) != ROK) 
               goto soUtlCpyErr2;

            routeCnt++;
         }
      } 
   } 

   /* Everything passed, set numComp */
   storedRoute->numComp.pres = PRSNT_NODEF;
   storedRoute->numComp.val = totalRoute;

   RETVALUE(ROK);
soUtlCpyErr2 :
   SOFREE(storedRoute->route[routeCnt], sizeof(SoRouteSeq));

soUtlCpyErr1 :
   for (routeCnt = routeCnt-1;routeCnt >= 0; routeCnt--)
   {
      soUtlDelSoRouteSeq(storedRoute->route[routeCnt]);
      SOFREE(storedRoute->route[routeCnt], sizeof(SoRouteSeq));
   }
   SOFREE(storedRoute->route, sizeof(Ptr)*(totalRoute));

soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /* soDlgStoreOutRoute */

/*
*
*       Fun:   soDlgUpdReqURI
*
*       Desc:  Updates the request URI to be stored in the call leg.
*              The Request URI is updated based on the routing procedures
*              described in RFC 3261. 
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgUpdReqURI
(
SoCLegCb   *cLeg,     /* Call Leg */
SoEvnt     *evnt,     /* Event Cb */ 
U8         direction  /* Direction */
)
#else
PRIVATE S16 soDlgUpdReqURI(cLeg, evnt, direction)
SoCLegCb   *cLeg;     /* Call Leg */
SoEvnt     *evnt;     /* Event Cb */ 
U8         direction; /* Direction */
#endif
{

  SoCLegHdrs    *cLegHdrs;   /* Headers stored in the call leg */
  S16           ret;         /* Return Values */
  SoRoute       *route;      /* Route informaion */
  SoAddrSpec    *addrSpec;   /* Address */
  U16           numComp;     /* Number of comp */
  U16           i;           /* Counter */

  TRC2(soDlgUpdReqURI);


  cLegHdrs = &cLeg->storedHdrs;

  /* For an outgoing message/ call leg, if the user has  provided
     a request URI then use remote target URI instead. */
  if ((direction == SO_USER) && 
      (evnt->t.request.requestLine.addrSpec.addrSpecType.pres != NOTPRSNT))
  {
    addrSpec = &evnt->t.request.requestLine.addrSpec;
  }
  else
  {
    SO_ADDRSPEC_FROM_ADDRCH(addrSpec, &cLegHdrs->remoteTrgtURI.addrCh);
  }

  /* Delete the existing ReURI before updating the cleg with the new one */
  soUtlDelSoAddrSpec(&cLegHdrs->reqURI);

  if (SO_GET_NUM_COMP(&cLegHdrs->route.numComp) <= 0)
  {
    /* If there is no route, update requestURI with remote targetURI */
    ret = soUtlCpySoAddrSpec(&cLegHdrs->reqURI, addrSpec, NULLP);
    if (ret != ROK)
      RETVALUE(RFAILED);

    cLegHdrs->nextHopAddr = SO_NEXTHOP_REQURI;
  }
  else
  {
    route = &cLegHdrs->route;
    ret = soUtlFindLrInRoute(route);
    if (ret == ROK)
    {
      ret = soUtlCpySoAddrSpec(&cLegHdrs->reqURI, addrSpec, NULLP);
      if (ret != ROK)
        RETVALUE(RFAILED);

      cLegHdrs->nextHopAddr = SO_NEXTHOP_ROUTE;
    }
    else
    {
      route = &cLegHdrs->route;
      
      /* Copy topmost route into requestURI */
      if (soUtlCpySoAddrSpec(&cLegHdrs->reqURI,
                             &route->route[0]->nameAddr.addrSpec,
                             NULLP)!=ROK )
        RETVALUE(RFAILED);

      /* Delete the top most RouteSeq */
      soUtlDelSoRouteSeq(route->route[0]);
      SOFREE(route->route[0], sizeof(SoRouteSeq));
      
      numComp = SO_GET_NUM_COMP(&route->numComp);
      for (i = 0; i < numComp - 1; i++)
      {
        route->route[i] = route->route[i + 1];
      }

      /* Copy the remote target URI to the end of the list */
      if (soUtlCpyGetMem((Ptr*)&(route->route[numComp-1]), sizeof(SoRouteSeq), NULLP) != ROK)
        RETVALUE(RFAILED);


      if (soUtlCpySoAddrSpec(&route->route[numComp-1]->nameAddr.addrSpec,
                          addrSpec,NULLP)!=ROK )
        RETVALUE(RFAILED);

      route->route[numComp-1]->pres.pres = PRSNT_NODEF;
      route->route[numComp-1]->nameAddr.pres.pres = PRSNT_NODEF;
      cLegHdrs->nextHopAddr = SO_NEXTHOP_REQURI;
    }
  }

  /* Strip unwanted parameters form the Request URI */
  (Void) soUtlStripUriParams(&cLegHdrs->reqURI);

  RETVALUE(ROK);
} 


/*
*
*       Fun:   soDlgSendResponse
*
*       Desc:  Send an error response to the remote
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/

/* so031.201: Added transCb argument*/
#ifdef ANSI
PUBLIC S16 soDlgSendResponse
(
SoCLegCb   *cLeg,         /* Call Leg */
SoTransCb  *transCb,      /* Transaction Cb */
SoEvnt     *evnt,         /* Event Cb */
U16        statusCode,    /* Response code to put into messasge  */
U16        extStatusCode  /* Extended status                     */
)
#else
PUBLIC S16 soDlgSendResponse(cLeg, evnt, statusCode, extStatusCode)
SoCLegCb   *cLeg;         /* Call Leg */
SoTransCb  *transCb,      /* Transaction Cb */
SoEvnt     *evnt;         /* Event Cb */
U16        statusCode;    /* Response code to put into messasge  */
U16        extStatusCode; /* Extended status                     */
#endif
{

  S16      ret;           /* Return Value */
  SoEvnt   *rspEvnt;      /* Response Event */

  TRC2(soDlgSendResponse);

  SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
         "\n[Dialog] Sending a %d Response to Peer: Call: %ld, CallLeg: %lx",
          statusCode, cLeg->call->spConnId, cLeg->legId));

  ret = soUtlBuildRspEvnt(cLeg->call->ent, &rspEvnt, evnt, 
 /* so011.201: Passing parameter event type */
                          SOT_ET_INVALID,
                          statusCode, extStatusCode);
  if (ret != ROK)
  {
    SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
         "\n[Dialog] Cannot Build Response Event"));
    RETVALUE(RFAILED);
  }
  
  ret = soDlgUaOutRsp(cLeg, rspEvnt, transCb);
  if (ret != ROK)
  {
    SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
         "\n[Dialog] Cannot Send Outgoing Response"));
    (Void) soCmFreeEvent (rspEvnt);
    RETVALUE(RFAILED);
  }

  /* so010.201 : Delete stored rsp, we dont need it */
  if (cLeg->sentRsp != NULLP)
  {
     SPutMsg (cLeg->sentRsp);
     cLeg->sentRsp = NULLP;
  }

  RETVALUE(ROK);
} 






/*
*
*       Fun:   soDlgSendRspNoCLeg
*
*       Desc:  Send an error response to the remote when no call or
*              call leg is available.
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soDlgSendRspNoCleg
(
SoTransCb  *transCb,      /* Transaction cb */
SoEvnt     *evnt,         /* Event Cb */
U16        statusCode,    /* Response code to put into messasge  */
U16        extStatusCode  /* Extended status                     */
)
#else
PUBLIC S16 soDlgSendRspNoCleg(transCb, evnt, statusCode, extStatusCode)
SoTransCb  *transCb;      /* Transaction cb */
SoEvnt     *evnt;         /* Event Cb */
U16        statusCode;    /* Response code to put into messasge  */
U16        extStatusCode; /* Extended status                     */
#endif
{

  S16      ret;           /* Return Value */
  SoEvnt   *rspEvnt;      /* Response Event */
  Buffer    *mBuf;        /* Buffer */
  U8       responseClass; /* Response class */
  
  /* so023.201:- To generate "To" tag without CLEG*/
  SoAddress    *to;        /* To Address */

  TRC2(soDlgSendRspNoCleg);

  SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
         "\n[Dialog] Sending a %d Response to Peer."
         " No Call/ Call Leg Available",
          statusCode));

  /* so023.201:- To generate "To" tag without CLEG*/
  /* Find "to" header in message */
  if ((ret = soCmFindHdrChoice(evnt, (U8 **) &to, SO_HEADER_GEN_TO)) != ROK)
  {
      RETVALUE(RFAILED);
  }

  /* Generate Local Tag without cLeg*/
  /* Passing 2nd arg cLeg = NULLP*/
  ret = soCmGenLocalTag(evnt, NULLP, to);
  if (ret != ROK)
      RETVALUE(RFAILED);

  ret = soUtlBuildErrRsp(&rspEvnt, evnt, statusCode, extStatusCode);
  if (ret != ROK)
  {
    SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
         "\n[Dialog] Cannot Build Response Event"));
    RETVALUE(RFAILED);
  }

  responseClass = (rspEvnt->t.response.statusLine.statusCode.val)/100;

  /* Pass message to transaction layer for further processing */
  ret = soTxnUaOutRsp(transCb, rspEvnt,
                      (responseClass), (SoUserCtxt *)NULLP, 
                      (PTR)NULLP, &mBuf);
  if (ret != ROK)
  {
    SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
         "\n[Dialog] Cannot Send Outgoing Response"));
    (Void) soCmFreeEvent (rspEvnt);
    RETVALUE(RFAILED);
  }

  if (mBuf != NULLP)
    SPutMsg(mBuf);

  RETVALUE(ROK);
} 






/*
*
*       Fun:   soDlgInitCLeg
*
*       Desc:  This function creates a new CLeg and initializes the
*              structure.
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PRIVATE SoCLegCb *soDlgInitCLeg
(
SoCallCb   *callCb,    /* Call Cb */
SoEvnt     *evnt,      /* Event Cb */      
U8         direction   /* Direction - From User/ From Remote */
)
#else
PRIVATE SoCLegCb *soDlgInitCLeg(callCb, evnt, direction)
SoCallCb   *callCb;    /* Call Cb */
SoEvnt     *evnt;      /* Event Cb */      
U8         direction;  /* Direction - From User/ From Remote */
#endif
{
  SoCLegCb  *cLeg;     /* Call Leg Cb */
  U16       numHlBins; /* Number of hash list bins */
  S16       ret;       /* Return value */
  Bool      initRelProvRsp; /* rel prov rsp ;list initialized */
  Bool      initRegInfo;    /* Reg Info init done */

  TRC2(soDlgInitCLeg);

  initRelProvRsp = FALSE;
  initRegInfo    = FALSE;

  SOALLOC(&cLeg, sizeof(SoCLegCb));

  if (cLeg == NULLP)
    RETVALUE(NULLP);

  /* Allocate & Store Call Leg Id */
  if (direction == SO_REMOTE)
  {
    /* so009.201 : Added user conn id */
    cLeg->userConnId = SO_CONNID_NOTUSED;
    cLeg->legId = ++callCb->nextLegNum;
    evnt->callLegId = cLeg->legId;
    numHlBins = callCb->ssapCb->cfg.numCLegHlBins;
    cLeg->role = SO_SERVER;
    /* Fill Accounting related info*/
#ifdef LSO_ACNT
    cLeg->accntCb.accOrigin = LSO_RECEIVER;
#endif /* LSO_ACNT */
    
    /* Save the received request URI */
     ret = soUtlCpySoAddrSpec (&cLeg->storedHdrs.origReqURI,
                               &evnt->t.request.requestLine.addrSpec,
                               NULLP);
     if (ret != ROK)
     {
        SOFREE(cLeg, sizeof(SoCLegCb));
        RETVALUE(NULLP);
     }
  }
  else
  {
    if (evnt->callLegId == 0)
      evnt->callLegId = ++callCb->nextLegNum;

    /* so009.201 : Added user conn id */
    cLeg->userConnId = callCb->suConnId;

    cLeg->legId = evnt->callLegId;
    cLeg->role = SO_CLIENT;
    numHlBins = callCb->ssapCb->cfg.numCLegHlBins;
    /* Fill Accounting related info*/
#ifdef LSO_ACNT
   cLeg->accntCb.accOrigin = LSO_ORIGINATOR;
#endif /* LSO_ACNT */
  }

  cLeg->clegState = SO_CLEG_STATE_NONE;
  cLeg->call  = callCb;

  /* Add Call Leg Entry into the list in call Cb */
  /* so011.201: Support to handle REGISTER message at UAC. The 
     feature has been added under the flag SO_XX_UA_PRC_REGISTER. */
#ifdef SO_XX_UA_PRC_REGISTER
  if ((callCb->sessCreatedBy != SOT_ET_REGISTER) ||
      (direction == SO_REMOTE))
#else
  if (callCb->sessCreatedBy != SOT_ET_REGISTER)
#endif
  {
    cmLListNode(&cLeg->llNode) = (PTR) cLeg;
    cmLListAdd2Tail(&callCb->cLegLst, &cLeg->llNode);
  }

  ret = ROK;

  /* Initialize Rspcontrol Block */
  soCmInitTimer(&cLeg->rspCb.soRspRetxTmr);
  soCmInitTimer(&cLeg->rspCb.soRspExpTmr);

#ifdef SO_SESSTIMER
  soCmInitTimer(&cLeg->sessTmrCb.sessExpTmr);
#endif /* SO_SESSTIMER */

#ifdef SO_EVENT
  /* Initialize Subscription cb */
  if (ret == ROK)
  {
    cmMemset((U8 *)&cLeg->subscCb, 0, sizeof(SoSubscCb));
    cmLListInit(&cLeg->subscCb.subCp);
  }
#endif /* SO_EVENT */

#ifdef SO_RFC_3262
  /* Initialize reliable provisional response cb */
  if (ret == ROK)
  {
    cmLListInit (&cLeg->relProvRspInfo.pendProvRspLst);
    /* initialize prov rsp cb  hash list */
    ret = cmHashListInit(&cLeg->relProvRspInfo.provRspCbLst,
                         numHlBins, 
                         (U16) SO_OFFSET_OF(SoProvRspCb, hlEnt),
                         FALSE,
                         CM_HASH_KEYTYPE_U32MOD,
                         soCb.init.region, soCb.init.pool);
    if(ret == ROK)
      initRelProvRsp = TRUE;
  }
#endif /* SO_RFC_3262 */


#ifdef SO_UA
  /* Initialize reliable provisional response cb */
  if (ret == ROK)
  {
    cmLListInit (&cLeg->regInfo.pendContactLst);
    /* initialize contact  hash list */
    ret = cmHashListInit(&cLeg->regInfo.contactLst,
                         numHlBins, 
                         (U16) SO_OFFSET_OF(SoRegContactCb, hlCLegCb),
                         FALSE,
                         CM_HASH_KEYTYPE_STR,
                         soCb.init.region, soCb.init.pool);
    
    if (ret == ROK)
      initRegInfo = TRUE;
  }
#endif /* SO_UA */

  if (ret == ROK)
  {
    /* initialize CallId hash list */
    ret = cmHashListInit(&cLeg->tranCbLst,
                         numHlBins, 
                         (U16) SO_OFFSET_OF(SoTransCb, cLegHlEnt),
                         FALSE,
                         CM_HASH_KEYTYPE_U32MOD,
                         soCb.init.region, soCb.init.pool);   
  }

  if (ret != ROK)
  {
#ifdef SO_RFC_3262
    if (initRelProvRsp == TRUE)
      cmHashListDeinit(&cLeg->relProvRspInfo.provRspCbLst);
#endif

#ifdef SO_UA
    if (initRegInfo == TRUE)
      cmHashListDeinit(&cLeg->regInfo.contactLst);
#endif /* SO_UA */
   
   /*--- so018.201: Delete cLeg from callCb list ---*/
#ifdef SO_XX_UA_PRC_REGISTER
    if ((callCb->sessCreatedBy != SOT_ET_REGISTER) ||
        (direction == SO_REMOTE))
#else
    if (callCb->sessCreatedBy != SOT_ET_REGISTER)
#endif
    {
       cmLListDelFrm (&callCb->cLegLst, &cLeg->llNode);
    }

    SOFREE(cLeg, sizeof(SoCLegCb));
    RETVALUE(NULLP);
  }

  /* Initialize recursion list */
  cmLListInit(&cLeg->recurseCb.recContactLst);
  
  /* Initialize Expires Timer */
  soCmInitTimer(&cLeg->expiresTmr);

  /* Initialize Cancel  Timer */
  soCmInitTimer(&cLeg->cancelTmrCb.cancelTmr);

  
  cLeg->pendingCancel = NULLP;
  cLeg->sentRsp = NULLP;
  cLeg->sentInvite = NULLP;

  RETVALUE(cLeg);
} /* soDlgCreateCleg */





/*
*       Fun:   soDlgUpdRemoteTrgtURI
*
*       Desc:  This function updates the Remote Target URI
*              information.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC S16 soDlgUpdRemoteTrgtURI
(
SoCLegCb   *cLeg,   /* CLeg Cb */
SoEvnt     *evnt    /* Event Cb */
)
#else
PUBLIC S16 soDlgUpdRemoteTrgtURI(cLeg, evnt)
SoCLegCb   *cLeg;   /* CLeg Cb */
SoEvnt     *evnt;   /* Event Cb */
#endif
{
  S16         ret;
  SoContact   *contact;       /* Ptr to contact   */
#ifdef SO_XX_UA_PRC_REGISTER  
  SoAddress   *from;   /* From Address */
#endif /* SO_XX_UA_PRC_REGISTER */

  TRC3(soDlgUpdRemoteTrgtURI);

/* so024.201 : The TrgtURI should be made from from tag in this case */
#ifdef SO_XX_UA_PRC_REGISTER  

   if(evnt->eventType.val == SOT_ET_REGISTER)
   {

      /* Find "from" header in message */
      if ((ret = soCmFindHdrChoice(evnt, (U8 **) &from, SO_HEADER_GEN_FROM)) 
         != ROK)
      {
       RETVALUE(ROK);
      }

      soUtlDelSoAddress(&cLeg->storedHdrs.remoteTrgtURI);

      /* Initially copy remote trgt uri from the to header */
      ret = soUtlCpySoAddress(&cLeg->storedHdrs.remoteTrgtURI, from, NULLP);
      RETVALUE(ROK);
   }

#endif /* SO_XX_UA_PRC_REGISTER */


  /* Locate the contact header */
  ret = soCmFindHdrChoice(evnt, (U8 **) &contact,
                          SO_HEADER_GEN_CONTACT);
  if (ret != ROK)
    RETVALUE(ROK);

  if (SO_CMP_TKN_LIT(&contact->contactDescType, SO_CONTACTDESC_CONTACTITEMS) != TRUE)
    RETVALUE(RFAILED);

  if (SO_GET_NUM_COMP(&contact->contactItems.numComp) == 0)
    RETVALUE(RFAILED);


  /* Copy nameAddr */
  /* Delete the older value if any exitsts and overwrite with new
     remotetrgtURI */
  soUtlDelSoAddrCh(&cLeg->storedHdrs.remoteTrgtURI.addrCh);

  cmMemset ((U8 *)&cLeg->storedHdrs.remoteTrgtURI.addrCh, 0, sizeof(SoAddrCh));

  if ( soUtlCpySoAddrCh(&cLeg->storedHdrs.remoteTrgtURI.addrCh,
          &contact->contactItems.contactItem[0]->contactAddrChoice,     
          NULLP)!=ROK )
    
    RETVALUE(RFAILED);

  cLeg->storedHdrs.remoteTrgtURI.pres.pres = PRSNT_NODEF;

  RETVALUE(ROK);
} /* soDlgUpdRemoteTrgtURI */





/*
*
*       Fun:   soDlgUpdRoute
*
*       Desc:  This function updates the route information
*              in the call leg.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC S16 soDlgUpdRoute
(
SoCLegCb   *cLeg,      /* Call leg  Cb */
SoEvnt     *evnt,      /* Event Cb */      
U8         direction   /* Direction - From User/ From Remote */
)
#else
PUBLIC S16 soDlgUpdRoute(cLeg, evnt, direction)
SoCLegCb   *cLeg;      /* Call leg  Cb */
SoEvnt     *evnt;      /* Event Cb */      
U8         direction;  /* Direction - From User/ From Remote */
#endif
{
  S16     ret;

  TRC3(soDlgUpdRoute);

  /* If it is an outgoing message store route from
     event to cLeg */
  if (direction == SO_USER)
  {
     /* so012.201: Store all route sequences */
    ret = soDlgStoreOutRoute(cLeg, evnt);
    if (ret == ROK)
    {
      /* If message doesnot have a Route header, see if we need to add 
         Default Proxy into Route header This will be done only if
         the stack is configured to send al messages thru the default proxy */
      if (cLeg->storedHdrs.route.numComp.val == 0)
      {
         if (cLeg->call->ent->reCfg.e.uaReCfg.dfltPrxCfg.useDfltPrx == TRUE)
         {
            if (SO_GET_NUM_COMP(&cLeg->call->ent->s.ua.dfltRouteSet.numComp) > 0) 
            {
               ret = soUtlCpySoRoute(&cLeg->storedHdrs.route, 
                                     &cLeg->call->ent->s.ua.dfltRouteSet,
                                     NULLP);
            } 
         }
      }
    }
  }
  else
  {
    /* For incoming messages, store Route in call leg based on
       the record route received in the message */
    ret =  soDlgStoreIncRoute(cLeg, evnt);      
  }

  if (ret == ROK)
  {
    ret = soDlgUpdReqURI(cLeg, evnt, direction);
  }

  RETVALUE(ret);
}




/*
*
*       Fun:   soDlgUpdOutClegInfo
*
*       Desc:  This function initializes information
*              for an outgoing call leg.
*
*       Notes:  
*
*
*       File:  po_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgUpdOutClegInfo
(
SoCLegCb   *cLeg,      /* CLeg Cb */
SoEvnt     *evnt,      /* Event Cb */
SoAddress  *to,        /* To Address */
SoAddress  *from,      /* From Address */
U32        cSeqVal,    /* CSeq  */
U8         direction   /* Direction : SO_USER/ SO_INTERNAL */
)
#else
PRIVATE S16 soDlgUpdOutClegInfo(cLeg, evnt, to, from, cSeqVal, direction)
SoCLegCb   *cLeg;      /* CLeg Cb */
SoEvnt     *evnt;      /* Event Cb */
SoAddress   *to;       /* To Address */
SoAddress   *from;     /* From Address */
U32         cSeqVal;   /* CSeq  */
U8          direction; /* Direction : SO_USER/ SO_INTERNAL */
#endif
{
  S16         ret;       /* Return Value */

  TRC2(soDlgUpdOutClegInfo);

  /* Generate local tag */
  if (direction != SO_INTERNAL)
  {
    ret = soCmGenLocalTag(evnt, cLeg, from);
    if (ret != ROK)
      RETVALUE(RFAILED);
  }

  /* Copy to address into Remote Address */
  if (soUtlCpySoAddress(&cLeg->storedHdrs.remoteAddr, to, 
                        (CmMemListCp *) NULLP) != ROK)
  {
    RETVALUE(RFAILED);
  }
  
  /* Store the Normalized form of the To address */
  if (soUtlStoreNormAddr(to, &cLeg->storedHdrs.normRemoteAddr) != ROK)
  {
    RETVALUE(RFAILED);
  }
 
  /* Copy From address into local address */
  if (soUtlCpySoAddress(&cLeg->storedHdrs.localAddr, from, 
                        (CmMemListCp *) NULLP) != ROK)
  {
    RETVALUE(RFAILED);
  }
  

  /* Copy Normalized from address into cleg */
  if (soUtlStoreNormAddr(from, &cLeg->storedHdrs.normLocalAddr) != ROK)
  {
    RETVALUE(RFAILED);
  }


  cLeg->storedHdrs.cSeqHiTx = cSeqVal;
  cLeg->storedHdrs.cSeqHiRx = SO_CSEQ_NONE_RECD;
    

  /* Initially copy remote trgt uri from the to header */
  ret = soUtlCpySoAddress(&cLeg->storedHdrs.remoteTrgtURI,
                           to, NULLP);

  if (ret!=ROK)
  {
    RETVALUE(RFAILED);
  }


  /* If it is invoked while creating an internal call leg, donot
     update the route here */

  if (direction != SO_INTERNAL)
  {
    /* Update the Route in the call leg */
    /* if (cLeg->call->ent->reCfg.e.uaReCfg.dfltPrxCfg.useDfltPrx == TRUE) */
       ret = soDlgUpdRoute(cLeg, evnt, direction);
       if (ret != ROK)
         RETVALUE(RFAILED);
  }
        
  RETVALUE(ROK);
}



/*
*
*       Fun:   soDlgUpdIncClegInfo
*
*       Desc:  This function initializes information
*              for an incoming call leg.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgUpdIncClegInfo
(
SoCLegCb   *cLeg,    /* CLeg Cb */
SoEvnt     *evnt,    /* Event Cb */
SoAddress   *to,     /* To Address */
SoAddress   *from,   /* From Address */
U32         cSeqVal  /* CSeq Value */
)
#else
PRIVATE S16 soDlgUpdIncClegInfo(cLeg, evnt, to, from, cSeqVal)
SoCLegCb   *cLeg;   /* CLeg Cb */
SoEvnt     *evnt;   /* Event Cb */
SoAddress  *to;     /* To Address */
SoAddress  *from;   /* From Address */
U32        cSeqVal; /* CSeq Value */
#endif
{
  S16         ret;   /* Return Value */
  U32         i;
  /* so007.201 : Added parameters */
#ifdef SO_REJECT_REINV_ON_UA_RESTART
  SoEntCb     *ent;    /* Entity Cb */
  TknStrOSXL  *tag;    /* tag string */
#endif /* SO_REJECT_REINV_ON_UA_RESTART */
  /* so033.201 : Added parameters */
#ifdef SO_REJECT_ON_UA_RESTART
  SoEntCb     *entCb;    /* Entity Cb */
  TknStrOSXL  *toTag;    /* tag string */
#endif /* SO_REJECT_ON_UA_RESTART */


  TRC2(soDlgUpdIncClegInfo);

  /* so008.201 : Set return value to RFAILED */

  /* so007.201 : Added code for  condition where the UAS 
   * might have crashed and restrated and then it receives a 
   * message for an old call whose context doesnot exist */
  /* so033.201 :Added code to reject for all the requests
     (invites & non-invites) */
#ifdef SO_REJECT_ON_UA_RESTART
  entCb = cLeg->call->ent;

  if (entCb->s.ua.reCfg.rejOnUARestart == TRUE)
  {
    ret = soCmGetAddrParam((U8 **)&toTag, to, SO_ADDRPARAM_TAGPARAM);

    if (ret == ROK)
    {
      /* Tag already present return NULL */
      RETVALUE(RFAILED);
    }
  }
#endif /* SO_REJECT_ON_UA_RESTART */

#ifdef SO_REJECT_REINV_ON_UA_RESTART 
  /* To Tag should not be present in incoming out of dialogue request */
  /* Return NULL to ensure that 481 is returned */
  
  ent = cLeg->call->ent;

  if ((ent->s.ua.reCfg.rejReInvOnUARestart == TRUE) &&
      (evnt->eventType.val == SOT_ET_INVITE))
  {
    ret = soCmGetAddrParam((U8 **)&tag, to, SO_ADDRPARAM_TAGPARAM);
  
    if (ret == ROK)
    {
      /* Tag already present return NULL */
      RETVALUE(RFAILED);
    }
  }
#endif /* SO_REJECT_REINV_ON_UA_RESTART */

  /* Generate local tag */
  ret = soCmGenLocalTag(evnt, cLeg, to);
  if (ret != ROK)
    RETVALUE(RFAILED);

  /* Copy To address into call leg */
  if (soUtlCpySoAddress(&cLeg->storedHdrs.localAddr, to, 
                        (CmMemListCp *) NULLP) != ROK)
  {
    RETVALUE(RFAILED);
  }

  /* Copy Normalized To address into call leg */
  if (soUtlStoreNormAddr(to, &cLeg->storedHdrs.normLocalAddr) != ROK)
    RETVALUE(RFAILED);

  /* Copy From address into call leg */
  if (soUtlCpySoAddress(&cLeg->storedHdrs.remoteAddr, from, 
                        (CmMemListCp *) NULLP) != ROK)
  {
    RETVALUE(RFAILED);
  }

  /* Copy Normalized from address into call leg */
  if (soUtlStoreNormAddr(from, &cLeg->storedHdrs.normRemoteAddr) != ROK)
    RETVALUE(RFAILED);


  /* Store the Remote Tag, if present */
  for (i = 0; i < SO_GET_NUM_COMP(&from->addrParams.numComp); i++)
  {
    /* Check to see if it is a tag */
    if (SO_CMP_TKN_LIT(&from->addrParams.addrParam[i]->addrParamType,
                       SO_ADDRPARAM_TAGPARAM) == TRUE)
    {
      ret = soUtlCpyTknStrOSXL(&cLeg->storedHdrs.remoteTag,
                               &from->addrParams.addrParam[i]->t.tagParam,
                               NULLP);
      if (ret != ROK)
        RETVALUE(RFAILED);
      break;
    }
  }


  cLeg->storedHdrs.cSeqHiRx = cSeqVal;
  cLeg->storedHdrs.cSeqHiTx = SO_CSEQ_START;

  /* Update the Remote Target URI */
  ret = soDlgUpdRemoteTrgtURI(cLeg, evnt);

  if (ret == ROK)
  {
    /* If incoming message doesnot have a contact address
       cpopy from the from' address */
    if (cLeg->storedHdrs.remoteTrgtURI.pres.pres == NOTPRSNT)
    {
      ret = soUtlCpySoAddress(&cLeg->storedHdrs.remoteTrgtURI,
                              from, NULLP);      
    }
  }

  if (ret == ROK)
    ret = soDlgUpdRoute(cLeg, evnt, SO_REMOTE);

  if (ret != ROK)
    RETVALUE(RFAILED);

  RETVALUE(ROK);
} /* soDlgUpdIncClegInfo */




/*
*
*       Fun:   soDlgFindNextHopAddr
*
*       Desc:  Function checks for the address to be
*              used for routing the message.
*              If a route set is present and the LR 
*              flag is present in the first entry of
*              the route set use that address else
*              it implies that the next hop is a 2543
*              RFC, theefore use Request URI to route
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgFindNextHopAddr
(
SoCLegCb   *cLeg,     /* CLeg Cb */
SoAddrSpec **reqAddr   /* Address of next hop */
)
#else
PRIVATE S16 soDlgFindNextHopAddr(cLeg, reqAddr)
SoCLegCb   *cLeg;     /* CLeg Cb */
SoAddrSpec **reqAddr;  /* Address of next hop */
#endif
{
  TRC3(soDlgFindNextHopAddr);

  /* If using 3261 the next hop will be the first element of the 
     route header */
  if (cLeg->storedHdrs.nextHopAddr == SO_NEXTHOP_ROUTE)
  {
    /* Return the First route parameter */
    (*reqAddr) = &cLeg->storedHdrs.route.route[0]->nameAddr.addrSpec;
  }
  else
  {
    /* if it is 2543 then the request URI will always point to the
       next hop */
    (*reqAddr) = &cLeg->storedHdrs.reqURI;
  }
  
  RETVALUE(ROK);
} /* soDlgFindNextHopAddr */



/*
*
*       Fun:   soDlgFindCancelNextHopAddr
*
*       Desc:  Function checks for the address to be
*              used for routing CANCEL message.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgFindCancelNextHopAddr
(
SoTransCb  *transCb,   /* Transaction Cb      */
SoAddrSpec *reqAddr    /* Address of next hop */
)
#else
PRIVATE S16 soDlgFindCancelNextHopAddr(transCb, reqAddr)
SoTransCb  *transCb;   /* Transaction Cb      */
SoAddrSpec *reqAddr;   /* Address of next hop */
#endif
{
  S16   ret;

  TRC3(soDlgFindCancelNextHopAddr);

  ret = ROK;

  /*--- Fill The Next Hop Address Used To Send CANCELED Request ---*/

  /*-------------- SIP Url --------------*/
   SO_FILL_TKNU8 (&reqAddr->addrSpecType , SO_ADDRSPEC_SIPURL);
   SO_FILL_TKNU8 (&reqAddr->t.sipUrl.pres, PRSNT_NODEF);

  /*---- No User Info -----*/
   SO_FILL_TKNU8 (&reqAddr->t.sipUrl.userInfo.pres, NOTPRSNT);

  /*----- No Url Info -----*/
   SO_FILL_TKNU16 (&reqAddr->t.sipUrl.urlParameters.numComp, 0);

  /*--- No Header Info ----*/
   SO_FILL_TKNU16 (&reqAddr->t.sipUrl.headers.pres, NOTPRSNT);

  /*--- Host Port Info ----*/
   ret = soCmTptAddrToHostPort (&reqAddr->t.sipUrl.hostPort,
                                &transCb->destAddr,
                                NULLP);
   RETVALUE (ret);

} /* soDlgFindCancelNextHopAddr */

/* so027.201: Changes for SIP TLS support */
#ifdef SO_TLS
/*
*
*       Fun:   soDlgFindTlsCancelNextHopAddr
*
*       Desc:  Function checks for the address to be
*              used for routing CANCEL message.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgFindTlsCancelNextHopAddr
(
SoTransCb  *transCb,   /* Transaction Cb      */
SoAddrSpec *reqAddr    /* Address of next hop */
)
#else
PRIVATE S16 soDlgFindTlsCancelNextHopAddr(transCb, reqAddr)
SoTransCb  *transCb;   /* Transaction Cb      */
SoAddrSpec *reqAddr;   /* Address of next hop */
#endif
{
  S16   ret;

  TRC3(soDlgFindTlsCancelNextHopAddr);

  ret = ROK;

  /*--- Fill The Next Hop Address Used To Send CANCELED Request ---*/

  /*-------------- SIP Url --------------*/
   SO_FILL_TKNU8 (&reqAddr->addrSpecType , SO_ADDRSPEC_SIPSURL);
   SO_FILL_TKNU8 (&reqAddr->t.sipsUrl.pres, PRSNT_NODEF);

  /*---- No User Info -----*/
   SO_FILL_TKNU8 (&reqAddr->t.sipsUrl.userInfo.pres, NOTPRSNT);

  /*----- No Url Info -----*/
   SO_FILL_TKNU16 (&reqAddr->t.sipsUrl.urlParameters.numComp, 0);

  /*--- No Header Info ----*/
   SO_FILL_TKNU16 (&reqAddr->t.sipsUrl.headers.pres, NOTPRSNT);

  /*--- Host Port Info ----*/
   ret = soCmTptAddrToHostPort (&reqAddr->t.sipsUrl.hostPort,
                                &transCb->destAddr,
                                NULLP);
   RETVALUE (ret);

} /* soDlgFindTlsCancelNextHopAddr */
#endif


/*
*
*       Fun:   soDlgChkMandUaOutReqHdr
*
*       Desc:  This function validates the mandatory
*              headers in an outgoing message
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgChkMandUaOutReqHdr
(
SoCLegCb   *cLeg,    /* Cleg Cb */
SoEvnt     *evnt     /* Evnt  */
)
#else
PRIVATE S16 soDlgChkMandUaOutReqHdr(cLeg, evnt)
SoCLegCb   *cLeg;    /* Cleg Cb */
SoEvnt     *evnt;    /* Event  */
#endif
{
  S16     ret;
  

  TRC3(soDlgChkMandUaOutReqHdr);

  /* Insert Request URI */
  /* so011.201: Do not update Req URI for CANCEL */
  if (evnt->eventType.val != SOT_ET_CANCEL)
  {
    ret = soUtlInsertReqURI(cLeg, evnt);
    if (ret != ROK)
      RETVALUE(SOT_ERR_MAND_HDR);

    /* so014.201 : To remove to tag or not */
    /* Insert To header */
    ret = soUtlInsertToHdr(cLeg, evnt, FALSE);
    if (ret != ROK)
      RETVALUE(SOT_ERR_MAND_HDR);
  }
  else
  {
    /* Insert To header */
    ret = soUtlInsertToHdr(cLeg, evnt, TRUE);
    if (ret != ROK)
      RETVALUE(SOT_ERR_MAND_HDR);
  }

  /* Insert From header */
  ret = soUtlInsertFromHdr(cLeg, evnt);
  if (ret != ROK)
    RETVALUE(SOT_ERR_MAND_HDR);
  
  /* Insert Call Id header */
  ret = soUtlInsertCallId(cLeg, evnt);
  if (ret != ROK)
    RETVALUE(SOT_ERR_MAND_HDR);

  /* Insert CSeq header */
  ret = soUtlInsertCSeq(cLeg, evnt, SO_CSEQ_NOTUSED, NULLP);
  if (ret != ROK)
    RETVALUE(SOT_ERR_MAND_HDR);

  /* Insert Route header */
  /* so011.201: Do not update Route for CANCEL */
  if (evnt->eventType.val != SOT_ET_CANCEL)
  {
    ret = soUtlInsertRoute(cLeg, evnt);
    if (ret != ROK)
      RETVALUE(SOT_ERR_MAND_HDR);
  }

  /* Insert Max forwards header */
  ret = soUtlInsertMaxFwds(cLeg->call->ent, evnt);
  if (ret != ROK)
    RETVALUE(SOT_ERR_MAND_HDR);
   
   /* so028.201 : check insTmStamp field and add Timestamp header */
   if(cLeg->call->ent->s.ua.reCfg.insTmStamp == TRUE)
   {
      /* Insert Max forwards header */
      ret = soUtlInsertTimestamp(cLeg->call->ent, evnt);
      if (ret != ROK)
         RETVALUE(SOT_ERR_MAND_HDR);
   }
 /*--- so014.201: If configured add "UserAgent" Header ---*/

   ret = soDlgPrcUserAgent (cLeg, evnt);
   if (ret != ROK)
      RETVALUE (SOT_ERR_ADD_HDR_FAILED);

   RETVALUE (SOT_ERR_NOERR);
}

#ifndef SO_TLS
/*
*
*       Fun:   soDlgChkOutReqHdr
*
*       Desc:  This function validates the mandatory
*              headers in an outgoing message
*
*       Notes:  
*
*
*       File:  so_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgChkOutReqHdr
(
SoEvnt     *evnt     /* Evnt  */
)
#else
PRIVATE S16 soDlgChkOutReqHdr(cLeg, evnt)
SoEvnt     *evnt;    /* Event  */
#endif
{
   U16     hdrIdx;
   U16     cnt;
 
   SoRoute *route;
   SoRouteSeq *routeSeq;
 
   SoContact *contact;
   SoContactItem *contactItem;
 
   SoAddrSpec *addrSpec;

   SoAddress *to;
   SoAddress *from;
 
   TRC3(soDlgChkOutReqHdr)

   /*--STEP 1 : Check To Header In Event Structure--*/
   if (soCmFindHdrChoice(evnt, (U8 **) &to, SO_HEADER_GEN_TO) == ROK)
   {
      if (to->pres.pres != NOTPRSNT)
      {
         if (to->addrCh.addrChType.pres != NOTPRSNT)
         {
            if (to->addrCh.addrChType.val == SO_ADDRCH_NAMEADDR)
               addrSpec = &(to->addrCh.t.nameAddr.addrSpec);
            else
               addrSpec = &(to->addrCh.t.addrSpec);
            
            if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
                (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPSURL))
               RETVALUE(SOT_ERR_INV_EVNT);
         }
      }
   }

   /*--STEP 2 : Check From Header In Event Structure--*/
   if (soCmFindHdrChoice(evnt, (U8 **) &from, SO_HEADER_GEN_FROM) == ROK)
   {
      if (from->pres.pres != NOTPRSNT)
      {
         if (from->addrCh.addrChType.pres != NOTPRSNT)
         {
            if (from->addrCh.addrChType.val == SO_ADDRCH_NAMEADDR)
               addrSpec = &(from->addrCh.t.nameAddr.addrSpec);
            else
               addrSpec = &(from->addrCh.t.addrSpec);
            
            if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
                (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPSURL))
               RETVALUE(SOT_ERR_INV_EVNT);
         }
      }
   }

   /*--STEP 3 : Check Route Header In Event Structure--*/
   while (soCmFindHdrStrtChIndex(evnt, (U8 **) &route, hdrIdx, &hdrIdx, SO_HEADER_REQ_ROUTE) == ROK)
   {
      if (route->numComp.pres != NOTPRSNT)
      {
         for (cnt = 0; cnt < route->numComp.val; cnt++)
         {
            routeSeq = route->route[cnt];
            if ((routeSeq->pres.pres != NOTPRSNT) &&
                (routeSeq->nameAddr.pres.pres != NOTPRSNT))
            {
               if (routeSeq->nameAddr.addrSpec.addrSpecType.pres != NOTPRSNT)
               {
                  if (routeSeq->nameAddr.addrSpec.addrSpecType.val == SO_ADDRSPEC_SIPSURL)
                     RETVALUE(SOT_ERR_INV_EVNT);
               }
            }
         }
      }
      hdrIdx++;
   }

   /*-- STEP 4 : Check Contact Header in Event Structure--*/
   hdrIdx = 0;
   while (soCmFindHdrStrtChIndex(evnt, (U8 **) &contact,
          hdrIdx, &hdrIdx, SO_HEADER_GEN_CONTACT) == ROK)
   {  
      if (contact->pres.pres != NOTPRSNT)
      {
         if ((contact->contactDescType.pres != NOTPRSNT) &&
             (contact->contactDescType.val == SO_CONTACTDESC_CONTACTITEMS))
         {
            if (contact->contactItems.numComp.pres != NOTPRSNT)
            {
               for (cnt = 0; cnt < contact->contactItems.numComp.val; cnt++)
               {  
                  contactItem = contact->contactItems.contactItem[cnt];
                  if ((contactItem->pres.pres != NOTPRSNT) &&
                      (contactItem->contactAddrChoice.addrChType.pres != NOTPRSNT))
                  {  
                     if (contactItem->contactAddrChoice.addrChType.val == SO_ADDRCH_NAMEADDR)
                        addrSpec = &(contactItem->contactAddrChoice.t.nameAddr.addrSpec);
                     else
                        addrSpec = &(contactItem->contactAddrChoice.t.addrSpec);

                     if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
                        (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPSURL))
                        RETVALUE(SOT_ERR_INV_EVNT);
                  }
               }
            }
         }
      }
      hdrIdx++;
   }

   /*-- STEP 5 : Check ReqUri in Evnt structure and cLeg--*/
   addrSpec = &evnt->t.request.requestLine.addrSpec;
   if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
       (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPSURL))
   {
      RETVALUE(SOT_ERR_INV_EVNT);
   }

   RETVALUE(ROK);
}
#endif


/*
*
*       Fun:   soDlgPrcUaOutReq
*
*       Desc:  Function updates the state and passes the message to
*              the transaction / the transport layer
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgPrcUaOutReq
(
SoUserCtxt *userCtxt, /* User Context */
CmTptAddr  *tptAddr,  /* Resolved addr incase of direct ip */
U8         tptProt    /* Transport Protocol */
)
#else
PRIVATE S16 soDlgPrcUaOutReq(userCtxt, tptAddr, tptProt)
SoUserCtxt *userCtxt; /* User Context */
CmTptAddr  *tptAddr;  /* Resolved addr incase of direct ip */
U8         tptProt;   /* Transport Protocol */
#endif
{
  S16         ret;       /* Return Value */
  SoCLegCb    *cLeg;     /* Call leg cb */
  SoEvnt      *evnt;     /* Event Structure */
  U8          prevCLegState; /* old cal leg State(for roll
                                back in case of failure */
  U8          modifyTpt; /* Transport modified from udp to TCP */
  SoTransCb   *transCb;  /* Transaction control Block */
  U16         eventType; /* Event Type */
  /* so006.201 : New param */
  SoCSeq      *cSeq;

  TRC3(soDlgPrcUaOutReq);

  modifyTpt = FALSE;

  /* Access evnt and call leg from user context because this 
     could be a call back from the DNS */
  if (userCtxt->evnt == NULLP)
     RETVALUE(RFAILED);

  evnt = userCtxt->evnt;
  userCtxt->evnt = NULLP;
     
  if (evnt->eventType.val != SOT_ET_ACK)
  {
     transCb = (SoTransCb *)userCtxt->userPtr;
     cLeg = (SoCLegCb *)transCb->cLeg;
  }
  else
     cLeg = (SoCLegCb *)userCtxt->userPtr;
     

  eventType = evnt->eventType.val;

  /* Update Contact Header for outgoing request */
  if ((eventType == SOT_ET_INVITE) ||
      (eventType == SOT_ET_NOTIFY) ||
      (eventType == SOT_ET_OPTIONS) ||
      (eventType == SOT_ET_UPDATE) ||
      (eventType == SOT_ET_REFER)  ||
      (eventType == SOT_ET_SUBSCRIBE))
  {
     /* so035.201: Pass self added flag while adding contact header */
     ret = soUtlAddContactHdr(cLeg, evnt, tptProt, &userCtxt->selfAdded);
 
     if (ret != ROK)
     {
        RETVALUE(SOT_ERR_MAND_HDR);
     }
  }

#ifdef SO_TLS
   /* Update TLS info if DNS returned TLS transport */
   /* so027.201: Changes for SIP TLS support */
   if (tptProt == LSO_TPTPROT_TLS_TCP)
      soDlgChkUpdTlsInfo(cLeg, evnt, SO_TLS_DNS);
#endif

  prevCLegState = cLeg->clegState;

  /* Update the call Leg State */
  ret = soDlgUpdState(cLeg, evnt, SO_USER);
  
  if (ret != SOT_ERR_NOERR)
  {
    RETVALUE(ret);
  }


  /* If it is a ACK send it directlty to the transport module */
  if (evnt->eventType.val == SOT_ET_ACK)
  {
    cLeg->ackCb.transport = tptProt;

    /* Copy Tpt address into the ack cb */
    cmMemcpy ((U8 *)&cLeg->ackCb.tptAddr, (U8 *)tptAddr, sizeof (CmTptAddr));

    SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
        "\n[Dialog] Outgoing Ack Sent to Transport:  Call: %ld, CallLeg: %lx",
        cLeg->call->spConnId, cLeg->legId));

    if (cLeg->ackCb.mBuf != NULLP)
       (Void) SPutMsg(cLeg->ackCb.mBuf);

    cLeg->ackCb.mBuf = NULLP;
     
    /*-- so006.201: Delete any branchId in VIA (if present) ---*/
    (Void) soUtlDeleteBranchId(evnt);

    /* Delete any existing Branch Idin the ackcb */
    soUtlDelTknStrOSXL (&cLeg->ackCb.branchId);

    /*-------- Save CSeq of request method -----------*/
    SO_GET_CSEQ_FROM_EVENT (evnt, cSeq);

    /*-- so021.201 : Added parameter for requestURI --*/
    /*-- so028.201 : Added parameter for via --*/
    /* For User Agent RequestURI in not used for      *
     * branchId Calculation                           */
    ret = soUtlGenerateBranchId (evnt, &cLeg->storedHdrs.normRemoteAddr, 
                                 &cLeg->storedHdrs.normLocalAddr,
                                 &cLeg->storedHdrs.remoteTag,   
                                 cSeq->cSeqVal.val,
                                 evnt->eventType.val,
                                 NULLP, 
                                 0,
                                 NULLP, 
                                 0,
                                 &cLeg->ackCb.branchId);

    if (ret == ROK)
    {
       ret = soTptSendInitialReq (cLeg->call->ssapCb->sys, 
                                  cLeg->call->ssapCb, tptAddr, 
                                  tptProt, evnt, cLeg->ackCb.modifyTpt, 
                                  &cLeg->ackCb.branchId, &cLeg->ackCb.tcmConn,
                                  &cLeg->ackCb.mBuf);
    }

    /* If the message was encoded & sent out successfully,
       update transport in ack structure, if necessary */
    if ((ret == ROK) && (cLeg->ackCb.mBuf != NULLP))
    {
     /*------ so009.201: Free the ACK Event Structure -----*/
      (Void) soCmFreeEvent(evnt);     

      if (cLeg->ackCb.modifyTpt == TRUE)
      {
        /* so038.201: replaced with macro to check for UDP transport */
        if (SO_TCM_UDP_TRANSPORT(cLeg->ackCb.transport))
          cLeg->ackCb.transport = LSO_TPTPROT_TCP;
        else
          cLeg->ackCb.transport = LSO_TPTPROT_UDP;
      }
    }
    else if( ret == SO_TPT_MULTI_THREADED_ENC)
       RETVALUE(ROK);
  }
  else
  {
    SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
      "\n[Dialog] Outgoing %s Request For Transaction:"
      "Call(%ld), CallLeg(%lx), State(%d)",
      soSOTEventDescrip[evnt->eventType.val - 1], 
      cLeg->call->spConnId, cLeg->legId, cLeg->clegState));

    /* Send message to the transaction module for further processing */
    ret = soTxnUaOutReq(transCb, tptAddr, tptProt);
  } 
  
  /* if procedure fails, get call leg back to previous state */
  if (ret != ROK)
  {
    cLeg->clegState = prevCLegState;
    SODBGP_SO(SO_DBGMASK_ERR, (soCb.init.prntBuf, 
             "\n[Dialog] Outgoing Request Sending Failed: Reason: %d", ret));

    userCtxt->userPtr = NULLP;
  }

  RETVALUE(ret);
} /* soDlgPrcUaOutReq */





/*
*
*       Fun:   soDlgChkMandUaOutRspHdr
*
*       Desc:  This function validates the mandatory
*              headers in an outgoing response
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgChkMandUaOutRspHdr
(
SoCLegCb   *cLeg,    /* Cleg Cb */
SoEvnt     *evnt,    /* Event  */
SoTransCb  *transCb  /* Transaction cb */
)
#else
PRIVATE S16 soDlgChkMandUaOutRspHdr(cLeg, evnt, transCb)
SoCLegCb   *cLeg;    /* Cleg Cb */
SoEvnt     *evnt;    /* Event  */
SoTransCb  *transCb;  /* Transaction cb */
#endif
{
  S16           ret;
#if (ERRCLASS & ERRCLS_DEBUG)
  TknStrOSXL    *callId;
#endif /* ERRCLASS & ERRCLS_DEBUG */
  SoRoute       *recordRoute;
  U16           hdrIdx;
  U16        responseCode;  /* Response Code  */
  SoTimestamp *timestamp;  /* so025.201 */

  TRC3(soDlgChkMandUaOutRspHdr);

  /* so014.201: Remove to tag for 100 response */
  responseCode = evnt->t.response.statusLine.statusCode.val;

  /* Insert From hdr */
  ret = soUtlInsertFromHdr(cLeg, evnt);
  if (ret != ROK)
    RETVALUE(SOT_ERR_MAND_HDR);

#ifdef SO_XX_UPD_LCL_TAGS 
  /* so011.201: Update local tags if provided
     by the user */
  ret = soUtlUpdateLclTags(cLeg, evnt);
  if (ret != ROK)
    RETVALUE(SOT_ERR_MAND_HDR);
#endif /* SO_XX_UPD_LCL_TAGS */

  /* so014.201: Remove to tag for 100 response */
  /* Insert To hdr */
  if (responseCode == SOT_RSP_100_TRYING)
  {
      /* so028.201 : Get the time delay and update timestamp header 
         if present in the req */
      /* if the stored value in the Cleg is not 0, that means the 
         incoming req had a timestamp header.*/

      if (cLeg->timestamp.pres.pres == PRSNT_NODEF)
      {
         U32 diffsec;
         U32 diffusec;
         U32 sec;
         U32 usec;
         /* Timestamp header is present in the incoming invite req. */

         /* Find From header in the event structure */
         ret = soCmFindHdrChoice(evnt, (U8 **) &timestamp, 
               SO_HEADER_GEN_TIMESTAMP);

         if (timestamp  == NULLP)
         {
            /* Create new to header */
            if ( soCmCreateHdrChoice(evnt, (U8 **) &timestamp, 
                  SO_HEADER_GEN_TIMESTAMP)!=ROK )
            {
               RETVALUE(RFAILED);
            }
         }
  
         /* Get the current ref time */
         ret = SGetRefTime(0, &sec, &usec);

         /* copy the timestamp frm CLEG */
         timestamp->pres.pres = PRSNT_NODEF;

         timestamp->timestampVal.pres = cLeg->timestamp.timestampVal.pres;
         timestamp->timestampVal.val = cLeg->timestamp.timestampVal.val;
         timestamp->timestampFrac.pres = cLeg->timestamp.timestampFrac.pres;
         timestamp->timestampFrac.val = cLeg->timestamp.timestampFrac.val;

         /* Take the diff and update the timestamp */
         if(usec < cLeg->usec)
         {
            diffusec = 1000000 + usec - cLeg->usec;
            diffsec = sec - cLeg->sec -1;
         }
         else
         {
            diffusec = usec - cLeg->usec;
            diffsec = sec - cLeg->sec;
         }

         timestamp->timestampDelay.pres = PRSNT_NODEF;
         timestamp->timestampDelay.val = diffsec;
         timestamp->timestampDelayFrac.pres = PRSNT_NODEF;
         timestamp->timestampDelayFrac.val = diffusec;
         
      }
      /* so029.201: If the 100 trying is sent for modify req, to tag should be included */
     if (cLeg->clegState == SO_CLEG_STATE_MODIFY)
        ret = soUtlInsertToHdr(cLeg, evnt, FALSE);
     else
        ret = soUtlInsertToHdr(cLeg, evnt, TRUE);
     if (ret != ROK)
       RETVALUE(SOT_ERR_MAND_HDR);
  }
  else
  {
     ret = soUtlInsertToHdr(cLeg, evnt, FALSE);
     if (ret != ROK)
       RETVALUE(SOT_ERR_MAND_HDR);
  }

  /* Check if call Id is the same as the stored one, under
     debug flag */
#if (ERRCLASS & ERRCLS_DEBUG)
   ret = soCmFindHdrChoice(evnt, (U8 **) &callId,
      SO_HEADER_GEN_CALLID);
   if (ret == ROK)
   {
     if (soUtlCmpTknStrOSXL(&cLeg->call->callId, callId, TRUE) != TRUE)
       RETVALUE(SOT_ERR_INVALID_CALLID);
   }
   else
#endif

  ret = soUtlInsertCallId(cLeg, evnt);
  if (ret != ROK)
    RETVALUE(SOT_ERR_MAND_HDR);

  /* Insert CSeq hdr */ 
  ret = soUtlInsertCSeq(cLeg, evnt, transCb->transCSeq, &transCb->extMethod);
  if (ret != ROK)
    RETVALUE(SOT_ERR_MAND_HDR);

  /* so006.201 : Record-Route is to be added only for 18x or 2xx messages 
   * This fix adds that check */
  responseCode = evnt->t.response.statusLine.statusCode.val;

  if ((responseCode >= SOT_RSP_180_RINGING) &&
      (responseCode < SOT_RSP_300_MULT_CHOICES))
  {
     /*--- so009.201: Use record route if provided by user ---*/
     ret = soCmFindHdrChIndex(evnt, (U8 **) &recordRoute, &hdrIdx,
                              SO_HEADER_GEN_RECORDROUTE);
     if (ret != ROK)
     {
        /* Insert record Route hdr */ 
        ret = soUtlInsertRecordRoute (cLeg, evnt);
        if (ret != ROK)
           RETVALUE (SOT_ERR_ADDING_RROUTE_HDR);
     }
  }
 
 /*--- so014.201: If configured add "Server" Header ---*/

   ret = soDlgPrcServer (cLeg, evnt);
   if (ret != ROK)
      RETVALUE (SOT_ERR_ADD_HDR_FAILED);
  
  RETVALUE (SOT_ERR_NOERR);

}


#ifdef SO_UA

/*--- so014.201: New function to add "Server" Header ---*/


/*
*
*       Fun:   soDlgPrcServer
*
*       Desc:  This function adds a server header if necessary.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_dlg.c
*
*/

#ifdef ANSI
PRIVATE S16 soDlgPrcServer
(
SoCLegCb   *cLeg,    /* Cleg Cb */
SoEvnt     *evnt     /* Event   */
)
#else
PRIVATE S16 soDlgPrcServer (cLeg, evnt)
SoCLegCb   *cLeg;    /* Cleg Cb */
SoEvnt     *evnt;    /* Event   */
#endif
{
   SoProdcomLst  *server;         /* Pointer to server header         */
   SystemId      sId;             /* System ID                        */
   SoTknStr      *cfgServer;      /* Pointer to configured value      */
   Txt           ver[LSO_STR_SZ]; /* Version                          */
   S16           ret;             /* value returned by function calls */

   TRC2 (soDlgPrcServer);

   /*-- Check if this entity is configured to add the server header --*/
   if (cLeg->call->ent->s.ua.reCfg.insServer.pres == NOTPRSNT)
      RETVALUE (ROK);

   /*----------- Do nothing, if header is already present ------------*/
   ret = soCmFindHdrChoice (evnt, (U8 **) &server, SO_HEADER_RSP_SERVER);
   if (ret == ROK)
      RETVALUE (ROK);

   /*---------- Add server header ----------*/
   ret = soCmCreateHdrChoice (evnt, (U8 **)&server, SO_HEADER_RSP_SERVER);
   if (ret != ROK)
      RETVALUE (RFAILED);

   /*- Add one element to the prodcom list -*/
   ret = soCmGrowList ((Void ***)&server->prodcom, 
                       sizeof (SoProdcom),
                       &server->numComp  ,
                       evnt);
   if (ret != ROK)
      RETVALUE(RFAILED);

   /*-------- Set the prodcom type ---------*/
   SO_FILL_TKNU8 (&server->prodcom[0]->prodcomType, SO_PRODCOM_PRODUCT);

   /*------ Copy the configured value ------*/

   cfgServer = &cLeg->call->ent->s.ua.reCfg.insServer;

   server->prodcom[0]->t.product.pres.pres = PRSNT_NODEF;

   SO_FILL_TKNSTROSXL (&server->prodcom[0]->t.product.name,
                       (U8 *)(cfgServer->str),
                       cmStrlen ((U8 *)(cfgServer->str)),
                       evnt,
                       ret);
   if (ret != ROK)
      RETVALUE (RFAILED);

   /*--- Fill "System Id" as value field ---*/

   (Void) soGetSid (&sId);

   sprintf (ver, "%d.%d", sId.mVer, sId.mRev);

   /* Copy version into server header */
   SO_FILL_TKNSTROSXL (&server->prodcom[0]->t.product.value,
                       (U8 *)(ver),
                       cmStrlen((U8 *)(ver)),
                       evnt,
                       ret);
   if (ret != ROK)
      RETVALUE (RFAILED);

   RETVALUE (ROK);

} /* end of soDlgPrcServer */



/*
*
*       Fun:   soDlgPrcUserAgent
*
*       Desc:  This function adds a userAgent header if necessary.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_dlg.c
*
*/

#ifdef ANSI
PUBLIC S16 soDlgPrcUserAgent
(
SoCLegCb   *cLeg,    /* Cleg Cb */
SoEvnt     *evnt     /* Event   */
)
#else
PUBLIC S16 soDlgPrcUserAgent (cLeg, evnt)
SoCLegCb   *cLeg;    /* Cleg Cb */
SoEvnt     *evnt;    /* Event   */
#endif
{
   SoProdcomLst  *userAgent;         /* Pointer to userAgent header   */
   SoTknStr      *cfgUserAgent;      /* Pointer to configured value   */
   S16           ret;             /* value returned by function calls */

   TRC2 (soDlgPrcUserAgent);

   /* Check if this entity is configured to add the userAgent header */
   if (cLeg->call->ent->s.ua.reCfg.insUserAgent.pres == NOTPRSNT)
      RETVALUE (ROK);

   /*----------- Do nothing, if header is already present ------------*/
   ret = soCmFindHdrChoice (evnt, (U8 **) &userAgent, SO_HEADER_GEN_USERAGENT);
   if (ret == ROK)
      RETVALUE (ROK);

   /*--------- Add UserAgent header --------*/
   ret = soCmCreateHdrChoice (evnt, (U8 **)&userAgent, SO_HEADER_GEN_USERAGENT);
   if (ret != ROK)
      RETVALUE (RFAILED);

   /*- Add one element to the prodcom list -*/
   ret = soCmGrowList ((Void ***)&userAgent->prodcom,
                       sizeof (SoProdcom) ,
                       &userAgent->numComp,
                       evnt);
   if (ret != ROK)
      RETVALUE (RFAILED);

   /*-------- Set the prodcom type ---------*/
   SO_FILL_TKNU8(&userAgent->prodcom[0]->prodcomType, SO_PRODCOM_PRODUCT);

   /*------ Copy the configured value ------*/

   cfgUserAgent = &cLeg->call->ent->s.ua.reCfg.insUserAgent;

   userAgent->prodcom[0]->t.product.pres.pres = PRSNT_NODEF;

   SO_FILL_TKNSTROSXL (&userAgent->prodcom[0]->t.product.name,
                       (U8 *)(cfgUserAgent->str), 
                       cmStrlen((U8 *)(cfgUserAgent->str)),
                       evnt,
                       ret);
   if (ret != ROK)
      RETVALUE (RFAILED);

   userAgent->prodcom[0]->t.product.value.pres = NOTPRSNT;

   RETVALUE (ROK);

} /* end of soDlgPrcUserAgent */






#endif /* SO_UA */




/*
*
*       Fun:   soDlgLocateRspTran
*
*       Desc:  This function locates transaction for a response.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC SoTransCb *soDlgLocateRspTran
(
SoCLegCb   *cLeg,   /* CLeg Cb */
SoEvnt     *evnt    /* Event Cb */
)
#else
PUBLIC SoTransCb  *soDlgLocateRspTran(cLeg, evnt)
SoCLegCb   *cLeg;   /* CLeg Cb */
SoEvnt     *evnt;   /* Event Cb */
#endif
{
  S16          ret;
  SoTransCb    *transCb;    /* Transaction Cb */

  TRC3(soDlgLocateRspTran);

  transCb = NULLP;

  /* Try to find the transaction from the list in the
     call leg using transId as the key */
  ret = cmHashListFind(&cLeg->tranCbLst, (U8 *) &evnt->transId,
                       sizeof(evnt->transId), 0,
                        (PTR *) &transCb);
  if (ret != ROK)
    RETVALUE(NULLP);


#ifndef SO_REL_1_2_INF
  /* Make sure the transaction method matches that os the rsp event */
  if (evnt->eventType.val == transCb->transMethod)
  {
    RETVALUE(transCb);
  }
  else
    RETVALUE(NULLP);
#else
  /* For the old interface update the ventType.val with the 
     transaction method */
  evnt->eventType.val = transCb->transMethod;
  RETVALUE(transCb);
#endif

} /* soDlgLocateRspTran */





/*
*
*       Fun:   soDlgLocateCancelTran
*
*       Desc:  This function locates transaction to be cancelled 
*              using parameters received in the CancelReq.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC SoTransCb *soDlgLocateCancelTrans
(
SoCLegCb   *cLeg,     /* CLeg Cb */
SoEvnt     *evnt,     /* Event Cb */
U8         direction  /* Direction */
)
#else
PUBLIC SoTransCb  *soDlgLocateCancelTrans(cLeg, evnt, direction)
SoCLegCb   *cLeg;     /* CLeg Cb */
SoEvnt     *evnt;     /* Event Cb */
U8         direction; /* Direction */
#endif
{
  S16          ret;
  SoTransCb    *transCb;     /* Transaction Cb */
  SoTransCb    *prevTransCb; /* temp transaction cb */
  U32          transId;      /* New transaction id for 
                                the cancel txn */
  SoCSeq      *cSeqHdr;       /* Header for cSeq */
  U32         cSeqVal;        /* CSeq Value */

  TRC3(soDlgLocateCancelTrans);

  transCb = NULLP;
  prevTransCb = NULLP;

  /* if the cancel was received from the user find the 
     transaction using the transId provided in the request */
  if (direction == SO_USER)
  {
    /* The transId provided by the user points to the transId
       of the transaction being cancelled */
    ret = cmHashListFind(&cLeg->tranCbLst, (U8 *) &evnt->transId,
                         sizeof(evnt->transId), 0,
                         (PTR *) &transCb);

    if ((ret != ROK) || (transCb == NULLP))
      RETVALUE(NULLP);

    /* Generate a new transaction id for the cancel */
    SO_TXN_AllOC_TRANSID (transId, evnt->eventType.val, cLeg->call->ent);
    
    evnt->transId = transId;
    RETVALUE(transCb);
  }
  else if (direction == SO_REMOTE)
  {
    /* This case occurs when a cancel is received from the remote end.
       In this case find transaction by matching the Cseq received */

    if (soCmFindHdrChoice(evnt, (U8 **) &cSeqHdr,
                          SO_HEADER_GEN_CSEQ) != ROK)
    {
      SODBGP_SO(SO_DBGMASK_ERR, (soCb.init.prntBuf,
               "\n[Dialog] soPrcGetCSeqMethod: No CSeq header"));
      RETVALUE(NULLP);
    }

    if (cSeqHdr->cSeqVal.pres != NOTPRSNT)
      cSeqVal = cSeqHdr->cSeqVal.val;
    else
      RETVALUE(NULLP);
  }
  else if (direction == SO_OTHER)
  {
    /* This case happens when a cancel timer has expired.
       In this case find the orig transaction based on cseq and
       method stored in the call leg */
    cSeqVal = cLeg->cancelTmrCb.cSeqVal;
  }

  
  while (cmHashListGetNext(&cLeg->tranCbLst, 
                           (PTR)prevTransCb,
                             (PTR *) &transCb) == ROK)
  {    
    prevTransCb = transCb;
    
    /*--- so017.201: Check if transaction is alive ----*/
    if (!SO_TXN_ISALIVE (SOT_ET_CANCEL, transCb))
         continue;
       
    /* Internal means that the stack is trying to clear a
       INVITE transaction internally */
    if (direction == SO_INTERNAL)
    {
      if (transCb->transMethod == SOT_ET_INVITE)
        RETVALUE(transCb);
      else
        continue;
    }
    /* so029.201: Check for transaction type as well */
    if (direction == SO_REMOTE)
    {
       if (!(transCb->transType == SO_TRANS_INV_SERVER) &&
           !(transCb->transType == SO_TRANS_NON_INV_SERVER))
          continue;
    }
    if (direction == SO_USER)
    {
       if (!(transCb->transType == SO_TRANS_INV_CLIENT) &&
           !(transCb->transType == SO_TRANS_NON_INV_CLIENT))
          continue;
    }

    if (transCb->transCSeq == cSeqVal)
    {
      if (direction == SO_OTHER)
      {
        if (transCb->transMethod == cLeg->cancelTmrCb.method)
          RETVALUE(transCb);
      }
      else  
        if (transCb->transMethod != SOT_ET_CANCEL)
          RETVALUE(transCb);
    }
  }
 
  RETVALUE (NULLP);
 
} /* soDlgLocateCanclTran */



/*
*
*       Fun:   soDlgChkDfltInPrx
*
*       Desc:  This function checks if the message is 
*              received from the default proxy
*
*       Notes: 
*
*       File:  so_utl.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgChkDfltInPrx
(
SoEntCb     *ent,        /* Ent Cb */
SoTransCb   *transCb,    /* Transaction cb */
SoEvnt      *evnt        /* Event cb */
)
#else
PRIVATE S16 soDlgChkDfltInPrx(ent, transCb, evnt)
SoEntCb     *ent;        /* Ent Cb */
SoTransCb   *transCb;    /* Transaction cb */
SoEvnt      *evnt;       /* Event cb */
#endif
{

  S16          ret;         /* Return Value */
  SoUserCtxt   userCtxt;   /* User Context */
  SoAddrSpec   *prxyName;   /* DNS address */
  CmTptAddr    prxyAddr;   /* Proxy Address */
  SoHost       *inHost;
  U32          inPort;  
  U8           tptProt;
  U8           queryType;
  PTR          queryCb;
  SoHostPort   *dfltProxy;
  CmTptAddr    viaAddr;
  Bool         addrMatch;

  TRC3(soDlgChkDfltInPrx);

  /*------------ Get Default Incoming Proxy Address -----------*/
  dfltProxy = &ent->s.ua.dfltRouteSet.route[0]->nameAddr.
              addrSpec.t.sipUrl.hostPort;

  /*--------- Get source address from TOP VIA element ---------*/
  ret = soCmGetAddrFromVia (evnt, &inHost, &inPort);
  if (ret != ROK)
     RETVALUE (RFAILED);

  /*------ Check if the message came from default proxy -------*/
  ret = soCmCompareHost (&(dfltProxy->host), inHost);
  if (ret == ROK)
  {
    if ((dfltProxy->port.pres == PRSNT_NODEF) &&
        (dfltProxy->port.val  != inPort))
      RETVALUE (RFAILED);

    RETVALUE (ROK);
  }

  if ((SO_CMP_TKN_LIT (&dfltProxy->host.hostType,
                       SO_HOST_HOSTNAME) == FALSE) &&
      (SO_CMP_TKN_LIT (&inHost->hostType,
                       SO_HOST_HOSTNAME) == FALSE))
  {
    /*--- Both address are IP address abd they do not match ---*/
      RETVALUE (RFAILED);
  }

  /* 
   * If the default proxy is domain name,perform DNS query to get
   * IP address.
   */
  if ((SO_CMP_TKN_LIT (&dfltProxy->host.hostType,
                       SO_HOST_HOSTNAME) == TRUE) &&
      (SO_CMP_TKN_LIT (&inHost->hostType,
                       SO_HOST_HOSTNAME) == FALSE))
  {
    /* 
     *The oubound proxy is configured as domain name but received
     *VIA header contains an IP address. DNS Query is required to
     *resolve domain name to IP address.
     */
      prxyName = &ent->s.ua.dfltRouteSet.route[0]->nameAddr.addrSpec;

      userCtxt.userPtr = (PTR)transCb;
      userCtxt.evnt    = evnt;

      ret = soDnsCheckAddr((PTR) &userCtxt, prxyName, &prxyAddr,
                          &tptProt, &queryType, soDlgDnsRspCallBack, 
                          &queryCb); 
      if (ret == RFAILED)
         RETVALUE (RFAILED);

      if (ret == ROKDNA)
      {
        /*--------- Save the context of DNS queryCb -----------*/
        SO_TXN_UPDATE_QUERYCB (transCb, queryCb)
        RETVALUE (ROKDNA);
      }

      if (ret == ROK)
      {
         if (soCmHostPortToTptAddr (inHost, inPort, &viaAddr) != ROK)
           RETVALUE (RFAILED);

         if (soCmpTptAddr (&prxyAddr, &viaAddr, &addrMatch) != ROK)
           RETVALUE (RFAILED);
      }
  }

  RETVALUE (ROK);
}


/*
*
*       Fun:   soDlgPrcUaIncReq
*
*       Desc:  Call back function invoked by the dialog 
*              layer after DNS query is completed
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC S16 soDlgPrcUaIncReq
(
SoTransCb   *transCb,   /* Transaction cb */
SoEvnt      *evnt       /* Event CB */
)
#else
PUBLIC S16 soDlgPrcUaIncReq(transCb, evnt)
SoTransCb   *transCb;   /* Transaction cb */
SoEvnt      *evnt;      /* Event CB */
#endif
{
   S16         ret;
   SoCLegCb    *cLeg;       /* Call Leg Cb */
   SoEntCb     *ent;        /* Entity Cb */
   U8          prevLegState;
   U16         statusCode;   /* Status Code for error esponse */

   TRC3(soDlgPrcUaIncReq);
   
   cLeg = (SoCLegCb *)transCb->cLeg;
   ent = cLeg->call->ent;

   prevLegState = cLeg->clegState;

   if (soDlgUpdState(cLeg, evnt, SO_REMOTE) != ROK)
   {
     /* for all messages except cancel send error response */
     if (evnt->eventType.val != SOT_ET_CANCEL)
     {
      /* so012.201: Find appropriate error code to be send */
       
       statusCode = soDlgFindStatusCode (evnt->eventType.val,
                                         cLeg->clegState);

       SO_UA_SEND_ERR_RSP(cLeg      , transCb , evnt, 
                          statusCode, SO_EXTRSP_NONE);
     }
     else
     {
       /* Drop the Cancel */
       soCmFreeEvent(evnt);
       RETVALUE(ROK);
     }

   }

   statusCode = 0;
   switch (evnt->eventType.val)
   {
      case SOT_ET_INVITE: /* so039.201: Added: Fall through */
         /* so024.201: Save tcm connection for rsp retx */
#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
         {
         SoRspCb     *rspCb;
         SoTcmConn   *tcmConn;

         rspCb = &cLeg->rspCb;
         tcmConn = &rspCb->tcmConn;

        /*- so033.201: We don't have to initialize connection structure *
         *             every time                                       */

         soPrcUpdateTcmConn (tcmConn, transCb->tcmConn.clientCb, transCb->tcmConn.serverCb);
         }
#endif
      case SOT_ET_MODIFY:
        statusCode = soUaInviteInd(cLeg, evnt);
        break;
      case SOT_ET_ACK:
        statusCode = soUaAckInd(cLeg, evnt);
        break;
      case SOT_ET_CANCEL:
        statusCode = soUaCancelInd(cLeg, evnt);
        break;
      case SOT_ET_BYE:
        statusCode = soUaByeInd(cLeg, evnt);
        break;
      case SOT_ET_INFO:
        statusCode = soUaInfoInd(cLeg, evnt);
        break;
      case SOT_ET_PRECON_MET:
        statusCode = soUaCometInd(cLeg, evnt);
        break;
      case SOT_ET_OPTIONS:
        statusCode = soUaOptionsInd(cLeg, evnt);
        break;
#ifdef SO_RFC_3262
      case SOT_ET_PRACK:
        statusCode = soUaPrackInd(cLeg, evnt);
        break;
#endif
#ifdef SO_UPDATE
      case SOT_ET_UPDATE:
        statusCode = soUaUpdateInd(cLeg, evnt);
        break;
#endif
      case SOT_ET_UNKNOWN:
        statusCode = soUaUnknownInd(cLeg, evnt);
        break;
#ifdef SO_INSTMSG
      case SOT_ET_MESSAGE:
        statusCode = soUaMessageInd(cLeg, evnt);
        break;
#endif
#ifdef SO_EVENT
      case SOT_ET_SUBSCRIBE:
        statusCode = soUaSubscInd(cLeg, evnt, transCb);
        break;

      case SOT_ET_NOTIFY:
        statusCode = soUaNotifyInd(cLeg->call->ssapCb, cLeg, 
                                   evnt, transCb);
        break;
#ifdef SO_REFER
      case SOT_ET_REFER:
        statusCode = soUaReferInd(cLeg, evnt, transCb);
        break;
#endif /* SO_REFER */
#endif /* SO_EVENT */
      /* so011.201: Support to handle REGISTER message at UAC. The 
         feature has been added under the flag SO_XX_UA_PRC_REGISTER. */
#ifdef SO_XX_UA_PRC_REGISTER
      case SOT_ET_REGISTER:
         statusCode = soUaRegisterInd(cLeg, evnt);
         break;
#endif /* SO_XX_UA_PRC_REGISTER */
   }

   /* SOT_RSP_ERROR is send if the sending of response  has failed inside any of the
      above functions */
   if (statusCode == SOT_RSP_ERROR)
   {  
     SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
         "\n[Dialog] Core Layer Can't Process Incoming Request"));
     RETVALUE(RFAILED);
   }

   /* statuscode != SOT_RSP_NONE means an error response needs to be sent */
   if (statusCode != SOT_RSP_NONE)
   {
      SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
                 " [Dialog] Sending Error Response \n"));

     /* so012.201: Call soDlgSendResponse directly to sent response */

      /* so031.201: Added transCb argument*/
      ret = soDlgSendResponse (cLeg, transCb, evnt, statusCode, SO_EXTRSP_NONE);
      if (ret != ROK)
         RETVALUE(RFAILED);

      soCmFreeEvent(evnt);
      RETVALUE (ROK);
     /*  SO_UA_SEND_ERR_RSP(cLeg, transCb, evnt,statusCode, SO_EXTRSP_NONE); */
   }

   RETVALUE (ROK);
}

/*****************************************************************************
*
*       Fun  : soDlgCreateCLegFromCLeg
*
*       Desc : Creates a new call leg based on an existing one.
*              This is needed if the UA receives multiple (forked)
*              responses
*          
*
*       Ret  : ROK it is in. 
*              RFAILED not in. 
*
*       Notes: 
*
*
*       File:  po_dlg.c
*
*****************************************************************************/
#ifdef ANSI
PUBLIC S16 soDlgCreateCLegFromCLeg
(
SoCLegCb   *prevCLeg,    /* Existing call leg */
SoCLegCb   **newCLeg,    /* New Call Leg */
SoEvnt     *evnt         /* Event */
)
#else
PUBLIC S16 soDlgCreateCLegFromCLeg(prevCLeg, newCLeg, evnt)
SoCLegCb   *prevCLeg;    /* Existing call leg */
SoCLegCb   **newCLeg;    /* New Call Leg */
SoEvnt     *evnt;        /* Event */
#endif
{
  S16          ret;
  U16          i;
  SoCLegCb     *tmpCLeg;    /* Temp call leg */
  SoCallCb     *callCb;     /* Call Cb */
  SoCSeq       *cSeq;
  SoAddress    *to;

  TRC3(soDlgCreateCLegFromCLeg);

  *newCLeg = NULLP;
  callCb = prevCLeg->call;

  tmpCLeg = soDlgInitCLeg (callCb, evnt, SO_USER);
  if (tmpCLeg == NULLP)
    RETVALUE(RFAILED);


  if (soCmFindHdrChoice(evnt, (U8 **) &cSeq, SO_HEADER_GEN_CSEQ) != ROK)
  {
    soDlgDeleteCleg(callCb, tmpCLeg);
    RETVALUE(RFAILED);
  }

 /* Find From header in the event structure */
  ret = soCmFindHdrChoice(evnt, (U8 **) &to,
                          SO_HEADER_GEN_TO);
  if (ret != ROK)
  {
    soDlgDeleteCleg(callCb, tmpCLeg);
    RETVALUE(RFAILED);
  }

  /* Store required call leg Info */
  /* Copy the to header received in the incoming response. All the
     other headers can be copied from the original call leg */
  ret = soDlgUpdOutClegInfo(tmpCLeg, evnt, to,
                            &prevCLeg->storedHdrs.localAddr, 
                            prevCLeg->storedHdrs.cSeqHiTx,
                            SO_INTERNAL);
  if (ret != ROK)
  {
    soDlgDeleteCleg(callCb, tmpCLeg);
    RETVALUE(RFAILED);
  }

  /* Update the To Tag in the call leg */
  /* Store the Remote Tag, if present */
 
  for (i = 0; i < SO_GET_NUM_COMP(&to->addrParams.numComp); i++)
  {
    /* Check to see if it is a tag */
    if (SO_CMP_TKN_LIT(&to->addrParams.addrParam[i]->addrParamType,
                       SO_ADDRPARAM_TAGPARAM) == TRUE)
    {
      ret = soUtlCpyTknStrOSXL(&tmpCLeg->storedHdrs.remoteTag,
                               &to->addrParams.addrParam[i]->t.tagParam,
                               NULLP);
      if (ret != ROK)
      {
        soDlgDeleteCleg(callCb, tmpCLeg);
        RETVALUE(RFAILED);
      }
      break;
    }
  }

  /* Update the From Tag in the new call leg. It will be the same as the previous
     call leg */
  ret = soUtlCpyTknStrOSXL(&tmpCLeg->storedHdrs.localTag,
                           &prevCLeg->storedHdrs.localTag,
                           NULLP);
  if (ret != ROK)
  {
    soDlgDeleteCleg(callCb, tmpCLeg);
    RETVALUE(RFAILED);
  }

  /* so033.201: Initialize cSeqHiRx to '0' for a new dialog being created, 
     instea of recieved CSeqVal */
  tmpCLeg->storedHdrs.cSeqHiRx = SO_CSEQ_NONE_RECD;
  /* so004.201 : Copy Session Timer data from previous leg */
#ifdef SO_SESSTIMER
  soCmInitTimer(&tmpCLeg->sessTmrCb.sessExpTmr);
  cmMemcpy((U8 *)&tmpCLeg->sessTmrCb,
           (U8 *)&prevCLeg->sessTmrCb,
           sizeof(SoSessTmrCb));
#endif /* SO_SESSTIMER */

  /* Set new leg state to initial */
  tmpCLeg->clegState = SO_CLEG_STATE_INITIAL;

  *newCLeg = tmpCLeg;

 /*------ so017.201: Added print during dialog creation --------*/
  SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
   "\n[Dialog] DIALOG Created => Entity(%d)  Call(%ld) CallLeg(%lx)",
   callCb->ent->entId, callCb->spConnId, tmpCLeg->legId));

  RETVALUE(ROK);
}




/*
*
*       Fun:   soDlgChkMandUaIncHdr
*
*       Desc:  This function validates the mandatory
*              headers in an incoming  request message
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgChkMandUaIncHdr
(
SoEntCb    *ent,     /* Entity cb */
SoCLegCb   *cLeg,    /* Call Leg Cb */
SoEvnt     *evnt     /* Event  */
)
#else
PRIVATE S16 soDlgChkMandUaIncHdr(ent, cLeg, evnt)
SoEntCb    *ent;     /* Entity cb */
SoCLegCb   *cLeg;    /* Call Leg Cb */
SoEvnt     *evnt;    /* Event  */
#endif
{
  S16        ret;         /* return value */
  Bool       found;       /* Tag found */
#ifdef SO_REPLACES
  SoReplaces   *soReplaces;
  Bool         dupPrsnt;
#endif
  SoTimestamp *timestamp;  /* so028.201 */

  TRC3(soDlgChkMandUaIncHdr);

#ifdef SO_REPLACES
  dupPrsnt  = FALSE;
#endif

  found = FALSE;
  ret = SOT_RSP_NONE;


  ret = soUtlChckSipUrls(evnt);
  if (ret != ROK)
  {
    ent->otherSts.nmbUnsupUri++;
    soCb.sts.otherSts.nmbUnsupUri++;
    RETVALUE(SOT_RSP_416_UNSPRTD_URI_SCHEME);
  } 

 
   /* Check for Require Headers and see if we support what is requested */
  if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
  {
    /* so028.201 : Check if timestamp header is included in the INVITE req. 
      If yes, then save the crnt time in callleg. This value will be used to 
      calculate the delay while sending 100 trying response */
    if (evnt->eventType.val == SOT_ET_INVITE)
    {
       ret = soCmFindHdrChoice (evnt, (U8 **) &timestamp, 
                                    SO_HEADER_GEN_TIMESTAMP);
       if (ret == ROK)
       {
          /* Timestamp header is present in the incoming invite req. */

          /* copy the timestamp to CLEG */
          cLeg->timestamp.pres.pres = PRSNT_NODEF;

          cLeg->timestamp.timestampVal.pres = timestamp->timestampVal.pres;
          cLeg->timestamp.timestampVal.val = timestamp->timestampVal.val;
          cLeg->timestamp.timestampFrac.pres = timestamp->timestampFrac.pres;
          cLeg->timestamp.timestampFrac.val = timestamp->timestampFrac.val;


          ret = SGetRefTime(0, &cLeg->sec, &cLeg->usec);
          if (ret != ROK)
             RETVALUE(SOT_RSP_ERROR);
       }
    }
    if (ent != NULLP)
    {  
      ret = soUtlCheckRequire(ent, evnt);
      if (ret != ROK)
        RETVALUE(SOT_RSP_420_BAD_EXTENSION);
    }
  }

#ifdef SO_REPLACES
  /* check if replaces header present in non-Invite requests
   * and check if more than one repelaces header present */
  ret = soCmFindHdrChoice (evnt, (U8 **) &soReplaces,
                            SO_HEADER_REQ_REPLACES);
   
  if (ret == ROK)
  {
     ret = soCmFindHdrDup (evnt,SO_HEADER_REQ_REPLACES, &dupPrsnt);
     if((dupPrsnt) || (evnt->eventType.val != SOT_ET_INVITE))
       RETVALUE(SOT_RSP_400_BAD_REQUEST);
  }      
#endif /* SO_REPLACES */

  RETVALUE(SOT_RSP_NONE);
}




/************************************************************
            Dialog Module Call Back Functions.
************************************************************/
/*
*
*       Fun:   soDlgDnsReqCallback
*
*       Desc:  Call back function invoked by DNS module
*              when a async query is complted
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC Void soDlgDnsReqCallBack
(
PTR          userCtxt,  /* User Context */
U8           queryType, /* Query Type */
CmTptAddr    *tptAddr,  /* Transport Address */
U8           tptProt,   /* Transport Protocol */
SoAddress    *addr      /* Address for NAPTR Query */
)
#else
PUBLIC Void soDlgDnsReqCallBack(userCtxt, queryType, tptAddr, tptProt, addr)
PTR          userCtxt;  /* User Context */
U8           queryType; /* Query Type */
CmTptAddr    *tptAddr;  /* Transport Address */
U8           tptProt;   /* Transport Protocol */
SoAddress    *addr;     /* Address for NAPTR Query */
#endif
{
  S16          ret;
  SoEvnt       *evnt;
  SoTransCb    *transCb;
  SoCLegCb     *cLeg;
  /* so024.201 : If callleg needs to be cleared, clear it */
  SoSSapCb     *ssapCb;
  UConnId      suConnId;
  UConnId      spConnId;
  Bool         callCleared;

  TRC3 (soDlgDnsReqCallBack);

  transCb = NULLP;
  cLeg    = NULLP;
  ret     = ROK;

  evnt    =  ((SoUserCtxt *)userCtxt)->evnt;

  if (evnt == NULLP)
     /* 
      * so009.201: Event as NULLP indicates that this functions has
      * already been called before for this DNS query. We should i-
      * gnore this call.
      */
      RETVOID;

 /*--- so009.201: QueryCb Is No Longer Needed For ACK Request ---*/
  if (evnt->eventType.val == SOT_ET_ACK)
  {
     cLeg = (SoCLegCb *)(((SoUserCtxt *)userCtxt)->userPtr);
     
    /*----- Release DNS QueryCb Block -----*/
#ifdef SO_DNS
    soDnsLookupRel ((PTR)cLeg->ackCb.dnsQuery);
#endif
     cLeg->ackCb.dnsQuery = NULLP;
  }
  /* so032.201: Save pointer to transaction and dialog */
  {
     transCb = (SoTransCb *)(((SoUserCtxt *)userCtxt)->userPtr);
     cLeg    = (SoCLegCb *)transCb->cLeg;
  }
 
  /* 
   * If DNS query went correctly, send out the message to
   * the newly resolved address.
   */
  if (queryType != SO_DNS_ADDR_TYPE_ERROR)
  {
     ret = soDlgPrcUaOutReq ((SoUserCtxt *)userCtxt, tptAddr, tptProt);
     if (ret == ROK)
       RETVOID;
  }
  
  /*------------- DNS Procedure was failure -----------*/

  /*-- Release stored DNS info & send errInd to user --*/

  if (evnt->eventType.val != SOT_ET_ACK)
  {
     /* so032.201: userPte may be null now */
     if (((SoUserCtxt *)userCtxt)->userPtr != NULLP)
     {
        /* so032.201: This implies that transaction has already been deleted */
        transCb = (SoTransCb *)(((SoUserCtxt *)userCtxt)->userPtr);
        cLeg    = (SoCLegCb *)transCb->cLeg;

        /*----- Release DNS QueryCb Block -----*/
#ifdef SO_DNS
        SO_TXN_DEL_QUERYCB (transCb)
#endif

        /*--- Event will be passed to user ----*/
        transCb->evnt = NULLP;

       /*---- Finally delete transaction -----*/
        soTxnDeleteTrans (transCb);
     }
  }

  SO_UA_CLEAR_STORED_EVNT (cLeg, evnt);

  /* so024.201: Clear contactCb */
  if (evnt->eventType.val == SOT_ET_REGISTER)
  {
     SO_UA_CLEAR_CONTACTS (cLeg, evnt);
  }

  /* so024.201 : If callleg needs to be cleared, clear it */
  ssapCb    = cLeg->call->ssapCb;
  suConnId  = cLeg->userConnId;
  spConnId  = cLeg->call->spConnId;

  /* so032.201: This may happen in initial state as well */
  if (cLeg->clegState == SO_CLEG_STATE_NONE ||
      cLeg->clegState == SO_CLEG_STATE_INITIAL)
  {
    if (soDlgChkAndDelCLeg (cLeg) != ROK)
       callCleared = FALSE;
    else
       callCleared = TRUE;
  }
  
  /* Send an error indication to the user */
  /* so009.201 : so024.201  Used user conn id instead of suConnId in callCb */
  /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
  {
     Bool intMsg = FALSE;

     if (evnt->eventType.val == SOT_ET_REGISTER)
     {
        intMsg = ((SoUserCtxt *)userCtxt)->intMsg;
     }

     soUiErrInd (ssapCb,
           suConnId, 
           spConnId,
           evnt,
           evnt->callLegId, 
           evnt->eventType.val,
           SOT_ERR_DNS_FAILED,
           callCleared,
           intMsg);
  }
#else
  soUiErrInd (ssapCb,
              suConnId, 
              spConnId,
              evnt,
              evnt->callLegId, 
              evnt->eventType.val,
              SOT_ERR_DNS_FAILED,
              callCleared); 
#endif

  RETVOID;

}

/*
*
*       Fun:   soDlgDnsRspCallBack
*
*       Desc:  Call back function invoked by DNS module
*              when a async query for address resolution
*              is complted. The DNSquerying is 
*              invoked when the default proxy address is 
*              of domain name format and the UA only
*              allows incoming request from a default proxy.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE Void soDlgDnsRspCallBack
(
PTR          userCtxt,  /* User Context */
U8           queryType, /* Query Type */
CmTptAddr    *tptAddr,  /* Transport Address */
U8           tptProt,   /* Transport Protocol */
SoAddress    *addr       /* Address for NAPTR Query */
)
#else
PRIVATE Void soDlgDnsRspCallBack(userCtxt, queryType, tptAddr, tptProt, addr)
PTR          userCtxt;  /* User Context */
U8           queryType; /* Query Type */
CmTptAddr    *tptAddr;  /* Transport Address */
U8           tptProt;   /* Transport Protocol */
SoAddress    *addr;      /* Address for NAPTR Query */
#endif
{
  S16         ret;
  SoTransCb   *transCb;   /* Transaction Control Block */
  SoCLegCb    *cLeg;
  SoCallCb    *callCb;
  SoHost      *inHost;
  U32         inPort;  
  CmTptAddr   viaAddr;
  Bool        addrMatch;
  SoEvnt      *evnt;

  TRC3(soDlgDnsRspCallBack);

  transCb = (SoTransCb *) (((SoUserCtxt *)userCtxt)->userPtr);
  evnt    = ((SoUserCtxt *)userCtxt)->evnt;
  cLeg    = (SoCLegCb *)transCb->cLeg;
  callCb  = cLeg->call;

  /*----- Release DNS QueryCb Block -----*/
#ifdef SO_DNS
     SO_TXN_DEL_QUERYCB (transCb)
#endif

  if (queryType != SO_DNS_ADDR_TYPE_ERROR)
  {
     ret = soCmGetAddrFromVia (evnt, &inHost, &inPort);

     if (soCmHostPortToTptAddr (inHost, inPort, &viaAddr) != ROK)
       goto SODLGDNSRSPCALLBACK;

     if (soCmpTptAddr (tptAddr, &viaAddr, &addrMatch) != ROK)
       goto SODLGDNSRSPCALLBACK;

   /* so029.201: Application should be informed only for           *
    * successful cases                                             */
     ret = soDlgPrcUaIncReq (transCb, evnt);
     if (ret != ROK)
       (Void) soCmFreeEvent (evnt);

     RETVOID;
  }


SODLGDNSRSPCALLBACK:
 
 /*--------- so029.201: No Dialog State Update Is Required --------*/

  cLeg->noStateUpd = TRUE;

  /* so031.201: Added transCb argument*/
  ret = soDlgSendResponse (cLeg,
                           transCb,
                           evnt,
                           SOT_RSP_305_USE_PROXY,
                           SO_EXTRSP_NONE);
  cLeg->noStateUpd = FALSE;

  if (ret != ROK)
     soDlgChkAndDelCLeg (cLeg);    

  soCmFreeEvent (evnt);

  RETVOID;
}





/*
*
*       Fun:   soDlgEncodeReqCallBack 
*
*       Desc:  Call back function invoked by the transaction/ transport 
*              layer after encode is completed by a multi-threaded
*              encoder/ decoder
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC Void soDlgEncodeReqCallBack
(
PTR      cLegPtr,   /* Pointer to call Leg */
SoEvnt   *evnt,     /* original Event */
U8       transport, /* Transport Type */
Buffer   *mBuf,     /* Encoded Message */
Bool     success    /* Encoding succesful/not */
)
#else
PUBLIC Void soDlgEncodeReqCallBack(cLegPtr, evnt, transport, mBuf, success)
PTR      cLegPtr;   /* Poibnter to call Leg */
SoEvnt   *evnt;     /* original Event */
U8       transport; /* Transport Type */
Buffer   *mBuf;     /* Encoded Message */
Bool     success;   /* Encoding succesful/not */
#endif
{

   SoCLegCb      *cLeg;   /* Call Leg pointer */

   TRC3(soDlgEncodeReqCallBack);

   cLeg = (SoCLegCb *)cLegPtr;

   /* If Encode has failed */
   if (!success)
   {
     SO_UA_CLEAR_STORED_EVNT(cLeg, evnt);

     /* Send an error indication to the user */
     /* so009.201 : Used user conn id instead of suConnId in callCb */
     /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
     soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
                cLeg->call->spConnId, 
                evnt, evnt->callLegId,
                evnt->eventType.val, SOT_ERR_ENC, FALSE, FALSE); 
#else
     soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
                cLeg->call->spConnId, 
                evnt, evnt->callLegId,
                evnt->eventType.val, SOT_ERR_ENC, FALSE); 
#endif
   }
   
   /* If encode was succesful store reqd values in the call leg */
   else if (cLeg != NULLP)
   {
     if (transport != cLeg->ackCb.transport)
       cLeg->ackCb.modifyTpt = TRUE;

     cLeg->ackCb.transport = transport;

     cLeg->ackCb.mBuf = mBuf;
     /* Release the event strucure */
     (Void) soCmFreeEvent(evnt);     
   }
       
   RETVOID;
}






/*
*
*       Fun:   soDlgEncodeRspCallBack 
*
*       Desc:  Call back function invoked by the transaction/ transport 
*              layer after encode is completed by a multi-threaded
*              encoder/ decoder, for 1xx and 2xx response for INVITE.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC Void soDlgEncodeRspCallBack
(
SoCLegCb *cLeg,     /* Pointer to call Leg    */
SoEvnt   *evnt,     /* Event Strcuture        */
Buffer   *mBuf     /* Encoded Message        */
)
#else
PUBLIC Void soDlgEncodeRspCallBack(cLeg, evnt, mBuf)
SoCLegCb *cLeg;     /* Pointer to call Leg    */
SoEvnt   *evnt;     /* Event Strcuture        */
Buffer   *mBuf;     /* Encoded Message */
#endif
{
   U16   responseClass; /* Response Class */
#ifdef SO_RFC_3262
   S16   ret;           /* Return Value */
#endif

   TRC3(soDlgEncodeRspCallBack);


   if ((cLeg == NULLP) || (mBuf == NULLP))
   {
     RETVOID;
   }

   responseClass = (evnt->t.response.statusLine.statusCode.val)/100;

   /* if 1xx */
   if (responseClass < SO_STACODE_TYPE_SUCCESS)
   {
     cLeg->sentRsp = mBuf;

#ifdef SO_RFC_3262
     ret = soUaPrcSent1xxInfo(cLeg, evnt, NULLP);
     if (ret == ROK)
       RETVOID;
     else
#endif
     {
       (Void) SPutMsg(mBuf);
     }

    /*so041.201: Reset the pointer set in beguning of block */
     cLeg->sentRsp = NULLP;

   }
   
   /* if 2xx */
   else if (responseClass == SO_STACODE_TYPE_SUCCESS)
   {
     SO_PRC_OUT_2XX_INFO(cLeg, mBuf); 
   }
   else
     (Void) SPutMsg(mBuf);

   RETVOID;
}





/*
*
*       Fun:   soDlgErrInd
*
*       Desc:  This function is invoked by the transaction layer
*              when an error is encountered in the sending of a
*              request/ response.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PUBLIC Void soDlgErrInd
(
SoCLegCb   *cLeg,     /* Call Leg Cb */
U8         errType,   /* Error Type */
SoEvnt     *evnt,     /* Event Strcuture */
SoUserCtxt *userCtxt  /* User Context */
)
#else
PUBLIC Void soDlgErrInd(cLeg, errType, evnt, userCtxt)
SoCLegCb   *cLeg;     /* Call Leg Cb */
U8         errType;   /* Error Type */
SoEvnt     *evnt;     /* Event Strcuture */
SoUserCtxt *userCtxt; /* User Context */
#endif
{
  S16        ret;
  Bool       callCleared;
  UConnId    suConnId;
  UConnId    spConnId;
  SoTransCb  *transCb;
  SoCallCb   *callCb;
  SoSSapCb   *ssapCb; 
  SoUserCtxt dnsUserCtxt;
  SoCSeq      *cSeq;   /* so041.201  */

  TRC3(soDlgErrInd);

  ret     = ROK;
  transCb = NULLP;
  cmMemset ((U8 *)&dnsUserCtxt, 0, sizeof (SoUserCtxt));

  switch (errType)
  {
    case SO_TRANS_REQ_ENC_FAILED:
    case SO_TRANS_RSP_ENC_FAILED:
      /*-------- Send an error indication to the user ---------*/

      SO_UA_CLEAR_STORED_EVNT(cLeg, evnt);

      /* so009.201 : Used user conn id instead of suConnId in callCb */
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
                 cLeg->call->spConnId, 
                 evnt, evnt->callLegId, 
                 evnt->eventType.val, SOT_ERR_ENC, FALSE, userCtxt->intMsg); 
#else
      soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
                 cLeg->call->spConnId, 
                 evnt, evnt->callLegId, 
                 evnt->eventType.val, SOT_ERR_ENC, FALSE); 
#endif
      break;

    /*------ so021.201: Added Case For Transport Failure ------*/
    case SO_TRANS_ERROR:
      /*-------- Send an error indication to the user ---------*/

      SO_UA_CLEAR_STORED_EVNT(cLeg, evnt);

      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      /* so026.201, Internal message should be passed */
      soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
                 cLeg->call->spConnId, 
                 evnt, evnt->callLegId, 
                 evnt->eventType.val, SOT_ERR_ENC, FALSE, userCtxt->intMsg); 
#else
      soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
                 cLeg->call->spConnId, 
                 evnt, evnt->callLegId, 
                 evnt->eventType.val, SOT_ERR_TIMEOUT, FALSE); 
#endif
      break;

    case SO_TRANS_NO_ACK:
      /*
       * This implies that no ACK was  received  for  a  non  2xx
       * response. In such a case release the call leg, depending
       * on the state 
       */
      /*
       * so015.201: For some cases it is possible that 4xx, 5xx
       *  response was send without creating call-leg.
       */
       if (cLeg)
         soDlgChkAndDelCLeg (cLeg);

      break;

    case SO_TRANS_TIMEOUT:
      /* 
       * This implies that the sending of the transaction failed,
       * because there was no rsp. In  this case we can try other
       * addresses obtained during the DNS query(if any) to retry
       * the message sending 
       */

      if (userCtxt == NULLP)
         goto SODLGERRIND;

      /*
       * so041.201: Since request may be retried,we should update
       * the CSEQ header. It should be incremented by one.             
       */
      
       if (soCmFindHdrChoice (evnt, (U8 **) &cSeq, SO_HEADER_GEN_CSEQ) != ROK)
         goto SODLGERRIND;

       cSeq->cSeqVal.val += 1; 

       /*--- Update the dialog creating CSEQ Value ------------*/
       cLeg->storedHdrs.dlgCreateCSeq = cLeg->storedHdrs.cSeqHiTx;

#ifdef SO_COMPRESS
      if (userCtxt->sigCompSupp)
      {
        /*
         * If compression was used  to send  message, try sending
         * uncompressed message using a new transaction.
         */
         /*------ Delete compression context from event -------*/
         soUtlDeleteSigCompRef (evnt);

         /*-------- Send message using new transaction --------*/

         ret = soDlgRetryTrans (cLeg, 
                                evnt,
                                &userCtxt->destAddr, 
                                userCtxt->transport,
                                userCtxt);
         if (ret != ROK)
            goto SODLGERRIND;

         RETVOID;
      }
#endif
      /*
       * Check if we need to try another destination based on DNS
       * query. If yes, create new  transaction  to send  message.
       */
      if (userCtxt->queryCb == NULLP)
            goto SODLGERRIND;

      /* so016.201 : Do not allocate new transaction ID on DNS failure */
      /*--- Allocate new transaction ID ----*/
      /*
      SO_TXN_AllOC_TRANSID (evnt->transId, 
                            evnt->eventType.val,
                            cLeg->call->ent);
      */

      /*------ Create New Transction -------*/
      transCb = soTxnUaCreateTrans (cLeg->call->ssapCb->sys,
                                    SO_CLIENT, 
                                    evnt,
                                    (PTR)cLeg,
                                    userCtxt);
      if (transCb == NULLP)
      {
#ifdef SO_DNS
         soDnsLookupRel ((PTR)userCtxt->queryCb);
#endif
         goto SODLGERRIND;
      }

     /*
      * NOTE that ones new transaction is suc-
      * ccessfully created, DNS query  context
      * is saved in tranactionCb.
      */
      userCtxt->queryCb = NULLP;

      /*- Insert transaction into call leg -*/
          
      ret = cmHashListInsert (&cLeg->tranCbLst,
                              (PTR)transCb, 
                              (U8 *) &transCb->transId,
                              sizeof(U32));
      if (ret != ROK)
      {
         /* so039.201: Initialize cLeg of trans to NULLP, so that it is not 
            deleted from hash list */
         transCb->cLeg =  NULLP; 
         goto SODLGERRIND;
      }

#ifdef SO_DNS
#ifdef SO_TLS
      /*
       * Reset TLS  info  if  DNS has returned
       * TLS transport earlier.
       */
      /* so035.201: Do not reset TLS Info incase of SO_TLS_DNS */
      if (cLeg->secure == SO_TLS_DNS)
      {
         /* No need to reset headers as they are not changed in case of
          * secure flag being SO_TLS_DNS 
          */
           cLeg->secure = SO_TLS_NONE;
      }
#endif

      /*-- Store the transCb in  userCtxt --*/
      dnsUserCtxt.userPtr = (PTR)transCb;
      dnsUserCtxt.evnt    = evnt;

      /*-- Try Next destination from DNS  --*/
      ret = soDnsModuleTimeoutHandle ((PTR)&dnsUserCtxt,
                                      SO_TXN_GET_QUERYCB (transCb),
                                      SO_DNS_TRAN_TIMEOUT);
      if (ret != ROK)
         goto SODLGERRIND;
#endif

      /*- Rest of handling in DNS callback -*/
      RETVOID;

     /*- Inform Service User about timeout -*/

SODLGERRIND :
      if (transCb)
      {
        transCb->evnt = NULLP;
        soTxnDeleteTrans (transCb);
      }

      callCb = cLeg->call;        
      
      SO_UA_CLEAR_STORED_EVNT (cLeg, evnt);

      /* 
       * so015.201 : Add new  function  to Check  and Clear Internal
       * Context (if reqd) 
       */
      (Void) soUaChkAndClearIntCtxt (cLeg, evnt);

      /*
       * so009.201 : Used user conn id instead of suConnId in callCb
       */
      ssapCb    = callCb->ssapCb,
      suConnId  = cLeg->userConnId, 
      spConnId  = callCb->spConnId,

     /*---- Delete call leg if required ----*/
       ret = soDlgChkAndDelCLeg (cLeg);
       if (ret == ROK)
         /*----- Call Leg was deleted ------*/
         callCleared = TRUE;
       else
         callCleared = FALSE;

     /*- Send an error indication to  user -*/
       /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
       /* so026.201, Internal message should be passed */
       soUiErrInd (ssapCb,
                   suConnId, 
                   spConnId,
                   evnt, 
                   evnt->callLegId, 
                   evnt->eventType.val,
                   SOT_ERR_SENDING,
                   callCleared, userCtxt->intMsg);
#else
       soUiErrInd (ssapCb,
                   suConnId, 
                   spConnId,
                   evnt, 
                   evnt->callLegId, 
                   evnt->eventType.val,
                   SOT_ERR_SENDING,
                   callCleared); 
#endif

     /*------ End of TIMEOUT handling ------*/
       break;

    default:

     break;
  }

  RETVOID;
}

#ifdef SO_COMPRESS
/*
*
*       Fun:   soDlgRetryTrans
*
*       Desc:  This function create new client transaction  and 
*              passes the event to transaction staet machine.
*
*       Notes:  
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgRetryTrans
(
SoCLegCb   *cLeg,     /* Call Leg Cb     */
SoEvnt     *evnt,     /* Event Strcuture */
CmTptAddr  *destAddr, /* Destination addr*/
U8         transport, /* TCP/UDP         */
SoUserCtxt *userCtxt  /* User Context    */
)
#else
PRIVATE S16 soDlgRetryTrans (cLeg, evnt, destAddr, transport, userCtxt)
SoCLegCb   *cLeg;     /* Call Leg Cb     */
SoEvnt     *evnt;     /* Event Strcuture */
CmTptAddr  *destAddr; /* Destination addr*/
U8         transport; /* TCP/UDP         */
SoUserCtxt *userCtxt; /* User Context    */
#endif
{
  S16       ret;      /* Return Value */
  SoTransCb *transCb; /* Transaction cb */

  TRC3 (soDlgRetryTrans);

  ret     = ROK;

  /*--- Allocate new transaction ID ----*/
  SO_TXN_AllOC_TRANSID (evnt->transId, 
                        evnt->eventType.val,
                        cLeg->call->ent);

  /*------ Create New Transction -------*/
  transCb = soTxnUaCreateTrans (cLeg->call->ssapCb->sys,
                                SO_CLIENT, 
                                evnt,
                                (PTR)cLeg,
                                userCtxt);
  if (transCb == NULLP)
  {
#ifdef SO_DNS
      if (userCtxt->queryCb)
         soDnsLookupRel ((PTR)userCtxt->queryCb);
#endif
      RETVALUE (RFAILED);
  }

  /*- Insert transaction into call leg -*/
      
  ret = cmHashListInsert (&cLeg->tranCbLst,
                          (PTR)transCb, 
                          (U8 *) &transCb->transId,
                          sizeof(U32));
  if (ret != ROK)
  {
      transCb->cLeg  = NULLP;
      transCb->evnt  = NULLP;
      soTxnDeleteTrans (transCb);
      RETVALUE (RFAILED);
  }

  ret = soTxnUaOutReq (transCb, destAddr, transport);
  if (ret != ROK)
  {
      /* so039.201: Removed soTxnDeleteTrans since it already deleted in soTxnUaOutReq */
      RETVALUE (RFAILED);
  }

  RETVALUE (ROK);

} /* soDlgRetryTrans */

#endif /* SO_COMPRESS */

/************************************************************
            Dialog State Machine Functions
************************************************************/

/*
*
*       Fun:   soDlgUpdState
*
*       Desc:  Function updates the call state.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgUpdState
(
SoCLegCb     *cLeg,      /* Call Leg Cb */
SoEvnt       *evnt,      /* Event Cb */
U8           direction   /* Direction */
)
#else
PRIVATE S16 soDlgUpdState(cLeg, evnt, direction)
SoCLegCb     *cLeg;      /* Call Leg Cb */
SoEvnt       *evnt;      /* Event Cb */
U8           direction;   /* Direction */
#endif
{

  S16        ret;        /* Return  Value */

  TRC3(soDlgUpdState);

  if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
  {
    ret = soDlgUpdReqState(cLeg, evnt, direction);
  }
  else
    ret = soDlgUpdRspState(cLeg, evnt, direction);

  RETVALUE(ret);
} /* soDlgUpdState */




/*
*
*       Fun:   soDlgUpdReqState
*
*       Desc:  Function updates the call state.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgUpdReqState
(
SoCLegCb     *cLeg,      /* Call Leg Cb */
SoEvnt       *evnt,      /* Event Cb */
U8           direction   /* Direction */
)
#else
PRIVATE S16 soDlgUpdReqState(cLeg, evnt, direction)
SoCLegCb     *cLeg;      /* Call Leg Cb */
SoEvnt       *evnt;      /* Event Cb */
U8           direction;   /* Direction */
#endif
{

  U8         msgType;    /* Message Type */
  U8         legState;
  U8         prevLegState; /* Previous Leg State */

  TRC3(soDlgUpdReqState);

  prevLegState = cLeg->clegState;

  switch (evnt->eventType.val)
  {
    case SOT_ET_INVITE:
      if (cLeg->recurseCb.recursState != SO_RECURSION_ON)
        msgType = SO_MSG_INVITE;
      else
        msgType = SO_MSG_INVITE_RECURSION;
      break;
    case SOT_ET_CANCEL:
      /* An incoming Cancel should always be passed 
         to the UA core to handle, since a 200 OK needs
         to be sent out always */
      if (direction == SO_REMOTE)
        RETVALUE(SOT_ERR_NOERR);

      msgType = SO_MSG_CANCEL;
      break;
    case SOT_ET_INFO:
    case SOT_ET_PRECON_MET:
      msgType = SO_MSG_INFO;
      break;

    case SOT_ET_ACK:
      msgType = SO_MSG_ACK;
      break;

    case SOT_ET_BYE:
      /* On the UAC side a BYE can be sent in early/ 
         confirmed state and can be received only in 
         the Confirmed state . 
         On the UAS side, a BYE can be sent only in a 
         confirmed state and can be received any time 
         after it reaches an early state. */

      if (((cLeg->role == SO_CLIENT) && 
           (direction == SO_USER)) || 
          ((cLeg->role == SO_SERVER) && 
           (direction == SO_REMOTE)))
        msgType = SO_MSG_UAC_BYE;
      else
        msgType= SO_MSG_UAS_BYE;
      break;

#ifdef SO_RFC_3262
    case SOT_ET_PRACK:
      msgType = SO_MSG_PRACK;
#endif

#ifdef SO_UPDATE
    case SOT_ET_UPDATE:
      msgType = SO_MSG_UPDATE;
      break;
#endif

    case SOT_ET_OPTIONS:
#ifdef SO_INSTMSG
    case SOT_ET_MESSAGE:
#endif /* SO_INSTMSG */
#ifdef SO_EVENT
    case SOT_ET_SUBSCRIBE:
    case SOT_ET_NOTIFY:
#ifdef SO_REFER
    case SOT_ET_REFER:
#endif
#endif
      if (cLeg->call->sessCreatedBy == SOT_ET_INVITE)
      {
        /* there shoudl have no cLeg state change 
         * for event, refer and notify */ 
        RETVALUE(SOT_ERR_NOERR);
      }
      else
      {
        msgType = SO_MSG_CIM;
      }
      break;

    case SOT_ET_REGISTER:
    case SOT_ET_UNKNOWN:
      msgType = SO_MSG_CIM;
      break;
    default:
      msgType = SO_MSG_OTHER;
      break;
  }
  
  legState = soDlgUaReqFsm[msgType][cLeg->clegState];
  if (legState == SO_CLEG_STATE_ERROR)
  {
    SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
       "\n[Dialog] Call State Update Failure: Call(%ld) CallLeg(%lx)"
       " State(%d)",
       cLeg->call->spConnId, cLeg->legId, prevLegState));

    RETVALUE(SOT_ERR_CLEGSTATE_INVALID);
  }
  /* so029.201 : This is the case of retransmitted ACK's. No debug prints to be printed */
  if (legState == SO_CLEG_STATE_IGNORE)
  {
    SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
       "\n[Dialog] Call State Update : Call(%ld) CallLeg(%lx)"
       " State(%d)",
       cLeg->call->spConnId, cLeg->legId, legState));
    RETVALUE (ROKDNA);
  }

  cLeg->clegState = legState;

  SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
    "\n[Dialog] Call State Updated: Call(%ld), CallLeg(%lx)"
    " Prev State(%d) to New State(%d)",
    cLeg->call->spConnId, cLeg->legId, prevLegState, legState));

  RETVALUE(SOT_ERR_NOERR);
} /* soDlgUpdReqState */




/*
*
*       Fun:   soDlgUpdRspState
*
*       Desc:  Function updates the Response call state.
*
*       Notes:  
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgUpdRspState
(
SoCLegCb     *cLeg,      /* Call Leg Cb */
SoEvnt       *evnt,      /* Event Cb */
U8           direction   /* Direction */
)
#else
PRIVATE S16 soDlgUpdRspState(cLeg, evnt, direction)
SoCLegCb     *cLeg;      /* Call Leg Cb */
SoEvnt       *evnt;      /* Event Cb */
U8           direction;  /* Direction */
#endif
{
   U16       responseClass; /* Response Class */
   U8        legState;      /* Call Leg State */
   U8        rspType;       /* Response Type */
   U8        prevLegState; /* Previous Leg State */

   responseClass = evnt->t.response.statusLine.statusCode.val/100;
   prevLegState = cLeg->clegState;

   switch (responseClass)
   {
     case SO_STACODE_TYPE_INFORM:
       if (cLeg->storedHdrs.remoteTag.val != NULLP)
         rspType = SO_RSP_PROV_RSP_TAG;
       else
         rspType = SO_RSP_PROV_RSP_NOTAG;
       break;
     case SO_STACODE_TYPE_SUCCESS:
       rspType = SO_RSP_2XX;
       break;
     case SO_STACODE_TYPE_REDIR:
     case SO_STACODE_TYPE_CLERR:
     case SO_STACODE_TYPE_SRVERR:
     case SO_STACODE_TYPE_GLFAIL:
       rspType = SO_RSP_ERR;
       break;
   }
   
   legState = soDlgUaRspFsm[rspType][cLeg->clegState];

   if (legState == SO_CLEG_STATE_ERROR)
     RETVALUE(SOT_ERR_CLEGSTATE_INVALID);

   cLeg->clegState = legState;

  SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
    "\n[Dialog] Call State Updated: Call(%ld) CallLeg(%lx)"
    " Prev State(%d) to New State(%d)\n",
    cLeg->call->spConnId, cLeg->legId, prevLegState, legState));

   RETVALUE(SOT_ERR_NOERR);
}

#ifdef SO_TLS

/*
*
*       Fun:   soDlgChkOutTlsInfo
*
*       Desc:  Function checks the TLS info for the call
*
*       Notes: This function is called to check if the user 
*              requested a secure transport. The user can
*              specify a secure transport by specifying To
*              Header as SIPS Url. User may also specify
*              either one of the following as SIPS URL :
*              ReqUri, Contact.
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgChkOutTlsInfo
(
SoCLegCb     *cLeg,      /* Call Leg Cb */
SoEvnt       *evnt       /* Event Cb */
)
#else
PRIVATE S16 soDlgChkOutTlsInfo(cLeg, evnt)
SoCLegCb     *cLeg;      /* Call Leg Cb */
SoEvnt       *evnt;      /* Event Cb */
#endif
{
   SoAddrSpec * addrSpec;
   SoAddress * to;
 
   TRC3(soDlgChkOutTlsInfo)

   /* Check if User asked for TLS transport */

   /*--STEP 1 : Check if To Header is sips--*/
   if (soCmFindHdrChoice(evnt, (U8 **) &to, SO_HEADER_GEN_TO) == ROK)
   {
      if (to->pres.pres != NOTPRSNT)
      {
         if (to->addrCh.addrChType.pres != NOTPRSNT)
         {
            if (to->addrCh.addrChType.val == SO_ADDRCH_NAMEADDR)
               addrSpec = &(to->addrCh.t.nameAddr.addrSpec);
            else
               addrSpec = &(to->addrCh.t.addrSpec);
            
            if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
                (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPSURL))
               RETVALUE(ROK);
         }
      }
   }

   /* so027.201: Changes for SIP TLS support */
   /*--STEP 2 : Check if Request URI is sips--*/
   addrSpec = &evnt->t.request.requestLine.addrSpec;
   if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
       (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPSURL))
      RETVALUE(ROK);

   RETVALUE(RFAILED);
}


/*
*
*       Fun:   soDlgSetTlsInfo
*
*       Desc:  Function updates the TLS info for the call
*
*       Notes: The function updates the URL information for
*              the call. Following headers are updated for 
*              the call in cLeg and the event structure :
*              Contact, Route, RequestUri.
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgSetTlsInfo
(
SoCLegCb     *cLeg,      /* Call Leg Cb */
SoEvnt       *evnt       /* Event Cb */
)
#else
PRIVATE S16 soDlgSetTlsInfo(cLeg, evnt)
SoCLegCb     *cLeg;      /* Call Leg Cb */
SoEvnt       *evnt;      /* Event Cb */
#endif
{
   U16     hdrIdx;
   U16     cnt;
 
   SoRoute *route;
   SoRouteSeq *routeSeq;
 
   SoContact *contact;
   SoContactItem *contactItem;
 
   SoAddrSpec *addrSpec;

   /* so027.201: Changes to support SIP TLS */
   SoAddress *to;
   SoAddress *from;
   SoAddress *localAddr;
 
   TRC3(soDlgSetTlsInfo)

   /* Change all sip Headers to sips */

   /* so027.201: Changes to support SIP TLS */
   /*--STEP 1 : Set To Header In Event Structure--*/
   hdrIdx = 0;
   if (soCmFindHdrChoice(evnt, (U8 **) &to, SO_HEADER_GEN_TO) == ROK)
   {
      if (to->pres.pres != NOTPRSNT)
      {
         if (to->addrCh.addrChType.pres != NOTPRSNT)
         {
            if (to->addrCh.addrChType.val == SO_ADDRCH_NAMEADDR)
               addrSpec = &(to->addrCh.t.nameAddr.addrSpec);
            else
               addrSpec = &(to->addrCh.t.addrSpec);
            
            if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
                (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPURL))
               addrSpec->addrSpecType.val = SO_ADDRSPEC_SIPSURL;
         }
      }
   }

   /* so027.201: Changes to support SIP TLS */
   /*--STEP 2 : Set From Header In Event Structure--*/
   if (soCmFindHdrChoice(evnt, (U8 **) &from, SO_HEADER_GEN_FROM) == ROK)
   {
      if (from->pres.pres != NOTPRSNT)
      {
         if (from->addrCh.addrChType.pres != NOTPRSNT)
         {
            if (from->addrCh.addrChType.val == SO_ADDRCH_NAMEADDR)
               addrSpec = &(from->addrCh.t.nameAddr.addrSpec);
            else
               addrSpec = &(from->addrCh.t.addrSpec);
            
            if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
                (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPURL))
               addrSpec->addrSpecType.val = SO_ADDRSPEC_SIPSURL;
         }
      }
   }
   localAddr = &cLeg->storedHdrs.localAddr;
   if (localAddr->pres.pres != NOTPRSNT)
   {
      if (localAddr->addrCh.addrChType.pres != NOTPRSNT)
      {
         if (localAddr->addrCh.addrChType.val == SO_ADDRCH_NAMEADDR)
            addrSpec = &(localAddr->addrCh.t.nameAddr.addrSpec);
         else
            addrSpec = &(localAddr->addrCh.t.addrSpec);

         if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
               (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPURL))
            addrSpec->addrSpecType.val = SO_ADDRSPEC_SIPSURL;
      }
   }

   /*--STEP 3 : Set Route Header In Event Structure--*/
   while (soCmFindHdrStrtChIndex(evnt, (U8 **) &route, hdrIdx, &hdrIdx, SO_HEADER_REQ_ROUTE) == ROK)
   {
      if (route->numComp.pres != NOTPRSNT)
      {
         for (cnt = 0; cnt < route->numComp.val; cnt++)
         {
            routeSeq = route->route[cnt];
            if ((routeSeq->pres.pres != NOTPRSNT) &&
                (routeSeq->nameAddr.pres.pres != NOTPRSNT))
            {
               if (routeSeq->nameAddr.addrSpec.addrSpecType.pres != NOTPRSNT)
               {
                  if (routeSeq->nameAddr.addrSpec.addrSpecType.val == SO_ADDRSPEC_SIPURL)
                     routeSeq->nameAddr.addrSpec.addrSpecType.val = SO_ADDRSPEC_SIPSURL;
               }
            }
         }
      }
      hdrIdx++;
   }

   /*--STEP 4 : Set Route Header In cLeg--*/
   route = &(cLeg->storedHdrs.route);
   if (route->numComp.pres != NOTPRSNT)
   {
      for (cnt = 0; cnt < route->numComp.val; cnt++)
      {
         routeSeq = route->route[cnt];
         if ((routeSeq->pres.pres != NOTPRSNT) &&
             (routeSeq->nameAddr.pres.pres != NOTPRSNT))
         {
            if (routeSeq->nameAddr.addrSpec.addrSpecType.pres != NOTPRSNT)
            {
               if (routeSeq->nameAddr.addrSpec.addrSpecType.val == SO_ADDRSPEC_SIPURL)
                  routeSeq->nameAddr.addrSpec.addrSpecType.val = SO_ADDRSPEC_SIPSURL;
            }
         }
      }
   }

   /*-- STEP 5 : Set Contact Header in Event Structure--*/
   hdrIdx = 0;
   while (soCmFindHdrStrtChIndex(evnt, (U8 **) &contact,
          hdrIdx, &hdrIdx, SO_HEADER_GEN_CONTACT) == ROK)
   {  
      if (contact->pres.pres != NOTPRSNT)
      {
         if ((contact->contactDescType.pres != NOTPRSNT) &&
             (contact->contactDescType.val == SO_CONTACTDESC_CONTACTITEMS))
         {
            if (contact->contactItems.numComp.pres != NOTPRSNT)
            {
               for (cnt = 0; cnt < contact->contactItems.numComp.val; cnt++)
               {  
                  contactItem = contact->contactItems.contactItem[cnt];
                  if ((contactItem->pres.pres != NOTPRSNT) &&
                      (contactItem->contactAddrChoice.addrChType.pres != NOTPRSNT))
                  {  
                     if (contactItem->contactAddrChoice.addrChType.val == SO_ADDRCH_NAMEADDR)
                        addrSpec = &(contactItem->contactAddrChoice.t.nameAddr.addrSpec);
                     else
                        addrSpec = &(contactItem->contactAddrChoice.t.addrSpec);

                     if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
                        (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPURL))
                        addrSpec->addrSpecType.val = SO_ADDRSPEC_SIPSURL;
                  }
               }
            }
         }
      }

      hdrIdx++;
   }

   /*-- STEP 6 : Set Contact Header in cLeg--*/
   contact = &(cLeg->storedHdrs.localTrgtURI);
   if (contact->pres.pres != NOTPRSNT)
   {
      if ((contact->contactDescType.pres != NOTPRSNT) &&
          (contact->contactDescType.val == SO_CONTACTDESC_CONTACTITEMS))
      {
         if (contact->contactItems.numComp.pres != NOTPRSNT)
         {
            for (cnt = 0; cnt < contact->contactItems.numComp.val; cnt++)
            {  
               contactItem = contact->contactItems.contactItem[cnt];
               if ((contactItem->pres.pres != NOTPRSNT) &&
                   (contactItem->contactAddrChoice.addrChType.pres != NOTPRSNT))
               {  
                  if (contactItem->contactAddrChoice.addrChType.val == SO_ADDRCH_NAMEADDR)
                     addrSpec = &(contactItem->contactAddrChoice.t.nameAddr.addrSpec);
                  else
                     addrSpec = &(contactItem->contactAddrChoice.t.addrSpec);

                  if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
                     (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPURL))
                     addrSpec->addrSpecType.val = SO_ADDRSPEC_SIPSURL;
               }
            }
         }
      }
   }

   /*-- STEP 7 : Set ReqUri in Evnt structure and cLeg--*/
   addrSpec = &evnt->t.request.requestLine.addrSpec;
   /* so027.201: Changes for SIP TLS support */
   if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
       (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPURL))
   {  
      addrSpec->addrSpecType.val = SO_ADDRSPEC_SIPSURL;
      cLeg->storedHdrs.reqURI.addrSpecType.val = SO_ADDRSPEC_SIPSURL;
      cLeg->storedHdrs.origReqURI.addrSpecType.val = SO_ADDRSPEC_SIPSURL;
   }

   RETVALUE(ROK);
}


/*
*
*       Fun:   soDlgChkUpdTlsInfo
*
*       Desc:  Function updates the TLS info for the call
*
*       Notes:
*
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgChkUpdTlsInfo
(
SoCLegCb     *cLeg,      /* Call Leg Cb */
SoEvnt       *evnt,      /* Event Cb */
U8           secure
)
#else
PRIVATE S16 soDlgChkUpdTlsInfo(cLeg, evnt, secure)
SoCLegCb     *cLeg;      /* Call Leg Cb */
SoEvnt       *evnt;      /* Event Cb */
U8           secure;
#endif
{
   TRC3(soDlgChkUpdTlsInfo)

   if (cLeg->secure == SO_TLS_NONE)
   {
      /* Check who has requested the feature */
      if (secure == SO_TLS_DNS)
      {
         /* so035.201: Do not mark call secure, only that trasnport is TLS */
         cLeg->secure = SO_TLS_DNS;
      }
      /* Check if User asked for secure call */
      else if (soDlgChkOutTlsInfo(cLeg, evnt) == ROK)
      {
         /* Mark CallLeg as secure */
         cLeg->secure = SO_TLS_USER;
         soDlgSetTlsInfo(cLeg, evnt);
      }
   }
   /* so035.201: Do no change headers again */

   RETVALUE(ROK);
}

/* so035.201: soDlgResetTlsInfo not required, removed from code */


/*
*
*       Fun:   soDlgChkIncReqTlsInfo
*
*       Desc:  Function checks for the TLS info in incomming request
*
*       Notes: This function is called to check if the terminator 
*              used a secure transport for all hops. 
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgChkIncReqTlsInfo
(
SoCLegCb     *cLeg,      /* Call Leg Cb */
SoEvnt       *evnt       /* Event Cb */
)
#else
PRIVATE S16 soDlgChkIncReqTlsInfo(cLeg, evnt)
SoCLegCb     *cLeg;      /* Call Leg Cb */
SoEvnt       *evnt;      /* Event Cb */
#endif
{
   U16     hdrIdx;
   U16     cnt;
   S16     ret;
 
   SoContact *contact;
   SoContactItem *contactItem;
 
   SoRoute *route;
   SoRouteSeq *routeSeq;

   SoAddrSpec * addrSpec;
   SoAddress * to;

   SoVia      *via;       /* Via received */
   SoViaItem  *viaItem;   /* New via item  */

   TRC3(soDlgChkIncReqTlsInfo)

   ret = ROKDNA;

   /* Check if User has used TLS transport */
   /*--STEP 1 : Check if To Header is sips--*/
   if (soCmFindHdrChoice(evnt, (U8 **) &to, SO_HEADER_GEN_TO) == ROK)
   {
      if (to->pres.pres != NOTPRSNT)
      {
         if (to->addrCh.addrChType.pres != NOTPRSNT)
         {
            if (to->addrCh.addrChType.val == SO_ADDRCH_NAMEADDR)
               addrSpec = &(to->addrCh.t.nameAddr.addrSpec);
            else
               addrSpec = &(to->addrCh.t.addrSpec);

            if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
                (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPSURL))
               ret = ROK;
         }
      }
   }
   
   if (ret == ROKDNA)
     RETVALUE(ret);

   /* Let us check the call used TLS for all hops */
   /* so035.201: Do not check for TLS transport in Via header */
   /* because hops within the same domain may not be TLS */

   /*--STEP 2 : Check for Route Header In Event Structure--*/
   hdrIdx = 0;
   while (soCmFindHdrStrtChIndex(evnt, (U8 **) &route, hdrIdx, &hdrIdx, SO_HEADER_REQ_ROUTE) == ROK)
   {  
      if (route->numComp.pres != NOTPRSNT)
      {  
         for (cnt = 0; cnt < route->numComp.val; cnt++)
         {  
            routeSeq = route->route[cnt];
            if ((routeSeq->pres.pres != NOTPRSNT) &&
                (routeSeq->nameAddr.pres.pres != NOTPRSNT))
            {  
               if (routeSeq->nameAddr.addrSpec.addrSpecType.pres != NOTPRSNT)
               {  
                  if (routeSeq->nameAddr.addrSpec.addrSpecType.val != SO_ADDRSPEC_SIPSURL)
                     RETVALUE(RFAILED);
               }
            }
         }
      }
      hdrIdx++;
   }

   /*--STEP 3 : Check if ReqUri is sips--*/
   addrSpec = &evnt->t.request.requestLine.addrSpec;
   if ((addrSpec->addrSpecType.pres == NOTPRSNT) || 
       (addrSpec->addrSpecType.val != SO_ADDRSPEC_SIPSURL))
      RETVALUE(RFAILED);

   /*--STEP 4 : Check if Contact Header is sips--*/
   hdrIdx = 0;
   while (soCmFindHdrStrtChIndex(evnt, (U8 **) &contact, 
          hdrIdx, &hdrIdx, SO_HEADER_GEN_CONTACT) == ROK)
   {
      if (contact->pres.pres != NOTPRSNT)
      {
         if ((contact->contactDescType.pres != NOTPRSNT) &&
             (contact->contactDescType.val == SO_CONTACTDESC_CONTACTITEMS))
         {
            if (contact->contactItems.numComp.pres != NOTPRSNT)
            {
               for (cnt = 0; cnt < contact->contactItems.numComp.val; cnt++)
               {
                  contactItem = contact->contactItems.contactItem[cnt];
                  if ((contactItem->pres.pres != NOTPRSNT) &&
                      (contactItem->contactAddrChoice.addrChType.pres != NOTPRSNT))
                  {
                     if (contactItem->contactAddrChoice.addrChType.val == SO_ADDRCH_NAMEADDR)
                        addrSpec = &(contactItem->contactAddrChoice.t.nameAddr.addrSpec);
                     else
                        addrSpec = &(contactItem->contactAddrChoice.t.addrSpec);

                     if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
                        (addrSpec->addrSpecType.val != SO_ADDRSPEC_SIPSURL))
                        RETVALUE(RFAILED);
                  }
               }
            }
         }
      }
      hdrIdx++;
   }

   /* so035.201: No need to check for To header again */

   RETVALUE(ROK);
}


/*
*
*       Fun:   soDlgChkIncRspTlsInfo
*
*       Desc:  Function checks the TLS info for call response
*
*       Notes: 
*
*       File:  po_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgChkIncRspTlsInfo
(
SoCLegCb     *cLeg,      /* Call Leg Cb */
SoEvnt       *evnt       /* Event Cb */
)
#else
PRIVATE S16 soDlgChkIncRspTlsInfo(cLeg, evnt)
SoCLegCb     *cLeg;      /* Call Leg Cb */
SoEvnt       *evnt;      /* Event Cb */
#endif
{
   U16     hdrIdx;
   U16     cnt;
 
   SoContact *contact;
   SoContactItem *contactItem;
 
   SoRoute *route;
   SoRouteSeq *routeSeq;

   SoAddrSpec * addrSpec;

   TRC3(soDlgChkIncRspTlsInfo)

   /* Check if User has used TLS transport */

   /*--STEP 1 : Check for Record-Route Header In Event Structure--*/
   hdrIdx = 0;
   while (soCmFindHdrStrtChIndex(evnt, (U8 **) &route, hdrIdx, &hdrIdx, SO_HEADER_GEN_RECORDROUTE) == ROK)
   {  
      if (route->numComp.pres != NOTPRSNT)
      {  
         for (cnt = 0; cnt < route->numComp.val; cnt++)
         {  
            routeSeq = route->route[cnt];
            if ((routeSeq->pres.pres != NOTPRSNT) &&
                (routeSeq->nameAddr.pres.pres != NOTPRSNT))
            {  
               if (routeSeq->nameAddr.addrSpec.addrSpecType.pres != NOTPRSNT)
               {  
                  if (routeSeq->nameAddr.addrSpec.addrSpecType.val != SO_ADDRSPEC_SIPSURL)
                     RETVALUE(RFAILED);
               }
            }
         }
      }

      hdrIdx++;
   }

   /*--STEP 2 : Check if Contact Header is sips--*/
   hdrIdx = 0;
   while (soCmFindHdrStrtChIndex(evnt, (U8 **) &contact, 
          hdrIdx, &hdrIdx, SO_HEADER_GEN_CONTACT) == ROK)
   {
      if (contact->pres.pres != NOTPRSNT)
      {
         if ((contact->contactDescType.pres != NOTPRSNT) &&
             (contact->contactDescType.val == SO_CONTACTDESC_CONTACTITEMS))
         {
            if (contact->contactItems.numComp.pres != NOTPRSNT)
            {
               for (cnt = 0; cnt < contact->contactItems.numComp.val; cnt++)
               {
                  contactItem = contact->contactItems.contactItem[cnt];
                  if ((contactItem->pres.pres != NOTPRSNT) &&
                      (contactItem->contactAddrChoice.addrChType.pres != NOTPRSNT))
                  {
                     if (contactItem->contactAddrChoice.addrChType.val == SO_ADDRCH_NAMEADDR)
                        addrSpec = &(contactItem->contactAddrChoice.t.nameAddr.addrSpec);
                     else
                        addrSpec = &(contactItem->contactAddrChoice.t.addrSpec);

                     if ((addrSpec->addrSpecType.pres != NOTPRSNT) &&
                        /* so027.201: Changes for SIP TLS support */
                        (addrSpec->addrSpecType.val != SO_ADDRSPEC_SIPSURL))
                        RETVALUE(RFAILED);
                  }
               }
            }
         }
      }
      hdrIdx++;
   }

   RETVALUE(ROK);
}

#endif /* SO_TLS */


/* so012.201: New Function To Find Error Code To Be Send In State Check
              Failure Cases. */

/*
*
*       Fun:   soDlgFindStatusCode
*
*       Desc:  This functions is called when state check fails for
*              incoming message. It returns appropriate error code
*              to be sent in response.
*
*       Notes:
*
*
*       File:  so_dlg.c
*
*/
#ifdef ANSI
PRIVATE S16 soDlgFindStatusCode
(
U8           eventType, /* Event type     */
U8           clegState  /* Call leg state */
)
#else
PRIVATE S16 soDlgFindStatusCode(eventType, clegState)
U8           eventType; /* Event type     */
U8           clegState; /* Call leg state */
#endif
{
   TRC3(soDlgFindStatusCode)

   /* 
    * If Re-INVITE is received in Modify Pending State, Return
    * 491 Response.
    */
   if ((eventType == SOT_ET_INVITE) &&
       (clegState == SO_CLEG_STATE_MODIFY))
   {
      RETVALUE (SOT_RSP_491_RETRY_AFTER);
   }

   RETVALUE (SOT_RSP_500_SRV_INT_ERROR);

} /* soDlgFindStatusCode */

/* so013.201: New function to update Req Uri for session refresh */
/*
*
*       Fun:   soDlgUpdModReqUri
*
*       Desc:  Updates the request URI to be stored in the call leg for a 
*              re-INVITE message. Only the Req URI is updated and no shuffling
*              is done as Routes are not updated for re-INVITE.
*
*       Notes:  
*
*
*       File:  so_dlg.c
*
*/
#ifdef ANSI
PUBLIC S16 soDlgUpdModReqUri
(
SoCLegCb   *cLeg,     /* Call Leg */
SoEvnt     *evnt,     /* Event Cb */
U8         direction  /* Direction */
)
#else
PUBLIC S16 soDlgUpdModReqUri(cLeg, evnt, direction)
SoCLegCb   *cLeg;     /* Call Leg */
SoEvnt     *evnt;     /* Event Cb */
U8         direction; /* Direction */
#endif
{
   SoCLegHdrs    *cLegHdrs;   /* Headers stored in the call leg */
   S16           ret;         /* Return Values */
   SoRoute       *route;      /* Route informaion */
   SoAddrSpec    *addrSpec;   /* Address */
   U16           numComp;     /* Number of comp */

   TRC2(soDlgUpdModReqUri)

   UNUSED(direction);

   cLegHdrs = &cLeg->storedHdrs;

   /* Locate remote target URI */
   SO_ADDRSPEC_FROM_ADDRCH(addrSpec, &cLegHdrs->remoteTrgtURI.addrCh);

   /* Check whether reqUri is present in the reqURI field or the Route field */
   /* so014.201: For route as next hop, req uri should be copied */
   if (cLegHdrs->nextHopAddr == SO_NEXTHOP_ROUTE)
   {
      /* Present in reqURI field */
      /* Delete the existing ReURI before updating the cleg with the new one */
      soUtlDelSoAddrSpec(&cLegHdrs->reqURI);

      /* Update requestURI with remote targetURI */
      ret = soUtlCpySoAddrSpec(&cLegHdrs->reqURI, addrSpec, NULLP);
      if (ret != ROK)
         RETVALUE(RFAILED);
   }
   else
   {
      /* Req Uri as the last Route */
      route = &cLegHdrs->route;
      numComp = SO_GET_NUM_COMP(&route->numComp);

      /* so014.201: There might not be any routes */
      /* Delete the last most RouteSeq */
      if (numComp > 0)
      {
         soUtlDelSoRouteSeq(route->route[numComp - 1]);

         /* Update last route with remote targetURI */
         if (soUtlCpySoAddrSpec(&route->route[numComp-1]->nameAddr.addrSpec,
                          addrSpec, NULLP) != ROK)
            RETVALUE(RFAILED);
      }
      else /* If no route is present copy into ReqURI */
      {
         /* Delete the existing ReURI before updating the cleg with the new one */
         soUtlDelSoAddrSpec(&cLegHdrs->reqURI);

         /* Update requestURI with remote targetURI */
         ret = soUtlCpySoAddrSpec(&cLegHdrs->reqURI, addrSpec, NULLP);
         if (ret != ROK)
            RETVALUE(RFAILED);
      }
   }

   /* Strip unwanted parameters form the Request URI */
   (Void) soUtlStripUriParams(&cLegHdrs->reqURI);

   RETVALUE(ROK);
}

#endif /* SO_UA */

/********************************************************************30**

         End of file:     so_dlg.c@@/main/2 - Tue Apr 20 12:46:21 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/2      ---         pk    1. New release for 2.1 
/main/2+   so001.201     ps    1. Save the record route for request message
                                  at UAS. This  value  will  be  updated in 
                                  response message.
/main/2+   so004.201     up    1. Copy Session Timer data from previous leg
/main/2+   so006.201     ps    1. ACK Must Match To Invite Transaction
                         pk    2. Record-Route is to be added only for 
                                  18x or 2xx messages 
                         pk    3. Do not delete REGISTER cLeg.
                         pk    4. Delete any branchId in VIA.
           so007.201     ab    1. Added code for  condition where the UAS 
                                  might have crashed and restrated and then 
                                  it receives a message for an old call 
                                  whose context doesnot exist
           so008.201     up    1. Set return value.
           so009.201     ps    1. For retransmitted 2xx, call let state must
                                  be active.
                         pk    2. To support INFO outside a call.
                         ps    3. Delete queryCb For ACK request.
                         pk    4. Handling of suConnid in call leg Cb.
                         ps    5. Remote tag updation.
                         ps    6. Freeing ACK event structure.
/main/2+   so010.201     ab    1. ACK Must Match To Invite Transaction correction
/main/2+   so011.201     up    1. Do not update Req URI and Route for CANCEL
                         up    2. Added feature to update local tags if 
                                  provided by the user. The feature is added
                                  under flag SO_XX_UPD_LCL_TAGS.
                         ab    3. Passing parameter event type
                         up    4. Support to handle REGISTER message at UAC.
                                  The feature has been added under the flag 
                                  SO_XX_UA_PRC_REGISTER.
/main/2+   so012.201     ab    1. Do not update To tag for repsonse to CANCEL
                               2. Store all route sequences in outgoing call.
                         ps    3. New Function added  to  find  error code to 
                                  be send in state check failure cases.
                               4. Do not change dialogue state for internal
                                  responses. 
/main/2+   so013.201     up    1. New function soDlgUpdModReqUri to update 
                                  Req Uri in cLeg.
                               2. Release received event after ACK re-transmission.
                         ps    3. Pass 1XX Response to user.
                         ab    4. If no rec-route in inc rsp, del stored route.
/main/2+   so014.201     ps    1. ReqURI/route for INVITE saved in transaction to
                                  be used for CANCEL Request.
                               2. Functions to add "UserAgent"/"Server" header.
                               3. Allow CANCEL For RE-INVITE Request.
                         ab    4. For route as next hop, req uri should be copied
                         ab    5. Remove To tag for 100 response.
                         ps    6. Removed return at the end of soDlgValidateCLeg()
                                  as statement is never reached.
/main/2+   so015.201     ab    1. Do not update To tag for response to REGISTER
                         pk    2. Delete  registration  context  on transaction
                                  timeout.
                         ps    3. Function to add user-agent header made public.
                               4. For ACK timeout, dialog context can be NULLP. 
/main/2+   so016.201     ab    1. Correction for removing To Tag from 200 OK
                                  response to REGISTER.
                         sg    2. Do not allocate new transaction ID on DNS failure 
/main/2+   so017.201     ps    1. Dialog matching procedure modified.
/main/2+   so018.201     ps    1. Cleanup after allocation failure.
/main/2+   so020.201     sg    1. Check if there is enough resource, return 503 
                                  when the stack runs low on resources
/main/2+   so021.201     ab    1. Added Case For Transport Failure in ErrInd. 
/main/2+   so021.201     ss    1. Added parameters in branch Id generation
/main/2+   so023.201     ad    1. To generate "To" tag without CLEG 
/main/2+   so024.201     ab    1. Clear contactCb on dns timeout for registraton.
                         ab    2. Save tcmConn in respCb for rsp retx in NAT case
                         ab    3. If callleg needs to be cleared, clear it on DNs timeout
/main/2+   so024.201     ss    1. Changed making of Trgt URI under the flag
/main/2+   so025.201     ab    1. For 1.2 interface pass if internal message
/main/2+   so025.201     ps    1. Correct deletion of subscription state machine
/main/2+   so026.201     ab    1. Passed internal message in soDlgErrInd
/main/2+                 ps    2. Subcription control block should be deleted
                                  only after ists last reference to TCB is
                                  removed.
/main/2+   so027.201     ab    1. Changes for SIP TLS support
                               2. Transition from initial to initial should
                                  be allowed to handle DNS cases
/main/2+   so028.201     ss    1. Added timestamp header in the outgoing message
                                  Calculated and added timestamp delay.
                         ss    2. Added parameter for via in branchId generation
/main/2+   so029.201     ps    1. No dialog state update required while sending
                                  proxy require error response.
                         ab    2. Check for transaction type as well while
                                  locating transCb
                         ss    3. Include TO tag in case 100 trying is sent 
                                  for modify request
                               4. Function added to close all pending txn
                               5. Added code for Ignore state of callleg
/main/2+   so030.201     ss    1. Send ErrInd to App in case of rsp dialog match fail
/main/2+   so031.201     aj    1. Added the check for the CSeq in the incoming request
/main/2+   so032.201     ng    1. userPtr may be null when soDlgPrcUaOutReq fails in
                                  soDlgDnsReqCallBack, handled that.
                               2. In soDlgDnsReqCallBack, even in initial cleg state
                                  dialog should be checked for deletion(ab).
/main/2+   so033.201     ng    1. Updated Cseq in stored headers for Clegs (ss)
                                  created by SO_USER
                         ng    2. Added proper initialzation/deletion of client/server(ps)
                                  connection information for ACk CB.
                         ng    3. Changed the return value to ROK in case the (ss)
                                  ErrInd is given to application
                         ng    4. Offer-answer in Subsequent Provisional/Normal Response(ad)
           so033.201     ng    1. Initialize cSeqHiRx to '0' for a new dialog being created
                                  instead of recieved CSeqVal 
           so033.201     ng    1. Added code for  condition where the UAS 
                                  might have crashed and restrated and then 
                                  it receives a message (invite or no-invite) for an old call 
                                  whose context doesnot exist
/main/2+   so035.201     ng    1. Separating TLS and secure call functionality(ab)
                         ng    2. Removed code to Send ErrInd to App in case of error match fail(pk)
                         ng    3. Removed checking of TLS transport in Via for secure incoming
                                  call cause indomain hops may have unsecure transports.(ab)
                         ng    4. Modified cLeg to transcb->cLeg arg passsed to  SO_UA_SEND_ERR_RSP  
                         ng    5. Removed code to Send ErrInd to App in case of error match fail
                                  Modify to RETVALUE(ret); from so033
/main/2+   so037.201     pk    1. In case error  is  returned  from function
                                  UaIncReq  before  transCb  is  updated  in 
                                  dialog hash list, make sure dialog context
                                  is NOT updated in transaction CB.(pk)
/main/2+   so038.201     ng    1. Replaced with macro to check for transport - UDP 
                                 and priority UDP
                                 
/main/2+   so038.201     ng    1. Modified function to move Closing pending Trans to the trans module 
/main/2+   so039.201     ng    1. Go through the Txn list and delete Txn only if 
                                  it is not deleted in transaction module

                         ng    2. In soDlgRetryTrans, removed calling soTxnDeleteTrans 
                                  since it already deleted in soTxnUaOutReq when t return fail
                         ng    3. When insertion to hash list fails, Initialize 
                                  cLeg of trans to NULLP, so that it is not 
                                  deleted from hash list 
/main/2+   so041.201     ng    1. Initialize pend2xxEvnt to NULLP in 
                                  soDlgDelRelProvRspInfo after free
                               2. Modified the logic to go through the hash list. 
                                  Before closing transaction get the next hash 
                                  list entity, since transaction is deleted for 
                                  TCP/TLS
                         ps    3. If request is retried dur to second DNS entry
                                  or due to compression,we should increment the
                                  CSEQ number. This will also result in 
                                  generating new  branch identifier in request.
                         ad    4. Reset the pointer after releasing the message
*********************************************************************91*/
