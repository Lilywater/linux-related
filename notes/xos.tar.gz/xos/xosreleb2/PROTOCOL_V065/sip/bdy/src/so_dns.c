/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SIP DNS Module

     Type:     C Source file

     Desc:     C source code for SIP dns module

     File:     so_dns.c

     Sid:      so_dns.c@@/main/4 - Tue Apr 20 12:46:24 2004

     Prg:      tn

*********************************************************************21*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tpt.h"        /* transport related structures */
#include "cm_hash.h"
#include "cm_tkns.h"
#include "cm_sdp.h"
#include "cm_abnf.h"       /* common Abnf */
#include "cm_dns.h"        /* common DNS */
#include "cm5.h"
#include "hit.h"           /* HIT interface defines */
#include "lso.h"           /* SIP layer management */
#include "sot.h"           /* SIP layer */
#include "so.h"            /* SIP layer */
#include "so_err.h"        /* SIP error defines */
#include "so_cm.h"         /* Common sip defines */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_hash.x"
#include "cm_llist.x"
#include "cm_xtree.x"
#include "cm_tkns.x"
#include "cm_tpt.x"        /* transport related structures */
#include "cm_mblk.x"
#include "cm_sdp.x"
#include "cm_abnf.x"       /* common abnf */
#include "cm_dns.x"        /* common DNS */
#include "cm_lib.x"
#include "cm5.x"
#include "lso.x"           /* SIP layer management */
#include "sot.x"           /* SIP layer */
#include "so_tcm.x"        /* SIP TUCL interface */
#include "so.x"            /* SIP layer */
#include "so_utl.x"        /* SIP utility functions */
#include "so_cm.x"
#include "so_cl.x"         /* SIP cache */
#include "so_dns.x"        /* SIP dns */
#include "so_cl.x"         /* cache library functions */

#define HEX_TO_DEC(hx) ((hx >='a' && hx<='z') ? hx-'a'+10 : hx - '0')

/* If in upcase range, map to lowcase */
#define TO_LOWER(c) ((c >= 'A' && c <= 'Z') ? c-'A'+'a' : c)

#ifdef SO_DNS

PRIVATE S16 soDnsInitQuery            ARGS((PTR rsp, SoDnsQueryCb **cb));
PRIVATE S16 soDnsInvErrHandle         ARGS((PTR rsp, SoDnsQueryCb **cb));

#ifdef SO_ENUM      
PRIVATE S16 soDnsGetEnumRspInfo       ARGS((CmDns2915RR *naptrRec, 
                                            U8 *serviceType, 
                                            U8 *e164Str,
                                            U16 *e164Strlen,
                                            U16 maxStrLen));

PRIVATE S16 soDnsProcNaptrUDNSTmr     ARGS((PTR rsp, SoDnsQueryCb **cb));
#endif /* SO_ENUM */      

PRIVATE S16 soDnsProcNaptrSDNSTmr     ARGS((PTR rsp, SoDnsQueryCb **cb));

#ifdef SO_INSTMSG
PRIVATE S16 soDnsProcImDNSTmr         ARGS((PTR rsp, SoDnsQueryCb **cb));
#endif
#ifdef SO_PRESENCE
PRIVATE S16 soDnsProcPresDNSTmr       ARGS((PTR rsp, SoDnsQueryCb **cb));
#endif      
PRIVATE S16 soDnsProcSrvDNSTmr        ARGS((PTR rsp, SoDnsQueryCb **cb));
PRIVATE S16 soDnsProcADNSTmr          ARGS((PTR rsp, SoDnsQueryCb **cb));
#ifdef SO_AAAA      
PRIVATE S16 soDnsProcAAAADNSTmr       ARGS((PTR rsp, SoDnsQueryCb **cb));
#endif      
PRIVATE S16 soDnsTranTimeoutErrHandle ARGS((PTR rsp, SoDnsQueryCb **cb));
PRIVATE S16 soDnsProcSrvTranTmr       ARGS((PTR rsp, SoDnsQueryCb **cb));
PRIVATE S16 soDnsProcATranTmr         ARGS((PTR rsp, SoDnsQueryCb **cb));
#ifdef SO_AAAA      
PRIVATE S16 soDnsProcAAAATranTmr      ARGS((PTR rsp, SoDnsQueryCb **cb));
#endif      
#ifdef SO_ENUM
PRIVATE S16 soDnsProcInNaptrUResult   ARGS((PTR rsp, SoDnsQueryCb **cb));
#endif      
PRIVATE S16 soDnsProcInNaptrSResult   ARGS((PTR rsp, SoDnsQueryCb **cb));
#ifdef SO_INSTMSG      
PRIVATE S16 soDnsProcInImResult       ARGS((PTR rsp, SoDnsQueryCb **cb));
#endif
#ifdef SO_PRESENCE      
PRIVATE S16 soDnsProcInPresResult     ARGS((PTR rsp, SoDnsQueryCb **cb));
#endif      
PRIVATE S16 soDnsProcInSrvResult      ARGS((PTR rsp, SoDnsQueryCb **cb));
PRIVATE S16 soDnsProcInAResult        ARGS((PTR rsp, SoDnsQueryCb **cb));
#ifdef SO_AAAA      
PRIVATE S16 soDnsProcInAAAAResult     ARGS((PTR rsp, SoDnsQueryCb **cb));
#endif      


PRIVATE CONSTANT PtrSoDnsFsmFnTbl soDnsFsmTbl[SO_DNS_FSM_NUM_EVNTS][SO_DNS_NUM_FSM]=
{
   /* SO_DNS_INIT_QUERY_EVENT - the lookup event from SO */
   {
      soDnsInitQuery,        /* SO_DNS_FSM_INIT         */
#ifdef SO_ENUM      
      soDnsInvErrHandle,     /* SO_DNS_FSM_NAPTRU_CACHE */
      soDnsInvErrHandle,     /* SO_DNS_FSM_NAPTRU       */
#endif      
      soDnsInvErrHandle,     /* SO_DNS_FSM_NAPTRS_CACHE */
      soDnsInvErrHandle,     /* SO_DNS_FSM_NAPTRS       */ 
#ifdef SO_INSTMSG
      soDnsInvErrHandle,     /* SO_DNS_FSM_IM_CACHE */
      soDnsInvErrHandle,     /* SO_DNS_FSM_IM       */ 
#endif
#ifdef SO_PRESENCE
      soDnsInvErrHandle,     /* SO_DNS_FSM_PRES_CACHE */
      soDnsInvErrHandle,     /* SO_DNS_FSM_PRES       */ 
#endif      
      soDnsInvErrHandle,     /* SO_DNS_FSM_SRV_CACHE    */
      soDnsInvErrHandle,     /* SO_DNS_FSM_SRV          */
      soDnsInvErrHandle,     /* SO_DNS_FSM_SRV_WAIT     */
      soDnsInvErrHandle,     /* SO_DNS_FSM_A_CACHE      */
      soDnsInvErrHandle,     /* SO_DNS_FSM_A            */
#ifdef SO_AAAA      
      soDnsInvErrHandle,     /* SO_DNS_FSM_AAAA_CACHE   */
      soDnsInvErrHandle,     /* SO_DNS_FSM_AAAA         */
#endif      
      soDnsInvErrHandle     /* SO_DNS_FSM_INV          */
   },
   /* SO_DNS_QUERY_TIMEOUT - the DNS query timeout event */
   {
      soDnsInvErrHandle,     /* SO_DNS_FSM_INIT         */
#ifdef SO_ENUM      
      soDnsInvErrHandle,     /* SO_DNS_FSM_NAPTRU_CACHE */
      soDnsProcNaptrUDNSTmr, /* SO_DNS_FSM_NAPTRU       */
#endif      
      soDnsInvErrHandle,     /* SO_DNS_FSM_NAPTRS_CACHE */
      soDnsProcNaptrSDNSTmr, /* SO_DNS_FSM_NAPTRS       */ 
#ifdef SO_INSTMSG
      soDnsInvErrHandle,     /* SO_DNS_FSM_IM_CACHE */
      soDnsProcImDNSTmr,     /* SO_DNS_FSM_IM       */ 
#endif
#ifdef SO_PRESENCE
      soDnsInvErrHandle,     /* SO_DNS_FSM_PRES_CACHE */
      soDnsProcPresDNSTmr,   /* SO_DNS_FSM_PRES       */ 
#endif      
      soDnsInvErrHandle,     /* S O_DNS_FSM_SRV_CACHE   */
      soDnsProcSrvDNSTmr,    /* SO_DNS_FSM_SRV          */
      soDnsProcSrvDNSTmr,    /* SO_DNS_FSM_SRV_WAIT     */
      soDnsInvErrHandle,     /* S O_DNS_FSM_A_CACHE     */
      soDnsProcADNSTmr,      /* SO_DNS_FSM_A            */
#ifdef SO_AAAA      
      soDnsInvErrHandle,     /* SO_DNS_FSM_AAAA_CACHE   */
      soDnsProcAAAADNSTmr,   /* SO_DNS_FSM_AAAA         */
#endif      
      soDnsInvErrHandle     /* SO_DNS_FSM_INV          */
   },
   
   /* SO_DNS_TRAN_TIMEOUT - the transaction timeout event */
   {
      soDnsTranTimeoutErrHandle,     /* SO_DNS_FSM_INIT         */
#ifdef SO_ENUM      
      soDnsTranTimeoutErrHandle,     /* SO_DNS_FSM_NAPTRU_CACHE */
      soDnsTranTimeoutErrHandle,     /* SO_DNS_FSM_NAPTRU       */
#endif      
      soDnsTranTimeoutErrHandle,     /* SO_DNS_FSM_NAPTRS_CACHE */
      soDnsTranTimeoutErrHandle,     /* SO_DNS_FSM_NAPTRS       */
#ifdef SO_INSTMSG
      soDnsTranTimeoutErrHandle,     /* SO_DNS_FSM_IM_CACHE     */
      soDnsTranTimeoutErrHandle,     /* SO_DNS_FSM_IM           */
#endif
#ifdef SO_PRESENCE
      soDnsTranTimeoutErrHandle,     /* SO_DNS_FSM_IM_CACHE     */
      soDnsTranTimeoutErrHandle,     /* SO_DNS_FSM_IM           */
#endif      
      soDnsProcSrvTranTmr,           /* SO_DNS_FSM_SRV_CACHE    */
      soDnsProcSrvTranTmr,           /* SO_DNS_FSM_SRV          */
      soDnsTranTimeoutErrHandle,     /* SO_DNS_FSM_SRV_WAIT     */
      soDnsProcATranTmr,             /* SO_DNS_FSM_A_CACHE      */
      soDnsProcATranTmr,             /* SO_DNS_FSM_A            */
#ifdef SO_AAAA      
      soDnsProcAAAATranTmr,          /* SO_DNS_FSM_AAAA_CACHE   */
      soDnsProcAAAATranTmr,          /* SO_DNS_FSM_AAAA         */
#endif      
      soDnsTranTimeoutErrHandle     /* SO_DNS_FSM_INV          */
   },
   /* SO_DNS_RSP_EVENT - the DNS query response event */
   {
      soDnsInvErrHandle,       /* SO_DNS_FSM_INIT         */
#ifdef SO_ENUM
      soDnsInvErrHandle,       /* SO_DNS_FSM_NAPTRU_CACHE */
      soDnsProcInNaptrUResult, /* SO_DNS_FSM_NAPTRU       */
#endif      
      soDnsInvErrHandle,       /* SO_DNS_FSM_NAPTRS_CACHE */
      soDnsProcInNaptrSResult, /* SO_DNS_FSM_NAPTRS       */
#ifdef SO_INSTMSG      
      soDnsInvErrHandle,       /* SO_DNS_FSM_IM_CACHE     */
      soDnsProcInImResult,     /* SO_DNS_FSM_IM           */
#endif
#ifdef SO_PRESENCE      
      soDnsInvErrHandle,       /* SO_DNS_FSM_PRES_CACHE   */
      soDnsProcInPresResult,   /* SO_DNS_FSM_PRES         */
#endif      
      soDnsInvErrHandle,       /* SO_DNS_FSM_SRV_CACHE    */
      soDnsProcInSrvResult,    /* SO_DNS_FSM_SRV          */
      soDnsInvErrHandle,       /* SO_DNS_FSM_SRV_WAIT     */
      soDnsInvErrHandle,       /* SO_DNS_FSM_A_CACHE      */
      soDnsProcInAResult,      /* SO_DNS_FSM_A            */
#ifdef SO_AAAA      
      soDnsInvErrHandle,       /* SO_DNS_FSM_AAAA_CACHE   */
      soDnsProcInAAAAResult,   /* SO_DNS_FSM_AAAA         */
#endif      
      soDnsInvErrHandle       /* SO_DNS_FSM_INV          */
   }
};

PRIVATE S16 soDnsFindPhysicalAddr     ARGS((
                                            CmDns2782RR    *srvAnswer,
                                            CmDnsResponse  *dnsRsp,
                                            Bool           *haveAddr,
                                            CmNetAddr      *physicalAddr,
                                            U32            *ttl));          

PRIVATE S16 soDnsDoARecur             ARGS((
                                            SoDnsQueryCb   *cb));      
PRIVATE S16 soDnsDoSrvRecur           ARGS((
                                            SoDnsQueryCb   *cb));      
#ifdef SO_ENUM
PRIVATE S16 soDnsDoNaptrRecur         ARGS((
                                            SoDnsQueryCb   *cb));      
#endif

PRIVATE S16 soDnsCreateQueryCb        ARGS((
                                            PTR             context,
                                            SoAddrSpec      *reqAddr,
                                            U8              addrType,
                                            TknU16          *port,   
                                            TknStrOSXL      *host,
                                            U8              tptProt,
                                            SoDnsQueryCb    **newQuery,
                                            U8              urlType,
                                            SoDnsCallBackFn callback,
                                            Bool            master));   

PRIVATE S16 soDnsNaptrSLookup         ARGS((SoDnsQueryCb    *newQueryCb));
#ifdef SO_ENUM
PRIVATE S16 soDnsNaptrULookup         ARGS((SoDnsQueryCb    *newQueryCb));
#endif

PRIVATE S16 soDnsSrvLookup            ARGS((
                                            SoDnsQueryCb    *query,
                                            U8              tptProt));
PRIVATE S16 soDnsALookup              ARGS((
                                            SoDnsQueryCb    *query));
#ifdef SO_AAAA
PRIVATE S16 soDnsAAAALookup          ARGS((
                                            SoDnsQueryCb    *query));
#endif /* SO_AAAA */
#ifdef SO_INSTMSG
PRIVATE S16 soDnsImLookup             ARGS((
                                            SoDnsQueryCb    *query));
PRIVATE S16 soDnsCacheFoundIm         ARGS((
                                            SoDnsQueryCb    *dnsQuery,
                                         SoClDnsSrvEnt   *findResult));
#endif /* SO_INSTMSG */
#ifdef SO_PRESENCE
PRIVATE S16 soDnsPresLookup           ARGS((
                                            SoDnsQueryCb    *query));
PRIVATE S16 soDnsCacheFoundPres       ARGS((
                                            SoDnsQueryCb    *dnsQuery,
                                         SoClDnsSrvEnt   *findResult));
#endif /* SO_PRESENCE */
PRIVATE S16 soDnsCacheFoundA          ARGS((
                                            SoDnsQueryCb    *dnsQuery,
                                         SoClDnsAEnt     *findResult));
PRIVATE S16 soDnsCacheFoundSrv        ARGS((
                                            SoDnsQueryCb    *dnsQuery,
                                         SoClDnsSrvEnt   *findResult));
PRIVATE S16 soDnsCacheSrvHit          ARGS((
                                            SoDnsQueryCb    *dnsQuery,
                                         SoClDnsSrvEnt   *findResult));
PRIVATE S16 soDnsCacheFoundNaptr      ARGS((
                                            SoDnsQueryCb    *dnsQuery,
                                            SoClDnsNaptrEnt *findResult,
                                            Bool            isNaptrU));

PRIVATE S16 soSendDnsQuery            ARGS((
                                            SoDnsQueryCb    *dnsQ,
                                            U8              qNameLen,
                                            U8              *qName,
                                            U16             qType,
                                            U8              qProtocol,
                                            U8              service));
PRIVATE S16 soDnsAnalyseNaptrSResult  ARGS((
                                            SoDnsQueryCb    *query));
PRIVATE S16 soDnsGetHostNameFromNaptrUri ARGS((
                                            SoDnsNaptrResult *result,
                                            TknStrOSXL       *hostName,
                                            U8               *tptProt,
                                            TknU16           *port,
                                            Bool             *isIp,
                                            U8               *ipType,
                                            Bool             *isTel));
#ifdef SO_ENUM
PRIVATE S16 soDnsProcNaptrQuery      ARGS((
                                           SoDnsQueryCb     *dnsQuery,
                                           TknStrOSXL       *hostName,
                                           Bool             isNaptrU));
PRIVATE Void soDnsFreeNaptrList      ARGS((CmLListCp         *cp));
#endif /* SO_ENUM */
PRIVATE Void soDnsFreeNaptrResult     ARGS((
                                           SoDnsNaptrResult *result));
PRIVATE Void soDnsFreeAResult         ARGS((
                                           SoDnsAResult     *result));
PRIVATE Void soDnsFreeSrvResult       ARGS((
                                           SoDnsSrvResult   *result));
PRIVATE Void soDnsFreeQueryCb        ARGS((
                                           SoDnsQueryCb     *cb));
PRIVATE S16 soDnsCpyHostStr          ARGS((
                                           TknStrOSXL       *hostName,
                                           TknStrOSXL       *target,
                                           Bool             noHost));
PRIVATE S16 soDnsUnEscape            ARGS((
                                           U8               *dst,
                                           U16              *dstLen,
                                           U8               *src,
                                           U16              srcLen,
                                           U16              maxLen));
PRIVATE S16 soDnsProcInQueryTmr      ARGS(( 
                                           PTR              rsp, 
                                           PTR              Cb));
PRIVATE S16 soDnsProcInTranTimeout   ARGS(( 
                                           PTR              rsp, 
                                           PTR              Cb));
PRIVATE Void soDnsSortSrvWeight      ARGS((
                                  CmLListCp        *dnsFindResults));
PRIVATE Void soDnsSortNaptrWeight    ARGS((
                                 CmLListCp        *dnsFindResults));
PRIVATE S16 soDnsProcInSrvErrRsp     ARGS((SoDnsQueryCb     **q));

#endif /* SO_DNS */


/********************************************************************
*
*       Fun:   soDnsCheckAddr
*
*       Desc:  Checks the address passed whether we 
*       need to do DNS query or not
*              
*
*       Ret:   the address type.
*
*       File:  so_dns.c
*
********************************************************************/
#ifdef ANSI
PUBLIC S16 soDnsCheckAddr
(
PTR             usrCtxt,   /* user context */
SoAddrSpec      *reqAddr,   /* Address we want to resolve */
CmTptAddr       *tptAddr,   /* Resolved addr incase of direct ip */
U8              *tptProt,   /* tpt protocol */
U8              *queryType, /* query type */
SoDnsCallBackFn callback,   /* call back function */
PTR             *dnsQueryCb /* query cb pointer */
)
#else
PUBLIC S16 soDnsCheckAddr(usrCtxt, reqAddr, tptAddr, 
                          tptProt, queryType, callback, dnsQueryCb)
PTR             usrCtxt;   /* user context */
SoAddrSpec      *reqAddr;   /* Address we want to resolve */
CmTptAddr       *tptAddr;   /* Resolved addr incase of direct ip */
U8              *tptProt;   /* tpt protocol */
U8              *queryType; /* query type */
SoDnsCallBackFn callback;   /* call back function */
PTR             *dnsQueryCb; /* query cb pointer */
#endif
{
   U32        a1;          
   U32        a2;          
   U32        a3;          
   U32        a4;          
   Cntr       i;           
   SoHostPort *hostPort;   
   SoSipUrl   *sipUrl;
#ifdef SO_TLS   
   SoSipUrl   *sipsUrl;
#endif
   U16        tmpCount;
   SoHost     *host;
#ifndef IPV6_SUPPORTED        
   SoIpv4Address *a;
#endif
#ifdef SO_DNS
   SoDnsQueryCb  *q;
   S16           ret;
   TknU16        tmpPort;
#endif
   U8            urlHostType;
   
   TRC2(soDnsCheckAddr);
   
   tmpCount = 0;
   *tptProt = LSO_TPTPROT_NULL;
   *queryType = SO_DNS_ADDR_TYPE_ERROR;
   /* set the tptAddr to zero because tcm module needs
    * the entire tptaddr for hash find. */ 
   (Void) cmMemset((U8 *)tptAddr, 0, sizeof(CmTptAddr));

   hostPort = NULLP;
   host = NULLP;
   
   if(reqAddr->addrSpecType.pres != PRSNT_NODEF)
   {
      RETVALUE(RFAILED);
   }      
   switch(reqAddr->addrSpecType.val)
   {
#ifdef SO_ENUM     
      case SO_ADDRSPEC_TELURL:
         *queryType = SO_DNS_ADDR_TYPE_TEL;
         break;
#endif
      /* so033.201: removed code for FAX & modem since it not supported */ 

#ifdef SO_INSTMSG 
      case SO_ADDRSPEC_IMURL:
         *queryType = SO_DNS_ADDR_TYPE_IM;         
         *tptProt = LSO_TPTPROT_UDP;
         hostPort = &reqAddr->t.sipUrl.hostPort;
         sipUrl = &reqAddr->t.sipUrl;
         host = &hostPort->host;
         
         if (sipUrl->urlParameters.numComp.pres == PRSNT_NODEF)
         {
            for (i = 0; i < sipUrl->urlParameters.numComp.val; i++)
            {
               if(sipUrl->urlParameters.urlParameter[i]->
                  urlParameterType.val == SO_URLPARAMETER_MADDRHOST &&
                  sipUrl->urlParameters.urlParameter[i]->
                  urlParameterType.pres == PRSNT_NODEF)
               {
                  host = &sipUrl->urlParameters.
                  urlParameter[i]->t.maddrHost;
                  break;
               }   
            }
         }
         switch(hostPort->host.hostType.val)
         {

            case SO_HOST_IPV4ADDRESS:
               a = &host->t.ipv4Address;
               tptAddr->type = CM_TPTADDR_IPV4;
               a1 = a->adr4.val &0xff;
               a2 = ((a->adr3.val &0xff) << 8);
               a3 = ((a->adr2.val &0xff) << 16);
               a4 = ((a->adr1.val &0xff) << 24);
               tptAddr->u.ipv4TptAddr.address = a1+a2+a3+a4;
               if (hostPort->port.pres == PRSNT_NODEF)
               {
                  tptAddr->u.ipv4TptAddr.port = 
                  sipUrl->hostPort.port.val;
               }
               else
               {
                  tptAddr->u.ipv4TptAddr.port = SO_PORT_DEFAULT;
               }   
               *queryType = SO_DNS_ADDR_TYPE_IP;
               RETVALUE(ROK);
               break;

#ifdef IPV6_SUPPORTED        
            case SO_HOST_IPV6REFERENCE:
               TknStrOSXL *a = &host->t.ipv6Reference;
               tptAddr->type = CM_TPTADDR_IPV6;

               i = a->len-1;
               a3 = 15;
               while (i > 0)
               {
                  a1 = 0;
                  for(a2 = 0; a2 <= 4; a2++)
                  {
                     if(a->val[i] == ':')
                     {
                        tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = 
                                                  a1 & 0xff;
                        a1 = a1 >> 8;
                        tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = 
                                                  a1 & 0xff;
                        i--;
                        break;
                     }
                     else
                     {
                        if(AIsUpper(a->val[i]))
                           a1 = a1 | ((a->val[i--] - 55) << 4 * a2);
                        else if (AIsLower(a->val[i]))
                           a1 = a1 | ((a->val[i--] - 87) << 4 * a2);
                        else
                           a1 = a1 | ((a->val[i--] - '0') << 4 * a2);
                     }
                  }
               }
               tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = a1 & 0xff;
               a1 = a1 >> 8;
               tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = a1 & 0xff;

               if(hostPort->port.pres == PRSNT_NODEF)
               {
                  tptAddr->u.ipv6TptAddr.port = 
                  sipUrl->hostPort.port.val;
               }
               else
               {
                  tptAddr->u.ipv6TptAddr.port = SO_PORT_DEFAULT;
               }
               *queryType = SO_DNS_CHECKADDR_IP;
               RETVALUE(ROK);
#endif
      
#ifdef SO_DNS      
            case SO_HOST_HOSTNAME:
               if(hostPort->port.pres != PRSNT_NODEF)
               {
                  tptAddr->u.ipv4TptAddr.port = SO_PORT_DEFAULT; 
               }         
               else
               {
                  tptAddr->u.ipv4TptAddr.port = 
                  sipUrl->hostPort.port.val;
                  *queryType = SO_DNS_ADDR_TYPE_A;
                  if(soCb.cfg.dnsCfg.useDns == FALSE)
                  {
#ifdef DEBUGP   
                      sprintf(soCb.init.prntBuf,
                        "\nsoDnsCheckAddr: DNS is not configured\n");
                      SPrint(soCb.init.prntBuf);
#endif
                      RETVALUE(RFAILED);
                  }
               }
               break;
#endif      
            default:
              RETVALUE(RFAILED);
         }
         break;
#endif

#ifdef SO_PRESENCE 
      case SO_ADDRSPEC_PRESURL:
      case SO_ADDRSPEC_PRESURLNOPARAMS:
         *queryType = SO_DNS_ADDR_TYPE_PRES;         
         *tptProt = LSO_TPTPROT_UDP;
         break;
#endif
    
      case SO_ADDRSPEC_SIPURL:
         tmpCount = 0;
         hostPort = &reqAddr->t.sipUrl.hostPort;
         sipUrl = &reqAddr->t.sipUrl;
         host = &hostPort->host;
         urlHostType = hostPort->host.hostType.val;
         /* get tpt protocol */
         for (i = 0; i < 
           SO_GET_NUM_COMP(&sipUrl->urlParameters.numComp); 
                              i++)
         {
            if(SO_CMP_TKN_LIT(
               &sipUrl->urlParameters.urlParameter[i]->
               urlParameterType,
               SO_URLPARAMETER_TRANSPORTPARAM) == TRUE)
            {
               if(sipUrl->urlParameters.urlParameter[i]->
                  urlParameterType.pres
                 == TRUE)
               {
                  *tptProt = 
                  sipUrl->urlParameters.urlParameter[i]->t.
                  transportParam.transportParamType.val;
                  break;
               }
            }
         }

         /* so002.201: Check URL parameter only for host part as domain name */
         /* so003.201: Check for maddr support */
         if ((sipUrl->urlParameters.numComp.pres == PRSNT_NODEF))
         {
           for (i = 0; i < sipUrl->urlParameters.numComp.val; i++)
           {
              if(sipUrl->urlParameters.urlParameter[i]->
                 urlParameterType.val == SO_URLPARAMETER_MADDRHOST &&
                 sipUrl->urlParameters.urlParameter[i]->
                 urlParameterType.pres == PRSNT_NODEF)
              {
                 host = &sipUrl->urlParameters.
                 urlParameter[i]->t.maddrHost;
                 urlHostType = host->hostType.val;
                 tmpCount++;
                 if(tmpCount == 2)
                    break;
              }   
              else if((urlHostType == SO_HOST_HOSTNAME) &&
                      ((SO_CMP_TKN_LIT(&sipUrl->urlParameters.
                             urlParameter[i]->urlParameterType, 
                             SO_URLPARAMETER_USERPARAM)) == TRUE))
              {
                 if (SO_CMP_TKN_LIT(&sipUrl->urlParameters.
                     urlParameter[i]->
                     t.userParam.userParamType, SO_USERPARAM_PHONE))
                 {
                    tmpCount++;
#ifdef SO_ENUM                      
                    *queryType = SO_DNS_ADDR_TYPE_TEL;
#else
                    *queryType = SO_DNS_ADDR_TYPE_ERROR;
                    RETVALUE(RFAILED);
#endif                      
                    if(tmpCount == 2)
                       break;
                 }
              }
           }
         }
#ifdef SO_ENUM                      
         if(*queryType == SO_DNS_ADDR_TYPE_TEL)
         break;
#endif

         switch(urlHostType) 
         {

            case SO_HOST_IPV4ADDRESS:
               a = &host->t.ipv4Address;
               tptAddr->type = CM_TPTADDR_IPV4;
               a1 = a->adr4.val &0xff;
               a2 = ((a->adr3.val &0xff) << 8);
               a3 = ((a->adr2.val &0xff) << 16);
               a4 = ((a->adr1.val &0xff) << 24);
               tptAddr->u.ipv4TptAddr.address = a1+a2+a3+a4;
               if (hostPort->port.pres == PRSNT_NODEF)
               {
                  tptAddr->u.ipv4TptAddr.port = 
                  sipUrl->hostPort.port.val;
               }
               else
               {
                  /* so035.201: Default port fpr TLS is 5061 */
                  if (*tptProt == LSO_TPTPROT_TLS_TCP)
                  {
                     tptAddr->u.ipv4TptAddr.port = SO_PORT_TLS_DEFAULT;
                  }
                  else
                  {
                     tptAddr->u.ipv4TptAddr.port = SO_PORT_DEFAULT;
                  }
               }   
               *queryType = SO_DNS_ADDR_TYPE_IP;
               if(*tptProt == LSO_TPTPROT_NULL)
                  *tptProt = LSO_TPTPROT_UDP;
               RETVALUE(ROK);
               break;

#ifdef IPV6_SUPPORTED        
            case SO_HOST_IPV6REFERENCE:
               TknStrOSXL *a = &host->t.ipv6Reference;
               tptAddr->type = CM_TPTADDR_IPV6;

               i = a->len-1;
               a3 = 15;
               while (i > 0)
               {
                  a1 = 0;
                  for(a2 = 0; a2 <= 4; a2++)
                  {
                     if(a->val[i] == ':')
                     {
                        tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = 
                                                  a1 & 0xff;
                        a1 = a1 >> 8;
                        tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = 
                                                  a1 & 0xff;
                        i--;
                        break;
                     }
                     else
                     {
                        if(AIsUpper(a->val[i]))
                           a1 = a1 | ((a->val[i--] - 55) << 4 * a2);
                        else if (AIsLower(a->val[i]))
                           a1 = a1 | ((a->val[i--] - 87) << 4 * a2);
                        else
                           a1 = a1 | ((a->val[i--] - '0') << 4 * a2);
                     }
                  }
               }
               tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = a1 & 0xff;
               a1 = a1 >> 8;
               tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = a1 & 0xff;

               if(hostPort->port.pres == PRSNT_NODEF)
               {
                  tptAddr->u.ipv6TptAddr.port = 
                  sipUrl->hostPort.port.val;
               }
               else
               {
                  tptAddr->u.ipv6TptAddr.port = SO_PORT_DEFAULT;
               }
               if(*tptProt == LSO_TPTPROT_NULL)
               *tptProt = LSO_TPTPROT_UDP;
               *queryType = SO_DNS_CHECKADDR_IP;
               RETVALUE(ROK);
#endif
      
#ifdef SO_DNS      
            case SO_HOST_HOSTNAME:
               if(hostPort->port.pres != PRSNT_NODEF)
               {
                  *queryType = SO_DNS_ADDR_TYPE_NAPTRS;
                  for(i = 0; 
                     i < SO_GET_NUM_COMP(
                         &sipUrl->urlParameters.numComp); i++)
                  {
                     if(SO_CMP_TKN_LIT(
                     &sipUrl->urlParameters.
                     urlParameter[i]->urlParameterType,
                     SO_URLPARAMETER_TRANSPORTPARAM) == TRUE)
                     {
                        if(sipUrl->urlParameters.urlParameter[i]->
                           urlParameterType.pres
                           == TRUE)
                        {
                           *tptProt = sipUrl->urlParameters.
                                urlParameter[i]->t.
                                transportParam.transportParamType.val;
                           *queryType = SO_DNS_ADDR_TYPE_SRV;
                           break;
                        }
                     }
                  }
              }         
              else
              {
                 *queryType = SO_DNS_ADDR_TYPE_A;
                 tptAddr->u.ipv4TptAddr.port = 
                 sipUrl->hostPort.port.val;
                 if(soCb.cfg.dnsCfg.useDns == FALSE)
                 {
#ifdef DEBUGP   
                    sprintf(soCb.init.prntBuf,
                            "\nsoDnsCheckAddr: DNS is not configured\n");
                    SPrint(soCb.init.prntBuf);
#endif
                    RETVALUE(RFAILED);
                 }
                 
       if(*tptProt != LSO_TPTPROT_NULL)
          break;    
                 
       *tptProt = LSO_TPTPROT_UDP;
                 
       for (i = 0; i < 
                      SO_GET_NUM_COMP(&sipUrl->urlParameters.numComp); 
                      i++)
                 {
                    if(SO_CMP_TKN_LIT(
                       &sipUrl->urlParameters.urlParameter[i]->
                       urlParameterType,
                       SO_URLPARAMETER_TRANSPORTPARAM) == TRUE)
                    {
                       if(sipUrl->urlParameters.urlParameter[i]->
                          urlParameterType.pres
                          == TRUE)
                       {
                          *tptProt = 
                          sipUrl->urlParameters.urlParameter[i]->t.
                          transportParam.transportParamType.val;
                       }
                    }
                 }
         }
              break;
#endif      
           default:
              RETVALUE(RFAILED);
        }
        break;
     
#ifdef SO_TLS
      case SO_ADDRSPEC_SIPSURL:
         tmpCount = 0;
         sipsUrl = &reqAddr->t.sipsUrl;
         hostPort = &reqAddr->t.sipsUrl.hostPort;
         host = &hostPort->host;
         *tptProt = LSO_TPTPROT_TLS_TCP;

        /*-- so021.201: Initialize urlHostType Variable --*/
         urlHostType = hostPort->host.hostType.val;

         /* so002.201: Check URL parameter only for host part as domain name */
         /* so003.201: Check for maddr support */
         if ((sipsUrl->urlParameters.numComp.pres == PRSNT_NODEF))
         {
            for (i = 0; 
                 i < sipsUrl->urlParameters.numComp.val; 
                 i++)
            {
               if ((sipsUrl->urlParameters.urlParameter[i]->
                   urlParameterType.val == SO_URLPARAMETER_MADDRHOST) &&
                   (sipsUrl->urlParameters.urlParameter[i]->
                   urlParameterType.pres == PRSNT_NODEF))
               {
                  host = &sipsUrl->urlParameters.
                  urlParameter[i]->t.maddrHost;
                  tmpCount++;
                  if(tmpCount == 2)
                     break;      
               }

               else if((urlHostType == SO_HOST_HOSTNAME) &&
                       ((SO_CMP_TKN_LIT(&sipsUrl->urlParameters.
                             urlParameter[i]->urlParameterType, 
                             SO_URLPARAMETER_USERPARAM)) == TRUE))
               {
                  if (SO_CMP_TKN_LIT(&sipsUrl->urlParameters.\
                      urlParameter[i]->\
                      t.userParam.userParamType, SO_USERPARAM_PHONE))
                  {
                     tmpCount++;
#ifdef SO_ENUM                     
                     *queryType = SO_DNS_ADDR_TYPE_TEL;
#else
                     *queryType = SO_DNS_ADDR_TYPE_ERROR;
                     RETVALUE(RFAILED);
#endif  
                     if(tmpCount == 2)
                        break;
                  }
               }
            }
         }
#ifdef SO_ENUM         
         if(*queryType == SO_DNS_ADDR_TYPE_TEL)
            break;
#endif

         switch(hostPort->host.hostType.val)
         {
            case SO_HOST_IPV4ADDRESS:
               a = &host->t.ipv4Address;
               tptAddr->type = CM_TPTADDR_IPV4;
               a1 = a->adr4.val &0xff;
               a2 = ((a->adr3.val &0xff) << 8);
               a3 = ((a->adr2.val &0xff) << 16);
               a4 = ((a->adr1.val &0xff) << 24);
               tptAddr->u.ipv4TptAddr.address = a1+a2+a3+a4;
               if (hostPort->port.pres == PRSNT_NODEF)
               {
                  tptAddr->u.ipv4TptAddr.port = 
                    sipsUrl->hostPort.port.val;
               }
               else
               {
                  /* so035.201: Use default port for TLS transport */
                  tptAddr->u.ipv4TptAddr.port = SO_PORT_TLS_DEFAULT;
               }   
               *queryType = SO_DNS_ADDR_TYPE_IP;
               RETVALUE(ROK);
               break;

#ifdef IPV6_SUPPORTED        
            case SO_HOST_IPV6REFERENCE:
               TknStrOSXL *a = &host->t.ipv6Reference;
               tptAddr->type = CM_TPTADDR_IPV6;
               i = a->len-1;
               a3 = 15;
               while (i > 0)
               {
                  a1 = 0;
                  for (a2 = 0; a2 <= 4; a2++)
                  {
                     if (a->val[i] == ':')
                     {
                        tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = 
                                                        a1 & 0xff;
                        a1 = a1 >> 8;
                        tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = 
                                                        a1 & 0xff;
                        i--;
                        break;
                     }
                     else
                     {
                        if (AIsUpper(a->val[i]))
                           a1 = a1 | ((a->val[i--] - 55) << 4 * a2);
                        else if (AIsLower(a->val[i]))
                           a1 = a1 | ((a->val[i--] - 87) << 4 * a2);
                        else
                           a1 = a1 | ((a->val[i--] - '0') << 4 * a2);
                     }
                  }
               }
               tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = a1 & 0xff;
               a1 = a1 >> 8;
               tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = a1 & 0xff;

               if (hostPort->port.pres == PRSNT_NODEF)
               {
                  tptAddr->u.ipv6TptAddr.port = 
                  sipsUrl->hostPort.port.val;
               }
               else
               {
                  /* so035.201: Default port for TLS is different */
                  tptAddr->u.ipv6TptAddr.port = SO_PORT_TLS_DEFAULT;
               }
               *queryType = SO_DNS_ADDR_TYPE_IP;
               if(*tptProt == LSO_TPTPROT_NULL)
                  *tptProt = LSO_TPTPROT_UDP;
               RETVALUE(ROK);
#endif
      
#ifdef SO_DNS      
            case SO_HOST_HOSTNAME:
               *queryType = SO_DNS_ADDR_TYPE_A;
               if(hostPort->port.pres != PRSNT_NODEF)
               {
                  /* so035.201: Default port for TLS is different */
                  /* so041.201: Corrected  ipv4TptAddr from ipv6TptAddr*/
                  tptAddr->u.ipv4TptAddr.port = SO_PORT_TLS_DEFAULT;
               }         
               else
               {
                  tptAddr->u.ipv4TptAddr.port = 
                    sipsUrl->hostPort.port.val;
                  if (soCb.cfg.dnsCfg.useDns == FALSE)
                  {      
#ifdef DEBUGP   
                    sprintf(soCb.init.prntBuf,
                            "\nsoDnsCheckAddr: DNS is not configured\n");
                    SPrint(soCb.init.prntBuf);
#endif
                     RETVALUE(RFAILED);
                  }
               }
               break;
#endif      
            default:
               RETVALUE(RFAILED);
         }
         break;   
#endif /* SO_TLS */     
      default:
         RETVALUE(RFAILED);
   }

#ifndef SO_DNS
   if(*queryType == SO_DNS_ADDR_TYPE_IP)
   {
      RETVALUE(ROK);
   }
   else
   {
      RETVALUE(RFAILED);
   }
#else   
   if(*queryType == SO_DNS_ADDR_TYPE_IP)
   {
      RETVALUE(ROK);
   }

   if(soCb.cfg.dnsCfg.useDns == FALSE)
   {
#ifdef DEBUGP   
         sprintf(soCb.init.prntBuf,
                 "\nsoDnsCheckAddr: DNS is not configured\n");
         SPrint(soCb.init.prntBuf);
#endif
         RETVALUE(RFAILED);
   }
      
   switch(*queryType)
   {
#ifdef SO_ENUM
      case SO_DNS_ADDR_TYPE_TEL:
            ret = soDnsCreateQueryCb(usrCtxt, reqAddr, *queryType, 
                     NULLP, NULLP, *tptProt,
                     (SoDnsQueryCb **)dnsQueryCb, 
                     reqAddr->addrSpecType.val, 
                     callback, TRUE);
            break;
#endif
#ifdef SO_TEL
      case SO_DNS_ADDR_TYPE_FAX:
      case SO_DNS_ADDR_TYPE_MODEM:
            ret = soDnsCreateQueryCb(usrCtxt, reqAddr, *queryType, 
                     NULLP, NULLP, *tptProt,
                     (SoDnsQueryCb **)dnsQueryCb, 
                     reqAddr->addrSpecType.val, 
                     callback, TRUE);
            break;
#endif /* SO_TEL */            
      default:
       tmpPort.pres = hostPort->port.pres;
       tmpPort.val = hostPort->port.val;
            ret = soDnsCreateQueryCb(usrCtxt, reqAddr, *queryType, 
                  &tmpPort, &host->t.hostName, *tptProt,
                  (SoDnsQueryCb **)dnsQueryCb, 
                  reqAddr->addrSpecType.val, 
                  callback, TRUE);
            break;
   } /* end of switch */

   if(ret != ROK)
   {
         *dnsQueryCb  = NULLP;
         RETVALUE(RFAILED);
   }

   q = (SoDnsQueryCb *)(*dnsQueryCb);

   /*
    * If we find IP address in cache, then make sure
    * that callback function is not called.
    */
   q->asyncCall     = FALSE;
   q->addrResolved = FALSE;

   ret = soDnsFsmTbl[SO_DNS_INIT_QUERY_EVENT][q->searchState] (NULLP, &q);

   if (ret != ROK)
   {
       soDnsLookupRel ((PTR)q);

       *dnsQueryCb  = NULLP;

       RETVALUE (RFAILED);    
   }

   if (q->addrResolved)
   {
     /*----- IP address resolved using cache ----*/
       cmMemcpy ((U8 *)tptAddr, (U8 *)&q->destAddr, sizeof (CmTptAddr));
   
       *tptProt = q->destProt;

       soDnsLookupRel ((PTR)q);

       *dnsQueryCb  = NULLP;

       RETVALUE (ROK);
   }
   else
   {
       /*--- DNS query send to resolve address ---*/
       /* return ROKDNA to indicate aync callback */
       q->asyncCall = TRUE;

       RETVALUE (ROKDNA);
   }

#endif /* SO_DNS */

} /* soDnsCheckAddr */

#ifdef SO_DNS


/*****************************************************************************
*
*       Fun:   soDnsProcADNSTmr
*
*       Desc:  generate initial DNS query
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsProcADNSTmr
(
PTR       rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsProcADNSTmr(rsp, q)
PTR       rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   SoDnsQueryCb *cb;      /* target */
   
   TRC2(soDnsProcADNSTmr);

   UNUSED(rsp);
   cb = *q;

#ifdef SO_AAAA
   RETVALUE(soDnsAAAALookup(cb));
#else   
   if(cb->srvResult == NULLP)
      RETVALUE(RFAILED);
   if(soDnsDoARecur(cb) != ROK)
      RETVALUE(RFAILED);      

   RETVALUE (ROK);

#endif /* SO_AAAA */
   

} /* soDnsProcADNSTmr */


#ifdef SO_AAAA
/*****************************************************************************
*
*       Fun:   soDnsProcAAAADNSTmr
*
*       Desc:  generate initial DNS query
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsProcAAAADNSTmr
(
PTR       rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsProcAAAADNSTmr(rsp, q)
PTR       rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   SoDnsQueryCb *cb;      /* target */
   
   TRC2(soDnsProcAAAADNSTmr);

   UNUSED(rsp);
   cb = *q;
   if(cb->srvResult == NULLP)
      RETVALUE(RFAILED);
   if(soDnsDoARecur(cb) != ROK)
      RETVALUE(RFAILED);   
   RETVALUE(ROK);
} /* soDnsProcAAAADNSTmr */
#endif /* SO_AAAA */
/*****************************************************************************
*
*       Fun:   soDnsProcSrvDNSTmr
*
*       Desc:  generate initial DNS query
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsProcSrvDNSTmr
(
PTR       rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsProcSrvDNSTmr(rsp, q)
PTR       rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   S16             ret;
   U8              cnt;
   SoClDnsSrvEnt   *result;     /* Result from cache lookup */
   SoDnsQueryCb    *master;
   SoDnsQueryCb    *cb;      /* target */

   
   TRC2(soDnsProcSrvDNSTmr);

   UNUSED(rsp);
   cb = *q;
   cb->searchState = SO_DNS_FSM_SRV_WAIT;
   if(cb->master != TRUE)
      master = cb->masterQueryCb;
   else
      master = cb;   
    
   cnt = 0;
   if(master->searchState == SO_DNS_FSM_SRV_WAIT)
      cnt++;

   if((master->tcpQueryCb != NULLP) &&
      (master->tcpQueryCb->searchState    == SO_DNS_FSM_SRV_WAIT))
      cnt++;

#ifdef SO_TLS   
   if((master->tlsTcpQueryCb != NULLP) &&
      (master->tlsTcpQueryCb->searchState == SO_DNS_FSM_SRV_WAIT))
      cnt++;
#endif

#ifdef SO_SCTP   
   if((master->sctpQueryCb != NULLP)   &&
      (master->sctpQueryCb->searchState   == SO_DNS_FSM_SRV_WAIT))
      cnt++;
#endif

   if(cnt == master->numCbs)   
   {      
      master->searchState = SO_DNS_FSM_SRV;
      ret = soClFindDnsSrvEntry(&soCb.cacheInfoCb.dnsSrvCache, 
             &master->queryAddress, &result);
      if (ret == ROK)
      {
         RETVALUE(soDnsCacheFoundSrv(master,result));
      }
      else
      {
         if(master->srvResult != NULLP)
    {
            soDnsFreeSrvResult(master->srvResult);
       master->srvResult = NULLP;
    }
         RETVALUE(soDnsALookup(master));
      }
   }
   RETVALUE(ROK);
} /* soDnsProcSrvDNSTmr */

#ifdef SO_PRESENCE
/*****************************************************************************
*
*       Fun:   soDnsProcPresDNSTmr
*
*       Desc:  generate initial DNS query
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsProcPresDNSTmr
(
PTR       rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsProcPresDNSTmr(rsp, q)
PTR       rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   SoDnsQueryCb *cb;      /* target */
   
   TRC2(soDnsProcPresDNSTmr);

   UNUSED(rsp);
   cb = *q;
   if(cb->presResult)
   {
      soDnsFreeSrvResult(cb->presResult);
      cb->presResult = NULLP;
   }
   cb->tptProt = LSO_TPTPROT_UDP;
   RETVALUE(soDnsALookup(cb));
} /* soDnsProcPresDNSTmr */
#endif /* SO_PRESENCE */


#ifdef SO_INSTMSG
/*****************************************************************************
*
*       Fun:   soDnsProcImDNSTmr
*
*       Desc:  generate initial DNS query
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsProcImDNSTmr
(
PTR       rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsProcImDNSTmr(rsp, q)
PTR       rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   SoDnsQueryCb *cb;      /* target */
   
   TRC2(soDnsProcImDNSTmr);

   UNUSED(rsp);
   cb = *q;
   if(cb->imResult)
   {
      soDnsFreeSrvResult(cb->imResult);
      cb->imResult = NULLP;
   }
   cb->tptProt = LSO_TPTPROT_UDP;
   RETVALUE(soDnsALookup(cb));
} /* soDnsProcImDNSTmr */

#endif /* SO_INSTMSG */
/*****************************************************************************
*
*       Fun:   soDnsProcNaptrSDNSTmr
*
*       Desc:  generate initial DNS query
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsProcNaptrSDNSTmr
(
PTR       rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsProcNaptrSDNSTmr(rsp, q)
PTR       rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   SoDnsQueryCb *cb;      /* target */
   
   TRC2(soDnsProcNaptrSDNSTmr);

   UNUSED(rsp);
   cb = *q;
   if(cb->naptrResult)
      soDnsFreeNaptrResult(cb->naptrResult);

   RETVALUE(soDnsSrvLookup(cb,LSO_TPTPROT_NULL));
} /* soDnsProcNaptrSDNSTmr */

#ifdef SO_ENUM

/********************************************************************
*
*       Fun:   soDnsGetEnumRspInfo
*
*       Desc:  Thsi utility is for obtaining the necessary ENUM 
*              response info 
*              
*
*       Ret:   the address type.
*
*       File:  so_dns.c
*
********************************************************************/

#ifdef ANSI
PRIVATE S16 soDnsGetEnumRspInfo
(
CmDns2915RR *naptrRec,  /* naptr response */ 
U8 *serviceType,        /* should either be SIP or TEL */ 
U8 *e164Str,            /* the e164 naptr string */
U16 *e164Strlen,        /* teh length of e164 naptr string */
U16 maxStrLen           /* the size of e164Str */
)
#else
S16 soDnsGetEnumRspInfo(naptrRec,serviceType,
                        e164Str,e164Strlen,maxStrLen) 
CmDns2915RR *naptrRec;  /* naptr response */ 
U8 *serviceType;        /* should either be SIP or TEL */ 
U8 *e164Str;            /* the e164 naptr string */
U16 *e164Strlen;        /* teh length of e164 naptr string */
U16 maxStrLen;          /* the size of e164Str */
#endif /* ANSI */
{
   U16        indx; 
   U8         *tmpVal;
   U8         *val;
   U8         separator;
   U16        bufIdx;
   U16        i;
   U16        length;
   U8         tele2u[] = "tel+E2U";
   U8         sipe2u[] = "sip+E2U";
   U8         name[] = "e164.arpa"; 
   U8         buf[CM_DNS_DNAME_LEN];
   
   TRC2(soDnsGetEnumRspInfo);
   if(naptrRec->serviceLen == 7 && 
      cmMemcmp((U8 *)sipe2u, naptrRec->service, 
               naptrRec->serviceLen) == 0)
   {
      /* do nothing for sip+E2U. next will be S query */
      *serviceType = SO_DNS_ENUM_RSPTYPE_SIP_E2U;
      RETVALUE(ROK);
   }
   if(naptrRec->serviceLen == 7 && 
      cmMemcmp((U8 *)tele2u, naptrRec->service, 
               naptrRec->serviceLen) != 0)
   {
      *serviceType = SO_DNS_ENUM_RSPTYPE_INVALID;
      RETVALUE(RFAILED);
   }
   /* the service is tel+E2U */
   *serviceType = SO_DNS_ENUM_RSPTYPE_TEL_E2U;

   tmpVal = naptrRec->regexp;
   separator = tmpVal[0];
   indx = 1;
   bufIdx = 0;
   
   /* skip the non tel part */
   while (tmpVal[indx++] != separator);
   
   /* copy the tel string to buf */
   while (tmpVal[indx] != separator)
   {
      buf[bufIdx++] = tmpVal[indx];
      indx++;
   }
   val = &buf[4];
   length = bufIdx-4;
   if (length <= 1 || length > maxStrLen/2)
   {
      RETVALUE(RFAILED);
   }
   indx = 0;
   
   for(i = 0; i < length; i++)
   {
      if(val[i] == ';')
         break;         
   }
   length = i;      
   
   for (i = length; i >0; i--)
   {
      if ((val[i-1] >= '0') && (val[i-1] <= '9'))
      {
         e164Str[indx++] = val[i-1];
         e164Str[indx++] = '.';
      }
   }

   for (i = 0; i < 9; i++)
      e164Str[indx++] = name[i];
   *e164Strlen = indx;   
   RETVALUE(ROK);
}
/*****************************************************************************
*
*       Fun:   soDnsProcNaptrUDNSTmr
*
*       Desc:  generate initial DNS query
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsProcNaptrUDNSTmr
(
PTR       rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsProcNaptrUDNSTmr(rsp, q)
PTR       rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   SoDnsQueryCb *cb;      /* target */
   
   TRC2(soDnsProcNaptrUDNSTmr);

   UNUSED(rsp);
   cb = *q;
   RETVALUE(soDnsDoNaptrRecur(cb));
} /* soDnsProcNaptrUDNSTmr */
#endif /* SO_ENUM */

/*****************************************************************************
*
*       Fun:   soDnsInvErrHandle
*
*       Desc:  generate initial DNS query
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsInvErrHandle
(
PTR       rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsInvErrHandle(rsp, q)
PTR       rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   CmTptAddr    addr;
   SoDnsQueryCb *cb;      /* target */
   
   TRC2(soDnsInvErrHandle);

   UNUSED(rsp);
   cb = *q;
   cmMemset((U8 *)&addr, 0, sizeof(CmTptAddr));
   (cb->callback)((PTR)&cb->usrCtxt, 
                  SO_DNS_ADDR_TYPE_ERROR,
                  &addr, cb->tptProt, NULLP);
   RETVALUE(ROK);
} /* soDnsInvErrHandle */

/*****************************************************************************
*
*       Fun:   soDnsInitQuery
*
*       Desc:  generate initial DNS query
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsInitQuery
(
PTR       rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsInitQuery(rsp, q)
PTR       rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   S16 ret;
   SoDnsQueryCb *cb;      /* target */
   
   TRC2(soDnsInitQuery);

   if(rsp != NULLP || q == NULLP || *q == NULLP) 
   {
      RETVALUE(RFAILED);
   }
   
   cb = *q;
   ret = RFAILED;
   switch(cb->queryType)
   {
      case SO_DNS_ADDR_TYPE_A:
         ret = soDnsALookup(cb);
         break;
#ifdef SO_AAAA    
      case SO_DNS_ADDR_TYPE_AAAA:
         ret = soDnsAAAALookup(cb);
         break;
#endif    
#ifdef SO_INSTMSG
      case SO_DNS_ADDR_TYPE_IM:
         ret = soDnsImLookup(cb);
         break;         
#endif
#ifdef SO_PRESENCE      
      case SO_DNS_ADDR_TYPE_PRES:    
         ret = soDnsPresLookup(cb);
         break;     
#endif         
      case SO_DNS_ADDR_TYPE_NAPTRS:
         ret = soDnsNaptrSLookup(cb);
         break;         
      case SO_DNS_ADDR_TYPE_SRV:
         ret = soDnsSrvLookup(cb, cb->tptProt);
         break;         
         
#ifdef SO_ENUM
      case SO_DNS_ADDR_TYPE_TEL:
         ret = soDnsNaptrULookup(cb);
         break;         
#endif      
#ifdef SO_TEL
      case SO_DNS_ADDR_TYPE_FAX:
      case SO_DNS_ADDR_TYPE_MODEM:
         ret = soDnsNaptrULookup(cb);
         break;         
#endif   
      case SO_DNS_ADDR_TYPE_IP:
      case SO_DNS_ADDR_TYPE_ERROR:
      default:
         RETVALUE(RFAILED);
   }

   RETVALUE(ret);

} /* soDnsInitQuery */

#ifdef SO_AAAA

/*****************************************************************************
*
*       Fun: soDnsProcInAAAAResult
*
*       Desc: Handles DNS response from server for A type queries
*
*       Ret: ROK
*            RFAILED
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsProcInAAAAResult
(
PTR            rsp,
SoDnsQueryCb   **cb            /* dns query control block */
)
#else
PRIVATE S16 soDnsProcInAAAAResult(rsp,cb)
PTR            rsp;
SoDnsQueryCb   **cb;            /* dns query control block */
#endif
{
   CmDnsResponse  *dnsRsp;        /* Dns response -> resource records */
   CmDns1035RR    *aAnswer;         /* Dns A response */
   SoClDnsAEnt    *cacheEnt;        /* Caching entity */
   CmNetAddr      physicalAddr;     /* Physical address (if available) */
   U16            ret;              /* return value */
   U16            answerCnt;        /* number of returned answers to query */
   Cntr           i;                /* loop index */
   SoDnsQueryCb   *q;            /* dns query control block */

   TRC2(soDnsProcInAAAAResult);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Handle incoming AAAA Result\n"));
   
   q = *cb;
   dnsRsp = (CmDnsResponse *)rsp;
   (Void) cmMemset((U8 *)&physicalAddr, 0, sizeof(CmNetAddr));

  /*--- so009.201: Validate The Response Message Type ---*/
   if (dnsRsp->queryInfo.qType != CM_DNS_QTYPE_AAAA)
  /*--- so015.201: Return ROKDNA to drop this response --*/
     RETVALUE (ROKDNA);

  /*---- so016.201: Stop The Response Receive Timer -----*/
   soSchedTmr (q, SO_TMR_DNS_LOOKUP, TMR_STOP, NOTUSED);

   ret = soClFindDnsAEntry(&soCb.cacheInfoCb.dnsACache, 
                           &q->queryAddress, &cacheEnt);
   if (ret != ROK)
   {
      cacheEnt = NULLP;
   }
   answerCnt = dnsRsp->header.anCount;
   for (i = 0; i < answerCnt; i++)
   {
      if (dnsRsp->queryInfo.qType == CM_DNS_QTYPE_AAAA) 
      {
         U8 *adr = (U8*)&physicalAddr.u.ipv6NetAddr;

         /* Copy answer addr to physicalAddress */
         aAnswer = &dnsRsp->ans[i].rsrcRcrd;
         physicalAddr.type = CM_NETADDR_IPV6;
         for (i = 0; i < CM_INET_IPV6ADDR_SIZE; i++)
            adr[i] = aAnswer->rdata.ipv6Address[i];
      }
      else
         RETVALUE(RFAILED);         

      if (cacheEnt == NULLP)
      {
         ret = soClAddDnsAEntry(&soCb.cacheInfoCb.dnsACache,
            &q->queryAddress, &cacheEnt);
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
      }
      if(soClAddDnsARecord(cacheEnt, &physicalAddr,aAnswer->ttl) != ROK)
      {
         RETVALUE(RFAILED);
      }
   }

   ret = soDnsCacheFoundA(q,cacheEnt);

   RETVALUE(ret);
} /* soDnsProcInAAAAResult */
#endif /* SO_AAAA */


/*****************************************************************************
*
*       Fun: soDnsProcInAResult
*
*       Desc: Handles DNS response from server for A type queries
*
*       Ret: ROK
*            RFAILED
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsProcInAResult
(
PTR            rsp,
SoDnsQueryCb   **cb             /* dns query control block */
)
#else
PRIVATE S16 soDnsProcInAResult(rsp, cb)
PTR            *rsp;       /* Dns response -> resource records */
SoDnsQueryCb   **cb;            /* dns query control block */
#endif
{
   CmDnsResponse  *dnsRsp;       /* Dns response -> resource records */
   CmDns1035RR    *aAnswer;      /* Dns A response */
   SoClDnsAEnt    *cacheEnt;     /* Caching entity */
   CmNetAddr      physicalAddr;  /* Physical address (if available) */
   U16            ret;           /* return value */
   U16            answerCnt;     /* num of returned answers to query */
   Cntr           i;             /* loop index */
   SoDnsQueryCb   *q;            /* dns query control block */

   TRC2(soDnsProcInAResult);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Handle incoming A Result\n"));
   
   q = *cb;
   dnsRsp = (CmDnsResponse *)rsp;
   (Void) cmMemset((U8 *)&physicalAddr, 0, sizeof(CmNetAddr));
   
  /*--- so009.201: Validate The Response Message Type ---*/
   if (dnsRsp->queryInfo.qType != CM_DNS_QTYPE_A)
  /*--- so015.201: Return ROKDNA to drop this response --*/
     RETVALUE (ROKDNA);

  /*---- so016.201: Stop The Response Receive Timer -----*/
   soSchedTmr (q, SO_TMR_DNS_LOOKUP, TMR_STOP, NOTUSED);

   ret = soClFindDnsAEntry(&soCb.cacheInfoCb.dnsACache, 
                           &q->queryAddress, &cacheEnt);
   if (ret != ROK)
   {
      cacheEnt = NULLP;
   }
   if(dnsRsp->header.anCount == 0)
      RETVALUE(RFAILED);
   
   answerCnt = dnsRsp->header.anCount;
   for (i = 0; i < answerCnt; i++)
   {
      U8 *adr = (U8*)&physicalAddr.u.ipv4NetAddr;
      aAnswer = &dnsRsp->ans[i].rsrcRcrd;
      physicalAddr.type = CM_NETADDR_IPV4;
      adr[3] = GetHiByte(GetHiWord(aAnswer->rdata.ipAddress));
      adr[2] = GetLoByte(GetHiWord(aAnswer->rdata.ipAddress));
      adr[1] = GetHiByte(GetLoWord(aAnswer->rdata.ipAddress));
      adr[0] = GetLoByte(GetLoWord(aAnswer->rdata.ipAddress));

      if (cacheEnt == NULLP)
      {
         ret = soClAddDnsAEntry(&soCb.cacheInfoCb.dnsACache,
            &q->queryAddress, &cacheEnt);
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
      }
      if(soClAddDnsARecord(cacheEnt, &physicalAddr,aAnswer->ttl) != ROK)
      {
         RETVALUE(RFAILED);
      }
   }
   ret = soDnsCacheFoundA(q,cacheEnt);

   RETVALUE(ret);
} /* soDnsProcInAResult */

/*****************************************************************************
*
*       Fun:   soDnsProcInSrvResult
*
*       Desc:  proc incoming SRV result
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsProcInSrvResult
(
PTR          rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsProcInSrvResult(rsp, q)
PTR          rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   CmDns2782RR    *srvAnswer; /* Dns SRV response */
   SoClDnsSrvEnt  *cacheEnt;  /* Caching entity */
   TknStrOSXL     targetOSXL; /* OSXL representation of answer target */
   Bool           haveAddr;   /* Flag to indicate if address avail */
   CmNetAddr      physicalAddr; /* Physical address (if available) */
   U8             targetVal[CM_DNS_DNAME_LEN];/* for targetOSXL data */
   U16            ret;          /* return value */
   U16            answerCnt;    /* num returned answers to query */
   Cntr           i;            /* loop index */
   U32            ttl;          /* time to live of answer */
   U8             protocol;     /* UDP/TCP as the TCM understands it */
   CmDnsResponse  *dnsRsp;
   SoDnsQueryCb   *master;
   U8             pCount;
   SoDnsQueryCb   *dnsQuery;    /* target */
   U8             numCbs;
   
   TRC2(soRcvSrvResponse);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Handle incoming SRV Result\n"));
   
   (Void) cmMemset((U8 *)&physicalAddr, 0, sizeof(CmNetAddr));
   dnsQuery = *q;
   dnsRsp = (CmDnsResponse *)rsp;

  /*--- so009.201: Validate The Response Message Type ---*/
   if (dnsRsp->queryInfo.qType != CM_DNS_QTYPE_SRV)
  /*--- so015.201: Return ROKDNA to drop this response --*/
     RETVALUE (ROKDNA);

  /*---- so016.201: Stop The Response Receive Timer -----*/
   soSchedTmr (dnsQuery, SO_TMR_DNS_LOOKUP, TMR_STOP, NOTUSED);

   /* If there are answers in the cache 
    * its probably from our complimentary
    * UDP/TCP query, so we just add our 
    * results to it and return that */
   ret = soClFindDnsSrvEntry(&soCb.cacheInfoCb.dnsSrvCache, 
         &dnsQuery->queryAddress, &cacheEnt);
   if (ret != ROK)
   {
      cacheEnt = NULLP;
   }
   numCbs = 1;
   answerCnt       = dnsRsp->header.anCount;
   targetOSXL.val  = (U8*)targetVal;
   targetOSXL.pres = PRSNT_NODEF;

   /* Loop through answers and add */
   for (i = 0; i < answerCnt; i++)
   {
      srvAnswer = &dnsRsp->ans[i].srvRcrd;
      soDnsFindPhysicalAddr(srvAnswer,dnsRsp,
               &haveAddr,&physicalAddr,&ttl);

      targetOSXL.len = srvAnswer->targetLen;
      cmMemcpy(targetOSXL.val,srvAnswer->target,targetOSXL.len);

      switch(dnsRsp->queryInfo.protocol)
      {
    case CM_DNS_PROTOCOL_UDP:
            protocol = LSO_TPTPROT_UDP;
       break;
    case CM_DNS_PROTOCOL_TCP:
            protocol = LSO_TPTPROT_TCP;
       break;
#ifdef SO_TLS       
    case CM_DNS_PROTOCOL_TLS_TCP:
            protocol = LSO_TPTPROT_TLS_TCP;
       break;
#endif /* SO_TLS */
#ifdef SO_SCTP       
    case CM_DNS_PROTOCOL_SCTP:
            protocol = LSO_TPTPROT_SCTP;
       break;
#endif /* SO_SCTP */       
    default:
            protocol = LSO_TPTPROT_UDP;
       break;
      }

      /* If main entry exists just add, otherwise create one */
      if (cacheEnt != NULLP)
      {
         soClAddDnsSrvAnsEntry(cacheEnt,&targetOSXL,
                               srvAnswer->priority,srvAnswer->weight,
                               srvAnswer->port, ttl,protocol,
                               haveAddr,physicalAddr);
      }
      else
      {
         soClAddDnsSrvEntry(&soCb.cacheInfoCb.dnsSrvCache,
                            &dnsQuery->queryAddress,&targetOSXL,
                            srvAnswer->priority,srvAnswer->weight,
                            srvAnswer->port,ttl,protocol,
                            &cacheEnt,haveAddr,physicalAddr);
      }
   }

   dnsQuery->searchState = SO_DNS_FSM_SRV_WAIT;
   if(!dnsQuery->master)
   {
      master = dnsQuery->masterQueryCb;
   }
   else
   {
      master = dnsQuery;
   }
   pCount = 0;
   if(master->searchState == SO_DNS_FSM_SRV_WAIT)
      pCount++;
   if(master->tcpQueryCb != NULLP)
   {
      numCbs++;      
      if(master->tcpQueryCb->searchState == SO_DNS_FSM_SRV_WAIT)
         pCount++;
   }
#ifdef SO_TLS   
   if(master->tlsTcpQueryCb != NULLP)
   { 
      numCbs++;
      if(master->tlsTcpQueryCb->searchState == SO_DNS_FSM_SRV_WAIT)
         pCount++;
   }
#endif /* SO_TLS */
#ifdef SO_SCTP   
   if(master->sctpQueryCb != NULLP)
   {      
      numCbs++;
      if(master->sctpQueryCb->searchState == SO_DNS_FSM_SRV_WAIT)
         pCount++;
   }
#endif /* SO_SCTP */   
   if(pCount == numCbs)
   {
      master->searchState = SO_DNS_FSM_SRV;
      if(master->tcpQueryCb)
    master->tcpQueryCb->searchState = SO_DNS_FSM_SRV;      
#ifdef SO_TLS      
      if(master->tlsTcpQueryCb)
         master->tlsTcpQueryCb->searchState = SO_DNS_FSM_SRV;
#endif /* SO_TLS */
#ifdef SO_SCTP      
      if(master->sctpQueryCb)
         master->sctpQueryCb->searchState = SO_DNS_FSM_SRV;
#endif /* SO_SCTP */      
   }
   
        
   if(dnsQuery->searchState != SO_DNS_FSM_SRV)
      RETVALUE(ROK);      
#ifdef SO_SCTP    
   if(master->sctpQueryCb != NULLP)
   {
      soDnsFreeQueryCb(master->sctpQueryCb);
      master->sctpQueryCb = NULLP;
   }
#endif /* SO_SCTP */   
#ifdef SO_TLS   
   if(master->tlsTcpQueryCb != NULLP)
   {
      soDnsFreeQueryCb(master->tlsTcpQueryCb);
      master->tlsTcpQueryCb = NULLP;
   }
#endif /* SO_TLS */   
   if(master->tcpQueryCb != NULLP)
   {
      soDnsFreeQueryCb(master->tcpQueryCb);
      master->tcpQueryCb = NULLP;
   }
   if(master->tcpQueryCb != NULLP)
   {
      soDnsFreeQueryCb(master->tcpQueryCb);
      master->tcpQueryCb = NULLP;
   }
   
   master->numCbs = 0;      
   if(cacheEnt == NULLP || soDnsCacheFoundSrv(master,cacheEnt) != ROK)
   {
      *q = master;      
      RETVALUE(RFAILED);
   }      
   RETVALUE(ROK);
} /* soDnsProcInSrvResult */

#ifdef SO_INSTMSG
/*****************************************************************************
*
*       Fun:   soDnsProcInImResult
*
*       Desc:  proc incoming SRV result
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsProcInImResult
(
PTR       rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsProcInImResult(rsp, q)
PTR       rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   CmDns2782RR    *srvAnswer; /* Dns SRV response */
   SoClDnsSrvEnt  *cacheEnt;  /* Caching entity */
   TknStrOSXL     targetOSXL; /* OSXL representation of ans target */
   Bool           haveAddr;   /* Flag to indicate if address avail */
   CmNetAddr      physicalAddr;/* Physical address (if available) */
   U8             targetVal[CM_DNS_DNAME_LEN];  /* space for tgtOSXL */
   U16            ret;              /* return value */
   U16            answerCnt;   /* num of returned answers to query */
   Cntr           i;           /* loop index */
   CmDnsResponse  *dnsRsp;
   SoDnsQueryCb   *dnsQuery;   /* target */

   TRC2(soRcvImResponse);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Handle incoming IM Result\n"));
   
   (Void) cmMemset((U8 *)&physicalAddr, 0, sizeof(CmNetAddr));
   dnsQuery = *q;
   haveAddr = FALSE;
   dnsRsp = (CmDnsResponse *)rsp;

  /*--- so009.201: Validate The Response Message Type ---*/
   if (dnsRsp->queryInfo.qType != CM_DNS_QTYPE_SRV)
  /*--- so015.201: Return ROKDNA to drop this response --*/
     RETVALUE (ROKDNA);

  /*---- so016.201: Stop The Response Receive Timer -----*/
   soSchedTmr (dnsQuery, SO_TMR_DNS_LOOKUP, TMR_STOP, NOTUSED);

   ret = soClFindDnsSrvEntry(&soCb.cacheInfoCb.dnsSrvCache, 
         &dnsQuery->queryAddress, &cacheEnt);
   if (ret != ROK)
   {
      cacheEnt = NULLP;
   }

   answerCnt       = dnsRsp->header.anCount;
   targetOSXL.val  = (U8*)targetVal;
   targetOSXL.pres = PRSNT_NODEF;


   /* Loop through answers and add */
   for (i = 0; i < answerCnt; i++)
   {
      srvAnswer = &dnsRsp->ans[i].srvRcrd;
      targetOSXL.len = srvAnswer->targetLen;
      cmMemcpy(targetOSXL.val,srvAnswer->target,targetOSXL.len);

      if (dnsRsp->queryInfo.protocol == CM_DNS_PROTOCOL_SIP)
      {
         if (cacheEnt != NULLP)
         {
            soClAddDnsSrvAnsEntry(cacheEnt,&targetOSXL,
                               srvAnswer->priority,srvAnswer->weight,
                               srvAnswer->port, srvAnswer->ttl,LSO_TPTPROT_UDP,
                               haveAddr,physicalAddr);
         }
         else
         {
            soClAddDnsSrvEntry(&soCb.cacheInfoCb.dnsSrvCache,
                            &dnsQuery->queryAddress,&targetOSXL,
                            srvAnswer->priority,srvAnswer->weight,
                            srvAnswer->port,srvAnswer->ttl,LSO_TPTPROT_UDP,
                            &cacheEnt,haveAddr,physicalAddr);
         }
      }
   }
   if(soDnsCacheFoundSrv(dnsQuery,cacheEnt) != ROK)
      RETVALUE(RFAILED);      
   RETVALUE(ROK);
} /* soDnsProcInImResult */
#endif /* SO_INSTMSG */

#ifdef SO_PRESENCE
/*****************************************************************************
*
*       Fun:   soDnsProcInPresResult
*
*       Desc:  proc incoming SRV result
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsProcInPresResult
(
PTR          rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsProcInPresResult(rsp, q)
PTR          rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   CmDns2782RR    *srvAnswer;       /* Dns SRV response */
   SoClDnsSrvEnt  *cacheEnt;        /* Caching entity */
   TknStrOSXL     targetOSXL;       /* OSXL representation of answer target */
   Bool           haveAddr;         /* Flag to indicate if address available */
   CmNetAddr      physicalAddr;     /* Physical address (if available) */
   U8             targetVal[CM_DNS_DNAME_LEN];  /* space for targetOSXL data */
   U16            ret;              /* return value */
   U16            answerCnt;        /* number of returned answers to query */
   Cntr           i;                /* loop index */
   U8             protocol;         /* UDP or TCP as the TCM understands it */
   CmDnsResponse  *dnsRsp;
   SoDnsQueryCb   *dnsQuery;        /* target */
   
   TRC2(soRcvPresResponse);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Handle incoming Pres Result\n"));
   
   cmMemset ((U8 *)&physicalAddr, 0, sizeof (CmNetAddr));

   dnsQuery = *q;
   haveAddr = FALSE;
   dnsRsp = (CmDnsResponse *)rsp;

  /*--- so009.201: Validate The Response Message Type ---*/
   if (dnsRsp->queryInfo.qType != CM_DNS_QTYPE_SRV)
  /*--- so015.201: Return ROKDNA to drop this response --*/
     RETVALUE (ROKDNA);

  /*---- so016.201: Stop The Response Receive Timer -----*/
   soSchedTmr (dnsQuery, SO_TMR_DNS_LOOKUP, TMR_STOP, NOTUSED);

   ret = soClFindDnsSrvEntry(&soCb.cacheInfoCb.dnsSrvCache, 
         &dnsQuery->queryAddress, &cacheEnt);
   if (ret != ROK)
   {
      cacheEnt = NULLP;
   }

   answerCnt       = dnsRsp->header.anCount;
   targetOSXL.val  = (U8*)targetVal;
   targetOSXL.pres = PRSNT_NODEF;


   /* Loop through answers and add */
   for (i = 0; i < answerCnt; i++)
   {
      srvAnswer = &dnsRsp->ans[i].srvRcrd;
      targetOSXL.len = srvAnswer->targetLen;
      cmMemcpy(targetOSXL.val,srvAnswer->target,targetOSXL.len);

      if (dnsRsp->queryInfo.protocol == CM_DNS_PROTOCOL_UDP)
      {
         protocol = LSO_TPTPROT_UDP;
         if (cacheEnt != NULLP)
         {
            ret = soClAddDnsSrvAnsEntry(cacheEnt,&targetOSXL,
                               srvAnswer->priority,srvAnswer->weight,
                               srvAnswer->port, srvAnswer->ttl,protocol,
                               haveAddr,physicalAddr);
         }
         else
         {
            ret = soClAddDnsSrvEntry(
            &soCb.cacheInfoCb.dnsSrvCache,&dnsQuery->queryAddress,
            &targetOSXL,
            srvAnswer->priority,srvAnswer->weight,
            srvAnswer->port, srvAnswer->ttl,protocol,
            &cacheEnt,haveAddr,physicalAddr);
         }
      }
   }
   if(soDnsCacheFoundSrv(dnsQuery,cacheEnt) != ROK)
      RETVALUE(RFAILED);      
   RETVALUE(ROK);
} /* soDnsProcInPresResult */

#endif /* SO_PRESENCE */

/*****************************************************************************
*
*       Fun:   soDnsProcInNaptrSResult
*
*       Desc:  proc incoming naptr s result
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsProcInNaptrSResult
(
PTR          rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsProcInNaptrSResult(rsp, q)
PTR          rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   CmDns2915RR    *nAnswer;         /* Dns NAPTR response */
   SoClDnsNaptrEnt *cacheEnt;       /* Caching entity */
   S16            ret;              /* return value */
   U16            answerCnt;        /* number of returned answers to query */
   Cntr           i;                /* loop index */
   U8             regexp[CM_DNS_DNAME_LEN];
   TknStrOSXL     targetOSXL;       /* OSXL representation of answer */
   CmDnsResponse  *dnsRsp;
   U16            actualAns;
   SoDnsQueryCb   *dnsQueryCb;      /* target */
   
   TRC2(soDnsProcInNaptrSResult);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Handle incoming NAPTRS Result\n"));
   
   dnsQueryCb = *q;
   if (dnsQueryCb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO078, ERRZERO,
                      "soDnsProcInNaptrSResult: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
   }

   dnsRsp = (CmDnsResponse *)rsp;
   
  /*--- so009.201: Validate The Response Message Type ---*/
   if (dnsRsp->queryInfo.qType != CM_DNS_QTYPE_NAPTR)
  /*--- so015.201: Return ROKDNA to drop this response --*/
     RETVALUE (ROKDNA);

  /*---- so016.201: Stop The Response Receive Timer -----*/
   soSchedTmr (dnsQueryCb, SO_TMR_DNS_LOOKUP, TMR_STOP, NOTUSED);

   ret = soClFindDnsNaptrEntry(&soCb.cacheInfoCb.dnsNaptrCache, 
                     &dnsQueryCb->queryAddress, &cacheEnt);
   if (ret != ROK)
   {
      cacheEnt = NULLP;
   }

   answerCnt      = dnsRsp->header.anCount;
   targetOSXL.val = (U8*)regexp;
   targetOSXL.pres = PRSNT_NODEF;
   actualAns = 0;
   
   /* Loop through answers and add */
   for (i = 0; i < answerCnt; i++)
   {
     
      /* Copy answer addr to physicalAddress */
      nAnswer = &dnsRsp->ans[i].naptrRcrd;
#ifndef SO_TLS
      if(nAnswer->replacementLen >= 11 && 
         cmMemcmp(nAnswer->replacement, (CONSTANT U8 *)"_sips._tcp.", 11) == 0)
/* so022.201 : removed warnings */
         continue;         
#endif /* SO_TLS */
#ifndef SO_SCTP
      if(nAnswer->replacementLen >= 11 && 
         cmMemcmp(nAnswer->replacement, (CONSTANT U8 *)"_sip._sctp.", 11) == 0)
         continue;         
#endif /* SO_SCTP */
      targetOSXL.len = nAnswer->replacementLen;
      cmMemcpy (targetOSXL.val, nAnswer->replacement, targetOSXL.len);

      /* If main entry exists just add, otherwise create one */
      if (cacheEnt != NULLP)
      {
         soClAddDnsNaptrAnsEntry(cacheEnt, &targetOSXL, nAnswer->order,
                         nAnswer->preference, nAnswer->ttl, FALSE);
      }
      else
      {
         ret = soClAddDnsNaptrEntry(&soCb.cacheInfoCb.dnsNaptrCache,
                                    &dnsQueryCb->queryAddress, 
                                    &targetOSXL, 
                                    nAnswer->order, nAnswer->preference,
                                    nAnswer->ttl, &cacheEnt, FALSE);  
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
      }
      actualAns++;
   }

   if(cacheEnt == NULLP || actualAns == 0)
   {
      RETVALUE(soDnsSrvLookup(dnsQueryCb, dnsQueryCb->tptProt));
   }
   
   ret = soDnsCacheFoundNaptr(dnsQueryCb,cacheEnt, FALSE);

   RETVALUE(ret);
} /* soDnsProcInNaptrSResult */

#ifdef SO_ENUM
/*****************************************************************************
*
*       Fun:   soDnsProcInNaptrUResult
*
*       Desc:  proc incoming naptr u result
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsProcInNaptrUResult
(
PTR       rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsProcInNaptrUResult(rsp, q)
PTR       rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   S16            ret;
   CmDns2915RR    *nAnswer;   /* Dns NAPTR response */
   SoClDnsNaptrEnt *cacheEnt; /* Caching entity */
   U16            answerCnt;  /* num of returned answers to query */
   Cntr           i;          /* loop index */
   U8             regexp[CM_DNS_DNAME_LEN];
   TknStrOSXL     targetOSXL; /* OSXL representation of answer */
   CmDnsResponse  *dnsRsp;
   U8             buf[CM_DNS_DNAME_LEN+9];  
   SoDnsNaptrResult *naptrResult;  /* used for removing duplicates */
   Bool           dupHit;     /* for finding duplicate naptr result */
   U16            e164StrLen;
   U8             serviceType;
   U16            numValidRec;
   SoDnsQueryCb   *dnsQueryCb;     /* target *//* so024.201 */
   
   TRC2(soDnsProcInNaptrUResult);
   
   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Handle incoming NAPTRU Result\n"));
   
   dnsQueryCb = *q;
   if (dnsQueryCb == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO079, ERRZERO,
                      "soDnsProcInNaptrUResult: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
   }
   
   dnsRsp = (CmDnsResponse *)rsp;
   numValidRec = 0;

  /*--- so009.201: Validate The Response Message Type ---*/
   if (dnsRsp->queryInfo.qType != CM_DNS_QTYPE_NAPTR)
  /*--- so015.201: Return ROKDNA to drop this response --*/
     RETVALUE (ROKDNA);

  /*---- so016.201: Stop The Response Receive Timer -----*/
   soSchedTmr (dnsQueryCb, SO_TMR_DNS_LOOKUP, TMR_STOP, NOTUSED);

   ret = soClFindDnsNaptrEntry(&soCb.cacheInfoCb.dnsNaptrCache, 
                     &dnsQueryCb->queryAddress, &cacheEnt);
   if (ret != ROK)
   {
      cacheEnt = NULLP;
   }

   answerCnt      = dnsRsp->header.anCount;
   targetOSXL.val = (U8*)regexp;
   targetOSXL.pres = PRSNT_NODEF;

   /* Loop through answers and add */
   for (i = 0; i < answerCnt; i++)
   {
      /* Copy answer addr to physicalAddress */
      nAnswer = &dnsRsp->ans[i].naptrRcrd;
      targetOSXL.len = nAnswer->regexpLen;
      cmMemcpy (targetOSXL.val, nAnswer->regexp, targetOSXL.len);
      serviceType = SO_DNS_ENUM_RSPTYPE_INVALID;
      e164StrLen = 0;
      if(soDnsGetEnumRspInfo(nAnswer,&serviceType,
            buf,&e164StrLen,CM_DNS_DNAME_LEN) != ROK)
         continue;
      dupHit = FALSE;
      /* loop detection. Only does tel part. 
       * SIP url part will be done in GA */
      if(serviceType == SO_DNS_ENUM_RSPTYPE_TEL_E2U &&         dnsQueryCb->naptrUCp.first != NULLP)
      {
         naptrResult =
            (SoDnsNaptrResult *)(dnsQueryCb->naptrUCp.first->node);
         /* set the default to be false */
         /* recurse through the naptrUCp list */
         while(naptrResult != NULLP)
         {
            /* if have a match drop the entry */
            if(e164StrLen == 
                  naptrResult->originalQuery.len && 
               cmMemcmp(buf, 
                  naptrResult->originalQuery.val, 
                  e164StrLen) == 0)
            {
               dupHit = TRUE;
               break;
            }
            else
            {
               if(naptrResult->node.next != NULLP)
                  naptrResult = 
                  (SoDnsNaptrResult *)(naptrResult->node.next->node);
               else
                  naptrResult = NULLP;
            }
         }
      }
         
      /* dump the duplicate */
      if(dupHit == TRUE)
      {
         continue;
      }

      /* If main entry exists just add, otherwise create one */
      if (cacheEnt != NULLP)
      {
         soClAddDnsNaptrAnsEntry(cacheEnt, &targetOSXL, nAnswer->order,
                         nAnswer->preference, nAnswer->ttl, TRUE);
      }
      else
      {
         ret = soClAddDnsNaptrEntry(&soCb.cacheInfoCb.dnsNaptrCache,
                                    &dnsQueryCb->queryAddress, 
                                    &targetOSXL, 
                                    nAnswer->order, nAnswer->preference,
                                    nAnswer->ttl, &cacheEnt, TRUE);  
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
      }
      /* increase the counter */
      numValidRec++;
   }
   if(numValidRec > 0)
      RETVALUE(soDnsCacheFoundNaptr(dnsQueryCb,cacheEnt, TRUE));
   else
      /* recurse here */
      RETVALUE(soDnsDoNaptrRecur(dnsQueryCb));
} /* soDnsProcInNaptrUResult */

#endif /* SO_ENUM */

/*****************************************************************************
*
*       Fun:   soDnsNaptrSLookup
*
*       Desc:  Performs DNS NAPTR type lookup
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: Checks DNS cache
*              If not found, query DNS server
*              Use callback function to return result to caller
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsNaptrSLookup
(
SoDnsQueryCb *newQueryCb
)
#else
PRIVATE S16 soDnsNaptrSLookup(newQueryCb)
SoDnsQueryCb *newQueryCb;
#endif
{
   S16               ret;         /* Return value */
   SoClDnsNaptrEnt   *result;     /* Result from cache lookup */
   TknStrOSXL        *hostName;
   SoDnsQueryCb      *dnsQuery;

   TRC2(soDnsNaptrSLookup);

   dnsQuery = newQueryCb;
   hostName = &dnsQuery->queryAddress;

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Performing NAPTRS Lookup\n"));
   
   /* Control block created, check cache */
   ret = soClFindDnsNaptrEntry(&soCb.cacheInfoCb.dnsNaptrCache, 
                               hostName, 
                               &result);
   if ((ret == ROK) && (result->listCp.count != 0))
   {
      /* Cache had valid records, return to user */

      if(soDnsCacheFoundNaptr(dnsQuery,result, FALSE) != ROK)
      {
         RETVALUE(RFAILED);
      }
      else
      {
         /*-- so032.201: Adding Debug Prints ---------------------------------*/
         SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
                  "[DNS] Found NAPTRS in Cache\n"));

         RETVALUE(ROK);
      }
   }
   dnsQuery->searchState = SO_DNS_FSM_NAPTRS;
   ret = soSendDnsQuery(dnsQuery, (U8)hostName->len,hostName->val,
                        CM_DNS_QTYPE_NAPTR, CM_DNS_PROTOCOL_UDP,
                        CM_DNS_SERVICE_SIP);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* soDnsNaptrSLookup */


/*****************************************************************************
*
*       Fun:   soDnsSrvLookup
*
*       Desc:  Performs DNS SRV type lookup
*
*       Ret:   ROK on success
*              RFAILED on error
*
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsSrvLookup
(
SoDnsQueryCb     *query,
U8               tptProt
)
#else
PRIVATE S16 soDnsSrvLookup(query, tptProt)
SoDnsQueryCb     *query;
U8               tptProt;
#endif
{
   S16             ret;         /* Return value */
#ifdef SO_TLS
   SoDnsQueryCb    *newTlsTcpQuery; /* DNS query control block */
#endif /* SO_TLS */  
#ifdef SO_SCTP
   SoDnsQueryCb    *newSctpPQuery; /* DNS query control block */
#endif /* SO_SCTP */  
   SoDnsQueryCb    *newTcpQuery;   /* DNS query control block */
   SoClDnsSrvEnt   *result;     /* Result from cache lookup */
   U8              protocol;
   /* so027.201 : Changes for SIP TLS support */
   U8              service = CM_DNS_SERVICE_SIP;
   
   TRC2(soDnsSrvLookup);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Performing SRV Lookup\n"));
   
   query->tptProt = tptProt;   
   ret = soClFindDnsSrvEntry(&soCb.cacheInfoCb.dnsSrvCache, 
                &query->queryAddress, &result);
   if (ret == ROK && soDnsCacheSrvHit(query, result) == ROK)
   {
      /*-- so032.201: Adding Debug Prints ------------------------------------*/
      SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
               "[DNS] Found SRV Record in Cache\n"));

      /* Cache had valid records, return to user */
      RETVALUE(soDnsCacheFoundSrv(query,result));
   }
   
   if(tptProt != LSO_TPTPROT_NULL) 
   {         
      query->searchState = SO_DNS_FSM_SRV;
      
      query->retryCount  = 0;
      
      if(tptProt == LSO_TPTPROT_UDP)
         protocol = CM_DNS_PROTOCOL_UDP;
      else if(tptProt == LSO_TPTPROT_TCP)
         protocol = CM_DNS_PROTOCOL_TCP;
#ifdef SO_TLS      
      /* so027.201 : Changes for SIP TLS support */
      else if(tptProt == LSO_TPTPROT_TLS_TCP)
      {
         protocol = CM_DNS_PROTOCOL_TLS_TCP;
         service = CM_DNS_SERVICE_SIPS;
      }
#endif /* SO_TLS */      
#ifdef SO_SCTP
      else if(tptProt == LSO_TPTPROT_SCTP)
         protocol = CM_DNS_PROTOCOL_SCTP;
#endif
         
      ret = soSendDnsQuery(query, (U8)query->queryAddress.len,
                           query->queryAddress.val,CM_DNS_QTYPE_SRV,
                           protocol, service);
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }
   }
   else
   {
      query->tptProt = LSO_TPTPROT_UDP;      
      query->searchState = SO_DNS_FSM_SRV;
      ret = soSendDnsQuery(query, (U8)query->queryAddress.len,
                           query->queryAddress.val,CM_DNS_QTYPE_SRV,
                           CM_DNS_PROTOCOL_UDP, CM_DNS_SERVICE_SIP);
      /* master should be successful */
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }
      if(soDnsCreateQueryCb((PTR)&query->usrCtxt, query->reqAddr, 
                         SO_DNS_ADDR_TYPE_SRV,
                         (TknU16 *)&query->origPort, 
                         &query->queryAddress, 
                         LSO_TPTPROT_TCP,
                         (SoDnsQueryCb **)&newTcpQuery, 
                         query->reqAddr->addrSpecType.val, 
                         query->callback, FALSE) == ROK)
      {
         newTcpQuery->queryType = query->queryType;
         query->tcpQueryCb = newTcpQuery;
         newTcpQuery->masterQueryCb = query;
         query->tcpQueryCb->searchState = SO_DNS_FSM_SRV;
         ret = soSendDnsQuery(newTcpQuery, 
               (U8)newTcpQuery->queryAddress.len,
               newTcpQuery->queryAddress.val,
               CM_DNS_QTYPE_SRV,
               CM_DNS_PROTOCOL_TCP, CM_DNS_SERVICE_SIP);
         if(ret != ROK)
         {
            soDnsFreeQueryCb(newTcpQuery);
            query->tcpQueryCb = NULLP;
         }
    else
       query->numCbs++;
      }
#ifdef SO_TLS      
      if(soDnsCreateQueryCb((PTR)&query->usrCtxt, query->reqAddr, 
                    SO_DNS_ADDR_TYPE_SRV,
                    (TknU16 *)&query->origPort, 
                    &query->queryAddress, 
                    LSO_TPTPROT_TLS_TCP,
                    (SoDnsQueryCb **)&newTlsTcpQuery, 
                    query->reqAddr->addrSpecType.val, 
                    query->callback, FALSE) == ROK)
      {
         query->tlsTcpQueryCb = newTlsTcpQuery;
         newTlsTcpQuery->masterQueryCb = query;    
         query->tlsTcpQueryCb->searchState = SO_DNS_FSM_SRV;
         ret = soSendDnsQuery(newTlsTcpQuery, 
                           (U8)newTlsTcpQuery->queryAddress.len,
                           newTlsTcpQuery->queryAddress.val,
            CM_DNS_QTYPE_SRV,
            CM_DNS_PROTOCOL_TLS_TCP, CM_DNS_SERVICE_SIPS);
         if(ret != ROK)
         {
            soDnsFreeQueryCb(newTlsTcpQuery);
            query->tlsTcpQueryCb = NULLP;
         }
    else
       query->numCbs++;
      }
#endif      
#ifdef SO_SCTP      
      if(soDnsCreateQueryCb((PTR)&query->usrCtxt, query->reqAddr, 
                    query->queryType, 
                    (TknU16 *)&query->origPort, 
                    &query->queryAddress, 
                    LSO_TPTPROT_SCTP,
                    (SoDnsQueryCb **)&newSctpQuery, 
                    query->reqAddr->addrSpecType.val, 
                    query->callback, FALSE) == ROK)
      {
         query->SctpQueryCb = newSctpQuery;
         newSctpQuery->masterQueryCb = queryCb;    
         query->sctpQueryCb->searchState = SO_DNS_FSM_SRV;
         ret = soSendDnsQuery(newTcpQuery, 
                           (U8)newSctpQuery->queryAddress.len,
                           newSctpQuery->queryAddress.val,
            CM_DNS_QTYPE_SRV,
            CM_DNS_PROTOCOL_SCTP, CM_DNS_SERVICE_SIP);
         if(ret != ROK)
         {
            soDnsFreeQueryCb(newSctpQuery);
            query->sctpQueryCb = NULLP;
         }
    else
       query->numCbs++;
      }
#endif      
   }
   RETVALUE(ROK);
} /* soDnsSrvLookup */

/*****************************************************************************
*
*       Fun:   soDnsALookup
*
*       Desc:  Performs DNS A type lookup
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: Checks DNS cache
*              If not found, query DNS server
*              Use callback function to return result to caller
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsALookup
(
SoDnsQueryCb    *query
)
#else
PRIVATE S16 soDnsALookup(query)
SoDnsQueryCb    *query;
#endif
{
   S16             ret;         /* Return value */
   SoClDnsAEnt     *result;     /* Result from cache lookup */

   TRC2(soDnsALookup);
   query->numCbs = 0;

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Performing A Record Lookup\n"));
   
   /* Control block created, check cache */
   ret = soClFindDnsAEntry(&soCb.cacheInfoCb.dnsACache, 
                 &query->queryAddress, &result);
   if (ret == ROK)
   {
      /*-- so032.201: Adding Debug Prints ------------------------------------*/
      SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
               "[DNS] Found A Record in Cache\n"));

      /* Cache had valid records, return to user */
      if(soDnsCacheFoundA(query,result) != ROK)
         RETVALUE(RFAILED);
      RETVALUE(ROK);
   }

   /* Nothing from cache */

   /* Construct new query and send to DNS server */
   
   query->retryCount = 0;

   query->searchState = SO_DNS_FSM_A;

   ret = soSendDnsQuery(query, (U8)query->queryAddress.len,
                        query->queryAddress.val,CM_DNS_QTYPE_A,
                        CM_DNS_PROTOCOL_UDP,CM_DNS_SERVICE_SIP);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* soDnsALookup */
#ifdef SO_AAAA
/*****************************************************************************
*
*       Fun:   soDnsAAAALookup
*
*       Desc:  Performs DNS AAAA type lookup
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: Checks DNS cache
*              If not found, query DNS server
*              Use callback function to return result to caller
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsAAAALookup
(
SoDnsQueryCb    *query
)
#else
PRIVATE S16 soDnsAAAALookup(query)
SoDnsQueryCb    *query;
#endif
{
   S16             ret;         /* Return value */
   SoClDnsAEnt     *result;     /* Result from cache lookup */

   TRC2(soDnsAAAALookup);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Performing AAAA Record Lookup\n"));
   
   ret = soClFindDnsAEntry(&soCb.cacheInfoCb.dnsACache, 
                 &query->queryAddress, &result);
   if (ret == ROK)
   {
      /*-- so032.201: Adding Debug Prints ------------------------------------*/
      SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
               "[DNS] Found AAAA Record in Cache\n"));

      /* Cache had valid records, return to user */
      RETVALUE(soDnsCacheFoundA(query,result));
   }

   /* Nothing from cache */

   /* Construct new query and send to DNS server */
   
   query->retryCount = 0;

   query->searchState = SO_DNS_FSM_AAAA;

   ret = soSendDnsQuery(query, (U8)query->queryAddress.len,
                        query->queryAddress.val, 
                        CM_DNS_QTYPE_AAAA,CM_DNS_PROTOCOL_UDP,
                        CM_DNS_SERVICE_SIP);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* soDnsAAAALookup */
#endif /* SO_AAAA */

#ifdef SO_INSTMSG

/*****************************************************************************
*
*       Fun:   soDnsImLookup
*
*       Desc:  Performs DNS IM type lookup
*
*       Ret:   ROK on success
*              RFAILED on error
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsImLookup
(
SoDnsQueryCb     *query
)
#else
PRIVATE S16 soDnsImLookup(query)
SoDnsQueryCb     *query;
#endif
{
   S16             ret;         /* Return value */
   SoClDnsSrvEnt   *result;     /* Result from cache lookup */
   TknStrOSXL      tmpStr;
   
   TRC2(soDnsImLookup);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Performing IM Lookup\n"));
   
   SOALLOC(&tmpStr.val, (query->queryAddress.len+3));
   if(tmpStr.val == NULLP)
      RETVALUE(RFAILED);

   tmpStr.pres = PRSNT_NODEF;
   tmpStr.len = query->queryAddress.len+3;
   cmMemcpy(tmpStr.val, query->queryAddress.val, 
            query->queryAddress.len);
   tmpStr.val[query->queryAddress.len]   = '_';
   tmpStr.val[query->queryAddress.len+1] = 'i';
   tmpStr.val[query->queryAddress.len+2] = 'm';
   ret = soClFindDnsSrvEntry(&soCb.cacheInfoCb.dnsSrvCache, 
                      &tmpStr, &result);
   soUtlDelTknStrOSXL(&tmpStr);
   if (ret == ROK)
   {
      /*-- so032.201: Adding Debug Prints ------------------------------------*/
      SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
               "[DNS] Found IM Record in Cache\n"));

      query->searchState = SO_DNS_FSM_IM_CACHE;
      soDnsCacheFoundIm(query,result);
      RETVALUE(ROK);
   }

      
   query->searchState = SO_DNS_FSM_IM;
   
   query->retryCount  = 0;

   ret = soSendDnsQuery(query, (U8)query->queryAddress.len,
                        query->queryAddress.val,CM_DNS_QTYPE_SRV,
                        CM_DNS_PROTOCOL_SIP, CM_DNS_SERVICE_IM);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* soDnsImLookup */
#endif /* SO_INSTMSG */

#ifdef SO_PRESENCE

/*****************************************************************************
*
*       Fun:   soDnsPresLookup
*
*       Desc:  Performs DNS PRES type lookup
*
*       Ret:   ROK on success
*              RFAILED on error
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsPresLookup
(
SoDnsQueryCb     *query
)
#else
PRIVATE S16 soDnsPresLookup(query)
SoDnsQueryCb     *query;
#endif
{
   S16             ret;         /* Return value */
   SoClDnsSrvEnt   *result;     /* Result from cache lookup */
   U8              service;
   TknStrOSXL      tmpStr;
   
   TRC2(soDnsPresLookup);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Performing Pres Record Lookup\n"));
   
   SOALLOC(tmpStr.val, (query->queryAddress.len+5));
   if(tmpStr.val == NULLP)
      RETVALUE(RFAILED);

   tmpStr.len = query->queryAddress.len+5;
   cmMemcpy(tmpStr.val, query->queryAddress.val, 
            query->queryAddress.len);
   tmpStr.val[query->queryAddress.len]   = '_';
   tmpStr.val[query->queryAddress.len+1] = 'p';
   tmpStr.val[query->queryAddress.len+2] = 'r';
   tmpStr.val[query->queryAddress.len+3] = 'e';
   tmpStr.val[query->queryAddress.len+4] = 's';
   ret = soClFindDnsSrvEntry(&soCb.cacheInfoCb.dnsSrvCache, 
                      &tmpStr, &result);
   soUtlDelTknStrOSXL(&tmpStr);
   if (ret == ROK)
   {
      /*-- so032.201: Adding Debug Prints ------------------------------------*/
      SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
               "[DNS] Found Pres Record in Cache\n"));

      query->searchState = SO_DNS_FSM_PRES_CACHE;
      soCacheFoundPres(query,result);
      RETVALUE(ROK);
   }

      
   query->searchState = SO_DNS_FSM_PRES;
   
   query->retryCount  = 0;

   ret = soSendDnsQuery(query, (U8)query->queryAddress.len,
                        query->queryAddress.val,CM_DNS_QTYPE_SRV,
                        CM_DNS_PROTOCOL_UDP, CM_DNS_SERVICE_PRES);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* soDnsPresLookup */
#endif /* SO_PRESENCE */


/*****************************************************************************
*
*       Fun:   soDnsCacheFoundA
*
*       Desc:  Returns result of DNS A query to caller
*
*       Ret:   Nothing
*
*       Notes: Calls user callback with results
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsCacheFoundA
(
SoDnsQueryCb  *dnsQuery,     /* Query record */
SoClDnsAEnt   *findResult    /* Result found */
)
#else
PRIVATE S16 soDnsCacheFoundA(dnsQuery, findResult)
SoDnsQueryCb  *dnsQuery;     /* Query record */
SoClDnsAEnt   *findResult;   /* Result found */
#endif
{
   SoDnsAResult   *result;    /* Resultset to be filled in */
   CmNetAddr      *target;    /* Target net address pointer */
   CmLList        *node;      /* Linked list node */
#ifdef SO_AAAA
   U8             count;      /* Loop counter */
#endif
   CmTptAddr      tptAddr;
   SoAddress         *naptrUri;
#ifdef SO_ENUM   
   SoDnsNaptrResult  *naptrResult;
#endif
   U8             tptProt;
   
   TRC2(soDnsCachehFoundA);

   if(findResult == NULLP)
      RETVALUE(RFAILED);
   
   /* Flag search as complete */
   dnsQuery->searchState = SO_DNS_FSM_A_CACHE;
   SOALLOC(&result, sizeof(SoDnsAResult));
   if(result == NULLP)
      RETVALUE(RFAILED);

   /* set the tptAddr to zero because tcm module needs
    * the entire tptaddr for hash find. */ 
   (Void) cmMemset((U8 *)&tptAddr, 0, sizeof(CmTptAddr));
   if(dnsQuery->aResult)
   {
      soDnsFreeAResult(dnsQuery->aResult);
      /* so027.201: Reinitializing DNS A result */
      dnsQuery->aResult = NULLP;
   }
   dnsQuery->aResult = result;
   result->numComp   = findResult->listCp.count;
   result->current   = 0;


   /* Alloc mem for array of ip adresses */
   SOALLOC(&result->ipAddress,sizeof(CmNetAddr)*result->numComp);
   if (result->ipAddress == NULLP)
   {
      RETVALUE(RFAILED);
   }

   /* Run thru llist of answerRec's and fill in array */
   for(target = result->ipAddress,
       node = findResult->listCp.first;
       node;
       node = node->next,target++)
   {
#ifdef SO_AAAA
      if (((SoClDnsAAnswerRec*)node)->ipAddress.type == CM_NETADDR_IPV4)
      {
#endif /* SO_AAAA */
         /* Found correct one */
         U8 *adr = (U8*)&target->u.ipv4NetAddr;

         target->type = CM_NETADDR_IPV4;

         adr[3] = GetHiByte(GetHiWord(
         *(&(&((SoClDnsAAnswerRec*)node)->ipAddress)->u.ipv4NetAddr)));
         adr[2] = GetLoByte(GetHiWord(
         *(&(&((SoClDnsAAnswerRec*)node)->ipAddress)->u.ipv4NetAddr)));
         adr[1] = GetHiByte(GetLoWord(
               *(&(&((SoClDnsAAnswerRec*)node)->ipAddress)->u.ipv4NetAddr)));
         adr[0] = GetLoByte(GetLoWord(
               *(&(&((SoClDnsAAnswerRec*)node)->ipAddress)->u.ipv4NetAddr)));
#ifdef SO_AAAA
      }
      else if (((SoClDnsAAnswerRec*)node)->ipAddress.type == 
                 CM_NETADDR_IPV6)
      {
         U8 *adr = (U8*)&target->u.ipv6NetAddr;

         target->type = CM_NETADDR_IPV6;
         for (count = 0; count < CM_INET_IPV6ADDR_SIZE; count++)
         {
            adr[count] = 
            ((SoClDnsAAnswerRec*)node)->ipAddress.u.ipv6NetAddr[count];
         }
      }
#endif /* SO_AAAA */
   }
   
   tptProt = dnsQuery->tptProt;
   
   if(result->current == result->numComp)
      RETVALUE(RFAILED);      
   
   if(result->ipAddress[result->current].type == CM_NETADDR_IPV4)
   {
      tptAddr.type = CM_TPTADDR_IPV4;
      if(dnsQuery->srvResult != NULLP)
      {
         tptAddr.u.ipv4TptAddr.port = 
         dnsQuery->srvResult->ports[dnsQuery->srvResult->current-1];
         /* so027.201 : For TLS transport returned will be TCP */
         if ((dnsQuery->srvResult->protocol[dnsQuery->srvResult->current-1] ==
             LSO_TPTPROT_TCP) && (tptProt == LSO_TPTPROT_TLS_TCP))
            tptProt = LSO_TPTPROT_TLS_TCP;
         else
            tptProt = 
            dnsQuery->srvResult->protocol[dnsQuery->srvResult->current-1];
      }
      else         
      {
         tptAddr.u.ipv4TptAddr.port = dnsQuery->origPort.val;
      }
      
      tptAddr.u.ipv4TptAddr.address = 
      result->ipAddress[result->current].u.ipv4NetAddr;
   }
#ifdef IPV6_SUPPORTED        
   else
   {
      tptAddr.type = CM_TPTADDR_IPV6;
      if(dnsQuery->srvResult != NULLP)
      {
         tptAddr.u.ipv6TptAddr.port = 
         dnsQuery->srvResult->ports[dnsQuery->srvResult->current-1];
         tptProt = 
         dnsQuery->srvResult->protocol[dnsQuery->srvResult->current-1];
      }
      else
      {
         tptAddr.u.ipv6TptAddr.port = dnsQuery->origPort.val;
      }
      cmMemcpy((U8 *)&tptAddr.u.ipv6TptAddr.ipv6NetAddr, 
      (U8 *)&result->ipAddress[result->current].u.ipv6NetAddr, 16);
   }
#endif   
   result->current++;
   /* Notify caller of result */
   switch(dnsQuery->queryType)
   {
#ifdef SO_ENUM
      case SO_DNS_ADDR_TYPE_TEL:
         naptrResult =(SoDnsNaptrResult *)(dnsQuery->naptrUCp.last->node);
         naptrUri = &naptrResult->uri[naptrResult->current-1];
         break;
#endif
#ifdef SO_TEL
      case SO_DNS_ADDR_TYPE_FAX: 
      case SO_DNS_ADDR_TYPE_MODEM:
         naptrResult =(SoDnsNaptrResult *)(dnsQuery->naptrUCp.last->node);
         naptrUri = &naptrResult->uri[naptrResult->current-1];
         break;
#endif
      default:
         naptrUri = NULLP;
         break;
   }

   if (dnsQuery->asyncCall)
   {
      /* 
       * This funcntion was called after receiving DNS query
       * response (i.e, ayncronously).
       */ 
      (dnsQuery->callback) ((PTR)&dnsQuery->usrCtxt, 
                            dnsQuery->queryType,
                            &tptAddr,
                            tptProt,
                            naptrUri);
   }
   else
   {
       cmMemcpy ((U8 *)&dnsQuery->destAddr, 
                 (U8 *)&tptAddr,
                 sizeof (CmTptAddr));
   
       dnsQuery->destProt     = tptProt;

       dnsQuery->addrResolved = TRUE;
   }

   /*-- so032.201: Clear cache if caching is diabled -------------------------*/
   if (soCb.cfg.dnsCfg.useDnsCache == FALSE)
   {
      SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
               "[DNS] Cahing is disabled, not adding to cache \n"));
      (Void)soClCacheClear(findResult->cacheCb);
   }

   RETVALUE(ROK);

} /* soDnsCacheFoundA */


/*****************************************************************************
*
*       Fun:   soDnsCacheFoundSrv
*
*       Desc:  Returns result of DNS SRV request to caller
*
*       Ret:   Nothing
*
*       Notes: Calls user callback with results
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsCacheFoundSrv
(
SoDnsQueryCb  *dnsQuery,     /* Query record */
SoClDnsSrvEnt *findResult    /* Result found */
)
#else
PRIVATE S16 soDnsCacheFoundSrv(dnsQuery, findResult)
SoDnsQueryCb  *dnsQuery;     /* Query record */
SoClDnsSrvEnt *findResult;   /* Result found */
#endif
{
   SoDnsSrvResult    *result;    /* Ptr to result in dnsQuery */
   SoDnsAResult      *tmpA;      /* Ptr to A result in dnsQuery */
   SoDnsSrvAnswerRec *node;      /* Ptr for accessing data in llist */
   CmLList           *llw;       /* Ptr for walking thru llist */
   Cntr              i;          /* Loop counter */
   CmTptAddr         tptAddr;
   U16               srvNum;
   U16               aNum;
   SoAddress         *naptrUri;
#ifdef SO_ENUM   
   SoDnsNaptrResult  *naptrResult;
#endif
   U16               tmpPos;
   Bool              appendDomain;
   
   TRC2(soDnsCacheFoundSrv);

   SOALLOC(&result, sizeof(SoDnsSrvResult));
   if(result == NULLP)
      RETVALUE(RFAILED);
   
   /* set the tptAddr to zero because tcm module needs
    * the entire tptaddr for hash find. */ 
   (Void) cmMemset((U8 *)&tptAddr, 0, sizeof(CmTptAddr));
   
   if(dnsQuery->srvResult)
      soDnsFreeSrvResult(dnsQuery->srvResult);
   dnsQuery->srvResult = result;

   /* save the query address for A query */   
   if (soUtlCpyTknStrOSXL(&result->originalQuery,
                          &dnsQuery->queryAddress, NULLP) != ROK)
      RETVALUE(RFAILED);
   
   /* Flag search as complete */
   dnsQuery->searchState = SO_DNS_FSM_SRV_CACHE;

   /* Randomly sort the list according to weights, must happen every time
      we return results */
   (Void)soDnsSortSrvWeight(&findResult->listCp);

   result->current     = 0;
   result->numComp     = findResult->listCp.count;
   result->ipAddress   = NULLP;

   if(result->numComp == 0)
      RETVALUE(RFAILED);
   
   /* Alloc mem for array of ip adresses */
   SOALLOC(&result->ipAddress,sizeof(SoDnsAResult)*result->numComp);
   if (result->ipAddress == NULLP)
   {
      RETVALUE(RFAILED);
   }

   /* Alloc mem for array of ip adresses */
   SOALLOC(&result->protocol,sizeof(U8)*result->numComp);
   if (result->protocol == NULLP)
   {
      SOFREE(result->ipAddress,sizeof(SoDnsAResult)*result->numComp);
      RETVALUE(RFAILED);
   }

   /* Alloc mem for array of ports */
   SOALLOC(&result->ports,sizeof(U16)*result->numComp);
   if (result->ports == NULLP)
   {
      SOFREE(result->protocol,sizeof(U8)*result->numComp);
      SOFREE(result->ipAddress,sizeof(SoDnsAResult)*result->numComp);
      RETVALUE(RFAILED);
   }
   /* Alloc mem for array of ports */
   SOALLOC(&result->hostNames,sizeof(TknStrOSXL)*result->numComp);
   if (result->hostNames == NULLP)
   {
      SOFREE(result->protocol,sizeof(U8)*result->numComp);
      SOFREE(result->ipAddress,sizeof(SoDnsAResult)*result->numComp);
      SOFREE(result->ports,sizeof(U16)*result->numComp);
      RETVALUE(RFAILED);
   }
   
   for(llw = findResult->listCp.first,i = 0; llw; llw = llw->next, i++)
   {
      node                 = (SoDnsSrvAnswerRec*)llw->node;
      result->ports[i]     = node->port;
      result->protocol[i]  = node->protocol;
      if(node->srvResult.pres != PRSNT_NODEF)
        RETVALUE(RFAILED);     

      /*
       * Sometime DNS server may just return host part in result
       * message. So  we need  to add the domain part to make it 
       * complete
       */
      appendDomain = TRUE;
      for(tmpPos = 0; tmpPos < node->srvResult.len; tmpPos++)
      {
         if(node->srvResult.val[tmpPos] == '.')
         {
            appendDomain = FALSE;
            break;
         }
      }
      if(appendDomain)
      {
    result->hostNames[i].len = 
    node->srvResult.len+dnsQuery->queryAddress.len+1;
         SOALLOC(&result->hostNames[i].val,
           result->hostNames[i].len);
         if(result->hostNames[i].val == NULLP)
         {
            result->hostNames[i].len = 0;
       RETVALUE(RFAILED);
         }
         result->hostNames[i].pres = PRSNT_NODEF;
      
         cmMemcpy(result->hostNames[i].val,node->srvResult.val, 
            node->srvResult.len);
         result->hostNames[i].val[node->srvResult.len] = '.';
         cmMemcpy(&result->hostNames[i].val[node->srvResult.len+1],
             dnsQuery->queryAddress.val, 
             dnsQuery->queryAddress.len);
      }
      else
      {
         result->hostNames[i].len = 
    node->srvResult.len;
         SOALLOC(&result->hostNames[i].val,
           result->hostNames[i].len);
         if(result->hostNames[i].val == NULLP)
         {
            result->hostNames[i].len = 0;
       RETVALUE(RFAILED);
         }
         result->hostNames[i].pres = PRSNT_NODEF;
      
         cmMemcpy(result->hostNames[i].val,node->srvResult.val, 
            node->srvResult.len);
      } 

      result->ipAddress[i].current = 0;
      if (node->validAddress == TRUE)
      {
         result->ipAddress[i].numComp = 1;
         /* Alloc mem for array of ip adresses */
         SOALLOC(&result->ipAddress[i].ipAddress,
                 sizeof(CmNetAddr)*result->ipAddress[i].numComp);
         if (result->ipAddress[i].ipAddress == NULLP)
         {
            /* No mem for other ips, all their numcomps == 0 so we break
             * out of loop and send the result as is */
            result->ipAddress[i].numComp = 0;
            break;
         }
         cmMemcpy((U8*)result->ipAddress[i].ipAddress,
                  (U8*)&node->ipAddress,sizeof(CmNetAddr));

      }
      else
      {
         result->ipAddress[i].numComp  = 0;
      }
   }

   if(result->current == result->numComp)
      RETVALUE(RFAILED);
   
   srvNum = result->current;
   tmpA =  &result->ipAddress[srvNum]; 
   aNum = tmpA->current;
   if(tmpA->numComp == 0)
   {
      /* This check is for recursion case */
      if(result->current >= result->numComp)
         RETVALUE(RFAILED);         

      soUtlDelTknStrOSXL(&dnsQuery->queryAddress);

      if(soUtlCpyTknStrOSXL(&dnsQuery->queryAddress, 
            &result->hostNames[result->current++],
            NULLP) != ROK)
         RETVALUE(RFAILED);         

      /*-- so032.201: Clear cache if caching is diabled ----------------------*/
      if (soCb.cfg.dnsCfg.useDnsCache == FALSE)
      {
         SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
                  "[DNS] Cahing is disabled, not adding to cache \n"));
         (Void)soClCacheClear(findResult->cacheCb);
      }

      if(soDnsALookup(dnsQuery) != ROK)
         RETVALUE(RFAILED);

      RETVALUE(ROK);      
   }

   /*
    * Usually DNS server does not return IP address in SRV query.
    * Some new version (ddds) may return IP address in SRV query.
    * Only for new case, we may hit this portion of code.
    */

   if(tmpA->ipAddress[aNum].type == CM_NETADDR_IPV4)
   {
      tptAddr.type = CM_TPTADDR_IPV4;
      tptAddr.u.ipv4TptAddr.port = result->ports[result->current];
      tptAddr.u.ipv4TptAddr.address = 
      tmpA->ipAddress[aNum].u.ipv4NetAddr;
   }
#ifdef IPV6_SUPPORTED        
   else
   {
      tptAddr.type = CM_TPTADDR_IPV6;
      tptAddr.u.ipv6TptAddr.port = result->ports[result->current];
      cmMemcpy((U8 *)&tptAddr.u.ipv6TptAddr.ipv6NetAddr, 
         (U8 *) &tmpA->ipAddress[aNum].u.ipv6NetAddr, 16);
   }
#endif   
   result->current++;
   switch(dnsQuery->queryType)
   {
#ifdef SO_ENUM
      case SO_DNS_ADDR_TYPE_TEL:
         naptrResult =(SoDnsNaptrResult *)(dnsQuery->naptrUCp.last->node);
         naptrUri = &naptrResult->uri[naptrResult->current-1];
         break;
#endif
#ifdef SO_TEL
      case SO_DNS_ADDR_TYPE_FAX: 
      case SO_DNS_ADDR_TYPE_MODEM:
         naptrResult =(SoDnsNaptrResult *)(dnsQuery->naptrUCp.last->node);
         naptrUri = &naptrResult->uri[naptrResult->current-1];
         break;
#endif
      default:
         naptrUri = NULLP;
         break;
   }


   if (dnsQuery->asyncCall)
   {
      /* 
       * This funcntion was called after receiving DNS query
       * response (i.e, ayncronously).
       */ 
      (*dnsQuery->callback) ((PTR)&dnsQuery->usrCtxt, 
                            dnsQuery->queryType,
                            &tptAddr, 
                            result->protocol[result->current-1],
                            naptrUri);
   } 
   else
   {
       cmMemcpy ((U8 *)&dnsQuery->destAddr, 
                 (U8 *)&tptAddr,
                 sizeof (CmTptAddr));
   
       dnsQuery->destProt = result->protocol[result->current-1];

       dnsQuery->addrResolved = TRUE;
   }

   /*-- so032.201: Clear cache if caching is diabled -------------------------*/
   if (soCb.cfg.dnsCfg.useDnsCache == FALSE)
   {
      SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
               "[DNS] Cahing is disabled, not adding to cache \n"));
      (Void)soClCacheClear(findResult->cacheCb);
   }

   RETVALUE(ROK);

} /* soDnsCacheFoundSrv */

/*****************************************************************************
*
*       Fun:   soDnsCacheSrvHit
*
*       Desc:  search the cache for a tpt protocol hit
*
*       Ret:   ROK/RFAILED
*
*       Notes: Calls user callback with results
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsCacheSrvHit
(
SoDnsQueryCb  *dnsQuery,     /* Query record */
SoClDnsSrvEnt *findResult    /* Result found */
)
#else
PRIVATE S16 soDnsCacheSrvHit(dnsQuery, findResult)
SoDnsQueryCb  *dnsQuery;     /* Query record */
SoClDnsSrvEnt *findResult;   /* Result found */
#endif
{
   SoDnsSrvAnswerRec *node;      /* Ptr for accessing data in llist */
   CmLList           *llw;       /* Ptr for walking thru llist */
   U16               i;

   TRC2(soDnsCacheSrvHit);

   if(dnsQuery->tptProt == LSO_TPTPROT_NULL)
      RETVALUE(ROK);      
   for(llw = findResult->listCp.first,i = 0; llw; llw = llw->next, i++)
   {
      node = (SoDnsSrvAnswerRec*)llw->node;
      if(dnsQuery->tptProt == node->protocol)
         RETVALUE(ROK);
   }     
   RETVALUE(RFAILED);     
} /* soDnsCacheSrvHit */

/*****************************************************************************
*
*       Fun:   soDnsSortSrvWeight
*
*       Desc:  Sorts SRV RR according to thier weight - see RFC 2782
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE Void soDnsSortSrvWeight
(
CmLListCp *dnsFindResults           /* List of DNS SRV query results */
)
#else
PRIVATE Void soDnsSortSrvWeight(dnsFindResults)
CmLListCp *dnsFindResults;           /* List of DNS SRV query results */
#endif
{
   CmLListCp         newListCp;      /* Temporary list control point*/
   SoDnsSrvAnswerRec *newEntry;      /* New answer record */
   U16               newPrioriry;    /* New prioriry */
   SoDnsSrvAnswerRec *curEntry;      /* Current answer record */
   U16               curPrioriry;    /* Current prioriry */
   U8                count;          /* Number of SRV recors with the same
                                        priority */
   U32               totalWeight;    /* Sum of SRV RRs weight */
   U32               runSum[24];     /* Running sum */
   U16               r1;             /* Random number */
   U16               r2;             /* Random number */
   U32               random;         /* Uniform random number */
   U8                i;              /* Counter */
   U8                j;              /* Counter */

   TRC2(soDnsSortSrvWeight);

   /* Check input parameters */
   if ( (dnsFindResults == NULLP) && (dnsFindResults->count > 0))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO080, ERRZERO,
                 "dnsFindResults: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVOID;
   }

   newListCp.count =0;
   newListCp.first = NULLP;
   newListCp.crnt  = NULLP;
   newListCp.last  = NULLP;

   /* so026.201 : Select srv response with lowest priority and highest weight */
   /* find the record with lowest priopity in dnsFindResults and move it to
      newListCp */
   while (dnsFindResults->count)
   {
      dnsFindResults->crnt = dnsFindResults->first;
      curEntry    = (SoDnsSrvAnswerRec*)dnsFindResults->crnt->node;
      newEntry    = curEntry;
      newPrioriry = curEntry->priority;

      while(curEntry != NULLP)
      {
         /* so026.201 : Select srv response with lowest priority and highest weight */
         if(newPrioriry > curEntry->priority)
         {
            newEntry    = curEntry;
            newPrioriry = curEntry->priority;
         }
    
         if (dnsFindResults->crnt->next != NULLP)
         {
            dnsFindResults->crnt = dnsFindResults->crnt->next;
            curEntry = (SoDnsSrvAnswerRec*)dnsFindResults->crnt->node;
         }
         else
            curEntry = NULLP;
      }

      /* so026.201 : Select srv response with lowest priority and highest weight */
      /* newEntry has the lowest priority -> move to new list*/
      cmLListDelFrm(dnsFindResults, &newEntry->llNode);
      cmLListAdd2Tail(&newListCp, &newEntry->llNode);
   }

   /* so026.201 : Select srv response with lowest priority and highest weight */
   /* newListCp contains SRV RR sorted by priority - the lowest is the first */
   while (newListCp.count)
   {
      count = 0;
      newListCp.crnt = newListCp.first;
      curPrioriry    = 
      ((SoDnsSrvAnswerRec*)newListCp.first->node)->priority;

      /* get the number of SRV RR with the same priority */
      while (newListCp.crnt != NULLP)
      {
         curEntry = (SoDnsSrvAnswerRec*)newListCp.crnt->node;
         if (curPrioriry == curEntry->priority)
         {
            count++;
            newListCp.crnt = newListCp.crnt->next;
         }
         else
            break;
      }

      /* sort SRV RR by weight only if 
       * there are more than one records */
      if (count > 1 )
      {
         totalWeight = 0;
         cmMemset((U8 *)runSum, 0, sizeof(runSum));

         for (i = 0, newListCp.crnt = newListCp.first;
              i < count;
              i++, newListCp.crnt = newListCp.crnt->next)
         {
            curEntry = (SoDnsSrvAnswerRec*)newListCp.crnt->node;
            totalWeight+= curEntry->weight;
            runSum[i]   = totalWeight;
         }

         SRandom(&r1);
         SRandom(&r2);
         random = (r1 << 16) + r2;
         /* so032.201: Anding makes it inclined towards 0 i.e. smaller values,
          * which will skew the final result towards values earlier in the
          * queue, mod will give better and more uniform results
          */
         random = (random % totalWeight) + 1;

         /* find the running sum which is equal or biger than random */
         for (i = 0; i < count; i++)
         {
            if (runSum[i] >= random)
            {
               i++;
               break;
            }
         }

         for (j = 0, newListCp.crnt = newListCp.first;
              j < i;
              j++, newListCp.crnt = newListCp.crnt->next)
         {
            curEntry = (SoDnsSrvAnswerRec*)newListCp.crnt->node;

         }
      }
      else
      {
         curEntry = (SoDnsSrvAnswerRec*)newListCp.first->node;
      }


      cmLListDelFrm(&newListCp, &curEntry->llNode);
      cmLListAdd2Tail(dnsFindResults, &curEntry->llNode);
   }
   RETVOID;
} /* soDnsSortSrvWeight */


#ifdef SO_INSTMSG   

/*****************************************************************************
*
*       Fun:   soDnsCacheFoundIm
*
*       Desc:  Returns result of DNS Im request to caller
*
*       Ret:   Nothing
*
*       Notes: Calls user callback with results
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsCacheFoundIm
(
SoDnsQueryCb  *dnsQuery,     /* Query record */
SoClDnsSrvEnt *findResult    /* Result found */
)
#else
PRIVATE S16 soDnsCacheFoundIm(dnsQuery, findResult)
SoDnsQueryCb  *dnsQuery;     /* Query record */
SoClDnsSrvEnt *findResult;   /* Result found */
#endif
{
   SoDnsSrvResult    *result;    /* Ptr to result in dnsQuery */
   SoDnsSrvAnswerRec *node;      /* Ptr for accessing data in llist */
   CmLList           *llw;       /* Ptr for walking thru llist */
   Cntr              i;          /* Loop counter */
   
   TRC2(soDnsCacheFoundIm);

   SOALLOC(&result, sizeof(SoDnsSrvResult));
   if(result == NULLP)
      RETVALUE(RFAILED);

   if(dnsQuery->imResult)
      soDnsFreeSrvResult(dnsQuery->imResult);
   dnsQuery->imResult = result;
   
   /* Flag search as complete */
   dnsQuery->searchState = SO_DNS_FSM_IM_CACHE;

   /* Randomly sort the list according to weights, 
    * must happen every time
      we return results */
   (Void)soDnsSortSrvWeight(&findResult->listCp);

   result->current     = 0;
   result->numComp     = findResult->listCp.count;
   result->ipAddress   = NULLP;


   /* Alloc mem for array of ip adresses */
   SOALLOC(&result->protocol,sizeof(U8)*result->numComp);
   if (result->protocol == NULLP)
   {
      RETVALUE(RFAILED);
   }

   /* Alloc mem for array of ports */
   SOALLOC(&result->ports,sizeof(U16)*result->numComp);
   if (result->ports == NULLP)
   {
      RETVALUE(RFAILED);
   }
   /* Alloc mem for array of ports */
   SOALLOC(&result->hostNames,sizeof(TknStrOSXL)*result->numComp);
   if (result->hostNames == NULLP)
   {
      RETVALUE(RFAILED);
   }
   
   for(llw = findResult->listCp.first,i = 0; llw; llw = llw->next, i++)
   {
      node                 = (SoDnsSrvAnswerRec*)llw->node;
      result->ports[i]     = node->port;
      result->protocol[i]  = node->protocol;
      if ( soUtlCpyTknStrOSXL(result->hostNames + i,
               &node->srvResult,NULLP)!=ROK )
      {
         RETVALUE(RFAILED);
      }
   }

   if(result->current >= result->numComp)
      RETVALUE(RFAILED);
   
   for(i = result->current; i < result->numComp; i++)
   {
      if(result->protocol[i] == LSO_TPTPROT_UDP)
         break;         
   }   
   result->current = (U16)i;
   if(i < result->numComp)
   {
      if(soUtlDelTknStrOSXL(&dnsQuery->queryAddress) != ROK)
         RETVALUE(RFAILED);         
      if(soUtlCpyTknStrOSXL(&dnsQuery->queryAddress, 
            &result->hostNames[result->current++],
            NULLP) != ROK)
      {
         RETVALUE(RFAILED);
      }    
      dnsQuery->tptProt = result->protocol[i];
      if(soDnsSrvLookup(dnsQuery,dnsQuery->tptProt) != ROK)
         RETVALUE(RFAILED);
   }
   else
   {
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* soDnsCacheFoundIm */
#endif /* SO_INSTMSG */

#ifdef SO_PRESENCE

/*****************************************************************************
*
*       Fun:   soDnsCacheFoundPres
*
*       Desc:  Returns result of DNS Im request to caller
*
*       Ret:   Nothing
*
*       Notes: Calls user callback with results
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsCacheFoundPres
(
SoDnsQueryCb  *dnsQuery,     /* Query record */
SoClDnsSrvEnt *findResult    /* Result found */
)
#else
PRIVATE S16 soDnsCacheFoundPres(dnsQuery, findResult)
SoDnsQueryCb  *dnsQuery;     /* Query record */
SoClDnsSrvEnt *findResult;   /* Result found */
#endif
{
   SoDnsSrvResult    *result;    /* Ptr to result in dnsQuery */
   SoDnsSrvAnswerRec *node;      /* Ptr for accessing data in llist */
   CmLList           *llw;       /* Ptr for walking thru llist */
   Cntr              i;          /* Loop counter */
   
   TRC2(soDnsCacheFoundPres);

   SOALLOC(&result, sizeof(SoDnsSrvResult));
   if(result == NULLP)
      RETVALUE(RFAILED);
   if(dnsQuery->presResult)
      soDnsFreeSrvResult(dnsQuery->presResult);
   dnsQuery->presResult = result;
   
   /* Flag search as complete */
#ifdef SO_PRESENCE   
   dnsQuery->searchState = SO_DNS_FSM_PRES_CACHE;
#endif

   /* Randomly sort the list according to weights, must happen every time
      we return results */
   (Void)soDnsSortSrvWeight(&findResult->listCp);

   result->current     = 0;
   result->numComp     = findResult->listCp.count;
   result->ipAddress   = NULLP;


   /* Alloc mem for array of ip adresses */
   SOALLOC(&result->protocol,sizeof(U8)*result->numComp);
   if (result->protocol == NULLP)
   {
      RETVALUE(RFAILED);
   }

   /* Alloc mem for array of ports */
   SOALLOC(&result->ports,sizeof(U16)*result->numComp);
   if (result->ports == NULLP)
   {
      RETVALUE(RFAILED);
   }
   /* Alloc mem for array of ports */
   SOALLOC(&result->hostNames,sizeof(TknStrOSXL)*result->numComp);
   if (result->hostNames == NULLP)
   {
      RETVALUE(RFAILED);
   }
   
   for(llw = findResult->listCp.first,i = 0; llw; llw = llw->next, i++)
   {
      node                 = (SoDnsSrvAnswerRec*)llw->node;
      result->ports[i]     = node->port;
      result->protocol[i]  = node->protocol;
      if( soUtlCpyTknStrOSXL(result->hostNames + i,
                             &node->srvResult,NULLP)!=ROK )
      {
         RETVALUE(RFAILED);
      }
   }

   if(result->current >= result->numComp)
      RETVALUE(RFAILED);
   
   for(i = result->current; i < result->numComp; i++)
   {
      if(result->protocol[i] == LSO_TPTPROT_UDP)
         break;         
   }   
   result->current = i;
   if(i < result->numComp)
   {
      if(soUtlDelTknStrOSXL(&dnsQuery->queryAddress) != ROK)
         RETVALUE(RFAILED);         
      if(soUtlCpyTknStrOSXL(&dnsQuery->queryAddress, 
            &result->hostNames[result->current++],
            NULLP) != ROK)
         RETVALUE(RFAILED);         
      dnsQuery->tptProt = result->protocol[i];
      if(soDnsSrvLookup(dnsQuery,dnsQuery->tptProt) != ROK)
         RETVALUE(RFAILED);
   }
   else
   {
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* soDnsCacheFoundPres */
#endif /* SO_PRESENCE */

/*****************************************************************************
*
*       Fun:   soDnsCacheFoundNaptr
*
*       Desc:  save teh naptr result to query Cb
*
*       Ret:   Nothing
*
*       Notes: 
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsCacheFoundNaptr
(
SoDnsQueryCb *dnsQuery,        /* query cb */
SoClDnsNaptrEnt *findResult,   /* Result found */
Bool            isNaptrU
)
#else
PRIVATE S16 soDnsCacheFoundNaptr(dnsQuery, findResult, isNaptrU)
SoDnsQueryCb  *dnsQuery;       /* Query record */
SoClDnsNaptrEnt *findResult;   /* Result found */
Bool            isNaptrU;
#endif
{
   SoDnsNaptrResult    *result;   /* Ptr to result in dnsQuery */
   SoDnsNaptrAnswerRec *node;     /* Ptr for accessing data in llist */
   CmLList             *llw;        /* Ptr for walking thru llist */
   Cntr                i;           /* Loop counter */
   Bool                isTel;
   Bool                isIp;
   TknU16              port;
   U8                  tptProt;
   U8                  ipType;
   
   TRC2(soDnsCacheFoundNaptr);

   isIp = FALSE;

#ifdef SO_ENUM  
   if(isNaptrU)
      dnsQuery->searchState = SO_DNS_FSM_NAPTRU_CACHE;
   else
#endif
      dnsQuery->searchState = SO_DNS_FSM_NAPTRS_CACHE;
      
   /* Sort the list according to Order and Preference */
   (Void)soDnsSortNaptrWeight(&findResult->listCp); 

   SOALLOC(&result, sizeof(SoDnsNaptrResult));
   if(result == NULLP)
   {
      RETVALUE(RFAILED);
   }
   if(isNaptrU)
   {
#ifdef SO_ENUM      
      result->flag = SO_DNS_NAPTR_FLAG_U;      
      result->node.node = (PTR)result;
      cmLListAdd2Tail(&dnsQuery->naptrUCp, &result->node);
#else
      RETVALUE(RFAILED);
#endif      
   }
   else
   {
      result->flag = SO_DNS_NAPTR_FLAG_S;      
      if(dnsQuery->naptrResult != NULLP)
      {
         soDnsFreeNaptrResult(dnsQuery->naptrResult);
      }
      dnsQuery->naptrResult = result;      
   }  
   result->current = 0;
   result->numComp    = findResult->listCp.count;

   SOALLOC(&result->uri, sizeof(SoAddress)*result->numComp);
   if (result->uri == NULLP)
   {
      RETVALUE(RFAILED);
   }
   if(soUtlCpyTknStrOSXL(&result->originalQuery, 
            &dnsQuery->queryAddress, NULLP) != ROK)
   {
      RETVALUE(RFAILED);
   }
   SOALLOC(&result->normUri, sizeof(TknStrOSXL)*result->numComp);
   if (result->normUri == NULLP)
   {
      RETVALUE(RFAILED);
   }

   for (llw = findResult->listCp.first, i = 0; llw; llw = llw->next, i++)
   {
      node = (SoDnsNaptrAnswerRec*)llw->node;
      soUtlDelTknStrOSXL(&result->normUri[i]);
      if (soUtlCpyTknStrOSXL(&result->normUri[i], 
                             &node->normNaptrResult, NULLP) 
          != ROK)
      {
         RETVALUE(RFAILED);
      }
      if (soUtlCpySoAddress(&result->uri[i], &node->naptrResult, 
                         (CmMemListCp *)NULLP) != ROK)
      {
         RETVALUE(RFAILED);
      }
   }
   
   if(soUtlDelTknStrOSXL(&dnsQuery->queryAddress) != ROK)
      RETVALUE(RFAILED);
   if(soDnsGetHostNameFromNaptrUri(result,
      &dnsQuery->queryAddress, &tptProt, &port, &isIp, &ipType, &isTel) != ROK)
      RETVALUE(RFAILED);

   result->current++;

   /* hit final result so signal dialog module */
   if(isIp == TRUE)
   {
      CmTptAddr         tptAddr;
      SoAddress         *naptrUri;
#ifdef SO_ENUM      
      SoDnsNaptrResult  *naptrResult;
#endif
      SoHost            *ipHost;
      SoIpv4Address     *a;
      U32               a1;          
      U32               a2;          
      U32               a3;          
      U32               a4;          
      
      /* set the tptAddr to zero because tcm module needs
       * the entire tptaddr for hash find. */ 
      (Void) cmMemset((U8 *)&tptAddr, 0, sizeof(CmTptAddr));
      
      if (result->uri[result->current-1].addrCh.addrChType.val == 
         SO_ADDRCH_NAMEADDR)
      {
        ipHost = &result->uri[result->current-1].addrCh.t.nameAddr.addrSpec.t.sipUrl.hostPort.host;
      }
      else
      {
        ipHost = &result->uri[result->current-1].addrCh.t.addrSpec.t.sipUrl.hostPort.host;
      }


      switch(dnsQuery->queryType)
      {
#ifdef SO_ENUM
         case SO_DNS_ADDR_TYPE_TEL:
            naptrResult =(SoDnsNaptrResult *)(dnsQuery->naptrUCp.last->node);
            naptrUri = &naptrResult->uri[naptrResult->current-1];
            break;
#endif
#ifdef SO_TEL
         case SO_DNS_ADDR_TYPE_FAX: 
         case SO_DNS_ADDR_TYPE_MODEM:
            naptrResult =(SoDnsNaptrResult *)(dnsQuery->naptrUCp.last->node);
            naptrUri = &naptrResult->uri[naptrResult->current-1];
            break;
#endif
         default:
            naptrUri = NULLP;
            break;
      }
   
      if(ipType == SO_HOST_IPV4ADDRESS)
      {
         tptAddr.type = CM_TPTADDR_IPV4;
         tptAddr.u.ipv4TptAddr.port = port.val;
         a = &ipHost->t.ipv4Address;
         a1 = a->adr4.val &0xff;
         a2 = ((a->adr3.val &0xff) << 8);
         a3 = ((a->adr2.val &0xff) << 16);
         a4 = ((a->adr1.val &0xff) << 24);
         tptAddr.u.ipv4TptAddr.address = a1+a2+a3+a4;
      }
#ifdef IPV6_SUPPORTED
      else
      {
         tptAddr.type = CM_TPTADDR_IPV6;
         tptAddr.u.ipv6TptAddr.port = port.val;
         cmMemcpy((U8*)&tptAddr.u.ipv6TptAddr.ipv6NetAddr, 
                  (U8*)&ipHost->t.tmpA->ipv6Reference.val, 16);
      }
#endif

      if (dnsQuery->asyncCall)
      {
         /* 
          * This funcntion was called after receiving DNS query
          * response (i.e, ayncronously).
          */ 
         (*dnsQuery->callback) ((PTR)&dnsQuery->usrCtxt,
                              dnsQuery->queryType,
                              &tptAddr,
                              tptProt,
                              naptrUri);
      }
      else
      {
         cmMemcpy ((U8 *)&dnsQuery->destAddr, 
                   (U8 *)&tptAddr,
                   sizeof (CmTptAddr));
   
         dnsQuery->destProt     = tptProt;

         dnsQuery->addrResolved = TRUE;
      }

      /*-- so032.201: Clear cache if caching is diabled ----------------------*/
      if (soCb.cfg.dnsCfg.useDnsCache == FALSE)
      {
         SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
                  "[DNS] Cahing is disabled, not adding to cache \n"));
         (Void)soClCacheClear(findResult->cacheCb);
      }

      RETVALUE(ROK);   

   }

   /*-- so032.201: Clear cache if caching is diabled -------------------------*/
   if (soCb.cfg.dnsCfg.useDnsCache == FALSE)
   {
      SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
               "[DNS] Cahing is disabled, not adding to cache \n"));
      (Void)soClCacheClear(findResult->cacheCb);
   }

   if(isNaptrU) 
   {      
#ifdef SO_ENUM
      if(soDnsProcNaptrQuery(dnsQuery, &dnsQuery->queryAddress, 
                             isTel) != ROK)
         RETVALUE(RFAILED);
#else
      RETVALUE(RFAILED);
#endif      
   }
   else
   {
      if(soDnsAnalyseNaptrSResult(dnsQuery) != ROK)
         RETVALUE(RFAILED);
      if(soDnsSrvLookup(dnsQuery,dnsQuery->tptProt) != ROK)
         RETVALUE(RFAILED);
   }
   
   RETVALUE(ROK);
} /* soDnsCacheFoundNaptr */


/*****************************************************************************
*
*       Fun:   soDnsSortNaptrWeight
*
*       Desc:  Sorts NAPTR RR according to thier preference. The weight
*              is determined by order and preference fields in the 
*              NAPTR resource record.
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE Void soDnsSortNaptrWeight
(
CmLListCp *dnsFindResults           /* List of DNS NAPTR query results */
)
#else
PRIVATE Void soDnsSortNaptrWeight(dnsFindResults)
CmLListCp *dnsFindResults;           /* List of DNS SRV query results */
#endif
{
   CmLListCp         newListCp;      /* Temporary list control point*/
   SoDnsNaptrAnswerRec *curEntry;    /* Current answer record */
   SoDnsNaptrAnswerRec *newEntry;    /* New answer record */
   U16                  newOrder;    /* New Order */
   U16                  newPreference; /* New Preference */ 

   TRC2(soDnsSortNaptrWeight);

   if((dnsFindResults == NULLP) && (dnsFindResults->count > 0))
   {
      RETVOID;
   }
   newListCp.count =0;
   newListCp.first = NULLP;
   newListCp.crnt  = NULLP;
   newListCp.last  = NULLP;

   /* Find the record with the lowest order and if orders are equivalent,
    * lowest preference */
   while (dnsFindResults->count)
   {
      dnsFindResults->crnt = dnsFindResults->first;
      curEntry    = (SoDnsNaptrAnswerRec*)dnsFindResults->crnt->node; 
      newEntry    = curEntry;
      newOrder    = curEntry->order;
      newPreference = curEntry->preference;

      while (curEntry != NULLP)
      {
         /* so030.201: Lowest order is given preference */
         if (newOrder > curEntry->order)
         {
            newEntry = curEntry;
            newOrder = curEntry->order;
            newPreference = curEntry->preference;
         }
         else if ((newOrder == curEntry->order) && 
                  (newPreference > curEntry->preference))
         {
            newEntry = curEntry;
            newOrder = curEntry->order;
            newPreference = curEntry->preference;
         }

         if (dnsFindResults->crnt->next != NULLP)
         {
            dnsFindResults->crnt = dnsFindResults->crnt->next;
            curEntry = (SoDnsNaptrAnswerRec*)dnsFindResults->crnt->node;
         }
         else
            curEntry = NULLP;
      }
      /* New entry has the lowest weight */
      cmLListDelFrm(dnsFindResults, &newEntry->llNode);
      cmLListAdd2Tail(&newListCp, &newEntry->llNode);
   }

   while (newListCp.count)
   {
      curEntry = (SoDnsNaptrAnswerRec*)newListCp.first->node;

      cmLListDelFrm(&newListCp, &curEntry->llNode);
      cmLListAdd2Tail(dnsFindResults, &curEntry->llNode);
   }

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Best NAPTR Response based on weight is %s\n",
      ((SoDnsNaptrAnswerRec*)dnsFindResults->first->node)->normNaptrResult.val));
   
   RETVOID;
} /* soDnsSortNaptrWeight */

/*****************************************************************************
*
*       Fun:   soDnsAnalyseNaptrSResult
*
*       Desc:  Post process received naptr s result
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsAnalyseNaptrSResult
(
SoDnsQueryCb   *query
)
#else
PRIVATE S16 soDnsAnalyseNaptrSResult(query)
SoDnsQueryCb   *query;
#endif
{
   U8                *val;
   
   TRC2(soDnsAnalyseNaptrSResult);

   if(cmMemcmp((U8 *)query->queryAddress.val, (CONSTANT U8 *)"_sip._udp.", 10) == 0)
   {
      query->tptProt = LSO_TPTPROT_UDP;
      SOALLOC(&val, query->queryAddress.len - 10);
      if(val == NULLP)
    RETVALUE(RFAILED);
      cmMemcpy(val, (query->queryAddress.val+10),
          (query->queryAddress.len-10));
      SOFREE(query->queryAddress.val, query->queryAddress.len);
      query->queryAddress.val = val;
      query->queryAddress.len -= 10;
   }      
   else if(cmMemcmp((U8 *)query->queryAddress.val, (CONSTANT U8 *)"_sip._tcp.", 
                    10) == 0)
   {
      query->tptProt = LSO_TPTPROT_TCP;
      SOALLOC(&val, query->queryAddress.len - 10);
      if(val == NULLP)
         RETVALUE(RFAILED);
      cmMemcpy(val, (query->queryAddress.val+10),
          (query->queryAddress.len-10));
      SOFREE(query->queryAddress.val, query->queryAddress.len);
      query->queryAddress.val = val;
      query->queryAddress.len -= 10;
   }
#ifdef SO_SCTP   
   else if(cmMemcmp((U8 *)query->queryAddress.val, 
                    "_sip._sctp.", 11) == 0)
   {
      query->tptProt = LSO_TPTPROT_SCTP;
      SOALLOC(&val, query->queryAddress.len - 11);
      if(val == NULLP)
         RETVALUE(RFAILED);
      cmMemcpy(val, (query->queryAddress.val+11),
          (query->queryAddress.len-11));
      SOFREE(query->queryAddress.val, query->queryAddress.len);
      query->queryAddress.val = val;
      query->queryAddress.len -= 11;
   }
#endif
#ifdef SO_TLS   
   else if(cmMemcmp((U8 *)query->queryAddress.val, 
                    (CONSTANT U8 *)"_sips._tcp.", 11) == 0)
   {
      query->tptProt = LSO_TPTPROT_TLS_TCP;
      SOALLOC(&val, query->queryAddress.len - 11);
      if(val == NULLP)
         RETVALUE(RFAILED);
      cmMemcpy(val, (query->queryAddress.val+11), 
          (query->queryAddress.len-11));
      SOFREE(query->queryAddress.val, query->queryAddress.len);
      query->queryAddress.val = val;
      query->queryAddress.len -= 11;
   }
#endif   
   else
   {
      RETVALUE(RFAILED);
   }      
   RETVALUE(ROK);
}

/*****************************************************************************
*
*       Fun: soSendDnsQuery
*
*       Desc: Issues DNS request
*
*       Ret:
*
*       Notes:
*
*       File:  so_dns.c
*
*****************************************************************************/
#ifdef ANSI
PRIVATE S16 soSendDnsQuery
(
SoDnsQueryCb      *dnsQ,        /* Dns query control block */
U8                qNameLen,     /* Length of name query */
U8                *qName,       /* Actual name to resolve via dns */
U16               qType,        /* Type of dns query to issue */
U8                qProtocol,    /* Protocol to query for */
U8                service       /* Service to query for */
)
#else
PRIVATE S16 soSendDnsQuery(dnsQ, qNameLen, qName, qType,qProtocol, service)
SoDnsQueryCb      *dnsQ;        /* Dns query control block */
U8                qNameLen;     /* Length of name query */
U8                *qName;       /* Actual name to resolve via dns */
U16               qType;        /* Type of dns query to issue */
U8                qProtocol;    /* Protocol to query for */
U8                service;      /* Service to query for */
#endif
{
   CmDnsQueryInfo    queryInfo;  /* DNS query information */
   Mem               mem;        /* Memory to use for dns query */
   S16               ret;        /* Return value */

   TRC2(soSendDnsQuery);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Sending out DNS Query\n"));
   
   if ( service != CM_DNS_SERVICE_SIP
#ifdef SO_INSTMSG
        && service != CM_DNS_SERVICE_IM        
#endif /* SO_INSTMSG */
#ifdef SO_TLS
        && service != CM_DNS_SERVICE_SIPS
#endif /* SO_TLS */
      ) 
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO081, 0,
         "soSendDnsQuery(): Invalid Service specified");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }
   if ((dnsQ == NULLP) || (qName== NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO082, 0,
         "soSendDnsQuery(): NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }
   /*-- so021.201: Removing Warning --*/
   /*-- Since qNameLen is U8, it will never be > 255 --*/
   if ((qNameLen == 0))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO083, qNameLen,
         "soSendDnsQuery(): Invalid qNameLen");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   /* Allocate new request number */
   queryInfo.qNameLen = qNameLen;
   cmMemcpy(queryInfo.qName,qName,qNameLen);
   queryInfo.qType    = qType;
   queryInfo.qclass   = CM_DNS_QCLASS_IN;
   /*CM_DNS_SERVICE_SIP / CM_DNS_SERVICE_IM */
   queryInfo.service  = service; 
   queryInfo.protocol = qProtocol; /*CM_DNS_PROTOCOL_UDP;*/

   mem.pool    = soCb.init.pool;
   mem.region  = soCb.init.region;


   /* Start timer _before_ generating request.
    * In tightly coupled with no DNS server the 
    * DiscInd will be received before
    * returning. in which case dnsQ will be invalid
    */
   if(dnsQ->mBuf != NULLP)
   {
      SPutMsg(dnsQ->mBuf);
      dnsQ->mBuf = NULLP;
   }
   if (dnsQ->requestId < SO_DNS_REQUESTIDLSTSZ)
   {
      cmDnsAbortRslvReq(soCb.dnsCb,dnsQ->requestId);
      dnsQ->requestId = SO_DNS_REQUESTIDLSTSZ;
   }
   soSchedTmr(dnsQ,SO_TMR_DNS_LOOKUP,TMR_START,
      soCb.reCfg.dnsReCfg.dnsQueryTmr.val);
   ret = cmDnsGenRslvReq(soCb.dnsCb,dnsQ,&queryInfo,
      dnsQ,(U16 *)&dnsQ->requestId,&mem);
   if (ret != ROK || dnsQ->requestId >= SO_DNS_REQUESTIDLSTSZ)
   {
      /* Fail - calling function should free memory */
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* soSendDnsQuery */

/*****************************************************************************
*
*       Fun:   soDnsGetHostNameFromNaptrUri
*
*       Desc:  get host name from URI
*
*
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsGetHostNameFromNaptrUri
(
SoDnsNaptrResult   *result,
TknStrOSXL         *hostName,
U8                 *tptProt,
TknU16             *port,             
Bool               *isIp,
U8                 *ipType, 
Bool               *isTel
)
#else
PRIVATE S16 soDnsGetHostNameFromNaptrUri(result, hostName, 
                                         tptProt, port, isIp, ipType, isTel)
SoDnsNaptrResult   *result;
TknStrOSXL         *hostName;
U8                 *tptProt;
TknU16             *port;             
Bool               *isIp;
U8                 *ipType; 
Bool               *isTel;
#endif
{
   /*SoClDnsNaptrEnt   *result; */    /* Result from cache lookup */
   U8                buf[CM_DNS_DNAME_LEN+9];    /* Buffer to hold the query string */
   U16               length;      /* Holds length of a string */
   U16               i;           /* Loop counter */
   /* Index into the buffer where the next
    *  character is to be placed */
   U8                indx;        
   U8                *val;        /* Holds the value of a string */
   /* String to be appended to the tel
    * to form DNS query */ 
   U8                name[] = "e164.arpa";  
   TknStrOSXL        tmpOSXL;
   SoAddrSpec        *reqAddr;
   SoHost            *host;
   U16               tmpCount;
   SoSipUrl   *sipUrl;
#ifdef SO_TLS   
   SoSipUrl   *sipsUrl;
#endif

   TRC2(soDnsGetHostNameFromNaptrUri);

   indx = 0;
   length = 0;
   *isTel = TRUE;
   tmpCount = 0;
   *tptProt = LSO_TPTPROT_NULL;

   if(result->flag == SO_DNS_NAPTR_FLAG_S)
   {
      *isTel = FALSE;
      *isIp = FALSE;
      RETVALUE(soDnsCpyHostStr(&result->normUri[result->current],
          hostName,FALSE));
   }

   if(result->uri[result->current].addrCh.addrChType.val == 
      SO_ADDRCH_NAMEADDR)
   {
      reqAddr = 
      &result->uri[result->current].addrCh.t.nameAddr.addrSpec;
   }
   else
      reqAddr = &result->uri[result->current].addrCh.t.addrSpec;

   
   switch(reqAddr->addrSpecType.val)
   {
      case SO_ADDRSPEC_SIPURL:
         length = reqAddr->t.sipUrl.userInfo.userType.value.len; 
         val = reqAddr->t.sipUrl.userInfo.userType.value.val; 
         *isTel = FALSE;
         host = &reqAddr->t.sipUrl.hostPort.host;
         port->pres  = reqAddr->t.sipUrl.hostPort.port.pres;
         port->val  = reqAddr->t.sipUrl.hostPort.port.val;
         sipUrl = &reqAddr->t.sipUrl;
         if (reqAddr->t.sipUrl.urlParameters.numComp.pres == 
             PRSNT_NODEF)
          {
             for (i = 0; 
                  i < reqAddr->t.sipUrl.urlParameters.numComp.val; i++)
             {
                if(sipUrl->urlParameters.urlParameter[i]->
                  urlParameterType.pres
                 == TRUE)
                {
                   *tptProt = 
                   sipUrl->urlParameters.urlParameter[i]->t.
                   transportParam.transportParamType.val;
                   tmpCount++;
                   if(tmpCount == 3)
                   break;
                }
                else if(reqAddr->t.sipUrl.urlParameters.urlParameter[i]->
                   urlParameterType.val == SO_URLPARAMETER_MADDRHOST &&
                   reqAddr->t.sipUrl.urlParameters.urlParameter[i]->
                   urlParameterType.pres == PRSNT_NODEF)
                {
                   host = &reqAddr->t.sipUrl.urlParameters.
                   urlParameter[i]->t.maddrHost;
                   tmpCount++;
                   if(tmpCount == 3)
                   break;
                }   
                else if(SO_CMP_TKN_LIT(
                        &reqAddr->t.sipUrl.urlParameters.
                        urlParameter[i]->
                        urlParameterType, 
                        SO_URLPARAMETER_USERPARAM) == TRUE)
                {
                   if (SO_CMP_TKN_LIT(&reqAddr->t.sipUrl.urlParameters.
                       urlParameter[i]->
                       t.userParam.userParamType, SO_USERPARAM_PHONE))
                   {
                      tmpCount++;
                      *isTel = TRUE;
                      if(tmpCount == 3)
                         break;
                   }
                }
             }
          }

    break;
#ifdef SO_TLS    
      case SO_ADDRSPEC_SIPSURL:
         length = reqAddr->t.sipsUrl.userInfo.userType.value.len; 
         val = reqAddr->t.sipsUrl.userInfo.userType.value.val; 
         *isTel = FALSE;
         host = &reqAddr->t.sipsUrl.hostPort.host;
         port->pres  = reqAddr->t.sipsUrl.hostPort.port.pres;
         port->val  = reqAddr->t.sipsUrl.hostPort.port.val;
         sipsUrl = &reqAddr->t.sipsUrl;
         *tptProt = LSO_TPTPROT_TLS_TCP;
         if (reqAddr->t.sipsUrl.urlParameters.numComp.pres == 
            PRSNT_NODEF)
          {
             for (i = 0; 
                  i < reqAddr->t.sipsUrl.urlParameters.numComp.val; i++)
             {
                if(reqAddr->t.sipsUrl.urlParameters.urlParameter[i]->
                   urlParameterType.val == SO_URLPARAMETER_MADDRHOST &&
                   reqAddr->t.sipsUrl.urlParameters.urlParameter[i]->
                   urlParameterType.pres == PRSNT_NODEF)
                {
                   host = &reqAddr->t.sipsUrl.urlParameters.
                   urlParameter[i]->t.maddrHost;
                   tmpCount++;
                   if(tmpCount == 2)
                   break;
                }   
                else if(SO_CMP_TKN_LIT(
                         &reqAddr->t.sipsUrl.urlParameters.
                         urlParameter[i]->
                         urlParameterType, 
                         SO_URLPARAMETER_USERPARAM) == TRUE)
                {
                   if (SO_CMP_TKN_LIT(
                       &reqAddr->t.sipsUrl.urlParameters.
                       urlParameter[i]->
                       t.userParam.userParamType, SO_USERPARAM_PHONE))
                   {
                      tmpCount++;
                      *isTel = TRUE;
                      if(tmpCount == 2)
                         break;
                   }
                }
             }
          }

         break;
#endif /* SO_TLS */         
#ifdef SO_ENUM    
      case SO_ADDRSPEC_TELURL:
         length = reqAddr->t.telUrl.digits.len;
         val = reqAddr->t.telUrl.digits.val;
         break;
#endif /* SO_ENUM */
      /* so033.201: removed code for FAX & modem since it not supported */ 
      default:
         RETVALUE(RFAILED);
   }   
   
   if(*isTel == TRUE)
   { 

      if (length <= 1 || length > CM_DNS_DNAME_LEN)
      {
         RETVALUE(RFAILED);
      }

      for(i = 0; i < length; i++)
      {
         if(val[i] == ';')
            break;         
      }
      length = i;      
      for (i = length; i >0; i--)
      {
         if ((val[i-1] >= '0') && (val[i-1] <= '9'))
         {
            buf[indx++] = val[i-1];
            buf[indx++] = '.';
         }
      }

      for (i = 0; i < 9; i++)
         buf[indx++] = name[i];

      tmpOSXL.val = (U8 *)buf;
      tmpOSXL.pres = PRSNT_NODEF;
      tmpOSXL.len = indx;
   
      if(soDnsCpyHostStr(&tmpOSXL,hostName,FALSE) != ROK)
      {
         RETVALUE(RFAILED);
      }
   }
   else
   {
      if(host && host->hostType.pres == PRSNT_NODEF)
      {
         if ((host->hostType.val == SO_HOST_IPV4ADDRESS)
#ifdef IPV6_SUPPORTED     
            || (host->hostType.val == SO_HOST_IPV6REFERENCE)
#endif
           )
         {
            *isIp = TRUE;
            *ipType = host->hostType.val; 
            if(*tptProt == LSO_TPTPROT_NULL)
               *tptProt = LSO_TPTPROT_UDP;
            if(port->pres == NOTPRSNT)
            {
               port->pres = PRSNT_NODEF;
               port->val = SO_PORT_DEFAULT;
            }
         }
         else
         {
            if(soDnsCpyHostStr(&host->t.hostName,hostName,FALSE) != ROK)
            {
               RETVALUE(RFAILED);
            }
         }
      }
      else
      {
         RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /* soDnsGetHostNameFromNaptrUri */

#ifdef SO_ENUM
/*****************************************************************************
*
*       Fun:   soDnsNaptrULookup
*
*       Desc:  Performs DNS NAPTR type lookup
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: Checks DNS cache
*              If not found, query DNS server
*              Use callback function to return result to caller
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsNaptrULookup
(
SoDnsQueryCb *newQueryCb
)
#else
PRIVATE S16 soDnsNaptrULookup(newQueryCb)
SoDnsQueryCb *newQueryCb;
#endif
{
   U8 buf[SO_DNS_ENUM_STR_LEN];   /* Buffer to hold the query string */
   U16               length;      /* Holds length of a string */
   U16               i;           /* Loop counter */
   /*-- so021.201: Removing warning --*/
   U16               indx;        /* Index into the buffer 
                                   * where the next
                                   * character is to be placed */
   U8                *val;        /* Holds the value of a string */
   U8                name[] = "e164.arpa";  /* String to be appended 
                                             * to the tel
                                             * to form DNS query */ 
   TknStrOSXL        tmpOSXL;
   SoAddrSpec        *reqAddr;
   SoAddress         *uri;
   SoDnsNaptrResult  *result;
   
   TRC2(soDnsNaptrULookup);

   indx = 0;
   length = 0;

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Performing NAPTRU Lookup\n"));
   
   if(newQueryCb->naptrUCp.last == NULLP)
   {
      reqAddr = newQueryCb->reqAddr;
   }
   else
   {   
      result = (SoDnsNaptrResult *)newQueryCb->naptrUCp.last->node;
   
      uri = &result->uri[result->current-1];
      if(uri->addrCh.addrChType.pres != PRSNT_NODEF)
         RETVALUE(RFAILED);
      if(uri->addrCh.addrChType.val == SO_ADDRCH_NAMEADDR)
         reqAddr = &uri->addrCh.t.nameAddr.addrSpec;      
      else if(uri->addrCh.addrChType.val == SO_ADDRCH_ADDRSPEC)
         reqAddr = &uri->addrCh.t.addrSpec;      
      else
         RETVALUE(RFAILED);
   }
   
   switch(reqAddr->addrSpecType.val)
   {
      case SO_ADDRSPEC_SIPURL:
         length = reqAddr->t.sipUrl.userInfo.userType.value.len; 
         val = reqAddr->t.sipUrl.userInfo.userType.value.val; 
         break;
#ifdef SO_TLS    
      case SO_ADDRSPEC_SIPSURL:
         length = reqAddr->t.sipUrl.userInfo.userType.value.len; 
         val = reqAddr->t.sipUrl.userInfo.userType.value.val; 
         break;
#endif /* SO_TLS */
      case SO_ADDRSPEC_TELURL:
         length = reqAddr->t.telUrl.digits.len;
         val = reqAddr->t.telUrl.digits.val;
         break;
      /* so033.201: removed code for FAX & modem since it not supported */ 
      default:
         RETVALUE(RFAILED);
   }    

   if (length <= 1 || length > 256)
   {
      RETVALUE(RFAILED);
   }

   for(i = 0; i < length; i++)
   {
      if(val[i] == ';')
         break;         
   }
   length = i;      
   for (i = length; i >0; i--)
   {
      if ((val[i-1] >= '0') && (val[i-1] <= '9'))
      {
         if(indx == SO_DNS_ENUM_STR_LEN)
            RETVALUE(RFAILED);       
         buf[indx++] = val[i-1];
         buf[indx++] = '.';
      }
   }

   for (i = 0; i < 9; i++)
   {
      if(indx == SO_DNS_ENUM_STR_LEN)
         RETVALUE(RFAILED);       
      buf[indx++] = name[i];
   }
   tmpOSXL.val = (U8 *)buf;
   tmpOSXL.pres = PRSNT_NODEF;
   tmpOSXL.len = indx;
   
   if(soDnsCpyHostStr(&tmpOSXL,&newQueryCb->queryAddress,FALSE) != ROK)
   {
      RETVALUE(RFAILED);
   }

   if(soDnsProcNaptrQuery(newQueryCb,&newQueryCb->queryAddress, TRUE) 
                          != ROK)
   {
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* soDnsNaptrULookup */

/*****************************************************************************
*
*       Fun:   soDnsProcNaptrQuery
*
*       Desc:  Performs DNS NAPTR type lookup
*
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsProcNaptrQuery
(
SoDnsQueryCb *dnsQuery,
TknStrOSXL   *hostName,
Bool         isNaptrU
)
#else
PRIVATE S16 soDnsProcNaptrQuery(dnsQuery, hostName, isNaptrU)
SoDnsQueryCb *dnsQuery;
TknStrOSXL   *hostName;
Bool         isNaptrU;
#endif
{
   S16               ret;         /* Return value */
   SoClDnsNaptrEnt   *result;     /* Result from cache lookup */

   TRC2(soDnsProcNaptrQuery);
#ifdef SO_ENUM   
   if(isNaptrU == TRUE)
   {
      dnsQuery->searchState = SO_DNS_FSM_NAPTRU;
   }
   else
   {      
      dnsQuery->searchState = SO_DNS_FSM_NAPTRS;
   }
#else
   dnsQuery->searchState = SO_DNS_FSM_NAPTRS;
#endif
   /* Control block created, check cache */
   ret = soClFindDnsNaptrEntry(&soCb.cacheInfoCb.dnsNaptrCache,
                               hostName, 
                               &result);
   if ((ret == ROK) && (result->listCp.count != 0))
   {
      /*-- so032.201: Adding Debug Prints ------------------------------------*/
      SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
               "[DNS] Found NAPTR Record in Cache\n"));

      /* Cache had valid records, return to user */
      /* so034.201: Pass isNaptrU instead of True*/
      if(soDnsCacheFoundNaptr(dnsQuery,result, isNaptrU) != ROK)
      {
         RETVALUE(RFAILED);
      }
      RETVALUE(ROK);
   }
   ret = soSendDnsQuery(dnsQuery, (U8)hostName->len,hostName->val,
                        CM_DNS_QTYPE_NAPTR, CM_DNS_PROTOCOL_UDP,
                        CM_DNS_SERVICE_SIP);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* soDnsProcNaptrQuery */
#endif /* SO_ENUM */

/*****************************************************************************
*
*       Fun:   soDnsFreeAResult
*
*       Desc:  free srv result
*
*       Ret:   Nothing
*
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE Void soDnsFreeAResult
(
SoDnsAResult *result     /* record */
)
#else
PRIVATE Void soDnsFreeAResult(result)
SoDnsAResult *result;     /* record */
#endif
{
   
   /* so027.201: Correction in trace */
   TRC2(soDnsFreeAResult);

   SOFREE(result->ipAddress, sizeof(CmNetAddr)*result->numComp);
   SOFREE(result, sizeof(SoDnsAResult));
   RETVOID;
} /* soDnsFreeAResult */

/*****************************************************************************
*
*       Fun:   soDnsFreeSRvResult
*
*       Desc:  free srv result
*
*       Ret:   Nothing
*
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE Void soDnsFreeSrvResult
(
SoDnsSrvResult *result     /* record */
)
#else
PRIVATE Void soDnsFreeSrvResult(result)
SoDnsSrvResult *result;    /* record */
#endif
{
   U16               i;
   
   TRC2(soDnsFreeSRvResult);

   if(result == NULLP)
      RETVOID;
   for(i = 0; i < result->numComp; i++)
   {
      if(result->ipAddress[i].ipAddress != NULLP)
      {         
         SOFREE(result->ipAddress[i].ipAddress, 
         sizeof(CmNetAddr)*(result->ipAddress[i].numComp));
      }
      soUtlDelTknStrOSXL(result->hostNames + i);
   }
 
 
   if(result->ports != NULLP)
      SOFREE(result->ports,sizeof(U16)*(result->numComp));
   if(result->hostNames != NULLP)
      SOFREE(result->hostNames,sizeof(TknStrOSXL)*(result->numComp));
   if(result->protocol != NULLP)
      SOFREE(result->protocol,sizeof(U8)*(result->numComp));
   if(result->ipAddress != NULLP)
      SOFREE(result->ipAddress,sizeof(SoDnsAResult)*(result->numComp));
   soUtlDelTknStrOSXL(&result->originalQuery);
   if(result != NULLP)
      SOFREE(result, sizeof(SoDnsSrvResult));
   RETVOID;
} /* soDnsFreeSrvResult */

/*****************************************************************************
*
*       Fun:   soDnsFreeNaptrResult
*
*       Desc:  save teh naptr result to query Cb
*
*       Ret:   Nothing
*
*       Notes: 
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE Void soDnsFreeNaptrResult
(
SoDnsNaptrResult *result
)
#else
PRIVATE Void soDnsFreeNaptrResult(result)
SoDnsNaptrResult *result;
#endif
{
   Cntr              i;           /* Loop counter */

   TRC2(soDnsFreeNaptrResult);

   
   soUtlDelTknStrOSXL(&result->originalQuery);
   for(i = 0; i < result->numComp; i++)
   {
      soUtlDelTknStrOSXL(&result->normUri[i]);
      soUtlDelSoAddress(&result->uri[i]);
   }
   SOFREE(result->normUri, sizeof(TknStrOSXL)*result->numComp);
   SOFREE(result->uri, sizeof(SoAddress)*result->numComp);
   SOFREE(result, sizeof(SoDnsNaptrResult));
   RETVOID;
} /* soDnsFreeNaptrResult */

#ifdef SO_ENUM
/*****************************************************************************
*
*       Fun:   soDnsFreeNaptrList
*
*       Desc:  free all the naptr U nodes
*
*       Ret:   Nothing
*
*       Notes: 
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE Void soDnsFreeNaptrList
(
CmLListCp *cp
)
#else
PRIVATE Void soDnsFreeNaptrList(cp)
CmLListCp *cp;
#endif
{
   SoDnsNaptrResult *result;
   CmLList           *node;       /* Ptr for walking thru llist */

   TRC2(soDnsFreeNaptrList);

   node = cp->last;
   while(node != NULLP)
   {
      cmLListDelFrm(cp, node);
      result = (SoDnsNaptrResult *)node->node;
      soDnsFreeNaptrResult(result);
      node = cp->last;
   }
   RETVOID;
} /* soDnsFreeNaptrList */
#endif /* SO_ENUM */


/********************************************************************
*
*       Fun:   soDnsFreeQueryCb
*
*       Desc:  free DNS query control block. Timer is not handled here
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       File:  so_dns.c
*
********************************************************************/
#ifdef ANSI
PRIVATE Void soDnsFreeQueryCb
(
SoDnsQueryCb *queryCb   /* query control block */
)
#else
PRIVATE Void soDnsFreeQueryCb(queryCb)
SoDnsQueryCb *queryCb;   /* query control block */
#endif
{
   TRC2(soDnsFreeQueryCb);
   
   (Void)soSchedTmr (queryCb,
      SO_TMR_DNS_LOOKUP, TMR_STOP, NOTUSED);
   if (queryCb->requestId < SO_DNS_REQUESTIDLSTSZ)
      cmDnsAbortRslvReq(soCb.dnsCb,queryCb->requestId);

   soUtlDelTknStrOSXL(&queryCb->queryAddress);
   
   if(queryCb->mBuf != NULLP)
      SPutMsg(queryCb->mBuf);

   if(queryCb->naptrResult)
      soDnsFreeNaptrResult(queryCb->naptrResult);

   if(queryCb->srvResult)
   {
      soDnsFreeSrvResult(queryCb->srvResult);
      queryCb->srvResult = NULLP;
   }
#ifdef SO_INSTMSG
   if(queryCb->imResult)
   {
      soDnsFreeSrvResult(queryCb->imResult);
      queryCb->imResult = NULLP;
   }
#endif   
#ifdef SO_PRESENCE
   if(queryCb->presResult)
   {
      soDnsFreeSrvResult(queryCb->presResult);
      queryCb->presResult = NULLP;
   }
#endif   
   if(queryCb->aResult)
   {
      soDnsFreeAResult(queryCb->aResult);
      queryCb->aResult = NULLP;
   }
   
#ifdef SO_ENUM
   soDnsFreeNaptrList(&queryCb->naptrUCp);
#endif /* SO_ENUM */
   
   SOFREE(queryCb,sizeof(SoDnsQueryCb));
   RETVOID;         
} /* soDnsFreeQueryCb */

/********************************************************************
*
*       Fun:   soDnsLookupRel
*
*       Desc:  free DNS query control block. Timer is not handled here
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       File:  so_dns.c
*
********************************************************************/
#ifdef ANSI
PUBLIC S16 soDnsLookupRel
(
PTR cb   /* query control block */
)
#else
PUBLIC S16 soDnsLookupRel(cb)
PTR cb;  /* query control block */
#endif
{
   SoDnsQueryCb *queryCb   /* query control block */
   
   TRC2(soDnsLookupRel);
   
   queryCb = (SoDnsQueryCb *)cb;
   
   if(queryCb->tcpQueryCb != NULLP)
      soDnsFreeQueryCb(queryCb->tcpQueryCb);
#ifdef SO_SCTP   
   if(queryCb->sctpQueryCb != NULLP)
      soDnsFreeQueryCb(queryCb->sctpQueryCb);
#endif   
#ifdef SO_TLS   
   if(queryCb->tlsTcpQueryCb != NULLP)
      soDnsFreeQueryCb(queryCb->tlsTcpQueryCb);
#endif /* SO_TLS */  
   soDnsFreeQueryCb(queryCb);
   RETVALUE(ROK);         
} /* soDnsLookupRel */


/********************************************************************
*
*       Fun:   soDnsCreateQueryCb
*
*       Desc:  Creates new DNS query control block
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       File:  so_dns.c
*
********************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsCreateQueryCb
(
PTR                     context,      /* User context */
SoAddrSpec              *reqAddr,     /* Request URI address */
U8                      addrType,     /* address type */
TknU16                  *port,        /* port */
TknStrOSXL              *host,
U8                      tptProt,      /* tpt protocol */
SoDnsQueryCb            **newQuery,   /* New query control block */
U8                      urlType,
SoDnsCallBackFn         callback,     /* call back function */
Bool                    master        /* master */
)
#else
PRIVATE S16 soDnsCreateQueryCb(context, reqAddr, addrType, 
                               port, host, tptProt, newQuery,
                               urlType, callback, master)
PTR                     context;      /* User context */
SoAddrSpec              *reqAddr;     /* Request URI address */
U8                      addrType;     /* address type */
TknU16                  *port;        /* port */
TknStrOSXL              *host;        /* host */
U8                      tptProt;      /* tpt protocol */
SoDnsQueryCb            **newQuery;   /* New query control block */
U8                      urlType;
SoDnsCallBackFn         callback;     /* call back function */
Bool                    master;       /* master */
#endif
{
   TRC2(soDnsCreateQueryCb);
   SOALLOC(newQuery, sizeof(SoDnsQueryCb));
   if (*newQuery == NULLP)
   {
      RETVALUE(RFAILED);
   }
   switch(addrType)
   {
#ifdef SO_ENUM
      case SO_DNS_ADDR_TYPE_TEL:
         break;
#endif
#ifdef SO_TEL
      case SO_DNS_ADDR_TYPE_FAX:
      case SO_DNS_ADDR_TYPE_MODEM:
         break;
#endif
      default:   
         if(soDnsCpyHostStr(host,
            &(*newQuery)->queryAddress,FALSE) != ROK)
         {
            SOFREE(*newQuery, sizeof(SoDnsQueryCb));
            RETVALUE(RFAILED);
         }
         break;
   }
   (*newQuery)->master       = master;
   (*newQuery)->numCbs = 1;      
   (*newQuery)->searchState  = SO_DNS_FSM_INIT;
   /* copy teh user context into DNS Cb */
   cmMemcpy((U8 *)&(*newQuery)->usrCtxt,
            (U8 *)context, sizeof(SoUserCtxt));
   (*newQuery)->reqAddr      = reqAddr;
   (*newQuery)->callback     = callback;
   (*newQuery)->queryType    = addrType;
   (*newQuery)->aResult      = NULLP;
   (*newQuery)->srvResult    = NULLP;
   (*newQuery)->naptrResult  = NULLP;
   (*newQuery)->requestId    = SO_DNS_REQUESTIDLSTSZ;
   (*newQuery)->mBuf         = NULLP;
   (*newQuery)->masterQueryCb= NULLP;
   (*newQuery)->retryCount   = 0;
   (*newQuery)->tcpQueryCb   = NULLP;
   (*newQuery)->tptProt      = tptProt;
   (*newQuery)->urlType      = urlType;
   if(port && port->pres == PRSNT_NODEF && port->val != 0)
   {
      (*newQuery)->origPort.val = port->val;
   }
   else
   {
      /* so041.201: if port is not preasent, update default port for TLS */ 
#ifdef SO_TLS
      if ((*newQuery)->tptProt == LSO_TPTPROT_TLS_TCP)
      {
         (*newQuery)->origPort.val = SO_PORT_TLS_DEFAULT;
      }
      else
#endif
         (*newQuery)->origPort.val = SO_PORT_DEFAULT;
   }

   (*newQuery)->origPort.pres = PRSNT_NODEF;
      
#ifdef SO_SCTP
   (*newQuery)->sctpQueryCb  = NULLP;
#endif   
#ifdef SO_ENUM
   cmLListInit(&((*newQuery)->naptrUCp));
#endif
   
   soCmInitTimer(&((*newQuery)->dnsQueryTmr));
   
   RETVALUE(ROK);
} /* soDnsCreateQueryCb */

/********************************************************************
*
*       Fun:   soDnsCpyHostStr
*
*       Desc:  Fills a tknstr with the host name specified
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       File:  so_dns.c
*
********************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsCpyHostStr
(
TknStrOSXL              *hostName, /* Host name to lookup */
TknStrOSXL              *target,   /* The place to put the unescaped host */
Bool                    noHost     /* true removes aa. from aa.bb.cc hosts */
)
#else
PRIVATE S16 soDnsCpyHostStr(hostName, target, noHost)
TknStrOSXL              *hostName; /* Host name to lookup */
TknStrOSXL              *target;   /* The place to put the unescaped host */
Bool                    noHost;    /* true removes aa. from aa.bb.cc hosts */
#endif
{
   TknStrOSXL  queryAddress;     /* Unescaped finished host */
   U8          *unescaped;       /* Unescaped string */
   U16         startDomain;      /* Start of domain part */
   U16         length;           /* Length of unescaped string */
   U16         numberOfDots;     /* No of Dots in the DNS name */

   TRC2(soDnsCpyHostStr);
   
   numberOfDots = 0;
   startDomain = 0;
   
   if(target == NULLP)
      RETVALUE(RFAILED);
   soUtlDelTknStrOSXL(target);
   SOALLOC(&unescaped,hostName->len);
   if (unescaped == NULLP)
   {
      RETVALUE(RFAILED);
   }

   soDnsUnEscape(unescaped,&length,hostName->val,
                 hostName->len,hostName->len);
   if(noHost)
   {
      for (startDomain = 0; startDomain < length; startDomain++)
      {
         if (unescaped[startDomain] == '.')
            numberOfDots++;
      }

      if (numberOfDots == 0)
      {
          SODBGP_SO(SO_DBGMASK_DNS, (soCb.init.prntBuf,
                   "\nQuery Address Invalid \n"));
          SOFREE(unescaped,hostName->len);
          RETVALUE(RFAILED);
      }
      if ((noHost == TRUE)&& (numberOfDots > 1))
      {
         for(startDomain = 0; startDomain < length &&
             unescaped[startDomain] != '.'; startDomain++)
         {
            startDomain++;
         }
         if (startDomain >= length)
         {
            startDomain = 0;
         }
      }
      else
      {
         startDomain = 0;
      }
      length -= startDomain;
      SOALLOC(&(queryAddress.val),length);
      if (queryAddress.val == NULLP)
      {
         SOFREE(unescaped,hostName->len);
         RETVALUE(RFAILED);
      }
      cmMemcpy(queryAddress.val,unescaped+startDomain,length);
      queryAddress.len  = length;
      queryAddress.pres = PRSNT_NODEF;
      SOFREE(unescaped,hostName->len);
      cmMemcpy((U8*)target,(U8*)&queryAddress,sizeof(TknStrOSXL));
      SOFREE(queryAddress.val,length);
   }
   else
   {
      queryAddress.len  = length;
      queryAddress.pres = PRSNT_NODEF;
      queryAddress.val = unescaped;
      cmMemcpy((U8*)target,(U8*)&queryAddress,sizeof(TknStrOSXL));
   }

   RETVALUE(ROK);
} /* soDnsCpyHostStr */


/*****************************************************************************
*
*       Fun:   soDnsUnEscape
*
*       Desc:  Unescapes a one string into the other not exeeding maxSize
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsUnEscape
(
U8         *dst,           /* Destination string */
U16        *dstLen,        /* Length of returned string */
U8         *src,           /* Source string */
U16        srcLen,         /* Source string length */
U16        maxLen          /* Max len of destination string */
)
#else
PRIVATE S16 soDnsUnEscape(dst,dstLen,src,srcLen,maxLen)
U8         *dst;           /* Destination string */
U16        *dstLen;        /* Length of returned string */
U8         *src;           /* Source string */
U16        srcLen;         /* Source string length */
U16        maxLen;         /* Max len of destination string */
#endif
{
   U16   unescKeyLength = srcLen;
   U8    *keyBuffer     = src;
   U8    *newKey        = dst;
   U16   *keyLength     = dstLen;
   U8    unescChar;    
   U8    ch;         
   Cntr  i;         
   Cntr  j;        
   Txt    *SO_URI_UNWISE_RESERVED_CHAR = ";/?:@&=+$,{}|\\^[]`";

   TRC2(soDnsUnEscape);

   (*keyLength) = 0;
   for (i=0; i<unescKeyLength && (*keyLength) < maxLen; i++)
   {
      ch = keyBuffer[i];
      if (ch == SO_URI_ESCAPE_CHAR)
      {
         /* Get unescaped version, if not required, keep as unescaped */
         /* Assume that reserved and unsafe characters
          * are already escaped */
         if (i+2<unescKeyLength)
         {
            unescChar = HEX_TO_DEC(TO_LOWER(keyBuffer[i+1])) << 4;
            unescChar += HEX_TO_DEC(TO_LOWER(keyBuffer[i+2]));


            for (j=0; SO_URI_UNWISE_RESERVED_CHAR[j] &&
                      SO_URI_UNWISE_RESERVED_CHAR[j] != unescChar; j++)
            /* Empty loop */;

            /* Only unescape if not in UNWISE_RESERVED set */
            if (SO_URI_UNWISE_RESERVED_CHAR[j] != unescChar)
            {
               /* Copy in unescaped format */
               newKey[(*keyLength)++] = unescChar;
               i+=2;
            }
            else
            {
               /* Copy in escaped format */
               newKey[(*keyLength)++] = keyBuffer[i++];
               newKey[(*keyLength)++] = keyBuffer[i++];
               newKey[(*keyLength)++] = keyBuffer[i];
            }
         }
         else
         {
            /* Error, should be at least 2 remaining! */
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG,ESO084,(ErrVal) 0,
               "dnsUnEscape: Invalid escaped character in key");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
            RETVALUE(RFAILED);
         }
      }
      else
      {
         /* Copy lower case version of character */
         newKey[(*keyLength)++] = TO_LOWER(ch);
      }
   }
   RETVALUE(ROK);
} /* soDnsUnEscape */

/*****************************************************************************
*
*       Fun:   soDnsSendRslvReqToDnsServer
*
*       Desc:  Send dns request to dns server over line
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  soth.c
*
******************************************************************************/
#ifdef ANSI
PUBLIC S16 soDnsSendRslvReqToDnsServer
(
Ptr         usrCtxt,             /* User context */
CmTptAddr   *dnsAddr,            /* DNS Transport Address */
Buffer      *mBuf                /* Message Buffer to transmit */
)
#else
PUBLIC S16 soDnsSendRslvReqToDnsServer(usrCtxt, dnsAddr, mBuf)
Ptr         usrCtxt;             /* This is soDnsSapCb->tsapCb */
CmTptAddr   *dnsAddr;            /* DNS Transport Address */
Buffer      *mBuf;               /* Message Buffer to transmit */
#endif
{
   SoDnsQueryCb   *q;
   S16            ret;

   TRC2(soDnsSendRslvReqToDnsServer);

   /* Update statistics */
   q = (SoDnsQueryCb *)usrCtxt;
   soCb.sts.dnsSts.nmbDnsQueryTx++;
   /* Store mBuf */
   if (q->mBuf == NULLP)
   {
      /* Increment reference count and store copy */
      ret = SAddMsgRef(mBuf,soCb.init.region,soCb.init.pool,&q->mBuf);
      if(ret != ROK)
         RETVALUE(RFAILED);
   }

   /* Fill tcmConn with target address and srv to use */
   /*soUtlCpyCmTptAddr(&soCb.dnsConn.clientCb->remoteAddr, 
    * dnsAddr, NULLP); */
   /* soPrcUpdateTcmConnServer(&soCb.dnsConn, soCb.dnsSrvCb); */

#ifdef DEBUGP   
   if(soCb.init.dbgMask & SO_DBGMASK_DNS)
   {
      SODBGP_SO(SO_DBGMASK_DNS, (soCb.init.prntBuf,
                   "\n--Outgoing DNS query--\n"));
      SPrntMsg(mBuf,0,0);
   }      
#endif /* DEBUGP */
   
   ret = soTptUdpSendDnsReq(soCb.dnsSrvCb, dnsAddr, mBuf);

   RETVALUE(ret);

} /* soDnsSendRslvReqToDnsServer */

/*****************************************************************************
*
*       Fun:   soDnsModuleTimeoutHandle
*
*       Desc:  Processes the dns query timer
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This function is invoked by TMR module dispatch a timer expiry
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PUBLIC S16 soDnsModuleTimeoutHandle
(
PTR          usrCtxt,
PTR          Cb,
U8           event
)
#else
PUBLIC S16 soDnsModuleTimeoutHandle(usrCtxt, Cb, event)
PTR          usrCtxt;
PTR          Cb;
U8           event;
#endif
{
   S16           ret;
   SoDnsQueryCb  *dnsCb;
   
   TRC2(soDnsModuleTimeoutHandle);

   dnsCb = (SoDnsQueryCb *)Cb;

   if(usrCtxt)
      cmMemcpy((U8 *)&dnsCb->usrCtxt, 
               (U8 *)usrCtxt, sizeof(SoUserCtxt));
   
   switch(event)
   {
      case SO_DNS_QUERY_TIMEOUT:
         ret = soDnsProcInQueryTmr(NULLP, Cb);
         break;
      case SO_DNS_TRAN_TIMEOUT:
         ret = soDnsProcInTranTimeout(NULLP, Cb);
         break;
      default:
         ret = RFAILED;
    break;
   }
   RETVALUE(ret);
} /* soDnsModuleTimeoutHandle */


/*****************************************************************************
*
*       Fun:   soDnsProcInQueryTmr
*
*       Desc:  Processes the dns query timer
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This function is invoked to dispatch 
*              a DNS query timeout event
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsProcInQueryTmr
(
PTR           rsp, 
PTR           Cb
)
#else
PRIVATE S16 soDnsProcInQueryTmr(rsp, Cb)
PTR           rsp; 
PTR           Cb;
#endif
{
   Buffer       *mBuf;      /* Encoded DNS request */
   S16          ret;
   SoDnsQueryCb *dnsCb;
   
   TRC2(soDnsProcInQueryTmr);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Process Query Timer Expiry\n"));
   
   dnsCb = (SoDnsQueryCb *)Cb;

   if (dnsCb->mBuf == NULLP)
   {
      SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf,
                "\n No Message For Retransmission  \n"));
      RETVALUE (RFAILED);
   }

   if (dnsCb->retryCount++ < soCb.reCfg.dnsReCfg.maxDnsRetry)
   {
      if(SAddMsgRef(dnsCb->mBuf,soCb.init.region,
                    soCb.init.pool,&mBuf) == ROK)
      {         
         soDnsSendRslvReqToDnsServer(
               dnsCb,&soCb.reCfg.dnsReCfg.dnsTptAddr,mBuf);
      }    
      soSchedTmr(dnsCb, SO_TMR_DNS_LOOKUP,TMR_START,
                 soCb.reCfg.dnsReCfg.dnsQueryTmr.val);
      RETVALUE(ROK);
   }

   soCb.sts.dnsSts.nmbDnsQueryTO++;
   ret = (soDnsFsmTbl[SO_DNS_QUERY_TIMEOUT][dnsCb->searchState])(rsp, 
          &dnsCb);
   if(ret != ROK)
   {
      soDnsInvErrHandle(NULLP, &dnsCb);
   }
   RETVALUE(ROK);
} /* soDnsProcInQueryTmr */

/*****************************************************************************
*
*       Fun:   soDnsProcInTranTimeout
*
*       Desc:  Processes the transaction timeout event
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: This function is invoked 
               to dispatch a tran timeout.
          The function returns RFAILED if no more retry is available. 
          For this case, the dialog module should envoke 
          the dns release routine for the clean up. 
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsProcInTranTimeout
(
PTR          rsp, 
PTR          Cb
)
#else
PRIVATE S16 soDnsProcInTranTimeout(rsp, Cb)
PTR          rsp; 
PTR          Cb;
#endif
{
   SoDnsQueryCb *dnsCb;
   S16          ret;
   
   TRC2(soDnsProcInTranTimeout);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Process Transaction Timeout Expiry\n"));
   
   dnsCb = (SoDnsQueryCb *)Cb;
   
   ret = (soDnsFsmTbl[SO_DNS_TRAN_TIMEOUT][dnsCb->searchState])(rsp, 
                                                             &dnsCb);
   RETVALUE(ret);
} /* soDnsProcInTranTimeout */

/*****************************************************************************
*
*       Fun:   soDnsTranTimeoutErrHandle
*
*       Desc:  The transaction timeout error handler.
*
*       Ret:   RFAILED
*
*       Notes: It's a dummy func now. 
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsTranTimeoutErrHandle
(
PTR       rsp,
SoDnsQueryCb **q      /* target */
)
#else
PRIVATE  S16 soDnsTranTimeoutErrHandle(rsp, q)
PTR       rsp;
SoDnsQueryCb **q;      /* target */
#endif
{
   TRC2(soDnsTranTimeoutErrHandle);

   UNUSED(rsp);
   UNUSED(q);
   RETVALUE(RFAILED);
} /* soDnsTranTimeoutErrHandle */


/*****************************************************************************
*
*       Fun:   soDnsProcSrvTranTmr
*
*       Desc:  process transaction timeout for SRV
*
*
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsProcSrvTranTmr
(
PTR           rsp, 
SoDnsQueryCb  **q     /* Query record */
)
#else
PRIVATE S16 soDnsProcSrvTranTmr(rsp, q)
PTR           rsp; 
SoDnsQueryCb  **q;     /* Query record */
#endif
{
   SoDnsSrvResult    *result;    /* Ptr to result in dnsQuery */
   SoDnsAResult      *tmpA;      /* Ptr to A result in dnsQuery */
   CmTptAddr         tptAddr;
   U16               srvNum;
   U16               aNum;
   SoAddress         *naptrUri;
#ifdef SO_ENUM   
   SoDnsNaptrResult  *naptrResult;
#endif /* SO_ENUM */   
   SoDnsQueryCb      *dnsQuery;     /* Query record */
   
   TRC2(soDnsProcSrvTranTmr);

   dnsQuery = *q;
   /* set the tptAddr to zero because tcm module needs
    * the entire tptaddr for hash find. */ 
   (Void) cmMemset((U8 *)&tptAddr, 0, sizeof(CmTptAddr));
   result = dnsQuery->srvResult;   
   srvNum = result->current;
   tmpA =  &result->ipAddress[srvNum]; 
   aNum = tmpA->current;
   if(tmpA->numComp == 0)
   {
      if(result->current >= result->numComp)
      {
         RETVALUE(soDnsDoSrvRecur(dnsQuery));         
      }
      soUtlDelTknStrOSXL(&dnsQuery->queryAddress);
      if(soUtlCpyTknStrOSXL(&dnsQuery->queryAddress, 
            &result->hostNames[result->current++],
            NULLP) != ROK)
      {
          RETVALUE(RFAILED);
      }    
      if(soDnsALookup(dnsQuery) != ROK)
         RETVALUE(RFAILED);
      RETVALUE(ROK);      
   }
   
   if(tmpA->ipAddress[aNum].type == CM_NETADDR_IPV4)
   {
      tptAddr.type = CM_TPTADDR_IPV4;
      tptAddr.u.ipv4TptAddr.port = result->ports[result->current++];
      tptAddr.u.ipv4TptAddr.address = 
      tmpA->ipAddress[aNum].u.ipv4NetAddr;
   }
#ifdef IPV6_SUPPORTED        
   else
   {
      tptAddr.type = CM_TPTADDR_IPV6;
      tptAddr.u.ipv6TptAddr.port = result->ports[result->current++];
      cmMemcpy((U8*)&tptAddr.u.ipv6TptAddr.ipv6NetAddr, 
         (U8*)&tmpA->ipAddress[aNum].u.ipv6NetAddr, 16);
   }
#endif   
   switch(dnsQuery->queryType)
   {
#ifdef SO_ENUM
      case SO_DNS_ADDR_TYPE_TEL:
         naptrResult =(SoDnsNaptrResult *)(dnsQuery->naptrUCp.last->node);
         naptrUri = &naptrResult->uri[naptrResult->current-1];
         break;
#endif
#ifdef SO_TEL
      case SO_DNS_ADDR_TYPE_FAX: 
      case SO_DNS_ADDR_TYPE_MODEM:
         naptrResult =(SoDnsNaptrResult *)(dnsQuery->naptrUCp.last->node);
         naptrUri = &naptrResult->uri[naptrResult->current-1];
         break;
#endif
      default:
         naptrUri = NULLP;
         break;
   }

   if (dnsQuery->asyncCall)
   {
      /* 
       * This funcntion was called after receiving DNS query
       * response (i.e, ayncronously).
       */ 
      (*dnsQuery->callback)((PTR)&dnsQuery->usrCtxt, 
                             dnsQuery->queryType,
                             &tptAddr, 
                             result->protocol[result->current-1],
                             naptrUri);
   }
   else
   {
       cmMemcpy ((U8 *)&dnsQuery->destAddr, 
                 (U8 *)&tptAddr,
                 sizeof (CmTptAddr));
   
       dnsQuery->destProt = result->protocol[result->current-1];

       dnsQuery->addrResolved = TRUE;
   }

   RETVALUE (ROK);

} /* soDnsProcSrvTranTmr */

/*****************************************************************************
*
*       Fun:   soDnsProcATranTmr
*
*       Desc:  process transaction timeout for SRV
*
*
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsProcATranTmr
(
PTR           rsp, 
SoDnsQueryCb  **q     /* Query record */
)
#else
PRIVATE S16 soDnsProcATranTmr(rsp, q)
PTR           rsp; 
SoDnsQueryCb  **q;     /* Query record */
#endif
{
   SoDnsAResult     *result;    /* Ptr to a result in dnsQuery */
   CmTptAddr         tptAddr;
   U16               port;
   U8                protocol;
   SoAddress         *naptrUri;
#ifdef SO_ENUM   
   SoDnsNaptrResult  *naptrResult;
#endif /* SO_ENUM */   
   U16               srvNum;
   SoDnsQueryCb      *dnsQuery;     /* Query record */
   
   TRC2(soDnsProcATranTmr);

   dnsQuery = *q;
   /* set the tptAddr to zero because tcm module needs
    * the entire tptaddr for hash find. */ 
   (Void) cmMemset((U8 *)&tptAddr, 0, sizeof(CmTptAddr));
   result = dnsQuery->aResult;
   
   cmMemset((U8 *)&tptAddr, 0, sizeof(CmTptAddr));
   
   if(dnsQuery->srvResult)
   {
      srvNum = dnsQuery->srvResult->current-1;      
      port = dnsQuery->srvResult->ports[srvNum];
      protocol = dnsQuery->srvResult->protocol[srvNum];
   }
   else
   {
      port = dnsQuery->origPort.val;
      protocol = dnsQuery->tptProt;
   } 
   if(result->current >= result->numComp)
   {
      if(dnsQuery->srvResult != NULLP)
      {
         soDnsFreeAResult(dnsQuery->aResult);
         /* so027.201: Reinitializing DNS A result */
         dnsQuery->aResult = NULLP;
         RETVALUE(soDnsProcSrvTranTmr(rsp, &dnsQuery));
      }
      else
      {
         if(dnsQuery->naptrResult != NULLP)
         {
            RETVALUE(soDnsDoSrvRecur(dnsQuery));    
         }
         RETVALUE(RFAILED);
      }
   }      
   
   if(result->ipAddress[result->current].type == CM_NETADDR_IPV4)
   {
      tptAddr.type = CM_TPTADDR_IPV4;
      tptAddr.u.ipv4TptAddr.port = port;
      tptAddr.u.ipv4TptAddr.address = 
       result->ipAddress[result->current++].u.ipv4NetAddr;
   }
   
   switch(dnsQuery->queryType)
   {
#ifdef SO_ENUM
      case SO_DNS_ADDR_TYPE_TEL:
         naptrResult =(SoDnsNaptrResult *)(dnsQuery->naptrUCp.last->node);
         naptrUri = &naptrResult->uri[naptrResult->current-1];
         break;
#endif
#ifdef SO_TEL
      case SO_DNS_ADDR_TYPE_FAX: 
      case SO_DNS_ADDR_TYPE_MODEM:
         naptrResult =(SoDnsNaptrResult *)(dnsQuery->naptrUCp.last->node);
         naptrUri = &naptrResult->uri[naptrResult->current-1];
         break;
#endif
      default:
         naptrUri = NULLP;
         break;
   }

   if (dnsQuery->asyncCall)
   {
      /* 
       * This funcntion was called after receiving DNS query
       * response (i.e, ayncronously).
       */ 
      (*dnsQuery->callback) ((PTR)&dnsQuery->usrCtxt, 
                             dnsQuery->queryType,
                             &tptAddr, 
                             protocol,
                             naptrUri);
   }
   else
   {
       cmMemcpy ((U8 *)&dnsQuery->destAddr, 
                 (U8 *)&tptAddr,
                 sizeof (CmTptAddr));
   
       dnsQuery->destProt     = protocol;

       dnsQuery->addrResolved = TRUE;
   }

   RETVALUE (ROK);

} /* soDnsProcATranTmr */

#ifdef SO_AAAA

/*****************************************************************************
*
*       Fun:   soDnsProcAAAATranTmr
*
*       Desc:  process transaction timeout for AAAA
*
*
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsProcAAAATranTmr
(
PTR           rsp, 
SoDnsQueryCb  **q     /* Query record */
)
#else
PRIVATE S16 soDnsProcAAAATranTmr(rsp, q)
PTR           rsp; 
SoDnsQueryCb  **q;     /* Query record */
#endif
{
   SoDnsAResult     *result;    /* Ptr to a result in dnsQuery */
   CmTptAddr         tptAddr;
   U16               port;
   U8                protocol;
   SoAddress         *naptrUri;
#ifdef SO_ENUM   
   SoDnsNaptrResult  *naptrResult;
#endif /* SO_ENUM */   
   U16               srvNum;
   SoDnsQueryCb      *dnsQuery;     /* Query record */
   
   TRC2(soDnsProcAAAATranTmr);

   dnsQuery = *q;
   /* set the tptAddr to zero because tcm module needs
    * the entire tptaddr for hash find. */ 
   (Void) cmMemset((U8 *)&tptAddr, 0, sizeof(CmTptAddr));
   result = dnsQuery->aResult;
   if(dnsQuery->srvResult)
   {
      srvNum = dnsQuery->srvResult->current-1;      
      port = dnsQuery->srvResult->ports[srvNum];
      protocol = dnsQuery->srvResult->protocol[srvNum];
   }
   else
   {
      port = dnsQuery->origPort.val;
      protocol = dnsQuery->tptProt;
   } 
   if(result->current >= result->numComp)
   {
      if(dnsQuery->srvResult != NULLP)
      {
         soDnsFreeAResult(dnsQuery->aResult);
         RETVALUE(soDnsProcSrvTranTmr(rsp, &dnsQuery));
      }
      else
      {
         if(dnsQuery->naptrResult != NULLP)
         {
            RETVALUE(soDnsDoSrvRecur(dnsQuery));    
         }
         RETVALUE(RFAILED);
      }
   }      
   
   if(result->ipAddress[result->current].type == CM_NETADDR_IPV4)
   {
      tptAddr.type = CM_TPTADDR_IPV4;
      tptAddr.u.ipv4TptAddr.port = port;
      tptAddr.u.ipv4TptAddr.address = 
      result->ipAddress[result->current++].u.ipv4NetAddr;
   }
   else
   {
      tptAddr.type = CM_TPTADDR_IPV6;
      tptAddr.u.ipv6TptAddr.port = port;
      cmMemcpy((U8*)&tptAddr.u.ipv6TptAddr.ipv6NetAddr, 
          (U8*)&result->ipAddress[result->current++].u.ipv6NetAddr, 16);
   }

   switch(dnsQuery->queryType)
   {
#ifdef SO_ENUM
      case SO_DNS_ADDR_TYPE_TEL:
         naptrResult =(SoDnsNaptrResult *)(dnsQuery->naptrUCp.last->node);
         naptrUri = &naptrResult->uri[naptrResult->current-1];
         break;
#endif
#ifdef SO_TEL
      case SO_DNS_ADDR_TYPE_FAX: 
      case SO_DNS_ADDR_TYPE_MODEM:
         naptrResult =(SoDnsNaptrResult *)(dnsQuery->naptrUCp.last->node);
         naptrUri = &naptrResult->uri[naptrResult->current-1];
         break;
#endif
      default:
         naptrUri = NULLP;
         break;
   }

   if (dnsQuery->asyncCall)
   {
      /* 
       * This funcntion was called after receiving DNS query
       * response (i.e, ayncronously).
       */ 
      (*dnsQuery->callback) ((PTR)&dnsQuery->usrCtxt, 
                             dnsQuery->queryType,
                             &tptAddr, 
                             protocol,
                             naptrUri);
   } 
   else
   {
       cmMemcpy ((U8 *)&dnsQuery->destAddr, 
                 (U8 *)&tptAddr,
                 sizeof (CmTptAddr));
   
       dnsQuery->destProt     = protocol;

       dnsQuery->addrResolved = TRUE;
   }


   RETVALUE(ROK);
} /* soDnsProcAAAATranTmr */
#endif

#ifdef SO_ENUM   
/*****************************************************************************
*
*       Fun:   soDnsDoNaptrRecur
*
*       Desc:  generate recursion on Naptr query
*
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsDoNaptrRecur
(
SoDnsQueryCb *cb      
)
#else
PRIVATE S16 soDnsDoNaptrRecur(cb)
SoDnsQueryCb *cb;     
#endif
{
   
   SoDnsNaptrResult   *result;
   CmLList             *node;
   Bool               isTel;
   Bool                isIp;
   TknU16              port;
   U8                  tptProt;
   U8                  ipType;
   
   TRC2(soDnsDoNaptrRecur);

   node = cb->naptrUCp.last;
   if(node == NULLP)
      RETVALUE(RFAILED);
   
   result = (SoDnsNaptrResult *)node->node;
   isTel = FALSE;
   
   while(result != NULLP && 
         result->current == result->numComp)
   {
      cmLListDelFrm(&cb->naptrUCp, node);
      soDnsFreeNaptrResult(result);
      /* free the NAPTR S result if any */
      if(cb->naptrResult != NULLP)
      {
         soDnsFreeNaptrResult(cb->naptrResult);
         cb->naptrResult = NULLP;
      }
      node = cb->naptrUCp.last;
      if(node != NULLP)
         result = (SoDnsNaptrResult*)node->node;
      else
         result = NULLP;     
   }
   if(result == NULLP)
      RETVALUE(RFAILED);      
   if(soDnsGetHostNameFromNaptrUri(result, 
         &cb->queryAddress, &tptProt, &port, &isIp, &ipType, &isTel) != ROK)
   {
      RETVALUE(RFAILED);
   }
   result->current++;
   if(isTel)
      RETVALUE(soDnsNaptrULookup(cb));
   else
      RETVALUE(soDnsNaptrSLookup(cb));
} /* soDnsDoNaptrRecur */
#endif /* SO_ENUM */   

/*****************************************************************************
*
*       Fun:   soDnsDoSrvRecur
*
*       Desc:  generate recursion on srv
*
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsDoSrvRecur
(
SoDnsQueryCb *cb      
)
#else
PRIVATE S16 soDnsDoSrvRecur(cb)
SoDnsQueryCb *cb;     
#endif
{
   Bool          isTel;
   Bool          isIp;
   TknU16        port;
   U8            tptProt;
   U8            ipType;
   
   TRC2(soDnsDoSrvRecur);

   isTel = FALSE;
   if(cb->naptrResult == NULLP)
   {
#ifdef SO_ENUM
      RETVALUE(soDnsDoNaptrRecur(cb));
#else
      RETVALUE(RFAILED);
#endif /* SO_ENUM || SO_TEL */    
   } 
   else if(cb->naptrResult->current == cb->naptrResult->numComp)
   {
#ifdef SO_ENUM
      RETVALUE(RFAILED);
#else      
      RETVALUE(RFAILED);
#endif /* SO_ENUM */    
   }
   if(cb->srvResult != NULLP)
   {
      soDnsFreeSrvResult(cb->srvResult);
      cb->srvResult = NULLP;
   }
   if(soUtlDelTknStrOSXL(&cb->queryAddress) != ROK)
      RETVALUE(RFAILED);
   if(soDnsGetHostNameFromNaptrUri(cb->naptrResult, 
      &cb->queryAddress, &tptProt, &port, &isIp, &ipType, &isTel) != ROK)
      RETVALUE(RFAILED);
   if(isTel)
      RETVALUE(RFAILED);         
   cb->naptrResult->current++;
   if(soDnsAnalyseNaptrSResult(cb) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(soDnsSrvLookup(cb,cb->tptProt));
} /* soDnsDoSrvRecur */

/*****************************************************************************
*
*       Fun:   soDnsDoARecur
*
*       Desc:  generate recursion on srv
*
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE  S16 soDnsDoARecur
(
SoDnsQueryCb *cb      
)
#else
PRIVATE  S16 soDnsDoARecur(cb)
SoDnsQueryCb *cb;     
#endif
{
   S16           ret;
   SoClDnsAEnt   *result;
   
   TRC2(soDnsDoARecur);

   if(cb->srvResult == NULLP || 
      cb->srvResult->current == cb->srvResult->numComp)
   {
#ifdef SO_ENUM      
      if(soDnsDoSrvRecur(cb)!= ROK)
         RETVALUE(soDnsDoNaptrRecur(cb));
#else
      RETVALUE(soDnsDoSrvRecur(cb));

#endif /* SO_ENUM */      
   }
   else
   {
      soUtlDelTknStrOSXL(&cb->queryAddress);
      if(soUtlCpyTknStrOSXL(&cb->queryAddress, 
         &cb->srvResult->hostNames[cb->srvResult->current++],
         NULLP) != ROK)
      {
         RETVALUE(RFAILED);         
      }
      ret = soClFindDnsAEntry(&soCb.cacheInfoCb.dnsACache, 
             &cb->queryAddress,&result);
      if (ret == ROK)
      {
         RETVALUE(soDnsCacheFoundA(cb,result));
      }
      else
      {
         RETVALUE(soDnsALookup(cb));
      }
   }
   RETVALUE(ROK);
} /* soDnsDoARecur */


/*****************************************************************************
*
*       Fun: soDnsRcvDnsResponse
*
*       Desc: Handles DNS response from server
*
*       Ret:
*
*       Notes: Called from common dns library
*              dnsRsp is a static stack variable in the dns library
*                - it should not be freed
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PUBLIC S16 soDnsRcvDnsResponse
(
Ptr            usrEntry,      /* User context = dns query control block */
CmDnsResponse  *dnsRsp        /* Dns response -> resource records */
)
#else
PUBLIC S16 soDnsRcvDnsResponse(usrEntry, dnsRsp)
Ptr            usrEntry;      /* User context = dns query control block */
CmDnsResponse  *dnsRsp;       /* Dns response -> resource records */
#endif
{
   S16            ret;
   SoDnsQueryCb   *q;            /* ctl blk for this query */
   CmTptAddr      tptAddr;       /* Resolved transport address */
   
   cmMemset((U8 *)&tptAddr, 0, sizeof(CmTptAddr));

   TRC2(soRcvDnsResponse);

   /*-- so032.201: Adding Debug Prints ---------------------------------------*/
   SODBGP_SO (SO_DBGMASK_DNS, (soCb.init.prntBuf, 
      "[DNS] Handle Incoming DNS Response"));
   
   q = (SoDnsQueryCb *)usrEntry;

   if(dnsRsp->header.responseCode == CM_DNS_RESP_CODE_OK)
   {
      soCb.sts.dnsSts.nmbDnsRspSuccess++;
      ret = 
      (soDnsFsmTbl[SO_DNS_RSP_EVENT][q->searchState])((PTR)dnsRsp, &q);

     /*-- so015.201: If response does not match request, drop it --*/
      if (ret == ROKDNA)
         RETVALUE (ROK);
          
      if(ret != ROK)
      {
         switch(q->searchState)
         {
            case SO_DNS_FSM_SRV:
              if(soDnsProcInSrvErrRsp(&q) != ROK)
              {
                 if(soDnsALookup(q) != ROK)
                 {
                    (*q->callback)((PTR)&q->usrCtxt, 
                             SO_DNS_ADDR_TYPE_ERROR,
                       &tptAddr, q->tptProt, NULLP);
                     RETVALUE(ROK);
                 }
              }
              break;
           case SO_DNS_FSM_A:
#ifdef SO_AAAA         
              if(soDnsAAAALookup(q) != ROK)
              {
                 (*q->callback)((PTR)&q->usrCtxt, 
                          SO_DNS_ADDR_TYPE_ERROR,
                          &tptAddr, q->tptProt, NULLP);
                 RETVALUE(ROK);
              }
#else
              if(soDnsDoARecur(q) != ROK)
              {
                 (*q->callback)((PTR)&q->usrCtxt, 
                          SO_DNS_ADDR_TYPE_ERROR,
                    &tptAddr, q->tptProt, NULLP);
                 RETVALUE(ROK);
               }
#endif /* SO_AAAA */    
               break;
#ifdef SO_AAAA          
            case SO_DNS_FSM_AAAA:
               if(soDnsDoARecur(q) != ROK)
               {
                  (*q->callback)((PTR)&q->usrCtxt, 
                                 SO_DNS_ADDR_TYPE_ERROR,
                                 &tptAddr, q->tptProt, NULLP);
                  RETVALUE(ROK);
               }
               break;
#endif /* SO_AAAA */ 
       default:         
               (*q->callback)((PTR)&q->usrCtxt, 
                        SO_DNS_ADDR_TYPE_ERROR,
                        &tptAddr, q->tptProt, NULLP);
               break;
         }
      }

      RETVALUE(ROK);
   }

  /*-------- so015.201: Stop The Response Receive Timer --------*/
   soSchedTmr (q, SO_TMR_DNS_LOOKUP, TMR_STOP, NOTUSED);

   soCb.sts.dnsSts.nmbDnsRspFail++;
   switch(q->searchState)
   {
      case SO_DNS_FSM_INIT:
         (*q->callback)((PTR)&q->usrCtxt, 
               SO_DNS_ADDR_TYPE_ERROR,
              &tptAddr, q->tptProt, NULLP);
         break;
#ifdef SO_ENUM   
      case SO_DNS_FSM_NAPTRU_CACHE:
         (*q->callback)((PTR)&q->usrCtxt, 
               SO_DNS_ADDR_TYPE_ERROR,
              &tptAddr, q->tptProt, NULLP);
         break;
      case SO_DNS_FSM_NAPTRU:
         if(soDnsDoNaptrRecur(q) != ROK)
         {
            (*q->callback)((PTR)&q->usrCtxt, 
                           SO_DNS_ADDR_TYPE_ERROR,
                     &tptAddr, q->tptProt, NULLP);
            RETVALUE(ROK);
         }
         break;
#endif   
      case SO_DNS_FSM_NAPTRS_CACHE:
         (*q->callback)((PTR)&q->usrCtxt, 
               SO_DNS_ADDR_TYPE_ERROR,
              &tptAddr, q->tptProt, NULLP);
         break;
      case SO_DNS_FSM_NAPTRS:
         if(soDnsSrvLookup(q,q->tptProt) != ROK)
            (*q->callback)((PTR)&q->usrCtxt, 
                           SO_DNS_ADDR_TYPE_ERROR,
                           &tptAddr, q->tptProt, NULLP);
         break;
#ifdef SO_INSTMSG   
      case SO_DNS_FSM_IM_CACHE:
         (*q->callback)((PTR)&q->usrCtxt, 
               SO_DNS_ADDR_TYPE_ERROR,
              &tptAddr, q->tptProt, NULLP);
         break;
      case SO_DNS_FSM_IM:
         if(soDnsALookup(q) != ROK)
    {
            (*q->callback)((PTR)&q->usrCtxt, 
                  SO_DNS_ADDR_TYPE_ERROR,
                 &tptAddr, q->tptProt, NULLP);
            RETVALUE(ROK);
    }
         break;
#endif
#ifdef SO_PRESENCE   
      case SO_DNS_FSM_PRES_CACHE:
         (*q->callback)((PTR)&q->usrCtxt, 
               SO_DNS_ADDR_TYPE_ERROR,
              &tptAddr, q->tptProt, NULLP);
         break;
      case SO_DNS_FSM_PRES: 
         if(soDnsALookup(q) != ROK)
    {
            (*q->callback)((PTR)&q->usrCtxt, 
                  SO_DNS_ADDR_TYPE_ERROR,
                 &tptAddr, q->tptProt, NULLP);
            RETVALUE(ROK);
    }
         break;
#endif   
      case SO_DNS_FSM_SRV_CACHE:
      case SO_DNS_FSM_SRV_WAIT:
         (*q->callback)((PTR)&q->usrCtxt, 
               SO_DNS_ADDR_TYPE_ERROR,
              &tptAddr, q->tptProt, NULLP);
         break;
      case SO_DNS_FSM_SRV:
         if(soDnsProcInSrvErrRsp(&q) != ROK)
         {
            if(soDnsALookup(q) != ROK)
            {
               (*q->callback)((PTR)&q->usrCtxt, 
                       SO_DNS_ADDR_TYPE_ERROR,
                       &tptAddr, q->tptProt, NULLP);
               RETVALUE(ROK);
           }
         }
         break;
      case SO_DNS_FSM_A_CACHE:
         (*q->callback)((PTR)&q->usrCtxt, 
               SO_DNS_ADDR_TYPE_ERROR,
               &tptAddr, q->tptProt, NULLP);
         break;
      case SO_DNS_FSM_A:
#ifdef SO_AAAA         
         if(soDnsAAAALookup(q) != ROK)
         {
            (*q->callback)((PTR)&q->usrCtxt, 
                  SO_DNS_ADDR_TYPE_ERROR,
                  &tptAddr, q->tptProt, NULLP);
            RETVALUE(ROK);
         }
#else
         if(soDnsDoARecur(q) != ROK)
         {
            (*q->callback)((PTR)&q->usrCtxt, 
                    SO_DNS_ADDR_TYPE_ERROR,
                 &tptAddr, q->tptProt, NULLP);
            RETVALUE(ROK);
         }
#endif /* SO_AAAA */    
         break;
#ifdef SO_AAAA   
      case SO_DNS_FSM_AAAA_CACHE:
         (*q->callback)((PTR)&q->usrCtxt, 
               SO_DNS_ADDR_TYPE_ERROR,
              &tptAddr, q->tptProt, NULLP);
         break;
      case SO_DNS_FSM_AAAA:
         if(soDnsDoARecur(q) != ROK)
         {
            (*q->callback)((PTR)&q->usrCtxt, 
                      SO_DNS_ADDR_TYPE_ERROR,
                      &tptAddr, q->tptProt, NULLP);
            RETVALUE(ROK);
         }
         break;
#endif   
      case SO_DNS_FSM_INV:
      default:         
         (*q->callback)((PTR)&q->usrCtxt, 
               SO_DNS_ADDR_TYPE_ERROR,
              &tptAddr, q->tptProt, NULLP);
         break;
   }
   RETVALUE(ROK);
} /* soDnsRcvDnsResponse */


/**********************************************************
*
*       Fun:   soDnsCfg
*
*       Desc:  Perform DNS configuration
*
*       Ret:   ROK / RFAILED
*
*       Notes:
*
*       File:  so_dns.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soDnsCfg
(
SoDnsReCfg *cfg,       /* Configuration information */
U16        *reason     /* Return reason */
)
#else
PUBLIC S16 soDnsCfg(cfg, reason)
SoDnsReCfg *cfg;       /* Configuration information */
U16        *reason;    /* Return reason */
#endif
{
   CmDnsDbgInfo   dbgInfo;    /* DNS debug information */
   Mem            sMem;       /* Memory ID */
   EntityId       entId;      /* Entity ID */

   TRC2(soDnsCfg);

   /* DNS configuration */
   if ((cfg->tSapId < 0) || (cfg->tSapId >= soCb.cfg.maxNmbTSaps))
   {
      *reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if (cfg->tptSrvId >= soCb.maxTptSrv)
   {
      *reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   /* Create dns configuration block */
   if (soCb.dnsCb != NULLP)
   {
      soDnsDeInit();
   }
   SOALLOC(&soCb.dnsCb,sizeof(CmDnsCb));
   if (soCb.dnsCb == NULLP)
   {
      *reason = LCM_REASON_MEM_NOAVAIL;
      RETVALUE(RFAILED);
   }
   /* Debugging not used in dns */
#ifdef DEBUGP
   dbgInfo.dbgMask   = soCb.init.dbgMask;
   dbgInfo.prntBuf   = soCb.init.prntBuf;
#endif /* DEBUGP */
   dbgInfo.layerName = NULLP;
   /* Entity ID set from hgInit */
   entId.inst    = soCb.init.inst;
   entId.ent     = soCb.init.ent;
   sMem.region   = soCb.init.region;
   sMem.pool     = soCb.init.pool;
   cmDnsInitDnsCb(soCb.dnsCb,&dbgInfo,
                  &cfg->dnsTptAddr,
                  soDnsSendRslvReqToDnsServer,
                  soDnsRcvDnsResponse,&sMem,
                  soCb.init.ent,&entId,
                  SO_DNS_REQUESTIDLSTSZ);

   /* Copy configuration data */
   cmMemcpy((U8*)&soCb.reCfg.dnsReCfg, (U8*)cfg,sizeof(SoDnsReCfg));

   /* expect the dnsSrvCb is NULLP. If not, 
    * free the previous one */
   if(soCb.dnsSrvCb != NULLP)
   {
      SOFREE(soCb.dnsSrvCb, sizeof(SoTptServerCb));
      soCb.allSrvCbLst[soCb.dnsSrvCb->suConnId] = NULLP;
   }
   /* Create new transport server */
   SOALLOC(&soCb.dnsSrvCb, sizeof(SoTptServerCb));
   if (soCb.dnsSrvCb == NULLP)
   {
      SOFREE(soCb.dnsCb, sizeof(CmDnsCb));
      soCb.dnsCb = NULLP;
      *reason    = LCM_REASON_MEM_NOAVAIL;
      RETVALUE(RFAILED);
   }

   soCb.dnsSrvCb->entCb          = NULLP;
   soCb.dnsSrvCb->hostName.pres  = NOTPRSNT;
   soCb.dnsSrvCb->nmbSSap        = 0;
   soCb.dnsSrvCb->tsapCb         = soCb.soTSapCbLst[cfg->tSapId];
   soCb.dnsSrvCb->tptProt        = LSO_TPTPROT_UDP;
   soCb.dnsSrvCb->tPar           = cfg->dnsTptParam;
   soCb.dnsSrvCb->suConnId       = cfg->tptSrvId;

   cmMemcpy((U8 *)&soCb.dnsSrvCb->localAddr, 
       (U8 *)&cfg->locAddr, sizeof(CmTptAddr));

   soCb.dnsSrvCb->state         = LSO_TPTSRV_DIS;
   soCb.dnsSrvCb->spConnId      = SO_INV_HIT_CONNID;

   cmLListInit(&soCb.dnsSrvCb->tcmConnLst);
   /* initialize the allSrvCbLst with the new tptSrvCb */
   soCb.allSrvCbLst[soCb.dnsSrvCb->suConnId] = soCb.dnsSrvCb;

   *reason = LCM_REASON_NOT_APPL;
   RETVALUE(ROK);
} /* soDnsCfg */



/**********************************************************
*
*       Fun:   soDnsDeInit
*
*       Desc:  Deinitialize dns
*
*       Ret:   ROK
*
*       Notes:
*
*       File:  so_dns.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soDnsDeInit
(
Void
)
#else
PUBLIC S16 soDnsDeInit()
#endif
{
   U32     dnsSrvId;      /* SuId for dns transport server */
   TRC3(soDnsDeInit);

   /* Deinitialize library */
   cmDnsDeInitDnsCb(soCb.dnsCb);

   /* Remove dns transport server */
   if (soCb.dnsSrvCb != NULLP)
   {
      dnsSrvId = soCb.dnsSrvCb->suConnId;
      /* close teh UDP server */
      soTptCloseServer(soCb.dnsSrvCb);
      /* free the memory here */
      SOFREE(soCb.dnsSrvCb, sizeof(SoTptServerCb));
      /* set the ptr to NULL */
      soCb.allSrvCbLst[dnsSrvId] = NULLP;
      soCb.dnsSrvCb = NULLP;
   }

   /* Free memory for dns Cb */
   SOFREE(soCb.dnsCb,sizeof(CmDnsCb));

   soCb.dnsCb = NULLP;

   RETVALUE(ROK);

} /* soDnsDeInit */


/*****************************************************************************
*
*       Fun: soDnsFindPhysicalAddr
*
*       Desc: Find an address from an dnsRsp->addition response for srv record
*
*       Ret: ROK
*            RFAILED
*
*       Notes:
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsFindPhysicalAddr
(
CmDns2782RR    *srvAnswer,    /* Dns SRV response */
CmDnsResponse  *dnsRsp,       /* Dns response -> resource records */
Bool           *haveAddr,     /* Is ph addr available */
CmNetAddr      *physicalAddr, /* physical address */
U32            *ttl           /* time to live for record */
)
#else
PRIVATE S16 soDnsFindPhysicalAddr(srvAnswer,dnsRsp,
                                  haveAddr,physicalAddr,ttl)
CmDns2782RR    *srvAnswer;    /* Dns SRV response */
CmDnsResponse  *dnsRsp;       /* Dns response -> resource records */
Bool           *haveAddr;     /* Is ph addr available */
CmNetAddr      *physicalAddr; /* physical address */
U32            *ttl;          /* time to live for record */
#endif
{
   TRC2(soDnsFindPhysicalAddr);

   *haveAddr = FALSE;
   *ttl      = srvAnswer->ttl;
   UNUSED(physicalAddr);
   
   RETVALUE(RFAILED);
} /* soDnsFindPhysicalAddr */

/*****************************************************************************
*
*       Fun:   soDnsProcInSrvErrRsp
*
*       Desc:  Proc DNS IN SRV rsp
*
*       Ret:   ROK on success
*
*
*       File:  so_dns.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soDnsProcInSrvErrRsp
(
SoDnsQueryCb     **q
)
#else
PRIVATE S16 soDnsProcInSrvErrRsp(q)
SoDnsQueryCb     **q;
#endif
{
   SoClDnsSrvEnt  *cacheEnt;        /* Caching entity */
   SoDnsQueryCb   *dnsQuery;
   SoDnsQueryCb   *master;
   S16            ret;
   SoDnsQueryCb   *query;
   U8             pCount;
   U8             numCb;
   
   TRC2(soRcvSrvResponse);

   pCount = 0;
   numCb = 1;
   query = *q;
   dnsQuery = query;
   dnsQuery->searchState = SO_DNS_FSM_SRV_WAIT;
   if(!dnsQuery->master)
   {
      master = dnsQuery->masterQueryCb;
   }
   else
   {
      master = dnsQuery;
   }
   if(master->searchState == SO_DNS_FSM_SRV_WAIT)
      pCount++;
   if(master->tcpQueryCb != NULLP)
   {
      numCb++; 
      if(master->tcpQueryCb->searchState == SO_DNS_FSM_SRV_WAIT)
         pCount++;
   }
#ifdef SO_TLS   
   if(master->tlsTcpQueryCb != NULLP)
   {
      numCb++; 
      if(master->tlsTcpQueryCb->searchState == SO_DNS_FSM_SRV_WAIT)
         pCount++;
   }
#endif /* SO_TLS */
#ifdef SO_SCTP   
   if(master->sctpQueryCb != NULLP)
   {
      numCb++;      
      if(master->sctpQueryCb->searchState == SO_DNS_FSM_SRV_WAIT)
         pCount++;
   }
#endif /* SO_SCTP */
   
   if(pCount != numCb)
   {
      RETVALUE(ROK);
   }
   
   *q = master;
   
#ifdef SO_SCTP    
   if(master->sctpQueryCb != NULLP)
   {
      soDnsFreeQueryCb(master->sctpQueryCb);
      master->sctpQueryCb = NULLP;
   }
#endif
   
#ifdef SO_TLS    
   if(master->tlsTcpQueryCb != NULLP)
   {
      soDnsFreeQueryCb(master->tlsTcpQueryCb);
      master->tlsTcpQueryCb = NULLP;
   }
#endif
   
   if(master->tcpQueryCb != NULLP)
   {
      soDnsFreeQueryCb(master->tcpQueryCb);
      master->tcpQueryCb = NULLP;
   }
   
   ret = soClFindDnsSrvEntry(&soCb.cacheInfoCb.dnsSrvCache, 
         &master->queryAddress, &cacheEnt);
   
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   
   RETVALUE(soDnsCacheFoundSrv(master,cacheEnt));
} /* soDnsProcInSrvErrRsp */

#endif /* SO_DNS */

/********************************************************************30**

         End of file:     so_dns.c@@/main/4 - Tue Apr 20 12:46:24 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/4      ---         mz    1. initial release.
              so002.201  ps    1. Check URL parameter only for host part
                                  as domain name.
              so003.201  ps    1. Changes for DNS for maddr support 
              so009.201  ps    1. Validate DNS Response Message Type.
              so015.201  ps    1. Do not stop response timer for incorrect
                                  response messages.
              so016.201  ps    1. Stop Response timer after validating 
                                  response message.
              so021.201  ad    1. Removing warning 
              so022.201  ss    1. Removed warnings
              so022.201  ss    1. Removed compilation error with TRACE2
              so026.201  ab    1. Select srv response with lowest priority
                                  and highest weight
              so027.201  ab    1. Changes for SIP TLS support
                               2. Reinitializing DNS A result
              so030.201  ss    1. Correction is checkin order while sorting
                                  DNS NAPTR results.
              so032.201  ng    1. Do not use cache lookup, if useDnsCache
                                  flag is disabled.
                               2. Added debug prints in lookup & response
                                  functions.
                               3. Changing & to % to get better probability
                                  results while sorting SRV results(ab)
              so033.201  ng    1. removed code for FAX & modem since it not supported  
              so034.201  ng    1. Pass isNaptrU instead of True (ad)
              so035.201  ng    1. Changed default port to 5061 for TLS transport(ab)

              so041.201  ng    1. Corrected  ipv4TptAddr from ipv6TptAddr
                               2. If port is not preasent update default port 
                                  for TLS in soDnsCreateQueryCb
/ *********************************************************************91*/
