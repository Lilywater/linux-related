/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SIP Portable Lower Interface

     Type:     C source file

     Desc:     C source code for SO layer portable Lower Interface

     File:     so_ptli.c

     Sid:      so_ptli.c@@/main/4 - Tue Apr 20 12:46:53 2004

     Prg:      wvdl

*********************************************************************21*/

/*
The following functions are provided in this file:
   HitBndReq                - Bind Request
   HitUbndReq               - Unbind Request
   HitServOpenReq           - Server Open Request
   HitConReq                - Connection Request
   HitConRsp                - Connection Response
   HitDatReq                - Data Request
   HitUDatReq               - Unit Data Request
   HitDiscReq               - Disconnect Request

It should be noted that not all of these functions may be required
by a particular network layer service provider.

*/

/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "cst.h"           /* Compression module defines      */
#include "so.h"            /* SIP layer defines               */
#include "so_trans.h"      /* Transaction module defines      */
#include "so_err.h"        /* SIP error defines               */
#include "so_cm.h"         /* SIP layer utility functions     */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lso.x"           /* Layer management SIP            */
#include "sot.x"           /* SOT interface structures        */
#include "cst.x"           /* Compression module structures   */
#include "so_tcm.x"        /* Transport module structures     */
#include "so.x"            /* SIP layer structures            */
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* SIP layer utility functions     */
#include "so_cm.x"         /* SIP layer common functions      */
#include "so_dns.x"        /* SIP DNS library                 */

#ifdef SO_ACC
#include "dhit.x"          /* dummy HIT interface */
#endif

/* local defines */
/* the acceptance test uses an additional dummy TUCL layer */
#ifdef SO_ACC
#define SO_MAX_LIHIT_SEL         3       /* maximum no. selectors */
#else
#define SO_MAX_LIHIT_SEL         2       /* maximum no. selectors */
#endif /* SO_ACC */

#ifndef LCSOLIHIT
#define PTSOLIHIT
#else
#ifndef HI
#define PTSOLIHIT
#else
#endif
#endif

/* forward references */
#ifdef PTSOLIHIT
PRIVATE S16 PtLiHitBndReq      ARGS((Pst          *pst,
                                     SuId         suId,
                                     SpId         spId));
PUBLIC S16 PtLiHitUbndReq      ARGS((Pst          *pst,
                                     SpId         spId,
                                     Reason       reason));
PRIVATE S16 PtLiHitServOpenReq ARGS((Pst          *pst,          
                                     SpId         spId,          
                                     UConnId      servConId,     
                                     CmTptAddr    *servTAddr,    
                                     CmTptParam   *tPar,         
                                     CmIcmpFilter *icmpFilter,   
                                     U8           srvcType));
PUBLIC S16 PtLiHitConReq       ARGS((Pst          *pst,      
                                     SpId         spId,      
                                     UConnId      suConId,   
                                     CmTptAddr    *remAddr,  
                                     CmTptAddr    *localAddr,
                                     CmTptParam   *tPar,     
                                     U8           srvcType));
PUBLIC S16 PtLiHitConRsp       ARGS((Pst          *pst,
                                     SpId         spId,
                                     UConnId      suConId,
                                     UConnId      spConId));
PUBLIC S16 PtLiHitDatReq       ARGS((Pst          *pst,
                                     SpId         spId,
                                     UConnId      spConId, 
                                     Buffer       *mBuf));

#ifdef HI_REL_1_4 
PUBLIC S16 PtLiHitUDatReq      ARGS((Pst          *pst,
                                     SpId         spId,
                                     UConnId      spConId,
                                     CmTptAddr    *remAddr,
                                     CmTptAddr    *srcAddr,
                                     CmIpHdrParm  *hdrParm,
                                     CmTptParam   *tPar,
                                     Buffer       *mBuf));
#else
PUBLIC S16 PtLiHitUDatReq      ARGS((Pst          *pst,
                                     SpId         spId,
                                     UConnId      spConId,
                                     CmTptAddr    *remAddr,
                                     CmTptAddr    *srcAddr,
                                     CmIpHdrParm  *hdrParm,
                                     Buffer       *mBuf));
#endif /* HI_REL_1_4 */
PUBLIC S16 PtLiHitDiscReq      ARGS((Pst          *pst,
                                     SpId         spId,
                                     U8           choice,
                                     UConnId      conId,
                                     Action       action,
                                     CmTptParam   *tPar));

#endif /* PTSOLIHIT */

/* Primitive Mapping Tables */
#ifndef SO_ACC

PRIVATE HitBndReq SoLiHitBndReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitBndReq,          /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitBndReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitBndReq,          /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitBndReq,          /* 1 - tightly coupled, portable */
#endif
};

PRIVATE HitUbndReq SoLiHitUbndReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitUbndReq,         /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitUbndReq,         /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitUbndReq,         /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitUbndReq,         /* 1 - tightly coupled, portable */
#endif
};

PRIVATE HitServOpenReq SoLiHitServOpenReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitServOpenReq,     /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitServOpenReq,     /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitServOpenReq,     /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitServOpenReq,     /* 1 - tightly coupled, portable */
#endif
};

PRIVATE HitConReq SoLiHitConReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitConReq,          /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitConReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitConReq,          /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitConReq,          /* 1 - tightly coupled, portable */
#endif
};

PRIVATE HitConRsp SoLiHitConRspMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitConRsp,          /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitConRsp,          /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitConRsp,          /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitConRsp,          /* 1 - tightly coupled, portable */
#endif
};

PRIVATE HitDatReq SoLiHitDatReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitDatReq,          /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitDatReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitDatReq,          /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitDatReq,          /* 1 - tightly coupled, portable */
#endif
};

PRIVATE HitUDatReq SoLiHitUDatReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitUDatReq,         /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitUDatReq,         /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitUDatReq,         /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitUDatReq,         /* 1 - tightly coupled, portable */
#endif
};

PRIVATE HitDiscReq SoLiHitDiscReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitDiscReq,         /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitDiscReq,         /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitDiscReq,         /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitDiscReq,         /* 1 - tightly coupled, portable */
#endif
};

#else /* SO_ACC */
/* the SIP acceptance test utilizes an additional dummy TUCL */

PRIVATE HitBndReq SoLiHitBndReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitBndReq,          /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitBndReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitBndReq,          /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitBndReq,          /* 1 - tightly coupled, portable */
#endif
#ifdef HI
   DHiUiHitBndReq,         /* 2 - tightly coupled, dummy Service Provider HI */
#else
   PtLiHitBndReq           /* 2 - tightly coupled, portable */
#endif
};

PRIVATE HitUbndReq SoLiHitUbndReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitUbndReq,         /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitUbndReq,         /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitUbndReq,         /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitUbndReq,         /* 1 - tightly coupled, portable */
#endif
#ifdef HI
   DHiUiHitUbndReq,        /* 2 - tightly coupled, dummy Service Provider HI */
#else
   PtLiHitUbndReq          /* 2 - tightly coupled, portable */
#endif
};

PRIVATE HitServOpenReq SoLiHitServOpenReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitServOpenReq,     /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitServOpenReq,     /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitServOpenReq,     /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitServOpenReq,     /* 1 - tightly coupled, portable */
#endif
#ifdef HI
   DHiUiHitServOpenReq,    /* 2 - tightly coupled, dummy Service Provider HI */
#else
   PtLiHitServOpenReq      /* 2 - tightly coupled, portable */
#endif
};

PRIVATE HitConReq SoLiHitConReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitConReq,          /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitConReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitConReq,          /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitConReq,          /* 1 - tightly coupled, portable */
#endif
#ifdef HI
   DHiUiHitConReq,         /* 2 - tightly coupled, dummy Service Provider HI */
#else
   PtLiHitConReq           /* 2 - tightly coupled, portable */
#endif
};

PRIVATE HitConRsp SoLiHitConRspMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitConRsp,          /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitConRsp,          /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitConRsp,          /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitConRsp,          /* 1 - tightly coupled, portable */
#endif
#ifdef HI
   DHiUiHitConRsp,         /* 2 - tightly coupled, dummy Service Provider HI */
#else
   PtLiHitConRsp           /* 2 - tightly coupled, portable */
#endif
};

PRIVATE HitDatReq SoLiHitDatReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitDatReq,          /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitDatReq,          /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitDatReq,          /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitDatReq,          /* 1 - tightly coupled, portable */
#endif
#ifdef HI
   DHiUiHitDatReq,         /* 2 - tightly coupled, dummy Service Provider HI */
#else
   PtLiHitDatReq           /* 2 - tightly coupled, portable */
#endif
};

PRIVATE HitUDatReq SoLiHitUDatReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitUDatReq,         /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitUDatReq,         /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitUDatReq,         /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitUDatReq,         /* 1 - tightly coupled, portable */
#endif
#ifdef HI
   DHiUiHitUDatReq,        /* 2 - tightly coupled, dummy Service Provider HI */
#else
   PtLiHitUDatReq          /* 2 - tightly coupled, portable */
#endif
};

PRIVATE HitDiscReq SoLiHitDiscReqMt[SO_MAX_LIHIT_SEL] =
{
#ifdef LCSOLIHIT
   cmPkHitDiscReq,         /* 0 - loosely coupled (default mechanism) */
#else
   PtLiHitDiscReq,         /* 0 - tightly coupled, portable */
#endif
#ifdef HI
   HiUiHitDiscReq,         /* 1 - tightly coupled, Service Provider HI */
#else
   PtLiHitDiscReq,         /* 1 - tightly coupled, portable */
#endif
#ifdef HI
   DHiUiHitDiscReq,        /* 2 - tightly coupled, dummy Service Provider HI */
#else
   PtLiHitDiscReq          /* 2 - tightly coupled, portable */
#endif
};

#endif /* SO_ACC */

/* Primitive Mapping Dispatching Functions */

/*
*
*       Fun:   Bind Request
*
*       Desc:  This function is used to bind a transport SAP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitBndReq
(
Pst  *pst,                /* post structure */
SuId suId,                /* service user SAP ID */
SpId spId                 /* service provider SAP ID */
)
#else
PUBLIC S16 SoLiHitBndReq(pst, suId, spId)
Pst  *pst;                /* post structure */
SuId suId;                /* service user SAP ID */
SpId spId;                /* service provider SAP ID */
#endif
{
   TRC3(SoLiHitBndReq)

   SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf , 
           "SoLiHitBndReq(pst, suId(%d), spId(%d)\n", suId, spId));

   (*SoLiHitBndReqMt[pst->selector])(pst, suId, spId);

   RETVALUE(ROK);
} /* SoLiHitBndReq */

/*
*
*       Fun:   Unbind Request
*
*       Desc:  This function is used to unbind a transport SAP
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitUbndReq
(
Pst    *pst,              /* post structure */
SpId   spId,              /* service provider SAP ID */
Reason reason             /* reason */
)
#else
PUBLIC S16 SoLiHitUbndReq(pst, spId, reason)
Pst    *pst;              /* post structure */
SpId   spId;              /* service provider SAP ID */
Reason reason;            /* reason */
#endif
{
   TRC3(SoLiHitUbndReq)

   SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf , 
           "SoLiHitUbndReq(pst, spId(%d), reason(%d)\n", spId, reason));

   (*SoLiHitUbndReqMt[pst->selector])(pst, spId, reason);

   RETVALUE(ROK);
} /* SoLiHitUbndReq */

/*
*
*       Fun:   Server Open Request
*
*       Desc:  This function is used to open a TCP or UDP server
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitServOpenReq
(
Pst          *pst,          /* post stucture */
SpId         spId,          /* service provider Id */
UConnId      servConId,     /* service user�s connection Id */
CmTptAddr    *servTAddr,    /* transport address of the server */
CmTptParam   *tPar,         /* transport parameters */
CmIcmpFilter *icmpFilter,   /* Filter parameters */
U8           srvcType       /* service type */
)
#else
PUBLIC S16 SoLiHitServOpenReq(pst, spId, servConId, servTAddr, tPar, 
                              icmpFilter, srvcType) 
Pst          *pst;          /* post stucture */
SpId         spId;          /* service provider Id */
UConnId      servConId;     /* service user�s connection Id */
CmTptAddr    *servTAddr;    /* transport address of the server */
CmTptParam   *tPar;         /* transport parameters */
CmIcmpFilter *icmpFilter;   /* Filter parameters */
U8           srvcType;      /* service type */
#endif
{
   TRC3(SoLiHitServOpenReq)

#ifdef DEBUGP
   {
      U16   port;
      Txt   addr[2 * CM_IPV6ADDR_SIZE + 1];

      soCmGetPortAndAscAddr (servTAddr, &port, addr);

      SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf , 
           "SoLiHitServOpenReq(pst, spId(%d), servConId(%ld), "
           "servTAddr.type(%d), servTAddr.port(%d), servTAddr.address(%s),"
           " tpar, srvcType (%d))\n",
           spId, servConId, servTAddr->type, port, addr, srvcType));
   }
#endif /* DEBUGP */

   (*SoLiHitServOpenReqMt[pst->selector])(pst, spId, servConId, servTAddr, 
                                          tPar, icmpFilter, srvcType);

   RETVALUE(ROK);
} /* SoLiHitServOpenReq */

/*
*
*       Fun:   Connection Request
*
*       Desc:  This function is used to connect a TCP client
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitConReq
(
Pst        *pst,          /* post stucture */
SpId       spId,          /* service provider Id */
UConnId    suConId,       /* service user�s connection Id */
CmTptAddr  *remAddr,      /* transport address of the server */
CmTptAddr  *localAddr,    /* local transport address */
CmTptParam *tPar,         /* transport parameters */
U8         srvcType       /* service type */
)
#else
PUBLIC S16 SoLiHitConReq(pst, spId, suConId, remAddr, localAddr, tPar, 
                         srvcType)
Pst        *pst;          /* post stucture */
SpId       spId;          /* service provider Id */
UConnId    suConId;       /* service user�s connection Id */
CmTptAddr  *remAddr;      /* transport address of the server */
CmTptAddr  *localAddr;    /* local transport address */
CmTptParam *tPar;         /* transport parameters */
U8         srvcType;      /* service type */
#endif
{
   TRC3(SoLiHitConReq)

#ifdef DEBUGP
   {
      U16   port1;
      U16   port2;
      Txt   addr1[2 * CM_IPV6ADDR_SIZE + 1];
      Txt   addr2[2 * CM_IPV6ADDR_SIZE + 1];

      soCmGetPortAndAscAddr (remAddr, &port1, addr1);
      soCmGetPortAndAscAddr (localAddr, &port2, addr2);

      SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf ,  
           "SoLiHitConReq(pst, spId(%d), suConId(%ld), "
           "remAddr.type(%d), remAddr.port(%d), remAddr.address(%s),"
           "localAddr.type(%d), localAddr.port(%d), localAddr.address(%s),"
           " tpar, srvcType (%d))\n",
           spId, suConId, remAddr->type, port1, addr1, localAddr->type, 
           port2, addr2, srvcType));
   }
#endif /* DEBUGP */

   (*SoLiHitConReqMt[pst->selector])(pst, spId, suConId, remAddr, localAddr, 
                                     tPar, srvcType);

   RETVALUE(ROK);
} /* SoLiHitConReq */

/*
*
*       Fun:   Connection Response
*
*       Desc:  This function is used to respond to a TCP client connection 
*              request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitConRsp
(
Pst        *pst,          /* post stucture */
SpId       spId,          /* service provider Id */
UConnId    suConId,       /* service user�s connection Id */
UConnId    spConId        /* service provider's connection Id */
)
#else
PUBLIC S16 SoLiHitConRsp(pst, spId, suConId, spConId)
Pst        *pst;          /* post stucture */
SpId       spId;          /* service provider Id */
UConnId    suConId;       /* service user�s connection Id */
UConnId    spConId;       /* service provider's connection Id */
#endif
{
   TRC3(SoLiHitConRsp)

   SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf , 
        "SoLiHitConRsp(pst, spId(%d), suConId(%ld), spConId(%ld)\n",
        spId, suConId, spConId));

   (*SoLiHitConRspMt[pst->selector])(pst, spId, suConId, spConId);

   RETVALUE(ROK);
} /* SoLiHitConRsp */

/*
*
*       Fun:   Data Request
*
*       Desc:  This function is used to send data to a TCP client
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitDatReq
(
Pst        *pst,          /* post stucture */
SpId       spId,          /* service provider Id */
UConnId    spConId,       /* service provider�s connection Id */
Buffer     *mBuf          /* message buffer */
)
#else
PUBLIC S16 SoLiHitDatReq(pst, spId, spConId, mBuf)
Pst        *pst;          /* post stucture */
SpId       spId;          /* service provider Id */
UConnId    spConId;       /* service provider�s connection Id */
Buffer     *mBuf;         /* message buffer */
#endif
{
   TRC3(SoLiHitDatReq)

   SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf , 
        "SoLiHitDatReq(pst, spId(%d), spConId(%ld), mBuf(%p)\n",
        spId, spConId, (Void *)mBuf));

#ifdef DEBUGP
   if (soCb.init.dbgMask & SO_DBGMASK_LI_MBUF)
   {
      SPrntMsg (mBuf, 0, 0);
   }
#endif /* DEBUGP */

   (*SoLiHitDatReqMt[pst->selector])(pst, spId, spConId, mBuf);

   RETVALUE(ROK);
} /* SoLiHitDatReq */

/*
*
*       Fun:   Unit Data Request
*
*       Desc:  This function is used to send data to an UDP client
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitUDatReq
(
Pst         *pst,          /* post stucture */
SpId        spId,          /* service provider Id */
UConnId     spConId,       /* service provider�s connection Id */
CmTptAddr   *remAddr,      /* remote address */
CmTptAddr   *srcAddr,      /* source address */
CmIpHdrParm *hdrParm,      /* header parameters */
#ifdef HI_REL_1_4
CmTptParam  *tPar,
#endif /* HI_REL_1_4 */
Buffer      *mBuf          /* message buffer */
)
#else /* ANSI */
#ifdef HI_REL_1_4
PUBLIC S16 SoLiHitUDatReq(pst, spId, spConId, remAddr, srcAddr, hdrParm, tPar,
                          mBuf)
Pst         *pst;          /* post stucture */
SpId        spId;          /* service provider Id */
UConnId     spConId;       /* service provider�s connection Id */
CmTptAddr   *remAddr;      /* remote address */
CmTptAddr   *srcAddr;      /* source address */
CmIpHdrParm *hdrParm;      /* header parameters */
CmTptParam  *tPar;
Buffer      *mBuf;         /* message buffer */
#else /* HI_REL_1_4 */
PUBLIC S16 SoLiHitUDatReq(pst, spId, spConId, remAddr, srcAddr, hdrParm, mBuf)
Pst         *pst;          /* post stucture */
SpId        spId;          /* service provider Id */
UConnId     spConId;       /* service provider�s connection Id */
CmTptAddr   *remAddr;      /* remote address */
CmTptAddr   *srcAddr;      /* source address */
CmIpHdrParm *hdrParm;      /* header parameters */
Buffer      *mBuf;         /* message buffer */
#endif /* HI_REL_1_4 */
#endif /* ANSI */
{
   TRC3(SoLiHitUDatReq)

#ifdef DEBUGP
   {
      U16   port;
      Txt   addr[2 * CM_IPV6ADDR_SIZE + 1];

      soCmGetPortAndAscAddr (remAddr, &port, addr);

      SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,
           "SoLiHitUDatReq(pst, spId(%d), spConId(%ld),"
            "remAddr.port(%d), remAddr.address(%s), mBuf(%p))\n",
            spId, spConId, port, addr, (Void *)mBuf));

      if (soCb.init.dbgMask & SO_DBGMASK_LI_MBUF)
      {
         SPrntMsg (mBuf, 0, 0);
      }
   }
#endif /* DEBUGP */

#ifdef HI_REL_1_4
   (*SoLiHitUDatReqMt[pst->selector])(pst, spId, spConId, remAddr, srcAddr, 
                                      hdrParm, tPar, mBuf);
#else
   (*SoLiHitUDatReqMt[pst->selector])(pst, spId, spConId, remAddr, srcAddr, 
                                      hdrParm, mBuf);
#endif /* HI_REL_1_4 */

   RETVALUE(ROK);
} /* SoLiHitUDatReq */

/*
*
*       Fun:   Disconnect Request
*
*       Desc:  This function is used to disconnect a server
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiHitDiscReq
(
Pst         *pst,          /* post stucture */
SpId        spId,          /* service provider Id */
U8          choice,        /* choice parameter */
UConnId     conId,         /* connection Id */
Action      action,        /* action type */
CmTptParam  *tPar          /* transport parameter */
)
#else
PUBLIC S16 SoLiHitDiscReq(pst, spId, choice, conId, action, tPar)
Pst         *pst;          /* post stucture */
SpId        spId;          /* service provider Id */
U8          choice;        /* choice parameter */
UConnId     conId;         /* connection Id */
Action      action;        /* action type */
CmTptParam  *tPar;         /* transport parameter */
#endif
{
   TRC3(SoLiHitDiscReq)

   SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf , 
           "SoLiHitDiscReq(pst, spId(%d), choice(%d), conId(%ld), action(%d),"
           "tPar\n", spId, choice, conId, action));

   (*SoLiHitDiscReqMt[pst->selector])(pst, spId, choice, conId, action, tPar);

   RETVALUE(ROK);
} /* SoLiHitDiscReq */

#ifdef PTSOLIHIT
/* Portable Stub Functions */

/*
*
*       Fun:   Portable Bind Request
*
*       Desc:  Portable version of HitBndReq primitive
*
*       Ret:   RFAILED
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PRIVATE S16 PtLiHitBndReq
(
Pst  *pst,                /* post structure */
SuId suId,                /* service user SAP ID */
SpId spId                 /* service provider SAP ID */
)
#else
PRIVATE S16 PtLiHitBndReq(pst, suId, spId)
Pst  *pst;                /* post structure */
SuId suId;                /* service user SAP ID */
SpId spId;                /* service provider SAP ID */
#endif
{
   TRC3(PtLiHitBndReq);

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(spId);

   RETVALUE(RFAILED);
} /* PtLiHitBndReq*/

/*
*
*       Fun:   Portable Unbind Request
*
*       Desc:  Portable version of HitUbndReq primitive
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 PtLiHitUbndReq
(
Pst    *pst,              /* post structure */
SpId   spId,              /* service provider SAP ID */
Reason reason             /* reason */
)
#else
PUBLIC S16 PtLiHitUbndReq(pst, spId, reason)
Pst    *pst;              /* post structure */
SpId   spId;              /* service provider SAP ID */
Reason reason;            /* reason */
#endif
{
   TRC3(PtLiHitUbndReq)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(reason);

   RETVALUE(RFAILED);
} /* PtLiHitUbndReq */

/*
*
*       Fun:   Portable Server OpenBind Request
*
*       Desc:  Portable version of HitServOpenReq primitive
*
*       Ret:   RFAILED
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PRIVATE S16 PtLiHitServOpenReq
(
Pst          *pst,          /* post stucture */
SpId         spId,          /* service provider Id */
UConnId      servConId,     /* service user�s connection Id */
CmTptAddr    *servTAddr,    /* transport address of the server */
CmTptParam   *tPar,         /* transport parameters */
CmIcmpFilter *icmpFilter,   /* Filter parameters */
U8           srvcType       /* service type */
)
#else
PUBLIC S16 PtLiHitServOpenReq(pst, spId, servConId, servTAddr, tPar, 
                              icmpFilter, srvcType) 
Pst          *pst;          /* post stucture */
SpId         spId;          /* service provider Id */
UConnId      servConId;     /* service user�s connection Id */
CmTptAddr    *servTAddr;    /* transport address of the server */
CmTptParam   *tPar;         /* transport parameters */
CmIcmpFilter *icmpFilter;   /* Filter parameters */
U8           srvcType;      /* service type */
#endif
{
   TRC3(PtLiHitServOpenReq);

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(servConId);
   UNUSED(servTAddr);
   UNUSED(tPar);
   UNUSED(icmpFilter);
   UNUSED(srvcType);

   RETVALUE(RFAILED);
} /* PtLiHitServOpenReq */

/*
*
*       Fun:   Portable Connection Request
*
*       Desc:  Portable version of HitConReq primitive
*
*       Ret:   RFAILED
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 PtLiHitConReq
(
Pst        *pst,          /* post stucture */
SpId       spId,          /* service provider Id */
UConnId    suConId,       /* service user�s connection Id */
CmTptAddr  *remAddr,      /* transport address of the server */
CmTptAddr  *localAddr,    /* local transport address */
CmTptParam *tPar,         /* transport parameters */
U8         srvcType       /* service type */
)
#else
PUBLIC S16 PtLiHitConReq(pst, spId, suConId, remAddr, localAddr, tPar, 
                         srvcType)
Pst        *pst;          /* post stucture */
SpId       spId;          /* service provider Id */
UConnId    suConId;       /* service user�s connection Id */
CmTptAddr  *remAddr;      /* transport address of the server */
CmTptAddr  *localAddr;    /* local transport address */
CmTptParam *tPar;         /* transport parameters */
U8         srvcType;      /* service type */
#endif
{
   TRC3(PtLiHitConReq);

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(suConId);
   UNUSED(remAddr);
   UNUSED(localAddr);
   UNUSED(tPar);
   UNUSED(srvcType);

   RETVALUE(RFAILED);
} /* PtLiHitConReq */

/*
*
*       Fun:   Portable Connection Response
*
*       Desc:  Portable version of HitConRsp primitive
*
*       Ret:   RFAILED
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 PtLiHitConRsp
(
Pst        *pst,          /* post stucture */
SpId       spId,          /* service provider Id */
UConnId    suConId,       /* service user�s connection Id */
UConnId    spConId        /* service provider's connection Id */
)
#else
PUBLIC S16 PtLiHitConRsp(pst, spId, suConId, spConId)
Pst        *pst;          /* post stucture */
SpId       spId;          /* service provider Id */
UConnId    suConId;       /* service user�s connection Id */
UConnId    spConId;       /* service provider's connection Id */
#endif
{
   TRC3(PtLiHitConRsp);

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(suConId);
   UNUSED(spConId);

   RETVALUE(RFAILED);
} /* PtLiHitConRsp */

/*
*
*       Fun:   Portable Data Request
*
*       Desc:  Portable version of HitDatReq primitive
*
*       Ret:   RFAILED
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 PtLiHitDatReq
(
Pst        *pst,          /* post stucture */
SpId       spId,          /* service provider Id */
UConnId    spConId,       /* service provider�s connection Id */
Buffer     *mBuf          /* message buffer */
)
#else
PUBLIC S16 PtLiHitDatReq(pst, spId, spConId, mBuf)
Pst        *pst;          /* post stucture */
SpId       spId;          /* service provider Id */
UConnId    spConId;       /* service provider�s connection Id */
Buffer     *mBuf;         /* message buffer */
#endif
{
   TRC3(PtLiHitDatReq);

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(spConId);
   UNUSED(mBuf);

   RETVALUE(RFAILED);
} /* PtLiHitDatReq */

/*
*
*       Fun:   Portable Unit Data Request
*
*       Desc:  Portable version of HitUDatReq primitive
*
*       Ret:   RFAILED
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 PtLiHitUDatReq
(
Pst         *pst,          /* post stucture */
SpId        spId,          /* service provider Id */
UConnId     spConId,       /* service provider�s connection Id */
CmTptAddr   *remAddr,      /* remote address */
CmTptAddr   *srcAddr,      /* source address */
CmIpHdrParm *hdrParm,      /* header parameters */
#ifdef HI_REL_1_4
CmTptParam  *tPar,         /* Transport Parameters */
#endif /* HI_REL_1_4 */
Buffer      *mBuf          /* message buffer */
)
#else
#ifdef HI_REL_1_4
PUBLIC S16 PtLiHitUDatReq(pst, spId, spConId, remAddr, srcAddr, hdrParm, 
                          tPar, mBuf)
Pst         *pst;          /* post stucture */
SpId        spId;          /* service provider Id */
UConnId     spConId;       /* service provider�s connection Id */
CmTptAddr   *remAddr;      /* remote address */
CmTptAddr   *srcAddr;      /* source address */
CmIpHdrParm *hdrParm;      /* header parameters */
CmTptParam  *tPar;         /* Transport Parameters */
Buffer      *mBuf;         /* message buffer */
#else
PUBLIC S16 PtLiHitUDatReq(pst, spId, spConId, remAddr, srcAddr, hdrParm, mBuf)
Pst         *pst;          /* post stucture */
SpId        spId;          /* service provider Id */
UConnId     spConId;       /* service provider�s connection Id */
CmTptAddr   *remAddr;      /* remote address */
CmTptAddr   *srcAddr;      /* source address */
CmIpHdrParm *hdrParm;      /* header parameters */
Buffer      *mBuf;         /* message buffer */
#endif
#endif
{
   TRC3(PtLiHitUDatReq);

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(spConId);
   UNUSED(remAddr);
   UNUSED(srcAddr);
   UNUSED(hdrParm);
   UNUSED(mBuf);

   RETVALUE(RFAILED);
} /* PtLiHitUDatReq */

/*
*
*       Fun:   Portable 
*
*       Desc:  Portable version of Hit primitive
*
*       Ret:   RFAILED
*
*       Notes: None
*
*       File:  so_ptli.c
*
*/
#ifdef ANSI
PUBLIC S16 PtLiHitDiscReq
(
Pst         *pst,          /* post stucture */
SpId        spId,          /* service provider Id */
U8          choice,        /* choice parameter */
UConnId     conId,         /* connection Id */
Action      action,        /* action type */
CmTptParam  *tPar          /* transport parameter */
)
#else
PUBLIC S16 PtLiHitDiscReq(pst, spId, choice, conId, action, tPar)
Pst         *pst;          /* post stucture */
SpId        spId;          /* service provider Id */
U8          choice;        /* choice parameter */
UConnId     conId;         /* connection Id */
Action      action;        /* action type */
CmTptParam  *tPar;         /* transport parameter */
#endif
{
   TRC3(PtLiHitDiscReq);

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(spId);
   UNUSED(choice);
   UNUSED(conId);
   UNUSED(action);
   UNUSED(tPar);

   RETVALUE(RFAILED);
} /* PtLiHitDiscReq */

#endif /* PTSOLIHIT */


#ifdef SO_COMPRESS

/*- Following function are interface to compressor/decompressor Module -*/

/*
*
*       Fun:   Compress Request
*
*       Desc:  This function is used to send signaling compression request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  cmp.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiCstCompressReq
(
Pst     *pst,
Buffer  *mBuf,
Ptr     compContext
)
#else
PUBLIC S16 SoLiCstCompressReq (pst, mBuf, compContext)
Pst     *pst;
Buffer  *mBuf;
Ptr     compContext;
#endif
{

  TRC3 (SoLiCstCompressReq)

  SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,  "SoLiCstCompressReq \n"));

  /*------- Pack Parameters --------*/
   RETVALUE (cmPkCstCompressReq (pst, mBuf, compContext));

} /* SoLiCstCompressReq */

/*
*
*       Fun:   Decompress Request
*
*       Desc:  This function is used to send signaling decompression request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  so_tcm.c
*
*/
#ifdef ANSI
PUBLIC S16 SoLiCstDecompressReq
(
Pst     *pst,
Buffer  *mBuf,
Ptr     compContext
)
#else
PUBLIC S16 SoLiCstDecompressReq (pst, mBuf, compContext)
Pst     *pst;
Buffer  *mBuf;
Ptr     compContext;
#endif
{

  TRC3 (SoLiCstDecompressReq)

  SODBGP_SO (DBGMASK_LI, (soCb.init.prntBuf,  "SoLiCstDecompressReq \n"));

  /*------- Pack Parameters --------*/
   RETVALUE (cmPkCstDecompressReq (pst, mBuf, compContext));

} /* SoLiCstDecompressReq */

#endif















/********************************************************************30**

         End of file:     so_ptli.c@@/main/4 - Tue Apr 20 12:46:53 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision sbstory:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------
 1.1         wvdl        1. Initial Release
*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---     ms   1. initial release.
*********************************************************************91*/
