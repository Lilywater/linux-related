/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SIP Layer

     Type:    C source file

     Desc:    product id file

     File:    so_id.c

     Sid:      so_id.c@@/main/3 - Wed Nov 26 15:17:20 2003

     Prg:     wvdl

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"           /* environment options */
#include "envdep.h"           /* environment dependent */
#include "envind.h"           /* environment independent */
#include "gen.h"              /* general layer */
#include "ssi.h"              /* system services */

/* header/extern include files (.x) */
#include "gen.x"              /* general layer */
#include "ssi.x"              /* system services */

/* defines */
#define SOSWMV 2            /* SIP - main version */
#define SOSWMR 1            /* SIP - main revision */
#define SOSWBV 0            /* SIP - branch version */
#define SOSWBR 41           /* SIP - branch revision for patch so041.201*/
#define SOSWPN "1000156"    /* SIP - part number */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* forward references */

PUBLIC S16 soGetSid ARGS((SystemId *sid));

/* public variable declarations */

/* copyright banner */

CONSTANT PUBLIC Txt soBan1[] =
      {"(c) COPYRIGHT 1989-2002, Trillium Digital Systems, Inc."};
CONSTANT PUBLIC Txt soBan2[] =
      {"                 All rights reserved."};

/* system id */

PRIVATE CONSTANT SystemId sId ={
   SOSWMV,                    /* main version */
   SOSWMR,                    /* main revision */
   SOSWBV,                    /* branch version */
   SOSWBR,                    /* branch revision */
   SOSWPN,                    /* part number */
};


/*
*     support functions
*/


/*
*
*       Fun:   soGetSid
*
*       Desc:  Get system id consisting of part number, main version and
*              revision and branch version and branch.
*
*       Ret:   TRUE      - ok
*
*       Notes: None
*
*       File:  so_id.c
*
*/
#ifdef ANSI
PUBLIC S16 soGetSid
(
SystemId *s                 /* system id */
)
#else
PUBLIC S16 soGetSid(s)
SystemId *s;                /* system id */
#endif
{
   TRC2(soGetSid)

   s->mVer  = sId.mVer;
   s->mRev  = sId.mRev;
   s->bVer  = sId.bVer;
   s->bRev  = sId.bRev;
   s->ptNmb = sId.ptNmb;

   RETVALUE(ROK);

} /* soGetSid */

#ifdef __cplusplus
}
#endif /* __cplusplus */



/********************************************************************30**

         End of file:     so_id.c@@/main/3 - Wed Nov 26 15:17:20 2003

*********************************************************************31*/
/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------
1.1           wvdl        1. Initial Release
*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/3      ---     ms   1. Release for 2.1.
/main/3+   so001.201 up   1. Branch Revision 1 for patch so001.201
/main/3+   so002.201 ps   1. Branch Revision 1 for patch so002.201
/main/3+   so003.201 up   1. Branch Revision 1 for patch so003.201
/main/3+   so004.201 up   1. Branch Revision 1 for patch so004.201
/main/3+   so005.201 up   1. Branch Revision 1 for patch so005.201
/main/3+   so006.201 up   1. Branch Revision 1 for patch so006.201
/main/3+   so007.201 up   1. Branch Revision 1 for patch so007.201
/main/3+   so008.201 up   1. Branch Revision 1 for patch so008.201
/main/3+   so009.201 ab   1. Branch Revision 1 for patch so009.201
/main/3+   so010.201 ab   1. Branch Revision 1 for patch so010.201
/main/3+   so011.201 ab   1. Branch Revision 1 for patch so011.201
/main/3+   so012.201 ab   1. Branch Revision 1 for patch so012.201
/main/3+   so013.201 ab   1. Branch Revision 1 for patch so013.201
/main/3+   so014.201 ab   1. Branch Revision 1 for patch so014.201
/main/3+   so015.201 ps   1. Branch Revision 1 for patch so015.201
/main/3+   so016.201 ab   1. Branch Revision 1 for patch so016.201
/main/3+   so017.201 ps   1. Branch Revision 1 for patch so017.201
/main/3+   so018.201 ps   1. Branch Revision 1 for patch so018.201
/main/3+   so019.201 ps   1. Branch Revision 1 for patch so019.201
/main/3+   so020.201 sg   1. Branch Revision 1 for patch so020.201
/main/3+   so021.201 sg   1. Branch Revision 1 for patch so021.201
/main/3+   so022.201 ad   1. Branch Revision 1 for patch so022.201
/main/3+   so023.201 ad   1. Branch Revision 1 for patch so023.201
/main/3+   so024.201 ad   1. Branch Revision 1 for patch so024.201
/main/3+   so025.201 ss   1. Branch Revision 1 for patch so025.201
/main/3+   so026.201 ad   1. Branch Revision 1 for patch so026.201
/main/3+   so027.201 ab   1. Branch Revision 1 for patch so027.201
/main/3+   so028.201 ss   1. Branch Revision 1 for patch so028.201
/main/3+   so029.201 ad   1. Branch Revision 1 for patch so029.201
/main/3+   so030.201 ss   1. Branch Revision 1 for patch so030.201
/main/3+   so031.201 aj   1. Branch Revision 1 for patch so031.201
/main/3+   so032.201 ng   1. Branch Revision 1 for patch so032.201
/main/3+   so033.201 ng   1. Branch Revision 1 for patch so033.201
/main/3+   so034.201 ng   1. Branch Revision 1 for patch so034.201
/main/3+   so035.201 ng   1. Branch Revision 1 for patch so035.201
/main/3+   so036.201 ng   1. Branch Revision 1 for patch so036.201
/main/3+   so037.201 ng   1. Branch Revision 1 for patch so037.201
/main/3+   so038.201 ng   1. Branch Revision 1 for patch so038.201
/main/3+   so039.201 ng   1. Branch Revision 1 for patch so039.201
/main/3+   so040.201 ng   1. Branch Revision 1 for patch so040.201
/main/3+   so041.201 ng   1. Branch Revision 1 for patch so041.201
*********************************************************************91*/
