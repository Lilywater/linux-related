#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timer library */
#include "cm_hash.h"       /* common hash library */
#include "cm_llist.h"      /* common linked list library */
#include "cm_inet.h"       /* common socket library */
#include "cm_tpt.h"        /* common transport library */
#include "cm_abnf.h"       /* common abnf */
#include "cm_tkns.h"       /* common tokens */
#include "cm_dns.h"        /* common DNS                   */
#include "hit.h"
#include "cm_sdp.h"
#include "cm_dns.h"        /* common DNS                   */
#include "sot.h"
#include "lso.h"
#include "so.h"
#include "so_trans.h"      /* Transaction module defines      */
#include "so_cm.h"
#include "so_err.h"
#ifdef SO_FTHA             /* fault tolerance */
#include "sht.h"           /* SHT interface header file */
#endif /* SO_FTHA */

/* header/extern include files (.x) */
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timer library */
#include "cm_hash.x"       /* common hash library */
#include "cm_llist.x"      /* common linked list library */
#include "cm_inet.x"       /* common socket library */
#include "cm_mblk.x"       /* common mem alloc defines */
#include "cm_abnf.x"       /* common abnf library */
#include "cm_tkns.x"       /* common tokens */
#include "cm_tpt.x"        /* common transport library */
#include "cm_xtree.x"      /* common radix tree */
#include "cm_lib.x"
#include "cm_dns.x"        /* common DNS                   */
#include "hit.x"
#include "cm_sdp.x"
#include "sot.x"
#include "lso.x"
#include "so_tcm.x"        /* tcm functions */
#include "so.x"
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* Utility functions */
#include "so_cl.x"         /* SIP cache */
#include "so_cm.x"         /* SIP common functions */
#include "so_lcs.x"        /* Location service */
#include "so_dns.x"        /* DNS functions */
#include "so_ua.x"         /* UA declarations */
#ifdef SO_FTHA             /* fault tolerance */
#include "sht.x"           /* SHT interface header file */
#endif /* SO_FTHA */



Void soHdrInit(Header *hdr) 
{

	TRC2(spHdrInit);

	hdr->elmId.elmnt = 0;
	hdr->elmId.elmntInst1 = 0;
	hdr->elmId.elmntInst2 = 0;
	hdr->elmId.elmntInst3 = 0;
	hdr->entId.ent = ENTSO;
	hdr->entId.inst = 0;
	hdr->seqNmb = 0;
	hdr->version = 0;
	hdr->msgType = 0;
	hdr->msgLen = sizeof(SoMngmt);
#ifdef SP_LMINT3
	hdr->transId = 2000;

#ifdef LCSMSPMILSP
	hdr->response.selector = 0;	/* LC */
#else
	hdr->response.selector = 1;	/* TC */
#endif
	hdr->response.mem.region = 0;
	hdr->response.mem.pool = 0;
	hdr->response.route = 0;
	hdr->response.prior = PRIOR1;
#endif /* SP_LMINT3 */
   
	RETVOID;
}


Void smSoPstInit(Pst *smSoPst)
{
	TRC2(smSpPstInit);
	
	cmMemset((U8 *)smSoPst, 0, sizeof(Pst));
	
#ifdef LCSMSPMILSP
	smSoPst->selector = 0;
#else
	smSoPst->selector = 1;
#endif
	
	smSoPst->event  = 0;
	smSoPst->region = 0;       /* region */
	smSoPst->pool = 0;           /* pool */
	smSoPst->prior = PRIOR1;                  /* priority */
	smSoPst->route = 0;                  /* route */
	smSoPst->dstProcId = SFndProcId();   /* destination processor id */
	smSoPst->dstEnt = ENTSO;             /* dst entity   (always ENTSP) */
	smSoPst->dstInst = 0;         /* dst instance (unused) */
	smSoPst->srcProcId = SFndProcId();   /* source processor id */
	smSoPst->srcEnt = ENTSM;            /* source entity */
	smSoPst->srcInst = 0;         /* src instance (unused) */
  
	RETVOID;
	
}




void soBndHiReq(void)
{
    Pst     smSoPst;           /* post structure */
    SoMngmt cntrl;             /* pointer to control structure */
	
	cmMemset((U8*)&cntrl, 0, sizeof(SoMngmt));
	
	soHdrInit(&cntrl.hdr);
	smSoPstInit(&smSoPst);
	
	smSoPst.event  = EVTLSOCNTRLREQ;
	cntrl.hdr.msgType = TCNTRL;
	cntrl.hdr.entId.ent = ENTSO;
	cntrl.hdr.entId.inst = 0;

	cntrl.hdr.elmId.elmnt   = STTSAP;
	cntrl.t.cntrl.action    = ABND_ENA;
	cntrl.t.cntrl.subAction = SAELMNT;

	cntrl.t.cntrl.s.sapId  = 1;
		
	(Void)SoMiLsoCntrlReq(&smSoPst, &cntrl);

}				




