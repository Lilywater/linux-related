/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:      Utility Functions 

     Type:     C source file

     Desc:     Source Code 

     File:     sohdrutl.c

     Sid:      sohdrutl.c@@/main/2 - Tue Apr 20 12:47:47 2004

     Prg:      pg 

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* environment options             */
#include "envdep.h"        /* environment dependent options   */
#include "envind.h"        /* environment independent options */
#include "gen.h"           /* general layer                   */
#include "ssi.h"           /* system service interface        */
#include "cm5.h"           /* common timer library            */
#include "cm_llist.h"      /* common linked list library      */
#include "cm_hash.h"       /* common hash library             */
#include "cm_tpt.h"        /* common transport library        */
#include "cm_tkns.h"       /* common tokens                   */
#include "cm_mblk.h"       /* common memory allocation        */
#include "cm_abnf.h"       /* common abnf library             */
#include "cm_sdp.h"        /* common sdp library              */
#include "cm_dns.h"        /* common dns library              */
#include "cm_inet.h"       /* common socket library           */
#include "hit.h"           /* hit interface defines           */
#include "lso.h"           /* layer management, sip           */
#include "sot.h"           /* sot interface defines           */
#include "so.h"            /* sip layer defines               */
#include "so_trans.h"      /* transaction module defines      */
#include "so_err.h"        /* sip error defines               */
#include "so_cm.h"         /* sip layer utility functions     */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer                   */
#include "ssi.x"           /* system services interface       */
#include "cm5.x"           /* common timer module             */
#include "cm_lib.x"        /* common linrary function         */
#include "cm_llist.x"      /* common link list library        */
#include "cm_hash.x"       /* common hash list library        */
#include "cm_tkns.x"       /* common tokens                   */
#include "cm_tpt.x"        /* common transport library        */
#include "cm_xtree.x"      /* common radix tree library       */
#include "cm_mblk.x"       /* common memory allocation        */
#include "cm_abnf.x"       /* common abnf library             */
#include "cm_sdp.x"        /* common sdp library              */
#include "cm_dns.x"        /* common dns library              */
#include "cm_inet.x"       /* common socket library           */
#include "hit.x"           /* hit interface defines           */
#include "lso.x"           /* layer management sip            */
#include "sot.x"           /* sot interface defines           */
#include "so_tcm.x"        /* transport module structures     */
#include "so.x"            /* sip layer structures            */
#include "so_trans.x"      /* transaction module structures   */
#include "so_utl.x"        /* sip layer utility functions     */
#include "so_cm.x"         /* sip layer common functions      */
#include "so_dns.x"        /* sip dns library                 */
#include "so_cl.x"         /* cache lib                       */

PRIVATE  S16 soUtlAddAllowMethod ARGS((
                              SoEvnt      *evnt,
                              SoAllow     *allow,
                              U8          method)); 

PRIVATE  S16 soUtlAddAllowMethodExt ARGS((
                              SoEvnt      *evnt,
                              SoAllow     *allow,
                              U8          *methodStr,
                              U16         len)); 

EXTERN CmAbnfElmDef soMsgDefVia; /*so028.201 : Added to encode top via item */
/*
*
*       Fun:   soUtlAddSuppHdr
*
*       Desc:  This function adds a Supported header to the current SIP
*              message.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:
*
*/

#ifdef ANSI
PUBLIC S16 soUtlAddSuppHdr
(
SoEntCb         *ent,
SoEvnt          *evnt         /* Pointer to complete SIP message   */
)
#else
PUBLIC S16 soUtlAddSuppHdr(ent, evnt)
SoEntCb         *ent;          /* Entity CB */
SoEvnt          *evnt;         /* Pointer to complete SIP message   */
#endif
{
   SoTknStrOSXLLst *suppHdr;   /* Supported structure in message    */
   SoTknStrOSXLLst *cfgSuppHdr; /* Pre configured Supported Header */
   S16             ret;        /* value returned by function calls  */
   U16             i;          /* Index                             */
   U16             j;          /* Index                             */
   U16             numComp;    /* nummber of components in the hdr  */
   U16             cfgNumComp; /* nummber of components in the cfgd hdr  */
   U8              entryFound; /* Entry exists in the Supp header  */

   TRC3(soUtlAddSuppHdr);

#ifdef SO_UA
   if (ent->entityType == LSO_ENT_UA)
     cfgSuppHdr = &ent->s.ua.supported;
#endif

#ifdef SO_NS
   if (ent->entityType == LSO_ENT_NS)
     cfgSuppHdr = &ent->s.ns.supported;
#endif /* SO_NS */

   cfgNumComp = SO_GET_NUM_COMP(&cfgSuppHdr->numComp);
   
   /* Determine if msg is a request or a response */
   /* Find supported header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &suppHdr,
                           SO_HEADER_GEN_SUPPORTED);

   if (ret != ROK)
   {
      if(cfgNumComp == 0)
         RETVALUE(ROK);
      /* Create new supported header */
      if ( soCmCreateHdrChoice(evnt, (U8 **) &suppHdr,
         SO_HEADER_GEN_SUPPORTED)!=ROK)
         RETVALUE(SOT_ERR_ADD_HDR_FAILED);
   }

   numComp = SO_GET_NUM_COMP(&suppHdr->numComp);


   /* Add the configured supported fields into the header, if not
      already present */
   for (i = 0; i < cfgNumComp; i++)
   {
      entryFound = FALSE;

      for (j = 0; j < numComp; j++)
      {
         if (SO_CMP_TKNSTR(suppHdr->stringList[j],
                           cfgSuppHdr->stringList[i]))
         {
            entryFound = TRUE;
            break;
         }
      }

      if (!entryFound)
      {
         if ( soCmGrowList((Void ***)&suppHdr->stringList,
                      sizeof(TknStrOSXL), &suppHdr->numComp, evnt)!=ROK )
            RETVALUE(SOT_ERR_RSRC);

         if ( soUtlCpyTknStrOSXL(
              suppHdr->stringList[suppHdr->numComp.val - 1],
              cfgSuppHdr->stringList[i],&evnt->memCp)!=ROK )
            RETVALUE(SOT_ERR_RSRC);
      }
   }

   RETVALUE(ROK);
} /* end of soUtlAddSuppHdr */


/*
*
*       Fun:   soUtlInsertDate
*
*       Desc:  This function generates a Date header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlInsertDate
(
SoEntCb  *ent,        /* Entity Cb */
SoEvnt   *evnt        /* Pointer to complete SIP message */
)
#else
PUBLIC S16 soUtlInsertDate(ent, evnt)
SoEntCb  *ent;         /* Entity Cb */
SoEvnt   *evnt;        /* Pointer to complete SIP message */
#endif
{
   SoSipDate *sipDate;  /* local pointer to SIP date in message        */
   DateTime dt;         /* Date-time structure to send to SGetDateTime */
   S16      ret;        /* value returned by function calls            */

   TRC2(soUtlInsertDate);

   /* Determine if msg is a request or a response */
   /* Find allow header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &sipDate, SO_HEADER_GEN_DATE);
   if (ret != ROK)
   {
      if ( soCmCreateHdrChoice(evnt, (U8 **)&sipDate, SO_HEADER_GEN_DATE)!=ROK )
      {
         RETVALUE(SOT_ERR_ADD_HDR_FAILED);
      }
   }

   /* Get current time */
   (Void) SGetDateTime(&dt);

   /* Pack current time into soSipDate */
   ret = soCmPackDate(sipDate, &dt);

   RETVALUE(ret);
} /* end of soUtlInsertDate */



/*
*
*       Fun:   soPrcAddAllowMethod
*
*       Desc:  Add a Method to an Allow header.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PRIVATE  S16 soUtlAddAllowMethod
(
SoEvnt      *evnt,         /* ES for alloc                    */
SoAllow     *allow,        /* Allow structure in message      */
U8          method         /* Method to add                   */
)
#else
PRIVATE  S16 soUtlAddAllowMethod(evnt, allow, method)
SoEvnt      *evnt;         /* ES for alloc                    */
SoAllow     *allow;        /* Allow structure in message      */
U8          method;        /* Method to add                   */
#endif
{
   U16      nMet;        /* Index of new method in end sys CB  */
   U16      i;
   S16      ret;

   TRC2(soUtlAddAllowMethod);

   for (i = 0; i < SO_GET_NUM_COMP(&allow->numComp); i++)
   {
      /* Return if this method already exists in the list */
      if ((SO_CMP_TKN_LIT(&allow->method[i]->type, SO_METHOD_METHODSTD)) &&
          (SO_CMP_TKN_LIT(&allow->method[i]->t.std, method)))
      {
         RETVALUE(ROK);
      }
   }

   nMet = SO_GET_NUM_COMP(&allow->numComp);
   ret = soCmGrowList((Void ***)&allow->method, sizeof(SoExtVal),
                       &allow->numComp, evnt);
   if (ret != ROK)
      RETVALUE(RFAILED);

   SO_FILL_TKNU8(&allow->method[nMet]->type, SO_METHOD_METHODSTD);
   SO_FILL_TKNU8(&allow->method[nMet]->t.std, method);

   RETVALUE(ROK);
} /* end of soUtlAddAllowMethod */




/*
*
*       Fun:   soUtlAddAllowMethodExt
*
*       Desc:  Add a non-standard Method to an Allow header.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PRIVATE  S16 soUtlAddAllowMethodExt
(
SoEvnt      *evnt,         /* ES for alloc                    */
SoAllow     *allow,        /* Allow structure in message      */
U8          *methodStr,    /* Method string to add            */
U16         len            /* Length of method String         */
)
#else
PRIVATE  S16 soUtlAddAllowMethodExt(evnt, allow, methodStr, len)
SoEvnt      *evnt;         /* ES for alloc                    */
SoAllow     *allow;        /* Allow structure in message      */
U8          *methodStr;    /* Method to add                   */
U16         len;           /* Length of method String         */
#endif
{
   S16      ret;
   U16      nMet;        /* Index of new method in end sys CB  */
   U16      i;

   TRC2(soUtlAddAllowMethodExt);

   for (i = 0; i < allow->numComp.val; i++)
   {
      /* Return if this method already exists in the list */
      if ((SO_CMP_TKN_LIT(&allow->method[i]->type,
                          SO_METHOD_EXTENSIONMETHOD)) &&
           (SO_CMP_TKNSTR_LIT(&allow->method[i]->t.ext, methodStr, len)))
      {
         RETVALUE(ROK);
      }
   }

   nMet = SO_GET_NUM_COMP(&allow->numComp);
   if ( soCmGrowList((Void ***)&allow->method, sizeof(SoExtVal),
                                 &allow->numComp, evnt)!=ROK )
   {
      RETVALUE(RFAILED);
   }

   SO_FILL_TKNU8(&allow->method[nMet]->type, SO_METHOD_EXTENSIONMETHOD);
   SO_FILL_TKNSTROSXL(&allow->method[nMet]->t.ext, methodStr, len, evnt, ret);

   RETVALUE(ret);
} /* end of soUtlAddAllowMethodExt */



#ifdef SO_UA

/*
*
*       Fun:   soUtlAddAllowHdr
*
*       Desc:  This function generates an Allow header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlAddAllowHdr
(
SoEntCb         *ent,         /* Entity CB */
SoEvnt          *evnt         /* Pointer to complete SIP message   */
)
#else
PUBLIC S16 soUtlAddAllowHdr(ent, evnt)
SoEntCb         *ent;         /* Entity CB */
SoEvnt          *evnt;         /* Pointer to complete SIP message   */
#endif
{
   SoAllow  *allowHdr;    /* Allow structure in message         */
   U16      i;            /* Index of end system allow list     */
   S16      ret;          /* value returned by function calls   */
   SoAllow  *cfgAllow;

   TRC2(soUtlAddAllowHdr);

   cfgAllow = &ent->s.ua.allow;

   /* Find allow header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &allowHdr,
                           SO_HEADER_GEN_ALLOW);
   if (ret != ROK)
   {
      if (soCmCreateHdrChoice(evnt, (U8 **)&allowHdr,
                                SO_HEADER_GEN_ALLOW) != ROK)
        RETVALUE(SOT_ERR_ADD_HDR_FAILED);
   }

   /* Add the std Methods to the Allow hdr */
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_INVITE);
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_ACK);
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_OPTIONS);
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_BYE);
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_CANCEL);
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_REGISTER);
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_INFO);
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_COMET);
#ifdef SO_UPDATE   
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_UPDATE);
#endif /* SO_UPDATE */   
#ifdef SO_RFC_3262
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_PRACK);
#endif /* SO_RFC_3262 */   
#ifdef SO_EVENT
#ifdef  SO_REFER
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_REFER);
#endif /*  SO_REFER */
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_SUBSCRIBE);
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_NOTIFY);
#endif /* SO_EVENT */
#ifdef SO_INSTMSG
   soUtlAddAllowMethod(evnt, allowHdr, SO_METHODSTD_MESSAGE);
#endif /* SO_INSTMSG */
   
   /* Headers from allow header if the pointer to allow is not NULL */
   if (cfgAllow != NULLP)
   {
      /* For each method in the allow list (for this UA) add it
         to Allow hdr */
      for (i = 0; i < SO_GET_NUM_COMP(&cfgAllow->numComp); i++)
      {
         /* Add method to allow header */
         switch (cfgAllow->method[i]->type.val)
         {
            case SO_METHOD_METHODSTD:
                if (soUtlAddAllowMethod(evnt, allowHdr,
                                   cfgAllow->method[i]->t.std.val)!=ROK )
                   RETVALUE(SOT_ERR_RSRC);
                break;
            case SO_METHOD_EXTENSIONMETHOD:
               if (soUtlAddAllowMethodExt(evnt, allowHdr,
                                      cfgAllow->method[i]->t.ext.val,
                                      cfgAllow->method[i]->t.ext.len)!=ROK )
                   RETVALUE(SOT_ERR_RSRC);
               break;
            default:
               break;
         }
      }
   }

   RETVALUE(SOT_ERR_NOERR);
} /* end of soPrcAddAllow */

#endif /* SO_UA */


/*
*
*       Fun:   soUtlAddOrgHdr
*
*       Desc:  This function generates an Organization header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  
*
*/

#ifdef ANSI
PUBLIC S16 soUtlAddOrgHdr
(
SoEntCb         *ent,         /* Entity CB */
SoEvnt          *evnt         /* Pointer to complete SIP message   */
)
#else
PUBLIC S16 soUtlAddOrgHdr(ent, evnt)
SoEntCb         *ent;         /* Entity CB */
SoEvnt          *evnt;        /* Pointer to complete SIP message   */
#endif
{
   SoTknStr    *dfltOrg;      /* Organization string              */
   TknStrOSXL  *org;          /* Organization header              */
   S16         ret;           /* value returned by function calls */

   TRC2(soPrcOrganization);

   dfltOrg = &ent->reCfg.hdrCfg.insOrg;

   /* Find Organization header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &org,
      SO_HEADER_GEN_ORGANIZATION);

   if (ret == ROK)
      RETVALUE(SOT_ERR_NOERR);

   /* No Organization header, must create one */
   if ( soCmCreateHdrChoice(evnt, (U8 **) &org,
      SO_HEADER_GEN_ORGANIZATION)!=ROK )
      RETVALUE(SOT_ERR_ADD_HDR_FAILED);

   SO_FILL_TKNSTROSXL(org, (U8 *)(dfltOrg->str),
                        cmStrlen((U8 *)(dfltOrg->str)), evnt, ret);
   if (ret != ROK)
     ret = SOT_ERR_ADD_HDR_FAILED;

   RETVALUE(ret);
} /* end of soUtlAddOrgHdr */



/*
*
*       Fun:   soUtlAddSubjectHdr
*
*       Desc:  This function generates a Subject header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  
*
*/

#ifdef ANSI
PUBLIC S16 soUtlAddSubjectHdr
(
SoEntCb         *ent,         /* Entity CB */
SoEvnt          *evnt         /* Pointer to complete SIP message   */
)
#else
PUBLIC S16 soUtlAddSubjectHdr(ent, evnt)
SoEntCb         *ent;         /* Entity CB */
SoEvnt          *evnt;        /* Pointer to complete SIP message   */
#endif
{
   SoTknStr    *dfltSub;      /* Organization string              */
   TknStrOSXL  *sub;          /* Organization header              */
   S16         ret;           /* value returned by function calls */

   TRC2(soUtlAddSubjectHdr);

   dfltSub = &ent->reCfg.hdrCfg.insSubject;

   if (dfltSub->pres == NOTPRSNT)
     RETVALUE(ROK);

   /* Find Organization header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &sub,
      SO_HEADER_GEN_SUBJECT);

   if (ret == ROK)
      RETVALUE(SOT_ERR_NOERR);

   /* No Organization header, must create one */
   if ( soCmCreateHdrChoice(evnt, (U8 **) &sub, SO_HEADER_GEN_SUBJECT)!=ROK )
      RETVALUE(SOT_ERR_ADD_HDR_FAILED);

   SO_FILL_TKNSTROSXL(sub, (U8 *)(dfltSub->str),
                        cmStrlen((U8 *)(dfltSub->str)), evnt, ret);
   RETVALUE(ret);
} /* end of soUtlAddSubjectHdr */


#ifdef SO_UA
/*
*
*       Fun:   soUtlAddExpires
*
*       Desc:  Adds expires header if not already present.
*
*       Ret:   ROK/RFAILED
*
*       Notes: 
*
*       File:  
*
*/

#ifdef ANSI
PUBLIC S16 soUtlAddExpires
(
SoEntCb         *ent,         /* Entity CB */
SoEvnt          *evnt         /* Pointer to complete SIP message   */
)
#else
PUBLIC S16 soUtlAddExpires(ent, evnt)
SoEntCb         *ent;         /* Entity CB */
SoEvnt          *evnt;        /* Pointer to complete SIP message   */
#endif
{
   U32        expiresVal;
   TknU32     *expires;     /* Pointer to expire header         */

   TRC2(soUtlAddExpires);

   if (ent->entityType != LSO_ENT_UA)
      RETVALUE(ROK);

   /* Find header in message */
   if ((soCmFindHdrChoice(evnt, (U8 **) &expires,
                          SO_HEADER_GEN_EXPIRES)) == ROK)
      RETVALUE(SOT_ERR_NOERR);


   /* If method is INVITE/Register and the default configured expires
      timer is 0 then donot create a expires header */
   switch (evnt->eventType.val)
   {
      case SOT_ET_INVITE:
         if (ent->s.ua.reCfg.dfltExpiresInInvite == 0)
            RETVALUE(SOT_ERR_NOERR);
         expiresVal = ent->s.ua.reCfg.dfltExpiresInInvite;
         break;
      case SOT_ET_REGISTER:
         if (ent->s.ua.reCfg.dfltExpiresInRegister == 0)
            RETVALUE(SOT_ERR_NOERR);
         expiresVal = ent->s.ua.reCfg.dfltExpiresInRegister;
         break;
#ifdef SO_EVENT
      case SO_METHODSTD_SUBSCRIBE:
         if (ent->reCfg.evntPkgExpires == 0)
            RETVALUE(SOT_ERR_NOERR);
         expiresVal = ent->reCfg.evntPkgExpires;
         break;
#endif /* SO_EVENT */
      default:
         RETVALUE(SOT_ERR_NOERR);
   }

   /* create expires */
   if ( soCmCreateHdrChoice(evnt, (U8 **) &expires,
         SO_HEADER_GEN_EXPIRES)!=ROK )
     RETVALUE(SOT_ERR_ADD_HDR_FAILED);

   SO_FILL_TKNU32(expires, expiresVal);

   RETVALUE(SOT_ERR_NOERR);
} /* end of soUtlAddExpires */


#endif /* SO_UA */




/*
*
*       Fun:   soUtlAddRequireHdr
*
*       Desc:  This checks adds a require header with option tag supplied.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlAddRequireHdr
(
SoEvnt  *evnt,        /* Pointer to complete SIP message   */
U8      *optionTag    /* Required option tag             */
)
#else
PUBLIC S16 soUtlAddRequireHdr(evnt, optionTag)
SoEvnt  *evnt;        /* Pointer to complete SIP message   */
U8      *optionTag;   /* Required option tag             */
#endif
{
   SoTknStrOSXLLst *require;      /* require structure in message     */
   U16             len;           /* length of option tag             */
   S16             ret;           /* value returned by function calls */
   U16             i;             /* loop counter                     */
   U16             nTag;          /* Index of new tag in require list */

   TRC2(soUtlAddRequireHdr);

   /* Determine if msg is a request or a response */
   /* Find header in message - create it if not found */
   ret = soCmFindHdrChoice(evnt, (U8 **) &require,
      SO_HEADER_GEN_REQUIRE);
   if (ret != ROK)
   {
      if ( soCmCreateHdrChoice(evnt, (U8 **) &require,
         SO_HEADER_GEN_REQUIRE)!=ROK )
        RETVALUE(SOT_ERR_ADD_HDR_FAILED);

   }

   /* check if an option tag is already in Require header */
   nTag = SO_GET_NUM_COMP(&require->numComp);   
   len  = cmStrlen(optionTag);

   /* Add this optionTag if it is not already in the list */
   for (i = 0; i < nTag; i++)
   {
      /* Return if this method already exists in the list */
      if ((require->stringList[i]->pres == PRSNT_NODEF) &&
          (require->stringList[i]->len == len) &&
          (!cmStrncmp(require->stringList[i]->val, 
                      optionTag,
                      require->stringList[i]->len)))
         RETVALUE(SOT_ERR_NOERR);
   }
   
   /* Add to require list */
   if ( soCmGrowList((Void ***)&require->stringList, sizeof(TknStrOSXL),
                &require->numComp, evnt)!=ROK )
   {
      RETVALUE(SOT_ERR_RSRC);
   }

   SO_FILL_TKNSTROSXL(require->stringList[nTag],
                      optionTag, len, evnt, ret);
   RETVALUE(ret);
} /* end of soUtlAddRequireHdr */


#ifdef SO_UA

/*
*
*       Fun:   soUtlAddAcceptHdr
*
*       Desc:  This function adds a Accept header to the current SIP
*              message.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:
*
*/

#ifdef ANSI
PUBLIC S16 soUtlAddAcceptHdr
(
SoEntCb         *ent,         /* Entity CB */
SoEvnt          *evnt,        /* Pointer to complete SIP message   */
SoAddress       *localAddr    /* Local address */
)
#else
PUBLIC S16 soUtlAddAcceptHdr(ent, evnt, localAddr)
SoEntCb         *ent;          /* Entity CB */
SoEvnt          *evnt;         /* Pointer to complete SIP message   */
SoAddress       *localAddr;    /* Local address */
#endif
{
   S16             ret;           /* value returned by function calls */
   U16             nMet;          /* Index of new method in end sys CB  */
   U16             i;             /* loop counter */
   SoMediaRangeVal *mediaRangeVal;/* pointer to mediaRangeVal in
                                     accept header */
   SoAddrSpec       *toAddrSpec;  /* Address spec for To                      */
   SoSipUrl         *sipUrl;      /* SIP URL                                  */
   TknStrOSXL       *user;        /* User part of SIP URL                     */
   SoClRegEnt       *regEntry;    /* Entry stored in cache                    */
   U16              findCount;    /* number of matches is registry            */
   SoAccept         *acceptHdr;   /* pointer to accept header in message     */
   SoAcceptEncoding *accEncHdr;   /* pointer to acceptEncoding header in     */
   U8               acceptHdrFlg = TRUE; /* accept hdr is there or not */
   SoAcceptLanguage *accLanHdr;    /* pointer to acceptLanguage header in
                                     message                                  */

   TRC2(soPrcAddAccept);

   /* Find allow header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &acceptHdr,
                           SO_HEADER_GEN_ACCEPT);
   if (ret != ROK)
   {
      acceptHdrFlg = FALSE;
      if ( soCmCreateHdrChoice(evnt, (U8 **)&acceptHdr,
         SO_HEADER_GEN_ACCEPT)!=ROK )
        RETVALUE(SOT_ERR_ADD_HDR_FAILED);
   }
   else
   {
      for (i = 0; i < SO_GET_NUM_COMP(&acceptHdr->numComp); i++)
      {
         mediaRangeVal = &acceptHdr->accept[i]->mediaRange.mediaRangeVal;

         if ((acceptHdr->accept[i]->pres.pres == PRSNT_NODEF) &&
             (acceptHdr->accept[i]->mediaRange.pres.pres == PRSNT_NODEF) &&
             (SO_CMP_TKN_LIT(&mediaRangeVal->mediaRangeValType,
                             SO_MEDIARANGEVAL_TYPESUB)) &&
             (mediaRangeVal->t.typeSub.pres.pres == PRSNT_NODEF) &&
             (SO_CMP_TKNSTR_LIT(&mediaRangeVal->t.typeSub.type,
                                (U8 *)SO_HDR_ACCEPT_TYPE,
                                SO_HDR_ACCEPT_TYPE_LEN)) &&
             (SO_CMP_TKNSTR_LIT(&mediaRangeVal->t.typeSub.subType,
                                (U8 *)SO_HDR_ACCEPT_SUBTYPE,
                                SO_HDR_ACCEPT_SUBTYPE_LEN)))
         {
            RETVALUE(SOT_ERR_NOERR);
         }
      }

   }

   if (acceptHdrFlg == FALSE)
   {
      nMet = SO_GET_NUM_COMP(&acceptHdr->numComp);
      if ( soCmGrowList((Void ***)&acceptHdr->accept,
                          sizeof(SoAcceptSeq),
                          &acceptHdr->numComp,
                          evnt)!=ROK )
         RETVALUE(SOT_ERR_RSRC);


      mediaRangeVal = &acceptHdr->accept[nMet]->mediaRange.mediaRangeVal;

      acceptHdr->accept[nMet]->pres.pres            = PRSNT_NODEF;
      acceptHdr->accept[nMet]->mediaRange.pres.pres = PRSNT_NODEF;

      SO_FILL_TKNU8(&mediaRangeVal->mediaRangeValType,
                    SO_MEDIARANGEVAL_TYPESUB);

      mediaRangeVal->t.typeSub.pres.pres = PRSNT_NODEF;

      SO_FILL_TKNSTROSXL(&mediaRangeVal->t.typeSub.type,
                         SO_HDR_ACCEPT_TYPE,
                         SO_HDR_ACCEPT_TYPE_LEN,
                         evnt, ret);
      if (ret != ROK)
         RETVALUE(SOT_ERR_RSRC);

      SO_FILL_TKNSTROSXL(&mediaRangeVal->t.typeSub.subType,
                         SO_HDR_ACCEPT_SUBTYPE,
                         SO_HDR_ACCEPT_SUBTYPE_LEN,
                         evnt, ret);
      if (ret != ROK)
         RETVALUE(SOT_ERR_RSRC);
   }

   SO_ADDRSPEC_FROM_ADDRCH(toAddrSpec, &localAddr->addrCh);
   if (toAddrSpec == NULLP)
      RETVALUE(RFAILED);

   SO_SIPURL_FROM_ADDRSPEC(sipUrl, toAddrSpec);
   if (sipUrl != (SoSipUrl *)NULLP)
   {
      SO_USER_FROM_SIPURL(user, sipUrl);
      if (user != (TknStrOSXL *)NULLP)
      {
         /* Get Accept, Accept-Enoding and Accept-Language from the local
            user registry */

         /* user is localy registered */
         ret = soClFindUser (&ent->s.ua.localUsrReg, toAddrSpec,
                             &regEntry, &findCount );
         if (ret != ROK)
         {
            SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
               "soUtlAddAcceptHdr: soClFindUser failed.\n"));
            RETVALUE(RFAILED);
         }

         if (findCount > 0)
         {
            if ((regEntry->acceptHdr.numComp.pres != NOTPRSNT) && (acceptHdrFlg == FALSE))
            {
               if ( soUtlCpySoAccept(acceptHdr,
                                  &regEntry->acceptHdr,
                                  &evnt->memCp)!=ROK )
               {
                  RETVALUE(RFAILED);
               }
            }

            if (regEntry->accEncHdr.numComp.pres != NOTPRSNT)
            {

               ret = soCmFindHdrChoice(evnt, (U8 **) &accEncHdr,
                                       SO_HEADER_GEN_ACCEPTENCODING);
               if (ret != ROK)
               {
                  if ( soCmCreateHdrChoice(evnt,
                                           (U8 **)&accEncHdr,
                                           SO_HEADER_GEN_ACCEPTENCODING)!=ROK )
                  {
                     RETVALUE(RFAILED);
                  }


                  if ( soUtlCpySoAcceptEncoding(accEncHdr,
                                        &regEntry->accEncHdr,
                                        &evnt->memCp)!=ROK )
                  {
                     RETVALUE(RFAILED);
                  }
               }
            }

            if (regEntry->accLanHdr.numComp.pres != NOTPRSNT)
            {
               ret = soCmFindHdrChoice(evnt, (U8 **) &accLanHdr,
                                       SO_HEADER_GEN_ACCEPTLANGUAGE);
               if (ret != ROK)
               {
                  if ( soCmCreateHdrChoice(evnt,
                                             (U8 **)&accLanHdr,
                                             SO_HEADER_GEN_ACCEPTLANGUAGE)!=ROK )
                  {
                     RETVALUE(RFAILED);
                  }


                  if ( soUtlCpySoAcceptLanguage(accLanHdr,
                                        &regEntry->accLanHdr,
                                        &evnt->memCp)!=ROK )
                  {
                     RETVALUE(RFAILED);
                  }
               }
            }
         }
      }
   }

   RETVALUE(SOT_ERR_NOERR);

}


/* so035.201: New flag to check if contact was previously added by Stack */
/*
*
*       Fun:   soUtlAddContactHdr
*
*       Desc:  This function adds a Contact header to the current SIP
*              message.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:
*
*/

#ifdef ANSI
PUBLIC S16 soUtlAddContactHdr
(
SoCLegCb        *cLeg,        /* Call Leg Cb */
SoEvnt          *evnt,        /* Pointer to complete SIP message   */
U8              tptProt,      /* tpt protocol */
Bool            *selfAdded    /* Contact was added by stack earlier */
)
#else
PUBLIC S16 soUtlAddContactHdr(cLeg, evnt, tptProt, selfAdded)
SoCLegCb        *cLeg;        /* Call Leg Cb */
SoEvnt          *evnt;        /* Pointer to complete SIP message   */
U8              tptProt;      /* tpt protocol */
Bool            *selfAdded;   /* Contact was added by stack earlier */
#endif
{
   S16           ret;
   S16           cnt;
   SoAddrSpec    *srcAddrSpec;
   SoAddrSpec    *addrSpec;
   SoContact     *contact;       /* Ptr to contact    */
   SoAddress     *source;        /* Source address for message  */
   SoEntCb       *ent;           /* Entity Cb */
   SoSipUrl      *sipUrl;
   U16           findCount;
   U16           numComp;
   SoClRegEnt    *regEntry;      /* entry in multicast cashe        */
   SoTptServerCb *serverCb;
   SoSipUrl      *srcSipUrl;     /* local pointer to SIP URL        */
   TknStrOSXL    *userPart;      /* Local pointer to user part      */
   U8            addrSpecType;   /* Addr Spec Type                  */
   U16           hdrIdx;         /* so035.201: Index of contact in the message */

   TRC3(soUtlAddContactHdr);

   ret = ROK;

   /* so035.201: Replace contact header, if it was previously added by stack */
   /*----------- STEP 1:  Check if user gave Contact ----------------*/
   if (soCmFindHdrChoice(evnt, (U8 **) &contact, SO_HEADER_GEN_CONTACT) == ROK)
   {
      if (*selfAdded == TRUE)
      {
         /* Delete old contact (if any) in cLeg & store the new contact */
         soUtlDelSoContact(&cLeg->storedHdrs.localTrgtURI);

         /* Contact header was previously added by the stack */
         soCmFindHdrChIndex(evnt, (U8 **) &contact, &hdrIdx,
                            SO_HEADER_GEN_CONTACT);
         soCmRemoveHdrChoice(evnt, hdrIdx, SO_HEADER_GEN_CONTACT);
      }
      else
      {
         /* Contact header was given by the application */
         /* so039.201: Fix for mem leak. Delete old contact (if any) in cLeg  */
         if (cLeg->storedHdrs.localTrgtURI.pres.pres != NOTPRSNT)
            soUtlDelSoContact(&cLeg->storedHdrs.localTrgtURI);
         /* Store new Contact */
         ret = soUtlCpySoContact(&cLeg->storedHdrs.localTrgtURI,
               contact, NULLP);
         RETVALUE(ret);
      }
   }

   /*----------- STEP 2:  Check if user is locally registered -------*/
   source = &cLeg->storedHdrs.localAddr;
   if (source == NULLP)
      RETVALUE(RFAILED);

   SO_ADDRSPEC_FROM_ADDRCH(srcAddrSpec, &source->addrCh);

   ent = cLeg->call->ent;
   ret = soClFindUser(&ent->s.ua.localUsrReg, srcAddrSpec,
                      &regEntry, &findCount);
   if (ret != ROK)
        RETVALUE(RFAILED);

   if (findCount > 0)
   {
     if (soClContactHdrFromCacheEntry(evnt, regEntry, FALSE, FALSE) == ROK)
         RETVALUE(ROK);
   }

   /*----------- STEP 3:  Check if Contact is already stored in cLeg -------*/
   if (cLeg->storedHdrs.localTrgtURI.pres.pres != NOTPRSNT)
   {
      /* Copy store local Contact in Event structre */
      if (soCmCreateHdrChoice(evnt, (U8 **)&contact, SO_HEADER_GEN_CONTACT) != ROK)
         RETVALUE (RFAILED);

      ret = soUtlCpySoContact(contact, &cLeg->storedHdrs.localTrgtURI, &evnt->memCp);
      RETVALUE(ret);
   }

   /*----- STEP 4:  If UAS, build Contact on basis of remoteTrgtURI ----*/
   if (tptProt == LSO_TPTPROT_NULL)
   {
      /* so006.201: Init transport protocol */
      tptProt = SO_TRANSPORT_UDP;

#ifdef SO_TLS
      if (cLeg->secure == SO_TLS_USER)
         tptProt = LSO_TPTPROT_TLS_TCP;
      else
#endif
      if (cLeg->storedHdrs.remoteTrgtURI.pres.pres != NOTPRSNT)
      {
         /* so006.201: Find transport protocol */
         if (cLeg->storedHdrs.remoteTrgtURI.addrCh.addrChType.val == SO_ADDRCH_NAMEADDR)
            addrSpec = &cLeg->storedHdrs.remoteTrgtURI.addrCh.t.nameAddr.addrSpec;
         else
            addrSpec = &cLeg->storedHdrs.remoteTrgtURI.addrCh.t.addrSpec;

         if ((addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPURL)  ||
             (addrSpec->addrSpecType.val == SO_ADDRSPEC_SIPSURL)  ||
             (addrSpec->addrSpecType.val == SO_ADDRSPEC_IMURL))
         {
            sipUrl = &addrSpec->t.sipUrl;
            for (cnt = 0; cnt < sipUrl->urlParameters.numComp.val; cnt++)
            {
               if(sipUrl->urlParameters.urlParameter[cnt]->
                  urlParameterType.val == SO_URLPARAMETER_TRANSPORTPARAM)
               {
                  tptProt = 
                   sipUrl->urlParameters.urlParameter[cnt]->t.transportParam.transportParamType.val;
                  break;
               }
            }
         }
      }
   }

   /* Create contact using source as contact item */
   if (soCmCreateHdrChoice(evnt, (U8 **)&contact,
                           SO_HEADER_GEN_CONTACT) != ROK)
      RETVALUE (RFAILED);

   SO_FILL_TKNU8(&contact->contactDescType, SO_CONTACTDESC_CONTACTITEMS);

   /* Add new contact item */
   if (soCmGrowList((Void ***)&contact->contactItems.contactItem,
                      sizeof(SoContactItem),
                      &contact->contactItems.numComp,
                      evnt) != ROK)
   {
      RETVALUE(RFAILED);
   }

   contact->pres.pres = PRSNT_NODEF;

   /* Set contact presence indicator */
   contact->contactItems.contactItem[0]->pres.pres = PRSNT_NODEF;

   /* Set contact type */
   SO_FILL_TKNU8(
   &contact->contactItems.contactItem[0]->contactAddrChoice.addrChType,
   SO_ADDRCH_ADDRSPEC);

   addrSpecType = SO_ADDRSPEC_SIPURL;
#ifdef SO_TLS
   /* so035.201: Change to sips only if a secure call is rquested */
   if (cLeg->secure == SO_TLS_USER)
      addrSpecType = SO_ADDRSPEC_SIPSURL;
#endif

   /* Set addrChoice type */
   SO_FILL_TKNU8(
      &contact->contactItems.contactItem[0]->contactAddrChoice.t.\
      addrSpec.addrSpecType, addrSpecType);

   /* Set local pointer to sipUrl */
   sipUrl =
      &contact->contactItems.contactItem[0]->contactAddrChoice.t.\
         addrSpec.t.sipUrl;

   sipUrl->pres.pres          = PRSNT_NODEF;

   /* Set local pointer to user part */
   SO_SIPURL_FROM_ADDRSPEC(srcSipUrl, srcAddrSpec);
   SO_USER_FROM_SIPURL(userPart, srcSipUrl);
   if (userPart != (TknStrOSXL *)NULLP)
   {
      /* Fill in userInfo from To/From */
      sipUrl->userInfo.pres.pres = PRSNT_NODEF;

      /* Set value type */
      SO_FILL_TKNU8(&sipUrl->userInfo.userType.valueType, SO_VALUE_TOKEN);

      if (soUtlCpyTknStrOSXL(&sipUrl->userInfo.userType.value,
                      userPart, &evnt->memCp)!=ROK )
      {
         RETVALUE(RFAILED);
      }
   }

   /* Fill in the hostPort field */
   sipUrl->hostPort.pres.pres = PRSNT_NODEF;

   ret = soTptSelectServer(ent, cLeg->call->ssapCb, tptProt, &serverCb);
   if (ret != ROK)
     RETVALUE(RFAILED);

   if (ent->s.ua.reCfg.useIpContact == TRUE)
   {
      /* Fill in IP host port */
     ret = soCmTptAddrToHostPort(&sipUrl->hostPort,
                                  &serverCb->localAddr,
                                  evnt);
     if (ret != ROK)
       RETVALUE(RFAILED);
   }
   else
   {
     SO_FILL_TKNU8(&sipUrl->hostPort.host.hostType, SO_HOST_HOSTNAME);

     /* Copy hostname */
     if ( soUtlCpyTknStrOSXL(&sipUrl->hostPort.host.t.hostName,
                          &serverCb->hostName,
                          &evnt->memCp)!=ROK )
      {
         RETVALUE(RFAILED);
      }

      if (serverCb->localAddr.type == CM_TPTADDR_IPV4)
      {
         SO_FILL_TKNU16(&sipUrl->hostPort.port,
                    serverCb->localAddr.u.ipv4TptAddr.port);
      }

#ifdef IPV6_SUPPORTED
      if (serverCb->tptAddr.type == CM_TPTADDR_IPV6)
      {
         SO_FILL_TKNU16(&sipUrl->hostPort.port,
                        serverCb->localAddr.u.ipv6TptAddr.port);
      }     
#endif /* IPV6_SUPPORTED */

   }

   sipUrl->urlParameters.numComp.pres = NOTPRSNT;

   /* so006.201: Set transport param */
   if (tptProt != SO_TRANSPORT_UDP)
   {
      ret = soCmGrowList ((Void ***) &sipUrl->urlParameters.urlParameter,
                          sizeof (SoUrlParameter),
                          &sipUrl->urlParameters.numComp,
                          evnt);
      if (ret != ROK)
        RETVALUE (RFAILED);

      numComp = SO_GET_NUM_COMP (&sipUrl->urlParameters.numComp);

      SO_FILL_TKNU8(
           &sipUrl->urlParameters.urlParameter[numComp - 1]->urlParameterType,
           SO_URLPARAMETER_TRANSPORTPARAM);

      /* so035.201: For a secure call, add transport=tcp */
#ifdef SO_TLS
      if (cLeg->secure == SO_TLS_USER && tptProt == SO_TRANSPORT_TLS)
      {
         SO_FILL_TKNU8(
               &sipUrl->urlParameters.urlParameter[numComp - 1]->t.transportParam.transportParamType,
               SO_TRANSPORT_TCP);
      }
      else
#endif      
      {
         SO_FILL_TKNU8(
               &sipUrl->urlParameters.urlParameter[numComp - 1]->t.transportParam.transportParamType,
               tptProt);
      }
   }

   /* If we support signaling compression, add "sigComp" parameter
    * in contact header */


#ifdef SO_COMPRESS
#ifdef SO_UA
   if ((ent->entityType == LSO_ENT_UA) &&
       (ent->s.ua.reCfg.sigCompSupp))
   {
      ret = soCmGrowList ((Void ***) &sipUrl->urlParameters.urlParameter,
                          sizeof (SoUrlParameter),
                          &sipUrl->urlParameters.numComp,
                          evnt);
      if (ret != ROK)
        RETVALUE (RFAILED);

      numComp = SO_GET_NUM_COMP (&sipUrl->urlParameters.numComp);

      SO_FILL_TKNU8(
           &sipUrl->urlParameters.urlParameter[numComp - 1]->urlParameterType,
           SO_URLPARAMETER_COMP);

      SO_FILL_TKNU8(
           &sipUrl->urlParameters.urlParameter[numComp - 1]->t.comp.valueType,
           SO_COMP_SIGCOMP);
   }
#endif
#endif

   /* Delete old contact (if any) in cLeg & store the new contact */
   soUtlDelSoContact(&cLeg->storedHdrs.localTrgtURI);
   ret = soUtlCpySoContact(&cLeg->storedHdrs.localTrgtURI, contact, NULLP);

   /* so035.201: Set selfAdded flag to true */
   *selfAdded = TRUE;
   RETVALUE(ret);
}




/*
*
*       Fun:   soUtlAddUnsuppHdrs
*
*       Desc:  This function adds an unsupported header to a
*              message.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlAddUnsuppHdr
(
SoEntCb         *ent,       /* Entity Cb */
SoEvnt          *reqEvnt,  /* Rcvd Message */
SoEvnt          *rspEvnt   /* Response Message */
)
#else
PUBLIC S16 soUtlAddUnsuppHdr(ent, reqEvnt, rspEvnt)
SoEntCb         *ent;       /* Entity Cb */
SoEvnt          *reqEvnt;  /* Rcvd Message */
SoEvnt          *rspEvnt;  /* Response Message */
#endif
{
   SoTknStrOSXLLst *supported;   /* List of options supported                */
   SoTknStrOSXLLst *unsupported; /* Supported structure in message           */
   SoTknStrOSXLLst *require;     /* require structure in message             */
   TknU16          *numComp;     /* Pointer to numComp token in require list */
   TknStrOSXL      *option;      /* Option to add to unsupported header      */
   U16             i;            /* Index of message supported list          */
   U16             j;            /* Index of end system supported list       */
   Bool            optionFound;  /* set to true if option found in end sys   */
   S16             ret;          /* value returned by function calls         */

   TRC2(soUtlAddUnsuppHdr);

   if (ent->entityType == SO_ENT_UA)
     supported = &ent->s.ua.supported;
#ifdef SO_NS
   else
     supported = &ent->s.ns.supported;
#endif /* SO_NS */

   if (reqEvnt == NULLP)
     RETVALUE(RFAILED);

   /* Find require header in message */
   if (soCmFindHdrChoice(reqEvnt, (U8 **) &require,
      SO_HEADER_GEN_REQUIRE) != ROK)
   {
      RETVALUE(RFAILED); /* No "Require", therefore no unsupported options! */
   }

   numComp = &(require->numComp);

   /* For each option in the supported list, check to see 
      if it is already in the end entity control block 
      supported list, and if not, add it. */
   for (i = 0; i < SO_GET_NUM_COMP(numComp); i++)
   {
      optionFound = FALSE;
      option      = require->stringList[i];

      for (j = 0;
           j < SO_GET_NUM_COMP(&supported->numComp);
           j++)
      {
         optionFound =
            (U8)(SO_CMP_TKNSTR_LIT(
                 supported->stringList[j],
                 option->val, option->len));
         if (optionFound)
         {
            break;
         }
      }

      /* Option not in end sys CB list, must add it to unsupported list */
      if (!optionFound)
      {

         /* Find unsupported header in message */
         ret = soCmFindHdrChoice(rspEvnt, (U8 **) &unsupported,
                                 SO_HEADER_RSP_UNSUPPORTED);
         if (ret != ROK)
         {
            /* No unsupported headers, must create one */
            if ( soCmCreateHdrChoice(rspEvnt, (U8 **)&unsupported,
                                     SO_HEADER_RSP_UNSUPPORTED)!=ROK )
            {
               RETVALUE(RFAILED);
            }
         }

         if ( soCmGrowList((Void ***)&unsupported->stringList,
                           sizeof(TknStrOSXL),
                           &unsupported->numComp,
                           rspEvnt)!=ROK )
            RETVALUE(RFAILED);


         if (soUtlCpyTknStrOSXL(
               unsupported->stringList[unsupported->numComp.val - 1],
               option,
               &(rspEvnt->memCp)) != ROK)
            RETVALUE(RFAILED);

      }
   }

   RETVALUE(ROK);
} /* end of soUtlAddUnsuppHdrs */

#endif /* SO_UA */





#ifdef SO_SESSTIMER
/*****************************************************************************
*
*       Fun:    soUtlAddMinSeHdr
*
*       Desc:   Adds the configured Min-SE into the event structure.
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   po_core.c
*
*****************************************************************************/
#ifdef ANSI
PUBLIC S16 soUtlAddMinSeHdr
(
SoEntCb         *ent,       /* Entity Cb */
SoEvnt          *evnt      /* Event */
)
#else
PUBLIC S16 soUtlAddMinSeHdr (ent, evnt)
SoEntCb         *ent;       /* Entity Cb */
SoEvnt          *evnt;      /* Event */
#endif /* ANSI */
{  

   SoMinSE   *minSe;
   S16   ret;
  
   TRC2(soUtlAddMinSeHdr);

   ret = ROK;

   /* Add the session expires header to the message */
   ret = soCmCreateHdrChoice(evnt, (U8 **)&minSe,
                                SO_HEADER_GEN_MINSE);
   if (ret != ROK)
   {
      RETVALUE(ret);
   }

   minSe->deltaSeconds.pres = PRSNT_NODEF;
   minSe->deltaSeconds.val = ent->reCfg.minSe;

   RETVALUE(ROK);
   
} /* end of soUtlAddMinSeHdr */

#endif /* SO_SESSTIMER */






/*
*
*       Fun:   soUtlAddRSeqHdr
*
*       Desc:  This function generates a RSeq header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  sohdrutl.c
*
*/

#ifdef ANSI
PUBLIC S16  soUtlAddRSeqHdr
(
SoEvnt   *evnt,    /* Event Cb */
U32      rSeqVal   /* RSeq value */
)
#else
PUBLIC S16 soUtlAddRSeqHdr(evnt, rSeqVal)
SoEvnt   *evnt;    /* Event Cb */
U32      rSeqVal;  /* RSeq value */
#endif
{
   TknU32      *rSeq;      /* RSeq header field to create      */
   S16         ret;        /* value returned by function calls */

   TRC2(soUtlAddRSeqHdr);

   /* Find rSeq header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &rSeq,
                                   SO_HEADER_GEN_RSEQ);
   if (ret != ROK)
   {
      /* No rSeq header, must create one */
      if ( soCmCreateHdrChoice(evnt, (U8 **) &rSeq,
                                  SO_HEADER_GEN_RSEQ) !=ROK )
      {
        RETVALUE(SOT_ERR_ADD_HDR_FAILED);
      }

      rSeq->pres = PRSNT_NODEF;
      rSeq->val  = rSeqVal;
   }

   RETVALUE(SOT_ERR_NOERR);

} /* end of soUtlAddRSeqHdr */





/*
*
*       Fun:   soUtlAddRAckHdr
*
*       Desc:  This function generates a RAck header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlAddRAckHdr
(
SoEvnt      *evnt,     /* Event Cb */
SoCSeq      *cSeq,     /* CSeq Value */
U32         rSeqVal    /* RSeq Value */
)
#else
PUBLIC S16 soUtlAddRAckHdr(evnt, cSeq, rSeqVal)
SoEvnt      *evnt;     /* Event Cb */
SoCSeq      *cSeq;     /* CSeq Value */
U32         rSeqVal;   /* RSeq Value */
#endif
{
   SoRAck      *rAck;      /* RAck header field to create      */
   S16         ret;        /* value returned by function calls */

   TRC2(soUtlAddRAckHdr);

    /* Find rAck header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &rAck,
                           SO_HEADER_GEN_RACK);
   if (ret == ROK)
   {
      /* RAck header already present */
      RETVALUE(ROK);
   }

   /* No rAck header, must create one */
   if ( soCmCreateHdrChoice(evnt, (U8 **) &rAck,
         SO_HEADER_GEN_RACK)!=ROK )
   {
      RETVALUE(RFAILED);
   }


 
   /* Set RAck CSeq Val from CSeq header */
   SO_FILL_TKNU32(&rAck->cSeqNum, cSeq->cSeqVal.val);


   /* Set RAck method type */
   SO_FILL_TKNU8(&rAck->method.type, cSeq->method.type.val);

   /* Copy method into rAck */
   switch (cSeq->method.type.val)
   {
      case SO_METHOD_METHODSTD:
         SO_FILL_TKNU8(&rAck->method.t.std, cSeq->method.t.std.val);
         break;

      case SO_METHOD_EXTENSIONMETHOD:
         ret = soUtlCpyTknStrOSXL(&rAck->method.t.ext, &cSeq->method.t.ext,
                               &evnt->memCp);
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
         break;

      default:
         SODBGP_SO(SO_DBGMASK_CORE, (soCb.init.prntBuf,
                 "soUtlAddRAckHdr: Invalid method type.\n"));
         RETVALUE(RFAILED);
   }

   /* Set seqVal in RAck */
   SO_FILL_TKNU32(&rAck->responseNum, rSeqVal);

   RETVALUE(ROK);
} /* end of soUtlAddRAckHdr */





/*
*
*       Fun:   soUtlStoreAllow
*
*       Desc:  Store Allow entries from incoming message to cLeg
*
*       Ret:   None
*
*       Notes: None
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PUBLIC  S16 soUtlStoreAllow
(
SoEvnt      *evnt,         /* ES for alloc                    */
SoAllow     *allow         /* Allow structure to grow         */
)
#else
PUBLIC  S16 soUtlStoreAllow(evnt, allow)
SoEvnt      *evnt;         /* ES for alloc                    */
SoAllow     *allow;        /* Allow structure to grow         */
#endif
{
   SoAllow  *rcvdAllow;   /* Allow structure in message         */
   U16      i;            /* Index of sip message allow list    */
   S16      ret;          /* value returned by function calls   */

   TRC2(soUtlStoreAllow);

   /* Find allow header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &rcvdAllow,
                           SO_HEADER_GEN_ALLOW);
   if (ret != ROK)
   {
      /* Allow header not present */
      RETVALUE(ROK);
   }

   /* For each method in the Allow hdr, add it to allow list (for this UA) */
   for (i = 0; i < SO_GET_NUM_COMP(&rcvdAllow->numComp); i++)
   {
      switch (rcvdAllow->method[i]->type.val)
      {
         case SO_METHOD_METHODSTD:
            if (soUtlAddAllowMethod(NULLP, allow,
                                    rcvdAllow->method[i]->t.std.val) != ROK)
            {
               RETVALUE(RFAILED);
            }
            break;
         case SO_METHOD_EXTENSIONMETHOD:
            if (soUtlAddAllowMethodExt(NULLP, allow,
                                       rcvdAllow->method[i]->t.ext.val,
                                       rcvdAllow->method[i]->t.ext.len) != ROK)
            {
               RETVALUE(RFAILED);
            }
            break;
         default:
            break;
      }
   }
   RETVALUE(ROK);
} /* end of soPrcMergeAllow */

/*****************************************************************************
*
*       Fun:   soUtlChkOptionTag
*
*       Desc:  This function checks a list of option tags to see if the
*              given option is in the list.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  po_core.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 soUtlChkOptionTag
(
SoEvnt  *evnt,        /* Sip event             */
U16     hdrType,      /* header type           */
U8      *optionTag    /* option tag            */
)
#else
PUBLIC S16 soUtlChkOptionTag(evnt, hdrType, optionTag)
SoEvnt  *evnt;        /* Sip event             */
U16     hdrType;      /* header type           */
U8      *optionTag;   /* option tag            */
#endif
{
   SoTknStrOSXLLst  *lst;        /* option list                        */
   U16              i;           /* option counter                     */
   S16              ret;         /* value returned by function calls   */

   TRC2(soUtlChkOptionTag);

   ret = soCmFindHdrChoice(evnt, (U8 **)&lst, hdrType);
   if (ret != ROK)
   {
      /* Header not found */
      RETVALUE(RFAILED);
   }

   for (i = 0; i < SO_GET_NUM_COMP(&lst->numComp); i++)
   {
      if (SO_CMP_TKNSTR_LIT(lst->stringList[i], optionTag, cmStrlen(optionTag))
                            == TRUE)
      {
         /* Option found */
         RETVALUE(ROK);
      }
   }

   /* Option not found */
   RETVALUE(RFAILED);
} /* end of soUtlChkOptionTag */






/*****************************************************************************
*
*       Fun  : soUtlFindLrInRoute
*
*       Desc : Check if the top route header contains
*              a lr parameter
*
*       Ret  : ROK it is in. 
*              RFAILED not in. 
*
*       Notes: 
*
*
*       File:  sohdrutl.c
*
*****************************************************************************/
#ifdef ANSI
PUBLIC S16 soUtlFindLrInRoute
(
SoRoute    *route    /* Route structure in message */
)
#else
PUBLIC S16 soUtlFindLrInRoute (route)
SoRoute    *route;   /* Route structure in message */
#endif
{
  U32             i;           /* indeax */
  SoUrlParameters *urlParams;  /* URL parameters */
  SoRouteSeq      *routeItem;  /* Route Set Item */


  TRC2(soUtlFindLrInRoute);

  routeItem = (route)->route[0];

  if ((routeItem->pres.pres != PRSNT_NODEF)
      || (routeItem->nameAddr.pres.pres != PRSNT_NODEF)
      || (routeItem->nameAddr.addrSpec.addrSpecType.val != 
          SO_ADDRSPEC_SIPURL)
      || (routeItem->nameAddr.addrSpec.t.sipUrl.pres.pres != 
          PRSNT_NODEF))
    RETVALUE(RFAILED);

  urlParams = &routeItem->nameAddr.addrSpec.t.sipUrl.urlParameters; 

  if (urlParams->numComp.pres != PRSNT_NODEF)
    RETVALUE(RFAILED);

  for (i = 0; i < urlParams->numComp.val; i++)
  {
    if (urlParams->urlParameter[i]->urlParameterType.val ==
        SO_URLPARAMETER_LRPARAM)
      RETVALUE(ROK);
  }

  RETVALUE(RFAILED);

} /* soUtlFindLrInRoute */


/* Added as part of so032.201*/
/*****************************************************************************
*
*       Fun  : soUtlFindLrInReqURI
*
*       Desc : Check if the reqURI contains
*              a lr parameter
*
*       Ret  : ROK it is in. 
*              RFAILED not in. 
*
*       Notes: 
*
*
*       File:  sohdrutl.c
*
*****************************************************************************/
#ifdef ANSI
PUBLIC S16 soUtlFindLrInReqURI
(
SoAddrSpec    *reqURI    /* ReqURI structure in message */
)
#else
PUBLIC S16 soUtlFindLrInReqURI (reqURI)
SoAddrSpec    *reqURI;   /* ReqURI structure in message */
#endif
{
   U32             i;           /* indeax */
   SoUrlParameters *urlParams;  /* URL parameters */
   
   TRC2(soUtlFindLrInReqURI);
   
   urlParams = NULLP;
   
   if( reqURI == NULLP)
      RETVALUE(RFAILED);

   if ((reqURI->addrSpecType.val != SO_ADDRSPEC_SIPURL)
         || (reqURI->t.sipUrl.pres.pres != PRSNT_NODEF))
      RETVALUE(RFAILED);

   urlParams = &reqURI->t.sipUrl.urlParameters; 

   if (urlParams->numComp.pres != PRSNT_NODEF)
      RETVALUE(RFAILED);

   for (i = 0; i < urlParams->numComp.val; i++)
   {
      if (urlParams->urlParameter[i]->urlParameterType.val ==
            SO_URLPARAMETER_LRPARAM)
         RETVALUE(ROK);
   }

   RETVALUE(RFAILED);

} /* soUtlFindLrInReqURI */






/*
*
*       Fun:   soUtlGetMethod
*
*       Desc:  This function generates a CSeq header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: 
*
*       File:  sohdrutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlGetMethod
(
SoEvnt       *evnt,      /* Event cb */
SoExtVal     *method,    /* Method     */
TknStrOSXL   *extMethod   /* Ext Method rcvd in the req (valid only for rsp) */  
)
#else
PUBLIC S16 soUtlGetMethod(evnt, method, extMethod)
SoEvnt       *evnt;      /* Event cb */
SoExtVal     *method;    /* Method     */
TknStrOSXL   *extMethod;  /* Method rcvd in the req (valid only for rsp) */ 
#endif
{
  S16       ret;

  TRC3(soUtlGetMethod);

  if (evnt->eventType.val != SOT_ET_UNKNOWN)
  {
    SO_FILL_TKNU8(&method->type, SO_METHOD_METHODSTD);
    SO_FILL_TKNU8(&method->t.std, evnt->eventType.val);
  }
  else 
  {
    SO_FILL_TKNU8(&method->type, SO_METHOD_EXTENSIONMETHOD);
    if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
    {
      ret = soUtlCpyTknStrOSXL(&method->t.ext, 
                               &evnt->t.request.requestLine.method.t.ext,
                               &evnt->memCp);
    }
    else
    {
      ret = soUtlCpyTknStrOSXL(&method->t.ext, 
                               extMethod,
                               &evnt->memCp);

    }

    if (ret != ROK)
      RETVALUE(RFAILED);
  }
  
  RETVALUE(ROK);
}



/*
*
*       Fun:   soUtlInsertRoute
*
*       Desc:  Removes the existing Route header and 
*              copies the content provided.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  
*
*/
#ifdef ANSI
PUBLIC S16 soUtlInsertRoute
(
SoCLegCb *cLeg,     /* Cleg Cb */
SoEvnt   *evnt     /* Event  */
)
#else
PUBLIC S16 soUtlInsertRoute(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
   S16         ret;
   SoRoute     *route;   /* Route in event */
   U16         hdrIdx;   /* Index of route header in the message */


   TRC2(soUtlInsertRoute);

  /* Find record route  header in the event structure */
  /* so012.201: Reset all route sequences */
  while ((ret = soCmFindHdrChIndex(evnt, (U8 **) &route, &hdrIdx, SO_HEADER_REQ_ROUTE)) == ROK)
  {
    soCmRemoveHdrChoice(evnt, hdrIdx, SO_HEADER_REQ_ROUTE);
  }

  /* Create a new Record Route header */
  if ((cLeg->storedHdrs.route.numComp.pres != NOTPRSNT) &&
      (cLeg->storedHdrs.route.numComp.val != 0))
  {
    if (soCmCreateHdrChoice(evnt, (U8 **) &route,
                             SO_HEADER_REQ_ROUTE) !=ROK )
    {
      RETVALUE(RFAILED);
    }
    /* Copy header from call leg to */
    ret = soUtlCpySoRoute(route, &cLeg->storedHdrs.route,
                        &evnt->memCp);
    if (ret != ROK)
      RETVALUE(RFAILED);
  }

  RETVALUE(ROK);
} /* end of soUtlInsertRoute */








/*
*
*       Fun:   soUtlInsertRecordRoute
*
*       Desc:  Removes the existing Record Route header and 
*              copies the content provided in the call Leg
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  
*
*/
#ifdef ANSI
PUBLIC S16 soUtlInsertRecordRoute
(
SoCLegCb *cLeg,     /* Cleg Cb */
SoEvnt   *evnt     /* Event  */
)
#else
PUBLIC S16 soUtlInsertRecordRoute(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
   S16         ret;
   SoRoute     *route;   /* Route in event */
   U16         hdrIdx;   /* Index of route header in the message */

   TRC2(soUtlInsertRecordRoute);

  /* Find record route  header in the event structure */
  ret = soCmFindHdrChIndex(evnt, (U8 **) &route, &hdrIdx,
                           SO_HEADER_GEN_RECORDROUTE);

  if (ret == ROK)
  {
    /* If the record route in the call leg is empty, remove 
       the existing header */

    cmMemset ((U8 *)route, 0, sizeof (SoRoute)); 

    if ((cLeg->storedHdrs.recordRoute.numComp.pres == NOTPRSNT) ||
        (cLeg->storedHdrs.recordRoute.numComp.val == 0))
    {
      soCmRemoveHdrChoice(evnt, hdrIdx, SO_HEADER_GEN_RECORDROUTE);
      RETVALUE(ROK);
    }

  }
  else
  {
    /* Create a new Record Route header */
    if ((cLeg->storedHdrs.recordRoute.numComp.pres != NOTPRSNT) &&
        (cLeg->storedHdrs.recordRoute.numComp.val != 0))
    {
      if (soCmCreateHdrChoice(evnt, (U8 **) &route,
                               SO_HEADER_GEN_RECORDROUTE) !=ROK )
      {
        RETVALUE(RFAILED);
      }
    }
    else
      RETVALUE(ROK);
  }

  /* Copy header from call leg to */
  ret = soUtlCpySoRoute(route, &cLeg->storedHdrs.recordRoute,
                        &evnt->memCp);
  if (ret != ROK)
    RETVALUE(RFAILED);

  RETVALUE(ROK);
} /* end of soUtlInsertRecordRoute */




/*
*
*       Fun:   soUtlInsertReqURI
*
*       Desc: Inserts Request URI from the call leg to event
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  
*
*/
#ifdef ANSI
PUBLIC S16 soUtlInsertReqURI
(
SoCLegCb *cLeg,     /* Cleg Cb */
SoEvnt   *evnt     /* Event  */
)
#else
PUBLIC S16 soUtlInsertReqURI(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
   S16           ret;
   SoRequestLine *reqLine; 

   TRC2(soUtlInsertReqURI);

   reqLine = &evnt->t.request.requestLine;

    cmMemset ((U8 *)&reqLine->addrSpec, 0, sizeof (SoAddrSpec)); 

   ret = soUtlCpySoAddrSpec(&reqLine->addrSpec, &cLeg->storedHdrs.reqURI,
                            &evnt->memCp);

   RETVALUE(ret);
} /* end of soUtlInsertRecRoute */





/*
*
*       Fun:   soUtlInsertToHdr
*
*       Desc:  This function adds a To header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  po_core.c
*
*/
#ifdef ANSI
/* so014.201: to remove To tag or not */
PUBLIC S16 soUtlInsertToHdr
(
SoCLegCb *cLeg,     /* Cleg Cb */
SoEvnt   *evnt,     /* Event  */
Bool     removeTag  /* Remove To Tag */
)
#else
PUBLIC S16 soUtlInsertToHdr(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
Bool     removeTag;/* Remove To Tag */
#endif
{
   S16         ret;
   SoAddress   *to;      /* Pointer to to header in message       */
   SoAddress   *addr;
   SoAddrParam *param;
   U16 cnt;
   U16 i;
   Bool tagFnd;

   TRC2(soUtlInsertToHdr);

   tagFnd = FALSE;

   /* Copy addr into to header */
   if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
   {
     addr = &cLeg->storedHdrs.remoteAddr;
   }
   else if (evnt->sipMessageType.val == SO_SIPMESSAGE_RESPONSE)
   {
     addr = &cLeg->storedHdrs.localAddr;
   }
   else
     RETVALUE(RFAILED);

   /* Find From header in the event structure */
   ret = soCmFindHdrChoice(evnt, (U8 **) &to,
                           SO_HEADER_GEN_TO);

  /* Find header in message */
  if (to  == NULLP)
  {
    /* Create new to header */
    if ( soCmCreateHdrChoice(evnt, (U8 **) &to,
                             SO_HEADER_GEN_TO)!=ROK )
      {
        RETVALUE(RFAILED);
      }
  }
#if (ERRCLASS & ERRCLS_DEBUG)
  else
  {
    ret = soUtlCmpSoAddress(to, addr);
    if (ret != ROK)
    {
      /* so026.201: Correcting debug print */
      SOLOGERROR(ERRCLS_DEBUG, ESO319, (ErrVal) ERRZERO,
                 "soUtlInsertToHdr: Invalid To Hdr");
      RETVALUE(RFAILED);
    }
  }
#endif

  if (soUtlCpySoAddress(to, addr, &evnt->memCp)!=ROK )
  {
    RETVALUE(RFAILED);
  }

   /* so006.201, so009.201 so014.201: If to tag is present and
         removeTag is TRUE, delete the to tag */
   if (removeTag == TRUE && to->addrParams.numComp.pres != NOTPRSNT) 
   {
      for (cnt = 0; cnt < to->addrParams.numComp.val; cnt++) 
      {
         param = to->addrParams.addrParam[cnt];
         if ((param->addrParamType.pres != NOTPRSNT) && 
             (param->addrParamType.val == SO_ADDRPARAM_TAGPARAM))
         {  
            tagFnd = TRUE;
            break;
         }
      }

      if (tagFnd == TRUE)
      {
         /* Move entries in header sequence */
         for (i = cnt; i < (to->addrParams.numComp.val - 1); i++)
            to->addrParams.addrParam[i] = to->addrParams.addrParam[i+1];;

         to->addrParams.addrParam[to->addrParams.numComp.val-1] = 
            to->addrParams.addrParam[cnt];

         soCmShrinkList((Void ***)&to->addrParams.addrParam, sizeof(SoAddrParam),
                     &to->addrParams.numComp, evnt);
      }
   }

  RETVALUE(ROK);
} /* end of soUtlInsertToHdr */




/*
*
*       Fun:   soUtlInsertFromHdr
*
*       Desc:  This function adds a From header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  po_core.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlInsertFromHdr
(
SoCLegCb *cLeg,     /* Cleg Cb */
SoEvnt   *evnt     /* Event  */
)
#else
PUBLIC S16 soUtlInsertFromHdr(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
   S16         ret;
   SoAddress   *from;      /* Pointer to to header in message       */
   SoAddress   *addr;      /* Address */

   TRC2(soUtlInsertFromHdr);

   /* Copy addr into to header */
   if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
   {
     addr = &cLeg->storedHdrs.localAddr;
   }
   else if (evnt->sipMessageType.val == SO_SIPMESSAGE_RESPONSE)
   {
     addr = &cLeg->storedHdrs.remoteAddr;
   }
   else
     RETVALUE(RFAILED);


  /* Find From header in the event structure */
  ret = soCmFindHdrChoice(evnt, (U8 **) &from,
                          SO_HEADER_GEN_FROM);

  /* Find header in message */
  if (from  == NULLP)
  {
    /* Create new to header */
    if ( soCmCreateHdrChoice(evnt, (U8 **) &from,
                             SO_HEADER_GEN_FROM)!=ROK )
      {
        RETVALUE(RFAILED);
      }
  }
#if (ERRCLASS & ERRCLS_DEBUG)
  else
  {
    ret = soUtlCmpSoAddress(from, addr);
    if (ret != ROK)
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO320, (ErrVal) ERRZERO,
                 "soUtlInsertFromHdr: Invalid From Hdr");
      RETVALUE(RFAILED);
    }
  }
#endif

  if (soUtlCpySoAddress(from, addr, &evnt->memCp)!=ROK )
  {
    RETVALUE(RFAILED);
  }

  RETVALUE(ROK);
} /* end of soUtlInsertFromHdr */





/*
*
*       Fun:   soUtlInsertCallId
*
*       Desc:  This function generates a CallId header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlInsertCallId
(
SoCLegCb   *cLeg,    /* Cleg Cb */
SoEvnt     *evnt     /* Event  */
)
#else
PUBLIC S16 soUtlInsertCallId(cLeg, evnt)
SoCLegCb   *cLeg;    /* Cleg Cb */
SoEvnt     *evnt;    /* Event  */
#endif
{
   TknStrOSXL *callId; /* CallID header field to create    */
   S16        ret;        /* value returned by function calls */

   TRC3(soUtlInsertCallId);

   /* Locate call Id in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &callId,
      SO_HEADER_GEN_CALLID);

   /* If not present, copy from call leg */
   if (ret != ROK)
   {
      /*  create callId */
      if ( soCmCreateHdrChoice(evnt, (U8 **) &callId,
            SO_HEADER_GEN_CALLID)!=ROK )
      {
         RETVALUE(RFAILED);
      }

      if ( soUtlCpyTknStrOSXL(callId, &cLeg->call->callId, &evnt->memCp)!=ROK )
      {
        RETVALUE(RFAILED);
      }

   }

   RETVALUE(ROK);
} /* end of soUtlInsertCallId */





/*
*
*       Fun:   soUtlInsertCSeq
*
*       Desc:  This function generates a CSeq header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: 
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlInsertCSeq
(
SoCLegCb   *cLeg,     /* Cleg Cb */
SoEvnt     *evnt,     /* Event  */
U32        cSeqVal,   /* cSeqVal */
TknStrOSXL *extMethod /* Extension Method value */
)
#else
PUBLIC S16 soUtlInsertCSeq(cLeg, evnt, cSeqVal, extMethod)
SoCLegCb   *cLeg;    /* Cleg Cb */
SoEvnt     *evnt;    /* Event  */
U32        cSeqVal;  /* cSeqVal */
TknStrOSXL *extMethod; /* Extension Method value */
#endif
{
   SoCSeq     *cSeq;   /* CSeq header field to create      */
   S16        ret;     /* value returned by function calls */
   Bool       cSeqFound;
   
   /*so028.201: Multiple Refers in a dialog*/
#ifdef SO_REFER   
   S16        len;     
   CmLList *curNode;
   CmLListCp *subCp;
   SoSubNode *tmpNode;

   subCp = &cLeg->subscCb.subCp;
   curNode = cmLListLast(subCp);
   
#endif /* SO_REFER */

   TRC2(soUtlInsertCSeq);

   cSeqFound = FALSE;

   /* Determine if msg is a request or a response */
   /* Find CSeq header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &cSeq,
      SO_HEADER_GEN_CSEQ);
   if (ret != ROK)
   {
      /*  create cSeq */
      if ( soCmCreateHdrChoice(evnt, (U8 **) &cSeq,
            SO_HEADER_GEN_CSEQ)!=ROK )
      {
         RETVALUE(RFAILED);
      }

      /* Fill Cseq method */
      ret = soUtlGetMethod(evnt, &cSeq->method, extMethod);
      if (ret != ROK)
        RETVALUE(RFAILED);     
   }
   else
     cSeqFound = TRUE;

   /* Fill Cseq value */
   if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
   {
     cSeq->cSeqVal.pres = PRSNT_NODEF;
     if ((evnt->eventType.val != SOT_ET_ACK) &&
         (evnt->eventType.val != SOT_ET_CANCEL))
     {
       cSeq->cSeqVal.val = cLeg->storedHdrs.cSeqHiTx++;
#ifdef SO_REFER
       /*so028.201: Multiple Refers in a dialog*/
       if (curNode != (CmLList *)NULLP)
       {
            tmpNode   = (SoSubNode *)cmLListNode(curNode);

            if ((tmpNode->subId.val == NULLP) && 
                  (tmpNode->type == SO_SUBSC_TYPE_REFER))
            { 
               SOALLOC(&(tmpNode->subId.val), sizeof(SO_MAX_UINTSZ_UA));
               if (tmpNode->subId.val == NULLP)
                  RETVALUE(SOT_ERR_RSRC);

               soUtlIntToStr(cSeq->cSeqVal.val, tmpNode->subId.val,&len);

               SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
               "soUtlInsertCSeq:  +++++++++++++++++++++++++++\n"));
               
               SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
               "soUtlInsertCSeq:  cSeq.val = %lu, subId.val = %s, len = %d.\n", 
               cSeq->cSeqVal.val,tmpNode->subId.val, len));

               SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
               "soUtlInsertCSeq:  +++++++++++++++++++++++++++\n"));

               tmpNode->subId.pres = cSeq->cSeqVal.pres;
               tmpNode->subId.len  = len;
            }
       
       }
#endif /*SO_REFER*/       
     }
     else
     {
       /* If there was no cseq inserted earlier or if the inserted cseq
          was 0 then fill in cSeq based on rcvd cSeq */
       if ((cSeqFound == FALSE) || ((cSeq->cSeqVal.val == 0) &&
                                    (cSeqVal != 0)))
         cSeq->cSeqVal.val = cSeqVal;
     }
   }
   else
   {
     /* For responses Fill value based on request */
     cSeq->cSeqVal.pres = PRSNT_NODEF;
     cSeq->cSeqVal.val = cSeqVal;
   }

   RETVALUE(ROK);
} /* end of soUtlInsertCSeq */








/*
*
*       Fun:   soUtlInsertMaxFwds
*
*       Desc:  This function adds the Max-Forwards header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  po_core.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlInsertMaxFwds
(
SoEntCb    *ent,     /* Entity Cb */
SoEvnt     *evnt     /* Event  */
)
#else
PUBLIC S16 soUtlInsertMaxFwds(ent, evnt)
SoEntCb    *ent;     /* Entity Cb */
SoEvnt     *evnt;    /* Event  */
#endif
{
   TknU32    *maxForwards;    /* maxForwards to be retrieved from message */
   S16       ret;             /* value returned by function calls         */

   TRC2(soUtlInsertMaxFwds);


    /* Determine if msg is a request or a response */
   if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
   {
      /* Find max-forwards header in message */
      ret = soCmFindHdrChoice(evnt, (U8 **) &maxForwards,
         SO_HEADER_REQ_MAXFORWARDS);

      if (ret != ROK)
      {
         /*  create maxForwards */
         if ( soCmCreateHdrChoice(evnt, (U8 **) &maxForwards,
               SO_HEADER_REQ_MAXFORWARDS)!=ROK )
         {
            RETVALUE(RFAILED);
         }

         maxForwards->pres = PRSNT_NODEF;

         if (ent->reCfg.hdrCfg.maxFwd != 0)
           maxForwards->val = ent->reCfg.hdrCfg.maxFwd;
         else
           maxForwards->val = SO_DFLT_MAX_FWDS;
      }
   }

   RETVALUE(ROK);
} /* end of soUtlInsertMaxFwds */


/* so028.201 : added function to add timestamp header in outgoing req */

/*
*
*       Fun:   soUtlInsertTimestamp
*
*       Desc:  This function adds the timestamp header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_core.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlInsertTimestamp
(
SoEntCb    *ent,     /* Entity Cb */
SoEvnt     *evnt     /* Event  */
)
#else
PUBLIC S16 soUtlInsertTimestamp(ent, evnt)
SoEntCb    *ent;     /* Entity Cb */
SoEvnt     *evnt;    /* Event  */
#endif
{
   SoTimestamp *timestamp; /* Timestamp header field to create  */
   Ticks       sysTime;    /* System time for timestamp         */
   S16         ret;        /* value returned by function calls  */

   TRC2(soUtlInsertTimestamp);


    /* Determine if msg is a request or a response */
   if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
   {
      /* Find max-forwards header in message */
      ret = soCmFindHdrChoice(evnt, (U8 **) &timestamp,
               SO_HEADER_GEN_TIMESTAMP);

      if (ret != ROK)
      {
         /* No timestamp header, must create one */
         if ( soCmCreateHdrChoice(evnt, (U8 **) &timestamp,
               SO_HEADER_GEN_TIMESTAMP)!=ROK )
         {
            RETVALUE(RFAILED);
         }
      }

      (Void) SGetSysTime(&sysTime);
      SO_FILL_TKNU16(&timestamp->timestampVal, sysTime);
   }

   RETVALUE(ROK);
} /* end of soUtlInsertTimestamp */



/*
*
*       Fun:   soPrcStripUriParams
*
*       Desc:  This parameter strips illegal parameters from the Request URI.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  po_core.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlStripUriParams
(
SoAddrSpec   *uri     /* URI from which to remove parameters     */
)
#else
PUBLIC S16 soUtlStripUriParams(uri)
SoAddrSpec   *uri;    /* URI from which to remove parameters     */
#endif
{
   SoSipUrl    *sipUrl;      /* SIP URL              */
   U16         i;            /* parameter counter    */
   SoUrlParameters *urlParameters; 
                             /* Pointer to URL Parameters in SIP
                                or TEL URL           */
   S16            idx;          /* parameter counter */
   U16            numCompVal;   /* value of numComp  */
   SoUrlParameter *urlParamItem; /* URL parameter    */
   S16            ret;       /* Return Value */
  
   TRC2(soUtlStripUriParams);

   if (uri == (SoAddrSpec *)NULLP)
   {
      /* Nothing to be done */
      RETVALUE(ROK);
   }

   sipUrl = (SoSipUrl *)NULLP;

#ifdef SO_ENUM
   if ((SO_CMP_TKN_LIT(&uri->addrSpecType, SO_ADDRSPEC_TELURL) == TRUE))
      RETVALUE(ROK);
#endif

   SO_SIPURL_FROM_ADDRSPEC(sipUrl, uri);

   if (sipUrl == (SoSipUrl *)NULLP) 
      /* Nothing to be done */
      RETVALUE(ROK);

   urlParameters = &sipUrl->urlParameters;

   i = 0;

   numCompVal = SO_GET_NUM_COMP(&urlParameters->numComp);

   while (i < numCompVal)
   {
      /* so010.201: Other params should be allowed in Request URI */
      if ((SO_CMP_TKN_LIT(
            &urlParameters->urlParameter[i]->urlParameterType,
            SO_URLPARAMETER_METHOD) == TRUE))
      {
         /* Save current url parameter pointer */
         urlParamItem = urlParameters->urlParameter[i];

         for (idx = i+1; idx < numCompVal; idx ++)
            urlParameters->urlParameter[idx-1] = 
               urlParameters->urlParameter[idx];

         /* Place saved pointer at the bottom for list resize */
         urlParameters->urlParameter[numCompVal - 1] = urlParamItem;

         /* Delete child elements for urlParameter */
         soUtlDelSoUrlParameter(urlParameters->urlParameter[numCompVal - 1]);

         /* Remove this parameter */
         ret = soCmShrinkList((Void ***)&urlParameters->urlParameter,
                        sizeof(SoUrlParameter),
                        &urlParameters->numComp,
                        NULLP);
         if (ret != ROK)
           RETVALUE(RFAILED);

         numCompVal = SO_GET_NUM_COMP(&urlParameters->numComp);
      }
      /* so010.201: Should move to next param if not deleting cunt */
      else
      {
         i++;
      }
   }
   
   RETVALUE(ROK);
} /* end of soUtlStripUriParams */






/*
*
*       Fun:   soUtlChckSipUrls
*
*       Desc:  Checks to see if there are supported URLs in the following:
*              -  Request-URI in REGISTER request.
*              -  Contact header in INVITE, OPTIONS, BYE requests.
*              -  Contact header in 2xx responses.
*              
*              The following URL's are supported:
*              sip - INVITE,BYE,OPTIONS,REGISTER,REFER,SUBSCRIBE,NOTIFY,MESSAGE
*              tel - INVITE,BYE,OPTIONS,REGISTER,REFER,SUBSCRIBE,NOTIFY
*              im  - MESSAGE
*              
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  po_mh.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlChckSipUrls
(
SoEvnt      *evnt  /* Event cb */
)
#else
PUBLIC S16 soUtlChckSipUrls(evnt)
SoEvnt      *evnt; /* Event cb */
#endif
{
   SoContact   *contact;         /* Contact header                    */
   SoAddrSpec  *addrSpec;        /* Address spec in contact           */
   U16         responseClass;    /* response class                    */
   S16         ret;              /* value returned by function calls  */

   TRC2(soUtlChckSipUrls);

   /* Check to see that message method is one of those requiring SIP URLs */
   if ((evnt->eventType.val != SOT_ET_INVITE) &&
       (evnt->eventType.val != SOT_ET_BYE) &&
       (evnt->eventType.val != SOT_ET_OPTIONS) &&
#ifdef SO_EVENT
#ifdef SO_REFER
       (evnt->eventType.val != SOT_ET_REFER) &&
#endif /* SO_REFER */
       (evnt->eventType.val != SOT_ET_SUBSCRIBE) &&
       (evnt->eventType.val != SOT_ET_NOTIFY) &&
#endif /* SO_EVENT */
#ifdef SO_INSTMSG
       (evnt->eventType.val != SOT_ET_MESSAGE) &&
#endif /* SO_INSTMSG */
       (evnt->eventType.val != SOT_ET_REGISTER))
   {
      /* No further checking necessary */
      RETVALUE(ROK);
   }

   /* No checking required for non-200 response */
   if (evnt->sipMessageType.val != SO_SIPMESSAGE_REQUEST)
   {
     /* Determine response class */
     responseClass = evnt->t.response.statusLine.statusCode.val / 100;

     if (responseClass != SO_STACODE_TYPE_SUCCESS)
     {
       RETVALUE(ROK);
     }
   }
   else
   { 
     /* We cannot support absolute URI, i.e. URIs that are not understood */
     if (SO_CMP_TKN_LIT(&evnt->t.request.requestLine.addrSpec.addrSpecType,
                        SO_ADDRSPEC_ABSOLUTEURI) == TRUE)
     {
       RETVALUE(RFAILED);
     }
   
     /* Check request URI in REGISTER request */
     if (evnt->eventType.val == SOT_ET_REGISTER)
     {
       /* Check that request URI is a SIP URL */
       if ((SO_CMP_TKN_LIT(
       &evnt->t.request.requestLine.addrSpec.addrSpecType,
       SO_ADDRSPEC_SIPURL) == TRUE))
      {
         /* Request URI is a SIP URL */
         RETVALUE(ROK);
      }
      else
      {
         /* Request URI is not a SIP URL - this is an error */
         RETVALUE(RFAILED);
      }
     }

     /* Check contact header in all other messages */
     ret = soCmFindHdrChoice(evnt, (U8 **)&contact,
                             SO_HEADER_GEN_CONTACT);
     if (ret != ROK)
     {
        /* No contact header - nothing to check */
        RETVALUE(ROK);
     }

     if (SO_GET_NUM_COMP(&contact->contactItems.numComp) == 0)
     {
        /* No contacts - nothing to check */
        RETVALUE(ROK);
     }

     /* Check that first contact item is a IM/SIP URL for message method, or 
        SIP URL for all other methods */
     SO_ADDRSPEC_FROM_ADDRCH(addrSpec,
                     &contact->contactItems.contactItem[0]->contactAddrChoice);

     if (addrSpec == NULLP)
        RETVALUE (RFAILED);

#ifdef SO_INSTMSG
     if (evnt->eventType.val == SOT_ET_MESSAGE)
     {

        if ((SO_CMP_TKN_LIT(&addrSpec->addrSpecType,
                            SO_ADDRSPEC_SIPURL) == TRUE))
        {
           RETVALUE(ROK); /* IM URL for MESSAGE method, so return OK */
        }
        /* No IM URL, we also want to check if we have a SIP URL */
     }
#endif /* SO_INSTMSG */

     if(addrSpec->addrSpecType.pres !=  PRSNT_NODEF)
        RETVALUE(RFAILED);

     switch(addrSpec->addrSpecType.val)
     {
      case SO_ADDRSPEC_SIPURL:
      case SO_ADDRSPEC_SIPSURL:
         break;

      default:
         /* Non-supported URL - this is an error */
         RETVALUE(RFAILED);
     }
   }

   RETVALUE(ROK);

} /* end of soUtlChckSipUrls */




/*
*
*       Fun:  soUtlChckMandHdrs
*
*       Desc:  Checks that all mandatory headers are present.
*              It also checks that there are no duplicates of
*              headers that may not be duplicated, and that there are no
*              request headers in responses, or response headers in requests.
*              in the message 
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  po_core.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlChckMandHdrs
(
SoEvnt     *evnt     /* Event  */
)
#else
PUBLIC S16 soUtlChckMandHdrs(evnt)
SoEvnt     *evnt;    /* Event  */
#endif
{

  S16          ret;      /* Return Value */
  SoCSeq       *cSeq;    /* pointer to CSeq  */
  U32          methodSum, msgSum; /* Sum of values for mandatory headers */
  SoHeaderSeq  *hdrSeq;
  U32          i;

  TRC3(soUtlChckMandHdrs);

  methodSum = 0;
  msgSum = 0;

  /* Find CSeq header in message */
  ret = soCmFindHdrChoice(evnt, (U8 **) &cSeq,
                          SO_HEADER_GEN_CSEQ);
  if (ret != ROK)
  {
    SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                                    "soMhChckMndHdrs: CSeq not found."));
    RETVALUE(ret);
  }

  /* Check for presence of cSeq method in message */
  if ((cSeq->pres.pres == NOTPRSNT) ||
      (cSeq->method.type.pres == NOTPRSNT) ||
      (cSeq->cSeqVal.pres == NOTPRSNT))
  {
    RETVALUE(RFAILED);
  }


  if (cSeq->method.type.val == SO_METHOD_EXTENSIONMETHOD)
  {
    /* Set methodSum to that for "standard" methods */
    methodSum = SO_MNDSUM_STD;
  }
  else
  {
    if (cSeq->method.t.std.pres == NOTPRSNT)
    {
      RETVALUE(RFAILED);
    }

    switch (cSeq->method.t.std.val)
    {
      case SO_METHODSTD_INVITE:
        methodSum = SO_MNDSUM_INVITE;
        break;
        
#ifdef SO_EVENT
      case SO_METHODSTD_SUBSCRIBE: 
      case SO_METHODSTD_NOTIFY: 
        if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
        {
          methodSum = SO_MNDSUM_EVENT;
          break;
        }
#endif /* SO_EVENT */

      case SO_METHODSTD_ACK:       /* fall through */
      case SO_METHODSTD_OPTIONS:   /* fall through */
      case SO_METHODSTD_BYE:       /* fall through */
      case SO_METHODSTD_CANCEL:    /* fall through */
      case SO_METHODSTD_REGISTER:  /* fall through */
      case SO_METHODSTD_INFO:      /* fall through */
      case SO_METHODSTD_COMET:     /* fall through */
      case SO_METHODSTD_PRACK:     /* fall through */
#ifdef SO_INSTMSG
      case SO_METHODSTD_MESSAGE: 
#endif /* SO_INSTMSG */
#ifdef SO_REFER
      case SO_METHODSTD_REFER:
#endif /* SO_REFER */
        methodSum = SO_MNDSUM_STD; 
        break;
        
        default:
          SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                                          "soMhChckMndHdrs: Invalid method"));
          
    }
  }

  if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
  {
    hdrSeq = &evnt->t.request.request;
  }
  else
  {
    hdrSeq = &evnt->t.response.response;
  }


   /* Loop through headers and build up msgSum */
   msgSum = 0;

   for (i = 0; i < SO_GET_NUM_COMP(&hdrSeq->numComp); i++)
   {
      if (hdrSeq->header[i]->headerType.pres != NOTPRSNT)
      {
         
         switch (hdrSeq->header[i]->headerType.val)
         {
            /* These headers may not be duplicated */
#ifdef SO_EVENT
            case SO_HEADER_REQ_EVENT:
               if (msgSum & SO_MND_EVENT)
                 RETVALUE(RFAILED);
               msgSum |= SO_MND_EVENT;
               break;            
#endif /* SO_EVENT */

            case SO_HEADER_GEN_CALLID:
               if (msgSum & SO_MND_CALLID)
                 RETVALUE(RFAILED);
               msgSum |= SO_MND_CALLID;
               break;

            case SO_HEADER_GEN_CSEQ:
               if (msgSum & SO_MND_CSEQ)
                 RETVALUE(RFAILED);
               msgSum |= SO_MND_CSEQ;
               break;

            case SO_HEADER_GEN_FROM:
               if (msgSum & SO_MND_FROM)
                 RETVALUE(RFAILED);
               msgSum |= SO_MND_FROM;
               break;

            case SO_HEADER_GEN_TO:
               if (msgSum & SO_MND_TO)
                 RETVALUE(RFAILED);
               msgSum |= SO_MND_TO;
               break;

            /* These headers may be duplicated - OR them */
#ifdef SO_EVENT
            case SO_HEADER_GEN_ALLOW_EVENTS:
               /* Allow Event is optional for some methods, only 
                  check for it if specified as required in methodSum*/
               msgSum |= (SO_MND_ALLOW_EVENT & methodSum);
               break;
#endif /* SO_EVENT */

            case SO_HEADER_GEN_VIA:
               msgSum |= SO_MND_VIA;
               break;

            case SO_HEADER_GEN_CONTACT:
               /* Contact is optional for some methods, only 
                  check for it if specified as required in methodSum*/
               msgSum |= (SO_MND_CONTACT & methodSum);
               break;
         }
      }
   }

   if (msgSum == methodSum)
   {
      /* All mandatory headers present and no duplicate headers */
      RETVALUE(ROK);
   }
   else
   {
     if (msgSum > methodSum)
     {
       /* We have enough headers to send a response */
       RETVALUE(ROK);
     }
      /* Some mandatory header not present or duplicated */
      RETVALUE(RFAILED);
   }
}


#ifdef SO_UA
/*
*
*       Fun:   soUtlCheckRequire
*
*       Desc:  This function checks for unsupported options
*              
*
*       Ret:   ROK      There was NO unsupported options
*              RFAILED  SIP Request contains unsupported options
*
*       Notes: None
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlCheckRequire
(
SoEntCb         *ent,         /* Entity Cb */
SoEvnt          *evnt         /* Pointer to complete SIP message   */
)
#else
PUBLIC S16 soUtlCheckRequire(ent, evnt)
SoEntCb         *ent;          /* Entity CB */
SoEvnt          *evnt;         /* Pointer to complete SIP message   */
#endif
{
   SoUACb          *ua;          /* SoUACb containing supported options      */
   SoTknStrOSXLLst *require;     /* require structure in message             */
   TknU16          *numComp;     /* Pointer to numComp token in require list */
   TknStrOSXL      *option;      /* Option to add to unsupported header      */
   U16             i;            /* Index of message supported list          */
   U16             j;            /* Index of end system supported list       */
   S16            optionFound;  /* set to true if option found in NS        */
   Bool            error;        /* set to true if unsupported option reqd   */
   S16             ret;          /* value returned by function calls         */

   TRC2(soUtlCheckRequire);

   /* Find require header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &require,
      SO_HEADER_GEN_REQUIRE);
   if (ret != ROK)
   {
      RETVALUE(ROK); /* No "Require", therefore no unsupported options! */
   }

   ua = &(ent->s.ua);
   numComp = &(require->numComp);

   /* For each option in the supported list, check to see if it is already in
    * the end entity control block supported list, and if not, add it.
    */

   error = FALSE;

   for (i = 0; i < SO_GET_NUM_COMP(numComp); i++)
   {
      optionFound = FALSE;
      option      = require->stringList[i];

      for (j = 0;
           j < SO_GET_NUM_COMP(&ua->supported.numComp);
           j++)
      {
          /* so034.201: Case Sensitivity of Option tag in Require Header
          */

          /* so041.201: Replaced soCmStrcasecmp with SO_CMP_TKNSTR_CAS macro */
          optionFound =
            SO_CMP_TKNSTR_CAS(ua->supported.stringList[j],
                                   option->val, option->len);

          /* so035.201: modified if condition since soCmStrcasecmp return 0 if successful*/
          /* so041.201: Correction after replacing with the macro */
         if (optionFound)
            break;
      }

      /* so041.201: Correction after replacing with the macro */
      if (!optionFound)
         error = TRUE;
   }

   if (error)
      RETVALUE(RFAILED);
   else
      RETVALUE(ROK);
} /* end of soUtlCheckRequire */
#endif /* SO_UA */



/*
*
*       Fun:   soUtlDeleteSigCompRef
*
*       Desc:  This function deletes the parameter "comp=sigComp" from
*              request-URI or TOP route element(which ever is the next
*              hop node).
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:
*
*/

#ifdef ANSI
PUBLIC S16 soUtlDeleteSigCompRef
(
SoEvnt          *evnt         /* Pointer to complete SIP message   */
)
#else
PUBLIC S16 soUtlDeleteSigCompRef (evnt)
SoEvnt          *evnt;         /* Pointer to complete SIP message   */
#endif
{
  S16             ret;
  U16             hdrIdx;
  U16             idx;
  U16             i;
  SoRoute         *route;
  SoAddrSpec      *addrSpec;
  SoUrlParameters *urlParameters;

   TRC3 (soUtlDeleteSigCompRef);

   /*-------- STEP 1: Find Next Hop Node For This Request --------*/
   /*
    * If the request contains "route" header, top "route" header el-
    * ment is our Next hop node. Else, "request-URI" contains our n-
    * ext hop node.
    */
    ret = soCmFindHdrChIndex (evnt, (U8 **) &route, &hdrIdx,
                              SO_HEADER_REQ_ROUTE);
    if (ret == ROK)
    {
     /*--- TOP Route Header Is Our Next Hop Node ---*/
      addrSpec  = &route->route[0]->nameAddr.addrSpec;
    }
    else
    {
     /*-- Request-URI Indicates Our Next Hop Node --*/
      addrSpec = &evnt->t.request.requestLine.addrSpec;
    }

    if ((addrSpec->addrSpecType.val != SO_ADDRSPEC_SIPURL ) &&
        (addrSpec->addrSpecType.val != SO_ADDRSPEC_SIPSURL) &&
        (addrSpec->addrSpecType.val != SO_ADDRSPEC_IMURL)) 
       /*---- Not the format to support sigComp ----*/
        RETVALUE (ROK);

   /* STEP 2:Find If Next Hop Node Supports Signaling Compression */

    urlParameters = &addrSpec->t.sipUrl.urlParameters;

    for (i = 0; i < SO_GET_NUM_COMP (&urlParameters->numComp); i++)
    {
      if (SO_CMP_TKN_LIT (&urlParameters->urlParameter[i]->urlParameterType,
                          SO_URLPARAMETER_COMP) == TRUE)
      {
       /*-- Delete the occurance of sigComp parameter ---*/

        for (idx = i+1; idx < SO_GET_NUM_COMP (&urlParameters->numComp); idx++)
             urlParameters->urlParameter[idx-1] = 
                           urlParameters->urlParameter[idx];

        soCmShrinkList ((Void ***)&urlParameters->urlParameter,
                        sizeof (SoUrlParameter),
                        &urlParameters->numComp,
                        evnt);
        break;
      }
    }

    RETVALUE (ROK);

} /* end of soUtlDeleteSigCompRef */



/*
*
*       Fun:   soUtlGenerateBranchId
*
*       Desc:  This function generates unique branch identifier for
*              each outgoing request message.
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: None
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlGenerateBranchId
(
SoEvnt       *request,    /* SIP Request Message                   */
TknStrOSXL   *toHeader,   /* Normalized "to" header                */
TknStrOSXL   *fromHeader, /* Normalized "from" header              */
TknStrOSXL   *toTag,      /* "To" Tag                              */
U32          cSeqValue,   /* Integer part of "CSeq" header         */
U8           cSeqMethod,  /* Method part of "CSeq" header          */
/*- so021.201: Request URI is also required for branchId calculation -*/
U8           *addr,       /* normalized AddrSpec */ 
U16          addrLen,     /* normalized AddrSpec len */
/* so028.201: Added to include top via element to generate the branchId */
U8           *viaItem,    /* via branch */
U16          viaLen,      /* length */
TknStrOSXL   *branchId    /* Generated Branch Identifier (updated) */
)
#else
PUBLIC S16 soUtlGenerateBranchId (request, toHeader,  fromHeader, 
                                  toTag,   cSeqValue, cSeqMethod, 
                                  addr, addrLen, viaItem, viaLen, branchId)
SoEvnt       *request;    /* SIP Request Message                   */
TknStrOSXL   *toHeader;   /* Normalized "to" header                */
TknStrOSXL   *fromHeader; /* Normalized "from" header              */
TknStrOSXL   *toTag;      /* "To" Tag                              */
U32          cSeqValue;   /* Integer part of "CSeq" header         */
U8           cSeqMethod;  /* Method part of "CSeq" header          */
/*- so021.201: Request URI is also required for branchId calculation -*/
U8           *addr;       /* normalized AddrSpec */ 
U16          addrLen;     /* normalized AddrSpec len */
/* so028.201: Added to include top via element to generate the branchId */
U8           *viaItem;    /* via branch */
U16          viaLen;      /* length */
TknStrOSXL   *branchId;   /* Generated Branch Identifier (updated) */
#endif
{ 
   S16         ret;
   TknStrOSXL  *callIdHeader;

   U8          *tmpPtr;
   U8          *hashKey;
   U16         hashKeyLen;
   U8          hash[SO_HASH_SZ];


#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (toHeader && fromHeader && request && branchId))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO321, (ErrVal) 0, "soUtlGenerateBranchId: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }
#endif

   TRC2(soUtlGenerateBranchId);

   /* 
    * Branch Identifier  is  generated as hash of "Call Id Header" +
    * "To Header" + "From Header" + "CSeq numeric value".
    * Magic cookie "z9hG4bk" is appended to this string to make bra-
    * nch identifier compliant to RFC 3261.
    */

    /*-------- Get CALL Identifier of SIP request message --------*/
      SO_GET_CALLID_FROM_EVENT (request, callIdHeader);
        
    /* 
     * STEP 1:
     * Generate Combined  String of "CallId" + "To" + "From" + "CSeq
     * Val"
     */
     hashKeyLen = callIdHeader->len +   /* CallId header length */
                  toHeader->len     +   /* To header  length    */
                  fromHeader->len   +   /* To header  length    */
                  toTag->len        +   /* To Tag length        */
                  addrLen           +   /* request URI length   */
                                        /* so021.201: Added rURI */
                  viaLen            +   /* so028.201: top via element */
                  sizeof(U32)       +   /* CSeq value length    */
                  sizeof(U8);           /* CSeq method length   */
        
     SOALLOC (&hashKey, hashKeyLen);
     if (hashKey == NULLP)
         RETVALUE (RFAILED);
    
     tmpPtr = hashKey;

     cmMemcpy (tmpPtr, callIdHeader->val, callIdHeader->len);
     tmpPtr += callIdHeader->len;

     cmMemcpy (tmpPtr, toHeader->val,     toHeader->len);
     tmpPtr += toHeader->len;

     cmMemcpy (tmpPtr, fromHeader->val,   fromHeader->len);
     tmpPtr += fromHeader->len;

     if (toTag->val)
     {
       cmMemcpy (tmpPtr, toTag->val, toTag->len);
       tmpPtr += toTag->len;
     }

    /* so021.201: Added RequestURI as well */
     if (addr)
     {
       cmMemcpy (tmpPtr, addr, addrLen);
       tmpPtr += addrLen;
     }

     /* so028.201: Added to include top via element to generate the branchId */
     if (viaItem)
     {
       cmMemcpy (tmpPtr, viaItem, viaLen);
       tmpPtr += viaLen;
     }

     cmMemcpy (tmpPtr, (U8 *)&cSeqValue,  sizeof (U32));
     tmpPtr += sizeof (U32);

     cmMemcpy (tmpPtr, (U8 *)&cSeqMethod, sizeof (U8));
        
    /*------ STEP 2: Generate HASH for the combined string -------*/

     ret = soCmGenHash (hashKey, hashKeyLen, hash);

     if (ret != ROK)
     {
         SOFREE (hashKey, hashKeyLen);
         RETVALUE (RFAILED);
     }
        
    /*
     * STEP 3: 
     * Set the branch identifier as "Magic Cookie" + "Genetared Hash"
     */
     branchId->pres = PRSNT_NODEF;
     branchId->len    = BRANCH_MAGSTR_SZ + SO_HASH_SZ * 2;

     SOALLOC (&branchId->val, branchId->len);
     if (branchId->val == NULLP)
     {
         SOFREE (hashKey, hashKeyLen);
         RETVALUE (RFAILED);
     }
        
     cmMemcpy ((U8 *) branchId->val, 
               (CONSTANT U8 *)BRANCH_MAGSTR, 
               BRANCH_MAGSTR_SZ);
        
     soCmFillHex ((Txt *) (branchId->val + BRANCH_MAGSTR_SZ), 
                  hash, 
                  SO_HASH_SZ);
        
   SOFREE (hashKey, hashKeyLen);

   RETVALUE (ROK);

} /* end of soUtlGenerateBranchId  */


/*---- so001.201: Get branchId parameter from TOP VIA header -----*/
/*
*
*       Fun:   soUtlGetBranchId
*
*       Desc:  This function gets the parameter "branchId" from TOP
*              via element (if present)
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:
*
*/

#ifdef ANSI
PUBLIC S16 soUtlGetBranchId
(
SoEvnt       *evnt,       /* Pointer to complete SIP message   */
TknStrOSXL   *branchId    /* Branch Identifier (updated)       */
)
#else
PUBLIC S16 soUtlGetBranchId (evnt, branchId)
SoEvnt       *evnt;       /* Pointer to complete SIP message   */
TknStrOSXL   *branchId;   /* Branch Identifier (updated)       */
#endif
{
  S16         ret;
  SoVia       *via;
  SoViaParams *viaParams;
  U16         i;

   TRC3 (soUtlGetBranchId);

    /*--------- Do nothing if VIA element does not exist ---------*/

    ret = soCmFindHdrChoice (evnt, (U8 **) &via, SO_HEADER_GEN_VIA);
    if (ret != ROK)
      RETVALUE (RFAILED);

    if (SO_GET_NUM_COMP (&via->numComp) < 1)
      RETVALUE (RFAILED);
      
   /*-- Find "branchId" parameter in TOP VIA element --*/

    viaParams = &via->viaItem[0]->viaParams;

    for (i = 0; i < SO_GET_NUM_COMP (&viaParams->numComp); i++)
    {
      if (SO_CMP_TKN_LIT (&viaParams->viaParam[i]->viaParamType,
                          SO_VIAPARAM_VIABRANCH) == TRUE)
      {
          branchId->pres = PRSNT_NODEF;

          branchId->len = viaParams->viaParam[i]->t.viaBranch.len;

          SOALLOC (&branchId->val, branchId->len);

          if (branchId->val == NULLP)
             RETVALUE (RFAILED);

          cmMemcpy ((U8 *)branchId->val,
                    (U8 *)viaParams->viaParam[i]->t.viaBranch.val,
                     branchId->len);

          RETVALUE (ROK);
      }
    }

    RETVALUE (RFAILED);

} /* end of soUtlGetBranchId */




/*
*
*       Fun:   soUtlDeleteBranchId
*
*       Desc:  This function deletes the parameter "branchId" from TOP
*              via element (if present)
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:
*
*/

#ifdef ANSI
PUBLIC S16 soUtlDeleteBranchId
(
SoEvnt          *evnt         /* Pointer to complete SIP message   */
)
#else
PUBLIC S16 soUtlDeleteBranchId (evnt)
SoEvnt          *evnt;         /* Pointer to complete SIP message   */
#endif
{
  S16         ret;
  SoVia       *via;
  SoViaParams *viaParams;
  U16         idx;
  U16         i;

   TRC3 (soUtlDeleteBranchId);

    /*--------- Do nothing if VIA element does not exist ---------*/

    ret = soCmFindHdrChoice (evnt, (U8 **) &via, SO_HEADER_GEN_VIA);
    if (ret != ROK)
      RETVALUE (ROK);

    if (SO_GET_NUM_COMP (&via->numComp) < 1)
      RETVALUE (ROK);
      
   /*-- Find and delete "branchId" parameter in TOP VIA element --*/

    viaParams = &via->viaItem[0]->viaParams;

    for (i = 0; i < SO_GET_NUM_COMP (&viaParams->numComp); i++)
    {
      if (SO_CMP_TKN_LIT (&viaParams->viaParam[i]->viaParamType,
                          SO_VIAPARAM_VIABRANCH) == TRUE)
      {
         /*-- Delete the occurance of sigComp parameter ---*/

          for (idx = i+1; idx < SO_GET_NUM_COMP (&viaParams->numComp); idx++)
               viaParams->viaParam[idx-1] = 
                             viaParams->viaParam[idx];

          soCmShrinkList ((Void ***)&viaParams->viaParam,
                          sizeof (SoViaParam),
                          &viaParams->numComp,
                          evnt);
          break;
      }
    }

    RETVALUE (ROK);

} /* end of soUtlDeleteBranchId */



/* so011.201, so014.201: New functions to store the original route and Req URI
   for CANCEL and ACK for 3-6xx response . */

/*
*
*       Fun:   soUtlStoreOrigRoute
*
*       Desc:  This function stores  the original Route list and 
*              Request URI in INVITE transaction CB. The same is
*              used while sending CANCEL/ACK for 3-6xx messages.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  sohdrutl.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlStoreOrigRoute
(
SoTransCb    *transCb,  /* Transaction control block            */
SoEvnt       *request   /* SIP Request message                  */
)
#else
PUBLIC S16 soUtlStoreOrigRoute (transCb, request)
SoTransCb    *transCb;  /* Transaction control block            */
SoEvnt       *request;  /* SIP Request message                  */
#endif
{
   S16          ret;
  SoRoute       *route;

   TRC2(soUtlStoreOrigRoute)
   
   /*----- Copy the request URI in transaction -------*/
   ret = soUtlCpySoAddrSpec (&transCb->origReqURI, 
                             &request->t.request.requestLine.addrSpec,
                             NULLP);
   if (ret != ROK)
     RETVALUE (RFAILED);
   
   /*------- Find the route header in message --------*/
    ret = soCmFindHdrChoice (request, (U8 **)&route, SO_HEADER_REQ_ROUTE);
    if (ret != ROK)
     /*------ Do Nothing ------*/
     RETVALUE (ROK);

   /*----- Copy the route header in transaction ------*/
   ret = soUtlCpySoRoute (&transCb->route, route, NULLP);
   if (ret != ROK)
     RETVALUE (RFAILED);

   RETVALUE (ROK);

} /* soUtlStoreOrigRoute */


#ifdef SO_XX_UPD_LCL_TAGS
/*
*
*       Fun:   soUtlUpdateLclTags
*
*       Desc:  This function handles changed local tags from
*              the user. This provides feature to let user
*              application change the local tag in the first
*              response message.
*
*       Notes:
*
*       File:  sohdrutl.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlUpdateLclTags
(
SoCLegCb *cLeg,     /* Cleg Cb */
SoEvnt   *evnt      /* Event  */
)
#else
PUBLIC S16 soUtlUpdateLclTags(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
   S16         ret;
   SoAddress   *to;      /* Pointer to header in message       */
   SoAddress   *addr; 
   SoAddrSpec  addrTmp;
   SoAddrParam *param;
   SoAddrParam *cLegParam;
   U16 cnt;
   Bool tagFnd;

   TRC2(soUtlUpdateLclTags);

   tagFnd = FALSE;

   /* Check if first response from the user application */
   if (((cLeg->call->ent->reCfg.snd100Always == FALSE)  &&
        (cLeg->clegState == SO_CLEG_STATE_INITIAL))     ||
        (cLeg->clegState == SO_CLEG_STATE_PROCEEDING))
   {
      /* Point to stored local address */
      addr = &cLeg->storedHdrs.localAddr;

      /* Find To header in the event structure */
      ret = soCmFindHdrChoice(evnt, (U8 **) &to,
                              SO_HEADER_GEN_TO);

      /* Find if user filled in To header in the message */
      if (to  == NULLP)
         RETVALUE(ROK);
         
      /* so032.201: To Add DisplayName in To-Header -----------------------------------*/
      if (to->addrCh.addrChType.val == SO_ADDRCH_NAMEADDR)
      {
         if ((to->addrCh.t.nameAddr.pres.pres != NOTPRSNT) &&
               (to->addrCh.t.nameAddr.displayName.displayNameType.pres != NOTPRSNT))
         {
            /*-- Check if local address is NAMEADDR type------------------------------*/
            if (cLeg->storedHdrs.localAddr.addrCh.addrChType.val == SO_ADDRCH_NAMEADDR) 
            {
               /*-- Delete the displayName from local address*/
               soUtlDelSoDisplayName(&cLeg->storedHdrs.localAddr.addrCh.t.nameAddr.displayName);

               /*-- Copy displayName from To header-----------------------------------*/
               if ((ret = soUtlCpySoDisplayName(&cLeg->storedHdrs.localAddr.addrCh.t.nameAddr.displayName, 
                           &to->addrCh.t.nameAddr.displayName, 
                           NULLP)) != ROK)
                  RETVALUE(ret);
            }
            else
               /*-- If local address is ADDRSPEC type------------------------------------*/
            {
               /*-- Copy the addrSpec in addrTmp variable--------------------------------*/
               cmMemcpy((U8 *)&addrTmp, 
                        (U8 *)&(cLeg->storedHdrs.localAddr.addrCh.t.addrSpec), 
                        sizeof(SoAddrSpec));

               cLeg->storedHdrs.localAddr.addrCh.addrChType.val = SO_ADDRCH_NAMEADDR; 

               /*-- Copy the address spec in the nameAddr->addrSpec --*/
               ret = soUtlCpySoAddrSpec(&cLeg->storedHdrs.localAddr.addrCh.t.nameAddr.addrSpec,
                                        &addrTmp,
                                        NULLP);

               /*-- Copy the displayName in local address ----------------------------*/
               ret = soUtlCpySoDisplayName(&cLeg->storedHdrs.localAddr.addrCh.t.nameAddr.displayName, 
                     &to->addrCh.t.nameAddr.displayName, NULLP);

               /*-- Now delete the addrTmp --*/
               soUtlDelSoAddrSpec(&addrTmp);

               RETVALUE(ret);
            }
         }  
      }

      /* To present, check if user filled in local tags */
      if (to->addrParams.numComp.pres != NOTPRSNT)
      {
         for (cnt = 0; cnt < to->addrParams.numComp.val; cnt++)
         {
            param = to->addrParams.addrParam[cnt];
            if ((param->addrParamType.pres != NOTPRSNT) &&
                (param->addrParamType.val == SO_ADDRPARAM_TAGPARAM))
            {
               tagFnd = TRUE;
               break;
            }
         }

         if (tagFnd == TRUE)
         {
            /* User filled tags param found, look for tags stored
               in call leg */
            tagFnd = FALSE;
            if (addr->addrParams.numComp.pres != NOTPRSNT)
            {
               for (cnt = 0; cnt < addr->addrParams.numComp.val; cnt++)
               {
                  cLegParam = addr->addrParams.addrParam[cnt];
                  if ((cLegParam->addrParamType.pres != NOTPRSNT) &&
                      (cLegParam->addrParamType.val == SO_ADDRPARAM_TAGPARAM))
                  {
                     tagFnd = TRUE;
                     break;
                  }
               }

               if (tagFnd == TRUE)
               {
                  if (soUtlDelTknStrOSXL(&cLegParam->t.tagParam) != ROK)
                     RETVALUE(RFAILED);
                  if (soUtlCpyTknStrOSXL(&cLegParam->t.tagParam, &param->t.tagParam, NULLP) != ROK)
                     RETVALUE(RFAILED);

                  /* so012.201: Update local tags in cLeg */
                  if (soUtlDelTknStrOSXL(&cLeg->storedHdrs.localTag) != ROK)
                     RETVALUE(RFAILED);
                  if (soUtlCpyTknStrOSXL(&cLeg->storedHdrs.localTag, &param->t.tagParam, NULLP) != ROK)
                     RETVALUE(RFAILED);
               }
            }
         }
      }
   }

   RETVALUE(ROK);
} /* end of soUtlUpdateLclTags */
#endif /* SO_XX_UPD_LCL_TAGS */

/* so028.201 : Added function to get encoded string of top via Item */
/*
*
*       Fun:   soUtlGetTopViaItem
*
*       Desc:  This function get the encoded string for the top via item
*
*       Notes:
*
*       File:  sohdrutl.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlGetTopViaItem
(
SoEvnt   *evnt,         /* Event  */
U8       **topViaItem,  /* via branch */ 
U16      *len
)
#else
PUBLIC S16 soUtlGetTopViaItem(evnt, topViaItem, len)
SoEvnt   *evnt;         /* Event  */
U8       **topViaItem;  /* via branch */ 
U16      *len;
#endif
{
   SoVia             *via;
   Mem               mem;
   CmAbnfErr         err;  
   Buffer            *hdrBuf;  /* Buffer into which to encode headers   */
   MsgLen            tempLen;
   U8                *viaItem;   /* via branch */ 
   S16               viaLen;
   S16               ret;              /* value returned by function calls  */
   

   mem.region = soCb.init.region;
   mem.pool = soCb.init.pool;

   /* Allocate memory for mBuf */
   if ( SGetMsg(mem.region, mem.pool, (Buffer **) &hdrBuf)!=ROK )
   {
      RETVALUE(RFAILED);
   }

   ret = soCmFindHdrChoice (evnt, (U8 **) &via, SO_HEADER_GEN_VIA);
   if (ret != ROK)
   {
      SPutMsg (hdrBuf); /* so030.201 : free the memory allocated */
      RETVALUE (RFAILED);
   }

   /* Call ABNF encode function */
   ret = cmAbnfEncPduMsg(CM_ABNF_PROT_SIP, (U8 *)via,
                            hdrBuf, &soMsgDefVia, &mem, &err);
   if (ret != ROK)
   {
      SPutMsg (hdrBuf); /* so030.201 : free the memory allocated */
      RETVALUE(RFAILED);
   }

   ret = SFndLenMsg(hdrBuf, &viaLen);
   if (ret != ROK)
   {
      SPutMsg (hdrBuf); /* so030.201 : free the memory allocated */
      RETVALUE(RFAILED);
   }
   ret = SGetSBuf(mem.region, mem.pool, &viaItem, viaLen);
   if (ret != ROK)
   {
      SPutMsg (hdrBuf); /* so030.201 : free the memory allocated */
      RETVALUE(RFAILED);
   }
   ret = SCpyMsgFix(hdrBuf, 0, viaLen, viaItem, &tempLen);
   if ((ret != ROK) || (viaLen != tempLen)) 
   {
      /* cleanup */
      SPutSBuf(mem.region, mem.pool, viaItem, viaLen);       
      SPutMsg (hdrBuf); /* so029.201 : free the memory allocated */
      RETVALUE(RFAILED);
   }
   
   SPutMsg (hdrBuf); /* so029.201 : free the memory allocated */
   *topViaItem = viaItem;
   *len = viaLen;
   
   RETVALUE(ROK);
}

/********************************************************************30**

         End of file:     sohdrutl.c@@/main/2 - Tue Apr 20 12:47:47 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/2      ---         pg    1. Release for 2.1.
/main/2+     so001.201   ps    1. New function to get branchID parameter
                                  from request message.
/main/2+     so006.201   up    1. Set transport type in CONTACT header
                         up    2. If message is CANCEL, remove To tag
/main/2+     so009.201   ab    1. If msg is CANCEL request remove To tag
/main/2+     so010.201   ab    1. Corrected striping off of request uri
                                  parameters.
/main/2+     so011.201   up    1. New functions to store the original 
                                  route and Req URI for CANCEL request.
                         up    2. New function to update the local tags
                                  if provided by the user app.
/main/2+     so012.201   ab    1. Reset all Route sequence in outgoing
                                  requests.
                         up    2. Update local tags in cLeg
/main/2+     so014.201   ps    1. ReqURI/route for INVITE saved in transaction to
                                  be used for CANCEL Request.
                         ab    2. To tag has to be removed in some cases
/main/2+     so021.201   ss    1. Added request URI in branch Id generation
/main/2+     so026.201   ab    1. Correcting debug print
/main/2+     so028.201   ad    1. Multiple Refers in a dialog.
                         ss    2. Added function to add timestamp header
                         ss    3. Added function to return encoded top via item
                                  and used it to generate branchId
/main/2+     so029.201   ss    1. Free the memory allocated
/main/2+     so030.201   ss    1. Free the memory allocated
/main/2+     so032.201   ng   1. Adding displayName in To-Header in the first response message.(ms)
                         ng   2. Added a function to check for lr (aj)    
/main/2+     so034.201   ng    1. Added function to check case-sensitivity of Option tag in Require Header(ms)
/main/2+     so035.201   ng    1. In function soUtlAddContactHdr checking 
                                  if Contact was added by the Stack.(ab)
                         ng    2. Modified if condition since soCmStrcasecmp 
                                  return 0 if successful
/main/2+     so039.201   ng    1. Fix for mem leak. Delete old contact (if any) in cLeg 
/main/2+     so041.201   ng    1. Replaced soCmStrcasecmp with SO_CMP_TKNSTR_CAS macro 
*********************************************************************91*/
