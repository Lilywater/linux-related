/**********************************************************************

         (c) COPYRIGHT 1989-2003 by 
         Beijing Xinwei Telecom Technology co., ltd. ShenZhen R&D center
         All rights reserved.

     
**********************************************************************/

/**********************************************************************

     Name:     so_dbg.c 

     Type:     C source file

     Desc:     C code for general, SAP and entity configuration 

     Create :  2006-05-11 chendh
     

**********************************************************************/

/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lhi.h"           /* HIT LM interface defines        */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "cst.h"           /* Compression module define       */
#include "so_cm.h"         /* SIP layer utility functions     */
#include "so.h"            /* SIP Layer defines               */
#include "cm_mem.h"        /* Common memory manager */ 
#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */

#ifdef SSI_WITH_CLI_ENABLED
#include "clishell.h"      /* XOS header */
#endif

#ifdef CP_UA_IF_TYPE_SAG
#include "../../../../sag/sagCliShell.h"    /* SAG header */
#endif

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lhi.x"           /* HIT LM interface defines        */
#include "lso.x"           /* Layer management SIP            */
#include "cst.x"           /* Compression module              */
#include "sot.x"           /* SOT interface defines           */
#include "so_tcm.x"        /* Transport module structures     */
#include "so_cm.x"         /* SIP layer utility functions     */
#include "so.x"
#include "cm_mem.x"        /* Common memory manager */ 
#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */


#ifdef CP_UA_IF_TYPE_SAG
#define XVOID   _VOID
#define XU32    _UINT
#define XS32    _INT
#define XCHAR   _CHAR

#define XOS_CliExtPrintf   CLI_EXT_Printf
#endif


#if defined(SSI_WITH_CLI_ENABLED) || defined(CP_UA_IF_TYPE_SAG)

/***************************************************************/
/*             Private Function Prototypes                     */
/***************************************************************/
PRIVATE Void soPrintGenCfg(CLI_ENV *pCliEnv);

/********************************************************************
 *
 *       Fun:   soPrintSoCb
 *
 *       Desc:  Interface show Functions to OAM
 *
 *       Ret:   RETVOID
 *
 *       Notes: 
 *
 ********************************************************************/
XVOID soPrintSoCb(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
	TskInit *pInit = &(soCb.init);

    XOS_CliExtPrintf(pCliEnv, "[SIP] SOCB : \r\n");

#ifdef SS_MULTIPLE_PROCS
    XOS_CliExtPrintf(pCliEnv, "[SIP] TskInit : \r\n"
                              "     proc                : %d\r\n", pInit->proc);
#endif /* SS_MULTIPLE_PROCS */

	XOS_CliExtPrintf(pCliEnv, "[SIP] TskInit : \r\n"
	                          "     ent                 : %d\r\n"
	                          "     inst                : %d\r\n",
	    pInit->ent, pInit->inst);
	
	XOS_CliExtPrintf(pCliEnv, "[SIP] TskInit : \r\n"
	                          "     reason              : %d\r\n"
                           	  "     cfgDone             : %d\r\n"
                          	  "     acnt                : %d\r\n"
                          	  "     usta                : %d\r\n"
                          	  "     trc                 : %d\r\n",
		pInit->reason, pInit->cfgDone, pInit->acnt, pInit->usta, pInit->trc);

#ifdef DEBUGP
	XOS_CliExtPrintf(pCliEnv, "[SIP] TskInit : \r\n"
	                          "     dbgMask             : %d\r\n"
	                          "     prntBuf             : \"%s\"\r\n", 
		pInit->dbgMask, pInit->prntBuf);
#endif

	XOS_CliExtPrintf(pCliEnv, "\r\n[SIP] GENCFG : \r\n");
	soPrintGenCfg(pCliEnv);	
}

/********************************************************************
 *
 *       Fun:   PrintSSapCfg
 *
 *       Desc:  Interface command Functions to OAM
 *
 *       Ret:   RETVOID
 *
 *       Notes: 
 *
 ********************************************************************/
PRIVATE Void PrintSSapCfg(CLI_ENV *pCliEnv,SoSSapCfg *pCfg)
{
	XOS_CliExtPrintf(pCliEnv, "[SIP] SoSSapCfg : \r\n"
	                          "     sSapId              : %d\r\n"
	                          "     sel                 : %d\r\n"
	                          "     prior               : %d\r\n"
	                          "     route               : %d\r\n"
	                          "     entId               : %d\r\n",
								pCfg->sSapId,pCfg->sel,pCfg->prior,pCfg->route,pCfg->entId);
	return;
}

/********************************************************************
 *
 *       Fun:   PrintSSapSts
 *
 *       Desc:  Interface command Functions to OAM
 *
 *       Ret:   RETVOID
 *
 *       Notes: 
 *
 ********************************************************************/
PRIVATE Void PrintSSapSts(CLI_ENV *pCliEnv,SoSSapSts *pSts)
{
	XOS_CliExtPrintf(pCliEnv, "[SIP] SoSSapSts: \r\n"
	                          "     sSapId              : %d\r\n"
	                          "     callsTx             : %d\r\n"
	                          "     callsRx             : %d\r\n"
	                          "     numLocReq           : %d\r\n"
	                          "     numRegReq           : %d\r\n",
								pSts->sSapId,pSts->callsTx,pSts->callsRx,pSts->numLocReq,pSts->numRegReq);
	return;
}

/********************************************************************
 *
 *       Fun:   PrintPst
 *
 *       Desc:  Interface command Functions to OAM
 *
 *       Ret:   RETVOID
 *
 *       Notes: 
 *
 ********************************************************************/
PRIVATE Void PrintPst(CLI_ENV *pCliEnv,Pst *pPst)
{	
	XOS_CliExtPrintf(pCliEnv, "[SIP] POST : \r\n"
	                          "     dstProcId           : %d\r\n"
	                          "     srcProcId           : %d\r\n"
	                          "     dstEnt              : %d\r\n"
	                          "     dstInst             : %d\r\n"
	                          "     srcEnt              : %d\r\n"
	                          "     srcInst             : %d\r\n"
	                          "     prior               : %d\r\n"
	                          "     route               : %d\r\n"
	                          "     event               : %d\r\n"
	                          "     selector            : %d\r\n"
	                          "     intfVer             : %d\r\n",
									pPst->dstProcId,
									pPst->srcProcId,
									pPst->dstEnt,
									pPst->dstInst,
									pPst->srcEnt,
									pPst->srcInst,
									pPst->prior,
									pPst->route,
									pPst->event,
									pPst->selector,
									pPst->intfVer);
	return;

}

/********************************************************************
 *
 *       Fun:   soPrintSapCb
 *
 *       Desc:  Interface command Functions to OAM
 *
 *       Ret:   RETVOID
 *
 *       Notes: 
 *
 ********************************************************************/
XVOID soPrintSapCb(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
	SoSSapCb     *pSsap;
	U16 iArray;
	SoGenCfg    *pCfg = &(soCb.cfg);

    XOS_CliExtPrintf(pCliEnv, "[SIP] SAPCB : \r\n");

	XOS_CliExtPrintf(pCliEnv, "     total               : %d\r\n",pCfg->maxNmbSSaps);

	for(iArray=0; iArray < pCfg->maxNmbSSaps; iArray++)
	{
		pSsap = soCb.soSSapCbLst[iArray];
		if(pSsap == NULLP)
			continue;

		XOS_CliExtPrintf(pCliEnv, "[SIP] SAPCB : ----------sPid(%d)-------\r\n",iArray);
		XOS_CliExtPrintf(pCliEnv, "     sapId               : %d\r\n"
		                          "     suId                : %d\r\n",
												pSsap->sapId,
												pSsap->suId);

		/* print configuration */
		PrintSSapCfg(pCliEnv,&pSsap->cfg);

		/* print statistication */
		PrintSSapSts(pCliEnv,&pSsap->sts);

		/* print status */
		XOS_CliExtPrintf(pCliEnv, "[SIP] SAPCB : \r\n"
		                          "     sts                 : %d\r\n",
												pSsap->sts);

		/* print post */
		PrintPst(pCliEnv,&pSsap->pst);

	}

	return ;
}

/********************************************************************
 *
 *       Fun:   soPrintGenStatic
 *
 *       Desc:  Interface command Functions to OAM
 *
 *       Ret:   RETVOID
 *
 *       Notes: 
 *
 ********************************************************************/
XVOID soPrintGenStatic(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
	SoGenSts *pGenSts = &(soCb.sts);

    XOS_CliExtPrintf(pCliEnv, "[SIP] GENSTATIC : \r\n");

	/* summary statistics */
	XOS_CliExtPrintf(pCliEnv, "[SIP] GENSTATIC summary statistics : \r\n"
		                      "     inRequests          : %d\r\n"
		                      "     outRequests         : %d\r\n"
		                      "     inResponses         : %d\r\n"
		                      "     outResponses        : %d\r\n",
								pGenSts->summSts.sumInReq,
								pGenSts->summSts.sumOutReq,
								pGenSts->summSts.sumInResp,
								pGenSts->summSts.sumOutResp);
	/* method statistics */
	XOS_CliExtPrintf(pCliEnv, "[SIP] GENSTATIC method statistics : \r\n"
		                      "     inINVITE            : %d\r\n"
		                      "     outINVITE           : %d\r\n"
		                      "     inACK               : %d\r\n"
		                      "     outACK              : %d\r\n"
		                      "     inBYE               : %d\r\n"
		                      "     outBYE              : %d\r\n"
		                      "     inCANCEL            : %d\r\n"
		                      "     outCANCEL           : %d\r\n"
		                      "     inOPTIONS           : %d\r\n"
		                      "     outOPTIONS          : %d\r\n"
		                      "     inREGISTER          : %d\r\n"
		                      "     outREGISTER         : %d\r\n"
		                      "     inINFO              : %d\r\n"
		                      "     outINFO             : %d\r\n"
		                      "     inPRACK             : %d\r\n"
		                      "     outPRACK            : %d\r\n",
								pGenSts->methSts.methInInv,pGenSts->methSts.methOutInv,pGenSts->methSts.methInAck,pGenSts->methSts.methOutAck,
								pGenSts->methSts.methInBye,pGenSts->methSts.methOutBye,pGenSts->methSts.methInCanc,pGenSts->methSts.methOutCanc,
								pGenSts->methSts.methInOpt,pGenSts->methSts.methOutOpt,pGenSts->methSts.methInReg,pGenSts->methSts.methOutReg,
								pGenSts->methSts.methInInfo,pGenSts->methSts.methOutInfo,pGenSts->methSts.methOutPrack,pGenSts->methSts.methInPrack);
	#ifdef SO_UPDATE
	XOS_CliExtPrintf(pCliEnv, "     inUPDATE            : %d\r\n"
	                          "     outUPDATE           : %d\r\n",
								pGenSts->methSts.methInUpdate,pGenSts->methSts.methOutUpdate);
	#endif
	#ifdef SO_EVENT
	XOS_CliExtPrintf(pCliEnv, "     inSUSCRIPTION       : %d\r\n"
	                          "     outSUSCRIPTION      : %d\r\n"
	                          "     inNOTIFY            : %d\r\n"
	                          "     outNOTIFY           : %d\r\n",								
								pGenSts->methSts.methInSubsc,pGenSts->methSts.methOutSubsc,pGenSts->methSts.methInNotify,pGenSts->methSts.methOutNotify);
	#endif
	#ifdef SO_INSTMSG
	XOS_CliExtPrintf(pCliEnv, "     inMESSAGE           : %d\r\n"
	                          "     outMESSAGE          : %d\r\n",								
								pGenSts->methSts.methInMessage,pGenSts->methSts.methOutMessage);
	#endif
	#ifdef  SO_REFER
	XOS_CliExtPrintf(pCliEnv, "     inREFER             : %d\r\n"
	                          "     outREFER            : %d\r\n",	
								pGenSts->methSts.methInRefer,pGenSts->methSts.methOutRefer);
	#endif

	/* response statistics */
	XOS_CliExtPrintf(pCliEnv, "[SIP] GENSTATIC response statistics : \r\n"
                    		  "     1xx Ins             : %d\r\n"
                    		  "     1xx Outs            : %d\r\n"
                    		  "     2xx Ins             : %d\r\n"
                    		  "     2xx Outs            : %d\r\n"
                    		  "     3xx Ins             : %d\r\n"
                    		  "     3xx Outs            : %d\r\n"
                    		  "     4xx Ins             : %d\r\n"
                    		  "     4xx Outs            : %d\r\n"
                    		  "     5xx Ins             : %d\r\n"
                    		  "     5xx Outs            : %d\r\n"
                    		  "     6xx Ins             : %d\r\n"
                    		  "     6xx Outs            : %d\r\n\r\n",
					pGenSts->respSts.infoClassIn,pGenSts->respSts.infoClassOut,pGenSts->respSts.successClassIn,pGenSts->respSts.successClassOut,
					pGenSts->respSts.redirClassIn,pGenSts->respSts.redirClassOut,pGenSts->respSts.reqFailClassIn,pGenSts->respSts.reqFailClassOut,
					pGenSts->respSts.srvFailClassIn,pGenSts->respSts.srvFailClassOut,pGenSts->respSts.globalFailClassIn,pGenSts->respSts.globalFailClassOut);
	
	/* error statistics */
	XOS_CliExtPrintf(pCliEnv, "[SIP] GENSTATIC error statistics : \r\n"
                    		  "     user not registered : %d\r\n"
                    		  "     user not available  : %d\r\n"
                    		  "     Invalid response    : %d\r\n"
                    		  "     Invalid request     : %d\r\n"
                    		  "     missing headers rcvd: %d\r\n"
                    		  "     SDP decode failures : %d\r\n"
                    		  "     SIP decode failures : %d\r\n"
                    		  "     SIP encode failures : %d\r\n\r\n",
					pGenSts->errSts.unkwnUser,pGenSts->errSts.usrUnavail,pGenSts->errSts.invalidRsp,pGenSts->errSts.invalidReq,
					pGenSts->errSts.missingMandHdr,pGenSts->errSts.sdpDecFail,pGenSts->errSts.sipDecFail,pGenSts->errSts.sipEncFail);

	/* other statistics */
	XOS_CliExtPrintf(pCliEnv, "[SIP] GENSTATIC other statistics : \r\n"
                    		  "     unsupported URIs                : %d\r\n"
                    		  "     registration timeouts           : %d\r\n"
                    		  "     retransmitted requests received : %d\r\n"
                    		  "     transaction timeouts            : %d\r\n\r\n",
					pGenSts->otherSts.nmbUnsupUri,pGenSts->otherSts.regTO,
					pGenSts->otherSts.reTxReq,pGenSts->otherSts.tranTO);

	return;	
}

/********************************************************************
 *
 *       Fun:   PrintTptAddr
 *
 *       Desc:  Interface command Functions to OAM
 *
 *       Ret:   RETVOID
 *
 *       Notes: 
 *
 ********************************************************************/
PRIVATE Void PrintTptAddr(CLI_ENV *pCliEnv,CmTptAddr *pTptAddr)
{
	unsigned char *pAddr;
	U32 Tmp32;

	if(NULL == pTptAddr)
		return; 

	if(pTptAddr->type != CM_TPTADDR_IPV4)
		return;

	Tmp32 = CM_INET_HTON_U32(pTptAddr->u.ipv4TptAddr.address);
	pAddr = (unsigned char *)&(Tmp32);

	XOS_CliExtPrintf(pCliEnv, "[SIP] IP Addr: %d.%d.%d.%d (%d)\r\n",
								pAddr[0],
								pAddr[1],
								pAddr[2],
								pAddr[3],
								pTptAddr->u.ipv4TptAddr.port);

	return ;

}

/********************************************************************
 *
 *       Fun:   soPrintGenCfg
 *
 *       Desc:  Interface command Functions to OAM
 *
 *       Ret:   RETVOID
 *
 *       Notes: 
 *
 ********************************************************************/
PRIVATE Void soPrintGenCfg(CLI_ENV *pCliEnv)
{
	SoGenCfg    *pCfg = &(soCb.cfg);
	SoGenReCfg  *pReCfg = &(soCb.reCfg); 

	XOS_CliExtPrintf(pCliEnv, "[SIP] GenCfg : \r\n"
	                          "     maxNmbSSaps         : %d\r\n"
	                          "     maxNmbTSaps         : %d\r\n"
	                          "     maxNmbUA            : %d\r\n"
	                          "     maxNmbNS            : %d\r\n"
	                          "     maxNmbRemReg        : %d\r\n"
	                          "     maxNmbActCalls      : %d\r\n"
	                          "     maxTransPerEnt      : %d\r\n"
	                          "     maxPendLocReq       : %d\r\n"
	                          "     locRegSz            : %d\r\n"
	                          "     remRegSz            : %d\r\n",
							   pCfg->maxNmbSSaps, 
							   pCfg->maxNmbTSaps, 
							   pCfg->maxNmbUA,
							   pCfg->maxNmbNS,
							   pCfg->maxNmbRemReg, 
							   pCfg->maxNmbActCalls, 
							   pCfg->maxTransPerEnt,
							   pCfg->maxPendLocReq,
							   pCfg->locRegSz, 
							   pCfg->remRegSz);

#ifdef SO_DNS 
	{
	SoDnsReCfg  *pDnsReCfg = &(soCb.reCfg.dnsReCfg);  

	XOS_CliExtPrintf(pCliEnv, "[SIP] GenCfg : DNS Server Addr\r\n");
	PrintTptAddr(pCliEnv,&(pDnsReCfg->dnsTptAddr));

	XOS_CliExtPrintf(pCliEnv, "[SIP] GenCfg : DNS Local Addr\r\n");
	PrintTptAddr(pCliEnv,&(pDnsReCfg->locAddr));

	XOS_CliExtPrintf(pCliEnv, "[SIP] GenCfg_DNS : \r\n"
	                          "     maxDnsRetry         : %d\r\n"
	                          "     dnsQueryTmr         : %d\r\n"
	                          "     maxDnsCacheExp      : %d\r\n",
							  pDnsReCfg->maxDnsRetry, 
							  pDnsReCfg->dnsQueryTmr.val, 
							  pDnsReCfg->maxDnsCacheExp);
	}
#endif

#ifdef DEBUGP
	XOS_CliExtPrintf(pCliEnv, "[SIP] GenCfg : \r\n"
	                          "     dbgMask             : %d\r\n",
									pCfg->dbgMask);

#endif

#ifdef SO_UA
	XOS_CliExtPrintf(pCliEnv, "[SIP] GenCfg : \r\n"
	                          "     maxNumRegPerEnt     : %d\r\n"
	                          "     maxNumCnctPerEnt    : %d\r\n",
									pCfg->maxNumRegPerEnt,
									pCfg->maxNumCnctPerEnt);
#endif

	/* print POST */
	PrintPst(pCliEnv,&pCfg->lmPst);

	/* transaction timer */
	XOS_CliExtPrintf(pCliEnv, "[SIP] GenCfg timer (100ms) : \r\n"
	                          "     t1                  : %d\r\n"
	                          "     t2                  : %d\r\n"
	                          "     t4                  : %d\r\n",
									pReCfg->tmrReTxCfg.t1,
									pReCfg->tmrReTxCfg.t2,
									pReCfg->tmrReTxCfg.t4);
}

/********************************************************************
 *
 *       Fun:   soPrintMemInfo
 *
 *       Desc:  Interface command Functions to OAM
 *
 *       Ret:   RETVOID
 *
 *       Notes: 
 *
 ********************************************************************/
XVOID soPrintMemInfo(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
    CmMmRegCb   *regionCb;
    U32         idx;
    U32         region = 0;
    TRC1(SRegInfoShow);

    regionCb = osCp.regionTbl[region].regCb;

    XOS_CliExtPrintf(pCliEnv, "\n\nBucket Memory: region %d\n", regionCb->region);
#ifdef SSI_MEM_DEBUG /* xingzhou.xu: added for debug statistics  -- 07/10/2006 */
	XOS_CliExtPrintf(pCliEnv, "==================================================================\n");
    XOS_CliExtPrintf(pCliEnv, "Bucket  Number of Blks configured  Size  Allocated  Max Allocated\n");
	XOS_CliExtPrintf(pCliEnv, "==================================================================\n");
#else	
    XOS_CliExtPrintf(pCliEnv, "====================================================\n");
    XOS_CliExtPrintf(pCliEnv, "Bucket  Number of Blks configured  Size  Allocated\n");
    XOS_CliExtPrintf(pCliEnv, "====================================================\n");
#endif

    for (idx = 0; idx < regionCb->numBkts; idx++)
    {
#ifdef SSI_MEM_DEBUG /* xingzhou.xu: added for debug statistics  -- 07/10/2006 */
      XOS_CliExtPrintf(pCliEnv, "%2d              %8lu          %5lu  %8lu  %8lu\n", 
#else      
      XOS_CliExtPrintf(pCliEnv, "%2d              %8lu          %5lu  %8lu\n", 
#endif /* SSI_MEM_DEBUG */      
              idx, regionCb->bktTbl[idx].numBlks,
              regionCb->bktTbl[idx].size,
              regionCb->bktTbl[idx].numAlloc
#ifdef SSI_MEM_DEBUG /* xingzhou.xu: added for debug statistics  -- 07/10/2006 */
              ,regionCb->bktTbl[idx].maxAlloc
#endif /* SSI_MEM_DEBUG */
               );
    }
    XOS_CliExtPrintf(pCliEnv, "\n---------------\n");
    XOS_CliExtPrintf(pCliEnv, "Heap Memory: region %d\n", regionCb->region);
    XOS_CliExtPrintf(pCliEnv, "Heap Size: %lu\n", regionCb->heapSize);
    XOS_CliExtPrintf(pCliEnv, "Heap Allocated: %lu\n", 
           (regionCb->heapSize - regionCb->heapCb.avlSize));
    XOS_CliExtPrintf(pCliEnv, "Heap Segmented blocks: %d\n",
                    regionCb->heapCb.numFragBlk);

    XOS_CliExtPrintf(pCliEnv, "\nNow, The total alloced mem number is %d\n\n", 
        regionCb->bktTbl[0].numAlloc*regionCb->bktTbl[0].size +
        regionCb->bktTbl[1].numAlloc*regionCb->bktTbl[1].size +
        regionCb->bktTbl[2].numAlloc*regionCb->bktTbl[2].size +
        regionCb->bktTbl[3].numAlloc*regionCb->bktTbl[3].size +
        regionCb->heapSize - regionCb->heapCb.avlSize);

    RETVALUE(ROK);
}

#ifdef DEBUGP
/********************************************************************
 *
 *       Fun:   soSetTraceLevel
 *
 *       Desc:  Interface command Functions to OAM
 *
 *       Ret:   RETVOID
 *
 *       Notes: 
 *
 ********************************************************************/
XVOID soSetTraceLevel(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
	U32 dbgMask;
	U8  *stopstring;

    if (maArgc == 2)
    {
        if (cmStrncmp(ppArgv[1], "help", 4) == 0)
        {
           XOS_CliExtPrintf(pCliEnv, 
                        "SetdbgMask\r\n"
                        "����Э��ջ���Կ���\r\n"
                        "����: dbgMask\r\n\r\n"
                        "0                 ��ʾ�ر�����debug��ӡ\r\n"
                        "0xFFFFFFFF        ��ʾ������debug��ӡ\r\n"
                        "0x00000100        ��ʾSO_DBGMASK_EVNT\r\n"
                        "0x00000200        ��ʾSO_DBGMASK_LI_MBUF\r\n"
                        "0x00000400        ��ʾSO_DBGMASK_CL\r\n"
                        "0x00000800        ��ʾSO_DBGMASK_ABNF_DEC\r\n"
                        "0x00001000        ��ʾSO_DBGMASK_ABNF_ENC\r\n"
                        "0x00002000        ��ʾSO_DBGMASK_DNS\r\n"
                        "0x00004000        ��ʾSO_DBGMASK_NS\r\n"
                        "0x00008000        ��ʾSO_DBGMASK_UA\r\n"
                        "0x00010000        ��ʾSO_DBGMASK_MH\r\n"
                        "0x00020000        ��ʾSO_DBGMASK_ACNT\r\n"
                        "0x00040000        ��ʾSO_DBGMASK_CORE\r\n"
                        "0x00080000        ��ʾSO_DBGMASK_TCM\r\n"
                        "0x00100000        ��ʾSO_DBGMASK_TRANS\r\n"
                        "0x00200000        ��ʾSO_DBGMASK_DLG\r\n"
                        "0x00400000        ��ʾSO_DBGMASK_ERR\r\n");
        }
        else
        {
           dbgMask = (XU32)strtoul(ppArgv[1], &stopstring, 16);
           soCb.init.dbgMask = dbgMask;
           XOS_CliExtPrintf(pCliEnv, "[SIP] Set Trace: dbgMask = 0x%x\r\n",
                               soCb.init.dbgMask);
        }
    }
   else if (maArgc == 1)
	{
		XOS_CliExtPrintf(pCliEnv, "[SIP] Set Trace: no input param\r\n");
	}
	else
   {
        XOS_CliExtPrintf(pCliEnv, "[SIP] Set Trace: the input param number is too much\r\n");
   }
}

/********************************************************************
 *
 *       Fun:   soShowTraceLevel
 *
 *       Desc:  Interface command Functions to OAM
 *
 *       Ret:   RETVOID
 *
 *       Notes: 
 *
 ********************************************************************/
XVOID soShowTraceLevel(CLI_ENV *pCliEnv, XS32 maArgc,XCHAR **ppArgv)
{
	U32 dbgMask, minDbgMask, maxDbgMask, curDbgMask;
	U16 flag;

    minDbgMask = 0x00000100;
    maxDbgMask = 0x00400000;
    curDbgMask = maxDbgMask;
    dbgMask = soCb.init.dbgMask;

    while (curDbgMask >= minDbgMask)
    {
        flag = dbgMask/curDbgMask;

        if (flag > 0)
        {
            switch(curDbgMask)
            {
                case 0x00000100:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_EVNT          : ON\r\n");
                    break;

                case 0x00000200:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_LI_MBUF       : ON\r\n");
                    break;

                case 0x00000400:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_CL            : ON\r\n");
                    break;

                case 0x00000800:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_ABNF_DEC      : ON\r\n");
                    break;

                case 0x00001000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_ABNF_ENC      : ON\r\n");
                    break;

                case 0x00002000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_DNS           : ON\r\n");
                    break;

                case 0x00004000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_NS            : ON\r\n");
                    break;

                case 0x00008000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_UA            : ON\r\n");
                    break;

                case 0x00010000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_MH            : ON\r\n");
                    break;

                case 0x00020000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_ACNT          : ON\r\n");
                    break;

                case 0x00040000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_CORE          : ON\r\n");
                    break;

                case 0x00080000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_TCM           : ON\r\n");
                    break;

                case 0x00100000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_TRANS         : ON\r\n");
                    break;

                case 0x00200000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_DLG           : ON\r\n");
                    break;

                case 0x00400000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_ERR           : ON\r\n");
                    break;
            }
        }
        else
        {
            switch(curDbgMask)
            {
                case 0x00000100:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_EVNT          : OFF\r\n");
                    break;

                case 0x00000200:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_LI_MBUF       : OFF\r\n");
                    break;

                case 0x00000400:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_CL            : OFF\r\n");
                    break;

                case 0x00000800:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_ABNF_DEC      : OFF\r\n");
                    break;

                case 0x00001000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_ABNF_ENC      : OFF\r\n");
                    break;

                case 0x00002000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_DNS           : OFF\r\n");
                    break;

                case 0x00004000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_NS            : OFF\r\n");
                    break;

                case 0x00008000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_UA            : OFF\r\n");
                    break;

                case 0x00010000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_MH            : OFF\r\n");
                    break;

                case 0x00020000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_ACNT          : OFF\r\n");
                    break;

                case 0x00040000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_CORE          : OFF\r\n");
                    break;

                case 0x00080000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_TCM           : OFF\r\n");
                    break;

                case 0x00100000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_TRANS         : OFF\r\n");
                    break;

                case 0x00200000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_DLG           : OFF\r\n");
                    break;

                case 0x00400000:
                    XOS_CliExtPrintf(pCliEnv, "SO_DBGMASK_ERR           : OFF\r\n");
                    break;
            }
        }

        dbgMask = dbgMask%curDbgMask;
        curDbgMask = curDbgMask/2;
    }
}
#endif

#endif /*SSI_WITH_CLI_ENABLED || CP_UA_IF_TYPE_SAG*/

/*added by wanglijun for set dbgmask from shell*/
#ifdef SIP_DEBUG
U32 g_soDbgMask = DBGMASK_LI|DBGMASK_UI|DBGMASK_MI|SO_DBGMASK_ERR;
#else
U32 g_soDbgMask = SO_DBGMASK_ERR;
#endif

Void soSetDbgMaskFromShell(U32 dbgMask)
{
  g_soDbgMask = dbgMask;
#ifdef DEBUGP
  soCb.init.dbgMask = g_soDbgMask;
#endif
  RETVOID;
}



