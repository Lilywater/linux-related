/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SIP  Timer Management Module

     Type:    C source file

     Desc:    C source code for SIP

              Timer Management Module

     File:    po_tmr.c

     Sid:      so_tmr.c@@/main/4 - Tue Apr 20 12:47:14 2004

     Prg:     op

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "so.h"            /* SIP layer defines               */
#include "so_trans.h"      /* Transaction module defines      */
#include "so_err.h"        /* SIP error defines               */
#include "so_cm.h"         /* SIP layer utility functions     */
#ifdef SO_UA
#include "so_ua.h"         /* UA  specific defines            */
#endif

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lso.x"           /* Layer management SIP            */
#include "sot.x"           /* SOT interface defines           */
#include "so_tcm.x"        /* Transport module structures     */
#include "so.x"            /* SIP layer structures            */
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* SIP layer utility functions     */
#include "so_cm.x"         /* SIP layer common functions      */
#include "so_dns.x"        /* SIP DNS library                 */
#include "so_cl.x"         /* SIP cache library routines      */
#include "so_lcs.x"         /* SIP Location Services        */
#ifdef SO_UA
#include "so_ua.x"         /* UA  specific structures         */
#endif
/* local defines */

/* local typedefs */

/* local externs */

/* forward references */

/* local function definition */

PRIVATE Void soProcTmr    ARGS ((Ptr cb, S16 tmrEvnt));

/* functions in other modules */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */


/*
*
*       Fun:   soCmInitTimerQueues
*
*       Desc:  Initialize timer queues
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       File:  po_tmr.c
*
*/
#ifdef ANSI
PUBLIC S16 soCmInitTimerQueues
(
Void
)
#else
PUBLIC S16 soCmInitTimerQueues()
#endif
{
   S16         ret;        /* Return value */

   TRC2(soCmInitTimerQueues);

   /* initialize timing queues */

   soCb.tmrInfoCb.soTq100msCp.nxtEnt = 0;
   soCb.tmrInfoCb.soTq100msCp.tmrLen = SO_TQ100MS_SZ;

   soCb.tmrInfoCb.soTq1MinCp.nxtEnt = 0;
   soCb.tmrInfoCb.soTq1MinCp.tmrLen = SO_TQ1MIN_SZ;

   soCb.tmrInfoCb.soTq30MinCp.nxtEnt = 0;
   soCb.tmrInfoCb.soTq30MinCp.tmrLen = SO_TQ30MIN_SZ;


   /* register SO timer s*/
   ret = SRegTmr(soCb.init.ent, soCb.init.inst,
                (S16)SO_TIMERES_100MS , soActvTmr100ms);
   ret = SRegTmr(soCb.init.ent, soCb.init.inst,
                 (S16)SO_TIMERES_1MIN , soActvTmr1Min);
   ret = SRegTmr(soCb.init.ent, soCb.init.inst,
                 (S16)SO_TIMERES_30MIN , soActvTmr30Min);

   RETVALUE(ROK);

} /* soCmInitTimerQueues */



/*
*
*       Fun:   soDeinitTimerQueues
*
*       Desc:  Deinitialize timer queues
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       File:  po_tmr.c
*
*/
#ifdef ANSI
PUBLIC S16 soDeinitTimerQueues
(
Void
)
#else
PUBLIC S16 soDeinitTimerQueues()
#endif
{

   TRC2(soDeinitTimerQueues);

   /* Deinitialize timing queues */

   /* Deregister timer functions */
   SDeregTmr(soCb.init.ent, soCb.init.inst,
            (S16)SO_TIMERES_100MS, soActvTmr100ms);
   SDeregTmr(soCb.init.ent, soCb.init.inst,
            (S16)SO_TIMERES_1MIN, soActvTmr1Min);
   SDeregTmr(soCb.init.ent, soCb.init.inst,
            (S16)SO_TIMERES_30MIN, soActvTmr30Min);

   /* reset all the timer queues */
   (Void)cmMemset((U8 *)&soCb.tmrInfoCb.soTq100msCp, 0, sizeof(CmTqCp));
   (Void)cmMemset((U8 *)&soCb.tmrInfoCb.soTq1MinCp,  0, sizeof(CmTqCp));
   (Void)cmMemset((U8 *)&soCb.tmrInfoCb.soTq30MinCp, 0, sizeof(CmTqCp));
   (Void)cmMemset((U8 *)&soCb.tmrInfoCb.soTq100ms,   0, 
                                       sizeof(CmTqType)* SO_TQ100MS_SZ);
   /* so007.201: Corrected memset problem */
   (Void)cmMemset((U8 *)&soCb.tmrInfoCb.soTq1Min,    0, 
                                        sizeof(CmTqType) * SO_TQ1MIN_SZ );
   (Void)cmMemset((U8 *)&soCb.tmrInfoCb.soTq30Min,   0, 
                                        sizeof(CmTqType) * SO_TQ30MIN_SZ);

   RETVALUE(ROK);

} /* soDeinitTimerQueues */




/*
*
*       Fun:   soSchedTmr
*
*       Desc:  Schedule/Deschedule a timer
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: tmrVal is in units of 500ms
*
*       File:  po_tmr.c
*
*/
#ifdef ANSI
PUBLIC S16 soSchedTmr
(
Ptr          soHandle,     /* Control block */
S16          tmrEvnt,      /* timer event */
Action       action,       /* action -- start/stop/restart */
U32          tmrVal        /* timer value */
)
#else
PUBLIC S16 soSchedTmr (soHandle, tmrEvnt, action, tmrVal)
Ptr          soHandle;     /* Control block */
S16          tmrEvnt;      /* timer event */
Action       action;       /* action -- start/stop/restart */
U32          tmrVal;       /* timer value */
#endif
{
   CmTimer   *tmr;         /* timers array */
   CmTmrArg  arg;          /* timer arguments */
   U16       a;            /* ticks for the queue with biggest period*/
   U16       b;            /* remainder for the queue with the next
                              biggest period */
   CmTqType  *startQ;      /* timing queue control point */
   CmTqCp    *startQCp;    /* timing queue */
   CmTqType  *stopQ;       /* timing queue control point */
   CmTqCp    *stopQCp;     /* timing queue */
   SoTimer   *soTmr;       /* Actual SoTimer inside control block */

   TRC2(soSchedTmr);

   a        = 0;
   startQ   = NULLP;
   startQCp = NULLP;
   stopQ    = NULLP;
   stopQCp  = NULLP;

   if ((action != TMR_STOP) && (tmrVal == 0))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO214, (ErrVal) tmrVal,
                 "soSchedTmr: tmrVal parameter is <= zero\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }

   /*
    * None of the bits from SOTMR_EVNT_IDXOFFSET to
    * 16 (maximum number of bits in tmrEvnt) should be
    * set in tmrEvnt
    */
   if (tmrEvnt & SOTMR_EVNT_IDXMASK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO215, (ErrVal) tmrEvnt,
                 "soSchedTmr: Invalid tmrEvnt passed \n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }

   SODBGP_SO(SO_DBGMASK_CORE, (soCb.init.prntBuf,
             "TIMER: Evnt %d Action %d Value %ld CB %p\n", tmrEvnt, 
             action, tmrVal, (Void *)soHandle));

   switch (tmrEvnt)
   {
      case SO_TMR_CACHE_REGISTER:
         soTmr = &((SoClRegContactEnt *)soHandle)->expireTmr;
         break;
      case SO_TMR_CACHE_REGISTER_RETRY:
         soTmr = &((SoClRegEnt *)soHandle)->retryAfterTmr;
         break;
      case SO_TMR_ENTITY_CONTROL:
         soTmr = &((SoEntCb *)soHandle)->ctrlTmr;
         break;
#ifdef SO_DNS 
      case SO_TMR_DNS_LOOKUP:
         soTmr = &((SoDnsQueryCb *)soHandle)->dnsQueryTmr;
         break;
      case SO_TMR_CACHE_DNS_A:
#ifdef SO_AAAA
      case SO_TMR_CACHE_DNS_AAAA:
#endif /* SO_AAAA */
         soTmr = &((SoClDnsAAnswerRec *)soHandle)->expireTmr;
         break;
      case SO_TMR_CACHE_DNS_SRV:
         soTmr = &((SoDnsSrvAnswerRec *)soHandle)->expireTimer;
         break;
#ifdef SO_ENUM
      case SO_TMR_CACHE_DNS_NAPTR:
         soTmr = &((SoDnsNaptrAnswerRec *)soHandle)->expireTimer;
         break;
#endif /* SO_ENUM */
#endif /* SO_DNS */



     /*------------ Transaction Layer Timers ------------*/

      case SO_TMR_TRANS_A:  /*-- Retransmission Timers --*/
      case SO_TMR_TRANS_E:
      case SO_TMR_TRANS_G:
         soTmr = &((SoTransCb *)soHandle)->retxTmr;
         break;

      case SO_TMR_TRANS_B:  /*--- Transactions Timers ---*/
      case SO_TMR_TRANS_D:
      case SO_TMR_TRANS_F:
      case SO_TMR_TRANS_H:
      case SO_TMR_TRANS_I:
      case SO_TMR_TRANS_J:
      case SO_TMR_TRANS_K:
         soTmr = &((SoTransCb *)soHandle)->transTmr;
         break;
#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))         
      case SO_TMR_TRANS_NATTMR:
         soTmr = &((SoTransCb *)soHandle)->natTmr;
         break;
#endif
     /*------------- Transport Module Timers ------------*/
      case SO_TMR_TCM_BND:
         soTmr = &((SoTSapCb *)soHandle)->bndTmr;
         break;

      case SO_TMR_TCM_IDLE:  /*--- Client IDLE Timer ----*/
         soTmr = &((SoTptClientCb *)soHandle)->tmrNode;
         break;

      case SO_TMR_TCM_CONNECTION: /*- Client Conn Timer -*/
         soTmr = &((SoTptClientCb *)soHandle)->connTmrNode;
         break;

      /* so010.201: Fix to guard opening of tpt srv with a timer */
      case SO_TMR_TCM_OPEN_SRV: /*-- Open Server Timer --*/
         soTmr = &((SoTptServerCb *)soHandle)->opnSrvTmrNode;
         break;

     /*-------------- UA Core Module Timers --------------*/
#ifdef SO_UA
#ifdef SO_RFC_3262
      case SO_TMR_1XX_RETX:
         soTmr = &((SoProvRspCb *)soHandle)->rspCb.soRspRetxTmr;
         break;
      case SO_TMR_1XX_EXPIRY:
         soTmr = &((SoProvRspCb *)soHandle)->rspCb.soRspExpTmr;
         break;
#endif /* SO_RFC_3262 */
      case SO_TMR_UA_CONTACT_EXP:
         soTmr = &((SoRegContactCb *)soHandle)->expiryTmr;
         break;
      case SO_TMR_2XX_RETX:
         soTmr = &((SoCLegCb *)soHandle)->rspCb.soRspRetxTmr;
         break;
      case SO_TMR_2XX_EXPIRY:
         soTmr = &((SoCLegCb *)soHandle)->rspCb.soRspExpTmr;
         break;
      case SO_TMR_EXPIRES:
         soTmr = &((SoCLegCb *)soHandle)->expiresTmr;
         break;
      case SO_TMR_CANCEL:
         soTmr = &((SoCLegCb *)soHandle)->cancelTmrCb.cancelTmr;
         break;
#endif /* SO_UA */
#ifdef SO_UA         
#ifdef SO_EVENT
      case SO_TMR_SUBSC_EXP:
         soTmr = &((SoSubNode *)soHandle)->subscTimer; 
         break;
#endif /* SO_EVENT */
#endif /* SO_UA */         
#ifdef SO_SESSTIMER
      case SO_TMR_SESSION_TIMER:
         soTmr = &((SoCLegCb *)soHandle)->sessTmrCb.sessExpTmr;
         break;
#endif /* SO_SESSTIMER */

#ifdef SO_LCS 
#ifdef SO_NS
      case SO_TMR_LCS_SEARCH:
         soTmr = &((SoLcsSearchRec *)soHandle)->searchTmr;
         break;
#endif /* SO_NS */
#endif /* SO_LCS */

      default:

#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO216, (ErrVal) tmrEvnt,
                   "soSchedTmr: Invalid tmrEvnt passed \n");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         RETVALUE(RFAILED);
         break;
   }

   soTmr->soCbPtr  = (PTR)soHandle;
   tmr = &soTmr->tmr;

   if ((action == TMR_START) || (action == TMR_RESTART))
   {
      if (tmrVal > SO_TMRVAL_300MIN)
      {
         a = (U16)(tmrVal/SO_TMRVAL_30MIN);
         b = (U16)(tmrVal%SO_TMRVAL_30MIN);
         soTmr->timeLeft = b;

         startQCp = &soCb.tmrInfoCb.soTq30MinCp;
         startQ   = soCb.tmrInfoCb.soTq30Min;
      }
      else if (tmrVal > SO_TMRVAL_10MIN)
      {
         a = (U16)(tmrVal/SO_TMRVAL_1MIN);
         b = (U16)(tmrVal%SO_TMRVAL_1MIN);
         soTmr->timeLeft = b;

         startQCp = &soCb.tmrInfoCb.soTq1MinCp;
         startQ   = soCb.tmrInfoCb.soTq1Min;
      }
      else
      {
         soTmr->timeLeft = (U16)tmrVal;
         a = soTmr->timeLeft;
         soTmr->timeLeft = 0;

         startQCp = &soCb.tmrInfoCb.soTq100msCp;
         startQ   = soCb.tmrInfoCb.soTq100ms;
      }
   }

   if ((action == TMR_STOP) || (action == TMR_RESTART))
   {
      stopQCp = soTmr->currentQCp;
      stopQ   = soTmr->currentQ;
   }

   if (action == TMR_STOP)
   {
      /* return ROK if timer has already been stopped.*/     
      if (tmr->tmrEvnt == TMR_NONE)
         RETVALUE(ROK);
      soTmr->timeLeft = 0;
      if (tmrEvnt == (tmr->tmrEvnt & ~SOTMR_EVNT_IDXMASK))
      {
         arg.tq     = stopQ;
         arg.tqCp   = stopQCp;
         arg.timers = tmr;
         arg.cb     = (PTR)soTmr;
         arg.evnt   = NOTUSED;
         arg.wait   = NOTUSED;
         arg.tNum   = 0;
         arg.max    = 1;

         cmRmvCbTq (&arg);
         RETVALUE(ROK);
      }
   }
   else if (action == TMR_START)
   {
      if (tmr->tmrEvnt == TMR_NONE)
      {
         arg.tq     = startQ;
         arg.tqCp   = startQCp;
         arg.timers = tmr;
         arg.cb     = (PTR)soTmr;
         arg.evnt   = tmrEvnt;
         arg.wait   = a;
         arg.tNum   = NOTUSED;
         arg.max    = 1;

         /* Store queue information to use when stopping timer */
         soTmr->currentQ = arg.tq;
         soTmr->currentQCp = arg.tqCp;

         cmPlcCbTq (&arg);
         RETVALUE(ROK);
      }
      else
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO217, (ErrVal) tmr->tmrEvnt,
                   "soSchedTmr: Invalid tmrEvnt passed in TMR_START\n");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      }
   }
   else if (action == TMR_RESTART)
   {
      if ((tmrEvnt == (tmr->tmrEvnt & ~SOTMR_EVNT_IDXMASK)) ||
          (tmr->tmrEvnt == TMR_NONE))
      {
         if (tmr->tmrEvnt != TMR_NONE)
         {
            arg.tq     = stopQ;
            arg.tqCp   = stopQCp;
            arg.timers = tmr;
            arg.cb     = (PTR)soTmr;
            arg.evnt   = NOTUSED;
            arg.wait   = NOTUSED;
            arg.tNum   = 0;
            arg.max    = 1;

            cmRmvCbTq (&arg);
         }

         arg.tq     = startQ;
         arg.tqCp   = startQCp;
         arg.timers = tmr;
         arg.cb     = (PTR)soTmr;
         arg.evnt   = tmrEvnt;
         arg.wait   = a;
         arg.tNum   = NOTUSED;
         arg.max    = 1;

         /* Store queue information to use when stopping timer */
         soTmr->currentQ = arg.tq;
         soTmr->currentQCp = arg.tqCp;

         cmPlcCbTq (&arg);
         RETVALUE(ROK);
      }
   }

#if (ERRCLASS & ERRCLS_DEBUG)
   SOLOGERROR (ERRCLS_DEBUG, ESO218, (ErrVal) tmr->tmrEvnt,
               "soSchedTmr: Invalid Action passed \n");
#endif
   RETVALUE(RFAILED);
} /* end of soSchedTmr */


/**********************************************************
*
*      Fun:    soActvTmr500ms
*
*      Desc:   Invoked by system services to process timers.
*
*              This function is registered during general configuration
*              using SRegTmr and is invoked at the specified period
*              by system services.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  po_tmr.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soActvTmr100ms
(
void
)
#else
PUBLIC S16 soActvTmr100ms ()
#endif
{
   TRC2(soActvTmr100ms)

   cmPrcTmr(&soCb.tmrInfoCb.soTq100msCp, &soCb.tmrInfoCb.soTq100ms[0], (PFV) soProcTmr);

   RETVALUE(ROK);
} /* end of soActvTmr100ms */


/**********************************************************
*
*      Fun:    soActvTmr1Min
*
*      Desc:   Invoked by system services to process timers.
*
*              This function is registered during general configuration
*              using SRegTmr and is invoked at the specified period
*              by system services.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  po_tmr.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soActvTmr1Min
(
void
)
#else
PUBLIC S16 soActvTmr1Min ()
#endif
{
   TRC2(soActvTmr1Min)

   cmPrcTmr(&soCb.tmrInfoCb.soTq1MinCp, &soCb.tmrInfoCb.soTq1Min[0], (PFV) soProcTmr);

   RETVALUE(ROK);
} /* end of soActvTmr1Min */


/**********************************************************
*
*      Fun:    soActvTmr30Min
*
*      Desc:   Invoked by system services to process timers.
*
*              This function is registered during general configuration
*              using SRegTmr and is invoked at the specified period
*              by system services.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  po_tmr.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soActvTmr30Min
(
void
)
#else
PUBLIC S16 soActvTmr30Min ()
#endif
{
   TRC2(soActvTmr30Min)

   cmPrcTmr(&soCb.tmrInfoCb.soTq30MinCp, &soCb.tmrInfoCb.soTq30Min[0], (PFV) soProcTmr);

   RETVALUE(ROK);
} /* end of soActvTmr30Min */

/***********************************************************
*
*      Fun:    soProcTmr
*
*      Desc:   Handle the expiration of a particular timer event
*
*       Ret:   RETVOID
*
*       Notes: This function dispatches the timer event expiry
*              to the appropriate module.
*
*       File:  po_tmr.c
*
***********************************************************/
#ifdef ANSI
PRIVATE Void soProcTmr
(
Ptr              cb,          /* control block using this timer */
S16              tmrEvnt      /* timer event */
)
#else
PRIVATE Void soProcTmr(cb, tmrEvnt)
Ptr              cb;          /* control block using this timer */
S16              tmrEvnt;     /* timer event */
#endif
{
   SoTimer     *soTmr;        /* Timer which expired */
#ifdef SO_SESSTIMER
   SoCLegCb    *cLegCb;       /* CallLeg Control block */
#endif /* SO_SESSTIMER */

   TRC2(soProcTmr);

   soTmr = (SoTimer *)cb;
   if (soTmr->timeLeft > 0)
   {
      /* Reschedule for remainder of time */
      soSchedTmr((Ptr)soTmr->soCbPtr, tmrEvnt, TMR_START, soTmr->timeLeft);
      RETVOID;
   }

   SODBGP_SO(SO_DBGMASK_CORE, (soCb.init.prntBuf,
             "TIMER-EXPIRY: Evnt %d CB %ld\n", tmrEvnt, (U32)(soTmr->soCbPtr)));

   switch (tmrEvnt & SOTMR_EVNT_MODMASK)
   {
#ifdef SO_UA
     /*--- Timer Expiry For Transaction Module ---*/
      case SOTMR_BASE_TRANS:
         soTxnProcTmrExpiry ((Ptr)soTmr->soCbPtr, 
                             (S16)(tmrEvnt & ~SOTMR_EVNT_IDXMASK));
         RETVOID;
         break;
#endif /* SO_UA */
     /*---- Timer Expiry For Transport Module ----*/
      case SOTMR_BASE_TCM:
         soTptProcTmrExpiry ((Ptr)soTmr->soCbPtr,
                             (S16)(tmrEvnt & ~SOTMR_EVNT_IDXMASK));
         RETVOID;
         break;

   } /* End of switch (processing based on module) */

   /* If timer is not handled on a module basis, process individually */
   switch (tmrEvnt)
   {

#ifdef SO_LCS 
#ifdef SO_NS
      case SO_TMR_LCS_SEARCH:
          (Void) soLcsTimer((SoLcsSearchRec *)(soTmr->soCbPtr));
         break;
#endif /* SO_NS */
#endif /* SO_LCS */

      case SO_TMR_CACHE_REGISTER:
         (Void) soClRegTimer((SoClRegContactEnt *)(soTmr->soCbPtr));
         break;
      case SO_TMR_CACHE_REGISTER_RETRY:
         (Void) soClRegRetryTimer((SoClRegEnt *)(soTmr->soCbPtr));
         break;

#ifdef SO_DNS 
#ifdef SO_ENUM
      case SO_TMR_CACHE_DNS_NAPTR:
         (Void) soClDnsNaptrTimer((SoDnsNaptrAnswerRec *)(soTmr->soCbPtr));
         break;
#endif /* SO_ENUM */

      case SO_TMR_CACHE_DNS_SRV:
         (Void) soClDnsSrvTimer((SoDnsSrvAnswerRec *)(soTmr->soCbPtr));
         break;

      case SO_TMR_CACHE_DNS_A:
         (Void) soClDnsATimer((SoClDnsAAnswerRec *)(soTmr->soCbPtr));
         break;

      case SO_TMR_DNS_LOOKUP:
         soDnsModuleTimeoutHandle(NULLP,soTmr->soCbPtr, 
                                  SO_DNS_QUERY_TIMEOUT);
         break;
#endif /* SO_DNS */

      case SO_TMR_ENTITY_CONTROL:
         soTmrEntityControl((SoEntCb *)(soTmr->soCbPtr));
         break;

#ifdef SO_UA
#ifdef SO_RFC_3262
      case SO_TMR_1XX_RETX:
         soUa1xxRetxTimeout((SoProvRspCb *)soTmr->soCbPtr);
         break;
      case SO_TMR_1XX_EXPIRY:
         soUa1xxTmrExpiry((SoProvRspCb *)soTmr->soCbPtr);
         break;
#endif /* SO_RFC_3262 */
      case SO_TMR_UA_CONTACT_EXP:
         soUaRegTimeout((SoRegContactCb *)soTmr->soCbPtr);
         break;
      case SO_TMR_2XX_RETX:
         soUa2xxRetxTimeout((SoCLegCb *)soTmr->soCbPtr);
         break;
      case SO_TMR_2XX_EXPIRY:
         soUa2xxTmrExpiry((SoCLegCb *)soTmr->soCbPtr);
         break;
      case SO_TMR_EXPIRES:
         soUaExpiresTmrExpiry((SoCLegCb *)soTmr->soCbPtr);
         break;
      case SO_TMR_CANCEL:
         soUaCancelTimeout((SoCLegCb *)soTmr->soCbPtr);
         break;
#endif /* SO_UA */
#ifdef SO_UA
#ifdef SO_EVENT
      case SO_TMR_SUBSC_EXP:
         soUaSubscTimerHandle((SoSubNode *)soTmr->soCbPtr, TRUE);
         break;
#endif /* SO_EVENT */
#endif /* SO_UA */

#ifdef SO_SESSTIMER
      case SO_TMR_SESSION_TIMER:
#ifdef SO_UA
         cLegCb = (SoCLegCb *)soTmr->soCbPtr;
         if (cLegCb->call->ent->entityType == LSO_ENT_UA)
            soUaxSessTmrExpiry(cLegCb);
#endif

         break;
#endif

      default:
         /* Timer not handled at all - error */
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO219, (ErrVal) tmrEvnt,
                 "soProcTmr: Invalid timer event\n");
#endif
         break;
    }

    RETVOID;
} /* end of soProcTmr */


/********************************************************************30**

         End of file:     so_tmr.c@@/main/4 - Tue Apr 20 12:47:14 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/4      ---      pg      1. Initial release
           so007.201  ps      1. Corrected memset problem.
/main/4    so010.201  ab      1. Fix to guard opening of tpt srv with a timer
*********************************************************************91*/
