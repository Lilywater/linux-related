/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SIP Management Interface

     Type:    C source file

     Desc:    Code for Management Interface primitives supplied by
              TRILLIUM

     File:    po_mi.c

     Sid:      so_mi.c@@/main/4 - Tue Apr 20 12:46:47 2004

     Prg:     wvdl

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timer library */
#include "cm_hash.h"       /* common hash library */
#include "cm_llist.h"      /* common linked list library */
#include "cm_inet.h"       /* common socket library */
#include "cm_tpt.h"        /* common transport library */
#include "cm_abnf.h"       /* common abnf */
#include "cm_tkns.h"       /* common tokens */
#include "cm_dns.h"        /* common DNS                   */
#include "hit.h"
#include "cm_sdp.h"
#include "cm_dns.h"        /* common DNS                   */
#include "sot.h"
#include "lso.h"
#include "so.h"
#include "so_trans.h"      /* Transaction module defines      */
#include "so_cm.h"
#include "so_err.h"
#ifdef SO_FTHA             /* fault tolerance */
#include "sht.h"           /* SHT interface header file */
#endif /* SO_FTHA */

/* header/extern include files (.x) */
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timer library */
#include "cm_hash.x"       /* common hash library */
#include "cm_llist.x"      /* common linked list library */
#include "cm_inet.x"       /* common socket library */
#include "cm_mblk.x"       /* common mem alloc defines */
#include "cm_abnf.x"       /* common abnf library */
#include "cm_tkns.x"       /* common tokens */
#include "cm_tpt.x"        /* common transport library */
#include "cm_xtree.x"      /* common radix tree */
#include "cm_lib.x"
#include "cm_dns.x"        /* common DNS                   */
#include "hit.x"
#include "cm_sdp.x"
#include "sot.x"
#include "lso.x"
#include "so_tcm.x"        /* tcm functions */
#include "so.x"
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* Utility functions */
#include "so_cl.x"         /* SIP cache */
#include "so_cm.x"         /* SIP common functions */
#include "so_lcs.x"        /* Location service */
#include "so_dns.x"        /* DNS functions */
#include "so_ua.x"         /* UA declarations */
#ifdef SO_FTHA             /* fault tolerance */
#include "sht.x"           /* SHT interface header file */
#endif /* SO_FTHA */
/* so032.201: To compile with multi-threaded encoder/decoder option */
#ifdef SO_ABNF_MT_LIB
#include "so_ed.x"
#endif

/* Public variable declarations */

/* function prototypes */

PRIVATE Void soMiFillResponsePost ARGS((
                Pst    *respPst,
                Pst    *reqPst,
                Header *reqHeader));

PRIVATE S16 soSSapUbndDis      ARGS((SoSSapCb  *ssapCb,
                                    U16 *reason));
PRIVATE S16 soSSapDel          ARGS((SoSSapCb  *ssapCb,
                                    U16 *reason));

PRIVATE S16 soSSapDelAssocTptSrv ARGS((SoSSapCb  *sSapCb,
                                       U32       **tptIdLst,
                                       U8      entId,
                                       U16       *reason));
PRIVATE S16 soSSapAddAssocTptSrv ARGS((SoSSapCb  *sSapCb,
                                       U32       **tptIdLst,
                                       U8       entId,
                                       U16       *reason));

PRIVATE U16 soSSapGrUbndDis    ARGS((ProcId procId, U16 *reason));
PRIVATE S16 soSSapGrDel        ARGS((ProcId procId, U16 *reason));

PRIVATE S16 initPtrArray       ARGS((Ptr        **array,
                                     U16        numEntries));

#ifdef LSO_ACNT
PRIVATE Void soMiAccntRecBuild       ARGS((SoAcntInfo  *acnt,
                                     SoCLegCb    *leg));
PRIVATE Void soMiFreeAcntInfo  ARGS((SoAcnt    *acnt));

#endif /* LSO_ACNT */

PRIVATE S16  soShutdownComplete  ARGS((U16    *reason));
PRIVATE S16  soShutdownReq          ARGS((U16    *reason));

#ifdef SO_FTHA
EXTERN S16 SoMiShtCntrlReq ARGS((Pst *pst, ShtCntrlReqEvnt *reqInfo));
EXTERN S16 SoMiShtCntrlCfm ARGS((Pst *pst, ShtCntrlCfmEvnt *cfmInfo));
#endif /* SO_FTHA */

/* functions */

/******************************************************************
*
*       Fun:   Configuration Request
*
*       Desc:  This function is used by the Layer Management to
*              configure the layer. The SIP layer responds with a
*              Configuration Confirm to the layer manager.
*
*       Ret:   ROK
*
*       Notes: Configuration must be performed in the following
*              sequence:
*              1) General configuration (STGEN)
*              2) Transport sap configuration (STTSAP)
*              3) SIP entity configuration (STSIPENT)
*              4) Session sap configuration (SSAP)
*
*       File:  po_mi.c
*
*******************************************************************/
#ifdef ANSI
PUBLIC S16 SoMiLsoCfgReq
(
Pst     *pst,           /* post structure */
SoMngmt *cfg            /* configuration structure */
)
#else
PUBLIC S16 SoMiLsoCfgReq(pst, cfg)
Pst     *pst;           /* post structure */
SoMngmt *cfg;           /* configuration structure */
#endif
{
   U16          ret;            /* return value */
   U16          reason;         /* result reason */
   Pst          cfmPst;         /* Post structure to use for confirm */

   TRC3(SoMiLsoCfgReq);

   /* initialize result and reason */
   reason = LCM_REASON_NOT_APPL;
   ret    = LCM_PRIM_OK;

   /* debug information */
   SODBGP_SO(DBGMASK_MI, (soCb.init.prntBuf,
                          "\nSM ---CfgReq---> SIP: elmId=%d transId=%ld"
                          " status=%u reason=%u\n",
                          cfg->hdr.elmId.elmnt, cfg->hdr.transId,
                          cfg->cfm.status, cfg->cfm.reason));

   soMiFillResponsePost(&cfmPst, pst, &cfg->hdr);

   /* which configuration element? */
   switch (cfg->hdr.elmId.elmnt)
   {
      case STGEN:
         ret = soGenCfgReq(&cfg->t.cfg, &reason);
         soSendLmCfm(&cfmPst, TCFG, ret, reason, cfg);
         break;

      case STTSAP:
         ret = soTcmTSapCfgReq(&cfg->t.cfg.c.tSapCfg,
            &cfg->t.cfg.r.tSapReCfg, &reason);
         soSendLmCfm(&cfmPst, TCFG, ret, reason, cfg);
         break;

      case STSIPENT:
         ret = soSipEntCfgReq(&cfg->t.cfg, &reason);
         soSendLmCfm(&cfmPst, TCFG, ret, reason, cfg);
         break;

      case STSSAP:
         ret = soSSapCfgReq(&cfg->t.cfg.c.sSapCfg, &reason);
         soSendLmCfm(&cfmPst, TCFG, ret, reason, cfg);
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         SOLOGERROR(ERRCLS_INT_PAR, ESO131, (ErrVal)cfg->hdr.elmId.elmnt,
                    "Invalid element.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         soSendLmCfm(&cfmPst, TCFG,
            LCM_PRIM_NOK, LCM_REASON_INVALID_ELMNT, cfg);
         break;
   }

   /* send confirm */

   RETVALUE(ROK);
} /* SoMiLsoCfgReq */

#ifdef LSO_ACNT


/**********************************************************
*
*       Fun:   soMiFreeAcntInfo
*
*       Desc:  Frees "to" and "from" fields in accounting info
*
*       Ret:    Nothing
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/

#ifdef ANSI
PRIVATE Void soMiFreeAcntInfo
(
SoAcnt    *acnt    /* Accounting structure */
)
#else
PRIVATE Void soMiFreeAcntInfo(acnt)
SoAcnt    *acnt;   /* Accounting structure */
#endif
{
   TRC2(soMiFreeAcntInfo);

   soUtlDelTknStrOSXL(&acnt->acntInfo.remoteAddr);
   soUtlDelTknStrOSXL(&acnt->acntInfo.localAddr);

   RETVOID;
} /* soMiFreeAcntInfo */



/**********************************************************
*
*       Fun:   Accounting Request
*
*       Desc:  This primitive is used by the Layer Manager to solicit
*              accounting information. The information is returned
*              by SoMiLsoAcntInd primitive. A confirm is provided by
*              a SoMiLsoAcntCfm primitive
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/

#ifdef ANSI
PUBLIC S16 SoMiLsoAcntReq
(
Pst     *pst,           /* post structure */
SoMngmt *mngmt
)
#else
PUBLIC S16 SoMiLsoAcntReq(pst, mngmt)
Pst     *pst;           /* post structure */
SoMngmt *mngmt;
#endif
{
   U16          reason;         /* Reason                            */
   Pst          cfmPst;         /* Post structure to use for confirm */

   TRC3(SoMiLsoAcntReq);

   /* Set return values */
   mngmt->cfm.reason = LCM_REASON_NOT_APPL;
   mngmt->cfm.status = LCM_PRIM_OK;

   if (soCb.init.acnt == TRUE)
   {
      if (soAcntReq(pst,mngmt,&reason) != ROK)
      {
         mngmt->cfm.reason = reason;
         mngmt->cfm.status = LCM_PRIM_NOK;
      }
   }

   soMiFillResponsePost(&cfmPst, pst, &mngmt->hdr);

   /* Set return values */
   cfmPst.event = EVTLSOACNTCFM;

   SoMiLsoAcntCfm(&cfmPst, mngmt);

   soMiFreeAcntInfo(&mngmt->t.acnt);

   RETVALUE(ROK);
} /* SoMiLsoAcntReq */
#endif /* LSO_ACNT */

/**********************************************************
*
*       Fun:   Statistics Request
*
*       Desc:  This primitive is used by the Layer Manager to solicit
*              statistics information. The statistics are returned
*              by SoMiLsoStsCfm primitive. The statistics counters
*              can be initialized to zero using the "action" parameter.
*              The possible values for "action" are:
*
*                 ZEROSTS:  zero statistics counters
*                 NOZEROSTS:don't zero statistics counters
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 SoMiLsoStsReq
(
Pst     *pst,           /* post structure */
Action  action,         /* action to be done */
SoMngmt *sts            /* statistics structure */
)
#else
PUBLIC S16 SoMiLsoStsReq(pst, action, sts)
Pst     *pst;           /* post structure */
Action  action;         /* action to be done */
SoMngmt *sts;           /* statistics structure */
#endif
{
   S16          ret;           /* return value */
   U16          reason;        /* result reason */
   SoSts        *stats;        /* pointer to sts structure*/
   Pst          cfmPst;        /* Post structure for confirm */

   TRC3(SoMiLsoStsReq);

   /* initialize result and reason */
   reason = LCM_REASON_NOT_APPL;
   ret    = LCM_PRIM_OK;

   soMiFillResponsePost(&cfmPst, pst, &sts->hdr);

   stats = &sts->t.sts;
   /* update the date and time */
   (Void)SGetDateTime(&sts->t.sts.dt);


   /* have to have general configuration done first */
   if (soCb.init.cfgDone == FALSE)
   {
      soSendLmCfm(&cfmPst, TSTS,
         LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE, sts);
      RETVALUE(ROK);
   }

   /* which statistics element? */
   switch (sts->hdr.elmId.elmnt)
   {
      case STGEN:
         ret = soGenStsReq(&stats->s.genSts, action, &reason);
         break;

      case STSSAP:
         ret = soSSapStsReq(stats, action, &reason);
         break;

      case STTSAP:
         ret = soTcmTSapStsReq(&stats->s.tSapSts, action, &reason);
         break;

      case STSIPENT:
         ret = soSipEntStsReq(&stats->s.entSts, action, &reason);
         break;

      default:
         sts->cfm.reason = LCM_REASON_INVALID_ELMNT;
         ret = LCM_PRIM_NOK;

#if (ERRCLASS & ERRCLS_INT_PAR)
         SOLOGERROR(ERRCLS_INT_PAR, ESO132, (ErrVal)sts->hdr.elmId.elmnt,
                     "Invalid element.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         break;
   }

   /* send confirm */
   soSendLmCfm(&cfmPst, TSTS, ret, sts->cfm.reason, sts);


   RETVALUE(ROK);

} /* end of SoMiLsoStsReq */




/**********************************************************
*
*       Fun:   Status Request
*
*       Desc:  This primitive is used by the Layer Manager to solicit
*              status information. The information is returned via the
*              SoMiLsoStaCfm primitive.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 SoMiLsoStaReq
(
Pst     *pst,           /* post structure */
SoMngmt *sta            /* status structure */
)
#else
PUBLIC S16 SoMiLsoStaReq(pst, sta)
Pst     *pst;           /* post structure */
SoMngmt *sta;           /* status structure */
#endif
{
   U16          ret;            /* result */
   U16          reason;         /* result reason */
   Pst          cfmPst;         /* Post structure for confirm */
   U32          id;             /* Element id */
   SoEntCb      *entCb;         /* Entity control block */
   S16          sapId;          /* SAP id */
   SoCallCb     *callCb;        /* call Control Block */
   SoCLegCb     *cLeg;          /* call leg control block */
   CmLList      *curNode;       /* Current node in list */
   DateTime    today;             /* current time of day         */
   U32         startSeconds;    /* Start Time in seconds       */
   U32         seconds;         /* number of seconds           */

   TRC3(SoMiLsoStaReq);

   SODBGP_SO(DBGMASK_MI, (soCb.init.prntBuf,
                          "\nSM ---StaReq---> SIP: elmId=%d transId=%ld"
                          " status=%u reason=%u\n",
                          sta->hdr.elmId.elmnt, sta->hdr.transId,
                          sta->cfm.status, sta->cfm.reason));

   /* initialize result and reason */
   reason = LCM_REASON_NOT_APPL;
   ret    = LCM_PRIM_OK;
   soMiFillResponsePost(&cfmPst, pst, &sta->hdr);

   /* update the date and time */
   (Void)SGetDateTime(&sta->t.ssta.dt);

   /* have to have general configuration done first */
   if (soCb.init.cfgDone == FALSE)
   {
      soSendLmCfm(&cfmPst, TSSTA, LCM_PRIM_NOK, LCM_REASON_GENCFG_NOT_DONE,
                  sta);
      RETVALUE(ROK);
   }

   /* which status element? */
   switch (sta->hdr.elmId.elmnt)
   {
      case STGEN:
#ifdef SO_DNS 
         /* Copy general status into return structure */
         sta->t.ssta.s.genSta.dnsACacheSz   = 
                 soCb.cacheInfoCb.dnsACache.memUsed +
            soCb.cacheInfoCb.dnsACache.rdxCp.memUsed;
         sta->t.ssta.s.genSta.dnsSrvCacheSz = 
                 soCb.cacheInfoCb.dnsSrvCache.memUsed +
            soCb.cacheInfoCb.dnsSrvCache.rdxCp.memUsed;
         sta->t.ssta.s.genSta.dnsNaptrCacheSz = soCb.cacheInfoCb.dnsNaptrCache.memUsed +
            soCb.cacheInfoCb.dnsNaptrCache.rdxCp.memUsed;
#endif /* SO_DNS */
         sta->t.ssta.s.genSta.mCastCacheSz  = soCb.cacheInfoCb.mcastCache.memUsed +
            soCb.cacheInfoCb.mcastCache.rdxCp.memUsed;
#ifdef SO_LCS 
#ifdef SO_NS
         sta->t.ssta.s.genSta.locCacheSz    = soCb.cacheInfoCb.extLocSrvCache.memUsed +
            soCb.cacheInfoCb.extLocSrvCache.rdxCp.memUsed;
#else
         sta->t.ssta.s.genSta.locCacheSz    = NULLD;
#endif /* SO_NS */
#endif /* SO_LCS */

#ifdef SO_DNS 
         sta->t.ssta.s.genSta.dnsACacheEntries   = soCb.cacheInfoCb.dnsACache.nmbEntries;
         sta->t.ssta.s.genSta.dnsSrvCacheEntries = soCb.cacheInfoCb.dnsSrvCache.nmbEntries;
         sta->t.ssta.s.genSta.dnsNaptrCacheEntries = 
                                                soCb.cacheInfoCb.dnsNaptrCache.nmbEntries;
#endif /* SO_DNS */
         sta->t.ssta.s.genSta.mCastCacheEntries  = soCb.cacheInfoCb.mcastCache.nmbEntries;
#ifdef SO_LCS 
#ifdef SO_NS
         sta->t.ssta.s.genSta.locSrvCacheEntries =
            soCb.cacheInfoCb.extLocSrvCache.nmbEntries;
#else
         sta->t.ssta.s.genSta.locSrvCacheEntries = NULLD;
#endif /* SO_NS */
#endif /* SO_LCS */
         sta->t.ssta.s.genSta.resCong = soCb.resCongStrt;
         break;

      case STSID:
         /* Copy system ID into return structure */
         (Void) soGetSid(&sta->t.ssta.s.sysId);
         break;

      case STTSAP:
         sapId = sta->t.ssta.s.tSapSta.tSapId;
         if (sapId >= soCb.cfg.maxNmbTSaps)
         {
            /* SAP ID is out of range */
            soSendLmCfm(&cfmPst,
                        TSSTA,
                        LCM_PRIM_NOK,
                        LCM_REASON_INVALID_SAP,
                        sta);
            RETVALUE(ROK);
         }
         if (soCb.soTSapCbLst[sapId] == (SoTSapCb *) NULLP)
         {
            /* TSAP is not configured */
            soSendLmCfm(&cfmPst,
                        TSSTA,
                        LCM_PRIM_NOK,
                        LCM_REASON_INVALID_SAP,
                        sta);
            RETVALUE(ROK);
         }

         sta->t.ssta.s.tSapSta.state = soCb.soTSapCbLst[sapId]->state;
         break;

      case STSSAP:
         sapId = sta->t.ssta.s.sSapSta.sSapId;
         if (sapId >= soCb.cfg.maxNmbSSaps)
         {
            /* SAP ID is out of range */
            soSendLmCfm(&cfmPst,
                        TSSTA,
                        LCM_PRIM_NOK,
                        LCM_REASON_INVALID_SAP,
                        sta);
            RETVALUE(ROK);
         }
         if (soCb.soSSapCbLst[sapId] == NULLP)
         {
            /* SSAP is not configured */
            soSendLmCfm(&cfmPst,
                        TSSTA,
                        LCM_PRIM_NOK,
                        LCM_REASON_INVALID_SAP,
                        sta);
            RETVALUE(ROK);
         }
         sta->t.ssta.s.sSapSta.state = soCb.soSSapCbLst[sapId]->state;
         break;

      case STSIPENT:
         id = sta->t.ssta.s.entSta.entId;
         if (id >= (U32)(soCb.maxEnt))
         {
            soSendLmCfm(&cfmPst, TSSTA, LCM_PRIM_NOK,
               LCM_REASON_INVALID_ENTITY, sta);
            RETVALUE(ROK);
         }
         entCb = soCb.entLst[id];
         if (entCb == NULLP)
         {
            soSendLmCfm(&cfmPst, TSSTA, LCM_PRIM_NOK,
               LCM_REASON_INVALID_ENTITY, sta);
            RETVALUE(ROK);
         }

         sta->t.ssta.s.entSta.operState = entCb->curState;
         sta->t.ssta.s.entSta.lmState = entCb->lmState;

         SGetDateTime(&today);
         soCmGetSecFromDate(&today, &seconds);
         soCmGetSecFromDate(&entCb->entEnbTime, &startSeconds);

         seconds -= startSeconds;
         if (seconds >  0)
           sta->t.ssta.s.entSta.strtTm = seconds;
         else
           sta->t.ssta.s.entSta.strtTm = 0;

         /* get the nmbActCalls information from callIdLst */
         sta->t.ssta.s.entSta.nmbActCalls = entCb->callIdLst.nmbEnt;

         /* Compute num of call legs and num of transactions */
         callCb = NULLP;
         sta->t.ssta.s.entSta.totNmbCLegs = 0;
         sta->t.ssta.s.entSta.totNmbTrans = 0;

         while (cmHashListGetNext(&entCb->callIdLst, (PTR) callCb,
                                  (PTR *) &callCb) == ROK)
         {           
           sta->t.ssta.s.entSta.totNmbCLegs += 
             cmLListLen(&callCb->cLegLst);

           /* Process all call legs in call */
           curNode = NULLP;
           curNode = cmLListFirst(&callCb->cLegLst);
           while (curNode != NULLP)
           {
             cLeg = (SoCLegCb *)(cmLListNode(curNode));
             if (cLeg != NULLP)
             {
               sta->t.ssta.s.entSta.totNmbTrans += 
                 cLeg->tranCbLst.nmbEnt;
             }

             curNode  = curNode->next;

           } /* end while curNode != NULLP */      

         } /* end while valid callCb */
         

         if (entCb->entityType == LSO_ENT_UA)
         {
#ifdef SO_UA
            /* Copy ua status into return structure */
            sta->t.ssta.s.entSta.t.uaSta.locRegSz =
               entCb->s.ua.localUsrReg.memUsed +
               entCb->s.ua.localUsrReg.rdxCp.memUsed;

            sta->t.ssta.s.entSta.t.uaSta.locRegEntries =
               entCb->s.ua.localUsrReg.nmbEntries;
            sta->t.ssta.s.entSta.t.uaSta.regWarnState =
               entCb->s.ua.localUsrReg.warningAlarm;
#endif /* SO_UA */
         }
         break;

      case STTPTSRV:
         id = sta->t.ssta.s.tptSrvSta.tptSrvId;
         if (id >= soCb.maxTptSrv)
         {
            soSendLmCfm(&cfmPst, TSSTA, LCM_PRIM_NOK, LSO_REASON_INV_TPTSRV,
                        sta);
            RETVALUE(ROK);
         }
         if (soCb.allSrvCbLst[id] == NULLP)
         {
            soSendLmCfm(&cfmPst, TSSTA, LCM_PRIM_NOK,
                        LSO_REASON_INV_TPTSRV, sta);
            RETVALUE(ROK);
         }

         sta->t.ssta.s.tptSrvSta.state = soCb.allSrvCbLst[id]->state;
         break;

      default:
         reason = LCM_REASON_INVALID_ELMNT;
         ret    = LCM_PRIM_NOK;

#if (ERRCLASS & ERRCLS_INT_PAR)
         SOLOGERROR(ERRCLS_INT_PAR, ESO133, (ErrVal)sta->hdr.elmId.elmnt,
                     "Invalid element.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         break;
   }

   /* send confirm */
   soSendLmCfm(&cfmPst, TSSTA, ret, reason, sta);

   RETVALUE(ROK);
} /* end of SoMiLsoStaReq */



/**********************************************************
*
*       Fun:   soMiFillResponsePost
*
*       Desc:  Fills post structure for response based on received
*              post structure
*
*       Ret:   Nothing
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC Void soMiFillResponsePost
(
Pst    *respPst,        /* response post structure */
Pst    *reqPst,         /* incoming request post structure */
Header *reqHeader       /* incoming request header */
)
#else
PUBLIC Void soMiFillResponsePost(respPst, reqPst, reqHeader)
Pst    *respPst;        /* response post structure */
Pst    *reqPst;         /* incoming request post structure */
Header *reqHeader;      /* incoming request header */
#endif
{
   TRC2(soMiFillResponsePost);

   /* Fill up the post struct for comfirm */
   respPst->srcEnt        = soCb.init.ent;
   respPst->srcInst       = soCb.init.inst;
   respPst->srcProcId     = soCb.init.procId;
   respPst->dstEnt        = reqPst->srcEnt;
   respPst->dstInst       = reqPst->srcInst;
   respPst->dstProcId     = reqPst->srcProcId;
   respPst->selector      = reqHeader->response.selector;
   respPst->prior         = reqHeader->response.prior;
   respPst->route         = reqHeader->response.route;
   respPst->region        = reqHeader->response.mem.region;
   respPst->pool          = reqHeader->response.mem.pool;

   RETVOID;
} /* soMiFillResponsePost */


/**********************************************************
*
*       Fun:   Control Request
*
*       Desc:  This primitive is used to control the specified element.
*              It can be used to enable or disable trace and alarm
*              (unsolicited status) generation. The control request
*              is also used for debug printing control.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 SoMiLsoCntrlReq
(
Pst     *pst,           /* post structure */
SoMngmt *cntrl          /* pointer to control structure */
)
#else
PUBLIC S16 SoMiLsoCntrlReq(pst, cntrl)
Pst     *pst;           /* post structure */
SoMngmt *cntrl;         /* pointer to control structure */
#endif
{
   S16           ret;            /* return value */
   U16           reason;         /* result reason */
   SoTSapCb      *tsapCb;        /* Control block for TSAP ctrl requests */
   SoEntCb       *entCb;         /* Control block for entity ctrl requests */
   SoSSapCb      *ssapCb;        /* Control block for SSAP ctrl requests */
   SoTptServerCb *serverCb;        /* Control block for tpt server */
   U8            entId;          /* Entity ID for entity control requests */
   SpId          tsapId;         /* TSAP ID */
   SpId          ssapId;         /* SSAP ID */
   U32           tptSrvId;       /* ID for transport server */
   Pst           cfmPst;         /* Post structure to use for LM confirm */
   U32           *tptIdLst;     /* List of Ids for transport server */
   
   UConnId      suConnId;

   TRC3(SoMiLsoCntrlReq);

   SODBGP_SO(DBGMASK_MI, (soCb.init.prntBuf,
                          "\nSM ---CtrlReq--> SIP: elmId=%d transId=%ld"
                          " action=%u subaction=%u\n",
                          cntrl->hdr.elmId.elmnt, cntrl->hdr.transId,
                          cntrl->t.cntrl.action, cntrl->t.cntrl.subAction));

   /* initialize result and reason */
   reason = LCM_REASON_NOT_APPL;
   ret    = LCM_PRIM_OK;

   soMiFillResponsePost(&cfmPst, pst, &cntrl->hdr);

   /* update the date and time */
   (Void) SGetDateTime(&cntrl->t.cntrl.dt);

   /* have to have general configuration done first */
   if (soCb.init.cfgDone == FALSE)
   {
      soSendLmCntrlCfm(&cfmPst,
                       LCM_PRIM_NOK,
                       LCM_REASON_GENCFG_NOT_DONE,
                       &cntrl->hdr);
      RETVALUE(ROK);
   }

   /* which control element? */
   switch (cntrl->hdr.elmId.elmnt)
   {
      case STGEN:
         /* shutdown */
         if (cntrl->t.cntrl.action == ASHUTDOWN)
         {
#ifdef SO_ABNF_MT_LIB
            if (soCb.cfg.nmbEDThreads > 0)
            {
               ret    = LCM_PRIM_OK_NDONE;
               if (!soCb.shutdownInProgress)
               {
                  soCb.shutdownInProgress = TRUE;
                  soMiFillResponsePost(&soCb.shutdownCfmPst, pst, &cntrl->hdr);
                  cmMemcpy((U8 *)&soCb.shutdownCntrlHdr, (U8 *)(&cntrl->hdr),
                            sizeof(Header));
                  ret = soShutdownReq(&reason);
               }
               soSendLmCntrlCfm(&cfmPst, ret, reason, &cntrl->hdr);
               SODBGP_SO(DBGMASK_MI, (soCb.init.prntBuf,
                  "\n------ SIP Stack Shutdown (CtrlReq)........\n"));
               RETVALUE(ROK);
            }
            else 
#endif /* SO_ABNF_MT_LIB */
            {
#ifdef SO_ABNF_MT_LIB
               /* send shutdown in Progress */
               soSendLmCntrlCfm(&cfmPst, LCM_PRIM_OK_NDONE, 
                                  LCM_REASON_NOT_APPL, &cntrl->hdr);
#endif /* SO_ABNF_MT_LIB */
               ret = soShutdownReq(&reason);
               soSendLmCntrlCfm(&cfmPst, ret, reason, &cntrl->hdr);
               SODBGP_SO(DBGMASK_MI, (soCb.init.prntBuf,
                  "\n------ SIP Stack Shutdown (CtrlReq)........\n"));
               RETVALUE(ROK);
            }
         }
         /* check control operation */
         switch (cntrl->t.cntrl.subAction)
         {
            case SAUSTA:
               switch (cntrl->t.cntrl.action)
               {
                  case AENA:
                     soCb.init.usta = TRUE;
                     break;
                  case ADISIMM:
                     soCb.init.usta = FALSE;
                     break;
                  default:
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION,
                        &cntrl->hdr);
                     RETVALUE(ROK);
                     break;
               }
               break;
#ifdef DEBUGP
            case SADBG:
               switch (cntrl->t.cntrl.action)
               {
                  case AENA:
                     soCb.init.dbgMask |=
                        cntrl->t.cntrl.s.dbgCntrl.genDbgMask;
                     break;
                  case ADISIMM:
                     soCb.init.dbgMask &=
                        ~(cntrl->t.cntrl.s.dbgCntrl.genDbgMask);
                     break;
                  default:
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION, &cntrl->hdr);
                     RETVALUE(ROK);
                     break;
               }
               break;
#endif /* DEBUGP */
            case SAACNT:
               switch (cntrl->t.cntrl.action)
               {
                  case AENA:
                     soCb.init.acnt = TRUE;
                     break;
                  case ADISIMM:
                     soCb.init.acnt = FALSE;
                     break;
                  default:
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION, &cntrl->hdr);
                     RETVALUE(ROK);
                     break;
               }
               break;
            case SAELMNT:
               /* This control req is used to clear a global cache */
                  if (cntrl->t.cntrl.action == ACLEAR)
                  {
                     switch (cntrl->t.cntrl.s.cacheCntrl.type)
                     {
#ifdef SO_DNS 
                        case LSO_DNS_A_CACHE:
                           soClCacheClear(&soCb.cacheInfoCb.dnsACache);
                           break;
                        case LSO_DNS_SRV_CACHE:
                           soClCacheClear(&soCb.cacheInfoCb.dnsSrvCache);
                           break;
                        case LSO_DNS_NAPTR_CACHE:
                           soClCacheClear(&soCb.cacheInfoCb.dnsNaptrCache);
                           break;
#endif /* SO_DNS */
                        case LSO_MCAST_CACHE:
                           soClCacheClear(&soCb.cacheInfoCb.mcastCache);
                           break;
#ifdef SO_LCS 
                        case LSO_LOCSRV_CACHE:
#ifdef SO_NS
                           soClCacheClear(&soCb.cacheInfoCb.extLocSrvCache);
#endif
                           break;
#endif /* SO_LCS */
                        default:
                           /* Invalid cache type */
                           soSendLmCntrlCfm(&cfmPst,
                              LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION,
                              &cntrl->hdr);
                           RETVALUE(ROK);
                           break;
                     }
                  }
                  else
                  {
                     /* Invalid action */
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION,
                        &cntrl->hdr);
                     RETVALUE(ROK);
                  }
               break;
         }

         /* End of control request for STGEN */
         /* Send OK primititve - default */
         soSendLmCntrlCfm(&cfmPst,
                          LCM_PRIM_OK,
                          LCM_REASON_NOT_APPL,
                          &cntrl->hdr);
         RETVALUE(ROK);
         break;

      case STTSAP:
         /* TSAP control request:
          *    SAELMNT = TSAP itself
          *    SATRC   = Tracing related to TSAP
          */

         switch (cntrl->t.cntrl.subAction)
         {
            case SAELMNT:    /* fall through */
            case SATRC:
               tsapId = cntrl->t.cntrl.s.sapId;
               break;
            default:
               soSendLmCntrlCfm(&cfmPst,
                  LCM_PRIM_NOK, LCM_REASON_INVALID_SUBACTION,
                  &cntrl->hdr);
               RETVALUE(ROK);
               break;
         }

         /* Check range, check tsapCb */
         if ((tsapId >= soCb.cfg.maxNmbTSaps) || (tsapId < 0))
         {
            soSendLmCntrlCfm(&cfmPst,
               LCM_PRIM_NOK, LCM_REASON_INVALID_ELMNT,
               &cntrl->hdr);
            RETVALUE(ROK);
         }

         /* Check if TSAP is valid  */
         tsapCb = soCb.soTSapCbLst[tsapId];
         if (tsapCb == NULLP)
         {
            soSendLmCntrlCfm(&cfmPst,
               LCM_PRIM_NOK, LCM_REASON_INVALID_SAP,
               &cntrl->hdr);
            RETVALUE(ROK);
         }

         /* Store the received header for the response */
         cmMemcpy((U8 *)&tsapCb->ctrlHdr, (U8 *)&cntrl->hdr,
                  sizeof(Header));
         cmMemcpy((U8 *)&tsapCb->cfmPst, (U8 *)&cfmPst,
                  sizeof(Pst));

         switch (cntrl->t.cntrl.subAction)
         {
            case SAELMNT:
               /* The processing functions must generate response
                * primitives directly
                */
               switch (cntrl->t.cntrl.action)
               {
                  case ABND_ENA:
                     soTcmTSapBndEna(tsapCb);
                     tsapCb->contEnt = ENTNC;        /* FTHA */
                     break;
                  case AENA:
                     soTcmTSapEna(tsapCb);
                     tsapCb->contEnt = ENTNC;        /* FTHA */
                     break;
                  case ADISIMM:
                     soTcmTSapDis(tsapCb);
                     tsapCb->contEnt = ENTSM;        /* FTHA */
                     break;
                  case ADEL:
                     soTcmTSapDel(tsapCb, TRUE);
                     break;
                  case AUBND_DIS:
                     soTcmTSapUbndDis(tsapCb);
                     tsapCb->contEnt = ENTSM;        /* FTHA */
                     break;
                  default:
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION,
                        &cntrl->hdr);
                     break;
                }
                break;
            case SATRC:
               switch (cntrl->t.cntrl.action)
               {
                  case AENA:
                     tsapCb->trcMask |= cntrl->t.cntrl.s.trcCntrl.trcMask;
                     tsapCb->trcLen = cntrl->t.cntrl.s.trcCntrl.trcLen;
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                        &cntrl->hdr);
                     break;
                  case ADISIMM:
                     tsapCb->trcMask &= ~cntrl->t.cntrl.s.trcCntrl.trcMask;
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                        &cntrl->hdr);
                     break;
                  default:
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION,
                        &cntrl->hdr);
                     break;
               }
               break;
         }
         RETVALUE(ROK);
         break;

      case STSSAP:

         /* Check SSAP id for validity */
         ssapId = cntrl->t.cntrl.s.sSapCntrl.sSapId;
         if ((ssapId < 0) || (ssapId >= soCb.cfg.maxNmbSSaps))
         {
            soSendLmCntrlCfm(&cfmPst,
                             LCM_PRIM_NOK,
                             LCM_REASON_INVALID_SAP,
                             &cntrl->hdr);
            RETVALUE(ROK);
         }

         /* Check if SSAP is valid  */
         ssapCb = soCb.soSSapCbLst[ssapId];
         if (ssapCb == NULLP)
         {
            soSendLmCntrlCfm(&cfmPst,
               LCM_PRIM_NOK, LCM_REASON_INVALID_SAP,
               &cntrl->hdr);
            RETVALUE(ROK);
         }
         switch (cntrl->t.cntrl.action)
         {
            case ADEL:
               ret = soSSapDel(ssapCb, &reason);
               soSendLmCntrlCfm(&cfmPst, ret, reason, &cntrl->hdr);
               break;

            case AUBND_DIS:
               ret = soSSapUbndDis(ssapCb, &reason);
               soSendLmCntrlCfm(&cfmPst, ret, reason, &cntrl->hdr);
               break;

            case AADD_ASSOC_TPTSRV:
               /* Associate SSAP with  transport servers */
               tptIdLst = cntrl->t.cntrl.s.sSapCntrl.tptSrvLst;
               /* so032.201: Retrieve entity ID from SSAP Cb */
               entId = ssapCb->cfg.entId; 
               /* Check range, get entity control block */
               if (entId >= soCb.maxEnt)
               {
                  soSendLmCntrlCfm(&cfmPst,
                     LCM_PRIM_NOK, LCM_REASON_INVALID_ENTITY,
                     &cntrl->hdr);
                  RETVALUE(ROK);
               }
               ret = soSSapAddAssocTptSrv(ssapCb,&tptIdLst, entId, &reason);
               soSendLmCntrlCfm(&cfmPst,
                                ret,
                                reason,
                                &cntrl->hdr);
               break;

            case ADEL_ASSOC_TPTSRV:
               /* Delete link between SSAP and transport servers */ 
               tptIdLst = cntrl->t.cntrl.s.sSapCntrl.tptSrvLst;
               /* so032.201: Retrieve entity ID from SSAP Cb */
               entId = ssapCb->cfg.entId; 
               /* Check range, get entity control block */
               if (entId >= soCb.maxEnt)
               {
                  soSendLmCntrlCfm(&cfmPst,
                     LCM_PRIM_NOK, LCM_REASON_INVALID_ENTITY,
                     &cntrl->hdr);
                  RETVALUE(ROK);
               }
               ret = soSSapDelAssocTptSrv(ssapCb, &tptIdLst, entId, &reason);
               soSendLmCntrlCfm(&cfmPst,
                                ret,
                                reason,
                                &cntrl->hdr);
               break;

            default:
               soSendLmCntrlCfm(&cfmPst,
                                LCM_PRIM_NOK,
                                LCM_REASON_INVALID_ACTION,
                                &cntrl->hdr);
               break;
         }
         RETVALUE(ROK);
         break;

      case STGRSSAP:
         switch (cntrl->t.cntrl.action)
         {
            case AUBND_DIS:
               ret = soSSapGrUbndDis(cntrl->t.cntrl.s.procId, &reason);
               break;

            case ADEL:
               ret = soSSapGrDel(cntrl->t.cntrl.s.procId, &reason);
               break;

            default:
               reason = LCM_REASON_INVALID_ACTION;
               ret    = LCM_PRIM_NOK;
               break;
         }
         break;

      case STSIPENT:
         /* Control request for a SIP entity
          * First get entity control block, then call appropriate
          * processing function
          * The individual processing functions must return the
          * confirm primitive to the SM
          */
         /* Get entity ID */
         switch (cntrl->t.cntrl.subAction)
         {
            case SAELMNT:
               entId = cntrl->t.cntrl.s.entId;
               break;
            case SATRC:
               entId = cntrl->t.cntrl.s.trcCntrl.t.entId;
               break;
#ifdef DEBUGP
            case SADBG:
               entId = (U8)cntrl->t.cntrl.s.dbgCntrl.entId;
               break;
#endif /* DEBUGP */
            default:
               /* Invalid subaction */
               soSendLmCntrlCfm(&cfmPst,
                  LCM_PRIM_NOK, LCM_REASON_INVALID_SUBACTION,
                  &cntrl->hdr);
               RETVALUE(ROK);
               break;
         }

         /* Check range, get entity control block */
         if (entId >= soCb.maxEnt)
         {
            soSendLmCntrlCfm(&cfmPst,
               LCM_PRIM_NOK, LCM_REASON_INVALID_ENTITY,
               &cntrl->hdr);
            RETVALUE(ROK);
         }

         /* Check if TSAP is valid  */
         entCb = soCb.entLst[entId];
         if (entCb == NULLP)
         {
            soSendLmCntrlCfm(&cfmPst,
               LCM_PRIM_NOK, LCM_REASON_INVALID_ENTITY,
               &cntrl->hdr);
            RETVALUE(ROK);
         }

         /* Store the received header for the response */
         cmMemcpy((U8 *)&entCb->ctrlHdr, (U8 *)&cntrl->hdr,
            sizeof(Header));
         cmMemcpy((U8 *)&entCb->pst, (U8 *)&cfmPst,
            sizeof(Pst));

         switch (cntrl->t.cntrl.subAction)
         {
            case SAELMNT:
               switch (cntrl->t.cntrl.action)
               {
                  case AENA:
                     soSipEntEna(entCb);
                     break;
                  case ADISIMM:
                     soSipEntDis(entCb, FALSE, TRUE);
                     break;
                  case ADISGRC:
                     soSipEntDis(entCb, TRUE, TRUE);
                     break;
                  case ADEL:
                     soSipEntDel(entCb, TRUE);
                     break;
                  default:
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_NOK, LCM_REASON_INVALID_ACTION,
                        &cntrl->hdr);
                     break;
               }
               break;
#ifdef DEBUGP
            case SADBG:
               if (cntrl->t.cntrl.action == AENA)
               {
                  entCb->dbgMask |= cntrl->t.cntrl.s.dbgCntrl.entDbgMask;
               }
               else
               {
                  entCb->dbgMask &= ~(cntrl->t.cntrl.s.dbgCntrl.entDbgMask);
               }
               soSendLmCntrlCfm(&cfmPst,
                  LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                  &cntrl->hdr);
               break;
#endif /* DEBUGP */

            case SATRC:
               if (cntrl->t.cntrl.action == AENA)
               {
                  entCb->trcMask |= cntrl->t.cntrl.s.trcCntrl.trcMask;
               }
               else
               {
                  entCb->trcMask &= ~(cntrl->t.cntrl.s.trcCntrl.trcMask);
               }
               /* Store trace length */
               entCb->trcLen = cntrl->t.cntrl.s.trcCntrl.trcLen;
               soSendLmCntrlCfm(&cfmPst,
                  LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                  &cntrl->hdr);
               break;
         }
         RETVALUE(ROK);
         break;

      case STTPTSRV:
         /* TPT server:
          *   Enabled, Disable
          *   Add, delete
          */
         switch (cntrl->t.cntrl.subAction)
         {
            case SAELMNT:

               tptSrvId = cntrl->t.cntrl.s.tptSrvCntrl.tptSrvId;
               if (tptSrvId >= soCb.maxTptSrv)
               {
                  soSendLmCntrlCfm(&cfmPst,
                     LCM_PRIM_OK, LSO_REASON_INV_TPTSRV,
                     &cntrl->hdr);
                  RETVALUE(ROK);
               }

               if (cntrl->t.cntrl.action == AADD)
               {
                  /* Add transport server */
                  /* Check entity ID */
                  entId = cntrl->t.cntrl.s.tptSrvCntrl.entId;
                  /* Check range, get entity control block */
                  if (entId >= soCb.maxEnt)
                  {
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_NOK, LCM_REASON_INVALID_ENTITY,
                        &cntrl->hdr);
                     RETVALUE(ROK);
                  }

                  /* Check if TSAP is valid  */
                  entCb = soCb.entLst[entId];
                  if (entCb == NULLP)
                  {
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_NOK, LCM_REASON_INVALID_ENTITY,
                        &cntrl->hdr);
                     RETVALUE(ROK);
                  }

                  /* Insert ID into config structure used by AddServer */
                  cntrl->t.cntrl.s.tptSrvCntrl.cfg.tptSrvId =
                     cntrl->t.cntrl.s.tptSrvCntrl.tptSrvId;
                  if (soMiAddTptServer(entCb,
                     &cntrl->t.cntrl.s.tptSrvCntrl.cfg, &reason) == ROK)
                  {
                     if (soCb.soTSapCbLst[cntrl->t.cntrl.s.
                         tptSrvCntrl.cfg.tSapId]->state == LSO_TSAP_BNDENA)
                     {
                        serverCb = soCb.allSrvCbLst[tptSrvId];
                        /* Store the received header for the response */
                        cmMemcpy((U8 *)&serverCb->ctrlHdr, (U8 *)&cntrl->hdr,
                           sizeof(Header));
                        cmMemcpy((U8 *)&serverCb->pst, (U8 *)&cfmPst,
                           sizeof(Pst));

                        if (soTptOpenServer (serverCb) != ROK)
                        {
                          soSendLmCntrlCfm(&cfmPst,
                             LCM_PRIM_NOK, LCM_REASON_INVALID_PAR_VAL, &cntrl->hdr);
                          RETVALUE(ROK);
                        }

                        serverCb->waitFinalCfm = TRUE;

                        soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_OK_NDONE, LCM_REASON_NOT_APPL,
                        &cntrl->hdr);

                        RETVALUE(ROK);
                     }
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                        &cntrl->hdr);
                  }
                  else
                  {
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_NOK, reason,
                        &cntrl->hdr);
                  }
                  RETVALUE(ROK);
               }

               serverCb = soCb.allSrvCbLst[tptSrvId];

               if (serverCb == NULLP)
               {
                  soSendLmCntrlCfm(&cfmPst,
                     LCM_PRIM_OK, LSO_REASON_INV_TPTSRV,
                     &cntrl->hdr);
                  RETVALUE(ROK);
               }

               /* Store the received header for the response */
               cmMemcpy((U8 *)&serverCb->ctrlHdr, (U8 *)&cntrl->hdr,
                  sizeof(Header));
               cmMemcpy((U8 *)&serverCb->pst, (U8 *)&cfmPst,
                  sizeof(Pst));

               switch (cntrl->t.cntrl.action)
               {
                  /* The functions to process the control request
                   * must return the confirm primitive to the
                   * SM
                   */
                  case AENA:
                      if (soTptOpenServer (serverCb) != ROK)
                      {
                          soSendLmCntrlCfm(&cfmPst,
                             LCM_PRIM_NOK, LCM_REASON_INVALID_PAR_VAL, &cntrl->hdr);
                          RETVALUE(ROK);
                      }
                   
                     serverCb->waitFinalCfm = TRUE;
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_OK_NDONE, LCM_REASON_NOT_APPL,
                        &cntrl->hdr);
                     RETVALUE(ROK);
                     break;

                  case ADISIMM:
                     soTptCloseServer (serverCb);
                     soMiTptSrvCloseInd(serverCb, TRUE);

                     soSendLmCntrlCfm(&cfmPst, LCM_PRIM_OK,
                                      LCM_REASON_NOT_APPL, &cntrl->hdr);
                     RETVALUE(ROK);
                     break;

                  case ADEL:
                     suConnId = serverCb->suConnId;
                     soTptCloseServer (serverCb);
                     soMiTptSrvCloseInd(serverCb, TRUE);
                     soTptFreeServer (serverCb);
                     soCb.allSrvCbLst[suConnId] = NULLP;
                     soSendLmCntrlCfm(&cfmPst,
                        LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                        &cntrl->hdr);
                     RETVALUE(ROK);
                     break;

                  default:
                     ret    = LCM_PRIM_NOK;
                     reason = LCM_REASON_INVALID_ACTION;
                     break;
                  }
                  break;
            default:
               reason = LCM_REASON_INVALID_SUBACTION;
               ret    = LCM_PRIM_NOK;
               break;
         }
         break;

      default:
         reason = LCM_REASON_INVALID_ELMNT;
         ret    = LCM_PRIM_NOK;
         break;
   }
   /* send confirm */
   soSendLmCntrlCfm(&cfmPst, ret, reason, &cntrl->hdr);

   RETVALUE(ROK);
} /* end of SoMiLsoCntrlReq */

#ifdef SO_FTHA

/**********************************************************
*
*       Fun:   System Agent Control Request
*
*       Desc:  Processes system agent control request primitive
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 SoMiShtCntrlReq
(
Pst               *pst,         /* post structure */
ShtCntrlReqEvnt   *reqInfo      /* system agent control request event */
)
#else
PUBLIC S16 SoMiShtCntrlReq(pst, reqInfo)
Pst               *pst;         /* post structure */
ShtCntrlReqEvnt   *reqInfo;     /* system agent control request event */
#endif
{
   Pst               repPst;         /* reply post structure */
   ShtCntrlCfmEvnt   cfmInfo;        /* system agent control confirm event */
   SoTSapCb          *tsapCb;        /* local pointer */
   S16               i;              /* local counter */
   S16               ret;            /* local return code */
   SoTptClientCb     *clientCb;        /* Connection to close */

   TRC3(SoMiShtCntrlReq)

   /* fill reply post structure */
   repPst.dstProcId = pst->srcProcId;
   repPst.dstEnt    = pst->srcEnt;
   repPst.dstInst   = pst->srcInst;
   repPst.prior     = reqInfo->hdr.response.prior;
   repPst.route     = reqInfo->hdr.response.route;
   repPst.selector  = reqInfo->hdr.response.selector;
   repPst.event     = EVTSHTCNTRLCFM;
   repPst.srcProcId = soCb.init.procId;
   repPst.srcEnt    = ENTSO;
   repPst.srcInst   = soCb.init.inst;

   cfmInfo.transId = reqInfo->hdr.transId;

   /* check if general configuration done */
   if (soCb.init.cfgDone != TRUE)
   {
      cfmInfo.status.status = LCM_PRIM_NOK;
      cfmInfo.status.reason = LCM_REASON_GENCFG_NOT_DONE;

      SoMiShtCntrlCfm(&repPst, &cfmInfo);
      RETVALUE(ROK);
   }

   /* fill status value */
   cfmInfo.status.reason = LCM_REASON_NOT_APPL;

   switch (reqInfo->reqType)
   {
      case SHT_REQTYPE_BND_ENA:      /* system agent control bind enable */

         /* call function for all SAPS */
         for (i = 0; i < soCb.cfg.maxNmbTSaps; i++)
         {
            if (soCb.soTSapCbLst[i] != (SoTSapCb *) NULLP)
            {
               /* we have a configured TSAP */
               tsapCb = soCb.soTSapCbLst[i];

               if (reqInfo->s.bndEna.grpType == SHT_GRPTYPE_ALL)
               {
                  /* bind and enable all ready SAPS based on
                     pst->dstProcId == reqInfo->s.bndEna.dstProcId
                     pst->dstEnt    == reqInfo->s.bndEna.dstEnt.ent
                     pst->dstInst   == reqInfo->s.bndEna.dstEnt.inst */

                  if ((tsapCb->cfg.dstProcId != reqInfo->s.bndEna.dstProcId) ||
                      (tsapCb->cfg.dstEnt != reqInfo->s.bndEna.dstEnt.ent) ||
                      (tsapCb->cfg.dstInst != reqInfo->s.bndEna.dstEnt.inst) ||
                      (tsapCb->contEnt == ENTSM))
                  {
                     /* one of the criteria does not match or the stack
                        manager is the controlling entity */
                     continue;
                  }
               }
               else if (reqInfo->s.bndEna.grpType == SHT_GRPTYPE_ENT)
               {
                  /* bind and enable all ready SAPS based on
                     pst->dstEnt    == reqInfo->s.bndEna.dstEnt.ent
                     pst->dstInst   == reqInfo->s.bndEna.dstEnt.inst */

                  if ((tsapCb->cfg.dstEnt != reqInfo->s.bndEna.dstEnt.ent) ||
                      (tsapCb->cfg.dstInst != reqInfo->s.bndEna.dstEnt.inst) ||
                      (tsapCb->contEnt == ENTSM))
                  {
                     /* one of the criteria does not match or the stack
                        manager is the controlling entity */
                     continue;
                  }
               }
               else
               {
                  /* unregcognised group type */
                  cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
                  break;
               }

               /* try and bind it */
               switch (tsapCb->state)
               {
                  case LSO_TSAP_UBNDDIS:
                     tsapCb->state = LSO_TSAP_WAIT_BNDENA;
                     if (tsapCb->reCfg.bndTmCfg.enb == TRUE)
                     {
                        ret = soSchedTmr(tsapCb,
                                         SO_TMR_TCM_BND, TMR_START,
                                         tsapCb->reCfg.bndTmCfg.val);
#if (ERRCLASS & ERRCLS_DEBUG)
                        if (ret != ROK)
                        {
                           SOLOGERROR(ERRCLS_DEBUG, ESO134, (ErrVal) ret,
                                      "SoMiShtCntrlReq: Timer start failed\n");
                        }
#endif /* ERRCLASS & ERRCLS_DEBUG */
                     }

                     /* Reset bind retry count */
                     tsapCb->bndRetryCnt = 0;

                     (Void)SoLiHitBndReq(&tsapCb->liPst,
                                         tsapCb->cfg.tSapId,
                                         tsapCb->cfg.spId);
                     break;
                  /* do nothing for these next two states */
                  case LSO_TSAP_WAIT_BNDENA:
                  case LSO_TSAP_BNDENA:
                     break;

                  case LSO_TSAP_WAIT_BNDDIS:
                     tsapCb->state = LSO_TSAP_WAIT_BNDENA;
                     break;

                  case LSO_TSAP_BNDDIS:
                     tsapCb->state = LSO_TSAP_BNDENA;
                     soTptProcessTsapServers (tsapCb, SO_TCM_TPTSRV_OPEN);
                     break;
                  default:
#if (ERRCLASS & ERRCLS_DEBUG)
                     SOLOGERROR(ERRCLS_DEBUG, ESO135,
                                (ErrVal) tsapCb->state,
                                "SoMiShtCntrlReq: Invalid TSAP state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
                     break;
               }
            }
         }
         break;

      case SHT_REQTYPE_UBND_DIS:      /* system agent control unbind disable */

         /* call function for all SAPS */
         for (i = 0; i < soCb.cfg.maxNmbTSaps; i++)
         {
            if (soCb.soTSapCbLst[i] != (SoTSapCb *) NULLP)
            {
               /* we have a configured TSAP */
               tsapCb = soCb.soTSapCbLst[i];

               if (reqInfo->s.ubndDis.grpType == SHT_GRPTYPE_ALL)
               {
                  /* unbind and disable all ready SAPS based on
                     pst->dstProcId == reqInfo->s.bndEna.dstProcId
                     pst->dstEnt    == reqInfo->s.bndEna.dstEnt.ent
                     pst->dstInst   == reqInfo->s.bndEna.dstEnt.inst */

                  if ((tsapCb->cfg.dstProcId != reqInfo->s.ubndDis.dstProcId) ||
                      (tsapCb->cfg.dstEnt != reqInfo->s.ubndDis.dstEnt.ent) ||
                      (tsapCb->cfg.dstInst != reqInfo->s.ubndDis.dstEnt.inst))
                  {
                     /* one of the criteria does not match */
                     continue;
                  }
               }
               else if (reqInfo->s.ubndDis.grpType == SHT_GRPTYPE_ENT)
               {
                  /* bind and enable all ready SAPS based on
                     pst->dstEnt    == reqInfo->s.ubndDis.dstEnt.ent
                     pst->dstInst   == reqInfo->s.ubndDis.dstEnt.inst */

                  if ((tsapCb->cfg.dstEnt != reqInfo->s.ubndDis.dstEnt.ent) ||
                      (tsapCb->cfg.dstInst != reqInfo->s.ubndDis.dstEnt.inst))
                  {
                     /* one of the criteria does not match */
                     continue;
                  }
               }
               else
               {
                  /* unregcognised group type */
                  cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
                  break;
               }

               /* try and unbind it */
               switch (tsapCb->state)
               {
                  case LSO_TSAP_UBNDDIS:
                     break;

                  case LSO_TSAP_WAIT_BNDENA:
                     tsapCb->state = LSO_TSAP_UBNDDIS;
                     (Void) soSchedTmr (tsapCb, SO_TMR_TCM_BND,
                                        TMR_STOP, NOTUSED);
                     break;

                  case LSO_TSAP_BNDENA:
                     /* Close all transport servers */
                     soTptProcessTsapServers (tsapCb, SO_TCM_TPTSRV_DISABLE);

                     /* Close all TCP connections */
                     while ((cmHashListGetNext(&tsapCb->suConnIdHlCp,
                                               NULLP,
                                               (PTR *) &clientCb)) == ROK)
                     {
                     /* Here we are trying to close the clientCb Forcefully.
                      * We remove all the  references  to this clientCb and
                      * bring it down. */
                        soTptCloseClient (clientCb, FALSE);
                     }

                     tsapCb->state = LSO_TSAP_UBNDDIS;

                     soGenStaInd(STTSAP, LCM_CATEGORY_INTERNAL,
                                 LSO_EVENT_UBND_OK,
                                 LSO_CAUSE_SAP_UBNDDIS, LSO_PAR_SAP,
                                 (Ptr) &tsapCb->cfg.tSapId);
                     break;

                  case LSO_TSAP_WAIT_BNDDIS:
                     tsapCb->state = LSO_TSAP_UBNDDIS;
                     (Void) soSchedTmr (tsapCb, SO_TMR_TCM_BND,
                                        TMR_STOP, NOTUSED);
                     break;

                  case LSO_TSAP_BNDDIS:
                     tsapCb->state = LSO_TSAP_UBNDDIS;
                     soGenStaInd(STTSAP, LCM_CATEGORY_INTERNAL,
                                 LSO_EVENT_UBND_OK,
                                 LSO_CAUSE_SAP_UBNDDIS, LSO_PAR_SAP,
                                 (Ptr) &tsapCb->cfg.tSapId);
                     break;

                  default:
#if (ERRCLASS & ERRCLS_DEBUG)
                     SOLOGERROR(ERRCLS_DEBUG, ESO136, (ErrVal) tsapCb->state,
                        "SoMiShtCntrlReq: Invalid TSAP state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
                     break;
               }
            }
         }
         break;

      default:
         cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
         break;
   }

   /* response is sent withoput waiting for bind or unbind to complete */
   /* even if no SAPs are bound or unbound we still send success */

   if (cfmInfo.status.reason != LCM_REASON_NOT_APPL)
   {
      cfmInfo.status.status = LCM_PRIM_NOK;
   }
   else
   {
      cfmInfo.status.status = LCM_PRIM_OK;
   }

   /* send the response */
   SoMiShtCntrlCfm(&repPst, &cfmInfo);

   RETVALUE(ROK);
} /* end SoMiShtCntrlReq */
#endif /* SO_FTHA */

/**********************************************************
*
*       Fun:   initPtrArray
*
*       Desc:  Initialize array of pointers
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PRIVATE S16 initPtrArray
(
Ptr        **array,      /* Pointer to array of pointers */
U16        numEntries    /* Number of entries in array */
)
#else
PRIVATE S16 initPtrArray(array, numEntries)
Ptr        **array;      /* Pointer to array of pointers */
U16        numEntries;   /* Number of entries in array */
#endif
{
   Cntr        i;    /* Counter */

   TRC2(initPtrArray);

   /*SOALLOC(array, numEntries * SBUFSIZE(sizeof(Ptr)));*/
   /* SBUFSIZE only require for block alignment during reservation */
   SOALLOC(array, numEntries * (sizeof(Ptr)));

   if (*array == NULLP)
   {
      RETVALUE(RFAILED);
   }
   for (i = 0; i < numEntries; i++)
   {
      (*array)[i] = NULLP;
   }

   RETVALUE(ROK);
} /* initPtrArray */



/**********************************************************
*
*       Fun:   soMiAddTptServer
*
*       Desc:  Adds transport server to entity
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soMiAddTptServer
(
SoEntCb       *entCb,      /* Entity to add tpt server to */
SoTptSrvCfg   *srvCfg,     /* Configuration for new tpt server */
U16           *reason      /* Return reason */
)
#else
PUBLIC S16 soMiAddTptServer(entCb, srvCfg, reason)
SoEntCb       *entCb;      /* Entity to add tpt server to */
SoTptSrvCfg   *srvCfg;     /* Configuration for new tpt server */
U16           *reason;     /* Return reason */
#endif
{
   S16               ret;         /* Return value */
   U32               i;           /* Counter */
   U32               j;           /* Counter */
   Bool              ssapFound;   /* TRUE is SSAP already in entity SSap list */
   SoTptServerCb     *serverCb;   /* Transport server */
   SoTSapCb          *tsapCb;     /* TSAP */
   S16               hostLen;     /* Length of host name */
   S16               domainLen;   /* Length of domain name */
   Bool              addrMatch;   /* Addresses match */

   TRC2(soMiAddTptServer);

   /* default values */
   ret = ROK;

   /* Check if TSAP is valid - TSAP must be configured before tpt server */
   if ((srvCfg->tSapId < 0) || (srvCfg->tSapId > soCb.cfg.maxNmbTSaps))
   {
      *reason = LCM_REASON_INVALID_SAP;
      RETVALUE(RFAILED);
   }
   tsapCb = soCb.soTSapCbLst[srvCfg->tSapId];
   if (tsapCb == NULLP)
   {
      *reason = LCM_REASON_INVALID_SAP;
      RETVALUE(RFAILED);
   }

   /* Check transport server Id */
   if (srvCfg->tptSrvId >= soCb.maxTptSrv)
   {
      *reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if (soCb.allSrvCbLst[srvCfg->tptSrvId] != NULLP)
   {
      /* Transport server ID already used */
      *reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if ((srvCfg->nmbSSap == 0) || (srvCfg->nmbSSap > LSO_TPTSRV_MAX_SSAP))
   {
      /* Transport server without SSAPs */
      *reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   /* Find existing tptserver with this address (i.e. check for duplicate) */
   for (i = 0; i < soCb.maxTptSrv; i++)
   {
      serverCb = soCb.allSrvCbLst[i];
      if (serverCb != NULLP)
      {
         if ((soCmpTptAddr(&serverCb->localAddr, &srvCfg->tptAddr, &addrMatch)
            == ROK) && (serverCb->tptProt == srvCfg->tptProt))
         {
            /* Address and protocol match -> duplicate */
            (*reason) = LCM_REASON_INVALID_PAR_VAL;
            RETVALUE(RFAILED);
         }
      }
   }

   /* Create new transport server */
   SOALLOC (&serverCb, sizeof (SoTptServerCb));
   if (serverCb == NULLP)
   {
      *reason = LCM_REASON_MEM_NOAVAIL;
      RETVALUE(RFAILED);
   }

   /* Further initialize new address control block */

   /* Copy other parameters */
   serverCb->tptProt       = srvCfg->tptProt;
   (Void) cmMemcpy ((U8 *)&serverCb->localAddr, 
                    (U8 *)&srvCfg->tptAddr,
                    SBUFSIZE (sizeof (CmTptAddr)));

   (Void)cmMemcpy ((U8 *)&serverCb->tPar, 
                   (U8 *)&srvCfg->tPar,
                   sizeof (CmTptParam));

   serverCb->tsapCb        = tsapCb;
   serverCb->entCb         = entCb;

   serverCb->nmbSSap       = srvCfg->nmbSSap;
   (Void) cmMemcpy ((U8 *)(serverCb->sSapLst),
                    (U8 *)(srvCfg->sSapLst), 
                    (srvCfg->nmbSSap * sizeof(SpId)));

   /* initialize rest of the server control block */
   serverCb->state         = LSO_TPTSRV_DIS;
   serverCb->suConnId      = srvCfg->tptSrvId;
   serverCb->spConnId      = SO_INV_HIT_CONNID;
   serverCb->currentSSap   = 0;


   /* initialize the allSrvCbLst with the new serverCb */
   soCb.allSrvCbLst[serverCb->suConnId] = serverCb;

   cmLListInit (&serverCb->tcmConnLst);

   /* Initialize memory hash list and hostname only for non-DNS transport
    * servers. If it is the DNS transport server, entCb will be NULL
    */
   if (entCb != NULLP)
   {
      /* Construct full host name for this transport server */
      domainLen = cmStrlen((U8 *)entCb->domainName);
      hostLen   = cmStrlen((U8 *)srvCfg->hostname);

      serverCb->hostName.len = domainLen + hostLen;
      if ((domainLen > 0) && (hostLen > 0))
      {
         /* Add "." inbetween */
         serverCb->hostName.len++;
      }
  
      SOALLOC (&serverCb->hostName.val, serverCb->hostName.len);
      if (serverCb->hostName.val == NULLP)
      {
         /* alloc failed, exit */
         SOFREE(serverCb, sizeof(SoTptServerCb));
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(RFAILED);
      }
      serverCb->hostName.pres = PRSNT_NODEF;

      /* Copy domainName */

      if (hostLen > 0)
      {
         (Void)cmMemcpy((U8 *)serverCb->hostName.val, (U8 *)srvCfg->hostname,
            hostLen);
         
         /* In stead of allowing multiple domains,
          * we can cheat the stack by using multiple host names 
          * and set domain name to be NULL. So here we need to check
          * the length of domain before adding the domain name. */
         if(domainLen > 0)
         {
            /* Add "." then hostname */
            serverCb->hostName.val[hostLen] = '.';
            (Void)cmMemcpy((U8 *)&serverCb->hostName.val[hostLen+1],
               (U8 *)entCb->domainName, domainLen);
         }
      }
      /* Here we need to handle the case that host length = zero
       * but domain length != 0. */
      else
      {
         if(domainLen > 0)
         {
            /* Copy domainName */
            (Void)cmMemcpy((U8 *)serverCb->hostName.val, 
                           (U8 *)entCb->domainName, domainLen);
         }
         else
            serverCb->hostName.pres = NOTPRSNT;
      }
   }

   for (i = 0; i < serverCb->nmbSSap; i++)
   {
      /* check if SSAP is configured */
      if (soCb.soSSapCbLst[serverCb->sSapLst[i]] != (SoSSapCb *)NULLP)
      {
         /* loop through the whole SSap list on the entity */
         for (j = 0, ssapFound = FALSE; j < LSO_MAX_SSAP_PER_ENTITY; j++)
         {
            if (entCb->soSSapCbLst[j] != (SoSSapCb *)NULLP)
            {
               if (serverCb->sSapLst[i] == entCb->soSSapCbLst[j]->sapId)
               {
                  ssapFound = TRUE;
                  break;
               }
            }
         }

         /* ssap id not found in entity list */
         if (ssapFound == FALSE)
         {
              /* notice that the array is filled in from the left and is not
               referenced by sapId */
               entCb->soSSapCbLst[entCb->nmbSSap] =
                                 soCb.soSSapCbLst[serverCb->sSapLst[i]];
               entCb->nmbSSap++;

         }
      }
   }

   /* so010.201: Fix to guard opening of tpt srv with a timer */
   /* Copy open server timer value and counter */
   /* so035.201: Copy the retry count value as current retry count */
   serverCb->opnSrvRetryCnt    =  srvCfg->opnSrvRetryCnt;
   serverCb->opnSrvCurRetryCnt =  srvCfg->opnSrvRetryCnt;
   (Void) cmMemcpy ((U8 *)&serverCb->opnSrvTmr,
                    (U8 *)&srvCfg->opnSrvTmr,
                    (sizeof(TmrCfg)));

   soCmInitTimer(&serverCb->opnSrvTmrNode);

   RETVALUE(ROK);

} /* soMiAddTptServer */



/**********************************************************
*
*       Fun:   soSSapAddAssocTptSrv
*
*       Desc:  Association between SSAP and transport server
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes:
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soSSapAddAssocTptSrv
(
SoSSapCb *sSapCb, 
U32      **tptIdLst,
U8      entId,
U16       *reason
)
#else
PUBLIC S16 soSSapAddAssocTptSrv(sSapCb, tptIdLst, entId, reason)
SoSSapCb *sSapCb; 
U32      **tptIdLst;
U8      entId;
U16      *reason;
#endif
{
   U32               i;           /* Counter */
   U32               n;           /* Counter */
   Bool              ssapFound;    /* TRUE if Transport Server is found */
   SoTptServerCb     *serverCb;   /* Transport server */
   SoEntCb           *entCb;
   U32               *tptIdArray;

   tptIdArray = *tptIdLst;
   entCb = soCb.entLst[entId];
   
   if (tptIdArray == NULLP || entCb == NULLP)
       RETVALUE(LCM_PRIM_NOK);

   for (n = 0; n < soCb.maxTptSrv; n++)
   {
      serverCb = soCb.allSrvCbLst[tptIdArray[n]];
      ssapFound = FALSE; /* default */   
      
      if (serverCb == NULLP)
         break;
      if(serverCb->entCb != entCb )
      {
         *reason = LSO_REASON_INVALID_ENTID;
         RETVALUE(LCM_PRIM_NOK);
      }
      /* Check that SSAP association does not already exist */
      for (i = 0; i < serverCb->nmbSSap; i++)
      {
         if (serverCb->sSapLst[i] == sSapCb->sapId) 
         {
            ssapFound = TRUE; 
            break;
         }
      } 
      /* Transport Server and SSAP association not found. Add the assoc. */
      if (ssapFound == FALSE)
      { 
            /* notice that the array is filled in from the left and is not
           referenced by sapId */
            serverCb->sSapLst[i] = sSapCb->sapId; 
            serverCb->nmbSSap++;
      }
   }
   *reason  = LCM_REASON_NOT_APPL;
   RETVALUE(LCM_PRIM_OK);
} /* soSSapAddAssocTptSrv */

/**********************************************************
*
*       Fun:   soSSapDelAssocTptSrv
*
*       Desc:  Deletes association between SSAP and transport server
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes:
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soSSapDelAssocTptSrv
(
SoSSapCb *sSapCb, 
U32      **tptIdLst,
U8      entId,
U16       *reason
)
#else
PUBLIC S16 soSSapDelAssocTptSrv(sSapCb, tptIdLst, entId, reason)
SoSSapCb *sSapCb; 
U32      **tptIdLst;
U8      entId;
U16      *reason;
#endif
{
   U32               i;           /* Counter */
   U32               j;           /* Counter */
   U32               n;           /* Counter */
   SoTptServerCb     *serverCb;   /* Transport server */
   SoEntCb           *entCb;
   U32               *tptIdArray;
   
   entCb = soCb.entLst[entId];
   tptIdArray = *tptIdLst;

   if (tptIdArray == NULLP || entCb == NULLP)
       RETVALUE(LCM_PRIM_NOK);

   for (n = 0; n < soCb.maxTptSrv; n++)
   {
      serverCb = soCb.allSrvCbLst[tptIdArray[n]];
      
      if (serverCb == NULLP)
         break;

      if(serverCb->entCb != entCb)
      {
         *reason = LSO_REASON_INVALID_ENTID;
         RETVALUE(LCM_PRIM_NOK);
      }

      for (i = 0; i < serverCb->nmbSSap; i++)
      {
         if (serverCb->sSapLst[i] == sSapCb->sapId) 
         {
            for (j=i; j<serverCb->nmbSSap;j++)
            {
               serverCb->sSapLst[j] = serverCb->sSapLst[j+1]; /* Do some sorting */
            }
            serverCb->sSapLst[j] = 0; /* Zero the last one */
            --serverCb->nmbSSap;
            break;
         }
      } 
   }
   *reason  = LCM_REASON_NOT_APPL;
   RETVALUE(LCM_PRIM_OK);
} /* soSSapDelAssocTptSrv */


/**********************************************************
*
*       Fun:   soSipEntCfgReq
*
*       Desc:  Perform SIP layer configuration
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: Initializes SIP entity
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soSipEntCfgReq
(
SoCfg         *cfg,        /* Configuration structure */
U16           *reason      /* Return reason */
)
#else
PUBLIC S16 soSipEntCfgReq(cfg, reason)
SoCfg         *cfg;        /* Configuration structure */
U16           *reason;     /* Return reason */
#endif
{
   SoEntCfg       *entCfg;       /* Configuration structure */
   SoEntReCfg     *reCfg;        /* Reconfiguration structure */
   SoEntCb        *ent;          /* Pointer to entity being configured */
   /* so016.201 :-Memory Leak fix in Re-config of UA Entity*/
   S16            j;             /* Counter */
   U16            i;             /* Counter */
   S16            ret;           /* Return value */
#ifdef SO_NS
   SoNSCb         *nwSrv;        /* Server part of control block */
   U8             oldState;      /* Configured proxy state */
#endif
#ifdef SO_UA
   SoUACb         *ua;           /* UA part of control block */
   U16            numRegHlBins;  /* Number of reg hl bins */
   U8             supportedStrIdx;
   U16            numComp;
#endif

   U16            nmbUA;         /* Number of UA */
   U16            nmbNS;         /* Number of NS */
   U16            numCallIdHlBins;  /* Number of call-id hl bins */

   U16            numClientTransHlBins;
   U16            numServerTransHlBins;

   TRC2(soSipEntCfgReq);

   /* have to have general configuration done first */
   if (soCb.init.cfgDone == FALSE)
   {
      SODBGP_SO(DBGMASK_MI, (soCb.init.prntBuf,
                 "soSipEntCfgReq: general config not done\n"));
      *reason = LCM_REASON_GENCFG_NOT_DONE;
      RETVALUE(LCM_PRIM_NOK);
   }

   /* Set auxilary variables */
   entCfg = &cfg->c.entCfg;
   reCfg  = &cfg->r.entReCfg;

   /* Check entity ID */
   if (entCfg->entId >= (soCb.cfg.maxNmbUA + soCb.cfg.maxNmbNS))
   {
      SODBGP_SO(DBGMASK_MI, (soCb.init.prntBuf,
                 "soSipEntCfgReq: trying to config too many entities\n"));
      *reason = LCM_REASON_EXCEED_CONF_VAL;
      RETVALUE(LCM_PRIM_NOK);
   }

   /* Check entity type - required for config and reconfig */
#if (defined(SO_UA) && defined(SO_NS))
   if ((entCfg->type != LSO_ENT_UA) &&
       (entCfg->type != LSO_ENT_NS)) 
#else
#ifdef SO_UA
   if (entCfg->type != LSO_ENT_UA)
#else /* SO_UA */
#ifdef SO_NS
   if (entCfg->type != LSO_ENT_NS) 
#endif /* SO_NS */
#endif /* SO_UA */
#endif /* SO_NS && SO_UA */
   {
      SODBGP_SO(DBGMASK_MI, (soCb.init.prntBuf,
                       "soSipEntCfgReq: invalid entity type\n"));
      *reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(LCM_PRIM_NOK);
   }

   /* do actual configuration */
   ent = soCb.entLst[entCfg->entId];
   if (ent == NULLP)
   {
      /* This is a first time configuration */

      /* Check if quantities have not been exceeded */
      nmbUA = 0;
      nmbNS = 0;
      for (i = 0; i < (soCb.cfg.maxNmbUA + soCb.cfg.maxNmbNS); i++)
      {
         if (soCb.entLst[i] != NULLP)
         {
            if (soCb.entLst[i]->entityType == LSO_ENT_UA)
            {
               nmbUA++;
            }
            else
            {
               nmbNS++;
            }
         }
      }

      if ((entCfg->type == LSO_ENT_UA) && (nmbUA >= soCb.cfg.maxNmbUA))
      {
         SODBGP_SO(DBGMASK_MI, (soCb.init.prntBuf,
                 "soSipEntCfgReq: trying to configure too many UA's\n"));
         *reason = LCM_REASON_EXCEED_CONF_VAL;
         RETVALUE(LCM_PRIM_NOK);
      }

      if ((entCfg->type == LSO_ENT_NS) && (nmbNS >= soCb.cfg.maxNmbNS))
      {
         SODBGP_SO(DBGMASK_MI, (soCb.init.prntBuf,
                 "soSipEntCfgReq: trying to configure too many NS's\n"));
         *reason = LCM_REASON_EXCEED_CONF_VAL;
         RETVALUE(LCM_PRIM_NOK);
      }

      /* Range checking */
      if ((entCfg->tptSrvLstCfg.nmbTptSrv < LSO_TPTSRV_MIN) ||
          (entCfg->tptSrvLstCfg.nmbTptSrv > LSO_TPTSRV_MAX))
      {
         SODBGP_SO(DBGMASK_MI, (soCb.init.prntBuf,
                   "soSipEntCfgReq: nmbTptSrv out of range\n"));
         *reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(LCM_PRIM_NOK);
      }

#ifdef SO_UA
      if (entCfg->type == LSO_ENT_UA)
      {
         numCallIdHlBins  = entCfg->e.uaCfg.callIdHlBins;
         numRegHlBins = entCfg->e.uaCfg.regHlBins;
         numClientTransHlBins = entCfg->e.uaCfg.clientTransHlBins;
         numServerTransHlBins = entCfg->e.uaCfg.serverTransHlBins;
      }
#endif

      /* Create control block */
      SOALLOC_NOALARM(&ent, sizeof(SoEntCb));
      if (ent == NULLP)
      {
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(LCM_PRIM_NOK);
      }

      /* Initialize basic fields */
      ent->entId          = entCfg->entId;
      ent->entityType     = entCfg->type;
      ent->curState       = LSO_ENT_DISABLED;
      ent->lmState        = LSO_ENT_DISABLED;
      ent->nextTransId    = SOT_TRANCTXT_NOTUSED + 1;
      /* Initialize nextConnId */
      ent->nextConnId = SOT_CONNID_NOTUSED + 1;

#ifdef DEBUGP
      ent->dbgMask = 0;
#endif

#ifdef SO_NAT  
#ifdef SO_USE_UDP_SRVR
      ent->addRportByDflt        = entCfg->addRportByDflt;
#endif /* SO_USE_UDP_SRVR */
#endif /* SO_NAT */
      /* Start with no tracing */
      ent->trcLen  = 0;
      ent->trcMask = 0;

      /* initialize the array of pointers to SSAP control blocks */
      for (i = 0; i < LSO_MAX_SSAP_PER_ENTITY; i++)
      {
         ent->soSSapCbLst[i] = (SoSSapCb *) NULLP;
      }

      /* Initialize timer */
      soCmInitTimer(&ent->ctrlTmr);

      /*----- Initialize hashlists used for User Agent ------*/
      if (entCfg->type == LSO_ENT_UA)
      {
         /* initialize CallId hash list */
         ret = cmHashListInit(&ent->callIdLst,
                              numCallIdHlBins, 
                              (U16) SO_OFFSET_OF(SoCallCb, callIdHlEnt),
                              FALSE,
                              CM_HASH_KEYTYPE_STR,
                              soCb.init.region, soCb.init.pool);

         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO137, (ErrVal)0, "cmHashListInit() failed.");
#endif
            SOFREE(ent, sizeof(SoEntCb));
            *reason = LCM_REASON_MEM_NOAVAIL;
            RETVALUE(LCM_PRIM_NOK);
         }

         /* initialize spConnId hash list */
         ret = cmHashListInit(&ent->spConnIdLst,
                              numCallIdHlBins, 
                              (U16) SO_OFFSET_OF(SoCallCb, spConnIdHlEnt),
                              FALSE,
                              CM_HASH_KEYTYPE_U32MOD,
                              soCb.init.region, soCb.init.pool);
   
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO138, (ErrVal)0, "cmHashListInit() failed.");
#endif
            cmHashListDeinit (&ent->callIdLst);
            SOFREE(ent, sizeof(SoEntCb));
            *reason = LCM_REASON_MEM_NOAVAIL;
            RETVALUE(LCM_PRIM_NOK);
         }

#ifdef SO_REL_1_2_INF
         /* initialize spConnId hash list */
         ret = cmHashListInit(&ent->suConnIdLst,
                              numCallIdHlBins, 
                              (U16) SO_OFFSET_OF(SoCallCb, suConnIdHlEnt),
                              FALSE,
                              CM_HASH_KEYTYPE_U32MOD,
                              soCb.init.region, soCb.init.pool);

         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO139, (ErrVal)0, "cmHashListInit() failed.");
#endif
            cmHashListDeinit (&ent->callIdLst);
            cmHashListDeinit (&ent->spConnIdLst);
            SOFREE(ent, sizeof(SoEntCb));
            *reason = LCM_REASON_MEM_NOAVAIL;
            RETVALUE(LCM_PRIM_NOK);
         }

         /* Initialize Transaction Hash List */
         /* so012.201: Allow dulicate entries in transLst */
         ret = cmHashListInit (&ent->transLst,
                              numServerTransHlBins,
                              (U16)SO_OFFSET_OF (SoTransCb, transIdHlEnt),
                              TRUE,
                              CM_HASH_KEYTYPE_U32MOD,
                              soCb.init.region, soCb.init.pool);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR (ERRCLS_DEBUG, ESO140, (ErrVal)0, "cmHashListInit() failed.");
#endif
            cmHashListDeinit (&ent->callIdLst);
            cmHashListDeinit (&ent->spConnIdLst);
#ifdef SO_REL_1_2_INF
            cmHashListDeinit (&ent->suConnIdLst);
#endif
            SOFREE(ent, sizeof(SoEntCb));
            *reason = LCM_REASON_MEM_NOAVAIL;
            RETVALUE(LCM_PRIM_NOK);
         }
#endif /* SO_REL_1_2_INF */

         /* Initialize Client Transaction Hash List */
         ret = cmHashListInit (&ent->clientTransLst,
                              numClientTransHlBins,
                              (U16)SO_OFFSET_OF (SoTransCb, entityHlEnt),
                              TRUE,
                              CM_HASH_KEYTYPE_STR,
                              soCb.init.region, soCb.init.pool);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR (ERRCLS_DEBUG, ESO141, (ErrVal)0, "cmHashListInit() failed.");
#endif
            cmHashListDeinit (&ent->callIdLst);
            cmHashListDeinit (&ent->spConnIdLst);
#ifdef SO_REL_1_2_INF
            cmHashListDeinit (&ent->suConnIdLst);
            cmHashListDeinit (&ent->transLst);
#endif
            SOFREE(ent, sizeof(SoEntCb));
            *reason = LCM_REASON_MEM_NOAVAIL;
            RETVALUE(LCM_PRIM_NOK);
         }

         /* Initialize Server Transaction Hash List */
         ret = cmHashListInit (&ent->serverTransLst,
                              numServerTransHlBins,
                              (U16)SO_OFFSET_OF (SoTransCb, entityHlEnt),
                              TRUE,
                              CM_HASH_KEYTYPE_STR,
                              soCb.init.region, soCb.init.pool);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR (ERRCLS_DEBUG, ESO142, (ErrVal)0, "cmHashListInit() failed.");
#endif
            cmHashListDeinit (&ent->callIdLst);
            cmHashListDeinit (&ent->spConnIdLst);
#ifdef SO_REL_1_2_INF
            cmHashListDeinit (&ent->suConnIdLst);
            cmHashListDeinit (&ent->transLst);
#endif
            cmHashListDeinit (&ent->clientTransLst);
            SOFREE(ent, sizeof(SoEntCb));
            *reason = LCM_REASON_MEM_NOAVAIL;
            RETVALUE(LCM_PRIM_NOK);
         }
      }


      /* Set up entity domain name */
      (Void) cmMemcpy((U8 *)ent->domainName,
                      (U8 *)entCfg->domainName,
                      LSO_HOSTNAME_MAX_SZ);

      /* Initialize remainder of entity variables
       * These are all set to zero by SOALLOC
       *  ent->currentUdpAddr = 0;
       *  ent->currentTcpAddr = 0;
       *  ent->currentSSap    = 0;
       *  ent->nmbSSap        = 0;  Update at end of config to correct number
       *  ent->nmbTptAddr     = 0;
       *  ent->connId         = 0;
       *
       * SSAPCbLst contains only NULL pointers
       * addrCbLst contains only NULL pointers
       *
       * Following statistics fields all zeroed by SOALLOC:
       * summSts
       * methSts
       * respSts
       * otherSts
       */

      /* Initialize transport server list */
      for (i = 0; i < entCfg->tptSrvLstCfg.nmbTptSrv; i++)
      {
         /* Add one transport server */
         ret = soMiAddTptServer(ent,
                                &entCfg->tptSrvLstCfg.tptSrvCfg[i],
                                reason);
         if (ret != ROK)
         {
            /* Incorrect tpt server config - return */
            soTptProcessEntServer (ent, SO_TCM_TPTSRV_FREE, NULLP);
            if (entCfg->type == LSO_ENT_UA)
            {
              cmHashListDeinit (&ent->spConnIdLst);
#ifdef SO_REL_1_2_INF
              cmHashListDeinit (&ent->suConnIdLst);
              cmHashListDeinit (&ent->transLst);
#endif

              cmHashListDeinit (&ent->callIdLst);

              cmHashListDeinit (&ent->clientTransLst);
              cmHashListDeinit (&ent->serverTransLst);
            }

            SOFREE (ent, sizeof(SoEntCb));
            RETVALUE (LCM_PRIM_NOK);
         }
      }

      /* Do network server-specific initialization */
      if (ent->entityType == LSO_ENT_NS)
      {
#ifdef SO_NS
         nwSrv = &ent->s.ns;
         /* Copy config structure */
         (Void) cmMemcpy((U8 *)&(nwSrv->cfg),
                         (U8 *)&(entCfg->e.nsCfg),
                         sizeof(SoNSCfg));
         /* Clear statistics
          * These are all set to zero by SOALLOC
          *  nwSrv->sts <- 0
          */
#endif /* SO_NS */
      }
      else
      {
#ifdef SO_UA
         /* Must be UA */
         ua = &ent->s.ua;
         /* copy the UA configuration structure */
         (Void)cmMemcpy((U8 *)&(ent->s.ua.cfg),
                        (U8 *)&(entCfg->e.uaCfg),
                        sizeof(SoUACfg));

         /* Initialize statistics and status
          * sts <- 0
          * sta <- 0
          * Zeroed by SOALLOC
          */

         /* Initialize Client Transaction Hash List */
         ret = cmHashListInit (&ent->s.ua.regCbLst,
                              numRegHlBins,
                              (U16)SO_OFFSET_OF (SoUaRegCb, regHlEnt),
                              FALSE,
                              CM_HASH_KEYTYPE_STR,
                              soCb.init.region, soCb.init.pool);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR (ERRCLS_DEBUG, ESO143, (ErrVal)0, "cmHashListInit() failed.");
#endif
            cmHashListDeinit (&ent->callIdLst);
            cmHashListDeinit (&ent->spConnIdLst);
            cmHashListDeinit (&ent->clientTransLst);
            cmHashListDeinit (&ent->serverTransLst);
            /* so015.201 : Delete suConnIdLst and transLst for 1.2 interface */
#ifdef SO_REL_1_2_INF
            cmHashListDeinit(&ent->suConnIdLst);
            cmHashListDeinit(&ent->transLst);
#endif
            SOFREE(ent, sizeof(SoEntCb));
            *reason = LCM_REASON_MEM_NOAVAIL;
            RETVALUE(LCM_PRIM_NOK);
         }

         /* Initialize local user registry */
         ret = soClCacheInit(&(ent->s.ua.localUsrReg),
                             soCb.init.pool,
                             soCb.init.region,
                             SO_CACHE_LOC_USER_REG,
                             SO_CACHE_ENTRIES_PER_NODE,
                             soCb.cfg.locRegSz,
                             NULLD,
                             NULLD,
                             NULLD,
                             NULLD,
                             ent);
         if ( ret != ROK)
         {
            soTptProcessEntServer (ent, SO_TCM_TPTSRV_FREE, NULLP);
#ifdef LSO_ACNT
            cmHashListDeinit (&ent->spConnIdLst);
#endif
            cmHashListDeinit (&ent->callIdLst);
 
            cmHashListDeinit (&ent->clientTransLst);
            cmHashListDeinit (&ent->serverTransLst);
            /* so015.201 : Delete suConnIdLst and transLst for 1.2 interface */
#ifdef SO_REL_1_2_INF
            cmHashListDeinit(&ent->suConnIdLst);
            cmHashListDeinit(&ent->transLst);
#endif

            SOFREE (ent, sizeof (SoEntCb));
            *reason = LCM_REASON_MEM_NOAVAIL;
            RETVALUE (LCM_PRIM_NOK);
         }
#endif /* SO_UA */
      }
      /* At this point the new entity control block is valid - add to soCb */
      soCb.entLst[entCfg->entId] = ent;
   }

   /*----------------- Entity Reconfiguration -----------------*/

#if (defined(SO_UA) && defined(SO_NS))
   /* first check if we are reconfiguring it for the same type of entity */
   if (ent->entityType != entCfg->type)
   {
      *reason = LSO_REASON_INVALID_ENTID;
      RETVALUE(LCM_PRIM_NOK);
   }
#endif

   /* Common reconfiguration between UA & network server */
   (Void) cmMemcpy((U8 *)&(ent->reCfg), (U8 *)(reCfg), sizeof(SoEntReCfg));  

#ifdef SO_UA
   if ((ent->entityType == LSO_ENT_UA) &&
       ((cfg->r.entReCfg.e.uaReCfg.dfltPrxCfg.useDfltPrx) ||
       (cfg->r.entReCfg.e.uaReCfg.dfltPrxCfg.rcvDfltPrxOnly)))
   {
      SoSipUrl *sipUrl;

      (Void) soUtlDelSoRoute (&ent->s.ua.dfltRouteSet);

      /* Add new routeSeq */
      if (soCmGrowList ((Void ***)&ent->s.ua.dfltRouteSet.route, 
                        sizeof(SoRouteSeq),
                        &ent->s.ua.dfltRouteSet.numComp, NULLP) != ROK)
      {
         RETVALUE (LCM_PRIM_NOK);
      }
      
      SO_FILL_TKNPRES(&ent->s.ua.dfltRouteSet.route[0]->pres, PRSNT_NODEF);
      SO_FILL_TKNPRES(&ent->s.ua.dfltRouteSet.route[0]->nameAddr.pres,
                      PRSNT_NODEF);
      ent->s.ua.dfltRouteSet.route[0]->nameAddr.displayName.displayNameType.pres = NOTPRSNT;

      SO_FILL_TKNU8(&ent->s.ua.dfltRouteSet.route[0]->nameAddr.addrSpec.addrSpecType, SO_ADDRSPEC_SIPURL);

      sipUrl = &ent->s.ua.dfltRouteSet.route[0]->nameAddr.addrSpec.t.sipUrl;
      SO_FILL_TKNU8(&sipUrl->pres, PRSNT_NODEF);

      /* NO Userinfo or Header Required */
      sipUrl->userInfo.pres.pres = NOTPRSNT;
      sipUrl->headers.pres.pres  = NOTPRSNT;

      if (cfg->r.entReCfg.e.uaReCfg.dfltPrxCfg.choice == LSO_DFLT_PRX_DOMAIN_NAME)
      {
         U16 len;
         SoEvnt *evnt = NULLP;

         /* Domain Name for outbound proxy provided */
         len = cmStrlen((U8*)cfg->r.entReCfg.e.uaReCfg.dfltPrxCfg.t.domainName);
         SO_FILL_TKNU8(&sipUrl->hostPort.pres, PRSNT_NODEF);
         SO_FILL_TKNU8(&sipUrl->hostPort.host.hostType, SO_HOST_HOSTNAME);
         SO_FILL_TKNSTROSXL(&sipUrl->hostPort.host.t.hostName, 
                            (U8*)cfg->r.entReCfg.e.uaReCfg.dfltPrxCfg.t.domainName, len, evnt, ret);
         if (ret != ROK)
            RETVALUE (LCM_PRIM_NOK);
         sipUrl->hostPort.port.pres = NOTPRSNT;
      }
      else
      { 
         /* It must be IP address for outbound proxy provided */
         ret = soCmTptAddrToHostPort(&sipUrl->hostPort, 
                                     &cfg->r.entReCfg.e.uaReCfg.dfltPrxCfg.t.dfltPrxAddr, NULLP);
         if (ret != ROK)
         {
            *reason = LCM_REASON_INVALID_PAR_VAL;
            RETVALUE(LCM_PRIM_NOK);
         }
      }

      sipUrl->urlParameters.numComp.pres = NOTPRSNT;

     /* If Proxy Supports RFC 3261, Add "Loose router" parameter          */

     if (cfg->r.entReCfg.e.uaReCfg.dfltPrxCfg.looseRouter)
     {
        ret = soCmGrowList ((Void ***) &sipUrl->urlParameters.urlParameter,
                            sizeof (SoUrlParameter),
                            &sipUrl->urlParameters.numComp,
                            NULLP);
        if (ret != ROK)
            RETVALUE(LCM_PRIM_NOK);

        numComp = SO_GET_NUM_COMP (&sipUrl->urlParameters.numComp);

        SO_FILL_TKNU8(
             &sipUrl->urlParameters.urlParameter[numComp - 1]->urlParameterType,
             SO_URLPARAMETER_LRPARAM);
     }

#ifdef SO_COMPRESS
     /* If Proxy Supports Signalling Compression, add "sigComp" parameter */

     if (cfg->r.entReCfg.e.uaReCfg.dfltPrxCfg.sigCompSupp)
     {
        ret = soCmGrowList ((Void ***) &sipUrl->urlParameters.urlParameter,
                            sizeof (SoUrlParameter),
                            &sipUrl->urlParameters.numComp,
                            NULLP);
        if (ret != ROK)
            RETVALUE(LCM_PRIM_NOK);

        numComp = SO_GET_NUM_COMP (&sipUrl->urlParameters.numComp);

        SO_FILL_TKNU8(
             &sipUrl->urlParameters.urlParameter[numComp - 1]->urlParameterType,
             SO_URLPARAMETER_COMP);

        SO_FILL_TKNU8(
             &sipUrl->urlParameters.urlParameter[numComp - 1]->t.comp.valueType,
             SO_COMP_SIGCOMP);
     }
#endif

   } /* End of (if default proxy configured) */

#endif /* SO_UA */
   

#ifdef  SO_REFER

   /* Add the internal event packages to the 'standard' list */
   ent->reCfg.supportedStdEvntPkg[ent->reCfg.nmbStdEvntPkg].pres=PRSNT_NODEF;

   cmMemcpy((U8*)&(ent->reCfg.supportedStdEvntPkg[ent->reCfg.nmbStdEvntPkg].str),
            (U8*)SO_INT_EVENT_PACK_NAME_1,
            cmStrlen((U8 *)SO_INT_EVENT_PACK_NAME_1) + 1);

   ent->reCfg.nmbStdEvntPkg += LSO_NUM_INT_PACKAGES;
#endif

   /* Now do reconfiguration based on entity type */
   if (ent->entityType == LSO_ENT_UA)
   {
#ifdef SO_UA
      /* UA reconfiguration */
      
      /* copy the UA reconfiguration structure */
      (Void) cmMemcpy((U8 *)&ent->s.ua.reCfg,
                      (U8 *)&reCfg->e.uaReCfg,
                      sizeof(SoUAReCfg));

      soClCacheReConfig(&(ent->s.ua.localUsrReg),
                        cfg->r.entReCfg.e.uaReCfg.threshUpper,
                        cfg->r.entReCfg.e.uaReCfg.threshLower,
                        NULLD,
                        NULLD);
      /* so016.201 :- Memory Leak fix in Re-config of UA Entity*/
      if( SO_GET_NUM_COMP(&ent->s.ua.supported.numComp) != 0 )
      {
         for( j = SO_GET_NUM_COMP(&ent->s.ua.supported.numComp) - 1;
               j >= 0; j--)
         {
              soUtlDelTknStrOSXL(ent->s.ua.supported.stringList[j]);
              if(soCmShrinkList(
                     (Void ***)&ent->s.ua.supported.stringList,
                     sizeof(TknStrOSXL),
                     &ent->s.ua.supported.numComp,
                     NULLP) != ROK)
                 RETVALUE(RFAILED);
              if( ent->s.ua.supported.numComp.val == 0 )
              {
                 ent->s.ua.supported.numComp.pres = NOTPRSNT;
                 break;
              }
         }
      }
      supportedStrIdx = -1;
      ent->s.ua.supported.numComp.val = 0;
#ifdef SO_RFC_3262
      if (ent->s.ua.reCfg.relProvRspSupp == TRUE) 
      {
          /* Set supported header */
          if ( soCmGrowList((Void ***)&ent->s.ua.supported.stringList,
                            sizeof(TknStrOSXL),
                            &ent->s.ua.supported.numComp,
                            NULLP)!=ROK )
          {
            RETVALUE(RFAILED);
          }
          supportedStrIdx += 1;
          SO_FILL_TKNSTROSXL(
                        ent->s.ua.supported.stringList[supportedStrIdx],
                        SO_OPTIONTAG_100REL, SO_OPTIONTAG_100REL_LEN,
                        (SoEvnt *)NULLP, ret);
          if (ret != ROK)
             RETVALUE (LCM_PRIM_NOK);
      }
#endif
#ifdef SO_SESSTIMER
      if ( soCmGrowList((Void ***)&ent->s.ua.supported.stringList,
                   sizeof(TknStrOSXL),
                   &ent->s.ua.supported.numComp,
                   NULLP)!=ROK )
      {
         RETVALUE(RFAILED);
      }

      supportedStrIdx += 1;
      SO_FILL_TKNSTROSXL(
                     ent->s.ua.supported.stringList[supportedStrIdx],
                         SO_OPTIONTAG_TIMER, SO_OPTIONTAG_TIMER_LEN,
                         (SoEvnt *)NULLP, ret);
      if (ret != ROK)
         RETVALUE (LCM_PRIM_NOK);
#endif /* SO_SESSTIMER */

/* so038.201: Add precondition to list of options supportted if RFC3312 falg is defined */
#ifdef SO_RFC_3312
      if ( soCmGrowList((Void ***)&ent->s.ua.supported.stringList,
                   sizeof(TknStrOSXL),
                   &ent->s.ua.supported.numComp,
                   NULLP)!=ROK )
      {
         RETVALUE(RFAILED);
      }

      supportedStrIdx += 1;
      SO_FILL_TKNSTROSXL(
                     ent->s.ua.supported.stringList[supportedStrIdx],
                         SO_OPTIONTAG_PRECOND, SO_OPTIONTAG_PRECOND_LEN,
                         (SoEvnt *)NULLP, ret);
      if (ret != ROK)
         RETVALUE (LCM_PRIM_NOK);
#endif /* SO_RFC_3312 */
#endif /* SO_UA */
   }
   else
   {
#ifdef SO_NS
      /* Must be network server */
      /* NS reconfiguration */

      /* Save the existing state */
      oldState = ent->s.ns.reCfg.proxyReCfg.prxState;

      /* copy the NS reconfiguration structure */
      (Void) cmMemcpy((U8 *)&ent->s.ns.reCfg,
                      (U8 *)&reCfg->e.nsReCfg,
                      sizeof(SoNSReCfg));
      
      /* so026.201: Clear supported list before configuration */
      cmMemset((U8 *)&ent->s.ns.supported, 0, sizeof(SoTknStrOSXLLst));

      /* Change state from stateless to stateful */
      if ((oldState == LSO_PRX_STATELESS) &&
          ((ent->s.ns.reCfg.proxyReCfg.prxState == LSO_PRX_STATEFUL)))
      {
         /* TCP servers are not open in stateless mode -
          * try to open any configured TCP servers */
         soTptProcessEntServer (ent,SO_TCM_TPTSRV_OPEN, NULLP);
      }

      /* What state to start in? */
      /* Initialize remote user registry? or part of config? */

      /* Set supported header */
      soCmGrowList((Void ***)&ent->s.ns.supported.stringList,
                   sizeof(TknStrOSXL),
                   &ent->s.ns.supported.numComp,
                   NULLP);

      SO_FILL_TKNSTROSXL(ent->s.ns.supported.stringList[0],
                         SO_OPTIONTAG_100REL, SO_OPTIONTAG_100REL_LEN,
                         (SoEvnt *)NULLP, ret);
      if (ret != ROK)
        RETVALUE(LCM_PRIM_OK);

#endif /* SO_NS */
   }

   RETVALUE(LCM_PRIM_OK);

} /* soSipEntCfgReq */


/**********************************************************
*
*       Fun:   soMiTptSrvOpenInd
*
*       Desc:  Indication from TCM that transport server opened OK
*
*       Ret:   Nothing
*
*       Notes: Enabled associated entity automatically
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC Void soMiTptSrvOpenInd
(
SoTptServerCb   *serverCb        /* Transport server control block */
)
#else
PUBLIC Void soMiTptSrvOpenInd(serverCb)
SoTptServerCb   *serverCb;       /* Transport server control block */
#endif
{
   SoEntCb     *entCb;     /* Associated entity */

   TRC2(soMiTptSrvOpenInd);

   /* send alarm to mark the enabling of the transport server */
   soGenStaInd(STTPTSRV, LCM_CATEGORY_INTERNAL, LSO_EVENT_TPTSRV_ENA,
               LCM_CAUSE_UNKNOWN, LSO_PAR_TPTSRV, (Ptr) &serverCb->suConnId);

   entCb = serverCb->entCb;

   if (entCb == NULLP)
   {
      /* This was the DNS server - DNS is now available */
      RETVOID;
   }
   switch (entCb->curState)
   {
      case LSO_ENT_DISABLED:
         if (entCb->lmState == LSO_ENT_ENABLED)
         {
            /* Was enabled from LM, so allow automatic enabling */
            entCb->curState = LSO_ENT_ENABLED;
            /* Get time stamp for ent uptime */
            SGetDateTime(&entCb->entEnbTime);

            /* SM alarm */
            soGenStaInd(STSIPENT, LCM_CATEGORY_INTERNAL , LSO_EVENT_ENT_ENA,
               LCM_CAUSE_UNKNOWN,LSO_PAR_ENT, &entCb->entId );
            /* so033.201: Provide cntrlcfm to LMI */
            if (serverCb->waitFinalCfm == TRUE)
            {
               /* This was config from LMI */
               soSendLmCntrlCfm(&soCb.init.lmPst,
                  LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                  &serverCb->ctrlHdr);
               serverCb->waitFinalCfm = FALSE;
            }
         }
         break;
      case LSO_ENT_ENABLED:
         /* Ignore */
         if (serverCb->waitFinalCfm == TRUE)
         {
            /* This was config from LMI */
            soSendLmCntrlCfm(&soCb.init.lmPst,
               LCM_PRIM_OK, LCM_REASON_NOT_APPL,
               &serverCb->ctrlHdr);
            serverCb->waitFinalCfm = FALSE;
         }
         break;
      case LSO_ENT_WAIT_ENB:
         /* Change state to enabled, send LM confirm OK */
         entCb->curState = LSO_ENT_ENABLED;

         /* Get time stamp for ent uptime */
         SGetDateTime(&entCb->entEnbTime);

         /* SM alarm */
         soGenStaInd(STSIPENT, LCM_CATEGORY_INTERNAL , LSO_EVENT_ENT_ENA ,
                     LCM_CAUSE_UNKNOWN,LSO_PAR_ENT, &entCb->entId );

         if (serverCb->waitFinalCfm == TRUE)
         {
            /* This was config from LMI */
           soSendLmCntrlCfm(&serverCb->pst,
              LCM_PRIM_OK, LCM_REASON_NOT_APPL,
              &serverCb->ctrlHdr);
           serverCb->waitFinalCfm = FALSE;

         }
         if (entCb->waitFinalCfm == TRUE)
         {
            /* Was from entity config */
            soSendLmCntrlCfm(&entCb->pst,
               LCM_PRIM_OK, LCM_REASON_NOT_APPL,
               &entCb->ctrlHdr);
            entCb->waitFinalCfm = FALSE;
         }
         break;
      case LSO_ENT_WAIT_DIS:
         /* Ignore */
         break;
   }
   RETVOID;
} /* soMiTptSrvOpenInd */



/**********************************************************
*
*       Fun:   soMiTptSrvCloseInd
*
*       Desc:  Indication from TCM that transport server has been closed
*
*       Ret:   Nothing
*
*       Notes: Disables associated entity if required
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC Void soMiTptSrvCloseInd
(
SoTptServerCb   *serverCb,    /* Transport server control block */
Bool            fromLMI       /* From LMI */
)
#else
PUBLIC Void soMiTptSrvCloseInd (serverCb, fromLMI)
SoTptServerCb   *serverCb;    /* Transport server control block */
Bool            fromLMI;      /* From LMI */
#endif
{
   SoEntCb        *entCb;     /* Associated entity */
   Bool           openSrv;    /* TRUE if at least one tpt server is open */
   SoTptServerCb  *curSrv;    /* Server pointer in allSrvCbLst */
   U16            i;          /* Counter */

   TRC2(soMiTptSrvCloseInd);

   if (fromLMI == TRUE)
   {
      soGenStaInd(STTPTSRV,
                  LCM_CATEGORY_INTERNAL,
                  LSO_EVENT_TPTSRV_DIS,
                  LCM_CAUSE_MGMT_INITIATED,
                  LSO_PAR_TPTSRV,
                  (Ptr) &serverCb->suConnId);
   }
   else
   {
      soGenStaInd(STTPTSRV,
                  LCM_CATEGORY_INTERNAL,
                  LSO_EVENT_TPTSRV_DIS,
                  LSO_CAUSE_LI_INITIATED,
                  LSO_PAR_TPTSRV,
                  (Ptr) &serverCb->suConnId);
   }

   entCb = serverCb->entCb;

   if (entCb == NULLP)
   {
      /* This was the DNS server - DNS is now not available any more */
      RETVOID;
   }
   switch (entCb->curState)
   {
      case LSO_ENT_DISABLED:
         /* Ignore */
         break;

      case LSO_ENT_WAIT_DIS:
      case LSO_ENT_ENABLED:
         /* Check if any more tpt servers remain open, if not disabled
          * entity and send alarm to LM
          */
         openSrv = FALSE;
         for (i = 0; i < soCb.maxTptSrv; i++)
         {
            curSrv = soCb.allSrvCbLst[i];
            /* Check if curSrv for the DNS tptSrv is valid */
            if (( curSrv != NULLP) && (curSrv->entCb != NULLP))
            {
               if ((curSrv->entCb->entId == entCb->entId) &&
                   (curSrv->state == LSO_TPTSRV_ENA))
               {
                  openSrv = TRUE;
                  break;
               }
            }
         }

         if (openSrv == FALSE)
         {
            entCb->curState = LSO_ENT_DISABLED;
            /* send alarm only if DISABLE is not initiated by LMI */
            if (entCb->lmState == LSO_ENT_ENABLED)
            {
               soGenStaInd(STSIPENT,
                        LCM_CATEGORY_INTERNAL,
                        LSO_EVENT_ENT_DIS,
                        LSO_CAUSE_TPT_FAIL,
                        LSO_PAR_ENT,
                        &entCb->entId);
            }

         }

         break;

      case LSO_ENT_WAIT_ENB:
         /* Ignore */
         break;
   }
   RETVOID;
} /* soMiTptSrvCloseInd */




/**********************************************************
*
*       Fun:   soSipEntEna
*
*       Desc:  Enable a SIP UA or NS
*
*       Ret:   ROK/RFAILED
*
*       Notes: Enable SIP entity
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soSipEntEna
(
SoEntCb    *entCb        /* Entity to disable */
)
#else
PUBLIC S16 soSipEntEna(entCb)
SoEntCb    *entCb;       /* Entity to disable */
#endif
{
   Bool        someOpen;    /* At least one tpt server is open */

   TRC2(soSipEntEna);

   /* Do common processing for all entities */
   /* Check entity state */
   switch (entCb->curState)
   {
      case LSO_ENT_WAIT_DIS:
         /* Cannot enable during disable */
         soSendLmCntrlCfm(&entCb->pst,
            LCM_PRIM_NOK, LCM_REASON_INVALID_STATE,
            &entCb->ctrlHdr);
         break;

      case LSO_ENT_WAIT_ENB:
         /* Already busy enabling, just confirm */
         entCb->waitFinalCfm = TRUE;
         soSendLmCntrlCfm(&entCb->pst,
            LCM_PRIM_OK_NDONE, LCM_REASON_NOT_APPL,
            &entCb->ctrlHdr);
         break;
      case LSO_ENT_ENABLED:
         soSendLmCntrlCfm(&entCb->pst,
            LCM_PRIM_OK, LCM_REASON_NOT_APPL, &entCb->ctrlHdr);
         soTptProcessEntServer(entCb, SO_TCM_TPTSRV_OPEN, NULLP);
         break;

      case LSO_ENT_DISABLED:

         /* At this point we know it is a first time enable for this entity */
         entCb->currentUDPSrv  = 0;
         entCb->currentTCPSrv  = 0;
#ifdef SO_TLS
         entCb->currentTLSSrv  = 0;
#endif

         /* Try to open transport servers */
         /*chendh modify it:It will open server when receive Bind confirm.
           so this does not need to open again*/
         /*if (soTptProcessEntServer(entCb, SO_TCM_TPTSRV_OPEN, &someOpen) == 0)
         {
            /* No transport servers could be opened * /
            soSendLmCntrlCfm(&entCb->pst,
               LCM_PRIM_NOK, LSO_REASON_NO_TPTSERVERS,
               &entCb->ctrlHdr);
            RETVALUE(ROK);
         }*/
         someOpen = TRUE; /*chendh add*/
         if (someOpen == TRUE)
         {
            /* At this point advance state to ENABLED directly */
            entCb->curState = LSO_ENT_ENABLED;
            entCb->lmState  = LSO_ENT_ENABLED;

            /* Get time stamp for ent uptime */
            SGetDateTime(&entCb->entEnbTime);

            entCb->waitFinalCfm = FALSE;
            soSendLmCntrlCfm(&entCb->pst,
                             LCM_PRIM_OK,
                             LCM_REASON_NOT_APPL,
                             &entCb->ctrlHdr);

            soGenStaInd(STSIPENT,
                        LCM_CATEGORY_INTERNAL,
                        LSO_EVENT_ENT_ENA,
                        LCM_CAUSE_UNKNOWN,
                        LSO_PAR_ENT,
                        &entCb->entId);
         }
         else            
         {
            /* so028.201: To take care of case when all transport 
             * servers get enabled till the time execution reaches 
             * this point, this can happens when HIT is tightly coupled
             */

            U16            i;          /* Counter */
            SoTptServerCb  *serverCb;  /* Transport server to close */
            U16            serverCfg;  /* Total no. of server configured for the entity*/ 
            U16            serverEnable;  /* Number of server enabled for the entity*/

            /*----- For each configured transport server ..... -----*/
            serverCfg = 0;
            serverEnable = 0;

            for (i = 0; i < soCb.maxTptSrv; i++)
            {
               if ((serverCb = soCb.allSrvCbLst[i]) == NULLP)
                  continue;

               if (serverCb->entCb != entCb)
                  continue;

               if (serverCb->state == LSO_TPTSRV_ENA)
               {
                    serverEnable++;
               }
               serverCfg++;

            }

            if(serverCfg == serverEnable)
            {
               /* When all Transport Server for Entity are Enabled, 
                * make the entity enable */
               entCb->curState = LSO_ENT_ENABLED;
               entCb->lmState  = LSO_ENT_ENABLED;
               entCb->waitFinalCfm = FALSE;
               soSendLmCntrlCfm(&entCb->pst,
                     LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                     &entCb->ctrlHdr);
            }
            else
            {
               /* At this point advance state to WAIT_ENB */
               entCb->curState = LSO_ENT_WAIT_ENB;
               entCb->lmState  = LSO_ENT_ENABLED;
               entCb->waitFinalCfm = TRUE;
               soSendLmCntrlCfm(&entCb->pst,
                     LCM_PRIM_OK_NDONE, LCM_REASON_NOT_APPL,
                     &entCb->ctrlHdr);
            }
         }
         break;
      default:
         /* Invalid state */
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO144, (ErrVal) entCb->curState,
            "soSipEntEna: Invalid entity state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         soSendLmCntrlCfm(&entCb->pst,
            LCM_PRIM_NOK, LCM_REASON_INVALID_STATE,
            &entCb->ctrlHdr);
         break;
   }

   RETVALUE(ROK);

} /* end of soSipEntEna */



/**********************************************************
*
*       Fun:   soTmrEntityControl
*
*       Desc:  Timer function for entity control
*
*       Ret:   Nothing
*
*       Notes: If this is called the control action failed
*              due to no response received from the lower interface
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC Void soTmrEntityControl
(
SoEntCb    *entCb        /* Entity */
)
#else
PUBLIC Void soTmrEntityControl(entCb)
SoEntCb    *entCb;       /* Entity */
#endif
{

   TRC2(soTmrEntityControl);

   switch (entCb->curState)
   {
      case LSO_ENT_WAIT_DIS:
         /* Close tpt servers */
         soTptProcessEntServer(entCb, SO_TCM_TPTSRV_CLOSE, NULLP);

         entCb->curState = LSO_ENT_DISABLED;
         soSendLmCntrlCfm(&entCb->pst,
            LCM_PRIM_OK, LCM_REASON_NOT_APPL,
            &entCb->ctrlHdr);
         break;
      default:
         /* Ignore timer in all other cases */
         break;
   }

   RETVOID;
} /* soTmrEntityControl */




/**********************************************************
*
*       Fun:   soSipEntDis
*
*       Desc:  Disable SIP entity
*
*       Ret:   Nothing
*
*       Notes: Disables SIP entity
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
 PUBLIC Void soSipEntDis
(
SoEntCb    *entCb,       /* Entity to disable   */
Bool       graceful,     /* Do graceful disable */
Bool       genCfm        /* Generate LM confirm */
)
#else
PUBLIC Void soSipEntDis(entCb, graceful, genCfm)
SoEntCb    *entCb;       /* Entity to disable   */
Bool       graceful;     /* Do graceful disable */
Bool       genCfm;       /* Generate LM confirm */
#endif
{
   SoCallCb       *delCall;    /* Call to be deleted */
   SoCLegCb       *cLeg;       /* Call leg to complete             */
   CmLList        *curNode;    /* Current node in list             */
   PTR            curItem;     /* Current item                     */
   S16            i;           /* Counter                          */

#ifdef SO_UA
   /*so030.201:- Removing transaction which are not part of any Call */
   SoTransCb      *transCb      /* Transaction Control Block      */
#endif /* SO_UA */
   

   TRC2(soSipEntDis);

   switch (entCb->curState)
   {
      case LSO_ENT_DISABLED:
         /* Already disabled */
         if (genCfm == TRUE)
         {
            soSendLmCntrlCfm(&entCb->pst,
                             LCM_PRIM_OK,
                             LCM_REASON_NOT_APPL,
                             &entCb->ctrlHdr);
         }
         entCb->lmState = LSO_ENT_DISABLED;
         break;

      case LSO_ENT_WAIT_ENB:
         /* Close tpt servers */
         entCb->lmState = LSO_ENT_DISABLED;
         soGenStaInd(STSIPENT,
                     LCM_CATEGORY_INTERNAL,
                     LSO_EVENT_ENT_DIS,
                     LCM_CAUSE_MGMT_INITIATED,
                     LSO_PAR_ENT,
                     &entCb->entId);

         soTptProcessEntServer(entCb, SO_TCM_TPTSRV_CLOSE, NULLP);
         entCb->curState = LSO_ENT_DISABLED;

         if (genCfm == TRUE)
         {
            soSendLmCntrlCfm(&entCb->pst,
               LCM_PRIM_OK, LCM_REASON_NOT_APPL,
               &entCb->ctrlHdr);
         }
         break;

      case LSO_ENT_WAIT_DIS:
         entCb->lmState = LSO_ENT_DISABLED;
         if (graceful == TRUE)
         {
            /* Busy, wait */
            entCb->waitFinalCfm = TRUE;
            if (genCfm == TRUE)
            {
               soSendLmCntrlCfm(&entCb->pst,
                                LCM_PRIM_OK_NDONE,
                                LCM_REASON_NOT_APPL,
                                &entCb->ctrlHdr);
            }
         }
         else
         {
            /* Already busy disabling */
            /* Close tpt servers */
            soTptProcessEntServer(entCb, SO_TCM_TPTSRV_CLOSE, NULLP);

            soSchedTmr(entCb, SO_TMR_ENTITY_CONTROL, TMR_STOP, NOTUSED);
            entCb->curState = LSO_ENT_DISABLED;
            if (genCfm == TRUE)
            {
               soSendLmCntrlCfm(&entCb->pst,
                                LCM_PRIM_OK,
                                LCM_REASON_NOT_APPL,
                                &entCb->ctrlHdr);
            }
         }
         break;

      case LSO_ENT_ENABLED:
         entCb->lmState = LSO_ENT_DISABLED;
         soGenStaInd(STSIPENT,
                     LCM_CATEGORY_INTERNAL,
                     LSO_EVENT_ENT_DIS,
                     LCM_CAUSE_MGMT_INITIATED,
                     LSO_PAR_ENT,
                     &entCb->entId);

         if (entCb->entityType == LSO_ENT_UA)
         {
#ifdef SO_UA
            /* Free supported list */
            for (i = SO_GET_NUM_COMP(&entCb->s.ua.supported.numComp) - 1; 
                 i >= 0; i --)
            {
               soUtlDelTknStrOSXL(entCb->s.ua.supported.stringList[i]);

               if (soCmShrinkList((Void ***)&entCb->s.ua.supported.stringList,
                                  sizeof(TknStrOSXL),
                                  &entCb->s.ua.supported.numComp,
                                  NULLP) != ROK)
                 RETVOID;

            }
            soUtlDelSoAllow(&entCb->s.ua.allow);
            soClCacheDeinit(&entCb->s.ua.localUsrReg);
            soUtlDelTknStrOSXL(&entCb->s.ua.regCallId);
#endif /* SO_UA */
         }


         if (entCb->entityType == LSO_ENT_NS)
         {
#ifdef SO_NS
            /* Free supported list */
            for (i = SO_GET_NUM_COMP(&entCb->s.ns.supported.numComp) - 1; 
                 i >= 0; i --)
            {
               soUtlDelTknStrOSXL(entCb->s.ns.supported.stringList[i]);
               if (soCmShrinkList((Void ***)&entCb->s.ns.supported.stringList,
                              sizeof(TknStrOSXL),
                              &entCb->s.ns.supported.numComp,
                                  NULLP) != ROK)
                 RETVOID;
            }
#endif /* SO_NS */
         }

         if (graceful == TRUE)
         {
            /* Entity function to send BYE/CANCEL */
            delCall = (SoCallCb *) NULLP;
            cLeg    = (SoCLegCb *) NULLP;

            while (cmHashListGetNext(&entCb->callIdLst, (PTR) delCall,
               (PTR *) &delCall) == ROK)
            {
               /* Process all call legs in call */
               curNode = cmLListFirst(&delCall->cLegLst);
               while (curNode != NULLP)
               {
                  curItem  = cmLListNode(curNode);
                  curNode  = curNode->next;
                  cLeg     = (SoCLegCb *)curItem;

                  if (cLeg != (SoCLegCb *) NULLP)
                  {
                     switch (entCb->entityType)
                     {
#ifdef SO_UA
                        case SO_ENT_UA:
                           /* Since it is graceful deletion, so send
                            * protocol msgs. to close the active call-legs
                            * give proper indication to the SU */
                           soUaEndCall(cLeg);
                           break;
#endif /* SO_UA */
#ifdef SO_NS
                        case SO_ENT_NS:
                           break;
#endif /* SO_NS */
                     }
                  }
               }
            }

            soSchedTmr(entCb, SO_TMR_ENTITY_CONTROL, TMR_START,
               SO_TMRVAL_ENT_DIS);
            entCb->curState     = LSO_ENT_WAIT_DIS;
            entCb->waitFinalCfm = TRUE;
            if (genCfm == TRUE)
            {
               soSendLmCntrlCfm(&entCb->pst,
                                LCM_PRIM_OK_NDONE,
                                LCM_REASON_NOT_APPL,
                                &entCb->ctrlHdr);
            }
         }
         else
         {
            /* Active entity - close tpt servers */
            soTptProcessEntServer(entCb, SO_TCM_TPTSRV_CLOSE, NULLP);
            entCb->curState = LSO_ENT_DISABLED;
            if (genCfm == TRUE)
            {
               soSendLmCntrlCfm(&entCb->pst,
                                LCM_PRIM_OK,
                                LCM_REASON_NOT_APPL,
                                &entCb->ctrlHdr);
            }
         }
         break;

      default:
         /* Invalid state */
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO145, (ErrVal) entCb->curState,
            "soSipEntDis: Invalid entity state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         if (genCfm == TRUE)
         {
            soSendLmCntrlCfm(&entCb->pst,
               LCM_PRIM_NOK, LCM_REASON_INVALID_STATE,
               &entCb->ctrlHdr);
         }
   }

#ifdef SO_UA
   /* Destroy all outstanding call control blocks for entity */
   if (entCb->entityType == SO_ENT_UA)
   {
     while (cmHashListGetNext(&entCb->callIdLst, NULLP, (PTR *) &delCall) == ROK)
     {
       soCoreDeleteCallCb(delCall);
     }
   }

   /*so030.201:- Removing transaction which are not part of any Call */
   /*---- Delete TCB entry from EntityCb hash list -----*/
   /*------ Release from UAS Transaction List ------*/
   while (cmHashListGetNext(&entCb->serverTransLst, (PTR) NULLP,
                            (PTR *) &transCb) == ROK)
   {
     soTxnDeleteTrans(transCb);
   }

   /*------ Release from UAC Transaction List ------*/
   while (cmHashListGetNext(&entCb->clientTransLst, (PTR) NULLP,
                            (PTR *) &transCb) == ROK)
   {
     soTxnDeleteTrans(transCb);
   }

#endif /* SO_UA */

   RETVOID;
} /* end of soSipEntDis */



/**********************************************************
*
*       Fun:   soSipEntDel
*
*       Desc:  Delete SIP entity
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC Void soSipEntDel
(
SoEntCb    *entCb,       /* Entity to delete */
Bool       genCfm        /* Generate confirm to LM */
)
#else
PUBLIC Void soSipEntDel(entCb, genCfm)
SoEntCb    *entCb;       /* Entity to delete */
Bool       genCfm;       /* Generate confirm to LM */
#endif
{
   S16            i;          /* counter      */
   U8             entId;      /* Entity ID    */
   U16            tmpReason;  /* Temporary for call to ssapDel */
#ifdef SO_UA
   SoCallCb       *delCall;   /* calls belonging to this entity */
   SoUaRegCb      *regCb;
#endif
   Pst            pst;           /* Post structure */
   Header         hdr;           /* Header to use in confirm */

   TRC2(soSipEntDel);

   entId = entCb->entId;

   if (entCb->curState == LSO_ENT_ENABLED)
   {
      /* Do immediate disable of entity */
      soSipEntDis(entCb, FALSE, FALSE);
   }

   /* Remove all transactions pending for entity */

   /* Free all SSAP's for entity */
   for (i = 0; i < LSO_MAX_SSAP_PER_ENTITY; i++)
   {
      if (entCb->soSSapCbLst[i] != NULLP)
      {
         /* Unbind and delete SSAP */
         soSSapDel(entCb->soSSapCbLst[i], &tmpReason);
      }
   }

   /* Free all transport servers */
   soTptProcessEntServer(entCb, SO_TCM_TPTSRV_FREE, NULLP);

#ifdef SO_UA
   if (entCb->entityType == LSO_ENT_UA)
   {
     /* Destroy all outstanding call control blocks for entity */
     while (cmHashListGetNext(&entCb->callIdLst, NULLP, (PTR *) &delCall) == ROK)
     {
       soCoreDeleteCallCb(delCall);
     }
   }
#endif /* SO_UA */
   cmHashListDeinit(&entCb->callIdLst);
   cmHashListDeinit(&entCb->spConnIdLst);

   cmHashListDeinit(&entCb->clientTransLst);
   cmHashListDeinit(&entCb->serverTransLst);

   /* so015.201 : Delete suConnIdLst and transLst for 1.2 interface */
#ifdef SO_REL_1_2_INF
   cmHashListDeinit(&entCb->suConnIdLst);
   cmHashListDeinit(&entCb->transLst);
#endif
   
   /* Get rid of caches & registries specific to entity */
#ifdef SO_UA
   if (entCb->entityType == LSO_ENT_UA)
   {
      /* Free supported list */
      for (i=SO_GET_NUM_COMP(&entCb->s.ua.supported.numComp)-1; i>=0; i--)
      {
         soUtlDelTknStrOSXL(entCb->s.ua.supported.stringList[i]);

         if (soCmShrinkList((Void ***)&entCb->s.ua.supported.stringList,
                        sizeof(TknStrOSXL),
                        &entCb->s.ua.supported.numComp,
                            NULLP) != ROK)
           RETVOID;
      }
      soUtlDelSoAllow(&entCb->s.ua.allow);
      soClCacheDeinit(&entCb->s.ua.localUsrReg);
      soUtlDelTknStrOSXL(&entCb->s.ua.regCallId);

      while (cmHashListGetNext(&entCb->s.ua.regCbLst, (PTR) NULLP,
                               (PTR *) &regCb) == ROK)
      {   
        soUaDeleteRegCb(entCb, regCb);
      }
      /* so016.201 : Deinitialize regCbLst */
      cmHashListDeinit(&entCb->s.ua.regCbLst);
         
   }
#endif /* SO_UA */

#ifdef SO_NS
   if (entCb->entityType == LSO_ENT_NS)
   {
      /* Free supported list */
      for (i=SO_GET_NUM_COMP(&entCb->s.ns.supported.numComp)-1; i>=0; i--)
      {
         soUtlDelTknStrOSXL(entCb->s.ns.supported.stringList[i]);

         if (soCmShrinkList((Void ***)&entCb->s.ns.supported.stringList,
                        sizeof(TknStrOSXL),
                        &entCb->s.ns.supported.numComp,
                            NULLP) != ROK)
           RETVOID;
      }
   }
#endif /* SO_NS */

   /* Save Pst and control header  */
   cmMemcpy((U8 *)&hdr, (U8 *)&entCb->ctrlHdr, sizeof(Header));
   cmMemcpy((U8 *)&pst, (U8 *)&entCb->pst, sizeof(Pst));

   /* Free control block itself */
   SOFREE(entCb, SBUFSIZE(sizeof(SoEntCb)));

   /* Remove reference in soCb */
   soCb.entLst[entId] = NULLP;

   /* 
    * Send Control Confirm to layer manager. This should be
    * as a last step in the layer
    */
   if (genCfm == TRUE)
   {
       soSendLmCntrlCfm (&pst, LCM_PRIM_OK, LCM_REASON_NOT_APPL, &hdr);
   }

   RETVOID;

} /* end of soSipEntDel */



#ifdef LSO_ACNT

/**********************************************************
*
*       Fun:   soMiAccntRecBuild
*
*       Desc:  Build an SoAcntInfo accounting record
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PRIVATE Void soMiAccntRecBuild
(
SoAcntInfo  *acnt,            /* accounting information */
SoCLegCb    *leg              /* Call Leg for the call */
)
#else
PRIVATE Void soMiAccntRecBuild(acnt, leg)
SoAcntInfo  *acnt;            /* accounting information */
SoCLegCb    *leg;             /* Call Leg for the call */
#endif
{
   S16         loop;
   DateTime    tod;              /* current time of day         */
   Duration    duration;         /* duration of Call in seconds */


   TRC2(soMiAccntRecBuild);

   /* Calculate Call duration */
   if (SO_DATETIME_SET(&leg->accntCb.callEnd))
   {
      soCmGetDuration(&leg->accntCb.callStart, &leg->accntCb.callEnd, 
                      &duration);
   }
   else
   {
      /* Get current time */
      SGetDateTime(&tod);
      soCmGetDuration(&leg->accntCb.callStart, &tod, &duration);
   }

   acnt->dt        = leg->accntCb.callStart;
   acnt->duration  = duration;
   acnt->entId     = leg->call->ent->entId;
   acnt->spconnId  = leg->call->spConnId;
   acnt->legId     = leg->legId;
   acnt->type      = leg->accntCb.accType;
   acnt->origin    = leg->accntCb.accOrigin;
   acnt->remoteAddr.pres   = PRSNT_NODEF;

   loop            = 0;
   while ((loop < leg->storedHdrs.normRemoteAddr.len) && 
          (leg->storedHdrs.normRemoteAddr.val[loop] != ':')) 
     loop++;

   acnt->remoteAddr.len    = loop;
   SOALLOC(&(acnt->remoteAddr.val),acnt->remoteAddr.len);

   if (acnt->remoteAddr.val == NULLP)
     RETVOID;

   for (loop = 0; loop<acnt->remoteAddr.len; loop++)
      acnt->remoteAddr.val[loop] = leg->storedHdrs.normRemoteAddr.val[loop];

   acnt->localAddr.pres = PRSNT_NODEF;
   loop            = 0;
   while ((loop < leg->storedHdrs.normLocalAddr.len) && 
          (leg->storedHdrs.normLocalAddr.val[loop] != ':')) loop++;
   acnt->localAddr.len  = loop;
   SOALLOC(&(acnt->localAddr.val),acnt->localAddr.len);
   if (acnt->localAddr.val == NULLP)
     RETVOID;

   for (loop = 0; loop<acnt->localAddr.len; loop++)
      acnt->localAddr.val[loop] = leg->storedHdrs.normLocalAddr.val[loop];

   acnt->mediaType = leg->accntCb.mediaType;
   acnt->sdpMedia = LSO_ACNT_NONE;
 
   RETVOID;
} /* soMiAccntRecBuild */

/**********************************************************
*
*       Fun:   soAcntReq
*
*       Desc:  Perform SIP accounting request
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: Enable SIP entity
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soAcntReq
(
Pst        *pst,           /* post structure */
SoMngmt    *mngmt,         /* Status structure */
U16        *reason
)
#else
PUBLIC S16 soAcntReq(pst, mngmt, reason)
Pst        *pst;           /* post structure */
SoMngmt    *mngmt;         /* status structure */
U16        *reason;
#endif
{
   U32         id;            /* Element id */
   SoAcntInfo  *acnt;         /* status structure */
   SoEntCb     *entCb;        /* Entity control block */
   SoCLegCb    *sipCLeg;      /* call leg found */
   SoCallCb    *callCb;

   TRC2(soAcntReq);

   acnt = &mngmt->t.acnt.acntInfo;
   id = acnt->entId;
   if (id >= (U32)(soCb.maxEnt))
   {
      *reason = LCM_REASON_INVALID_ENTITY;
      RETVALUE(RFAILED);
   }
   entCb = soCb.entLst[id];
   
   if (entCb->entityType != LSO_ENT_UA)
   {
      *reason = LCM_REASON_INVALID_ENTITY;
      RETVALUE(RFAILED);
   }

#ifdef SO_UA
   /* so032.201: Pass event type to locate call control block */
   callCb = soCoreLocateCallCb(entCb, acnt->spconnId, SO_CONNID_NOTUSED,
                               NULLP, SOT_ET_UNKNOWN);

   if (callCb == NULLP)
   {
     *reason = LSO_REASON_INV_CALLHDL;
     RETVALUE(RFAILED);
   }

   sipCLeg = soDlgFindCLegFromSu(callCb, acnt->legId);
   
   if (sipCLeg == NULLP)
   {
     *reason = LSO_REASON_INV_CALLHDL;
     RETVALUE(RFAILED);
   }

   /* Build Response for acnt req */
   soMiAccntRecBuild(acnt, sipCLeg);

   acnt->type = LSO_ACNT_NOTAPPL;

   /* Call duration if Call not released yet */
   if (sipCLeg->accntCb.accType != LSO_ACNT_REL)
     SGetDateTime(&mngmt->t.acnt.dt);
#endif /* SO_UA */

   RETVALUE( ROK );
} /* end of soAcntReq */
#endif /* LSO_ACNT */




/**********************************************************
*
*       Fun:   soGenCfgReq
*
*       Desc:  Perform SIP layer configuration
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: Initializes global control block
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soGenCfgReq
(
SoCfg      *cfg,        /* Configuration structure */
U16        *reason      /* Return reason */
)
#else
PUBLIC S16 soGenCfgReq(cfg, reason)
SoCfg      *cfg;        /* Configuration structure */
U16        *reason;     /* Return reason */
#endif
{
   Size           sMemSize;   /* amount of static memory required */
   S16            ret;        /* return value */
   Cntr           i;          /* temporary */
   SoGenCfg       *genCfg;    /* Configuration structure */
   SoGenReCfg     *genReCfg;  /* Reconfiguration structure */

   TRC2(soGenCfgReq);

   genCfg    = &cfg->c.genCfg;
   genReCfg  = &cfg->r.genReCfg;
   /* Can only configure once */
   if (soCb.init.cfgDone != TRUE)
   {
      /* Range checking on variables */
      if ((genCfg->maxNmbSSaps == 0)    || (genCfg->maxNmbTSaps == 0) ||
          (genCfg->maxTransPerEnt == 0))
      {
         *reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(LCM_PRIM_NOK);
      }

      if ((genReCfg->GMToffset < -12) || (genReCfg->GMToffset > 13))
      {
         *reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(LCM_PRIM_NOK);
      }

      /* Clear statistics */
      cmMemset((U8 *)&soCb.sts, 0, sizeof(soCb.sts));

      /* copy the general configuration structure */
      (Void)cmMemcpy((U8 *)&soCb.cfg, (U8 *)genCfg, sizeof(SoGenCfg));

      /* copy the general reconfiguration structure */
      (Void)cmMemcpy((U8 *)&soCb.reCfg, (U8 *)genReCfg, sizeof(SoGenReCfg));

#ifdef DEBUGP
      /* Set initial debug mask */
      soCb.init.dbgMask = genCfg->dbgMask;
#endif /* DEBUGP */

      /*
       * compute the required static memory
       * max. SSAPS +
       * SSAP pointers
       * max. TSAPS +
       * TSAP pointers +
       * max. active calls +
       * Active call pointers +
       * max. network servers +
       * max. endsystems +
       * max. entities +
       * max. transactions on layer
       */

      sMemSize =
         (genCfg->maxNmbSSaps * SBUFSIZE(sizeof(SoSSapCb))) +
         (genCfg->maxNmbSSaps * SBUFSIZE(sizeof(SoSSapCb *))) +
         (genCfg->maxNmbTSaps * SBUFSIZE(sizeof(SoTSapCb))) +
         (genCfg->maxNmbTSaps * SBUFSIZE(sizeof(SoTSapCb *))) +
         (genCfg->maxNmbActCalls * SBUFSIZE(sizeof(SoCallCb)))  +
         (genCfg->maxNmbActCalls * SBUFSIZE(sizeof(SoCallCb *))) +
         ((genCfg->maxNmbNS + genCfg->maxNmbUA) *
         SBUFSIZE(sizeof(SoEntCb))) +
         ((genCfg->maxNmbNS + genCfg->maxNmbUA) *
         genCfg->maxTransPerEnt * SBUFSIZE(sizeof(SoTransCb))) +
         (genCfg->maxBlkSize * genCfg->maxTransPerEnt);


      if (genCfg->maxNmbUA > 0)
      {
         soClCacheMemSzCheck(&genCfg->locRegSz, genCfg->locRegSz);
         sMemSize = sMemSize + (genCfg->locRegSz * genCfg->maxNmbUA);
      }

      if (genCfg->maxNmbRemReg > 0)
      {
         soClCacheMemSzCheck(&genCfg->remRegSz, genCfg->remRegSz);
         sMemSize = sMemSize + (genCfg->remRegSz * genCfg->maxNmbRemReg);
      }
#ifdef SO_DNS 
      /*-- so032.201: DNS Cache is used, even if caching is disabled ---------*/
      if (genCfg->dnsCfg.useDnsCache == FALSE)
      {
         genCfg->dnsCfg.dnsACacheSz       = LSO_CACHE_MIN_MEM_SIZE;
         genCfg->dnsCfg.dnsSrvCacheSz     = LSO_CACHE_MIN_MEM_SIZE;
         genCfg->dnsCfg.dnsNaptrCacheSz   = LSO_CACHE_MIN_MEM_SIZE;
      }

      soClCacheMemSzCheck(&genCfg->dnsCfg.dnsACacheSz,
                             genCfg->dnsCfg.dnsACacheSz);
      soClCacheMemSzCheck(&genCfg->dnsCfg.dnsSrvCacheSz,
                             genCfg->dnsCfg.dnsSrvCacheSz);
      soClCacheMemSzCheck(&genCfg->dnsCfg.dnsNaptrCacheSz,
                             genCfg->dnsCfg.dnsNaptrCacheSz);
      sMemSize = sMemSize + genCfg->dnsCfg.dnsACacheSz
                          + genCfg->dnsCfg.dnsNaptrCacheSz 
                          + genCfg->dnsCfg.dnsSrvCacheSz;
      /*-- so032.201: DNS Cache is used, even if caching is disabled ---------*/
#endif /* SO_DNS */
#ifdef SO_NS
#ifdef SO_LCS 
      if ((genCfg->locSrvCfg.useExtLocServices == TRUE) &&
          (genCfg->locSrvCfg.locCachePres == TRUE))
      {
         soClCacheMemSzCheck(&genCfg->locSrvCfg.locCacheSz,
                             genCfg->locSrvCfg.locCacheSz);
         sMemSize = sMemSize + genCfg->locSrvCfg.locCacheSz;
      }
#endif /* SO_LCS */
#endif /* SO_NS */

#ifdef SO_UA
      sMemSize = sMemSize + 
                 (genCfg->maxNmbUA * genCfg->maxNumRegPerEnt *
                  SBUFSIZE(sizeof(SoUaRegCb))) +
                 (genCfg->maxNmbUA * genCfg->maxNumCnctPerEnt *
                  SBUFSIZE(sizeof(SoRegContactCb)));
#endif /* SO_UA */

      /* reserve static memory */
      ret = SGetSMem(soCb.init.region, sMemSize, &soCb.init.pool);
      if (ret != ROK)
      {
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(LCM_PRIM_NOK);
      }

      soCb.resCongStrt = FALSE;
      soCb.nmbRemReg = 0;
      soCb.nmbTSap = 0;
      soCb.nmbSSap = 0;
      soCb.maxEnt  = soCb.cfg.maxNmbUA + soCb.cfg.maxNmbNS;
      
      /* Initialize MTU size */
      soCb.cfg.mtu = genCfg->mtu;

      /* allocate space for the SSAP list, and zero it */
      SOALLOC((Data **) &soCb.soSSapCbLst,
              genCfg->maxNmbSSaps * sizeof(SoSSapCb *));
      if (soCb.soSSapCbLst == NULLP)
      {
         SPutSMem(soCb.init.region, soCb.init.pool);
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(LCM_PRIM_NOK);
      }

      /* we need to initialize each element of the static array of pointers
         to SSAP control blocks */
      for (i = 0;  i < genCfg->maxNmbSSaps;  i++)
      {
         soCb.soSSapCbLst[i] = (SoSSapCb *) NULLP;
      }

      /* allocate space for the TSAP list, and zero it */
      SOALLOC((Data **)&soCb.soTSapCbLst,
              genCfg->maxNmbTSaps * sizeof(SoTSapCb *));
      if (soCb.soTSapCbLst == NULLP)
      {
         SOFREE(soCb.soSSapCbLst,
                genCfg->maxNmbSSaps * sizeof(SoSSapCb *));

         SPutSMem(soCb.init.region, soCb.init.pool);
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(LCM_PRIM_NOK);
      }

      /* we need to initialize each element of the static array of pointers
         to TSAP control blocks */
      for (i = 0;  i < genCfg->maxNmbTSaps;  i++)
      {
         soCb.soTSapCbLst[i] = NULLP;
      }

      ret = initPtrArray((Ptr **)&soCb.entLst,
                         (U16)(genCfg->maxNmbUA + genCfg->maxNmbNS));
      if (ret != ROK)
      {
         SOFREE(soCb.soSSapCbLst,
                genCfg->maxNmbSSaps * sizeof(SoSSapCb *));

         SOFREE(soCb.soTSapCbLst,
                genCfg->maxNmbTSaps * sizeof(SoTSapCb *));

         SPutSMem(soCb.init.region, soCb.init.pool);
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(LCM_PRIM_NOK);
      }

      soCb.maxTptSrv = (genCfg->maxNmbUA + genCfg->maxNmbNS) * LSO_TPTSRV_MAX;

      /* Allocate space for transport server list */
      ret = initPtrArray((Ptr **)&soCb.allSrvCbLst, soCb.maxTptSrv);
      if (ret != ROK)
      {
         SOFREE(soCb.soSSapCbLst,
                genCfg->maxNmbSSaps * sizeof(SoSSapCb *));

         SOFREE(soCb.soTSapCbLst,
                genCfg->maxNmbTSaps * sizeof(SoTSapCb *));

         SOFREE(soCb.entLst,
                (genCfg->maxNmbNS + genCfg->maxNmbUA) *
                 sizeof(SoEntCb *));

         SPutSMem(soCb.init.region, soCb.init.pool);
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(LCM_PRIM_NOK);
      }

      /* copy and update Pst structure for the layer management interface */
      (Void)cmMemcpy((U8 *)&soCb.init.lmPst, (U8 *)&genCfg->lmPst,
                     sizeof(Pst));
      soCb.init.lmPst.srcProcId = soCb.init.procId;
      soCb.init.lmPst.srcEnt    = soCb.init.ent;
      soCb.init.lmPst.srcInst   = soCb.init.inst;
      soCb.init.lmPst.event     = EVTNONE;


      ret = soCmInitTimerQueues();
      if (ret != ROK)
      {
         /* Free all memory previously allocated */
         SOFREE(soCb.soSSapCbLst,
                genCfg->maxNmbSSaps * sizeof(SoSSapCb *));

         SOFREE(soCb.soTSapCbLst,
                genCfg->maxNmbTSaps * sizeof(SoTSapCb *));

         SOFREE(soCb.entLst,
                (genCfg->maxNmbNS + genCfg->maxNmbUA) *
                 sizeof(SoEntCb *));

         SPutSMem(soCb.init.region, soCb.init.pool);
         *reason = LCM_REASON_REGTMR_FAIL;
         RETVALUE(LCM_PRIM_NOK);
      }

      /* initialise global caches */
#ifdef SO_DNS 
      soCb.cacheInfoCb.dnsNaptrCache.cacheOK    = FALSE;
      soCb.cacheInfoCb.dnsSrvCache.cacheOK    = FALSE;
      soCb.cacheInfoCb.dnsACache.cacheOK      = FALSE;
#endif /* SO_DNS */
      soCb.cacheInfoCb.mcastCache.cacheOK     = FALSE;
#ifdef SO_NS
#ifdef SO_LCS 
      soCb.cacheInfoCb.extLocSrvCache.cacheOK = FALSE;
      soCb.cacheInfoCb.locCacheAvail = FALSE;
#endif /* SO_LCS */
#endif /* SO_NS */

#ifdef SO_DNS 
      /*-- so032.201: DNS Cache is used, even if caching is disabled ---------*/
         soClCacheInit(&soCb.cacheInfoCb.dnsNaptrCache,
                       soCb.init.pool,
                       soCb.init.region,
                       SO_CACHE_DNS_NAPTR,
                       SO_CACHE_ENTRIES_PER_NODE,
                       cfg->c.genCfg.dnsCfg.dnsNaptrCacheSz,
                       /* DNS cache does not need thresholds 
                        * for memory alarms */
                       NULLD,
                       NULLD,
                       soCb.reCfg.dnsReCfg.maxDnsCacheExp,
                       soCb.reCfg.dnsReCfg.maxDnsCacheExp,
                       NULLP);

         soClCacheInit(&soCb.cacheInfoCb.dnsSrvCache,
                       soCb.init.pool,
                       soCb.init.region,
                       SO_CACHE_DNS_SRV,
                       SO_CACHE_ENTRIES_PER_NODE,
                       cfg->c.genCfg.dnsCfg.dnsSrvCacheSz,
                       /* DNS cache does not need thresholds for memory alarms */
                       NULLD,
                       NULLD,
                       soCb.reCfg.dnsReCfg.maxDnsCacheExp,
                       soCb.reCfg.dnsReCfg.maxDnsCacheExp,
                       NULLP);

         soClCacheInit(&soCb.cacheInfoCb.dnsACache,
                       soCb.init.pool,
                       soCb.init.region,
                       SO_CACHE_DNS_A,
                       SO_CACHE_ENTRIES_PER_NODE,
                       cfg->c.genCfg.dnsCfg.dnsACacheSz,
                       /* DNS cache does not need thresholds for memory alarms */
                       NULLD,
                       NULLD,
                       soCb.reCfg.dnsReCfg.maxDnsCacheExp,
                       soCb.reCfg.dnsReCfg.maxDnsCacheExp,
                       NULLP);
      /*-- so032.201: DNS Cache is used, even if caching is disabled ---------*/
#endif /* SO_DNS */

#ifdef SO_NS
#ifdef SO_LCS 
      if ((genCfg->locSrvCfg.useExtLocServices == TRUE) &&
          (genCfg->locSrvCfg.locCachePres == TRUE))
      {
         soClCacheInit(&soCb.cacheInfoCb.extLocSrvCache,
                       soCb.init.pool,
                       soCb.init.region,
                       SO_CACHE_MCAST_REG,
                       SO_CACHE_ENTRIES_PER_NODE,
                       cfg->c.genCfg.locSrvCfg.locCacheSz,
                       /* locSrv cache does not need thresholds
                          for memory alarms */
                       NULLD,
                       NULLD,
                       soCb.reCfg.locSrvReCfg.dfltLocCacheExp,
                       soCb.reCfg.locSrvReCfg.maxLocCacheExp,
                       NULLP);
         soCb.cacheInfoCb.locCacheAvail = TRUE;
      }
      /* inititalise misc. parmameters in soCb */
      soCb.cacheInfoCb.nextSearchNum = 0;

     /* location services */
     ret = cmHashListInit(&soCb.cacheInfoCb.searchList,
                          soCb.cfg.locSrvCfg.locSrchHlBins, 
                          (U16)SO_OFFSET_OF(SoLcsSearchRec, hlNode),
                          FALSE,
                          CM_HASH_KEYTYPE_U32MOD,
                          soCb.init.region,
                          soCb.init.pool);
#else 
     ret = ROK;
#endif /* SO_LCS */

      ret = ROK;
      if (ret != ROK)
      {
         /* deinit global caches */
         soClCacheDeinit(&soCb.cacheInfoCb.mcastCache);
#ifdef SO_DNS 
         soClCacheDeinit(&soCb.cacheInfoCb.dnsNaptrCache);
         soClCacheDeinit(&soCb.cacheInfoCb.dnsSrvCache);
         soClCacheDeinit(&soCb.cacheInfoCb.dnsACache);
#endif /* SO_DNS */
#ifdef SO_LCS 
         soClCacheDeinit(&soCb.cacheInfoCb.extLocSrvCache);
#endif /* SO_LCS */

        /* Free all memory previously allocated */
        SOFREE(soCb.soSSapCbLst,
               genCfg->maxNmbSSaps * sizeof(SoSSapCb *));

        SOFREE(soCb.soTSapCbLst,
               genCfg->maxNmbTSaps * sizeof(SoTSapCb *));

        SOFREE(soCb.entLst,
               (genCfg->maxNmbNS + genCfg->maxNmbUA) *
               sizeof(SoEntCb *));

        SPutSMem(soCb.init.region, soCb.init.pool);
        *reason = LCM_REASON_HASHING_FAILED;
        RETVALUE(LCM_PRIM_NOK);
     }
#endif /* SO_NS */

#ifdef SO_DNS 
      /* DNS variables */
      if (genCfg->dnsCfg.useDns == TRUE)
      {
         ret = soDnsCfg(&genReCfg->dnsReCfg,reason);
         if ( ret != ROK)
         {
            /* deinit global caches */
            soClCacheDeinit(&soCb.cacheInfoCb.mcastCache);
            soClCacheDeinit(&soCb.cacheInfoCb.dnsNaptrCache);
            soClCacheDeinit(&soCb.cacheInfoCb.dnsSrvCache);
            soClCacheDeinit(&soCb.cacheInfoCb.dnsACache);
#ifdef SO_NS
            soClCacheDeinit(&soCb.cacheInfoCb.extLocSrvCache);
#endif /* SO_NS */
   
            /* Free all memory previously allocated */
            SOFREE(soCb.soSSapCbLst,
                   genCfg->maxNmbSSaps * sizeof(SoSSapCb *));

            SOFREE(soCb.soTSapCbLst,
                   genCfg->maxNmbTSaps * sizeof(SoTSapCb *));
  
            SOFREE(soCb.entLst,
                   (genCfg->maxNmbNS + genCfg->maxNmbUA) *
                   sizeof(SoEntCb *));
            SPutSMem(soCb.init.region, soCb.init.pool);
            RETVALUE(LCM_PRIM_NOK);
         }
      }
#endif /* SO_DNS */

#ifdef SO_ABNF_MT_LIB
      /* Initialize Encoder/Decoder related variables */
      soCb.lastEDInst = soCb.init.inst + soCb.cfg.nmbEDThreads +1;
      soCb.nxtEDInst =  soCb.init.inst + 1;
      /* Initialize post structure for ED */
      soCb.edPst.dstProcId = soCb.init.procId;
      soCb.edPst.srcProcId = soCb.init.procId;
      soCb.edPst.dstEnt = soCb.init.ent;
      soCb.edPst.srcEnt = soCb.init.ent;
      soCb.edPst.dstInst = soCb.init.inst + 1;
      soCb.edPst.srcInst = soCb.init.inst;
      soCb.edPst.region =  soCb.init.region;
      soCb.edPst.pool =  soCb.init.pool;
   
      cmLListInit (&soCb.soEDList);
      soCb.shutdownInProgress = FALSE;
   
      /* call function to create multiple ED instances */
      ret = soCreateEDInst(soCb.cfg.nmbEDThreads, soCb.nxtEDInst, soCb.init.ent);
      if(ret != ROK)
      {
         /* deinit global caches */
         soClCacheDeinit(&soCb.cacheInfoCb.mcastCache);
#ifdef SO_DNS 
         soClCacheDeinit(&soCb.cacheInfoCb.dnsNaptrCache);
         soClCacheDeinit(&soCb.cacheInfoCb.dnsSrvCache);
         soClCacheDeinit(&soCb.cacheInfoCb.dnsACache);
#endif /* SO_DNS */
#ifdef SO_NS
         soClCacheDeinit(&soCb.cacheInfoCb.extLocSrvCache);
#endif /* SO_NS */
   
#ifdef SO_DNS 
         /* delete the DNS server */
         if (soCb.dnsCb != NULLP)
         {
            soDnsDeInit();
            soPrcDelTcmConn(&soCb.dnsConn);
         }
#endif /* SO_DNS */

         /* Free all memory previously allocated */
         SOFREE(soCb.soSSapCbLst,
                genCfg->maxNmbSSaps * sizeof(SoSSapCb *));

         SOFREE(soCb.soTSapCbLst,
                genCfg->maxNmbTSaps * sizeof(SoTSapCb *));

         SOFREE(soCb.entLst,
                (genCfg->maxNmbNS + genCfg->maxNmbUA) *
                sizeof(SoEntCb *));

         SPutSMem(soCb.init.region, soCb.init.pool);
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(LCM_PRIM_NOK);
      }
#endif /* SO_ABNF_MT_LIB */
   }
   else      /* do only reconfigure */
   {
      /* Range checking on variables */
      if ((genReCfg->GMToffset < -12) || (genReCfg->GMToffset > 13))
      {
         *reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(LCM_PRIM_NOK);
      }
      /* copy the general reconfiguration structure */
      (Void)cmMemcpy((U8 *)&soCb.reCfg, (U8 *)genReCfg,
                     sizeof(SoGenReCfg));

      /* DNS reconfiguration structure             */
#ifdef SO_DNS 
      /* so033.201 :This could be the retransmission of same configuration 
       * The Dns Configuration can be changed by giving a different 
       * transport Server Id.For the same transport Server Id it will be taken
       * as the Re-configuration */
      if ((soCb.cfg.dnsCfg.useDns == TRUE) && 
            (genReCfg->dnsReCfg.tptSrvId != soCb.dnsSrvCb->suConnId))
      {
         ret = soDnsCfg (&genReCfg->dnsReCfg, reason);
         if ( ret != ROK)
            RETVALUE(LCM_PRIM_NOK);
        /*--- Also open the transport server ---*/
         soTptOpenServer (soCb.dnsSrvCb);
      }
#endif
   }

   /* Accounting defaults to NONE */
   soCb.init.acnt = FALSE;

   soCb.init.cfgDone = TRUE;

   SODBGP_SO(DBGMASK_MI, (soCb.init.prntBuf,
      "\n------ SIP Stack STARTUP (GenCfg)........\n"));


   *reason = LCM_REASON_NOT_APPL;
   RETVALUE(LCM_PRIM_OK);

} /* end of soGenCfgReq */



/**********************************************************
*
*       Fun:   soGenStsReq
*
*       Desc:  Perform SIP statistics request
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: General SIP layer statistics
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soGenStsReq
(
SoGenSts   *sts,        /* Statistics structure */
Action     action,
U16        *reason
)
#else
PUBLIC S16 soGenStsReq(sts, action, reason)
SoGenSts   *sts;        /* statistics structure */
Action     action;
U16        *reason;
#endif
{
   TRC2(soGenStsReq);

     /* Copy general statistics into return structure */
     cmMemcpy((U8 *)sts, (U8 *)&soCb.sts,
              sizeof(SoGenSts));

     /* Copy DNS statistics into return structure */
#ifdef SO_DNS 
     sts->dnsSts.dnsACache.peakNmbEntries   = soCb.cacheInfoCb.dnsACache.peakEntries;
     sts->dnsSts.dnsACache.peakMemUsage     = soCb.cacheInfoCb.dnsACache.peakMem;
     sts->dnsSts.dnsSrvCache.peakNmbEntries = soCb.cacheInfoCb.dnsSrvCache.peakEntries;
     sts->dnsSts.dnsSrvCache.peakMemUsage   = soCb.cacheInfoCb.dnsSrvCache.peakMem;
     sts->dnsSts.dnsNaptrCache.peakNmbEntries = soCb.cacheInfoCb.dnsNaptrCache.peakEntries;
     sts->dnsSts.dnsNaptrCache.peakMemUsage   = soCb.cacheInfoCb.dnsNaptrCache.peakMem;
#endif /* SO_DNS */

#ifdef SO_LCS 
#ifdef SO_NS
     /* Copy location services cache statistics into return structure */
     sts->locSrvCache.peakNmbEntries = soCb.cacheInfoCb.extLocSrvCache.peakEntries;
     sts->locSrvCache.peakMemUsage   = soCb.cacheInfoCb.extLocSrvCache.peakMem;
#else
     sts->locSrvCache.peakNmbEntries = NULLD;
     sts->locSrvCache.peakMemUsage   = NULLD;
#endif /* SO_NS */
#endif /* SO_LCS */

     /* Copy multicast cache statistics into return structure */
     sts->mCastCache.peakNmbEntries  = soCb.cacheInfoCb.mcastCache.peakEntries;
     sts->mCastCache.peakMemUsage    = soCb.cacheInfoCb.mcastCache.peakMem;

     /* Clear if required */
     if (action == ZEROSTS)
     {
        cmMemset((U8 *)&soCb.sts, 0, sizeof(SoGenSts));

#ifdef SO_DNS 
        soCb.cacheInfoCb.dnsACache.peakEntries      = 0;
        soCb.cacheInfoCb.dnsACache.peakMem          = 0;
        soCb.cacheInfoCb.dnsSrvCache.peakEntries    = 0;
        soCb.cacheInfoCb.dnsSrvCache.peakMem        = 0;
        soCb.cacheInfoCb.dnsNaptrCache.peakEntries    = 0;
        soCb.cacheInfoCb.dnsNaptrCache.peakMem        = 0;
#endif /* SO_DNS */

#ifdef SO_NS
#ifdef SO_LCS 
        soCb.cacheInfoCb.extLocSrvCache.peakEntries = 0;
        soCb.cacheInfoCb.extLocSrvCache.peakMem     = 0;
#endif /* SO_LCS */
#endif /* SO_NS */
        soCb.cacheInfoCb.mcastCache.peakEntries     = 0;
        soCb.cacheInfoCb.mcastCache.peakMem         = 0;
     }


   RETVALUE(LCM_PRIM_OK);
} /* end of soGenStsReq */

/**********************************************************
*
*       Fun:   soSipEntStsReq
*
*       Desc:  Perform SIP statistics request
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: SIP entity statistics
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soSipEntStsReq
(
SoEntSts      *sts,        /* Configuration structure */
Action        action,
U16           *reason      /* Return reason */
)
#else
PUBLIC S16 soSipEntStsReq(sts, action, reason)
SoEntSts      *sts;        /* Configuration structure */
Action        action;
U16           *reason;     /* Return reason */
#endif
{
   S16        ret;


   TRC2(soSipEntStsReq);

   /* Copy summary statistics into return structure */
   cmMemcpy((U8 *)&sts->summSts,
            (U8 *)&soCb.entLst[sts->entId]->summSts,
            sizeof(SoSummSts));

   /* Clear if required */
   if (action == ZEROSTS)
   {
      cmMemset((U8 *)&soCb.entLst[sts->entId]->summSts, 0,
               sizeof(SoSummSts));
   }

   /* Copy method statistics into return structure */
   cmMemcpy((U8 *)&sts->methSts,
            (U8 *)&soCb.entLst[sts->entId]->methSts,
            sizeof(SoMethSts));

   /* Clear if required */
   if (action == ZEROSTS)
   {
      cmMemset((U8 *)&soCb.entLst[sts->entId]->methSts, 0,
               sizeof(SoMethSts));
   }

   /* Copy response statistics into return structure */
   cmMemcpy((U8 *)&sts->respSts,
            (U8 *)&soCb.entLst[sts->entId]->respSts,
            sizeof(SoRespSts));

   /* Clear if required */
   if (action == ZEROSTS)
   {
      cmMemset((U8 *)&soCb.entLst[sts->entId]->respSts, 0,
               sizeof(SoRespSts));
   }

   /*--- so019.201: Also copy error statistics ---*/
   cmMemcpy((U8 *)&sts->errSts,
            (U8 *)&soCb.entLst[sts->entId]->errSts,
            sizeof(SoErrSts));

   /* Clear if required */
   if (action == ZEROSTS)
   {
      cmMemset((U8 *)&soCb.entLst[sts->entId]->errSts, 0, sizeof(SoErrSts));
   }

   /* Copy other statistics into return structure */
   cmMemcpy((U8 *)&sts->otherSts,
            (U8 *)&soCb.entLst[sts->entId]->otherSts,
            sizeof(SoOtherSts));

   /* Clear if required */
   if (action == ZEROSTS)
   {
      cmMemset((U8 *)&soCb.entLst[sts->entId]->otherSts, 0,
               sizeof(SoOtherSts));
   }

   switch (sts->stsType)
   {
#ifdef SO_UA
      case LSO_STS_UA:
         /* Copy ua statistics into return structure */
         cmMemcpy((U8 *)&(sts->t.uaSts),
                  (U8 *)&(soCb.entLst[sts->entId]->s.ua.sts),
                  sizeof(SoUASts));

         sts->t.uaSts.peakMemUsage =
            soCb.entLst[sts->entId]->s.ua.localUsrReg.peakMem;

         sts->t.uaSts.peakNmbEntries =
            soCb.entLst[sts->entId]->s.ua.localUsrReg.peakEntries;

         /* Clear if required */
         if (action == ZEROSTS)
         {
            cmMemset((U8 *)&(soCb.entLst[sts->entId]->s.ua.sts), 0,
                     sizeof(SoUASts));
            soCb.entLst[sts->entId]->s.ua.localUsrReg.peakMem     = 0;
            soCb.entLst[sts->entId]->s.ua.localUsrReg.peakEntries = 0;
         }
         break;
#endif /* SO_UA */
#ifdef SO_NS
      case LSO_STS_NS:
         /* Copy ns statistics into return structure */
         cmMemcpy((U8 *)&(sts->t.nsSts),
                  (U8 *)&(soCb.entLst[sts->entId]->s.ns.sts),
                  sizeof(SoNSSts));

         /* Clear if required */
         if (action == ZEROSTS)
         {
            cmMemset((U8 *)&(soCb.entLst[sts->entId]->s.ns.sts), NULLD,
                     sizeof(SoNSSts));

         }
         break;
#endif /* SO_NS */
      default:
         ret = LCM_PRIM_NOK;
         *reason = LCM_REASON_INVALID_ELMNT;

#if (ERRCLASS & ERRCLS_INT_PAR)
         SOLOGERROR(ERRCLS_INT_PAR, ESO146, (ErrVal)sts->stsType,
                     "soSipEntStsReq: Invalid element.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         RETVALUE(LCM_PRIM_NOK);
         break;
   }
   RETVALUE(LCM_PRIM_OK);
} /* end of soSipEntStsReq */



/**********************************************************
*
*       Fun:   soGenStaInd
*
*       Desc:  This function is used to send unsolicited Status
*              Indications to the Layer Manager
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC Void soGenStaInd
(
Elmnt elmnt,              /* ALARM element */
U16   category,           /* ALARM category */
U16   event,              /* ALARM event */
U16   cause,              /* ALARM cause */
U8    alarmType,          /* Type of parameter */
Ptr   par                 /* Pointer to parameter */
)
#else
PUBLIC Void soGenStaInd(elmnt, category, event, cause, alarmType, par)
Elmnt elmnt;              /* ALARM element */
U16   category;           /* ALARM category */
U16   event;              /* ALARM event */
U16   cause;              /* ALARM cause */
U8    alarmType;          /* Type of parameter */
Ptr   par;                /* Pointer to parameter */
#endif
{
   SoMngmt      sm;      /* management structure */

   TRC2(soGenStaInd);

   /* have to have general configuration done first */
   if (soCb.init.cfgDone == FALSE)
   {
      RETVOID;
   }

   /* if we're not generating unsolicited status indications, do nothing */
   if (soCb.init.usta == FALSE)
   {
      RETVOID;
   }

   /* zero out the management structure */
   (Void) cmMemset((U8 *) &sm, 0, sizeof(SoMngmt));

   /* fill in the element */
   sm.hdr.elmId.elmnt = elmnt;

   /* fill in the category, event and cause */
   sm.t.usta.alarm.category = category;
   sm.t.usta.alarm.event    = event;
   sm.t.usta.alarm.cause    = cause;

   /* update the date and time */
   (Void)SGetDateTime(&sm.t.usta.alarm.dt);

   /* fill in the alarm specific information */
   sm.t.usta.alarmInfo.alarmType = alarmType;
   switch (alarmType)
   {
      case LSO_PAR_NONE:
         break;

      case LSO_PAR_MEM:
         cmMemcpy((U8 *)&sm.t.usta.alarmInfo.v.mem,
                  (U8 *)par,
                  sizeof(Mem));
         break;
      case LSO_PAR_SAP:
         cmMemcpy((U8 *)&sm.t.usta.alarmInfo.v.sapId,
                  (U8 *)par,
                  sizeof(SpId));
         break;
      case LSO_PAR_ENT:
         cmMemcpy((U8 *)&sm.t.usta.alarmInfo.v.entId,
                  (U8 *)par,
                  sizeof(U8));
         break;
      case LSO_PAR_CONNID:
         cmMemcpy((U8 *)&sm.t.usta.alarmInfo.v.connId,
                  (U8 *)par,
                  sizeof(UConnId));
         break;
      case LSO_PAR_TPTADDR:
         cmMemcpy((U8 *)&sm.t.usta.alarmInfo.v.tptAddr,
                  (U8 *)par,
                  sizeof(CmTptAddr));
         break;
      case LSO_PAR_VAL:
      case LSO_PAR_STATUS:
      case LSO_PAR_REASON:
      case LSO_PAR_CHOICE:
         cmMemcpy((U8 *)&sm.t.usta.alarmInfo.v.val,
                  (U8 *)par,
                  sizeof(U32));
         break;
      case LSO_PAR_TPTSRV:
         cmMemcpy((U8 *)&sm.t.usta.alarmInfo.v.tptSrvId,
                  (U8 *)par,
                  sizeof(U32));
         break;
      case LSO_PAR_REG:
         cmMemcpy((U8 *)&sm.t.usta.alarmInfo.v.reg,
                  (U8 *)par,
                  sizeof(SoRegInf));
         break;
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         SOLOGERROR(ERRCLS_INT_PAR, ESO147,
                    (ErrVal)alarmType,
                     "Invalid element.");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         RETVOID;
         break;
   }


   (Void)SoMiLsoStaInd(&(soCb.init.lmPst), &sm);

   RETVOID;
} /* end of soGenStaInd */


/**********************************************************
*
*       Fun:   soGenTrcInd
*
*       Desc:  This function is used to send Trace Indications to
*              the Layer Manager.
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC Void soGenTrcInd
(
S16      elmnt,           /* type of element to trace */
SpId     sapId,           /* SAP ID */
U8       soEntId,         /* entity ID */
U16      evnt,            /* trace event */
Buffer   *mBuf            /* message being traced */
)
#else
PUBLIC Void soGenTrcInd(elmnt, sapId, soEntId, evnt, mBuf)
S16      elmnt;           /* type of element to trace */
SpId     sapId;           /* SAP ID */
U8       soEntId;         /* entity ID */
U16      evnt;            /* trace event */
Buffer   *mBuf;           /* message being traced */
#endif
{
   SoMngmt      sm;             /* management structure */
   Buffer       *trcBuf;        /* buffer to trace      */
   SoTSapCb     *tsapCb;        /* TSAP being traced    */
   MsgLen       bufLen;         /* Length of buffer to be traced */
   S16          i;              /* temporary */
   Data         d;              /* temporary */
   S16          ret;            /* Return value */

   TRC2(soGenTrcInd);

/*chendh*/
#ifdef SO_ACC
   /* Only process further if tracing is enabled for the specified
    * TSAP or entity
    */
   if (elmnt == STTSAP)
   {
      tsapCb = soCb.soTSapCbLst[sapId];

      if (((tsapCb->trcMask & evnt) == 0) ||
          (tsapCb->trcLen == 0))
      {
         /* This trace event is not enabled or length exceeded */
         RETVOID;
      }

      SFndLenMsg(mBuf, &bufLen);

      if (tsapCb->trcLen < bufLen)
      {
         bufLen = tsapCb->trcLen;
      }
   }

   /* have to have general configuration done first */
   if (soCb.init.cfgDone == FALSE)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO148, (ErrVal)0,
           "Trace Indication requested; general configuration not done.");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVOID;
   }

   /* zero out the management structure */
   (Void)cmMemset((U8 *)&sm, 0, sizeof(SoMngmt));

   sm.hdr.elmId.elmnt = elmnt;

   /* fill in the SAP ID, the entity ID and the event */
   if (elmnt == STTSAP)
     sm.t.trc.t.tSapId  = sapId;
   else
     sm.t.trc.t.entId   = soEntId;
   sm.t.trc.evnt      = evnt;

   /* Allocate a new message and copy the number of bytes from the source
    *  message that we are required to trace.
    */
   if (SGetMsg(soCb.init.lmPst.region, soCb.init.lmPst.pool, &trcBuf) != ROK)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      SOLOGERROR(ERRCLS_ADD_RES, ESO149, (ErrVal)0, "SGetMsg() failed.");
#endif /* (ERRCLASS & ERRCLS_ADD_RES) */
      RETVOID;
   }

   for (i = 0;  i < bufLen;  i++)
   {
      (Void)SExamMsg(&d, mBuf, (MsgLen)i);
      ret = SAddPstMsg(d, trcBuf);
      if (ret != ROK)
      {
         (Void)SPutMsg(trcBuf);/*so038.201:Modified mBuf to trcBuf*/
#if (ERRCLASS & ERRCLS_ADD_RES)
         SOLOGERROR(ERRCLS_ADD_RES, ESO150, (ErrVal)0, "SAddPstMsg() failed.");
#endif /* (ERRCLASS & ERRCLS_ADD_RES) */
         RETVOID;
      }
   }

   /* update the date and time */
   (Void)SGetDateTime(&sm.t.trc.dt);

   (Void)SoMiLsoTrcInd(&(soCb.init.lmPst), &sm, trcBuf);

#endif/* SO_ACC*/
   RETVOID;
} /* end of soGenTrcInd */



/**********************************************************
*
*       Fun:   soSendLmCntrlCfm
*
*       Desc:  This function sends control confirm primitives to the
*              Layer Manager
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC Void soSendLmCntrlCfm
(
Pst      *pst,           /* Post structure */
U16      status,         /* confirm status */
U16      reason,         /* failure reason */
Header   *hdr            /* Header to use in confirm */
)
#else
PUBLIC Void soSendLmCntrlCfm(pst, status, reason, hdr)
Pst      *pst;           /* Post structure */
U16      status;         /* confirm status */
U16      reason;         /* failure reason */
Header   *hdr;           /* Header to use in confirm */
#endif
{
   SoMngmt           mngmt;    /* Management structure for confirm */

   TRC2(soSendLmCntrlCfm);

   /* Copy header fields */
   cmMemset((U8 *)&mngmt, 0, sizeof(SoMngmt));
   cmMemcpy((U8 *)&mngmt.hdr, (U8 *)hdr, sizeof(Header));

   soSendLmCfm(pst, TCNTRL, status, reason, &mngmt);

   RETVOID;

} /* soSendLmCntrlCfm */



/**********************************************************
*
*       Fun:   soSendLmCfm
*
*       Desc:  This function sends various confirm primitives to the
*              Layer Manager
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC Void soSendLmCfm
(
Pst      *pst,           /* Post structure */
U8       cfmType,        /* confirm type */
U16      status,         /* confirm status */
U16      reason,         /* failure reason */
SoMngmt  *mngmt          /* Management struc to use in confirm */
)
#else
PUBLIC Void soSendLmCfm(pst, cfmType, status, reason, mngmt)
Pst      *pst;           /* Post structure */
U8       cfmType;        /* confirm type */
U16      status;         /* confirm status */
U16      reason;         /* failure reason */
SoMngmt  *mngmt;         /* Management struc to use in confirm */
#endif
{
   TRC2(soSendLmCfm);

   /* set the result */
   mngmt->cfm.status = status;
   mngmt->cfm.reason = reason;

   /* fill up the Pst structure for comfirm */
   pst->event  = EVTLSOCFGCFM;

   switch(cfmType)
   {
      case TCFG:
         /* send configuration confirm */
         pst->event  = EVTLSOCFGCFM;
         (Void)SoMiLsoCfgCfm(pst, mngmt);
         break;

      case TSTS:
         /* send Statistics confirm */
         pst->event  = EVTLSOSTSCFM;
         (Void)SoMiLsoStsCfm(pst, mngmt);
         break;

      case TCNTRL:
         /* send control confirm */
         pst->event  = EVTLSOCNTRLCFM;
         (Void)SoMiLsoCntrlCfm(pst, mngmt);
         break;

      case TSSTA:
         /* send solicited status confirm */
         pst->event  = EVTLSOSTACFM;
         (Void)SoMiLsoStaCfm(pst, mngmt);
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO151, (ErrVal)cfmType,
                    "soSendLmCfm() unknown primitive type.");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         break;
   }

   RETVOID;
} /* end of soSendLmCfm */





/**********************************************************
*
*       Fun:   soShutdownReq
*
*       Desc:  This function shuts down SIP. All SIP
*              entities, SSAPs and TSAPs are destroyed and
*              general configuration is erased.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_OK_NDONE        - shutdown Started
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PRIVATE S16 soShutdownReq
(
U16 *reason             /* result reason */
)
#else
PRIVATE S16 soShutdownReq(reason)
U16 *reason;            /* result reason */
#endif
{
   U16 ret, i;

   TRC2(soShutdownReq);

   *reason = LCM_REASON_NOT_APPL;
   ret = LCM_PRIM_OK;

   if (soCb.init.cfgDone == FALSE)
   {
      RETVALUE(LCM_PRIM_OK);
   }

   /* Unbind but keep all SSAPs enabled */
   for (i = 0;  i < soCb.cfg.maxNmbSSaps;  i++)
   {
      if (soCb.soSSapCbLst[i] == NULLP)
      {
         continue;
      }
      /* Destroy all outstanding call control blocks on SSAP */
      /* SSaps Bind Enabled */
      soSSapUbndDis(soCb.soSSapCbLst[i], reason);
      soCb.soSSapCbLst[i]->state = LSO_SSAP_BNDENA;
   }

#ifdef SO_ABNF_MT_LIB
   if (cmLListLen (&soCb.soEDList) != 0)
      RETVALUE(LCM_PRIM_OK_NDONE);
   else
#endif
      RETVALUE(soShutdownComplete(reason));

} /* end of soShutdownReq */


#ifdef SO_ABNF_MT_LIB
/**********************************************************
*
*       Fun:   soShutdown
*
*       Desc:  This function shuts down SIP. All SIP
*              entities, SSAPs and TSAPs are destroyed and
*              general configuration is erased.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soShutdown
(
Void
)
#else
PUBLIC S16 soShutdown()
#endif
{
   U16           ret;
   U16           reason;         /* result reason */

   TRC2(soShutdown);

   /* initialize result and reason */
   reason = LCM_REASON_NOT_APPL;
   ret    = LCM_PRIM_OK;

   ret = soShutdownComplete(&reason);
   soSendLmCntrlCfm(&soCb.shutdownCfmPst, ret, reason, &soCb.shutdownCntrlHdr);
   SODBGP_SO(DBGMASK_MI, (soCb.init.prntBuf,
      "\n------ SIP Stack Shutdown (CtrlReq)........\n"));

   soCb.shutdownInProgress = FALSE; 
   RETVALUE(ROK);

} /* end of soShutdown */
#endif /* SO_ABNF_MT_LIB */


/**********************************************************
*
*       Fun:   soShutdownComplete
*
*       Desc:  This function shuts down SIP. All SIP
*              entities, SSAPs and TSAPs are destroyed and
*              general configuration is erased.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PRIVATE S16 soShutdownComplete
(
U16 *reason             /* result reason */
)
#else
PRIVATE S16 soShutdownComplete(reason)
U16 *reason;            /* result reason */
#endif
{
   U16 i, ret;
#ifdef SO_ABNF_MT_LIB
   Inst            tmpInst;            /* temp instance */
#endif /* SO_ABNF_MT_LIB */

   TRC2(soShutdownComplete);

   /* delete all SSAPs */
   for (i = 0;  i < soCb.cfg.maxNmbSSaps;  i++)
   {
      if (soCb.soSSapCbLst[i] == NULLP)
      {
         continue;
      }

      /* now disable & delete all the SSaps and distroy them */
      soCb.soSSapCbLst[i]->state = LSO_SSAP_UBNDDIS;
      ret = soSSapDel(soCb.soSSapCbLst[i], reason);
   }

#ifdef SO_ABNF_MT_LIB
   /* Destroy all Encoder/Decoder Instances */
   tmpInst = soCb.init.inst + 1;
   for(i = 0; i < soCb.cfg.nmbEDThreads; i++)
   {
      SDeregTTsk(soCb.init.ent, tmpInst);
      SDestroySTsk(soCb.tskIdAr[i]);
      tmpInst++;
   }
   /* free Task id array */
   if(soCb.tskIdAr != NULLP)
   {
      SPutSBuf (soCb.init.region, soCb.init.pool, 
           soCb.tskIdAr, (soCb.cfg.nmbEDThreads * sizeof(SSTskId)));
   }
#endif /* SO_ABNF_MT_LIB */

   /* delete the all entities */
   for (i = 0;  i < (soCb.cfg.maxNmbUA + soCb.cfg.maxNmbNS);  i++)
   {
      if (soCb.entLst[i] != NULLP)
      {
         soSipEntDel(soCb.entLst[i], FALSE);
      }
   }

#ifdef SO_DNS 
   /* delete the DNS server */
   if (soCb.dnsCb != NULLP)
   {
      soDnsDeInit();
      soPrcDelTcmConn(&soCb.dnsConn);
   }
#endif

   /* delete the all TSAPs */
   for (i = 0;  i < soCb.cfg.maxNmbTSaps;  i++)
   {
      if (soCb.soTSapCbLst[i] != NULLP)
      {
         soTcmTSapDel(soCb.soTSapCbLst[i], FALSE);
      }
   }

#ifdef SO_NS
#ifdef SO_LCS 
   soLcsDeInit();
#endif /* SO_LCS */
   cmHashListDeinit(&soCb.cacheInfoCb.searchList);
#endif /* SO_NS */

   /* deinit global caches */
#ifdef SO_DNS 
   /*-- so032.201: DNS Cache is used, even if caching is disabled ---------*/
   soClCacheDeinit(&soCb.cacheInfoCb.dnsNaptrCache);
   soClCacheDeinit(&soCb.cacheInfoCb.dnsSrvCache);
   soClCacheDeinit(&soCb.cacheInfoCb.dnsACache);
#endif /* SO_DNS */
#ifdef SO_NS
#ifdef SO_LCS 
   if ((soCb.cfg.locSrvCfg.useExtLocServices == TRUE) &&
       (soCb.cfg.locSrvCfg.locCachePres == TRUE))
   {
      soClCacheDeinit(&soCb.cacheInfoCb.extLocSrvCache);
   }
#endif /* SO_LCS */
#endif /* SO_NS */

   /* clean up what we did in general configuration */
   soDeinitTimerQueues();

   SOFREE(soCb.soTSapCbLst,
          soCb.cfg.maxNmbTSaps * sizeof(SoTSapCb *));

   SOFREE(soCb.soSSapCbLst,
          soCb.cfg.maxNmbSSaps * sizeof(SoSSapCb *));

   SOFREE(soCb.entLst,
          (soCb.cfg.maxNmbNS + soCb.cfg.maxNmbUA) * sizeof(PTR *));

   SOFREE(soCb.allSrvCbLst, soCb.maxTptSrv * sizeof(PTR *));

   SPutSMem(soCb.init.region, soCb.init.pool);

   (Void)cmMemset((U8 *)&soCb.cfg, 0, sizeof(SoGenCfg));

   /* general configuration needs to be done now */
   soCb.init.cfgDone = FALSE;

   RETVALUE(LCM_PRIM_OK);

} /* end of soShutdownComplete */



#ifdef LSO_ACNT

/*
*
*       Fun:   soPrcAccounting
*
*       Desc:  Generates Accounting indication for specified Call
*
*       Ret:   Nothing
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PUBLIC Void soMiPrcAccounting
(
SoCLegCb       *leg,        /* Call */
U8             accInd       /* accounting indication */
)
#else
PUBLIC Void soMiPrcAccounting(leg,accInd)
SoCLegCb       *leg;        /* Call */
U8             accInd;      /* accounting indication */
#endif
{
#ifdef DEBUGP
   Duration    duration;         /* duration of Call in seconds */
   DateTime    tod;              /* current time of day         */
   U8          callIdStr[256];   /* Debug printing string for callId */
   U16         callIdLen;        /* Length of callId                 */
#endif

   TRC2(soPrcAccounting);

#ifdef DEBUGP
      callIdLen = leg->call->callId.len;
      if (callIdLen >= 255)
         callIdLen = 255;
      cmMemcpy(callIdStr, leg->call->callId.val, callIdLen);
      /* Zero terminate */
      callIdStr[callIdLen] = 0;
#endif

   if (leg->accntCb.accType == LSO_ACNT_REL)
   {
      SODBGP_SO(SO_DBGMASK_ACNT,
                (soCb.init.prntBuf,
                 "soPrcAccounting: Call:%s CallLeg:%lx Call released!\n",
                 callIdStr, leg->legId));
      RETVOID;
   }
   else
   {
      leg->accntCb.accType = accInd;
   }

   switch (accInd)
   {
      case  LSO_ACNT_EST:
         /* Get current time */
         SODBGP_SO(SO_DBGMASK_ACNT,
                   (soCb.init.prntBuf,
                    "\nsoPrcAccounting: Call:%s CallLeg:%lx **STARTED**\n",
                    callIdStr, leg->legId));
         SGetDateTime(&leg->accntCb.callStart);
         soMiSendAccInd(leg);
         break;
      case  LSO_ACNT_REL:
         /* only set the Call End Date/Time once */
         if (!SO_DATETIME_SET(&leg->accntCb.callEnd))
         {
            /* Get current time */
            SGetDateTime(&leg->accntCb.callEnd);
         }
#ifdef DEBUGP
         /* Call duration */
         soCmGetDuration(&leg->accntCb.callStart, &leg->accntCb.callEnd, 
                         &duration);
         SODBGP_SO(SO_DBGMASK_ACNT,
                   (soCb.init.prntBuf,
                    "\nsoPrcAccounting: Call:%s CallLeg:%lx **ENDED**"
                    " (Duration:%ld.%d secs)\n",
                    callIdStr, leg->legId,
                    (U32) DURATIONINSECONDS(duration),
                    duration.tenths));
#endif
         soMiSendAccInd(leg);
         break;

      case  LSO_ACNT_MOD:
#ifdef DEBUGP
         /* Get current time */
         SGetDateTime(&tod);
         /* Call duration so far */
         soCmGetDuration(&leg->accntCb.callStart, &tod, &duration);
         SODBGP_SO(SO_DBGMASK_ACNT,
                   (soCb.init.prntBuf,
                    "\nsoPrcAccounting: Call:%s CallLeg:%lx **MODIFIED**"
                    " (Duration:%ld.%d secs)\n",
                    callIdStr, leg->legId,
                    (U32) DURATIONINSECONDS(duration),
                    duration.tenths));
#endif
         soMiSendAccInd(leg);
         break;
   }

   RETVOID;
} /* soMiPrcAccounting */




/**********************************************************
*
*       Fun:   soMiSendAccInd
*
*       Desc:  This function sends an accounting indication
*              to the layer manager
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC Void soMiSendAccInd
(
SoCLegCb   *leg            /* Call Leg CB */
)
#else
PUBLIC Void soMiSendAccInd(leg)
SoCLegCb   *leg;           /* Call Leg CB */
#endif
{
   S16         ret;        /* value returned by function calls */
   SoMngmt     mngmt;      /* accounting management structure */

   TRC2(soMiSendAccInd);

   if (soCb.init.acnt == FALSE)
   {
      RETVOID;
   }

   cmMemset((U8 *)&mngmt, 0, sizeof(SoMngmt));

   soMiAccntRecBuild(&mngmt.t.acnt.acntInfo, leg);

   mngmt.hdr.elmId.elmnt = STSIPENT;
   SGetDateTime(&mngmt.t.acnt.dt);

   switch (mngmt.t.acnt.acntInfo.origin)
   {
     case LSO_ORIGINATOR:
       SODBGP_SO(SO_DBGMASK_ACNT,
                 (soCb.init.prntBuf,
                  "soMiSendAccInd: from ORIGINATOR\n"));
       break;
     case LSO_RECEIVER:
       SODBGP_SO(SO_DBGMASK_ACNT,
                 (soCb.init.prntBuf,
                  "soMiSendAccInd: from RECEIVER\n"));
       break;
     default:
       SODBGP_SO(SO_DBGMASK_ACNT,
                 (soCb.init.prntBuf,
                  "soMiSendAccInd: from ***NOT SET***\n"));
       break;
   }

   ret = SoMiLsoAcntInd(&leg->call->ent->pst, &mngmt);
   
   soMiFreeAcntInfo(&mngmt.t.acnt);

   RETVOID;
} /* soMiSendAccInd */


#endif /* LSO_ACNT */




/**********************************************************
*
*       Fun:   soSSapCfgReq
*
*       Desc:  Perform SIP layer configuration
*
*       Ret:   ROK
*
*       Notes: Initializes SIP SSAP
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soSSapCfgReq
(
SoSSapCfg     *cfg,        /* Configuration structure */
U16           *reason      /* Return reason */
)
#else
PUBLIC S16 soSSapCfgReq(cfg, reason)
SoSSapCfg     *cfg;        /* Configuration structure */
U16           *reason;     /* Return reason */
#endif
{
   SoSSapCb   *newSsap;       /* New SSAP control block */

   TRC2(soSSapCfgReq);

   /* have to have general configuration done first */
   if (soCb.init.cfgDone == FALSE)
   {
      *reason = LCM_REASON_GENCFG_NOT_DONE;
      RETVALUE(LCM_PRIM_NOK);
   }
   if ((cfg->sSapId >= soCb.cfg.maxNmbSSaps) || (cfg->sSapId < 0))
   {
      *reason = LCM_REASON_INVALID_SAP;
      RETVALUE(LCM_PRIM_NOK);
   }

   if (soCb.soSSapCbLst[cfg->sSapId] == NULLP)
   {
      /* allocate space for the SSAP */
      SOALLOC((Data **)&newSsap, sizeof(SoSSapCb));

      if (newSsap == NULLP)
      {
         /* No memory, config failed */
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(LCM_PRIM_NOK);
      }
      soCb.soSSapCbLst[cfg->sSapId] = newSsap;

      /* copy the configuration */
      cmMemcpy((U8 *)&newSsap->cfg,
               (U8 *)cfg, sizeof(SoSSapCfg));

      /* store initialize state */
      newSsap->sapId = cfg->sSapId;
      newSsap->state = LSO_SSAP_UBNDDIS;
      soCb.nmbSSap++;

      /* Initialize ->sys when binding */
      newSsap->sys = NULLP;
      /* newSsap->sts is zero from alloc */
      /* Initialize pst structure to upper interface */
      /* suId,   pst.dstProcId, dstEnt, dstInst initialized from BndReq */

      newSsap->pst.srcProcId = soCb.init.procId;
      newSsap->pst.srcEnt    = soCb.init.ent;
      newSsap->pst.srcInst   = soCb.init.inst;

      newSsap->pst.prior     = cfg->prior;
      newSsap->pst.route     = cfg->route;
      newSsap->pst.event     = 0;
      newSsap->pst.region    = cfg->memId.region;
      newSsap->pst.pool      = cfg->memId.pool;
      newSsap->pst.selector  = cfg->sel;

      /* initialize statistics */
      (Void) cmMemset((U8 *)&newSsap->sts, 0, sizeof(SoSSapSts));
      newSsap->sts.sSapId = cfg->sSapId;

   }
   else
   {
       *reason = LCM_REASON_INVALID_SAP;
       RETVALUE(LCM_PRIM_NOK);
   }

   *reason = LCM_REASON_NOT_APPL;
   RETVALUE(LCM_PRIM_OK);
} /* end of soSSapCfgReq */



/**********************************************************
*
*       Fun:   soSSapStsReq
*
*       Desc:  Perform SIP statistics request
*
*       Ret:   ROK
*
*       Notes: SSAP statistics
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soSSapStsReq
(
SoSts       *sts,        /* Statistics structure */
Action      action,
U16         *reason
)
#else
PUBLIC S16 soSSapStsReq(sts, action, reason)
SoSts       *sts;        /* statistics structure */
Action      action;
U16         *reason;
#endif
{
   TRC2(soSSapStsReq);

   /* Copy general statistics into return structure */
   cmMemcpy((U8 *)&sts->s.sSapSts,
            (U8 *)&soCb.soSSapCbLst[sts->s.sSapSts.sSapId]->sts,
             sizeof(SoSSapSts));

   /* Clear if required */
   if (action == ZEROSTS)
   {
     cmMemset((U8 *)&soCb.soSSapCbLst[sts->s.sSapSts.sSapId]->sts, 0,
              sizeof(SoSSapSts));
   }

   RETVALUE(LCM_PRIM_OK);

} /* end of soSSapStsReq */



/**********************************************************
*
*       Fun:   Delete SSap
*
*       Desc:  Deletes an SSAP
*
*       Ret:   LCM_PRIM_OK
*
*       Notes:
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soSSapDel
(
SoSSapCb    *ssapCb,    /* SSAP to delete         */
U16         *reason     /* Reason to return to LM */
)
#else
PUBLIC S16 soSSapDel(ssapCb, reason)
SoSSapCb    *ssapCb;    /* SSAP to delete         */
U16         *reason;    /* Reason to return to LM */
#endif
{
   SpId           sapId;        /* Sap ID to delete */
   S32            i;            /* Counter */
   SoEntCb        *locEntPtr;   /* local pointer */
   U16            j;            /* Counter */
   U16            k;            /* Counter */

   TRC2(soSSapDel);

   sapId = ssapCb->sapId;

   soSSapUbndDis(ssapCb, reason);

   cmHashListDeinit(&ssapCb->tranCbLst);

   *reason    = LCM_REASON_NOT_APPL;

   /* Remove reference in entities to SSAP */
   for (i = 0;  i < (soCb.cfg.maxNmbUA + soCb.cfg.maxNmbNS);  i++)
   {
      if (soCb.entLst[i] != NULLP)
      {
         locEntPtr = soCb.entLst[i];

         /* check through the list of SSaps for this entity */
         for (j = 0; j < locEntPtr->nmbSSap; j++)
         {
            if (locEntPtr->soSSapCbLst[j] != NULLP)
            {
               if (locEntPtr->soSSapCbLst[j]->sapId == sapId)
               {
                  /* we need to remove element j and sort the list down */
                  for (k = j; k < locEntPtr->nmbSSap - 1; k++)
                  {
                     locEntPtr->soSSapCbLst[k] = locEntPtr->soSSapCbLst[k+1];
                  }
                  locEntPtr->soSSapCbLst[k] = NULLP;
                  locEntPtr->nmbSSap--;
                  break;
               }
            }

         }
      }
   }

   /* free space for the SSAP */
   SOFREE(ssapCb, sizeof(SoSSapCb));

   soCb.soSSapCbLst[sapId] = NULLP;

   RETVALUE(LCM_PRIM_OK);
} /* soSSapDel */


/**********************************************************
*
*       Fun:   soSSapUbndDis
*
*       Desc:  Unbound and Disable SSAP
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soSSapUbndDis
(
SoSSapCb   *ssapCb,   /* SSAP to unbind and disabled */
U16        *reason    /* Reason to return to LM      */
)
#else
PUBLIC S16 soSSapUbndDis(ssapCb, reason)
SoSSapCb   *ssapCb;   /* SSAP to unbind and disabled */
U16        *reason;   /* Reason to return to LM      */
#endif
{
   TRC2(soSSapUbndDis);

   switch (ssapCb->state)
   {
      case LSO_SSAP_BNDENA:
         ssapCb->state = LSO_SSAP_UBNDDIS;

         /* send alarm for SSAP being unbound */
         soGenStaInd(STSSAP, LCM_CATEGORY_INTERNAL, LSO_EVENT_UBND_OK,
                     LSO_CAUSE_SAP_UBNDDIS, LSO_PAR_SAP,
                     (Ptr) &(ssapCb->cfg.sSapId));
         break;

      default:
         *reason       = LCM_REASON_INVALID_STATE;
         RETVALUE(RFAILED);
         break;
   }

   *reason = LCM_REASON_NOT_APPL;

   RETVALUE(ROK);
} /* soSSapUbndDis */



/**********************************************************
*
*       Fun:   soSSapGrDel
*
*       Desc:  Delete group of SSap
*
*       Ret:
*
*       Notes:
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soSSapGrDel(
ProcId procId,
U16  *reason
)
#else
PUBLIC S16 soSSapGrDel(procId, reason)
ProcId procId;
U16  *reason;
#endif
{
   U16   i;      /* Counter */
   U16   count;  /* How many SSAP's were processed */

   TRC2(soSSapGrDel);

   count = 0;

   for (i = 0; i < soCb.cfg.maxNmbSSaps; i++)
   {
      if ((soCb.soSSapCbLst[i] != NULLP) &&
          (soCb.soSSapCbLst[i]->pst.dstProcId == procId))
      {
         soSSapDel(soCb.soSSapCbLst[i], reason);
         count++;
      }
   }

   if (count == 0)
   {
      /* None found */
      *reason = LCM_REASON_NOT_APPL;
      RETVALUE(LCM_PRIM_NOK);
   }

   *reason = LCM_REASON_NOT_APPL;
   RETVALUE(LCM_PRIM_OK);
} /* soSSapGrDel */


/**********************************************************
*
*       Fun:   soSSapGrUbndDis
*
*       Desc:  Unbound and Disable group of SSAP
*
*       Ret:   LCM_PRIM_OK / LCM_PRIM_NOK
*
*       Notes: Unbinds and disabled all SSAP's with the
*              specified destination processor ID
*
*       File:  po_mi.c
*
**********************************************************/
#ifdef ANSI
PUBLIC U16 soSSapGrUbndDis
(
ProcId   procId,   /* Common destination processor ID */
U16      *reason   /* Reason to return in LM confirm  */
)
#else
PUBLIC U16 soSSapGrUbndDis(procId, reason)
ProcId   procId;   /* Common destination processor ID */
U16      *reason;  /* Reason to return in LM confirm  */
#endif
{
   U16      i;             /* Counter           */
   S16      ret;           /* Return value      */
   ProcId   locProcId;     /* local processor ID */

   TRC2(soSSapGrUbndDis);

   ret = LCM_PRIM_OK;

   /* check the validity of the procId */
   locProcId = SFndProcId();
   if (locProcId != procId)
   {
      /* invalid procID */
      *reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(LCM_PRIM_NOK);
   }

   /* loop through the list of configured SSAPs */
   for (i = 0; i < soCb.cfg.maxNmbSSaps; i++)
   {
      if (soCb.soSSapCbLst[i] != (SoSSapCb *) NULLP)
      {
         /* Configured SSAP found, match the procId */
         if (soCb.soSSapCbLst[i]->pst.srcProcId == procId)
         {
            /* SSAP with matching procId found */
            (Void) soSSapUbndDis(soCb.soSSapCbLst[i], reason);
         }
      }
   }

   *reason = LCM_REASON_NOT_APPL;

   RETVALUE(LCM_PRIM_OK);
} /* soSSapGrUbndDis */


/**********************************************************
*
*       Fun:   soTcmTSapCfgReq
*
*       Desc:  This function configures the TSAP.
*
*       Ret:   LCM_PRIM_OK              - successful
*              LCM_PRIM_NOK             - failure
*
*       Notes: None
*
*       File:  po_mi.c.c
*
**********************************************************/

#ifdef ANSI
PUBLIC S16 soTcmTSapCfgReq
(
SoTSapCfg   *cfg,         /* pointer to TSAP configuration structure */
SoTSapReCfg *reCfg,       /* reconfiguration structure */
U16         *reason       /* result reason */
)
#else
PUBLIC S16 soTcmTSapCfgReq(cfg, reCfg, reason)
SoTSapCfg   *cfg;         /* pointer to TSAP configuration structure */
SoTSapReCfg *reCfg;       /* reconfiguration structure */
U16         *reason;      /* result reason */
#endif
{
   S16         ret;           /* temporary */
   SoTSapCb    *newTSapCb;    /* New control block */
   SuId        tsapId;        /* TSap ID */

   TRC2(soTcmTSapCfgReq);

   tsapId = cfg->tSapId;


   /* have to have general configuration done first */
   if (soCb.init.cfgDone == FALSE)
   {
      *reason = LCM_REASON_GENCFG_NOT_DONE;
      RETVALUE(LCM_PRIM_NOK);
   }

   if ((tsapId >= soCb.cfg.maxNmbTSaps) || (tsapId < 0))
   {
      *reason = LCM_REASON_INVALID_SAP;
      RETVALUE(LCM_PRIM_NOK);
   }

   /* check if first time configuration */
   if (soCb.soTSapCbLst[tsapId] == NULLP)
   {
      SOALLOC((Data **)&newTSapCb, sizeof(SoTSapCb));
      if (newTSapCb == NULLP)
      {
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(LCM_PRIM_NOK);
      }

      /* copy the configuration */
      (Void)cmMemcpy((U8 *)&newTSapCb->cfg, (U8 *)cfg, sizeof(SoTSapCfg));

      newTSapCb->suConnIdSeqNum  = soCb.maxTptSrv;
      newTSapCb->srvConnIdSeqNum = 0;

      /* Initialize connection list */
      ret = cmHashListInit(&newTSapCb->suConnIdHlCp,
                           cfg->suConIdHlBins,
                           (U16)SO_OFFSET_OF(SoTptClientCb, suConnIdHl),
                           FALSE,
                           CM_HASH_KEYTYPE_CONID,
                           soCb.init.region,
                           soCb.init.pool);
      if (ret != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO152, (ErrVal)0,"cmHashListInit() failed.");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         /* free memory */
         SOFREE(newTSapCb, sizeof(SoTSapCb));
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(LCM_PRIM_NOK);
      }

      ret = cmHashListInit(&newTSapCb->tptAddrHlCp,
                           cfg->tptAddrHlBins,
                           (U16)SO_OFFSET_OF(SoTptClientCb, tptAddrHl),
                           TRUE,
                           CM_HASH_KEYTYPE_ANY,
                           soCb.init.region,
                           soCb.init.pool);
      if (ret != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO153, (ErrVal)0,"cmHashListInit() failed.");
#endif
         cmHashListDeinit(&newTSapCb->suConnIdHlCp);
         /* free memory */
         SOFREE(newTSapCb, sizeof(SoTSapCb));
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE(LCM_PRIM_NOK);
      }

      /* Store new TSAP */
      soCb.soTSapCbLst[tsapId] = newTSapCb;

      /* Fill in the post structure for the new TSAP */
      newTSapCb->liPst.srcProcId = soCb.init.procId;
      newTSapCb->liPst.srcEnt    = soCb.init.ent;
      newTSapCb->liPst.srcInst   = soCb.init.inst;

      newTSapCb->liPst.dstProcId = newTSapCb->cfg.dstProcId;
      newTSapCb->liPst.dstEnt    = newTSapCb->cfg.dstEnt;
      newTSapCb->liPst.dstInst   = newTSapCb->cfg.dstInst;

      newTSapCb->liPst.prior     = newTSapCb->cfg.dstPrior;
      newTSapCb->liPst.route     = newTSapCb->cfg.dstRoute;
      newTSapCb->liPst.selector  = newTSapCb->cfg.dstSel;
      newTSapCb->liPst.event     = EVTNONE;

      newTSapCb->liPst.region    = newTSapCb->cfg.memId.region;
      newTSapCb->liPst.pool      = newTSapCb->cfg.memId.pool;

      /* State of new TSAP if unbound and disabled */
      newTSapCb->state          = LSO_TSAP_UBNDDIS;

      /* initialize the bind retry count and the bind timer */
      newTSapCb->bndRetryCnt = 0;
      newTSapCb->resCong     = FALSE;

      /* SO_DIS_SAP compile time flag should only be enabled if the control
         is done via stack manager at the initialisation time */
#ifdef SO_DIS_SAP
      newTSapCb->contEnt = ENTSM;   /* stack manager controlling entity */
#else
      newTSapCb->contEnt = ENTNC;   /* unknown controlling entity */
#endif /* SO_DIS_SAP */

      soCmInitTimer(&newTSapCb->bndTmr);

      /* zero statistics */
      (Void)cmMemset((U8 *)&newTSapCb->sts, 0, sizeof(SoTSapSts));
      newTSapCb->sts.tSapId = tsapId;

      newTSapCb->cfgDone = TRUE;

#ifdef SO_DNS 
      /* do DNS config if dns server belongs to this TASP */
      if (soCb.dnsCb != (CmDnsCb *)NULLP)
      {
          if (soCb.reCfg.dnsReCfg.tSapId == tsapId)
          {
              soCb.dnsSrvCb->tsapCb = soCb.soTSapCbLst[cfg->tSapId];
          }
      }
#endif
   }
   /* reconfiguration - just change parameters
    * Only new connections will be affected
    */
   (Void)cmMemcpy((U8 *)&(soCb.soTSapCbLst[tsapId]->reCfg),
      (U8 *)reCfg, sizeof(SoTSapReCfg));

   *reason = LCM_REASON_NOT_APPL;
   RETVALUE(LCM_PRIM_OK);
} /* soTcmTSapCfg */


/**********************************************************
*
*       Fun:   soTcmTSapSts
*
*       Desc:  TSap statistics
*
*       Ret:   LCM_PRIM_OK   - ok
*
*       File:  po_mi.c
*
**********************************************************/

#ifdef ANSI
PUBLIC S16 soTcmTSapStsReq
(
SoTSapSts   *sts,       /* Returned statistics */
Action      action,     /* Action */
U16         *reason     /* Result */
)
#else
PUBLIC S16 soTcmTSapStsReq(sts, action, reason)
SoTSapSts   *sts;       /* Returned statistics */
Action      action;     /* Action */
U16         *reason;    /* Result */
#endif
{
   SoTSapCb    *tsapCb;    /* TSAP control block */
   SpId        sapId;      /* TSAP id */

   TRC3(soTcmTSapStsReq);

   sapId = sts->tSapId;

   /* request to invalid TSAP */
   if ((sapId >= soCb.cfg.maxNmbTSaps) || (sapId < 0))
   {
      *reason = LCM_REASON_INVALID_ELMNT;
      RETVALUE(LCM_PRIM_NOK);
   }

   tsapCb = soCb.soTSapCbLst[sapId];

   if (tsapCb == NULLP)
   {
      *reason = LCM_REASON_INVALID_SAP;
      RETVALUE(LCM_PRIM_NOK);
   }

   /* copy the statistics information from the TSAP */
   (Void)cmMemcpy((U8 *)sts, (U8 *)&tsapCb->sts, sizeof(SoTSapSts));

   /* zero the statistics if required */
   if (action == ZEROSTS)
   {
      (Void) cmMemset((U8 *)&tsapCb->sts, 0, sizeof(SoTSapSts));
      tsapCb->sts.tSapId = sapId;
   }

   RETVALUE(LCM_PRIM_OK);
} /* end of soTcmTSapSts */



/**********************************************************
*
*       Fun:   soTcmTSapBndEna
*
*       Desc:  Bind and enable TSAP
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  po_mi.c
*
**********************************************************/

#ifdef ANSI
PUBLIC Void soTcmTSapBndEna
(
SoTSapCb  *tsapCb    /* TSAP control block */
)
#else
PUBLIC Void soTcmTSapBndEna(tsapCb)
SoTSapCb  *tsapCb;   /* TSAP control block */
#endif
{
   S16         ret;        /* Return value */

   TRC2(soTcmTSapBndEna);

   switch (tsapCb->state)
   {
      case LSO_TSAP_UBNDDIS:
         tsapCb->state = LSO_TSAP_WAIT_BNDENA;
         if (tsapCb->reCfg.bndTmCfg.enb == TRUE)
         {
            ret = soSchedTmr (tsapCb,
                              SO_TMR_TCM_BND, TMR_START,
                              tsapCb->reCfg.bndTmCfg.val);
#if (ERRCLASS & ERRCLS_DEBUG)
            if (ret != ROK)
            {
               SOLOGERROR(ERRCLS_DEBUG, ESO154,
                  (ErrVal) ret,"soTcmTSapBndEna: Timer start failed\n");
            }
#endif /* ERRCLASS & ERRCLS_DEBUG */
         }

         soSendLmCntrlCfm(&tsapCb->cfmPst,
                          LCM_PRIM_OK_NDONE,
                          LCM_REASON_NOT_APPL,
                          &tsapCb->ctrlHdr);

         /* Reset bind retry count */
         tsapCb->bndRetryCnt = 0;

         (Void)SoLiHitBndReq(&tsapCb->liPst,
                             tsapCb->cfg.tSapId,
                             tsapCb->cfg.spId);
         break;

      case LSO_TSAP_WAIT_BNDENA:
         soSendLmCntrlCfm(&soCb.init.lmPst,
                          LCM_PRIM_OK_NDONE,
                          LCM_REASON_NOT_APPL,
                          &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_BNDENA:
         soSendLmCntrlCfm(&soCb.init.lmPst,
                          LCM_PRIM_OK,
                          LCM_REASON_NOT_APPL,
                          &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_WAIT_BNDDIS:
         tsapCb->state = LSO_TSAP_WAIT_BNDENA;
         soSendLmCntrlCfm(&tsapCb->cfmPst,
                          LCM_PRIM_OK_NDONE,
                          LCM_REASON_NOT_APPL,
                          &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_BNDDIS:
         tsapCb->state = LSO_TSAP_BNDENA;
         soSendLmCntrlCfm(&soCb.init.lmPst,
                          LCM_PRIM_OK,
                          LCM_REASON_NOT_APPL,
                          &tsapCb->ctrlHdr);
         soTptProcessTsapServers (tsapCb, SO_TCM_TPTSRV_OPEN);
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO155, (ErrVal) tsapCb->state,
            "soTcmTSapBndEna: Invalid TSAP state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         soSendLmCntrlCfm(&soCb.init.lmPst,
                          LCM_PRIM_NOK,
                          LCM_REASON_INVALID_STATE,
                          &tsapCb->ctrlHdr);
         break;
   }
   RETVOID;
} /* soTcmTSapBndEna */


/**********************************************************
*
*       Fun:   soTcmTSapEna
*
*       Desc:  Enable TSAP
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  po_mi.c
*
**********************************************************/

#ifdef ANSI
PUBLIC Void soTcmTSapEna
(
SoTSapCb  *tsapCb    /* TSAP control block */
)
#else
PUBLIC Void soTcmTSapEna(tsapCb)
SoTSapCb  *tsapCb;   /* TSAP control block */
#endif
{

   TRC2(soTcmTSapEna);

   switch (tsapCb->state)
   {
      case LSO_TSAP_UBNDDIS:
         soSendLmCntrlCfm(&soCb.init.lmPst,
            LCM_PRIM_NOK, LCM_REASON_INVALID_STATE,
            &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_WAIT_BNDENA:
         soSendLmCntrlCfm(&tsapCb->cfmPst,
            LCM_PRIM_OK_NDONE, LCM_REASON_NOT_APPL,
            &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_BNDENA:
         soSendLmCntrlCfm(&soCb.init.lmPst,
            LCM_PRIM_OK, LCM_REASON_NOT_APPL,
            &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_WAIT_BNDDIS:
         tsapCb->state = LSO_TSAP_WAIT_BNDENA;
         soSendLmCntrlCfm(&tsapCb->cfmPst,
            LCM_PRIM_OK_NDONE, LCM_REASON_NOT_APPL,
            &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_BNDDIS:
         tsapCb->state  = LSO_TSAP_BNDENA;
         soSendLmCntrlCfm(&soCb.init.lmPst,
            LCM_PRIM_OK, LCM_REASON_NOT_APPL,
            &tsapCb->ctrlHdr);
         soTptProcessTsapServers (tsapCb, SO_TCM_TPTSRV_OPEN);
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO156, (ErrVal) tsapCb->state,
            "soTcmTSapBndEna: Invalid TSAP state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         soSendLmCntrlCfm(&soCb.init.lmPst,
            LCM_PRIM_NOK, LCM_REASON_INVALID_STATE,
            &tsapCb->ctrlHdr);
         break;
   }
   RETVOID;
} /* soTcmTSapEna */


/**********************************************************
*
*       Fun:  soTcmTSapDis
*
*       Desc: Disables TSAP
*
*       Ret:  Nothing
*
*       Notes:
*
*       File:  so_tcm.c
*
**********************************************************/

#ifdef ANSI
PUBLIC Void soTcmTSapDis
(
SoTSapCb  *tsapCb    /* TSAP control block */
)
#else
PUBLIC Void soTcmTSapDis(tsapCb)
SoTSapCb  *tsapCb;   /* TSAP control block */
#endif
{

   SoTptClientCb    *clientCb;  /* Connection control block */

   TRC2(soTcmTSapDis);

   switch (tsapCb->state)
   {
      case LSO_TSAP_UBNDDIS:
         soSendLmCntrlCfm(&soCb.init.lmPst,
            LCM_PRIM_OK, LCM_REASON_NOT_APPL,
            &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_WAIT_BNDENA:
         tsapCb->state = LSO_TSAP_WAIT_BNDDIS;
         soSendLmCntrlCfm(&soCb.init.lmPst,
            LCM_PRIM_OK, LCM_REASON_NOT_APPL,
            &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_BNDENA:
         /* Close all transport servers */
         soTptProcessTsapServers (tsapCb, SO_TCM_TPTSRV_CLOSE);

         while (cmHashListGetNext (&tsapCb->suConnIdHlCp, NULLP,
                                  (PTR *)&clientCb) == ROK)
         {
            /* Here we are trying to close the clientCb Forcefully. We remove 
             * all the references to this clientCb and bring it down. */
            soTptCloseClient (clientCb, FALSE);
         }

         tsapCb->state = LSO_TSAP_BNDDIS;
         soSendLmCntrlCfm(&soCb.init.lmPst,
            LCM_PRIM_OK, LCM_REASON_NOT_APPL,
            &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_WAIT_BNDDIS:
         soSendLmCntrlCfm(&tsapCb->cfmPst,
            LCM_PRIM_OK_NDONE, LCM_REASON_NOT_APPL,
            &tsapCb->ctrlHdr);
         break;
      case LSO_TSAP_BNDDIS:
         soSendLmCntrlCfm(&soCb.init.lmPst,
            LCM_PRIM_OK, LCM_REASON_NOT_APPL,
            &tsapCb->ctrlHdr);
         break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO157, (ErrVal) tsapCb->state,
            "soTcmTSapDis: Invalid TSAP state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         soSendLmCntrlCfm(&soCb.init.lmPst,
            LCM_PRIM_NOK, LCM_REASON_INVALID_STATE,
            &tsapCb->ctrlHdr);
         break;
   }

   RETVOID;
} /* soTcmTSapDis */


/**********************************************************
*
*       Fun:   soTcmTSapUbndDis
*
*       Desc:  Unbind and disable TSAP
*
*       Ret:   Nothing
*
*       Notes: Assumes TUCL has crashed, does not send TUCL primitives
*                - Only resets state in SIP data structures
*
*       File:  po_mi.c
*
**********************************************************/

#ifdef ANSI
PUBLIC Void soTcmTSapUbndDis
(
SoTSapCb  *tsapCb    /* TSAP control block */
)
#else
PUBLIC Void soTcmTSapUbndDis(tsapCb)
SoTSapCb  *tsapCb;   /* TSAP control block */
#endif
{
   SoTptClientCb  *clientCb;    /* Connection to close */
   S16            retVal;     /* Return value */

   TRC2(soTcmTSapUbndDis);

   switch (tsapCb->state)
   {
      case LSO_TSAP_UBNDDIS:
         soSendLmCntrlCfm(&soCb.init.lmPst,
                          LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                          &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_WAIT_BNDENA:
         tsapCb->state = LSO_TSAP_UBNDDIS;
         (Void) soSchedTmr (tsapCb, SO_TMR_TCM_BND, TMR_STOP, NOTUSED);
         soSendLmCntrlCfm(&soCb.init.lmPst,
                          LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                          &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_BNDENA:
         /* Close all transport servers */
         soTptProcessTsapServers (tsapCb, SO_TCM_TPTSRV_DISABLE);

         /* Close all TCP connections */
         while((retVal = cmHashListGetNext(&tsapCb->suConnIdHlCp,
                                           NULLP, (PTR *) &clientCb)) == ROK)
         {
            /* Here we are trying to close the clientCb Forcefully.
             * We remove all the references to this clientCb and
             * bring it down. */
            soTptCloseClient (clientCb, FALSE);
         }

         tsapCb->state = LSO_TSAP_UBNDDIS;

         /* state change */
         soGenStaInd(STTSAP, LCM_CATEGORY_INTERNAL, LSO_EVENT_UBND_OK,
                     LSO_CAUSE_SAP_UBNDDIS, LSO_PAR_SAP,
                     (Ptr) &tsapCb->cfg.tSapId);

         soSendLmCntrlCfm(&soCb.init.lmPst,
                          LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                          &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_WAIT_BNDDIS:
         tsapCb->state = LSO_TSAP_UBNDDIS;
         (Void) soSchedTmr (tsapCb, SO_TMR_TCM_BND, TMR_STOP, NOTUSED);

         soSendLmCntrlCfm(&soCb.init.lmPst,
                          LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                          &tsapCb->ctrlHdr);
         break;

      case LSO_TSAP_BNDDIS:
         tsapCb->state = LSO_TSAP_UBNDDIS;

         /* state change */
         soGenStaInd(STTSAP, LCM_CATEGORY_INTERNAL, LSO_EVENT_UBND_OK,
                     LSO_CAUSE_SAP_UBNDDIS, LSO_PAR_SAP,
                     (Ptr) &tsapCb->cfg.tSapId);

         soSendLmCntrlCfm(&soCb.init.lmPst,
                          LCM_PRIM_OK, LCM_REASON_NOT_APPL,
                          &tsapCb->ctrlHdr);
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO158, (ErrVal) tsapCb->state,
            "soTcmTSapUbndDis: Invalid TSAP state\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         soSendLmCntrlCfm(&soCb.init.lmPst,
                          LCM_PRIM_NOK,
                          LCM_REASON_INVALID_STATE,
                          &tsapCb->ctrlHdr);
         break;
   }
   RETVOID;
} /* end of soTcmTSapUbndDis */


/**********************************************************
*
*       Fun:   soTcmTSapDel
*
*       Desc:  Deletes TSap
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  po_mi.c
*
**********************************************************/

#ifdef ANSI
PUBLIC Void soTcmTSapDel
(
SoTSapCb  *tsapCb,   /* TSAP control block */
Bool      genCfm     /* Generate LM confirm */
)
#else
PUBLIC Void soTcmTSapDel(tsapCb, genCfm)
SoTSapCb  *tsapCb;   /* TSAP control block */
Bool      genCfm;    /* Generate LM confirm */
#endif
{
   S16           retVal;     /* Return value */
   SoTptClientCb *clientCb;    /* Connection control block */

   TRC2(soTcmTSapDel);

   switch (tsapCb->state)
   {
      case LSO_TSAP_UBNDDIS:
         break;

      case LSO_TSAP_WAIT_BNDENA:
         (Void) soSchedTmr(tsapCb, SO_TMR_TCM_BND, TMR_STOP, NOTUSED);
         (Void) SoLiHitUbndReq (&tsapCb->liPst, tsapCb->cfg.spId,
            HI_UBNDREQ_MNGMT);
         soGenStaInd(STTSAP, LCM_CATEGORY_INTERNAL, LSO_EVENT_UBND_OK,
                     LSO_CAUSE_SAP_UBNDDIS, LSO_PAR_SAP,
                     (Ptr) &tsapCb->cfg.tSapId);
         break;

      case LSO_TSAP_BNDENA:
         while((retVal = cmHashListGetNext(&tsapCb->suConnIdHlCp,
                                           NULLP,
                                           (PTR *) &clientCb)) == ROK)
         {
            /* Here we are trying to close the clientCb Forcefully.
             * We remove all the references to this clientCb and
             * bring it down. */
            soTptCloseClient (clientCb, FALSE);
         }

         /* Close all transport servers */
         soTptProcessTsapServers (tsapCb, SO_TCM_TPTSRV_FREE);

         (Void) SoLiHitUbndReq (&tsapCb->liPst,
            tsapCb->cfg.spId, HI_UBNDREQ_MNGMT);
         soGenStaInd(STTSAP, LCM_CATEGORY_INTERNAL, LSO_EVENT_UBND_OK,
                     LSO_CAUSE_SAP_UBNDDIS, LSO_PAR_SAP,
                     (Ptr) &tsapCb->cfg.tSapId);
         break;

      case LSO_TSAP_WAIT_BNDDIS:
         (Void) soSchedTmr(tsapCb, SO_TMR_TCM_BND, TMR_STOP, NOTUSED);
         (Void) SoLiHitUbndReq (&tsapCb->liPst, tsapCb->cfg.spId,
            HI_UBNDREQ_MNGMT);
         soGenStaInd(STTSAP, LCM_CATEGORY_INTERNAL, LSO_EVENT_UBND_OK,
                     LSO_CAUSE_SAP_UBNDDIS, LSO_PAR_SAP,
                     (Ptr) &tsapCb->cfg.tSapId);
         break;

      case LSO_TSAP_BNDDIS:
         (Void) SoLiHitUbndReq (&tsapCb->liPst,
            tsapCb->cfg.spId, HI_UBNDREQ_MNGMT);
         soGenStaInd(STTSAP, LCM_CATEGORY_INTERNAL, LSO_EVENT_UBND_OK,
                     LSO_CAUSE_SAP_UBNDDIS, LSO_PAR_SAP,
                     (Ptr) &tsapCb->cfg.tSapId);
         break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO159, (ErrVal) tsapCb->state,
            "soTcmTSapDel: Invalid TSAP state - delete anyway\n");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         break;
   }

   if (genCfm == TRUE)
   {
      soSendLmCntrlCfm(&soCb.init.lmPst,
         LCM_PRIM_OK, LCM_REASON_NOT_APPL, &tsapCb->ctrlHdr);
   }

   /* Remove from global list and free control block */
   soCb.soTSapCbLst[tsapCb->cfg.tSapId] = NULLP;

   cmHashListDeinit(&tsapCb->suConnIdHlCp);

   cmHashListDeinit(&tsapCb->tptAddrHlCp);
   
   SOFREE (tsapCb, sizeof (SoTSapCb));

   RETVOID;
} /* soTcmTSapDel */






/********************************************************************30**

         End of file:     so_mi.c@@/main/4 - Tue Apr 20 12:46:47 2004

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      ms            1. initial release.
/main/1+    so002.11  us            1. accounting related functions
                                     added.
                                    2. miscellaneous.
            so007.101 zmc           1. In stead of allowing multiple 
                                       domains, we can cheat the stack 
                                       by using multiple host names 
                                       and set domain name to be NULL.
                                       So here we need to check
                                       the length of domain before adding 
                                       the domain name.
                                    2. Here we need to handle the case 
                                       that host length = zero
                                       but domain length != 0.
/main/1+    so010.101 zmc           1. The status request did not 
                                       retrieve the number of active calls. 
                                       This fix is provided here.
/main/1+    so011.101  ak           1. LSO_ACNT related Code was added 
                                    2. Added the code to handle the addition and
                                       deletion of association between SSAP and 
                                       transport server through SSAP control 
                                       requests -
                                       AADD_ASSOC_TPTSRV and ADEL_ASSOC_TPTSRV
/main/1+     so012.101 fl           1. Add SO_NS for all locSrvCfg,
                                       locSrvReCfg, locSrvSapId 
                                       references
                       hd           2. Change entId from U32 to U8.
                                    3. Remove (entId < 0) because entId is U8.
/main/1+     so013.101 hd           1. Check if curSrv for the DNS tptSrv is 
                                       valid or not.
             so014.101 zmc          1. Set the prevSipCall = sipCall to solve 
                                       the machine hanging problem due to the 
                                       garbage collector.
                       bdu          2. Adapted calls to soUaEndCallLegToRemote
                                       and soUaEndCallLegToSU for new parameter
                                       lists.
                       hd           3. Garbage collection is in cyclic timer.
             so015.101 bdu          1. Make callIdHlBins and callHdlHlBins,
                                       numCLegHlBins, numTransHlBins, 
                                       locSrchHlBins and suConIdHlBins as
                                       configurable parameter and change 
                                       hashing function correspondingly.
             so018.101 yj,np        1. calls to soTptCloseClient  need 
                                       additional params
                                    2. Upon shutdown, we donot inform the 
                                       remote-end anymore. Come on guys, it is
                                       a shutdown, after all :-)
/main/1+     so019.101 hd           1. Miscellaneous.
             so020.101 pk           1. Miscellaneous changes in shutdown.
             so022.101 yj           1. Removed Garbage collection.
                       ak           2. Fixed code that used soCmShrinkList 
                                       incorrectly.  
             so023.101 cvp          1. Added the (de)initialisation of tpt  
                                       addr hash list.
/main/1+     so024.101 cvp          1. Increased the default sizes of hash 
                                       lists.
/main/1+     so025.101 hd           1. Miscellaneous.
             so025.101 pk           1. Added calc of ent uptime and
                                       filling of the param in stacfm
/main/2      ---       cy           1. Miscellaneous changes.
                                    2. changed copyright header
/main/2+     so001.102 bdu          1. Use entCb for reCfg instead of entCfg.
                                    2. Fixed some issues in SSap Deletion.
/main/2+     so002.102 bdu          1. free the RegCb in EntDel.
             so005.102 bdu          2. Moved some params inside UA flag
                                       in soSipEntDel
             so006.102 ps           1. Changes for performance improvement.
/main/4      ---       pg           1. Initial Release
/main/4      so010.201 ab           1. Fix to guard opening of tpt srv with a timer
/main/4+     so012.201 ps           1. Allow transaction list to have duplicate
                                       entries.
/main/4+     so015.201 ab           1. Delete suConnIdLst and transLst for 1.2
                                       interface.
/main/4+     so016.201 ab           1. Deinitialize regCbLst during shutdown.
                       ad           2. Memory Leak fix in Re-config of UA Entity 
/main/4+     so019.201 ps           1. Update error statistics.
/main/4+     so026.201 ab           1. Clear supported list before entity cfg.
/main/4+     so028.201 ad           1. Entity re-cfg for the case of Tightly coupling.
/main/4+     so030.201 ss           1. Removing transaction which are not part of any Call
/main/4+     so032.201 ng           1. Initialize DNS cache even if caching is disabled to
                                       hold temporary resulsts till the end of DNS trans.
                                    2. Pass event type to locate call control block
                                    3. Include so_ed.x to compile with SO_ABNF_MT_LIB
                                    4. Retreive entity Id from ssapCb(ab) 
/main/4+     so033.201 ng           1. Put the check for Transport SrvId in (aj)
                                       re-configuration of DNS.
             so033.201 ng           2. Provide cntrlcfm to LMI for server open indication and entity is disabled previously.  
/main/4+     so035.201 ng           1. Reset the retry of server connection ones
                                       all retry is done.Also localized checking
                                       of retry count at one place.(ps)
/main/4+     so038.201 ng           1. Add precondition to list of options supportted 
                                       if RFC3312 falg is defined
/main/4+     so038.201  ng          1. Modified mBuf to trcBuf for release mem in soGenTrcInd
*********************************************************************91*/
