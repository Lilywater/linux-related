/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SIP Layer

     Type:     C source file

     Desc:     C source code for SO layer portable Lower Interface

     File:     so_cm.c

     Sid:      so_cm.c@@/main/6 - Tue Apr 20 12:45:59 2004

     Prg:      dg

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_inet.h"       /* common socket library */
#include "cm_tpt.h"        /* common transport library */
#include "cm_tkns.h"       /* common tokens library */
#include "cm_sdp.h"        /* common sdp library */
#include "cm_dns.h"        /* common DNS                   */
#include "cm_abnf.h"       /* common abnf library */

#include "so_err.h"        /* SIP error defines */
#include "lso.h"           /* LM interface */
#include "sot.h"           /* Upper interface */
#include "so.h"            /* SIP layer */
#include "so_cm.h"         /* SIP layer utility functions */
#include "cm_hash.h"       /* common hash list */
#include "cm_llist.h"      /* common linked list */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* common hash list */
#include "cm_xtree.x"      /* common radix tree */
#include "cm_llist.x"      /* common linked list */
#include "cm5.x"           /* common timers */


#include "cm_inet.x"       /* common socket library */
#include "cm_tkns.x"       /* common tokens library */
#include "cm_tpt.x"        /* common transport library */
#include "cm_lib.x"        /* common library */

#include "cm_mblk.x"       /* common memory block library */
#include "cm_sdp.x"        /* common sdp library */
#include "cm_dns.x"        /* common DNS                   */
#include "cm_md5.x"        /* common MD5 */
#include "cm_abnf.x"       /* common abnf */

#include "lso.x"           /* LM interface */
#include "sot.x"           /* Upper interface */
#include "so_tcm.x"        /* SIP transport module structures */
#include "so.x"            /* SIP layer structures */
#include "so_utl.x"        /* SIP layer utility functions */
#include "so_cm.x"         /* SIP layer common functions */
/* so019.201: Change to fix the compile warning */
#include "so_ua.x"          /* SIP UA                       */



/* local typedefs */
#define SO_URI_ESC_CHAR '%'


/* local function definitions */

/* public variable declarations */

PUBLIC SoInitCb    soCb;   /* Layer global control block */

PUBLIC Txt *soExtSIPCodes[]=
{
   "",
   "Resources low",
   "Invalid method for registrar",
   "Entity Disabled",
   "Remote registry failure",
   "3rd Party registration not allowed",
   "Request-URI mismatch"
};


PUBLIC SoStatusCodePhrase soSIPCodes[]=
{
   {100, "Trying"},
   {180, "Ringing"},
   {181, "Call is Being Forwarded"},
   {182, "Queued"},
   {183, "Session Progress"},
   {200, "OK"},
   {202, "Accepted"},
   {300, "Multiple Choices"},
   {301, "Moved Permanently"},
   {302, "Moved Temporarily"},
   {305, "Use Proxy"},
   {380, "Alternative Service"},
   {400, "Bad Request"},
   {401, "Unauthorized"},
   {402, "Payment Required"},
   {403, "Forbidden"},
   {404, "Not Found"},
   {405, "Method not allowed"},
   {406, "Not Acceptable"},
   {407, "Proxy Authentication Required"},
   {408, "Request Timeout"},
   {409, "Conflict"},
   {410, "Gone"},
   {411, "Length Required"},
   {413, "Request Entity Too Large"},
   {414, "Request URI Too Large"},
   {415, "Unsupported Media Type"},
   {416, "Unsupported URI Scheme"},
   /* so020.201: Corrected the misspelling of extension */
   {420, "Bad Extension"},
   {421, "Extension Required"},
   {422, "Session Timer Too Small"},
   {423, "Interval Too Brief"},
   {480, "Temporarily Unavailable"},
   {481, "Call Leg/Transaction Does Not Exist"},
   {482, "Loop Detected"},
   {483, "Too Many Hops"},
   {484, "Address Incomplete"},
   {485, "Ambiguous"},
   {486, "Busy Here"},
   {487, "Request Terminated"},
   {488, "Not Acceptable Here"},
   {489, "Bad Event"},
   /* so012.201: Add 491 response code */
   {491, "Request Pending"},
   {500, "Internal Server Error"},
   {501, "Not Implemented"},
   {502, "Bad Gateway"},
   {503, "Service Unavailable"},
   {504, "Gateway Timeout"},
   {505, "SIP Version not supported"},
   {580, "Precondition Failure"},
   {600, "Busy Everywhere"},
   {603, "Decline"},
   {604, "Does not exist anywhere"},
   {606, "Not Acceptable"},
   {0, " "}                      /* this should always be the last entry */
                                 /* all codes go before this one */
};





/*
*
*       Fun:   soCmGetDaysInMonth
*
*       Desc:  This function gets the number of days in a given month in a
*              given year.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmGetDaysInMonth
(
U8 *daysInMonth,     /* Days in month */
U8 month,            /* Month         */
U16 year             /* Year          */
)
#else
PUBLIC S16 soCmGetDaysInMonth(daysInMonth, month, year)
U8 *daysInMonth;     /* Days in month */
U8 month;            /* Month         */
U16 year;            /* Year          */
#endif
{
   TRC2(soCmGetDaysInMonth);

   switch (month)
   {
      case 4:
         /* fall through */
      case 6:
         /* fall through */
      case 9:
         /* fall through */
      case 11:
         *daysInMonth = 30;
         break;
      case 1:
         /* fall through */
      case 3:
         /* fall through */
      case 5:
         /* fall through */
      case 7:
         /* fall through */
      case 8:
         /* fall through */
      case 10:
         /* fall through */
      case 12:
         *daysInMonth = 31;
         break;
      case 2:
         if ((year % 4 == 0) && ((year % 100 != 0) || (year % 400 == 0)))
         {
            *daysInMonth = 29;
         }
         else
         {
            *daysInMonth = 28;
         }
         break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO060, month,
                       "soCmGetDaysInMonth: Invalid month.");
#endif /* ERRCLASS & ERRCLS_DEBUG */
            RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of soCmGetDaysInMonth */

/*
*
*       Fun:   soCmGetDateFromSec
*
*       Desc:  This function converts seconds since Jan 1, 2000 to a date.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmGetDateFromSec
(
DateTime *dt,     /* date to be output       */
U32 seconds       /* seconds to be converted */
)
#else
PUBLIC S16 soCmGetDateFromSec(dt, seconds)
DateTime *dt;     /* date to be output       */
U32 seconds;      /* seconds to be converted */
#endif
{
   U32 remDays;         /* number of days remaining    */
   U32 remSeconds;      /* number of seconds remaining */
   U16 year;            /* year counter                */
   U8  month;           /* month counter               */
   U16 daysInYear;      /* no. days in year            */
   U8  daysInMonth;     /* no. days in month           */

   TRC2(soCmGetDateFromSec);

   remDays    = seconds / SO_CM_SEC_IN_DAY;
   remSeconds = seconds % SO_CM_SEC_IN_DAY;

   year = SO_CM_START_YEAR;
   if ((year % 4 == 0) && ((year % 100 != 0) || (year % 400 == 0)))
   {
      /* year is a leap-year */
      daysInYear = 366;
   }
   else
   {
      /* year is not a leap-year */
      daysInYear = 365;
   }

   while (remDays >= daysInYear)
   {
      year++;
      remDays -= daysInYear;
      if ((year % 4 == 0) && ((year % 100 != 0) || (year % 400 == 0)))
      {
         /* year is a leap-year */
         daysInYear = 366;
      }
      else
      {
         /* year is not a leap-year */
         daysInYear = 365;
      }
   }

   month = SO_CM_START_MONTH;

   (Void) soCmGetDaysInMonth(&daysInMonth, month, year);

   while (remDays >= daysInMonth)
   {
      remDays -= daysInMonth;
      month++;
      (Void) soCmGetDaysInMonth(&daysInMonth, month, year);
   }

   dt->year  = (U8)(year - 1900);
   dt->month = month;
   dt->day   = remDays + 1;

   dt->hour    = remSeconds/SO_CM_SEC_IN_HOUR;
   remSeconds %= SO_CM_SEC_IN_HOUR;
   dt->min     = remSeconds/SO_CM_SEC_IN_MIN;
   remSeconds %= SO_CM_SEC_IN_MIN;
   dt->sec     = remSeconds;
   dt->tenths  = 0;

   RETVALUE(ROK);
} /* end of soCmGetDateFromSec */

/*
*
*       Fun:   soCmGetDuration
*
*       Desc:  This function calculates the elapsed time (duration)
*              from the given Start and End dates.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmGetDuration
(
DateTime *tStart,       /* "start" date             */
DateTime *tEnd,         /* "end" date               */
Duration *duration      /* duration to be outputed  */
)
#else
PUBLIC S16 soCmGetDuration(tStart, tEnd, duration)
DateTime *tStart;       /* "start" date             */
DateTime *tEnd;         /* "end" date               */
Duration *duration;     /* duration to be outputed */
#endif
{
   U32         startSeconds;    /* Start Time in seconds       */
   U32         seconds;         /* number of seconds           */
   U32         remSeconds;      /* number of seconds remaining */

   TRC2(soCmGetDuration);

   soCmGetSecFromDate(tEnd, &seconds);
   soCmGetSecFromDate(tStart, &startSeconds);

   seconds -= startSeconds;
   if (seconds<0)
   {
      RETVALUE(RFAILED);
   }

   duration->days     = seconds / SO_CM_SEC_IN_DAY;
   remSeconds         = seconds % SO_CM_SEC_IN_DAY;

   duration->hours    = remSeconds/SO_CM_SEC_IN_HOUR;
   remSeconds        %= SO_CM_SEC_IN_HOUR;

   duration->mins     = remSeconds/SO_CM_SEC_IN_MIN;
   remSeconds        %= SO_CM_SEC_IN_MIN;
   duration->secs     = remSeconds;

   duration->tenths  = 0;

   RETVALUE(ROK);
} /* end of soCmGetDuration */


/*
*
*       Fun:   soCmGetSecFromDate
*
*       Desc:  This function converts a date and time to seconds since
*              Jan 1, 2000.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmGetSecFromDate
(
DateTime *dt,     /* date to be converted */
U32 *seconds      /* seconds to be output */
)
#else
PUBLIC S16 soCmGetSecFromDate(dt, seconds)
DateTime *dt;     /* date to be converted */
U32 *seconds;     /* seconds to be output */
#endif
{
   U16 year;         /* year counter      */
   U8  month;        /* month counter     */
   U16 daysInYear;   /* no. days in year  */
   U8  daysInMonth;  /* no. days in month */

   TRC2(soCmGetSecFromDate);

   *seconds = 0;
   year     = SO_CM_START_YEAR;

   while (year < (U16)(1900 + dt->year))
   {
      if ((year % 4 == 0) && ((year % 100 != 0) || (year % 400 == 0)))
      {
         /* year is a leap-year */
         daysInYear = 366;
      }
      else
      {
         /* year is not a leap-year */
         daysInYear = 365;
      }
      year++;
      *seconds += daysInYear * SO_CM_SEC_IN_DAY;
   }

   month = SO_CM_START_MONTH;

   while (month < dt->month )
   {
      (Void) soCmGetDaysInMonth(&daysInMonth, month, (U16)(1900 + dt->year));
      month++;
      *seconds += daysInMonth * SO_CM_SEC_IN_DAY;
   }

   *seconds += (dt->day - 1) * SO_CM_SEC_IN_DAY;
   *seconds += dt->hour * SO_CM_SEC_IN_HOUR;
   *seconds += dt->min * SO_CM_SEC_IN_MIN;
   *seconds += dt->sec;

   RETVALUE(ROK);
} /* end of soCmGetSecFromDate */

/*
*
*       Fun:   soCmPackDate
*
*       Desc:  This function packs the date and time supplied in dt
*              into the SoSipDate structure supplied.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmPackDate
(
SoSipDate   *sipDate,   /* SIP Date structure into which to pack date */
DateTime    *dt         /* Date-time structure to pack into sipDate   */
)
#else
PUBLIC S16 soCmPackDate(sipDate, dt)
SoSipDate   *sipDate;   /* SIP Date structure into which to pack date */
DateTime    *dt;        /* Date-time structure to pack into sipDate   */
#endif
{
   U32      seconds;      /* Seconds since Jan 1, 2000 */
   U32      days;         /* Days since Jan 1, 2000    */
   S16      ret;          /* Function return values    */

   TRC2(soCmPackDate);

   /* Set presence indicator */
   sipDate->pres.pres = PRSNT_NODEF;

   /* Must correct hour for GMT offset */
   ret = soCmGetSecFromDate(dt, &seconds);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   seconds -= soCb.reCfg.GMToffset * SO_CM_SEC_IN_OFFSET_UNIT;
   days     = seconds/SO_CM_SEC_IN_DAY;

   ret = soCmGetDateFromSec(dt, seconds);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* Set fields in sipDate */
   SO_FILL_TKNU16(&sipDate->day, (U16) dt->day);
   SO_FILL_TKNU8(&sipDate->month, dt->month);
   SO_FILL_TKNU8(&sipDate->wkDay,
                (U8)((days + SO_CM_START_WKDAY) % SO_CM_DAYS_IN_WEEK));
   if (sipDate->wkDay.val == 0)
   {
      sipDate->wkDay.val = SO_CM_DAYS_IN_WEEK;
   }

   /* Date-time gives time since Jan 1, 1900 - must add 1900 to year */
   SO_FILL_TKNU16(&sipDate->year, 1900 + (U16) dt->year);

   SO_FILL_TKNU16(&sipDate->hr, (U16) dt->hour);
   SO_FILL_TKNU16(&sipDate->mn, (U16) dt->min);
   SO_FILL_TKNU16(&sipDate->sec, (U16) dt->sec);

   RETVALUE(ROK);
} /* end of soCmPackDate */

/*
*
*       Fun:   soCmCreateHdrChoice
*
*       Desc:  This function creates a header choice in the
*              event structure of the type specified in choiceType.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmCreateHdrChoice
(
SoEvnt *evnt,           /* Event structure containing choice          */
U8     **header,        /* Pointer to header structure to be returned */
U16    choiceType       /* Type of choice sought                      */
)
#else
PUBLIC S16 soCmCreateHdrChoice(evnt, header, choiceType)
SoEvnt *evnt;           /* Event structure containing choice          */
U8     **header;        /* Pointer to header structure to be returned */
U16    choiceType;      /* Type of choice sought                      */
#endif
{
   U16              numCompVal;   /* Actual integer value of numComp         */
   SoHeaderSeq      *hdrSeq;      /* Header sequence where hdr to be created */
   SoHeader         *newHeader;   /* New header to be added                  */

   TRC2(soCmCreateHdrChoice);

   /* so016.201: - Null pointer check */
   if (evnt == NULLP)
      RETVALUE(RFAILED);

   if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
   {
      hdrSeq = &evnt->t.request.request;
   }
   else
   {
      hdrSeq = &evnt->t.response.response;
   }

   if (soCmGrowList((Void ***)&hdrSeq->header,
                       sizeof(SoHeader), &hdrSeq->numComp, evnt) != ROK)
   {
      RETVALUE(RFAILED);
   }

   numCompVal = hdrSeq->numComp.val;

   newHeader = hdrSeq->header[numCompVal-1];
   SO_FILL_TKNU8(&newHeader->headerType, choiceType);
   /* All headers at same address */
   (*header) = (U8 *)&hdrSeq->header[numCompVal-1]->t.accept;

   SO_FILL_TKNU8((TknU8 *)*header, PRSNT_NODEF);

   RETVALUE(ROK);

}/* end of soCmCreateHdrChoice*/

/*
*
*       Fun:   soCmRemoveHdrChoice
*
*       Desc:  This function removes a header choice in the
*              event structure at the index specified.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmRemoveHdrChoice
(
SoEvnt *evnt,           /* Event structure containing choice          */
U16    idx,             /* Index of item to remove                    */
U16    choiceType       /* Type of choice sought                      */
)
#else
PUBLIC S16 soCmRemoveHdrChoice(evnt, idx, choiceType)
SoEvnt *evnt;           /* Event structure containing choice          */
U16    idx;             /* Index of item to remove                    */
U16    choiceType;      /* Type of choice sought                      */
#endif
{
   U16              numCompVal;  /* Actual integer value of numComp    */
   U16              i;           /* Loop counter                       */
   SoHeader         *delHeader;  /* New header to be deleted           */
   SoHeaderSeq      *hdrSeq;     /* Header sequence where hdr to be deleted */
   S16              ret;         /* Return Value */

   TRC2(soCmRemoveHdrChoice);

   /* so016.201: - Null pointer check */
   if (evnt == NULLP)
      RETVALUE(RFAILED);

   if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
   {
      hdrSeq = &evnt->t.request.request;
   }
   else
   {
      hdrSeq = &evnt->t.response.response;
   }

   numCompVal = SO_GET_NUM_COMP(&hdrSeq->numComp);

   delHeader  = hdrSeq->header[idx];

   if (SO_CMP_TKN_LIT(&delHeader->headerType, choiceType) != TRUE)
   {
      SODBGP_SO(SO_DBGMASK_NS, (soCb.init.prntBuf,
              "Choice types do not match.\n"));
      RETVALUE(RFAILED);
   }

   /* Move entries in header sequence */
   for (i = idx; i < (numCompVal - 1); i++)
   {
      hdrSeq->header[i] = hdrSeq->header[i+1];
   }

   /* Shrink list */
   ret = soCmShrinkList((Void ***)&hdrSeq->header, sizeof(SoHeader),
                     &hdrSeq->numComp, evnt);
   if (ret != ROK)
     RETVALUE(RFAILED);

   RETVALUE(ROK);

}/* end of soCmRemoveHdrChoice*/


/*
*
*       Fun:   soCmFindHdrDup
*
*       Desc:  This function loops through all headers to see if there is a 
*              duplicate header found.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmFindHdrDup
(
SoEvnt *evnt,           /* Event structure containing choice */
U16    choiceType,      /* Type of choice sought */
Bool   *dupPrsnt        /* TRUE if duplicates are found */
)
#else
PUBLIC S16 soCmFindHdrDup(evnt, choiceType, dupPrsnt)
SoEvnt *evnt;           /* Event structure containing choice */
U16    choiceType;      /* Type of choice sought */
Bool   *dupPrsnt;       /* TRUE if duplicates are found */
#endif
{
   U16         i;             /* Counter for requestHeaderCh */
   SoHeader    *hdr;          /* Header to check */
   SoHeaderSeq *hdrSeq;       /* Header sequence to search */
   Bool        choiceFound;   /* choice found */

   TRC2(soCmFindHdrDup);

   /* Initialisations */
   choiceFound = FALSE;
   *dupPrsnt = FALSE;

   /* so016.201: - Null pointer check */
   if (evnt == NULLP)
      RETVALUE(RFAILED);


   if (SO_CMP_TKN_LIT(&evnt->sipMessageType,
      SO_SIPMESSAGE_REQUEST) == TRUE)
   {
      hdrSeq = &evnt->t.request.request;
   }
   else
   {
      hdrSeq = &evnt->t.response.response;
   }

   /* Find requestHeaderCh element with required header field */
   for (i = 0; i < SO_GET_NUM_COMP(&hdrSeq->numComp); i++)
   {
      hdr = hdrSeq->header[i];

      if (hdr->headerType.val == choiceType)
      {
         if (choiceFound == TRUE)
         {
            *dupPrsnt = TRUE;
            RETVALUE(ROK);
         }
         choiceFound = TRUE;
      }
   }

   RETVALUE(ROK);
} /* end of soCmFindHdrDup */


/*
*
*       Fun:   soCmFindHdrStrtChIndex
*
*       Desc:  This function finds the first header set choice in the
*              event structure of the type specified in choiceType , 
*              starting from the given start index in strtIdx, and
*              returns both the index and the header choice. 
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_cm.c
*
*/
#ifdef ANSI
PUBLIC S16 soCmFindHdrStrtChIndex
(
SoEvnt *evnt,           /* Event structure containing choice          */
U8     **choice,        /* Pointer to choice structure to be returned */
U16    strtIdx,         /* starting index                             */
U16    *idx,            /* Index to return                            */
U16    choiceType       /* Type of choice sought                      */
)
#else
PUBLIC S16 soCmFindHdrStrtChIndex(evnt, choice, strtIdx, idx, choiceType)
SoEvnt *evnt;           /* Event structure containing choice          */
U8     **choice;        /* Pointer to choice structure to be returned */
U16    strtIdx;         /* starting index                             */
U16    *idx;            /* Index to return                            */
U16    choiceType;      /* Type of choice sought                      */
#endif
{
   U16          i;      /* Counter for requestHeaderCh                     */
   Bool         choiceFound;  /* Flag to check if cSeq exists in event 
                               * structure */
   SoHeaderSeq  *hdrSeq; /* Header sequence to search */
   SoHeader     *hdr;    /* Header to check */

   TRC2(soCmFindHdrStrtChIndex);

   /* so016.201: - Null pointer check */
   if (evnt == NULLP)
      RETVALUE(RFAILED);
   
   if (SO_CMP_TKN_LIT(&evnt->sipMessageType, SO_SIPMESSAGE_REQUEST) == TRUE)
   {
      hdrSeq = &evnt->t.request.request;
   }
   else
   {
      hdrSeq = &evnt->t.response.response;
   }

   choiceFound = FALSE;

   /* Find requestHeaderCh element with required header field */
   for (i = strtIdx; i < SO_GET_NUM_COMP(&hdrSeq->numComp); i++)
   {
      hdr = hdrSeq->header[i];
      if (hdr->headerType.val == choiceType)
      {
         choiceFound = TRUE;
         /* All headers at same address */
         (*choice) = (U8 *)&hdr->t.accept;
         *idx = i;
         break;
      }
   }

   /* Return error if header not found */
   if (choiceFound == FALSE)
   {
      *choice = (U8 *) NULLP;
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of soCmFindHdrStrtChIndex */


/*
*
*       Fun:   soCmFindHdrChoice
*
*       Desc:  This function finds the first header set choice in the
*              event structure of the type specified in choiceType.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Just call soCmFindHdrChIndex. Duplicate func.
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmFindHdrChoice
(
SoEvnt *evnt,           /* Event structure containing choice            */
U8     **choice,        /* Pointer to choice structure to be returned   */
U16    choiceType       /* Type of choice sought                        */
)
#else
PUBLIC S16 soCmFindHdrChoice(evnt, choice, choiceType)
SoEvnt *evnt;           /* Event structure containing choice            */
U8     **choice;        /* Pointer to choice structure to be returned   */
U16    choiceType;      /* Type of choice sought                        */
#endif
{
   U16    hdrIdx;       /* Header index */ 
   S16    ret;          /* return value */

   TRC2(soCmFindHdrChoice);

   /* so016.201: - Null pointer check */
   if (evnt == NULLP)
      RETVALUE(RFAILED);

   ret = soCmFindHdrChIndex(evnt, choice, &hdrIdx, choiceType);
   RETVALUE(ret);

} /* end of soCmFindHdrChoice */

/*
*
*       Fun:   soCmFindHdrChIndex
*
*       Desc:  This function finds the first header set choice in the
*              event structure of the type specified in choiceType and
*              returns both the index and the header choice.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmFindHdrChIndex
(
SoEvnt *evnt,           /* Event structure containing choice          */
U8     **choice,        /* Pointer to choice structure to be returned */
U16    *idx,            /* Index to return                            */
U16    choiceType       /* Type of choice sought                      */
)
#else
PUBLIC S16 soCmFindHdrChIndex(evnt, choice, idx, choiceType)
SoEvnt *evnt;           /* Event structure containing choice          */
U8     **choice;        /* Pointer to choice structure to be returned */
U16    *idx;            /* Index to return                            */
U16    choiceType;      /* Type of choice sought                      */
#endif
{
   U16    i;            /* Counter for requestHeaderCh                     */
   Bool   choiceFound;  /* Flag to check if cSeq exists in event structure */
   SoHeaderSeq  *hdrSeq; /* Header sequence to search */
   SoHeader     *hdr;    /* Header to check */

   TRC2(soCmFindHdrChIndex);

   /* so016.201: - Null pointer check */
   if (evnt == NULLP)
      RETVALUE(RFAILED);

   if (SO_CMP_TKN_LIT(&evnt->sipMessageType, SO_SIPMESSAGE_REQUEST) == TRUE)
   {
      hdrSeq = &evnt->t.request.request;
   }
   else
   {
      hdrSeq = &evnt->t.response.response;
   }

   choiceFound = FALSE;
   /* Find requestHeaderCh element with required header field */
   for (i = 0; i < SO_GET_NUM_COMP(&hdrSeq->numComp); i++)
   {
      hdr = hdrSeq->header[i];
      if (hdr->headerType.val == choiceType)
      {
         choiceFound = TRUE;
         /* All headers at same address */
         (*choice) = (U8 *)&hdr->t.accept;
         *idx = i;
         /* Find the first item, such as Via or Contact and return */
         break;
      }
   }

   /* Return error if header not found */
   if (choiceFound == FALSE)
   {
      *choice = (U8 *) NULLP;
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of soCmFindHdrChIndex */

/*
*
*       Fun:   soCmGetCurTime
*
*       Desc:  This function finds the time in 100ns intervals since
*              15thOct 1582.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmGetCurTime
(
U8         *curTime       /* Pointer to time structure */
)
#else
PUBLIC S16 soCmGetCurTime(curTime)
U8         *curTime;      /* Pointer to time structure */
#endif
{
   DateTime dt;           /* Date-time          */
   U32      secInYear;    /* seconds in year    */
   U32      secInMonth;   /* seconds in month   */
   U32      secInDay;     /* seconds in day     */
   U32      secInHour;    /* seconds in hour    */
   U32      secSince1970; /* seconds since 1970 */
   U32      i1;           /* temp variable      */
   U32      i2;           /* temp variable      */
   U32      a1;           /* temp variable      */
   U32      a2;           /* temp variable      */
   U32      a3;           /* temp variable      */
   U32      a4;           /* temp variable      */
   U32      b1;           /* temp variable      */
   U32      b2;           /* temp variable      */
   U32      b3;           /* temp variable      */
   U32      b4;           /* temp variable      */
   U32      c1;           /* temp variable      */
   U32      c2;           /* temp variable      */
   U32      c3;           /* temp variable      */
   U32      c4;           /* temp variable      */
   U32      carry;        /* carry value        */

   TRC2(soCmGetCurTime);

   secInYear  = SO_CM_SEC_IN_YEAR;
   secInMonth = SO_CM_SEC_IN_MONTH;
   secInDay   = SO_CM_SEC_IN_DAY;
   secInHour  = SO_CM_SEC_IN_HOUR;

   /* SGetDateTime give time since Jan 1, 1900 */

   (Void) SGetDateTime(&dt);

   /* convert to  time since Jan1, 1970 */
   secSince1970 = (((dt.year - 70) * secInYear) + (dt.month * secInMonth) +
                   (dt.day * secInDay) + (dt.hour *secInHour) + (dt.min *60) +
                     dt.sec);


   secSince1970 = secSince1970 - 24*secInDay;

   /* need to give 100ns intervals. So get the 100ns intervals from sec */

   i1 = (secSince1970 & (U32)0xffffff00) >> 8;
   i2 = (secSince1970 & (U32)0x000000ff) << 24;

   /*add 100ms counts to i2 also w/o losing resolution*/
   i2 = i2 + ((U32)dt.tenths << 20);


   /* need time since Gregorian reform to English calender. Offset from
   * Jan 1, 1970 till Oct 15, 1582 is 0x01B21 DD21 13814000
   * need to do 64 bit addition */

   b1 = 0x4000;
   b2 = 0x1381;
   b3 = 0x1DD2;
   b4 = 0x01B2;

   a1 = GetLoWord(i2);
   a2 = GetHiWord(i2);
   a3 = GetLoWord(i1);
   a4 = GetHiWord(i1);

   c1    =(a1 + b1);
   carry = ((c1 >> 16) & 0x01L);
   c1    = c1 & 0x0000ffff;
   c2    = (a2 + b2) + carry;
   carry = ((c2 >> 16) & 0x01L);
   c2    = c2 & 0x0000ffff;
   c3    = (a3 + b3) + carry;
   carry = ((c3 >> 16) & 0x01L);
   c3    = c3 & 0x0000ffff;
   c4    = (a4 + b4) + carry;
   c4    = c4 & 0x0000ffff;

   curTime[0] = (U8)(GetHiByte(c4));
   curTime[1] = (U8)(GetLoByte(c4));

   curTime[2] = (U8)(GetHiByte(c3));
   curTime[3] = (U8)(GetLoByte(c3));

   curTime[4] = (U8)(GetHiByte(c2));
   curTime[5] = (U8)(GetLoByte(c2));

   curTime[6] = (U8)(GetHiByte(c1));
   curTime[7] = (U8)(GetLoByte(c1));

   RETVALUE(ROK);
} /* end of soCmGetCurTime */

/*
*
*       Fun:   soCmGenHash
*
*       Desc:  Generates an MD5 hash of a given string.
*
*       Ret:   ROK      - success
*              RFAILED  - failed
*              hash - returns the computed MD5 hash
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmGenHash
(
U8    *input,              /* Input Data              */
U32   len,                 /* length                  */
U8    *hash                /* filled in with MAC hash */
)
#else
PUBLIC S16 soCmGenHash(input, len, hash)
U8    *input;              /* Input Data              */
U32    len;                /* length                  */
U8    *hash;               /* filled in with MAC hash */
#endif
{
   /* local parameters */
   CmMD5Ctx context;        /* MD5 context */

   TRC2(soCmGenHash);

   cmMD5Init(&context);
   cmMD5Update(&context, input, len);
   cmMD5Final((U8 *)hash, &context);

   RETVALUE(ROK);

} /* end of soCmGenHash */



/*
*
*       Fun:   soCmCompareHost
*
*       Desc:  Compares two SoHost structures.
*
*       Ret:   ROK      - SoHost structures equal
*              RFAILED  - SoHost structures not equal
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmCompareHost
(
SoHost  *h1,              /* First SoHost structure   */
SoHost  *h2               /* Second SoHost structure  */
)
#else
PUBLIC S16 soCmCompareHost(h1, h2)
SoHost  *h1;              /* First SoHost structure   */
SoHost  *h2;              /* Second SoHost structure  */
#endif
{
   TRC2(soCmCompareHost);

   if (SO_CMP_TKN_LIT(&h1->hostType, SO_HOST_IPV4ADDRESS) == TRUE)
   {
      /* Must be IPV4 */
      if (SO_CMP_TKN_LIT(&h2->hostType, SO_HOST_IPV4ADDRESS) != TRUE)
      {
         RETVALUE(RFAILED);
      }
      if (SO_CMP_IPV4(&h1->t.ipv4Address, &h2->t.ipv4Address) != TRUE)
      {
         RETVALUE(RFAILED);
      }
      RETVALUE(ROK);
   }
   if (SO_CMP_TKN_LIT(&h1->hostType, SO_HOST_IPV6REFERENCE) == TRUE)
   {
      if (SO_CMP_TKN_LIT(&h2->hostType, SO_HOST_IPV6REFERENCE) != TRUE)
      {
         RETVALUE(RFAILED);
      }
      if (SO_CMP_TKNSTR(&h1->t.ipv6Reference, &h2->t.ipv6Reference) != TRUE)
      {
         RETVALUE(RFAILED);
      }
      RETVALUE(ROK);
   }
   if (SO_CMP_TKN_LIT (&h1->hostType, SO_HOST_HOSTNAME) == TRUE)
   {
      if (SO_CMP_TKN_LIT(&h2->hostType, SO_HOST_HOSTNAME) != TRUE)
      {
         RETVALUE(RFAILED);
      }
      if (SO_CMP_TKNSTR(&h1->t.hostName, &h2->t.hostName) != TRUE)
      {
         RETVALUE(RFAILED);
      }
      RETVALUE(ROK);
   }

   RETVALUE(RFAILED);

} /* soCmCompareHost */


/*
*
*       Fun:   soCmCompareHostPort
*
*       Desc:  Compares two SoHostPort structures.
*
*       Ret:   ROK      - SoHostPort structures equal
*              RFAILED  - SoHostPort structures not equal
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmCompareHostPort
(
SoHostPort  *hp1,              /* First SoHostPort structure   */
SoHostPort  *hp2               /* Second SoHostPort structure  */
)
#else
PUBLIC S16 soCmCompareHostPort(hp1, hp2)
SoHostPort  *hp1;              /* First SoHostPort structure   */
SoHostPort  *hp2;              /* Second SoHostPort structure  */
#endif
{
   TRC2(soCmCompareHostPort);

   if (soCmCompareHost(&hp1->host, &hp2->host) == ROK)
   {
       if (SO_CMP_TKN_LIT(&hp1->host.hostType, SO_HOST_IPV4ADDRESS) == TRUE)
       {
          if (SO_CMP_TKN(&hp1->port, &hp2->port) != TRUE)
          {
             /* so006.201: Check for the case when port is absent in 
              * both the fields */
             if (((SO_CMP_TKN_LIT(&hp1->port, SO_PORT_DEFAULT)) &&
                  (hp2->port.pres == NOTPRSNT)) ||
                 ((SO_CMP_TKN_LIT(&hp2->port, SO_PORT_DEFAULT)) &&
                  (hp1->port.pres == NOTPRSNT)) ||
                 ((hp1->port.pres == NOTPRSNT) && (hp2->port.pres == NOTPRSNT)))
             {
                RETVALUE(ROK);
             }
             else
             {
  /* Comment Prashant: flag in wrong place */
/*#ifdef SO_TLS*/
                /* so035.201: Default port in case of TLS is 5061 */
                /* Checking for TLS default port as well */
                if (((SO_CMP_TKN_LIT(&hp1->port, SO_PORT_TLS_DEFAULT)) &&
                     (hp2->port.pres == NOTPRSNT)) ||
                    ((SO_CMP_TKN_LIT(&hp2->port, SO_PORT_TLS_DEFAULT)) &&
                     (hp1->port.pres == NOTPRSNT)) ||
                    ((hp1->port.pres == NOTPRSNT) &&
                     (hp2->port.pres == NOTPRSNT)))
                {
                   RETVALUE(ROK);
                }
                else
/*#endif*/
                {
                   RETVALUE(RFAILED);
                }
             }
          }
          else
          {
             RETVALUE(ROK);
          }
       }
       /* else must be IPV6 */
       RETVALUE(ROK);
   }

   RETVALUE(RFAILED);
} /* end of soCmCompareHostPort */




/*
*
*       Fun:   soCmCmpHostPortType
*
*       Desc:  Compares two SoHostPort structures.
*
*       Ret:   ROK      - SoHostPort structures equal
*              RFAILED  - SoHostPort structures not equal
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmCmpHostPortType
(
SoHostPortType  *hpt1,      /* First SoHostPortType structure   */
SoHostPortType  *hpt2       /* Second SoHostPortType structure  */
)
#else
PUBLIC S16 soCmCmpHostPortType(hpt1, hpt2)
SoHostPortType  *hpt1;      /* First SoHostPortType structure   */
SoHostPortType  *hpt2;      /* Second SoHostPortType structure  */
#endif
{
   TRC2(soCmCmpHostPortType);

   if (hpt1->type.val != hpt2->type.val)
        RETVALUE (RFAILED);

   if (hpt1->type.val == SO_SENTBY_HOSTPORT)
      RETVALUE (soCmCompareHostPort (&hpt1->t.hostPort, &hpt2->t.hostPort));

   else
      RETVALUE (soUtlCmpTknStrOSXL (&hpt1->t.host, &hpt2->t.host, FALSE));
} /* end of soCmCmpHostPortType */











/*
*
*       Fun:   soCmResizeEvntList
*
*       Desc:  Resizes a dynamic list in event structure.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: List must be a triple pointer.
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmResizeEvntList
(
PTR      *list,      /* List to be resized         */
TknU16   *numComp,   /* Number of elements in list */
U16      newSize,    /* New number of elements     */
SoEvnt   *evnt       /* Event structure            */
)
#else
PUBLIC S16 soCmResizeEvntList(list, numComp, newSize, evnt)
PTR      *list;      /* List to be resized         */
TknU16   *numComp;   /* Number of elements in list */
U16      newSize;    /* New number of elements     */
SoEvnt   *evnt;      /* Event structure            */
#endif
{
   PTR newList;     /* New pointer list to be allocated   */
   U16 numCompVal;  /* Value of numComp                   */
   U16 granSize;    /* Granular size of pointer array     */

   TRC2(soCmResizeEvntList);

   numCompVal = SO_GET_NUM_COMP(numComp);

   if (newSize > 0)
   {
      /* compute current list size */
      if (numCompVal > 0)
      {
         granSize  = (U16)((numCompVal)/SO_DYNLIST_GRANULARITY);
         if (granSize * SO_DYNLIST_GRANULARITY < numCompVal)
         {
            granSize++;
         }

         granSize *= SO_DYNLIST_GRANULARITY;
      }
      else
      {
         granSize = 0;
      }

      /* Allocate a new block? */
      if (newSize > granSize)
      {
         granSize  = (U16)((newSize)/SO_DYNLIST_GRANULARITY);
         if (granSize * SO_DYNLIST_GRANULARITY < newSize)
         {
            granSize++;
         }
         granSize *= SO_DYNLIST_GRANULARITY;

         if (cmGetMem(&evnt->memCp, granSize * sizeof(PTR),
                      (Ptr *)&newList) != ROK)
           RETVALUE(RFAILED);

         (Void) cmMemset((U8 *)newList, 0,
                         (PTR)granSize * sizeof(PTR));
      }
      else
      {
          newList = *list;
      }

      if (newSize < numCompVal)
      {
         (Void) cmMemset((U8 *)(newList + newSize * sizeof(PTR)), 0,
                         (PTR)(granSize - newSize) * sizeof(PTR));

         numCompVal = newSize;
      }
      if ((numCompVal > 0) && (newList != *list))
      {
         cmMemcpy((U8 *)newList, (U8 *) *list, numCompVal * sizeof(PTR));
      }
   }
   else
   {
      newList = (PTR)NULLP;
   }

   /* Can't free memory from event block until whole event is freed */

   *list = newList;
   SO_FILL_NUM_COMP(numComp, newSize);

   RETVALUE(ROK);
} /* end of soCmResizeEvntList */


/*
*
*       Fun:   soCmResizeList
*
*       Desc:  Resizes list in event structure.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: List must be a triple pointer.
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmResizeList
(
PTR      *list,      /* List to be resized         */
U16      *numComp,   /* Number of elements in list */
U16      newSize     /* New number of elements     */
)
#else
PUBLIC S16 soCmResizeList(list, numComp, newSize)
PTR      *list;      /* List to be resized         */
U16      *numComp;   /* Number of elements in list */
U16      newSize;    /* New number of elements     */
#endif
{
   PTR newList;      /* Possible new list to allocate                 */
   U16 numCompVal;   /* Integer numComp value                         */
   U16 curGranSize;  /* Current array size in granular units          */
   U16 newGranSize;  /* New array size in granular units              */
   U16 granSize;     /* Granular array size (X * granular size)       */

   TRC2(soCmResizeList)

   numCompVal = *numComp;

   if (newSize > 0)
   {

      /* compute current list size in granular units */
      if (numCompVal > 0)
      {
         curGranSize = (U16)((numCompVal)/SO_DYNLIST_GRANULARITY);
         if ((U16)((numCompVal)%SO_DYNLIST_GRANULARITY) != 0)
            curGranSize ++;
      }
      else
      {
         curGranSize = 0;
      }

      newGranSize = (U16)(newSize/SO_DYNLIST_GRANULARITY);
      if ((U16)(newSize%SO_DYNLIST_GRANULARITY) != 0)
         newGranSize ++;

      granSize  = (U16)((newSize)/SO_DYNLIST_GRANULARITY);
      if ((U16)((newSize)%SO_DYNLIST_GRANULARITY) != 0)
         granSize ++;

      granSize *= SO_DYNLIST_GRANULARITY;

      /* Allocate a new block? */
      if (newGranSize != curGranSize)
      {
         SOALLOC(&newList, granSize * sizeof(PTR));
         if (newList == NULLP)
           RETVALUE(RFAILED);
      }
      else
      {
          newList = *list;
      }

      if (newSize < numCompVal)
      {
         (Void) cmMemset((U8 *)(newList + newSize * sizeof(PTR)), 0,
                         (PTR)(granSize - newSize) * sizeof(PTR));

         numCompVal = newSize;
      }
      if ((numCompVal > 0) && (newList != *list))
      {
         cmMemcpy((U8 *)newList, (U8 *) *list, numCompVal * sizeof(PTR));
      }
   }
   else
   {
      newList = (PTR)NULLP;
   }

   /* Free old list if a new one was allocated */
   if ((*list != (PTR)NULLP) && (*list != newList))
   {
      SOFREE(*list, *numComp * sizeof(PTR));
   }

   *list    = newList;
   *numComp = newSize;

   RETVALUE(ROK);

} /* end of soCmResizeList */


/*
*
*       Fun:   soCmFillHex
*
*       Desc:  Fills a string with the hex representation of a binary array.
*
*       Ret:   ROK
*              RFAILED
*
*       Notes:
*            1. The string must have enough space allocated (2x length).
*            2. Returns ASCIIZ string.
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmFillHex
(
Txt   *str,          /* Destination string         */
U8    *data,         /* source data                */
U16   length         /* length of data             */
)
#else
PUBLIC S16 soCmFillHex(str, data, length)
Txt   *str;          /* Destination string         */
U8    *data;         /* source data                */
U16   length;        /* length of data             */
#endif
{
   U16      i;            /* Counter                    */
   Txt      tmpStr[4];    /* Temporary string */

   TRC2(soCmFillHex);

   for (i = 0; i < length; ++i)
   {
      sprintf(tmpStr,"%02X", data[i]);
      str[i * 2]     = tmpStr[0];
      str[(i * 2) + 1] = tmpStr[1];
   }

   RETVALUE(ROK);
} /* end of soCmFillHex */


/*
*
*       Fun:   soCmCmpDomain
*
*       Desc:  This function compares a domain name in a host name to the
*              entity's domain name.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmCmpDomain
(
TknStrOSXL  *hostName,      /* Host name to check */
Txt         *localDomain    /* Local domain name  */
)
#else
PUBLIC S16 soCmCmpDomain(hostName, localDomain)
TknStrOSXL  *hostName;      /* Host name to check */
Txt         *localDomain;   /* Local domain name  */
#endif
{
   U16 domNameLen;    /* Length of domain name   */
   U16 i;             /* Counter                 */

   TRC2(soCmCmpDomain);

   if (hostName->pres == NOTPRSNT)
   {
      SODBGP_SO(SO_DBGMASK_NS,
                (soCb.init.prntBuf, "Host name not present"));
      RETVALUE(RFAILED);
   }

   domNameLen = cmStrlen((U8 *) localDomain);

   if (hostName->len < domNameLen)
   {
      /* Host name shorter than domain length */
      RETVALUE(RFAILED);
   }

   i = 1;

   /* Check one character at a time */
   while (i++ < domNameLen)
   {
      if (SO_LOWERCASE(hostName->val[hostName->len - i]) !=
          SO_LOWERCASE(localDomain[domNameLen - i]))
      {
         /* Domain name is not the same */
         RETVALUE(RFAILED);
      }
   }

   if (hostName->len == domNameLen)
   {
      /* The host name contains only the domain and the two match*/
      RETVALUE(ROK);
   }

   /* Check that next charater is a "." */
   if (hostName->val[hostName->len - domNameLen - 1] != '.')
   {
      /* Domain name is not complete -> different from what is in host name */
      RETVALUE(RFAILED);
   }

   /* Host name contains domain name */
   RETVALUE(ROK);
} /* end of soCmCmpDomain */



/*
*
*       Fun:   soCmFilterUri
*
*       Desc:  This function normalizes an arbitrary string for
*              URI comparison.
*
*       Ret:   ROK/RFAILED
*
*       Notes: dst must provide enough space
*              (call this function with dst == NULLP to calculate length)
*              If phoneUser is true, the visual separators are removed
*              If caseInsensitive is true, all A-Z characters are converted
*              to lower case a-z
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmFilterUri
(
U8          *dst,            /* Pointer to key to be built */
U16         *dstLen,         /* Length of resulting string */
U8          *src,            /* Pointer to addr-spec       */
U16         srcLen,          /* Length of src              */
Bool        phoneUser,       /* String is a phone user     */
Bool        caseInsensitive  /* Convert to lower case      */
)
#else
PUBLIC S16 soCmFilterUri(dst, dstLen, src, srcLen, phoneUser, caseInsensitive)
U8          *dst;            /* Pointer to key to be built */
U16         *dstLen;         /* Length of resulting string */
U8          *src;            /* Pointer to addr-spec       */
U16         srcLen;          /* Length of src              */
Bool        phoneUser;       /* String is a phone user     */
Bool        caseInsensitive; /* Convert to lower case      */
#endif
{
   U16            src_i;       /* Source index             */
   U16            dst_i;       /* Destination index        */
   U16            i;           /* Counter                  */
   U8             unesc_ch;    /* un-escaped character     */
   Bool           use_unesc;   /* use escaped version?     */
   Bool           copyData;    /* gerate output?           */
   Bool           validCh;     /* Is this character valid  */

   /* Reserved and unsafe characters in URI */

   PRIVATE U8    SO_URI_UNWISE_CHAR[]    = "{}|\\^[]`";
   PRIVATE U8    SO_URI_TEL_VISUAL_SEP[] = "-.()";
   /* so001.201: change length to 9 */
   PRIVATE U8    unwise_len = 9;
   PRIVATE U8    tel_visual_sep_len = 4;

   TRC2(soCmFilterUri);

   *dstLen = 0;
   dst_i   = 0;

   if (dst == (U8 *)NULLP)
   {
      copyData = FALSE;
   }
   else
   {
      copyData = TRUE;
   }

   /* Convert escaped character that are safe to normal representation
    * and convert string to lower case
    */
   for (src_i = 0; src_i < srcLen; ++src_i)
   {
      validCh = TRUE;
      if (src[src_i] == SO_URI_ESC_CHAR)
      {
         if (src_i + 2 < srcLen)
         {
            use_unesc = TRUE;

            unesc_ch   = SO_GET_HEX_NIBBLE(src[src_i + 1]);
            unesc_ch <<= 4;
            unesc_ch  += SO_GET_HEX_NIBBLE(src[src_i + 2]);

            for (i = 0; i < unwise_len; ++i)
            {
               if (unesc_ch == SO_URI_UNWISE_CHAR[i])
               {
                  use_unesc = FALSE;
                  break;
               }
            }

            /* Check if it is a visual separator */
            if (phoneUser == TRUE)
            {
               for (i = 0; i < tel_visual_sep_len; ++i)
               {
                  if (unesc_ch == SO_URI_TEL_VISUAL_SEP[i])
                  {
                     validCh = FALSE;
                     break;
                  }
               }
            }

            if (validCh == TRUE)
            {
               if (use_unesc == TRUE)
               {
                  if (caseInsensitive == TRUE)
                     unesc_ch = SO_LOWERCASE(unesc_ch);

                  if (copyData == TRUE)
                  {
                     dst[dst_i++] = unesc_ch;
                  }
                  else
                  {
                     dst_i++;
                  }
               }
               else /* copy lower-case escaped version */
               {
                  if (copyData == TRUE)
                  {
                     dst[dst_i++] = SO_LOWERCASE(src[src_i++]);
                     dst[dst_i++] = SO_LOWERCASE(src[src_i++]);
                     dst[dst_i++] = SO_LOWERCASE(src[src_i]);
                  }
                  else
                  {
                     dst_i += 3;
                  }
               }
               src_i += 2;
            }
         }
         else /* incorrect length */
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO061, ERRZERO, "soCmFilterUri failed");
#endif /* ERRCLASS & ERRCLS_DEBUG */
            RETVALUE(RFAILED);
         }
      }
      else /* not an escaped character - convert to lower case */
      {
         if (phoneUser == TRUE)
         {
            for (i = 0; i < tel_visual_sep_len; ++i)
            {
               if (src[src_i] == SO_URI_TEL_VISUAL_SEP[i])
               {
                  validCh = FALSE;
                  break;
               }
            }
         }

         if (validCh == TRUE)
         {
            if (copyData == TRUE)
            {
               if (caseInsensitive == TRUE)
               {
                  dst[dst_i++] = SO_LOWERCASE(src[src_i]);
               }
               else
               {
                  dst[dst_i++] = src[src_i];
               }
            }
            else
            {
               dst_i++;
            }
         }
      }
   }

   *dstLen = dst_i;

   RETVALUE(ROK);
} /* end of soCmFilterUri */

/*
*
*       Fun:   soCmNormAddr
*
*       Desc:  This function normalizes an addr-spec in text form for use
*              as part of the transaction key.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Set key = NULLP to calculate the key length before generation.
*              At the moment only the following tptParam's are supported:
*                 -transportParam
*                 -userParam
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmNormAddr 
(
U8          *key,        /* Pointer to key to be built */
SoAddrSpec  *addrSpec,   /* Pointer to addr-spec       */
U16         *retLen      /* Returned length            */
)
#else
PUBLIC S16 soCmNormAddr(key, addrSpec, retLen)
U8          *key;        /* Pointer to key to be built */
SoAddrSpec  *addrSpec;   /* Pointer to addr-spec       */
U16         *retLen;     /* Returned length            */
#endif
{
   SoHostPort        *hostPort;              /* local hostPort pointer      */
   TknStrOSXL        *tknStr;                /* local tokenStrOSXL ptr      */
   S16               ret;                    /* function return valuse      */
   U8                *s_dyn;                 /* temporary dynamic string    */
   U8                s_dynSize;              /* temp s_dyn size             */
   U8                temp[SO_IPV4_STRSIZE];

   U8                s_st[80];               /* temporary static string     */
   U16               keyLen;                 /* key length                  */
   U16               fltLen;                 /* Resulting filtered length   */
   U16               i;                      /* counter                     */
   U16               numCompVal;             /* number of components        */
   SoUrlParameters   *urlParameters;         /* ptr to SIP URL parameters   */
   SoTransportParam  *transportParam;        /* SIP URL transport parameter */
   SoUserParam       *userParam;             /* SIP URL user parameter      */
   Bool              paramValid;             /* is parameter valid?         */
   Bool              copyData;               /* make actual string?         */
   U8                udp_txt[]   = ";udp";   /* tptParam - udp              */
   U8                tcp_txt[]   = ";tcp";   /* tptParam - tcp              */
   U8                phone_txt[] = ";phone"; /* User parameter - phone      */
   U8                ip_txt[]    = ";ip";    /* User parameter - ip         */
   Bool              phoneUser;              /* This is a phone user        */


   TRC2(soCmNormAddr);

   keyLen  = 0;
   *retLen = 0;

   /* if key is NULL, just calculate the length */
   if (key == (U8 *)NULLP)
   {
      copyData = FALSE;
   }
   else
   {
      copyData = TRUE;
   }


   if ((SO_CMP_TKN_LIT(&addrSpec->addrSpecType, SO_ADDRSPEC_SIPURL) == TRUE)
       || (SO_CMP_TKN_LIT(&addrSpec->addrSpecType, SO_ADDRSPEC_SIPSURL) == TRUE)
#ifdef SO_INSTMSG
       ||(SO_CMP_TKN_LIT(&addrSpec->addrSpecType, SO_ADDRSPEC_IMURL) == TRUE) 
#endif /* SO_INSTMSG */
       )
   {
      /* Attempt to find hostPort from SipURL */
      SO_HOSTPORT_FROM_ADDRSPEC(hostPort, addrSpec);

      /* hostPort == NULL - SipURL NOT present */
      if (hostPort == (SoHostPort *)NULLP)
      {
         RETVALUE(RFAILED);
      }

      /* Retrieve possible transport/user parameters */
      transportParam = (SoTransportParam *)NULLP;
      userParam      = (SoUserParam *)NULLP;
      urlParameters  = &addrSpec->t.sipUrl.urlParameters;
      numCompVal     = SO_GET_NUM_COMP(&urlParameters->numComp);

      for (i = 0; i < numCompVal; ++i)
      {
         if (urlParameters->urlParameter[i] != (SoUrlParameter *)NULLP)
         {
            if (SO_CMP_TKN_LIT(
               &urlParameters->urlParameter[i]->urlParameterType,
               SO_URLPARAMETER_TRANSPORTPARAM) == TRUE)
            {
               transportParam = &urlParameters->urlParameter[i]->t.\
                  transportParam;
            }
            else if (SO_CMP_TKN_LIT(
               &urlParameters->urlParameter[i]->urlParameterType,
               SO_URLPARAMETER_USERPARAM) == TRUE)
            {
               userParam = &urlParameters->urlParameter[i]->t.\
                  userParam;
            }
         }
      }

      /* Copy User/Telephone-subscriber if available */
      SO_USER_FROM_SIPURL(tknStr, &addrSpec->t.sipUrl);

      phoneUser = FALSE;
      if (userParam != NULLP)
      {
         if (SO_CMP_TKN_LIT(&userParam->userParamType,
            SO_USERPARAM_PHONE))
            phoneUser = TRUE;
      }

      /* Username is present */
      if (tknStr != (TknStrOSXL *)NULLP)
      {
         if (copyData == TRUE)
         {
            (Void) soCmFilterUri((U8 *)&key[keyLen], &fltLen,
               (U8 *)tknStr->val, tknStr->len, phoneUser, FALSE);
         }
         else
         {
            (Void) soCmFilterUri((U8 *)NULLP, &fltLen,
               (U8 *)tknStr->val, tknStr->len, phoneUser, FALSE);
         }
         keyLen += fltLen;

         SO_PASSWORD_FROM_SIPURL(tknStr, &addrSpec->t.sipUrl);
         /* Password is present */
         if (tknStr != (TknStrOSXL *)NULLP)
         {
            if (copyData == TRUE)
            {
               /* add '[' */
               key[keyLen++] = '[';

               (Void) cmMemcpy((U8 *)&key[keyLen], (U8 *)tknStr->val,
                  tknStr->len);
               keyLen += tknStr->len;

               /* add ']' */
               key[keyLen++] = ']';
            }
            else
            {
               keyLen += 2; /* the '[' and ']' */
               keyLen += tknStr->len;
            }
         }
         /* Add @ */
         if (copyData == TRUE)
         {
            key[keyLen++] = '@';
         }
         else
         {
            keyLen++;
         }
      }

      /* Copy host */
      s_dynSize = 0;
  
      /* Temp stack variable used to save memory 
       *     allocation in function soCmStrAddrFromHostPort */
      s_dyn = &temp[0];

      ret = soCmStrAddrFromHostPort(hostPort, &s_dyn, &s_dynSize);
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

      if (copyData == TRUE)
      {
         (Void) soCmFilterUri((U8 *)&key[keyLen], &fltLen, s_dyn,
                              s_dynSize, FALSE, TRUE);
      }
      else
      {
         (Void) soCmFilterUri((U8 *)NULLP, &fltLen, s_dyn, s_dynSize,
                              FALSE, TRUE);
      }
      keyLen += fltLen;
     
      /* Add port if available */
      if (hostPort->port.pres == PRSNT_NODEF)
      {
        /* Temp variable to save multiple call to 
         *            function cmStrlen  */
         U16 s_st_len;

         sprintf((S8 *)s_st, ":%li", hostPort->port.val);
         s_st_len = cmStrlen(s_st);

         if (copyData == TRUE)
         {
            (Void) cmMemcpy((U8 *)&key[keyLen], s_st, (PTR)s_st_len);
         }
         keyLen += s_st_len;
      }
      else /* otherwise add default port */
      {
        /* Temp variable to save multiple call to 
         *            function cmStrlen  */
         U16 s_st_len;

         sprintf((S8 *)s_st, ":5060");
         s_st_len = cmStrlen(s_st);


         if (copyData == TRUE)
         {
            (Void) cmMemcpy((U8 *)&key[keyLen], s_st, (PTR)s_st_len);
         }
         keyLen += s_st_len;
      }

      /* Add transport parameter */
      paramValid = FALSE;
      if (transportParam != (SoTransportParam *)NULLP)
      {
         if (SO_CMP_TKN_LIT(&transportParam->transportParamType,
            SO_TRANSPORT_UDP))
         {
            paramValid = TRUE;
            if (copyData == TRUE)
            {
               (Void) cmMemcpy(&key[keyLen], udp_txt,
                  (PTR)cmStrlen(udp_txt));
            }
            keyLen += cmStrlen(udp_txt);
         }
         else if (SO_CMP_TKN_LIT(&transportParam->transportParamType,
               SO_TRANSPORT_TCP))
         {
            paramValid = TRUE;
            if (copyData == TRUE)
            {
               (Void) cmMemcpy(&key[keyLen], (U8 *)tcp_txt,
                  (PTR)cmStrlen(udp_txt));
            }
            keyLen += cmStrlen(tcp_txt);
         }
      }

      /* default is udp */
      if (paramValid == FALSE)
      {
         if (copyData == TRUE)
         {
            (Void) cmMemcpy(&key[keyLen], (U8 *)udp_txt,
               (PTR)cmStrlen(udp_txt));
         }
         keyLen += cmStrlen(udp_txt);
      }

      /* Add user parameter? */
      if (userParam != (SoUserParam *)NULLP)
      {
         if (phoneUser == TRUE)
         {
            if (copyData == TRUE)
            {
               (Void) cmMemcpy(&key[keyLen], (U8 *)phone_txt,
                  (PTR)cmStrlen(phone_txt));
            }
            keyLen += cmStrlen(phone_txt);
         }
         else if (SO_CMP_TKN_LIT(&userParam->userParamType,
               SO_USERPARAM_IP))
         {
            if (copyData == TRUE)
            {
               (Void) cmMemcpy(&key[keyLen], (U8 *)ip_txt,
                  (PTR)cmStrlen(ip_txt));
            }
            keyLen += cmStrlen(ip_txt);
         }
      }
   }
   /* else try to get absolute URI */
   else if (SO_CMP_TKN_LIT(&addrSpec->addrSpecType, SO_ADDRSPEC_ABSOLUTEURI)
            == TRUE)
   {
      if (addrSpec->t.absoluteUri.pres.pres == PRSNT_NODEF)
      {
         /* Copy scheme */
         SO_SCHEME_FROM_ABSURI(tknStr, &addrSpec->t.absoluteUri);
         if (tknStr == (TknStrOSXL *)NULLP)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO062, ERRZERO,
               "soCmBuildTranKey failed");
#endif /* ERRCLASS & ERRCLS_DEBUG */
            RETVALUE(RFAILED);
         }

         if (copyData == TRUE)
         {
            (Void) soCmFilterUri((U8 *)&key[keyLen], &fltLen,
               (U8 *)tknStr->val, tknStr->len, FALSE, TRUE);
         }
         else
         {
            (Void) soCmFilterUri((U8 *)NULLP, &fltLen,
               (U8 *)tknStr->val, tknStr->len, FALSE, TRUE);
         }
         keyLen += fltLen;

         /* add ':' */
         if (copyData == TRUE)
         {
            key[keyLen++] = ':';
         }
         else
         {
            keyLen++;
         }

         /* Copy hierpart/opaquepart -- no translation */
         SO_DESCPART_FROM_ABSURI(tknStr, &addrSpec->t.absoluteUri);

         if (tknStr == (TknStrOSXL *)NULLP)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO063, ERRZERO,
               "soCmBuildTranKey failed");
#endif /* ERRCLASS & ERRCLS_DEBUG */
            RETVALUE(RFAILED);
         }

         if (copyData == TRUE)
         {
            (Void) cmMemcpy((U8 *)&key[keyLen], (U8 *)tknStr->val,
               (PTR)tknStr->len);
         }
         keyLen += tknStr->len;
      }
      else
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO064, ERRZERO, "soCmBuildTranKey failed");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         RETVALUE(RFAILED);
      }
   }
#ifdef SO_ENUM
   else if (SO_CMP_TKN_LIT(&addrSpec->addrSpecType, SO_ADDRSPEC_TELURL) 
                == TRUE) 
   {

      /* Copy User/Telephone-subscriber if available */
      if(addrSpec->t.telUrl.digits.pres == PRSNT_NODEF)
         tknStr = &addrSpec->t.telUrl.digits;
      else
         tknStr = NULLP;      

      phoneUser = FALSE;
      /* Username is present */
      if (tknStr != (TknStrOSXL *)NULLP)
      {
         if (copyData == TRUE)
         {
            (Void) soCmFilterUri((U8 *)&key[keyLen], &fltLen,
               (U8 *)tknStr->val, tknStr->len, phoneUser, FALSE);
         }
         else
         {
            (Void) soCmFilterUri((U8 *)NULLP, &fltLen,
               (U8 *)tknStr->val, tknStr->len, phoneUser, FALSE);
         }
         keyLen += fltLen;
      }
  }
#endif /* SO_ENUM */

   *retLen = keyLen;

   RETVALUE(ROK);
} /* end of soCmNormAddr */

/*
*
*       Fun:   soCmNormAddress
*
*       Desc:  Generates a normalized string representation of an address
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: Provide a NULL destination to calculate the resulting
*              length only.
*              The string is NOT null terminated.
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmNormAddress
(
U8        *key,       /* Destination string      */
SoAddress *addr,      /* Source From header      */
U16       *retLen,    /* Resulting string length */
Bool      inclTag     /* Include tag             */
)
#else
PUBLIC S16 soCmNormAddress(key, addr, retLen, inclTag)
U8        *key;       /* Destination string      */
SoAddress *addr;      /* Source From header      */
U16       *retLen;    /* Resulting string length */
Bool      inclTag;    /* Include tag             */
#endif
{
   SoAddrSpec *addrSpec;         /* Pointer to addrSpec          */
   TknStrOSXL *tagParam;         /* Pointer to tag parameter     */
   TknStrOSXL *addrExtScheme;    /* Pointer to address extension */
   TknStrOSXL *addrExt;          /* Pointer to address extension */
   U16        numCompVal;        /* number of components         */
   U16        keyLen;            /* Resulting string length      */
   U32        i;                 /* counter                      */
   S16        ret;               /* function return value        */
   Bool       copyData;          /* actually generate string?    */

   TRC2(soCmNormAddress)

   *retLen = 0;
   keyLen  = 0;

   if (addr->pres.pres != PRSNT_NODEF)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO065, ERRZERO, "soCmNormAddress failed");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }

   SO_ADDRSPEC_FROM_ADDRCH(addrSpec, &addr->addrCh);

   if (addrSpec == (SoAddrSpec *)NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO066, ERRZERO, "soCmNormAddress failed");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }

   /* Two modes of operation */
   if (key == (U8 *)NULLP)
   {
      copyData = FALSE;
   }
   else
   {
      copyData = TRUE;
   }

   if (copyData == TRUE)
   {
      ret = soCmNormAddr(key, addrSpec, &keyLen);
   }
   else
   {
      ret = soCmNormAddr((U8 *)NULLP, addrSpec, &keyLen);
   }

   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   if (inclTag == TRUE)
   {
      /* Find a possible tag / addr-extension parameters */
      tagParam      = (TknStrOSXL *)NULLP;
      addrExtScheme = (TknStrOSXL *)NULLP;
      addrExt       = (TknStrOSXL *)NULLP;
      numCompVal    = SO_GET_NUM_COMP(&addr->addrParams.numComp);

      for (i = 0; i < numCompVal; ++i)
      {
         if (addr->addrParams.addrParam[i] != (SoAddrParam *)NULLP)
         {
            if (SO_CMP_TKN_LIT(&addr->addrParams.addrParam[i]->addrParamType,
               SO_ADDRPARAM_TAGPARAM) == TRUE)
            {
               tagParam = &addr->addrParams.addrParam[i]->t.tagParam;
            }
            else if (SO_CMP_TKN_LIT(
               &addr->addrParams.addrParam[i]->addrParamType,
               SO_ADDRPARAM_GENERICPARAM) == TRUE)
            {
               addrExtScheme =
                  &addr->addrParams.addrParam[i]->t.genericParam.token;
               SO_TKNSTR_FROM_GENERICPARAM(addrExt,
                  &addr->addrParams.addrParam[i]->t.genericParam);
            }
         }
      }

      if (tagParam != (TknStrOSXL *)NULLP)
      {
         if (tagParam->pres == PRSNT_NODEF)
         {
            if (copyData)
            {
               /* Add ';' */
               key[keyLen++] = ';';
               (Void) cmMemcpy(&key[keyLen], (U8 *)tagParam->val,
                  (PTR)tagParam->len);
               keyLen += tagParam->len;
            }
            else
            {
               keyLen += (tagParam->len + 1);
            }
         }
      }

      if (addrExt != (TknStrOSXL *)NULLP && addrExtScheme != (TknStrOSXL *)NULLP)
      {
         if (addrExt->pres == PRSNT_NODEF && addrExtScheme->pres == PRSNT_NODEF)
         {
            if (copyData)
            {
               /* Add ';' */
               key[keyLen++] = ';';
               (Void) cmMemcpy(&key[keyLen], (U8 *)addrExtScheme->val,
                  (PTR)addrExtScheme->len);
               keyLen += addrExtScheme->len;

               /* Add '=' */
               key[keyLen++] = '=';
               (Void) cmMemcpy(&key[keyLen], (U8 *)addrExt->val,
                  (PTR)addrExt->len);
               keyLen += addrExt->len;
            }
            else
            {
               keyLen += (addrExtScheme->len + 1);
               keyLen += (addrExt->len + 1);
            }
         }
      }
   }


   *retLen = keyLen;

   RETVALUE(ROK);
} /* soCmNormAddress */





/*******************************************************************
*
*       Fun:   soCmHostPortToTptAddr
*
*       Desc:  This function copies a HostPort to an NetAddr
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  so_cm.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC S16 soCmHostPortToTptAddr
(
SoHost     *host,   /* Host Portion */
U32        port,    /* Host Port    */
CmTptAddr  *tptAddr /* Transport address (returned) */
)
#else
PUBLIC S16 soCmHostPortToTptAddr (host, port, tptAddr)
SoHost     *host;   /* Host Portion */
U32        port;    /* Host Port    */
CmTptAddr  *tptAddr;/* Transport address (returned) */
#endif
{
#ifdef IPV6_SUPPORTED
   U32        a1;          /* Temp ip storage for conversion */
   U32        a2;          /* Temp ip storage for conversion */
   U32        a3;          /* Temp ip storage for conversion */
   Cntr       i;           /* Loop counter */
#endif /*IPV6_SUPPORTED */

   TRC2(soCmHostPortToTptAddr);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (! (host && tptAddr))
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO067, (ErrVal) 0, "soCmHostPortToTptAddr: "
                 "Invalid parameter");
      RETVALUE (RFAILED);
    }
#endif

    switch (host->hostType.val)
    {
       case SO_HOST_IPV4ADDRESS:
       {
          SoIpv4Address *a     = &host->t.ipv4Address;

          tptAddr->type = CM_TPTADDR_IPV4;

          tptAddr->u.ipv4TptAddr.address  =  (a->adr4.val & 0xff);
          tptAddr->u.ipv4TptAddr.address += ((a->adr3.val & 0xff) << 8);
          tptAddr->u.ipv4TptAddr.address += ((a->adr2.val & 0xff) << 16);
          tptAddr->u.ipv4TptAddr.address += ((a->adr1.val & 0xff) << 24);

          tptAddr->u.ipv4TptAddr.port = port;
          break;
       }

#ifdef IPV6_SUPPORTED
   
       case SO_HOST_IPV6REFERENCE:
       {
         TknStrOSXL *a = &host->t.ipv6Reference;

         tptAddr->type = CM_TPTADDR_IPV6;

         i = a->len-1;
         a3 = 15;

         while (i > 0)
         {
            a1 = 0;
            for (a2 = 0; a2 <= 4; a2++)
            {
               if (a->val[i] == ':')
               {
                  tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = a1 & 0xff;
                  a1 = a1 >> 8;
                  tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = a1 & 0xff;
                  i--;
                  break;
               }
               else
               {
                  if (AIsUpper(a->val[i]))
                     a1 = a1 | ((a->val[i--] - 55) << 4 * a2);
                  else if (AIsLower(a->val[i]))
                     a1 = a1 | ((a->val[i--] - 87) << 4 * a2);
                  else
                     a1 = a1 | ((a->val[i--] - '0') << 4 * a2);
               }
            }
         }

         tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = a1 & 0xff;
         a1 = a1 >> 8;
         tptAddr->u.ipv6TptAddr.ipv6NetAddr[a3--] = a1 & 0xff;

         tptAddr->u.ipv6TptAddr.port = port;
         break;
       }
#endif
       default:
#if (ERRCLASS & ERRCLS_DEBUG)
          SOLOGERROR (ERRCLS_DEBUG, ESO068, host->hostType.val,
                  "soCmHostPortToTptAddr: Invalid transport address type.");
          RETVALUE (RFAILED);
#endif
         break;

    } /* End of switch */

   RETVALUE(ROK);

} /* end of soCmHostPortToTptAddr */



/***********************************************************
*       Fun:   soCmpTptAddr 
*
*       Desc:  Compares two CmTptAddr
*
*       Ret:   TRUE = complete match, FALSE = no match or address match
*
*       Notes: Returns _address
*
*       File:  so_cm.c
*
**********************************************************/
#ifdef ANSI
PUBLIC S16 soCmpTptAddr
(
CmTptAddr  *one,             /* Address to compare */
CmTptAddr  *two,             /* Address to compare */
Bool       *addressMatch     /* Return true if at least _address_ matches */
)
#else
PUBLIC S16 soCmpTptAddr( one,  two, addressMatch)
CmTptAddr  *one;             /* Address to compare */
CmTptAddr  *two;             /* Address to compare */
Bool       *addressMatch;    /* Return true if at least _address_ matches */
#endif
{
   U16 i;

   TRC2(soCmpTptAddr);

   /* default values */
   i = 0;

   (*addressMatch) = FALSE;

   if (one->type != two->type)
   {
      RETVALUE(RFAILED);
   }

   if (one->type == CM_TPTADDR_IPV4)
   {
      if (one->u.ipv4TptAddr.address != two->u.ipv4TptAddr.address)
      {
         RETVALUE(RFAILED);
      }

      (*addressMatch) = TRUE;

      if (one->u.ipv4TptAddr.port != two->u.ipv4TptAddr.port)
      {
         RETVALUE(RFAILED);
      }
      RETVALUE(ROK);
   }

   else if (one->type == CM_TPTADDR_IPV6)
   {
      while (i < (CM_IPV6ADDR_SIZE - 1))
      {
         if (one->u.ipv6TptAddr.ipv6NetAddr[i] !=
             two->u.ipv6TptAddr.ipv6NetAddr[i])
         {
            RETVALUE(RFAILED);
         }
         i++;
      }

      (*addressMatch) = TRUE;

      if (one->u.ipv6TptAddr.port != two->u.ipv6TptAddr.port)
      {
         RETVALUE(RFAILED);
      }
      RETVALUE(ROK);
   }

   RETVALUE(RFAILED);
   
} /* soCmpTptAddr */




#ifdef DEBUGP
/***********************************************************
*       Fun:   soBCDToAsc
*
*       Desc:  Converts a BCD address into printable ASCII format.
*              The length is specified in octets.
*              The ASCII string is null terminated. The length
*              of the ascii string should be 2*len + 1
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  so_cm.c
*
**********************************************************/
#ifdef ANSI
PUBLIC Void soBcdToAsc
(
U8  *str,                    /* input address string to be converted */
U8  len,                     /* length of input string in octets */
Txt *ascStr                  /* output ASCII string */
)
#else
PUBLIC Void soBcdToAsc(str, len, ascStr)
U8  *str;                    /* input address string to be converted */
U8  len;                     /* length of input string in octets */
Txt *ascStr;                 /* output ASCII string */
#endif
{
   U8 i;                     /* counter */
   U8 j;                     /* counter */

   TRC2 (soBcdToAsc);

   /* convert BCD address into ASCII */
   for (i = 0, j = 0; i < len; i++, j += 2)
   {
      ascStr[j]     = BCD_TO_ASCII(str[i] >> 4);
      ascStr[j + 1] = BCD_TO_ASCII(str[i] & 0x0F);
   }

   ascStr[j] = '\0';
} /* end of soBcdToAsc */
#endif /* DEBUGP */


#ifdef DEBUGP
/***********************************************************
*       Fun:   soCmGetPortAndAscAddr
*
*       Desc:  Get IP port and IP address ASCII string
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  so_cm.c
*
**********************************************************/
#ifdef ANSI
PUBLIC Void soCmGetPortAndAscAddr
(
CmTptAddr  *addr,                   /* transport address */
U16        *port,                   /* port */
Txt        *str                     /* address string */
)
#else
PUBLIC Void soCmGetPortAndAscAddr (addr, port, str)
CmTptAddr  *addr;                   /* transport address */
U16        *port;                   /* port */
Txt        *str;                    /* address string */
#endif
{
   TRC2 (soCmGetPortAndAscAddr);

   if (addr && addr->type == CM_TPTADDR_IPV4)
   {
      *port = addr->u.ipv4TptAddr.port;
      sprintf (str, "%lX", addr->u.ipv4TptAddr.address);
   }
   else if (addr && addr->type == CM_TPTADDR_IPV6)
   {
      *port = addr->u.ipv6TptAddr.port;
      /* BCD address into ASCII */
      soBcdToAsc (addr->u.ipv6TptAddr.ipv6NetAddr, CM_IPV6ADDR_SIZE, str);
   }
   else
   {
      *port = 0;
      str[0] = '\0';
   }

   RETVOID;
} /* end of soCmGetPortAndAscAddr */

#endif /* DEBUGP */



/*
*
*       Fun:   soCmTptAddrToHostPort
*
*       Desc:  This function copies a CmTptAddr to an SoHostPort
*
*       Ret:   ROK/RFAILED
*
*       Notes: if evnt == NULL SOALLOC is used, else cmGetMem.
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmTptAddrToHostPort
(
SoHostPort *hostPort,   /* HostPort to be filled       */
CmTptAddr  *addr,       /* Source address              */
SoEvnt     *evnt        /* event for memory allocation */
)
#else
PUBLIC S16 soCmTptAddrToHostPort(hostPort, addr, evnt)
SoHostPort *hostPort;   /* HostPort to be filled       */
CmTptAddr  *addr;       /* Source address              */
SoEvnt     *evnt;       /* event for memory allocation */
#endif
{
   U8    *ipHex;        /* Hex U32 IPv4 representation */
#ifdef IPV6_SUPPORTED
   U8     temp[50];     /* Variable to hold IP V6 address 
                           in string format            */
   U32    a1;           /* Variable used in converting the 
                           IPV6 address from binary to
                           string format               */
   U32    a2;           /* Variable used in converting the 
                           IPV6 address from binary to
                           string format               */
   U32    i;            /* Loop counter                */
   U32    j;            /* Loop counter                */
   U32    indx;         /* Indiates the next position to be 
                           filled in the text array    */
   S16    ret;
#endif /* IPV6_SUPPORTED  */

   TRC2(soCmTptAddrToHostPort);

   if (addr == 0)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO069, ERRZERO,
                 "soCmTptAddrToHostPort: NULL address");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }


   /* Discover from what address this message arrived */
   switch (addr->type)
   {
      case CM_TPTADDR_IPV4:
         SO_FILL_TKNU8(&hostPort->host.hostType, SO_HOST_IPV4ADDRESS);

         ipHex =
            (U8 *)&addr->u.ipv4TptAddr.address;

         /* Copy to SoIpv4Address */
         hostPort->host.t.ipv4Address.pres.pres = PRSNT_NODEF;

         SO_FILL_TKNU8(&hostPort->host.t.ipv4Address.adr1,
                       GetHiByte(GetHiWord(addr->u.ipv4TptAddr.address)));
         SO_FILL_TKNU8(&hostPort->host.t.ipv4Address.adr2,
                       GetLoByte(GetHiWord(addr->u.ipv4TptAddr.address)));
         SO_FILL_TKNU8(&hostPort->host.t.ipv4Address.adr3,
                       GetHiByte(GetLoWord(addr->u.ipv4TptAddr.address)));
         SO_FILL_TKNU8(&hostPort->host.t.ipv4Address.adr4,
                       GetLoByte(GetLoWord(addr->u.ipv4TptAddr.address)));

         SO_FILL_TKNU16(&hostPort->port, addr->u.ipv4TptAddr.port);
         break;

#ifdef IPV6_SUPPORTED
      case CM_TPTADDR_IPV6:
         SO_FILL_TKNU8(&hostPort->host.hostType, SO_HOST_IPV6REFERENCE);

         /* Treat IPv6 as a binary string. Convert it to a string */

         indx = 0;
         for (i = 0; i < CM_IPV6ADDR_SIZE/2; i++)
         {
            for (j = 0; j < 2; j++)
            {
               a1 = addr->u.ipv6TptAddr.ipv6NetAddr[i*2+j]/16;
               a2 = addr->u.ipv6TptAddr.ipv6NetAddr[i*2+j]%16;
               if (a1 > 9)
                  temp[indx++] = a1 + 87;
               else
                  temp[indx++] = a1 + '0';

               if (a2 > 9)
                  temp[indx++] = a2 + 87;
               else
                  temp[indx++] = a2 + '0';
            }
            temp[indx++] = ':';
         }
         SO_FILL_TKNSTROSXL(
            &hostPort->host.t.ipv6Reference,
            (U8 *) temp,
            indx-1, evnt,ret);
         if (ret != ROK)
            RETVALUE (RFAILED);

         SO_FILL_TKNU16(&hostPort->port,
            addr->u.ipv6TptAddr.port);
         break;
#endif
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO070, addr->type,
                  "soCmTptAddrToHostPort: Invalid transport address type.");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }

   SO_FILL_TKNU8(&hostPort->pres, PRSNT_NODEF);

   RETVALUE(ROK);
} /* end of soCmTptAddrToHostPort */


/*
*
*       Fun:   soCmStrAddrFromHostPort
*
*       Desc:  This function retrieves the host address as a string
*
*       Ret:   ROK/RFAILED
*
*       Notes: string is allocated on the heap.
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmStrAddrFromHostPort
(
SoHostPort *hostPort,   /* SoHostPort from which to extract address  */
U8         **str,       /* Pointer to destination string             */
U8         *size        /* Pointer to destination string size        */
)
#else
PUBLIC S16 soCmStrAddrFromHostPort(hostPort, str, size)
SoHostPort *hostPort;   /* SoHostPort from which to extract address  */
U8         **str;       /* Pointer to destination string             */
U8         *size;       /* Pointer to destination string size        */
#endif
{
   TknU8          *hostType; /* Pointer to hosttype                   */
   SoIpv4Address  *ipv4;     /* Pointer to ipv4 address               */
   TknStrOSXL     *addr;     /* Pointer to hostname/ipv6 tokenstring  */

   TRC2(soCmStrAddrFromHostPort);


   *size = 0;

   SO_HOSTTYPE_FROM_HOSTPORT(hostType, hostPort);

   if (hostType == (TknU8 *)NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO071, ERRZERO,
         "soCmStrAddrFromHostPort: hostType not present in From header.");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }

   if (hostType->val == SO_HOST_IPV4ADDRESS)
   {
      SO_IPV4ADDRESS_FROM_HOSTPORT(ipv4, hostPort);
      if (ipv4 == (SoIpv4Address *)NULLP)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO072, ERRZERO,
            "soCmStrAddrFromHostPort: ipv4 not present in From header.");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         RETVALUE(RFAILED);
      }

      sprintf((S8 *)(*str), "%i.%i.%i.%i",
               ipv4->adr1.val,
               ipv4->adr2.val,
               ipv4->adr3.val,
               ipv4->adr4.val);

      *size = (U8)cmStrlen(*str);
   }
   else
   {
      SO_HOSTNAME_FROM_HOSTPORT(addr, hostPort);
      if (addr == (TknStrOSXL *)NULLP)
      {
         SO_IPV6ADDRESS_FROM_HOSTPORT(addr, hostPort);
      }

      /* Error - no address-type found */
      if (addr == (TknStrOSXL *)NULLP)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO073, ERRZERO,
            "soCmStrAddrFromHostPort: "
            "Could not resolve host address from SoAddrCh");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         RETVALUE(RFAILED);
      }


      *str = addr->val;
      *size = (U8)addr->len;
   }

   RETVALUE(ROK);
} /* end of soCmStrAddrFromHostPort */

/*
*
*       Fun:   soCmGrowList
*
*       Desc:  This function grows a dynamic array.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: Providing a NULL evnt will result in allocation from
*              heap, otherwise evnt->memCp will be used.
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmGrowList
(
Void     ***list,              /* Pointer to array to be resized     */
U16      typeSize,             /* Size if an array element           */
TknU16   *numComp,             /* Pointer to numComp                 */
SoEvnt   *evnt                 /* event for allocating memory        */
)
#else
PUBLIC S16 soCmGrowList(list, typeSize, numComp, evnt)
Void     ***list;              /* Pointer to array to be resized     */
U16      typeSize;             /* Size if an array element           */
TknU16   *numComp;             /* Pointer to numComp                 */
SoEvnt   *evnt;                /* event for allocating memory        */
#endif
{
   S16   ret;                  /* Function return values  */
   U16   numCompVal;           /* Numeric numComp         */

   TRC2(soCmGrowList)

   numCompVal = SO_GET_NUM_COMP(numComp);

   if (evnt != (SoEvnt *)NULLP)
   {
      ret = soCmResizeEvntList((PTR *)list, numComp, (U16)(numCompVal + 1),
                                 evnt);
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

      ret = cmGetMem(&evnt->memCp, (Size)typeSize,
                        (Ptr *)(&(*list)[numCompVal]));
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

      (Void) cmMemset((U8 *)(*list)[numCompVal], 0, (PTR)typeSize);
   }
   else
   {
      /* set numComp->val to 0 if numComp->pres == NOTPRSNT */
      /* it is used in the next step without checking */
      if (numComp->pres == NOTPRSNT)
         numComp->val = 0;

      ret = soCmResizeList((PTR *)list, &(numComp->val),
                              (U16)(numCompVal + 1));
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }

      SOALLOC(&(*list)[numCompVal], typeSize);
      if ((*list)[numCompVal] == (Void *)NULLP)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO074, ERRZERO,
                    "soCmGrowList: SOALLOC failed.");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         RETVALUE(RFAILED);
      }
   }

   SO_FILL_NUM_COMP(numComp, numCompVal + 1);

   RETVALUE(ROK);
} /* soCmGrowList */


/*
*
*       Fun:   soCmShrinkList
*
*       Desc:  This function shrinks a dynamic array.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: Set evnt to NULL to deallocate the HEAP.
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmShrinkList
(
Void     ***list,              /* Pointer to array to be resized     */
U16      typeSize,             /* Size if an array element           */
TknU16   *numComp,             /* Pointer to numComp                 */
SoEvnt   *evnt                 /* event for allocating memory        */
)
#else
PUBLIC S16 soCmShrinkList(list, typeSize, numComp, evnt)
Void     ***list;              /* Pointer to array to be resized     */
U16      typeSize;             /* Size if an array element           */
TknU16   *numComp;             /* Pointer to numComp                 */
SoEvnt   *evnt;                /* event for allocating memory        */
#endif
{
   U16   numCompVal;           /* Numeric numComp         */
   S16   ret;                  /* return Value */

   TRC2(soCmShrinkList)

   numCompVal = SO_GET_NUM_COMP(numComp);

   if (numCompVal > 0)
   {
      if (evnt == (SoEvnt *)NULLP)
      {
         SOFREE((*list)[numCompVal - 1], typeSize);

         ret = soCmResizeList((PTR *)(list), &(numComp->val),
                              (U16)(numCompVal - 1));
         if (ret != ROK)
           RETVALUE(RFAILED);
      }
      else
      {
         (Void) soCmResizeEvntList((PTR *)(list), numComp,
                                    (U16)(numCompVal - 1),
                                    evnt);
      }
   }

   RETVALUE(ROK);
} /* soCmShrinkList */



/*****************************************************************************
*
*       Fun:   soCmGetSIPCodes
*
*       Desc:  Find the reason phrase for SIP status code and fill in
*           status line structures
*
*       Ret:   ROK if the status code found
*
*       Notes: None
*
*       File:  so_cm.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 soCmGetSIPCodes
(
U16               code,          /* status code                         */
U16               extCode,       /* Extended code                       */
SoStatusLine      *codePhrase,   /* structure to fill in                */
SoEvnt            *evnt          /* status line belongs to this event   */
)
#else
PUBLIC S16 soCmGetSIPCodes(code, extCode, codePhrase, evnt)
U16               code;          /* status code                         */
U16               extCode;       /* Extended code                       */
SoStatusLine      *codePhrase;   /* structure to fill in                */
SoEvnt            *evnt;         /* status line belongs to this event   */
#endif
{
   U8          i;                /* counter                             */
   Txt         buffer[100];
   S16         ret;

   TRC2(soCmGetSIPCodes)

   for (i = 0; ;i++ )
   {
      /* The assumption here is that 0 is not a valid status code. */
      if (soSIPCodes[i].code == 0)
         break;

      if (code == soSIPCodes[i].code)
      {
         SO_FILL_TKNU16(&codePhrase->statusCode, code);
         /* status code found */
         if (extCode == SO_EXTRSP_NONE)
         {
            sprintf(buffer,"%s", soSIPCodes[i].phrase);
         }
         else
         {
            sprintf(buffer,"%s (%s)", soSIPCodes[i].phrase, soExtSIPCodes[extCode]);
         }
         SO_FILL_TKNSTROSXL(&codePhrase->reasonPhrase,buffer,
            cmStrlen((U8 *)buffer), evnt, ret);
         if (ret != ROK)
             RETVALUE(RFAILED);

         RETVALUE(ROK);
      }
   }

   /* code not found */
   RETVALUE(RFAILED);

} /* end of soCmGetSIPCodes */



/*****************************************************************************
*
*       Fun:   soCmCreateEvent
*
*       Desc:  Creates new event, sets event type
*
*       Ret:   Nothing
*
*       Notes: Allocates memory, sets event type
*
*       File:  so_cm.c
*
******************************************************************************/
#ifdef ANSI
PUBLIC S16 soCmCreateEvent
(
SoEvnt          **newEvent,   /* New event structure */
U8              eventType     /* Event type to create */
)
#else
PUBLIC S16 soCmCreateEvent(newEvent, eventType)
SoEvnt          **newEvent;   /* New event structure */
U8              eventType;    /* Event type to create */
#endif
{
   S16         ret;              /* Return value */
   Mem         eventMem;         /* Memory to use for event */

   TRC2(soCmCreateEvent);

   (*newEvent) = NULLP;

   /* allocate memory for new event */
   eventMem.region = soCb.init.region;
   eventMem.pool   = soCb.init.pool;

   /* Allocate memory for event structure */
   ret = cmAllocEvnt(sizeof(SoEvnt), soCb.cfg.maxBlkSize , &eventMem,
                     (Ptr *)newEvent);
   if (ret != ROK)
   {
      SO_GEN_SMEM_ALARM;
      RETVALUE(RFAILED);
   }

   /* fill in event detail */
   (*newEvent)->eventType.pres = PRSNT_NODEF;
   (*newEvent)->eventType.val  = eventType;

   RETVALUE(OK);
} /* soCmCreateEvent */

#ifndef CM_SDP_OPAQUE
/*****************************************************************************
*
*       Fun:   soCmCreateSdpEvent
*
*       Desc:  Creates new event, sets event type
*
*       Ret:   Nothing
*
*       Notes: Allocates memory for SDP event.
*
*       File:  so_cm.c
*
******************************************************************************/
#ifdef ANSI
PUBLIC S16 soCmCreateSdpEvent
(
SoSdpEvnt          **newEvent    /* New event structure */
)
#else
PUBLIC S16 soCmCreateSdpEvent(newEvent)
SoSdpEvnt          **newEvent;   /* New event structure */
#endif
{
   S16         ret;              /* Return value */
   Mem         eventMem;         /* Memory to use for event */

   TRC2(soCmCreateSdpEvent);

   (*newEvent) = NULLP;

   /* allocate memory for new event */
   eventMem.region = soCb.init.region;
   eventMem.pool   = soCb.init.pool;

   /* Allocate memory for event structure */
   ret = cmAllocEvnt(sizeof(SoSdpEvnt), soCb.cfg.maxBlkSize , &eventMem,
                     (Ptr *)newEvent);
   if (ret != ROK)
   {
      SO_GEN_SMEM_ALARM;
      RETVALUE(RFAILED);
   }

   RETVALUE(OK);
} /* soCmCreateSdpEvent */
#endif /* CM_SDP_OPAQUE */

/*
*
*       Fun:   soCmFreeBody
*
*       Desc:  This message frees all the memory associated with a
*              SIP body.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmFreeBody
(
SoBody   *body          /* body to free */
)
#else
PUBLIC S16 soCmFreeBody(body)
SoBody   *body;         /* body to free */
#endif
{
   U16 i;      /* counter for multi-part body */
   S16 ret;    /* return value                */

   TRC2(soCmFreeBody);

   if (body == NULLP)
   {
      RETVALUE(ROK);
   }

   /* Check body type */
   switch (body->bodyType.val)
   {
      case SOT_BODYTYPE_SINGLEPART:
         /* Check that single-part body type is present */
         if (body->u.singlePart.bodySinglePartType.pres == NOTPRSNT)
         {
            RETVALUE(RFAILED);
         }

#ifndef CM_SDP_OPAQUE
         /* Check if body is SDP */
         if (body->u.singlePart.bodySinglePartType.val == SOT_BODYSINGLEPART_SDP)
         {
            if ((Ptr) body->u.singlePart.s.sdp != NULLP)
            {
               /* Free SDP part */
               cmFreeMem((Ptr) body->u.singlePart.s.sdp);
               body->u.singlePart.s.sdp = NULLP;
            }
         }
         else 
#endif /* CM_SDP_OPAQUE */
         if (body->u.singlePart.bodySinglePartType.val == SOT_BODYSINGLEPART_STR)
         {
            /* Free Buffer */
            if (body->u.singlePart.s.str.pres != NOTPRSNT)
            {
               if (body->u.singlePart.s.str.val != (Buffer *) NULLP)
               {
                  SPutMsg(body->u.singlePart.s.str.val);
                  body->u.singlePart.s.str.val = NULLP;
               }
            }
         }
         break;

      case SOT_BODYTYPE_MULTIPART:
         /* Free each of the multi-part elements */
         for (i = 0; i < SO_GET_NUM_COMP(&body->u.multiPart.numComp);
              i++)
         {
            /* Call soCmFreeBody recursively to release this nested body */
            ret = soCmFreeBody(body->u.multiPart.bodyElm[i]->body);
            if (ret != ROK)
            {
               RETVALUE(ret);
            }
         }

         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO075, ERRZERO,
                    "soCmFreeBody: Invalid SIP body type.");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of soCmFreeBody */


/*
*
*       Fun:   soCmFreeEvent
*
*       Desc:  This function frees all the memory associated with a SIP event
*              structure.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmFreeEvent
(
SoEvnt  *evnt    /* Event structure to free */
)
#else
PUBLIC S16 soCmFreeEvent(evnt)
SoEvnt  *evnt;   /* Event structure to free */
#endif
{
   S16 ret;       /* return value */

   TRC2(soCmFreeEvent);

   /* so016.201: - Null pointer check */
   if (evnt == NULLP)
      RETVALUE(RFAILED);

   /* Free all child events */
   if (evnt->sipBody.bodyType.pres != NOTPRSNT)
   {
      ret = soCmFreeBody(&evnt->sipBody);
      if (ret != ROK)
      {
         RETVALUE(ret);
      }
   }

/* so036.201: Changes for SO_CALEA */
#ifdef SO_CALEA
   if (evnt->rawMsg != NULLP)
   {
      SPutMsg(evnt->rawMsg);
      evnt->rawMsg = NULLP;
   }
#endif
   /* Free parent event */
   cmFreeMem((Ptr) evnt);

   RETVALUE(ROK);
} /* end of soCmFreeEvent */


/*
*
*       Fun:   soCmGetAddrParam
*
*       Desc:  This function gets a specific address parameter
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmGetAddrParam
(
U8          **param,       /* Returned parameter         */
SoAddress   *addrItem,     /* Address item to search     */
U8          addrParamType  /* Type of address parameter  */
)
#else
PUBLIC S16 soCmGetAddrParam(param, addrItem, addrParamType)
U8          **param;       /* Returned parameter         */
SoAddress   *addrItem;     /* Address item to search     */
U8          addrParamType; /* Type of address parameter  */
#endif
{
   U32        i;       /* Index into via parameter array   */

   TRC2(soCmGetAddrParam);

   /* Initialize return value */
   (*param) = NULLP;

   for (i = 0; i < SO_GET_NUM_COMP(&addrItem->addrParams.numComp); i++)
   {
      if (SO_CMP_TKN_LIT(&addrItem->addrParams.addrParam[i]->addrParamType,
         addrParamType) == TRUE)
      {
         (*param) = (U8 *)&addrItem->addrParams.addrParam[i]->t;
         RETVALUE(ROK);
      }
   }

   RETVALUE(RFAILED);

} /* soCmGetAddrParam */




/*
*
*       Fun:   soCmGetAddrFromVia
*
*       Desc:  This function gets an address from the SIP message supplied.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Uses topmost via address
*                - use maddr if present
*                - otherwise use "received"
*                - all else fails, use "sent-by" address
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmGetAddrFromVia
(
SoEvnt     *evnt,           /* Pointer to complete SIP message   */
SoHost     **host,          /* host to be retrieved from via */
U32        *port            /* pointer to port to be retrieved from via */
)
#else
PUBLIC S16 soCmGetAddrFromVia(evnt, host, port)
SoEvnt     *evnt;           /* Pointer to complete SIP message   */
SoHost     **host;          /* host to be retrieved from via */
U32        *port;           /* pointer to port to be retrieved from via */
#endif
{
   SoVia             *via;       /* Via structure in message                 */
   SoHostPortType    *sentBy;    /* SoSentBy strucure in via header          */
   SoHostPort        *hostPort;  /* hostPort in sentBy                       */
   U16               i;          /* Index of via header                      */
   S16               ret;        /* value returned by function calls         */
   SoViaItem         *topVia;    /* Topmost via                              */
   SoViaParam        *oneParam;  /* Via parameter                            */

   TRC2(soCmGetAddrFromVia);

   /* Find Via header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &via,
      SO_HEADER_GEN_VIA);

   if (ret != ROK)
   {
      SODBGP_SO(SO_DBGMASK_NS,
                (soCb.init.prntBuf,
                 "soCmGetAddrFromVia: Via header not found"));
      RETVALUE(RFAILED);
   }

   /* Check number of vias */
   if (SO_GET_NUM_COMP(&via->numComp) == 0)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO076, ERRZERO,
                 "soCmGetAddrFromVia: No items in Via sequence.");
#endif
      RETVALUE(RFAILED);
   }

   topVia = via->viaItem[0];

   /* Initialize host and port */
   (*host) = NULLP;
   (*port) = SO_PORT_DEFAULT;

   sentBy = &via->viaItem[0]->sentBy;
   hostPort = &sentBy->t.hostPort;
   (*host) = &hostPort->host;

   if (hostPort->port.pres != NOTPRSNT)
      (*port) = hostPort->port.val;

   for (i = 0; i < SO_GET_NUM_COMP(&topVia->viaParams.numComp); i++)
   {
     oneParam = topVia->viaParams.viaParam[i];

#ifdef SO_NAT         
     if (SO_CMP_TKN_LIT(&oneParam->viaParamType, SO_VIAPARAM_VIARPORT)
         == TRUE)
       if (oneParam->t.viaRport.pres != NOTPRSNT)
              *port = oneParam->t.viaRport.val;
#endif
   }

   RETVALUE(ROK);

} /* end of soCmGetAddrFromVia */

/*
*
*       Fun:   soCmChkDomain
*
*       Desc:
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmChkDomain
(
SoAddrSpec   *addrSpec,       /* Address structure containing address     */
SoEntCb      *ent,            /* Entity to check against                  */
Bool         *hostMatch,      /* Actual host names match                  */
Bool         *domainMatch     /* Only domain names match                  */
)
#else
PUBLIC S16 soCmChkDomain(addrSpec, ent, hostMatch, domainMatch)
SoAddrSpec   *addrSpec;       /* Address structure containing domain name */
SoEntCb      *ent;            /* Entity to check against                  */
Bool         *hostMatch;      /* Actual host names match                  */
Bool         *domainMatch;    /* Only domain names match                  */
#endif
{
   U16               i;            /* Index of transport servers          */
   SoHostPort        *hostPort;    /* local pointer to hostPort           */
   SoHostPort        locHostPort;  /* local hostPort structure            */
   SoHostPort        uriHostPort;  /* local hostPort structure            */
   S16               ret;          /* function return valuse              */
   SoTptServerCb     *tptSrv;      /* Transport server being compared     */

   TRC2(soCmChkDomain);

   (*hostMatch) = FALSE;
   (*domainMatch) = FALSE;

   /* Set uriHostPort to 0's */
   cmMemset((U8 *)&uriHostPort, 0, sizeof(SoHostPort));

   /* Find host port in Request URI */
   SO_HOSTPORT_FROM_ADDRSPEC(hostPort, addrSpec);

   if (hostPort == (SoHostPort *) NULLP)
   {
      /* so038.201: If it is tel URI return ok */
      if ((SO_CMP_TKN_LIT(&addrSpec->addrSpecType, SO_ADDRSPEC_TELURL)) == TRUE
           ||(SO_CMP_TKN_LIT(&addrSpec->addrSpecType, SO_ADDRSPEC_ABSOLUTEURI)) == TRUE)
      {
         RETVALUE(ROK);
      }

      SODBGP_SO(SO_DBGMASK_NS,
                (soCb.init.prntBuf, "HostPort not present"));
      RETVALUE(RFAILED);
   }

   if (hostPort->host.hostType.pres == NOTPRSNT)
   {
      SODBGP_SO(SO_DBGMASK_NS,
                (soCb.init.prntBuf, "Host not present"));
      RETVALUE(RFAILED);
   }

   /* Check if there is a maddr param */
   for (i = 0; i < SO_GET_NUM_COMP(&addrSpec->t.sipUrl.urlParameters.numComp);
        i++)
   {
      if (SO_CMP_TKN_LIT(
            &addrSpec->t.sipUrl.urlParameters.urlParameter[i]->urlParameterType,
            SO_URLPARAMETER_MADDRHOST) == TRUE)
      {
         /* Copy host into uriHostPort */
         soUtlCpySoHost(
            &uriHostPort.host,
            &addrSpec->t.sipUrl.urlParameters.urlParameter[i]->t.maddrHost,
            NULLP);
         uriHostPort.pres.pres = PRSNT_NODEF;
         break;
      }
   }

   /* Check to see if host has been filled in from maddr */
   if (uriHostPort.host.hostType.pres == NOTPRSNT)
   {
      /* Host is not present - copy from AddrSpec */
      soUtlCpySoHost(
         &uriHostPort.host,
         &addrSpec->t.sipUrl.hostPort.host,
         NULLP);
      uriHostPort.pres.pres = PRSNT_NODEF;
   }

   /* Set port */
   if (hostPort->port.pres == NOTPRSNT)
   {
      SO_FILL_TKNU32(&uriHostPort.port, SO_PORT_DEFAULT);
   }
   else
   {
      SO_FILL_TKNU32(&uriHostPort.port, hostPort->port.val);
   }

   /* Compare host names against all transport server host names and/or addr */
   i = 0;
   while (i < soCb.maxTptSrv)
   {
      tptSrv = soCb.allSrvCbLst[i];
      if (tptSrv != NULLP)
      {
         if (tptSrv->entCb == ent)
         {
            /* Compare host name or IP address depending on type */

            if (uriHostPort.host.hostType.val == SO_HOST_HOSTNAME)
            {
               /* Check host name (case insensitive) */
               if (soUtlCmpTknStrOSXL(&tptSrv->hostName,
                  &uriHostPort.host.t.hostName, FALSE) == TRUE)
               {
                  (*hostMatch)   = TRUE;
                  (*domainMatch) = TRUE;
                  soUtlDelSoHostPort(&uriHostPort);
                  RETVALUE(ROK);
               }
            }
            else
            {
               /* Check IP address */
               ret =  soCmTptAddrToHostPort(&locHostPort,
                                            &soCb.allSrvCbLst[i]->localAddr,
                                            NULLP);
               if (ret != ROK)
               {
                  soUtlDelSoHostPort(&uriHostPort);
                  RETVALUE(ret);
               }

               ret = soCmCompareHostPort(&uriHostPort, &locHostPort);

               /* so038.201: replaced with macro to check for UDP transport */
               if ((ret != ROK) &&
                   (SO_TCM_UDP_TRANSPORT(soCb.allSrvCbLst[i]->tptProt)))
               {
                  /* Free host part of hostPort, but leave port intact */
                  soUtlDelSoHost(&locHostPort.host);

               }

               /* Have to allocate and free each time as TknStr's may have
                * different lengths
                */
               soUtlDelSoHostPort(&locHostPort);
               if (ret == ROK)
               {
                  /* Addresses match */
                  (*hostMatch) = TRUE;
                  (*domainMatch) = TRUE;
                  soUtlDelSoHostPort(&uriHostPort);
                  RETVALUE(ROK);
               }
            }
         }
      }
      i++;
   }

   /* At this point we know host names did not match, check domain part */
   if ((uriHostPort.host.hostType.val == SO_HOST_HOSTNAME) && (ent != NULLP))
   {
      if (soCmCmpDomain(&uriHostPort.host.t.hostName, ent->domainName) == ROK)
      {
         (*domainMatch) = TRUE;
         soUtlDelSoHostPort(&uriHostPort);
         RETVALUE(ROK);
      }
   }

   /* No match at all */
   soUtlDelSoHostPort(&uriHostPort);
   RETVALUE(ROK);
} /* end of soCmChkDomain */


/*****************************************************************************
*
*      Fun:   soCmFindSSap
*
*      Desc:  Finds the next available SSap
*
*      Ret:   ROK
*
*      Notes: None
*
*      File:  so_cm.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC Void soCmFindSSap
(
SoSSapCb       **ssap,     /* SSAP to send message         */
SoTptServerCb  *srv        /* SSap belongs to this server  */
)
#else
PUBLIC Void soCmFindSSap(ssap, srv)
SoSSapCb       **ssap;     /* SSAP to send message         */
SoTptServerCb  *srv;       /* SSap belongs to this server  */
#endif
{
    U16         idx;       /* index in SSapCbLst    */

    TRC2(soCmFindSSap);

    (*ssap) = NULLP;

    if ((srv == NULLP) || (srv->nmbSSap == 0))
    {
       RETVOID;
    }

    for (idx = 0; idx < LSO_TPTSRV_MAX_SSAP; idx++)
    {
       if (soCb.soSSapCbLst[srv->sSapLst[srv->currentSSap]]
           != (SoSSapCb *)NULLP)
       {
          /*-- so031.201: Check the state of the SAP as well. --*/
          if(soCb.soSSapCbLst[srv->sSapLst[srv->currentSSap]]->state == LSO_SSAP_BNDENA)
          {
             *ssap = soCb.soSSapCbLst[srv->sSapLst[srv->currentSSap]];
             srv->currentSSap = (srv->currentSSap + 1) % (srv->nmbSSap);

             RETVOID;
          }
       }
       srv->currentSSap = (srv->currentSSap + 1) % (srv->nmbSSap);

    }

    RETVOID;

} /* end of soCmFindSSap */


/*****************************************************************************
*
*       Fun:   soCmInitTimer
*
*       Desc:  Initialize the timer control blocks
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  so_cm.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC Void soCmInitTimer
(
SoTimer      *tmr         /* timer control block array */
)
#else
PUBLIC Void soCmInitTimer (tmr)
SoTimer      *tmr;         /* timer control block array */
#endif
{
   TRC2(soCmInitTimer)

   cmInitTimers ((CmTimer *)&tmr->tmr, 1);

   tmr->currentQ = NULLP;
   tmr->currentQCp = NULLP;
   tmr->soCbPtr    = 0;

   RETVOID;
} /* soCmInitTimer */


/*
*
*       Fun:   soCmSetEvntType
*
*       Desc:  This function checks the method in the message and sets
*              the event type appropriately.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmSetEvntType
(
SoEvnt  *evnt      /* soEvnt structure */
)
#else
PUBLIC S16 soCmSetEvntType(evnt)
SoEvnt  *evnt;     /* soEvnt structure */
#endif
{
   SoCSeq     *cSeq;   /* CSeq header field to create      */
   S16        ret;     /* value returned by function calls */

   TRC2(soCmSetEvntType);

   ret = soCmFindHdrChoice(evnt, (U8 **) &cSeq, SO_HEADER_GEN_CSEQ);
   if (ret != ROK)
   {
      RETVALUE(ret);
   }

   if (cSeq->method.type.pres == NOTPRSNT)
   {
      RETVALUE(RFAILED);
   }

   evnt->eventType.pres = PRSNT_NODEF;

   if (cSeq->method.type.val == SO_METHOD_EXTENSIONMETHOD)
   {
      evnt->eventType.val  = SOT_ET_UNKNOWN;
      RETVALUE(ROK);
   }

   if (cSeq->method.type.val != SO_METHOD_METHODSTD)
   {
      RETVALUE(RFAILED);
   }

   if (cSeq->method.t.std.pres == NOTPRSNT)
   {
      RETVALUE(RFAILED);
   }

   switch (cSeq->method.t.std.val)
   {
      case SO_METHODSTD_INVITE:
         evnt->eventType.val = SOT_ET_INVITE;
         break;
      
      case SO_METHODSTD_INFO:
         evnt->eventType.val = SOT_ET_INFO;
         break;

      case SO_METHODSTD_COMET:
         evnt->eventType.val = SOT_ET_PRECON_MET;
         break;

      case SO_METHODSTD_ACK:
         evnt->eventType.val = SOT_ET_ACK;
         break;

      case SO_METHODSTD_PRACK:
         evnt->eventType.val = SOT_ET_PRACK;
         break;

      case SO_METHODSTD_CANCEL:
         evnt->eventType.val = SOT_ET_CANCEL;
         break;

      case SO_METHODSTD_OPTIONS:
         evnt->eventType.val = SOT_ET_OPTIONS;
         break;

      case SO_METHODSTD_REGISTER:
         evnt->eventType.val = SOT_ET_REGISTER;
         break;

      case SO_METHODSTD_BYE:
         evnt->eventType.val = SOT_ET_BYE;
         break;

#ifdef  SO_REFER
      case SO_METHODSTD_REFER:
         evnt->eventType.val = SOT_ET_REFER;
         break;
#endif
#ifdef  SO_INSTMSG
      case SO_METHODSTD_MESSAGE:
         evnt->eventType.val = SOT_ET_MESSAGE;
         break;
#endif

#ifdef  SO_EVENT
      case SO_METHODSTD_SUBSCRIBE:
         evnt->eventType.val = SOT_ET_SUBSCRIBE;
         break;
      
      case SO_METHODSTD_NOTIFY:
         evnt->eventType.val = SOT_ET_NOTIFY;
         break;
#endif

#ifdef  SO_UPDATE
      case SO_METHODSTD_UPDATE:
         evnt->eventType.val = SOT_ET_UPDATE;
         break;
#endif
         
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO077, ERRZERO,
                    "soCmSetEvntType :Invalid method");
#endif
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of soCmSetEvntType */




/*
*
*       Fun:   soCmGenLocalTag
*
*       Desc:  This function generates the From tag.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: 
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmGenLocalTag
(
SoEvnt        *evnt,    /* Event Cb */
SoCLegCb      *cLeg,    /* Call Leg Cb */
SoAddress     *addr     /* Address to add tag to */
)
#else
PUBLIC S16 soCmGenLocalTag(evnt, cLeg, addr)
SoEvnt        *evnt;    /* Event Cb */
SoCLegCb      *cLeg;    /* Call Leg Cb */
SoAddress     *addr;    /* Address to add tag to */
#endif
{
   TknStrOSXL *tag;         /* pointer to tag to be filled   */
   U8         *tagStr;      /* tag string                    */
   U16        tagStrLen;    /* length of tag string          */
   U16        numComp;      /* Number of to Param            */
   U16        rand1;        /* Random element of tag         */
   Ticks      sysTime;      /* System time in ticks          */
   S16        ret;          /* Function return value         */

   TRC2(soCmGenLocalTag);

   ret = soCmGetAddrParam((U8 **)&tag, addr, 
                          SO_ADDRPARAM_TAGPARAM);
   if (ret == ROK)
   {
     /* so023.201:- To generate "To" tag without CLEG*/ 
     if ( cLeg != NULLP)
     { 
         /* Tag already present */
         ret = soUtlCpyTknStrOSXL(&cLeg->storedHdrs.localTag, tag, NULLP);
         RETVALUE(ret);
     }
   }

   tag = NULLP;

   numComp = addr->addrParams.numComp.val;

   /* Add tag to To header */
   if (soCmGrowList((Void ***)&addr->addrParams.addrParam,
                    sizeof(SoAddrParam), &addr->addrParams.numComp, 
                    evnt) != ROK)
   {
      RETVALUE(RFAILED);
   }

   SO_FILL_TKNU8(&addr->addrParams.addrParam[numComp]->addrParamType,
                 SO_ADDRPARAM_TAGPARAM);

   /* Set output pointer to new tag */
   tag = &addr->addrParams.addrParam[numComp]->t.tagParam;

   /* Set hashKeyLen */
   tagStrLen = LSO_NODEID_SZ + sizeof(U16) + sizeof(Ticks);

   SOALLOC(&tagStr, tagStrLen);
   if (tagStr == NULLP)
   {
      /*so041.201 Release the memory given by the Grow List*/
      soCmShrinkList((Void ***)&addr->addrParams.addrParam, sizeof(SoAddrParam),
            &addr->addrParams.numComp, evnt);
      RETVALUE(RFAILED);
   }
   /* Get system time */
   SGetSysTime(&sysTime);

   /* Set random element */
   SRandom(&rand1);

   /* Copy random element into tagStr */
   cmMemcpy(tagStr, (U8 *)&rand1, sizeof(U16));

   /* Copy nodeId into tagStr */
   cmMemcpy(tagStr + sizeof(U16), (U8 *)soCb.cfg.nodeIdStr, LSO_NODEID_SZ);

   /* Copy system time into tagStr */ /* ASA */
   cmMemcpy(tagStr + LSO_NODEID_SZ + sizeof(U16), (U8 *)&sysTime, sizeof(Ticks));

   tag->pres = PRSNT_NODEF;
   tag->len  = tagStrLen * 2;

   /* Allocate memory for tag */
   ret = cmGetMem(&evnt->memCp, (Size)tag->len, (Ptr *)&tag->val);
   if (ret != ROK)
   {
      SOFREE(tagStr, tagStrLen);
      /*so041.201 Release the memory given by the Grow List*/
      soCmShrinkList((Void ***)&addr->addrParams.addrParam, sizeof(SoAddrParam),
                     &addr->addrParams.numComp, evnt);
      RETVALUE(ret);
   }

   /* Convert hash to hex representation */
   ret = soCmFillHex((Txt *) tag->val, tagStr, tagStrLen);

   if (ret == ROK)
   {
     /* so023.201:- To generate "To" tag without CLEG*/ 
     if ( cLeg != NULLP)
     { 
         ret = soUtlCpyTknStrOSXL(&cLeg->storedHdrs.localTag, tag, NULLP);
     }
   }

   SOFREE(tagStr, tagStrLen);

   RETVALUE(ret);
} /* end of soCmGenLocalTag */





/*
*
*       Fun:   soCmSaveRemoteTag
*
*       Desc:  Saves to tag into the address provided
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soCmSaveRemoteTag
(
SoAddress      *addr,      /* Address that needs to be updatedwith tag */
SoAddress      *rcvdAddr,  /* Updated Address to copy from */
SoEvnt         *evnt,      /* Message containing To tag */
TknStrOSXL     *storedTag, /* tag rcvd in incoming msstored in call leg */
TknStrOSXL     *rcvdTag    /* tag rcvd in incoming msg */
)
#else
PUBLIC S16 soCmSaveRemoteTag(addr,rcvdAddr, evnt, storedTag, rcvdTag)
SoAddress      *addr;      /* Address that needs to be updatedwith tag */
SoAddress      *rcvdAddr;  /* Updated Address to copy from */
SoEvnt         *evnt;      /* Message containing To tag */
TknStrOSXL     *storedTag; /* tag rcvd in incoming msstored in call leg */
TknStrOSXL     *rcvdTag;   /* tag rcvd in incoming msg */
#endif
{
   
   TRC2(soCmSaveRemoteTag);

   if ((storedTag->pres == NOTPRSNT) &&
       (rcvdTag != NULLP))
   {
     if (soUtlCpyTknStrOSXL(storedTag, rcvdTag, NULLP) != ROK)
     {
       RETVALUE(RFAILED);
     }

     /* Update "To" address copy in call leg to include the tag */
     soUtlDelSoAddress(addr);

     if (soUtlCpySoAddress(addr, rcvdAddr, NULLP) != ROK)
     {
       RETVALUE(RFAILED);
     }

     RETVALUE(ROK);
   }

   /* Tag already present - ignore */
   RETVALUE(ROK);

} /* soCmSaveRemoteTag */


/*---- so018.201: Function to remote remote tag context ----*/

/*****************************************************************************
*
*       Fun:    soCmRemoveRemoteTag
*
*       Desc:   This function will remote context of remote tag stored
*               in call leg.
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_cm.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC  S16 soCmRemoveRemoteTag
(
SoEntCb   *ent,  /* Entity Cb   */
SoCLegCb  *cLeg  /* Call Leg Cb */
)
#else
PUBLIC  S16 soCmRemoveRemoteTag (ent, cLeg)
SoEntCb   *ent,  /* Entity Cb   */
SoCLegCb  *cLeg  /* Call Leg Cb */
#endif /* ANSI */
{  
   SoAddress   *addr;
   SoAddrParam *param;
   U16         cnt, i;
   Bool        tagFnd = FALSE;

   TRC2(soCmRemoveRemoteTag);

  /*------------- Remove remote tag for call leg ------------*/
   if (cLeg->storedHdrs.remoteTag.pres == PRSNT_NODEF)
     (Void) soUtlDelTknStrOSXL (&cLeg->storedHdrs.remoteTag);

  /*---------- Remove remote tag for remote address ---------*/
   addr = &cLeg->storedHdrs.remoteAddr;

   if (addr->addrParams.numComp.pres == NOTPRSNT)
      RETVALUE (ROK);

   for (cnt = 0; cnt < addr->addrParams.numComp.val; cnt++) 
   {
      param = addr->addrParams.addrParam[cnt];
      if ((param->addrParamType.pres != NOTPRSNT) && 
          (param->addrParamType.val == SO_ADDRPARAM_TAGPARAM))
      {  
         tagFnd = TRUE;
         break;
      }
   }

   if (tagFnd == TRUE)
   {
      /* Move entries in header sequence */
      for (i = cnt; i < (addr->addrParams.numComp.val - 1); i++)
         addr->addrParams.addrParam[i] = addr->addrParams.addrParam[i+1];;

     /* so029.201: Tag Address Paramater should be last element of *
      * the list.                                                  */
      addr->addrParams.addrParam[addr->addrParams.numComp.val-1] = param;

     /* so029.201: Delete the tag paramater within the SoAddrParam */
      if (param->t.tagParam.pres == PRSNT_NODEF)
         (Void) soUtlDelTknStrOSXL (&param->t.tagParam);

      soCmShrinkList((Void ***)&addr->addrParams.addrParam, sizeof(SoAddrParam),
                  &addr->addrParams.numComp, NULLP);

     /*- so025.201: If this was last parameter, set present flag to FALSE -*/
      if (addr->addrParams.numComp.val == 0)
          addr->addrParams.numComp.pres = NOTPRSNT;

   }

   RETVALUE (ROK);

} /* end of soCmRemoveRemoteTag */





/*****************************************************************************
*
*       Fun:    soCmpQVal
*
*       Desc:   This function compares Q values. 
*
*       Ret:    TRUE - If the first arg is > than the second.
*               FALSE - If ths first arg is <= the second arg.
*
*       Notes:  
*
*       File:   so_cl.c   
*
*****************************************************************************/
#ifdef ANSI
PUBLIC S16 soCmpQVal
(
SoQValue       *firstQVal,   /* First Q Value  */
SoQValue       *secondQVal,  /* Second Q Value */
Bool           *isGreater
)
#else
PUBLIC S16 soCmpQVal(firstQVal, secondQVal, isGreater)
SoQValue       *firstQVal;   /* First Q Value  */
SoQValue       *secondQVal;  /* Second Q Value */
Bool           *isGreater;
#endif /* ANSI */
{
   TRC2(soCmpQVal);

   if ((firstQVal->pres.pres != PRSNT_NODEF) ||
       (secondQVal->pres.pres != PRSNT_NODEF))
      RETVALUE(RFAILED);

   isGreater = FALSE;

   if (firstQVal->qVInt.pres == PRSNT_NODEF)
   {
      if (secondQVal->qVInt.pres == PRSNT_NODEF)
      {
         if (firstQVal->qVInt.val > secondQVal->qVInt.val)
         {
            *isGreater = TRUE;
            RETVALUE(ROK);
         }
      }
      else
      {
         *isGreater = TRUE;
         RETVALUE(ROK);
      }
   }
   else
   {
      if (secondQVal->qVInt.pres == PRSNT_NODEF)
      {
         *isGreater = FALSE;
         RETVALUE(ROK);
      }
   }

   if (firstQVal->qVFrac.pres == PRSNT_NODEF)
   {
      if (secondQVal->qVFrac.pres == PRSNT_NODEF)
      {
         if (firstQVal->qVFrac.val > secondQVal->qVFrac.val)
         {
            *isGreater = TRUE;
            RETVALUE(ROK);
         }
      }
      else
      {
         *isGreater = TRUE;
         RETVALUE(ROK);
      }
   }
   else
   {
      if (secondQVal->qVFrac.pres == PRSNT_NODEF)
      {
         *isGreater = FALSE;
         RETVALUE(ROK);
      }
   }
   
   RETVALUE(ROK);

} /* end of soCmpQVal */

/* so020.201: New function to compare strings in case insensitive manner */
/*
*
*       Fun:   soCmStrcasecmp
*
*       Desc:  common primitive to compare a contiguous string of characters
*              terminated by the '\0' character.
*
*              when strcasecmp is available, it uses that. otherwise, it
*              compares the strings using a for loop.
*
*              The following is the "strcasecmp" description from the SunOS 5.8
*              man-page. soCmStrcasecmp follows this.
*
*              strcasecmp(), strncasecmp()
*              The  strcasecmp()  and  strncasecmp()  functions  are  case-
*              insensitive  versions  of   strcmp()  and  strncmp() respec-
*              tively, described below.  They assume  the  ASCII  character
*              set  and ignore differences in case when comparing lower and
*              upper case characters.
*
*       Notes: None
*
*       File:  so_cm.c
*
*/
#ifdef ANSI
PUBLIC S16 soCmStrcasecmp
(
CONSTANT U8 *s1,
CONSTANT U8 *s2
)
#else
PUBLIC S16 soCmStrcasecmp (s1, s2)
CONSTANT U8 *s1;
CONSTANT U8 *s2;
#endif
{
#if (STRCMP_AVAIL)
   RETVALUE(strcasecmp((CONSTANT S8 *)s1, (CONSTANT S8 *)s2));
#else   /* STRCMP_AVAIL */
  
   S32 UpperVsLowerDiff;

   UpperVsLowerDiff = 'a' - 'A';

   while (*s1 && *s2)
   {
      if (*s1 >= 'A' && *s1 <= 'Z')
      {
         if (*s2 >= 'A' && *s2 <= 'Z')
         {
            /* Both the values are in upper case, we can compare them directly */
            if (*s1 ^ *s2)
               RETVALUE(*s1 - *s2);
         }
         else 
         {
            /* S1 is in upper case while S2 is in lower case 
               make S1 in lower case and compare */
            if ((*s1 + UpperVsLowerDiff ) ^ *s2)
               RETVALUE((*s1 + UpperVsLowerDiff ) - *s2);
         }
      }
      else
      {
         if (*s2 >= 'A' && *s2 <= 'Z')
         {
            /* S2 is in upper case while S1 is in lower case 
               make S2 in lower case and compare */
            if (*s1 ^ (*s2 + UpperVsLowerDiff ) ) 
               RETVALUE (*s1 - (*s2 + UpperVsLowerDiff ) );
         }
         else 
         {
            /* Both the values are in lower case, we can compare them directly */
            if (*s1 ^ *s2)
               RETVALUE(*s1 - *s2);
         }
      }

      s1++;
      s2++;
   }
   RETVALUE(0);
   
#endif      /* strcasecmp is not available */

} /* end of soCmStrcasecmp */



/********************************************************************30**

         End of file:     so_cm.c@@/main/6 - Tue Apr 20 12:45:59 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************70**

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/6      ---     ms   1. Release for 2.1.
/main/6+ so001.201   pk   1. Changed valuesize of array in FilterURI 
                             function to 9.
                          2. Removed Miscellaneous patch related 
                             comments.                    
/main/6+ so006.201   up   1. Check for the case when port is absent in 
                             both the fields.
/main/6+ so012.201   ps   1. Added response status code 491.
/main/6+ so016.201   ad   1. Null pointer check.
/main/6+ so018.201   ps   1. New funciton  to  remove  remote tag context
                             from call leg.
/main/6+ so019.201   sg   1. Change to fix the compile warning 
/main/6+ so020.201   sg   1. Corrected the misspelling of extension 
                     ss   2. New function for case insensitive comparison
/main/6+ so023.201   ad   1. To generate "To" tag without CLEG
/main/6+ so025.201   ps   1. Reset all parameters of numComp field 
/main/6+ so029.201   ps   1. Deletion of tag parameter before calling
                             shrinkList() function.
/main/6+ so031.201   aj   1. Check the state of the SSAP before selecting
/main/6+ so035.201   ng   1. Check for default port 5061 in case of TLS.(ab)
/main/6+ so036.201   ng   1. Changes for SO_CALEA
/main/6+ so038.201   ng   1. In soCmChkDomain, For tel URI return ok if 
                             hostport is not present in request URI
/main/6+ so038.201   ng   1. Replaced with macro to check for transport - UDP 
                              and priority UDP
/main/6+ so041.201   aj   1. Added the ShrinkList in case of failure in memory
                             requirement. 
*********************************************************************91*/
