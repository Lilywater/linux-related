/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SIP - external - message activation

     Type:    C source file

     Desc:    Functions required for scheduling and initialization.

     File:    so_ex_ms.c

     Sid:      so_ex_ms.c@@/main/4 - Tue Apr 20 12:46:37 2004

     Prg:     wvdl

*********************************************************************21*/



/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lso.h"           /* Layer management, SIP           */
#include "cst.h"           /* Compression module defines      */
#include "sot.h"           /* SOT interface defines           */
#include "so.h"            /* SIP layer defines               */
#include "so_trans.h"      /* Transaction module defines      */
#include "so_err.h"        /* SIP error defines               */
#include "so_cm.h"         /* SIP layer utility functions     */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lso.x"           /* Layer management SIP            */
#include "cst.x"           /* Compression module structure    */
#include "sot.x"           /* SOT interface defines           */
#include "so_tcm.x"        /* Transport module structures     */
#include "so.x"            /* SIP layer structures            */
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* SIP layer utility functions     */
#include "so_cm.x"         /* SIP layer common functions      */
#include "so_dns.x"        /* SIP DNS library                 */
#include "so_ed.x"         /* SIP multi-thread ED             */




/* public routines */

/*
*
*       Fun:    activate task
*
*       Desc:   Processes received events from the SIP interfaces.
*               Primitives are unpacked and the correct functions are called.
*
*       Ret:    ROK  -    ok
*               RFAILED - failed
*
*       Notes:  This is only used for dispatching to the unpacking routines.
*               If tightly coupled then we should never be in this file.
*
*       File:   so_ex_ms.c
*
*/
#ifdef ANSI
PUBLIC S16 soActvTsk
(
Pst    *pst,                /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 soActvTsk(pst, mBuf)
Pst    *pst;                /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   /* local variables */
   S16         ret;           /* return code */
   Mem         sMem;          /* mem block passed to unpacking code */
   S16         maxBlockSize;  /* maximum block size */
   
   TRC2(soActvTsk); 
   
   ret         = ROK;
   sMem.region = soCb.init.region;
   sMem.pool   = soCb.init.pool;                         

   maxBlockSize = soCb.cfg.maxBlkSize;

   switch(pst->srcEnt)
   {
#ifdef LCSOLIHIT
      case ENTHI:
         switch(pst->event)
         {
            /* loosely coupled lower interface */
            case EVTHITBNDCFM:                  /* bind confirm */
               ret = cmUnpkHitBndCfm(SoLiHitBndCfm, pst, mBuf);
               break;
            case EVTHITCONIND:                  /* connection indication */
               ret = cmUnpkHitConInd(SoLiHitConInd, pst, mBuf);
               break;
            case EVTHITCONCFM:                  /* connection confirm */
               ret = cmUnpkHitConCfm(SoLiHitConCfm, pst, mBuf);
               break;
            case EVTHITFLCIND:                  /* flow control indication */
               ret = cmUnpkHitFlcInd(SoLiHitFlcInd, pst, mBuf);
               break;
            case EVTHITDATIND:                  /* Data indication */
               ret = cmUnpkHitDatInd(SoLiHitDatInd, pst, mBuf);
               break;
            case EVTHITUDATIND:                 /* Unit Data indication */
               ret = cmUnpkHitUDatInd(SoLiHitUDatInd, pst, mBuf);
               break;
            case EVTHITDISCIND:                 /* disconnect indication */
               ret = cmUnpkHitDiscInd(SoLiHitDiscInd, pst, mBuf);
               break;
            case EVTHITDISCCFM:                 /* disconnect indication */
               ret = cmUnpkHitDiscCfm(SoLiHitDiscCfm, pst, mBuf);
               break;
            default:
               /* should hopefully never get here */
               SPutMsg(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
               SOLOGERROR(ERRCLS_DEBUG, ESO090, pst->event,
                          "soActvTsk: Invalid event");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
               ret = RFAILED;
               break;
         }
         break;
#endif /* LCSOLIHIT */

#if (defined(LCSOUISOT) || defined(LWLCSOUISOT))         
      case ENTSV:
         switch(pst->event)
         {
            /* loosely coupled upper interface */
            case EVTSOTBNDREQ:                  /* bind request */
               ret = cmUnpkSotBndReq(SoUiSotBndReq, pst, mBuf);
               break;
            case EVTSOTUBNDREQ:                 /* Unbind request */
               ret = cmUnpkSotUbndReq(SoUiSotUbndReq, pst, mBuf);
               break;
            case EVTSOTCIMREQ:                  /* CIM request */
               ret = cmUnpkSotCIMReq(SoUiSotCIMReq, pst, mBuf,&sMem,
                                     maxBlockSize);
               break;
            case EVTSOTCIMRSP:                  /* CIM response */
               ret = cmUnpkSotCIMRsp(SoUiSotCIMRsp, pst, mBuf,&sMem,
                                     maxBlockSize);
               break;
            case EVTSOTCONREQ:                  /* connection request */
               ret = cmUnpkSotConReq(SoUiSotConReq, pst, mBuf,&sMem,
                                     maxBlockSize);
               break;
            case EVTSOTCONRSP:                  /* connection response */
               ret = cmUnpkSotConRsp(SoUiSotConRsp, pst, mBuf,&sMem,
                                     maxBlockSize);
               break;
            case EVTSOTCNSTREQ:                 /* connection status request */
               ret = cmUnpkSotCnStReq(SoUiSotCnStReq, pst, mBuf,&sMem,
                                      maxBlockSize);
               break;
            case EVTSOTRELREQ:                  /* release request */
               ret = cmUnpkSotRelReq(SoUiSotRelReq, pst, mBuf,&sMem,
                                     maxBlockSize);
               break;
            case EVTSOTRELRSP:                  /* release response */
               ret = cmUnpkSotRelRsp(SoUiSotRelRsp, pst, mBuf,&sMem,
                                     maxBlockSize);
               break;
            case EVTSOTMODREQ:                  /* modify request */
               ret = cmUnpkSotModReq(SoUiSotModReq, pst, mBuf,&sMem,
                                     maxBlockSize);
               break;
            case EVTSOTMODRSP:                  /* nodify response */
               ret = cmUnpkSotModRsp(SoUiSotModRsp, pst, mBuf,&sMem,
                                     maxBlockSize);
               break;
            case EVTSOTCAMREQ:
               ret = cmUnpkSotCAMReq(SoUiSotCAMReq, pst, mBuf, &sMem,
                                     maxBlockSize);
               break;
            case EVTSOTCAMRSP:
               ret = cmUnpkSotCAMRsp(SoUiSotCAMRsp, pst, mBuf, &sMem,
                                     maxBlockSize);
               break;

#ifndef SO_REL_1_2_INF
            case EVTSOTACKREQ:
               ret = cmUnpkSotAckReq(SoUiSotAckReq, pst, mBuf, &sMem,
                                     maxBlockSize);
               break;

            case EVTSOTCANCELREQ:
               ret = cmUnpkSotCancelReq(SoUiSotCancelReq, pst, mBuf, &sMem,
                                     maxBlockSize);
               break;
#ifdef SO_UA
            case EVTSOTAUDITREQ:
               ret = cmUnpkSotAuditReq(SoUiSotAuditReq, pst, mBuf, &sMem,
                                     maxBlockSize);
               break;
#endif /* SO_UA */
#endif

            default:
               /* should hopefully never get here */
               SPutMsg(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
               SOLOGERROR(ERRCLS_DEBUG, ESO091, pst->event,
                          "soActvTsk: Invalid event");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
               ret = RFAILED;
               break;
         }
         break;
#endif /* LCSOUISOT or LWLCSOUISOT */

#ifdef LCSMSOMILSO
      case ENTSM:
         switch(pst->event)
         {
            /* loosely coupled layer manager interface */
            case EVTLSOCFGREQ:                  /* configuration request */
               ret = cmUnpkLsoCfgReq(SoMiLsoCfgReq, pst, mBuf);
               break;
            case EVTLSOCNTRLREQ:                /* control request */
               ret = cmUnpkLsoCntrlReq(SoMiLsoCntrlReq, pst, mBuf);
               break;
            case EVTLSOSTAREQ:                  /* status request */
               ret = cmUnpkLsoStaReq(SoMiLsoStaReq, pst, mBuf);
               break;
            case EVTLSOSTSREQ:                  /* statistics request */
               ret = cmUnpkLsoStsReq(SoMiLsoStsReq, pst, mBuf);
               break;
#ifdef LSO_ACNT
            /* so006.201: Fixed compilation error */
            case EVTLSOACNTREQ:                 /* accounting request */
            {
               /* so001.201: Fixed compilation error */
               CmMemListCp mPtr;
               /* Used for mem allocation, mostly for TknStrOSXL's */
               cmInitMemCp(&mPtr, maxBlockSize, &sMem);

               ret = cmUnpkLsoAcntReq(SoMiLsoAcntReq, pst, mBuf,&mPtr);
            }
               break;
#endif /* LSO_ACNT */
            
            default:
               /* should hopefully never get here */
               SPutMsg(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
               SOLOGERROR(ERRCLS_DEBUG, ESO092, pst->event,
                          "soActvTsk: Invalid event");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
               ret = RFAILED;
               break;
         }
         break;
#endif /* LCSMSOMILSO */

#ifdef SO_COMPRESS
      case ENTCS:
         switch (pst->event)
         {
            /* loosely coupled lower interface */
            case EVTCSTCOMPRESSCFM:
               ret = cmUnpkCstCompressCfm (SoLiCstCompressCfm, pst, mBuf);
               break;

            case EVTCSTDECOMPRESSCFM:
               ret = cmUnpkCstDecompressCfm (SoLiCstDecompressCfm, pst, mBuf);
               break;

            default:
               
               SPutMsg(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
               SOLOGERROR(ERRCLS_DEBUG, ESO093, pst->event,
                          "soActvTsk: Invalid event");
#endif
               ret = RFAILED;
               break;
         }
         break;
#endif

#ifdef FTHA
      case ENTSH:   /* events from system agent */
         switch (pst->event)
         {
            case EVTSHTCNTRLREQ:            /* system agent control request */
               /* call unpacking function */
               cmUnpkShtCntrlReq(SoMiShtCntrlReq, pst, mBuf);
               break;

            default:
               SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                         __FILE__, __LINE__, ERRCLS_INT_PAR, ESO094,
                         (ErrVal) pst->event, 
                         "soActvTsk: Invalid event from ENTSH");
               SPutMsg(mBuf);
               break;
         }
         break;
#endif /* FTHA */

#ifdef SO_ABNF_MT_LIB
      case ENTSO:
         switch (pst->event)
         {
            case EVTMEDENCREQ:          
               /* This message is for ED Instances */
               ret = cmUnpkMedEncReq(soRcvEncodeMsgReq, pst, mBuf);
               break;
            case EVTMEDDECREQ:          
               /* This message is for ED Instances */
               ret = cmUnpkMedDecReq(soRcvDecodeMsgReq, pst, mBuf);
               break;
            case EVTMEDENCCFM:          
               /* Encode cfm from ED */
               ret = cmUnpkMedEncCfm(soRcvEncodeMsgCfm, pst, mBuf);
               break;
            case EVTMEDDECCFM:          
               /* decode cfm from ED */
               ret = cmUnpkMedDecCfm(soRcvDecodeMsgCfm, pst, mBuf);
               break;
            default:
               SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                         __FILE__, __LINE__, ERRCLS_INT_PAR, ESO095,
                         (ErrVal) pst->event, 
                         "soActvTsk: Invalid event from ENTSO");
               SPutMsg(mBuf);
               break;
         }
         break;
#endif /* SO_ABNF_MT_LIB */

      default:
         /* should hopefully never get here */
         SPutMsg(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO096, pst->event,
                    "soActvTsk: Invalid event");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         ret = RFAILED;
         break;
   } /* switch */

   SExitTsk();
   RETVALUE(ret);
} /* soActvTsk */
      

/********************************************************************30**

        End of file:     so_ex_ms.c@@/main/4 - Tue Apr 20 12:46:37 2004

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---      ms  1. Release for 2.1.
/main/4+    so001.201 up  1. Fixed compilation error
/main/4+    so006.201 up  1. Fixed compilation error
*********************************************************************91*/
