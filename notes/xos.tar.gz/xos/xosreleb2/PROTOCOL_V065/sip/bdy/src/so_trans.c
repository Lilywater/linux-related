/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SIP - external interface - portable

     Type:    C source file

     Desc:    Transaction layer 

     File:    so_trans.c

     Sid:      so_trans.c@@/main/2 - Tue Apr 20 12:47:16 2004

     Prg:     ps 

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "so.h"            /* SIP layer defines               */
#include "so_trans.h"      /* Transaction module defines      */
#include "so_err.h"        /* SIP error defines               */
#include "so_cm.h"         /* SIP layer utility functions     */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lso.x"           /* Layer management SIP            */
#include "sot.x"           /* SOT interface defines           */
#include "so_tcm.x"        /* Transport module structures     */
#include "so.x"            /* SIP layer structures            */
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* SIP layer utility functions     */
#include "so_cm.x"         /* SIP layer common functions      */
#include "so_dns.x"        /* SIP DNS library                 */

#ifdef SO_UA

#define SSAP  ( ((SoCLegCb *)transCb->cLeg) ?                 \
                (((SoCLegCb *)transCb->cLeg)->call->ssapCb) : \
                (NULLP) ) 

/*-------------------- PRIVATE Function Declaration ------------------------*/

/*------- INVITE Client -------*/
PRIVATE S16 soTxnInvClientFsmT0S1 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvClientFsmT1S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvClientFsmT1S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvClientFsmT2S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvClientFsmT2S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvClientFsmT3S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvClientFsmT3S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvClientFsmT3S4 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvClientFsmT4S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvClientFsmT5S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvClientFsmT6S4 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvClientFsmT7S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt));
PRIVATE S16 soTxnInvClientFsmT7S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt));
PRIVATE S16 soTxnInvClientError   ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 

/*----- NON INVITE Client -----*/
PRIVATE S16 soTxnNonInvClientFsmT0S1 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvClientFsmT1S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvClientFsmT1S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvClientFsmT2S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvClientFsmT2S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvClientFsmT2S4 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvClientFsmT3S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvClientFsmT3S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvClientFsmT4S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvClientFsmT4S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvClientFsmT5S4 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvClientError   ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 


/*------- INVITE Server -------*/
PRIVATE S16 soTxnInvServerFsmT0S1 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerFsmT0S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerFsmT0S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerFsmT0S4 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerFsmT0S5 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerFsmT1S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerFsmT2S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerFsmT3S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerFsmT4S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerFsmT5S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerFsmT5S4 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerFsmT6S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerFsmT7S4 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerFsmT8S5 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnInvServerError   ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 


/*----- NON INVITE Server -----*/
PRIVATE S16 soTxnNonInvServerFsmT0S1 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvServerFsmT0S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvServerFsmT0S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvServerFsmT0S4 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvServerFsmT1S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvServerFsmT1S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvServerFsmT2S2 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvServerFsmT2S3 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvServerFsmT3S4 ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 
PRIVATE S16 soTxnNonInvServerError   ARGS ((SoTransCb *transCb, SoEvnt *evnt)); 


/*---------- Others -----------*/
PRIVATE S16  soTxnFindBranchId        ARGS((SoVia *via,  TknStrOSXL **viaBranch)); 
PRIVATE S16  soTxnUacUpdateTransCb    ARGS((SoTransCb *transCb, SoEvnt *request));
PRIVATE S16  soTxnUasUpdateTransCb    ARGS((SoTransCb *transCb, SoEvnt *request));
PRIVATE S16  soTxnProcess3261BranchId ARGS((SoTransCb *transCb, SoEvnt *request));
PRIVATE S16   soTxnSendAck            ARGS((SoTransCb *transCb, SoEvnt *ackEvnt));
PRIVATE S16   soTxnGenAck             ARGS((SoTransCb *transCb, 
                                            SoEvnt    *response,
                                            SoEvnt    **ackEvnt));

PRIVATE Void soTxnDeleteTransFromDiag ARGS((SoTransCb  *transCb)); 



PRIVATE  SoTxnInvClientFsm soTxnInvClientFsm[/* No Of Trigger */]
                                     [SO_TRANS_MAX_CLIENT_STATES] = 
{
  { /* SO_TRANS_REQ_FROM_USER Invite Request From User */
      soTxnInvClientFsmT0S1, /* SO_TRANS_CLIENT_IDLE       */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_CALLING    */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  },
  { /* SO_TRANS_1XX_FROM_PEER  */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_IDLE       */
      soTxnInvClientFsmT1S2, /* SO_TRANS_CLIENT_CALLING    */
      soTxnInvClientFsmT1S3, /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  },
  { /* SO_TRANS_2XX_FROM_PEER */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_IDLE       */
      soTxnInvClientFsmT2S2, /* SO_TRANS_CLIENT_CALLING    */
      soTxnInvClientFsmT2S3, /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  },
  { /* SO_TRANS_3_6XX_FROM_PEER */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_IDLE       */
      soTxnInvClientFsmT3S2, /* SO_TRANS_CLIENT_CALLING    */
      soTxnInvClientFsmT3S3, /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnInvClientFsmT3S4, /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  },
  { /* SO_TRANS_TIMER_A_EXPIRES */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_IDLE       */
      soTxnInvClientFsmT4S2, /* SO_TRANS_CLIENT_CALLING    */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  },
  { /* SO_TRANS_TIMER_B_EXPIRES */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_IDLE       */
      soTxnInvClientFsmT5S2, /* SO_TRANS_CLIENT_CALLING    */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  },
  { /* SO_TRANS_TIMER_D_EXPIRES */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_IDLE       */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_CALLING    */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnInvClientFsmT6S4, /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  },
  { /* SO_TRANS_TIMER_NAT_EXPIRES */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_IDLE       */
      soTxnInvClientFsmT7S2, /* SO_TRANS_CLIENT_CALLING    */
      soTxnInvClientFsmT7S3, /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnInvClientError,   /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  }
};



PRIVATE CONSTANT SoTxnNonInvClientFsm soTxnNonInvClientFsm[/* No Of Trigger */]
                                                 [SO_TRANS_MAX_CLIENT_STATES] =
{
  { /* SO_TRANS_REQ_FROM_USER Invite Request From User */
      soTxnNonInvClientFsmT0S1, /* SO_TRANS_CLIENT_IDLE       */
      soTxnNonInvClientError,   /* SO_TRANS_CLIENT_TRYING     */
      soTxnNonInvClientError,   /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnNonInvClientError,   /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnNonInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  },
  { /* SO_TRANS_1XX_FROM_PEER  */
      soTxnNonInvClientError,   /* SO_TRANS_CLIENT_IDLE       */
      soTxnNonInvClientFsmT1S2, /* SO_TRANS_CLIENT_TRYING     */
      soTxnNonInvClientFsmT1S3, /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnNonInvClientError,   /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnNonInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  },
  { /* SO_TRANS_2_6XX_FROM_PEER */
      soTxnNonInvClientError,   /* SO_TRANS_CLIENT_IDLE       */
      soTxnNonInvClientFsmT2S2, /* SO_TRANS_CLIENT_TRYING     */
      soTxnNonInvClientFsmT2S3, /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnNonInvClientFsmT2S4, /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnNonInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  },
  { /* SO_TRANS_TIMER_E_EXPIRES */
      soTxnNonInvClientError,   /* SO_TRANS_CLIENT_IDLE       */
      soTxnNonInvClientFsmT3S2, /* SO_TRANS_CLIENT_TRYING     */
      soTxnNonInvClientFsmT3S3, /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnNonInvClientError,   /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnNonInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  },
  { /* SO_TRANS_TIMER_F_EXPIRES */
      soTxnNonInvClientError,   /* SO_TRANS_CLIENT_IDLE       */
      soTxnNonInvClientFsmT4S2, /* SO_TRANS_CLIENT_TRYING     */
      soTxnNonInvClientFsmT4S3, /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnNonInvClientError,   /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnNonInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  },
  { /* SO_TRANS_TIMER_K_EXPIRES */
      soTxnNonInvClientError,   /* SO_TRANS_CLIENT_IDLE       */
      soTxnNonInvClientError,   /* SO_TRANS_CLIENT_TRYING     */
      soTxnNonInvClientError,   /* SO_TRANS_CLIENT_PROCEEDING */
      soTxnNonInvClientFsmT5S4, /* SO_TRANS_CLIENT_COMPLETED  */
      soTxnNonInvClientError    /* SO_TRANS_CLIENT_TERMINATED */
  }
};

/*
 * so017.201: In our implementation we have new state in called 
 *  "After 2xx".  Please note that this state is not defined in
 *  RFC 3261. We have introduced  this state to make our dialog
 *  matching rules mush simpler.
 *  Before introducing this state INVITE server transaction us-
 *  ed to terminate after sending 2xx response.With this change
 *  INVITE server  transaction will continue to exist for 64*t1
 *  seconds after  sending 2xx response. With that we intend to
 *  catch all retransmitted  INVITE received after 2xx response
 *  in transaction state machine itself.
 */

/*-- so017.201: TimerJ applicable for both Inv/NonInv Transaction --*/

PRIVATE CONSTANT SoTxnInvServerFsm soTxnInvServerFsm[/* No Of Trigger */]
                                             [SO_TRANS_MAX_INV_SERVER_STATES] = 
{
  { /* SO_TRANS_REQ_FROM_PEER Invite Request From Peer */
      soTxnInvServerFsmT0S1, /* SO_TRANS_INV_SERVER_IDLE       */
      soTxnInvServerFsmT0S2, /* SO_TRANS_INV_SERVER_PROCEEDING */
      soTxnInvServerFsmT0S3, /* SO_TRANS_INV_SERVER_COMPLETED  */
      soTxnInvServerFsmT0S4, /* SO_TRANS_INV_SERVER_CONFIRMED  */
      soTxnInvServerFsmT0S5, /* SO_TRANS_INV_SERVER_AFTER_2XX  */
      soTxnInvServerError    /* SO_TRANS_INV_SERVER_TERMINATED */
  },
  { /* SO_TRANS_1XX_FROM_USER  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_IDLE       */
      soTxnInvServerFsmT1S2, /* SO_TRANS_INV_SERVER_PROCEEDING */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_COMPLETED  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_CONFIRMED  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_AFTER_2XX  */
      soTxnInvServerError    /* SO_TRANS_INV_SERVER_TERMINATED */
  },
  { /* SO_TRANS_TIMER_J_EXPIRES */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_IDLE       */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_PROCEEDING */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_COMPLETED  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_CONFIRMED  */
      soTxnInvServerFsmT8S5, /* SO_TRANS_INV_SERVER_AFTER_2XX  */
      soTxnInvServerError    /* SO_TRANS_INV_SERVER_TERMINATED */
  },
  { /* SO_TRANS_2XX_FROM_USER */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_IDLE       */
      soTxnInvServerFsmT2S2, /* SO_TRANS_INV_SERVER_PROCEEDING */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_COMPLETED  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_CONFIRMED  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_AFTER_2XX  */
      soTxnInvServerError    /* SO_TRANS_INV_SERVER_TERMINATED */
  },
  { /* SO_TRANS_3_6XX_FROM_USER */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_IDLE       */
      soTxnInvServerFsmT3S2, /* SO_TRANS_INV_SERVER_PROCEEDING */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_COMPLETED  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_CONFIRMED  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_AFTER_2XX  */
      soTxnInvServerError    /* SO_TRANS_INV_SERVER_TERMINATED */
  },
  { /* SO_TRANS_TIMER_G_EXPIRES */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_IDLE       */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_PROCEEDING */
      soTxnInvServerFsmT4S3, /* SO_TRANS_INV_SERVER_COMPLETED  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_CONFIRMED  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_AFTER_2XX  */
      soTxnInvServerError    /* SO_TRANS_INV_SERVER_TERMINATED */
  },
  { /* SO_TRANS_ACK_FROM_PEER */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_IDLE       */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_PROCEEDING */
      soTxnInvServerFsmT5S3, /* SO_TRANS_INV_SERVER_COMPLETED  */
      soTxnInvServerFsmT5S4, /* SO_TRANS_INV_SERVER_CONFIRMED  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_AFTER_2XX  */
      soTxnInvServerError    /* SO_TRANS_INV_SERVER_TERMINATED */
  },
  { /* SO_TRANS_TIMER_H_EXPIRES */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_IDLE       */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_PROCEEDING */
      soTxnInvServerFsmT6S3, /* SO_TRANS_INV_SERVER_COMPLETED  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_CONFIRMED  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_AFTER_2XX  */
      soTxnInvServerError    /* SO_TRANS_INV_SERVER_TERMINATED */
  },
  { /* SO_TRANS_TIMER_I_EXPIRES */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_IDLE       */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_PROCEEDING */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_COMPLETED  */
      soTxnInvServerFsmT7S4, /* SO_TRANS_INV_SERVER_CONFIRMED  */
      soTxnInvServerError,   /* SO_TRANS_INV_SERVER_AFTER_2XX  */
      soTxnInvServerError    /* SO_TRANS_INV_SERVER_TERMINATED */
  }
};

/*-- so017.201: TimerJ applicable for both Inv/NonInv Transaction --*/

PRIVATE CONSTANT SoTxnNonInvServerFsm soTxnNonInvServerFsm[/* No Of Trigger */]
                                                 [SO_TRANS_MAX_NONINV_SERVER_STATES] = 
{
  { /* SO_TRANS_REQ_FROM_PEER */
      soTxnNonInvServerFsmT0S1, /* SO_TRANS_NON_INV_SERVER_IDLE       */
      soTxnNonInvServerFsmT0S2, /* SO_TRANS_NON_INV_SERVER_TRYING     */
      soTxnNonInvServerFsmT0S3, /* SO_TRANS_NON_INV_SERVER_PROCEEDING */
      soTxnNonInvServerFsmT0S4, /* SO_TRANS_NON_INV_SERVER_COMPLETED  */
      soTxnNonInvServerError    /* SO_TRANS_NON_INV_SERVER_TERMINATED */
  },
  { /* SO_TRANS_1XX_FROM_USER  */
      soTxnNonInvServerError,   /* SO_TRANS_NON_INV_SERVER_IDLE       */
      soTxnNonInvServerFsmT1S2, /* SO_TRANS_NON_INV_SERVER_TRYING     */
      soTxnNonInvServerFsmT1S3, /* SO_TRANS_NON_INV_SERVER_PROCEEDING */
      soTxnNonInvServerError,   /* SO_TRANS_NON_INV_SERVER_COMPLETED  */
      soTxnNonInvServerError    /* SO_TRANS_NON_INV_SERVER_TERMINATED */
  },
  { /* SO_TRANS_TIMER_J_EXPIRES */
      soTxnNonInvServerError,   /* SO_TRANS_NON_INV_SERVER_IDLE       */
      soTxnNonInvServerError,   /* SO_TRANS_NON_INV_SERVER_TRYING     */
      soTxnNonInvServerError,   /* SO_TRANS_NON_INV_SERVER_PROCEEDING */
      soTxnNonInvServerFsmT3S4, /* SO_TRANS_NON_INV_SERVER_COMPLETED  */
      soTxnNonInvServerError    /* SO_TRANS_NON_INV_SERVER_TERMINATED */
  },
  { /* SO_TRANS_2_6XX_FROM_USER */
      soTxnNonInvServerError,   /* SO_TRANS_NON_INV_SERVER_IDLE       */
      soTxnNonInvServerFsmT2S2, /* SO_TRANS_NON_INV_SERVER_TRYING     */
      soTxnNonInvServerFsmT2S3, /* SO_TRANS_NON_INV_SERVER_PROCEEDING */
      soTxnNonInvServerError,   /* SO_TRANS_NON_INV_SERVER_COMPLETED  */
      soTxnNonInvServerError    /* SO_TRANS_NON_INV_SERVER_TERMINATED */
  }
};

#define  CLEG  ((SoCLegCb *)transCb->cLeg)

/*------------ INTERFACE FUNCTIONS FOR DIALOG/CORE Layer -------------*/

/*
*
*       Fun:   soTxnUaCreateTrans
*
*       Desc:  This function is used by transaction user(dialog layer) to 
*              create transaction  control block. The transaction control
*              block is initialized and the user context is stored in the
*              control block. 
*
*       Ret:   If success, pointer to created transaction control block.
*              If failure, NULLP
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PUBLIC SoTransCb  *soTxnUaCreateTrans
(
SoEntCb       *entCb,       /* SIP Entity control block       */
U8            uaType,       /* User agent client or server    */
SoEvnt        *request,     /* SIP Request message to be sent */
PTR           cLeg,         /* Dialog layer's control block   */
SoUserCtxt    *userContext  /* Transacion user information    */
)
#else
PUBLIC SoTransCb  *soTxnUaCreateTrans (entCb, uaType, request, 
                                       cLeg,  userContext)
SoEntCb       *entCb;       /* SIP Entity control block       */
U8            uaType;       /* User agent client or server    */
SoEvnt        *request;     /* SIP Request message to be sent */
PTR           cLeg;         /* Dialog layer's control block   */
SoUserCtxt    *userContext; /* Transacion user information    */
#endif
{
    S16        ret;
    SoTransCb  *transCb;

    TRC2(soTxnUaCreateTrans);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (!entCb)
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO220, (ErrVal) 0, "soTxnUaCreateTrans: "
                 "Invalid parameter");
      RETVALUE (NULLP);
    }
#endif

    /*---- Allocate Transaction control block ----*/
      SOALLOC (&transCb, sizeof (SoTransCb))
      if (transCb == NULLP)
        RETVALUE (NULLP);

    /*-- Update TCB elements common to UAC/UAS ---*/
      transCb->entCb       = entCb;

    /*------ Save user context information -------*/
      if (userContext)
         cmMemcpy ((U8 *)&transCb->userContext, 
                   (U8 *)userContext, 
                   sizeof (SoUserCtxt));

    /*------ Save dialog layer control block -----*/
      transCb->cLeg = cLeg;

    /*-- Initialize info common for UAC and UAS --*/
      soCmInitTimer (&transCb->retxTmr);
      soCmInitTimer (&transCb->transTmr);
#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
      soCmInitTimer (&transCb->natTmr);
#endif

      soPrcInitTcmConn (&transCb->tcmConn, 
                        SO_TPT_TCMCONN_USER_TRANS,
                        (PTR) transCb);

    /*--- Update UAS/UAC specifoc information ----*/
      if (uaType == SO_UAC)
        ret = soTxnUacUpdateTransCb (transCb, request);

      else if (uaType == SO_UAS)
        ret = soTxnUasUpdateTransCb (transCb, request);

      if (ret != ROK)
      {
          soTxnDeleteTrans (transCb); transCb = NULLP;
          RETVALUE (NULLP);
      }

      SODBGP_SO (SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                "\n[TRANS ] TCB    Created => Call(%ld), " 
                "CallLeg(%lx), Trans(%lx)\n",
                ((SoCLegCb *)cLeg) ? ((SoCLegCb *)cLeg)->call->spConnId : 0,
                ((SoCLegCb *)cLeg) ? ((SoCLegCb *)cLeg)->legId : 0,
                transCb->transId));

      RETVALUE (transCb);
      
} /* End of Fn (soTxnUaCreateTrans) */



/*
*
*       Fun:   soTxnUaOutReq
*
*       Desc:  This function is used by transaction user(dialog layer) to
*              send request using client transaction. 
*              This function initiates the client (either invite or non-
*              invite transaction state machine.
*
*       Ret:   If success, return ROK
*              If failure, return SIP user related error code.
*
*       Notes: REQUEST EVENT STRUCTURE DELETION LOGIC
*              
*              Trasaction layer will delete event structure if any of the
*              following condition happens.
*              (1) When first response(i.e, response in calling or trying
*                  state) is received from peer. In such case transaction
*                  layer will delete event if  user has  NOT requested to
*                  save the event (by userContext->saveEvent)
*
*              Transaction layer will NOT delete event structure and pass
*              it back to user(soDlgErrInd) under following condition.
*              (2) Multithreaded encoder error.
*              (1) TCP/UDP connection failure.
*              (2) No response from peer (timer B or F fires).
*              (3) When response is received from peer but user has requ-
*                  ested to save the event (by userContext->saveEvent)
*
*              Event structure is also NOT deleted in case of this funct-
*              ion returns failure.
*
*              If the user has requested to save event structure, it will
*              be its reponsibility to delete event structure.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PUBLIC S16   soTxnUaOutReq
(
SoTransCb    *transCb,   /* Transaction control block                    */
CmTptAddr    *destAddr,  /* Destination IP-address/port to send request  */
U8           transport   /* TCP or UDP transport to be used              */
)
#else
PUBLIC S16   soTxnUaOutReq(transCb, destAddr, transport)
SoTransCb    *transCb;   /* Transaction control block                    */
CmTptAddr    *destAddr;  /* Destination IP-address/port to send request  */
U8           transport;  /* TCP or UDP transport to be used              */
#endif
{
    S16 ret;

    TRC2(soTxnUaOutReq);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && destAddr))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO221, (ErrVal) 0, "soTxnUaOutReq: "
                   "Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }
#endif

    /*--------------- Save Transport Information -----------------*/
      transCb->transport = transport;
      cmMemcpy ((U8 *)&transCb->destAddr, (U8 *)destAddr, sizeof (CmTptAddr));

    /*--------------- Save Transport Information -----------------*/

    /*--- Invoke Invite/Non-Invite State m/c to handle request ---*/
      if (transCb->transMethod == SOT_ET_INVITE)
         ret = soTxnInvClientFsm[SO_TRANS_REQ_FROM_USER]
                                [SO_TRANS_CLIENT_IDLE](transCb, NULLP);
      else
         ret = soTxnNonInvClientFsm[SO_TRANS_REQ_FROM_USER]
                                   [SO_TRANS_CLIENT_IDLE](transCb, NULLP);

      if (ret != ROK)
      {
       /*--- Caller will need response evnt in case of failure ---*/
          transCb->evnt = NULLP;

         /*--- Delete TCB ---*/
          soTxnDeleteTrans (transCb);
      }

      RETVALUE (ret);

} /* End of Fn (soTxnUaOutReq) */




/*
*
*       Fun:   soTxnUaOutRsp
*
*       Desc:  This function is used by transaction user(dialog layer) to
*              send response using server transaction. 
*              This function calls specific server (either invite or non-
*              invite) transaction state machine function.
*
*              This function will update "msg" parameter with encoded re-
*              sponse message in case of 2XX response for INVITE transac-
*              tion.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return SIP user related error code.
*
*       Notes: EVENT STRUCTURE DELETION LOGIC
*              
*              Trasaction layer will delete event structure in all cases.
*              In case of Multithreaded encoder, event structure will be
*              deleted  when encoder thread returns.
*
*              Only if this function  returns  failure (or multithreaded
*              encoder returns failure) caller  will  be responsible for 
*              event structure deletion.
*              
*       File:  so_trans.c
*
*/

#ifdef ANSI
PUBLIC S16   soTxnUaOutRsp
(
SoTransCb     *transCb,      /* Transaction control block         */
SoEvnt        *response,     /* SIP Response message to be sent   */
U8            responseClass, /* 1XX/2XX/3-6XX Response            */
SoUserCtxt    *userContext,  /* Transacion user information       */
PTR           cLeg,          /* Dialog layer's control block      */
Buffer        **msg          /* Encoded Response message (Updated)*/
)
#else
PUBLIC S16   soTxnUaOutRsp(transCb, response, responseClass, userContext, 
                           cLeg,    msg)
SoTransCb     *transCb;      /* Transaction control block         */
SoEvnt        *response;     /* SIP Response message to be sent   */
U8            responseClass; /* 1XX/2XX/3-6XX Response            */
SoUserCtxt    *userContext;  /* Transacion user information       */
PTR           cLeg;          /* Dialog layer's control block      */
Buffer        **msg;         /* Encoded Response message (Updated)*/
#endif
{
    S16   ret;
    Bool  deleteTrans;

    TRC2(soTxnUaOutRsp);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && response && msg))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO222, (ErrVal) 0, "soTxnUaOutRsp: "
                   "Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }
#endif

      *msg        = NULLP;
      deleteTrans = FALSE;

    /*--- Save user context in TCB ----*/
      if (userContext)
         cmMemcpy ((U8 *)&transCb->userContext, 
                   (U8 *)userContext, 
                   sizeof (SoUserCtxt));

    /* Save dialog layer control block */
      transCb->cLeg = (PTR) cLeg;

    /*- Save response event structure -*/
      transCb->evnt = response;

    /*- Invoke Invite/Non-Invite Server State m/c to handle response -*/
      if (transCb->transMethod == SOT_ET_INVITE)
      {
         /*---- Response for INVITE Server ----*/

           if (responseClass == SO_STACODE_TYPE_INFORM)     
           {
              /* 1xx Provisional Response      */
              ret = soTxnInvServerFsm[SO_TRANS_1XX_FROM_USER]
                                     [transCb->transState] (transCb, response);
              /* so010.201 : Fixing filling of mBuf         */
              /* so011.201 : Undo changes done in so010.201 */
              if (ret == ROK)
               /*  Provide caller with a copy of encoded 1XX message. */
                 ret = SAddMsgRef (transCb->retxMsg, soCb.init.region, 
                                   soCb.init.pool,   msg);
           }

           else if (responseClass == SO_STACODE_TYPE_SUCCESS)
           {
              /* 2xx Successful Final Response */
              ret = soTxnInvServerFsm[SO_TRANS_2XX_FROM_USER]
                                     [transCb->transState] (transCb, response);
              /*
               * so017.201:
               * Successfull sending of 2XX response to INVITE completes
               * the transaction functionality. Retransmission of 2XX r-
               * esponse is taken care by core layer. 
               * For UDP, in our implemenation, we keep invite server t-
               * ransaction for 64*t1 seconds to wait for any retransmi-
               * tted INVITE.
               *
               * Provide caller with the encoded 2XX message.
               */
               (*msg) = transCb->retxMsg; transCb->retxMsg = NULLP;

               if ((transCb->transport == LSO_TPTPROT_TCP) ||
                   (transCb->transport == LSO_TPTPROT_TLS_TCP))
                 deleteTrans = TRUE;
           }

           else
              /* 3-6xx failure Final Response  */
              ret = soTxnInvServerFsm[SO_TRANS_3_6XX_FROM_USER]
                                     [transCb->transState] (transCb, response);
      } /*-- Invite Response --*/
        
      else
      {
         /*--- Response for Non INVITE Server ---*/

           if (responseClass == SO_STACODE_TYPE_INFORM)     
              /* 1xx provisional Response */
              ret = soTxnNonInvServerFsm[SO_TRANS_1XX_FROM_USER]
                                     [transCb->transState] (transCb, response);

           else 
           {
              /*  2-6xx Final Response    */
              ret = soTxnNonInvServerFsm[SO_TRANS_2_6XX_FROM_USER]
                                     [transCb->transState] (transCb, response);
              /*
               * Successfull sending of 2XX response to NON-INVITE comp-
               * letes the transaction, if transport is TCP. So transac-
               * tion must be deleted.
               */
               if ((transCb->transport == LSO_TPTPROT_TCP) ||
                   (transCb->transport == LSO_TPTPROT_TLS_TCP))
                  deleteTrans = TRUE;
           }
      } /* Non-Invite Response */

      if (ret == SO_TPT_MULTI_THREADED_ENC)
      {
        /*
         * Encoding not finished YET. The rest of functionality for this
         * state will be done in the callback function.
         *
         * Callback function  must  also ensure  that event structure is 
         * getting deleted.
         */
         transCb->evnt = NULLP;

         RETVALUE (ROK);
      }

      else if (ret != ROK)
      {
         /* Calling entity will need response evnt in case of failure */
         /*--- so018.201: Save event structure for calling entity ----*/
         transCb->evnt = NULLP;

         /*--- Delete TCB ---*/
         soTxnDeleteTrans (transCb);

         RETVALUE (RFAILED);
      }

    /* 
     * Response message was successfully processed.  Now we  can  delete 
     * response event structure.
     */
      SO_TXN_DEL_EVENT (transCb, transCb->evnt);

      if (deleteTrans == TRUE)
        soTxnDeleteTrans (transCb);

     RETVALUE (ROK);

} /* End of Fn (soTxnUaOutRsp) */



/*
*
*       Fun:   soTxnDeleteTrans
*
*       Desc:  This function  is used by  various entities  to delete the
*              context of transaction. This function will remove TCB from
*              call leg link list and delete TCB.
*
*       Ret:   If success, ROK
*              If failure, RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PUBLIC Void  soTxnDeleteTrans
(
SoTransCb      *transCb           /* Transaction Control Block      */
)
#else
PUBLIC Void  soTxnDeleteTrans (transCb)
SoTransCb      *transCb;          /* Transaction Control Block      */
#endif
{

  SoCLegCb *cLegCb;
  S16      tmrEvnt;

    TRC2(soTxnDeleteTrans);

    cLegCb = (SoCLegCb *)transCb->cLeg;

#if (ERRCLASS & ERRCLS_DEBUG)
    if (!transCb)
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO223, (ErrVal) 0, "soTxnDeleteTrans: "
                 "Invalid parameter");
      RETVOID;
    }

    SODBGP_SO (SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
      "\n[TRANS ] TCB    Deleted => Call(%ld), CallLeg(%lx), Trans(%lx)\n",
      (cLegCb) ? cLegCb->call->spConnId : 0,
      (cLegCb) ? cLegCb->legId : 0,
        transCb->transId));

    SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*
     * If we know that TCB is present in link list of call
     * legCb, remove TCB from the list.
     */
     if (cLegCb)
         (Void) soDlgRmvTransContext (cLegCb, transCb);


    /*------------ Delete branch ID paraemter -----------*/
     soUtlDelTknStrOSXL (&transCb->branchId);

    /*---- Delete encoded message buffer, if present ----*/
     SO_TXN_DEL_MBUF (transCb->retxMsg);

    /*------ Delete event structure, if present ---------*/
     SO_TXN_DEL_EVENT (transCb, transCb->evnt);

#ifdef SO_EVENT     
    /*--- so026.201: Delete subscription CB reference ---*/
     SO_TXN_DEL_SUBS_REF (transCb);
#endif

    /*-------- Delete VIA header stored in TCB ----------*/
     soUtlDelSoVia (&transCb->via);      

    /*------- Delete Request URI stored in TCB ----------*/
     soUtlDelSoAddrSpec (&transCb->origReqURI);

    /*------- Delete Route header stored in TCB ---------*/
     soUtlDelSoRoute (&transCb->route);

    /* Delete the Method parametr if it was of
     *  type extension method. 
     */
    soUtlDelTknStrOSXL (&transCb->extMethod);

    /* 
     * Remove TCB reference from TCP/UDP Server and Client 
     * connection control block list.
     */
     soPrcDelTcmConn (&transCb->tcmConn);

    /*---- Delete TCB entry from EntityCb hash list -----*/
     if ((transCb->transType == SO_TRANS_INV_CLIENT) ||
         (transCb->transType == SO_TRANS_NON_INV_CLIENT))
        /*------ Release from UAC Transaction List ------*/
        cmHashListDelete (&transCb->entCb->clientTransLst,
                          (PTR) transCb);
     else
        /*------ Release from UAS Transaction List ------*/
        cmHashListDelete (&transCb->entCb->serverTransLst,
                          (PTR) transCb);

#ifdef SO_REL_1_2_INF
    /*---- Delete TCB entry from EntityCb hash list -----*/
     cmHashListDelete (&transCb->entCb->transLst,
                       (PTR) transCb);
#endif

   /* 
    * Stop retransmission timers. 
    * NOTE: This statement will stop TIMER A/E/G.
    */
     tmrEvnt = transCb->retxTmr.tmr.tmrEvnt;
     if (tmrEvnt != TMR_NONE)
     {
       soSchedTmr (transCb, transCb->retxTmr.tmr.tmrEvnt, TMR_STOP, NOTUSED);
     }

   /* 
    * Stop transaction timers. 
    * NOTE: This statement will stop TIMER B/D/F/K/H/I/J.
    */
     tmrEvnt = transCb->transTmr.tmr.tmrEvnt;
     if (tmrEvnt != TMR_NONE)
     {
       soSchedTmr (transCb, transCb->transTmr.tmr.tmrEvnt, TMR_STOP, NOTUSED);
     }

   /* 
    * Stop transaction NAT timer.
    */
#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
     tmrEvnt = transCb->natTmr.tmr.tmrEvnt;
     if (tmrEvnt != TMR_NONE)
     {
       soSchedTmr (transCb, transCb->natTmr.tmr.tmrEvnt, TMR_STOP, NOTUSED);
     }
#endif

    /*------ Delete DNS Query Context, if required ------*/
#ifdef SO_DNS
     SO_TXN_DEL_QUERYCB (transCb);
#endif

    /*- Finally, delete transaction control block (TCB) -*/
     SOFREE (transCb, sizeof (SoTransCb));

     RETVOID;

} /* End of Fn (soTxnDeleteTrans) */





/*------------- INTERFACE FUNCTIONS FOR TRANSPORT Layer --------------*/

/*
*
*       Fun:   soTxnUaIncReq
*
*       Desc:  This function is used by TRANSPORT Layer to pass request
*              message to transaction layer.
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: EVENT STRUCTURE DELETION LOGIC
*
*              If the function returns failure,calling entity should d-
*              elete the  request event structure. This event structure
*              will NOT be saved in the transaction Cb.
*              If the function returns success, either SIP user or tra-
*              nsaction should delete the event structure.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PUBLIC S16   soTxnUaIncReq
(
SoTransCb    *transCb,       /* Transaction control block         */
SoEvnt       *request,       /* SIP Request message received      */
SoTcmConn    *tcmConn        /* TCP/UDP connection information    */
)
#else
PUBLIC S16   soTxnUaIncReq(transCb, request, tcmConn)
SoTransCb    *transCb;       /* Transaction control block         */
SoEvnt       *request;       /* SIP Request message received      */
SoTcmConn    *tcmConn;       /* TCP/UDP connection information    */
#endif
{
    S16 ret;

    TRC2(soTxnUaIncReq);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && request && tcmConn))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO224, (ErrVal) 0, "soTxnUaIncReq: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }
#endif

    /*------ Copy TCP/UDP connection information in TCB ------*/
      soPrcUpdateTcmConn (&transCb->tcmConn,  tcmConn->clientCb, 
                          tcmConn->serverCb);
      transCb->transport = tcmConn->serverCb->tptProt;

    /*- Invoke Invite/Non-Invite State m/c to handle request -*/

      if (SO_CMP_TKN_LIT (&request->eventType, SOT_ET_INVITE))
         /*--- First/Retransmitted INV Request Messsage --*/
         ret = soTxnInvServerFsm[SO_TRANS_REQ_FROM_PEER]
                                [transCb->transState] (transCb, request);

      else if (SO_CMP_TKN_LIT (&request->eventType, SOT_ET_ACK))
         /*--- ACK received for NON 2XX Final Response ---*/
         ret = soTxnInvServerFsm[SO_TRANS_ACK_FROM_PEER]
                                [transCb->transState] (transCb, request);

      else
         /*- First/Retransmitted NonINV Request Messsage -*/
         ret = soTxnNonInvServerFsm[SO_TRANS_REQ_FROM_PEER]
                                   [transCb->transState] (transCb, request);

      RETVALUE (ret);

} /* End of Fn (soTxnUaIncReq) */




/*
*
*       Fun:   soTxnUaIncRsp
*
*       Desc:  This function is used by TRANSPORT Layer to pass response
*              message to transaction layer.
*              This function passed  the  response to appropriate client 
*              (either invite or non-invite)  transaction  state machine.
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: EVENT STRUCTURE DELETION LOGIC
*              
*              If the function returns failure,calling entity should d-
*              elete the response event structure. This event structure
*              will NOT be saved in the transaction Cb.
*              If the function returns success, either SIP user or tra-
*              nsaction layer will delete the event structure.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PUBLIC S16   soTxnUaIncRsp
(
SoTransCb    *transCb,       /* Transaction control block            */
SoEvnt       *response       /* SIP Response message received        */
)
#else
PUBLIC S16   soTxnUaIncRsp(transCb, response)
SoTransCb    *transCb;       /* Transaction control block            */
SoEvnt       *response;      /* SIP Response message received        */
#endif
{
    S16     ret;
    U16     responseClass;

    TRC2(soTxnUaIncRsp);

    ret = ROK;
    responseClass = 0;

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && response))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO225, (ErrVal) 0, "soTxnUaIncRsp: "
                   "Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }
#endif

    /*---- Update transation ID in Response Event ----*/
      response->transId = transCb->transId;

    /*----- Find Response Class (1xx/2xx/3-6xx) ------*/
      responseClass = response->t.response.statusLine.statusCode.val/100;

    /*--- Invoke Invite/Non-Invite Client State m/c to handle response ---*/
      if (transCb->transMethod == SOT_ET_INVITE)
      {
         /*---- Response for INVITE Client ----*/

           if (responseClass == SO_STACODE_TYPE_INFORM)     
              /* 1xx Provisional Response      */
              ret = soTxnInvClientFsm[SO_TRANS_1XX_FROM_PEER]
                                     [transCb->transState] (transCb, response);

           else if (responseClass == SO_STACODE_TYPE_SUCCESS)
           {
              /* 2xx Successful Final Response */
              ret = soTxnInvClientFsm[SO_TRANS_2XX_FROM_PEER]
                                     [transCb->transState] (transCb, response);
           }
           else
           {
              /* 3-6xx failure Final Response  */
              ret = soTxnInvClientFsm[SO_TRANS_3_6XX_FROM_PEER]
                                     [transCb->transState] (transCb, response);
           }
      }

      else
      {
         /*--- Response for Non INVITE Client ---*/

           if (responseClass == SO_STACODE_TYPE_INFORM)     
              /* 1xx provisional Response */
              ret = soTxnNonInvClientFsm[SO_TRANS_1XX_FROM_PEER]
                                     [transCb->transState] (transCb, response);

           else 
              /*  2-6xx Final Response    */
              ret = soTxnNonInvClientFsm[SO_TRANS_2_6XX_FROM_PEER]
                                     [transCb->transState] (transCb, response);
      }

      RETVALUE (ret);

} /* End of Fn (soTxnUaIncRsp) */



/*
*
*       Fun:   soTxnEncodeReqCallBack
*
*       Desc:  This function is called by Transport Layer as callback
*              in case of Multi Threaded encoder.Transport layer will
*              call this function ones request encoding is completed.
*
*       Ret:   If success, return ROK
*              If failure, return RFAILED
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PUBLIC Void  soTxnEncodeReqCallBack 
(
PTR          residePtr,      /* Transaction control block             */
U8           transport,      /* Selected Transport protocol (TCP/UDP) */
Buffer       *mBuf,          /* Encoded Request Message               */
Bool         success         /* Was Encoding Successful!              */
)
#else
PUBLIC Void  soTxnEncodeReqCallBack (residePtr, transport, mBuf, success)
PTR          residePtr;      /* Transaction control block             */
U8           transport;      /* Selected Transport protocol (TCP/UDP) */
Buffer       *mBuf;          /* Encoded Request Message               */
Bool         success;        /* Was Encoding Successful!              */
#endif
{
    SoTransCb   *transCb;
    S16         ret, ret1;

    TRC2(soTxnEncodeReqCallBack);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (!(residePtr))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO226, (ErrVal) 0, "soTxnEncodeReqCallBack:"
                   " Invalid parameter");
        RETVOID;
      }

      if ((success) && (mBuf == NULLP))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO227, (ErrVal) 0, "soTxnEncodeReqCallBack:"
                   " Invalid mBuf parameter");
        RETVOID;
      }
#endif

      transCb = (SoTransCb *) residePtr;
      ret  = ROK;
      ret1 = ROK;

     /*------------- Check if encoding was successful -----------*/
      if (!success)
      { 
        /*- Encoding failure. Notify dialog layer about failure -*/
         SoEvnt    *tmpEvnt;
         SoCLegCb  *tmpCLeg;

         tmpEvnt  = transCb->evnt;  transCb->evnt  = NULLP;
         tmpCLeg  = (SoCLegCb *)transCb->cLeg;

         /*--- Delete TCB ---*/
         soTxnDeleteTrans (transCb);

         /*----- Notify dialog layer about encoding fialure -----*/
         (Void) soDlgErrInd (tmpCLeg,
                             SO_TRANS_REQ_ENC_FAILED,
                             tmpEvnt,
                             NULLP);
         /*
          * NOTE  that response event is passed to dialog layer and
          * further  processing/deletion  of response event is done
          * by dialog layer.
          */

          RETVOID;

      } /* End of if (encoding was not successful) */


    /*------ Encoding Was Successful. Save Encoded Message ------*/
      transCb->retxMsg = mBuf;

    /*- STEP 1: Check if Transport layer has changed transport --*/
    /* so038.201: replaced with macro to check for UDP transport */
      if ((SO_TCM_UDP_TRANSPORT(transCb->transport)) &&
          (transport          == LSO_TPTPROT_TCP))
      {
        /*
         * Transport was changed from UDP to TCP by transport layer.
         * MUST retry request if TCP connection fails in this state.
         */
         transCb->transportChanged = TRUE;
         transCb->transport        = LSO_TPTPROT_TCP;
      }

    /*--- Further action depends on Transaction type ---*/
      if (transCb->transMethod == SOT_ET_INVITE)
      {
        /*---------------- INVITE Transaction -------------------*/

        /*- STEP 2: For Unreliable Transport Start Timer A (T1) -*/
        /* so038.201: replaced with macro to check for UDP transport */
          if (SO_TCM_UDP_TRANSPORT(transCb->transport))
          {
            transCb->retxTmrVal = soCb.reCfg.tmrReTxCfg.t1;
            ret = soSchedTmr (transCb, SO_TMR_TRANS_A, TMR_START,
                              transCb->retxTmrVal);

#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
           /*-- If NAT is required, Start NAT Transaction timer -*/
            if (ret == ROK)
               ret = soSchedTmr (transCb, SO_TMR_TRANS_NATTMR,
                                 TMR_START,
                                 soCb.reCfg.tmrReTxCfg.natTmrVal);
#endif
          }

        /*--- STEP 3: For All Transport Start Timer B (64*T1) ---*/
          ret1 = soSchedTmr (transCb, SO_TMR_TRANS_B, TMR_START,
                             64*soCb.reCfg.tmrReTxCfg.t1 + SO_TMRVAL_1_S*2);
        /*
         * 2 seconds is added to timer value just to make sure that
         * timerB and last instance of timerA does not timeout sim-
         * ultaneously.
         */
      
        /*----- Finally, change state to Calling and return -----*/
          transCb->transState = SO_TRANS_CLIENT_CALLING;
      }

      else
      {
        /*-------------- NON INVITE Transaction -----------------*/

        /*- STEP 2: For Unreliable Transport Start Timer E (T1) -*/
        /* so038.201: replaced with macro to check for UDP transport */
          if (SO_TCM_UDP_TRANSPORT(transCb->transport))
          {
            transCb->retxTmrVal = soCb.reCfg.tmrReTxCfg.t1;

            ret = soSchedTmr (transCb, SO_TMR_TRANS_E, TMR_START,
                              transCb->retxTmrVal);
          }

        /*--- STEP 3: For All Transport Start Timer F (64*T1) ---*/

          ret1 = soSchedTmr (transCb, SO_TMR_TRANS_F, TMR_START,
                             64*soCb.reCfg.tmrReTxCfg.t1 + SO_TMRVAL_1_S*2);
        /*
         * 2 seconds is added to timer value just to make sure that
         * timerF and last instance of timerE does not timeout sim-
         * ultaneously.
         */

        /*----- Finally, change state to Trying and return ------*/
          transCb->transState = SO_TRANS_CLIENT_TRYING;
      }

      if ((ret != ROK) || (ret1 != ROK))
           soTxnDeleteTransFromDiag (transCb);

    RETVOID;

} /* End of Fn (soTxnEncodeReqCallBack) */



/*
*
*       Fun:   soTxnEncodeRspCallBack
*
*       Desc:  This function is called by Transport Layer as callback
*              in case of Multi Threaded encoder.Transport layer will
*              call this function ones response encoding is completed
*
*       Ret:   void
*
*       Notes: This function must deallocate  response  event (if not
*               passed to the dialog layer)
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PUBLIC Void   soTxnEncodeRspCallBack 
(
PTR          residePtr,      /* Transaction control block    */
SoEvnt       *response,      /* Response event               */
Buffer       *mBuf,          /* Encoded Response Message     */
Bool         success         /* Was Encoding Successful!     */
)
#else
PUBLIC Void   soTxnEncodeRspCallBack (residePtr, response, mBuf, success)
PTR          residePtr;      /* Transaction control block    */
SoEvnt       *response;      /* Response event               */
Buffer       *mBuf;          /* Encoded Response Message     */
Bool         success;        /* Was Encoding Successful!     */
#endif
{
    SoTransCb  *transCb;
    S16        ret, ret1;
    SoCLegCb   *tmpCLeg;
    Buffer     *tmpMbuf;
    SoEvnt     *tmpEvnt;
    U16        responseClass;

    TRC2(soTxnEncodeRspCallBack);

#if (ERRCLASS & ERRCLS_DEBUG)
      if ((residePtr == NULLP) ||
          ((success) && (mBuf == NULLP)))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO228, (ErrVal) 0, "soTxnEncodeRspCallBack:"
                   " Invalid parameter");
        RETVOID;
      }
#endif

      tmpMbuf = NULLP;
      tmpEvnt = NULLP;
      transCb = (SoTransCb *)residePtr;
      tmpCLeg = (SoCLegCb *)transCb->cLeg;
      ret     = ROK;
      ret1    = ROK;

     /*------------- Check if encoding was successful -----------*/
      if (!success)
      { 
        /*- Encoding failure. Notify dialog layer about failure -*/

         /*--- Delete TCB ---*/
         soTxnDeleteTrans (transCb);

         /*----- Notify dialog layer about encoding failure -----*/
         (Void) soDlgErrInd (tmpCLeg,
                             SO_TRANS_RSP_ENC_FAILED,
                             response,
                             NULLP);
         /*
          * NOTE  that response event is passed to dialog layer and
          * further  processing/deletion  of response event is done
          * by dialog layer.
          */
          RETVOID;

      } /* End of if (encoding was not successful) */

    /*------ Encoding Was Successful. Save Encoded Message ------*/
     /* modified by weigy */
      SO_TXN_DEL_MBUF(transCb->retxMsg);

      transCb->retxMsg = mBuf;

    /*--------- Initialize Response Class ---------*/
      responseClass = (response->t.response.statusLine.statusCode.val)/100;
 
    /*
     *Further action depends on Transaction type and response class
     */
      if (transCb->transMethod == SOT_ET_INVITE)
      {
        /*---------------- INVITE Transaction -------------------*/

          if (responseClass == SO_STACODE_TYPE_SUCCESS)
          {
           /*---- so017.201: Handle "After 2xx" state here ------*/
           /*
            * Successfull sending of 2XX response to INVITE comple-
            * tes transaction. Retransmission  of  2XX  response is
            * taken care by core layer. For reliable transport, tr-
            * ansaction must be deleted from here.
            */
            tmpMbuf = transCb->retxMsg; transCb->retxMsg = NULLP;

            if ((transCb->transport == LSO_TPTPROT_TCP) ||
                (transCb->transport == LSO_TPTPROT_TLS_TCP))
            {
               transCb->transState = SO_TRANS_NON_INV_SERVER_TERMINATED;
               soCmFreeEvent (response);
               soTxnDeleteTransFromDiag (transCb);
               RETVOID;
            }

           /* 
            * For Unreliable transport, start timer J to absorb any
            * retransmitted request message. Transaction is deleted 
            * ones the Timer J expires.
            */ 
            else
            {
               ret = soSchedTmr (transCb, SO_TMR_TRANS_J, TMR_START,
                                 64*soCb.reCfg.tmrReTxCfg.t1);

               /*-- Finally, change state to "After 2xx" state --*/
               transCb->transState = SO_TRANS_INV_SERVER_AFTER_2XX;
            }

            /*----- Pass encoded 2xx message to dialog layer ----*/
            (Void) soDlgEncodeRspCallBack (tmpCLeg, /* Call Leg  */
                                    response, /* Response Event  */
                                    tmpMbuf);/* Encoded Response */
            /* 
             * Response message was  successfully processed. Now we
             * can delete response event structure.
             */
            soCmFreeEvent (response);

            RETVOID;
          } /* End of if (2xx response)     */

          else if (responseClass == SO_STACODE_TYPE_INFORM)
          {
            /*---------- 1XX Povisional Final Response ----------*/
            /*---- Pass reference to encoded message to user ----*/
            if (SAddMsgRef (transCb->retxMsg, soCb.init.region, 
                            soCb.init.pool,   &tmpMbuf) != ROK)
                  tmpMbuf = NULLP;

            (Void) soDlgEncodeRspCallBack (tmpCLeg,/* Call Leg   */
                                    response,/* Response Event   */
                                    tmpMbuf);/* Encoded Response */

          } /* End of if (1xx response)     */

          else
          {
            /*---------- 3-6XX Failure Final Response -----------*/
            
            /*--- For Unreliable Transport Start Timer G (T1) ---*/
            /* so038.201: replaced with macro to check for UDP transport */
              if (SO_TCM_UDP_TRANSPORT(transCb->transport))
              {
                transCb->retxTmrVal = soCb.reCfg.tmrReTxCfg.t1;
                ret = soSchedTmr (transCb, SO_TMR_TRANS_G, TMR_START,
                                  transCb->retxTmrVal);
              }

            /*----- For All Transport Start Timer H (64*T1) -----*/
              ret1  = soSchedTmr (transCb, SO_TMR_TRANS_H, TMR_START,
                                  64*soCb.reCfg.tmrReTxCfg.t1);
      
            /*-------- Finally, change state to Completed -------*/
              transCb->transState = SO_TRANS_INV_SERVER_COMPLETED;

          } /* End of else (3-6xx response) */
      } /* End of if (Invite Transaction)   */

      else
      {
        /*-------------- NON INVITE Transaction -----------------*/

          if (responseClass == SO_STACODE_TYPE_INFORM)
          {    /*--- 1XX Response ---*/
           /*--- Change transaction state to Proceeding ---*/
             transCb->transState = SO_TRANS_NON_INV_SERVER_PROCEEDING;
          }

          else /*-- 2-6XX Response --*/
          { /*
             * For reliable transport, Non Invite server trasaction
             * is completed on sending final response. First delete
             * transaction and then trigger deletion of call leg,if
             * this was the last transaction.
             */
             if ((transCb->transport == LSO_TPTPROT_TCP) ||
                 (transCb->transport == LSO_TPTPROT_TLS_TCP))
             {
                transCb->transState = SO_TRANS_NON_INV_SERVER_TERMINATED;
                soCmFreeEvent (response);
                soTxnDeleteTransFromDiag (transCb);
                RETVOID;
             }

            /* 
             * For Unreliable transport,start timer J to absorb any
             * retransmitted request message.Transaction is deleted 
             * ones the Timer J expires.
             */ 
             else
             {
                ret = soSchedTmr (transCb, SO_TMR_TRANS_J, TMR_START,
                                  64*soCb.reCfg.tmrReTxCfg.t1);

                /*--- Finally, change state to completed state ---*/
                transCb->transState = SO_TRANS_NON_INV_SERVER_COMPLETED;
             }
          } /* End of else (2-6xx Final response) */
          
      } /* End of else (Non Invite Transaction)   */


    /*----------- Response Event is no longer needed ------------*/
      soCmFreeEvent (response);

      if ((ret != ROK) || (ret1 != ROK))
           soTxnDeleteTransFromDiag (transCb);

    RETVOID;

} /* End of Fn (soTxnEncodeRspCallBack) */



/*
*
*       Fun:   soTxnMatchClientTrans
*
*       Desc:  This function is used by Transport layer to match received
*              response message to corresponding transaction.
*
*       Ret:   If success, return ROK and transCb points to TCB
*              If failure, return RFAILED
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PUBLIC S16   soTxnMatchClientTrans 
(
SoEntCb      *entCb,         /* SIP Entity control block                  */
SoEvnt       *response,      /* SIP Response message received             */
SoVia        *via,           /* VIA header receivded in response message  */
SoTransCb    **transCb       /* Transaction control block                 */
)
#else
PUBLIC S16   soTxnMatchClientTrans (entCb, response, via, transCb)
SoEntCb      *entCb;         /* SIP Entity control block                  */
SoEvnt       *response;      /* SIP Response message received             */
SoVia        *via;           /* VIA header receivded in response message  */
SoTransCb    **transCb;      /* Transaction control block                 */
#endif
{
   S32        ret;
   U16        i;
   TknStrOSXL *viaBranch;
   U8         cSeqMethod;
   SoCSeq     *cSeq;

    TRC2(soTxnMatchClientTrans);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (entCb && response && via && transCb))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO229, (ErrVal) 0,"soTxnMatchClientTrans:"
                   " Invalid parameter");
        RETVALUE (RFAILED);
      }
#endif

      viaBranch  = NULLP;
      (*transCb) = NULLP;

     /*---- Extract branchId parameter from TOP VIA Element ---*/
      ret = soTxnFindBranchId (via, &viaBranch);

      if ((ret != ROK) || (viaBranch == NULLP))
      {
         /* 
          * No BranchId with magic cookie present in TOP VIA.This
          * indicates incorrect response message.
          */
         RETVALUE (RFAILED);
      }

     /* Response has magic cookie  in TOP VIA branch parameter */
     /*
      * Find CLient Transcation Control Block (TCB) based on mat-
      * ching rule specified in section 17.1.3 RFC 3261
      */
      SO_GET_CSEQ_FROM_EVENT (response, cSeq);

      SO_METHOD_FROM_CSEQ (cSeqMethod, cSeq);

      i = 0; (*transCb) = NULLP;
      while (cmHashListFind (&entCb->clientTransLst,
                            (U8  *) viaBranch->val,
                            (U16  ) viaBranch->len,
                            i++,
                            (PTR *) transCb) == ROK)
      {
         /*
          * An Incoming Response Message matches client transa-
          * ction if (1) branchId of response matches  branchId
          * of  request which created transaction and  (2) CSeq
          * method of response  matches method of request which
          * created transaction.
          */
          if ((*transCb)->transMethod == cSeqMethod)
             /*--- Match Found ---*/
             RETVALUE (ROK);
  
          (*transCb) = NULLP;
      }

      (*transCb) = NULLP;
      RETVALUE (ROK);

} /* End of Fn (soTxnMatchClientTrans) */




/*
*
*       Fun:   soTxnMatchServerTrans
*
*       Desc:  This function is used by Transport layer to match received
*              request message to corresponding transaction.
*
*       Ret:   If success, return ROK and transCb points to TCB
*              If failure, return RFAILED
*
*       Notes:
*
*       File:  so_trans.c
*
*/

/*---------- so017.201: Removed cLeg argument for this functions ---------*/

#ifdef ANSI
PUBLIC S16   soTxnMatchServerTrans 
(
SoEntCb      *entCb,         /* SIP Entity control block                  */
SoEvnt       *request,       /* SIP Request message received              */
SoTcmConn    *tcmConn,       /* Client/Server Information                 */
SoVia        *via,           /* VIA header receivded in request message   */
SoTransCb    **transCb       /* Transaction control block (TCB)           */
)
#else
PUBLIC S16   soTxnMatchServerTrans (entCb, request, tcmConn, via, transCb)
SoEntCb      *entCb;         /* SIP Entity control block                  */
SoEvnt       *request;       /* SIP Request message received              */
SoTcmConn    *tcmConn;       /* Client/Server Information                 */
SoVia        *via;           /* VIA header receivded in request message   */
SoTransCb    **transCb;      /* Transaction control block (TCB)           */
#endif
{
   S32             ret;
   U16             i;
   TknStrOSXL      *viaBranch;
   SoHostPortType  *reqSentBy;
   SoHostPortType  *transSentBy;

    TRC2(soTxnMatchServerTrans);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (entCb && via && tcmConn && transCb))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO230, (ErrVal) 0,"soTxnMatchServerTrans:"
                   " Invalid parameter");
        RETVALUE (RFAILED);
      }
#endif

      viaBranch  = NULLP;
      (*transCb) = NULLP;

     /*---- Extract branchId parameter from TOP VIA Element ---*/
      ret = soTxnFindBranchId (via, &viaBranch);

      if (ret != ROK)
      {
         /*-- No VIA Element Present. This should not happen --*/
         RETVALUE (RFAILED);
      }

      else if (viaBranch == NULLP)
      {
         /* 
          * No BranchId with magic cookie present in TOP VIA.This
          * indicates that request message  was generated by node
          * NOT compliant to RFC 3261. Try to  find TCB using old
          * 2543 transaction matching rules.
          */
         /* so017.201: Function to find transction for 2543 Req */
          RETVALUE (soTxnMatch2543ServerTrans (entCb, request, transCb));
      }
        
     /*- Request contains magic cookie in TOP VIA branch parameter */
     /*
      * Find Server Transcation Control Block (TCB) based on matching
      * rule specified in section 17.2.3 RFC 3261
      */

     /*--- Extract sent-by field in TOP VIA of Request Message ----*/
      reqSentBy = &via->viaItem[0]->sentBy;

      i = 0; (*transCb) = NULLP;
      while (cmHashListFind (&entCb->serverTransLst,
                            (U8  *) viaBranch->val,
                            (U16  ) viaBranch->len,
                            i++,
                            (PTR *) transCb) == ROK)
      {
          /*----- so017.201: Check if transaction exists -----*/
           if (!SO_TXN_ISALIVE (request->eventType.val, (*transCb)))
           {
              (*transCb) = NULLP;
              continue;
           }

          /* 
           * Extract sent-by in TOP VIA of request that created
           * transaction. NOTE: it is assumed that  atleast one
           * viaParam is present.
           */
           transSentBy = &(*transCb)->via.viaItem[0]->sentBy;

          /*
           * Match sent-by in TOP VIA against the one that cre-
           * ated transaction.
           */
          if (soCmCmpHostPortType (transSentBy, reqSentBy) == ROK)
          {
             /* 
              * Match the request method (so001.201: Except for
              * ACK). ACK will match coresponding INVITE trans-
              * action, if present.
              */
             if ((request->eventType.val == SOT_ET_ACK)    ||
                 (request->eventType.val == (*transCb)->transMethod))
                   /*------ Match Found -----*/
                   RETVALUE (ROK);
          }
  
          (*transCb) = NULLP;
      }

      (*transCb) = NULLP;

      RETVALUE (ROK);

} /* End of Fn (soTxnMatchServerTrans) */

/*-- so017.201: New function to match server transaction for 2543 peer ---*/
/*
*
*       Fun:   soTxnMatch2543ServerTrans
*
*       Desc:  This functions finds server transaction for an incom-
*              ing request without branchId. In orde
*              control block for a new request message received from
*              peer entity.
*              
*              This function is called from dialog module one recei-
*              ving a NEW request.It is very important that only NEW
*              request are passed to this function and not the retr-
*              nsmitted requests.
*
*       RET :  SO_DLG_MATCH, if request matches any existing dialogs
*              SO_DLG_CREATE, New dialog needs to be created
*              SO_DLG_NOMATCH, no match found with  existing dialogs
*
*              If callCb if found "callCb" argument  will be updated
*              If call leg if found "cLegCb" will be updated.
*
*       Notes: 
*
*       File:  so_trans.c
*
*/
#ifdef ANSI
PUBLIC S16 soTxnMatch2543ServerTrans
(
SoEntCb    *ent,      /* Entity Cb                 */
SoEvnt     *request,  /* Request Event             */
SoTransCb  **transCb  /* transaction Cb (returned) */
)
#else
PUBLIC S16 soTxnMatch2543ServerTrans (ent, request, transCb)
SoEntCb    *ent;      /* Entity Cb                 */
SoEvnt     *request;  /* Request Event             */
SoTransCb  **transCb; /* transaction Cb (returned) */
#endif
{
  S16         ret;           /* return value of function */
  CmLList     *llEnt;      /* Used to traverse link list */
  SoCallCb    *callCb;       /* Call control block       */
  SoCLegCb    *cLegCb;       /* Dialog control block     */
  TknStrOSXL  *callId;       /* "callId" in request      */
  TknStrOSXL  *localTag;     /* Dialog's Local tag       */
  TknStrOSXL  *remoteTag;    /* Dialog's Remote tag      */
  SoAddress   *reqLocalAddr; /* "To" header in request   */
  SoAddress   *reqRemoteAddr;/* "From" header in request */
  TknStrOSXL  *reqLocalTag;  /* "To" tag in request      */
  TknStrOSXL  *reqRemoteTag; /* "From" tag in request    */
  SoCSeq      *reqCSeq;      /* "CSeq" header in request */
  SoAddrSpec  *reqURI;       /* "requestURI" in request  */
  SoVia       *reqVia;       /* "Via" header in request  */
  SoViaItem   *reqViaItem;   /* Top "Via" element in request*/
  SoTransCb   *lclTransCb;   /* temp transaction Cb pointer */
  SoTransCb   *prevTransCb;  /* temp transaction Cb pointer */
  Bool        transFound;    /* Found matching transaction  */

  TRC3 (soTxnMatch2543ServerTrans);

  /*----------------- Initialize Local Variables --------------------*/
  ret          = ROK;
  llEnt        = NULLP;
  (*transCb)   = NULLP;
  prevTransCb  = NULLP;
  transFound   = FALSE;

  /*
   * According to section 17.2.3 of RFC 3261,a request without branchId
   * matches  a  server transaction  if  requestURI,  to tag,  from tag,
   * callID,  CSeq and  top VIA header matches the request that created
   * the transaction.
   * Furthermore, ACK request matches a transaction if requestURI, from
   * tag, callID, CSeq (not method) and top VIA header matches the INV-
   * ITE request that created transaction.
   */


  /*-- STEP 1: Find if "CallId" header matches any server transaction --*/

   (Void) soCmFindHdrChoice (request, (U8 **)&callId, SO_HEADER_GEN_CALLID);

   /* so032.201: Pass event type for locating call cb */
   callCb = soCoreLocateCallCb (ent, SO_CONNID_NOTUSED, SO_CONNID_NOTUSED,
                                callId, SOT_ET_UNKNOWN);
   if (callCb == NULLP)
     /*------- No matching Call found ------*/
      RETVALUE (ROK);

  /*------- Extract required headers to be matched from request --------*/
   ret = soCoreGetAddrAndTags (request, &reqLocalAddr, &reqRemoteAddr,
                               &reqLocalTag, &reqRemoteTag);
   if (ret != ROK)
     RETVALUE (RFAILED);

   (Void) soCmFindHdrChoice (request, (U8 **) &reqCSeq, SO_HEADER_GEN_CSEQ);
   (Void) soCmFindHdrChoice (request, (U8 **) &reqVia , SO_HEADER_GEN_VIA);
   if (!reqCSeq || !reqVia)
     RETVALUE (RFAILED);

   reqViaItem = reqVia->viaItem[0];
   reqURI     = &request->t.request.requestLine.addrSpec;

  /*-- STEP 2: Find the matching dialog based on to/from/reqURI fields -*/

  /*----- For each dialog in call ... -----*/
   for (cLegCb = (SoCLegCb *)CM_LLIST_FIRST_NODE (&callCb->cLegLst, llEnt);
        cLegCb;
        cLegCb = (SoCLegCb *)CM_LLIST_NEXT_NODE (&callCb->cLegLst, llEnt))
   {
        remoteTag  = &cLegCb->storedHdrs.remoteTag;
        localTag   = &cLegCb->storedHdrs.localTag;
      
       /*--- Match with remote tag present in call leg ---*/
        if (((reqRemoteTag)  && (remoteTag->pres == NOTPRSNT))    ||
            ((!reqRemoteTag) && (remoteTag->pres == PRSNT_NODEF)) ||
            ((reqRemoteTag)  && !(SO_CMP_TKNSTR (remoteTag, reqRemoteTag))))
             continue;
        
       /* 
        * For NON-ACK request, if local tag was received in
        * request, match with local tag present in call leg
        */
        if ((reqLocalTag) && (request->eventType.val != SOT_ET_ACK))
        {
           if (!(SO_CMP_TKNSTR (localTag, reqLocalTag)))
             continue;
        }
   
       /*--- Match with requestURI present in call leg ---*/
        ret = soUtlCmpSoAddrSpec (reqURI, &cLegCb->storedHdrs.origReqURI);
        if (ret != ROK)
             continue;

       /*------------ Found matching call leg ------------*/

       /*-- STEP 3: Find matching transaction based on cSeq/VIA fields --*/

       /*-- For each transaction in dialog ... --*/
        prevTransCb  = NULLP;
        while (cmHashListGetNext (&cLegCb->tranCbLst,
                                 (PTR  ) prevTransCb,
                                 (PTR *) &lclTransCb) == ROK)
        {
             prevTransCb = lclTransCb;
       
            /*--------- Check if transaction is alive ---------*/
             if (!SO_TXN_ISALIVE (request->eventType.val, lclTransCb))
                  continue;
       
            /*-- Match with cSeq value present in transaction -*/
             if (reqCSeq->cSeqVal.val != lclTransCb->transCSeq)
                  continue;
       
            /*- For NON-ACK request,match CSeq method as well -*/
             if (request->eventType.val != SOT_ET_ACK)
             {
               if (request->eventType.val != lclTransCb->transMethod)
                  continue;
             }
            /*- ACK request will match the INVITE transaction -*/
             else
             {
               if (lclTransCb->transMethod != SOT_ET_INVITE)
                  continue;
             }
        
            /*----------- Found matching transaction ----------*/
             transFound  = TRUE;
             break;
       
        } /* For (each transaction in dialog) */
    
        if (transFound)
          break;

   } /* For (each dialog in call) */
        
   if (transFound)
   {
     /*------ Found tranaction matcing request ------*/
     SODBGP_SO (SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
        "\n[TRANS] Matching Server Transaction Found (2543):"
        " Call(%ld), CallLeg(%ld), D-State(%d), Trans(%lx), T-State(%d)",
        cLegCb->call->spConnId, cLegCb->legId, cLegCb->clegState, 
        lclTransCb->transId, lclTransCb->transState));

     (*transCb) = lclTransCb;
   }

   RETVALUE (ROK);

} /* End of fn soTxnMatch2543ServerTrans () */



/*
*
*       Fun:   soTxnClientConnFailure
*
*       Desc:  This function is used by Transport layer to indicate that
*              client connection used by this Transaction no longer exi-
*              sts
*
*       Ret:   None
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PUBLIC Void soTxnClientConnFailure 
(
PTR      residePtr      /* Transaction control block (TCB)  */
)
#else
PUBLIC Void soTxnClientConnFailure (residePtr)
PTR      residePtr;     /* Transaction control block (TCB)  */
#endif
{
   S16            ret;
   SoTransCb      *transCb;
   SoUserCtxt     tmpUserContext;
   SoEvnt         *tmpEvnt;
   SoCLegCb       *tmpCLeg;
   SoEntCb        *tmpEntCb;

   TRC2(soTxnClientConnFailure);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (residePtr))
   {
      SOLOGERROR (ERRCLS_DEBUG, ESO231, (ErrVal) 0,"soTxnClientConnFailure:"
                 " Invalid parameter");
      RETVOID;
   }
#endif

   transCb = (SoTransCb *)residePtr;

   switch (transCb->transType)
   {
      case SO_TRANS_INV_CLIENT:
      case SO_TRANS_NON_INV_CLIENT:

          if ((transCb->transState == SO_TRANS_CLIENT_CALLING) ||
              (transCb->transState == SO_TRANS_CLIENT_TRYING))
          {
             /*Failure in sending initial request message itself.*/

             /*--- CASE 1: Retry request with UDP, if required --*/
              if (transCb->transportChanged)
              {
                /* In this case, if the  transport  was modified from
                 * UDP to TCP, and TCP connection has now failed, sw-
                 * itch back to UDP and retry request.
                 *
                 * Before retrying request with UDP, first change TCB
                 * elements to the state that existed  before sending 
                 * request message.
                 */
                 transCb->transportChanged = FALSE;
                 transCb->transport        = LSO_TPTPROT_UDP;

                 soPrcDelTcmConn (&transCb->tcmConn);
                 SO_TXN_DEL_MBUF (transCb->retxMsg);

                 soUtlDelSoVia (&transCb->via);

                 (Void) soUtlDelTopViaElement (transCb->evnt);

                /*------- Send The Request Again With UDP --------*/
                 ret = soTptSendInitialReq (transCb->entCb,
                                    SSAP,
                                    &transCb->destAddr,/* Dest Address  */
                                    transCb->transport,/* TCP/UDP       */
                                    transCb->evnt,     /* Request Msg   */
                                    FALSE,             /* Modify Transport */
                                    &transCb->branchId,/* Branch Identifier*/
                                    &transCb->tcmConn, /* Server/Client Cb */
                                    &transCb->retxMsg);
                 if (ret == ROK)
                      RETVOID; /*------ Return Successfully ------*/
              }

             /* CASE 2: Inform dialog layer that request could not be send */
              cmMemcpy ((U8 *)&tmpUserContext, (U8 *)&transCb->userContext,
                        sizeof (SoUserCtxt));

#ifdef SO_COMPRESS
              tmpUserContext.sigCompSupp = transCb->tcmConn.sigCompSupp;
#endif
              tmpUserContext.transport   = transCb->transport;
              cmMemcpy ((U8 *) &tmpUserContext.destAddr,
                        (U8 *) &transCb->destAddr,
                        sizeof (CmTptAddr));

              cmMemset ((U8 *)&transCb->userContext, 0, sizeof (SoUserCtxt));

              tmpEntCb    = transCb->entCb;
              tmpEvnt     = transCb->evnt; transCb->evnt = (SoEvnt *)NULLP;
              tmpCLeg     = (SoCLegCb *)transCb->cLeg;
 
              transCb->transState = SO_TRANS_CLIENT_TERMINATED;
              soTxnDeleteTrans (transCb);

              (Void) soDlgErrInd (tmpCLeg,
                                  SO_TRANS_TIMEOUT,
                                  tmpEvnt, /* Pass request event to user */
                                  &tmpUserContext);

          } /* End of if (client calling state) */

         /*
          * NOTE: For client transactions, in state other that call-
          *       ing/trying, we do not care if client connection is
          *       down. If required, A new connection will be opened
          */
          break;

      case SO_TRANS_INV_SERVER:
      case SO_TRANS_NON_INV_SERVER:
         /*
          * NOTE: For server transactions,  we do not care if client 
          *       connection is down.  If required, a new connection 
          *       will be opened
          */
          break;

   } /* End of switch (transaction type) */

   RETVOID;

} /* End of Fn (soTxnClientConnFailure) */



/*
*
*       Fun:   soTxnServerConnFailure
*
*       Desc:  This function is used by Transport layer to indicate that
*              client connection used by this Transaction no longer exi-
*              sts
*
*       Ret:   None
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PUBLIC Void soTxnServerConnFailure 
(
PTR      residePtr      /* Transaction control block (TCB)  */
)
#else
PUBLIC Void soTxnServerConnFailure (residePtr)
PTR      residePtr;     /* Transaction control block (TCB)  */
#endif
{
   SoTransCb      *transCb;
   SoCLegCb       *tmpCLeg;
   SoEvnt         *tmpEvnt;
   U8             transState;

   TRC2(soTxnServerConnFailure);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (residePtr))
   {
      SOLOGERROR (ERRCLS_DEBUG, ESO232, (ErrVal) 0,"soTxnServerConnFailure:"
                 " Invalid parameter");
      RETVOID;
   }
#endif

   transCb = (SoTransCb *)residePtr;

   switch (transCb->transType)
   {
      case SO_TRANS_INV_CLIENT:
      case SO_TRANS_NON_INV_CLIENT:

             /*
              * For client transaction, server connection failure is
              * fatal error. The peer  node  may not be able to send
              * response messages for this transaction.So delete the
              * transaction and inform dialog layer.
              */
              tmpCLeg     = (SoCLegCb *)transCb->cLeg;
 
              transState  = transCb->transState;
              transCb->transState = SO_TRANS_CLIENT_TERMINATED;

             /*
              * so033.201:Provide the application ErrInd 
              * Primitive only in the case Transaction state
              * is not completed or Terminated. If the transaction state 
              * is completed simply delete the Transaction.
              */
              if(transState < SO_TRANS_CLIENT_COMPLETED)
              {
                 /*
                  * so021.201:Pass the event structure to application in
                  * ErrInd Primitive.
                  */
                 tmpEvnt   = transCb->evnt; transCb->evnt = (SoEvnt *)NULLP;
                 soTxnDeleteTrans (transCb);
                 (Void) soDlgErrInd (tmpCLeg, SO_TRANS_ERROR, tmpEvnt, NULLP);
              }
              else
              {
                 soTxnDeleteTrans (transCb);
              }

          break;

      case SO_TRANS_INV_SERVER:
      case SO_TRANS_NON_INV_SERVER:
         /*
          * NOTE: For server transactions,  we do not care if server 
          *       connection is down.  If required, a new connection 
          *       will be used.
          */
          break;

   } /* End of switch (transaction type) */

   RETVOID;

} /* End of Fn (soTxnServerConnFailure) */



/*******************************************************************
*
*       Fun:   soTxnProcTmrExpiry
*
*       Desc:  Process expiry of all timers  related  to transaction 
*              module. This function is invoked by TMR module dispa-
*              tch a timer expiry.
*
*       Ret:   None
*
*       Notes:
*
*       File:  so_trans.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC Void soTxnProcTmrExpiry
(
Ptr           cb,        /* Control block */
S16           tmrEvnt    /* Timer event   */
)
#else
PUBLIC Void soTxnProcTmrExpiry (cb, tmrEvnt)
Ptr           cb;        /* Control block */
S16           tmrEvnt;   /* Timer event   */
#endif
{
   SoTransCb  * transCb;

   TRC2(soTxnProcTmrExpiry);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! (cb))
   {
     SOLOGERROR (ERRCLS_DEBUG, ESO233, (ErrVal) 0, "soTxnProcTmrExpiry:"
                " Invalid parameter");
     RETVOID;
   }
#endif

   transCb = (SoTransCb *)cb;
 
   switch (tmrEvnt)
   {
      case SO_TMR_TRANS_A:  /*-- Retransmission Timers --*/
              soTxnInvClientFsm[SO_TRANS_TIMER_A_EXPIRES][transCb->transState]
                               (transCb, NULLP);
              break;

      case SO_TMR_TRANS_E:  /*-- Retransmission Timers --*/
              soTxnNonInvClientFsm[SO_TRANS_TIMER_E_EXPIRES][transCb->transState]
                                  (transCb, NULLP);
              break;

      case SO_TMR_TRANS_G:  /*-- Retransmission Timers --*/
              soTxnInvServerFsm[SO_TRANS_TIMER_G_EXPIRES][transCb->transState]
                               (transCb, NULLP);
              break;

      case SO_TMR_TRANS_B:  /*--- Transactions Timers ---*/
              soTxnInvClientFsm[SO_TRANS_TIMER_B_EXPIRES][transCb->transState]
                               (transCb, NULLP);
              break;

      case SO_TMR_TRANS_D:  /*--- Transactions Timers ---*/
              soTxnInvClientFsm[SO_TRANS_TIMER_D_EXPIRES][transCb->transState]
                               (transCb, NULLP);
              break;

      case SO_TMR_TRANS_F:  /*--- Transactions Timers ---*/
              soTxnNonInvClientFsm[SO_TRANS_TIMER_F_EXPIRES][transCb->transState]
                                  (transCb, NULLP);
              break;

      case SO_TMR_TRANS_H:  /*--- Transactions Timers ---*/
              soTxnInvServerFsm[SO_TRANS_TIMER_H_EXPIRES][transCb->transState]
                               (transCb, NULLP);
              break;

      case SO_TMR_TRANS_I:  /*--- Transactions Timers ---*/
              soTxnInvServerFsm[SO_TRANS_TIMER_I_EXPIRES][transCb->transState]
                               (transCb, NULLP);
              break;

      case SO_TMR_TRANS_J:  /*--- Transactions Timers ---*/
             /*- so017.201: TimerJ is started for both Inv and Non Inv Servers -*/
              if (transCb->transType == SO_TRANS_INV_SERVER)
                soTxnInvServerFsm[SO_TRANS_TIMER_J_EXPIRES][transCb->transState]
                                 (transCb, NULLP);
              else
                soTxnNonInvServerFsm[SO_TRANS_TIMER_J_EXPIRES][transCb->transState]
                                    (transCb, NULLP);
              break;

      case SO_TMR_TRANS_K:  /*--- Transactions Timers ---*/
              soTxnNonInvClientFsm[SO_TRANS_TIMER_K_EXPIRES][transCb->transState]
                                  (transCb, NULLP);
              break;

      case SO_TMR_TRANS_NATTMR:/*-- Transactions Timers -*/
              soTxnInvClientFsm[SO_TRANS_TIMER_NAT_EXPIRES][transCb->transState]
                                  (transCb, NULLP);
              break;                    
              
   } /* End of switch (transaction timer type) */

   RETVOID;

} /* soTxnProcTmrExpiry */



/*******************************************************************
*
*       Fun:   soTxnSelectSSap
*
*       Desc:  Process expiry of all timers  related  to transaction 
*              module. This function is invoked by TMR module dispa-
*              tch a timer expiry.
*
*       Ret:   None
*
*       Notes:
*
*       File:  so_trans.c
*
*******************************************************************/




/*------------------- PRIVATE FUNCTIONS ------------------------*/



/*
*
*       Fun:   soTxnFindBranchId
*
*       Desc:  This is a utility function to find the branch id in
*              TOP VIA  header element.   It is also verifies that
*              branch id starts with MAGIC COOKIE defined in 3261.
*
*       Ret:   If success, return ROK and viaBranch points to bra-
*              nchId param
*              If failure, return RFAILED.
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnFindBranchId 
(
SoVia        *via,           /* VIA header                           */
TknStrOSXL   **viaBranch     /* Pointer to VIA branchId parameter    */
)
#else
PRIVATE S16   soTxnFindBranchId (via, viaBranch)
SoVia        *via;           /* VIA header                           */
TknStrOSXL   **viaBranch;    /* Pointer to VIA branchId parameter    */
#endif
{
   S32        i;
   SoViaItem  *viaItem;

    TRC2(soTxnFindBranchId);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (via && viaBranch))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO234, (ErrVal) 0,"soTxnFindBranchId:"
                   " Invalid parameter");
        RETVALUE (RFAILED);
      }
#endif

    /*-------- Extract the TOP VIA header element ---------*/
      if (SO_GET_NUM_COMP (&via->numComp) < 1)
         RETVALUE (RFAILED);
      
      viaItem = via->viaItem[0];
       
    /*
     * Check if TOP VIA element  contains  branchId parameter
     * with magic cookie.
     */
      (*viaBranch) = NULLP;
      
      for (i = 0; i < SO_GET_NUM_COMP (&viaItem->viaParams.numComp); i++)
      {
        if (SO_CMP_TKN_LIT(
                     &viaItem->viaParams.viaParam[i]->viaParamType,
                     SO_VIAPARAM_VIABRANCH) == TRUE)
        {
           (*viaBranch) = &(viaItem->viaParams.viaParam[i]->t.viaBranch);
         
           if (soUtlCmpTknStrOSXLCi ((*viaBranch),
                                  (U8 *)BRANCH_MAGSTR, 
                                  BRANCH_MAGSTR_SZ) == ROK)
              /*--- TOP VIA header contains magic cookie ---*/
              break;
        }

        (*viaBranch) = NULLP;
      }

      RETVALUE (ROK);

} /* End of Fn (soTxnFindBranchId) */



/*
*
*       Fun:   soTxnUacUpdateTransCb 
*
*       Desc:  Update transaction control block when created by request
*              from service user.
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnUacUpdateTransCb 
(
SoTransCb    *transCb,       /* Transaction control block            */
SoEvnt       *request        /* SIP Request message                  */
)
#else
PRIVATE S16   soTxnUacUpdateTransCb(transCb, request)
SoTransCb    *transCb;       /* Transaction control block            */
SoEvnt       *request;       /* SIP Request message                  */
#endif
{
    S16         ret;
    SoCSeq      *cSeq;
    TknStrOSXL  *toHeader;
    TknStrOSXL  *toTag;
    TknStrOSXL  *fromHeader;

    TRC2(soTxnUacUpdateTransCb);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && request))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO235, (ErrVal) 0, "soTxnUacUpdateTransCb: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }
#endif

    /*---- Update Transaction Type (INVITE or NON-INVITE) -----*/
      if (SO_CMP_TKN_LIT (&request->eventType, SOT_ET_INVITE))
          transCb->transType = SO_TRANS_INV_CLIENT;
      else
          transCb->transType = SO_TRANS_NON_INV_CLIENT;

    /*--- Save tranaction Id allocated by SIP User ---*/
      transCb->transId       = request->transId;

    /*----- Initialize transaction state to IDLE -----*/
      transCb->transState    = SO_TRANS_CLIENT_IDLE;

    /*--------- Update SIP Request method ------------*/
      transCb->transMethod   = request->eventType.val;

    /*-------- Save CSeq of request method -----------*/
      SO_GET_CSEQ_FROM_EVENT (request, cSeq);
      transCb->transCSeq   = cSeq->cSeqVal.val;

    /* 
     * so014.201: For INVITE  transaction save the Route
     *   header and requestURI header. These fields will
     *   be  used  during sending  of CANCEL and ACK for 
     *   3-6xx Responses.
     */
      ret = soUtlStoreOrigRoute (transCb, request);
      if (ret != ROK)
         RETVALUE (RFAILED);

    /*-------- Save CSeq of request method -----------*/
      SO_GET_CSEQ_FROM_EVENT (request, cSeq);
      transCb->transCSeq   = cSeq->cSeqVal.val;

    /*---- Update SIP Extension method (if reqd) -----*/
      SO_TXN_FILL_EXT_METHOD (transCb, cSeq);
     
    /* 
     * so001.201: Generate branchId. For CANCEL request,
     * caller must make  sure  that VIA and branchId of
     * corresponding INVITE are already present.
     */
    if (!(SO_CMP_TKN_LIT (&request->eventType, SOT_ET_CANCEL)))
    {
      /*-- Delete any branchId in VIA (if present) ---*/
      (Void) soUtlDeleteBranchId (request);

      /* Generate Unique Branch ID parameter. RfC 3261 8.1.1.7 */
      
      toHeader   = & ((SoCLegCb *)transCb->cLeg)->storedHdrs.normRemoteAddr;
      toTag      = & ((SoCLegCb *)transCb->cLeg)->storedHdrs.remoteTag;
      fromHeader = & ((SoCLegCb *)transCb->cLeg)->storedHdrs.normLocalAddr;

      /*-- so021.201 : Added parameter for requestURI --*/
      /*-- so028.201 : Added parameter for via --*/
      /* For User Agent RequestURI in not used for      *
       * branchId Calculation                           */
      ret = soUtlGenerateBranchId (request, toHeader, fromHeader,
                                   toTag,   transCb->transCSeq,
                                   transCb->transMethod,
                                   NULLP, 0,
                                   NULLP, 0,
                                   &transCb->branchId);
      if (ret != ROK)
         RETVALUE (RFAILED);
    }
    else
    {
      /* Extract branchId provided by core layer in VIA header */
      ret = soUtlGetBranchId (request, &transCb->branchId);
      if (ret != ROK)
         RETVALUE (RFAILED);

      /*---- Delete branchId in VIA (will be added by TCM) ----*/
      (Void) soUtlDeleteBranchId (request);
    }

    /*----------- Save the request event structure ------------*/
      transCb->evnt = request;

    /*--- Insert TCB in entity hashlist indexed by branchID ---*/
      ret = cmHashListInsert (&transCb->entCb->clientTransLst,
                              (PTR ) transCb, 
                              (U8 *) transCb->branchId.val,
                              (U16 ) transCb->branchId.len);
      if (ret != ROK)
      {
          SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                "\n[TRANS] Client HashList Insert Failed"));
          RETVALUE (RFAILED);
      }

#ifdef SO_REL_1_2_INF
    /* 
     * In order to maintain  backward compatibility with SIP 1.2
     * release, we need to keep hash list of transactionCb inde-
     * xed on transactionID.
     */
    /*--- Insert TCB in entity hashlist indexed by TransID ----*/
      ret = cmHashListInsert (&transCb->entCb->transLst,
                              (PTR ) transCb,
                              (U8 *) &transCb->transId,
                              (U16 ) sizeof (U32));
      if (ret != ROK)
      {
          SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                "\n[TRANS] transId HashList Insert Failed"));
          RETVALUE (RFAILED);
      }
#endif
      
    RETVALUE (ROK);

} /* End of Fn (soTxnUacUpdateTransCb) */





/*
*
*       Fun:   soTxnUasUpdateTransCb 
*
*       Desc:  Update transaction control block when created by request
*              from peer.
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnUasUpdateTransCb 
(
SoTransCb    *transCb,       /* Transaction control block            */
SoEvnt       *request        /* SIP Request message                  */
)
#else
PRIVATE S16   soTxnUasUpdateTransCb(transCb, request)
SoTransCb    *transCb;       /* Transaction control block            */
SoEvnt       *request;       /* SIP Request message                  */
#endif
{
    S16     ret;
    SoCSeq  *cSeq;

    TRC2(soTxnUasUpdateTransCb);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && request))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO236, (ErrVal) 0, "soTxnUasUpdateTransCb: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }
#endif

    /*------- Update Transaction Type and State ---------*/
      if (SO_CMP_TKN_LIT (&request->eventType, SOT_ET_INVITE))
      {
          transCb->transType  = SO_TRANS_INV_SERVER;
          transCb->transState = SO_TRANS_INV_SERVER_IDLE;
      }
      else
      {
          transCb->transType  = SO_TRANS_NON_INV_SERVER;
          transCb->transState = SO_TRANS_NON_INV_SERVER_IDLE;
      }

    /*------------ Update SIP Request method. -----------*/
      transCb->transMethod    = request->eventType.val;

    /*----- Allocate locally unique transaction id. -----*/
      SO_TXN_AllOC_TRANSID (transCb->transId, 
                            transCb->transMethod,
                            transCb->entCb);
      
    /*--------- Update the transId in the event. --------*/ 
      request->transId = transCb->transId;

    /*---------- Save CSeq of request method ------------*/
      SO_GET_CSEQ_FROM_EVENT (request, cSeq);
      transCb->transCSeq      = cSeq->cSeqVal.val;

    /*----- Update SIP Extension method (if reqd) -------*/
      SO_TXN_FILL_EXT_METHOD (transCb, cSeq);
     
    /* 
     *  Save VIA header (will be used in response msg). Also 
     *  process branchId, if request  was initiated  by node
     *  compliant to RFC 3261 
     */
      ret = soTxnProcess3261BranchId (transCb, request);
      if (ret != ROK)
         RETVALUE (RFAILED);
      
#ifdef SO_REL_1_2_INF
    /* 
     * In order to maintain  backward compatibility with SIP 1.2
     * release, we need to keep hash list of transactionCb inde-
     * xed on transactionID.
     */
    /*--- Insert TCB in entity hashlist indexed by TransID ----*/
      ret = cmHashListInsert (&transCb->entCb->transLst,
                              (PTR ) transCb,
                              (U8 *) &transCb->transId,
                              (U16 ) sizeof (U32));
      if (ret != ROK)
      {
          SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                    "\n[TRANS] TransId HashList Insert Failed"));
          RETVALUE (RFAILED);
      }
#endif
      
    RETVALUE (ROK);

} /* End of Fn (soTxnUasUpdateTransCb) */



/*
*
*       Fun:   soTxnProcess3261BranchId
*
*       Desc:  Check if the request was originatedd by node compliant to
*              rfc 3261. If yes, insert   received branchId  in the hash
*              list for easy access.
*          
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnProcess3261BranchId 
(
SoTransCb    *transCb,       /* Transaction control block            */
SoEvnt       *request        /* SIP Request message                  */
)
#else
PRIVATE S16   soTxnProcess3261BranchId(transCb, request)
SoTransCb    *transCb;       /* Transaction control block            */
SoEvnt       *request;       /* SIP Request message                  */
#endif
{
   S32        ret;
   SoVia      *via;
   TknStrOSXL *viaBranch;

    TRC2(soTxnProcess3261BranchId);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && request))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO237, (ErrVal) 0,"soTxnProcess3261BranchId:"
                   " Invalid parameter");
        RETVALUE (RFAILED);
      }
#endif

    /*---- Find the VIA header in request message ----*/
      SO_GET_VIA_FROM_EVENT (request, via);

    /*- First save VIA in Transaction control block --*/
      if (soUtlPrcStoreVia (&transCb->via, request) != ROK)
      {
          SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                "\n[TRANS] Store VIA Failed"));
          RETVALUE (RFAILED);
      }
 
     /*---- Extract branchId parameter from TOP VIA Element ---*/
      if (soTxnFindBranchId (via, &viaBranch) != ROK)
      {
         /*--------- Incorrect VIA Element Present. -----------*/
         SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                "\n[TRANS] Incorrect VIA Element"));
         RETVALUE (RFAILED);
      }

      else if (viaBranch == NULLP)
      {
        /* 
         * No BranchId with magic cookie present in TOP VIA.Means
         * Request was generate by node NOT compliant to RFC 3261.
         * No processing based on branchId needed here.
         */
         RETVALUE (ROK);
      }

      else /* Valid viaBranch */
      {
        /* 
         * Request was generate by node compliant to RFC 3261.So
         * store the branchId in transaction control block (TCB) 
         * and also  insert TCB in entity  hash list indexed  by
         * branchId.
         */
         ret = soUtlCpyTknStrOSXL (&transCb->branchId, viaBranch, NULLP);
         if (ret != ROK)
            RETVALUE (RFAILED);

         ret = cmHashListInsert (&transCb->entCb->serverTransLst,
                                 (PTR ) transCb,
                                 (U8 *) transCb->branchId.val,
                                 (U16 ) transCb->branchId.len);
         if (ret != ROK)
         {
            SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                      "\n[TRANS] Server HashList Insert Failed"));
            RETVALUE (RFAILED);
         }
      }

      RETVALUE (ROK);

} /* End of Fn (soTxnProcess3261BranchId) */







/*------------ INVITE CLIENT TRANSACTION STATE FUNCTIONS ------------*/


/*
*
*       Fun:   soTxnInvClientFsmT0S1
*
*       Desc:  This function is part of INVITE Client transaction. It 
*              handles INVITE request from user in IDLE state.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return SIP user related error code.
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvClientFsmT0S1
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16   soTxnInvClientFsmT0S1 (transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    S16        ret;
    SoVia      *via;

    TRC2(soTxnInvClientFsmT0S1);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO238, (ErrVal) 0, "soTxnInvClientFsmT0S1: "
                   "Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Sending Invite"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*- STEP 1: Pass the INVITE Request to transport layer for transmission -*/
      ret = soTptSendInitialReq (transCb->entCb,
                                 SSAP,
                                 &transCb->destAddr, /* Dest Address  */
                                 transCb->transport, /* TCP/UDP       */
                                 transCb->evnt,      /* Request Msg   */
                                 TRUE,               /* Modify Transport */
                                 &transCb->branchId, /* Branch Identifier*/
                                 &transCb->tcmConn,  /* Server/Client Cb */
                                 &transCb->retxMsg); /* Encoded Msg   */

      if (ret == SO_TPT_TRANSPORT_CHANGED)
      {
        /*
         * Transport was changed from UDP to TCP by transport layer.
         * MUST retry request if TCP connection fails in this state.
         */
         transCb->transportChanged = TRUE;
         transCb->transport        = LSO_TPTPROT_TCP;
      }
      else if (ret == SO_TPT_MULTI_THREADED_ENC)
      {
        /*
         * Encoding not finished YET. The rest of functionality for
         * this  state  will  be  done  in  the  callback function.
         */
        /*----------- Save VIA send in request message ----------*/
         SO_GET_VIA_FROM_EVENT (transCb->evnt, via);
         ret = soUtlCpySoVia (&transCb->via, via, NULLP);

         transCb->retxMsg = NULLP;
         RETVALUE (ROK);
      }
      else if (ret != ROK)
         RETVALUE (ret);

     /*------------- Save VIA send in request message -----------*/
      SO_GET_VIA_FROM_EVENT (transCb->evnt, via);
      ret = soUtlCpySoVia (&transCb->via, via, NULLP);

    /*--- STEP 2: For Unreliable Transport Start Timer A (T1) ---*/
    /* so038.201: replaced with macro to check for UDP transport */
      if (SO_TCM_UDP_TRANSPORT(transCb->transport))
      {
        transCb->retxTmrVal = soCb.reCfg.tmrReTxCfg.t1;
        ret = soSchedTmr (transCb, SO_TMR_TRANS_A, TMR_START,
                          transCb->retxTmrVal);
        if (ret != ROK)
          RETVALUE (SOT_ERR_UNKNOWN);

#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
         /*- If NAT is required,Start NAT Transaction timer too -*/
         ret = soSchedTmr (transCb, SO_TMR_TRANS_NATTMR, TMR_START,
                          soCb.reCfg.tmrReTxCfg.natTmrVal);
         if (ret != ROK)
           RETVALUE (SOT_ERR_UNKNOWN);
#endif              
      }

    /*----- STEP 3: For All Transport Start Timer B (64*T1) -----*/
      ret = soSchedTmr (transCb, SO_TMR_TRANS_B, TMR_START,
                        64*soCb.reCfg.tmrReTxCfg.t1 + SO_TMRVAL_1_S * 2);
    /*
     * 2 seconds is added to timer value just to make sure that t-
     * imerB and last instance of timerA does not timeout simutan-
     * eously.
     */
      if (ret != ROK)
          RETVALUE (SOT_ERR_UNKNOWN);
          
    /*------- Finally, change state to Calling and return -------*/
      transCb->transState = SO_TRANS_CLIENT_CALLING;

      RETVALUE (ROK);

} /* End of Fn (soTxnInvClientFsmT0S1) */




/*
*
*       Fun:   soTxnInvClientFsmT1S2
*
*       Desc:  This function is part of INVITE Client transaction. It 
*              handles 1xx response from peer in CALLING state.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvClientFsmT1S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvClientFsmT1S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    S16 ret;

    TRC2(soTxnInvClientFsmT1S2);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO239, (ErrVal) 0, "soTxnInvClientFsmT1S2: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      if (transCb->transState == SO_TRANS_CLIENT_CALLING)
      {
        SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                     "\n[TRANS] 1XX (Inv) From Peer"));
        SO_TXN_DEBUG_PRINT (transCb);
      }
#endif

    /*-- If this is first response, delete request event structure --*/
      SO_TXN_DEL_EVENT (transCb, transCb->evnt);

    /*- After first response, encoded request message is not needed -*/
      SO_TXN_DEL_MBUF (transCb->retxMsg);

    /*--- After first response, DNS Query CB is not longer needed ---*/
#ifdef SO_DNS
      SO_TXN_DEL_QUERYCB (transCb);
#endif

    /*
     * STEP 1:
     * Provisional response received, MUST stop timers A&B. NOTE: After
     * this point we have no timers in transaction layer to protect in-
     * vite client transaction. 
     */
     /* so038.201: replaced with macro to check for UDP transport */
      if (SO_TCM_UDP_TRANSPORT(transCb->transport ))
        soSchedTmr (transCb, SO_TMR_TRANS_A, TMR_STOP, 0);

      soSchedTmr (transCb, SO_TMR_TRANS_B, TMR_STOP, 0);

    /*------------- STEP 2: change state to PROCEEDING --------------*/
      transCb->transState = SO_TRANS_CLIENT_PROCEEDING;

    /*---- STEP 3: Pass the INVITE Prov. Response to dialog layer ---*/
      
     /*--- so018.201: Do not pass retransmitted 100 to dialog user --*/
      if ((evnt->t.response.statusLine.statusCode.val == SOT_RSP_100_TRYING) &&
          (evnt->sipBody.bodyType.pres == NOTPRSNT) &&
          (transCb->prevRspCode        == SOT_RSP_100_TRYING))
      {
        SODBGP_SO (SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                  "\n[TRANS]: Dropping Retx 100 Response"));
        (Void) soCmFreeEvent (evnt);
        RETVALUE (ROK);
      }

      transCb->prevRspCode = evnt->t.response.statusLine.statusCode.val;

      ret = soDlgUaIncRsp (transCb->entCb,
                           evnt,
                           CLEG,
                           &transCb->userContext);
     /*
      * NOTE: If the above function returns failure, just return RFAIL-
      *       ED so that transport can delete event structure.
      */
      RETVALUE (ret);

} /* End of Fn (soTxnInvClientFsmT1S2) */




/*
*
*       Fun:   soTxnInvClientFsmT1S3
*
*       Desc:  This function is part of INVITE Client transaction. It 
               handles 1xx response from peer in PROCEEDING state.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvClientFsmT1S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvClientFsmT1S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{

    TRC2(soTxnInvClientFsmT1S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO240, (ErrVal) 0, "soTxnInvClientFsmT1S3: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] 1XX (Inv) From Peer"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*
     * Handling of 1xx in "proceeding" state is similar to handling  2xx
     * in "calling" state. Except that timer A & B must have already st-
     * opped.
     */
      RETVALUE (soTxnInvClientFsmT1S2 (transCb, evnt));

} /* End of Fn (soTxnInvClientFsmT1S3) */




/*
*
*       Fun:   soTxnInvClientFsmT2S2
*
*       Desc:  This function is part of INVITE Client transaction. It 
               handles 2xx response from peer in CALLING state.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvClientFsmT2S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvClientFsmT2S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    S16             ret;
    SoUserCtxt      tmpUserContext;
    SoEntCb         *tmpEntCb;
    SoCLegCb        *tmpCLegCb;

    TRC2(soTxnInvClientFsmT2S2);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO241, (ErrVal) 0, "soTxnInvClientFsmT2S2: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      if (transCb->transState == SO_TRANS_CLIENT_CALLING)
      {
        SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                     "\n[TRANS] 2XX (Inv) From Peer"));
        SO_TXN_DEBUG_PRINT (transCb);
      }
#endif

    /*---- If this is first response, delete request event structure ----*/
      SO_TXN_DEL_EVENT (transCb, transCb->evnt);

    /*--- After first response, encoded request message is not needed ---*/
      SO_TXN_DEL_MBUF (transCb->retxMsg);

    /*----- After first response, DNS Query CB is not longer needed -----*/
#ifdef SO_DNS
      SO_TXN_DEL_QUERYCB (transCb);
#endif

    /*- STEP 1: Successful final response received,MUST stop timers A&B -*/
    /* so038.201: replaced with macro to check for UDP transport */
      if (SO_TCM_UDP_TRANSPORT(transCb->transport))
      {
        soSchedTmr (transCb, SO_TMR_TRANS_A, TMR_STOP, 0);

#if (defined(SO_NAT) && defined(SO_USE_UDP_SRVR))
        soSchedTmr (transCb, SO_TMR_TRANS_NATTMR, TMR_STOP, 0);
#endif              
      }

      soSchedTmr (transCb, SO_TMR_TRANS_B, TMR_STOP, 0);

    /* 
     * Invite client trasaction is completed on receiving 2xx response.
     * So, first delete the transaction and then pass the final respo-
     * nse to dialog layer as the last step.
     */
      cmMemcpy ((U8 *)&tmpUserContext, (U8 *)&transCb->userContext,
                sizeof (SoUserCtxt));

      tmpEntCb  = transCb->entCb;
      tmpCLegCb = (SoCLegCb *)transCb->cLeg;

      transCb->transState = SO_TRANS_CLIENT_TERMINATED;

      soTxnDeleteTrans (transCb);
     
      ret = soDlgUaIncRsp (tmpEntCb,
                           evnt,
                           tmpCLegCb,
                           &tmpUserContext);
     /*
      * NOTE: If the above function returns failure, dialog layer MUST
      *       have taken appropriate action to delete dialog (if requ-
      *       ired). Just return RFAILED so that  transport can delete
      *       event structure.
      */

      RETVALUE (ret);
      
} /* End of Fn (soTxnInvClientFsmT2S2) */




/*
*
*       Fun:   soTxnInvClientFsmT2S3
*
*       Desc:  This function is part of INVITE Client transaction. It 
               handles 2xx response from peer in PROCEEDING state.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return error code.
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvClientFsmT2S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvClientFsmT2S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{

    TRC2(soTxnInvClientFsmT2S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO242, (ErrVal) 0, "soTxnInvClientFsmT2S3: "
                   "Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] 2XX (Inv) From Peer"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*
     * Handling of 2xx in "proceeding" state is similar to handling  2xx
     * in "calling" state. Except that timer A & B must have already st-
     * opped.
     */
      RETVALUE (soTxnInvClientFsmT2S2 (transCb, evnt));
      
} /* End of Fn (soTxnInvClientFsmT2S3) */




/*
*
*       Fun:   soTxnInvClientFsmT3S2
*
*       Desc:  This function is part of INVITE Client  transaction. It 
               handles 3-6xx final response from peer in CALLING state
*              
*
*       Ret:   If success, return ROK 
*              If failure, return error code.
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvClientFsmT3S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvClientFsmT3S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    S16           ret;
    SoUserCtxt   tmpUserContext;
    SoEntCb      *tmpEntCb;
    SoCLegCb     *tmpCLegCb;
    SoEvnt       *ackEvnt;

    TRC2(soTxnInvClientFsmT3S2);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO243, (ErrVal) 0, "soTxnInvClientFsmT3S2: "
                   "Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }

      if (transCb->transState == SO_TRANS_CLIENT_CALLING)
      {
        SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                     "\n[TRANS] 3-6XX (Inv) From Peer"));
        SO_TXN_DEBUG_PRINT (transCb);
      }
#endif

    /*
     * NOTE: If the function returns failure before passing response to 
     *       dialog layer, it must trigger deletion of call leg,if this
     *       was the last transaction.
     */

    /*-- If this is first response,delete request event structure --*/
      SO_TXN_DEL_EVENT (transCb, transCb->evnt);

    /* After first response, encoded request message is not needed -*/
      SO_TXN_DEL_MBUF (transCb->retxMsg);

    /*-- After first response, DNS Query CB is not longer needed ---*/
#ifdef SO_DNS
      SO_TXN_DEL_QUERYCB (transCb);
#endif

    /*---- STEP 1: Final response received,MUST stop timers A&B ----*/
    /* so038.201: replaced with macro to check for UDP transport */
      if (SO_TCM_UDP_TRANSPORT(transCb->transport))
      {
        soSchedTmr (transCb, SO_TMR_TRANS_A, TMR_STOP, 0);

#if (defined(SO_NAT) && defined(SO_USE_UDP_SRVR))
        soSchedTmr (transCb, SO_TMR_TRANS_NATTMR, TMR_STOP, 0);
#endif              
      }

      soSchedTmr (transCb, SO_TMR_TRANS_B, TMR_STOP, 0);

    /*- STEP 2: Generate and send ACK for the 3-6xx final response -*/
      if ((soTxnGenAck  (transCb, evnt, &ackEvnt) != ROK) ||
          (soTxnSendAck (transCb, ackEvnt)        != ROK))
      {
         soTxnDeleteTransFromDiag (transCb);
         RETVALUE (RFAILED);
      }

     /* 
      * For reliable transport, Invite client  trasaction is completed on
      * receiving 3-6xx response.
      * So, first delete the transaction and then pass the final response
      * to dialog layer as the last step.
      */

      if ((transCb->transport == LSO_TPTPROT_TCP) ||
          (transCb->transport == LSO_TPTPROT_TLS_TCP))
      {
         cmMemcpy ((U8 *)&tmpUserContext, (U8 *)&transCb->userContext,
                   sizeof (SoUserCtxt));

         tmpEntCb  = transCb->entCb;
         tmpCLegCb = (SoCLegCb *)transCb->cLeg;

         transCb->transState = SO_TRANS_CLIENT_TERMINATED;
         soTxnDeleteTrans (transCb);

         /*------- Pass response to dialog layer as last step ------*/
          ret = soDlgUaIncRsp (tmpEntCb,
                               evnt,
                               tmpCLegCb,
                               &tmpUserContext);
      }

     /*
      * For Unreliable transport,start timer D to absorb any retransmitted
      * 3-6xx response. Transaction is  deleted  ones the Timer D expires.
      */
      else
      {
        /*------------- Enter COMPLETED State -------------*/
         transCb->transState = SO_TRANS_CLIENT_COMPLETED;

         ret = soSchedTmr (transCb, SO_TMR_TRANS_D, TMR_START,
                           SO_TMRVAL_SIP_32S);
         if (ret != ROK)
         {
            soTxnDeleteTransFromDiag (transCb);
            RETVALUE (ret);
         }

         if (ret == ROK)
           /*- Pass response to dialog layer as last step -*/
           ret = soDlgUaIncRsp (transCb->entCb,
                                evnt,
                                CLEG,
                                &transCb->userContext);
      }

     /*
      * NOTE: If the soDlgUaIncRsp  returns failure, dialog layer MUST
      *       have taken appropriate action to delete dialog (if requ-
      *       ired). Just return RFAILED so that  transport can delete
      *       event structure.
      */
      
      RETVALUE (ret);

} /* End of Fn (soTxnInvClientFsmT3S2) */



/*
*
*       Fun:   soTxnInvClientFsmT3S3
*
*       Desc:  This function is part of INVITE Client transaction. It 
*              handles 3-6xx final  response from peer in  PROCEEDING 
*              state.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvClientFsmT3S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvClientFsmT3S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    TRC2(soTxnInvClientFsmT3S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO244, (ErrVal) 0, "soTxnInvClientFsmT3S3: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] 3-6XX (Inv) From Peer"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*
     * Handling of 3-6xx response in proceeding state is similar to pro-
     * cessing of 3-6xx response in  calling state (except for  the fact 
     * that timer A & B will not running in proceedidng state.
     */

      RETVALUE (soTxnInvClientFsmT3S2 (transCb, evnt));

      
} /* End of Fn (soTxnInvClientFsmT3S3) */



/*
*
*       Fun:   soTxnInvClientFsmT3S4
*
*       Desc:  This function is part of INVITE Client transaction. It 
*              handles 3-6xx final response from peer in COMPLETED state
*              
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvClientFsmT3S4
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvClientFsmT3S4(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    S16      ret;
    SoEvnt   *ackEvnt;

    TRC2(soTxnInvClientFsmT3S4);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO245, (ErrVal) 0, "soTxnInvClientFsmT3S4: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] 3-6XX (Inv) From Peer"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*- STEP 1: retransmit the ACK for the 3-6xx final response -*/

      if (transCb->retxMsg)
      {
        /*- Encoded ACK is present. Just retransmit the request -*/ 
         ret = soTptSendReTransReq (transCb->entCb,
                                    &transCb->destAddr,
                                    &transCb->tcmConn,
                                    transCb->retxMsg);
      }
      else
      {
        /* 
         * Generate ACK event and send. Note that this case will a-
         * rise only for multithreaded encoder cases.
         */ 
         ret = soTxnGenAck (transCb, evnt, &ackEvnt);

         if (ret == ROK)
           ret = soTxnSendAck (transCb, ackEvnt);
      }
      
    /*
     * NOTE: There is no need to take any action if the above func-
     *       tion returns failure. Transaction will be deleted ones
     *       timer D expires.
     */

     /*- Delete event structure -*/
      (Void) soCmFreeEvent (evnt);

      RETVALUE (ROK);
      
} /* End of Fn (soTxnInvClientFsmT3S4) */



/*
*
*       Fun:   soTxnInvClientFsmT4S2
*
*       Desc:  This function is part of INVITE Client transaction. It
*              handles timeout of Timer A in Calling state.
*
*       Ret:   If success, ROK
*              if failure, RFAILED
*
*       Notes: This function will only be called for Unreliable tran-
*              sport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvClientFsmT4S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16   soTxnInvClientFsmT4S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    S16 ret;

    TRC2(soTxnInvClientFsmT4S2);

#if (ERRCLASS & ERRCLS_DEBUG)
      /* so038.201: replaced with macro to check for UDP transport */
      if (! ((transCb) && (transCb->transState == SO_TRANS_CLIENT_CALLING) &&
             (SO_TCM_UDP_TRANSPORT(transCb->transport))))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO246, (ErrVal) 0, "soTxnInvClientFsmT4S2: "
                   "Invalid parameter/state");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Timer A (Inv) Expires"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*- STEP 1:Pass INVITE Request to transport layer for retrans -*/
      if (transCb->retxMsg)
      {
         ret = soTptSendReTransReq (transCb->entCb,
                                    &transCb->destAddr,
                                    &transCb->tcmConn,
                                    transCb->retxMsg);
         if (ret != ROK)
         {
            soTxnDeleteTransFromDiag (transCb);
            RETVALUE (RFAILED);
         }
      }

    /*--- STEP 2: ReStart Timer A with twice the previous value ---*/
      transCb->retxTmrVal = 2 * transCb->retxTmrVal;

      ret = soSchedTmr (transCb, SO_TMR_TRANS_A, TMR_START,
                        transCb->retxTmrVal);
      if (ret != ROK)
      {
         soTxnDeleteTransFromDiag (transCb);
         RETVALUE (RFAILED);
      }

      RETVALUE (ROK);

} /* End of Fn (soTxnInvClientFsmT4S2) */



/*
*
*       Fun:   soTxnInvClientFsmT5S2
*
*       Desc:  This function is part of INVITE Client transaction. It 
*              handles timeout of Timer B in Calling state.
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16 soTxnInvClientFsmT5S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16 soTxnInvClientFsmT5S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    SoUserCtxt     tmpUserContext;
    SoEntCb        *tmpEntCb;
    SoEvnt         *tmpEvnt;
    SoCLegCb       *tmpCLeg;

    TRC2(soTxnInvClientFsmT5S2);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! ((transCb) && (transCb->transState == SO_TRANS_CLIENT_CALLING)))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO247, (ErrVal) 0, "soTxnInvClientFsmT5S2: "
                   "Invalid parameter/state");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Timer B (Inv) Expires"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif
   
    /*
     * NO response at all was received from the peer. Terminate
     * transaction and notify dialog layer about timeout.
     *
     * NOTE: ErrInd  contains userContext incuding DNS Query CB.
     */
     cmMemcpy ((U8 *)&tmpUserContext, (U8 *)&transCb->userContext,
               sizeof (SoUserCtxt));

#ifdef SO_COMPRESS
     tmpUserContext.sigCompSupp = transCb->tcmConn.sigCompSupp;
#endif
     tmpUserContext.transport   = transCb->transport;
     cmMemcpy ((U8 *) &tmpUserContext.destAddr,
               (U8 *) &transCb->destAddr,
               sizeof (CmTptAddr));

     cmMemset ((U8 *)&transCb->userContext, 0, sizeof (SoUserCtxt));
     
     tmpEntCb     = transCb->entCb;
     tmpEvnt      = transCb->evnt; transCb->evnt = (SoEvnt *)NULLP;
     tmpCLeg      = (SoCLegCb *)transCb->cLeg;

     transCb->transState = SO_TRANS_CLIENT_TERMINATED;
     soTxnDeleteTrans (transCb);

     /*---- Notify dialog layer about the timeout ----*/
     (Void) soDlgErrInd (tmpCLeg,
                         SO_TRANS_TIMEOUT,
                         tmpEvnt, /* Pass request event to user */
                         &tmpUserContext);
     RETVALUE (ROK);

} /* End of Fn (soTxnInvClientFsmT5S2) */



/*
*
*       Fun:   soTxnInvClientFsmT6S4
*
*       Desc:  This function is part of INVITE Client transaction. It 
*              handles timeout of Timer D in Completed state.
*
*       Ret:   If success, ROK
*              if failure, RFAILED
*
*       Notes: This function must be called only for unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvClientFsmT6S4
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16   soTxnInvClientFsmT6S4(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    TRC2(soTxnInvClientFsmT6S4);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! ((transCb) && (transCb->transState == SO_TRANS_CLIENT_COMPLETED)))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO248, (ErrVal) 0, "soTxnInvClientFsmT6S4: "
                   "Invalid parameter/state");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Timer B (Inv) Expires"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif
   
    /*
     * Aleady waited for 32 sec for any  retransmitted  3-6xx final
     * response from peer. Now, delete the transaction and initiate
     * call leg deletion, if this was the last transaction.
     */
     transCb->transState = SO_TRANS_CLIENT_TERMINATED;
     soTxnDeleteTransFromDiag (transCb);

     RETVALUE (ROK);

} /* End of Fn (soTxnInvClientFsmT6S4) */



/*
*
*       Fun:   soTxnInvClientFsmT7S2
*
*       Desc:  This function is part of INVITE Client transaction. It 
*              handles timeout of NAT Timer in Calling state.
*
*       Ret:   If success, ROK
*              if failure, RFAILED
*
*       Notes: This function must be called only for unreliable tran-
*              sport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvClientFsmT7S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16   soTxnInvClientFsmT7S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
   S16 ret;
#endif

   TRC2(soTxnInvClientFsmT7S2);

#if (ERRCLASS & ERRCLS_DEBUG)
   /* 
    * so015.201: Corrected Error Check Since This Funcion Is Called
    *            From soTxnInvClientFsmT7S3() also.
    */
   if (! ((transCb)                                        &&
         ((transCb->transState == SO_TRANS_CLIENT_CALLING) ||
          (transCb->transState == SO_TRANS_CLIENT_PROCEEDING))))
   {
      SOLOGERROR(ERRCLS_DEBUG, ESO249, (ErrVal) 0, "soTxnInvClientFsmT7S2: "
                   "Invalid parameter/state");
       RETVALUE (RFAILED);
   }

   SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                  "\n[TRANS] NAT Timer Expires"));
   SO_TXN_DEBUG_PRINT (transCb);
#endif
   
#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))

   /*- STEP 1:Pass INVITE Request to transport layer for retrans -*/

   if (transCb->retxMsg)
   {
      ret = soTptSendReTransReq (transCb->entCb,
                                 &transCb->destAddr,
                                 &transCb->tcmConn,
                                 transCb->retxMsg);
      if (ret != ROK)
      {
         soTxnDeleteTransFromDiag (transCb);
         RETVALUE (RFAILED);
      }
   }

   /*-------- STEP 2: Re-Start NAT Timer With Same Value ---------*/
   ret = soSchedTmr (transCb, SO_TMR_TRANS_NATTMR, TMR_START,
                     soCb.reCfg.tmrReTxCfg.natTmrVal);
   if (ret != ROK)
   {
      soTxnDeleteTransFromDiag (transCb);
      RETVALUE (RFAILED);
   }
#endif
   
   RETVALUE (ROK);
} /* End of Fn (soTxnInvClientFsmT7S2) */



/*
*
*       Fun:   soTxnInvClientFsmT7S3
*
*       Desc:  This function is part of INVITE Client transaction. It 
*              handles timeout of NAT Timer in Proceeding state.
*
*       Ret:   If success, ROK
*              if failure, RFAILED
*
*       Notes: This function must be called only for unreliable tran-
*              sport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvClientFsmT7S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16   soTxnInvClientFsmT7S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
   
   TRC2(soTxnInvClientFsmT7S3);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (! ((transCb) && (transCb->transState == SO_TRANS_CLIENT_PROCEEDING)))
   {
      SOLOGERROR(ERRCLS_DEBUG, ESO250, (ErrVal) 0, "soTxnInvClientFsmT7S3: "
                   "Invalid parameter/state");
       RETVALUE (RFAILED);
   }

   SO_TXN_DEBUG_PRINT (transCb);

#endif

  /*
   * Handling of NAT Timer expiry in "proceeding" state is similar to
   * handling of this timer expiry in "calling" state.
   */
   RETVALUE (soTxnInvClientFsmT7S2 (transCb, evnt));

} /* End of Fn (soTxnInvClientFsmT7S3) */




/*
*
*       Fun:   soTxnInvClientError
*
*       Desc:  This function is part of INVITE Client transacti-
*              on. It handles incorrect triggers in given state.
*              
*       Ret:   returns RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvClientError
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16   soTxnInvClientError (transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    TRC2(soTxnInvClientError);

   /*
    * Incorrect trigger received in the given transaction state.
    * Sipmly ignore the trigger.
    * NOTE: This may arise either due to incorrect message from
    *       peer or local errors.
    */

    SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
              "\n[TRANS] Invalid Trigger For Invite Client"));

    SO_TXN_DEBUG_PRINT (transCb);

    RETVALUE (RFAILED);

} /* End of Fn (soTxnInvClientError) */





/*---------- NON INVITE CLIENT TRANSACTION STATE FUNCTIONS ------------*/



/*
*
*       Fun:   soTxnNonInvClientFsmT0S1
*
*       Desc:  This function is part of Non INVITE Client transaction. It 
*              handles NON-INVITE request from user in IDLE state.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return SIP user related error code.
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvClientFsmT0S1
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16   soTxnNonInvClientFsmT0S1(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    S16        ret;
    SoVia      *via;

    TRC2(soTxnNonInvClientFsmT0S1);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO251, (ErrVal) 0,"soTxnNonInvClientFsmT0S1:"
                   " Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Sending Non Invite"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*- STEP 1: Pass Non INVITE Request to transport layer for transmission -*/
      ret = soTptSendInitialReq (transCb->entCb,
                                 SSAP,
                                 &transCb->destAddr, /* Dest Address  */
                                 transCb->transport, /* TCP/UDP       */
                                 transCb->evnt,      /* Request Msg   */
                                 TRUE,               /* Modify Transport */
                                 &transCb->branchId, /* Branch Identifier*/
                                 &transCb->tcmConn,  /* Server/Client Cb */
                                 &transCb->retxMsg); /* Encoded Msg   */

      if (ret == SO_TPT_TRANSPORT_CHANGED)
      {
        /*
         * Transport was changed from UDP to TCP by transport layer.
         * MUST retry request if TCP connection fails in this state.
         */
         transCb->transportChanged = TRUE;
         transCb->transport        = LSO_TPTPROT_TCP;

      }
      else if (ret == SO_TPT_MULTI_THREADED_ENC)
      {
        /*
         * Encoding not finished YET. The rest of functionality for
         * this state will be done in the callback function.
         */
        /*----------- Save VIA send in request message ----------*/
         SO_GET_VIA_FROM_EVENT (transCb->evnt, via);
         if (soUtlCpySoVia (&transCb->via, via, NULLP) != ROK)
             RETVALUE (ret);

         transCb->retxMsg = NULLP;
         RETVALUE (ROK);
      }
      else if (ret != ROK)
         RETVALUE (ret);

     /*------------- Save VIA send in request message -----------*/
      SO_GET_VIA_FROM_EVENT (transCb->evnt, via);
      if (soUtlCpySoVia (&transCb->via, via, NULLP) != ROK)
         RETVALUE (ret);

    /*--- STEP 2: For Unreliable Transport Start Timer E (T1) ---*/
    /* so038.201: replaced with macro to check for UDP transport */
      if (SO_TCM_UDP_TRANSPORT(transCb->transport))
      {
        transCb->retxTmrVal = soCb.reCfg.tmrReTxCfg.t1;


        ret = soSchedTmr (transCb, SO_TMR_TRANS_E, TMR_START,
                          transCb->retxTmrVal);
        if (ret != ROK)
          RETVALUE (SOT_ERR_UNKNOWN);
      }

    /*----- STEP 3: For All Transport Start Timer F (64*T1) -----*/
      ret = soSchedTmr (transCb, SO_TMR_TRANS_F, TMR_START,
                        64*soCb.reCfg.tmrReTxCfg.t1 + SO_TMRVAL_1_S*2);
    /*
     * 2 seconds is added to timer value just to make sure that t-
     * imerF and last instance of timerE does not timeout simutan-
     * eously.
     */
      if (ret != ROK)
          RETVALUE (SOT_ERR_UNKNOWN);
      
    /*------- Finally, change state to Trying and return --------*/
      transCb->transState = SO_TRANS_CLIENT_TRYING;

      RETVALUE (ret);

} /* End of Fn (soTxnNonInvClientFsmT0S1) */




/*
*       Fun:   soTxnNonInvClientFsmT1S2
*
*       Desc:  This function is part of NON INVITE Client transaction. It 
*              handles 1xx response from peer in TRYING state.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvClientFsmT1S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnNonInvClientFsmT1S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    S16 ret;

    TRC2(soTxnNonInvClientFsmT1S2);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO252, (ErrVal) 0,"soTxnNonInvClientFsmT1S2:"
                   " Invalid parameter");
        RETVALUE (RFAILED);
      }

      if (transCb->transState == SO_TRANS_CLIENT_TRYING)
      {
        SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                     "\n[TRANS] 1XX (non INV) From Peer"));
        SO_TXN_DEBUG_PRINT (transCb);
      }
#endif

    /* 
     * so015.201: Request event should not be deleted as Timer F is st-
     *            ill running.  Request event will be required if timer
     *            F expires.
     */

    /*--- After first response, DNS Query CB is not longer needed ---*/
#ifdef SO_DNS
      SO_TXN_DEL_QUERYCB (transCb);
#endif

    /*--------- STEP 1: change state to PROCEEDING and return -------*/
      transCb->transState = SO_TRANS_CLIENT_PROCEEDING;

    /*-- STEP 2: Pass the Non INVITE Prov. Response to dialog layer -*/

     /*--- so018.201: Do not pass retransmitted 100 to dialog user --*/
      if ((evnt->t.response.statusLine.statusCode.val == SOT_RSP_100_TRYING) &&
          (evnt->sipBody.bodyType.pres == NOTPRSNT) &&
          (transCb->prevRspCode        == SOT_RSP_100_TRYING))
      {
        SODBGP_SO (SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                  "\n[TRANS]: Dropping Retx 100 Response"));
        (Void) soCmFreeEvent (evnt);
        RETVALUE (ROK);
      }

      transCb->prevRspCode = evnt->t.response.statusLine.statusCode.val;

      ret = soDlgUaIncRsp (transCb->entCb,
                           evnt,
                           CLEG,
                           &transCb->userContext);
     /*
      * NOTE: If the above function returns failure, just return RFAIL-
      *       ED so that transport can delete event structure.
      */
  
    /*------------- NOTE: Timer E & F will continue to run ----------*/

      RETVALUE (ret);

} /* End of Fn (soTxnNonInvClientFsmT1S2) */




/*
*
*       Fun:   soTxnNonInvClientFsmT1S3
*
*       Desc:  This function is part of NON INVITE Client transaction. It 
               handles 1xx response from peer in PROCEEDING state.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvClientFsmT1S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnNonInvClientFsmT1S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{

    TRC2(soTxnNonInvClientFsmT1S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO253, (ErrVal) 0,"soTxnNonInvClientFsmT1S3:"
                   " Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] 1XX (non INV) From Peer"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*
     * Handling of 1xx in "proceeding" state is similar to handling  1xx
     * in "trying" state. 
     */
      RETVALUE (soTxnNonInvClientFsmT1S2 (transCb, evnt));

} /* End of Fn (soTxnNonInvClientFsmT1S3) */





/*
*
*       Fun:   soTxnNonInvClientFsmT2S2
*
*       Desc:  This function is part of NON INVITE Client transaction. It 
               handles 2-6xx final response from peer in TRYING state
*              
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvClientFsmT2S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnNonInvClientFsmT2S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    S16            ret;
    SoUserCtxt     tmpUserContext;
    SoEntCb        *tmpEntCb;
    SoCLegCb       *tmpCLegCb;

    TRC2(soTxnNonInvClientFsmT2S2);

    ret = ROK;
    tmpEntCb = NULLP;
    tmpCLegCb = NULLP;

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO254, (ErrVal) 0,"soTxnNonInvClientFsmT2S2:"
                   " Invalid parameter");
        RETVALUE (RFAILED);
      }

      if (transCb->transState == SO_TRANS_CLIENT_TRYING)
      {
        SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                     "\n[TRANS] 2-6XX (non INV) From Peer"));
        SO_TXN_DEBUG_PRINT (transCb);
      }
#endif

    /*
     * NOTE: If the function returns failure before passing response to 
     *       dialog layer, it must trigger deletion of call leg,if this
     *       was the last transaction.
     */

    /*-- If this is first response,delete request event structure --*/
      SO_TXN_DEL_EVENT (transCb, transCb->evnt);

    /*-------- Encoded Request message is no longer required -------*/
      SO_TXN_DEL_MBUF (transCb->retxMsg);

    /*-- After first response, DNS Query CB is not longer needed ---*/
#ifdef SO_DNS
      SO_TXN_DEL_QUERYCB (transCb);
#endif

    /*---- STEP 1: Final response received,MUST stop timers E&F ----*/
    /* so038.201: replaced with macro to check for UDP transport */
      if (SO_TCM_UDP_TRANSPORT(transCb->transport))
        soSchedTmr (transCb, SO_TMR_TRANS_E, TMR_STOP, 0);

      soSchedTmr (transCb, SO_TMR_TRANS_F, TMR_STOP, 0);

     /* 
      * For reliable transport, Non Invite client trasaction is completed 
      * on receiving 2-6xx final response.
      * So, first delete the transaction and then pass the final response
      * to dialog layer as the last step.
      */
      if ((transCb->transport == LSO_TPTPROT_TCP) ||
          (transCb->transport == LSO_TPTPROT_TLS_TCP))
      {
         cmMemcpy ((U8 *)&tmpUserContext, (U8 *)&transCb->userContext,
                   sizeof (SoUserCtxt));

         tmpEntCb  = transCb->entCb;
         tmpCLegCb = (SoCLegCb *)transCb->cLeg;

         transCb->transState = SO_TRANS_CLIENT_TERMINATED;
         soTxnDeleteTrans (transCb);

         /*------- Pass response to dialog layer as last step ------*/
          ret = soDlgUaIncRsp (tmpEntCb,
                               evnt,
                               tmpCLegCb,
                               &tmpUserContext);
      }

     /* 
      * For Unreliable transport,start timer K to absorb any retransmitted
      * 2-6xx response. Transaction is  deleted  ones the Timer K expires.
      */ 
      else
      {
         /*------------- Enter COMPLETED State ------------*/
         transCb->transState = SO_TRANS_CLIENT_COMPLETED;

         ret = soSchedTmr (transCb, SO_TMR_TRANS_K, TMR_START,
                           soCb.reCfg.tmrReTxCfg.t4);
         if (ret != ROK)
         {
            soTxnDeleteTransFromDiag (transCb);
            RETVALUE (ret);
         }

         if (ret == ROK)
           /*- Pass response to dialog layer as last step -*/
           ret = soDlgUaIncRsp (transCb->entCb,
                                evnt,
                                CLEG,
                                &transCb->userContext);
      }

     /*
      * NOTE: If the soDlgUaIncRsp returns  failure, dialog layer MUST
      *       have taken appropriate action to delete dialog (if requ-
      *       ired). Just return RFAILED so that  transport can delete
      *       event structure.
      */
  
      RETVALUE (ret);

} /* End of Fn (soTxnNonInvClientFsmT2S2) */



/*
*
*       Fun:   soTxnNonInvClientFsmT2S3
*
*       Desc:  This function is part of NON INVITE Client  transaction. It 
*              handles 2-6xx final response from peer in PROCEEDING state.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvClientFsmT2S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnNonInvClientFsmT2S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    TRC2(soTxnNonInvClientFsmT2S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR (ERRCLS_DEBUG, ESO255, (ErrVal) 0, 
                   "soTxnNonInvClientFsmT2S3: Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] 2-6XX (non INV) From Peer"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*
     * Handling of 2-6xx response in proceeding state is similar to pro-
     * cessing of 2-6xx response in  calling state (except for  the fact 
     * that timer E & F will not running in proceedidng state.)
     */
      RETVALUE (soTxnNonInvClientFsmT2S2 (transCb, evnt));
      
} /* End of Fn (soTxnNonInvClientFsmT2S3) */




/*
*
*       Fun:   soTxnNonInvClientFsmT2S4
*
*       Desc:  This function is part of NON INVITE Client  transaction. It 
*              handles 2-6xx final response from peer in COMPLETED  state.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvClientFsmT2S4
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnNonInvClientFsmT2S4(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    TRC2(soTxnNonInvClientFsmT2S4);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR (ERRCLS_DEBUG, ESO256, (ErrVal) 0, 
                   "soTxnNonInvClientFsmT2S4: Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] 2-6XX (non INV) From Peer"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*--- No action required. Just dump the event ---*/
      soCmFreeEvent ((evnt));

      RETVALUE (ROK);
      
} /* End of Fn (soTxnNonInvClientFsmT2S4) */




/*
*
*       Fun:   soTxnNonInvClientFsmT3S2
*
*       Desc:  This function is part of NON INVITE Client transaction. It 
*              handles timeout of Timer E in TRYING state.
*              
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: This function will only be called for Unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16  soTxnNonInvClientFsmT3S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16  soTxnNonInvClientFsmT3S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    S16 ret;

    TRC2(soTxnNonInvClientFsmT3S2);

#if (ERRCLASS & ERRCLS_DEBUG)
    /* so038.201: replaced with macro to check for UDP transport */
      if (! ((transCb) && SO_TCM_UDP_TRANSPORT(transCb->transport)))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO257, (ErrVal) 0,"soTxnNonInvClientFsmT3S2:"
                   " Invalid parameter/state");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Timer E (non INV) Expires"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*- STEP 1:Pass Non INVITE Request to transport layer for retransmission -*/
      if (transCb->retxMsg)
      {
          ret = soTptSendReTransReq (transCb->entCb,
                                     &transCb->destAddr,
                                     &transCb->tcmConn,
                                     transCb->retxMsg);
          if (ret != ROK)
          {
             soTxnDeleteTransFromDiag (transCb);
             RETVALUE (RFAILED);
          }
      }

    /*-- STEP 2: Restart Timer E with value MIN((2 * prevoius val), T2) --*/
      transCb->retxTmrVal = 2 * transCb->retxTmrVal;
      if (transCb->retxTmrVal > soCb.reCfg.tmrReTxCfg.t2)
          transCb->retxTmrVal = soCb.reCfg.tmrReTxCfg.t2;


      ret = soSchedTmr(transCb, SO_TMR_TRANS_E, TMR_START, transCb->retxTmrVal);
      if (ret != ROK)
      {
         soTxnDeleteTransFromDiag (transCb);
         RETVALUE (RFAILED);
      }

      RETVALUE (ROK);

} /* End of Fn (soTxnNonInvClientFsmT3S2) */




/*
*
*       Fun:   soTxnNonInvClientFsmT3S3
*
*       Desc:  This function is part of NON INVITE Client transaction. It 
*              handles timeout of Timer E in PROCEEDING state.
*              
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16  soTxnNonInvClientFsmT3S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16  soTxnNonInvClientFsmT3S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    S16 ret;

    TRC2(soTxnNonInvClientFsmT3S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO258, (ErrVal) 0,"soTxnNonInvClientFsmT3S3:"
                   " Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Timer E (non INV) Expires"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*- STEP 1:Pass Non INVITE Request to transport layer for retransmission -*/
      if (transCb->retxMsg)
      {
         ret = soTptSendReTransReq (transCb->entCb,
                                    &transCb->destAddr,
                                    &transCb->tcmConn,
                                    transCb->retxMsg);
         if (ret != ROK)
         {
            soTxnDeleteTransFromDiag (transCb);
            RETVALUE (RFAILED);
         }
      }

    /*------- STEP 2: Continue retransmission at T2 interval -------*/


      ret = soSchedTmr (transCb, SO_TMR_TRANS_E, TMR_START,
                        soCb.reCfg.tmrReTxCfg.t2);
      if (ret != ROK)
      {
         soTxnDeleteTransFromDiag (transCb);
         RETVALUE (RFAILED);
      }

      RETVALUE (ROK);

} /* End of Fn (soTxnNonInvClientFsmT3S3) */




/*
*
*       Fun:   soTxnNonInvClientFsmT4S2
*
*       Desc:  This function is part of NON INVITE Client transaction. It 
*              handles timeout of Timer F in TRYING state.
*
*       Ret:   If success, ROK
*              if failure, RFAILED
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16  soTxnNonInvClientFsmT4S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16  soTxnNonInvClientFsmT4S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    SoUserCtxt     tmpUserContext;
    SoEntCb        *tmpEntCb;
    SoEvnt         *tmpEvnt;
    SoCLegCb       *tmpCLeg;

    TRC2(soTxnNonInvClientFsmT4S2);

#if (ERRCLASS & ERRCLS_DEBUG)
     /* 
      * so015.201:  Corrected Error Check Since This  Funcion Is Called From
      *             soTxnNonInvClientFsmT4S3() also.
      */
      if (! ((transCb)                                       &&
            ((transCb->transState == SO_TRANS_CLIENT_TRYING) ||
             (transCb->transState == SO_TRANS_CLIENT_PROCEEDING))))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO259, (ErrVal) 0, "soTxnNonInvClientFsmT4S2:"
                   " Invalid parameter/state");
        RETVALUE (RFAILED);
      }
 
      if (transCb->transState == SO_TRANS_CLIENT_TRYING)
      {
        SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                     "\n[TRANS] Timer F (non INV) Expires"));
        SO_TXN_DEBUG_PRINT (transCb);
      }
#endif

    /*
     * NO response at all was received from the peer. Terminate transaction 
     * and notify the dialog layer.
     */
     cmMemcpy ((U8 *)&tmpUserContext, (U8 *)&transCb->userContext,
               sizeof (SoUserCtxt));

#ifdef SO_COMPRESS
     tmpUserContext.sigCompSupp = transCb->tcmConn.sigCompSupp;
#endif
     tmpUserContext.transport   = transCb->transport;
     cmMemcpy ((U8 *) &tmpUserContext.destAddr,
               (U8 *) &transCb->destAddr,
               sizeof (CmTptAddr));

     cmMemset ((U8 *)&transCb->userContext, 0, sizeof (SoUserCtxt));

     tmpEntCb    = transCb->entCb;
     tmpEvnt     = transCb->evnt; transCb->evnt = (SoEvnt *)NULLP;
     tmpCLeg     = (SoCLegCb *)transCb->cLeg;
 
     transCb->transState = SO_TRANS_CLIENT_TERMINATED;
     soTxnDeleteTrans (transCb);

      /*---- Notify dialog layer about the timeout ----*/
      (Void) soDlgErrInd (tmpCLeg,
                          SO_TRANS_TIMEOUT,
                          tmpEvnt, /* Pass request event to user */
                          &tmpUserContext);
      RETVALUE (ROK);

} /* End of Fn (soTxnNonInvClientFsmT4S2) */





/*
*
*       Fun:   soTxnNonInvClientFsmT4S3
*
*       Desc:  This function is part of NON INVITE Client transaction. It 
*              handles timeout of Timer F in PROCEEDING state.
*              
*       Ret:   If success, ROK
*              if failure, RFAILED
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16  soTxnNonInvClientFsmT4S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16  soTxnNonInvClientFsmT4S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{

    TRC2(soTxnNonInvClientFsmT4S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! ((transCb) && (transCb->transState == SO_TRANS_CLIENT_PROCEEDING)))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO260, (ErrVal) 0, "soTxnNonInvClientFsmT4S3:"
                   " Invalid parameter/state");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Timer F (non INV) Expires"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif
   
    /*
     * No Final response from the peer node. The handling is similar to
     * handling of Timer E expiry in TRYING state.
     */
     RETVALUE (soTxnNonInvClientFsmT4S2 (transCb, evnt));

    /*
     * NOTE: In this case there will no request event in TCB as it  was
     *       deleted when provisional response from user. So dialog la-
     *       yer should no retry request.
     */

} /* End of Fn (soTxnNonInvClientFsmT4S3) */



/*
*
*       Fun:   soTxnNonInvClientFsmT5S4
*
*       Desc:  This function is part of NON INVITE Client transaction. It 
*              handles timeout of Timer K in COMPLETED state.
*
*       Ret:   If success, ROK
*              if failure, RFAILED
*
*       Notes: This function must be called only for unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16  soTxnNonInvClientFsmT5S4
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16  soTxnNonInvClientFsmT5S4(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    TRC2(soTxnNonInvClientFsmT5S4);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! ((transCb) && (transCb->transState == SO_TRANS_CLIENT_COMPLETED)))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO261, (ErrVal) 0, "soTxnNonInvClientFsmT5S4:"
                   " Invalid parameter/state");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Timer K (non INV) Expires"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif
   
    /*
     * Aleady waited for T4 sec for any  retransmitted  2-6xx final
     * response from peer. Now, delete the transaction and initiate
     * call leg deletion, if this was the last transaction.
     * 
     */
     transCb->transState = SO_TRANS_CLIENT_TERMINATED;
     soTxnDeleteTransFromDiag (transCb);

     RETVALUE (ROK);

} /* End of Fn (soTxnNonInvClientFsmT5S4) */



/*
*
*       Fun:   soTxnNonInvClientError
*
*       Desc:  This function is part of NON INVITE Client transacti-
*              on. It handles incorrect triggers in given state.
*              
*       Ret:   returns RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvClientError
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16   soTxnNonInvClientError (transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    TRC2(soTxnNonInvClientError);

   /*
    * Incorrect trigger received in the given transaction state.
    * Sipmly ignore the trigger.
    * NOTE: This may arise either due to incorrect message from
    *       peer or local errors.
    */

    SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
              "\n[TRANS] Invalid Trigger For Non Invite Client"));

    SO_TXN_DEBUG_PRINT (transCb);

    RETVALUE (RFAILED);

} /* End of Fn (soTxnNonInvClientError) */





/*---------- INVITE SERVER TRANSACTION STATE FUNCTIONS ------------*/

/*
*
*       Fun:   soTxnInvServerFsmT0S1
*
*       Desc:  This function is part of INVITE Server transaction. It 
               handles INVITE request from peer in IDLE state.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED.
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvServerFsmT0S1
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvServerFsmT0S1(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    S16 ret;

    TRC2(soTxnInvServerFsmT0S1);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO262, (ErrVal) 0, "soTxnInvServerFsmT0S1: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf,
                                   "\n[TRANS] INVITE Received"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif
      
    /*------------ STEP 1: change state to PROCEEDING ---------------*/
      transCb->transState = SO_TRANS_INV_SERVER_PROCEEDING;

    
    /*---- STEP 2: Pass the INVITE Request to dialog layer ---*/
      ret = soDlgUaIncReq (transCb->entCb,
                           evnt,
                           transCb,
                           &transCb->tcmConn);
    /*
     * NOTE: If the above function  returns failure,  dialog/core layer
     *       MUST have deleted transaction (and in some cases call leg
     *       as well).
     */
      if (ret != ROK)
         RETVALUE (RFAILED);


      RETVALUE (ROK);

} /* End of Fn (soTxnInvServerFsmT0S1) */




/*
*
*       Fun:   soTxnInvServerFsmT0S2
*
*       Desc:  This function is  part of INVITE Server transaction. It 
*              handles INVITE request received from peer in PROCEEDING
*              state.
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: This function will only be called for Unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvServerFsmT0S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvServerFsmT0S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    S16 ret;

    TRC2(soTxnInvServerFsmT0S2);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO263, (ErrVal) 0, "soTxnInvServerFsmT0S2: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      if (transCb->transState == SO_TRANS_INV_SERVER_PROCEEDING)
      {
        SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                     "\n[TRANS] INVITE Received"));
        SO_TXN_DEBUG_PRINT (transCb);
      }
#endif

    /*
     * Retransmitted INVITE request received. Pass most recent
     * response to transport layer for retransmission.
     */
     if (transCb->retxMsg)
     {
         ret = soTptSendRsp (transCb->entCb,
                             SSAP,
                             &transCb->via,  /* Req VIA        */
                             NULLP,          /* No Rsp Evnt    */
                             &transCb->retxMsg, /* Encoded Rsp */
                             &transCb->tcmConn);
         if (ret != ROK)
         {
           /* 
            * This indicates fatal error. Delete TCB and inform dia-
            * log layer.
            */

            SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                    "\n[TRANS] Cannot Send Response Message "));

            soTxnDeleteTransFromDiag (transCb);
            RETVALUE (RFAILED);
         }
     }

    /*--- Deallocate Event ---*/
     (Void) soCmFreeEvent (evnt);

     RETVALUE (ROK);

} /* End of Fn (soTxnInvServerFsmT0S2) */



/*
*
*       Fun:   soTxnInvServerFsmT0S3
*
*       Desc:  This function is part of INVITE Server transaction. It 
*              handles INVITE request received from peer in COMPLETED
*              state.
*
*       Ret:   If success, return ROK 
*              If failure, return SIP user related error code.
*
*       Notes: This function will only be called for Unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvServerFsmT0S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvServerFsmT0S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    TRC2(soTxnInvServerFsmT0S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO264, (ErrVal) 0, "soTxnInvServerFsmT0S3: "
                   "Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] INVITE Received"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*
     * Handling of retransmitted INVITE request in completed state is
     * similar to handling in proceeding state.
     */
      RETVALUE (soTxnInvServerFsmT0S2 (transCb, evnt));

} /* End of Fn (soTxnInvServerFsmT0S3) */




/*
*
*       Fun:   soTxnInvServerFsmT0S4
*
*       Desc:  This function is part of INVITE Server transaction. It 
*              handles INVITE request received from peer in CONFIRMED
*              state.
*
*       Ret:   If success, return ROK 
*              If failure, return SIP user related error code.
*
*       Notes: This function will only be called for Unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvServerFsmT0S4
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvServerFsmT0S4(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{

    TRC2(soTxnInvServerFsmT0S4);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO265, (ErrVal) 0, "soTxnInvServerFsmT0S4: "
                   "Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] INVITE Received"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*
     * Handling of retransmitted INVITE request in completed state is
     * similar to handling in proceeding state.
     */
      RETVALUE (soTxnInvServerFsmT0S2 (transCb, evnt));

} /* End of Fn (soTxnInvServerFsmT0S4) */



/*-- so017.201: New function to handle transmitted INVITE after sending 2XX --*/
/*
*
*       Fun:   soTxnInvServerFsmT0S5
*
*       Desc:  This function is part of INVITE Server transaction.  It 
*              handles INVITE request received from peer after sending
*              2XX Response.
*              The SO_TRANS_INV_SERVER_AFTER_2XX state  is NOT defined 
*              in RFC 3261, but present in our implementation  to make
*              dialog matching rules simpler.
*
*       Ret:   If success, return ROK 
*              If failure, return SIP user related error code.
*
*       Notes: This function will only be called for Unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvServerFsmT0S5
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvServerFsmT0S5(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{

    TRC2(soTxnInvServerFsmT0S5);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO265, (ErrVal) 0, "soTxnInvServerFsmT0S5: "
                   "Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                "\n[TRANS] INVITE Received After Sending 2XX"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*--- Simply drop event and return ---*/
     (Void) soCmFreeEvent (evnt);

     RETVALUE (ROK);

} /* End of Fn (soTxnInvServerFsmT0S5) */






/*
*
*       Fun:   soTxnInvServerFsmT1S2
*
*       Desc:  This function is   part of INVITE Server transaction. It 
*              handles 1XX response to INVITE request received from user
*              in PROCEEDING state.
*
*       Ret:   If success, return ROK 
*              If failure, return SIP user related error code.
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvServerFsmT1S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Response Message.       */
)
#else
PRIVATE S16   soTxnInvServerFsmT1S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Response Message.       */
#endif
{
    S16   ret;
#if (ERRCLASS & ERRCLS_DEBUG)
    U8    responseClass;
#endif

    TRC2(soTxnInvServerFsmT1S2);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO266, (ErrVal) 0,"soTxnInvServerFsmT1S2:"
                   "Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }

      responseClass = (evnt->t.response.statusLine.statusCode.val)/100;

      if ((transCb->transState == SO_TRANS_INV_SERVER_PROCEEDING) &&
          (responseClass       == SO_STACODE_TYPE_INFORM))
      {
        SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                     "\n[TRANS] 1XX (INV) Send"));
        SO_TXN_DEBUG_PRINT (transCb);
      }
#endif

    /*- STEP 1: Pass the response to transport layer for transmisssion -*/
     
      if (transCb->retxMsg)
      {
         SPutMsg (transCb->retxMsg);
        /*- so041.201: Reset the pointer after releasing the message ---*/
         transCb->retxMsg = NULLP;
      }      

      ret = soTptSendRsp (transCb->entCb,
                          SSAP,
                          &transCb->via,      /* Destination VIA*/
                          evnt,               /* Response Msg   */
                          &transCb->retxMsg,  /* Encode Rsp Msg */
                          &transCb->tcmConn); /* Client/Server  */

      if (ret == SO_TPT_MULTI_THREADED_ENC)
        /*
         * Encoding not finished YET. The rest of functionality for
         * this  state  will  be  done  in  the  callback function.
         */
         RETVALUE (ret);

      else if (ret != ROK)
      {
         SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                   "\n[TRANS] Cannot Send Response Message "));
      }

    /*--- NO State change required ----*/
      RETVALUE (ret);

} /* End of Fn (soTxnInvServerFsmT1S2) */



/*
*
*       Fun:   soTxnInvServerFsmT2S2
*
*       Desc:  This function is   part of INVITE Server transaction. It 
*              handles 2XX response to INVITE request received from user
*              in PROCEEDING state.
*
*       Ret:   If success, return ROK 
*              If failure, return SIP user related error code.
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvServerFsmT2S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Response Message.       */
)
#else
PRIVATE S16   soTxnInvServerFsmT2S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Response Message.       */
#endif
{
    S16 ret;

    TRC2(soTxnInvServerFsmT2S2);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO267, (ErrVal) 0, "soTxnInvServerFsmT2S2: "
                   "Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] 2XX (INV) Send"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*
     * Handling of 2XX response to INVITE request from user in proceeding
     * state is almost  similar to handling of 1XX  response in  the same
     * state.
     */

     ret = soTxnInvServerFsmT1S2 (transCb, evnt);
     if (ret != ROK)
        RETVALUE (ret);
     
    /*
     * so017.201
     * Successfull sending of 2XX response to INVITE completes the trans-
     * action functionality. For UDP transport,  in our implemenation, we
     * have introduced new state  "After 2xx" to absorb any retransmitted
     * INVITEs.  This has been done to  improve our dialog matching rules.
     * We wait  till TimerJ (64*T1) for  any retransmitted INVITE request.
     */

    /*
     * For reliable transport,  Invite server trasaction is completed  on
     * sending final response, calling function will delete the transact-
     * ion.
     */
     if ((transCb->transport == LSO_TPTPROT_TCP) ||
         (transCb->transport == LSO_TPTPROT_TLS_TCP))
     {
        transCb->transState = SO_TRANS_NON_INV_SERVER_TERMINATED;

        /*--- Transaction is deleted from calling function ----*/
     }

    /* 
     * For Unreliable transport,start timer J to absorb any retransmitted
     * request message. Transaction is  deleted  ones the Timer J expires.
     */
     else
     {
        ret = soSchedTmr (transCb, SO_TMR_TRANS_J, TMR_START,
                          64*soCb.reCfg.tmrReTxCfg.t1);
        if (ret != ROK)
           RETVALUE (SOT_ERR_UNKNOWN);

       /*----- Finally, change state to "After 2xx" state -----*/
        transCb->transState = SO_TRANS_INV_SERVER_AFTER_2XX;
     }

     RETVALUE (ROK);

} /* End of Fn (soTxnInvServerFsmT2S2) */


/*- so017.201: New function to handle TimerJ expiry in "After 2xx" state -*/

/*
* 
*       Fun:   soTxnInvServerFsmT8S5
*
*       Desc:  This function is part of INVITE Server transaction. It ha-
*              ndles timeout of Timer J in "After 2xx" state.
*
*       Ret:   If success, ROK
*              if failure, RFAILED
*
*       Notes: This function must be called only for unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16  soTxnInvServerFsmT8S5
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16  soTxnInvServerFsmT8S5(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{

    TRC2(soTxnInvServerFsmT8S5);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO282, (ErrVal) 0,"soTxnInvServerFsmT8S5:"
                   " Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Timer J (INV) Expires"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif
   
    /*
     * Aleady waited for 64*T1 sec for any retransmitted request message
     * from peer. Now, delete the transaction and initiate call leg del-
     * etion, if this was the last transaction.
     * 
     */
     transCb->transState = SO_TRANS_INV_SERVER_TERMINATED;
     soTxnDeleteTransFromDiag (transCb);

     RETVALUE (ROK);

} /* End of Fn (soTxnInvServerFsmT8S5) */





/*
*
*       Fun:   soTxnInvServerFsmT3S2
*
*       Desc:  This function is  part of INVITE Server transaction. It 
*              handles 3-6XX final response to INVITE request received
*              from user in PROCEEDING state.
*
*       Ret:   If success, return ROK 
*              If failure, return SIP user related error code.
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvServerFsmT3S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Response Message.       */
)
#else
PRIVATE S16   soTxnInvServerFsmT3S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Response Message.       */
#endif
{
    S16 ret;

    TRC2(soTxnInvServerFsmT3S2);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO268, (ErrVal) 0, "soTxnInvServerFsmT3S2: "
                   "Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] 3-6XX (INV) Send"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*-------- STEP 1: Pass response to transport layer  --------*/

     ret = soTxnInvServerFsmT1S2 (transCb, evnt);
     if (ret != ROK)
     { /* Could not send response to peer node */
           RETVALUE (ret);
     }

    /*--- STEP 2: For Unreliable Transport Start Timer G (T1) ---*/
    /* so038.201: replaced with macro to check for UDP transport */
      if (SO_TCM_UDP_TRANSPORT(transCb->transport))
      {
        transCb->retxTmrVal = soCb.reCfg.tmrReTxCfg.t1;
        ret = soSchedTmr (transCb, SO_TMR_TRANS_G, TMR_START,
                          transCb->retxTmrVal);
        if (ret != ROK)
          RETVALUE (SOT_ERR_UNKNOWN);
      }

    /*----- STEP 3: For All Transport Start Timer H (64*T1) -----*/
      ret = soSchedTmr (transCb, SO_TMR_TRANS_H, TMR_START,
                        64*soCb.reCfg.tmrReTxCfg.t1);
      if (ret != ROK)
          RETVALUE (SOT_ERR_UNKNOWN);
      
    /*------ Finally, change state to Completed and return ------*/
      transCb->transState = SO_TRANS_INV_SERVER_COMPLETED;

      RETVALUE (ROK);

} /* End of Fn (soTxnInvServerFsmT3S2) */




/*
*
*       Fun:   soTxnInvServerFsmT4S3
*
*       Desc:  This function is  part of INVITE Server transaction. It 
*              handles timer G expiry in COMPLETED state.
*
*       Ret:   If success, ROK
*              if failure, RFAILED
*
*       Notes: This function will only be called for Unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16  soTxnInvServerFsmT4S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16  soTxnInvServerFsmT4S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    S16 ret;

    TRC2(soTxnInvServerFsmT4S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO269, (ErrVal) 0, "soTxnInvServerFsmT4S3: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Timer G (Inv) Expires"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*
     * STEP 1:
     * NO ACK for 3-6xx response received yet. Pass MOST recent response
     * to transport layer for retransmission.
     */
     if (transCb->retxMsg)
     {
         ret = soTptSendRsp (transCb->entCb,
                             SSAP,
                             &transCb->via,  /* Req VIA        */
                             NULLP,          /* No Rsp Evnt    */
                             &transCb->retxMsg, /* Encoded Rsp */
                             &transCb->tcmConn);
         if (ret != ROK)
         {
            SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                   "\n[TRANS] Cannot Send Response Message "));
      
            soTxnDeleteTransFromDiag (transCb);
            RETVALUE (RFAILED);
         }
     }

    /* STEP 2: ReStart Timer G with value MIN((2 * previous val), T2) */
      transCb->retxTmrVal = 2 * transCb->retxTmrVal;
      if (transCb->retxTmrVal > soCb.reCfg.tmrReTxCfg.t2)
          transCb->retxTmrVal = soCb.reCfg.tmrReTxCfg.t2;

      ret = soSchedTmr (transCb, SO_TMR_TRANS_G, TMR_START,
                        transCb->retxTmrVal);
      if (ret != ROK)
      {
         soTxnDeleteTransFromDiag (transCb);
         RETVALUE (RFAILED);
      }

     /*--- NO State change required ---*/

      RETVALUE (ROK);

} /* End of Fn (soTxnInvServerFsmT4S3) */



/*
*
*       Fun:   soTxnInvServerFsmT5S3
*
*       Desc:  This function is part of INVITE Server transaction. It 
*              handles ACK  for 3_6XX response from peer in COMPLETED 
*              state
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED.
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvServerFsmT5S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvServerFsmT5S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    S16      ret;
    SoCLegCb *tmpCLeg;

    TRC2(soTxnInvServerFsmT5S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO270, (ErrVal) 0,"soTxnInvServerFsmT5S3:"
                   " Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] ACK Received "));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

      tmpCLeg = (SoCLegCb *)transCb->cLeg;

    /*
     * NOTE: If the function returns failure before passing ACK to 
     *       dialog layer, it must trigger deletion of call leg.
     */

    /*--- STEP 1: ACK message received, MUST stop timers G&H ---*/
    /* so038.201: replaced with macro to check for UDP transport */
      if (SO_TCM_UDP_TRANSPORT(transCb->transport))
        soSchedTmr (transCb, SO_TMR_TRANS_G, TMR_STOP, 0);

      soSchedTmr (transCb, SO_TMR_TRANS_H, TMR_STOP, 0);

     /*
      * For reliable transport, Invite server trasaction is compl-
      * eted on receiving ACK for 3-6xx response. So, delete tran-
      * saction first.
      */
      if ((transCb->transport == LSO_TPTPROT_TCP) ||
          (transCb->transport == LSO_TPTPROT_TLS_TCP))
         soTxnDeleteTrans (transCb);

     /* 
      * For Unreliable transport, start timer I to absorb any ret-
      * ransmitted ACK. Transaction is deleted ones the TimerI ex-
      * pires.
      */
      else
      {
         ret = soSchedTmr (transCb, SO_TMR_TRANS_I, TMR_START,
                           soCb.reCfg.tmrReTxCfg.t4);
         if (ret != ROK)
         {
            soTxnDeleteTransFromDiag (transCb);
            RETVALUE (ret);
         }

         /*--------------- Enter CONFIRMED State ---------------*/
         transCb->transState = SO_TRANS_INV_SERVER_CONFIRMED;
      }

     /*
      * Pass received ACK to dialog layer.  Dialog layer will take
      * further action (may be deletion) on call leg.
      */
      (Void) soDlgErrRspAck (tmpCLeg);

     /*-------- Finally delete ACK event and return ROK --------*/
      (Void) soCmFreeEvent (evnt);

      RETVALUE (ROK);
 
} /* End of Fn (soTxnInvServerFsmT5S3) */




/*
*
*       Fun:   soTxnInvServerFsmT5S4
*
*       Desc:  This function is part of INVITE Server transaction. It 
*              handles ACK  for 3_6XX response from peer in CONFIRMED 
*              state
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvServerFsmT5S4
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnInvServerFsmT5S4(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{

    TRC2(soTxnInvServerFsmT5S4);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO271, (ErrVal) 0,"soTxnInvServerFsmT5S4:"
                   " Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] ACK Received "));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*---- Retransmission of ACK received. Drop the message ----*/  

     /*- Delete event structure -*/
      (Void) soCmFreeEvent (evnt);

      RETVALUE (ROK);
      
} /* End of Fn (soTxnInvServerFsmT5S4) */




/*
*
*       Fun:   soTxnInvServerFsmT6S3
*
*       Desc:  This function is part of INVITE Server transaction. It 
*              handles timeout of Timer H in COMPLETED state.
*              
*       Ret:   If success, ROK
*              if failure, RFAILED
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16  soTxnInvServerFsmT6S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16  soTxnInvServerFsmT6S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    SoUserCtxt     tmpUserContext;
    SoEntCb        *tmpEntCb;
    SoCLegCb       *tmpCLeg;

    TRC2(soTxnInvServerFsmT6S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO272, (ErrVal) 0, "soTxnInvServerFsmT6S3:"
                   " Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Timer H (INV) Expires "));
      SO_TXN_DEBUG_PRINT (transCb);
#endif
   
    /*
     * NO ACK for 3_6XX response was received from the peer. Terminate 
     * transaction and notify the dialog layer.
     */
     cmMemcpy ((U8 *)&tmpUserContext, (U8 *)&transCb->userContext,
               sizeof (SoUserCtxt));
     cmMemset ((U8 *)&transCb->userContext, 0, sizeof (SoUserCtxt));

     tmpEntCb    = transCb->entCb;
     tmpCLeg     = (SoCLegCb *)transCb->cLeg;
 
     transCb->transState = SO_TRANS_INV_SERVER_TERMINATED;
     soTxnDeleteTrans (transCb);

      /*---- Notify dialog layer about the timeout ----*/
      (Void) soDlgErrInd (tmpCLeg,
                          SO_TRANS_NO_ACK,
                          NULLP,
                          &tmpUserContext);
      RETVALUE (ROK);

} /* End of Fn (soTxnInvServerFsmT6S3) */



/*
*
*       Fun:   soTxnInvServerFsmT7S4
*
*       Desc:  This function is part of INVITE Server transaction. It 
*              handles timeout of Timer I in CONFIRMED state.
*              
*       Ret:   If success, ROK
*              if failure, RFAILED
*
*       Notes: This function must be called only for unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16  soTxnInvServerFsmT7S4
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16  soTxnInvServerFsmT7S4(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    TRC2(soTxnInvServerFsmT7S4);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO273, (ErrVal) 0, "soTxnInvServerFsmT7S4: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Timer I (INV) Expires "));
      SO_TXN_DEBUG_PRINT (transCb);
#endif
   
    /*
     * Aleady waited for T4 sec for any  retransmitted ACK for 3_6XX
     * response from peer.  Now, delete the transaction and initiate
     * call leg deletion, if this was the last transaction.
     *
     */
     transCb->transState = SO_TRANS_INV_SERVER_TERMINATED;
     soTxnDeleteTransFromDiag (transCb);

     RETVALUE (ROK);

} /* End of Fn (soTxnInvServerFsmT7S4) */



/*
*
*       Fun:   soTxnInvServerError
*
*       Desc:  This function is part of INVITE Server transacti-
*              on. It handles incorrect triggers in given state.
*              
*       Ret:   returns RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnInvServerError
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16   soTxnInvServerError (transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    TRC2(soTxnInvServerError);

   /*
    * Incorrect trigger received in the given transaction state.
    * Sipmly ignore the trigger.
    * NOTE: This may arise either due to incorrect message from
    *       peer or local errors.
    */

    SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
              "\n[TRANS] Invalid Trigger For Invite Server"));

    SO_TXN_DEBUG_PRINT (transCb);

    RETVALUE (RFAILED);

} /* End of Fn (soTxnInvServerError) */







/*---------- NON INVITE SERVER TRANSACTION STATE FUNCTIONS ----------*/


/*
*
*       Fun:   soTxnNonInvServerFsmT0S1
*
*       Desc:  This function is part of NON INVITE Server transaction.
*              It handles  NON INVITE request from peer in IDLE state.
*              
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvServerFsmT0S1
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnNonInvServerFsmT0S1(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    S16 ret;

    TRC2(soTxnNonInvServerFsmT0S1);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO274, (ErrVal) 0,"soTxnNonInvServerFsmT0S1:"
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] NON INVITE Received"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*-------------- STEP 1: change state to TRYING -----------------*/
      transCb->transState = SO_TRANS_NON_INV_SERVER_TRYING;

    /*----- STEP 1: Pass the Non INVITE request to dialog layer -----*/
      ret = soDlgUaIncReq (transCb->entCb,
                           evnt,
                           transCb,
                           &transCb->tcmConn);
    /*
     * NOTE: If the above function  returns failure,  dialog/core layer
     *       MUST have deleted transaction as well.
     */
      if (ret != ROK)
         RETVALUE (RFAILED);

      RETVALUE (ROK);

} /* End of Fn (soTxnNonInvServerFsmT0S1) */




/*
*
*       Fun:   soTxnNonInvServerFsmT0S2
*
*       Desc:  This function is  part of NON INVITE Server transaction. 
*              It handles NON INVITE request received from peer in 
*              TRYING state.
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: This function will only be called for Unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvServerFsmT0S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnNonInvServerFsmT0S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{

    TRC2(soTxnNonInvServerFsmT0S2);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO275, (ErrVal) 0,"soTxnNonInvServerFsmT0S2:"
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] NON INVITE Received"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

     /*-- Retransmitted INVITE request received. Just drop the request --*/

     /*---- Deallocate Event ---*/
      (Void) soCmFreeEvent (evnt);

      RETVALUE (ROK);

} /* End of Fn (soTxnNonInvServerFsmT0S2) */



/*
*
*       Fun:   soTxnNonInvServerFsmT0S3
*
*       Desc:  This function is  part of NON INVITE Server transaction.
*              It  handles  NON INVITE  request  received  from peer in 
*              PROCEEDING state.
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: This function will only be called for Unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvServerFsmT0S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnNonInvServerFsmT0S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{
    S16 ret;

    TRC2(soTxnNonInvServerFsmT0S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO276, (ErrVal) 0,"soTxnNonInvServerFsmT0S3:"
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      if (transCb->transState == SO_TRANS_NON_INV_SERVER_PROCEEDING)
      {
        SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                     "\n[TRANS] NON INVITE Received"));
        SO_TXN_DEBUG_PRINT (transCb);
      }
#endif

    /*
     * Retransmitted NON INVITE request received. Pass  most recent 
     * response to transport layer for retransmission.
     */
     if (transCb->retxMsg)
     {
         ret = soTptSendRsp (transCb->entCb,
                             SSAP,
                             &transCb->via,  /* Req VIA        */
                             NULLP,          /* No Rsp         */
                             &transCb->retxMsg, /* Encoded Rsp */
                             &transCb->tcmConn);
         if (ret != ROK)
         {
           /* 
            * This indicates fatal error. Delete TCB and inform dia-
            * log layer.
            */
            SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                   "\n[TRANS] Cannot Send Response Message "));

            soTxnDeleteTransFromDiag (transCb);
            RETVALUE (RFAILED);
         }
     }

     /*- Delete event structure -*/
      (Void) soCmFreeEvent (evnt);

      RETVALUE (ROK);

} /* End of Fn (soTxnNonInvServerFsmT0S3) */



/*
*
*       Fun:   soTxnNonInvServerFsmT0S4
*
*       Desc:  This function is  part of NON INVITE Server transaction.
*              It handles NON INVITE request received from peer in 
*              PROCEEDING state.
*
*       Ret:   If success, return ROK 
*              If failure, return RFAILED
*
*       Notes: This function will only be called for Unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvServerFsmT0S4
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* Decoded SIP Message.        */
)
#else
PRIVATE S16   soTxnNonInvServerFsmT0S4(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* Decoded SIP Message.        */
#endif
{

    TRC2(soTxnNonInvServerFsmT0S4);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO277, (ErrVal) 0,"soTxnNonInvServerFsmT0S4:"
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] NON INVITE Received"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*
     * Retransmitted NON INVITE request received. Handling of retranmitted
     * request in completed state is similar to handling in proceeding
     * state.
     */
     RETVALUE (soTxnNonInvServerFsmT0S3 (transCb, evnt));

} /* End of Fn (soTxnNonInvServerFsmT0S4) */



/*
*
*       Fun:   soTxnNonInvServerFsmT1S2
*
*       Desc:  This function is part of NON INVITE Server transaction.It 
*              handles 1XX response to NON INVITE request received from 
*              user in TRYING state.
*
*       Ret:   If success, return ROK 
*              If failure, return SIP user related error code.
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvServerFsmT1S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Response Message.       */
)
#else
PRIVATE S16   soTxnNonInvServerFsmT1S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Response Message.       */
#endif
{
    S16   ret;
#if (ERRCLASS & ERRCLS_DEBUG)
    U8    responseClass;
#endif

    TRC2(soTxnNonInvServerFsmT1S2);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO278, (ErrVal) 0, "soTxnNonInvServerFsmT1S2:"
                   " Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }

      responseClass = (evnt->t.response.statusLine.statusCode.val)/100;

      if ((transCb->transState == SO_TRANS_NON_INV_SERVER_TRYING) &&
          (responseClass       == SO_STACODE_TYPE_INFORM))
      {
        SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                     "\n[TRANS] 1XX (Non INV) Send"));
        SO_TXN_DEBUG_PRINT (transCb);
      }
#endif

    /*- STEP 1: Pass the response to transport layer for transmisssion -*/
     
      if (transCb->retxMsg)
      {     
          SPutMsg (transCb->retxMsg);
         /*- so041.201: Reset the pointer after releasing the message --*/
          transCb->retxMsg = NULLP;
      }

      ret = soTptSendRsp (transCb->entCb,
                          SSAP,
                          &transCb->via,      /* Destination VIA*/
                          evnt,               /* Response Msg   */
                          &transCb->retxMsg,  /* Encode Rsp Msg */
                          &transCb->tcmConn); /* Client/Server  */

      if (ret == SO_TPT_MULTI_THREADED_ENC)
        /*
         * Encoding not finished YET. The rest of functionality for
         * this  state  will  be  done  in  the  callback function.
         */
         RETVALUE (ret);

      if (ret != ROK)
      {
         SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
                   "\n[TRANS] Cannot Send Response Message "));
         RETVALUE (ret);
      }

    /*----- STEP 2: Change transaction state to Proceeding -----*/
      transCb->transState = SO_TRANS_NON_INV_SERVER_PROCEEDING;

      RETVALUE (ROK);

} /* End of Fn (soTxnNonInvServerFsmT1S2) */



/*
*
*       Fun:   soTxnNonInvServerFsmT1S3
*
*       Desc:  This function is part of NON INVITE Server transaction.It 
*              handles 1XX response to NON INVITE request received from 
*              user in TRYING state.
*
*       Ret:   If success, return ROK 
*              If failure, return SIP user related error code.
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvServerFsmT1S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Response Message.       */
)
#else
PRIVATE S16   soTxnNonInvServerFsmT1S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Response Message.       */
#endif
{

    TRC2(soTxnNonInvServerFsmT1S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO279, (ErrVal) 0,"soTxnNonInvServerFsmT1S3:"
                   " Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] 1XX (Non INV) Send"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*
     * Handling of 1XX response from user in proceeding state is similar
     * to handling in trying state. Just pass the  response to transport
     * layer for transmission.
     */
     RETVALUE (soTxnNonInvServerFsmT1S2 (transCb, evnt));

} /* End of Fn (soTxnNonInvServerFsmT1S3) */




/*
*
*       Fun:   soTxnNonInvServerFsmT2S2
*
*       Desc:  This function is  part of NON INVITE Server transaction. 
*              It handles 2-6XX final  response to NON  INVITE request
*              received from user in TRYING state.
*
*       Ret:   If success, return ROK 
*              If failure, return SIP user related error code.
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvServerFsmT2S2
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Response Message.       */
)
#else
PRIVATE S16   soTxnNonInvServerFsmT2S2(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Response Message.       */
#endif
{
    S16 ret;

    TRC2(soTxnNonInvServerFsmT2S2);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO280, (ErrVal) 0,"soTxnNonInvServerFsmT2S2:"
                   "Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }

      if (transCb->transState == SO_TRANS_NON_INV_SERVER_TRYING)
      {
        SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                     "\n[TRANS] 2-6XX (Non INV) Send"));
        SO_TXN_DEBUG_PRINT (transCb);
      }
#endif

    /*- STEP 1: Pass the response to transport layer for transmisssion -*/

      ret = soTxnNonInvServerFsmT1S2 (transCb, evnt);
      if (ret != ROK)
      { /* Could not send response to peer node */
           RETVALUE (ret);
      }

     /* 
      * For reliable transport, Non Invite server trasaction is completed
      * on sending final response.
      */
      if ((transCb->transport == LSO_TPTPROT_TCP) ||
          (transCb->transport == LSO_TPTPROT_TLS_TCP))
      {
         transCb->transState = SO_TRANS_NON_INV_SERVER_TERMINATED;

         /*--- Transaction is deleted from calling function ----*/
      }

     /* 
      * For Unreliable transport,start timer J to absorb any retransmitted
      * request message. Transaction is  deleted  ones the Timer J expires.
      */ 
      else
      {
         ret = soSchedTmr (transCb, SO_TMR_TRANS_J, TMR_START,
                           64*soCb.reCfg.tmrReTxCfg.t1);
         if (ret != ROK)
            RETVALUE (SOT_ERR_UNKNOWN);

         /*--- Finally, change state to completed state ---*/
         transCb->transState = SO_TRANS_NON_INV_SERVER_COMPLETED;
      }

      RETVALUE (ROK);

} /* End of Fn (soTxnNonInvServerFsmT2S2) */



/*
*
*       Fun:   soTxnNonInvServerFsmT2S3
*
*       Desc:  This  function is part of NON INVITE Server transaction. It 
*              handles 2_6XX final response to NON INVITE request received
*              from user in PRoCEEDING state.
*
*       Ret:   If success, return ROK 
*              If failure, return SIP user related error code.
*
*       Notes:
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvServerFsmT2S3
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Response Message.       */
)
#else
PRIVATE S16   soTxnNonInvServerFsmT2S3(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Response Message.       */
#endif
{

    TRC2(soTxnNonInvServerFsmT2S3);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && evnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO281, (ErrVal) 0,"soTxnNonInvServerFsmT2S3:"
                   " Invalid parameter");
        RETVALUE (SOT_ERR_UNKNOWN);
      }
#endif

    /*
     * Handling of final response from user in proceeding state is similar
     * to handling in trying  state. Just pass the  response to  transport
     * layer for transmission  and  either terminate transaction (for TCP) 
     * or start timer J (for UDP).
     */
     RETVALUE (soTxnNonInvServerFsmT2S2 (transCb, evnt));

} /* End of Fn (soTxnNonInvServerFsmT2S3) */



/*
*
*       Fun:   soTxnNonInvServerFsmT3S4
*
*       Desc:  This function is part of NON INVITE Server transaction. It 
*              handles timeout of Timer J in COMPLETED state.
*
*       Ret:   If success, ROK
*              if failure, RFAILED
*
*       Notes: This function must be called only for unreliable transport.
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16  soTxnNonInvServerFsmT3S4
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16  soTxnNonInvServerFsmT3S4(transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{

    TRC2(soTxnNonInvServerFsmT3S4);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO282, (ErrVal) 0,"soTxnNonInvServerFsmT3S4:"
                   " Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] Timer J (non INV) Expires"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif
   
    /*
     * Aleady waited for 64*T1 sec for any retransmitted request message
     * from peer. Now, delete the transaction and initiate call leg del-
     * etion, if this was the last transaction.
     * 
     */
     transCb->transState = SO_TRANS_NON_INV_SERVER_TERMINATED;
     soTxnDeleteTransFromDiag (transCb);

     RETVALUE (ROK);

} /* End of Fn (soTxnNonInvServerFsmT3S4) */



/*
*
*       Fun:   soTxnNonInvServerError
*
*       Desc:  This function is part of NON INVITE Client transacti-
*              on. It handles incorrect triggers in given state.
*              
*       Ret:   returns RFAILED
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE S16   soTxnNonInvServerError
(
SoTransCb    *transCb,       /* Transaction control block   */
SoEvnt       *evnt           /* SIP Message. NOT USED       */
)
#else
PRIVATE S16   soTxnNonInvServerError (transCb, evnt)
SoTransCb    *transCb;       /* Transaction control block   */
SoEvnt       *evnt;          /* SIP Message. NOT USED       */
#endif
{
    TRC2(soTxnNonInvServerError);

   /*
    * Incorrect trigger received in the given transaction state.
    * Sipmly ignore the trigger.
    * NOTE: This may arise either due to incorrect message from
    *       peer or local errors.
    */

    SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
              "\n[TRANS] Invalid Trigger For Non Invite Server"));

    SO_TXN_DEBUG_PRINT (transCb);

    RETVALUE (RFAILED);

} /* End of Fn (soTxnNonInvServerError) */



/*
*
*       Fun:   soTxnGenAck
*
*       Desc:  This function constructs ACK for non successfull final
*              response for INVITE request.
*
*       Ret:   If success, return ROK and ackEvnt pointer is updated.
*              If failure, return RFAILED
*
*       Notes:
*              
*       File:  so_trans.c
*
*/
#ifdef ANSI
PRIVATE S16   soTxnGenAck
(
SoTransCb    *transCb,   /* Transaction control block         */
SoEvnt       *response,  /* 3-6xx Response message            */
SoEvnt       **ackEvnt   /* Genetared ACK message (updated)   */
)
#else
PRIVATE S16   soTxnGenAck (transCb, response, ackEvnt)
SoTransCb    *transCb;   /* Transaction control block         */
SoEvnt       *response;  /* 3-6xx Response message            */
SoEvnt       **ackEvnt;  /* Genetared ACK message (updated)   */
#endif
{
    S16        ret;
    U16        i;
    TknStrOSXL *callId;
    SoCSeq     *cSeq;
    SoVia      *via;
    SoRoute    *route;
    SoAddress  *from, *to, *toHdrInRsp;
    SoCLegCb   *cLeg;
    /* so015.201: Insert Max Forwards in outgoing ACK request */
    TknU32     *maxForwards;

    TRC2(soTxnGenAck);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && transCb->cLeg && response && ackEvnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO283, (ErrVal) 0, "soTxnGenAck: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }
#endif

   cLeg = (SoCLegCb *)transCb->cLeg;

   SO_GET_TOHDR_FROM_EVENT (response, toHdrInRsp);

  /*----------------- Create NEW Event For ACK -------------------*/
   ret = soCmCreateEvent (ackEvnt, NULLD);
   if (ret != ROK)
        RETVALUE (RFAILED);

   /*--------- Its a request event ----------*/
   SO_FILL_TKNU8 (&(*ackEvnt)->sipMessageType, SO_SIPMESSAGE_REQUEST);
   (*ackEvnt)->t.request.pres.pres = PRSNT_NODEF;

   /*--- Fill Request URI for ACK Message ---*/
   /*---------- This must be same as one send in INVITE ----------*/
   ret = soUtlCpySoAddrSpec (&(*ackEvnt)->t.request.requestLine.addrSpec,
                             &transCb->origReqURI,
                             &(*ackEvnt)->memCp);
   if (ret != ROK)
         goto SOTXNGENACK_FAILED;

   (*ackEvnt)->t.request.requestLine.pres.pres        = PRSNT_NODEF;
   (*ackEvnt)->t.request.requestLine.method.type.pres = PRSNT_NODEF;
   (*ackEvnt)->t.request.requestLine.method.type.val  = SO_METHOD_METHODSTD;
   (*ackEvnt)->t.request.requestLine.method.t.std.pres= PRSNT_NODEF;
   (*ackEvnt)->t.request.requestLine.method.t.std.val = SO_METHODSTD_ACK;

   SO_FILL_TKNSTROSXL (&(*ackEvnt)->t.request.requestLine.sipVersion,
                       soCb.cfg.protVer,
                       cmStrlen ((U8 *)soCb.cfg.protVer), 
                       (*ackEvnt), ret);
    if (ret != ROK)
         goto SOTXNGENACK_FAILED;

   /*--- Fill CALL Identifier header in ACK ---*/
   /*--- This should be same as INVITE, so take it from call cb --*/
    ret = soCmCreateHdrChoice ((*ackEvnt), (U8 **) &callId, SO_HEADER_GEN_CALLID);
    if (ret != ROK)
         goto SOTXNGENACK_FAILED;

    callId->pres =  cLeg->call->callId.pres;
    callId->len  =  cLeg->call->callId.len;
    callId->val  =  cLeg->call->callId.val;


   /*---- Fill CSeq header in ACK message -----*/
   /*----- Numeric field of CSeq should be same as in INVITE -----*/
    ret = soCmCreateHdrChoice ((*ackEvnt), (U8 **) &cSeq, SO_HEADER_GEN_CSEQ);
    if (ret != ROK)
         goto SOTXNGENACK_FAILED;

   SO_FILL_TKNU32(&cSeq->cSeqVal,      transCb->transCSeq);
   SO_FILL_TKNU8 (&cSeq->method.type,  SO_METHOD_METHODSTD);
   SO_FILL_TKNU8 (&cSeq->method.t.std, SO_METHODSTD_ACK);


   /*--- Fill "From" header in ACK message ----*/
   /*--------- "From" header should be same as in INVITE ---------*/
    ret = soCmCreateHdrChoice ((*ackEvnt), (U8 **) &from, SO_HEADER_GEN_FROM);
    if (ret != ROK)
         goto SOTXNGENACK_FAILED;

    ret = soUtlCpySoAddressNoAlloc (from, 
                                    &cLeg->storedHdrs.localAddr,
                                    &(*ackEvnt)->memCp);
    if (ret != ROK)
         goto SOTXNGENACK_FAILED;

   /*---- Fill "To" header in ACK message -----*/
   /*---- "To" header should be same as in received response -----*/
    ret = soCmCreateHdrChoice ((*ackEvnt), (U8 **) &to, SO_HEADER_GEN_TO);
    if (ret != ROK)
         goto SOTXNGENACK_FAILED;

    ret = soUtlCpySoAddressNoAlloc (to, toHdrInRsp, &(*ackEvnt)->memCp);
    if (ret != ROK)
         goto SOTXNGENACK_FAILED;


   /*---- Fill "Via" header in ACK message ----*/
   /*---------- "Via" header should be same as in INVITE ---------*/
    ret = soCmCreateHdrChoice ((*ackEvnt), (U8 **) &via, SO_HEADER_GEN_VIA);
    if (ret != ROK)
         goto SOTXNGENACK_FAILED;

    via->numComp.pres = PRSNT_NODEF;
    via->numComp.val  = transCb->via.numComp.val;

    ret = soUtlCpyGetLstPtr ((Ptr *)&via->viaItem,
                             sizeof (SoViaItem *),
                             &transCb->via.numComp,
                             &(*ackEvnt)->memCp);
    if (ret != ROK)
         goto SOTXNGENACK_FAILED;

    for (i = 0; i < via->numComp.val; i++)
         via->viaItem[i]  = transCb->via.viaItem[i];

   /*--- Fill "Max Forwards" header in ACK message ---*/
   /*---------- This should be same as INVITE --------*/
   /*-- so015.201: Fill Max Forwards in ACK request --*/
    ret = soCmCreateHdrChoice ((*ackEvnt),
                               (U8 **) &maxForwards, 
                               SO_HEADER_REQ_MAXFORWARDS);
    if (ret != ROK)
         goto SOTXNGENACK_FAILED;

    maxForwards->pres = PRSNT_NODEF;
    if (transCb->entCb->reCfg.hdrCfg.maxFwd != 0)
       maxForwards->val = transCb->entCb->reCfg.hdrCfg.maxFwd;
    else
       maxForwards->val = SO_DFLT_MAX_FWDS;

   /*--- Fill "route" header in ACK message ---*/
   /*----- so014.201: This must be same as one send in INVITE ----*/
    if (transCb->route.numComp.pres && transCb->route.numComp.val)
    {
      ret = soCmCreateHdrChoice ((*ackEvnt), (U8 **) &route, SO_HEADER_REQ_ROUTE);
      if (ret != ROK)
         goto SOTXNGENACK_FAILED;

      ret = soUtlCpySoRoute (route, &transCb->route, &(*ackEvnt)->memCp);
      if (ret != ROK)
        goto SOTXNGENACK_FAILED;
    }

   /*----- so015.201: Fill "UserAgent" header in ACK message -----*/
    ret = soDlgPrcUserAgent (cLeg, (*ackEvnt));
    if (ret != ROK)
      goto SOTXNGENACK_FAILED;

    RETVALUE (ROK);

SOTXNGENACK_FAILED:
    (Void) soCmFreeEvent ((*ackEvnt));

    RETVALUE (RFAILED);

} /* End of Fn (soTxnGenAck) */



/*
*
*       Fun:   soTxnSendAck
*
*       Desc:  This function i sued to send ACK for non  successfull 
*              final response for INVITE request.
*
*       Ret:   If success, return ROK
*              If failure, return RFAILED
*
*       Notes:
*              
*       File:  so_trans.c
*
*/
#ifdef ANSI
PRIVATE S16   soTxnSendAck
(
SoTransCb    *transCb,   /* Transaction control block         */
SoEvnt       *ackEvnt    /* Genetared ACK message (updated)   */
)
#else
PRIVATE S16   soTxnSendAck (transCb, ackEvnt)
SoTransCb    *transCb;   /* Transaction control block         */
SoEvnt       *ackEvnt;   /* Genetared ACK message (updated)   */
#endif
{
    S16        ret;

    TRC2(soTxnSendAck);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (! (transCb && ackEvnt))
      {
        SOLOGERROR(ERRCLS_DEBUG, ESO284, (ErrVal) 0, "soTxnSendAck: "
                   "Invalid parameter");
        RETVALUE (RFAILED);
      }

      SODBGP_SO(SO_DBGMASK_TRANS, (soCb.init.prntBuf, 
                                   "\n[TRANS] ACK Send"));
      SO_TXN_DEBUG_PRINT (transCb);
#endif

    /*- Pass the ACK Request to transport layer for transmission -*/
      transCb->tcmConn.tcmConnType = SO_NOCALLBACK; /*- See NOTE below -*/

      ret = soTptSendInitialReq (transCb->entCb,
                                SSAP,
                                &transCb->destAddr, /* Dest Address     */
                                transCb->transport, /* TCP/UDP          */
                                ackEvnt,            /* ACK Message      */
                                FALSE,        /* Don't Modify Transport */
                                NULLP,        /* No Branch Identifier   */
                                &transCb->tcmConn,  /* Server/Client Cb */
                                &transCb->retxMsg); /* Encoded ACK Msg  */

      if (ret == SO_TPT_MULTI_THREADED_ENC)
      {
        /*--- Encoding not finished YET.  -----*/
         transCb->retxMsg = NULLP; RETVALUE (ROK);
      }

     /*---- ACK Event is NO longer required ----*/
      soCmFreeEvent ((ackEvnt));

      RETVALUE (ret);

    /*
     * NOTE: In case of TCP as transport, transaction  control block
     *       will be destroyed after sending ACK. In such a case, if
     *       multithreded encoder is used,  we  don't want transport 
     *       layer to call callback fn "soTxnEncodeReqCallBack" aft-
     *       er encoding. Changing tcmConnType will server this pur-
     *       pose.
     */

} /* End of Fn (soTxnSendAck) */





/*
*
*       Fun:   soTxnDeleteTransFromDiag
*
*       Desc:  This function  is  used by various entities to delete 
*              the context of transaction from dialog. This function
*              will also trigger call leg deletion of required.
*
*       Ret:   Void
*
*       Notes: 
*
*       File:  so_trans.c
*
*/

#ifdef ANSI
PRIVATE Void soTxnDeleteTransFromDiag
(
SoTransCb  *transCb   /* Transaction Control Block      */
)
#else
PRIVATE Void soTxnDeleteTransFromDiag (transCb)
SoTransCb  *transCb;  /* Transaction Control Block      */
#endif
{
  SoCLegCb *cLeg;

    TRC2(soTxnDeleteTransFromDiag);

#if (ERRCLASS & ERRCLS_DEBUG)
    if (!transCb)
    {
      SOLOGERROR(ERRCLS_DEBUG, ESO285, (ErrVal) 0, "soTxnDeleteTransFromDiag"
                 "Invalid parameter");
      RETVOID;
    }
#endif

    /*--- Remove context of transaction from dialog ---*/
     cLeg = (SoCLegCb *)transCb->cLeg;
     soTxnDeleteTrans (transCb);

    /*--- Trigger deletion of call leg, If required ---*/
     if (cLeg)
       soDlgChkAndDelCLeg (cLeg);

     RETVOID;

} /* End of Fn (soTxnDeleteTransFromDiag) */



/* so038.201: Added new function */

/* so038.201 : Added function function to move Closing pending Trans to the trans */
/*
*
*       Fun:   soTxnClosePendingTrans
*
*       Desc:  This function  is used by  various entities  to send
*              4xx final response to pending transactions within a
*              dialog, on which the Bye response has been sent or
*              BYE confirm has been received. 
*
*       Ret:
*
*
*       Notes:
*
*       File:  so_trans.c
*
*/
#ifdef ANSI
PUBLIC Void  soTxnClosePendingTrans
(
SoTransCb      *transCb           /* Transaction Control Block      */
)
#else
PUBLIC Void  soTxnClosePendingTrans (transCb)
SoTransCb      *transCb;          /* Transaction Control Block      */
#endif
{

  SoCLegCb *cLeg;
  SoCallCb *callCb;     /* CALL CB */
  SoEvnt   *rspEvnt;    /* Response Event */
  S16      ret;         /* Return Value */

  TRC2(soTxnClosePendingTrans);


#if (ERRCLASS & ERRCLS_DEBUG)
    if (!transCb)
    {
      SOLOGERROR(ERRCLS_DEBUG, ESOXXX, (ErrVal) 0, "soTxnClosePendingTrans: " "Invalid parameter");
      RETVOID;
    }
#endif

    ret      = ROK;
    cLeg     = (SoCLegCb *)transCb->cLeg;
    callCb   = cLeg->call;

#if (ERRCLASS & ERRCLS_DEBUG)

    SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, \
         "\n[Trans] Closing pending transaction for Call: %ld, \
         CallLeg: %lx, Trans: %lx, "   \
         "TransType: %d, TransState: %d, TransMethod: %d\n",   \
          cLeg->call->spConnId, cLeg->legId, transCb->transId, \
          transCb->transType, transCb->transState, transCb->transMethod));

    SO_TXN_DEBUG_PRINT (transCb);
#endif


    if (((transCb->transType == SO_TRANS_INV_SERVER) &&
         (transCb->transState == SO_TRANS_INV_SERVER_PROCEEDING)) ||
        ((transCb->transType == SO_TRANS_NON_INV_SERVER) &&
        ((transCb->transState == SO_TRANS_NON_INV_SERVER_TRYING) ||
         (transCb->transState == SO_TRANS_NON_INV_SERVER_PROCEEDING))))
    {
       if (transCb != NULLP)
       {
          /* Build 487 response */
          soUtlBuildRspEvnt(cLeg->call->ent, &rspEvnt, NULLP,
                            transCb->transMethod,
                            SOT_RSP_487_REQ_TERMINATED,
                            SO_EXTRSP_NONE);

          rspEvnt->transId = transCb->transId;
          rspEvnt->callLegId = cLeg->legId;

          cLeg->noStateUpd = TRUE;
          ret = soDlgUaOutRsp(cLeg, rspEvnt, transCb);
          if (ret != ROK)
          {
             /* The call leg needs to be deleted explicilty since
                an error response couldnot be sent out for it.*/
             (Void) soCmFreeEvent (rspEvnt);
          }
       }
    }

    RETVOID;

} /* End of Fn (soTxnClosePendingTrans) */

#endif /* SO_UA */


/********************************************************************30**

         End of file:     so_trans.c@@/main/2 - Tue Apr 20 12:47:16 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/2      ---      ps   1. Changed copyright header.
/main/2+   so001.201  ps   1. For CANCEL Transaction creation,caller must
                              pass VIA header that is  same as VIA header
                              of corresponding INVITE request.
                           2. Matching server  transaction procedure must
                              not include CANCEL method.A new transaction
                              must be created for CANCEL request.
/main/2+   so010.201  ab   1. Fixed filling of mBuf
           so011.201  ps   1. Undo changes done in so010.201
/main/2+   so012.201  ab   1. Orig ReqURI & route should be sent in ACK
/main/2+   so014.201  ps   1. ReqURI/route for INVITE saved in transaction to
                              be used for CANCEL Request.
(/main/2+   so015.201  ad   1. Insert Max Forwards in outgoing ACK request
           so015.201  ps   1. For non-invite transaction, do not delete
                              request  event  on receiving 1xx response.
                           2. Insert Server address in outgoing ACK request.
/main/2+   so017.201  ps   1. Dialog matching procedure modified.This include
                              adding new state in invite server transaction.
/main/2+   so018.201  ps   1. Drop retransmitted 100 trying responses.
/main/2+   so021.201  ab   1. Pass event structure to application in
                              ErrInd Primitive.
/main/2+   so021.201  ss   1. Added Req URI in branch Id generation.
/main/2+   so026.201  ps   1. Subcription control block should be deleted
                              only after ists last reference to TCB is
                              removed.
/main/2+   so028.201  ss   1. Added Via in branch Id generation.
/main/2+   so032.201  ng   1. Pass event type for locating call cb(ab)
/main/2+   so033.201  ng   1. Call the DlgErrInd only in case of Transaction(aj)
                              state is not complete.
/main/2+   so038.201  ng   1. Replaced with macro to check for transport - UDP 
                              and priority UDP
                      pk   2. Added function to move Closing pending Trans to the trans module 
/main/2+   so041.201  ng   1. Reset the pointer after releasing the message.
*********************************************************************91*/

