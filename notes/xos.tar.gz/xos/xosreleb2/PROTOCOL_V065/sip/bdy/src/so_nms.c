/**********************************************************************

    Name:   so_nms.c 

    Type:   C source file

    Desc:   

    File:   so_nms.c

    Sid:    

    Created by: 

**********************************************************************/
#ifdef CP_OAM_SUPPORT

/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lhi.h"           /* HIT LM interface defines        */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "cst.h"           /* Compression module define       */
#include "so_cm.h"         /* SIP layer utility functions     */
#include "su_cfg.h"       /* SIP User defines                */
#include "so.h"            /* SIP Layer defines               */
#include "so_cfg.h" 
#include "sm.h"
#include "xosshell.h"
#include "oam_interface.h"
#include "cp_tab_def.h"


/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lhi.x"           /* HIT LM interface defines        */
#include "lso.x"           /* Layer management SIP            */
#include "cst.x"           /* Compression module              */
#include "sot.x"           /* SOT interface defines           */
#include "so_cm.x"         /* SIP layer utility functions     */
#include "su_cfg.x"       /* SIP User structures             */
#include "so_oam.x"
#include "so_cfg.x" 
#include "sm.x"
#include "sot.x"           /* SOT interface defines           */
#include "so_tcm.x"        /* Transport module structures     */
#include "so.x"            /* SIP layer structures            */

#include "xosshell.h"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"

EXTERN int getTblRec (int iTbId, int iRecId, char *szBuf);
EXTERN int parseFile();

VOID soResetCfgData( )
{
  RETVOID;
}

S16 soNmsRecvInitCfg(tb_record* prow)
{
  SoGenOAMTab     *pSoNmsGenOAM;    
    SoEntOAMTab   *pSoNmsEntOAM;
  SoHdrOAMTab   *pSoNmsHdrOAM;
  SoReUaOAMTab  *pSoNmsReUaOAM;
    CP_OAM_COM_IP_TAB *pIpTab;
  U32 uIPAddr;
    
  while(prow)
  {
    switch(prow->tableid)
    {
      case APP_TABLE_ID_VOIP_SIP_GEN:
        pSoNmsGenOAM = (SoGenOAMTab *) prow->panytbrow;

        g_SoNmsCfgData.soNmsGenCfg.tracnT1 = pSoNmsGenOAM->tracnT1;
        g_SoNmsCfgData.soNmsGenCfg.tracnT2 = pSoNmsGenOAM->tracnT2;
        g_SoNmsCfgData.soNmsGenCfg.tracnT4 = pSoNmsGenOAM->tracnT4;

        break;
      case APP_TABLE_ID_VOIP_SIP_ENT:
        pSoNmsEntOAM = (SoEntOAMTab *) prow->panytbrow;

        strcpy(g_SoNmsCfgData.soNmsEntCfg.domainName,pSoNmsEntOAM->domainName);
        g_SoNmsCfgData.soNmsEntCfg.listenPort = pSoNmsEntOAM->listenPort;
                if ( ROK != CpComGetIpAddr(pSoNmsEntOAM->IpIndex, &uIPAddr) )
                {
                    RETVALUE(RFAILED);
                }                 
        g_SoNmsCfgData.soNmsEntCfg.IpAddr = uIPAddr;        
        g_SoNmsCfgData.soNmsEntCfg.sessTmrVal = pSoNmsEntOAM->sessTmrVal;
        break;
      case APP_TABLE_ID_VOIP_SIP_HDR:
        pSoNmsHdrOAM = (SoHdrOAMTab *) prow->panytbrow;

        g_SoNmsCfgData.soNmsHdrCfg.insDates = pSoNmsHdrOAM->insDates;
        g_SoNmsCfgData.soNmsHdrCfg.insAllow = pSoNmsHdrOAM->insAllow;
        g_SoNmsCfgData.soNmsHdrCfg.insExpires = pSoNmsHdrOAM->insExpires;
        g_SoNmsCfgData.soNmsHdrCfg.insUAHdr = pSoNmsHdrOAM->insUAHdr;
        g_SoNmsCfgData.soNmsHdrCfg.insSupported = pSoNmsHdrOAM->insSupported;
        g_SoNmsCfgData.soNmsHdrCfg.insAccept = pSoNmsHdrOAM->insAccept;
        g_SoNmsCfgData.soNmsHdrCfg.maxFwd = pSoNmsHdrOAM->maxFwd;
        strcpy(g_SoNmsCfgData.soNmsHdrCfg.insOrg,pSoNmsHdrOAM->insOrg);
        strcpy(g_SoNmsCfgData.soNmsHdrCfg.insSubject,pSoNmsHdrOAM->insSubject);
        break;
      case APP_TABLE_ID_VOIP_SIP_REUA:
        pSoNmsReUaOAM = (SoReUaOAMTab *) prow->panytbrow;

        g_SoNmsCfgData.soNmsReUaCfg.dfltExpiresInRegister = pSoNmsReUaOAM->dfltExpiresInRegister;
        g_SoNmsCfgData.soNmsReUaCfg.alertUsrOnExp = pSoNmsReUaOAM->alertUsrOnExp;
        g_SoNmsCfgData.soNmsReUaCfg.refreshOnExp = pSoNmsReUaOAM->refreshOnExp;
        if ( ROK != CpComGetIpAddr(pSoNmsReUaOAM->IpIndex, &uIPAddr) )
                {
                    RETVALUE(RFAILED);
                }
        g_SoNmsCfgData.soNmsReUaCfg.IpAddr = uIPAddr;
        g_SoNmsCfgData.soNmsReUaCfg.regSrvPort = pSoNmsReUaOAM->regSrvPort;
        break;
            case APP_TABLE_ID_COM_IP:
                pIpTab = (CP_OAM_COM_IP_TAB*)prow->panytbrow;

                if ( ROK !=  CpComSetOneIpTab(EN_CP_OPR_ADD,  pIpTab) )
                {
 //                   ITCFGDBGP(DBGMASK_MI, (itGlobalTabCfg.CfgInit.prntBuf, \
 //                   "itRecvInitCfg(CpComSetOneIpTab is RFAILED)\n"));
                    RETVALUE(RFAILED);
                }
                break;
      default:
        break;
    }

    prow = prow->next;
  }

  RETVALUE(ROK);
}


S16 soNmsCfgMsg()
{    
    /* static config data only be done in config start phase, and it would not change after system started*/
    if( gSmCb[ENTSO].smStatus == SM_INIT_CFG_STATE)
    {
        soNmsConfigureUa();              
    }

  RETVALUE(ROK);
}

unsigned char soInitCfgCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow)
{

  if(ROK != soNmsRecvInitCfg(prow))
  {
    opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
    RETVALUE(RFAILED);
  }   

  if(TRUE == pack_end)
  {
    if(ROK != soNmsCfgMsg())
    {
      opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
      RETVALUE(RFAILED);
    }   

    /* send out a config req message to sm*/
    if( ROK != smSendCfgReq(ENTSO, SM_INIT_CFG_STATE))
    {
      opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
      RETVALUE(RFAILED);                         
    }

    /* wait initial cofiguration finished*/
    ssWaitSema(&gSmCb[ENTSO].sema);

    /* send response to subagent*/
    if(SM_SUCCESS_STATE ==  gSmCb[ENTSO].smStatus)
    {
      /* All the initialization configuration data is processed successfully */
      opt_response_batch(sepuense, OAM_RESPONSE_OK);      
      SoNmsBndEnblStck();         
    }
    else 
    {
      opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
    }

    smReset(ENTSO);
  
  
  }

    /* print all input oam cfg info */
    printf("\n[SoGenCfgTab=91]\n");
    printf("tracnT1     tracnT2     tracnT4\n");
    printf("I4          I4          I4\n");
    printf("--------------------------------\n");
    printf("%d  ",soCb.reCfg.tmrReTxCfg.t1);
    printf("%d  ",soCb.reCfg.tmrReTxCfg.t2);
    printf("%d  \n",soCb.reCfg.tmrReTxCfg.t4);
    printf("--------------------------------\n");

    printf("\n[SoHdrCfgTab=93]\n");
    printf("insDates    insAllow    insExpires      insUAHdr  insSupported  insAccept   maxFwd  insOrg  insSubject\n");
    printf("I4          I4          I4              I4          I4            I4          I4      C64     C16\n");
    printf("--------------------------------\n");
    printf("%d  ",soCb.entLst[0]->reCfg.hdrCfg.insDate);
    printf("%d  ",soCb.entLst[0]->reCfg.hdrCfg.insAllow);
    printf("%d  ",soCb.entLst[0]->reCfg.hdrCfg.insExpires);
    printf("%d  ",soCb.entLst[0]->reCfg.hdrCfg.insUAHdr);
    printf("%d  ",soCb.entLst[0]->reCfg.hdrCfg.insSupported);
    printf("%d  ",soCb.entLst[0]->reCfg.hdrCfg.insAccept);
    printf("%d  ",soCb.entLst[0]->reCfg.hdrCfg.maxFwd);
    printf("%s  ",soCb.entLst[0]->reCfg.hdrCfg.insOrg.str);
    printf("%s  \n",soCb.entLst[0]->reCfg.hdrCfg.insSubject.str);
    printf("--------------------------------\n");

    printf("\n[SoReUaCfgTab=94]\n");
    printf("dfltExpiresInRegister   alertUsrOnExp   refreshOnExp\n");
    printf("I4                  I4            I4\n");
    printf("--------------------------------\n");
    printf("%d  ",soCb.entLst[0]->s.ua.reCfg.dfltExpiresInRegister);
    printf("%d  ",soCb.entLst[0]->s.ua.reCfg.alertUsrOnExp);
    printf("%d  \n",soCb.entLst[0]->s.ua.reCfg.refreshOnExp);
    printf("--------------------------------\n");
    /* print end*/

  printf("test in soInitCfgCallback()\n");
  RETVALUE(ROK) ;
}

#endif /*CP_OAM_SUPPORT*/




