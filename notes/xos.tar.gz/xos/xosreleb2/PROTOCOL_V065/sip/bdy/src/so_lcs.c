/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SIP Location Services Module

     Type:     C Source file

     Desc:     C source code for SIP lcs module

     File:     po_lcs.c

     Sid:      so_lcs.c@@/main/4 - Tue Apr 20 12:46:39 2004

     Prg:      tn

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "so.h"            /* SIP layer defines               */
#include "so_trans.h"      /* Transaction module defines      */
#include "so_err.h"        /* SIP error defines               */
#include "so_cm.h"         /* SIP layer utility functions     */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lso.x"           /* Layer management SIP            */
#include "sot.x"           /* SOT interface defines           */
#include "so_tcm.x"        /* Transport module structures     */
#include "so.x"            /* SIP layer structures            */
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* SIP layer utility functions     */
#include "so_cm.x"         /* SIP layer common functions      */
#include "so_dns.x"        /* SIP DNS library                 */
#include "so_cl.x"         /* SIP cache                       */
#include "so_lcs.x"        /* SIP lcs                         */

/* local defines */

/* local typedefs */

/* local externs */

/* forward references */

/* local function definitions */

#ifdef SO_NS
#ifdef SO_LCS 

/* Create new search record */
PRIVATE S16 soLcsCreateSearchRec ARGS((
               SoEvnt          *evnt,
               SoAddrSpec      *toAddress,
               SoLcsSearchRec  **newSearch,
               SoSSapCb        *ssapCb
               ));

/* Delete search record */
PRIVATE S16 soLcsDeleteSearchRec   ARGS((
               SoLcsSearchRec  *delSearch      /* Search record to delete*/
               ));

/* Search termination functions */

PRIVATE S16 soLcsLocatedInd ARGS((
                SoLcsSearchRec  *srchRec,       /* Search record          */
                SoClRegEnt      *contacts       /* Result found           */
                ));

/* Search functions */

/* Perform actual search */
PRIVATE S16 soLcsSearch ARGS((
              SoLcsSearchRec  *srchRec
              ));




/* functions in other modules */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */


/*****************************************************************************
*
*       Fun:   soLcsCreateSearchRec
*
*       Desc:  Creates new search record
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: Allocates new search record to search for IP address
*              corresponding to user@host specified in input
*              address.
*
*       File:  so_lcs.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soLcsCreateSearchRec
(
SoEvnt                  *evnt,         /* Event                  */
SoAddrSpec              *toAddress,    /* Address to search for  */
SoLcsSearchRec          **newSearch,   /* New search record      */
SoSSapCb                *ssapCb        /* SSAP                   */
)
#else
PRIVATE S16 soLcsCreateSearchRec(evnt, toAddress, newSearch, ssapCb)
SoEvnt                  *evnt;         /* Event                  */
SoAddrSpec              *toAddress;    /* Address to search for  */
SoLcsSearchRec          **newSearch;   /* New search record      */
SoSSapCb                *ssapCb;       /* SSAP                   */
#endif
{
   S16              ret;        /* Return value */
   U8               keyBuffer[SO_CACHEKEY_SIZE];   /*Temporary key buffer */

   TRC2(soLcsCreateSearchRec);

   SOALLOC(newSearch, sizeof(SoLcsSearchRec));

   if (*newSearch == NULLP)
     RETVALUE(RFAILED);

   /* Allocate next search number from global control block */
   /*
    * Search number format is as follows
    * <4th octet as 0x00>
    * <3rd octet as message method>
    * <2nd and 1st octet as running integer>
    */
   (*newSearch)->searchNum  = soCb.cacheInfoCb.nextSearchNum++;
   (*newSearch)->searchNum &= ~SO_TRANSID_METHOD_MASK;
   (*newSearch)->searchNum |= (U32)((U8)(SOT_ET_LRQ) << 16);

   (*newSearch)->evnt      = evnt;
   (*newSearch)->toAddress = toAddress;
   (*newSearch)->ssapCb = ssapCb;

   cmInitTimers(&((*newSearch)->searchTmr.tmr),1);

   /* Calculate key to search for. This is the same format as what is used
    * in the caches/registries = normalized version of address
    */

   ret = soClNormalizeCacheKey(toAddress, keyBuffer, &(*newSearch)->keyLength);
   if (ret != ROK)
   {
      SOFREE(newSearch,sizeof(SoLcsSearchRec));
      RETVALUE(RFAILED);
   }

   SOALLOC(&(*newSearch)->searchKey, (*newSearch)->keyLength);
   if ((*newSearch)->searchKey == NULLP)
   {
      SOFREE(newSearch,sizeof(SoLcsSearchRec));
      RETVALUE(RFAILED);
   }

   cmMemcpy((U8 *)(*newSearch)->searchKey, (U8 *)keyBuffer,
      (*newSearch)->keyLength);

   /* Store search record in search list */
   ret = cmHashListInsert(&soCb.cacheInfoCb.searchList,(PTR)(*newSearch),
      (U8 *)&(*newSearch)->searchNum,
      sizeof((*newSearch)->searchNum));
   if (ret != ROK)
   {
      SOFREE((*newSearch)->searchKey,(*newSearch)->keyLength);
      SOFREE(newSearch,sizeof(SoLcsSearchRec));
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* soLcsCreateSearchRec */



/*****************************************************************************
*
*       Fun:   soLcsDeleteSearchRec
*
*       Desc:  Creates new search record
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: Allocates new search record to search for IP address
*              corresponding to [user@]host specified in input
*              request URI.
*
*       File:  so_lcs.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soLcsDeleteSearchRec
(
SoLcsSearchRec  *delSearch      /* Search record to delete*/
)
#else
PRIVATE S16 soLcsDeleteSearchRec(delSearch)
SoLcsSearchRec  *delSearch;     /* Search record to delete*/
#endif
{
   TRC2(soLcsDeleteSearchRec);

   /* Stop timer in case it is running */
   soSchedTmr (delSearch, SO_TMR_LCS_SEARCH, TMR_STOP, NOTUSED);

   if (cmHashListDelete(&soCb.cacheInfoCb.searchList,(PTR)delSearch) != ROK)
      RETVALUE(RFAILED);

   SOFREE(delSearch->searchKey, delSearch->keyLength);

   SOFREE(delSearch,sizeof(SoLcsSearchRec));

   RETVALUE(ROK);
} /* soLcsDeleteSearchRec */




/*****************************************************************************
*
*       Fun:   soLcsSearchFailed
*
*       Desc:  Internal function to process failed search
*
*       Ret:   Nothing
*
*       Notes: Calls user callback with no results, clears search record
*
*       File:  so_lcs.c
*
******************************************************************************/
#ifdef ANSI
PUBLIC S16 soLcsSearchFailed
(
SoLcsSearchRec  *srchRec,       /* Search record          */
SoClRegEnt      *findResult     /* Result found           */
)
#else
PUBLIC S16 soLcsSearchFailed(srchRec, findResult)
SoLcsSearchRec  *srchRec;      /* Search record          */
SoClRegEnt      *findResult;   /* Result found           */
#endif
{

   TRC2(soLcsSearchFailed);

   /* Stop timer in case it is running */
   soSchedTmr(srchRec, SO_TMR_LCS_SEARCH, TMR_STOP, NOTUSED);


   /* Notify caller of result */
   if (soLcsLocatedInd(srchRec, findResult) != ROK)
      RETVALUE(RFAILED);

   /* Free search record */
   if (soLcsDeleteSearchRec(srchRec) != ROK)
      RETVALUE(RFAILED);

   RETVALUE(ROK);
} /* soLcsSearchFailed */



/*****************************************************************************
*
*       Fun:   soLcsSearchOK
*
*       Desc:  Internal function to process result of LCS
*
*       Ret:   Nothing
*
*       Notes: Calls user callback with results
*
*       File:  so_lcs.c
*
******************************************************************************/
#ifdef ANSI
PUBLIC S16 soLcsSearchOK
(
SoLcsSearchRec  *srchRec,       /* Search record          */
SoClRegEnt      *findResult     /* Result found           */
)
#else
PUBLIC S16 soLcsSearchOK(srchRec, findResult)
SoLcsSearchRec  *srchRec;      /* Search record          */
SoClRegEnt      *findResult;   /* Result found           */
#endif
{

   TRC2(soLcsSearchOK);

   /* Stop timer in case it is running */
   (Void)soSchedTmr(srchRec, SO_TMR_LCS_SEARCH, TMR_STOP, NOTUSED);

   /* Notify caller of result */
   if (soLcsLocatedInd(srchRec, findResult) != ROK)
      RETVALUE(RFAILED);

   /* Free search record */
   if (soLcsDeleteSearchRec(srchRec) != ROK)
      RETVALUE(RFAILED);

   RETVALUE(ROK);
} /* soLcsSearchOK */


/*****************************************************************************
*
*       Fun:   soLcsLocatedInd
*
*       Desc:  Internal function to process result of LCS
*
*       Ret:   Nothing
*
*       Notes: 
*
*       File:  so_lcs.c
*
******************************************************************************/
#ifdef ANSI
PRIVATE S16 soLcsLocatedInd
(
SoLcsSearchRec  *srchRec,       /* Search record          */
SoClRegEnt      *contacts       /* Result found           */
)
#else
PRIVATE S16 soLcsLocatedInd(srchRec, contacts)
SoLcsSearchRec  *srchRec;      /* Search record          */
SoClRegEnt      *contacts;     /* Result found           */
#endif
{
   S16  ret;

   TRC2(soLcsLocatedInd);

   /* If the contact is NULL then return 404 message */
   if (contacts == NULLP)
   {
      soTptReturnError(srchRec->ssapCb->sys, NULLP, NULLP, srchRec->evnt, 
                       SOT_RSP_404_NOT_FOUND);
      RETVALUE(RFAILED);
   }

   /* Copy the first contact into the Req URI */ 
   ret = soClCopyContactIntoReqUri(srchRec->evnt,
                                   (SoClRegContactEnt *)
                                   cmLListNode(cmLListFirst(&contacts->listContacts)));
   if (ret != ROK)
      RETVALUE(RFAILED);

   /* Send the Ind to the user */    
   ret = soUiCIMInd (srchRec->ssapCb, 
                     SOT_CONNID_NOTUSED,
                     SOT_CONNID_NOTUSED,
                     (SoEvnt *)srchRec->evnt);

   if (ret != ROK)
     RETVALUE (RFAILED);

   RETVALUE(ROK);
} /* soLcsLocatedInd */



/*--------------------------------------------------------------------
      SIP Location Services Functions: Search Function
 ---------------------------------------------------------------------*/


/*****************************************************************************
*
*       Fun:   soLcsSearch
*
*       Desc:  Perform location search
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  so_lcs.c
*
******************************************************************************/
#ifdef ANSI
PUBLIC S16 soLcsSearch
(
SoLcsSearchRec  *srchRec      /* Search record                */
)
#else
PUBLIC S16 soLcsSearch(srchRec)
SoLcsSearchRec  *srchRec;     /* Search record                */
#endif
{
   S16             ret;           /* Return value */
   SoClRegEnt      *regEntry;     /* Registry entry from cache */
   U16             findCount;     /* Number of entries found */
   SoEvnt          *reqEvnt;      /* Event to SOT to request location */
   SoAddress       *lrqTo;        /* To header for LRQ */
   SoAddrSpec      *requestURI;   /* temporary pointer to requestURI */
   SoSSapCb        *locSrvSSap;   /* Location service sap  */

   TRC2(soLcsSearch);

   /* 1st check LCS cache */
   if (soCb.cfg.locSrvCfg.locCachePres == TRUE)
   {
      ret = soClFindUser(&soCb.cacheInfoCb.extLocSrvCache, srchRec->toAddress,
                         &regEntry, &findCount);
      if ((ret == ROK) && (findCount>0))
      {
         /* Found answer, return to user, */
         if (soLcsSearchOK(srchRec, regEntry) != ROK)
            RETVALUE(RFAILED);
         else
            RETVALUE(ROK);
      }
   }

   /* No cache or nothing in cache, query external LCS via upper interface
    * Send request to location server
    * Set timer for timeout
    *
    */
   if (soCmCreateEvent(&reqEvnt, SOT_ET_LRQ) != ROK)
   {
      soLcsSearchFailed(srchRec, NULLP);
      RETVALUE(RFAILED);
   }

   /* Store context information */
   reqEvnt->transId = srchRec->searchNum;

   /* Construct new message to send via SOT */
   /* SO_ET_LRQ contains sip message with "To" = req URI */
   reqEvnt->sipMessageType.pres = PRSNT_NODEF;
   reqEvnt->sipMessageType.val  = SO_SIPMESSAGE_REQUEST;
   reqEvnt->t.request.pres.pres = PRSNT_NODEF;

   /* Add new request header */
   ret = soCmCreateHdrChoice(reqEvnt, (U8 **)&lrqTo, SO_HEADER_GEN_TO);
   if (ret != ROK)
   {
      (Void) soCmFreeEvent(reqEvnt);
      soLcsSearchFailed(srchRec, NULLP);
   }

   lrqTo->addrCh.addrChType.pres = PRSNT_NODEF;
   lrqTo->addrCh.addrChType.val  = SO_ADDRCH_ADDRSPEC;

   soUtlCpySoAddrSpec(&lrqTo->addrCh.t.addrSpec, srchRec->toAddress, &reqEvnt->memCp);

    /* Include Request-Uri in sending the Location Services 
     * Request to the External Location Services. Currently 
     * for internal Location Services we still use the "To" 
     * field. However for the external LS, we pass both
     * and it is up to the application to chose. */
    /* also Include memCp in soCpySoAddrSpec */
   requestURI = &srchRec->evnt->t.request.requestLine.addrSpec;
   if (requestURI->addrSpecType.pres != NOTPRSNT)
   {
      if (soUtlCpySoAddrSpec(&reqEvnt->t.request.requestLine.addrSpec, 
            requestURI, &reqEvnt->memCp) != ROK)
      {
         (Void) soCmFreeEvent(reqEvnt);
         soLcsSearchFailed(srchRec, NULLP);
      }
   }

   (Void)soSchedTmr(srchRec, SO_TMR_LCS_SEARCH, TMR_START, SO_TMRVAL_LCS_EXTLCS);

   /* Check if ssap is valid */
   locSrvSSap = soCb.soSSapCbLst[srchRec->ssapCb->sys->reCfg.locSrvSapId];
   if (locSrvSSap == NULLP)
      RETVALUE(RFAILED);

   ret = soUiCIMInd (locSrvSSap, 
                     SOT_CONNID_NOTUSED,
                     SOT_CONNID_NOTUSED,
                     reqEvnt);
   if (ret != ROK)
     RETVALUE (RFAILED);

   RETVALUE(ROK);
} /* soLcsSearch */




/*--------------------------------------------------------------------
      SIP Location Services Functions: External interface functions
      soLcsFindSipUser
         Initiate new search for a SIP user
      soLcsTimer
         Process location service timer
      soLcsProcessRegistrarResult
         Handle response from registrar server
 ---------------------------------------------------------------------*/


/*****************************************************************************
*
*       Fun:   soLcsFindSipUser
*
*       Desc:  Locate sip user
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: Allocates new search record to search for IP address
*              corresponding to user@host specified in input
*              sip URL, normally this URL = "To" part of message
*
*       File:  so_lcs.c
*
******************************************************************************/
#ifdef ANSI
PUBLIC S16 soLcsFindSipUser
(
SoEvnt          *evnt,          /* Event                        */
SoSSapCb        *ssapCb,        /* Sap to be used for this call */
SoAddrSpec      *toAddress      /* Address to find              */
)
#else
PUBLIC S16 soLcsFindSipUser(evnt, ssapCb, toAddress)
SoEvnt          *evnt;          /* Event                        */
SoSSapCb        *ssapCb;        /* Sap to be used for this call */
SoAddrSpec      *toAddress;     /* Address to find              */
#endif
{
   S16               ret;         /* Return value */
   SoLcsSearchRec    *searchRec;  /* Current search record */

   TRC2(soLcsFindSipUser);

   if (toAddress == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG,ESO097,(ErrVal) 0,
                 "soLcsFindSipUser: NULL parameter");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
      RETVALUE(RFAILED);
   }

   ret = soLcsCreateSearchRec(evnt, toAddress, &searchRec, ssapCb);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* Search record allocated, perform actual search */
   if (soLcsSearch(searchRec)!= ROK)
      RETVALUE(RFAILED);

   RETVALUE(ROK);
} /* soLcsFindSipUser */



/*****************************************************************************
*
*       Fun:   soLcsTimer
*
*       Desc:  Times out a search
*
*       Ret:   Nothing
*
*       Notes: Search must have failed if timer times out
*
*       File:  so_lcs.c
*
******************************************************************************/
#ifdef ANSI
PUBLIC Void soLcsTimer
(
SoLcsSearchRec   *srchRec      /* Search record */
)
#else
PUBLIC Void soLcsTimer(srchRec)
SoLcsSearchRec   *srchRec;     /* Search record */
#endif
{
  
   TRC2(soLcsTimer);
   /* Timeout on search - failed */
   soLcsSearchFailed(srchRec, NULLP);

   RETVOID;

} /* soLcsTimer */


/*****************************************************************************
*
*       Fun:   soLcsDeInit
*
*       Desc:  Terminates all pending searches
*
*       Ret:   Nothing
*
*       Notes:
*
*       File:  po_lcs.c
*
******************************************************************************/
#ifdef ANSI
PUBLIC Void soLcsDeInit
(
Void
)
#else
PUBLIC Void soLcsDeInit()
#endif
{
   SoLcsSearchRec  *srchRec;     /* Search record */

   TRC2(soLcsDeInit);

   /* Terminate all pending LCS searches */
   while (cmHashListGetNext(&soCb.cacheInfoCb.searchList, NULLP, (PTR *) &srchRec) == ROK)
   {
      soLcsDeleteSearchRec(srchRec);
   }

   RETVOID;

} /* soLcsDeInit */

#endif /* SO_LCS */
#endif /* SO_NS */


/********************************************************************30**

         End of file:     so_lcs.c@@/main/4 - Tue Apr 20 12:46:39 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**


*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/4      ---     ms     1. initial release.
*********************************************************************91*/

