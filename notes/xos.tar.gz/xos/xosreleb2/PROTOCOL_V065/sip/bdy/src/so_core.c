/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SIP Layer

     Type:    C source file

     Desc:    SIP Core functions

     File:    po_core.c

     Sid:      so_core.c@@/main/4 - Tue Apr 20 12:46:07 2004

     Prg:     pk

*********************************************************************21*/

/* header include files (.h) */
#include "envopt.h"         /* environment options          */
#include "envdep.h"         /* environment dependent        */
#include "envind.h"         /* environment independent      */
#include "gen.h"            /* general layer                */
#include "ssi.h"            /* system services              */
#include "cm_llist.h"       /* common library               */
#include "cm_hash.h"        /* common hash list             */
#include "cm_tpt.h"         /* common transport             */
#include "cm_tkns.h"        /* common tokens                */
#include "cm_sdp.h"         /* common SDP                   */
#include "cm_mblk.h"        /* common memory allocation     */
#include "cm_abnf.h"        /* common abnf library          */
#include "cm_dns.h"         /* common DNS                   */
#include "sot.h"            /* SOT interface                */
#include "lso.h"            /* layer management, SIP        */
#include "so.h"             /* SIP layer defines            */
#include "so_trans.h"       /* Transaction related structures */
#include "so_err.h"         /* SIP error defines            */
#include "so_cm.h"          /* SIP layer utility functions  */
#include "so_ua.h"          /* interface between UI and UA  */

/* header/extern include files (.x) */
#include "gen.x"            /* general layer                */
#include "ssi.x"            /* system services              */
#include "cm5.x"            /* common timer module          */
#include "cm_lib.x"         /* common library               */
#include "cm_llist.x"       /* common link list             */
#include "cm_hash.x"        /* common hash list             */
#include "cm_tkns.x"        /* common tokens                */
#include "cm_tpt.x"         /* common transport             */
#include "cm_xtree.x"       /* common radix tree            */
#include "cm_mblk.x"        /* common memory allocation     */
#include "cm_sdp.x"         /* common SDP                   */
#include "cm_abnf.x"        /* common abnf library          */
#include "cm_dns.x"         /* common DNS                   */
#include "sot.x"            /* SOT interface                */
#include "lso.x"            /* layer management SIP         */
#include "so_tcm.x"         /* Transport related structures */
#include "so.x"             /* SIP layer structures         */
#include "so_trans.x"       /* Transaction related structures */
#include "so_cm.x"          /* SIP layer utility functions  */
#include "so_dns.x"         /* SIP DNS functions            */
#include "so_tcm.x"         /* TCM defines                  */
#include "so_utl.x"         /* SIP utility functions        */
#include "so_cl.x"          /* SIP Cache  Services          */
#include "so_lcs.x"         /* SIP Location Services        */

#ifdef SO_UA
/***************************************************************/
/*             Private Function Prototypes                     */
/***************************************************************/
PRIVATE  Void soCoreInitSessCreatedBy ARGS((SoCallCb  *callCb,
                                            SoEvnt    *evnt));

PRIVATE S16 soCoreInitCallCb ARGS((SoSSapCb *ssap,
                                   SoEntCb  *ent,
                                   UConnId  suConnId,
                                   SoEvnt   *evnt,
                                   SoCallCb *callCb,
                                   U8      direction));

/*- so017.201: Functions to help match messages to dialog -*/

PRIVATE SoCLegCb * soCoreFindRspDlgWithTags ARGS ((
                                       SoCallCb   *callCb,
                                       TknStrOSXL *rcvdLocalTag,  
                                       TknStrOSXL *rcvdRemoteTag,
				       SoCLegCb   **partialCLeg,
                                       SoCSeq      *rxCSeq));

PRIVATE S16 soCoreValidateRspDlg ARGS ((
                                       SoCLegCb   *cLegCb,
                                       TknStrOSXL *rcvdLocalTag,  
                                       TknStrOSXL *rcvdRemoteTag));

/*- so023.201: Add partialed call leg when matching the dialog -*/
PRIVATE SoCLegCb * soCoreFindDlgWithTags ARGS ((
                                       SoCallCb   *callCb,
                                       SoEvnt     *request,       
                                       SoAddress  *rcvdLocalAddr, 
                                       SoAddress  *rcvdRemoteAddr,
                                       TknStrOSXL *rcvdLocalTag,  
                                       TknStrOSXL *rcvdRemoteTag,
                                       SoCLegCb   **partialCLeg));

PRIVATE SoCLegCb * soCoreFindCancelDlg ARGS ((
                                       SoCallCb   *callCb,        
                                       SoEvnt     *request,       
                                       SoAddress  *rcvdLocalAddr, 
                                       SoAddress  *rcvdRemoteAddr,
                                       TknStrOSXL *rcvdRemoteTag));


/***************************************************************/
/*      Interface Functions to Dialog Layer                    */
/***************************************************************/

/*-- Interface functions for matching request/response to dialog --*/

/*
*
*       Fun:   soCoreReqMatchDialog
*
*       Desc:  This function  locates a  call control block and cleg 
*              control block for a new request message received from
*              peer entity.
*              
*              This function is called from dialog module one recei-
*              ving a NEW request.It is very important that only NEW
*              request are passed to this function and not the retr-
*              nsmitted requests.
*
*       RET :  SO_DLG_MATCH, if request matches any existing dialogs
*              SO_DLG_CREATE, New dialog needs to be created
*              SO_DLG_NOMATCH, no match found with  existing dialogs
*
*              If callCb if found "callCb" argument  will be updated
*              If call leg if found "cLegCb" will be updated.
*
*       Notes: 
*
*       File:  so_core.c
*
*/
#ifdef ANSI
PUBLIC S16 soCoreReqMatchDialog
(
SoEntCb    *ent,      /* Entity Cb              */
SoEvnt     *request,  /* Request Event          */
SoCallCb   **callCb,  /* Call Cb (returned)     */
SoCLegCb   **cLegCb   /* Call Leg Cb (returned) */
)
#else
PUBLIC S16 soCoreReqMatchDialog (ent, request, callCb, cLegCb)
SoEntCb    *ent;      /* Entity Cb              */
SoEvnt     *request;  /* Request Event          */
SoCallCb   **callCb;  /* Call Cb (returned)     */
SoCLegCb   **cLegCb;  /* Call Leg Cb (returned) */
#endif
{
  S16         ret;           /* return value of function */
  TknStrOSXL  *callId;       /* "callId" in request      */
  SoAddress   *reqLocalAddr; /* "To" header in request   */
  SoAddress   *reqRemoteAddr;/* "From" header in request */
  TknStrOSXL  *reqLocalTag;  /* "To" tag in request      */
  TknStrOSXL  *reqRemoteTag; /* "From" tag in request    */
 /* so023.201 Call leg that at least matches the local tag */
  SoCLegCb    *partialCLeg;  /* DialogCb that matches
                                atleast matches local
                                tag                 */

  TRC3 (soCoreReqMatchDialog);

  /*----------------- Initialize Local Variables --------------------*/
   *cLegCb  = NULLP;
   *callCb = NULLP;

  /*------- STEP 1: Find Call Context Based on "CallId" header ------*/
   soCmFindHdrChoice (request, (U8 **)&callId, SO_HEADER_GEN_CALLID);
    
   /* so032.201: Passing even type to locate Call Cb */
   *callCb = soCoreLocateCallCb (ent, SO_CONNID_NOTUSED, SO_CONNID_NOTUSED,
                                 callId, SOT_ET_UNKNOWN);
   /*- If Call Context is not found, simply return -*/
   if (*callCb == NULLP)
      RETVALUE (SO_DLG_CREATE);

  /*---- STEP 2: Find dialog context based on local/remote tags -----*/
   
   /*---- Locate local/remote tag and address in request message ----*/
    ret =  soCoreGetAddrAndTags (request,
                                 &reqLocalAddr,
                                 &reqRemoteAddr,
                                 &reqLocalTag,
                                 &reqRemoteTag);
    if (ret != ROK)
      RETVALUE (SO_DLG_NOMATCH);

   /*-- Further handling depends on request method -*/
    switch (request->eventType.val)
    {
       case SOT_ET_INVITE   :
       case SOT_ET_SUBSCRIBE:

      /*--- so024.201: Create the dialog for register msg in case UA *
       *---            accepting registration                        */
#ifdef SO_XX_UA_PRC_REGISTER
       case SOT_ET_REGISTER:
#endif

      /*--- so041.201: IM can be received outside dialog. IM without *
       *---            local-tag indicates that we need to create    *
       *---            new dialog.                                   */
       case SOT_ET_MESSAGE:
           /*------ Dialog Creating Requests -------*/

            if (reqLocalTag == NULLP)
              /*
               * Dialog creating  request with  no "local tag"  implies
               * that new  dialog is being created.
               */
               RETVALUE (SO_DLG_CREATE);

           /* 
            * Must be request within dialog.
            * Find dialog that  matches tags received in the request m-
            * essage.
            */
            (*cLegCb) = soCoreFindDlgWithTags ((*callCb),
                                         request      ,
                                         reqLocalAddr ,
                                         reqRemoteAddr,
                                         reqLocalTag  ,
                                         reqRemoteTag ,
                                         &partialCLeg);
           break;

       case SOT_ET_CANCEL   : /* CANCEL Request */

            if (reqLocalTag == NULLP)
            {
              /*
               * CANCEL request with NO local tag, implies canceling of
               * dialog creating request. This CANCEL can be considered
               * matching a dialog only if, remote tag, CSEQ and reque-
               * stURI matches that of request that created dialog.
               * 
               * This matcing is required to take care of following sc-
               * enarios.
               * (1) Multiple forked legs with same CSeq, but different
               *     URI's.
               * (2) Multiple legs with different CSeq, but same reque-
               *     st URI.
               * (3) CANCEL received after INVITE tranaction is comple-
               *     ted.
               */
               (*cLegCb) = soCoreFindCancelDlg ((*callCb),
                                             request,
                                             reqLocalAddr,
                                             reqRemoteAddr,
                                             reqRemoteTag);
            }

            else
            {
              /*----------- Must be request within dialog -----------*/
              /*
               * CANCEL with localTag implies canceling of request wit-
               * in dialog.
               * Find dialog that  matches tags received in the request
               * message.
               */
               (*cLegCb) = soCoreFindDlgWithTags ((*callCb),
                                           request      ,
                                           reqLocalAddr ,
                                           reqRemoteAddr,
                                           reqLocalTag  ,
                                           reqRemoteTag ,
                                           &partialCLeg);
            }

           break;

      /*
         so023.201 If a partial match is found when processing the
                   NOTIFY request, save the call leg into cLegCb so
                   that the request is not rejected by 481. This is 
                   because the NOTIFY can protentially arrive before
                   the 200 OK for the SUBSCRIBE message, which is 
                   allowed by the RFC 
       */
       case SOT_ET_NOTIFY   : /* Notify Request */
           /* 
            * Any other request  must be within  an existing dialog. It
            * MUST have a local tag.
            */
   /* cso032.201: Support for outside Dialog Notifications */  
   /* Create a new dialog if To(local) tag is not present for out of dialog notify */
             if (reqLocalTag == NULLP)
#ifdef SO_OUTDLGNOTIFY
               RETVALUE (SO_DLG_CREATE);
#else
               RETVALUE (SO_DLG_NOMATCH);
#endif

           /*------------ Must be request within dialog -------------*/
           /*-- Find dialog that match tags received in the request -*/
            (*cLegCb) = soCoreFindDlgWithTags ((*callCb),
                                           request      ,
                                           reqLocalAddr ,
                                           reqRemoteAddr,
                                           reqLocalTag  ,
                                           reqRemoteTag ,
                                           &partialCLeg);

            if ((*cLegCb == NULLP) && partialCLeg)
            {
               /* so034.201: If remote tag is not present in cleg (NOTIFY is recd before 200), 
                  update remote tag with  rcvd NOTIFY 'To' tag */
               if ((partialCLeg)->storedHdrs.remoteTag.pres == NOTPRSNT)
               {
                  if (soCmSaveRemoteTag (&(partialCLeg)->storedHdrs.remoteAddr,
                                         reqRemoteAddr,
                                         request,
                                         &(partialCLeg)->storedHdrs.remoteTag,
                                         reqRemoteTag) != ROK)
                    RETVALUE (SO_DLG_NOMATCH);
                    *cLegCb = partialCLeg; /* */
               }
               else
                  RETVALUE (SO_DLG_CREATE);/*create new dialog for forked SUBSCRIBES
                                             and NOTIFY recieved before 200 */
            }

           break;

       default: 
           /* 
            * Any other request  must be within  an existing dialog. It
            * MUST have a local tag.
            */
            if (reqLocalTag == NULLP)
               RETVALUE (SO_DLG_NOMATCH);

           /*------------ Must be request within dialog -------------*/
           /*-- Find dialog that match tags received in the request -*/
            (*cLegCb) = soCoreFindDlgWithTags ((*callCb),
                                           request      ,
                                           reqLocalAddr ,
                                           reqRemoteAddr,
                                           reqLocalTag  ,
                                           reqRemoteTag ,
                                           &partialCLeg);
           break;

    } /* End of switch (request Method) */

    if ((*cLegCb))
      /*---------- Request belongs to an existing dialog ------------*/
       RETVALUE (SO_DLG_MATCH);
    
   /* 
    * Request does not belong to existing, and is also not dialog crea-
    * ting request
    */
    RETVALUE (SO_DLG_NOMATCH);

} /* End of fn soCoreReqMatchDialog () */



/*
*
*       Fun:   soCoreRspMatchDialog
*
*       Desc:  This function  locates a  call control block and cleg 
*              control  block  for a response message.
*              
*              In most of cases,  transaction that received response
*              is sufficient to  find dialog  for response. Only for
*              1xx/2xx response for dialog  creating  requests  like
*              INVITE/SUBSCRIBE, we may need to create new dialogs.
*
*       RET :  SO_DLG_MATCH, if response matches any existing dialogs
*              SO_DLG_CREATE, New dialog needs to be created
*              SO_DLG_NOMATCH, no match found with  existing dialogs
*
*              If callLeg if found "cLegCb" argument will be updated.
*
*       Notes: 
*
*       File:  so_core.c
*
*/
#ifdef ANSI
PUBLIC S16 soCoreRspMatchDialog
(
SoEntCb    *ent,      /* Entity Cb              */
SoEvnt     *response, /* Response Event         */
SoCallCb   *callCb,   /* Call to which response's
                         transaction belongs    */
SoCLegCb   **cLegCb,  /* Dialog Cb that received
                         message (modified)     */
SoCLegCb   **partialCLeg /* DialogCb that matches
                            atleast matches local
                            tag                 */
)
#else
PUBLIC S16 soCoreRspMatchDialog (ent, response, callCb, cLegCb, partialCLeg)
SoEntCb    *ent;      /* Entity Cb              */
SoEvnt     *response; /* Rsponse Event          */
SoCallCb   *callCb;   /* Call to which response's
                         transaction belongs    */
SoCLegCb   **cLegCb;  /* Dialog Cb that received
                         message (modified)     */
SoCLegCb   **partialCLeg;/* DialogCb that matches
                            atleast matches local
                            tag                 */
#endif
{
  S16         ret;           /* return value of function  */
  TknStrOSXL  *callId;       /* "callId" in response      */
  SoAddress   *resLocalAddr; /* "To" header in response   */
  SoAddress   *resRemoteAddr;/* "From" header in response */
  TknStrOSXL  *resLocalTag;  /* "To" tag in response      */
  TknStrOSXL  *resRemoteTag; /* "From" tag in response    */
  U16         responseCode;  /* Response Code             */
  SoCSeq      *rxCSeq;       /* CSeq received in CANCEL    */

  TRC3 (soCoreRspMatchDialog);

  /*----------------- Initialize Local Variables ---------------------*/
   (*partialCLeg) = NULLP;
   responseCode   = response->t.response.statusLine.statusCode.val;

  /*------- STEP 1: Find Call Context, if not already provided -------*/
   if (callCb == NULLP)
   {
     soCmFindHdrChoice (response, (U8 **)&callId, SO_HEADER_GEN_CALLID);
    
     /* so032.201: Passing even type to locate Call Cb */
     callCb = soCoreLocateCallCb (ent, SO_CONNID_NOTUSED, SO_CONNID_NOTUSED,
                                  callId, SOT_ET_UNKNOWN);
     if (callCb == NULLP)
     /*- For Response, call context should always exist -*/
        RETVALUE (SO_DLG_NOMATCH);
   }

  /*----- STEP 2: Find dialog context based on local/remote tags -----*/
   
   /*---- Locate local/remote tag and address in response message ----*/
    ret =  soCoreGetAddrAndTags (response    , &resLocalAddr, &resRemoteAddr,
                                 &resLocalTag, &resRemoteTag);

   /*---------------- All response MUST have local tag ---------------*/
    if ((ret != ROK) || (resLocalTag == NULLP))
      RETVALUE (SO_DLG_NOMATCH);

   /*-- Further handling depends upon response method --*/
    switch (response->eventType.val)
    {
       case SOT_ET_INVITE   :
       case SOT_ET_SUBSCRIBE:

         /*---------- Response For Dialog Creating Requests ----------*/
	 /*-- Find dialog that match tags received in the response ---*/
         soCmFindHdrChoice (response, (U8 **) &rxCSeq, SO_HEADER_GEN_CSEQ);

         /*-- Find dialog that match tags received in the response ---*/
         (*cLegCb) = soCoreFindRspDlgWithTags (callCb , resLocalTag,
                                          resRemoteTag, partialCLeg, rxCSeq);

         /* 
          * Multiple 1-6xx Response  for dialog  creating requests will
          * result in creating new dialog, if one does not already exi-
          * sts.
          * so018.201: Create dialog for all unique responses.
          */
          if ((*cLegCb == NULLP) && (*partialCLeg))
              RETVALUE (SO_DLG_CREATE);

          if ((*cLegCb) == NULLP)
             RETVALUE (SO_DLG_NOMATCH);

         /*------- Update Remote Tag For 1xx/2xx, If Required --------*/
         /*---- so018.201: Save remote tag for all final responses ---*/
          if (((*cLegCb)->storedHdrs.remoteTag.pres == NOTPRSNT) &&
              (responseCode > SOT_RSP_100_TRYING))
          {
             if (soCmSaveRemoteTag (&(*cLegCb)->storedHdrs.remoteAddr,
                                    resRemoteAddr,
                                    response     ,
                                    &(*cLegCb)->storedHdrs.remoteTag,
                                    resRemoteTag) != ROK)
               RETVALUE (SO_DLG_NOMATCH);
          }

          RETVALUE (SO_DLG_MATCH);

         break;

       default:

         /*--------- Response For Non-Dialog Creating Requests -------*/
         /*
          * The Non-dialog creating responses MUST ALWAYS match callLeg
          * that received  the response.  We just need to validate that
          * headers received in response  are similar to that stored in 
          * callLeg.
          */
          if ((cLegCb == NULLP) || (*cLegCb == NULLP))
           /*----- Responses MUST have an existing dialog. ------*/
            RETVALUE (SO_DLG_NOMATCH);

          ret = soCoreValidateRspDlg (*cLegCb, resLocalTag, resRemoteTag);
          if (ret != ROK)
            RETVALUE (SO_DLG_NOMATCH);

          RETVALUE (SO_DLG_MATCH);
          
         break;

    } /* End of switch (response Method) */


} /* End of fn soCoreRspMatchDialog () */

/*
*
*       Fun:   soCoreFindRspDlgWithTags
*
*       Desc:  This function finds dialog for a response  message that
*              matches local and remote tags.  
*
*       RET :  cLegCb, if success.
*              NULLP,  if not found.
*
*       Notes: 
*
*       File:  so_core.c
*
*/
#ifdef ANSI
PRIVATE SoCLegCb * soCoreFindRspDlgWithTags
(
SoCallCb   *callCb,        /* Entity Cb                */
TknStrOSXL *rcvdLocalTag,  /* Local tag received       */
TknStrOSXL *rcvdRemoteTag, /* Remote tag received      */
SoCLegCb   **partialCLeg,  /* Dialog Cb that matches at
                              least matches local tag  */
SoCSeq      *rxCSeq
)
#else
PRIVATE SoCLegCb * soCoreFindRspDlgWithTags (callCb, rcvdLocalTag,
                                rcvdRemoteTag, partialCLeg, rxCSeq)
SoCallCb   *callCb;        /* Entity Cb                */
TknStrOSXL *rcvdLocalTag;  /* Local tag received       */
TknStrOSXL *rcvdRemoteTag; /* Remote tag received      */
SoCLegCb   **partialCLeg;  /* Dialog Cb that matches at
                              least matches local tag  */
SoCSeq      *rxCSeq;
#endif
{
  CmLList     *llEnt;      /* Used to traverse link list */
  TknStrOSXL  *localTag;   /* Dialog's Local tag         */
  TknStrOSXL  *remoteTag;  /* Dialog's Remote tag        */
  SoCLegCb    *cLegCb;     /* Call leg pointer returned  */

  TRC3 (soCoreFindRspDlgWithTags);

  /*----------------- Initialize Local Variables --------------------*/
   llEnt          = NULLP;
   (*partialCLeg) = NULLP;

  /*-------- Search Call Leg Link List for matching call leg --------*/
   /* so022.201: Start from the end of the list */
   cLegCb = (SoCLegCb *)((llEnt = cmLListLast(&callCb->cLegLst))
                          ? llEnt->node : NULLP);
   for (;cLegCb;
        cLegCb = (SoCLegCb *)CM_LLIST_PREV_NODE (&callCb->cLegLst, llEnt))
   {
        remoteTag  = &cLegCb->storedHdrs.remoteTag;
        localTag   = &cLegCb->storedHdrs.localTag;

       /*-- Match with local tag present in the call leg --*/
        if (!(SO_CMP_TKNSTR (localTag , rcvdLocalTag)))
           continue;

        (*partialCLeg) = cLegCb;

       /*-- Match with remote tag present in the call leg -*/
        if (remoteTag->pres == PRSNT_NODEF)
        {
           if ((!rcvdRemoteTag) || !(SO_CMP_TKNSTR (remoteTag, rcvdRemoteTag)))
              continue;
        }
        else
        {
           /*- so033.201 : Call Leg control block without remote tag    *
            * indicates that it has not yet received any response.      *
            * When the first response with valid remote tag is received *
            * it is updated in call leg control block.                  *
            *                                                           *
            * Since we support multiple simultaneous call legs(dialogs) *
            * as part one call control block, it is quite possible that *
            * at any given time,we have multiple call leg control block *
            * without remote tags in them.                              *
            *                                                           *
            * Given the fact that remote tag in call leg will not be    *
            * present ONLY for first response, we can check the CSEQ    *
            * of dialog creating request with the CSEQ value received   *
            * in the response to make sure that the response belongs to *
            * this call leg (dialog) control block.                     *
            * 
            * Dialog match will considered to be failed, if for the     *
            * first response, CSeq match fails. partialCLeg will be Null*
            * in this case.                                             */

            if (rxCSeq->cSeqVal.val != cLegCb->storedHdrs.dlgCreateCSeq)
            {
               (*partialCLeg) = NULLP;
               continue;
            }
        }

        break;

   } /* For (each dialog in call) */

   if (cLegCb)
   {
      /*----------- Found Matching Dialog For Message ------------*/
       SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
          "\n[Dialog] Found Dialog For Response:"
          " Call(%ld), CallLeg(%lx), State(%d)",
          cLegCb->call->spConnId, cLegCb->legId, cLegCb->clegState));
   }

   RETVALUE (cLegCb);

} /* End of fn soCoreFindRspDlgWithTags () */


/*
*
*       Fun:   soCoreValidateRspDlg
*
*       Desc:  This function validates whether response belongs to a
*              given dialog or not.
*
*       RET :  ROK, if success.
*              RFAILED,  if faulure.
*
*       Notes: 
*
*       File:  so_core.c
*
*/
#ifdef ANSI
PRIVATE S16 soCoreValidateRspDlg
(
SoCLegCb   *cLegCb,        /* Call Leg to be matched   */
TknStrOSXL *rcvdLocalTag,  /* Local tag received       */
TknStrOSXL *rcvdRemoteTag  /* Remote tag received      */
)
#else
PRIVATE S16 soCoreValidateRspDlg (cLegCb, rcvdLocalTag, rcvdRemoteTag)
SoCLegCb   *cLegCb;        /* Call Leg to be matched   */
TknStrOSXL *rcvdLocalTag;  /* Local tag received       */
TknStrOSXL *rcvdRemoteTag; /* Remote tag received      */
#endif
{
  TknStrOSXL  *localTag;   /* Dialog's Local tag         */
  TknStrOSXL  *remoteTag;  /* Dialog's Remote tag        */

  TRC3 (soCoreValidateRspDlg);

  /*---------- Initialize Local Variables ------------*/
   remoteTag  = &cLegCb->storedHdrs.remoteTag;
   localTag   = &cLegCb->storedHdrs.localTag;

  /*-- Match with local tag present in the call leg --*/
   if (!(SO_CMP_TKNSTR (localTag , rcvdLocalTag)))
      RETVALUE (RFAILED);

  /*-- Match with remote tag present in the call leg -*/
   if ((remoteTag->pres == PRSNT_NODEF) &&
       ((!rcvdRemoteTag) || !(SO_CMP_TKNSTR (remoteTag, rcvdRemoteTag))))
      RETVALUE (RFAILED);

  /*------- Found Matching Dialog For Message --------*/
   SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf,
      "\n[Dialog] Found Dialog For Response:"
      " Call(%ld), CallLeg(%lx), State(%d)",
      cLegCb->call->spConnId, cLegCb->legId, cLegCb->clegState));

   RETVALUE (ROK);

} /* End of fn soCoreValidateRspDlg () */



/*
*
*       Fun:   soCoreFindDlgWithTags
*
*       Desc:  This function finds dialog that matches local and remo-
*              te tags.  If  remote  tag  is NULLP, it implies peer is
*              2543 compliant,  and  we  need to match "to" and "from"
*              header as well.
*
*       RET :  cLegCb, if success.
*              NULLP,  if not found.
*
*       Notes: 
*
*       File:  so_core.c
*
*/
#ifdef ANSI
PRIVATE SoCLegCb * soCoreFindDlgWithTags
(
SoCallCb   *callCb,        /* Entity Cb                */
SoEvnt     *request,       /* Request Event            */
SoAddress  *rcvdLocalAddr, /* Local address received   */
SoAddress  *rcvdRemoteAddr,/* Remote address received  */
TknStrOSXL *rcvdLocalTag,  /* Local tag received       */
TknStrOSXL *rcvdRemoteTag, /* Remote tag received      */
SoCLegCb   **partialCLeg   /* Dialog Cb that matches at
                              least matches local tag  */
)
#else
PRIVATE SoCLegCb * soCoreFindDlgWithTags (callCb, request, rcvdLocalAddr, rcvdRemoteAddr,
                                  rcvdLocalTag, rcvdRemoteTag)
SoCallCb   *callCb;        /* Entity Cb                */
SoEvnt     *request;       /* Request Event            */
SoAddress  *rcvdLocalAddr; /* Local address received   */
SoAddress  *rcvdRemoteAddr;/* Remote address received  */
TknStrOSXL *rcvdLocalTag;  /* Local tag received       */
TknStrOSXL *rcvdRemoteTag; /* Remote tag received      */
SoCLegCb   **partialCLeg;  /* Dialog Cb that matches at
                              least matches local tag  */
#endif
{
  CmLList     *llEnt;      /* Used to traverse link list */
  TknStrOSXL  *localTag;   /* Dialog's Local tag         */
  TknStrOSXL  *remoteTag;  /* Dialog's Remote tag        */
  SoCLegCb    *cLegCb;     /* Call leg pointer returned  */

  Bool        isPeer2543;  /* Is peer compliant to 2543  */
  TknStrOSXL  *normLocalAddr; /* Normalized local address in call leg  */
  TknStrOSXL  *normRemoteAddr;/* Normalized remote address in call leg */
  TknStrOSXL  normRcvdLocalAddr; /* Normalized Local address received  */
  TknStrOSXL  normRcvdRemoteAddr;/* Normalized Remote address received */

  TRC3 (soCoreFindDlgWithTags);

  /*----------------- Initialize Local Variables --------------------*/
   isPeer2543 = FALSE;
   llEnt      = NULLP;
   cLegCb     = NULLP;
   remoteTag  = NULLP;
   localTag   = NULLP;
  /* so023.201 Initialize the partially matched call leg */
   *partialCLeg = NULLP;
   cmMemset ((U8 *)&normRcvdLocalAddr , 0, sizeof (TknStrOSXL));
   cmMemset ((U8 *)&normRcvdRemoteAddr, 0, sizeof (TknStrOSXL));

  /*
   * If remote tag is absent, it implies peer is compliant to 2543 dra-
   * ft. In this case match "to" and "from" header as well.
   */
   if (rcvdRemoteTag == NULLP)
   {
      isPeer2543 = TRUE;
     
      /*---- Convert "to" header to string format for comparison ----*/
      if (soUtlStoreNormAddr (rcvdLocalAddr, &normRcvdLocalAddr) != ROK)
        RETVALUE (NULLP);
      
      /*--- Convert "From" header to string format for comparison ---*/
      if (soUtlStoreNormAddr (rcvdRemoteAddr, &normRcvdRemoteAddr) != ROK)
      {
        SOFREE (normRcvdLocalAddr.val , normRcvdLocalAddr.len);
        RETVALUE (NULLP);
      }
   }

  /*-------- Search Call Leg Link List for matching call leg --------*/
   for (cLegCb = (SoCLegCb *)CM_LLIST_FIRST_NODE (&callCb->cLegLst, llEnt);
        cLegCb;
        cLegCb = (SoCLegCb *)CM_LLIST_NEXT_NODE (&callCb->cLegLst, llEnt))
   {
        remoteTag      = &cLegCb->storedHdrs.remoteTag;
        localTag       = &cLegCb->storedHdrs.localTag;
        normRemoteAddr = &cLegCb->storedHdrs.normRemoteAddr;
        normLocalAddr  = &cLegCb->storedHdrs.normLocalAddr;
      
       /*-- Match with local/remote address present in call leg cb --*/
       
       /* so023.201 Match with the local tag to find the partial match */ 
        if (isPeer2543)
        {
           if (!(SO_CMP_TKNSTR (normRemoteAddr, &normRcvdRemoteAddr)) ||
               !(SO_CMP_TKNSTR (normLocalAddr , &normRcvdLocalAddr)))
             continue;
        }

       /* so023.201 Match with the remote tag to find the complete match */ 
        if ((rcvdLocalTag) && !(SO_CMP_TKNSTR (localTag , rcvdLocalTag)))
             continue;

        (*partialCLeg) = cLegCb;

       /*---- Match with local/remote tag present in the call leg ---*/
        if ((rcvdRemoteTag) && !(SO_CMP_TKNSTR (remoteTag, rcvdRemoteTag)))
             continue;

       /* weigy: here need check clegState */
        if (cLegCb->clegState == SO_CLEG_STATE_TERMINATED)
             continue;

       /*------------ Found Matching Dialog For Message -------------*/

       /*-- so022.201 : To correct the debug Level to Informational -*/ 
        SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
           "\n[Dialog] Found Dialog For Request:"
           " Call(%ld), CallLeg(%lx), State(%d)",
           cLegCb->call->spConnId, cLegCb->legId, cLegCb->clegState));

        break;
        
   } /* For (each dialog in call) */

   if (isPeer2543)
   {
     SOFREE (normRcvdLocalAddr.val , normRcvdLocalAddr.len);
     SOFREE (normRcvdRemoteAddr.val, normRcvdRemoteAddr.len);
   }

   RETVALUE (cLegCb);

} /* End of fn soCoreFindDlgWithTags () */


/*
*
*       Fun:   soCoreGetAddrAndTags
*
*       Desc:  This function extracts local/remote tags and address from
*              given SIP message.
*
*       RET :  ROK, if success.
*              RFAILED, if faliure.
*
*       Notes: 
*
*       File:  so_core.c
*
*/
#ifdef ANSI
PUBLIC S16 soCoreGetAddrAndTags
(
SoEvnt     *evnt,      /* SIP Message                */
SoAddress  **localAddr, /* Local address in message   */
SoAddress  **remoteAddr,/* Remote address in message  */
TknStrOSXL **localTag,  /* Local tag in message       */
TknStrOSXL **remoteTag  /* Remote tag in message      */
)
#else
PUBLIC S16 soCoreGetAddrAndTags (evnt, localAddr, remoteAddr,
                                  localTag, remoteTag)
SoEvnt     *evnt,      /* SIP Message                */
SoAddress  **localAddr, /* Local address in message   */
SoAddress  **remoteAddr,/* Remote address in message  */
TknStrOSXL **localTag,  /* Local tag in message       */
TknStrOSXL **remoteTag  /* Remote tag in message      */
#endif
{
  TRC3 (soCoreGetAddrAndTags);

  /* 
   * For  SIP  Request  message, "to" header represents "local" address
   * and "from" header represents "remote" address.
   */
   if (SO_CMP_TKN_LIT (&evnt->sipMessageType, SO_SIPMESSAGE_REQUEST))
   {
     (Void) soCmFindHdrChoice (evnt, (U8 **) localAddr , SO_HEADER_GEN_TO);
     (Void) soCmFindHdrChoice (evnt, (U8 **) remoteAddr, SO_HEADER_GEN_FROM);
   }
  /* 
   * For  SIP Response message, "to" header represents "remote" address
   * and "from" header represents "local" address.
   */
   else
   {
     (Void) soCmFindHdrChoice (evnt, (U8 **) localAddr , SO_HEADER_GEN_FROM);
     (Void) soCmFindHdrChoice (evnt, (U8 **) remoteAddr, SO_HEADER_GEN_TO);
   }

   if (!(*localAddr) || !(*remoteAddr))
     RETVALUE (RFAILED);

  /*---------- Extract tags from local and remote address -----------*/
   (Void) soUtlExtractTag ((*localAddr) , localTag);
   (Void) soUtlExtractTag ((*remoteAddr), remoteTag);

   RETVALUE (ROK);

} /* End of fn soCoreGetAddrAndTags () */


/*
*
*       Fun:   soCoreFindCancelDlg
*
*       Desc:  This function  match CANCEL request without localTag to
*              an existing dialog.
*              CANCEL without localTag will match dialog that was cre-
*              ated by request having same CSEQ, requestURI and remote
*              Tag as present in this CANCEL request.
*
*       RET :  cLegCb, if success.
*              NULLP,  if not found.
*
*       Notes: 
*
*       File:  so_core.c
*
*/
#ifdef ANSI
PRIVATE SoCLegCb * soCoreFindCancelDlg
(
SoCallCb   *callCb,        /* Entity Cb                */
SoEvnt     *request,       /* Request Event            */
SoAddress  *rcvdLocalAddr, /* Local address received   */
SoAddress  *rcvdRemoteAddr,/* Remote address received  */
TknStrOSXL *rcvdRemoteTag  /* Remote tag received      */
)
#else
PRIVATE SoCLegCb * soCoreFindCancelDlg (callCb, request, rcvdLocalAddr, rcvdRemoteAddr,
                                rcvdRemoteTag)
SoCallCb   *callCb;        /* Entity Cb                */
SoEvnt     *request;       /* Request Event            */
SoAddress  *rcvdLocalAddr; /* Local address received   */
SoAddress  *rcvdRemoteAddr;/* Remote address received  */
TknStrOSXL *rcvdRemoteTag; /* Remote tag received      */
#endif
{  
  S16         ret;         /* return value of function   */
  CmLList     *llEnt;      /* Used to traverse link list */
  TknStrOSXL  *localTag;   /* Dialog's Local tag         */
  TknStrOSXL  *remoteTag;  /* Dialog's Remote tag        */
  SoCLegCb    *cLegCb;     /* Call leg pointer returned  */
  SoCSeq      *rxCSeq;     /* CSeq received in CANCEL    */

  Bool        isPeer2543;  /* Is peer compliant to 2543  */
  TknStrOSXL  *normLocalAddr; /* Normalized local address in call leg  */
  TknStrOSXL  *normRemoteAddr;/* Normalized remote address in call leg */
  TknStrOSXL  normRcvdLocalAddr; /* Normalized Local address received  */
  TknStrOSXL  normRcvdRemoteAddr;/* Normalized Remote address received */

  TRC3 (soCoreFindCancelDlg);

  /*----------------- Initialize Local Variables --------------------*/
   isPeer2543 = FALSE;
   llEnt      = NULLP;
   cLegCb     = NULLP;
   remoteTag  = NULLP;
   localTag   = NULLP;
   cmMemset ((U8 *)&normRcvdLocalAddr , 0, sizeof (TknStrOSXL));
   cmMemset ((U8 *)&normRcvdRemoteAddr, 0, sizeof (TknStrOSXL));

  /*----------------- Get CSEQ received in CANCEL -------------------*/
   soCmFindHdrChoice (request, (U8 **) &rxCSeq, SO_HEADER_GEN_CSEQ);
   if (!rxCSeq)
      RETVALUE (NULLP);

  /*
   * If remote tag is absent, it implies peer is compliant to 2543 dra-
   * ft. In this case match "to" and "from" header as well.
   */
   if (rcvdRemoteTag == NULLP)
   {
      isPeer2543 = TRUE;
     
      /*---- Convert "to" header to string format for comparison ----*/
      if (soUtlStoreNormAddr (rcvdLocalAddr, &normRcvdLocalAddr) != ROK)
        RETVALUE (NULLP);
      
      /*--- Convert "From" header to string format for comparison ---*/
      if (soUtlStoreNormAddr (rcvdRemoteAddr, &normRcvdRemoteAddr) != ROK)
      {
        SOFREE (normRcvdLocalAddr.val , normRcvdLocalAddr.len);
        RETVALUE (NULLP);
      }
   }

  /*-------- Search Call Leg Link List for matching call leg --------*/
   for (cLegCb = (SoCLegCb *)CM_LLIST_FIRST_NODE (&callCb->cLegLst, llEnt);
        cLegCb;
        cLegCb = (SoCLegCb *)CM_LLIST_NEXT_NODE (&callCb->cLegLst, llEnt))
   {
        remoteTag      = &cLegCb->storedHdrs.remoteTag;
        localTag       = &cLegCb->storedHdrs.localTag;
        normRemoteAddr = &cLegCb->storedHdrs.normRemoteAddr;
        normLocalAddr  = &cLegCb->storedHdrs.normLocalAddr;
      
       /*-- Match with local/remote address present in call leg cb --*/
        if (isPeer2543)
        {
           if (!(SO_CMP_TKNSTR (normRemoteAddr, &normRcvdRemoteAddr)) ||
               !(SO_CMP_TKNSTR (normLocalAddr , &normRcvdLocalAddr)))
             continue;
        }
       /*------- Match with remote tag present in the call leg ------*/
        else if (!(SO_CMP_TKNSTR (remoteTag, rcvdRemoteTag)))
             continue;
        
       /*- Match CSeq in CANCEL with dialog creating request's CSEQ -*/
        if (rxCSeq->cSeqVal.val != cLegCb->storedHdrs.dlgCreateCSeq)
             continue;
        
       /* 
        * Match requestURI  in  CANCEL  with  dialog creating request's
        * requestURI
        */
        ret = soUtlCmpSoAddrSpec (&cLegCb->storedHdrs.origReqURI,
                                  &request->t.request.requestLine.addrSpec);
        if (ret != ROK)
             continue;

       /*------- Found the Call Leg Matcing CANCEL Request ----------*/

        SODBGP_SO (SO_DBGMASK_DLG, (soCb.init.prntBuf, 
           "\n[Dialog] Found Dialog For CANCEL Request: "
           "Call(%ld), CallLeg(%lx), State(%d)",
           cLegCb->call->spConnId, cLegCb->legId, cLegCb->clegState));

        break;

   } /* For (each dialog in call) */

   if (isPeer2543)
   {
     SOFREE (normRcvdLocalAddr.val , normRcvdLocalAddr.len);
     SOFREE (normRcvdRemoteAddr.val, normRcvdRemoteAddr.len);
   }

   RETVALUE (cLegCb);

} /* End of fn soCoreFindCancelDlg () */

/*-- End of functions to match request/response to dialog --*/



/*
*
*       Fun:   soCoreCreateCallCb
*
*       Desc:  This function creates anew call control Block
*
*       Notes: 
*
*       File:  po_core.c
*
*/
#ifdef ANSI
PUBLIC  SoCallCb *soCoreCreateCallCb
(
SoSSapCb *ssap,        /* SSAP cb */
SoEntCb  *ent,         /* Entity Control Block */
UConnId  suConnId,     /* Service User Conn Id */
SoEvnt   *evnt,        /* Message */
U8       direction     /* Request from user/ from remote */
)
#else
PUBLIC  SoCallCb *soCoreCreateCallCb(ssap, ent, suConnId, evnt, direction)
SoSSapCb *ssap;       /* SSAP cb */
SoEntCb  *ent;        /* Entity Control Block */
UConnId  suConnId;    /* Service User Conn Id */
SoEvnt   *evnt;       /* Message */
U8       direction;   /* Request from user/ from remote */
#endif
{
   SoCallCb   *callCb;     /* Call Cb */
   S16        ret;         /* Return Value */

   TRC3(soCoreCreateCallCb);

   /* Check for message type before creating the call */
   if ((evnt->eventType.val != SOT_ET_INVITE) &&
       (evnt->eventType.val != SOT_ET_REGISTER) &&
       (evnt->eventType.val != SOT_ET_MESSAGE) &&
       (evnt->eventType.val != SOT_ET_UNKNOWN) &&
       (evnt->eventType.val != SOT_ET_SUBSCRIBE) &&
       (evnt->eventType.val != SOT_ET_REFER) &&
       (evnt->eventType.val != SOT_ET_OPTIONS) &&
       (evnt->eventType.val != SOT_ET_UPDATE) &&
       /* so009.201 : To support INFO outside a call */
       (evnt->eventType.val != SOT_ET_INFO) &&
       (evnt->eventType.val != SOT_ET_NOTIFY))
     RETVALUE(NULLP);

   /* Check if there is enough resource to set up the call */
   ret = soUtlChkRes(evnt, direction);
   if (ret != ROK)
     RETVALUE(NULLP);

   /* Allocate memory for tranCb */
   SOALLOC(&callCb, sizeof(SoCallCb));
   
   if (callCb == NULLP)
     RETVALUE(NULLP);

   ret = soCoreInitCallCb(ssap, ent, suConnId, evnt, callCb, direction);

   if (ret != ROK)
   {
     SOFREE(callCb, sizeof(SoCallCb));
     RETVALUE(NULLP);
   }

   /* Add into list of calls on entity */
   ret = cmHashListInsert(&ent->callIdLst, (PTR) (callCb),
                          (U8 *) callCb->callId.val,
                          (U16)  callCb->callId.len);
   if (ret != ROK)
   {
     SOFREE(callCb, sizeof(SoCallCb));
     RETVALUE(NULLP);
   }

   ret = cmHashListInsert(&ent->spConnIdLst, (PTR) (callCb), 
                          (U8 *) &callCb->spConnId, (U16)sizeof(UConnId));
   if  (ret != ROK)
   {
      cmHashListDelete(&ent->callIdLst, (PTR) callCb);
      SOFREE(callCb, sizeof(SoCallCb));
      RETVALUE(NULLP);
   }

#ifdef SO_REL_1_2_INF
   if ((direction != SO_REMOTE) && (callCb->suConnId != SO_CONNID_NOTUSED)) 
   { 
      ret = cmHashListInsert(&ent->suConnIdLst, (PTR) (callCb), 
                          (U8 *) &callCb->suConnId, (U16)sizeof(UConnId));
      if  (ret != ROK)
      {
         cmHashListDelete(&ent->callIdLst, (PTR) callCb);
         cmHashListDelete(&ent->spConnIdLst, (PTR) callCb);
         SOFREE(callCb, sizeof(SoCallCb));
         RETVALUE(NULLP);
      }
   }
#endif /* SO_REL_1_2_INF */

   SODBGP_SO (SO_DBGMASK_CORE, (soCb.init.prntBuf, 
         "\n[CORE  ] CALL   Created => Call (%ld)\n",
         callCb->spConnId));

   RETVALUE(callCb);
} /* soCoreCreateCallCb */



/*
*
*       Fun:   soCoreLocateCallCb
*
*       Desc:  This function locates a call control block from the list 
*              in the entity control block.
*
*       Notes: 
*
*       File:  po_core.c
*
*/
/* so032.201: Passing even type to locate Call Cb */
#ifdef ANSI
PUBLIC  SoCallCb *soCoreLocateCallCb
(
SoEntCb     *ent,         /* Entity Control Block */
UConnId     suConnId,     /* Service User Conn Id */
UConnId     spConnId,     /* Service Provider Conn Id */
TknStrOSXL  *callId,      /* Call Id */
U8          eventType     /* Type of SIP Message */
)
#else
PUBLIC  SoCallCb *soCoreLocateCallCb(ent, suConnId, spConnId, callId)
SoEntCb     *ent;         /* Entity Control Block */
UConnId     suConnId;     /* Service User Conn Id */
UConnId     spConnId;     /* Service Provider Conn Id */
TknStrOSXL  *callId;      /* Call Id */
U8          eventType;    /* Type of SIP Message */
#endif
{
   SoCallCb *callCb;

   TRC3(soCoreLocateCallCb);
 
   callCb = NULLP;

   /* Use SP ConnId if present. */
   if (spConnId != SO_CONNID_NOTUSED)
   {
     cmHashListFind(&ent->spConnIdLst, (U8 *) &spConnId, sizeof(UConnId),
                    0, (PTR *) &callCb);
   }
   else if (suConnId != SO_CONNID_NOTUSED)
   {
#ifndef SO_REL_1_2_INF
   /* so032.201: Do not find callCb based on suConnId for Invite, as suConnId
    * will alyways be invalid in case of initial Invite
    */
   if (eventType != SOT_ET_INVITE)
   {
      SoCallCb  *tmpCallCb;
      tmpCallCb = NULLP;
      while (cmHashListGetNext(&ent->spConnIdLst, (PTR) tmpCallCb,
                              (PTR *) &tmpCallCb) == ROK)
      {
           if (tmpCallCb->suConnId == suConnId)
           {
             callCb = tmpCallCb;
             break;
           }
      }
    }
    /* so032.201: Find callCb based on callId for Invite messages, this is 
     * required when sending out Invite after receiving 407 type response,
     * where call-id is same as the original Invite.
     */
    else if ((callId != NULLP) && (callId->pres != NOTPRSNT))
    {
       cmHashListFind(&ent->callIdLst, (U8 *)callId->val, 
                    (U16) callId->len, (U16) 0, (PTR *) &callCb);
    }
#else
      /* Use suConnId if one is provided */
      cmHashListFind(&ent->suConnIdLst, (U8 *) &suConnId, sizeof(UConnId),
                     0, (PTR *) &callCb);
#endif
   }
   /* Use callId if present */
   else if ((callId != NULLP) && (callId->pres != NOTPRSNT))
   {
     cmHashListFind(&ent->callIdLst, (U8 *)callId->val, 
                    (U16) callId->len, (U16) 0, (PTR *) &callCb);
   }


   /* Update the suConnId , if required */
   if ((callCb != NULLP) && (callCb->suConnId == SO_CONNID_NOTUSED) &&
       (suConnId != SO_CONNID_NOTUSED))
   {
      callCb->suConnId = suConnId;
#ifdef SO_REL_1_2_INF
      if (cmHashListInsert(&ent->suConnIdLst, (PTR) (callCb), 
                          (U8 *) &callCb->suConnId, 
                          (U16)sizeof(UConnId)) != ROK)
      {
         RETVALUE(NULLP);
      }
#endif /* SO_REL_1_2_INF */
   }


   RETVALUE(callCb);

} /* soCoreLocateCallCb */



/*
*
*       Fun:   soCoreChkAndDelCall
*
*       Desc:  Deletes call if no call leg is present
*
*       Notes: 
*
*       File:  po_core.c
*
*/
#ifdef ANSI
PUBLIC Void soCoreChkAndDelCall
(
SoCallCb *callCb   /* Call control Block to be deleted */
)
#else
PUBLIC Void soCoreChkAndDelCall(callCb)
SoCallCb *callCb;  /* Call control Block to be deleted */
#endif
{

  /* so025.201 : If session created by register, check regCLeg before */
  /* deleting callCb */
  U16 result;

  TRC2(soCoreChkAndDelCall);
  if (callCb->sessCreatedBy != SOT_ET_REGISTER)
  {
     if (cmLListLen(&callCb->cLegLst) == 0)
        soCoreDeleteCallCb(callCb);
  }
  else
  {
     cmHashListQuery(&callCb->regCLegLst, CM_HASH_QUERYTYPE_ENTRIES, &result);
     if (result == 0)
        soCoreDeleteCallCb(callCb);
     else
        SODBGP_SO (SO_DBGMASK_CORE, (soCb.init.prntBuf, "\n[CORE  ] CALL not deleted"));

  }
  RETVOID;
/* so025.201 */
} /* soCoreChkAndDelCall */


/*
*
*       Fun:   soCoreDeleteCallCb
*
*       Desc:  This function Deletes a call cb.
*
*       Notes: 
*
*       File:  po_core.c
*
*/
#ifdef ANSI
PUBLIC Void soCoreDeleteCallCb
(
SoCallCb *callCb   /* Call control Block to be deleted */
)
#else
PUBLIC Void soCoreDeleteCallCb(callCb)
SoCallCb *callCb;  /* Call control Block to be deleted */
#endif
{
  SoEntCb  *ent;     /* Entity associated with the call */
  CmLList  *curNode; /* Current node in list            */
  PTR      curItem;  /* Current item                    */
  SoCLegCb *cLegCb;  /* Temp Call Leg control block     */


  TRC2(soCoreDeleteCallCb);

  ent = NULLP;

   SODBGP_SO (SO_DBGMASK_CORE, (soCb.init.prntBuf, 
         "\n[CORE  ] CALL   Deleted => Call (%ld)\n",
         callCb->spConnId));

  ent= callCb->ent;
  
  if (ent != NULLP)
  {
    cmHashListDelete(&ent->callIdLst, (PTR) callCb);
    cmHashListDelete(&ent->spConnIdLst, (PTR) callCb);
#ifdef SO_REL_1_2_INF
    cmHashListDelete(&ent->suConnIdLst, (PTR) callCb);
#endif
  }

  /* Destroy all call legs in call */
  curNode = cmLListFirst(&callCb->cLegLst);
   while (curNode != NULLP)
   {
      curItem  = cmLListNode(curNode);
      curNode  = curNode->next;
      cLegCb   = (SoCLegCb *)curItem;
      soDlgDeleteCleg(callCb,cLegCb);
   }

   /* Delete All registration related call legs */
   while (cmHashListGetNext(&callCb->regCLegLst, (PTR) NULLP,
                            (PTR *) &cLegCb) == ROK)
   {
     soDlgDeleteCleg(callCb,cLegCb);
   }

   /* Deallocate call Id  */
   soUtlDelTknStrOSXL(&callCb->callId);

   cmHashListDeinit (&callCb->regCLegLst);

   /* Deallocate callCb */
   SOFREE(callCb, sizeof(SoCallCb));

   RETVOID;
}



/*
*
*       Fun:   soCoreCreateCallCtxt
*
*       Desc:  This function creates a call & call leg.
*
*       Notes: 
*
*       File:  po_core.c
*
*/
#ifdef ANSI
PUBLIC Void soCoreCreateCallCtxt
(
SoSSapCb  *ssap,      /* SSAP Cb */
SoEntCb   *ent,       /* Entity CB */
SoEvnt    *evnt,       /* Event cb */
UConnId   suConnId,   /* Sevice User ConnId */
U8        direction,  /* Direction SO_USER/SO_REMOTE */
SoCallCb  **callCb,   /* Call Cb */
SoCLegCb  **cLeg      /* Call Leg Cb */
)
#else
PUBLIC Void soCoreCreateCallCtxt(ssap, ent, evnt, suConnId, 
                                 direction, callCb, cLeg)
SoSSapCb  *ssap;      /* SSAP Cb */
SoEntCb   *ent;       /* Entity CB */
SoEvnt    *evnt;       /* Event cb */
UConnId   suConnId;   /* Sevice User ConnId */
U8        direction;  /* Direction SO_USER/SO_REMOTE */
SoCallCb  **callCb;   /* Call Cb */
SoCLegCb  **cLeg;     /* Call Leg Cb */
#endif
{
  
  if (*callCb == NULLP)
  {
    *callCb = soCoreCreateCallCb(ssap, ent, suConnId, evnt, direction);

      if (*callCb == NULLP)
        RETVOID;
  }


  *cLeg = soDlgCreateCleg(*callCb, evnt, direction);
  if (*cLeg == NULLP)
  {
    soCoreDeleteCallCb(*callCb);
    RETVOID;
  }

  /* so022.201 : Save user connection identifier in call leg */
  if (direction == SO_USER)
    (*cLeg)->userConnId = suConnId;

  RETVOID;
}






/*
*
*       Fun:   soCoreLocateSuCallCtxt
*
*       Desc:  This function locates a call control block and cleg 
*              control block for a message received form the Service
*              user.
*
*       Notes: 
*
*       File:  po_core.c
*
*/
#ifdef ANSI
PUBLIC Void soCoreLocateSuCallCtxt
(
SoSSapCb    *ssap,        /* SSAP Cb */
SoEvnt      *evnt,         /* Event   */
UConnId     suConnId,     /* Service User Connection Id */
UConnId     spConnId,     /* Service Provider Connection Id */
SoCallCb    **call,       /* Call Cb */
SoCLegCb    **cLeg        /* Call Leg Cb */
)
#else
PUBLIC Void soCoreLocateSuCallCtxt(ssap, evnt, suConnId, spConnId, call, cLeg)
SoSSapCb    *ssap;        /* SSAP Cb */
SoEvnt      *evnt;         /* Event   */
UConnId     suConnId;     /* Service User Connection Id */
UConnId     spConnId;     /* Service Provider Connection Id */
SoCallCb    **call;       /* Call Cb */
SoCLegCb    **cLeg;       /* Call Leg Cb */
#endif
{
  TknStrOSXL *callId; /* Pointer to where CallId must be placed */

  TRC3(soCoreLocateSuCallCtxt);

  *call = NULLP;
  *cLeg = NULLP;

   soCmFindHdrChoice(evnt, (U8 **) &callId, 
                     SO_HEADER_GEN_CALLID);

  *call = soCoreLocateCallCb(ssap->sys, suConnId, spConnId, callId, evnt->eventType.val);
   if (*call == NULLP)
     RETVOID;

  *cLeg = soDlgFindCLegFromSu(*call, evnt->callLegId);

  /* so009.201 : Update the User Connection Id (suConnId) in call leg
     if not already done */
  if (((*cLeg) != NULLP) && ((*cLeg)->userConnId == SO_CONNID_NOTUSED) &&
       (suConnId != SO_CONNID_NOTUSED))
  {
     (*cLeg)->userConnId = suConnId;

  }

  RETVOID;
  
} /* soCoreLocateSuCallCtxt */




/***************************************************************/
/*                     Support Functions                       */
/***************************************************************/


/*
*
*       Fun:   soCoreInitSessCreatedBy
*
*       Desc:  This function locates a call control block from the list 
*              in the entity control block.
*
*       Notes: 
*
*       File:  po_core.c
*
*/
#ifdef ANSI
PRIVATE  Void soCoreInitSessCreatedBy
(
SoCallCb  *callCb,    /* Call Control Block */
SoEvnt    *evnt       /* Message Event */
)
#else
PRIVATE Void soCoreInitSessCreatedBy(callCb, evnt)
SoCallCb  *callCb;    /* Call Control Block */
SoEvnt    *evnt;      /* Message Event */
#endif
{

   TRC3(soCoreInitSessCreatedBy);

   callCb->sessCreatedBy = SO_CALL_CREATEDBY_NONE;

   /* Set the type of session */
   switch(evnt->eventType.val)
   {
      case SOT_ET_INVITE:
      case SOT_ET_REGISTER:
      case SOT_ET_UNKNOWN: /* so035.201: Added for unknown event to update sess Created By */
#ifdef  SO_REFER
      case SOT_ET_REFER:
#endif
#ifdef SO_EVENT
      case SOT_ET_SUBSCRIBE:
      case SOT_ET_NOTIFY:
#endif /* SO_EVENT */
      /* so029.201: Added Options outside dialog*/   
      case SOT_ET_OPTIONS:
         callCb->sessCreatedBy = evnt->eventType.val;
         break;
   }

  RETVOID;
} /* soCoreInitSessCreatedBy */





/*
*
*       Fun:   soCoreInitCallCb
*
*       Desc:  This function initializes a new call cb
*
*       Notes: 
*
*       File:  po_core.c
*
*/
#ifdef ANSI
PRIVATE S16 soCoreInitCallCb
(
SoSSapCb *ssap,        /* SSAP cb */
SoEntCb  *ent,        /* Entity Control Block */
UConnId  suConnId,    /* Service User Conn Id */
SoEvnt   *evnt,       /* Message */
SoCallCb *callCb,     /* New Call Control Block */   
U8       direction     /* Request from user/ from remote */
)
#else
PRIVATE S16 soCoreInitCallCb(ssap, ent, suConnId, evnt, callCb, direction)
SoSSapCb *ssap;        /* SSAP cb */
SoEntCb  *ent;        /* Entity Control Block */
UConnId  suConnId;    /* Service User Conn Id */
SoEvnt   *evnt;       /* Message */
SoCallCb *callCb;     /* New Call Control Block */
U8       direction;   /* Request from user/ from remote */
#endif
{
  S16        ret = ROK;        /* Return Value */
  TknStrOSXL *callId = NULLP;    /* Pointer to where CallId must be placed */


  cmMemset((U8 *)callCb, 0, sizeof(SoCallCb));
 
  callCb->ssapCb = ssap;
  callCb->ent = ent;
  callCb->suConnId = suConnId;

  /* Initialize all call leg lists */
  cmLListInit(&callCb->cLegLst);

  /* The Registartion call leg list allows duplicates */
  /* so039.201: get result of cmHashListInit into ret*/
  ret = cmHashListInit(&callCb->regCLegLst, callCb->ent->s.ua.cfg.regAddrHlBins, 
                 (U16) SO_OFFSET_OF(SoCLegCb, regHlEnt),
                 TRUE, CM_HASH_KEYTYPE_STR,
                 soCb.init.region, soCb.init.pool);
  /* so038.201: Added error check condition */
  if (ret != ROK)
    RETVALUE(ret);

                 
  /* Generate a new spConnId for the call */
  ret = soUtlGenSpConnId(callCb);
  if (ret != ROK)
    RETVALUE(RFAILED);

  /* Initialize the session created by flag */
  soCoreInitSessCreatedBy(callCb, evnt);

  soCmFindHdrChoice(evnt, (U8 **) &callId, SO_HEADER_GEN_CALLID);
  
  /* If the event doesnot contain a callId and if message is from user,
     generate a new one */
  if (callId == NULLP)
  {
    if (direction == SO_USER)
    {      
      if (soUtlGenCallId(&callCb->callId) != ROK)
        RETVALUE(RFAILED);
    }
    else
      RETVALUE(RFAILED);
  }
  else
  {
    /* Copy callId */
    if (soUtlCpyTknStrOSXL(&callCb->callId, callId, NULLP) != ROK)
    {
      RETVALUE(RFAILED);
    }
  }

  
  RETVALUE(ROK);
    
} /* soCoreInitCallCb */

#endif /* SO_UA */
/********************************************************************30**

         End of file:     so_core.c@@/main/4 - Tue Apr 20 12:46:07 2004

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---      pk          1. Initial Release
/main/4+   so008.201  up          1. Variable addition
/main/4+   so009.201  pk          1. Changes to support INFO outside a call.
                                  2. Changes to support addition of 
                                     suConnId in Call Leg
/main/4+   so017.201  ps          1. New functions for dialog matching pro-
                                     cedure.
/main/4+   so018.201  ps          1. Save remote tag in  cLeg  for  failure
                                     final responses as well.
/main/4+   so022.201  ps          1. Save user connection identifier in 
                                     call leg
/main/4+              ad          1. To correct the debug Level to Informational
                      ab          2. Start from the end of the list for matching
                                     dialogs.
/main/4+   so023.201  sg          1. Support partial call leg matching 
                                     when processing incoming Notify request
                                     dialogs.
/main/4+   so024.201  ss          1. The dialog for register msg in case UA 
                                     is accepting registration
/main/4+   so025.201  ss          1. Changed deletion of callId in case of 
                                     Registration timeout
/main/4+   so029.201  ss          1. Updated sessCreatedBy for OPTIONS also
/main/4+   so032.201  ng          1. Pass event type to locate call cb. This
                                     is required as for Invite, search should
                                     not be done based on suConnId(ab)
                      ng          2. Support for outside Dialog Notifications   
/main/4+   so033.201  ng          1. Added extra check of CSeq for dialog (ss)
                                     matching

 /main/4+  so034.201  ng           1. If remote tag is not present in cleg 
                                     (NOTIFY is recd before 200), update remote tag 
                                     with  rcvd NOTIFY 'To' tag 

  /main/4+  so035.201  ng          1 Added for unknown event to update sess Created By
  /main/4+  so038.201  ng          1. Added error check condition
  /main/4+  so039.201  ng          1. Get result of cmHashListInit into ret 
  /main/4+  so041.201  ng          1. Fix for a condition, where Instant message
                                      arriveing with the same call-id and no "local tag".
*********************************************************************91*/

