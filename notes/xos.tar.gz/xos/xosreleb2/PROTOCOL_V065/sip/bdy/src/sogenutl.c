/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SIP Utility functions

     Type:    C source file

     Desc:    C source code for SIP Utility functions

     File:    sogenutl.c

     Sid:      sogenutl.c@@/main/2 - Tue Apr 20 12:47:42 2004

     Prg:     pk

*********************************************************************21*/



/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "so.h"            /* SIP layer defines               */
#include "so_trans.h"      /* Transaction module defines      */
#include "so_err.h"        /* SIP error defines               */
#include "so_cm.h"         /* SIP layer utility functions     */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_sdpdb.x"      /* SDP abnf definitions            */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lso.x"           /* Layer management SIP            */
#include "sot.x"           /* SOT interface defines           */
#include "so_tcm.x"        /* Transport module structures     */
#include "so.x"            /* SIP layer structures            */
#include "so_trans.x"      /* Transaction module structures   */
#include "so_utl.x"        /* SIP layer utility functions     */
#include "so_cm.x"         /* SIP layer common functions      */


/*******************************************************************
*
*       Fun:   soUtlAddrWithCfgServer
*
*       Notes: The function is used to compare  the address
*              against all configured servers. 
*
*       Ret:   serverCb on success.
*              NULLP on error.
*
*       File:  so_utl.c
*
*******************************************************************/

#ifdef ANSI
PUBLIC SoTptServerCb *soUtlAddrWithCfgServer
(
SoEntCb       *entCb,     /* Entity Control Block   */
SoHostPort    *hostPort,  /* hostPort addr          */
U8            protVal     /* Protocol Name value    */
)
#else
PUBLIC SoTptServerCb *soUtlAddrWithCfgServer (entCb, hostPort, protVal)
SoEntCb       *entCb;    /* Entity Control Block   */
SoHostPort    *hostPort; /* hostPort addr          */
U8            protVal;   /* Protocol Name value    */
#endif
{
   S16            ret;
   U16            i = 0;
   SoTptServerCb  *serverCb;
   SoTptServerCb  *tempServerCb;
   SoHostPort     serverHostPort;

   TRC2 (soUtlAddrWithCfgServer);

   /* Initialize the serverCb to NULL */
   serverCb = NULLP;

   while (i < soCb.maxTptSrv)
   {
      tempServerCb = soCb.allSrvCbLst[i];

      if ((tempServerCb == NULLP)                      ||
         /* Server does belongs not to entity  */
          (tempServerCb->entCb != entCb)               ||
         /*      Server is not enabled         */
          (tempServerCb->state != LSO_TPTSRV_ENA)      ||
         /*      Ignore multicast server       */
          (SO_TCM_SERVER_MCAST (tempServerCb) == TRUE) || 
         /* Server protocol must match         */
          ((protVal == LSO_TPTPROT_UDP) && !(SO_TCM_UDP_TRANSPORT (tempServerCb->tptProt)))  ||
          ((protVal == LSO_TPTPROT_TCP) && !(SO_TCM_TCP_TRANSPORT (tempServerCb->tptProt)))  ||
          ((protVal == LSO_TPTPROT_TLS_TCP) && !(SO_TCM_TLS_TRANSPORT (tempServerCb->tptProt))))
      {
         /*-- This server is no match. Check next one ---*/
         i++;
         continue;
      }                                                                        

     /*
      * Now compare address (hostPort) of server connection
      * with that present in the address.
      */
      cmMemset ((U8 *)(&serverHostPort), 0, sizeof (SoHostPort));

      ret = soCmTptAddrToHostPort (&serverHostPort,
                                   &tempServerCb->localAddr,
                                   (SoEvnt *)NULLP);
      if (ret != ROK)
         RETVALUE (NULLP);

      ret = soCmCompareHostPort (&serverHostPort, hostPort);
      if (ret != ROK)
      {
         /*-- This server is no match. Check next one ---*/
         i++;
         (Void) soUtlDelSoHostPort (&serverHostPort);
         continue;
      }                                                                        

      /* 
       * Found the matching server connection and thus the
       * VIA field is also verified.
       */
      serverCb = tempServerCb;
      (Void) soUtlDelSoHostPort (&serverHostPort);
      break;
                                                                        
   } /* End of while (each server connection) */

   RETVALUE(serverCb);
}

/*
*
*       Fun:   soUtlGenCallId
*
*       Desc:  This function generates a new callId
*
*       Notes: 
*
*       File:  so_utl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlGenCallId
(
TknStrOSXL *callId        /* Pointer to where CallId must be placed */
)
#else
PUBLIC S16 soUtlGenCallId(callId)
TknStrOSXL *callId;       /* Pointer to where CallId must be placed */
#endif 
{
   U8               curTime[12]; /* 64 bit time stamp                 */
   S16              ret;         /* value returned by function calls  */
   SoTptServerCb    *tptSrv;     /* transport server                  */
   U16              idx;
  
   /* Pick the first tpt Srv to use for callId */
   for(idx = 0; idx < soCb.maxTptSrv; idx++)
   {
      tptSrv = soCb.allSrvCbLst[idx];
      if(tptSrv != NULLP && tptSrv->entCb != NULLP)
         break;
   }
   if(tptSrv == NULLP)
      RETVALUE(RFAILED);

   /* Initialize callId to be not present in case of error return */
   callId->pres = NOTPRSNT;

   ret = soCmGetCurTime(curTime);
   if (ret != ROK)
      RETVALUE(RFAILED);
 

   /* Fill up the running sequence number */
   curTime[8]   = GetHiByte(GetHiWord(soCb.seqNum));
   curTime[9]   = GetLoByte(GetHiWord(soCb.seqNum));
   curTime[10]  = GetHiByte(GetLoWord(soCb.seqNum));
   curTime[11]  = GetLoByte(GetLoWord(soCb.seqNum));

   /* 12*2 - time value in hex + 1 - for "@" */
   callId->len = (U16)(25 + tptSrv->hostName.len);


   SOALLOC(&callId->val, callId->len);
   if (callId->val == NULLP)
      RETVALUE(RFAILED);

   (Void) soCmFillHex((Txt *)callId->val, (U8 *)&curTime, 12);

   callId->val[24] = '@';

   cmMemcpy((U8 *) &(callId->val[25]),(U8 *)tptSrv->hostName.val, 
            tptSrv->hostName.len);

   callId->pres = PRSNT_NODEF;

   /* Increment the random number to ensure uniqueness */
   soCb.seqNum++;

   RETVALUE(ROK);
} /* soUtlGenCallId */

/*
*
*       Fun:    soUtlCpyGetLstPtr
*
*       Desc:   Copies the pointer list
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   sogenutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpyGetLstPtr
(
Ptr         *dstLstPtr,
U16         structPtrSize,
TknU16      *numComp,
CmMemListCp *cpyMemCp
)
#else
PUBLIC S16 soUtlCpyGetLstPtr(dstLstPtr, structPtrSize, numComp, cpyMemCp)
Ptr         *dstLstPtr;
U16         structPtrSize;
TknU16      *numComp;
CmMemListCp *cpyMemCp;
#endif
{
   TRC2(soUtlCpyGetLstPtr);

   if (numComp->val > 0 && numComp->pres != NOTPRSNT)
   {
      soUtlCpyGetMem(dstLstPtr, (U16)(structPtrSize * numComp->val), cpyMemCp);
   }
   else
   {
      dstLstPtr = NULLP;
   }

   RETVALUE(ROK);
} /* soUtlCpyGetLstPtr */

/*------ so017.201: Function to compare CSeq -------*/

/*
*
*       Fun:   soUtlCmpCSeq
*
*       Desc:  This function compares two CSEQ headers.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  so_cm.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlCmpCSeq
(
SoCSeq  *cSeq1,   /* CSeq Header  */
SoCSeq  *cSeq2    /* CSeq Header  */
)
#else
PUBLIC S16 soUtlCmpCSeq (cSeq1, cSeq2)
SoCSeq  *cSeq1;   /* CSeq Header  */
SoCSeq  *cSeq2;   /* CSeq Header  */
#endif
{
   TRC2(soUtlCmpCSeq);

   if (cSeq1->pres.pres != cSeq2->pres.pres)
      RETVALUE (RFAILED);
   
   if (cSeq1->pres.pres == NOTPRSNT)
      RETVALUE (ROK);

  /*----------- Match CSeq Value --------------*/

   if (cSeq1->cSeqVal.pres != cSeq2->cSeqVal.pres)
      RETVALUE (RFAILED);
   
   if ((cSeq1->cSeqVal.pres == PRSNT_NODEF) &&
       (cSeq1->cSeqVal.val  != cSeq2->cSeqVal.val))
      RETVALUE (RFAILED);
   
  /*---------- Match CSeq Method --------------*/

   if (cSeq1->method.type.pres != cSeq2->method.type.pres)
      RETVALUE (RFAILED);
   
   if (cSeq1->method.type.pres == NOTPRSNT)
      RETVALUE (ROK);

   if (cSeq1->method.type.val  != cSeq2->method.type.val)
      RETVALUE (RFAILED);
   
   if (cSeq1->method.type.val  == SO_METHOD_METHODSTD)
   {
       if (cSeq1->method.t.std.pres  != cSeq2->method.t.std.pres)
          RETVALUE (RFAILED);
       
       if ((cSeq1->method.t.std.pres == PRSNT_NODEF) &&
           (cSeq1->method.t.std.val  != cSeq2->method.t.std.val))
          RETVALUE (RFAILED);
   }
   else if (cSeq1->method.type.val   == SO_METHOD_EXTENSIONMETHOD)
   {
       if (cSeq1->method.t.ext.pres  != cSeq2->method.t.ext.pres)
          RETVALUE (RFAILED);
       
       if (cSeq1->method.t.ext.pres  == PRSNT_NODEF)
       { 
         if (cSeq1->method.t.ext.len != cSeq2->method.t.ext.len)
            RETVALUE (RFAILED);
         
         if (cSeq1->method.t.ext.len != 0)
         {
            if (cmMemcmp (cSeq1->method.t.ext.val,
                          cSeq2->method.t.ext.val,
                          cSeq1->method.t.ext.len) != 0)
               RETVALUE (RFAILED);
         }
       }
   }

   RETVALUE (ROK);

} /* end of soUtlCmpCSeq */




/*****************************************************************************
*
*      Fun:   soUtlCmpSoAddress
*
*      Desc:  Compares SoAddress
*
*      Ret:   ROK if headers are the same else RFAILED
*
*      Notes: None
*
*      File:  
*
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 soUtlCmpSoAddress
(
SoAddress       *addr1,   /* Address */
SoAddress       *addr2    /* Address 2 */
)
#else
PUBLIC S16 soUtlCmpSoAddress(addr1, addr2)
SoAddress       *addr1;   /* Address */
SoAddress       *addr2;   /* Address 2 */
#endif
{
   SoAddrSpec   *tmpAddr;       /* Address spec part */
   U16          keyLength1;     /* Length of cache key */
   U8           *keyBuffer1;    /*Temporary buffer for key */
   U16          keyLength2;     /* Length of cache key */
   U8           *keyBuffer2;    /*Temporary buffer for key */
   S16          ret;            /* Return value */

   TRC2(soUtlCmpSoAddress)

   SO_ADDRSPEC_FROM_ADDRCH(tmpAddr, &addr1->addrCh);

   if (soUtlCalcAddrKey(tmpAddr, &keyBuffer1, &keyLength1) != ROK)
   {
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
         "soUtlCmpSoAddress: Normalize To header failed\n"));
      RETVALUE(RFAILED);
   }

   SO_ADDRSPEC_FROM_ADDRCH(tmpAddr, &addr2->addrCh);
   if (soUtlCalcAddrKey(tmpAddr,&keyBuffer2, &keyLength2) != ROK)
   {
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
         "soUtlCmpSoAddress: Normalize From header failed\n"));
      RETVALUE(RFAILED);
   }

   if (keyLength1 == keyLength2)
   {
      ret = cmMemcmp((U8 *)keyBuffer1, (U8 *)keyBuffer2, keyLength1);
      
      /* release locally allocated buffers */
      SOFREE(keyBuffer1, keyLength1);
      SOFREE(keyBuffer2, keyLength2);

      if (ret == ROK)
      {
         RETVALUE(ROK);
      }
      else
         RETVALUE(RFAILED);
   }
   else
   {
     /* release locally allocated buffers */
      SOFREE(keyBuffer1, keyLength1);
      SOFREE(keyBuffer2, keyLength2);

      RETVALUE(RFAILED);
   }
} /* end of soUtlCmpSoAddress */


/*
*
*       Fun:   soUtlCmpSoAddrSpec
*
*       Desc:  This function compares two addrSpec.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  sogenutl.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlCmpSoAddrSpec
(
SoAddrSpec *addrSpec1,       /* first  address Spec */
SoAddrSpec *addrSpec2        /* second address Spec */
)
#else
PUBLIC S16 soUtlCmpSoAddrSpec(addrSpec1, addrSpec2)
SoAddrSpec *addrSpec1;       /* first  address Spec */
SoAddrSpec *addrSpec2;       /* second address Spec */
#endif
{
   U8    *addrSpecStr1;
   U8    *addrSpecStr2;
   U16   addrSpecLen1;
   U16   addrSpecLen2;
   S16   ret;

   TRC2(soUtlCmpSoAddrSpec);

   if ((addrSpec1 == NULLP) || (addrSpec2 == NULLP))
      RETVALUE (RFAILED);

   /* Get length of addrSpec 1 */
   ret = soCmNormAddr ((U8 *)NULLP, addrSpec1, &addrSpecLen1);
   if (ret != ROK)
      RETVALUE (RFAILED);

   /* Get length of addrSpec 2 */
   ret = soCmNormAddr ((U8 *)NULLP, addrSpec2, &addrSpecLen2);
   if (ret != ROK)
      RETVALUE (RFAILED);

   if (addrSpecLen1 != addrSpecLen2)
      /* Normalized lengths not equal - addrSpec's are not equivalent */
      RETVALUE (RFAILED);

   /* Allocate memory for addrSpec1 in string format */
   SOALLOC (&addrSpecStr1, addrSpecLen1 + 1);
   if (addrSpecStr1 == NULLP)
      RETVALUE (RFAILED);

   /* Normalize addrSpec1 */
   ret = soCmNormAddr (addrSpecStr1, addrSpec1, &addrSpecLen1);
   if (ret != ROK)
   {
      SOFREE (addrSpecStr1, addrSpecLen1 + 1);
      RETVALUE (RFAILED);
   }
   /* Add null terminator */
   addrSpecStr1[addrSpecLen1] = 0;

   /* Allocate memory for addrSpec2 in string format */
   SOALLOC (&addrSpecStr2, addrSpecLen2 + 1);
   if (addrSpecStr2 == NULLP)
   {
      SOFREE (addrSpecStr1, addrSpecLen1 + 1);
      RETVALUE (RFAILED);
   }

   /* Normalize addrSpec2 */
   ret = soCmNormAddr (addrSpecStr2, addrSpec2, &addrSpecLen2);
   if (ret != ROK)
   {
      SOFREE (addrSpecStr1, addrSpecLen1 + 1);
      SOFREE (addrSpecStr2, addrSpecLen2 + 1);
      RETVALUE (RFAILED);
   }
   /* Add null terminator */
   addrSpecStr2[addrSpecLen2] = 0;

   if (cmStrncmp (addrSpecStr1, addrSpecStr2, addrSpecLen1) == 0)
      ret = ROK;
   else
      ret = RFAILED;

   /* Free memory */
   SOFREE (addrSpecStr1, addrSpecLen1 + 1);
   SOFREE (addrSpecStr2, addrSpecLen2 + 1);

   RETVALUE (ret);

} /* end of soUtlCmpSoAddrSpec */



/*
*
*       Fun:    soUtlCpySoAddressNoAlloc
*
*       Desc:   Copies the SoAddress struct
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_utl.c
*
*/
/* 
 * so006.102: New function to copy SoAddress structure, where the source 
 *            is an element of control block. In this case  we may  save 
 *            few allocation for new Address structure.
 */
#ifdef ANSI
PUBLIC S16 soUtlCpySoAddressNoAlloc
(
SoAddress   *dstSoAddrCh,
SoAddress   *srcSoAddrCh,
CmMemListCp *cpyMemCp
)
#else
PUBLIC S16 soUtlCpySoAddressNoAlloc(dstSoAddrCh, srcSoAddrCh, cpyMemCp)
SoAddress   *dstSoAddrCh;
SoAddress   *srcSoAddrCh;
CmMemListCp *cpyMemCp;
#endif
{
   S16         i;
   SoUrlParameters *srcUrl, *dstUrl;
   SoHeaderExt     *srcName, *dstName;

   srcName = NULLP;
   dstName = NULLP;
   srcUrl  = NULLP;
   dstUrl  = NULLP;

   TRC2(soUtlCpySoAddressNoAlloc);

   if (srcSoAddrCh->pres.pres == NOTPRSNT)
      RETVALUE(ROK);

   cmMemcpy((U8 *)dstSoAddrCh, (U8 *)srcSoAddrCh, sizeof(SoAddress));

   if (srcSoAddrCh->addrCh.addrChType.pres != NOTPRSNT)
   {
    if (srcSoAddrCh->addrCh.addrChType.val == SO_ADDRCH_NAMEADDR)
    {
       if ((srcSoAddrCh->addrCh.t.nameAddr.pres.pres != NOTPRSNT) &&
           (srcSoAddrCh->addrCh.t.nameAddr.displayName.displayNameType.pres != NOTPRSNT) &&
           (srcSoAddrCh->addrCh.t.nameAddr.displayName.displayNameType.val == SO_PARAMVAL_TOKEN) &&
           (srcSoAddrCh->addrCh.t.nameAddr.displayName.t.displayNameRep.numComp.pres != NOTPRSNT))
       {

        if (soUtlCpyGetLstPtr(
                    (Ptr *)&dstSoAddrCh->addrCh.t.nameAddr.displayName.t.displayNameRep.stringList, sizeof(TknStrOSXL *),
                    &srcSoAddrCh->addrCh.t.nameAddr.displayName.t.displayNameRep.numComp, cpyMemCp) != ROK)
            RETVALUE(RFAILED);

        for (i = 0; i < srcSoAddrCh->addrCh.t.nameAddr.displayName.t.displayNameRep.numComp.val; i++)
        {
          dstSoAddrCh->addrCh.t.nameAddr.displayName.t.displayNameRep.stringList[i] = srcSoAddrCh->addrCh.t.nameAddr.displayName.t.displayNameRep.stringList[i];
        }

       }

       /* Find The Url and Name memory */
       if ((srcSoAddrCh->addrCh.t.nameAddr.pres.pres != NOTPRSNT) &&
           (srcSoAddrCh->addrCh.t.nameAddr.addrSpec.addrSpecType.pres != NOTPRSNT))
       {
           /* Sip Url */
           if ((srcSoAddrCh->addrCh.t.nameAddr.addrSpec.addrSpecType.val == SO_ADDRSPEC_SIPURL) 

               )
           {

             if (srcSoAddrCh->addrCh.t.nameAddr.addrSpec.t.sipUrl.pres.pres != NOTPRSNT) 
             {
                  
               srcUrl = &srcSoAddrCh->addrCh.t.nameAddr.addrSpec.t.sipUrl.urlParameters;
               dstUrl = &dstSoAddrCh->addrCh.t.nameAddr.addrSpec.t.sipUrl.urlParameters;

               
               if (srcSoAddrCh->addrCh.t.nameAddr.addrSpec.t.sipUrl.headers.pres.pres != NOTPRSNT)
               {
                srcName = &srcSoAddrCh->addrCh.t.nameAddr.addrSpec.t.sipUrl.headers.headerExt;
                dstName = &dstSoAddrCh->addrCh.t.nameAddr.addrSpec.t.sipUrl.headers.headerExt;
               }
             }

           }
       }
    }


    if (srcSoAddrCh->addrCh.addrChType.val == SO_ADDRCH_ADDRSPEC)
    {
       /* Find The Url and Name memory */
       if (srcSoAddrCh->addrCh.t.addrSpec.addrSpecType.pres != NOTPRSNT)
       {
           /* Sip Url */
           if ((srcSoAddrCh->addrCh.t.addrSpec.addrSpecType.val == SO_ADDRSPEC_SIPURL) 

)
           {

             if (srcSoAddrCh->addrCh.t.addrSpec.t.sipUrl.pres.pres != NOTPRSNT) 
             {
                  
               srcUrl = &srcSoAddrCh->addrCh.t.addrSpec.t.sipUrl.urlParameters;
               dstUrl = &dstSoAddrCh->addrCh.t.addrSpec.t.sipUrl.urlParameters;

               
               if (srcSoAddrCh->addrCh.t.addrSpec.t.sipUrl.headers.pres.pres != NOTPRSNT)
               {
                srcName = &srcSoAddrCh->addrCh.t.addrSpec.t.sipUrl.headers.headerExt;
                dstName = &dstSoAddrCh->addrCh.t.addrSpec.t.sipUrl.headers.headerExt;
               }
             }

           }
       }

    }
   }

   if (srcUrl && srcUrl->numComp.pres != NOTPRSNT)
   {
      if (soUtlCpyGetLstPtr((Ptr *)&dstUrl->urlParameter, sizeof(SoUrlParameter *),
                         &srcUrl->numComp, cpyMemCp) != ROK)
         RETVALUE(RFAILED);

      for (i = 0; i < srcUrl->numComp.val; i++)
        dstUrl->urlParameter[i] = srcUrl->urlParameter[i];
   }
 
   if (srcName && srcName->numComp.pres != NOTPRSNT)
   {
      if (soUtlCpyGetLstPtr((Ptr *)&dstName->header, sizeof(SoNameVal *),
                         &srcName->numComp, cpyMemCp) != ROK)
         RETVALUE(RFAILED);

      for (i = 0; i < srcName->numComp.val; i++)
        dstName->header[i] = srcName->header[i];
   }
 

   if (srcSoAddrCh->addrParams.numComp.pres != NOTPRSNT)
   {
      if (soUtlCpyGetLstPtr((Ptr *)&dstSoAddrCh->addrParams.addrParam, 
                         sizeof(SoAddrParam *),
                         &srcSoAddrCh->addrParams.numComp, cpyMemCp) != ROK)
         RETVALUE(RFAILED);

      for (i = 0; i < srcSoAddrCh->addrParams.numComp.val; i++)
         dstSoAddrCh->addrParams.addrParam[i] = srcSoAddrCh->addrParams.addrParam[i];
   }

    RETVALUE(ROK);

} /* soUtlCpySoAddressNoAlloc */


/*
*
*       Fun:   soUtlStoreNormAddr
*
*       Desc:  This function stores the normalized version of an address.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  sogenutl.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlStoreNormAddr
(
SoAddress   *addr,       /* address to store                                  */
TknStrOSXL  *norm        /* token string in which to store normalized version */
)
#else
PUBLIC S16 soUtlStoreNormAddr(addr, norm)
SoAddress   *addr;       /* address to store                                  */
TknStrOSXL  *norm;       /* token string in which to store normalized version */
#endif
{
   TRC2(soUtlStoreNormAddr);

   /* Check to see if norm is already present */
   if (norm->pres == PRSNT_NODEF)
   {
      /* Already present - no need to store it */
      RETVALUE(ROK);
   }

   /* Get norm length 1 */
   if (soCmNormAddress((U8 *)NULLP, addr, &norm->len, FALSE) != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* Allocate memory for norm->val */
   SOALLOC(&norm->val, norm->len);

   if (norm->val == NULLP)
     RETVALUE(RFAILED);

   /* Set present flag */
   norm->pres = PRSNT_NODEF;

   /* Normalize address */
   if (soCmNormAddress(norm->val, addr, &norm->len, FALSE) != ROK)
   {
      SOFREE(norm->val, norm->len);
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of soUtlStoreNormAddr */


/*****************************************************************************
*
*       Fun  : soUtlCmpTknStrOSXL
*
*       Desc : Compares Open strings
*
*       Ret  : TRUE, strings are equal
*              FALSE, not equal
*
*       Notes: Case insensitive comparison possible if specified
*
*
*       File:  so_cm.c
*
*****************************************************************************/
#ifdef ANSI
PUBLIC Bool soUtlCmpTknStrOSXL
(
TknStrOSXL *str1,             /* String to compare                    */
TknStrOSXL *str2,             /* String to compare to                 */
Bool       caseSensitive      /* FALSE -> case insensitive comparison */
)
#else
PUBLIC Bool soUtlCmpTknStrOSXL(str1, str2, caseSensitive)
TknStrOSXL *str1;             /* String to compare                    */
TknStrOSXL *str2;             /* String to compare to                 */
Bool       caseSensitive;     /* FALSE -> case insensitive comparison */
#endif
{
   U32      i;    /* Counter */
   TRC2(soUtlCmpTknStrOSXL)

   if(str1->len != str2->len)
      RETVALUE (FALSE);
   if (caseSensitive == FALSE)
   {
      if(cmMemcmp((U8 *)str1->val,(U8 *)str2->val,(sizeof(U8)*str1->len)) == 0)
         RETVALUE(TRUE);
      RETVALUE(FALSE);
   }
   /* Case insensitive comparison */
   for (i=0; i < str1->len; i++)
   {
      if (SO_LOWERCASE(str1->val[i]) != SO_LOWERCASE(str2->val[i]))
      {
         RETVALUE(FALSE);
      }
   }
   /* Match in all characters */
   RETVALUE(TRUE);

}/* soUtlCmpTknStrOSXL */


/*
*
*       Fun:   soUtlCmpTknStrOSXLCi
*
*       Desc:  Case-insensitive comparison of TknStrOSXL with literal.
*
*       Ret:   ROK        match
*              RFAILED    no match
*
*       Notes:
*
*       File:  sogenutl.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlCmpTknStrOSXLCi
(
TknStrOSXL    *tknStr,    /* Value to compare */
U8            *str,       /* literal string   */
U16           len         /* compare length   */
)
#else
PUBLIC S16 soUtlCmpTknStrOSXLCi(tknStr, str, len)
TknStrOSXL    *tknStr;    /* Value to compare */
U8            *str;       /* literal string   */
U16           len;        /* compare length   */
#endif
{
   U16 i;  /* counter */

   TRC2(soUtlCmpTknStrOSXLCi);

   if (tknStr == NULLP)
   {
      /* No match */
      RETVALUE(RFAILED);
   }

   if (tknStr->pres == NOTPRSNT)
   {
      RETVALUE(RFAILED);
   }

   if (tknStr->len < len)
   {
      RETVALUE(RFAILED);
   }

   for (i = 0; i < len; i++)
   {
      if (SO_LOWERCASE(tknStr->val[i]) != SO_LOWERCASE(str[i]))
      {
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);
} /* soUtlCmpTknStrOSXLCi */


/*
*
*       Fun:    soUtlCmpAddrInContact
*
*       Desc:   Compares the addrSpec in the SoContactItem struct
*
*       Ret:    ROK     - the addresses are same
*               RFAILED - the addresses are not same
*               ROKDNA  - the new contact does not have an address
*               RIGNORE - an error happened during comparison because 
*                         of the newContactItem
*
*       Notes:  None
*
*       File:   
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCmpAddrInContact
(
SoContactItem *newContact,       /* new contact item */
SoContactItem *oldContact        /* old contact item */
)
#else
PUBLIC S16 soUtlCmpAddrInContact(newContact, oldContact)
SoContactItem *newContact;       /* new contact item */
SoContactItem *oldContact;       /* old contact item */
#endif
{
   U8         *newKey;           
   U8         *oldKey;
   U16        newKeyLen;
   U16        oldKeyLen;
   SoAddrSpec *newAddrSpec;
   SoAddrSpec *oldAddrSpec;
   S16        ret;

   TRC2(soUtlCmpAddrInContact);

   /* check for present */
   if ((newContact->pres.pres != PRSNT_NODEF) || 
       (newContact->contactAddrChoice.addrChType.pres != PRSNT_NODEF))
      RETVALUE(ROKDNA);

   if ((oldContact->pres.pres != PRSNT_NODEF) || 
       (oldContact->contactAddrChoice.addrChType.pres != PRSNT_NODEF))
      RETVALUE(RFAILED);

   /* get addrSpec */
   if (newContact->contactAddrChoice.addrChType.val == SO_ADDRCH_ADDRSPEC)
      newAddrSpec = &newContact->contactAddrChoice.t.addrSpec;
   else
      newAddrSpec = &newContact->contactAddrChoice.t.nameAddr.addrSpec;

   if (oldContact->contactAddrChoice.addrChType.val == SO_ADDRCH_ADDRSPEC)
      oldAddrSpec = &oldContact->contactAddrChoice.t.addrSpec;
   else
      oldAddrSpec = &oldContact->contactAddrChoice.t.nameAddr.addrSpec;

   /* get normalized key length */
   if ( (ret = soCmNormAddr(NULLP, newAddrSpec, &newKeyLen)) != ROK)
      RETVALUE(RIGNORE);
   if ( (ret = soCmNormAddr(NULLP, oldAddrSpec, &oldKeyLen)) != ROK)
      RETVALUE(RFAILED);

   /* compare key length */
   if (newKeyLen != oldKeyLen)
      RETVALUE(RFAILED);

   /* get normalized keys */
   SOALLOC(&newKey, newKeyLen);

   if (newKey == NULLP)
      RETVALUE(RFAILED);

   if ( (ret = soCmNormAddr(newKey, newAddrSpec, &newKeyLen)) != ROK)
      RETVALUE(RIGNORE);

   SOALLOC(&oldKey, oldKeyLen);
   if (oldKey == NULLP)
      RETVALUE(RFAILED);

   if ( (ret = soCmNormAddr(oldKey, oldAddrSpec, &oldKeyLen)) != ROK)
      RETVALUE(RFAILED);

   /* compare key */
   ret = cmMemcmp(newKey, oldKey, newKeyLen);
   if (ret != 0)
      ret = RFAILED;
   else
      ret = ROK;

   /* clean */
   SOFREE(newKey, newKeyLen);
   SOFREE(oldKey, oldKeyLen);

   RETVALUE(ret);
} /* end of soUtlCmpAddrInContact */

/*
*
*       Fun:    soUtlExtractTag
*
*       Desc:   Extract Tag parameter from soAddress
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   sogenutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlExtractTag
(
 SoAddress   *addr,   /* Address  */
 TknStrOSXL  **tag     /* Tag to be returned */
)
#else
PUBLIC S16 soUtlExtractTag(addr, tag)
SoAddress   *addr;   /* Address  */
TknStrOSXL  **tag;     /* Tag to be returned */
#endif
{
   U16      i;        /* Index */

   TRC3(soUtlExtractTag);

   *tag = NULLP;

   for (i = 0; i < SO_GET_NUM_COMP(&addr->addrParams.numComp); i++)
   {
     /* Check to see if it is a tag */
     if (SO_CMP_TKN_LIT(&addr->addrParams.addrParam[i]->addrParamType,
                        SO_ADDRPARAM_TAGPARAM) == TRUE)
     {
        *tag = &addr->addrParams.addrParam[i]->t.tagParam;
        break;
     }
   }

   if (*tag == NULLP)
     RETVALUE(RFAILED);

   RETVALUE(ROK);

} /* soUtlExtractTag */


#ifdef SO_UA

/*
*
*       Fun:   soUtlBuildRspEvnt
*
*       Desc:  Creates response message based on incoming message
*
*       Ret:   ROK/RFAILED
*
*       Notes: This function identifies the method of the oldMsg
*              and routes oldMsg and sipMsg to the correct function to build
*              the response.
*
*       File:  
*
*/

#ifdef ANSI
PUBLIC S16 soUtlBuildRspEvnt
(
SoEntCb  *ent,          /* Entity Cb                           */
SoEvnt   **rspEvnt,     /* Response Evnt                       */
SoEvnt   *reqEvnt,      /* Request Evnt                        */
/* so011.201: Adding parameter request event type */
U8       reqEventType,  /* Request event type */
U16      statusCode,    /* Response code to put into messasge  */
U16      extStatusCode  /* Extended status                     */
)
#else
PUBLIC S16 soUtlBuildRspEvnt(ent, rspEvnt, reqEvnt, statusCode, extStatusCode)
SoEntCb  *ent;          /* Entity Cb                           */
SoEvnt   **rspEvnt;     /* Response Evnt                       */
SoEvnt   *reqEvnt;      /* Request Evnt                        */
/* so011.201: Adding parameter request event type */
U8       reqEventType,  /* Request event type */
U16      statusCode;    /* Response code to put into messasge  */
U16      extStatusCode; /* Extended status                     */
#endif
{
   S16         ret;          /* value returned by function calls */
   SoEvnt      *newEvnt;      /* New Evenet */
   U8          eventType;   /* Event Type */

   TRC2(soUtlBuildRspEvnt);

   ret = ROK;
   
   if (reqEvnt != NULLP)
     eventType = reqEvnt->eventType.val;
   else
   /* so011.201: Adding parameter request event type */
     eventType = reqEventType;

   /* Create the event structure */
   if (soCmCreateEvent(rspEvnt, eventType) != ROK)
   {
      RETVALUE(RFAILED);
   }

   newEvnt = *rspEvnt;

   if (reqEvnt != NULLP)
   {
     /* Copy Basic event related parameters */
     newEvnt->transId = reqEvnt->transId;
     newEvnt->callLegId = reqEvnt->callLegId;
     newEvnt->srcTranCb = reqEvnt->srcTranCb;
     newEvnt->dstTranCb = reqEvnt->dstTranCb;
#ifdef SO_REPLACES
     newEvnt->rplcSuConId = reqEvnt->rplcSuConId;
     newEvnt->rplcSpConId = reqEvnt->rplcSpConId;
     newEvnt->rplcCLegId = reqEvnt->rplcCLegId;
#endif /* SO_REPLACES */
   }


   /* Construct status line */
   SO_FILL_TKNU8(&newEvnt->sipMessageType, SO_SIPMESSAGE_RESPONSE);

   SO_FILL_TKNSTROSXL(&newEvnt->t.response.statusLine.
                      sipVersion, soCb.cfg.protVer,
                      cmStrlen((U8 *)soCb.cfg.protVer), newEvnt, ret);
   if (ret != ROK)
      RETVALUE(RFAILED);

   newEvnt->t.response.pres.pres            = PRSNT_NODEF;
   newEvnt->t.response.statusLine.pres.pres = PRSNT_NODEF;

   ret = soCmGetSIPCodes(statusCode, extStatusCode,
                         &newEvnt->t.response.statusLine,
                         newEvnt);
   if (ret != ROK)
   {
     (Void) soCmFreeEvent(newEvnt);
     *rspEvnt = NULLP;
      SODBGP_SO(SO_DBGMASK_ERR, (soCb.init.prntBuf,
                 "soPrcResponseBuild: Response code not found.\n"));
      RETVALUE(ret);
   }


   if (statusCode == SOT_RSP_420_BAD_EXTENSION)
   {
     ret = soUtlAddUnsuppHdr(ent, reqEvnt, newEvnt);
     /* so038.201: Added error check condition */
     if (ret != ROK)
     {
        (Void) soCmFreeEvent(newEvnt);
        *rspEvnt = NULLP;
        SODBGP_SO(SO_DBGMASK_ERR, (soCb.init.prntBuf,
                 "soUtlAddUnsuppHdr: Failed to Add Unsupported Header.\n"));
        RETVALUE(ret);
     }

   }

#ifdef SO_SESSTIMER
   if (statusCode == SOT_RSP_422_SESSTIMER_TOO_SMALL)
   {
     ret = soUtlAddMinSeHdr(ent, newEvnt);
     /* so038.201: Added error check condition */
     if (ret != ROK)
     {
        (Void) soCmFreeEvent(newEvnt);
        *rspEvnt = NULLP;
        SODBGP_SO(SO_DBGMASK_ERR, (soCb.init.prntBuf,
                 "soUtlAddMinSeHdr: Failed to Add MinSe Header.\n"));
        RETVALUE(ret);
     }

   }
#endif /* SO_SESSTIMER */

   RETVALUE(ret);
} /* end of soUtlBuildRspEvnt */


/*
*
*       Fun:   soUtlBuildErrRsp
*
*       Desc:  Creates response message based on incoming message
*
*       Ret:   ROK/RFAILED
*
*       Notes: 
*
*       File:  
*
*/

#ifdef ANSI
PUBLIC S16 soUtlBuildErrRsp
(
SoEvnt   **rspEvnt,     /* Response Evnt                       */
SoEvnt   *reqEvnt,      /* Request Evnt                        */
U16      statusCode,    /* Response code to put into messasge  */
U16      extStatusCode  /* Extended status                     */
)
#else
PUBLIC S16 soUtlBuildErrRsp(rspEvnt, reqEvnt, statusCode, extStatusCode)
SoEvnt   **rspEvnt;     /* Response Evnt                       */
SoEvnt   *reqEvnt;      /* Request Evnt                        */
U16      statusCode;    /* Response code to put into messasge  */
U16      extStatusCode; /* Extended status                     */
#endif
{
   S16         ret;          /* value returned by function calls */
   SoEvnt      *newEvnt;      /* New Evenet */
   TknStrOSXL *callId, *rxCallId;
   SoCSeq     *cSeq,   *rxcSeq;
   SoVia      *via,    *rxVia;
   SoAddress  *from, *to, *rxTo, *rxFrom;
   /* so007.201 : Addition */
   U16        numHdr;     /* Total Headers*/
   SoHeader   *hdr;       /* Header to check */
   S16        cnt; 

   TRC2(soUtlBuildErrRsp);

   ret = ROK;

   /* Create the event structure */
   if (soCmCreateEvent(rspEvnt, reqEvnt->eventType.val) != ROK)
   {
      RETVALUE(RFAILED);
   }

   newEvnt = *rspEvnt;

   /* Construct status line */
   SO_FILL_TKNU8(&newEvnt->sipMessageType, SO_SIPMESSAGE_RESPONSE);

   SO_FILL_TKNSTROSXL(&newEvnt->t.response.statusLine.
         sipVersion, soCb.cfg.protVer,
         cmStrlen((U8 *)soCb.cfg.protVer), reqEvnt, ret);
   if (ret != ROK)
   {
      (Void) soCmFreeEvent(newEvnt);
      RETVALUE(RFAILED);
   }

   newEvnt->t.response.pres.pres            = PRSNT_NODEF;
   newEvnt->t.response.statusLine.pres.pres = PRSNT_NODEF;

   ret = soCmGetSIPCodes(statusCode, extStatusCode,
         &newEvnt->t.response.statusLine,
         newEvnt);
   if (ret != ROK)
   {
      (Void) soCmFreeEvent(newEvnt);
      *rspEvnt = NULLP;
      SODBGP_SO(SO_DBGMASK_CORE, (soCb.init.prntBuf,
               "soPrcResponseBuild: Response code not found.\n"));
      RETVALUE(ret);
   }

   /* Get all the parameters from the request event */
   SO_GET_CALLID_FROM_EVENT (reqEvnt, rxCallId);
   SO_GET_TOHDR_FROM_EVENT  (reqEvnt,  rxTo);
   SO_GET_FROMHDR_FROM_EVENT(reqEvnt, rxFrom);
   SO_GET_CSEQ_FROM_EVENT   (reqEvnt, rxcSeq);

   /*-- Fill CALL Identifier header in response --*/
   ret = soCmCreateHdrChoice (newEvnt, (U8 **) &callId, SO_HEADER_GEN_CALLID);
   if (ret != ROK)
   {
      /* so039.201: Free event in case of error */
      (Void) soCmFreeEvent(newEvnt);
      RETVALUE(RFAILED);
   }

   ret = soUtlCpyTknStrOSXL (callId, rxCallId, &newEvnt->memCp);
   if (ret != ROK)
   {
      /* so039.201: Free event in case of error */
      (Void) soCmFreeEvent(newEvnt);
      RETVALUE(RFAILED);
   }

   /*---- Fill CSeq header in response message ---*/
   ret = soCmCreateHdrChoice (newEvnt, (U8 **) &cSeq, SO_HEADER_GEN_CSEQ);
   if (ret != ROK)
   {
      /* so039.201: Free event in case of error */
      (Void) soCmFreeEvent(newEvnt);
      RETVALUE(RFAILED);
   }

   ret = soUtlCpySoCSeq (cSeq, rxcSeq, &newEvnt->memCp);
   if (ret != ROK)
   {
      /* so039.201: Free event in case of error */
      (Void) soCmFreeEvent(newEvnt);
      RETVALUE(RFAILED);
   }

   /*--- Fill "From" header in response message --*/
   ret = soCmCreateHdrChoice (newEvnt, (U8 **) &from, SO_HEADER_GEN_FROM);
   if (ret != ROK)
   {
      /* so039.201: Free event in case of error */
      (Void) soCmFreeEvent(newEvnt);
      RETVALUE(RFAILED);
   }

   ret = soUtlCpySoAddress (from, rxFrom, &newEvnt->memCp);
   if (ret != ROK)
   {
      /* so039.201: Free event in case of error */
      (Void) soCmFreeEvent(newEvnt);
      RETVALUE(RFAILED);
   }

   /*---- Fill "To" header in response message ---*/
   ret = soCmCreateHdrChoice (newEvnt, (U8 **) &to, SO_HEADER_GEN_TO);
   if (ret != ROK)
   {
      /* so039.201: Free event in case of error */
      (Void) soCmFreeEvent(newEvnt);
      RETVALUE(RFAILED);
   }

   ret = soUtlCpySoAddress (to, rxTo, &newEvnt->memCp);
   if (ret != ROK)
   {
      /* so039.201: Free event in case of error */
      (Void) soCmFreeEvent(newEvnt);
      RETVALUE(RFAILED);
   }

   /* so007.201: Copy Via excatly as it appears in the incoming message */
   /*--- Fill "Via" header in response message ---*/
   numHdr = SO_GET_NUM_COMP(&reqEvnt->t.request.request.numComp);

   for (cnt = 0; cnt < numHdr; cnt++)
   {
      hdr = reqEvnt->t.request.request.header[cnt];
      if (SO_CMP_TKN_LIT(&hdr->headerType, SO_HEADER_GEN_VIA) == TRUE)
      {
         rxVia = &hdr->t.via;

         /*--- Fill "Via" header in response message ---*/
         ret = soCmCreateHdrChoice (newEvnt, (U8 **) &via, SO_HEADER_GEN_VIA);
         if (ret != ROK)
            RETVALUE(RFAILED);

         ret = soUtlCpySoVia (via, rxVia, &newEvnt->memCp);
         if (ret != ROK)
         {
            /* so039.201: Free event in case of error */
            (Void) soCmFreeEvent(newEvnt);
            RETVALUE(RFAILED);
         }
      }
   }

   RETVALUE(ret);
} /* end of soUtlBuildErrRsp */

#endif /* SO_UA */



/*
*
*       Fun:   soUtlUpdOutReqSts
*
*       Desc:  Records statistics for outgoing requests
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  po_ua.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlUpdOutReqSts
(
SoEntCb   *ent,      /* entityCb */
U16       evntType   /* Event Type */
)
#else
PUBLIC S16 soUtlUpdOutReqSts(ent, evntType)
SoEntCb   *ent;      /* entityCb */
U16       evntType;  /* Event Type */
#endif
{
   /* local variables */
   TRC2(soUtlUpdOutReqSts);


   /* entity statistics */
   ent->summSts.sumOutReq++;

   /* general statistics */
   soCb.sts.summSts.sumOutReq++;

   switch (evntType)
   {
     case SOT_ET_INVITE:
       /* entity statistics */
       ent->methSts.methOutInv++;

       /* general statistics */
       soCb.sts.methSts.methOutInv++;
       break;

     case SOT_ET_ACK:
       /* entity statistics */
       ent->methSts.methOutAck++;

       /* general statistics */
       soCb.sts.methSts.methOutAck++;
       break;

     case SOT_ET_INFO:
       /* entity statistics */
       ent->methSts.methOutInfo++;

       /* general statistics */
       soCb.sts.methSts.methOutInfo++;
       break;

     case SOT_ET_PRACK:
       /* entity statistics */
       ent->methSts.methOutPrack++;

       /* general statistics */
       soCb.sts.methSts.methOutPrack++;
       break;

     case SOT_ET_OPTIONS:
       /* entity statistics */
       ent->methSts.methOutOpt++;

       /* general statistics */
       soCb.sts.methSts.methOutOpt++;
       break;

     case SOT_ET_REGISTER:
       /* entity statistics */
       ent->methSts.methOutReg++;

       /* general statistics */
       soCb.sts.methSts.methOutReg++;
       break;

     case SOT_ET_BYE:
       /* entity statistics */
       ent->methSts.methOutBye++;

       /* general statistics */
       soCb.sts.methSts.methOutBye++;
            break;

     case SOT_ET_CANCEL:
       ent->methSts.methOutCanc++;
       soCb.sts.methSts.methOutCanc++;
       break;

#ifdef  SO_REFER
     case SOT_ET_REFER:
       /* entity statistics */
       ent->methSts.methOutRefer++;

       /* general statistics */
       soCb.sts.methSts.methOutRefer++;
       break;
#endif /*  SO_REFER */

#ifdef SO_EVENT
     case SOT_ET_SUBSCRIBE:
       /* entity statistics */
       ent->methSts.methOutSubsc++;

       /* general statistics */
       soCb.sts.methSts.methOutSubsc++;
       break;

     case SOT_ET_NOTIFY:
       /* entity statistics */
       ent->methSts.methOutNotify++;
       
       /* general statistics */
       soCb.sts.methSts.methOutNotify++;
       break;
#endif

#ifdef SO_INSTMSG
     case SOT_ET_MESSAGE :
       /* entity statistics */
       ent->methSts.methOutMessage++;
       
       /* general statistics */
       soCb.sts.methSts.methOutMessage++;
       break;
#endif 

#ifdef SO_UPDATE
     case SOT_ET_UPDATE:
       /* entity statistics */
       ent->methSts.methOutUpdate++;
       
       /* general statistics */
       soCb.sts.methSts.methOutUpdate++;
       break;
#endif
     default:
       break;
   }

   RETVALUE(ROK);
} 

/*
*
*       Fun:   soUtlUpdInReqSts
*
*       Desc:  Records statistics for messages sent to the network.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  po_ua.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlUpdInReqSts
(
SoEntCb   *ent,      /* entityCb */
U16       evntType   /* Event Type */
)
#else
PUBLIC S16 soUtlUpdInReqSts(ent, evntType)
SoEntCb   *ent;      /* entityCb */
U16       evntType;  /* Event Type */
#endif
{
   /* local variables */
   TRC2(soUtlUpdInReqSts);


   /* entity statistics */
   ent->summSts.sumInReq++;

   /* general statistics */
   soCb.sts.summSts.sumInReq++;

   switch (evntType)
   {
     case SOT_ET_INVITE:
       /* entity statistics */
       ent->methSts.methInInv++;

       /* general statistics */
       soCb.sts.methSts.methInInv++;
       break;

     case SOT_ET_ACK:
       /* entity statistics */
       ent->methSts.methInAck++;

       /* general statistics */
       soCb.sts.methSts.methInAck++;
       break;

     case SOT_ET_INFO:
       /* entity statistics */
       ent->methSts.methInInfo++;

       /* general statistics */
       soCb.sts.methSts.methInInfo++;
       break;

     case SOT_ET_PRACK:
       /* entity statistics */
       ent->methSts.methInPrack++;

       /* general statistics */
       soCb.sts.methSts.methInPrack++;
       break;

     case SOT_ET_OPTIONS:
       /* entity statistics */
       ent->methSts.methInOpt++;

       /* general statistics */
       soCb.sts.methSts.methInOpt++;
       break;

     case SOT_ET_REGISTER:
       /* entity statistics */
       ent->methSts.methInReg++;

       /* general statistics */
       soCb.sts.methSts.methInReg++;
       break;

     case SOT_ET_BYE:
       /* entity statistics */
       ent->methSts.methInBye++;

       /* general statistics */
       soCb.sts.methSts.methInBye++;
            break;

     case SOT_ET_CANCEL:
       ent->methSts.methInCanc++;
       soCb.sts.methSts.methInCanc++;
       break;

#ifdef  SO_REFER
     case SOT_ET_REFER:
       /* entity statistics */
       ent->methSts.methInRefer++;

       /* general statistics */
       soCb.sts.methSts.methInRefer++;
       break;
#endif /*  SO_REFER */

#ifdef SO_EVENT
     case SOT_ET_SUBSCRIBE:
       /* entity statistics */
       ent->methSts.methInSubsc++;

       /* general statistics */
       soCb.sts.methSts.methInSubsc++;
       break;

     case SOT_ET_NOTIFY:
       /* entity statistics */
       ent->methSts.methInNotify++;
       
       /* general statistics */
       soCb.sts.methSts.methInNotify++;
       break;
#endif

#ifdef SO_INSTMSG
     case SOT_ET_MESSAGE :
       /* entity statistics */
       ent->methSts.methInMessage++;
       
       /* general statistics */
       soCb.sts.methSts.methInMessage++;
       break;
#endif 

#ifdef SO_UPDATE
     case SOT_ET_UPDATE:
       /* entity statistics */
       ent->methSts.methInUpdate++;
       
       /* general statistics */
       soCb.sts.methSts.methInUpdate++;
       break;
#endif
     default:
       break;
   }

   RETVALUE(ROK);
} 

/*
*
*       Fun:   soUtlUpdOutRspSts
*
*       Desc:  Records statistics for messages sent to the network.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  po_ua.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlUpdOutRspSts
(
SoEntCb   *ent,           /* entityCb */
U16       responseClass   /* Response Class */
)
#else
PUBLIC S16 soUtlUpdOutRspSts(ent, responseClass)
SoEntCb   *ent;            /* entityCb */
U16       responseClass;   /* esponse Class */
#endif
{
   /* local variables */
   TRC2(soUtlUpdOutRspSts);

   /* entity statistics */
   ent->summSts.sumOutResp++;

   /* general statistics */
   soCb.sts.summSts.sumOutResp++;

   switch (responseClass)
   {
     case SO_STACODE_TYPE_INFORM:
       /* entity statistics */
       ent->respSts.infoClassOut++;
       
       /* general statistics */
       soCb.sts.respSts.infoClassOut++;
       break;

     case SO_STACODE_TYPE_SUCCESS:
       /* entity statistics */
       ent->respSts.successClassOut++;
       
       /* general statistics */
       soCb.sts.respSts.successClassOut++;
       break;

     case SO_STACODE_TYPE_REDIR:
       /* entity statistics */
       ent->respSts.redirClassOut++;
       
       /* general statistics */
       soCb.sts.respSts.redirClassOut++;
       break;

     case SO_STACODE_TYPE_CLERR:
       /* entity statistics */
       ent->respSts.reqFailClassOut++;
       
       /* general statistics */
       soCb.sts.respSts.reqFailClassOut++;
       break;
       
     case SO_STACODE_TYPE_SRVERR:
       /* entity statistics */
       ent->respSts.srvFailClassOut++;

       /* general statistics */
       soCb.sts.respSts.srvFailClassOut++;
       break;

     case SO_STACODE_TYPE_GLFAIL:
       /* entity statistics */
       ent->respSts.globalFailClassOut++;
       
       /* general statistics */
       soCb.sts.respSts.globalFailClassOut++;
       break;

     default:
       RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} 






/*
*
*       Fun:   soUtlUpdInRspSts
*
*       Desc:  Records statistics for messages sent to the network.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  po_ua.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlUpdInRspSts
(
SoEntCb   *ent,           /* entityCb */
U16       responseClass   /* Response Class */
)
#else
PUBLIC S16 soUtlUpdInRspSts(ent, responseClass)
SoEntCb   *ent;            /* entityCb */
U16       responseClass;   /* esponse Class */
#endif
{
   /* local variables */
   TRC2(soUtlUpdInRspSts);

   /* entity statistics */
   ent->summSts.sumInResp++;

   /* general statistics */
   soCb.sts.summSts.sumInResp++;

   switch (responseClass)
   {
     case SO_STACODE_TYPE_INFORM:
       /* entity statistics */
       ent->respSts.infoClassIn++;
       
       /* general statistics */
       soCb.sts.respSts.infoClassIn++;
       break;

     case SO_STACODE_TYPE_SUCCESS:
       /* entity statistics */
       ent->respSts.successClassIn++;
       
       /* general statistics */
       soCb.sts.respSts.successClassIn++;
       break;

     case SO_STACODE_TYPE_REDIR:
       /* entity statistics */
       ent->respSts.redirClassIn++;
       
       /* general statistics */
       soCb.sts.respSts.redirClassIn++;
       break;

     case SO_STACODE_TYPE_CLERR:
       /* entity statistics */
       ent->respSts.reqFailClassIn++;
       
       /* general statistics */
       soCb.sts.respSts.reqFailClassIn++;
       break;
       
     case SO_STACODE_TYPE_SRVERR:
       /* entity statistics */
       ent->respSts.srvFailClassIn++;

       /* general statistics */
       soCb.sts.respSts.srvFailClassIn++;
       break;

     case SO_STACODE_TYPE_GLFAIL:
       /* entity statistics */
       ent->respSts.globalFailClassIn++;
       
       /* general statistics */
       soCb.sts.respSts.globalFailClassIn++;
       break;

     default:
       RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} 



#ifdef LSO_ACNT
/*
*
*       Fun:   soUtlPrcContentType
*
*       Desc:  This checks for the presence of a Content Type header.
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlPrcContentType
(
SoCLegCb *cLeg,    /* Call Leg Cb */
SoEvnt   *evnt     /* Event cb */
)
#else
PUBLIC S16 soUtlPrcContentType(cLeg, evnt)
SoCLegCb *cLeg;    /* Call Leg Cb */
SoEvnt   *evnt;    /* Event cb */
#endif
{
   SoContentTypeHdr  *contentType;  /* ptr to ContentType */

   TRC2(soUtlPrcContentType);

   /* Find header in message */
   if (soCmFindHdrChoice(evnt, (U8 **) &contentType,
                              SO_HEADER_ENT_CONTENTTYPE) != ROK)
   {
      cLeg->accntCb.mediaType = LSO_ACNT_MEDIA_NONE;
      RETVALUE(RFAILED);
   }

   if (SO_CMP_TKN_LIT(&contentType->subType.valueType,
                           SO_MEDIA_SUBTYPE_SDP) == TRUE)
      cLeg->accntCb.mediaType = LSO_ACNT_MEDIA_SDP_DECODED;
   else
      cLeg->accntCb.mediaType = LSO_ACNT_MEDIA_OTHER;

   RETVALUE(ROK);
} /* soUtlPrcContentType */

#endif /* LSO_ACNT */


/*
*
*       Fun:    soUtlDelTopRouteElement
*
*       Desc:   deletes top via element
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelTopRouteElement
(
SoEvnt   *evnt
)
#else
PUBLIC S16 soUtlDelTopRouteElement (evnt)
SoEvnt   *evnt;
#endif
{
   S16        ret;
   U16        i, hdrIdx;
   TknU16     *numComp;
   U16        numCompVal;
   SoRoute    *route;
   SoRouteSeq *routeSeq;

   TRC2(soUtlDelTopRouteElement);

   /* Find Route header in message */
   ret = soCmFindHdrChIndex (evnt, (U8 **) &route, &hdrIdx, SO_HEADER_REQ_ROUTE);
   if (ret != ROK)
      RETVALUE (ROK);

   /* Remove the first Route header and move any other headers up the list */
   numComp    = &(route->numComp);
   numCompVal = SO_GET_NUM_COMP(numComp);

   if (numCompVal > 0)
   {
      /* Save top route item pointer */
      routeSeq = route->route[0];

      for (i = 0; i < numCompVal - 1; i++)
      {
         route->route[i] = route->route[i + 1];
      }

      /* Place saved pointer at the bottom for list resize */
      route->route[numCompVal - 1] = routeSeq;

      ret = soCmShrinkList((Void ***)&route->route, sizeof(SoRouteSeq),
                        numComp,
                        evnt);
      if (ret != ROK)
        RETVALUE(RFAILED);

      if (SO_GET_NUM_COMP(numComp) == 0)
      {
         /* Delete reference to this route header */
         if (soCmRemoveHdrChoice (evnt, hdrIdx, SO_HEADER_REQ_ROUTE)!=ROK )
            RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);

} /* soUtlDelTopRouteElement */



/*
*
*       Fun:    soUtlDelTopViaElement
*
*       Desc:   deletes top via element
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelTopViaElement
(
SoEvnt *evnt 
)
#else
PUBLIC S16 soUtlDelTopViaElement(evnt)
SoEvnt *evnt;
#endif
{
   S16        ret;
   U16        i, hdrIdx;
   TknU16     *numComp;
   U16        numCompVal;
   SoVia      *via;
   SoViaItem  *viaItem;

   TRC2(soUtlDelTopViaElement);

   /* Find Via header in message */
   ret = soCmFindHdrChIndex(evnt, (U8 **) &via, &hdrIdx, SO_HEADER_GEN_VIA);
   if (ret != ROK)
      RETVALUE (RFAILED);

   /* ViaHidden not supported */
   if (SO_CMP_TKN_LIT(&via->viaItem[0]->sentBy.type, SO_SENTBY_HOSTPORT) != TRUE)
      RETVALUE(RFAILED);

   /* Remove the first via header and move any other headers up the list */
   numComp    = &(via->numComp);
   numCompVal = SO_GET_NUM_COMP(numComp);

   if (numCompVal > 0)
   {
      /* Save top via item pointer */
      viaItem = via->viaItem[0];

      for (i = 0; i < numCompVal - 1; i++)
      {
         via->viaItem[i] = via->viaItem[i + 1];
      }

      /* Place saved pointer at the bottom for list resize */
      via->viaItem[numCompVal - 1] = viaItem;

      ret = soCmShrinkList((Void ***)&via->viaItem, sizeof(SoViaItem),
                        numComp,
                        evnt);
      if (ret != ROK)
        RETVALUE(RFAILED);

      if (SO_GET_NUM_COMP(numComp) == 0)
      {
         /* Delete reference to this via header */
         if (soCmRemoveHdrChoice (evnt, hdrIdx, SO_HEADER_GEN_VIA)!=ROK )
            RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);

} /* soUtlDelTopViaElement */





/*
*
*       Fun:   soUtlGenSpConnId
*
*       Desc:  This function generates a new spConnId
*
*       Notes: 
*
*       File:  so_utl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlGenSpConnId
(
SoCallCb *callCb  /* Call Cb for which the spConnId is to be 
                    allocated */
)
#else
PUBLIC S16 soUtlGenSpConnId(callCb)
SoCallCb *callCb; /* Call Cb for which the spConnId is to be 
                    allocated */
#endif 
{
  SoSSapCb    *ssap;      /* SSAP */

  TRC2(soUtlGenSpConnId);

  ssap = callCb->ssapCb;
  callCb->spConnId = ssap->sys->nextConnId++;

  /* Update nextConnId */
  if (ssap->sys->nextConnId > SOT_CLEGID_MAX)
    ssap->sys->nextConnId = (SOT_CLEGID_NOTUSED + 1);
  
  RETVALUE(ROK);
}


/*
*
*       Fun:   soUtlChkRes
*
*       Desc:  This function checks if resources are available to 
*              process a new message.
*
*       Notes: 
*
*       File:  so_utl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlChkRes
(
SoEvnt *evnt,         /* SIP Message */
U8     direction      /* From User/ From Remote end */
)
#else
PUBLIC S16 soUtlChkRes(evnt, direction)
SoEvnt *evnt;         /* SIP Message */
U8     direction;     /* From User/ From Remote end */
#endif 
{
   S16     ret;
   Status  status;   /* Status of Resource Check */
   Mem     mem;

   TRC3(soUtlChkRes);

   mem.region = soCb.init.region;
   mem.pool   = soCb.init.pool;
   /* Check for availablity of system resources */
   SChkRes(soCb.init.region, soCb.init.pool, &status);

   /* entity was not under resource congestion */
   if(!soCb.resCongStrt)
   {
     if(status > soCb.cfg.resThreshLower)
       ret= ROK;
     else
     {
       /* congestion starts */
       soCb.resCongStrt = TRUE;

       /* Inform the Layer Manager of congestion stops*/
       soGenStaInd (STGEN, LCM_CATEGORY_RESOURCE,
                    LSO_EVENT_RES_CONG_STRT,
                    LCM_CAUSE_UNKNOWN, LSO_PAR_MEM, (Ptr)&mem);
       
       ret = RFAILED;
     }
   }
   else  /* entity already under resource congestion */
   {
     if(status >= soCb.cfg.resThreshUpper)
     {
       soCb.resCongStrt = FALSE;
       
       /* Inform the Layer Manager of congestion stops*/
       soGenStaInd (STGEN, LCM_CATEGORY_RESOURCE,
                    LSO_EVENT_RES_CONG_STOP,
                    LCM_CAUSE_UNKNOWN, LSO_PAR_MEM, (Ptr)&mem);
       ret = ROK;
     }
     else
       ret = RFAILED;
   }

   RETVALUE(ret);
}


/***********************************************************************
*
*       Fun:    soUaCalcAddrKey
*
*       Desc:   Calculates the key associated with a RegCbLst in the
*               call Leg. The key is the normalized request URI.
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   po_ua.c
*
**********************************************************************/
#ifdef ANSI
PUBLIC S16 soUtlCalcAddrKey
(
SoAddrSpec *addr,     /* Request URI */
U8         **key,     /* Key to be returned */
U16        *keyLen    /* Length of the key */
)
#else
PUBLIC S16 soUtlCalcAddrKey(addr, key, keyLen)
SoAddrSpec *addr;     /* Request URI */
U8         **key;     /* Key to be returned */
U16        *keyLen;   /* Length of the key */
#endif
{
  S16      ret;          /* value returned by function calls   */
  
  TRC3(soUaCalcAddrKey);

  /* Create text version of address */
  ret = soCmNormAddr((U8 *)NULLP, addr, keyLen);
  if (ret != ROK)
    RETVALUE(SOT_ERR_RSRC);

  SOALLOC(key, *keyLen);

  if (*key == NULLP)
    RETVALUE(SOT_ERR_RSRC);

  /* Normalize key */
  ret = soCmNormAddr(*key, addr, keyLen);
  if (ret != ROK)
    RETVALUE(SOT_ERR_RSRC);

  RETVALUE(SOT_ERR_NOERR);
} /* soUaCalcAddrKey */

/*
*
*       Fun:   soSizeOfSoContactParam
*
*       Desc:  Calculates the amount of memory a particular
*              instance os SoContactParam uses.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size
*
*       File:  so_utl
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoContactParam
(
SoContactParam *contactParam,  /* contact item structure */
U32            *size           /* Memory size to allocate */
)
#else
PUBLIC S16 soSizeOfSoContactParam (contactParam, size)
SoContactParam *contactParam;  /* Cache control block */
U32            *size;          /* Memory size to allocate */
#endif
{
   S16   ret;
   U32   tempSize;

   TRC2(soSizeOfSoContactParam);

   ret = ROK;
   tempSize = 0;

   *size = sizeof(SoContactParam);

   if (contactParam->contactParamType.pres == NOTPRSNT)
   {
      RETVALUE(ret);
   }

   switch (contactParam->contactParamType.val)
   {
      case SO_CONTACTPARAM_STD:
         /* Size of SoContactParamStd has already been added */
         break;

      case SO_CONTACTPARAM_EXTN:
         if (contactParam->t.genericParam.pres.pres != NOTPRSNT)
         {
            if (contactParam->t.genericParam.token.pres != NOTPRSNT)
            {
               *size += sizeof(U8) * contactParam->t.genericParam.token.len;
            }
            if (contactParam->t.genericParam.paramVal.value.pres != NOTPRSNT)
            {
               *size += sizeof(U8) *
                  contactParam->t.genericParam.paramVal.value.len;
            }
         }
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO306,
                    (ErrVal) contactParam->contactParamType.val,
                    "soSizeOfSoContactParam: SoContactParam contactParamType "
                    "is invalid");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         ret = RFAILED;
         break;
   }

   RETVALUE(ret);
} /* soSizeOfSoContactParam */


/*
*
*       Fun:   soSizeOfSoContactItem
*
*       Desc:  Calculates the amount of memory a particular
*              instance os SoContactItem uses.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size
*
*       File:  so_utl
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoContactItem
(
SoContactItem *contactItem,  /* contact item structure */
U32           *size          /* Memory size to allocate */
)
#else
PUBLIC S16 soSizeOfSoContactItem (contactItem, size)
SoContactItem *contactItem;  /* Cache control block */
U32           *size;         /* Memory size to allocate */
#endif
{
   U32   tmpSize;
   S16   i;
   S16   ret;

   TRC2(soSizeOfSoContactItem);

   *size = sizeof(SoContactItem);
   tmpSize = 0;

   if (contactItem->pres.pres == NOTPRSNT)
   {
      RETVALUE(ROK);
   }

   /* size of SoAddrCh */
   if (contactItem->contactAddrChoice.addrChType.pres != NOTPRSNT)
   {
      switch (contactItem->contactAddrChoice.addrChType.val)
      {
         case SO_ADDRCH_NAMEADDR:
            if (contactItem->contactAddrChoice.t.nameAddr.pres.pres
                != NOTPRSNT)
            {
               ret = soSizeOfSoDisplayName(
                  &contactItem->contactAddrChoice.t.nameAddr.displayName,
                  &tmpSize);
               if (ret != ROK)
               {
                  RETVALUE(RFAILED);
               }
               *size += tmpSize - sizeof(SoDisplayName);
               tmpSize = 0;
            }

            ret = soSizeOfSoAddrSpec(
               &contactItem->contactAddrChoice.t.nameAddr.addrSpec, &tmpSize);
            if (ret != ROK)
            {
               RETVALUE(RFAILED);
            }
            *size += tmpSize - sizeof(SoAddrSpec);
            tmpSize = 0;
            break;

         case SO_ADDRCH_ADDRSPEC:
            ret = soSizeOfSoAddrSpec(&contactItem->contactAddrChoice.t.addrSpec,
                               &tmpSize);
            if (ret != ROK)
            {
               RETVALUE(RFAILED);
            }
            *size += tmpSize - sizeof(SoAddrSpec);
            tmpSize = 0;
            break;

         default:
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO307,
                       (ErrVal) contactItem->contactAddrChoice.addrChType.val,
                       "soSizeOfSoContactItem: SoAddrCh addrChType is invalid");
#endif /* ERRCLASS & ERRCLS_DEBUG */
            RETVALUE(RFAILED);
      }
   }

   /* size of SoContactParams */
   if (contactItem->contactParams.numComp.pres != NOTPRSNT)
   {
      *size += sizeof(SoContactParam *) *
         contactItem->contactParams.numComp.val;

      for (i = 0; i < contactItem->contactParams.numComp.val; i++)
      {
         ret = soSizeOfSoContactParam(contactItem->\
                                         contactParams.contactParam[i],
                                      &tmpSize);
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
         *size += tmpSize;
         tmpSize = 0;
      }
   }

   RETVALUE(ROK);
} /* soSizeOfSoContactItem */

/*
*
*       Fun:   soSizeOfSoDisplayName
*
*       Desc:  Calculates the amount of memory a particular
*              instance os SoDisplayName uses.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size
*
*       File:  so_utl
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoDisplayName
(
SoDisplayName *displayName,        /* contact item structure */
U32           *size                /* Memory size to allocate */
)
#else
PUBLIC S16 soSizeOfSoDisplayName (displayName, size)
SoDisplayName *displayName;    /* Cache control block */
U32           *size;           /* Memory size to allocate */
#endif
{
   S16   i;

   TRC2(soSizeOfSoDisplayName);

   *size = sizeof(SoDisplayName);

   if (displayName->displayNameType.pres == NOTPRSNT)
   {
      RETVALUE(ROK);
   }

   switch (displayName->displayNameType.val)
   {
      case SO_PARAMVAL_TOKEN:
         if (displayName->t.displayNameRep.numComp.pres != NOTPRSNT)
         {
            *size += sizeof(TknStrOSXL *) *
               displayName->t.displayNameRep.numComp.val;
            for (i = 0; i < displayName->t.displayNameRep.numComp.val; i++)
            {
               *size += sizeof(TknStrOSXL) +
                  (sizeof(U8) *
                   displayName->t.displayNameRep.stringList[i]->len);
            }
         }
         break;

      case SO_PARAMVAL_QUOTEDSTR:
         *size += sizeof(U8) * displayName->t.quotedStr.len;
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO308,
                    (ErrVal) displayName->displayNameType.val,
                    "soSizeOfSoDisplayName: SoDisplayName displayNameType "
                    "is invalid");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* soSizeOfSoDisplayName */




/*
*
*       Fun:   soSizeOfSoAddrSpec
*
*       Desc:  Calculates the amount of memory a particular
*              instance os SoAddrSpec uses.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size
*
*       File:  so_utl
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoAddrSpec
(
SoAddrSpec *addrSpec,      /* contact item structure */
U32        *size           /* Memory size to allocate */
)
#else
PUBLIC S16 soSizeOfSoAddrSpec (addrSpec, size)
SoAddrSpec *addrSpec;      /* Cache control block */
U32        *size;          /* Memory size to allocate */
#endif
{
   S16   i;                /* Loop Counter */
   U32   tmpSize;          /* Tempory storage for calculating the size */
   S16   ret;

   TRC2(soSizeOfSoAddrSpec);

   *size = sizeof(SoAddrSpec);
   tmpSize = 0;

   if (addrSpec->addrSpecType.pres == NOTPRSNT)
   {
      RETVALUE(ROK);
   }

   switch (addrSpec->addrSpecType.val)
   {
#ifdef SO_INSTMSG
      case SO_ADDRSPEC_IMURL:
#endif /* SO_INSTMSG */
      case SO_ADDRSPEC_SIPURL:
         /* Size of SoSipUrl */
         *size += sizeof(SoSipUrl);

         if (addrSpec->t.sipUrl.pres.pres == NOTPRSNT)
         {
            RETVALUE(ROK);
         }

         /* Size of SoStrValue -> TknStOSXL */
         if (addrSpec->t.sipUrl.userInfo.pres.pres != NOTPRSNT)
         {
            if (addrSpec->t.sipUrl.userInfo.userType.value.pres != NOTPRSNT)
            {
               *size += sizeof(U8) *
                  addrSpec->t.sipUrl.userInfo.userType.value.len;
            }
            *size += sizeof(U8) * addrSpec->t.sipUrl.userInfo.password.len;
         }

         /* Size of SoHostPort */
         if (addrSpec->t.sipUrl.hostPort.pres.pres != NOTPRSNT)
         {
            ret = soSizeOfSoHost(&addrSpec->t.sipUrl.hostPort.host, &tmpSize);
            if (ret != ROK)
            {
               RETVALUE(RFAILED);
            }
            *size += tmpSize - sizeof(SoHost);
            tmpSize = 0;
         }

         /* Size of SoUrlParameters */
         if (addrSpec->t.sipUrl.urlParameters.numComp.pres != NOTPRSNT)
         {
            *size += sizeof(SoUrlParameter *) *
               addrSpec->t.sipUrl.urlParameters.numComp.val;
            for (i = 0; i < addrSpec->t.sipUrl.urlParameters.numComp.val; i++)
            {
               ret = soSizeOfSoUrlParameter(
                  addrSpec->t.sipUrl.urlParameters.urlParameter[i], &tmpSize);
               if (ret != ROK)
               {
                  RETVALUE(RFAILED);
               }
               *size += tmpSize;
               tmpSize = 0;
            }
         }

         /* Size of SoHeaders */
         if (addrSpec->t.sipUrl.headers.pres.pres != NOTPRSNT)
         {
            ret = soSizeOfSoNameVal(&addrSpec->t.sipUrl.headers.header,
                                    &tmpSize);
            if (ret != ROK)
            {
               RETVALUE(RFAILED);
            }
            *size += tmpSize -  sizeof(SoNameVal);
            tmpSize = 0;

            if (addrSpec->t.sipUrl.headers.headerExt.numComp.pres != NOTPRSNT)
            {
               *size += sizeof(SoNameVal *) *
                  addrSpec->t.sipUrl.headers.headerExt.numComp.val;
               for (i = 0;
                    i < addrSpec->t.sipUrl.headers.headerExt.numComp.val; i++)
               {
                  ret = soSizeOfSoNameVal(
                     addrSpec->t.sipUrl.headers.headerExt.header[i], &tmpSize);
                  if (ret != ROK)
                  {
                     RETVALUE(RFAILED);
                  }
                  *size += tmpSize;
                  tmpSize = 0;
               }
            }
         }
         break;

#ifdef SO_ENUM
      case SO_ADDRSPEC_TELURL:
         /* Size of SoTelUrl */
         *size += sizeof(SoTelUrl);
         break;
#endif /* SO_ENUM */

      case SO_ADDRSPEC_ABSOLUTEURI :
         /* Size of SoAbsoluteUri */
         *size += sizeof(SoAbsoluteUri);

         if (addrSpec->t.absoluteUri.pres.pres == NOTPRSNT)
         {
            RETVALUE(ROK);
         }
         /* Size of TknStrOSXL */
         if (addrSpec->t.absoluteUri.scheme.pres != NOTPRSNT)
         {
            *size += sizeof(U8) * addrSpec->t.absoluteUri.scheme.len;
         }
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO309,
                    (ErrVal) addrSpec->addrSpecType.val,
                    "soSizeOfSoAddrSpec: SoAddrSpec addrSpecType is invalid");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* soSizeOfSoAddrSpec */

/*
*
*       Fun:   soSizeOfSoUrlParameter
*
*       Desc:  Calculates the amount of memory a particular
*              instance os SoUrlParameter uses.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size
*
*       File:  so_utl
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoUrlParameter
(
SoUrlParameter *urlParameter,  /* contact item structure */
U32            *size           /* Memory size to allocate */
)
#else
PUBLIC S16 soSizeOfSoUrlParameter (urlParameter, size)
SoUrlParameter *urlParameter;  /* Cache control block */
U32            *size;          /* Memory size to allocate */
#endif
{
   U32   tmpSize;
   S16   ret;

   TRC2(soSizeOfSoUrlParameter);

   *size += sizeof(SoUrlParameter);
   tmpSize = 0;

   if (urlParameter->urlParameterType.pres == NOTPRSNT)
   {
      RETVALUE(ROK);
   }

   switch (urlParameter->urlParameterType.val)
   {
      case SO_URLPARAMETER_TRANSPORTPARAM:
         if (urlParameter->t.transportParam.otherTransport.pres)
         {
            *size += sizeof(U8) *
               urlParameter->t.transportParam.otherTransport.len;
         }
         break;

      case SO_URLPARAMETER_USERPARAM:
         if (urlParameter->t.userParam.otherUser.pres)
         {
            *size += sizeof(U8) *
               urlParameter->t.userParam.otherUser.len;
         }
         break;

      case SO_URLPARAMETER_METHOD:
         ret = soSizeOfSoExtVal(&urlParameter->t.method, &tmpSize,
                          SO_METHOD_EXTENSIONMETHOD);
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
         *size += tmpSize - sizeof(SoExtVal);
         tmpSize = 0;
         break;

      case SO_URLPARAMETER_TTLPARAM:
      /* so002.102: fix for LR */
      case SO_URLPARAMETER_LRPARAM:
         /* Already added to *size */
         break;

      case SO_URLPARAMETER_MADDRHOST:
         ret = soSizeOfSoHost(&urlParameter->t.maddrHost, &tmpSize);
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
         *size += tmpSize - sizeof(SoHost);
         tmpSize = 0;
         break;
#ifdef SO_PINT
       case SO_URLPARAMETER_TSPDOMAIN:
         ret = soSizeOfSoHost(&urlParameter->t.tspDomain, &tmpSize);
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
         *size += tmpSize - sizeof(SoHost);
         tmpSize = 0;
         break;  
#endif

      case SO_URLPARAMETER_OTHERPARAM :
         ret = soSizeOfSoNameVal(&urlParameter->t.otherParam, &tmpSize);
         if (ret != ROK)
         {
            RETVALUE(RFAILED);
         }
         *size += tmpSize - sizeof(SoNameVal);
         tmpSize = 0;
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO310,
                    (ErrVal) urlParameter->urlParameterType.val,
                    "soSizeOfSoUrlParameter: SoUrlParameter urlParameterType "
                    "is invalid");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* soSizeOfSoUrlParameter */

/*
*
*       Fun:   soSizeOfSoAddress
*
*       Desc:  Calculates the amount of memory a particular
*              instance os SoAddress uses.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size
*
*       File:  so_utl
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoAddress
(
SoAddress  *addr,          /* contact item structure */
U32        *size           /* Memory size to allocate */
)
#else
PUBLIC S16 soSizeOfSoAddress (addr, size)
SoAddress  *addr;          /* Cache control block */
U32        *size;          /* Memory size to allocate */
#endif
{
   S16   i;                /* Loop Counter */
   U32   tmpSize;          /* Tempory storage for calculating the size */

   TRC2(soSizeOfSoAddress);

   *size = sizeof(SoAddress);
   tmpSize = 0;

   if (addr->pres.pres == NOTPRSNT)
   {
      RETVALUE(ROK);
   }

   if (addr->addrCh.addrChType.pres != NOTPRSNT)
   {
      switch (addr->addrCh.addrChType.val)
      {
          case SO_ADDRCH_NAMEADDR:
             if (addr->addrCh.t.nameAddr.pres.pres != NOTPRSNT)
             {
                soSizeOfSoDisplayName(&addr->addrCh.t.nameAddr.displayName, 
                                      &tmpSize);
                *size = *size + tmpSize - sizeof(SoNameAddr);
                tmpSize = 0;
             }
             if (addr->addrCh.t.nameAddr.addrSpec.addrSpecType.pres != NOTPRSNT)
             {
                soSizeOfSoAddrSpec (&addr->addrCh.t.nameAddr.addrSpec, 
                                    &tmpSize);
                *size = *size + tmpSize - sizeof(SoAddrSpec);
                tmpSize = 0;
             }
             break;

          case SO_ADDRCH_ADDRSPEC:
             soSizeOfSoAddrSpec (&addr->addrCh.t.addrSpec, &tmpSize);
             *size = *size + tmpSize - sizeof(SoAddrSpec);
             tmpSize = 0;
             break;

          default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO311,
                    (ErrVal) addr->addrCh.addrChType.val,
                    "soSizeOfSoAddress: SoAddrCh addrChType is invalid");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         RETVALUE(RFAILED);
      }
   }

   if (addr->addrParams.numComp.pres != NOTPRSNT)
   {
      *size += sizeof(SoAddrParam *) * addr->addrParams.numComp.val;
      *size += sizeof(SoAddrParam) * addr->addrParams.numComp.val;
      for (i = 0; i < addr->addrParams.numComp.val; i++)
      {
         switch (addr->addrParams.addrParam[i]->addrParamType.val)
         {
            case SO_ADDRPARAM_TAGPARAM:
                 *size += addr->addrParams.addrParam[i]->t.tagParam.len;
                 tmpSize = 0;
                 break;

            case SO_ADDRPARAM_GENERICPARAM:
                 if (addr->addrParams.addrParam[i]->t.genericParam.pres.pres !=
                                 NOTPRSNT)
                 {
                    if (addr->addrParams.addrParam[i]->t.genericParam.\
                                    token.pres != NOTPRSNT)
                       *size += addr->addrParams.addrParam[i]->t.genericParam.\
                                token.len;

                    if (addr->addrParams.addrParam[i]->t.genericParam.\
                                    paramVal.value.pres != NOTPRSNT)
                       *size += addr->addrParams.addrParam[i]->t.genericParam.\
                                    paramVal.value.len;
                 }
                 break;

            default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO312,
                    (ErrVal) addr->addrParams.addrParam[i]->addrParamType.val,
                    "soSizeOfSoAddress: SoAddrParam addrParamType is invalid");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         RETVALUE(RFAILED);
         }
      }
   }

   RETVALUE(ROK);
} /* soSizeOfSoAddress */

/*
*
*       Fun:   soSizeOfSoHost
*
*       Desc:  Calculates the amount of memory a particular
*              instance os SoHost uses.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size
*
*       File:  so_utl
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoHost
(
SoHost *host,          /* contact item structure */
U32    *size           /* Memory size to allocate */
)
#else
PUBLIC S16 soSizeOfSoHost (host, size)
SoHost *host;          /* Cache control block */
U32    *size;          /* Memory size to allocate */
#endif
{
   TRC2(soSizeOfSoHost);

   *size += sizeof(SoHost);

   if (host->hostType.pres == NOTPRSNT)
   {
      RETVALUE(ROK);
   }

   switch (host->hostType.val)
   {
      case SO_HOST_HOSTNAME:
         if (host->t.hostName.pres != NOTPRSNT)
         {
            *size += sizeof(U8) * host->t.hostName.len;
         }
         break;

      case SO_HOST_IPV4ADDRESS:
         /* Size of IPv4 Addresses already added */
         break;

      case SO_HOST_IPV6REFERENCE:
         if (host->t.ipv6Reference.pres != NOTPRSNT)
         {
            *size += sizeof(U8) * host->t.ipv6Reference.len;
         }
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG, ESO313, (ErrVal) host->hostType.val,
                    "soSizeOfSoHost: SoHost hostType is invalid");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* soSizeOfSoHost */




/*
*
*       Fun:   soSizeOfSoNameVal
*
*       Desc:  Calculates the amount of memory a particular
*              instance os SoNameVal uses.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size
*
*       File:  so_utl
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoNameVal
(
SoNameVal *nameVal,        /* contact item structure */
U32       *size           /* Memory size to allocate */
)
#else
PUBLIC S16 soSizeOfSoNameVal (nameVal, size)
SoNameVal *nameVal;        /* Cache control block */
U32       *size;           /* Memory size to allocate */
#endif
{
   TRC2(soSizeOfSoNameVal);

   *size = sizeof(SoNameVal);

   if (nameVal->pres.pres == NOTPRSNT)
   {
      RETVALUE(ROK);
   }
   if (nameVal->name.pres != NOTPRSNT)
   {
      *size += sizeof(U8) * nameVal->name.len;
   }
   if (nameVal->value.pres != NOTPRSNT)
   {
      *size += sizeof(U8) * nameVal->value.len;
   }

   RETVALUE(ROK);
} /* soSizeOfSoNameVal */


/*
*
*       Fun:   soSizeOfSoExtVal
*
*       Desc:  Calculates the amount of memory a particular
*              instance os SoExtVal uses.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size
*
*       File:  so_utl
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoExtVal
(
SoExtVal *extVal,        /* contact item structure */
U32      *size,          /* Memory size to allocate */
U8       extTypeVal
)
#else
PUBLIC S16 soSizeOfSoExtVal (extVal, size, extTypeVal)
SoExtVal *extVal;        /* Cache control block */
U32      *size;          /* Memory size to allocate */
U8       extTypeVal;
#endif
{
   TRC2(soSizeOfSoExtVal);

   *size = sizeof(SoExtVal);

   if (extVal->type.pres == NOTPRSNT)
   {
      RETVALUE(ROK);
   }

   if (extVal->t.ext.pres != NOTPRSNT)
   {
      if (extVal->type.val == extTypeVal)
      {
         *size += sizeof(U8) * extVal->t.ext.len;
      }
   }

   RETVALUE(ROK);
} /* soSizeOfSoExtVal */







/*
*
*       Fun:   soSizeOfSoMediaRangeVal
*
*       Desc:  Calculates the amount of memory a particular
*              instance of SoMediaRange
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size. 
*
*       File:  so_utl.c
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoMediaRangeVal
(
SoMediaRangeVal   *mediaRangeVal,  /* media range val structure */
U32               *size            /* size to allocate */
)
#else
PUBLIC S16 soSizeOfSoMediaRangeVal(mediaRangeVal, size)
SoMediaRangeVal   *mediaRangeVal;  /* media range val structure */
U32               *size;           /* size to allocate */
#endif
{
   TRC2(soSizeOfSoMediaRangeVal);

   *size = 0;

   if (mediaRangeVal->mediaRangeValType.pres != NOTPRSNT)
   {
      switch (mediaRangeVal->mediaRangeValType.val)
      {
         case SO_MEDIARANGEVAL_ALLSTAR :
            break;
         case SO_MEDIARANGEVAL_TYPESTAR:
            *size += mediaRangeVal->t.typeStar.len;
            break;
         case SO_MEDIARANGEVAL_TYPESUB:
            if (mediaRangeVal->t.typeSub.pres.pres != NOTPRSNT)
            {
               *size += (mediaRangeVal->t.typeSub.type.len +
                         mediaRangeVal->t.typeSub.subType.len);
            }
            break;

         default:
#if (ERRCLASS & ERRCLS_DEBUG)
           SOLOGERROR(ERRCLS_DEBUG, ESO314,
                      (ErrVal)mediaRangeVal->mediaRangeValType.val,
                       "soSizeOfSoMediaRangeVal: SoMediaRangeVal "
                       "mediaRangeValType is invalid");
#endif
            RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);
} /* end of soSizeOfSoMediaRangeVal */

   
/*
*
*       Fun:   soSizeOfSoAccept
*
*       Desc:  Calculates the amount of memory a particular
*              instance os SoAccept uses.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size
*
*       File:  so_utl
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoAccept
(
SoAccept *acceptHdr,        /* contact item structure */
U32      *size           /* Memory size to allocate */
)
#else
PUBLIC S16 soSizeOfSoAccept (acceptHdr, size)
SoAccept *acceptHdr;        /* Cache control block */
U32      *size;          /* Memory size to allocate */
#endif
{
   U16             i;
   U32             tmpSize;
   SoMediaRangeVal *mediaRangeVal;
   
   TRC2(soSizeOfSoAccept);

   *size = sizeof(SoAccept);

   if (acceptHdr->numComp.pres != NOTPRSNT)
   {
      *size += sizeof(SoAcceptSeq *) * acceptHdr->numComp.val;

      for (i = 0; i < acceptHdr->numComp.val; i++)
      {
         *size += sizeof(SoAcceptSeq);
         if (acceptHdr->accept[i]->pres.pres != NOTPRSNT)
         {
            if (acceptHdr->accept[i]->mediaRange.pres.pres != NOTPRSNT)
            {
               mediaRangeVal = &acceptHdr->accept[i]->mediaRange.mediaRangeVal;
               if (mediaRangeVal->mediaRangeValType.pres != NOTPRSNT)
               {
                  switch (mediaRangeVal->mediaRangeValType.val)
                  {
                     case SO_MEDIARANGEVAL_ALLSTAR :
                        break;
                     case SO_MEDIARANGEVAL_TYPESTAR:
                        *size += mediaRangeVal->t.typeStar.len;
                        break;
                     case SO_MEDIARANGEVAL_TYPESUB:
                        if (mediaRangeVal->t.typeSub.pres.pres != NOTPRSNT)
                        {
                           *size += (mediaRangeVal->t.typeSub.type.len +
                                     mediaRangeVal->t.typeSub.subType.len);
                        }
                        break;
                     default:
#if (ERRCLASS & ERRCLS_DEBUG)
                        SOLOGERROR(ERRCLS_DEBUG, ESO315,
                                   (ErrVal)mediaRangeVal->mediaRangeValType.val,
                                   "soSizeOfSoAccept: SoMediaRangeVal "
                                   "mediaRangeValType is invalid");
#endif /* ERRCLASS & ERRCLS_DEBUG */
                        break;
                  }
               }
               soSizeOfSoParameters(
                  &acceptHdr->accept[i]->mediaRange.parameters,
                  &tmpSize);
               *size += tmpSize - sizeof(SoParameters);
            }
         }
      }
   }
      
   RETVALUE(ROK);
} /* soSizeOfSoAccept */

/*
*
*       Fun:   soSizeOfSoParameters
*
*       Desc:  Calculates the amount of memory a particular
*              instance os SoContactParam uses.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size
*
*       File:  so_utl
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoParameters
(
SoParameters *parameters,  /* contact item structure */
U32            *size           /* Memory size to allocate */
)
#else
PUBLIC S16 soSizeOfSoParameters (parameters, size)
SoParameters *parameters;  /* Cache control block */
U32            *size;          /* Memory size to allocate */
#endif
{
   U16   i;
   
   TRC2(soSizeOfSoParameters);

   *size = sizeof(SoParameters);

   if (parameters->numComp.pres != NOTPRSNT)
   {
      *size += sizeof(SoParameter *) * parameters->numComp.val;

      for (i = 0; i < parameters->numComp.val; i++)
      {
         *size += sizeof(SoParameter);
         if (parameters->parameter[i]->pres.pres != NOTPRSNT)
         {
            *size += parameters->parameter[i]->token.len;
            if (parameters->parameter[i]->paramVal.valueType.pres != NOTPRSNT)
            {
               *size += parameters->parameter[i]->paramVal.value.len;
            }
         }
      }
   }               

   RETVALUE(ROK);
} /* soSizeOfSoParameters */
 
/*
*
*       Fun:   soSizeOfSoAcceptEncoding
*
*       Desc:  Calculates the amount of memory a particular
*              instance os SoAcceptEncoding uses.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size
*
*       File:  so_utl
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoAcceptEncoding
(
SoAcceptEncoding *acceptEncoding,        /* contact item structure */
U32      *size           /* Memory size to allocate */
)
#else
PUBLIC S16 soSizeOfSoAcceptEncoding (acceptEncoding, size)
SoAcceptEncoding *acceptEncoding;        /* Cache control block */
U32      *size;          /* Memory size to allocate */
#endif
{
   U16   i;
   U32   tmpSize;

   TRC2(soSizeOfSoAcceptEncoding);

   *size = sizeof(SoAcceptEncoding);

   if (acceptEncoding->numComp.pres != NOTPRSNT)
   {
      *size += sizeof(SoAcceptEncodingSeq *) * acceptEncoding->numComp.val;

      for (i = 0; i < acceptEncoding->numComp.val; i++)
      {
         *size += sizeof(SoAcceptEncodingSeq);
         if (acceptEncoding->acceptEncoding[i]->pres.pres != NOTPRSNT)
         {
            soSizeOfSoExtVal(
               &acceptEncoding->acceptEncoding[i]->codings.contentCoding,
               &tmpSize, SO_CONTENTCODING_EXTENSION);
            *size += tmpSize;
         }
      }
   }

   RETVALUE(ROK);
} /* soSizeOfSoAcceptEncoding */
   
/*
*
*       Fun:   soSizeOfSoAcceptLanguage
*
*       Desc:  Calculates the amount of memory a particular
*              instance os SoAcceptLanguage uses.
*
*       Ret:   ROK/RFAILED
*
*       Notes: Returns the size used into *size
*
*       File:  so_utl
*
*/
#ifdef ANSI
PUBLIC S16 soSizeOfSoAcceptLanguage
(
SoAcceptLanguage *acceptLanguage,        /* contact item structure */
U32      *size           /* Memory size to allocate */
)
#else
PUBLIC S16 soSizeOfSoAcceptLanguage (acceptLanguage, size)
SoAcceptLanguage *acceptLanguage;        /* Cache control block */
U32      *size;          /* Memory size to allocate */
#endif
{
   U16   i;
   
   TRC2(soSizeOfSoAcceptLanguage);

   *size = sizeof(SoAcceptLanguage);

   if (acceptLanguage->numComp.pres != NOTPRSNT)
   {
      *size += sizeof(SoAcceptLanguageSeq *) * acceptLanguage->numComp.val;

      for (i = 0; i < acceptLanguage->numComp.val; i++)
      {
         *size += sizeof(SoAcceptLanguageSeq);
         if (acceptLanguage->acceptLanguage[i]->pres.pres != NOTPRSNT)
         {
            *size += acceptLanguage->acceptLanguage[i]->languageRange.len;
         }
      }
   }

   RETVALUE(ROK);
} /* soSizeOfSoAcceptLanguage */


/*
*
*    Fun:    soUtlCpySoEvnt
*
*    Desc:    copy the structure pack
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoEvnt
(
SoEvnt *dst,
SoEvnt *src
)
#else
PUBLIC S16 soUtlCpySoEvnt(dst, src)
SoEvnt *dst;
SoEvnt *src;
#endif
{
   S16 ret;
   CmMemListCp mem;

   TRC3(soUtlCpySoEvnt)

   ret = ROK;

   /* Backup cpyMemCp */
   cmMemcpy((U8 *)&mem, (U8 *)&dst->memCp, sizeof(CmMemListCp));

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoEvnt));

   /* Restore cpyMemCp */
   cmMemcpy((U8 *)&dst->memCp, (U8 *)&mem, sizeof(CmMemListCp));

   /* This must be done so that the body structure is not freed when the is a
      failure before copying the body structure. */
   dst->sipBody.bodyType.pres = NOTPRSNT;

   if( src->sipMessageType.pres != NOTPRSNT )
   {
      switch( src->sipMessageType.val )
      {
         case  SO_SIPMESSAGE_AUDIT :
#ifndef SO_REL_1_2_INF
#ifdef SO_UA
            if (soUtlCpySoAudit(&dst->t.auditEvnt, &src->t.auditEvnt, &dst->memCp) != ROK)
               ret = RFAILED; 
#endif /* SO_UA */
#endif /*  SO_REL_1_2_INF  */
            break;
         case  SO_SIPMESSAGE_ERROR :
            if (soUtlCpySoErrEvnt(&dst->t.errEvnt, &src->t.errEvnt, &dst->memCp) != ROK)
               ret = RFAILED; 
            break;
         case  SO_SIPMESSAGE_REFRESH :
#ifndef SO_REL_1_2_INF
            if (soUtlCpySoRefreshEvnt(&dst->t.refreshEvnt, &src->t.refreshEvnt, &dst->memCp) != ROK)
               ret = RFAILED; 
#endif /*  SO_REL_1_2_INF  */
            break;
         case  SO_SIPMESSAGE_REQUEST :
            if (soUtlCpySoRequest(&dst->t.request, &src->t.request, &dst->memCp) != ROK)
               ret = RFAILED; 
            break;
         case  SO_SIPMESSAGE_RESPONSE :
            if (soUtlCpySoResponse(&dst->t.response, &src->t.response, &dst->memCp) != ROK)
               ret = RFAILED; 
            break;
         default:
               ret = RFAILED; 
      }
   }

   if (ret != ROK)
   {
      soCmFreeEvent(dst);
      RETVALUE(RFAILED);
   }

   if (soUtlCpySoBody(&dst->sipBody, &src->sipBody, &dst->memCp) != ROK)
   {
      soCmFreeEvent(dst);
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /*end of function soUtlCpySoEvnt*/


/*
*
*       Fun:    soUtlCpySoBodySinglePart
*
*       Desc:   Copies the SoBodySinglePart struct
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_utl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoBodySinglePart
(
SoBodySinglePart *dstSoBodySinglePart,
SoBodySinglePart *srcSoBodySinglePart,
CmMemListCp      *cpyMemCp
)
#else
PUBLIC S16 soUtlCpySoBodySinglePart(dstSoBodySinglePart,
                                  srcSoBodySinglePart,
                                  cpyMemCp)
SoBodySinglePart *dstSoBodySinglePart;
SoBodySinglePart *srcSoBodySinglePart;
CmMemListCp      *cpyMemCp;
#endif
{
   Mem   eventMem;

   TRC2(soUtlCpySoBodySinglePart);

   eventMem.region = soCb.init.region;
   eventMem.pool   = soCb.init.pool;

   if (srcSoBodySinglePart->bodySinglePartType.pres != NOTPRSNT)
   {
      switch (srcSoBodySinglePart->bodySinglePartType.val)
      {
         case SOT_BODYSINGLEPART_STR:
            if (SCpyMsgMsg(srcSoBodySinglePart->s.str.val,
                           soCb.init.region,
                           soCb.init.pool,
                           &dstSoBodySinglePart->s.str.val)
                != ROK)
               RETVALUE(RFAILED);
            break;

#ifndef CM_SDP_OPAQUE
         case SOT_BODYSINGLEPART_SDP:
            if (soUtlCpyGetMem((Ptr *)&dstSoBodySinglePart->s.sdp,
                            sizeof(SoSdpEvnt),
                            cpyMemCp) != ROK)
               RETVALUE(RFAILED);

            if (soUtlCpySoSdpEvnt(&dstSoBodySinglePart->s.sdp,
                               srcSoBodySinglePart->s.sdp,
                               cpyMemCp) != ROK)
               RETVALUE(RFAILED);
         break;
#endif /* CM_SDP_OPAQUE */

         default:
#if (ERRCLASS & ERRCLS_DEBUG)
            SOLOGERROR(ERRCLS_DEBUG, ESO316,
                       (ErrVal) srcSoBodySinglePart->bodySinglePartType.val,
                       "soUtlCpySoBodySinglePart: SoBodySinglePart "
                       "bodySinglePartType is invalid");
#endif /* ERRCLASS & ERRCLS_DEBUG */
            RETVALUE(RFAILED);
            break;
      }
   }
   RETVALUE(ROK);
} /* soUtlCpySoBodySinglePart */

#ifndef CM_SDP_OPAQUE

/*
*
*       Fun:    soUtlCpySoSdpEvnt
*
*       Desc:   Copies the SoSdpEvnt struct
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_utl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSdpEvnt
(
SoSdpEvnt   **dstSoSdpEvnt,
SoSdpEvnt   *srcSoSdpEvnt,
CmMemListCp *cpyMemCp
)
#else
PUBLIC S16 soUtlCpySoSdpEvnt(dstSoSdpEvnt, srcSoSdpEvnt, cpyMemCp)
SoSdpEvnt **dstSoSdpEvnt;
SoSdpEvnt *srcSoSdpEvnt;
CmMemListCp *cpyMemCp;
#endif
{
   S16          ret;
   Buffer       *mBuf;
   MsgLen       numSdpBytes;
   CmAbnfErr    err;
   CmAbnfDecOff decOff;
   Mem          abnfMem;
   U8           *CRLFStr = (U8 *)"\r\n";


   TRC2(soUtlCpySoSdpEvnt);

   ret = SGetMsg(soCb.init.region, soCb.init.pool, &mBuf);
   if (ret != ROK)
   {
      SO_GEN_SMEM_ALARM;
      RETVALUE(ROK);
   }

   abnfMem.region = soCb.init.region;
   abnfMem.pool   = soCb.init.pool;

   /* Initialize err */
   (Void) cmMemset((U8 *)&err, 0, sizeof(CmAbnfErr));

   /* ENCODE SDP EVENT INTO MBUF FROM SRC STRCUTURE */
   ret = cmAbnfEncPduMsg(CM_ABNF_PROT_SDP,
                         (U8 *)&srcSoSdpEvnt->sdp,
                         mBuf,
                         &cmMsgDefSdp,
                         &abnfMem,
                         &err);
   if (ret != ROK)
   {
#ifdef DEBUGP
      if (soCb.init.dbgMask & SO_DBGMASK_ABNF_ENC)
      {
         (Void) soUtlPrntMsg(mBuf,
                            "SDP body encode FAILED!!", FALSE, 0);
         SODBGP_SO(SO_DBGMASK_ABNF_ENC,
                   (soCb.init.prntBuf,
                    "soUtlCpySoSdpEvnt: Encode failed: Error code=%d idNum=%d\n",
                    err.code, err.idNum));
      }
#endif /* DEBUGP */
      SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }
#ifdef DEBUGP
   if (soCb.init.dbgMask & SO_DBGMASK_ABNF_ENC)
   {
      (Void) soUtlPrntMsg(mBuf, "Encoded SDP body", FALSE, 0);
   }
#endif /* DEBUGP */
   /* Add final CRLF */
   ret = SAddPstMsgMult(CRLFStr, 2, mBuf);


   /* DECODE SDP EVENT INTO DST STRUCTRE FROM MBUF */

   /* Allocate memory for SDP event structure */
   ret = soCmCreateSdpEvent(dstSoSdpEvnt);
   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SOLOGERROR(ERRCLS_DEBUG, ESO317, ERRZERO,
                 "soUtlCpySoSdpEvnt: soCmCreateSdpEvent failed to create an "
                 "SDP Event structure");
#endif /* ERRCLASS & ERRCLS_DEBUG */
      RETVALUE(ret);
   }

   /* Attempt to decode SDP part */
   (Void) cmMemset((U8 *)&decOff, 0, sizeof(CmAbnfDecOff));
   (Void) cmMemset((U8 *)&err, 0, sizeof(CmAbnfErr));

   ret = cmAbnfDecPduMsg(CM_ABNF_PROT_SDP,
                         &((*dstSoSdpEvnt)->memCp),
                         (U8 *)&((*dstSoSdpEvnt)->sdp),
                         mBuf,
                         &cmMsgDefSdp,
                         &numSdpBytes,
                         &decOff,
                         &err);
   if (ret == ROK)
   {
#ifdef DEBUGP
      if (soCb.init.dbgMask & SO_DBGMASK_ABNF_DEC)
      {
         (Void) soUtlPrntMsg(mBuf, "soUtlCpySoSdpEvnt: SDP decoded", TRUE,
                            (MsgLen)(numSdpBytes));
      }
#endif /* DEBUGP */
   }
   else
   {
      SODBGP_SO(SO_DBGMASK_ABNF_DEC, (soCb.init.prntBuf,
                "soUtlCpySoSdpEvnt: SDP decode failed: Error=%d, Element=%d",
                err.code, err.idNum));
#ifdef DEBUGP
      if (soCb.init.dbgMask & SO_DBGMASK_ABNF_DEC)
      {
         (Void) soUtlPrntMsg(mBuf, "soUtlCpySoSdpEvnt: SDP decode error", TRUE,

                            (MsgLen)(numSdpBytes));
      }
#endif /* DEBUGP */
      /* so001.102 
       * The task of soUtlCpySoSdpEvnt is to copy the event structure from the
       * source to the destination. If we free dst->memCp, then all the copied
       * event structures will be freed.
       */
      SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }

   SPutMsg(mBuf);

   RETVALUE(ROK);
} /* soUtlCpySoSdpEvnt */
#endif /* CM_SDP_OPAQUE */

/*
*
*       Fun:    soUtlCpyGetMem
*
*       Desc:   Get memory for the copy function
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   sogenutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpyGetMem
(
Ptr         *dstPtr,
U16         memSize,
CmMemListCp *cpyMemCp
)
#else
PUBLIC S16 soUtlCpyGetMem(dstPtr, memSize, cpyMemCp)
Ptr         *dstPtr;
U16         memSize;
CmMemListCp *cpyMemCp;
#endif
{

   TRC2(soUtlCpyGetMem);

   if (cpyMemCp != NULLP)
   {
      if (cmGetMem(cpyMemCp, memSize, dstPtr) != ROK)
      {
         SO_GEN_SMEM_ALARM;
         RETVALUE(RFAILED);
      }
   }
   else
   {
      SOALLOC(dstPtr, memSize);
      if (*dstPtr == NULLP)
      {
         RETVALUE(RFAILED);
      }
   }

   RETVALUE(ROK);
} /* soUtlCpyGetMem */

/*
*
*       Fun:    soUtlCpyTknStrOSXL
*
*       Desc:   Copies the TknStrOSXL struct
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   sogenutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpyTknStrOSXL
(
TknStrOSXL  *dstTknStrOSXL,
TknStrOSXL  *srcTknStrOSXL,
CmMemListCp *cpyMemCp
)
#else
PUBLIC S16 soUtlCpyTknStrOSXL(dstTknStrOSXL, srcTknStrOSXL, cpyMemCp)
TknStrOSXL  *dstTknStrOSXL;
TknStrOSXL  *srcTknStrOSXL;
CmMemListCp *cpyMemCp;
#endif
{
   TRC2(soUtlCpyTknStrOSXL);

   dstTknStrOSXL->pres = srcTknStrOSXL->pres;

   if (srcTknStrOSXL->pres == NOTPRSNT)
      RETVALUE(ROK);

   /* Alloc mem block for val */
   if (srcTknStrOSXL->len > 0)
   {
      dstTknStrOSXL->len = srcTknStrOSXL->len;

      if (soUtlCpyGetMem((Ptr *)&dstTknStrOSXL->val,
                      (U16)(sizeof(U8) * srcTknStrOSXL->len), cpyMemCp) != ROK)
      {
         dstTknStrOSXL->pres = NOTPRSNT;
         dstTknStrOSXL->len = 0;
         RETVALUE(RFAILED);
      }
      cmMemcpy(dstTknStrOSXL->val, srcTknStrOSXL->val,
               srcTknStrOSXL->len);
   }

   RETVALUE(ROK);
} /* soUtlCpyTknStrOSXL */

#ifdef DEBUGP
/*
*
*       Fun:   soUtlPrntMsg
*
*       Desc:  This function is used for debugging purposes to output the
*              contents of an encoded message buffer.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: bytesDec is set to -1 if this message has not been decoded.
*
*       File:  sogenutl.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlPrntMsg
(
Buffer *mBuf,    /* encoded buffer */
Txt    *dbg,     /* debug message  */
U8     rxMsg,    /* TRUE if it is an incoming message */
MsgLen bytesDec  /* bytes decoded  */
)
#else
PUBLIC S16 soUtlPrntMsg(mBuf, dbg, rxMsg, bytesDec)
Buffer *mBuf;     /* encoded buffer */
Txt    *dbg;      /* debug message  */
U8     rxMsg;     /* TRUE if it is an incoming message */
MsgLen bytesDec;  /* bytes decoded  */
#endif
{
   Data    *bufOut;              /* Unpacked message                    */
   U8      ch;                   /* Temporary character                 */
   MsgLen  bufOutLen;            /* Message length                      */
   MsgLen  unpacked;             /* number of bytes unpacked            */
   S16     ret;                  /* value returned by function calls    */
   MsgLen  i;                    /* Index into string                   */
   MsgLen  sLen;                 /* Length of string                    */
   Txt     *pPrintBuf;           /* Pointer to part of string to print  */
   Txt     linePrefix1[10];      /* Line at start of each message       */
   Txt     linePrefix2[10];      /* Index line for message              */
   U8      firstLine;            /* TRUE for 1st line of message        */

   TRC2(soUtlPrntMsg);

   bufOutLen = 0;

   if (rxMsg == TRUE)
   {
      cmMemcpy((U8 *)linePrefix1, (U8 *)"---->", 6);
   }
   else
   {
      cmMemcpy((U8 *)linePrefix1,(U8 *) "<----", 6); 
   }
   cmMemcpy((U8 *)linePrefix2,(U8 *)"     ", 6);
   firstLine = TRUE;

   (Void) SFndLenMsg(mBuf, &bufOutLen);

   if (bufOutLen == 0)
   {
      SPrint(dbg);
      SPrint("\n---- Zero-length message! ----\n");
      RETVALUE(ROK);
   }

   /* Include zero terminator */
   SOALLOC(&bufOut, bufOutLen + 1);
   if (bufOut == NULLP)
   {
      RETVALUE(RFAILED);
   }

   ret = SCpyMsgFix(mBuf, 0, bufOutLen, bufOut, &unpacked);
   bufOutLen++;
   if (ret != ROK)
   {
      SOFREE(bufOut, bufOutLen);
      RETVALUE(ret);
   }

   /* Print debug header if supplied */
   if (dbg != (Txt *) NULLP)
   {
      if (cmStrlen((U8 *)dbg)>0)
      {
         SPrint(dbg);
         SPrint("\n");
      }
   }

   if ((bytesDec == 0) && (rxMsg == TRUE))
   {
      /* Nothing decoded */
      SPrint("*** Message not decoded ***\n");
   }

   sLen      = cmStrlen((U8 *)bufOut);
   /* Remember the beginning of the first line */
   pPrintBuf = (Txt *)bufOut;

   for (i = 0; i < sLen; i++)
   {
      /* Is this a non-printable character ? */
      if ( (bufOut[i] < ' ') || (bufOut[i] >= 127) )
      {
         /* Is this the end of the line ? */
         if (bufOut[i] == '\n')
         {
            /* Terminate the end of the line with string terminator -> \0 */
            bufOut[i] = 0;

            /* Print formatting strings */
            if (firstLine == TRUE)
            {
               SPrint(linePrefix1);
            }
            else
            {
               SPrint(linePrefix2);
            }
            firstLine = FALSE;
            /* Print the line, if string is 1 byte or more */
            if(*pPrintBuf)
               SPrint(pPrintBuf);
            SPrint("\n");
            /* Remember the start of the next line */
            pPrintBuf = (Txt *)&bufOut[i + 1];
         }
         else
         {
            /* Replace Unprintable control character witn '!'*/
            bufOut[i] = '!';
         }
      }
      /* Have we reached the last decoded byte ? */
      if ((rxMsg == TRUE) && (i == (bytesDec-1)) && (bytesDec < (sLen-3)) &&
          (bytesDec > 0))
      {
         /* Print last line before end of bytes decoded */
         if(pPrintBuf != (Txt *)&bufOut[i])
         {
            /* Last line is not empty */
            ch        = bufOut[i];
            bufOut[i] = 0;

            SPrint(pPrintBuf);

            bufOut[i] = ch;
            pPrintBuf = (Txt *)&bufOut[i];
         }
         SPrint("\n");
         SPrint("Undecoded part of message:\n");
      }
   }                                        

   SPrint("\n");

   SOFREE(bufOut, bufOutLen);

   RETVALUE(ROK);
} /* end of soUtlPrntMsg */
#endif /* DEBUGP */


/*
*
*       Fun:    soUtlCpySoExtVal
*
*       Desc:   Copies the SoMethod struct
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  Structure - except for TknStrOSXL - has been copied before
*               calling this function
*
*       File:   so_utl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoExtVal
(
SoExtVal    *dstSoExtVal,
SoExtVal    *srcSoExtVal,
CmMemListCp *cpyMemCp
)
#else
PUBLIC S16 soUtlCpySoExtVal(dstSoExtVal, srcSoExtVal, cpyMemCp)
SoExtVal    *dstSoExtVal;
SoExtVal    *srcSoExtVal;
CmMemListCp *cpyMemCp;
#endif
{
   TRC2(soUtlCpySoExtVal);

   cmMemcpy((U8 *)dstSoExtVal, (U8 *)srcSoExtVal, sizeof(SoExtVal));

   if (srcSoExtVal->type.pres != NOTPRSNT)
   {
      switch (srcSoExtVal->type.val)
      {
         case SO_METHOD_METHODSTD:
            dstSoExtVal->t.std.pres = srcSoExtVal->t.std.pres;
            dstSoExtVal->t.std.val = srcSoExtVal->t.std.val;
            break;
         case SO_METHOD_EXTENSIONMETHOD:
            if (soUtlCpyTknStrOSXL(&dstSoExtVal->t.ext,
                                &srcSoExtVal->t.ext,
                                cpyMemCp) != ROK)
               RETVALUE(RFAILED);
            break;
         default :
            RETVALUE(RFAILED);
            break;
      }
   }

   RETVALUE(ROK);
} /* soUtlCpySoExtVal */


/*
*
*       Fun:    soUtlDelTknStrOSXL
*
*       Desc:   Frees the internal mem for the TknStrOSXL struct
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_utl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelTknStrOSXL
(
TknStrOSXL *delTknStrOSXL
)
#else
PUBLIC S16 soUtlDelTknStrOSXL(delTknStrOSXL)
TknStrOSXL *delTknStrOSXL;
#endif
{
   TRC2(soUtlDelTknStrOSXL);

   if (delTknStrOSXL->pres == NOTPRSNT)
      RETVALUE(ROK);

   if (delTknStrOSXL->len > 0)
      SOFREE(delTknStrOSXL->val, sizeof(U8) * delTknStrOSXL->len);

   delTknStrOSXL->pres = NOTPRSNT;
   delTknStrOSXL->len  = 0;

   RETVALUE(ROK);
} /* soUtlDelTknStrOSXL */


/*
*
*       Fun:    soUtlDelSoExtVal
*
*       Desc:   Frees the internal mem for the SoExtVal struct
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_utl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoExtVal
(
SoExtVal *dst
)
#else
PUBLIC S16 soUtlDelSoExtVal(dst)
SoExtVal *dst;
#endif
{
   TRC2(soUtlDelSoExtVal);

   if (dst->type.pres != NOTPRSNT)
   {
      /* so004.201: Check for non-std */
      if (dst->type.val == SO_EXTVAL_NONSTD)
         soUtlDelTknStrOSXL(&dst->t.ext);
   }

   RETVALUE(ROK);
} /* soUtlDelSoExtVal */


/*
*
*       Fun:    soUtlDelSoBodySinglePart
*
*       Desc:   Frees the internal mem for the SoBodySinglePart struct
*
*       Ret:    ROK     - ok
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_utl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoBodySinglePart
(
SoBodySinglePart *dst
)
#else
PUBLIC S16 soUtlDelSoBodySinglePart(dst)
SoBodySinglePart *dst;
#endif
{
   TRC2(soUtlDelSoBodySinglePart);

   RETVALUE(ROK);
} /* soUtlDelSoBodySinglePart */


/*
*
*       Fun:   soUtlPrcStoreVia
*
*       Desc:  This function stores the Via header(s) in a message in its
*              transaction control block.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes:
*
*       File:  po_core.c
*
*/

#ifdef ANSI
PUBLIC S16 soUtlPrcStoreVia
(
SoVia       *storeVia,  /* Via Structure in CB   */
SoEvnt      *evnt       /* SIP Event             */
)
#else
PUBLIC S16 soUtlPrcStoreVia (storeVia, evnt)
SoVia       *storeVia;  /* Via Structure in CB   */
SoEvnt      *evnt;      /* SIP Event             */
#endif
{
   SoVia             *via;       /* Via structure in message                 */
   SoViaItem         *viaItem;   /* New via item                             */
   U16               i;          /* Index of headers                         */
   U16               j;          /* Index of via header                      */
   U16               viaComp;    /* Number of via headers in message         */
   SoHeaderSeq       *hdrSeq;    /* Header sequence to search                */
   SoHeader          *hdr;       /* Header to check                          */

   U16               totalVia;   /* Total Vias to be copied                  */
   U16               numHdr;     /* Total Headers                            */
   S16               viaCnt;     /* Via Cntr                                 */

   TRC2(soUtlPrcStoreVia);


   /* Locate Via header */
   if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
      hdrSeq = &evnt->t.request.request;
   else
      hdrSeq = &evnt->t.response.response;

   /*------ STEP 1 : Find total Via in the message -------*/
   totalVia = 0;
   numHdr = SO_GET_NUM_COMP(&hdrSeq->numComp);
   for (i = 0; i < numHdr; i++)
   {
      hdr = hdrSeq->header[i];
      if (SO_CMP_TKN_LIT(&hdr->headerType, SO_HEADER_GEN_VIA) == TRUE)
      {
         via = &hdr->t.via;
         totalVia += SO_GET_NUM_COMP(&via->numComp);
      }
   }

   if (totalVia == 0)
      RETVALUE(ROK);

   /*------ STEP 2 : Delete the existing Via elements -------*/
   /* Delete any existing route elements */
   if (soUtlDelSoVia(storeVia) != ROK)
      RETVALUE(RFAILED);

   /*------ STEP 3 : Allocate memory for array of pointer -------*/
   if (soUtlCpyGetMem((Ptr*)&(storeVia->viaItem), (U16)(sizeof(Ptr)*(totalVia)), NULLP) != ROK) 
      goto soUtlCpyErr0;

   /*------ STEP 4 : Copy all Viaitems -------*/
   viaCnt = 0;
   for (i = 0; i < numHdr; i++)
   {
      hdr = hdrSeq->header[i];
      /* Check for Via header */
      if (SO_CMP_TKN_LIT(&hdr->headerType, SO_HEADER_GEN_VIA) == TRUE)
      {
         via = &hdr->t.via;
         viaComp = SO_GET_NUM_COMP(&via->numComp);

         for (j = 0; j < viaComp; j++)
         {
            viaItem = via->viaItem[j];

            if (soUtlCpyGetMem((Ptr*)&(storeVia->viaItem[viaCnt]), sizeof(SoViaItem), NULLP) != ROK) 
               goto soUtlCpyErr1;
            if (soUtlCpySoViaItem(storeVia->viaItem[viaCnt], viaItem, NULLP) != ROK)
               goto soUtlCpyErr2;
            
            viaCnt++;
         }
      }
   }

   /* Everything passed, set numComp */
   storeVia->numComp.pres = PRSNT_NODEF;
   storeVia->numComp.val = totalVia;

   RETVALUE(ROK);

soUtlCpyErr2 :
   SOFREE(storeVia->viaItem[viaCnt], sizeof(SoViaItem));
soUtlCpyErr1 :
   for (viaCnt = viaCnt-1;viaCnt >= 0; viaCnt--)
   {
      soUtlDelSoViaItem(storeVia->viaItem[viaCnt]);
      SOFREE(storeVia->viaItem[viaCnt], sizeof(SoViaItem));
   }
   SOFREE(storeVia->viaItem, sizeof(Ptr)*(totalVia));
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /* end of soPrcStoreVia */


/* Generated Function Declarations start */


/*
*
*    Fun:    soUtlCpySoTransportParam
*
*    Desc:    copy the structure SoTransportParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoTransportParam
(
SoTransportParam *dst,
SoTransportParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoTransportParam(dst, src, mem)
SoTransportParam *dst;
SoTransportParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoTransportParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoTransportParam));

   if (soUtlCpyTknStrOSXL(&dst->otherTransport, &src->otherTransport, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlCpySoTransportParam*/

/*
*
*    Fun:    soUtlCpySoUserParam
*
*    Desc:    copy the structure SoUserParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoUserParam
(
SoUserParam *dst,
SoUserParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoUserParam(dst, src, mem)
SoUserParam *dst;
SoUserParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoUserParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoUserParam));

   if (soUtlCpyTknStrOSXL(&dst->otherUser, &src->otherUser, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlCpySoUserParam*/

/*
*
*    Fun:    soUtlCpySoNameVal
*
*    Desc:    copy the structure SoNameVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoNameVal
(
SoNameVal *dst,
SoNameVal *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoNameVal(dst, src, mem)
SoNameVal *dst;
SoNameVal *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoNameVal)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoNameVal));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpyTknStrOSXL(&dst->name, &src->name, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpyTknStrOSXL(&dst->value, &src->value, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->name);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoNameVal*/

/*
*
*    Fun:    soUtlCpySoHost
*
*    Desc:    copy the structure SoHost
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoHost
(
SoHost *dst,
SoHost *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoHost(dst, src, mem)
SoHost *dst;
SoHost *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoHost)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoHost));

   if( src->hostType.pres != NOTPRSNT )
   {
      switch( src->hostType.val )
      {
         case  SO_HOST_HOSTNAME :
            if (soUtlCpyTknStrOSXL(&dst->t.hostName, &src->t.hostName, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HOST_IPV4ADDRESS :
            break;
         case  SO_HOST_IPV6REFERENCE :
            if (soUtlCpyTknStrOSXL(&dst->t.ipv6Reference, &src->t.ipv6Reference, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoHost*/

/*
*
*    Fun:    soUtlCpySoStrValue
*
*    Desc:    copy the structure SoStrValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoStrValue
(
SoStrValue *dst,
SoStrValue *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoStrValue(dst, src, mem)
SoStrValue *dst;
SoStrValue *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoStrValue)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoStrValue));

   if( src->valueType.pres != NOTPRSNT )
   {
      if (soUtlCpyTknStrOSXL(&dst->value, &src->value, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoStrValue*/

/*
*
*    Fun:    soUtlCpySoUrlParameter
*
*    Desc:    copy the structure SoUrlParameter
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoUrlParameter
(
SoUrlParameter *dst,
SoUrlParameter *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoUrlParameter(dst, src, mem)
SoUrlParameter *dst;
SoUrlParameter *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoUrlParameter)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoUrlParameter));

   if( src->urlParameterType.pres != NOTPRSNT )
   {
      switch( src->urlParameterType.val )
      {
         case  SO_URLPARAMETER_COMP :
            if (soUtlCpySoStrValue(&dst->t.comp, &src->t.comp, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_URLPARAMETER_ISUB :
#ifdef SO_ENUM
            if (soUtlCpyTknStrOSXL(&dst->t.isub, &src->t.isub, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_ENUM  */
            break;
         case  SO_URLPARAMETER_LRPARAM :
            break;
         case  SO_URLPARAMETER_MADDRHOST :
            if (soUtlCpySoHost(&dst->t.maddrHost, &src->t.maddrHost, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_URLPARAMETER_METHOD :
            if (soUtlCpySoExtVal(&dst->t.method, &src->t.method, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_URLPARAMETER_OTHERPARAM :
            if (soUtlCpySoNameVal(&dst->t.otherParam, &src->t.otherParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_URLPARAMETER_PHONECONTEXT :
#ifdef SO_ENUM
            if (soUtlCpyTknStrOSXL(&dst->t.phoneContext, &src->t.phoneContext, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_ENUM  */
            break;
         case  SO_URLPARAMETER_POSTD :
#ifdef SO_ENUM
            if (soUtlCpyTknStrOSXL(&dst->t.postd, &src->t.postd, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_ENUM  */
            break;
         case  SO_URLPARAMETER_TRANSPORTPARAM :
            if (soUtlCpySoTransportParam(&dst->t.transportParam, &src->t.transportParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_URLPARAMETER_TSPDOMAIN :
#ifdef SO_PINT
            if (soUtlCpySoHost(&dst->t.tspDomain, &src->t.tspDomain, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_PINT  */
            break;
         case  SO_URLPARAMETER_TTLPARAM :
            break;
         case  SO_URLPARAMETER_USERPARAM :
            if (soUtlCpySoUserParam(&dst->t.userParam, &src->t.userParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoUrlParameter*/

/*
*
*    Fun:    soUtlCpySoHeaderExt
*
*    Desc:    copy the structure SoHeaderExt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoHeaderExt
(
SoHeaderExt *dst,
SoHeaderExt *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoHeaderExt(dst, src, mem)
SoHeaderExt *dst;
SoHeaderExt *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoHeaderExt)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoHeaderExt));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->header), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->header[i]), sizeof(SoNameVal), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoNameVal(dst->header[i], src->header[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->header[i], sizeof(SoNameVal));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoNameVal(dst->header[i]);
         SOFREE(dst->header[i], sizeof(SoNameVal));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->header, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoHeaderExt*/

/*
*
*    Fun:    soUtlCpySoUserInfo
*
*    Desc:    copy the structure SoUserInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoUserInfo
(
SoUserInfo *dst,
SoUserInfo *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoUserInfo(dst, src, mem)
SoUserInfo *dst;
SoUserInfo *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoUserInfo)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoUserInfo));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoStrValue(&dst->userType, &src->userType, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpyTknStrOSXL(&dst->password, &src->password, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoStrValue(&dst->userType);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoUserInfo*/

/*
*
*    Fun:    soUtlCpySoHeaders
*
*    Desc:    copy the structure SoHeaders
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoHeaders
(
SoHeaders *dst,
SoHeaders *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoHeaders(dst, src, mem)
SoHeaders *dst;
SoHeaders *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoHeaders)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoHeaders));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoNameVal(&dst->header, &src->header, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoHeaderExt(&dst->headerExt, &src->headerExt, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoNameVal(&dst->header);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoHeaders*/

/*
*
*    Fun:    soUtlCpySoTknStrOSXLLst
*
*    Desc:    copy the structure SoTknStrOSXLLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoTknStrOSXLLst
(
SoTknStrOSXLLst *dst,
SoTknStrOSXLLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoTknStrOSXLLst(dst, src, mem)
SoTknStrOSXLLst *dst;
SoTknStrOSXLLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoTknStrOSXLLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoTknStrOSXLLst));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->stringList), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->stringList[i]), sizeof(TknStrOSXL), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpyTknStrOSXL(dst->stringList[i], src->stringList[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->stringList[i], sizeof(TknStrOSXL));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelTknStrOSXL(dst->stringList[i]);
         SOFREE(dst->stringList[i], sizeof(TknStrOSXL));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->stringList, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoTknStrOSXLLst*/

/*
*
*    Fun:    soUtlCpySoHostPort
*
*    Desc:    copy the structure SoHostPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoHostPort
(
SoHostPort *dst,
SoHostPort *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoHostPort(dst, src, mem)
SoHostPort *dst;
SoHostPort *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoHostPort)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoHostPort));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoHost(&dst->host, &src->host, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoHostPort*/

/*
*
*    Fun:    soUtlCpySoUrlParameters
*
*    Desc:    copy the structure SoUrlParameters
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoUrlParameters
(
SoUrlParameters *dst,
SoUrlParameters *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoUrlParameters(dst, src, mem)
SoUrlParameters *dst;
SoUrlParameters *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoUrlParameters)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoUrlParameters));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->urlParameter), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->urlParameter[i]), sizeof(SoUrlParameter), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoUrlParameter(dst->urlParameter[i], src->urlParameter[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->urlParameter[i], sizeof(SoUrlParameter));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoUrlParameter(dst->urlParameter[i]);
         SOFREE(dst->urlParameter[i], sizeof(SoUrlParameter));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->urlParameter, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoUrlParameters*/

/*
*
*    Fun:    soUtlCpySoParameter
*
*    Desc:    copy the structure SoParameter
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoParameter
(
SoParameter *dst,
SoParameter *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoParameter(dst, src, mem)
SoParameter *dst;
SoParameter *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoParameter)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoParameter));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpyTknStrOSXL(&dst->token, &src->token, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoStrValue(&dst->paramVal, &src->paramVal, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->token);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoParameter*/

/*
*
*    Fun:    soUtlCpySoTypeSub
*
*    Desc:    copy the structure SoTypeSub
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoTypeSub
(
SoTypeSub *dst,
SoTypeSub *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoTypeSub(dst, src, mem)
SoTypeSub *dst;
SoTypeSub *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoTypeSub)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoTypeSub));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpyTknStrOSXL(&dst->type, &src->type, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpyTknStrOSXL(&dst->subType, &src->subType, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->type);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoTypeSub*/

/*
*
*    Fun:    soUtlCpySoMediaRangeVal
*
*    Desc:    copy the structure SoMediaRangeVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoMediaRangeVal
(
SoMediaRangeVal *dst,
SoMediaRangeVal *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoMediaRangeVal(dst, src, mem)
SoMediaRangeVal *dst;
SoMediaRangeVal *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoMediaRangeVal)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoMediaRangeVal));

   if( src->mediaRangeValType.pres != NOTPRSNT )
   {
      switch( src->mediaRangeValType.val )
      {
         case  SO_MEDIARANGEVAL_ALLSTAR :
            break;
         case  SO_MEDIARANGEVAL_TYPESTAR :
            if (soUtlCpyTknStrOSXL(&dst->t.typeStar, &src->t.typeStar, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_MEDIARANGEVAL_TYPESUB :
            if (soUtlCpySoTypeSub(&dst->t.typeSub, &src->t.typeSub, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoMediaRangeVal*/


/*
*
*    Fun:    soUtlCpySoCallInfoPurpose
*
*    Desc:    copy the structure SoCallInfoPurpose
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoCallInfoPurpose
(
SoCallInfoPurpose *dst,
SoCallInfoPurpose *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoCallInfoPurpose(dst, src, mem)
SoCallInfoPurpose *dst;
SoCallInfoPurpose *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoCallInfoPurpose)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoCallInfoPurpose));

   if (soUtlCpyTknStrOSXL(&dst->purposeExt, &src->purposeExt, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlCpySoCallInfoPurpose*/

/*
*
*    Fun:    soUtlCpySoSubscExpReason
*
*    Desc:    copy the structure SoSubscExpReason
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSubscExpReason
(
SoSubscExpReason *dst,
SoSubscExpReason *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSubscExpReason(dst, src, mem)
SoSubscExpReason *dst;
SoSubscExpReason *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoSubscExpReason)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSubscExpReason));

   if (soUtlCpyTknStrOSXL(&dst->subscExpReasonExt, &src->subscExpReasonExt, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlCpySoSubscExpReason*/

/*
*
*    Fun:    soUtlCpySoDisplayName
*
*    Desc:    copy the structure SoDisplayName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoDisplayName
(
SoDisplayName *dst,
SoDisplayName *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoDisplayName(dst, src, mem)
SoDisplayName *dst;
SoDisplayName *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoDisplayName)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoDisplayName));

   if( src->displayNameType.pres != NOTPRSNT )
   {
      switch( src->displayNameType.val )
      {
         case  SO_PARAMVAL_QUOTEDSTR :
            if (soUtlCpyTknStrOSXL(&dst->t.quotedStr, &src->t.quotedStr, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_PARAMVAL_TOKEN :
            if (soUtlCpySoTknStrOSXLLst(&dst->t.displayNameRep, &src->t.displayNameRep, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoDisplayName*/

/*
*
*    Fun:    soUtlCpySoAbsoluteUri
*
*    Desc:    copy the structure SoAbsoluteUri
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAbsoluteUri
(
SoAbsoluteUri *dst,
SoAbsoluteUri *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAbsoluteUri(dst, src, mem)
SoAbsoluteUri *dst;
SoAbsoluteUri *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoAbsoluteUri)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAbsoluteUri));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpyTknStrOSXL(&dst->scheme, &src->scheme, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpyTknStrOSXL(&dst->absUriDesc, &src->absUriDesc, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->scheme);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAbsoluteUri*/
#ifdef SO_ENUM

/*
*
*    Fun:    soUtlCpySoTelNumPar
*
*    Desc:    copy the structure SoTelNumPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoTelNumPar
(
SoTelNumPar *dst,
SoTelNumPar *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoTelNumPar(dst, src, mem)
SoTelNumPar *dst;
SoTelNumPar *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoTelNumPar)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoTelNumPar));

   if( src->type.pres != NOTPRSNT )
   {
      switch( src->type.val )
      {
         case  SO_TEL_CIC :
            if (soUtlCpyTknStrOSXL(&dst->t.cic, &src->t.cic, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_TEL_EXTN :
            if (soUtlCpySoParameter(&dst->t.extn, &src->t.extn, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_TEL_ISUB :
            if (soUtlCpyTknStrOSXL(&dst->t.isub, &src->t.isub, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_TEL_PHONE_CONTEXT :
            if (soUtlCpyTknStrOSXL(&dst->t.phCntxt, &src->t.phCntxt, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_TEL_POSTD :
            if (soUtlCpyTknStrOSXL(&dst->t.postd, &src->t.postd, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_TEL_RN :
            if (soUtlCpyTknStrOSXL(&dst->t.rn, &src->t.rn, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_TEL_TSP :
            if (soUtlCpySoHost(&dst->t.tsp, &src->t.tsp, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoTelNumPar*/

/*
*
*    Fun:    soUtlCpySoTelNumPars
*
*    Desc:    copy the structure SoTelNumPars
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoTelNumPars
(
SoTelNumPars *dst,
SoTelNumPars *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoTelNumPars(dst, src, mem)
SoTelNumPars *dst;
SoTelNumPars *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoTelNumPars)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoTelNumPars));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->par), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->par[i]), sizeof(SoTelNumPar), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoTelNumPar(dst->par[i], src->par[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->par[i], sizeof(SoTelNumPar));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoTelNumPar(dst->par[i]);
         SOFREE(dst->par[i], sizeof(SoTelNumPar));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->par, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoTelNumPars*/

/*
*
*    Fun:    soUtlCpySoTelUrl
*
*    Desc:    copy the structure SoTelUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoTelUrl
(
SoTelUrl *dst,
SoTelUrl *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoTelUrl(dst, src, mem)
SoTelUrl *dst;
SoTelUrl *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoTelUrl)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoTelUrl));

   if (soUtlCpyTknStrOSXL(&dst->digits, &src->digits, mem) != ROK)
      goto soUtlCpyErr0;
   if (soUtlCpySoTelNumPars(&dst->pars, &src->pars, mem) != ROK)
      goto soUtlCpyErr1;
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->digits);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoTelUrl*/
#endif /* SO_ENUM */

/*
*
*    Fun:    soUtlCpySoPriority
*
*    Desc:    copy the structure SoPriority
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoPriority
(
SoPriority *dst,
SoPriority *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoPriority(dst, src, mem)
SoPriority *dst;
SoPriority *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoPriority)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoPriority));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpyTknStrOSXL(&dst->otherPriority, &src->otherPriority, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoPriority*/

/*
*
*    Fun:    soUtlCpySoSipUrl
*
*    Desc:    copy the structure SoSipUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSipUrl
(
SoSipUrl *dst,
SoSipUrl *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSipUrl(dst, src, mem)
SoSipUrl *dst;
SoSipUrl *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoSipUrl)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSipUrl));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoUserInfo(&dst->userInfo, &src->userInfo, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoHostPort(&dst->hostPort, &src->hostPort, mem) != ROK)
         goto soUtlCpyErr1;
      if (soUtlCpySoUrlParameters(&dst->urlParameters, &src->urlParameters, mem) != ROK)
         goto soUtlCpyErr2;
      if (soUtlCpySoHeaders(&dst->headers, &src->headers, mem) != ROK)
         goto soUtlCpyErr3;
   }
   RETVALUE(ROK);
soUtlCpyErr3 :
   if (mem == NULLP)
   {
      soUtlDelSoUrlParameters(&dst->urlParameters);
   }
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      soUtlDelSoHostPort(&dst->hostPort);
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoUserInfo(&dst->userInfo);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoSipUrl*/

/*
*
*    Fun:    soUtlCpySoAddrSpec
*
*    Desc:    copy the structure SoAddrSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAddrSpec
(
SoAddrSpec *dst,
SoAddrSpec *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAddrSpec(dst, src, mem)
SoAddrSpec *dst;
SoAddrSpec *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoAddrSpec)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAddrSpec));

   if( src->addrSpecType.pres != NOTPRSNT )
   {
      switch( src->addrSpecType.val )
      {
         case  SO_ADDRSPEC_ABSOLUTEURI :
            if (soUtlCpySoAbsoluteUri(&dst->t.absoluteUri, &src->t.absoluteUri, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_ADDRSPEC_IMURL :
#ifdef SO_INSTMSG
            if (soUtlCpySoSipUrl(&dst->t.imUrl, &src->t.imUrl, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_INSTMSG  */
            break;
         case  SO_ADDRSPEC_SIPSURL :
#ifdef SO_TLS
            if (soUtlCpySoSipUrl(&dst->t.sipsUrl, &src->t.sipsUrl, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_TLS  */
            break;
         case  SO_ADDRSPEC_SIPURL :
            if (soUtlCpySoSipUrl(&dst->t.sipUrl, &src->t.sipUrl, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_ADDRSPEC_TELURL :
#ifdef SO_ENUM
            if (soUtlCpySoTelUrl(&dst->t.telUrl, &src->t.telUrl, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_ENUM  */
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoAddrSpec*/

/*
*
*    Fun:    soUtlCpySoContactParam
*
*    Desc:    copy the structure SoContactParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoContactParam
(
SoContactParam *dst,
SoContactParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoContactParam(dst, src, mem)
SoContactParam *dst;
SoContactParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoContactParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoContactParam));

   if( src->contactParamType.pres != NOTPRSNT )
   {
      switch( src->contactParamType.val )
      {
         case  SO_CONTACTPARAM_EXTN :
            if (soUtlCpySoParameter(&dst->t.genericParam, &src->t.genericParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_CONTACTPARAM_FEAT :
#ifdef SO_CALLERPREF
            if (soUtlCpySoStrValue(&dst->t.fparam, &src->t.fparam, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_CONTACTPARAM_STD :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoContactParam*/

/*
*
*    Fun:    soUtlCpySoInfoParam
*
*    Desc:    copy the structure SoInfoParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoInfoParam
(
SoInfoParam *dst,
SoInfoParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoInfoParam(dst, src, mem)
SoInfoParam *dst;
SoInfoParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoInfoParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoInfoParam));

   if( src->infoParamType.pres != NOTPRSNT )
   {
      switch( src->infoParamType.val )
      {
         case  SO_INFOPARAM_EXTN :
            if (soUtlCpySoParameter(&dst->t.genericParam, &src->t.genericParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_INFOPARAM_PURPOSE :
            if (soUtlCpySoCallInfoPurpose(&dst->t.callInfoPurpose, &src->t.callInfoPurpose, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoInfoParam*/

/*
*
*    Fun:    soUtlCpySoNameAddr
*
*    Desc:    copy the structure SoNameAddr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoNameAddr
(
SoNameAddr *dst,
SoNameAddr *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoNameAddr(dst, src, mem)
SoNameAddr *dst;
SoNameAddr *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoNameAddr)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoNameAddr));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoDisplayName(&dst->displayName, &src->displayName, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoAddrSpec(&dst->addrSpec, &src->addrSpec, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoDisplayName(&dst->displayName);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoNameAddr*/

/*
*
*    Fun:    soUtlCpySoContactParams
*
*    Desc:    copy the structure SoContactParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoContactParams
(
SoContactParams *dst,
SoContactParams *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoContactParams(dst, src, mem)
SoContactParams *dst;
SoContactParams *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoContactParams)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoContactParams));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->contactParam), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->contactParam[i]), sizeof(SoContactParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoContactParam(dst->contactParam[i], src->contactParam[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->contactParam[i], sizeof(SoContactParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoContactParam(dst->contactParam[i]);
         SOFREE(dst->contactParam[i], sizeof(SoContactParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->contactParam, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoContactParams*/

/*
*
*    Fun:    soUtlCpySoViaParam
*
*    Desc:    copy the structure SoViaParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoViaParam
(
SoViaParam *dst,
SoViaParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoViaParam(dst, src, mem)
SoViaParam *dst;
SoViaParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoViaParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoViaParam));

   if( src->viaParamType.pres != NOTPRSNT )
   {
      switch( src->viaParamType.val )
      {
         case  SO_VIAPARAM_GENERICPARAM :
            if (soUtlCpySoParameter(&dst->t.genericParam, &src->t.genericParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_VIAPARAM_MADDR :
            if (soUtlCpySoHost(&dst->t.maddr, &src->t.maddr, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_VIAPARAM_RECEIVED :
            if (soUtlCpySoHost(&dst->t.received, &src->t.received, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_VIAPARAM_VIABRANCH :
            if (soUtlCpyTknStrOSXL(&dst->t.viaBranch, &src->t.viaBranch, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_VIAPARAM_VIACOMP :
            if (soUtlCpySoStrValue(&dst->t.comp, &src->t.comp, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_VIAPARAM_VIARPORT :
#ifdef SO_NAT
#endif /*  SO_NAT  */
            break;
         case  SO_VIAPARAM_VIATTL :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoViaParam*/

/*
*
*    Fun:    soUtlCpySoParameters
*
*    Desc:    copy the structure SoParameters
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoParameters
(
SoParameters *dst,
SoParameters *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoParameters(dst, src, mem)
SoParameters *dst;
SoParameters *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoParameters)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoParameters));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->parameter), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->parameter[i]), sizeof(SoParameter), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoParameter(dst->parameter[i], src->parameter[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->parameter[i], sizeof(SoParameter));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoParameter(dst->parameter[i]);
         SOFREE(dst->parameter[i], sizeof(SoParameter));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->parameter, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoParameters*/

/*
*
*    Fun:    soUtlCpySoProtocolName
*
*    Desc:    copy the structure SoProtocolName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoProtocolName
(
SoProtocolName *dst,
SoProtocolName *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoProtocolName(dst, src, mem)
SoProtocolName *dst;
SoProtocolName *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoProtocolName)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoProtocolName));

   if (soUtlCpyTknStrOSXL(&dst->protocolExt, &src->protocolExt, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlCpySoProtocolName*/

/*
*
*    Fun:    soUtlCpySoMediaRange
*
*    Desc:    copy the structure SoMediaRange
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoMediaRange
(
SoMediaRange *dst,
SoMediaRange *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoMediaRange(dst, src, mem)
SoMediaRange *dst;
SoMediaRange *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoMediaRange)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoMediaRange));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoMediaRangeVal(&dst->mediaRangeVal, &src->mediaRangeVal, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoParameters(&dst->parameters, &src->parameters, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoMediaRangeVal(&dst->mediaRangeVal);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoMediaRange*/

/*
*
*    Fun:    soUtlCpySoCodings
*
*    Desc:    copy the structure SoCodings
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoCodings
(
SoCodings *dst,
SoCodings *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoCodings(dst, src, mem)
SoCodings *dst;
SoCodings *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoCodings)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoCodings));

   if (soUtlCpySoExtVal(&dst->contentCoding, &src->contentCoding, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlCpySoCodings*/

/*
*
*    Fun:    soUtlCpySoInfoParams
*
*    Desc:    copy the structure SoInfoParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoInfoParams
(
SoInfoParams *dst,
SoInfoParams *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoInfoParams(dst, src, mem)
SoInfoParams *dst;
SoInfoParams *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoInfoParams)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoInfoParams));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->infoParam), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->infoParam[i]), sizeof(SoInfoParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoInfoParam(dst->infoParam[i], src->infoParam[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->infoParam[i], sizeof(SoInfoParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoInfoParam(dst->infoParam[i]);
         SOFREE(dst->infoParam[i], sizeof(SoInfoParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->infoParam, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoInfoParams*/

/*
*
*    Fun:    soUtlCpySoAddrCh
*
*    Desc:    copy the structure SoAddrCh
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAddrCh
(
SoAddrCh *dst,
SoAddrCh *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAddrCh(dst, src, mem)
SoAddrCh *dst;
SoAddrCh *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoAddrCh)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAddrCh));

   if( src->addrChType.pres != NOTPRSNT )
   {
      switch( src->addrChType.val )
      {
         case  SO_ADDRCH_ADDRSPEC :
            if (soUtlCpySoAddrSpec(&dst->t.addrSpec, &src->t.addrSpec, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_ADDRCH_NAMEADDR :
            if (soUtlCpySoNameAddr(&dst->t.nameAddr, &src->t.nameAddr, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoAddrCh*/

/*
*
*    Fun:    soUtlCpySoContactItem
*
*    Desc:    copy the structure SoContactItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoContactItem
(
SoContactItem *dst,
SoContactItem *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoContactItem(dst, src, mem)
SoContactItem *dst;
SoContactItem *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoContactItem)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoContactItem));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoAddrCh(&dst->contactAddrChoice, &src->contactAddrChoice, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoContactParams(&dst->contactParams, &src->contactParams, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoAddrCh(&dst->contactAddrChoice);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoContactItem*/

/*
*
*    Fun:    soUtlCpySoAddrParam
*
*    Desc:    copy the structure SoAddrParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAddrParam
(
SoAddrParam *dst,
SoAddrParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAddrParam(dst, src, mem)
SoAddrParam *dst;
SoAddrParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoAddrParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAddrParam));

   if( src->addrParamType.pres != NOTPRSNT )
   {
      switch( src->addrParamType.val )
      {
         case  SO_ADDRPARAM_GENERICPARAM :
            if (soUtlCpySoParameter(&dst->t.genericParam, &src->t.genericParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_ADDRPARAM_TAGPARAM :
            if (soUtlCpyTknStrOSXL(&dst->t.tagParam, &src->t.tagParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoAddrParam*/

/*
*
*    Fun:    soUtlCpySoAlso
*
*    Desc:    copy the structure SoAlso
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAlso
(
SoAlso *dst,
SoAlso *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAlso(dst, src, mem)
SoAlso *dst;
SoAlso *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoAlso)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAlso));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->addrChoice), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->addrChoice[i]), sizeof(SoAddrCh), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoAddrCh(dst->addrChoice[i], src->addrChoice[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->addrChoice[i], sizeof(SoAddrCh));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoAddrCh(dst->addrChoice[i]);
         SOFREE(dst->addrChoice[i], sizeof(SoAddrCh));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->addrChoice, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAlso*/

/*
*
*    Fun:    soUtlCpySoSentProtocol
*
*    Desc:    copy the structure SoSentProtocol
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSentProtocol
(
SoSentProtocol *dst,
SoSentProtocol *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSentProtocol(dst, src, mem)
SoSentProtocol *dst;
SoSentProtocol *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoSentProtocol)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSentProtocol));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoProtocolName(&dst->protocolName, &src->protocolName, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpyTknStrOSXL(&dst->protocolVersion, &src->protocolVersion, mem) != ROK)
         goto soUtlCpyErr1;
      if (soUtlCpySoExtVal(&dst->transport, &src->transport, mem) != ROK)
         goto soUtlCpyErr2;
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->protocolVersion);
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoProtocolName(&dst->protocolName);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoSentProtocol*/

/*
*
*    Fun:    soUtlCpySoHostPortType
*
*    Desc:    copy the structure SoHostPortType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoHostPortType
(
SoHostPortType *dst,
SoHostPortType *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoHostPortType(dst, src, mem)
SoHostPortType *dst;
SoHostPortType *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoHostPortType)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoHostPortType));

   if( src->type.pres != NOTPRSNT )
   {
      switch( src->type.val )
      {
         case  SO_HOSTPORTTYPE_HOST :
            if (soUtlCpyTknStrOSXL(&dst->t.host, &src->t.host, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HOSTPORTTYPE_HOSTPORT :
            if (soUtlCpySoHostPort(&dst->t.hostPort, &src->t.hostPort, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoHostPortType*/

/*
*
*    Fun:    soUtlCpySoViaParams
*
*    Desc:    copy the structure SoViaParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoViaParams
(
SoViaParams *dst,
SoViaParams *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoViaParams(dst, src, mem)
SoViaParams *dst;
SoViaParams *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoViaParams)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoViaParams));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->viaParam), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->viaParam[i]), sizeof(SoViaParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoViaParam(dst->viaParam[i], src->viaParam[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->viaParam[i], sizeof(SoViaParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoViaParam(dst->viaParam[i]);
         SOFREE(dst->viaParam[i], sizeof(SoViaParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->viaParam, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoViaParams*/

/*
*
*    Fun:    soUtlCpySoRetryParam
*
*    Desc:    copy the structure SoRetryParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRetryParam
(
SoRetryParam *dst,
SoRetryParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRetryParam(dst, src, mem)
SoRetryParam *dst;
SoRetryParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoRetryParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRetryParam));

   if( src->retryParamType.pres != NOTPRSNT )
   {
      switch( src->retryParamType.val )
      {
         case  SO_RETRYPARAM_DURATION :
            break;
         case  SO_RETRYPARAM_EXTN :
            if (soUtlCpySoParameter(&dst->t.genericParam, &src->t.genericParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoRetryParam*/

/*
*
*    Fun:    soUtlCpySoAcceptParam
*
*    Desc:    copy the structure SoAcceptParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAcceptParam
(
SoAcceptParam *dst,
SoAcceptParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAcceptParam(dst, src, mem)
SoAcceptParam *dst;
SoAcceptParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoAcceptParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAcceptParam));

   if( src->prodcomType.pres != NOTPRSNT )
   {
      switch( src->prodcomType.val )
      {
         case  SO_GENERIC_PARAM_TYPE :
            if (soUtlCpySoParameter(&dst->u.genericParam, &src->u.genericParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_QVALUE_TYPE :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoAcceptParam*/

/*
*
*    Fun:    soUtlCpySoAcceptParams
*
*    Desc:    copy the structure SoAcceptParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAcceptParams
(
SoAcceptParams *dst,
SoAcceptParams *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAcceptParams(dst, src, mem)
SoAcceptParams *dst;
SoAcceptParams *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoAcceptParams)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAcceptParams));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->ap), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->ap[i]), sizeof(SoAcceptParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoAcceptParam(dst->ap[i], src->ap[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->ap[i], sizeof(SoAcceptParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoAcceptParam(dst->ap[i]);
         SOFREE(dst->ap[i], sizeof(SoAcceptParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->ap, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAcceptParams*/

/*
*
*    Fun:    soUtlCpySoAcceptSeq
*
*    Desc:    copy the structure SoAcceptSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAcceptSeq
(
SoAcceptSeq *dst,
SoAcceptSeq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAcceptSeq(dst, src, mem)
SoAcceptSeq *dst;
SoAcceptSeq *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoAcceptSeq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAcceptSeq));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoMediaRange(&dst->mediaRange, &src->mediaRange, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoAcceptParams(&dst->acceptParams, &src->acceptParams, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoMediaRange(&dst->mediaRange);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAcceptSeq*/

/*
*
*    Fun:    soUtlCpySoAcceptEncodingSeq
*
*    Desc:    copy the structure SoAcceptEncodingSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAcceptEncodingSeq
(
SoAcceptEncodingSeq *dst,
SoAcceptEncodingSeq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAcceptEncodingSeq(dst, src, mem)
SoAcceptEncodingSeq *dst;
SoAcceptEncodingSeq *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoAcceptEncodingSeq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAcceptEncodingSeq));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoCodings(&dst->codings, &src->codings, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoAcceptParams(&dst->apList, &src->apList, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoCodings(&dst->codings);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAcceptEncodingSeq*/

/*
*
*    Fun:    soUtlCpySoAcceptLanguageSeq
*
*    Desc:    copy the structure SoAcceptLanguageSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAcceptLanguageSeq
(
SoAcceptLanguageSeq *dst,
SoAcceptLanguageSeq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAcceptLanguageSeq(dst, src, mem)
SoAcceptLanguageSeq *dst;
SoAcceptLanguageSeq *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoAcceptLanguageSeq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAcceptLanguageSeq));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpyTknStrOSXL(&dst->languageRange, &src->languageRange, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoAcceptParams(&dst->acceptParams, &src->acceptParams, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->languageRange);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAcceptLanguageSeq*/

/*
*
*    Fun:    soUtlCpySoContactItems
*
*    Desc:    copy the structure SoContactItems
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoContactItems
(
SoContactItems *dst,
SoContactItems *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoContactItems(dst, src, mem)
SoContactItems *dst;
SoContactItems *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoContactItems)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoContactItems));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->contactItem), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->contactItem[i]), sizeof(SoContactItem), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoContactItem(dst->contactItem[i], src->contactItem[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->contactItem[i], sizeof(SoContactItem));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoContactItem(dst->contactItem[i]);
         SOFREE(dst->contactItem[i], sizeof(SoContactItem));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->contactItem, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoContactItems*/

/*
*
*    Fun:    soUtlCpySoProdcom
*
*    Desc:    copy the structure SoProdcom
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoProdcom
(
SoProdcom *dst,
SoProdcom *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoProdcom(dst, src, mem)
SoProdcom *dst;
SoProdcom *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoProdcom)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoProdcom));

   if( src->prodcomType.pres != NOTPRSNT )
   {
      switch( src->prodcomType.val )
      {
         case  SO_PRODCOM_COMMENT :
            if (soUtlCpyTknStrOSXL(&dst->t.comment, &src->t.comment, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_PRODCOM_PRODUCT :
            if (soUtlCpySoNameVal(&dst->t.product, &src->t.product, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoProdcom*/

/*
*
*    Fun:    soUtlCpySoViaItem
*
*    Desc:    copy the structure SoViaItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoViaItem
(
SoViaItem *dst,
SoViaItem *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoViaItem(dst, src, mem)
SoViaItem *dst;
SoViaItem *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoViaItem)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoViaItem));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoSentProtocol(&dst->sentProtocol, &src->sentProtocol, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoHostPortType(&dst->sentBy, &src->sentBy, mem) != ROK)
         goto soUtlCpyErr1;
      if (soUtlCpySoViaParams(&dst->viaParams, &src->viaParams, mem) != ROK)
         goto soUtlCpyErr2;
      if (soUtlCpyTknStrOSXL(&dst->viaComment, &src->viaComment, mem) != ROK)
         goto soUtlCpyErr3;
   }
   RETVALUE(ROK);
soUtlCpyErr3 :
   if (mem == NULLP)
   {
      soUtlDelSoViaParams(&dst->viaParams);
   }
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      soUtlDelSoHostPortType(&dst->sentBy);
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoSentProtocol(&dst->sentProtocol);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoViaItem*/

/*
*
*    Fun:    soUtlCpySoRouteSeq
*
*    Desc:    copy the structure SoRouteSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRouteSeq
(
SoRouteSeq *dst,
SoRouteSeq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRouteSeq(dst, src, mem)
SoRouteSeq *dst;
SoRouteSeq *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoRouteSeq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRouteSeq));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoNameAddr(&dst->nameAddr, &src->nameAddr, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoParameters(&dst->rParams, &src->rParams, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoNameAddr(&dst->nameAddr);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRouteSeq*/

/*
*
*    Fun:    soUtlCpySoWarningItem
*
*    Desc:    copy the structure SoWarningItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoWarningItem
(
SoWarningItem *dst,
SoWarningItem *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoWarningItem(dst, src, mem)
SoWarningItem *dst;
SoWarningItem *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoWarningItem)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoWarningItem));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpyTknStrOSXL(&dst->warnAgent, &src->warnAgent, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpyTknStrOSXL(&dst->warnText, &src->warnText, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->warnAgent);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoWarningItem*/

/*
*
*    Fun:    soUtlCpySoAccept
*
*    Desc:    copy the structure SoAccept
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAccept
(
SoAccept *dst,
SoAccept *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAccept(dst, src, mem)
SoAccept *dst;
SoAccept *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoAccept)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAccept));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->accept), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->accept[i]), sizeof(SoAcceptSeq), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoAcceptSeq(dst->accept[i], src->accept[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->accept[i], sizeof(SoAcceptSeq));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoAcceptSeq(dst->accept[i]);
         SOFREE(dst->accept[i], sizeof(SoAcceptSeq));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->accept, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAccept*/

/*
*
*    Fun:    soUtlCpySoAcceptEncoding
*
*    Desc:    copy the structure SoAcceptEncoding
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAcceptEncoding
(
SoAcceptEncoding *dst,
SoAcceptEncoding *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAcceptEncoding(dst, src, mem)
SoAcceptEncoding *dst;
SoAcceptEncoding *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoAcceptEncoding)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAcceptEncoding));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->acceptEncoding), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->acceptEncoding[i]), sizeof(SoAcceptEncodingSeq), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoAcceptEncodingSeq(dst->acceptEncoding[i], src->acceptEncoding[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->acceptEncoding[i], sizeof(SoAcceptEncodingSeq));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoAcceptEncodingSeq(dst->acceptEncoding[i]);
         SOFREE(dst->acceptEncoding[i], sizeof(SoAcceptEncodingSeq));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->acceptEncoding, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAcceptEncoding*/

/*
*
*    Fun:    soUtlCpySoAcceptLanguage
*
*    Desc:    copy the structure SoAcceptLanguage
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAcceptLanguage
(
SoAcceptLanguage *dst,
SoAcceptLanguage *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAcceptLanguage(dst, src, mem)
SoAcceptLanguage *dst;
SoAcceptLanguage *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoAcceptLanguage)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAcceptLanguage));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->acceptLanguage), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->acceptLanguage[i]), sizeof(SoAcceptLanguageSeq), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoAcceptLanguageSeq(dst->acceptLanguage[i], src->acceptLanguage[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->acceptLanguage[i], sizeof(SoAcceptLanguageSeq));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoAcceptLanguageSeq(dst->acceptLanguage[i]);
         SOFREE(dst->acceptLanguage[i], sizeof(SoAcceptLanguageSeq));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->acceptLanguage, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAcceptLanguage*/
#ifdef SO_EVENT

/*
*
*    Fun:    soUtlCpySoEventHeader
*
*    Desc:    copy the structure SoEventHeader
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoEventHeader
(
SoEventHeader *dst,
SoEventHeader *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoEventHeader(dst, src, mem)
SoEventHeader *dst;
SoEventHeader *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoEventHeader)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoEventHeader));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpyTknStrOSXL(&dst->eventName, &src->eventName, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoParameters(&dst->params, &src->params, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->eventName);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoEventHeader*/

#endif /* SO_EVENT */

/*
*
*    Fun:    soUtlCpySoCallInfoSeq
*
*    Desc:    copy the structure SoCallInfoSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoCallInfoSeq
(
SoCallInfoSeq *dst,
SoCallInfoSeq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoCallInfoSeq(dst, src, mem)
SoCallInfoSeq *dst;
SoCallInfoSeq *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoCallInfoSeq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoCallInfoSeq));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoAbsoluteUri(&dst->absoluteUri, &src->absoluteUri, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoInfoParams(&dst->infoParams, &src->infoParams, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoAbsoluteUri(&dst->absoluteUri);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoCallInfoSeq*/

/*
*
*    Fun:    soUtlCpySoCallInfo
*
*    Desc:    copy the structure SoCallInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoCallInfo
(
SoCallInfo *dst,
SoCallInfo *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoCallInfo(dst, src, mem)
SoCallInfo *dst;
SoCallInfo *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoCallInfo)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoCallInfo));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->callInfo), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->callInfo[i]), sizeof(SoCallInfoSeq), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoCallInfoSeq(dst->callInfo[i], src->callInfo[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->callInfo[i], sizeof(SoCallInfoSeq));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoCallInfoSeq(dst->callInfo[i]);
         SOFREE(dst->callInfo[i], sizeof(SoCallInfoSeq));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->callInfo, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoCallInfo*/

/*
*
*    Fun:    soUtlCpySoInfoSeq
*
*    Desc:    copy the structure SoInfoSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoInfoSeq
(
SoInfoSeq *dst,
SoInfoSeq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoInfoSeq(dst, src, mem)
SoInfoSeq *dst;
SoInfoSeq *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoInfoSeq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoInfoSeq));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoAbsoluteUri(&dst->absoluteUri, &src->absoluteUri, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoParameters(&dst->genericParams, &src->genericParams, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoAbsoluteUri(&dst->absoluteUri);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoInfoSeq*/

/*
*
*    Fun:    soUtlCpySoInfo
*
*    Desc:    copy the structure SoInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoInfo
(
SoInfo *dst,
SoInfo *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoInfo(dst, src, mem)
SoInfo *dst;
SoInfo *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoInfo)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoInfo));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->info), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->info[i]), sizeof(SoInfoSeq), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoInfoSeq(dst->info[i], src->info[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->info[i], sizeof(SoInfoSeq));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoInfoSeq(dst->info[i]);
         SOFREE(dst->info[i], sizeof(SoInfoSeq));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->info, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoInfo*/

/*
*
*    Fun:    soUtlCpySoAddrParams
*
*    Desc:    copy the structure SoAddrParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAddrParams
(
SoAddrParams *dst,
SoAddrParams *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAddrParams(dst, src, mem)
SoAddrParams *dst;
SoAddrParams *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoAddrParams)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAddrParams));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->addrParam), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->addrParam[i]), sizeof(SoAddrParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoAddrParam(dst->addrParam[i], src->addrParam[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->addrParam[i], sizeof(SoAddrParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoAddrParam(dst->addrParam[i]);
         SOFREE(dst->addrParam[i], sizeof(SoAddrParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->addrParam, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAddrParams*/

/*
*
*    Fun:    soUtlCpySoRoute
*
*    Desc:    copy the structure SoRoute
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRoute
(
SoRoute *dst,
SoRoute *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRoute(dst, src, mem)
SoRoute *dst;
SoRoute *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoRoute)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRoute));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->route), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->route[i]), sizeof(SoRouteSeq), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoRouteSeq(dst->route[i], src->route[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->route[i], sizeof(SoRouteSeq));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoRouteSeq(dst->route[i]);
         SOFREE(dst->route[i], sizeof(SoRouteSeq));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->route, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRoute*/

/*
*
*    Fun:    soUtlCpySoDispositionParam
*
*    Desc:    copy the structure SoDispositionParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoDispositionParam
(
SoDispositionParam *dst,
SoDispositionParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoDispositionParam(dst, src, mem)
SoDispositionParam *dst;
SoDispositionParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoDispositionParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoDispositionParam));

   if( src->dispositionParamType.pres != NOTPRSNT )
   {
      switch( src->dispositionParamType.val )
      {
         case  SO_DISP_PARAM_EXTN :
            if (soUtlCpySoParameter(&dst->t.parameter, &src->t.parameter, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_DISP_PARAM_HANDLING :
            if (soUtlCpySoExtVal(&dst->t.handlingParmVal, &src->t.handlingParmVal, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoDispositionParam*/

/*
*
*    Fun:    soUtlCpySoDispositionParams
*
*    Desc:    copy the structure SoDispositionParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoDispositionParams
(
SoDispositionParams *dst,
SoDispositionParams *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoDispositionParams(dst, src, mem)
SoDispositionParams *dst;
SoDispositionParams *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoDispositionParams)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoDispositionParams));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->dispositionParam), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->dispositionParam[i]), sizeof(SoDispositionParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoDispositionParam(dst->dispositionParam[i], src->dispositionParam[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->dispositionParam[i], sizeof(SoDispositionParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoDispositionParam(dst->dispositionParam[i]);
         SOFREE(dst->dispositionParam[i], sizeof(SoDispositionParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->dispositionParam, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoDispositionParams*/

/*
*
*    Fun:    soUtlCpySoAllow
*
*    Desc:    copy the structure SoAllow
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAllow
(
SoAllow *dst,
SoAllow *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAllow(dst, src, mem)
SoAllow *dst;
SoAllow *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoAllow)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAllow));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->method), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->method[i]), sizeof(SoExtVal), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoExtVal(dst->method[i], src->method[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->method[i], sizeof(SoExtVal));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoExtVal(dst->method[i]);
         SOFREE(dst->method[i], sizeof(SoExtVal));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->method, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAllow*/

/*
*
*    Fun:    soUtlCpySoContentDisposition
*
*    Desc:    copy the structure SoContentDisposition
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoContentDisposition
(
SoContentDisposition *dst,
SoContentDisposition *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoContentDisposition(dst, src, mem)
SoContentDisposition *dst;
SoContentDisposition *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoContentDisposition)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoContentDisposition));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoStrValue(&dst->type, &src->type, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoDispositionParams(&dst->params, &src->params, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoStrValue(&dst->type);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoContentDisposition*/

/*
*
*    Fun:    soUtlCpySoRetryParams
*
*    Desc:    copy the structure SoRetryParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRetryParams
(
SoRetryParams *dst,
SoRetryParams *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRetryParams(dst, src, mem)
SoRetryParams *dst;
SoRetryParams *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoRetryParams)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRetryParams));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->retryParam), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->retryParam[i]), sizeof(SoRetryParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoRetryParam(dst->retryParam[i], src->retryParam[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->retryParam[i], sizeof(SoRetryParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoRetryParam(dst->retryParam[i]);
         SOFREE(dst->retryParam[i], sizeof(SoRetryParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->retryParam, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRetryParams*/

/*
*
*    Fun:    soUtlCpySoProdcomLst
*
*    Desc:    copy the structure SoProdcomLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoProdcomLst
(
SoProdcomLst *dst,
SoProdcomLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoProdcomLst(dst, src, mem)
SoProdcomLst *dst;
SoProdcomLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoProdcomLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoProdcomLst));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->prodcom), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->prodcom[i]), sizeof(SoProdcom), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoProdcom(dst->prodcom[i], src->prodcom[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->prodcom[i], sizeof(SoProdcom));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoProdcom(dst->prodcom[i]);
         SOFREE(dst->prodcom[i], sizeof(SoProdcom));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->prodcom, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoProdcomLst*/

/*
*
*    Fun:    soUtlCpySoWarning
*
*    Desc:    copy the structure SoWarning
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoWarning
(
SoWarning *dst,
SoWarning *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoWarning(dst, src, mem)
SoWarning *dst;
SoWarning *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoWarning)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoWarning));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->warningItem), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->warningItem[i]), sizeof(SoWarningItem), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoWarningItem(dst->warningItem[i], src->warningItem[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->warningItem[i], sizeof(SoWarningItem));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoWarningItem(dst->warningItem[i]);
         SOFREE(dst->warningItem[i], sizeof(SoWarningItem));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->warningItem, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoWarning*/

/*
*
*    Fun:    soUtlCpySoContact
*
*    Desc:    copy the structure SoContact
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoContact
(
SoContact *dst,
SoContact *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoContact(dst, src, mem)
SoContact *dst;
SoContact *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoContact)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoContact));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoContactItems(&dst->contactItems, &src->contactItems, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoContact*/

/*
*
*    Fun:    soUtlCpySoCSeq
*
*    Desc:    copy the structure SoCSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoCSeq
(
SoCSeq *dst,
SoCSeq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoCSeq(dst, src, mem)
SoCSeq *dst;
SoCSeq *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoCSeq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoCSeq));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoExtVal(&dst->method, &src->method, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoCSeq*/

/*
*
*    Fun:    soUtlCpySoAddress
*
*    Desc:    copy the structure SoAddress
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAddress
(
SoAddress *dst,
SoAddress *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAddress(dst, src, mem)
SoAddress *dst;
SoAddress *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoAddress)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAddress));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoAddrCh(&dst->addrCh, &src->addrCh, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoAddrParams(&dst->addrParams, &src->addrParams, mem) != ROK)
         goto soUtlCpyErr1;
   }
   
   RETVALUE(ROK);

soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoAddrCh(&dst->addrCh);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAddress*/

/*
*
*    Fun:    soUtlCpySoVia
*
*    Desc:    copy the structure SoVia
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoVia
(
SoVia *dst,
SoVia *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoVia(dst, src, mem)
SoVia *dst;
SoVia *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoVia)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoVia));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->viaItem), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->viaItem[i]), sizeof(SoViaItem), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoViaItem(dst->viaItem[i], src->viaItem[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->viaItem[i], sizeof(SoViaItem));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoViaItem(dst->viaItem[i]);
         SOFREE(dst->viaItem[i], sizeof(SoViaItem));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->viaItem, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoVia*/

/*
*
*    Fun:    soUtlCpySoAuthorization
*
*    Desc:    copy the structure SoAuthorization
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAuthorization
(
SoAuthorization *dst,
SoAuthorization *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAuthorization(dst, src, mem)
SoAuthorization *dst;
SoAuthorization *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoAuthorization)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAuthorization));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpyTknStrOSXL(&dst->authScheme, &src->authScheme, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoParameters(&dst->authParams, &src->authParams, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->authScheme);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAuthorization*/

/*
*
*    Fun:    soUtlCpySoAuthenticate
*
*    Desc:    copy the structure SoAuthenticate
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAuthenticate
(
SoAuthenticate *dst,
SoAuthenticate *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAuthenticate(dst, src, mem)
SoAuthenticate *dst;
SoAuthenticate *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoAuthenticate)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAuthenticate));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->challenge), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->challenge[i]), sizeof(SoAuthorization), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoAuthorization(dst->challenge[i], src->challenge[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->challenge[i], sizeof(SoAuthorization));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoAuthorization(dst->challenge[i]);
         SOFREE(dst->challenge[i], sizeof(SoAuthorization));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->challenge, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAuthenticate*/

/*
*
*    Fun:    soUtlCpySoReplyTo
*
*    Desc:    copy the structure SoReplyTo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoReplyTo
(
SoReplyTo *dst,
SoReplyTo *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoReplyTo(dst, src, mem)
SoReplyTo *dst;
SoReplyTo *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoReplyTo)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoReplyTo));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoAddrCh(&dst->addr, &src->addr, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoParameters(&dst->params, &src->params, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoAddrCh(&dst->addr);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoReplyTo*/

/*
*
*    Fun:    soUtlCpySoContentEncoding
*
*    Desc:    copy the structure SoContentEncoding
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoContentEncoding
(
SoContentEncoding *dst,
SoContentEncoding *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoContentEncoding(dst, src, mem)
SoContentEncoding *dst;
SoContentEncoding *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoContentEncoding)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoContentEncoding));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->contentCoding), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->contentCoding[i]), sizeof(SoExtVal), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoExtVal(dst->contentCoding[i], src->contentCoding[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->contentCoding[i], sizeof(SoExtVal));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoExtVal(dst->contentCoding[i]);
         SOFREE(dst->contentCoding[i], sizeof(SoExtVal));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->contentCoding, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoContentEncoding*/

/*
*
*    Fun:    soUtlCpySoContentTypeHdr
*
*    Desc:    copy the structure SoContentTypeHdr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoContentTypeHdr
(
SoContentTypeHdr *dst,
SoContentTypeHdr *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoContentTypeHdr(dst, src, mem)
SoContentTypeHdr *dst;
SoContentTypeHdr *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoContentTypeHdr)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoContentTypeHdr));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoStrValue(&dst->type, &src->type, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoStrValue(&dst->subType, &src->subType, mem) != ROK)
         goto soUtlCpyErr1;
      if (soUtlCpySoParameters(&dst->parameters, &src->parameters, mem) != ROK)
         goto soUtlCpyErr2;
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      soUtlDelSoStrValue(&dst->subType);
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoStrValue(&dst->type);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoContentTypeHdr*/

/*
*
*    Fun:    soUtlCpySoRetryAfter
*
*    Desc:    copy the structure SoRetryAfter
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRetryAfter
(
SoRetryAfter *dst,
SoRetryAfter *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRetryAfter(dst, src, mem)
SoRetryAfter *dst;
SoRetryAfter *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoRetryAfter)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRetryAfter));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpyTknStrOSXL(&dst->retryAfterComment, &src->retryAfterComment, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoRetryParams(&dst->retryParams, &src->retryParams, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->retryAfterComment);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRetryAfter*/

/*
*
*    Fun:    soUtlCpySoRAck
*
*    Desc:    copy the structure SoRAck
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRAck
(
SoRAck *dst,
SoRAck *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRAck(dst, src, mem)
SoRAck *dst;
SoRAck *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoRAck)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRAck));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoExtVal(&dst->method, &src->method, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoRAck*/
#ifdef SO_REFER

/*
*
*    Fun:    soUtlCpySoReferTo
*
*    Desc:    copy the structure SoReferTo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoReferTo
(
SoReferTo *dst,
SoReferTo *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoReferTo(dst, src, mem)
SoReferTo *dst;
SoReferTo *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoReferTo)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoReferTo));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoAddrCh(&dst->addr, &src->addr, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoParameters(&dst->params, &src->params, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoAddrCh(&dst->addr);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoReferTo*/

/*
*
*    Fun:    soUtlCpySoReferredByParam
*
*    Desc:    copy the structure SoReferredByParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoReferredByParam
(
SoReferredByParam *dst,
SoReferredByParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoReferredByParam(dst, src, mem)
SoReferredByParam *dst;
SoReferredByParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoReferredByParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoReferredByParam));

   if( src->type.pres != NOTPRSNT )
   {
      switch( src->type.val )
      {
         case  SO_RF_BY_GENERIC_PARAM :
            if (soUtlCpySoParameter(&dst->t.genericParam, &src->t.genericParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_RF_BY_ID_PAR :
            if (soUtlCpyTknStrOSXL(&dst->t.cid, &src->t.cid, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoReferredByParam*/

/*
*
*    Fun:    soUtlCpySoReferredByParams
*
*    Desc:    copy the structure SoReferredByParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoReferredByParams
(
SoReferredByParams *dst,
SoReferredByParams *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoReferredByParams(dst, src, mem)
SoReferredByParams *dst;
SoReferredByParams *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoReferredByParams)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoReferredByParams));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->soRefrdByPar), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->soRefrdByPar[i]), sizeof(SoReferredByParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoReferredByParam(dst->soRefrdByPar[i], src->soRefrdByPar[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->soRefrdByPar[i], sizeof(SoReferredByParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoReferredByParam(dst->soRefrdByPar[i]);
         SOFREE(dst->soRefrdByPar[i], sizeof(SoReferredByParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->soRefrdByPar, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoReferredByParams*/

/*
*
*    Fun:    soUtlCpySoReferredBy
*
*    Desc:    copy the structure SoReferredBy
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoReferredBy
(
SoReferredBy *dst,
SoReferredBy *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoReferredBy(dst, src, mem)
SoReferredBy *dst;
SoReferredBy *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoReferredBy)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoReferredBy));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoAddrCh(&dst->referredUrl, &src->referredUrl, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoReferredByParams(&dst->refrdByPar, &src->refrdByPar, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoAddrCh(&dst->referredUrl);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoReferredBy*/

/*
*
*    Fun:    soUtlCpySoReplacesParam
*
*    Desc:    copy the structure SoReplacesParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoReplacesParam
(
SoReplacesParam *dst,
SoReplacesParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoReplacesParam(dst, src, mem)
SoReplacesParam *dst;
SoReplacesParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoReplacesParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoReplacesParam));

   if( src->paramType.pres != NOTPRSNT )
   {
      switch( src->paramType.val )
      {
         case  SO_REPLACES_GENERIC_PARAMS :
            if (soUtlCpySoParameter(&dst->u.genericParams, &src->u.genericParams, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_REPLACES_PARAMTYPE_FROMTAG :
            if (soUtlCpyTknStrOSXL(&dst->u.fromTag, &src->u.fromTag, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_REPLACES_PARAMTYPE_TOTAG :
            if (soUtlCpyTknStrOSXL(&dst->u.toTag, &src->u.toTag, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_REPLACES_PARAMTYPE_EARLYONLY :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoReplacesParam*/

/*
*
*    Fun:    soUtlCpySoReplacesParams
*
*    Desc:    copy the structure SoReplacesParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoReplacesParams
(
SoReplacesParams *dst,
SoReplacesParams *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoReplacesParams(dst, src, mem)
SoReplacesParams *dst;
SoReplacesParams *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoReplacesParams)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoReplacesParams));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->replacesParam), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->replacesParam[i]), sizeof(SoReplacesParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoReplacesParam(dst->replacesParam[i], src->replacesParam[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->replacesParam[i], sizeof(SoReplacesParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoReplacesParam(dst->replacesParam[i]);
         SOFREE(dst->replacesParam[i], sizeof(SoReplacesParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->replacesParam, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoReplacesParams*/

/*
*
*    Fun:    soUtlCpySoReplaces
*
*    Desc:    copy the structure SoReplaces
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoReplaces
(
SoReplaces *dst,
SoReplaces *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoReplaces(dst, src, mem)
SoReplaces *dst;
SoReplaces *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoReplaces)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoReplaces));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpyTknStrOSXL(&dst->callId, &src->callId, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoReplacesParams(&dst->replacesParams, &src->replacesParams, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->callId);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoReplaces*/
#endif /* SO_REFER */
#ifdef SO_SESSTIMER

/*
*
*    Fun:    soUtlCpySoSessExpParam
*
*    Desc:    copy the structure SoSessExpParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSessExpParam
(
SoSessExpParam *dst,
SoSessExpParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSessExpParam(dst, src, mem)
SoSessExpParam *dst;
SoSessExpParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoSessExpParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSessExpParam));

   if( src->type.pres != NOTPRSNT )
   {
      switch( src->type.val )
      {
         case  SO_SESSION_EXP_EXTN :
            if (soUtlCpySoParameter(&dst->u.param, &src->u.param, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_SESSION_EXP_REFRESHER :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoSessExpParam*/

/*
*
*    Fun:    soUtlCpySoSessExpParams
*
*    Desc:    copy the structure SoSessExpParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSessExpParams
(
SoSessExpParams *dst,
SoSessExpParams *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSessExpParams(dst, src, mem)
SoSessExpParams *dst;
SoSessExpParams *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoSessExpParams)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSessExpParams));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->param), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->param[i]), sizeof(SoSessExpParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoSessExpParam(dst->param[i], src->param[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->param[i], sizeof(SoSessExpParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoSessExpParam(dst->param[i]);
         SOFREE(dst->param[i], sizeof(SoSessExpParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->param, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoSessExpParams*/

/*
*
*    Fun:    soUtlCpySoSessionExpires
*
*    Desc:    copy the structure SoSessionExpires
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSessionExpires
(
SoSessionExpires *dst,
SoSessionExpires *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSessionExpires(dst, src, mem)
SoSessionExpires *dst;
SoSessionExpires *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoSessionExpires)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSessionExpires));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoSessExpParams(&dst->params, &src->params, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoSessionExpires*/

/*
*
*    Fun:    soUtlCpySoMinSE
*
*    Desc:    copy the structure SoMinSE
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoMinSE
(
SoMinSE *dst,
SoMinSE *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoMinSE(dst, src, mem)
SoMinSE *dst;
SoMinSE *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoMinSE)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoMinSE));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoParameters(&dst->params, &src->params, mem) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoMinSE*/
#endif /* SO_SESSIONTIMER */
#ifdef SO_CALLERPREF

/*
*
*    Fun:    soUtlCpySoRequestDispositionParam
*
*    Desc:    copy the structure SoRequestDispositionParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRequestDispositionParam
(
SoRequestDispositionParam *dst,
SoRequestDispositionParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRequestDispositionParam(dst, src, mem)
SoRequestDispositionParam *dst;
SoRequestDispositionParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoRequestDispositionParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRequestDispositionParam));

   RETVALUE(ROK);
} /*end of function soUtlCpySoRequestDispositionParam*/

/*
*
*    Fun:    soUtlCpySoRequestDisposition
*
*    Desc:    copy the structure SoRequestDisposition
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRequestDisposition
(
SoRequestDisposition *dst,
SoRequestDisposition *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRequestDisposition(dst, src, mem)
SoRequestDisposition *dst;
SoRequestDisposition *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoRequestDisposition)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRequestDisposition));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->requestDispositionParams), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->requestDispositionParams[i]), sizeof(SoRequestDispositionParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoRequestDispositionParam(dst->requestDispositionParams[i], src->requestDispositionParams[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->requestDispositionParams[i], sizeof(SoRequestDispositionParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoRequestDispositionParam(dst->requestDispositionParams[i]);
         SOFREE(dst->requestDispositionParams[i], sizeof(SoRequestDispositionParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->requestDispositionParams, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRequestDisposition*/


/*
*
*    Fun:    soUtlCpySoAcParam
*
*    Desc:    copy the structure SoAcParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAcParam
(
SoAcParam *dst,
SoAcParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAcParam(dst, src, mem)
SoAcParam *dst;
SoAcParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoAcParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAcParam));

   if( src->type.pres != NOTPRSNT )
   {
      switch( src->type.val )
      {
         case  SO_ACCEPTCONTACT_PAR_EXPLICIT :
            break;
         case  SO_ACCEPTCONTACT_PAR_EXTN :
            if (soUtlCpySoParameter(&dst->u.genericParam, &src->u.genericParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_ACCEPTCONTACT_PAR_FP :
            if (soUtlCpySoStrValue(&dst->u.fparam, &src->u.fparam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_ACCEPTCONTACT_PAR_REQUIRE :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoAcParam*/

/*
*
*    Fun:    soUtlCpySoAcParams
*
*    Desc:    copy the structure SoAcParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAcParams
(
SoAcParams *dst,
SoAcParams *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAcParams(dst, src, mem)
SoAcParams *dst;
SoAcParams *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoAcParams)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAcParams));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->acParam), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->acParam[i]), sizeof(SoAcParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoAcParam(dst->acParam[i], src->acParam[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->acParam[i], sizeof(SoAcParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoAcParam(dst->acParam[i]);
         SOFREE(dst->acParam[i], sizeof(SoAcParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->acParam, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAcParams*/

/*
*
*    Fun:    soUtlCpySoAcceptContact
*
*    Desc:    copy the structure SoAcceptContact
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAcceptContact
(
SoAcceptContact *dst,
SoAcceptContact *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAcceptContact(dst, src, mem)
SoAcceptContact *dst;
SoAcceptContact *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoAcceptContact)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAcceptContact));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->acParams), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->acParams[i]), sizeof(SoAcParams), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoAcParams(dst->acParams[i], src->acParams[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->acParams[i], sizeof(SoAcParams));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoAcParams(dst->acParams[i]);
         SOFREE(dst->acParams[i], sizeof(SoAcParams));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->acParams, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoAcceptContact*/

/*
*
*    Fun:    soUtlCpySoRcParam
*
*    Desc:    copy the structure SoRcParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRcParam
(
SoRcParam *dst,
SoRcParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRcParam(dst, src, mem)
SoRcParam *dst;
SoRcParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoRcParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRcParam));

   if( src->type.pres != NOTPRSNT )
   {
      switch( src->type.val )
      {
         case  SO_REJECTCONTACT_PAR_EXTN :
            if (soUtlCpySoParameter(&dst->u.genericParam, &src->u.genericParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_REJECTCONTACT_PAR_FP :
            if (soUtlCpySoStrValue(&dst->u.fparam, &src->u.fparam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoRcParam*/

/*
*
*    Fun:    soUtlCpySoRcParams
*
*    Desc:    copy the structure SoRcParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRcParams
(
SoRcParams *dst,
SoRcParams *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRcParams(dst, src, mem)
SoRcParams *dst;
SoRcParams *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoRcParams)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRcParams));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->rcParam), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->rcParam[i]), sizeof(SoRcParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoRcParam(dst->rcParam[i], src->rcParam[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->rcParam[i], sizeof(SoRcParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoRcParam(dst->rcParam[i]);
         SOFREE(dst->rcParam[i], sizeof(SoRcParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->rcParam, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRcParams*/

/*
*
*    Fun:    soUtlCpySoRejectContact
*
*    Desc:    copy the structure SoRejectContact
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRejectContact
(
SoRejectContact *dst,
SoRejectContact *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRejectContact(dst, src, mem)
SoRejectContact *dst;
SoRejectContact *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoRejectContact)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRejectContact));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->rcParams), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->rcParams[i]), sizeof(SoRcParams), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoRcParams(dst->rcParams[i], src->rcParams[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->rcParams[i], sizeof(SoRcParams));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoRcParams(dst->rcParams[i]);
         SOFREE(dst->rcParams[i], sizeof(SoRcParams));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->rcParams, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRejectContact*/
#endif /* SO_CALLERPREF */

/*
*
*    Fun:    soUtlCpySoTypeVal
*
*    Desc:    copy the structure SoTypeVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoTypeVal
(
SoTypeVal *dst,
SoTypeVal *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoTypeVal(dst, src, mem)
SoTypeVal *dst;
SoTypeVal *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoTypeVal)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoTypeVal));

   if (soUtlCpySoStrValue(&dst->type, &src->type, mem) != ROK)
      goto soUtlCpyErr0;
   if (soUtlCpySoStrValue(&dst->val, &src->val, mem) != ROK)
      goto soUtlCpyErr1;
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoStrValue(&dst->type);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoTypeVal*/

/*
*
*    Fun:    soUtlCpySoPrivLst
*
*    Desc:    copy the structure SoPrivLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoPrivLst
(
SoPrivLst *dst,
SoPrivLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoPrivLst(dst, src, mem)
SoPrivLst *dst;
SoPrivLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoPrivLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoPrivLst));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->privVal), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->privVal[i]), sizeof(SoTypeVal), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoTypeVal(dst->privVal[i], src->privVal[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->privVal[i], sizeof(SoTypeVal));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoTypeVal(dst->privVal[i]);
         SOFREE(dst->privVal[i], sizeof(SoTypeVal));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->privVal, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoPrivLst*/

/*
*
*    Fun:    soUtlCpySoRpiTok
*
*    Desc:    copy the structure SoRpiTok
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRpiTok
(
SoRpiTok *dst,
SoRpiTok *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRpiTok(dst, src, mem)
SoRpiTok *dst;
SoRpiTok *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoRpiTok)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRpiTok));

   if( src->type.pres != NOTPRSNT )
   {
      switch( src->type.val )
      {
         case  SO_RPI_ID_TYPE :
            if (soUtlCpySoStrValue(&dst->u.id, &src->u.id, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_RPI_OTHER_RPI_TOKEN :
            if (soUtlCpySoTypeVal(&dst->u.othRpi, &src->u.othRpi, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_RPI_PRIVACY :
            if (soUtlCpySoPrivLst(&dst->u.prvLst, &src->u.prvLst, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_RPI_PTY_TYPE :
            if (soUtlCpySoStrValue(&dst->u.party, &src->u.party, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_RPI_SCREEN :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoRpiTok*/

/*
*
*    Fun:    soUtlCpySoRpiTokLst
*
*    Desc:    copy the structure SoRpiTokLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRpiTokLst
(
SoRpiTokLst *dst,
SoRpiTokLst *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRpiTokLst(dst, src, mem)
SoRpiTokLst *dst;
SoRpiTokLst *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoRpiTokLst)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRpiTokLst));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->rpiTok), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->rpiTok[i]), sizeof(SoRpiTok), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoRpiTok(dst->rpiTok[i], src->rpiTok[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->rpiTok[i], sizeof(SoRpiTok));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoRpiTok(dst->rpiTok[i]);
         SOFREE(dst->rpiTok[i], sizeof(SoRpiTok));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->rpiTok, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRpiTokLst*/

/*
*
*    Fun:    soUtlCpySoRpid
*
*    Desc:    copy the structure SoRpid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRpid
(
SoRpid *dst,
SoRpid *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRpid(dst, src, mem)
SoRpid *dst;
SoRpid *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoRpid)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRpid));

   if (soUtlCpySoNameAddr(&dst->nameAddr, &src->nameAddr, mem) != ROK)
      goto soUtlCpyErr0;
   if (soUtlCpySoRpiTokLst(&dst->rpiTokLst, &src->rpiTokLst, mem) != ROK)
      goto soUtlCpyErr1;
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoNameAddr(&dst->nameAddr);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRpid*/

/*
*
*    Fun:    soUtlCpySoRemPartyId
*
*    Desc:    copy the structure SoRemPartyId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRemPartyId
(
SoRemPartyId *dst,
SoRemPartyId *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRemPartyId(dst, src, mem)
SoRemPartyId *dst;
SoRemPartyId *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoRemPartyId)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRemPartyId));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->rpidLst), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->rpidLst[i]), sizeof(SoRpid), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoRpid(dst->rpidLst[i], src->rpidLst[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->rpidLst[i], sizeof(SoRpid));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoRpid(dst->rpidLst[i]);
         SOFREE(dst->rpidLst[i], sizeof(SoRpid));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->rpidLst, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRemPartyId*/

/*
*
*    Fun:    soUtlCpySoRpidPrivcy
*
*    Desc:    copy the structure SoRpidPrivcy
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRpidPrivcy
(
SoRpidPrivcy *dst,
SoRpidPrivcy *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRpidPrivcy(dst, src, mem)
SoRpidPrivcy *dst;
SoRpidPrivcy *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoRpidPrivcy)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRpidPrivcy));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->rpidPriv), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->rpidPriv[i]), sizeof(SoRpiTokLst), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoRpiTokLst(dst->rpidPriv[i], src->rpidPriv[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->rpidPriv[i], sizeof(SoRpiTokLst));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoRpiTokLst(dst->rpidPriv[i]);
         SOFREE(dst->rpidPriv[i], sizeof(SoRpiTokLst));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->rpidPriv, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRpidPrivcy*/
#ifdef SO_EVENT

/*
*
*    Fun:    soUtlCpySoSubExpParam
*
*    Desc:    copy the structure SoSubExpParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSubExpParam
(
SoSubExpParam *dst,
SoSubExpParam *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSubExpParam(dst, src, mem)
SoSubExpParam *dst;
SoSubExpParam *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoSubExpParam)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSubExpParam));

   if( src->type.pres != NOTPRSNT )
   {
      switch( src->type.val )
      {
         case  SO_SUB_EXP_PAR_EXPIRES :
            break;
         case  SO_SUB_EXP_PAR_GENERIC_PARAM :
            if (soUtlCpySoParameter(&dst->u.genericParam, &src->u.genericParam, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_SUB_EXP_PAR_REASON :
            if (soUtlCpySoStrValue(&dst->u.reason, &src->u.reason, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_SUB_EXP_PAR_RETRY_AFT :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoSubExpParam*/

/*
*
*    Fun:    soUtlCpySoSubExpParams
*
*    Desc:    copy the structure SoSubExpParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSubExpParams
(
SoSubExpParams *dst,
SoSubExpParams *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSubExpParams(dst, src, mem)
SoSubExpParams *dst;
SoSubExpParams *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoSubExpParams)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSubExpParams));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->subExpParamList), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->subExpParamList[i]), sizeof(SoSubExpParam), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoSubExpParam(dst->subExpParamList[i], src->subExpParamList[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->subExpParamList[i], sizeof(SoSubExpParam));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoSubExpParam(dst->subExpParamList[i]);
         SOFREE(dst->subExpParamList[i], sizeof(SoSubExpParam));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->subExpParamList, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoSubExpParams*/

/*
*
*    Fun:    soUtlCpySoSubscState
*
*    Desc:    copy the structure SoSubscState
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSubscState
(
SoSubscState *dst,
SoSubscState *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSubscState(dst, src, mem)
SoSubscState *dst;
SoSubscState *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoSubscState)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSubscState));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoStrValue(&dst->subVal, &src->subVal, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoSubExpParams(&dst->subExpParams, &src->subExpParams, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoStrValue(&dst->subVal);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoSubscState*/
#endif /* SO_EVENT */

/*
*
*    Fun:    soUtlCpySoMechPar
*
*    Desc:    copy the structure SoMechPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoMechPar
(
SoMechPar *dst,
SoMechPar *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoMechPar(dst, src, mem)
SoMechPar *dst;
SoMechPar *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoMechPar)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoMechPar));

   if( src->mechParamType.pres != NOTPRSNT )
   {
      switch( src->mechParamType.val )
      {
         case  SO_MECH_PAR_DG_ALG :
            if (soUtlCpyTknStrOSXL(&dst->u.dgAlg, &src->u.dgAlg, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_MECH_PAR_DG_QOP :
            if (soUtlCpyTknStrOSXL(&dst->u.dgQop, &src->u.dgQop, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_MECH_PAR_DG_VERIFY :
            if (soUtlCpyTknStrOSXL(&dst->u.dgVerify, &src->u.dgVerify, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_MECH_PAR_EXTN :
            if (soUtlCpySoParameter(&dst->u.ext, &src->u.ext, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_MECH_PAR_PREF :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoMechPar*/

/*
*
*    Fun:    soUtlCpySoMechPars
*
*    Desc:    copy the structure SoMechPars
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoMechPars
(
SoMechPars *dst,
SoMechPars *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoMechPars(dst, src, mem)
SoMechPars *dst;
SoMechPars *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoMechPars)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoMechPars));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->mechPar), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->mechPar[i]), sizeof(SoMechPar), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoMechPar(dst->mechPar[i], src->mechPar[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->mechPar[i], sizeof(SoMechPar));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoMechPar(dst->mechPar[i]);
         SOFREE(dst->mechPar[i], sizeof(SoMechPar));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->mechPar, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoMechPars*/

/*
*
*    Fun:    soUtlCpySoSecMech
*
*    Desc:    copy the structure SoSecMech
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSecMech
(
SoSecMech *dst,
SoSecMech *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSecMech(dst, src, mem)
SoSecMech *dst;
SoSecMech *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoSecMech)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSecMech));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoStrValue(&dst->mechName, &src->mechName, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoMechPars(&dst->mechPars, &src->mechPars, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoStrValue(&dst->mechName);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoSecMech*/

/*
*
*    Fun:    soUtlCpySoSecVerify
*
*    Desc:    copy the structure SoSecVerify
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSecVerify
(
SoSecVerify *dst,
SoSecVerify *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSecVerify(dst, src, mem)
SoSecVerify *dst;
SoSecVerify *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoSecVerify)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSecVerify));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->secMech), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->secMech[i]), sizeof(SoSecMech), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoSecMech(dst->secMech[i], src->secMech[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->secMech[i], sizeof(SoSecMech));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoSecMech(dst->secMech[i]);
         SOFREE(dst->secMech[i], sizeof(SoSecMech));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->secMech, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoSecVerify*/

/*
*
*    Fun:    soUtlCpySoSecServer
*
*    Desc:    copy the structure SoSecServer
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSecServer
(
SoSecServer *dst,
SoSecServer *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSecServer(dst, src, mem)
SoSecServer *dst;
SoSecServer *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoSecServer)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSecServer));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->secMech), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->secMech[i]), sizeof(SoSecMech), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoSecMech(dst->secMech[i], src->secMech[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->secMech[i], sizeof(SoSecMech));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoSecMech(dst->secMech[i]);
         SOFREE(dst->secMech[i], sizeof(SoSecMech));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->secMech, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoSecServer*/

/*
*
*    Fun:    soUtlCpySoSecClient
*
*    Desc:    copy the structure SoSecClient
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSecClient
(
SoSecClient *dst,
SoSecClient *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSecClient(dst, src, mem)
SoSecClient *dst;
SoSecClient *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoSecClient)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSecClient));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->secMech), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->secMech[i]), sizeof(SoSecMech), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoSecMech(dst->secMech[i], src->secMech[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->secMech[i], sizeof(SoSecMech));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoSecMech(dst->secMech[i]);
         SOFREE(dst->secMech[i], sizeof(SoSecMech));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->secMech, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoSecClient*/

/*
*
*    Fun:    soUtlCpySoReasonPar
*
*    Desc:    copy the structure SoReasonPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoReasonPar
(
SoReasonPar *dst,
SoReasonPar *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoReasonPar(dst, src, mem)
SoReasonPar *dst;
SoReasonPar *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoReasonPar)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoReasonPar));

   if( src->reasonType.pres != NOTPRSNT )
   {
      switch( src->reasonType.val )
      {
         case  SO_REASON_CAUSE :
            break;
         case  SO_REASON_EXTN :
            if (soUtlCpySoParameter(&dst->u.extn, &src->u.extn, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_REASON_TEXT :
            if (soUtlCpyTknStrOSXL(&dst->u.text, &src->u.text, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoReasonPar*/

/*
*
*    Fun:    soUtlCpySoReasonPars
*
*    Desc:    copy the structure SoReasonPars
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoReasonPars
(
SoReasonPars *dst,
SoReasonPars *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoReasonPars(dst, src, mem)
SoReasonPars *dst;
SoReasonPars *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoReasonPars)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoReasonPars));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->reasonPar), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->reasonPar[i]), sizeof(SoReasonPar), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoReasonPar(dst->reasonPar[i], src->reasonPar[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->reasonPar[i], sizeof(SoReasonPar));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoReasonPar(dst->reasonPar[i]);
         SOFREE(dst->reasonPar[i], sizeof(SoReasonPar));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->reasonPar, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoReasonPars*/

/*
*
*    Fun:    soUtlCpySoReasonVal
*
*    Desc:    copy the structure SoReasonVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoReasonVal
(
SoReasonVal *dst,
SoReasonVal *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoReasonVal(dst, src, mem)
SoReasonVal *dst;
SoReasonVal *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoReasonVal)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoReasonVal));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoProtocolName(&dst->protocolName, &src->protocolName, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoReasonPars(&dst->reasonPars, &src->reasonPars, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoProtocolName(&dst->protocolName);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoReasonVal*/

/*
*
*    Fun:    soUtlCpySoReason
*
*    Desc:    copy the structure SoReason
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoReason
(
SoReason *dst,
SoReason *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoReason(dst, src, mem)
SoReason *dst;
SoReason *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoReason)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoReason));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->reasonVal), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->reasonVal[i]), sizeof(SoReasonVal), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoReasonVal(dst->reasonVal[i], src->reasonVal[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->reasonVal[i], sizeof(SoReasonVal));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoReasonVal(dst->reasonVal[i]);
         SOFREE(dst->reasonVal[i], sizeof(SoReasonVal));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->reasonVal, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoReason*/

/*
*
*    Fun:    soUtlCpySoPrivacy
*
*    Desc:    copy the structure SoPrivacy
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoPrivacy
(
SoPrivacy *dst,
SoPrivacy *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoPrivacy(dst, src, mem)
SoPrivacy *dst;
SoPrivacy *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoPrivacy)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoPrivacy));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->privVal), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->privVal[i]), sizeof(SoStrValue), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoStrValue(dst->privVal[i], src->privVal[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->privVal[i], sizeof(SoStrValue));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoStrValue(dst->privVal[i]);
         SOFREE(dst->privVal[i], sizeof(SoStrValue));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->privVal, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoPrivacy*/

/*
*
*    Fun:    soUtlCpySoPAssertedId
*
*    Desc:    copy the structure SoPAssertedId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoPAssertedId
(
SoPAssertedId *dst,
SoPAssertedId *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoPAssertedId(dst, src, mem)
SoPAssertedId *dst;
SoPAssertedId *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoPAssertedId)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoPAssertedId));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->addrChoice), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->addrChoice[i]), sizeof(SoAddrCh), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoAddrCh(dst->addrChoice[i], src->addrChoice[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->addrChoice[i], sizeof(SoAddrCh));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoAddrCh(dst->addrChoice[i]);
         SOFREE(dst->addrChoice[i], sizeof(SoAddrCh));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->addrChoice, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoPAssertedId*/

/*
*
*    Fun:    soUtlCpySoPPreferredId
*
*    Desc:    copy the structure SoPPreferredId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoPPreferredId
(
SoPPreferredId *dst,
SoPPreferredId *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoPPreferredId(dst, src, mem)
SoPPreferredId *dst;
SoPPreferredId *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoPPreferredId)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoPPreferredId));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->addrChoice), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->addrChoice[i]), sizeof(SoAddrCh), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoAddrCh(dst->addrChoice[i], src->addrChoice[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->addrChoice[i], sizeof(SoAddrCh));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoAddrCh(dst->addrChoice[i]);
         SOFREE(dst->addrChoice[i], sizeof(SoAddrCh));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->addrChoice, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoPPreferredId*/

/*
*
*    Fun:    soUtlCpySoHeader
*
*    Desc:    copy the structure SoHeader
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoHeader
(
SoHeader *dst,
SoHeader *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoHeader(dst, src, mem)
SoHeader *dst;
SoHeader *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoHeader)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoHeader));

   if( src->headerType.pres != NOTPRSNT )
   {
      switch( src->headerType.val )
      {
         case  SO_HEADER_ANONMY :
            if (soUtlCpySoStrValue(&dst->t.anony, &src->t.anony, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_ENT_CONTENTDISPOSITION :
            if (soUtlCpySoContentDisposition(&dst->t.contentDisposition, &src->t.contentDisposition, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_ENT_CONTENTENCODING :
            if (soUtlCpySoContentEncoding(&dst->t.contentEncoding, &src->t.contentEncoding, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_ENT_CONTENTLANGUAGE :
            if (soUtlCpySoTknStrOSXLLst(&dst->t.contentLanguage, &src->t.contentLanguage, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_ENT_CONTENTLENGTH :
            break;
         case  SO_HEADER_ENT_CONTENTTYPE :
            if (soUtlCpySoContentTypeHdr(&dst->t.contentType, &src->t.contentType, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_ENT_MIMEVERSION :
            if (soUtlCpyTknStrOSXL(&dst->t.mimeVersion, &src->t.mimeVersion, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_ACCEPT :
            if (soUtlCpySoAccept(&dst->t.accept, &src->t.accept, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_ACCEPTENCODING :
            if (soUtlCpySoAcceptEncoding(&dst->t.acceptEncoding, &src->t.acceptEncoding, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_ACCEPTLANGUAGE :
            if (soUtlCpySoAcceptLanguage(&dst->t.acceptLanguage, &src->t.acceptLanguage, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_ALERTINFO :
            if (soUtlCpySoInfo(&dst->t.alertInfo, &src->t.alertInfo, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_ALLOW :
            if (soUtlCpySoAllow(&dst->t.allow, &src->t.allow, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_ALLOW_EVENTS :
#ifdef SO_EVENT
            if (soUtlCpySoTknStrOSXLLst(&dst->t.allowEvents, &src->t.allowEvents, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_EVENT  */
            break;
         case  SO_HEADER_GEN_ALLOW_EVENTSU :
#ifdef SO_EVENT
            if (soUtlCpySoTknStrOSXLLst(&dst->t.allowEvents, &src->t.allowEvents, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_EVENT  */
            break;
         case  SO_HEADER_GEN_CALLID :
            if (soUtlCpyTknStrOSXL(&dst->t.callId, &src->t.callId, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_CALLINFO :
            if (soUtlCpySoCallInfo(&dst->t.callInfo, &src->t.callInfo, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_CONTACT :
            if (soUtlCpySoContact(&dst->t.contact, &src->t.contact, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_CSEQ :
            if (soUtlCpySoCSeq(&dst->t.cSeq, &src->t.cSeq, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_DATE :
            break;
         case  SO_HEADER_GEN_ENCRYPTION :
            if (soUtlCpyTknStrOSXL(&dst->t.encryption, &src->t.encryption, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_EXPIRES :
            break;
         case  SO_HEADER_GEN_EXTENSION :
            if (soUtlCpyTknStrOSXL(&dst->t.extensionHeader, &src->t.extensionHeader, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_FROM :
            if (soUtlCpySoAddress(&dst->t.from, &src->t.from, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_MINEXPIRES :
            break;
         case  SO_HEADER_GEN_MINSE :
#ifdef SO_SESSTIMER
            if (soUtlCpySoMinSE(&dst->t.minSe, &src->t.minSe, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_SESSTIMER  */
            break;
         case  SO_HEADER_GEN_ORGANIZATION :
            if (soUtlCpyTknStrOSXL(&dst->t.organization, &src->t.organization, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_PASSERTEDID :
            if (soUtlCpySoPAssertedId(&dst->t.assertId, &src->t.assertId, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_PATH :
            if (soUtlCpySoRoute(&dst->t.path, &src->t.path, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_PMEDIAAUTHORIZATION :
            if (soUtlCpySoTknStrOSXLLst(&dst->t.pMediaAuth, &src->t.pMediaAuth, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_PPREFERREDID :
            if (soUtlCpySoPPreferredId(&dst->t.preferredId, &src->t.preferredId, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_PRIVACY :
            if (soUtlCpySoPrivacy(&dst->t.privacy, &src->t.privacy, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_PROXYREQUIRE :
            if (soUtlCpySoTknStrOSXLLst(&dst->t.proxyRequire, &src->t.proxyRequire, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_RACK :
            if (soUtlCpySoRAck(&dst->t.rAck, &src->t.rAck, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_REASON :
            if (soUtlCpySoReason(&dst->t.reason, &src->t.reason, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_RECORDROUTE :
            if (soUtlCpySoRoute(&dst->t.recordRoute, &src->t.recordRoute, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_REPLYTO :
            if (soUtlCpySoReplyTo(&dst->t.replyTo, &src->t.replyTo, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_REQUIRE :
            if (soUtlCpySoTknStrOSXLLst(&dst->t.require, &src->t.require, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_RSEQ :
            break;
         case  SO_HEADER_GEN_SERVICEROUTE :
            if (soUtlCpySoRoute(&dst->t.serviceRoute, &src->t.serviceRoute, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_SESSION_EXPIRES :
         case  SO_HEADER_GEN_SESSION_EXPIRESX :
#ifdef SO_SESSTIMER
            if (soUtlCpySoSessionExpires(&dst->t.sessExpires, &src->t.sessExpires, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_SESSTIMER  */
            break;
         case  SO_HEADER_GEN_SUBJECT :
            if (soUtlCpyTknStrOSXL(&dst->t.subject, &src->t.subject, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_SUPPORTED :
            if (soUtlCpySoTknStrOSXLLst(&dst->t.supported, &src->t.supported, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_TIMESTAMP :
            break;
         case  SO_HEADER_GEN_TO :
            if (soUtlCpySoAddress(&dst->t.to, &src->t.to, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_USERAGENT :
            if (soUtlCpySoProdcomLst(&dst->t.userAgent, &src->t.userAgent, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_VIA :
            if (soUtlCpySoVia(&dst->t.via, &src->t.via, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_WARNING :
            if (soUtlCpySoWarning(&dst->t.warning, &src->t.warning, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_WWWAUTHENTICATE :
            if (soUtlCpySoAuthenticate(&dst->t.wwwAuthenticate, &src->t.wwwAuthenticate, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REM_PARTY_ID :
            if (soUtlCpySoRemPartyId(&dst->t.remPtid, &src->t.remPtid, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_ACCEPT_CONTACT :
#ifdef SO_CALLERPREF
            if (soUtlCpySoAcceptContact(&dst->t.acceptContact, &src->t.acceptContact, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_HEADER_REQ_ACCEPT_CONTACTA :
#ifdef SO_CALLERPREF
            if (soUtlCpySoAcceptContact(&dst->t.acceptContact, &src->t.acceptContact, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_HEADER_REQ_ALSO :
            if (soUtlCpySoAlso(&dst->t.also, &src->t.also, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_AUTHENTICATIONINFO :
            if (soUtlCpySoParameters(&dst->t.authInfo, &src->t.authInfo, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_AUTHORIZATION :
            if (soUtlCpySoAuthorization(&dst->t.authorization, &src->t.authorization, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_EVENT :
#ifdef SO_EVENT
            if (soUtlCpySoEventHeader(&dst->t.event, &src->t.event, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_EVENT  */
            break;
         case  SO_HEADER_REQ_EVENTO :
#ifdef SO_EVENT
            if (soUtlCpySoEventHeader(&dst->t.event, &src->t.event, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_EVENT  */
            break;
         case  SO_HEADER_REQ_INREPLYTO :
            if (soUtlCpySoTknStrOSXLLst(&dst->t.inReplyTo, &src->t.inReplyTo, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_MAXFORWARDS :
            break;
         case  SO_HEADER_REQ_PRIORITY :
            if (soUtlCpySoPriority(&dst->t.priority, &src->t.priority, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_PROXYAUTHORIZATION :
            if (soUtlCpySoAuthorization(&dst->t.proxyAuthorization, &src->t.proxyAuthorization, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_REFERBY :
#ifdef SO_REFER
            if (soUtlCpySoReferredBy(&dst->t.referredBy, &src->t.referredBy, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_REFER  */
            break;
         case  SO_HEADER_REQ_REFERBYB :
#ifdef SO_REFER
            if (soUtlCpySoReferredBy(&dst->t.referredBy, &src->t.referredBy, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_REFER  */
            break;
         case  SO_HEADER_REQ_REFERTO :
#ifdef SO_REFER
            if (soUtlCpySoReferTo(&dst->t.referTo, &src->t.referTo, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_REFER  */
            break;
         case  SO_HEADER_REQ_REFERTOR :
#ifdef SO_REFER
            if (soUtlCpySoReferTo(&dst->t.referTo, &src->t.referTo, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_REFER  */
            break;
         case  SO_HEADER_REQ_REJECT_CONTACT :
#ifdef SO_CALLERPREF
            if (soUtlCpySoRejectContact(&dst->t.rejectContact, &src->t.rejectContact, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_HEADER_REQ_REJECT_CONTACTJ :
#ifdef SO_CALLERPREF
            if (soUtlCpySoRejectContact(&dst->t.rejectContact, &src->t.rejectContact, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_HEADER_REQ_REPLACES :
#ifdef SO_REFER
            if (soUtlCpySoReplaces(&dst->t.replaces, &src->t.replaces, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_REFER  */
            break;
         case  SO_HEADER_REQ_REQUESTDISPOSITION :
#ifdef SO_CALLERPREF
            if (soUtlCpySoRequestDisposition(&dst->t.requestDisposition, &src->t.requestDisposition, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_HEADER_REQ_REQUESTDISPOSITIOND :
#ifdef SO_CALLERPREF
            if (soUtlCpySoRequestDisposition(&dst->t.requestDisposition, &src->t.requestDisposition, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_HEADER_REQ_RESPONSEKEY :
            if (soUtlCpyTknStrOSXL(&dst->t.responseKey, &src->t.responseKey, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_ROUTE :
            if (soUtlCpySoRoute(&dst->t.route, &src->t.route, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_RPID_PRIV :
            if (soUtlCpySoRpidPrivcy(&dst->t.rpidPriv, &src->t.rpidPriv, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_RSP_ERRORINFO :
            if (soUtlCpySoInfo(&dst->t.errorInfo, &src->t.errorInfo, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_RSP_PROXYAUTHENTICATE :
            if (soUtlCpySoAuthenticate(&dst->t.proxyAuthenticate, &src->t.proxyAuthenticate, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_RSP_RETRYAFTER :
            if (soUtlCpySoRetryAfter(&dst->t.retryAfter, &src->t.retryAfter, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_RSP_SERVER :
            if (soUtlCpySoProdcomLst(&dst->t.server, &src->t.server, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_RSP_UNSUPPORTED :
            if (soUtlCpySoTknStrOSXLLst(&dst->t.unsupported, &src->t.unsupported, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_SEC_CLIENT :
            if (soUtlCpySoSecClient(&dst->t.secClient, &src->t.secClient, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_SEC_SERVER :
            if (soUtlCpySoSecServer(&dst->t.secServer, &src->t.secServer, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_SEC_VERIFY :
            if (soUtlCpySoSecVerify(&dst->t.secVerify, &src->t.secVerify, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_SUBSC_STATE :
#ifdef SO_EVENT
            if (soUtlCpySoSubscState(&dst->t.subscSt, &src->t.subscSt, mem) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_EVENT  */
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoHeader*/

/*
*
*    Fun:    soUtlCpySoRequestLine
*
*    Desc:    copy the structure SoRequestLine
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRequestLine
(
SoRequestLine *dst,
SoRequestLine *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRequestLine(dst, src, mem)
SoRequestLine *dst;
SoRequestLine *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoRequestLine)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRequestLine));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoExtVal(&dst->method, &src->method, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoAddrSpec(&dst->addrSpec, &src->addrSpec, mem) != ROK)
         goto soUtlCpyErr1;
      if (soUtlCpyTknStrOSXL(&dst->sipVersion, &src->sipVersion, mem) != ROK)
         goto soUtlCpyErr2;
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      soUtlDelSoAddrSpec(&dst->addrSpec);
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoExtVal(&dst->method);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRequestLine*/

/*
*
*    Fun:    soUtlCpySoHeaderSeq
*
*    Desc:    copy the structure SoHeaderSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoHeaderSeq
(
SoHeaderSeq *dst,
SoHeaderSeq *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoHeaderSeq(dst, src, mem)
SoHeaderSeq *dst;
SoHeaderSeq *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoHeaderSeq)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoHeaderSeq));

   if( src->numComp.pres != NOTPRSNT )
   {
      if (soUtlCpyGetMem((Ptr*)&(dst->header), (U16)(sizeof(Ptr)*(src->numComp.val)), mem) != ROK)
         goto soUtlCpyErr0;
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->header[i]), sizeof(SoHeader), mem) != ROK)
            goto soUtlCpyErr1;
         if (soUtlCpySoHeader(dst->header[i], src->header[i], mem) != ROK)
            goto soUtlCpyErr2;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->header[i], sizeof(SoHeader));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoHeader(dst->header[i]);
         SOFREE(dst->header[i], sizeof(SoHeader));
      }
   }
   if (mem == NULLP)
   {
      SOFREE(dst->header, sizeof(Ptr)*(src->numComp.val));
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoHeaderSeq*/

/*
*
*    Fun:    soUtlCpySoStatusLine
*
*    Desc:    copy the structure SoStatusLine
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoStatusLine
(
SoStatusLine *dst,
SoStatusLine *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoStatusLine(dst, src, mem)
SoStatusLine *dst;
SoStatusLine *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoStatusLine)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoStatusLine));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpyTknStrOSXL(&dst->sipVersion, &src->sipVersion, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpyTknStrOSXL(&dst->reasonPhrase, &src->reasonPhrase, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->sipVersion);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoStatusLine*/

/*
*
*    Fun:    soUtlCpySoRequest
*
*    Desc:    copy the structure SoRequest
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRequest
(
SoRequest *dst,
SoRequest *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRequest(dst, src, mem)
SoRequest *dst;
SoRequest *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoRequest)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRequest));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoRequestLine(&dst->requestLine, &src->requestLine, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoHeaderSeq(&dst->request, &src->request, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoRequestLine(&dst->requestLine);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRequest*/

/*
*
*    Fun:    soUtlCpySoResponse
*
*    Desc:    copy the structure SoResponse
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoResponse
(
SoResponse *dst,
SoResponse *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoResponse(dst, src, mem)
SoResponse *dst;
SoResponse *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoResponse)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoResponse));

   if(src->pres.pres != NOTPRSNT)
   {
      if (soUtlCpySoStatusLine(&dst->statusLine, &src->statusLine, mem) != ROK)
         goto soUtlCpyErr0;
      if (soUtlCpySoHeaderSeq(&dst->response, &src->response, mem) != ROK)
         goto soUtlCpyErr1;
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoStatusLine(&dst->statusLine);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoResponse*/
#ifndef SO_REL_1_2_INF
#ifdef SO_UA

/*
*
*    Fun:    soUtlCpySoAuditInfo
*
*    Desc:    copy the structure SoAuditInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAuditInfo
(
SoAuditInfo *dst,
SoAuditInfo *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAuditInfo(dst, src, mem)
SoAuditInfo *dst;
SoAuditInfo *src;
CmMemListCp *mem;
#endif
{
   TRC3(soUtlCpySoAuditInfo)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAuditInfo));

   if (soUtlCpyTknStrOSXL(&dst->callId, &src->callId, mem) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlCpySoAuditInfo*/

/*
*
*    Fun:    soUtlCpySoSSapInfo
*
*    Desc:    copy the structure SoSSapInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoSSapInfo
(
SoSSapInfo *dst,
SoSSapInfo *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoSSapInfo(dst, src, mem)
SoSSapInfo *dst;
SoSSapInfo *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoSSapInfo)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoSSapInfo));

   for (i=0;i<src->numCalls ;i++)
   {
      if (soUtlCpySoAuditInfo(&dst->callInfo[i], &src->callInfo[i], mem) != ROK)
         goto soCpyErr0;
   }
   RETVALUE(ROK);

soCpyErr0 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoAuditInfo(&dst->callInfo[i]);
      }
   }
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoSSapInfo*/

/*
*
*    Fun:    soUtlCpySoAudit
*
*    Desc:    copy the structure SoAudit
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoAudit
(
SoAudit *dst,
SoAudit *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoAudit(dst, src, mem)
SoAudit *dst;
SoAudit *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoAudit)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoAudit));

   switch( src->auditType )
   {
      case  SOT_AUDIT_CALL :
         if (soUtlCpySoAuditInfo(&dst->auditInfo.callInfo, &src->auditInfo.callInfo, mem) != ROK)
            RETVALUE(RFAILED);
         break;
      case  SOT_AUDIT_SSAP :
         if (soUtlCpySoSSapInfo(&dst->auditInfo.ssapInfo, &src->auditInfo.ssapInfo, mem) != ROK)
            RETVALUE(RFAILED);
         break;
      default:
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoAudit*/
#endif /* SO_UA */


/*
*
*    Fun:    soUtlCpySoRegRefreshInfo
*
*    Desc:    copy the structure SoRegRefreshInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRegRefreshInfo
(
SoRegRefreshInfo *dst,
SoRegRefreshInfo *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRegRefreshInfo(dst, src, mem)
SoRegRefreshInfo *dst;
SoRegRefreshInfo *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoRegRefreshInfo)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRegRefreshInfo));

   if (soUtlCpySoContactItem(&dst->contactItem, &src->contactItem, mem) != ROK)
      goto soUtlCpyErr0;
   if (soUtlCpySoAddress(&dst->to, &src->to, mem) != ROK)
      goto soUtlCpyErr1;
   if (soUtlCpySoAddress(&dst->from, &src->from, mem) != ROK)
      goto soUtlCpyErr2;
   if (soUtlCpyTknStrOSXL(&dst->callId, &src->callId, mem) != ROK)
      goto soUtlCpyErr3;
   if (soUtlCpySoAddrSpec(&dst->regAddr, &src->regAddr, mem) != ROK)
      goto soUtlCpyErr4;
   RETVALUE(ROK);
soUtlCpyErr4 :
   if (mem == NULLP)
   {
      soUtlDelTknStrOSXL(&dst->callId);
   }
soUtlCpyErr3 :
   if (mem == NULLP)
   {
      soUtlDelSoAddress(&dst->from);
   }
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      soUtlDelSoAddress(&dst->to);
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoContactItem(&dst->contactItem);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoRegRefreshInfo*/

/*
*
*    Fun:    soUtlCpySoRefreshEvnt
*
*    Desc:    copy the structure SoRefreshEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoRefreshEvnt
(
SoRefreshEvnt *dst,
SoRefreshEvnt *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoRefreshEvnt(dst, src, mem)
SoRefreshEvnt *dst;
SoRefreshEvnt *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoRefreshEvnt)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoRefreshEvnt));

   switch( src->type )
   {
      case  SOT_ET_REG_TMO :
         if (soUtlCpySoRegRefreshInfo(&dst->t.regInfo, &src->t.regInfo, mem) != ROK)
            RETVALUE(RFAILED);
         break;
      case  SOT_ET_SUBSC_TMO :
#ifdef SO_EVENT
         if (soUtlCpyTknStrOSXL(&dst->t.subscId, &src->t.subscId, mem) != ROK)
            RETVALUE(RFAILED);
#endif /*  SO_EVENT  */
         break;
      default:
         break;
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoRefreshEvnt*/
#endif /* SO_REL_1_2_INF */

/*
*
*    Fun:    soUtlCpySoErrEvnt
*
*    Desc:    copy the structure SoErrEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoErrEvnt
(
SoErrEvnt *dst,
SoErrEvnt *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoErrEvnt(dst, src, mem)
SoErrEvnt *dst;
SoErrEvnt *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoErrEvnt)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoErrEvnt));

#ifndef SO_REL_1_2_INF
#ifdef SO_EVENT
   switch( src->errCode )
   {
      case  SOT_ERR_REFER_TMO :
         if (soUtlCpyTknStrOSXL(&dst->t.referId, &src->t.referId, mem) != ROK)
            RETVALUE(RFAILED);
         break;
      case  SOT_ERR_SUBSC_TMO :
         if (soUtlCpyTknStrOSXL(&dst->t.subscId, &src->t.subscId, mem) != ROK)
            RETVALUE(RFAILED);
         break;
      default:
         break;
   }
#endif /*  SO_EVENT  */
#endif /*  SO_REL_1_2_INF  */
   RETVALUE(ROK);
} /*end of function soUtlCpySoErrEvnt*/

/*
*
*    Fun:    soUtlCpySoBodyMultiPartElm
*
*    Desc:    copy the structure SoBodyMultiPartElm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoBodyMultiPartElm
(
SoBodyMultiPartElm *dst,
SoBodyMultiPartElm *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoBodyMultiPartElm(dst, src, mem)
SoBodyMultiPartElm *dst;
SoBodyMultiPartElm *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoBodyMultiPartElm)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoBodyMultiPartElm));

   if (soUtlCpySoHeaderSeq(&dst->hdrSeq, &src->hdrSeq, mem) != ROK)
      goto soUtlCpyErr0;
   if (soUtlCpyGetMem((Ptr*)&(dst->body), sizeof(SoBody), mem) != ROK)
      goto soUtlCpyErr1;
   if (soUtlCpySoBody(dst->body, src->body, mem) != ROK)
      goto soUtlCpyErr2;
   RETVALUE(ROK);
soUtlCpyErr2 :
   if (mem == NULLP)
   {
      SOFREE(dst->body, sizeof(SoBody));
   }
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      soUtlDelSoHeaderSeq(&dst->hdrSeq);
   }
soUtlCpyErr0 :
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoBodyMultiPartElm*/

/*
*
*    Fun:    soUtlCpySoBodyMultiPart
*
*    Desc:    copy the structure SoBodyMultiPart
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoBodyMultiPart
(
SoBodyMultiPart *dst,
SoBodyMultiPart *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoBodyMultiPart(dst, src, mem)
SoBodyMultiPart *dst;
SoBodyMultiPart *src;
CmMemListCp *mem;
#endif
{
   Cntr i;

   TRC3(soUtlCpySoBodyMultiPart)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoBodyMultiPart));

   if( src->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<src->numComp.val;i++)
      {
         if (soUtlCpyGetMem((Ptr*)&(dst->bodyElm[i]), sizeof(SoBodyMultiPartElm), mem) != ROK)
            goto soUtlCpyErr0;
         if (soUtlCpySoBodyMultiPartElm(dst->bodyElm[i], src->bodyElm[i], mem) != ROK)
            goto soUtlCpyErr1;
      }
   }
   RETVALUE(ROK);
soUtlCpyErr1 :
   if (mem == NULLP)
   {
      SOFREE(dst->bodyElm[i], sizeof(SoBodyMultiPartElm));
   }
soUtlCpyErr0 :
   if (mem == NULLP)
   {
      for (i = i-1;i >= 0; i--)
      {
         soUtlDelSoBodyMultiPartElm(dst->bodyElm[i]);
         SOFREE(dst->bodyElm[i], sizeof(SoBodyMultiPartElm));
      }
   }
   RETVALUE(RFAILED);
} /*end of function soUtlCpySoBodyMultiPart*/

/*
*
*    Fun:    soUtlCpySoBody
*
*    Desc:    copy the structure SoBody
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlCpySoBody
(
SoBody *dst,
SoBody *src,
CmMemListCp *mem
)
#else
PUBLIC S16 soUtlCpySoBody(dst, src, mem)
SoBody *dst;
SoBody *src;
CmMemListCp *mem;
#endif
{

   TRC3(soUtlCpySoBody)

   cmMemcpy((U8 *)dst, (U8 *)src, sizeof(SoBody));

   if( src->bodyType.pres != NOTPRSNT )
   {
      switch( src->bodyType.val )
      {
         case  SOT_BODYTYPE_MULTIPART :
            if (soUtlCpySoBodyMultiPart(&dst->u.multiPart, &src->u.multiPart, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SOT_BODYTYPE_SINGLEPART :
            if (soUtlCpySoBodySinglePart(&dst->u.singlePart, &src->u.singlePart, mem) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlCpySoBody*/


/*
*
*    Fun:    soUtlDelSoTransportParam
*
*    Desc:    Delete the structure SoTransportParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoTransportParam
(
SoTransportParam *dst
)
#else
PUBLIC S16 soUtlDelSoTransportParam(dst)
SoTransportParam *dst;
#endif
{

   TRC3(soUtlDelSoTransportParam)

   if (soUtlDelTknStrOSXL(&dst->otherTransport) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlDelSoTransportParam*/

/*
*
*    Fun:    soUtlDelSoUserParam
*
*    Desc:    Delete the structure SoUserParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoUserParam
(
SoUserParam *dst
)
#else
PUBLIC S16 soUtlDelSoUserParam(dst)
SoUserParam *dst;
#endif
{

   TRC3(soUtlDelSoUserParam)

   if (soUtlDelTknStrOSXL(&dst->otherUser) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlDelSoUserParam*/

/*
*
*    Fun:    soUtlDelSoNameVal
*
*    Desc:    Delete the structure SoNameVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoNameVal
(
SoNameVal *dst
)
#else
PUBLIC S16 soUtlDelSoNameVal(dst)
SoNameVal *dst;
#endif
{

   TRC3(soUtlDelSoNameVal)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelTknStrOSXL(&dst->name) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelTknStrOSXL(&dst->value) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoNameVal*/

/*
*
*    Fun:    soUtlDelSoHost
*
*    Desc:    Delete the structure SoHost
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoHost
(
SoHost *dst
)
#else
PUBLIC S16 soUtlDelSoHost(dst)
SoHost *dst;
#endif
{

   TRC3(soUtlDelSoHost)

   if( dst->hostType.pres != NOTPRSNT )
   {
      switch( dst->hostType.val )
      {
         case  SO_HOST_HOSTNAME :
            if (soUtlDelTknStrOSXL(&dst->t.hostName) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HOST_IPV4ADDRESS :
            break;
         case  SO_HOST_IPV6REFERENCE :
            if (soUtlDelTknStrOSXL(&dst->t.ipv6Reference) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoHost*/

/*
*
*    Fun:    soUtlDelSoStrValue
*
*    Desc:    Delete the structure SoStrValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoStrValue
(
SoStrValue *dst
)
#else
PUBLIC S16 soUtlDelSoStrValue(dst)
SoStrValue *dst;
#endif
{

   TRC3(soUtlDelSoStrValue)

   if( dst->valueType.pres != NOTPRSNT )
   {
      if (soUtlDelTknStrOSXL(&dst->value) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoStrValue*/

/*
*
*    Fun:    soUtlDelSoUrlParameter
*
*    Desc:    Delete the structure SoUrlParameter
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoUrlParameter
(
SoUrlParameter *dst
)
#else
PUBLIC S16 soUtlDelSoUrlParameter(dst)
SoUrlParameter *dst;
#endif
{

   TRC3(soUtlDelSoUrlParameter)

   if( dst->urlParameterType.pres != NOTPRSNT )
   {
      switch( dst->urlParameterType.val )
      {
         case  SO_URLPARAMETER_COMP :
            if (soUtlDelSoStrValue(&dst->t.comp) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_URLPARAMETER_ISUB :
#ifdef SO_ENUM
            if (soUtlDelTknStrOSXL(&dst->t.isub) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_ENUM  */
            break;
         case  SO_URLPARAMETER_LRPARAM :
            break;
         case  SO_URLPARAMETER_MADDRHOST :
            if (soUtlDelSoHost(&dst->t.maddrHost) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_URLPARAMETER_METHOD :
            if (soUtlDelSoExtVal(&dst->t.method) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_URLPARAMETER_OTHERPARAM :
            if (soUtlDelSoNameVal(&dst->t.otherParam) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_URLPARAMETER_PHONECONTEXT :
#ifdef SO_ENUM
            if (soUtlDelTknStrOSXL(&dst->t.phoneContext) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_ENUM  */
            break;
         case  SO_URLPARAMETER_POSTD :
#ifdef SO_ENUM
            if (soUtlDelTknStrOSXL(&dst->t.postd) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_ENUM  */
            break;
         case  SO_URLPARAMETER_TRANSPORTPARAM :
            if (soUtlDelSoTransportParam(&dst->t.transportParam) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_URLPARAMETER_TSPDOMAIN :
#ifdef SO_PINT
            if (soUtlDelSoHost(&dst->t.tspDomain) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_PINT  */
            break;
         case  SO_URLPARAMETER_TTLPARAM :
            break;
         case  SO_URLPARAMETER_USERPARAM :
            if (soUtlDelSoUserParam(&dst->t.userParam) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoUrlParameter*/

/*
*
*    Fun:    soUtlDelSoHeaderExt
*
*    Desc:    Delete the structure SoHeaderExt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoHeaderExt
(
SoHeaderExt *dst
)
#else
PUBLIC S16 soUtlDelSoHeaderExt(dst)
SoHeaderExt *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoHeaderExt)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoNameVal(dst->header[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->header[i], sizeof(SoNameVal));
      }
      SOFREE(dst->header, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoHeaderExt*/

/*
*
*    Fun:    soUtlDelSoUserInfo
*
*    Desc:    Delete the structure SoUserInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoUserInfo
(
SoUserInfo *dst
)
#else
PUBLIC S16 soUtlDelSoUserInfo(dst)
SoUserInfo *dst;
#endif
{

   TRC3(soUtlDelSoUserInfo)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoStrValue(&dst->userType) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelTknStrOSXL(&dst->password) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoUserInfo*/

/*
*
*    Fun:    soUtlDelSoHeaders
*
*    Desc:    Delete the structure SoHeaders
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoHeaders
(
SoHeaders *dst
)
#else
PUBLIC S16 soUtlDelSoHeaders(dst)
SoHeaders *dst;
#endif
{

   TRC3(soUtlDelSoHeaders)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoNameVal(&dst->header) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoHeaderExt(&dst->headerExt) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoHeaders*/

/*
*
*    Fun:    soUtlDelSoTknStrOSXLLst
*
*    Desc:    Delete the structure SoTknStrOSXLLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoTknStrOSXLLst
(
SoTknStrOSXLLst *dst
)
#else
PUBLIC S16 soUtlDelSoTknStrOSXLLst(dst)
SoTknStrOSXLLst *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoTknStrOSXLLst)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelTknStrOSXL(dst->stringList[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->stringList[i], sizeof(TknStrOSXL));
      }
      SOFREE(dst->stringList, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoTknStrOSXLLst*/

/*
*
*    Fun:    soUtlDelSoHostPort
*
*    Desc:    Delete the structure SoHostPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoHostPort
(
SoHostPort *dst
)
#else
PUBLIC S16 soUtlDelSoHostPort(dst)
SoHostPort *dst;
#endif
{

   TRC3(soUtlDelSoHostPort)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoHost(&dst->host) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoHostPort*/

/*
*
*    Fun:    soUtlDelSoUrlParameters
*
*    Desc:    Delete the structure SoUrlParameters
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoUrlParameters
(
SoUrlParameters *dst
)
#else
PUBLIC S16 soUtlDelSoUrlParameters(dst)
SoUrlParameters *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoUrlParameters)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoUrlParameter(dst->urlParameter[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->urlParameter[i], sizeof(SoUrlParameter));
      }
      SOFREE(dst->urlParameter, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoUrlParameters*/

/*
*
*    Fun:    soUtlDelSoParameter
*
*    Desc:    Delete the structure SoParameter
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoParameter
(
SoParameter *dst
)
#else
PUBLIC S16 soUtlDelSoParameter(dst)
SoParameter *dst;
#endif
{

   TRC3(soUtlDelSoParameter)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelTknStrOSXL(&dst->token) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoStrValue(&dst->paramVal) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoParameter*/

/*
*
*    Fun:    soUtlDelSoTypeSub
*
*    Desc:    Delete the structure SoTypeSub
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoTypeSub
(
SoTypeSub *dst
)
#else
PUBLIC S16 soUtlDelSoTypeSub(dst)
SoTypeSub *dst;
#endif
{

   TRC3(soUtlDelSoTypeSub)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelTknStrOSXL(&dst->type) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelTknStrOSXL(&dst->subType) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoTypeSub*/

/*
*
*    Fun:    soUtlDelSoMediaRangeVal
*
*    Desc:    Delete the structure SoMediaRangeVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoMediaRangeVal
(
SoMediaRangeVal *dst
)
#else
PUBLIC S16 soUtlDelSoMediaRangeVal(dst)
SoMediaRangeVal *dst;
#endif
{

   TRC3(soUtlDelSoMediaRangeVal)

   if( dst->mediaRangeValType.pres != NOTPRSNT )
   {
      switch( dst->mediaRangeValType.val )
      {
         case  SO_MEDIARANGEVAL_ALLSTAR :
            break;
         case  SO_MEDIARANGEVAL_TYPESTAR :
            if (soUtlDelTknStrOSXL(&dst->t.typeStar) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_MEDIARANGEVAL_TYPESUB :
            if (soUtlDelSoTypeSub(&dst->t.typeSub) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoMediaRangeVal*/


/*
*
*    Fun:    soUtlDelSoCallInfoPurpose
*
*    Desc:    Delete the structure SoCallInfoPurpose
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoCallInfoPurpose
(
SoCallInfoPurpose *dst
)
#else
PUBLIC S16 soUtlDelSoCallInfoPurpose(dst)
SoCallInfoPurpose *dst;
#endif
{

   TRC3(soUtlDelSoCallInfoPurpose)

   if (soUtlDelTknStrOSXL(&dst->purposeExt) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlDelSoCallInfoPurpose*/

/*
*
*    Fun:    soUtlDelSoSubscExpReason
*
*    Desc:    Delete the structure SoSubscExpReason
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSubscExpReason
(
SoSubscExpReason *dst
)
#else
PUBLIC S16 soUtlDelSoSubscExpReason(dst)
SoSubscExpReason *dst;
#endif
{

   TRC3(soUtlDelSoSubscExpReason)

   if (soUtlDelTknStrOSXL(&dst->subscExpReasonExt) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlDelSoSubscExpReason*/

/*
*
*    Fun:    soUtlDelSoDisplayName
*
*    Desc:    Delete the structure SoDisplayName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoDisplayName
(
SoDisplayName *dst
)
#else
PUBLIC S16 soUtlDelSoDisplayName(dst)
SoDisplayName *dst;
#endif
{

   TRC3(soUtlDelSoDisplayName)

   if( dst->displayNameType.pres != NOTPRSNT )
   {
      switch( dst->displayNameType.val )
      {
         case  SO_PARAMVAL_QUOTEDSTR :
            if (soUtlDelTknStrOSXL(&dst->t.quotedStr) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_PARAMVAL_TOKEN :
            if (soUtlDelSoTknStrOSXLLst(&dst->t.displayNameRep) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoDisplayName*/

/*
*
*    Fun:    soUtlDelSoAbsoluteUri
*
*    Desc:    Delete the structure SoAbsoluteUri
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAbsoluteUri
(
SoAbsoluteUri *dst
)
#else
PUBLIC S16 soUtlDelSoAbsoluteUri(dst)
SoAbsoluteUri *dst;
#endif
{

   TRC3(soUtlDelSoAbsoluteUri)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelTknStrOSXL(&dst->scheme) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelTknStrOSXL(&dst->absUriDesc) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAbsoluteUri*/
#ifdef SO_ENUM

/*
*
*    Fun:    soUtlDelSoTelNumPar
*
*    Desc:    Delete the structure SoTelNumPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoTelNumPar
(
SoTelNumPar *dst
)
#else
PUBLIC S16 soUtlDelSoTelNumPar(dst)
SoTelNumPar *dst;
#endif
{

   TRC3(soUtlDelSoTelNumPar)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  SO_TEL_CIC :
            if (soUtlDelTknStrOSXL(&dst->t.cic) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_TEL_EXTN :
            if (soUtlDelSoParameter(&dst->t.extn) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_TEL_ISUB :
            if (soUtlDelTknStrOSXL(&dst->t.isub) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_TEL_PHONE_CONTEXT :
            if (soUtlDelTknStrOSXL(&dst->t.phCntxt) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_TEL_POSTD :
            if (soUtlDelTknStrOSXL(&dst->t.postd) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_TEL_RN :
            if (soUtlDelTknStrOSXL(&dst->t.rn) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_TEL_TSP :
            if (soUtlDelSoHost(&dst->t.tsp) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoTelNumPar*/

/*
*
*    Fun:    soUtlDelSoTelNumPars
*
*    Desc:    Delete the structure SoTelNumPars
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoTelNumPars
(
SoTelNumPars *dst
)
#else
PUBLIC S16 soUtlDelSoTelNumPars(dst)
SoTelNumPars *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoTelNumPars)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoTelNumPar(dst->par[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->par[i], sizeof(SoTelNumPar));
      }
      SOFREE(dst->par, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoTelNumPars*/

/*
*
*    Fun:    soUtlDelSoTelUrl
*
*    Desc:    Delete the structure SoTelUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoTelUrl
(
SoTelUrl *dst
)
#else
PUBLIC S16 soUtlDelSoTelUrl(dst)
SoTelUrl *dst;
#endif
{

   TRC3(soUtlDelSoTelUrl)

   if (soUtlDelTknStrOSXL(&dst->digits) != ROK)
      RETVALUE(RFAILED);
   if (soUtlDelSoTelNumPars(&dst->pars) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlDelSoTelUrl*/
#endif /* SO_ENUM */

/*
*
*    Fun:    soUtlDelSoPriority
*
*    Desc:    Delete the structure SoPriority
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoPriority
(
SoPriority *dst
)
#else
PUBLIC S16 soUtlDelSoPriority(dst)
SoPriority *dst;
#endif
{

   TRC3(soUtlDelSoPriority)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelTknStrOSXL(&dst->otherPriority) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoPriority*/

/*
*
*    Fun:    soUtlDelSoSipUrl
*
*    Desc:    Delete the structure SoSipUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSipUrl
(
SoSipUrl *dst
)
#else
PUBLIC S16 soUtlDelSoSipUrl(dst)
SoSipUrl *dst;
#endif
{

   TRC3(soUtlDelSoSipUrl)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoUserInfo(&dst->userInfo) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoHostPort(&dst->hostPort) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoUrlParameters(&dst->urlParameters) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoHeaders(&dst->headers) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoSipUrl*/

/*
*
*    Fun:    soUtlDelSoAddrSpec
*
*    Desc:    Delete the structure SoAddrSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAddrSpec
(
SoAddrSpec *dst
)
#else
PUBLIC S16 soUtlDelSoAddrSpec(dst)
SoAddrSpec *dst;
#endif
{

   TRC3(soUtlDelSoAddrSpec)

   if( dst->addrSpecType.pres != NOTPRSNT )
   {
      switch( dst->addrSpecType.val )
      {
         case  SO_ADDRSPEC_ABSOLUTEURI :
            if (soUtlDelSoAbsoluteUri(&dst->t.absoluteUri) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_ADDRSPEC_IMURL :
#ifdef SO_INSTMSG
            if (soUtlDelSoSipUrl(&dst->t.imUrl) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_INSTMSG  */
            break;
         case  SO_ADDRSPEC_SIPSURL :
#ifdef SO_TLS
            if (soUtlDelSoSipUrl(&dst->t.sipsUrl) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_TLS  */
            break;
         case  SO_ADDRSPEC_SIPURL :
            if (soUtlDelSoSipUrl(&dst->t.sipUrl) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_ADDRSPEC_TELURL :
#ifdef SO_ENUM
            if (soUtlDelSoTelUrl(&dst->t.telUrl) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_ENUM  */
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAddrSpec*/

/*
*
*    Fun:    soUtlDelSoContactParam
*
*    Desc:    Delete the structure SoContactParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoContactParam
(
SoContactParam *dst
)
#else
PUBLIC S16 soUtlDelSoContactParam(dst)
SoContactParam *dst;
#endif
{

   TRC3(soUtlDelSoContactParam)

   if( dst->contactParamType.pres != NOTPRSNT )
   {
      switch( dst->contactParamType.val )
      {
         case  SO_CONTACTPARAM_EXTN :
            if (soUtlDelSoParameter(&dst->t.genericParam) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_CONTACTPARAM_FEAT :
#ifdef SO_CALLERPREF
            if (soUtlDelSoStrValue(&dst->t.fparam) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_CONTACTPARAM_STD :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoContactParam*/

/*
*
*    Fun:    soUtlDelSoInfoParam
*
*    Desc:    Delete the structure SoInfoParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoInfoParam
(
SoInfoParam *dst
)
#else
PUBLIC S16 soUtlDelSoInfoParam(dst)
SoInfoParam *dst;
#endif
{

   TRC3(soUtlDelSoInfoParam)

   if( dst->infoParamType.pres != NOTPRSNT )
   {
      switch( dst->infoParamType.val )
      {
         case  SO_INFOPARAM_EXTN :
            if (soUtlDelSoParameter(&dst->t.genericParam) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_INFOPARAM_PURPOSE :
            if (soUtlDelSoCallInfoPurpose(&dst->t.callInfoPurpose) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoInfoParam*/

/*
*
*    Fun:    soUtlDelSoNameAddr
*
*    Desc:    Delete the structure SoNameAddr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoNameAddr
(
SoNameAddr *dst
)
#else
PUBLIC S16 soUtlDelSoNameAddr(dst)
SoNameAddr *dst;
#endif
{

   TRC3(soUtlDelSoNameAddr)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoDisplayName(&dst->displayName) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoAddrSpec(&dst->addrSpec) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoNameAddr*/

/*
*
*    Fun:    soUtlDelSoContactParams
*
*    Desc:    Delete the structure SoContactParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoContactParams
(
SoContactParams *dst
)
#else
PUBLIC S16 soUtlDelSoContactParams(dst)
SoContactParams *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoContactParams)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoContactParam(dst->contactParam[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->contactParam[i], sizeof(SoContactParam));
      }
      SOFREE(dst->contactParam, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoContactParams*/

/*
*
*    Fun:    soUtlDelSoViaParam
*
*    Desc:    Delete the structure SoViaParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoViaParam
(
SoViaParam *dst
)
#else
PUBLIC S16 soUtlDelSoViaParam(dst)
SoViaParam *dst;
#endif
{

   TRC3(soUtlDelSoViaParam)

   if( dst->viaParamType.pres != NOTPRSNT )
   {
      switch( dst->viaParamType.val )
      {
         case  SO_VIAPARAM_GENERICPARAM :
            if (soUtlDelSoParameter(&dst->t.genericParam) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_VIAPARAM_MADDR :
            if (soUtlDelSoHost(&dst->t.maddr) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_VIAPARAM_RECEIVED :
            if (soUtlDelSoHost(&dst->t.received) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_VIAPARAM_VIABRANCH :
            if (soUtlDelTknStrOSXL(&dst->t.viaBranch) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_VIAPARAM_VIACOMP :
            if (soUtlDelSoStrValue(&dst->t.comp) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_VIAPARAM_VIARPORT :
#ifdef SO_NAT
#endif /*  SO_NAT  */
            break;
         case  SO_VIAPARAM_VIATTL :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoViaParam*/

/*
*
*    Fun:    soUtlDelSoParameters
*
*    Desc:    Delete the structure SoParameters
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoParameters
(
SoParameters *dst
)
#else
PUBLIC S16 soUtlDelSoParameters(dst)
SoParameters *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoParameters)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoParameter(dst->parameter[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->parameter[i], sizeof(SoParameter));
      }
      SOFREE(dst->parameter, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoParameters*/

/*
*
*    Fun:    soUtlDelSoProtocolName
*
*    Desc:    Delete the structure SoProtocolName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoProtocolName
(
SoProtocolName *dst
)
#else
PUBLIC S16 soUtlDelSoProtocolName(dst)
SoProtocolName *dst;
#endif
{

   TRC3(soUtlDelSoProtocolName)

   if (soUtlDelTknStrOSXL(&dst->protocolExt) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlDelSoProtocolName*/

/*
*
*    Fun:    soUtlDelSoMediaRange
*
*    Desc:    Delete the structure SoMediaRange
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoMediaRange
(
SoMediaRange *dst
)
#else
PUBLIC S16 soUtlDelSoMediaRange(dst)
SoMediaRange *dst;
#endif
{

   TRC3(soUtlDelSoMediaRange)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoMediaRangeVal(&dst->mediaRangeVal) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoParameters(&dst->parameters) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoMediaRange*/

/*
*
*    Fun:    soUtlDelSoCodings
*
*    Desc:    Delete the structure SoCodings
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoCodings
(
SoCodings *dst
)
#else
PUBLIC S16 soUtlDelSoCodings(dst)
SoCodings *dst;
#endif
{

   TRC3(soUtlDelSoCodings)

   if (soUtlDelSoExtVal(&dst->contentCoding) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlDelSoCodings*/

/*
*
*    Fun:    soUtlDelSoInfoParams
*
*    Desc:    Delete the structure SoInfoParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoInfoParams
(
SoInfoParams *dst
)
#else
PUBLIC S16 soUtlDelSoInfoParams(dst)
SoInfoParams *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoInfoParams)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoInfoParam(dst->infoParam[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->infoParam[i], sizeof(SoInfoParam));
      }
      SOFREE(dst->infoParam, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoInfoParams*/

/*
*
*    Fun:    soUtlDelSoAddrCh
*
*    Desc:    Delete the structure SoAddrCh
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAddrCh
(
SoAddrCh *dst
)
#else
PUBLIC S16 soUtlDelSoAddrCh(dst)
SoAddrCh *dst;
#endif
{

   TRC3(soUtlDelSoAddrCh)

   if( dst->addrChType.pres != NOTPRSNT )
   {
      switch( dst->addrChType.val )
      {
         case  SO_ADDRCH_ADDRSPEC :
            if (soUtlDelSoAddrSpec(&dst->t.addrSpec) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_ADDRCH_NAMEADDR :
            if (soUtlDelSoNameAddr(&dst->t.nameAddr) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAddrCh*/

/*
*
*    Fun:    soUtlDelSoContactItem
*
*    Desc:    Delete the structure SoContactItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoContactItem
(
SoContactItem *dst
)
#else
PUBLIC S16 soUtlDelSoContactItem(dst)
SoContactItem *dst;
#endif
{

   TRC3(soUtlDelSoContactItem)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoAddrCh(&dst->contactAddrChoice) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoContactParams(&dst->contactParams) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoContactItem*/

/*
*
*    Fun:    soUtlDelSoAddrParam
*
*    Desc:    Delete the structure SoAddrParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAddrParam
(
SoAddrParam *dst
)
#else
PUBLIC S16 soUtlDelSoAddrParam(dst)
SoAddrParam *dst;
#endif
{

   TRC3(soUtlDelSoAddrParam)

   if( dst->addrParamType.pres != NOTPRSNT )
   {
      switch( dst->addrParamType.val )
      {
         case  SO_ADDRPARAM_GENERICPARAM :
            if (soUtlDelSoParameter(&dst->t.genericParam) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_ADDRPARAM_TAGPARAM :
            if (soUtlDelTknStrOSXL(&dst->t.tagParam) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAddrParam*/

/*
*
*    Fun:    soUtlDelSoAlso
*
*    Desc:    Delete the structure SoAlso
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAlso
(
SoAlso *dst
)
#else
PUBLIC S16 soUtlDelSoAlso(dst)
SoAlso *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoAlso)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoAddrCh(dst->addrChoice[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->addrChoice[i], sizeof(SoAddrCh));
      }
      SOFREE(dst->addrChoice, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAlso*/

/*
*
*    Fun:    soUtlDelSoSentProtocol
*
*    Desc:    Delete the structure SoSentProtocol
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSentProtocol
(
SoSentProtocol *dst
)
#else
PUBLIC S16 soUtlDelSoSentProtocol(dst)
SoSentProtocol *dst;
#endif
{

   TRC3(soUtlDelSoSentProtocol)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoProtocolName(&dst->protocolName) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelTknStrOSXL(&dst->protocolVersion) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoExtVal(&dst->transport) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoSentProtocol*/

/*
*
*    Fun:    soUtlDelSoHostPortType
*
*    Desc:    Delete the structure SoHostPortType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoHostPortType
(
SoHostPortType *dst
)
#else
PUBLIC S16 soUtlDelSoHostPortType(dst)
SoHostPortType *dst;
#endif
{

   TRC3(soUtlDelSoHostPortType)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  SO_HOSTPORTTYPE_HOST :
            if (soUtlDelTknStrOSXL(&dst->t.host) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HOSTPORTTYPE_HOSTPORT :
            if (soUtlDelSoHostPort(&dst->t.hostPort) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoHostPortType*/

/*
*
*    Fun:    soUtlDelSoViaParams
*
*    Desc:    Delete the structure SoViaParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoViaParams
(
SoViaParams *dst
)
#else
PUBLIC S16 soUtlDelSoViaParams(dst)
SoViaParams *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoViaParams)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoViaParam(dst->viaParam[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->viaParam[i], sizeof(SoViaParam));
      }
      SOFREE(dst->viaParam, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoViaParams*/

/*
*
*    Fun:    soUtlDelSoRetryParam
*
*    Desc:    Delete the structure SoRetryParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRetryParam
(
SoRetryParam *dst
)
#else
PUBLIC S16 soUtlDelSoRetryParam(dst)
SoRetryParam *dst;
#endif
{

   TRC3(soUtlDelSoRetryParam)

   if( dst->retryParamType.pres != NOTPRSNT )
   {
      switch( dst->retryParamType.val )
      {
         case  SO_RETRYPARAM_DURATION :
            break;
         case  SO_RETRYPARAM_EXTN :
            if (soUtlDelSoParameter(&dst->t.genericParam) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRetryParam*/

/*
*
*    Fun:    soUtlDelSoAcceptParam
*
*    Desc:    Delete the structure SoAcceptParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAcceptParam
(
SoAcceptParam *dst
)
#else
PUBLIC S16 soUtlDelSoAcceptParam(dst)
SoAcceptParam *dst;
#endif
{

   TRC3(soUtlDelSoAcceptParam)

   if( dst->prodcomType.pres != NOTPRSNT )
   {
      switch( dst->prodcomType.val )
      {
         case  SO_GENERIC_PARAM_TYPE :
            if (soUtlDelSoParameter(&dst->u.genericParam) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_QVALUE_TYPE :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAcceptParam*/

/*
*
*    Fun:    soUtlDelSoAcceptParams
*
*    Desc:    Delete the structure SoAcceptParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAcceptParams
(
SoAcceptParams *dst
)
#else
PUBLIC S16 soUtlDelSoAcceptParams(dst)
SoAcceptParams *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoAcceptParams)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoAcceptParam(dst->ap[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->ap[i], sizeof(SoAcceptParam));
      }
      SOFREE(dst->ap, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAcceptParams*/

/*
*
*    Fun:    soUtlDelSoAcceptSeq
*
*    Desc:    Delete the structure SoAcceptSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAcceptSeq
(
SoAcceptSeq *dst
)
#else
PUBLIC S16 soUtlDelSoAcceptSeq(dst)
SoAcceptSeq *dst;
#endif
{

   TRC3(soUtlDelSoAcceptSeq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoMediaRange(&dst->mediaRange) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoAcceptParams(&dst->acceptParams) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAcceptSeq*/

/*
*
*    Fun:    soUtlDelSoAcceptEncodingSeq
*
*    Desc:    Delete the structure SoAcceptEncodingSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAcceptEncodingSeq
(
SoAcceptEncodingSeq *dst
)
#else
PUBLIC S16 soUtlDelSoAcceptEncodingSeq(dst)
SoAcceptEncodingSeq *dst;
#endif
{

   TRC3(soUtlDelSoAcceptEncodingSeq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoCodings(&dst->codings) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoAcceptParams(&dst->apList) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAcceptEncodingSeq*/

/*
*
*    Fun:    soUtlDelSoAcceptLanguageSeq
*
*    Desc:    Delete the structure SoAcceptLanguageSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAcceptLanguageSeq
(
SoAcceptLanguageSeq *dst
)
#else
PUBLIC S16 soUtlDelSoAcceptLanguageSeq(dst)
SoAcceptLanguageSeq *dst;
#endif
{

   TRC3(soUtlDelSoAcceptLanguageSeq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelTknStrOSXL(&dst->languageRange) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoAcceptParams(&dst->acceptParams) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAcceptLanguageSeq*/

/*
*
*    Fun:    soUtlDelSoContactItems
*
*    Desc:    Delete the structure SoContactItems
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoContactItems
(
SoContactItems *dst
)
#else
PUBLIC S16 soUtlDelSoContactItems(dst)
SoContactItems *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoContactItems)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoContactItem(dst->contactItem[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->contactItem[i], sizeof(SoContactItem));
      }
      SOFREE(dst->contactItem, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoContactItems*/

/*
*
*    Fun:    soUtlDelSoProdcom
*
*    Desc:    Delete the structure SoProdcom
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoProdcom
(
SoProdcom *dst
)
#else
PUBLIC S16 soUtlDelSoProdcom(dst)
SoProdcom *dst;
#endif
{

   TRC3(soUtlDelSoProdcom)

   if( dst->prodcomType.pres != NOTPRSNT )
   {
      switch( dst->prodcomType.val )
      {
         case  SO_PRODCOM_COMMENT :
            if (soUtlDelTknStrOSXL(&dst->t.comment) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_PRODCOM_PRODUCT :
            if (soUtlDelSoNameVal(&dst->t.product) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoProdcom*/

/*
*
*    Fun:    soUtlDelSoViaItem
*
*    Desc:    Delete the structure SoViaItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoViaItem
(
SoViaItem *dst
)
#else
PUBLIC S16 soUtlDelSoViaItem(dst)
SoViaItem *dst;
#endif
{

   TRC3(soUtlDelSoViaItem)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoSentProtocol(&dst->sentProtocol) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoHostPortType(&dst->sentBy) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoViaParams(&dst->viaParams) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelTknStrOSXL(&dst->viaComment) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoViaItem*/

/*
*
*    Fun:    soUtlDelSoRouteSeq
*
*    Desc:    Delete the structure SoRouteSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRouteSeq
(
SoRouteSeq *dst
)
#else
PUBLIC S16 soUtlDelSoRouteSeq(dst)
SoRouteSeq *dst;
#endif
{

   TRC3(soUtlDelSoRouteSeq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoNameAddr(&dst->nameAddr) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoParameters(&dst->rParams) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRouteSeq*/

/*
*
*    Fun:    soUtlDelSoWarningItem
*
*    Desc:    Delete the structure SoWarningItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoWarningItem
(
SoWarningItem *dst
)
#else
PUBLIC S16 soUtlDelSoWarningItem(dst)
SoWarningItem *dst;
#endif
{

   TRC3(soUtlDelSoWarningItem)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelTknStrOSXL(&dst->warnAgent) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelTknStrOSXL(&dst->warnText) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoWarningItem*/

/*
*
*    Fun:    soUtlDelSoAccept
*
*    Desc:    Delete the structure SoAccept
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAccept
(
SoAccept *dst
)
#else
PUBLIC S16 soUtlDelSoAccept(dst)
SoAccept *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoAccept)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoAcceptSeq(dst->accept[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->accept[i], sizeof(SoAcceptSeq));
      }
      SOFREE(dst->accept, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAccept*/

/*
*
*    Fun:    soUtlDelSoAcceptEncoding
*
*    Desc:    Delete the structure SoAcceptEncoding
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAcceptEncoding
(
SoAcceptEncoding *dst
)
#else
PUBLIC S16 soUtlDelSoAcceptEncoding(dst)
SoAcceptEncoding *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoAcceptEncoding)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoAcceptEncodingSeq(dst->acceptEncoding[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->acceptEncoding[i], sizeof(SoAcceptEncodingSeq));
      }
      SOFREE(dst->acceptEncoding, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAcceptEncoding*/

/*
*
*    Fun:    soUtlDelSoAcceptLanguage
*
*    Desc:    Delete the structure SoAcceptLanguage
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAcceptLanguage
(
SoAcceptLanguage *dst
)
#else
PUBLIC S16 soUtlDelSoAcceptLanguage(dst)
SoAcceptLanguage *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoAcceptLanguage)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoAcceptLanguageSeq(dst->acceptLanguage[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->acceptLanguage[i], sizeof(SoAcceptLanguageSeq));
      }
      SOFREE(dst->acceptLanguage, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAcceptLanguage*/
#ifdef SO_EVENT

/*
*
*    Fun:    soUtlDelSoEventHeader
*
*    Desc:    Delete the structure SoEventHeader
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoEventHeader
(
SoEventHeader *dst
)
#else
PUBLIC S16 soUtlDelSoEventHeader(dst)
SoEventHeader *dst;
#endif
{

   TRC3(soUtlDelSoEventHeader)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelTknStrOSXL(&dst->eventName) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoParameters(&dst->params) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoEventHeader*/
#endif /* SO_EVENT */

/*
*
*    Fun:    soUtlDelSoCallInfoSeq
*
*    Desc:    Delete the structure SoCallInfoSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoCallInfoSeq
(
SoCallInfoSeq *dst
)
#else
PUBLIC S16 soUtlDelSoCallInfoSeq(dst)
SoCallInfoSeq *dst;
#endif
{

   TRC3(soUtlDelSoCallInfoSeq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoAbsoluteUri(&dst->absoluteUri) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoInfoParams(&dst->infoParams) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoCallInfoSeq*/

/*
*
*    Fun:    soUtlDelSoCallInfo
*
*    Desc:    Delete the structure SoCallInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoCallInfo
(
SoCallInfo *dst
)
#else
PUBLIC S16 soUtlDelSoCallInfo(dst)
SoCallInfo *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoCallInfo)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoCallInfoSeq(dst->callInfo[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->callInfo[i], sizeof(SoCallInfoSeq));
      }
      SOFREE(dst->callInfo, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoCallInfo*/

/*
*
*    Fun:    soUtlDelSoInfoSeq
*
*    Desc:    Delete the structure SoInfoSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoInfoSeq
(
SoInfoSeq *dst
)
#else
PUBLIC S16 soUtlDelSoInfoSeq(dst)
SoInfoSeq *dst;
#endif
{

   TRC3(soUtlDelSoInfoSeq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoAbsoluteUri(&dst->absoluteUri) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoParameters(&dst->genericParams) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoInfoSeq*/

/*
*
*    Fun:    soUtlDelSoInfo
*
*    Desc:    Delete the structure SoInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoInfo
(
SoInfo *dst
)
#else
PUBLIC S16 soUtlDelSoInfo(dst)
SoInfo *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoInfo)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoInfoSeq(dst->info[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->info[i], sizeof(SoInfoSeq));
      }
      SOFREE(dst->info, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoInfo*/

/*
*
*    Fun:    soUtlDelSoAddrParams
*
*    Desc:    Delete the structure SoAddrParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAddrParams
(
SoAddrParams *dst
)
#else
PUBLIC S16 soUtlDelSoAddrParams(dst)
SoAddrParams *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoAddrParams)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoAddrParam(dst->addrParam[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->addrParam[i], sizeof(SoAddrParam));
      }
      SOFREE(dst->addrParam, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAddrParams*/

/*
*
*    Fun:    soUtlDelSoRoute
*
*    Desc:    Delete the structure SoRoute
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRoute
(
SoRoute *dst
)
#else
PUBLIC S16 soUtlDelSoRoute(dst)
SoRoute *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoRoute)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoRouteSeq(dst->route[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->route[i], sizeof(SoRouteSeq));
      }
      SOFREE(dst->route, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRoute*/

/*
*
*    Fun:    soUtlDelSoDispositionParam
*
*    Desc:    Delete the structure SoDispositionParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoDispositionParam
(
SoDispositionParam *dst
)
#else
PUBLIC S16 soUtlDelSoDispositionParam(dst)
SoDispositionParam *dst;
#endif
{

   TRC3(soUtlDelSoDispositionParam)

   if( dst->dispositionParamType.pres != NOTPRSNT )
   {
      switch( dst->dispositionParamType.val )
      {
         case  SO_DISP_PARAM_EXTN :
            if (soUtlDelSoParameter(&dst->t.parameter) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_DISP_PARAM_HANDLING :
            if (soUtlDelSoExtVal(&dst->t.handlingParmVal) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoDispositionParam*/

/*
*
*    Fun:    soUtlDelSoDispositionParams
*
*    Desc:    Delete the structure SoDispositionParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoDispositionParams
(
SoDispositionParams *dst
)
#else
PUBLIC S16 soUtlDelSoDispositionParams(dst)
SoDispositionParams *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoDispositionParams)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoDispositionParam(dst->dispositionParam[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->dispositionParam[i], sizeof(SoDispositionParam));
      }
      SOFREE(dst->dispositionParam, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoDispositionParams*/

/*
*
*    Fun:    soUtlDelSoAllow
*
*    Desc:    Delete the structure SoAllow
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAllow
(
SoAllow *dst
)
#else
PUBLIC S16 soUtlDelSoAllow(dst)
SoAllow *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoAllow)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoExtVal(dst->method[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->method[i], sizeof(SoExtVal));
      }
      SOFREE(dst->method, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAllow*/

/*
*
*    Fun:    soUtlDelSoContentDisposition
*
*    Desc:    Delete the structure SoContentDisposition
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoContentDisposition
(
SoContentDisposition *dst
)
#else
PUBLIC S16 soUtlDelSoContentDisposition(dst)
SoContentDisposition *dst;
#endif
{

   TRC3(soUtlDelSoContentDisposition)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoStrValue(&dst->type) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoDispositionParams(&dst->params) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoContentDisposition*/

/*
*
*    Fun:    soUtlDelSoRetryParams
*
*    Desc:    Delete the structure SoRetryParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRetryParams
(
SoRetryParams *dst
)
#else
PUBLIC S16 soUtlDelSoRetryParams(dst)
SoRetryParams *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoRetryParams)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoRetryParam(dst->retryParam[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->retryParam[i], sizeof(SoRetryParam));
      }
      SOFREE(dst->retryParam, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRetryParams*/

/*
*
*    Fun:    soUtlDelSoProdcomLst
*
*    Desc:    Delete the structure SoProdcomLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoProdcomLst
(
SoProdcomLst *dst
)
#else
PUBLIC S16 soUtlDelSoProdcomLst(dst)
SoProdcomLst *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoProdcomLst)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoProdcom(dst->prodcom[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->prodcom[i], sizeof(SoProdcom));
      }
      SOFREE(dst->prodcom, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoProdcomLst*/

/*
*
*    Fun:    soUtlDelSoWarning
*
*    Desc:    Delete the structure SoWarning
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoWarning
(
SoWarning *dst
)
#else
PUBLIC S16 soUtlDelSoWarning(dst)
SoWarning *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoWarning)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoWarningItem(dst->warningItem[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->warningItem[i], sizeof(SoWarningItem));
      }
      SOFREE(dst->warningItem, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoWarning*/

/*
*
*    Fun:    soUtlDelSoContact
*
*    Desc:    Delete the structure SoContact
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoContact
(
SoContact *dst
)
#else
PUBLIC S16 soUtlDelSoContact(dst)
SoContact *dst;
#endif
{

   TRC3(soUtlDelSoContact)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoContactItems(&dst->contactItems) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoContact*/

/*
*
*    Fun:    soUtlDelSoCSeq
*
*    Desc:    Delete the structure SoCSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoCSeq
(
SoCSeq *dst
)
#else
PUBLIC S16 soUtlDelSoCSeq(dst)
SoCSeq *dst;
#endif
{

   TRC3(soUtlDelSoCSeq)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoExtVal(&dst->method) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoCSeq*/

/*
*
*    Fun:    soUtlDelSoAddress
*
*    Desc:    Delete the structure SoAddress
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAddress
(
SoAddress *dst
)
#else
PUBLIC S16 soUtlDelSoAddress(dst)
SoAddress *dst;
#endif
{

   TRC3(soUtlDelSoAddress)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoAddrCh(&dst->addrCh) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoAddrParams(&dst->addrParams) != ROK)
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /*end of function soUtlDelSoAddress*/

/*
*
*    Fun:    soUtlDelSoVia
*
*    Desc:    Delete the structure SoVia
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoVia
(
SoVia *dst
)
#else
PUBLIC S16 soUtlDelSoVia(dst)
SoVia *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoVia)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoViaItem(dst->viaItem[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->viaItem[i], sizeof(SoViaItem));
      }
      SOFREE(dst->viaItem, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   
   RETVALUE(ROK);
} /*end of function soUtlDelSoVia*/

/*
*
*    Fun:    soUtlDelSoAuthorization
*
*    Desc:    Delete the structure SoAuthorization
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAuthorization
(
SoAuthorization *dst
)
#else
PUBLIC S16 soUtlDelSoAuthorization(dst)
SoAuthorization *dst;
#endif
{

   TRC3(soUtlDelSoAuthorization)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelTknStrOSXL(&dst->authScheme) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoParameters(&dst->authParams) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAuthorization*/

/*
*
*    Fun:    soUtlDelSoAuthenticate
*
*    Desc:    Delete the structure SoAuthenticate
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAuthenticate
(
SoAuthenticate *dst
)
#else
PUBLIC S16 soUtlDelSoAuthenticate(dst)
SoAuthenticate *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoAuthenticate)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoAuthorization(dst->challenge[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->challenge[i], sizeof(SoAuthorization));
      }
      SOFREE(dst->challenge, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAuthenticate*/

/*
*
*    Fun:    soUtlDelSoReplyTo
*
*    Desc:    Delete the structure SoReplyTo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoReplyTo
(
SoReplyTo *dst
)
#else
PUBLIC S16 soUtlDelSoReplyTo(dst)
SoReplyTo *dst;
#endif
{

   TRC3(soUtlDelSoReplyTo)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoAddrCh(&dst->addr) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoParameters(&dst->params) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoReplyTo*/

/*
*
*    Fun:    soUtlDelSoContentEncoding
*
*    Desc:    Delete the structure SoContentEncoding
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoContentEncoding
(
SoContentEncoding *dst
)
#else
PUBLIC S16 soUtlDelSoContentEncoding(dst)
SoContentEncoding *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoContentEncoding)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoExtVal(dst->contentCoding[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->contentCoding[i], sizeof(SoExtVal));
      }
      SOFREE(dst->contentCoding, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoContentEncoding*/

/*
*
*    Fun:    soUtlDelSoContentTypeHdr
*
*    Desc:    Delete the structure SoContentTypeHdr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoContentTypeHdr
(
SoContentTypeHdr *dst
)
#else
PUBLIC S16 soUtlDelSoContentTypeHdr(dst)
SoContentTypeHdr *dst;
#endif
{

   TRC3(soUtlDelSoContentTypeHdr)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoStrValue(&dst->type) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoStrValue(&dst->subType) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoParameters(&dst->parameters) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoContentTypeHdr*/

/*
*
*    Fun:    soUtlDelSoRetryAfter
*
*    Desc:    Delete the structure SoRetryAfter
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRetryAfter
(
SoRetryAfter *dst
)
#else
PUBLIC S16 soUtlDelSoRetryAfter(dst)
SoRetryAfter *dst;
#endif
{

   TRC3(soUtlDelSoRetryAfter)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelTknStrOSXL(&dst->retryAfterComment) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoRetryParams(&dst->retryParams) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRetryAfter*/

/*
*
*    Fun:    soUtlDelSoRAck
*
*    Desc:    Delete the structure SoRAck
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRAck
(
SoRAck *dst
)
#else
PUBLIC S16 soUtlDelSoRAck(dst)
SoRAck *dst;
#endif
{

   TRC3(soUtlDelSoRAck)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoExtVal(&dst->method) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRAck*/
#ifdef SO_REFER

/*
*
*    Fun:    soUtlDelSoReferTo
*
*    Desc:    Delete the structure SoReferTo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoReferTo
(
SoReferTo *dst
)
#else
PUBLIC S16 soUtlDelSoReferTo(dst)
SoReferTo *dst;
#endif
{

   TRC3(soUtlDelSoReferTo)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoAddrCh(&dst->addr) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoParameters(&dst->params) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoReferTo*/

/*
*
*    Fun:    soUtlDelSoReferredByParam
*
*    Desc:    Delete the structure SoReferredByParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoReferredByParam
(
SoReferredByParam *dst
)
#else
PUBLIC S16 soUtlDelSoReferredByParam(dst)
SoReferredByParam *dst;
#endif
{

   TRC3(soUtlDelSoReferredByParam)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  SO_RF_BY_GENERIC_PARAM :
            if (soUtlDelSoParameter(&dst->t.genericParam) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_RF_BY_ID_PAR :
            if (soUtlDelTknStrOSXL(&dst->t.cid) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoReferredByParam*/

/*
*
*    Fun:    soUtlDelSoReferredByParams
*
*    Desc:    Delete the structure SoReferredByParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoReferredByParams
(
SoReferredByParams *dst
)
#else
PUBLIC S16 soUtlDelSoReferredByParams(dst)
SoReferredByParams *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoReferredByParams)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoReferredByParam(dst->soRefrdByPar[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->soRefrdByPar[i], sizeof(SoReferredByParam));
      }
      SOFREE(dst->soRefrdByPar, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoReferredByParams*/

/*
*
*    Fun:    soUtlDelSoReferredBy
*
*    Desc:    Delete the structure SoReferredBy
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoReferredBy
(
SoReferredBy *dst
)
#else
PUBLIC S16 soUtlDelSoReferredBy(dst)
SoReferredBy *dst;
#endif
{

   TRC3(soUtlDelSoReferredBy)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoAddrCh(&dst->referredUrl) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoReferredByParams(&dst->refrdByPar) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoReferredBy*/

/*
*
*    Fun:    soUtlDelSoReplacesParam
*
*    Desc:    Delete the structure SoReplacesParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoReplacesParam
(
SoReplacesParam *dst
)
#else
PUBLIC S16 soUtlDelSoReplacesParam(dst)
SoReplacesParam *dst;
#endif
{

   TRC3(soUtlDelSoReplacesParam)

   if( dst->paramType.pres != NOTPRSNT )
   {
      switch( dst->paramType.val )
      {
         case  SO_REPLACES_GENERIC_PARAMS :
            if (soUtlDelSoParameter(&dst->u.genericParams) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_REPLACES_PARAMTYPE_FROMTAG :
            if (soUtlDelTknStrOSXL(&dst->u.fromTag) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_REPLACES_PARAMTYPE_TOTAG :
            if (soUtlDelTknStrOSXL(&dst->u.toTag) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoReplacesParam*/

/*
*
*    Fun:    soUtlDelSoReplacesParams
*
*    Desc:    Delete the structure SoReplacesParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoReplacesParams
(
SoReplacesParams *dst
)
#else
PUBLIC S16 soUtlDelSoReplacesParams(dst)
SoReplacesParams *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoReplacesParams)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoReplacesParam(dst->replacesParam[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->replacesParam[i], sizeof(SoReplacesParam));
      }
      SOFREE(dst->replacesParam, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoReplacesParams*/

/*
*
*    Fun:    soUtlDelSoReplaces
*
*    Desc:    Delete the structure SoReplaces
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoReplaces
(
SoReplaces *dst
)
#else
PUBLIC S16 soUtlDelSoReplaces(dst)
SoReplaces *dst;
#endif
{

   TRC3(soUtlDelSoReplaces)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelTknStrOSXL(&dst->callId) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoReplacesParams(&dst->replacesParams) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoReplaces*/
#endif /* SO_REFER */
#ifdef SO_SESSTIMER

/*
*
*    Fun:    soUtlDelSoSessExpParam
*
*    Desc:    Delete the structure SoSessExpParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSessExpParam
(
SoSessExpParam *dst
)
#else
PUBLIC S16 soUtlDelSoSessExpParam(dst)
SoSessExpParam *dst;
#endif
{

   TRC3(soUtlDelSoSessExpParam)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  SO_SESSION_EXP_EXTN :
            if (soUtlDelSoParameter(&dst->u.param) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_SESSION_EXP_REFRESHER :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoSessExpParam*/

/*
*
*    Fun:    soUtlDelSoSessExpParams
*
*    Desc:    Delete the structure SoSessExpParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSessExpParams
(
SoSessExpParams *dst
)
#else
PUBLIC S16 soUtlDelSoSessExpParams(dst)
SoSessExpParams *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoSessExpParams)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoSessExpParam(dst->param[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->param[i], sizeof(SoSessExpParam));
      }
      SOFREE(dst->param, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoSessExpParams*/

/*
*
*    Fun:    soUtlDelSoSessionExpires
*
*    Desc:    Delete the structure SoSessionExpires
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSessionExpires
(
SoSessionExpires *dst
)
#else
PUBLIC S16 soUtlDelSoSessionExpires(dst)
SoSessionExpires *dst;
#endif
{

   TRC3(soUtlDelSoSessionExpires)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoSessExpParams(&dst->params) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoSessionExpires*/

/*
*
*    Fun:    soUtlDelSoMinSE
*
*    Desc:    Delete the structure SoMinSE
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoMinSE
(
SoMinSE *dst
)
#else
PUBLIC S16 soUtlDelSoMinSE(dst)
SoMinSE *dst;
#endif
{

   TRC3(soUtlDelSoMinSE)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoParameters(&dst->params) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoMinSE*/
#endif /* SO_SESSIONTIMER */
#ifdef SO_CALLERPREF

/*
*
*    Fun:    soUtlDelSoRequestDispositionParam
*
*    Desc:    Delete the structure SoRequestDispositionParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRequestDispositionParam
(
SoRequestDispositionParam *dst
)
#else
PUBLIC S16 soUtlDelSoRequestDispositionParam(dst)
SoRequestDispositionParam *dst;
#endif
{

   TRC3(soUtlDelSoRequestDispositionParam)

   RETVALUE(ROK);
} /*end of function soUtlDelSoRequestDispositionParam*/

/*
*
*    Fun:    soUtlDelSoRequestDisposition
*
*    Desc:    Delete the structure SoRequestDisposition
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRequestDisposition
(
SoRequestDisposition *dst
)
#else
PUBLIC S16 soUtlDelSoRequestDisposition(dst)
SoRequestDisposition *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoRequestDisposition)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoRequestDispositionParam(dst->requestDispositionParams[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->requestDispositionParams[i], sizeof(SoRequestDispositionParam));
      }
      SOFREE(dst->requestDispositionParams, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRequestDisposition*/

/*
*
*    Fun:    soUtlDelSoAcParam
*
*    Desc:    Delete the structure SoAcParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAcParam
(
SoAcParam *dst
)
#else
PUBLIC S16 soUtlDelSoAcParam(dst)
SoAcParam *dst;
#endif
{

   TRC3(soUtlDelSoAcParam)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  SO_ACCEPTCONTACT_PAR_EXPLICIT :
            break;
         case  SO_ACCEPTCONTACT_PAR_EXTN :
            if (soUtlDelSoParameter(&dst->u.genericParam) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_ACCEPTCONTACT_PAR_FP :
            if (soUtlDelSoStrValue(&dst->u.fparam) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_ACCEPTCONTACT_PAR_REQUIRE :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAcParam*/

/*
*
*    Fun:    soUtlDelSoAcParams
*
*    Desc:    Delete the structure SoAcParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAcParams
(
SoAcParams *dst
)
#else
PUBLIC S16 soUtlDelSoAcParams(dst)
SoAcParams *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoAcParams)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoAcParam(dst->acParam[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->acParam[i], sizeof(SoAcParam));
      }
      SOFREE(dst->acParam, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAcParams*/

/*
*
*    Fun:    soUtlDelSoAcceptContact
*
*    Desc:    Delete the structure SoAcceptContact
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAcceptContact
(
SoAcceptContact *dst
)
#else
PUBLIC S16 soUtlDelSoAcceptContact(dst)
SoAcceptContact *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoAcceptContact)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoAcParams(dst->acParams[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->acParams[i], sizeof(SoAcParams));
      }
      SOFREE(dst->acParams, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAcceptContact*/

/*
*
*    Fun:    soUtlDelSoRcParam
*
*    Desc:    Delete the structure SoRcParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRcParam
(
SoRcParam *dst
)
#else
PUBLIC S16 soUtlDelSoRcParam(dst)
SoRcParam *dst;
#endif
{

   TRC3(soUtlDelSoRcParam)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  SO_REJECTCONTACT_PAR_EXTN :
            if (soUtlDelSoParameter(&dst->u.genericParam) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_REJECTCONTACT_PAR_FP :
            if (soUtlDelSoStrValue(&dst->u.fparam) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRcParam*/

/*
*
*    Fun:    soUtlDelSoRcParams
*
*    Desc:    Delete the structure SoRcParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRcParams
(
SoRcParams *dst
)
#else
PUBLIC S16 soUtlDelSoRcParams(dst)
SoRcParams *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoRcParams)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoRcParam(dst->rcParam[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->rcParam[i], sizeof(SoRcParam));
      }
      SOFREE(dst->rcParam, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRcParams*/

/*
*
*    Fun:    soUtlDelSoRejectContact
*
*    Desc:    Delete the structure SoRejectContact
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRejectContact
(
SoRejectContact *dst
)
#else
PUBLIC S16 soUtlDelSoRejectContact(dst)
SoRejectContact *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoRejectContact)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoRcParams(dst->rcParams[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->rcParams[i], sizeof(SoRcParams));
      }
      SOFREE(dst->rcParams, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRejectContact*/
#endif /* SO_CALLERPREF */

/*
*
*    Fun:    soUtlDelSoTypeVal
*
*    Desc:    Delete the structure SoTypeVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoTypeVal
(
SoTypeVal *dst
)
#else
PUBLIC S16 soUtlDelSoTypeVal(dst)
SoTypeVal *dst;
#endif
{

   TRC3(soUtlDelSoTypeVal)

   if (soUtlDelSoStrValue(&dst->type) != ROK)
      RETVALUE(RFAILED);
   if (soUtlDelSoStrValue(&dst->val) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlDelSoTypeVal*/

/*
*
*    Fun:    soUtlDelSoPrivLst
*
*    Desc:    Delete the structure SoPrivLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoPrivLst
(
SoPrivLst *dst
)
#else
PUBLIC S16 soUtlDelSoPrivLst(dst)
SoPrivLst *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoPrivLst)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoTypeVal(dst->privVal[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->privVal[i], sizeof(SoTypeVal));
      }
      SOFREE(dst->privVal, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoPrivLst*/

/*
*
*    Fun:    soUtlDelSoRpiTok
*
*    Desc:    Delete the structure SoRpiTok
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRpiTok
(
SoRpiTok *dst
)
#else
PUBLIC S16 soUtlDelSoRpiTok(dst)
SoRpiTok *dst;
#endif
{

   TRC3(soUtlDelSoRpiTok)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  SO_RPI_ID_TYPE :
            if (soUtlDelSoStrValue(&dst->u.id) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_RPI_OTHER_RPI_TOKEN :
            if (soUtlDelSoTypeVal(&dst->u.othRpi) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_RPI_PRIVACY :
            if (soUtlDelSoPrivLst(&dst->u.prvLst) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_RPI_PTY_TYPE :
            if (soUtlDelSoStrValue(&dst->u.party) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_RPI_SCREEN :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRpiTok*/

/*
*
*    Fun:    soUtlDelSoRpiTokLst
*
*    Desc:    Delete the structure SoRpiTokLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRpiTokLst
(
SoRpiTokLst *dst
)
#else
PUBLIC S16 soUtlDelSoRpiTokLst(dst)
SoRpiTokLst *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoRpiTokLst)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoRpiTok(dst->rpiTok[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->rpiTok[i], sizeof(SoRpiTok));
      }
      SOFREE(dst->rpiTok, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRpiTokLst*/

/*
*
*    Fun:    soUtlDelSoRpid
*
*    Desc:    Delete the structure SoRpid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRpid
(
SoRpid *dst
)
#else
PUBLIC S16 soUtlDelSoRpid(dst)
SoRpid *dst;
#endif
{

   TRC3(soUtlDelSoRpid)

   if (soUtlDelSoNameAddr(&dst->nameAddr) != ROK)
      RETVALUE(RFAILED);
   if (soUtlDelSoRpiTokLst(&dst->rpiTokLst) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlDelSoRpid*/

/*
*
*    Fun:    soUtlDelSoRemPartyId
*
*    Desc:    Delete the structure SoRemPartyId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRemPartyId
(
SoRemPartyId *dst
)
#else
PUBLIC S16 soUtlDelSoRemPartyId(dst)
SoRemPartyId *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoRemPartyId)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoRpid(dst->rpidLst[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->rpidLst[i], sizeof(SoRpid));
      }
      SOFREE(dst->rpidLst, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRemPartyId*/

/*
*
*    Fun:    soUtlDelSoRpidPrivcy
*
*    Desc:    Delete the structure SoRpidPrivcy
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRpidPrivcy
(
SoRpidPrivcy *dst
)
#else
PUBLIC S16 soUtlDelSoRpidPrivcy(dst)
SoRpidPrivcy *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoRpidPrivcy)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoRpiTokLst(dst->rpidPriv[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->rpidPriv[i], sizeof(SoRpiTokLst));
      }
      SOFREE(dst->rpidPriv, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRpidPrivcy*/
#ifdef SO_EVENT

/*
*
*    Fun:    soUtlDelSoSubExpParam
*
*    Desc:    Delete the structure SoSubExpParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSubExpParam
(
SoSubExpParam *dst
)
#else
PUBLIC S16 soUtlDelSoSubExpParam(dst)
SoSubExpParam *dst;
#endif
{

   TRC3(soUtlDelSoSubExpParam)

   if( dst->type.pres != NOTPRSNT )
   {
      switch( dst->type.val )
      {
         case  SO_SUB_EXP_PAR_EXPIRES :
            break;
         case  SO_SUB_EXP_PAR_GENERIC_PARAM :
            if (soUtlDelSoParameter(&dst->u.genericParam) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_SUB_EXP_PAR_REASON :
            if (soUtlDelSoStrValue(&dst->u.reason) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_SUB_EXP_PAR_RETRY_AFT :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoSubExpParam*/

/*
*
*    Fun:    soUtlDelSoSubExpParams
*
*    Desc:    Delete the structure SoSubExpParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSubExpParams
(
SoSubExpParams *dst
)
#else
PUBLIC S16 soUtlDelSoSubExpParams(dst)
SoSubExpParams *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoSubExpParams)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoSubExpParam(dst->subExpParamList[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->subExpParamList[i], sizeof(SoSubExpParam));
      }
      SOFREE(dst->subExpParamList, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoSubExpParams*/

/*
*
*    Fun:    soUtlDelSoSubscState
*
*    Desc:    Delete the structure SoSubscState
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSubscState
(
SoSubscState *dst
)
#else
PUBLIC S16 soUtlDelSoSubscState(dst)
SoSubscState *dst;
#endif
{

   TRC3(soUtlDelSoSubscState)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoStrValue(&dst->subVal) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoSubExpParams(&dst->subExpParams) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoSubscState*/
#endif /* SO_EVENT */

/*
*
*    Fun:    soUtlDelSoMechPar
*
*    Desc:    Delete the structure SoMechPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoMechPar
(
SoMechPar *dst
)
#else
PUBLIC S16 soUtlDelSoMechPar(dst)
SoMechPar *dst;
#endif
{

   TRC3(soUtlDelSoMechPar)

   if( dst->mechParamType.pres != NOTPRSNT )
   {
      switch( dst->mechParamType.val )
      {
         case  SO_MECH_PAR_DG_ALG :
            if (soUtlDelTknStrOSXL(&dst->u.dgAlg) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_MECH_PAR_DG_QOP :
            if (soUtlDelTknStrOSXL(&dst->u.dgQop) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_MECH_PAR_DG_VERIFY :
            if (soUtlDelTknStrOSXL(&dst->u.dgVerify) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_MECH_PAR_EXTN :
            if (soUtlDelSoParameter(&dst->u.ext) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_MECH_PAR_PREF :
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoMechPar*/

/*
*
*    Fun:    soUtlDelSoMechPars
*
*    Desc:    Delete the structure SoMechPars
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoMechPars
(
SoMechPars *dst
)
#else
PUBLIC S16 soUtlDelSoMechPars(dst)
SoMechPars *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoMechPars)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoMechPar(dst->mechPar[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->mechPar[i], sizeof(SoMechPar));
      }
      SOFREE(dst->mechPar, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoMechPars*/

/*
*
*    Fun:    soUtlDelSoSecMech
*
*    Desc:    Delete the structure SoSecMech
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSecMech
(
SoSecMech *dst
)
#else
PUBLIC S16 soUtlDelSoSecMech(dst)
SoSecMech *dst;
#endif
{

   TRC3(soUtlDelSoSecMech)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoStrValue(&dst->mechName) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoMechPars(&dst->mechPars) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoSecMech*/

/*
*
*    Fun:    soUtlDelSoSecVerify
*
*    Desc:    Delete the structure SoSecVerify
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSecVerify
(
SoSecVerify *dst
)
#else
PUBLIC S16 soUtlDelSoSecVerify(dst)
SoSecVerify *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoSecVerify)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoSecMech(dst->secMech[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->secMech[i], sizeof(SoSecMech));
      }
      SOFREE(dst->secMech, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoSecVerify*/

/*
*
*    Fun:    soUtlDelSoSecServer
*
*    Desc:    Delete the structure SoSecServer
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSecServer
(
SoSecServer *dst
)
#else
PUBLIC S16 soUtlDelSoSecServer(dst)
SoSecServer *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoSecServer)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoSecMech(dst->secMech[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->secMech[i], sizeof(SoSecMech));
      }
      SOFREE(dst->secMech, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoSecServer*/

/*
*
*    Fun:    soUtlDelSoSecClient
*
*    Desc:    Delete the structure SoSecClient
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSecClient
(
SoSecClient *dst
)
#else
PUBLIC S16 soUtlDelSoSecClient(dst)
SoSecClient *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoSecClient)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoSecMech(dst->secMech[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->secMech[i], sizeof(SoSecMech));
      }
      SOFREE(dst->secMech, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoSecClient*/

/*
*
*    Fun:    soUtlDelSoReasonPar
*
*    Desc:    Delete the structure SoReasonPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoReasonPar
(
SoReasonPar *dst
)
#else
PUBLIC S16 soUtlDelSoReasonPar(dst)
SoReasonPar *dst;
#endif
{

   TRC3(soUtlDelSoReasonPar)

   if( dst->reasonType.pres != NOTPRSNT )
   {
      switch( dst->reasonType.val )
      {
         case  SO_REASON_CAUSE :
            break;
         case  SO_REASON_EXTN :
            if (soUtlDelSoParameter(&dst->u.extn) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_REASON_TEXT :
            if (soUtlDelTknStrOSXL(&dst->u.text) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoReasonPar*/

/*
*
*    Fun:    soUtlDelSoReasonPars
*
*    Desc:    Delete the structure SoReasonPars
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoReasonPars
(
SoReasonPars *dst
)
#else
PUBLIC S16 soUtlDelSoReasonPars(dst)
SoReasonPars *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoReasonPars)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoReasonPar(dst->reasonPar[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->reasonPar[i], sizeof(SoReasonPar));
      }
      SOFREE(dst->reasonPar, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoReasonPars*/

/*
*
*    Fun:    soUtlDelSoReasonVal
*
*    Desc:    Delete the structure SoReasonVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoReasonVal
(
SoReasonVal *dst
)
#else
PUBLIC S16 soUtlDelSoReasonVal(dst)
SoReasonVal *dst;
#endif
{

   TRC3(soUtlDelSoReasonVal)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoProtocolName(&dst->protocolName) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoReasonPars(&dst->reasonPars) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoReasonVal*/

/*
*
*    Fun:    soUtlDelSoReason
*
*    Desc:    Delete the structure SoReason
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoReason
(
SoReason *dst
)
#else
PUBLIC S16 soUtlDelSoReason(dst)
SoReason *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoReason)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoReasonVal(dst->reasonVal[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->reasonVal[i], sizeof(SoReasonVal));
      }
      SOFREE(dst->reasonVal, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoReason*/

/*
*
*    Fun:    soUtlDelSoPrivacy
*
*    Desc:    Delete the structure SoPrivacy
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoPrivacy
(
SoPrivacy *dst
)
#else
PUBLIC S16 soUtlDelSoPrivacy(dst)
SoPrivacy *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoPrivacy)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoStrValue(dst->privVal[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->privVal[i], sizeof(SoStrValue));
      }
      SOFREE(dst->privVal, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoPrivacy*/

/*
*
*    Fun:    soUtlDelSoPAssertedId
*
*    Desc:    Delete the structure SoPAssertedId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoPAssertedId
(
SoPAssertedId *dst
)
#else
PUBLIC S16 soUtlDelSoPAssertedId(dst)
SoPAssertedId *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoPAssertedId)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoAddrCh(dst->addrChoice[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->addrChoice[i], sizeof(SoAddrCh));
      }
      SOFREE(dst->addrChoice, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoPAssertedId*/

/*
*
*    Fun:    soUtlDelSoPPreferredId
*
*    Desc:    Delete the structure SoPPreferredId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoPPreferredId
(
SoPPreferredId *dst
)
#else
PUBLIC S16 soUtlDelSoPPreferredId(dst)
SoPPreferredId *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoPPreferredId)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoAddrCh(dst->addrChoice[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->addrChoice[i], sizeof(SoAddrCh));
      }
      SOFREE(dst->addrChoice, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoPPreferredId*/

/*
*
*    Fun:    soUtlDelSoHeader
*
*    Desc:    Delete the structure SoHeader
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoHeader
(
SoHeader *dst
)
#else
PUBLIC S16 soUtlDelSoHeader(dst)
SoHeader *dst;
#endif
{

   TRC3(soUtlDelSoHeader)

   if( dst->headerType.pres != NOTPRSNT )
   {
      switch( dst->headerType.val )
      {
         case  SO_HEADER_ANONMY :
            if (soUtlDelSoStrValue(&dst->t.anony) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_ENT_CONTENTDISPOSITION :
            if (soUtlDelSoContentDisposition(&dst->t.contentDisposition) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_ENT_CONTENTENCODING :
            if (soUtlDelSoContentEncoding(&dst->t.contentEncoding) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_ENT_CONTENTLANGUAGE :
            if (soUtlDelSoTknStrOSXLLst(&dst->t.contentLanguage) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_ENT_CONTENTLENGTH :
            break;
         case  SO_HEADER_ENT_CONTENTTYPE :
            if (soUtlDelSoContentTypeHdr(&dst->t.contentType) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_ENT_MIMEVERSION :
            if (soUtlDelTknStrOSXL(&dst->t.mimeVersion) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_ACCEPT :
            if (soUtlDelSoAccept(&dst->t.accept) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_ACCEPTENCODING :
            if (soUtlDelSoAcceptEncoding(&dst->t.acceptEncoding) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_ACCEPTLANGUAGE :
            if (soUtlDelSoAcceptLanguage(&dst->t.acceptLanguage) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_ALERTINFO :
            if (soUtlDelSoInfo(&dst->t.alertInfo) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_ALLOW :
            if (soUtlDelSoAllow(&dst->t.allow) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_ALLOW_EVENTS :
#ifdef SO_EVENT
            if (soUtlDelSoTknStrOSXLLst(&dst->t.allowEvents) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_EVENT  */
            break;
         case  SO_HEADER_GEN_ALLOW_EVENTSU :
#ifdef SO_EVENT
            if (soUtlDelSoTknStrOSXLLst(&dst->t.allowEvents) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_EVENT  */
            break;
         case  SO_HEADER_GEN_CALLID :
            if (soUtlDelTknStrOSXL(&dst->t.callId) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_CALLINFO :
            if (soUtlDelSoCallInfo(&dst->t.callInfo) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_CONTACT :
            if (soUtlDelSoContact(&dst->t.contact) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_CSEQ :
            if (soUtlDelSoCSeq(&dst->t.cSeq) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_DATE :
            break;
         case  SO_HEADER_GEN_ENCRYPTION :
            if (soUtlDelTknStrOSXL(&dst->t.encryption) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_EXPIRES :
            break;
         case  SO_HEADER_GEN_EXTENSION :
            if (soUtlDelTknStrOSXL(&dst->t.extensionHeader) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_FROM :
            if (soUtlDelSoAddress(&dst->t.from) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_MINEXPIRES :
            break;
         case  SO_HEADER_GEN_MINSE :
#ifdef SO_SESSTIMER
            if (soUtlDelSoMinSE(&dst->t.minSe) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_SESSTIMER  */
            break;
         case  SO_HEADER_GEN_ORGANIZATION :
            if (soUtlDelTknStrOSXL(&dst->t.organization) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_PASSERTEDID :
            if (soUtlDelSoPAssertedId(&dst->t.assertId) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_PATH :
            if (soUtlDelSoRoute(&dst->t.path) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_PMEDIAAUTHORIZATION :
            if (soUtlDelSoTknStrOSXLLst(&dst->t.pMediaAuth) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_PPREFERREDID :
            if (soUtlDelSoPPreferredId(&dst->t.preferredId) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_PRIVACY :
            if (soUtlDelSoPrivacy(&dst->t.privacy) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_PROXYREQUIRE :
            if (soUtlDelSoTknStrOSXLLst(&dst->t.proxyRequire) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_RACK :
            if (soUtlDelSoRAck(&dst->t.rAck) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_REASON :
            if (soUtlDelSoReason(&dst->t.reason) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_RECORDROUTE :
            if (soUtlDelSoRoute(&dst->t.recordRoute) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_REPLYTO :
            if (soUtlDelSoReplyTo(&dst->t.replyTo) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_REQUIRE :
            if (soUtlDelSoTknStrOSXLLst(&dst->t.require) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_RSEQ :
            break;
         case  SO_HEADER_GEN_SERVICEROUTE :
            if (soUtlDelSoRoute(&dst->t.serviceRoute) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_SESSION_EXPIRES :
         case  SO_HEADER_GEN_SESSION_EXPIRESX :
#ifdef SO_SESSTIMER
            if (soUtlDelSoSessionExpires(&dst->t.sessExpires) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_SESSTIMER  */
            break;
         case  SO_HEADER_GEN_SUBJECT :
            if (soUtlDelTknStrOSXL(&dst->t.subject) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_SUPPORTED :
            if (soUtlDelSoTknStrOSXLLst(&dst->t.supported) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_TIMESTAMP :
            break;
         case  SO_HEADER_GEN_TO :
            if (soUtlDelSoAddress(&dst->t.to) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_USERAGENT :
            if (soUtlDelSoProdcomLst(&dst->t.userAgent) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_VIA :
            if (soUtlDelSoVia(&dst->t.via) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_WARNING :
            if (soUtlDelSoWarning(&dst->t.warning) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_GEN_WWWAUTHENTICATE :
            if (soUtlDelSoAuthenticate(&dst->t.wwwAuthenticate) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REM_PARTY_ID :
            if (soUtlDelSoRemPartyId(&dst->t.remPtid) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_ACCEPT_CONTACT :
#ifdef SO_CALLERPREF
            if (soUtlDelSoAcceptContact(&dst->t.acceptContact) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_HEADER_REQ_ACCEPT_CONTACTA :
#ifdef SO_CALLERPREF
            if (soUtlDelSoAcceptContact(&dst->t.acceptContact) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_HEADER_REQ_ALSO :
            if (soUtlDelSoAlso(&dst->t.also) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_AUTHENTICATIONINFO :
            if (soUtlDelSoParameters(&dst->t.authInfo) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_AUTHORIZATION :
            if (soUtlDelSoAuthorization(&dst->t.authorization) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_EVENT :
#ifdef SO_EVENT
            if (soUtlDelSoEventHeader(&dst->t.event) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_EVENT  */
            break;
         case  SO_HEADER_REQ_EVENTO :
#ifdef SO_EVENT
            if (soUtlDelSoEventHeader(&dst->t.event) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_EVENT  */
            break;
         case  SO_HEADER_REQ_INREPLYTO :
            if (soUtlDelSoTknStrOSXLLst(&dst->t.inReplyTo) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_MAXFORWARDS :
            break;
         case  SO_HEADER_REQ_PRIORITY :
            if (soUtlDelSoPriority(&dst->t.priority) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_PROXYAUTHORIZATION :
            if (soUtlDelSoAuthorization(&dst->t.proxyAuthorization) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_REFERBY :
#ifdef SO_REFER
            if (soUtlDelSoReferredBy(&dst->t.referredBy) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_REFER  */
            break;
         case  SO_HEADER_REQ_REFERBYB :
#ifdef SO_REFER
            if (soUtlDelSoReferredBy(&dst->t.referredBy) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_REFER  */
            break;
         case  SO_HEADER_REQ_REFERTO :
#ifdef SO_REFER
            if (soUtlDelSoReferTo(&dst->t.referTo) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_REFER  */
            break;
         case  SO_HEADER_REQ_REFERTOR :
#ifdef SO_REFER
            if (soUtlDelSoReferTo(&dst->t.referTo) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_REFER  */
            break;
         case  SO_HEADER_REQ_REJECT_CONTACT :
#ifdef SO_CALLERPREF
            if (soUtlDelSoRejectContact(&dst->t.rejectContact) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_HEADER_REQ_REJECT_CONTACTJ :
#ifdef SO_CALLERPREF
            if (soUtlDelSoRejectContact(&dst->t.rejectContact) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_HEADER_REQ_REPLACES :
#ifdef SO_REFER
            if (soUtlDelSoReplaces(&dst->t.replaces) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_REFER  */
            break;
         case  SO_HEADER_REQ_REQUESTDISPOSITION :
#ifdef SO_CALLERPREF
            if (soUtlDelSoRequestDisposition(&dst->t.requestDisposition) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_HEADER_REQ_REQUESTDISPOSITIOND :
#ifdef SO_CALLERPREF
            if (soUtlDelSoRequestDisposition(&dst->t.requestDisposition) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_CALLERPREF  */
            break;
         case  SO_HEADER_REQ_RESPONSEKEY :
            if (soUtlDelTknStrOSXL(&dst->t.responseKey) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_REQ_ROUTE :
            if (soUtlDelSoRoute(&dst->t.route) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_RPID_PRIV :
            if (soUtlDelSoRpidPrivcy(&dst->t.rpidPriv) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_RSP_ERRORINFO :
            if (soUtlDelSoInfo(&dst->t.errorInfo) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_RSP_PROXYAUTHENTICATE :
            if (soUtlDelSoAuthenticate(&dst->t.proxyAuthenticate) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_RSP_RETRYAFTER :
            if (soUtlDelSoRetryAfter(&dst->t.retryAfter) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_RSP_SERVER :
            if (soUtlDelSoProdcomLst(&dst->t.server) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_RSP_UNSUPPORTED :
            if (soUtlDelSoTknStrOSXLLst(&dst->t.unsupported) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_SEC_CLIENT :
            if (soUtlDelSoSecClient(&dst->t.secClient) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_SEC_SERVER :
            if (soUtlDelSoSecServer(&dst->t.secServer) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_SEC_VERIFY :
            if (soUtlDelSoSecVerify(&dst->t.secVerify) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SO_HEADER_SUBSC_STATE :
#ifdef SO_EVENT
            if (soUtlDelSoSubscState(&dst->t.subscSt) != ROK)
               RETVALUE(RFAILED);
#endif /*  SO_EVENT  */
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoHeader*/

/*
*
*    Fun:    soUtlDelSoRequestLine
*
*    Desc:    Delete the structure SoRequestLine
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRequestLine
(
SoRequestLine *dst
)
#else
PUBLIC S16 soUtlDelSoRequestLine(dst)
SoRequestLine *dst;
#endif
{

   TRC3(soUtlDelSoRequestLine)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoExtVal(&dst->method) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoAddrSpec(&dst->addrSpec) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelTknStrOSXL(&dst->sipVersion) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRequestLine*/

/*
*
*    Fun:    soUtlDelSoHeaderSeq
*
*    Desc:    Delete the structure SoHeaderSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoHeaderSeq
(
SoHeaderSeq *dst
)
#else
PUBLIC S16 soUtlDelSoHeaderSeq(dst)
SoHeaderSeq *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoHeaderSeq)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoHeader(dst->header[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->header[i], sizeof(SoHeader));
      }
      SOFREE(dst->header, sizeof(Ptr)*(dst->numComp.val));
      dst->numComp.pres   = NOTPRSNT;
      dst->numComp.val    = 0;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoHeaderSeq*/

/*
*
*    Fun:    soUtlDelSoStatusLine
*
*    Desc:    Delete the structure SoStatusLine
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoStatusLine
(
SoStatusLine *dst
)
#else
PUBLIC S16 soUtlDelSoStatusLine(dst)
SoStatusLine *dst;
#endif
{

   TRC3(soUtlDelSoStatusLine)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelTknStrOSXL(&dst->sipVersion) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelTknStrOSXL(&dst->reasonPhrase) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoStatusLine*/

/*
*
*    Fun:    soUtlDelSoRequest
*
*    Desc:    Delete the structure SoRequest
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRequest
(
SoRequest *dst
)
#else
PUBLIC S16 soUtlDelSoRequest(dst)
SoRequest *dst;
#endif
{

   TRC3(soUtlDelSoRequest)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoRequestLine(&dst->requestLine) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoHeaderSeq(&dst->request) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRequest*/

/*
*
*    Fun:    soUtlDelSoResponse
*
*    Desc:    Delete the structure SoResponse
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoResponse
(
SoResponse *dst
)
#else
PUBLIC S16 soUtlDelSoResponse(dst)
SoResponse *dst;
#endif
{

   TRC3(soUtlDelSoResponse)

   if(dst->pres.pres != NOTPRSNT)
   {
      if (soUtlDelSoStatusLine(&dst->statusLine) != ROK)
         RETVALUE(RFAILED);
      if (soUtlDelSoHeaderSeq(&dst->response) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoResponse*/
#ifndef SO_REL_1_2_INF
#ifdef SO_UA

/*
*
*    Fun:    soUtlDelSoAuditInfo
*
*    Desc:    Delete the structure SoAuditInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAuditInfo
(
SoAuditInfo *dst
)
#else
PUBLIC S16 soUtlDelSoAuditInfo(dst)
SoAuditInfo *dst;
#endif
{
   TRC3(soUtlDelSoAuditInfo)

   if (soUtlDelTknStrOSXL(&dst->callId) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlDelSoAuditInfo*/

/*
*
*    Fun:    soUtlDelSoSSapInfo
*
*    Desc:    Delete the structure SoSSapInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoSSapInfo
(
SoSSapInfo *dst
)
#else
PUBLIC S16 soUtlDelSoSSapInfo(dst)
SoSSapInfo *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoSSapInfo)

   for (i=0;i<dst->numCalls ;i++)
   {
      if (soUtlDelSoAuditInfo(&dst->callInfo[i]) != ROK)
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoSSapInfo*/

/*
*
*    Fun:    soUtlDelSoAudit
*
*    Desc:    Delete the structure SoAudit
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoAudit
(
SoAudit *dst
)
#else
PUBLIC S16 soUtlDelSoAudit(dst)
SoAudit *dst;
#endif
{

   TRC3(soUtlDelSoAudit)

   switch( dst->auditType )
   {
      case  SOT_AUDIT_CALL :
         if (soUtlDelSoAuditInfo(&dst->auditInfo.callInfo) != ROK)
            RETVALUE(RFAILED);
         break;
      case  SOT_AUDIT_SSAP :
         if (soUtlDelSoSSapInfo(&dst->auditInfo.ssapInfo) != ROK)
            RETVALUE(RFAILED);
         break;
      default:
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoAudit*/
#endif /* SO_UA */

/*
*
*    Fun:    soUtlDelSoRegRefreshInfo
*
*    Desc:    Delete the structure SoRegRefreshInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRegRefreshInfo
(
SoRegRefreshInfo *dst
)
#else
PUBLIC S16 soUtlDelSoRegRefreshInfo(dst)
SoRegRefreshInfo *dst;
#endif
{

   TRC3(soUtlDelSoRegRefreshInfo)

   if (soUtlDelSoContactItem(&dst->contactItem) != ROK)
      RETVALUE(RFAILED);
   if (soUtlDelSoAddress(&dst->to) != ROK)
      RETVALUE(RFAILED);
   if (soUtlDelSoAddress(&dst->from) != ROK)
      RETVALUE(RFAILED);
   if (soUtlDelTknStrOSXL(&dst->callId) != ROK)
      RETVALUE(RFAILED);
   if (soUtlDelSoAddrSpec(&dst->regAddr) != ROK)
      RETVALUE(RFAILED);
   RETVALUE(ROK);
} /*end of function soUtlDelSoRegRefreshInfo*/

/*
*
*    Fun:    soUtlDelSoRefreshEvnt
*
*    Desc:    Delete the structure SoRefreshEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoRefreshEvnt
(
SoRefreshEvnt *dst
)
#else
PUBLIC S16 soUtlDelSoRefreshEvnt(dst)
SoRefreshEvnt *dst;
#endif
{

   TRC3(soUtlDelSoRefreshEvnt)

   switch( dst->type )
   {
      case  SOT_ET_REG_TMO :
         if (soUtlDelSoRegRefreshInfo(&dst->t.regInfo) != ROK)
            RETVALUE(RFAILED);
         break;
      case  SOT_ET_SUBSC_TMO :
#ifdef SO_EVENT
         if (soUtlDelTknStrOSXL(&dst->t.subscId) != ROK)
            RETVALUE(RFAILED);
#endif /*  SO_EVENT  */
         break;
      default:
         break;
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoRefreshEvnt*/
#endif /* SO_REL_1_2_INF */

/*
*
*    Fun:    soUtlDelSoErrEvnt
*
*    Desc:    Delete the structure SoErrEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoErrEvnt
(
SoErrEvnt *dst
)
#else
PUBLIC S16 soUtlDelSoErrEvnt(dst)
SoErrEvnt *dst;
#endif
{

   TRC3(soUtlDelSoErrEvnt)

#ifndef SO_REL_1_2_INF
#ifdef SO_EVENT
   switch( dst->errCode )
   {
      case  SOT_ERR_REFER_TMO :
         if (soUtlDelTknStrOSXL(&dst->t.referId) != ROK)
            RETVALUE(RFAILED);
         break;
      case  SOT_ERR_SUBSC_TMO :
         if (soUtlDelTknStrOSXL(&dst->t.subscId) != ROK)
            RETVALUE(RFAILED);
         break;
      default:
         break;
   }
#endif /*  SO_EVENT  */
#endif /*  SO_REL_1_2_INF  */
   RETVALUE(ROK);
} /*end of function soUtlDelSoErrEvnt*/

/*
*
*    Fun:    soUtlDelSoBodyMultiPartElm
*
*    Desc:    Delete the structure SoBodyMultiPartElm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoBodyMultiPartElm
(
SoBodyMultiPartElm *dst
)
#else
PUBLIC S16 soUtlDelSoBodyMultiPartElm(dst)
SoBodyMultiPartElm *dst;
#endif
{

   TRC3(soUtlDelSoBodyMultiPartElm)

   if (soUtlDelSoHeaderSeq(&dst->hdrSeq) != ROK)
      RETVALUE(RFAILED);
   if (soUtlDelSoBody(dst->body) != ROK)
      RETVALUE(RFAILED);
   SOFREE(dst->body, sizeof(SoBody));
   RETVALUE(ROK);
} /*end of function soUtlDelSoBodyMultiPartElm*/

/*
*
*    Fun:    soUtlDelSoBodyMultiPart
*
*    Desc:    Delete the structure SoBodyMultiPart
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoBodyMultiPart
(
SoBodyMultiPart *dst
)
#else
PUBLIC S16 soUtlDelSoBodyMultiPart(dst)
SoBodyMultiPart *dst;
#endif
{
   Cntr i;

   TRC3(soUtlDelSoBodyMultiPart)

   if( dst->numComp.pres != NOTPRSNT )
   {
      for (i=0;i<dst->numComp.val;i++)
      {
         if (soUtlDelSoBodyMultiPartElm(dst->bodyElm[i]) != ROK)
            RETVALUE(RFAILED);
         SOFREE(dst->bodyElm[i], sizeof(SoBodyMultiPartElm));
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoBodyMultiPart*/

/*
*
*    Fun:    soUtlDelSoBody
*
*    Desc:    Delete the structure SoBody
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_genutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlDelSoBody
(
SoBody *dst
)
#else
PUBLIC S16 soUtlDelSoBody(dst)
SoBody *dst;
#endif
{

   TRC3(soUtlDelSoBody)

   if( dst->bodyType.pres != NOTPRSNT )
   {
      switch( dst->bodyType.val )
      {
         case  SOT_BODYTYPE_MULTIPART :
            if (soUtlDelSoBodyMultiPart(&dst->u.multiPart) != ROK)
               RETVALUE(RFAILED);
            break;
         case  SOT_BODYTYPE_SINGLEPART :
            if (soUtlDelSoBodySinglePart(&dst->u.singlePart) != ROK)
               RETVALUE(RFAILED);
            break;
         default:
            RETVALUE(RFAILED);
      }
   }
   RETVALUE(ROK);
} /*end of function soUtlDelSoBody*/



/*so028.201: Multiple Refers in a dialog*/
/*
*
*    Fun:    soUtlIntToStr
*
*    Desc:    Convert the integer Value into String format
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sogenutl.c
*
*/
#ifdef ANSI
PUBLIC S16 soUtlIntToStr
(
 U32       val,
 U8        *str,
 S16       *len
)
#else
PUBLIC S16 soUtlIntToStr(val, str, len)
 U32       val;
 U8        *str;
 S16       *len;
#endif
{

   U32  val1 = val;
   S16  idxMax = SO_MAX_UINTSZ_UA - 1;
   S16  idx = idxMax;
   S16  idx1;
   S16  idx2;
   S16  tmpLen = 0;
   S16  tmpStr[SO_MAX_UINTSZ_UA];

   tmpStr[idx] = 0;     
   (idx)--;              
   *len = 0;           

   TRC3(soUtlIntToStr)

   if (str == NULLP)
         RETVALUE(RFAILED);

   do                  
   {                                              
      tmpStr[idx] = (U8)(val1 % 10) + '0';   
      idx--;                                  
      val1 = val1/10;                      
      tmpLen++;                             
   } while((val1));                          
                                            
   for(idx1 = (idxMax - tmpLen),idx2 = 0; 
         idx1 < idxMax; idx1++,idx2++)  
   {
        str[idx2] = tmpStr[idx1];
        (*len)++;
    
   }

   str[idx2]= 0;    
      
   RETVALUE(ROK);
} /*end of function soUtlIntToStr*/

/* Generated Function Declarations end */

/********************************************************************30**

 End of file:     sogenutl.c@@/main/2 - Tue Apr 20 12:47:42 2004

*********************************************************************31*/
/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/
/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/2      ---      pk   1. initial release.
/main/2+    so004.201 up   1. Check for SO_EXTVAL_NONSTD
            so007.201 pk   1. Fixed copy of via addresses for internally
                              generated via responses.
/main/2+    so011.201 ab   1. Adding parameter request event type
/main/2+    so017.201 ps   1. New function to compare CSeq header.
/main/2+    so028.201 ad   1. Multiple Refers in a dialog.
/main/2+    so038.201 ng  1. Added error check condition
/main/2+    so039.201 ng  1. Free event in case of error in soUtlBuildErrRsp
*********************************************************************91*/


