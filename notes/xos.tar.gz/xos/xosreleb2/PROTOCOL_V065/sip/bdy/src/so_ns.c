/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SIP Network Server

     Type:    C source file

     Desc:    Code for SIP network server.

     File:    po_ns.c

     Sid:      so_ns.c@@/main/4 - Tue Apr 20 12:46:50 2004

     Prg:     pg

*********************************************************************21*/

/***********************************************************************

    Functions contained in po_ns.c

      Requests from a SIP End System or another Proxy Server:
      (From lower interface)

      soNsIncReq
      soNsIncRsp

      Requests/Responses from Call Control:

      soNsCIMReq
      soNsCIMRsp

***********************************************************************/


/* header include files (.h) */
#include "envopt.h"         /* environment options          */
#include "envdep.h"         /* environment dependent        */
#include "envind.h"         /* environment independent      */
#include "gen.h"            /* general layer                */
#include "ssi.h"            /* system services              */
#include "cm_llist.h"       /* common library               */
#include "cm_hash.h"        /* common hash list             */
#include "cm_tpt.h"         /* common transport             */
#include "cm_tkns.h"        /* common tokens                */
#include "cm_sdp.h"         /* common SDP                   */
#include "cm_mblk.h"        /* common memory allocation     */
#include "cm_abnf.h"        /* common abnf library          */
#include "cm_dns.h"         /* common DNS                   */
#include "sot.h"            /* SOT interface                */
#include "lso.h"            /* layer management, SIP        */
#include "so.h"             /* SIP layer defines            */
#include "so_trans.h"       /* Transaction related structures */
#include "so_err.h"         /* SIP error defines            */
#include "so_cm.h"          /* SIP layer utility functions  */


/* header/extern include files (.x) */
#include "gen.x"            /* general layer                */
#include "ssi.x"            /* system services              */
#include "cm5.x"            /* common timer module          */
#include "cm_lib.x"         /* common library               */
#include "cm_llist.x"       /* common link list             */
#include "cm_hash.x"        /* common hash list             */
#include "cm_tkns.x"        /* common tokens                */
#include "cm_tpt.x"         /* common transport             */
#include "cm_xtree.x"       /* common radix tree            */
#include "cm_mblk.x"        /* common memory allocation     */
#include "cm_sdp.x"         /* common SDP                   */
#include "cm_abnf.x"        /* common abnf library          */
#include "cm_dns.x"         /* common DNS                   */
#include "sot.x"            /* SOT interface                */
#include "lso.x"            /* layer management SIP         */
#include "so_tcm.x"         /* Transport related structures */
#include "so.x"             /* SIP layer structures         */
#include "so_trans.x"       /* Transaction related structures */
#include "so_cm.x"          /* SIP layer utility functions  */
#include "so_dns.x"         /* SIP DNS functions            */
#include "so_tcm.x"         /* TCM defines                  */
#include "so_utl.x"         /* SIP utility functions        */
#include "so_cl.x"          /* Cache Library                */
#include "so_lcs.x"         /* SIP Location Services        */


#ifdef SO_NS

/* local function definitions */

PRIVATE S16 soNsOutRsp           ARGS((SoEntCb *ent, SoSSapCb *ssap, SoEvnt *response));
PRIVATE S16 soNsOutReq           ARGS((SoSSapCb *ssap, SoEvnt *request));
PRIVATE S16 soNsPrcOutReq        ARGS((SoSSapCb *ssap,
                                       SoEvnt     *request,
                                       CmTptAddr  *destAddr,
                                       U8         tptProt));

PRIVATE S16 soPrcLoopDetection   ARGS((SoEvnt *evnt, SoTcmConn *tcmConn));
PRIVATE S16 soNsReqHdrs          ARGS((SoEntCb *ent, SoEvnt *evnt));
PRIVATE S16 soNsPrePrcRouteInfo  ARGS ((SoEntCb *entCb, SoEvnt *request));
PRIVATE S16 soNsPostPrcRouteInfo ARGS((SoEvnt  *request,
                                       SoAddrSpec **nextHopAddr));
PRIVATE S16 soMoveReqURIAndRoute ARGS((SoEvnt  *request));
PRIVATE S16 soMoveLastRouteInReqURI ARGS((SoEvnt  *request));
PRIVATE S16 soAddRoute ARGS(( SoEntCb *ent, SoEvnt  *evnt, 
                                    SoTptServerCb   *serverCb,  U16   choiceType)); 
PRIVATE S16 soNsGenerateBranchId ARGS((SoEvnt   *evnt, TknStrOSXL *branch));

/*------- Extract "ROUTE" Header from event ------*/
#define SO_DLG_GET_ROUTEHDR_FROM_EVENT(evnt, route)                      \
{                                                                        \
  S16  _ret;                                                             \
  _ret = soCmFindHdrChoice((evnt), (U8 **)&(route), SO_HEADER_REQ_ROUTE);\
  if (_ret != ROK)                                                       \
        (route) = NULLP;                                                 \
}




/*****************************************************************************
 *       Fun:    soNsIncReq
 *
 *       Desc:   Processes new response message received
 *
 *       Ret:    None
 *
 *       Notes:  
 *
 *       File:   po_ns.c
*****************************************************************************/

#ifdef ANSI
PUBLIC S16  soNsIncReq
(
SoEntCb        *ent,                /* SIP entity             */
SoEvnt         *evnt,               /* SIP event              */
SoTcmConn      *tcmConn             /* Connection information */
)
#else
PUBLIC S16   soNsIncReq(ent, evnt, tcmConn)
SoEntCb        *ent;                /* SIP entity             */
SoEvnt         *evnt;               /* SIP event              */
SoTcmConn      *tcmConn;            /* Connection information */
#endif
{
   S16              ret;           /* value returned by functions       */
   TknU32           *maxForwards;  /* Max. forwards header              */
   SoSSapCb         *ssapCb;       /* SSap to Use                       */
   SoAddrSpec       *reqAddr;      /* Address Spec of re URI            */
#ifdef SO_LCS 
   SoAddress        *to;           /* Pointer to to add in event struct */
   SoAddrSpec       *toAddr;       /* Address Spec of "To"= User        */
#endif
   SoSipUrl         *sipUrl;       /* SIP URL                           */
   SoRoute          *route;        /* Route Header                      */
   U16              hdrIdx;        /* Header Index                      */
   Bool             hostMatch;     /* Request is for this host          */
   Bool             domainMatch;   /* Request is for this domain        */
   Bool             hasRoute;      /* Request does have route header    */
   SoSSapCb         *remRegSSap;   /* Remote register ssap              */
   
#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
   SoViaItem *viaItem;
#endif

   TRC2(soNsIncReq);
   
   /* Set the hasRoue to FALSE */
   hasRoute = FALSE;

   /* Check that request line is present */
   if (evnt->t.request.requestLine.pres.pres == NOTPRSNT)
   {
      RETVALUE(RFAILED);
   }

   reqAddr = &evnt->t.request.requestLine.addrSpec;

   /* Loop detection */
   if (soPrcLoopDetection(evnt, tcmConn) != ROK)
   {
      /* Loop detected, return error */
      SODBGP_SO(SO_DBGMASK_NS,
            (soCb.init.prntBuf,
            "soNsRequestInd: SIP LoopDetection=TRUE, 482 response, dropped\n"));
      soTptReturnError(ent, tcmConn->clientCb, tcmConn->serverCb, evnt, 
                          SOT_RSP_482_LOOP_DETECTED);
      RETVALUE(RFAILED);
   }

   ret = soCmFindHdrChoice(evnt, (U8 **) &maxForwards, SO_HEADER_REQ_MAXFORWARDS);
   if (ret == ROK)
   {
      if (maxForwards->val == 0)
      {
         soTptReturnError(ent, tcmConn->clientCb, tcmConn->serverCb, evnt, 
                          SOT_RSP_483_TOO_MANY_HOPS);
         RETVALUE(RFAILED);
      }
      /* Decrement value to send onwards */
      maxForwards->val--;
   }

   if (evnt->eventType.val == SOT_ET_INVITE)
   {
      /* Reject a new call comming on TCP, if NS is configured stateless */
      /* so027.201: Changes for SIP TLS */
      if (((tcmConn->serverCb->tptProt == LSO_TPTPROT_TCP) ||
           (tcmConn->serverCb->tptProt == LSO_TPTPROT_TLS_TCP)) &&
          (ent->s.ns.reCfg.proxyReCfg.prxState == LSO_PRX_STATELESS))
      {
         soTptReturnError(ent, tcmConn->clientCb, tcmConn->serverCb, evnt,
                          SOT_RSP_500_SRV_INT_ERROR);
         RETVALUE(RFAILED);
      }
   }

   /* 
    * Preprocess Route Information in incoming request (section 16.4, RFC 3261)
    */
   ret = soNsPrePrcRouteInfo (ent, evnt);
   if (ret != ROK)
      RETVALUE (RFAILED);

   /* Add Record Route if required */
   if (ent->s.ns.reCfg.proxyReCfg.recordRoute == TRUE)
   {
      ret = soAddRoute (ent, evnt, tcmConn->serverCb, SO_HEADER_GEN_RECORDROUTE);
      if (ret != ROK)
         RETVALUE (RFAILED);
   }

   (Void) soCmFindSSap (&ssapCb, tcmConn->serverCb);
   if (ssapCb == NULLP)
      RETVALUE (RFAILED);

#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
   /* insert Via header here in order to remember serverCb */
   viaItem = soTptAddVia(ent, evnt,tcmConn->serverCb);
   if (viaItem == NULLP)
           RETVALUE (SOT_ERR_UNKNOWN);
#endif 

   soCmChkDomain(reqAddr, ent, &hostMatch, &domainMatch);

   if ((ent->s.ns.cfg.regSrvLoc == LSO_STAND_ALONE) ||
       (ent->s.ns.cfg.regSrvLoc == LSO_COLOCATED))
   {
      /* Check if ssap is valid */
      remRegSSap = soCb.soSSapCbLst[ent->s.ns.cfg.remRegSapId];
      if (remRegSSap == NULLP)
         RETVALUE(RFAILED);
   }

   if (hostMatch == TRUE)
   {
      /* The request is for this HOST
       * Only network server with REGISTRAR functionality can respond,
       * and then only to REGISTER or OPTIONS request
       */
      if (evnt->t.request.requestLine.method.t.std.val == SO_METHODSTD_REGISTER)
      {
         if ((ent->s.ns.cfg.regSrvLoc == LSO_STAND_ALONE) ||
             (ent->s.ns.cfg.regSrvLoc == LSO_COLOCATED))
         {
            SO_SIPURL_FROM_ADDRSPEC(sipUrl, reqAddr);
            if ((sipUrl) && (sipUrl->userInfo.pres.pres != NOTPRSNT))
            {
               soTptReturnError(ent, tcmConn->clientCb, tcmConn->serverCb, evnt,
                                SO_EXTRSP_REQURI_MISMATCH);
               RETVALUE(RFAILED);
            }

#ifdef SO_PATH_ROUTE 
            /* Cross check if the proxy is pre-configured to be included in Path 
               header fileds on Register request */ 
            if (ent->s.ns.cfg.pathRoute == TRUE)
            {
               /* Try to find out the Path header in the supported list */
               if (soUtlChkOptionTag(evnt, SO_HEADER_GEN_SUPPORTED, SO_OPTIONTAG_PATH) == ROK)
               {
                  /* Now Insert the URI in the path header */
                  if (soAddRoute (ent, evnt, tcmConn->serverCb, SO_HEADER_GEN_PATH) != ROK)
                     RETVALUE (RFAILED);
                  /* Add in the Require header field */ 
                  if (soUtlAddRequireHdr(evnt, SO_OPTIONTAG_PATH) != ROK)
                     RETVALUE(SOT_ERR_REQUIRE_FAIL);
               }
               else
               {
                  soTptReturnError(ent, tcmConn->clientCb, tcmConn->serverCb, evnt,
                                   SOT_RSP_421_EXTENSION_REQUIRED);
                  RETVALUE(RFAILED);
               }
            }
#endif /* SO_PATH_ROUTE */ 
            
            /* Process registrar message */
            ret = soUiCIMInd (remRegSSap, 
                              SOT_CONNID_NOTUSED,
                              SOT_CONNID_NOTUSED,
                              evnt);
            if (ret != ROK)
               RETVALUE (RFAILED);
            else
               RETVALUE (ROK);
         }
         else
         {
            /* No registrar functionality, but registrar message
             * -> invalid, respond with error
             */
            soTptReturnError(ent, tcmConn->clientCb, tcmConn->serverCb, evnt,
                             SOT_RSP_405_METHOD_NOT_ALLOWED);
            RETVALUE(RFAILED);
         }  
      }

      /* Not a registrar message, check if we are stand-alone registrar */
      if (ent->s.ns.cfg.regSrvLoc == LSO_STAND_ALONE)
      {
         soTptReturnError(ent, tcmConn->clientCb, tcmConn->serverCb, evnt,
                          SOT_RSP_405_METHOD_NOT_ALLOWED);
         RETVALUE(RFAILED);
      }
      /* Otherwise continue */
   }
   /* Not for this host, perhaps domain? */
   if (domainMatch == TRUE)
   {
      /* This request is at least for our domain, process now,
       * do user location if required
       */
      /* if we only find the domain match for the register 
       * message pass it to SU also. Please note that SU need to resolve the
       * host and then further proxy it down if there are multiple registars
       * in the domain. 
       */
      if (evnt->t.request.requestLine.method.t.std.val == SO_METHODSTD_REGISTER)
      {
         SO_SIPURL_FROM_ADDRSPEC(sipUrl, reqAddr);
         if ((sipUrl) && (sipUrl->userInfo.pres.pres != NOTPRSNT))
         {
            soTptReturnError(ent, tcmConn->clientCb, tcmConn->serverCb, evnt,
                             SO_EXTRSP_REQURI_MISMATCH);
            RETVALUE(RFAILED);
         }

         if (ent->s.ns.cfg.regSrvLoc == LSO_STAND_ALONE) 
         {
            /* Process registrar message */
            ret = soUiCIMInd (remRegSSap, SOT_CONNID_NOTUSED,
                              SOT_CONNID_NOTUSED,
                              evnt);
            if (ret != ROK)
               RETVALUE (RFAILED);
            else
               RETVALUE (ROK);
         }
      }
               
      /* Not a registrar message, check if we are stand-alone registrar */
      if (ent->s.ns.cfg.regSrvLoc == LSO_STAND_ALONE)
      {
         soTptReturnError(ent, tcmConn->clientCb, tcmConn->serverCb, evnt,
                          SOT_RSP_405_METHOD_NOT_ALLOWED);
         RETVALUE(RFAILED);
      }

      /* Find Route header in message */
      if (soCmFindHdrChIndex(evnt, (U8 **) &route, &hdrIdx, SO_HEADER_REQ_ROUTE) == ROK)
            hasRoute = TRUE;

      if (!hasRoute)
      {
         /* At this point we know:
             - message is for our domain
             - we may proxy it (not stand-alone registrar)
          */
#ifdef SO_LCS 
         /* Find To header in the evnt structure */
         ret = soCmFindHdrChoice(evnt, (U8 **) &to, SO_HEADER_GEN_TO);
         if (ret != ROK)
         {
            SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                                      "soUaCmpToFrom: To header missing\n"));
            RETVALUE(RFAILED);
         }

         /* Extract the "To" address from the header, to use with loc srv */
         SO_ADDRSPEC_FROM_ADDRCH(toAddr, &to->addrCh);
         if (toAddr == NULLP)
         {
             SODBGP_SO(SO_DBGMASK_NS,
                       (soCb.init.prntBuf,
                       "soNsRequestInd: 'To' header invalid - msg dropped\n"));
            RETVALUE(RFAILED);
         }

         if (soCb.cfg.locSrvCfg.useExtLocServices == TRUE)
         {
            /* Now go for LCS service */
            if ( soLcsFindSipUser(evnt, ssapCb, toAddr)!=ROK )
            {
               SODBGP_SO(SO_DBGMASK_NS, (soCb.init.prntBuf,
                     "soNsIncReq: Error initiating 'Find SIP user' - "
                      "msg dropped\n"));
               RETVALUE(RFAILED);
            }
            RETVALUE(ROK);
         }
#endif /* SO_LCS */
      }
   }

   /* At this point we know it is:
    *   - A new request
    *   - Not for our domain or actual host
    */
   /* Check for stand-alone registrar */
   if (ent->s.ns.cfg.regSrvLoc == LSO_STAND_ALONE)
   {
      soTptReturnError(ent, tcmConn->clientCb, tcmConn->serverCb, evnt,
                       SOT_RSP_405_METHOD_NOT_ALLOWED);
      RETVALUE(RFAILED);
   }

   ret = soUiCIMInd (ssapCb, 
                     SOT_CONNID_NOTUSED,
                     SOT_CONNID_NOTUSED,
                     evnt);
   if (ret != ROK)
     RETVALUE (RFAILED);

   RETVALUE(ROK);

} /* soNsIncReq */


/*****************************************************************************
 *
 *       Fun:    soNsIncRsp
 *
 *       Desc:   Processes new response message received
 *
 *       Ret:    None
 *
 *       Notes:  
 *
 *       File:   po_ns.c
 *
*****************************************************************************/

#ifdef ANSI
PUBLIC S16 soNsIncRsp
(
SoEntCb        *ent,                /* SIP entity             */
SoEvnt         *evnt,               /* SIP event              */
SoTcmConn      *tcmConn             /* Connection information */
)
#else
PUBLIC S16 soNsIncRsp(ent, evnt, tcmConn)
SoEntCb        *ent;               /* SIP entity             */
SoEvnt         *evnt;              /* SIP event              */
SoTcmConn      *tcmConn;           /* Connection information */
#endif
{
   S16         ret;
   SoSSapCb    *ssapCb;  /* SSap to Use       */

   TRC2(soNsIncRsp);

   (Void) soCmFindSSap (&ssapCb, tcmConn->serverCb);
   if (ssapCb == NULLP)
      RETVALUE(RFAILED);

   /* update statistics */
/*   soCb.soSSapCbLst[ssapCb->sapId]->sts.numCIMInd++; */

   ret = soUiCIMInd (ssapCb, 
                     SOT_CONNID_NOTUSED,
                     SOT_CONNID_NOTUSED,
                     evnt);
   if (ret != ROK)
      RETVALUE(RFAILED);
  
   RETVALUE(ROK); 
} /* soNsIncRsp */


/*****************************************************************************
*
*      Fun:   soNsCIMReq
*
*      Desc:  CIMReq from upper interface to NS
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes:
*
*      File:  po_ns.c
*
*****************************************************************************/
#ifdef ANSI
PUBLIC S16 soNsCIMReq
(
SoSSapCb   *ssap,     /* SSAP on which request was received */
SoEvnt     *evnt      /* Event CB                           */
)
#else
PUBLIC S16 soNsCIMReq(ssap, evnt)
SoSSapCb   *ssap;    /* SSAP on which request was received */
SoEvnt     *evnt;    /* Event CB                           */
#endif
{
   S16          ret;        /* value returned by function calls  */

   TRC2(soNsCIMReq);

   /*
    * For Stateless NS, CIMReq primitive is used to
    * (1) Forward Request.
    * (2) Send Response.
    */
    if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
      ret = soNsOutReq (ssap, evnt);

    else
      ret = soNsOutRsp (ssap->sys, ssap, evnt);

    RETVALUE (ret);
}


/*****************************************************************************
*
*      Fun:   soNsCIMRsp
*
*      Desc:  CIMRsp from upper interface to NS
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes: 
*
*      File:  po_ns.c
*
*****************************************************************************/
#ifdef ANSI
PUBLIC S16 soNsCIMRsp
(
SoSSapCb   *ssap,     /* SSAP on which request was received */
SoEvnt     *evnt      /* Event CB                           */
)
#else
PUBLIC S16 soNsCIMRsp(ssap, evnt)
SoSSapCb   *ssap;    /* SSAP on which request was received */
SoEvnt     *evnt;    /* Event CB                           */
#endif
{
   S16             ret;          /* Return value               */
#ifdef SO_LCS
   SoLcsSearchRec  *srchRec;     /* Search record              */
   U32             srchNum;      /* Search number              */
   SoContact       *contactHdr;  /* Contact header in response */
   SoClRegEnt      *result;      /* Result cache record        */
   SoEvnt          *oldEvnt;        /* SIP event                  */ 
#endif /* SO_LCS */

   TRC2(soNsCIMRsp);

   /*
    * For Stateless NS, CIMRsp primitive is used to
    * return address after location service and register response
    */
#ifdef SO_LCS
   if (evnt->eventType.val == SOT_ET_LRQ)
   {
      /* Retrieve search number */
      srchNum = evnt->transId;
      result  = NULLP;

      if (cmHashListFind(&soCb.cacheInfoCb.searchList,  (U8 *)&srchNum,
                         sizeof(srchNum), 0, (PTR *)&srchRec) == RFAILED)
      {
         /* Entry has already been deleted - log error */
#if (ERRCLASS & ERRCLS_DEBUG)
         SOLOGERROR(ERRCLS_DEBUG,ESO160,(ErrVal) srchNum,
                    "soNsCIMRsp: Response for invalid search record");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         /* Still OK as far as upper interface concerned */
         RETVALUE(RFAILED);
      }

      /* Initialize the old event */
      oldEvnt = (SoEvnt *)srchRec->evnt;

      /* Stop timer */
      (Void)soSchedTmr(srchRec, SO_TMR_LCS_SEARCH, TMR_STOP, NOTUSED);

      /* Process return from external location server */
      /* Answer must be in contact header - extract contact header */
      ret = soCmFindHdrChoice(evnt, (U8 **) &contactHdr, SO_HEADER_GEN_CONTACT);
      if (ret != ROK)
      {
         soLcsSearchFailed(srchRec, NULLP);
         (Void) soCmFreeEvent (evnt);
         RETVALUE(ROK);
      }

      /* Process contact header */
      /* Cache if required then return cache record */

      if (soCb.cfg.locSrvCfg.locCachePres == TRUE)
      {
         /* We should cache this result */
         ret = soClUpdateCacheContacts(&soCb.cacheInfoCb.extLocSrvCache, srchRec->searchKey,
            srchRec->keyLength, FALSE, evnt, &result, NULLP, NULLP);
         if (ret != ROK)
         {
            soLcsSearchFailed(srchRec, NULLP);
            (Void) soCmFreeEvent (evnt);
            RETVALUE(ROK);
         }
         soLcsSearchOK(srchRec, result); 
         (Void) soCmFreeEvent (evnt);
         RETVALUE(ret);
      }

      /* No LCS cache, just convert contact header to cache entry, return
       * and then free
       */
      result = NULLP;

      ret = soClCreateRegEntry(NULLP, srchRec->searchKey, srchRec->keyLength,
                               &result, evnt);
      if (ret != ROK)
      {
         soLcsSearchFailed(srchRec, NULLP);
         (Void) soCmFreeEvent (evnt);
         RETVALUE(ROK);
      }

      /* Return value to user then free temporary cache entry */
      soLcsSearchOK(srchRec, result);
      (Void) soCmFreeEvent (evnt);

      soClFreeCacheRegCb(NULLP, result);
      RETVALUE(ROK);
     
   }
   else 
#endif /* SO_LCS */
   /* This is response for register */

   /*---- so020.201: Provide service user SAP parameter ----*/
#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
      ret = soNsOutRsp (ssap->sys, ssap , evnt);
#else
      ret = soNsOutRsp (ssap->sys, NULLP, evnt);
#endif

    RETVALUE (ret);
} /* soNsCIMRsp */


/*****************************************************************************
*
*      Fun:   soNsOutReq
*
*      Desc:  Handles request from SIP User
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes:
*
*      File:  po_ns.c
*
*****************************************************************************/
#ifdef ANSI
PRIVATE S16 soNsOutReq
(
SoSSapCb   *ssap,     /* SSAP on which request was received */
SoEvnt     *request   /* SIP Request message                */
)
#else
PRIVATE S16 soNsOutReq (ssap, request)
SoSSapCb   *ssap;     /* SSAP on which request was received */
SoEvnt     *request;  /* SIP Request message                */
#endif
{
   S16          ret;      
   CmTptAddr    destAddr;
   U8           tptProt;
   SoUserCtxt   userCtxt;
   U8           queryType;
   SoAddrSpec   *nextHopAddr;
   SoDnsQueryCb *dnsQueryCb;
 
   TRC2(soNsOutReq);

   /* Check required headers and add them if configured to do so */
   if (soNsReqHdrs (ssap->sys, request) != ROK)
      RETVALUE (RFAILED);

   /* 
    * Postprocess Route Information of outgoing request (section 16.6
    * , step 6, RFC 3261)
    */
   ret = soNsPostPrcRouteInfo (request, &nextHopAddr);
   if (ret != ROK)
      RETVALUE (RFAILED);

   /*--------- Call DNS module to resolve next hop address --------*/

   cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

   userCtxt.userPtr = (PTR) ssap;
   userCtxt.evnt    = request;

   ret = soDnsCheckAddr((PTR) &userCtxt, nextHopAddr, &destAddr,
                        &tptProt, &queryType, soNsDnsCallBack,
                        (PTR *)&dnsQueryCb);

   if (ret == ROKDNA)
   {
#ifdef SO_DNS
      /* 
       * Rest of the functionality  will  be done after DNS
       * returns in function soNsDnsCallBack
       */
      SO_DNS_UPDATE_QUERYCB (dnsQueryCb)
#endif /* SO_DNS */
      RETVALUE (ROK);
   }

   if (ret == ROK)
      /*- DNS module resolved destination to IP address -*/
      ret = soNsPrcOutReq (ssap, request, &destAddr, tptProt);
   
   else
      /*---------- DNS module returned failure ----------*/
      RETVALUE (RFAILED);

   RETVALUE (ret);

} /* soNsOutReq */


/*****************************************************************************
*
*      Fun:   soNsPrcOutReq
*
*      Desc:  Handles request from SIP User
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes:
*
*      File:  po_ns.c
*
*****************************************************************************/
#ifdef ANSI
PRIVATE S16 soNsPrcOutReq
(
SoSSapCb   *ssap,     /* SSAP on which request was received */
SoEvnt     *request,  /* SIP Request message                */
CmTptAddr  *destAddr, /* destination IP addesss             */
U8         tptProt    /* transport protocol                 */
)
#else
PRIVATE S16 soNsPrcOutReq (ssap, request, destAddr, tptProt)
SoSSapCb   *ssap;     /* SSAP on which request was received */
SoEvnt     *request;  /* SIP Request message                */
CmTptAddr  *destAddr; /* destination IP addesss             */
U8         tptProt;   /* transport protocol                 */
#endif
{
   S16          ret;        /* value returned by function calls  */
   SoTcmConn    tcmConn;    /* Pointer to connection information */
   Buffer       *mBuf;      /* Encoded SIP Request Message       */
   TknStrOSXL   branch;     /* Branch  parameter                 */
 
   TRC2(soNsPrcOutReq);

   mBuf = NULLP;

   soPrcInitTcmConn (&tcmConn, SO_UNKNOWN, NULLP);

   if (soNsGenerateBranchId (request, &branch) != ROK)
      RETVALUE (RFAILED); 
  
   ret = soTptSendInitialReq (ssap->sys, ssap    ,
                              destAddr , tptProt ,
                              request  , FALSE   , 
                              &branch  , &tcmConn, 
                              &mBuf);
   /* Free the branchId */
   SOFREE (branch.val, branch.len);

   if (ret == SO_TPT_MULTI_THREADED_ENC)
      RETVALUE (ROK);

   else if (ret != ROK)
      RETVALUE (ret);

   /*-- Message was successfully send, we don't need encoded message --*/
   if (mBuf)
     SPutMsg (mBuf);

   /* 
    * Release the request event is the msg was sent out successfully.
    * In failure cases the msg will get deleted by the calling funct-
    * ion 
    */
   if (request != NULLP)
     (Void) soCmFreeEvent (request);

   RETVALUE (ROK);

} /* soNsPrcOutReq */

/*
*
*       Fun:   soNsDnsCallBack
*
*       Desc:  Call back function invoked by DNS module
*              when a async query is complted
*
*       Notes:  
*
*
*       File:  so_ns.c
*
*/
#ifdef ANSI
PUBLIC Void soNsDnsCallBack
(
PTR          userCtxt,  /* User Context            */
U8           queryType, /* Query Type              */
CmTptAddr    *destAddr, /* Transport Address       */
U8           tptProt,   /* Transport Protocol      */
SoAddress    *addr      /* Address for NAPTR Query */
)
#else
PUBLIC Void soNsDnsCallBack(userCtxt, queryType, destAddr, tptProt, addr)
PTR          userCtxt;  /* User Context            */
U8           queryType; /* Query Type              */
CmTptAddr    *destAddr; /* Transport Address       */
U8           tptProt;   /* Transport Protocol      */
SoAddress    *addr;     /* Address for NAPTR Query */
#endif
{
  S16        ret;
  SoUserCtxt *usrCtxt;

  TRC3(soNsDnsCallBack);
 
  usrCtxt = (SoUserCtxt *) userCtxt;
  /*
   * If DNS query was successful, send  out message to  resolved 
   * address.
   */
  if (queryType != SO_DNS_ADDR_TYPE_ERROR)
  {
    /*---------- DNS was successfull -----------*/
     ret = soNsPrcOutReq ((SoSSapCb *)usrCtxt->userPtr,
                          usrCtxt->evnt,
                          destAddr,
                          tptProt);
     if (ret != ROK)
       goto SONSDNSCALLBACK;

#ifdef SO_DNS
    if (usrCtxt->queryCb)
       soDnsLookupRel (usrCtxt->queryCb);
#endif

    RETVOID;
  }

 /*-------------- DNS was failure --------------*/

SONSDNSCALLBACK:
    /*-- Send an error indication to the user --*/
  /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
    soUiErrInd ((SoSSapCb *)usrCtxt->userPtr,
                SOT_CONNID_NOTUSED, 
                SOT_CONNID_NOTUSED,
                usrCtxt->evnt     , 
                usrCtxt->evnt->callLegId, 
                usrCtxt->evnt->eventType.val,
                SOT_ERR_DNS_FAILED, 
                FALSE, FALSE);
#else
    soUiErrInd ((SoSSapCb *)usrCtxt->userPtr,
                SOT_CONNID_NOTUSED, 
                SOT_CONNID_NOTUSED,
                usrCtxt->evnt     , 
                usrCtxt->evnt->callLegId, 
                usrCtxt->evnt->eventType.val,
                SOT_ERR_DNS_FAILED, 
                FALSE); 
#endif

    usrCtxt->evnt = NULLP;

#ifdef SO_DNS
  if (usrCtxt->queryCb)
     soDnsLookupRel (usrCtxt->queryCb);
#endif

  RETVOID;

}  /* soNsDnsCallBack */



/*****************************************************************************
*
*      Fun:   soNsOutRsp
*
*      Desc:  Handles response from SIP user
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes: 
*
*      File:  po_ns.c
*
*****************************************************************************/
#ifdef ANSI
PRIVATE S16 soNsOutRsp
(
SoEntCb    *ent,     /* SIP entity                         */
SoSSapCb   *ssap,    /* SSAP on which request was received */
SoEvnt     *response /* Event CB                           */
)
#else
PRIVATE S16 soNsOutRsp(ent, ssap, response)
SoEntCb    *ent;     /* SIP entity                         */
SoSSapCb   *ssap;    /* SSAP on which request was received */
SoEvnt     *response;/* Event CB                           */
#endif
{
   SoVia        *via;       /* Via structure in event            */
   SoTcmConn    tcmConn;    /* Pointer to connection information */
   Buffer       *mBuf;      /* Encoded SIP Request Message       */
   S16          ret;        /* value returned by function calls  */
#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
   SoViaItem    *viaItem;
   SoTptServerCb *serverCb;
#endif 

   TRC2(soNsOutRsp);

   cmMemset ((U8 *)&tcmConn, 0, sizeof (SoTcmConn));

   /* Find Via header in message */
   ret = soCmFindHdrChoice(response, (U8 **) &via, SO_HEADER_GEN_VIA);
   if (ret != ROK)
      RETVALUE(RFAILED);
  
#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
   /*- Select server connection based on VIA info -*/
      
   /*-------- Extract the TOP VIA header element ---------*/
   if (SO_GET_NUM_COMP (&via->numComp) < 1)
        RETVALUE (NULLP);
      
   viaItem = via->viaItem[0];
   serverCb = soCmpViaWithCfgServer (ssap->sys, viaItem);        

   soPrcInitTcmConn (&tcmConn, SO_UNKNOWN, NULLP);
   tcmConn.serverCb      = serverCb;
#else
   soPrcInitTcmConn (&tcmConn, SO_UNKNOWN, NULLP);
#endif

#if (defined (SO_NAT) && defined (SO_USE_UDP_SRVR))
    /* remove the top Via now */
   (Void) soUtlDelTopViaElement (response);
   /* Find next Via header in message */
   ret = soCmFindHdrChoice(response, (U8 **) &via, SO_HEADER_GEN_VIA);
   if (ret != ROK)
      RETVALUE(RFAILED);
#endif
   
   ret = soTptSendRsp (ent, ssap, via, response, &mBuf, &tcmConn);

   if (ret == SO_TPT_MULTI_THREADED_ENC)
      RETVALUE (ROK);

   if (ret != ROK)
      RETVALUE (ret);

   /*-- Message was successfully send, we don't need encoded message --*/
   if (mBuf)
     SPutMsg (mBuf);

   /* If message was sent out successfully release the event here */
   if (response != NULLP)
     (Void) soCmFreeEvent (response);

   RETVALUE(ROK);

} /* soNsOutRsp */

/*****************************************************************************
*
*      Fun:   soNsReqHdrs
*
*      Desc:  Adds the common request headers
*
*      Ret:   ROK
*
*      Notes: None
*
*      File:  po_ns.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE S16 soNsReqHdrs
(
SoEntCb     *ent,           /* Entity CB                   */
SoEvnt      *evnt           /* Pointer to SIP Message      */ 
)
#else
PRIVATE S16 soNsReqHdrs(ent, evnt)
SoEntCb     *ent;          /* Entity CB                   */
SoEvnt      *evnt;         /* Pointer to SIP Message      */ 
#endif
{

   TRC2(soNsReqHdrs)

   if (ent->reCfg.hdrCfg.insOrg.pres == PRSNT_NODEF)
   {
      if ( soUtlAddOrgHdr(ent, evnt)!=ROK )
      {
         RETVALUE(RFAILED);
      }
   }   

   if (ent->reCfg.hdrCfg.insDate == TRUE)
   {
      if ( soUtlInsertDate(ent, evnt)!=ROK )
         RETVALUE(RFAILED);
   }

   if (ent->reCfg.hdrCfg.maxFwd > 0)
   {
      if ( soUtlInsertMaxFwds(ent, evnt)!=ROK )
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* ens of soNsReqHdrs */

/*****************************************************************************
*
*       Fun:   soPrcLoopDetection
*
*       Desc:  This function does loop detection for the supplied message.
*
*       Ret:   ROK - No loop detected.
*              RFAILED - Loop detected.
*
*       Notes: None
*
*       File:  so_ns.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE S16 soPrcLoopDetection
(
SoEvnt         *evnt,              /* Pointer to complete SIP message */
SoTcmConn      *tcmConn            /* Connection information          */
)
#else
PRIVATE S16 soPrcLoopDetection(evnt, tcmConn)
SoEvnt         *evnt;      /* Pointer to complete SIP message */
SoTcmConn      *tcmConn;   /* Connection information          */
#endif
{
   SoVia             *via;             /* Via structure in message          */
   TknStrOSXL        branch;           /* Branch hash to compare to vias    */
   U16               i;                /* Index of via header               */
   U16               j;                /* Index of via param                */
   SoHostPort        locHostPort;      /* SoHostPort of local address       */
   SoHostPort        *viaHostPort;     /* SoHostPort of remote address      */
   S16               ret;              /* value returned by function calls  */
   U16               strtIdx;          /* starting index                    */

   TRC2(soPrcLoopDetection);

    cmMemset ((U8 *)&branch     , 0, sizeof (TknStrOSXL));
    cmMemset ((U8 *)&locHostPort, 0, sizeof (SoHostPort));

    strtIdx = 0;
    ret     = ROK;

   /* Find Via header in message */
   if (soCmFindHdrChoice(evnt, (U8 **) &via, SO_HEADER_GEN_VIA) != ROK)
      RETVALUE (RFAILED);

   if (soNsGenerateBranchId (evnt, &branch) != ROK)
      RETVALUE (RFAILED);

   /* Compare Via host name and port with those of the
    * transport server
    */
   ret = soCmTptAddrToHostPort(&locHostPort,
                               &tcmConn->serverCb->localAddr,
                               NULLP);
   if (ret != ROK)
   {
      SOFREE (branch.val, branch.len);
      RETVALUE (RFAILED); 
   }

   /*---- Check to see if own address found in Via headers ----*/
   while (soCmFindHdrStrtChIndex (evnt   , (U8 **) &via,
                                  strtIdx, &strtIdx, 
                                  SO_HEADER_GEN_VIA) == ROK)
   {
      for (i = 0; i < SO_GET_NUM_COMP (&via->numComp); i++)
      {
        /*--------------- Hidden VIA not supported ------------*/
        if (SO_CMP_TKN_LIT(&via->viaItem[i]->sentBy.type, SO_SENTBY_HOSTPORT) != TRUE)
           continue;

        /*------------ Encrypted VIA not supported ------------*/
         if (via->viaItem[i]->sentBy.type.val == SO_SENTBY_CONCEALEDHOST)
           continue;
      
        /*------ Compare received VIA with transport server ---*/
         viaHostPort = &via->viaItem[i]->sentBy.t.hostPort;

         if (soCmCompareHostPort (&locHostPort, viaHostPort) != ROK)
           continue;

        /*----- Check if the branchID was generated by us -----*/
         for (j = 0;
              j < SO_GET_NUM_COMP (&via->viaItem[i]->viaParams.numComp);
              j++)
         {
            if (SO_CMP_TKN_LIT(
                  &via->viaItem[i]->viaParams.viaParam[j]->viaParamType,
                  SO_VIAPARAM_VIABRANCH) == TRUE)
            {
               if (SO_CMP_TKNSTR_LIT(
                     &branch,
                     via->viaItem[i]->viaParams.viaParam[j]->t.viaBranch.val,
                     branch.len) == TRUE)
               {
                  /*---------- Loop has been detected ---------*/
                  SOFREE (branch.val, branch.len);
                  soUtlDelSoHostPort (&locHostPort);

                  RETVALUE (RFAILED);
               }
            }
         }

      } /* End of for (each VIA  ITEM) */

      strtIdx++;

   } /* End of While (each VIA header) */


   /*--------------- No loop detected, return OK --------------*/

   SOFREE (branch.val, branch.len);
   soUtlDelSoHostPort  (&locHostPort);

   RETVALUE(ROK);

} /* end of soPrcLoopDetection */



/*****************************************************************************
*
*       Fun:   soNsPrePrcRouteInfo
*
*       Desc:  This function pre processes route  information  received in 
*              incoming request message. It modifies request-URI and route
*              header depending on whether the  request was  received from
*              node complaint to RFC 3261 or draft 2543.
*
*              This function implements section 16.4 of RFC 3261.
*
*       Ret:   ROK - If success,
*              RFAILED - If failure.
*
*       Notes: None
*
*       File:  po_ns.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE S16 soNsPrePrcRouteInfo
(
SoEntCb        *entCb,    /* Entity control block */
SoEvnt         *request   /* SIP request message  */
)
#else
PRIVATE S16 soNsPrePrcRouteInfo (entCb, request)
SoEntCb        *entCb;    /* Entity control block */
SoEvnt         *request;  /* SIP request message  */
#endif
{
   S16         ret;
   SoAddrSpec  *reqURI;    
   Bool        hostMatch;  
   Bool        domainMatch;

   TknU16      *numComp;
   U16         numCompVal;
   U16         hdrIdx;
   SoRoute     *route;
   SoRouteSeq  *routeSeq;

   TRC2 (soNsPrePrcRouteInfo)
  /*
   *  Compare request URI of request message against configured
   *  servers. If there is match,it indicates that node sending
   *  request in compliant only to draft 2543 (a strict router).
   *  In such a case move the last route header element to req-
   *  uest-URI.
   *  Otherwise, request was generated by node compliant to RFC
   *  3261, so simply delete TOP route element.
   */

  /*- STEP 1: Compare Request-URI against configured servers -*/

   reqURI = &request->t.request.requestLine.addrSpec;

   ret = soCmChkDomain (reqURI, entCb, &hostMatch, &domainMatch);
   if (ret != ROK)
     RETVALUE (RFAILED);

  /*
   *  so032.201 : Added  check for the lr param in ReqURI.
   *  As per the section 16.4 of the RFC 3261 if the request URI contains 
   *  a value that proxy previously placed in the Record-Route,the proxy 
   *  MUST replace the Request-URI in the request with the last value 
   *  from the Route header field.This will only happen when the element
   *  sending the request to the proxy (which may have been an endpoint)
   *  is a strict router
   */  
   
   ret = soUtlFindLrInReqURI(reqURI);

   if ((hostMatch == TRUE) && (ret == ROK))
   {
      /*-------- ReqURI matches configured server. ---------*/

      /*-- Move Last Route Element In RequestURI --*/
       ret = soMoveLastRouteInReqURI (request);
       if (ret != ROK)
         RETVALUE (ret);
   }
   else
   {
      /* 
       * Node sending request is compliant to RFC 3261. Simply
       * delete TOP route header element (if present).
       */
      /* so004.201: Delete top Route element only if it matches 
       * the local server */
      /* Find Route header in message */
      ret = soCmFindHdrChIndex (request, (U8 **) &route, &hdrIdx, SO_HEADER_REQ_ROUTE);
      if (ret != ROK) 
         RETVALUE (ROK);

      numComp    = &(route->numComp);
      numCompVal = SO_GET_NUM_COMP(numComp);

      if (numCompVal > 0)
      {
         /* Get top route item pointer */
         routeSeq = route->route[0];
         if (soCmChkDomain (&routeSeq->nameAddr.addrSpec, entCb, 
               &hostMatch, &domainMatch) == ROK)
            if (hostMatch == TRUE)
               ret = soUtlDelTopRouteElement (request);
      }
   }
                                
   RETVALUE (ret);

} /* end of soNsPrePrcRouteInfo  */


/*****************************************************************************
*
*       Fun:   soNsPostPrcRouteInfo
*
*       Desc:  This function post  processes route information in outgoing 
*              request message.  It modifies  request-URI and route header
*              depending on whether the next hop  node is complaint to RFC
*              3261(loose router) or draft 2543 (strict router).
*
*              This function implements section 16.6, step6 of RFC 3261.
*
*              Thsi function also updates next hop node's address.
*
*       Ret:   ROK - If success,
*              RFAILED - If failure.
*
*       Notes: None
*
*       File:  po_ns.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE S16 soNsPostPrcRouteInfo
(
SoEvnt     *request,  /* SIP request message  */
SoAddrSpec **nextHopAddr  /* Next HOP Node    */ 
)
#else
PRIVATE S16 soNsPostPrcRouteInfo (request, nextHopAddr)
SoEvnt     *request;  /* SIP request message  */
SoAddrSpec **nextHopAddr; /* Next HOP Node    */ 
#endif
{
   S16         ret;
   SoRoute     *route;

   TRC2 (soNsPostPrcRouteInfo)
   ret   = ROK;
   route = NULLP;
   (*nextHopAddr) = NULLP;

  /*
   *  If the next hop router is loose router (RFC3261 compliant),
   *  then no  change in requestURI or  Route header is required.
   *  TOP route element will be used for routing.
   *
   *  Otherwise, it next hop router is strict router (draft 2543
   *  compliant), then
   *   (1) Move the requestURI as last route header element.
   *   (2) Move first route header element in requestURI.
   */

   SO_DLG_GET_ROUTEHDR_FROM_EVENT (request, route);

   if (route)
     ret = soUtlFindLrInRoute (route);

   if ((ret == RFAILED) && (route))
   {
     /*----- Next HOP node is strict router. -----*/

     /*-- Move requetURI as last route element ---*/
     /*- Also copy first route element to reqURI -*/
     ret = soMoveReqURIAndRoute (request);
     if (ret != ROK)
        RETVALUE (RFAILED);

     /*-- Finally delete the TOP route element ---*/
     ret = soUtlDelTopRouteElement (request);

     /*----- Use ReqURI As Next Hop address ------*/
     (*nextHopAddr) = &request->t.request.requestLine.addrSpec;
   }

   else
   {
     /*------ Next HOP node is loose router. -----*/
     /*-- No changes in reqURI or route is reqd. -*/
     if (route)
       /* Use TOP route element as Next Hop Addr -*/
       (*nextHopAddr) = &route->route[0]->nameAddr.addrSpec;
     else
       /*---- Use ReqURI As Next Hop address -----*/
       (*nextHopAddr) = &request->t.request.requestLine.addrSpec;
   }
       
   RETVALUE (ret);

} /* end of soNsPostPrcRouteInfo  */


/*****************************************************************************
*
*       Fun:   soMoveLastRouteInReqURI
*
*       Desc:  This function copies the last route element into request Line.
*              It then deletes the last route element.
*            
*       Ret:   ROK, If success.
*              RFAILED, If failure.
*
*       Notes: None
*
*       File:  po_ns.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE S16 soMoveLastRouteInReqURI
(
SoEvnt   *request   /* SIP request message  */
)
#else
PRIVATE S16 soMoveLastRouteInReqURI (request)
SoEvnt   *request;  /* SIP request message  */
#endif
{
   S16          ret;
   S16          i;
   SoHeaderSeq  *hdrSeq;
   TknU16       *numComp;
   SoAddrSpec   *reqURI;    
   SoRoute      *route;
   SoRouteSeq   *lastRouteElem;

   TRC2 (soMoveLastRouteInReqURI)

   route = NULLP;

  /*-------- STEP 1: Find the last route header ----------*/
   hdrSeq = &request->t.request.request;
   
   for (i = SO_GET_NUM_COMP (&hdrSeq->numComp) -1; i >= 0; i--)
      if (hdrSeq->header[i]->headerType.val == SO_HEADER_REQ_ROUTE)
      {
         route = &hdrSeq->header[i]->t.route;
         break;
      }

   if ((route == NULLP) || (route->numComp.pres == NOTPRSNT))
     RETVALUE (ROK);

   lastRouteElem = route->route[route->numComp.val - 1];

   if ((lastRouteElem->pres.pres == NOTPRSNT) ||
       (lastRouteElem->nameAddr.pres.pres == NOTPRSNT) ||
       (lastRouteElem->nameAddr.addrSpec.addrSpecType.pres == NOTPRSNT))
     RETVALUE (RFAILED);

  /*---- STEP 2: Copy Last Route Element To requestURI ---*/

   reqURI  = &request->t.request.requestLine.addrSpec; 
   cmMemset ((U8 *)reqURI, 0, sizeof (SoAddrSpec));

   ret = soUtlCpySoAddrSpec (reqURI,
                             &lastRouteElem->nameAddr.addrSpec,
                             &request->memCp);
   if (ret != ROK)
     RETVALUE (RFAILED);

  /*----- STEP 3: Finally, Delete Last Route element -----*/

   numComp    = &(route->numComp);
   (Void) soCmShrinkList ((Void ***)&route->route,
                          sizeof (SoRouteSeq),
                          numComp,
                          request);

   if (SO_GET_NUM_COMP (numComp) == 0)
     if (soCmRemoveHdrChoice (request, i, SO_HEADER_REQ_ROUTE) != ROK)
          RETVALUE (RFAILED);

   RETVALUE (ROK);

} /* end of soMoveLastRouteInReqURI  */


/*****************************************************************************
*
*       Fun:   soMoveReqURIAndRoute
*
*       Desc:  This function copies requestURI as Last Route header.
*            
*       Ret:   ROK, If success.
*              RFAILED, If failure.
*
*       Notes: None
*
*       File:  po_ns.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE S16 soMoveReqURIAndRoute
(
SoEvnt   *request   /* SIP request message  */
)
#else
PRIVATE S16 soMoveReqURIAndRoute (request)
SoEvnt   *request;  /* SIP request message  */
#endif
{
   S16          ret;
   SoAddrSpec   *reqURI;    
   SoRoute      *route;
   SoRouteSeq   *routeSeq;

   TRC2 (soMoveReqURIAndRoute)

   route   = NULLP;
   reqURI  = &request->t.request.requestLine.addrSpec; 

  /*------------ STEP 1: Add a Route header --------------*/
   ret = soCmCreateHdrChoice (request, (U8 **) &route,
                              SO_HEADER_REQ_ROUTE);
   if (ret != ROK)
     RETVALUE (RFAILED);

  /*---- STEP 2: Copy RequestURI to Last route header ----*/
   route->numComp.pres = PRSNT_NODEF;
   route->numComp.val  = 0;

   ret = soCmGrowList ((Void ***)&route->route,
                       sizeof (SoRouteSeq),
                       &route->numComp, request);

   routeSeq = route->route[0];

   SO_FILL_TKNU8 (&routeSeq->pres, PRSNT_NODEF);
   routeSeq->rParams.numComp.pres = NOTPRSNT;
   routeSeq->rParams.numComp.val  = 0;

   SO_FILL_TKNU8 (&routeSeq->nameAddr.pres, PRSNT_NODEF);
   routeSeq->nameAddr.displayName.displayNameType.pres = NOTPRSNT;

   ret = soUtlCpySoAddrSpec (&routeSeq->nameAddr.addrSpec,
                             reqURI,
                             &request->memCp);
   if (ret != ROK)
     RETVALUE (RFAILED);

  /*---- STEP 3: Copy Top Route Element To RequestURI ----*/

   SO_DLG_GET_ROUTEHDR_FROM_EVENT (request, route);

   if ((route == NULLP) || (route->numComp.pres == NOTPRSNT))
     RETVALUE (RFAILED);

   routeSeq = route->route[0];

   if ((routeSeq->pres.pres == NOTPRSNT) ||
       (routeSeq->nameAddr.pres.pres == NOTPRSNT) ||
       (routeSeq->nameAddr.addrSpec.addrSpecType.pres == NOTPRSNT))
     RETVALUE (RFAILED);

   cmMemset ((U8 *)reqURI, 0, sizeof (SoAddrSpec));

   ret = soUtlCpySoAddrSpec (reqURI,
                             &routeSeq->nameAddr.addrSpec,
                             &request->memCp);
   if (ret != ROK)
     RETVALUE (RFAILED);

   RETVALUE (ROK);

} /* end of soMoveReqURIAndRoute  */
/*****************************************************************************
*
*       Fun:   soAddRoute
*
*       Desc:  This function copies the Server addres in route 
*            
*       Ret:   ROK, If success.
*              RFAILED, If failure.
*
*       Notes: None
*
*       File:  po_ns.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE S16 soAddRoute
(
SoEntCb         *ent,         /* Entity Cb             */ 
SoEvnt          *evnt,        /* Pointer to SIP event  */
SoTptServerCb   *serverCb,    /* Server Cb             */
U16             choiceType    /* Type of choice sought */ 
)
#else
PRIVATE S16 soAddRoute(ent, evnt, serverCb, choiceType)
SoEntCb         *ent;         /* Entity Cb            */ 
SoEvnt          *evnt;        /* Pointer to SIP event */
SoTptServerCb   *serverCb;    /* Server Cb            */
U16             choiceType;   /* Type of choice type  */
#endif
{
   SoRoute           *recordRoute;    /* Record route structure in message   */
   SoNameAddr        *nameAddr;       /* New nameAddr strucure for rr header */
   SoRouteSeq        *recordRouteSeq; /* Pointer to record-route entry       */
   SoSipUrl          *sipUrl;         /* SIP URL                             */
   U16               numComp;         /* Pointer to numComp token in rr list */
   S16               ret;             /* value returned by function calls    */
   U16               i;               /* temporary index */

   TRC2(soAddRoute);

   /* Find first record route header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &recordRoute, choiceType);
   if (ret != ROK)
   {
      /* No record route headers, must create one */
      if ( soCmCreateHdrChoice(evnt, (U8 **)&recordRoute, choiceType)!= ROK )
         RETVALUE(RFAILED);

   }

   /* Add new record route header */
   if ( soCmGrowList((Void ***)&recordRoute->route,
                     sizeof(SoRouteSeq),
                     &recordRoute->numComp,
                     evnt)!=ROK )
   {
      RETVALUE(RFAILED);
   }

   /* New Record Route header must be last in the list, index is numComp - 1 */
   numComp = SO_GET_NUM_COMP(&recordRoute->numComp);

   /* Set nameAddr local variable to point to recordRoute[numComp - 1] */
   recordRouteSeq = recordRoute->route[numComp - 1];

   /* Record-Route must be added before any existing ones */
   for (i = (U16)(numComp - 1); i > 0; i--)
   {
      /* Move record-route pointers down the list */
      recordRoute->route[i] = recordRoute->route[i - 1];
   }
   recordRoute->route[0] = recordRouteSeq;
      
   nameAddr       = &recordRouteSeq->nameAddr;

   /* Initialize recordRouteSeq structure to zeroes to erase any old data */
   cmMemset((U8*)recordRouteSeq, 0, (PTR)sizeof(SoRouteSeq));

   SO_FILL_TKNU8(&recordRouteSeq->pres, PRSNT_NODEF);
   SO_FILL_TKNU8(&nameAddr->pres,       PRSNT_NODEF);

   SO_FILL_TKNU8(&nameAddr->addrSpec.addrSpecType, SO_ADDRSPEC_SIPURL);

   sipUrl = &nameAddr->addrSpec.t.sipUrl;
   SO_FILL_TKNU8(&sipUrl->pres, PRSNT_NODEF);
   SO_FILL_TKNU8(&sipUrl->hostPort.pres, PRSNT_NODEF);

   if (ent->s.ns.reCfg.proxyReCfg.useIpRecRoute == TRUE)
   {
      /* Fill in IP host port */
     ret = soCmTptAddrToHostPort(&sipUrl->hostPort,
                                 &serverCb->localAddr,
                                 evnt);
     if (ret != ROK)
       RETVALUE(RFAILED);
   }
   else
   {
     SO_FILL_TKNU8(&sipUrl->hostPort.host.hostType, SO_HOST_HOSTNAME);

     /* Copy hostname */
     if ( soUtlCpyTknStrOSXL(&sipUrl->hostPort.host.t.hostName,
                          &serverCb->hostName,
                          &evnt->memCp)!=ROK )
      {
         RETVALUE(RFAILED);
      }

      if (serverCb->localAddr.type == CM_TPTADDR_IPV4)
      {
         SO_FILL_TKNU16(&sipUrl->hostPort.port,
                    serverCb->localAddr.u.ipv4TptAddr.port);
      }

#ifdef IPV6_SUPPORTED
      if (serverCb->tptAddr.type == CM_TPTADDR_IPV6)
      {
         SO_FILL_TKNU16(&sipUrl->hostPort.port,
                        serverCb->localAddr.u.ipv6TptAddr.port);
      }     
#endif /* IPV6_SUPPORTED */
   }

   /*--- so020.201: Add "lr" parameter in "record route" header ---*/
   if (choiceType == SO_HEADER_GEN_RECORDROUTE)
   {
      ret = soCmGrowList ((Void ***) &sipUrl->urlParameters.urlParameter,
                          sizeof (SoUrlParameter),
                          &sipUrl->urlParameters.numComp,
                          evnt); /* so021.201: Corrected Last Arg. */
      if (ret != ROK)
         RETVALUE(RFAILED);

      numComp = SO_GET_NUM_COMP (&sipUrl->urlParameters.numComp);

      SO_FILL_TKNU8(
           &sipUrl->urlParameters.urlParameter[numComp - 1]->urlParameterType,
           SO_URLPARAMETER_LRPARAM);
   }

   RETVALUE(ROK);
} /* end of soAddRoute */
/*****************************************************************************
*
*       Fun:   soNsGenerateBranchId
*
*       Desc:  This function copies the Server addres in route 
*            
*       Ret:   ROK, If success.
*              RFAILED, If failure.
*
*       Notes: None
*
*       File:  po_ns.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE S16 soNsGenerateBranchId
(
SoEvnt            *evnt,              /* Pointer to complete SIP message   */
TknStrOSXL        *branch              /* Branch hash to compare to vias    */
)
#else
PRIVATE S16 soNsGenerateBranchId(evnt, branch)
SoEvnt            *evnt;              /* Pointer to complete SIP message   */
TknStrOSXL        *branch;            /* Branch hash to compare to vias    */
#endif
{
   SoAddress         *to;              /* To address                              */
   SoAddress         *from;            /* From address                            */    
   SoCSeq            *cSeq;            /* C-Sequence                              */ 
   TknStrOSXL        normTo;          /* normalized to                           */ 
   TknStrOSXL        normFrom;        /* normalized from                         */ 
   S16               ret;              /* value returned by function calls  */
   TknStrOSXL        toTag, *toTagPtr; /* To  tag                           */ 
   U8                cSeqMethod;
   /*- so021.201: Request URI is also required for branchId calculation -*/
   U8                *addr;            /* normalized AddrSpec     */ 
   U16               addrLen;          /* normalized AddrSpec len */
   /* so028.201 : added to include top via parameter in branchId calculation */
   U8                *viaItem = NULLP; /* via branch */ 
   U16               viaLen = 0;       /* length */

   TRC2(soNsGenerateBranchId);

    cmMemset ((U8 *)&normTo,   0, sizeof (TknStrOSXL));
    cmMemset ((U8 *)&normFrom, 0, sizeof (TknStrOSXL));

   /* Check if to and from are present */
   ret = soCmFindHdrChoice(evnt, (U8 **) &to, SO_HEADER_GEN_TO);
   if (ret != ROK)
      RETVALUE (ret);

   /*- so006.201: "to" tag is not required for branchId calculation -*/
   cmMemset ((U8 *)&toTag,    0, sizeof (TknStrOSXL));
   toTagPtr = &toTag;

   /* Check if from is present */
   ret = soCmFindHdrChoice(evnt, (U8 **) &from, SO_HEADER_GEN_FROM);
   if (ret != ROK)
   {
      RETVALUE(ret);
   }

   /* Check if cSeq is present */
   ret = soCmFindHdrChoice(evnt, (U8 **) &cSeq, SO_HEADER_GEN_CSEQ);
   if (ret != ROK)
   {
      RETVALUE(ret);
   }

   /* Get Normalized To */
   ret = soUtlStoreNormAddr(to, &normTo);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* Get Normalized From */
   ret = soUtlStoreNormAddr(from, &normFrom);
   if (ret != ROK)
   {
      if (normTo.len)
         SOFREE(normTo.val, normTo.len);

      RETVALUE(RFAILED);
   }
 
   /*- so006.201: Request method is not required for branchId calculation -*/
   cSeqMethod = 0;

   cmMemset((U8 *)branch, 0, sizeof(TknStrOSXL));

   /* 
    * so021.201 : Use requestURI also to calculate branch Id to 
    * correctly detecting loop in case of spiral  loop requests
    */

   /*------ First Contvert RequestURI in string format -------*/
   ret = soCmNormAddr ((U8 *)NULLP, &evnt->t.request.requestLine.addrSpec, 
                       &addrLen);
   if (ret != ROK)
   {
      RETVALUE(ret);
   }
   
   SOALLOC (&addr, addrLen);
   if (addr == NULLP)
      RETVALUE (RFAILED);
      
   ret = soCmNormAddr (addr, &evnt->t.request.requestLine.addrSpec, &addrLen);
   if (ret != ROK)
   {
      RETVALUE(ret);
   }

   /* so026.201: Added to include top via element to generate the branchId */
   soUtlGetTopViaItem(evnt, &viaItem, &viaLen);

   /*----------------- Generate hash for branch ---------------------*/
   ret = soUtlGenerateBranchId(evnt, &normTo, &normFrom, toTagPtr,
                               cSeq->cSeqVal.val, cSeqMethod,
                               addr, addrLen, viaItem, viaLen, branch);
   if (normTo.len)
      SOFREE(normTo.val, normTo.len);

   if (normFrom.len)
      SOFREE(normFrom.val, normFrom.len);

   if (addrLen)
      SOFREE (addr, addrLen); /* so021.201: Free allocated parameter */

   /* so029.201 : free the memory allocated in GetTopViaItem */
   if (viaLen)
      SPutSBuf(soCb.init.region, soCb.init.pool, viaItem, viaLen);

   RETVALUE(ret);

} /* soNsGenerateBranchId */ 

#endif /* SO_NS */
/********************************************************************30**

         End of file:     so_ns.c@@/main/4 - Tue Apr 20 12:46:50 2004

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:
;
*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------
   1.1         pg       1. Initial version
*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---     pg           1. initial release.
/main/4+   so004.201 up           1. Delete top Route element only if 
                                     it matches the local server
/main/4+   so006.201 ps           1. Branch Id generation at stateless
                                     proxy server is independent of 
                                     to tag and cseq method.
/main/4+   so020.201 ps           1. Add "lr" parameter as part of record
                                     -route header.
                     ps           2. Provide correct parameter in OutRsp
                                     function.
/main/4+   so021.201 ps           1. Removed memory leak in call to 
                                     soCmGrowList() function. 
/main/4+   so021.201 ss           1. Added Req URI in Branch Id generation
/main/4+   so025.201 ab           1. For 1.2 interface pass if internal message
/main/4+   so027.201 ab           1. Changes for SIP TLS
/main/4+   so028.201 ss           1. Added Top via in Branch Id generation
/main/4+   so029.201 ss           1. Free the memory allocated in GetTopViaItem
/main/4+   so032.201 ng           1. Added check for the lr parameter in ReqURI (aj)
*********************************************************************91*/
