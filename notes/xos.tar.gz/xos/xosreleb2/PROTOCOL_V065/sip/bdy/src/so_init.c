#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lhi.h"           /* HIT LM interface defines        */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */
#include "cst.h"           /* Compression module define       */
#include "so_cm.h"         /* SIP layer utility functions     */
#include "su_cfg.h"       /* SIP User defines                */
#include "so.h"            /* SIP Layer defines               */
#include "so_cfg.h" 
#include "sm.h"
#include "so.h"

#ifdef CP_OAM_SUPPORT
#include "xosshell.h"
#include "cp_tab_def.h"

#include "oam_interface.h"
#include "oam_tab_def.h"
#include "cp_oam_stru.x"
#include "so_nms.h"
#endif

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lhi.x"           /* HIT LM interface defines        */
#include "lso.x"           /* Layer management SIP            */
#include "cst.x"           /* Compression module              */
#include "sot.x"           /* SOT interface defines           */
#include "so_cm.x"         /* SIP layer utility functions     */
#include "su_cfg.x"       /* SIP User structures             */

#ifdef CP_OAM_SUPPORT
#include "so_oam.x"
#include "so_cfg.x" 
#endif


#include "sm.x"
#include "so_tcm.x"
#include "so.x"


#ifdef ANSI
PUBLIC S16 sip_init_fun
(
SSTskId soTskId
)
#else
PUBLIC S16 sip_init_fun(soTskId)
SSTskId soTskId;
#endif
{
   S16     ret;
   
   ret=ROK;

   if(soTskId == 0)
   {
	   if (SCreateSTsk ((SSTskPrior) 13, &soTskId) != ROK)
	   {
	      SPrint("SipInit: SCreateSTsk() failed.");
	      RETVALUE (RFAILED);
	   }
   }
   
   /*------ SIP layer normal task -------*/
   if (SRegTTsk((Ent) ENTSO,
                (Inst) SO_APPINST_0,
                (Ttype) TTNORM,
                (Prior) PRIOR0,
                soActvInit,
                soActvTsk) != ROK)
   {
      SPrint("SipInit: SRegTTsk() for SIP normal"
                     " task failed.\n");
      RETVALUE (RFAILED);
   }
   ret = SAttachTTsk ((Ent) ENTSO, (Inst) SO_APPINST_0, soTskId);
   
#ifdef CP_OAM_SUPPORT
   /*spInitCfgData();*/

   if( ROK != smRegCb((Ent)ENTSO, gSoSmQ, sizeof(gSoSmQ)/sizeof(CmLListCp), smSoSendReqQ,soResetCfgData))
   {
      RETVALUE(RFAILED);
   }

	if( OAM_CALL_SUCC != register_msg_proc(CP_MODULE_ID_VOIP_SIP,  APP_SYNC_MSG,  soInitCfgCallback, NULL))
	{
      RETVALUE(RFAILED);
   } 

   (unsigned char)get_resource(xwCpSipSoGenCfg, sizeof(SoGenOAMTab), xwCpSipSoGenCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpSipSoEntCfg, sizeof(SoEntOAMTab), xwCpSipSoEntCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpSipSoHdrCfg, sizeof(SoHdrOAMTab), xwCpSipSoHdrCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpSipSoReUaCfg, sizeof(SoReUaOAMTab), xwCpSipSoReUaCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpComIpTable, sizeof(CP_OAM_COM_IP_TAB), xwCpComIpTable_ROW_NUM);

   if( OAM_CALL_SUCC != app_register(CP_MODULE_ID_VOIP_SIP, &soNmsCfgTbl[0], sizeof(soNmsCfgTbl)/sizeof(soNmsCfgTbl[0])))
   {
      RETVALUE(RFAILED);
   }
#endif

   RETVALUE (ret);      
}
