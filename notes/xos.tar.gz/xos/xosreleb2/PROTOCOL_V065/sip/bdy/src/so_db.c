/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/
/********************************************************************20**

     Name:     SIP message database for encoding/decoding

     Type:     C source file

     Desc:     Definition for SDP encoding/decoding Database Elements

     File:     so_db.c

     Sid:      so_db.c@@/main/4 - Tue Apr 20 12:46:14 2004

     Prg:      jvn, sc, tn

*********************************************************************21*/


/* Header include files (.h) */
#define  CFG_APP

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_mblk.h"       /* Header file */
#include "cm_tkns.h"       /* common token structures */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_inet.h"       /* Inet header file */
#include "cm_tpt.h"        /* Transport  header file */
#include "cm_sdp.h"        /* Common SDP module */
#include "sot.h"           /* SIP upper interface */


/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_mblk.x"       /* Header file */
#include "cm_tkns.x"       /* common token structures */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_inet.x"       /* Inet header file */
#include "cm_tpt.x"        /* Transport  header file */
#include "cm_abndb.x"      /* Common database elemet definition */
#include "cm_sdp.x"        /* Common SDP module */
#include "sot.x"           /* SIP upper interface */
#include "so_rx.x"

#define soRegExpOtherTransport soRegExpOtherHandling
#define soRegExpOtherUser soRegExpOtherHandling
#define soRegExpOtherParam soRegExpOtherHandling
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/* Reference to SDP message definition in ABNF database so_db.c */
EXTERN CmAbnfElmDef soMsgDefSipMessage;
EXTERN CmAbnfElmDef soMsgDefHeaderList;
EXTERN CmAbnfElmDef soMsgDefMetaSws;
EXTERN CmAbnfElmDef soMsgDefTelSubscriberStr;
EXTERN CmAbnfElmDef soMsgDefTelSubscriber;
EXTERN CmAbnfElmDef soMsgDefServerList1;

#ifdef __cplusplus
}
#endif /* __cplusplus */

/* so DataBase Definitions */

/* Forward declerations */
EXTERN CmAbnfElmDef soMsgDefMethodList;
EXTERN CmAbnfElmDef soMsgDefPriority;
EXTERN CmAbnfElmDef soMsgDefMetaForwardSlashStr;
EXTERN CmAbnfElmDef soMsgDefAddrCh;
/********************************************************
Token Strings
*********************************************************/
/********************************************************
Token - Entry for a token
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefTokenRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefToken =
{
#ifdef CM_ABNF_DBG
   "SO TOKEN",
   "SORE_TOKEN",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 1,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefTokenRange,
   soRegExpOtherHandling
};

/********************************************************
TokenHost - Entry for a token or host
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefTokenHostRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefTokenHost =
{
#ifdef CM_ABNF_DBG
   "SO TOKEN",
   "SORE_TOKEN",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 2,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefTokenHostRange,
   soRegExpTokenHost
};

/********************************************************
IP version 6 Address
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefIpv6AddressRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefIpv6Address =
{
#ifdef CM_ABNF_DBG
   "SO IPV6ADDRESS",
   "SORE_IPV6ADDRESS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 3,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefIpv6AddressRange,
   soRegExpIpv6Address
};

/********************************************************
OtherTransport -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefOtherTransportRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefOtherTransport =
{
#ifdef CM_ABNF_DBG
   "SO OTHERTRANSPORT",
   "OTHERHANDLING",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 4,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefOtherTransportRange,
   soRegExpOtherHandling
};

/********************************************************
OtherUser   -  Other User  -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefOtherUserRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefOtherUser =
{
#ifdef CM_ABNF_DBG
   "SO OTHERUSER",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 5,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefOtherUserRange,
   soRegExpOtherHandling
};

/********************************************************
ExtensionMethod   -  Extension Method  -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefExtensionMethodRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefExtensionMethod =
{
#ifdef CM_ABNF_DBG
   "SO EXTENSIONMETHOD",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 6,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefExtensionMethodRange,
   soRegExpExtensionMethod
};

/********************************************************
HostName -  Host Name   -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefHostNameRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefHostName =
{
#ifdef CM_ABNF_DBG
   "SO HOSTNAME",
   "SORE_HOSTNAME",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 7,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefHostNameRange,
   soRegExpHostName
};

/********************************************************
HName -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefHNameRange = {1, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefHName =
{
#ifdef CM_ABNF_DBG
   "SO HNAME",
   "SORE_HNAME",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 8,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefHNameRange,
   soRegExpHName
};

/********************************************************
HValue   -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefHValueRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefHValue =
{
#ifdef CM_ABNF_DBG
   "SO HVALUE",
   "SORE_HVALUE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 9,
   sizeof(TknStrOSXL),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefHValueRange,
   soRegExpHName
};

/********************************************************
User  -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefUserRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefUser =
{
#ifdef CM_ABNF_DBG
   "SO USER",
   "SORE_USER",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 10,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefUserRange,
   soRegExpUserName
};

/********************************************************
TelephoneSubscriber  -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefTelephoneSubscriberRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefTelephoneSubscriberOld =
{
#ifdef CM_ABNF_DBG
   "SO TELEPHONESUBSCRIBER",
   "SORE_TELEPHONESUBSCRIBER",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 11,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefTelephoneSubscriberRange,
   soRegExpTelUserName
};

/********************************************************
pName -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefPNameRange = {1, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefPName =
{
#ifdef CM_ABNF_DBG
   "SO PNAME",
   "SORE_PNAME",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 12,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefPNameRange,
   soRegExpPName
};

/********************************************************
pValue   -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefPValueRange = {1, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefPValue =
{
#ifdef CM_ABNF_DBG
   "SO PVALUE",
   "SORE_PVALUE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 13,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefPValueRange,
   soRegExpPName
};

/********************************************************
quotedStr   -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefQuotedStrRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefQuotedStrToken =
{
#ifdef CM_ABNF_DBG
   "SO QUOTEDSTRTOKEN",
   "SORE_QUOTEDSTR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 14,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefQuotedStrRange,
   soRegExpQuotedStr
};

PUBLIC CmAbnfElmDef *soMsgDefQuotedStrSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefQuotedStrToken,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefQuotedStrSeq =
{
   2,
   soMsgDefQuotedStrSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefQuotedStr =
{
#ifdef CM_ABNF_DBG
   "SO QUOTEDSTR",
   "NULLP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 15,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefQuotedStrSeq,
   NULLP
};

/********************************************************
PasswordText   -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefPasswordTextRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefPasswordText =
{
#ifdef CM_ABNF_DBG
   "SO PASSWORDTEXT",
   "SORE_PASSWORDTEXT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 16,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefPasswordTextRange,
   soRegExpPasswordText
};

/********************************************************
Scheme   -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefSchemeRange = {1, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefScheme =
{
#ifdef CM_ABNF_DBG
   "SO SCHEME",
   "SORE_SCHEME",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 17,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefSchemeRange,
   soRegExpScheme
};

#ifdef SO_EVENT

#ifdef SO_REFER
/********************************************************
from-tag -  Enum for "from-tag"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefReplacesFromTagStrEnum =
{
   (Data *)"from-tag",
   SO_REPLACES_PARAMTYPE_FROMTAG
};

PUBLIC CmAbnfElmDef soMsgDefReplacesFromTagStr =
{
#ifdef CM_ABNF_DBG
   "SO FROM TAG",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 18,
    sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefReplacesFromTagStrEnum,
   NULLP
};

/********************************************************
to-tag -  Enum for "to-tag"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefReplacesToTagStrEnum =
{
   (Data *)"to-tag",
   SO_REPLACES_PARAMTYPE_TOTAG
};

PUBLIC CmAbnfElmDef soMsgDefReplacesToTagStr =
{
#ifdef CM_ABNF_DBG
   "SO To TAG",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 19,
    sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefReplacesToTagStrEnum,
   NULLP
};

/********************************************************
early-only -  Enum for "early-only"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefReplacesEarlyOnlyStrEnum =
{
   (Data *)"early-only",
   SO_REPLACES_PARAMTYPE_EARLYONLY
};

PUBLIC CmAbnfElmDef soMsgDefReplacesEarlyOnlyStr =
{
#ifdef CM_ABNF_DBG
   "SO EARLY ONLY",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 20,
    sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefReplacesEarlyOnlyStrEnum,
   NULLP
};

#endif /* SO_REFER */
#endif /* SO_EVENT */

/********************************************************
Comment  -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefCommentRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefCommentToken =
{
#ifdef CM_ABNF_DBG
   "SO COMMENT",
   "SORE_COMMENT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 21,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefCommentRange,
   soRegExpComment
};

PUBLIC CmAbnfElmDef *soMsgDefCommentSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefCommentToken,
   &soMsgDefMetaSws
}; 

PUBLIC CmAbnfElmTypeSeq soMsgDefCommentSeq =
{
   3,
   soMsgDefCommentSeqElmnt
}; 


PUBLIC CmAbnfElmDef soMsgDefComment =
{
#ifdef CM_ABNF_DBG
   "SO COMMENT",
   "SORE_COMMENT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 22,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefCommentSeq,
   NULLP
};

/********************************************************
LanguageRange  -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefLanguageRangeRange = {1, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefLanguageRange =
{
#ifdef CM_ABNF_DBG
   "SO LANGUAGERANGE",
   "SORE_LANGUAGERANGE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 23,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefLanguageRangeRange,
   soRegExpLanguageRange
};

/********************************************************
ProductVersion -  TknStrOSXL
*********************************************************/
PUBLIC CmAbnfElmTypeRange soDefProductVersionRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef *soMsgDefProductVersionElmnt[] =
{
   &soMsgDefMetaForwardSlashStr,
   &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeq soMsgDefProductVersionSeq =
{
   2,
   soMsgDefProductVersionElmnt
};

PUBLIC CmAbnfElmDef soMsgDefProductVersion =
{
#ifdef CM_ABNF_DBG
   "SOTEST PRODUCTVERSION",
   "SOTESTRE_PRODUCTVERSION",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 24,
   sizeof(TknStrOSXL),
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefProductVersionSeq,
   soRegExpMetaForwardSlash
};

/********************************************************
CallIdVal   -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefCallIdValRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefCallIdVal =
{
#ifdef CM_ABNF_DBG
   "SO CALLIDVAL",
   "SORE_CALLIDVAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 25,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefCallIdValRange,
   soRegExpCallIdVal
};

/********************************************************
SubjectTxt  -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefSubjectTxtRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefSubjectTxt =
{
#ifdef CM_ABNF_DBG
   "SO SUBJECTTXT",
   "SORE_SUBJECTTXT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 26,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefSubjectTxtRange,
   soRegExpSubjectTxt
};

/********************************************************
LanguageTag -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefLanguageTagRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefLanguageTag =
{
#ifdef CM_ABNF_DBG
   "SO LANGUAGETAG",
   "SORE_LANGUAGETAG",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 27,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefLanguageTagRange,
   soRegExpLanguageTag
};

/********************************************************
MimeVersionVal -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefMimeVersionValRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefMimeVersionVal =
{
#ifdef CM_ABNF_DBG
   "SO MIMEVERSIONVAL",
   "SORE_MIMEVERSIONVAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 28,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefMimeVersionValRange,
   soRegExpMimeVersionVal
};

/********************************************************
OrganizationVal   -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefOrganizationValRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefOrganizationVal =
{
#ifdef CM_ABNF_DBG
   "SO ORGANIZATIONVAL",
   "SORE_ORGANIZATIONVAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 29,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefOrganizationValRange,
   soRegExpOrganizationVal
};

/********************************************************
ResponseKeyVal -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefResponseKeyValRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefResponseKeyVal =
{
#ifdef CM_ABNF_DBG
   "SO RESPONSEKEYVAL",
   "SORE_RESPONSEKEYVAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 30,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefResponseKeyValRange,
   soRegExpResponseKeyVal
};

/********************************************************
Extension   -  TknStrOSXL
*********************************************************/
PUBLIC CmAbnfElmTypeRange soMsgDefExtensionRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefExtension =
{
#ifdef CM_ABNF_DBG
   "SO EXTENSION",
   "SORE_EXTENSION",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 31,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefExtensionRange,
   soRegExpExtension
};

/********************************************************
VersionVal  -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefVersionValRange = {3, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefVersionVal =
{
#ifdef CM_ABNF_DBG
   "SO VERSIONVAL",
   "SORE_VERSIONVAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 32,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefVersionValRange,
   soRegExpVersionVal
};

/********************************************************
Encryption  -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefEncryptionRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefEncryption =
{
#ifdef CM_ABNF_DBG
   "SO ENCRYPTION",
   "SORE_ENCRYPTION",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 33,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefEncryptionRange,
   soRegExpEncryption
};

/********************************************************
ReasonPhrase   -  TknStrOSXL
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefReasonPhraseRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefReasonPhrase =
{
#ifdef CM_ABNF_DBG
   "SO REASONPHRASE",
   "SORE_REASONPHRASE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 34,
   sizeof(TknStrOSXL),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefReasonPhraseRange,
   soRegExpReasonPhrase
};

/********************************************************
TknU16   &  TknU32
*********************************************************/
/********************************************************
day   -  TknU16
*********************************************************/
PUBLIC CmAbnfElmTypeIntRange soMsgDefDayRange = {2, 0xFFFF, 0, 31};

PUBLIC CmAbnfElmDef soMsgDefDay =
{
#ifdef CM_ABNF_DBG
   "SO DAY",
   "SORE_DAY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 35,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&soMsgDefDayRange,
   soRegExpDay
};

/********************************************************
year  -  TknU16
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefYearRange = {4, 4, 0, 9999};

PUBLIC CmAbnfElmDef soMsgDefYear =
{
#ifdef CM_ABNF_DBG
   "SO YEAR",
   "SORE_YEAR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 36,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&soMsgDefYearRange,
   soRegExpYear
};

/********************************************************
hr -  TknU16
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefHrRange = {2, 2, 0, 23};

PUBLIC CmAbnfElmDef soMsgDefHr =
{
#ifdef CM_ABNF_DBG
   "SO HR",
   "SORE_HR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 37,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&soMsgDefHrRange,
   soRegExpHr
};

/********************************************************
mn -  Minutes  -  TknU16
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefMnRange = {2, 2, 0, 59};

PUBLIC CmAbnfElmDef soMsgDefMn =
{
#ifdef CM_ABNF_DBG
   "SO MN",
   "SORE_MN",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 38,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&soMsgDefMnRange,
   soRegExpMn
};

/********************************************************
sec   -  Seconds  -  TknU16
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefSecRange = {2, 2, 0, 59};

PUBLIC CmAbnfElmDef soMsgDefSec =
{
#ifdef CM_ABNF_DBG
   "SO SEC",
   "SORE_SEC",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 39,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&soMsgDefSecRange,
   soRegExpSec
};

/********************************************************
Ttl   -  TknU16
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefTtlRange = {1, 3, 0, 255};

PUBLIC CmAbnfElmDef soMsgDefTtl =
{
#ifdef CM_ABNF_DBG
   "SO TTL",
   "SORE_TTL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 40,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&soMsgDefTtlRange,
   soRegExpTtl
};

/********************************************************
Frac  -  Fraction -  TknU16
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefFracRange = {0, 3, 0, 999};

PUBLIC CmAbnfElmDef soMsgDefFrac =
{
#ifdef CM_ABNF_DBG
   "SO FRAC",
   "SORE_FRAC",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 41,
   sizeof(TknU16),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&soMsgDefFracRange,
   soRegExpFrac
};

/********************************************************
QVInt -  TknU16
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefQVIntRange = {1, 1, 0, 1};

PUBLIC CmAbnfElmDef soMsgDefQVInt =
{
#ifdef CM_ABNF_DBG
   "SO QVINT",
   "SORE_QVINT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 42,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&soMsgDefQVIntRange,
   soRegExpQVInt
};

/********************************************************
WarnCode -  TknU16
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefWarnCodeRange = {0, 0xFFFF, 0, 999};

PUBLIC CmAbnfElmDef soMsgDefWarnCode =
{
#ifdef CM_ABNF_DBG
   "SO WARNCODE",
   "SORE_WARNCODE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 43,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&soMsgDefWarnCodeRange,
   soRegExpWarnCode
};

/********************************************************
StatusCode  -  TknU16
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefStatusCodeRange = {0, 0xFFFF, 0, 999};

PUBLIC CmAbnfElmDef soMsgDefStatusCode =
{
#ifdef CM_ABNF_DBG
   "SO STATUSCODE",
   "SORE_STATUSCODE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 44,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT16,
   (U8 *)&soMsgDefStatusCodeRange,
   soRegExpStatusCode
};

/********************************************************
DeltaSeconds   -  TknU32
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefDeltaSecondsRange = {0, 10, 0, 0xFFFFFFFF};

PUBLIC CmAbnfElmDef soMsgDefDeltaSeconds =
{
#ifdef CM_ABNF_DBG
   "SO DELTASECONDS",
   "SORE_DELTASECONDS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 45,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefDeltaSecondsRange,
   cmAbnfRegExpDgt
};

/********************************************************
PPort -  TknU32
*********************************************************/
PUBLIC CmAbnfElmTypeIntRange soMsgDefPPortRange = {0, 5, 0, 65535};

PUBLIC CmAbnfElmDef soMsgDefPPort =
{
#ifdef CM_ABNF_DBG
   "SO PPORT",
   "SORE_PPORT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 46,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefPPortRange,
   soRegExpPPort
};

/********************************************************
DFrac TknU32
*********************************************************/

/* so028.201 : increased range of the timestamp delay fraction */
PUBLIC CmAbnfElmTypeIntRange soMsgDefDFracRange = {0, 0xFFFF, 0, 999999999};

PUBLIC CmAbnfElmDef soMsgDefDFrac =
{
#ifdef CM_ABNF_DBG
   "SO DFRAC",
   "SORE_DFRAC",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 47,
   sizeof(TknU32),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefDFracRange,
   cmAbnfRegExpDgt
};

/********************************************************
TsFrac   -  Tknu32
*********************************************************/

/* so029.201 : increased range */
PUBLIC CmAbnfElmTypeIntRange soMsgDefTsFracRange = {0, 0xFFFF, 0, 999999999};

PUBLIC CmAbnfElmDef soMsgDefTsFrac =
{
#ifdef CM_ABNF_DBG
   "SO TSFRAC",
   "SORE_TSFRAC",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 48,
   sizeof(TknU32),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefTsFracRange,
   cmAbnfRegExpDgt
};

/********************************************************
Delay -  TknU32
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefDelayRange = {0, 0xFFFF, 0, 0xFFFFFFFF};

PUBLIC CmAbnfElmDef soMsgDefDelay =
{
#ifdef CM_ABNF_DBG
   "SO DELAY",
   "SORE_DELAY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 49,
   sizeof(TknU32),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefDelayRange,
   cmAbnfRegExpDgt
};

/********************************************************
Length   -  TknU32
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefLengthRange = {0, 0xFFFF, 0, 9999};

PUBLIC CmAbnfElmDef soMsgDefLength =
{
#ifdef CM_ABNF_DBG
   "SO LENGTH",
   "SORE_LENGTH",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 50,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefLengthRange,
   cmAbnfRegExpDgt
};

/********************************************************
CSeqVal  -  TknU32
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefCSeqValRange = {0, 10, 0, 0xFFFFFFFF};

PUBLIC CmAbnfElmDef soMsgDefCSeqVal =
{
#ifdef CM_ABNF_DBG
   "SO_CSEQVAL",
   "cmAbnfRegExpDgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 51,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefCSeqValRange,
   cmAbnfRegExpDgt
};

/********************************************************
TimestampVal   -  TknU32
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefTimestampValRange = {0, 0xFFFF, 0,
0xFFFFFFFF};

PUBLIC CmAbnfElmDef soMsgDefTimestampVal =
{
#ifdef CM_ABNF_DBG
   "SO TIMESTAMPVAL",
   "SORE_TIMESTAMPVAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 52,
   sizeof(TknU32),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefTimestampValRange,
   cmAbnfRegExpDgt
};

/********************************************************
MaxForwardsVal -  TknU32
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefMaxForwardsValRange = {0, 10, 0,
999999};

PUBLIC CmAbnfElmDef soMsgDefMaxForwardsVal =
{
#ifdef CM_ABNF_DBG
   "SO MAXFORWARDSVAL",
   "SORE_MAXFORWARDSVAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 53,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefMaxForwardsValRange,
   cmAbnfRegExpDgt
};

/********************************************************
ResponseNum -  TknU32
*********************************************************/

#ifdef SO_RFC_3262
PUBLIC CmAbnfElmTypeIntRange soMsgDefResponseNumRange = {0, 0xFFFF, 0,
0xFFFFFFFF};

PUBLIC CmAbnfElmDef soMsgDefResponseNum =
{
#ifdef CM_ABNF_DBG
   "SO RESPONSENUM",
   "SORE_RESPONSENUM",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 54,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefResponseNumRange,
   soRegExpResponseNum
};

/********************************************************
CSeqNum  -  TknU32
*********************************************************/
/* so012.102 : Fixed the cSeq range */
PUBLIC CmAbnfElmTypeIntRange soMsgDefCSeqNumRange = {0, 10, 0, 0xFFFFFFFF};

PUBLIC CmAbnfElmDef soMsgDefCSeqNum =
{
#ifdef CM_ABNF_DBG
   "SO CSEQNUM",
   "SORE_CSEQNUM",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 55,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefCSeqNumRange,
   soRegExpCSeqNum
};

#endif /* SO_RFC_3262 */


/********************************************************
Skip
*********************************************************/
/********************************************************
Linewrap -  Skip from text
*********************************************************/
PUBLIC CmAbnfElmTypeEnum soMsgDefSkipLinewrapRange = {0, 0};

PUBLIC CmAbnfElmDef soMsgDefSkipLinewrap =
{
#ifdef CM_ABNF_DBG
    "SO LINEWRAP",
    "SORE_LINEWRAP",
#endif /*CM_ABNF_DBG*/
   CM_ABNF_ELMNID_SIP_BASE + 56,
     0,
    (CM_ABNF_OPTIONAL),
    CM_ABNF_TYPE_SKIP,
    (U8 *)&soMsgDefSkipLinewrapRange,
    soRegExpLineWrap
};

/********************************************************
SkipAllSpaceEat - Destroys all spaces
*********************************************************/
PUBLIC CmAbnfElmTypeEnum soMsgDefSkipAllSpaceEatRange = {0, 0};

PUBLIC CmAbnfElmDef soMsgDefSkipAllSpaceEat =
{
#ifdef CM_ABNF_DBG
   "SO SPACEEAT",
   "SORE_SPACEEAT",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 57,
   0,
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SKIP,
   (U8 *)&soMsgDefSkipAllSpaceEatRange,
   soRegExpAllSpaceEater
};

/********************************************************
phoneSkip   -  Skip "phone" in message
*********************************************************/

PUBLIC CmAbnfElmDef soMsgDefPhoneStrSkip =
{
#ifdef CM_ABNF_DBG
   "SO KWPHONESKIPSTR",
   "SORE_PHONE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 58,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   soRegExpPhone
};

/********************************************************
ipSkip   -  Skip "ip" in message
*********************************************************/

PUBLIC CmAbnfElmDef soMsgDefIpStrSkip =
{
#ifdef CM_ABNF_DBG
   "SO KWIPSKIPSTR",
   "SORE_IP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 59,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SKIP,
   NULLP,
   soRegExpIp
};

/********************************************************
MetaForwardSlash  -  Meta for "/"
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaForwardSlashStrMeta =
{
   (Data *)"/"
};

PUBLIC CmAbnfElmDef soMsgDefMetaForwardSlashStr =
{
#ifdef CM_ABNF_DBG
   "SO METAFORWARDSLASHSTR",
   "SORE_METAFORWARDSLASH",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 60,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaForwardSlashStrMeta,
   soRegExpMetaForwardSlash
};

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaStarStrMeta =
{
   (Data *)"*"
};

PUBLIC CmAbnfElmDef soMsgDefMetaStarStr =
{
#ifdef CM_ABNF_DBG
   "SO METASTARSTR",
   "SORE_METASTAR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 61,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaStarStrMeta,
   soRegExpMetaStar
};

/********************************************************
AllStar  -  Skip from text message
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAllStarSeqElmnt[] =
{
   &soMsgDefMetaStarStr,
   &soMsgDefMetaForwardSlashStr,
   &soMsgDefMetaStarStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAllStarSeq =
{
   3,
   soMsgDefAllStarSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefAllStar =
{
#ifdef CM_ABNF_DBG
   "SO CONTENTCODINGLIST1",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 62,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefAllStarSeq,
   NULLP
};

/********************************************************
SIPSkip  -  Skip from text
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSIPStrSkipRange = {0 ,0 };

PUBLIC CmAbnfElmDef soMsgDefSIPStrSkip =
{
#ifdef CM_ABNF_DBG
   "SO KWSIPSKIPSTR",
   "SORE_SIP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 63,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SKIP,
   (U8 *)&soMsgDefSIPStrSkipRange,
   soRegExpSIP
};

/********************************************************
MetaStarSkip   -  Skip from text
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefMetaStarStrSkipRange = {0 ,0 };

PUBLIC CmAbnfElmDef soMsgDefMetaStarStrSkip =
{
#ifdef CM_ABNF_DBG
   "SO METASTARSKIPSTR",
   "SORE_METASTAR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 64,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SKIP,
   (U8 *)&soMsgDefMetaStarStrSkipRange,
   soRegExpMetaStar
};

/********************************************************
Metas
*********************************************************/

/********************************************************
MetaRightAngleBracket - Meta for ">"
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaRightAngleBracketStrMeta =
{
   (Data *)">"
};

PUBLIC CmAbnfElmDef soMsgDefMetaRightAngleBracketStr =
{
#ifdef CM_ABNF_DBG
   "SO METARIGHTANGLEBRACKETSTR",
   "SORE_METARIGHTANGLEBRACKET",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 65,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaRightAngleBracketStrMeta,
   soRegExpMetaRightAngleBracket
};


/********************************************************
MetaLeftAngleBracket - Meta for "<"
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaLeftAngleBracketStrMeta =
{
   (Data *)"<"
};

PUBLIC CmAbnfElmDef soMsgDefMetaLeftAngleBracketStr =
{
#ifdef CM_ABNF_DBG
   "SO METALEFTANGLEBRACKETSTR",
   "SORE_METALEFTANGLEBRACKET",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 66,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaLeftAngleBracketStrMeta,
   soRegExpMetaLeftAngleBracket
};

/********************************************************
MetaDot  -  Meta for "."
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaDotStrMeta =
{
   (Data *)"."
};

PUBLIC CmAbnfElmDef soMsgDefMetaDotStr =
{
#ifdef CM_ABNF_DBG
   "SO METADOTSTR",
   "SORE_METADOT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 67,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaDotStrMeta,
   soRegExpMetaDot
};


/********************************************************
OpenSqrBr   -  Meta for "["
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaOpenSqrBrStrMeta =
{
   (Data *)"["
};

PUBLIC CmAbnfElmDef soMsgDefMetaOpenSqrBrStr =
{
#ifdef CM_ABNF_DBG
   "SO METAOPENSQRBRSTR",
   "SORE_METAOPENSQRBR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 68,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaOpenSqrBrStrMeta,
   soRegExpMetaOpenSqrBr
};

/********************************************************
CloseSqrBr  -  Meta for "]"
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaCloseSqrBrStrMeta =
{
   (Data *)"]"
};

PUBLIC CmAbnfElmDef soMsgDefMetaCloseSqrBrStr =
{
#ifdef CM_ABNF_DBG
   "SO METACLOSESQRBRSTR",
   "SORE_METACLOSESQRBR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 69,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaCloseSqrBrStrMeta,
   soRegExpMetaCloseSqrBr
};

/********************************************************
MetaEqual   -  Meta for "="
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaEqualStrMeta =
{
   (Data *)"="
};

PUBLIC CmAbnfElmDef soMsgDefMetaEqualStr =
{
#ifdef CM_ABNF_DBG
   "SO METAEQUALSTR",
   "SORE_METAEQUAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 70,
  0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaEqualStrMeta,
   soRegExpMetaEqual
};

/********************************************************
MetaComma   -  Meta for ","
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaCommaStrMeta =
{
   (Data *)","
};

PUBLIC CmAbnfElmDef soMsgDefMetaCommaStr =
{
#ifdef CM_ABNF_DBG
   "SO METACOMMASTR",
   "SORE_METACOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 71,
  0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaCommaStrMeta,
   soRegExpMetaComma
};

/********************************************************
MetaViaParSep  -  Hacked Meta for Via header's via-parms
During encoding, we encode multiple via-parms in mulitple
lines in the form of multiple Via headers rather than a
single Via header containing multiple via-parms.
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaViaParSepMeta =
{
   (Data *)"\r\nVia:"
};

PUBLIC CmAbnfElmDef soMsgDefMetaViaParSep =
{
#ifdef CM_ABNF_DBG
   "SO METACOMMASTR",
   "SORE_METACOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 72,
  0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaViaParSepMeta,
   soRegExpMetaComma
};

/* This is a hack to accept an incoming date header
 * with or without a space between a comma and day but always 
 * put a space after a , and day while encoding. 
 */
/********************************************************
MetaCommaOptSpace   -  Meta for ", "
*********************************************************/
PUBLIC CmAbnfElmTypeMeta soMsgDefMetaCommaOptSpaceStrMeta =
{
   (Data *)", "
};

PUBLIC CmAbnfElmDef soMsgDefMetaCommaOptSpaceStr =
{
#ifdef CM_ABNF_DBG
   "SO METACOMMASTROPTSPACE",
   "SORE_METACOMMAOPTSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 73,
  0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaCommaOptSpaceStrMeta,
   soRegExpMetaComma
};


/********************************************************
MetaSpace   -  Meta for " "(space)
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaSpaceStrMeta =
{
   (Data *)" "
};

PUBLIC CmAbnfElmDef soMsgDefMetaSpaceStr =
{
#ifdef CM_ABNF_DBG
   "SO METASPACESTR",
   "SORE_METASPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 74,
  0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaSpaceStrMeta,
   soRegExpMetaSpace
};

/* BEGIN: Three new headers support */

/* so001.201: Support for new Meta for display name */
/********************************************************
DNLWS         -  Meta
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaDNLwsMeta =
{
   (Data *)" "
}; 

PUBLIC CmAbnfElmDef soMsgDefMetaDNLws =
{
#ifdef CM_ABNF_DBG
   "SO METADNLWS",
   "SORE_METADNLWS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 865,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaDNLwsMeta,
   soRegExpMetaDNLws
};


/********************************************************
LWS         -  Meta
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaLwsMeta =
{
   (Data *)" "
};

PUBLIC CmAbnfElmDef soMsgDefMetaLws =
{
#ifdef CM_ABNF_DBG
   "SO METALWS",
   "SORE_METALWS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 75,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaLwsMeta,
   soRegExpMetaLws
};

PUBLIC CmAbnfElmDef soMsgDefMetaSws =
{
#ifdef CM_ABNF_DBG
   "SO METASWS",
   "SORE_METALWS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 76,
   0,
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaLwsMeta,
   soRegExpMetaLws
};


/* so023.201 Changes for allowing a space between colon and header value */
PUBLIC CmAbnfElmDef soMsgDefMetaOptSwsDecMandSwsEnc =
{
#ifdef CM_ABNF_DBG
   "SO METAOPTSWSDECMANDSWSENC",
   "SORE_METAOPTLWSDEC",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 76,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaLwsMeta,
   soRegExpMetaOptSwsDec
};


/********************************************************
MetaColon   -  Meta for ":"
This def does not accept line-break before or after the ":";
Therefore this def represents HCOLON
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefMetaColonStrSeqElmnt[] =
{
   &cmMsgDefOptMetaSpace,
   &cmMsgDefMetaColon,
   &soMsgDefMetaSws
};

PUBLIC CmAbnfElmTypeSeq soMsgDefMetaColonStrSeq =
{
   3,
   soMsgDefMetaColonStrSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefMetaColonStr =
{
#ifdef CM_ABNF_DBG
   "SO METACOLON",
   "SORE_METACOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 77,
   0,
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefMetaColonStrSeq,
   NULLP
};

/* so023.201 Changes for allowing a space between colon and header value */
/********************************************************
MetaColon   -  Meta for ": "
This def does not accept line-break before or after the ":";
Therefore this def represents HCOLON
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefMetaSwsColonStrSeqElmnt[] =
{
   &cmMsgDefOptMetaSpace,
   &cmMsgDefMetaColon,
   &soMsgDefMetaOptSwsDecMandSwsEnc   /* changed by balyan */
};

PUBLIC CmAbnfElmTypeSeq soMsgDefMetaSwsColonStrSeq =
{
   3,
   soMsgDefMetaSwsColonStrSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefMetaSwsColonStr =
{
#ifdef CM_ABNF_DBG
   "SO METACOLONSWS",
   "SORE_METACOLONSWS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 77,
   0,
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQ,
#ifdef SO_SPACE_AFTER_COLON
   (U8 *)&soMsgDefMetaSwsColonStrSeq,
#else
   (U8 *)&soMsgDefMetaColonStrSeq,
#endif
   NULLP
};

/* END: Three new headers support */

/********************************************************
GMT   -  Meta for "GMT"
*********************************************************/
PUBLIC CmAbnfElmTypeMeta soMsgDefGMTStrMeta =
{
   (Data *)"GMT"
};

PUBLIC CmAbnfElmDef soMsgDefGMTStr =
{
#ifdef CM_ABNF_DBG
   "SO GMTSTR",
   "SORE_GMT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 78,
  0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefGMTStrMeta,
   soRegExpGMT
};

/********************************************************
CRLF  -  Meta for Carriage return line feed
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaCRLFStrMeta =
{
   (Data *)"\r\n"
};

PUBLIC CmAbnfElmDef soMsgDefMetaCRLFStr =
{
#ifdef CM_ABNF_DBG
   "SO METACRLFSTR",
   "SORE_METACRLF",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 79,
  0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaCRLFStrMeta,
   soRegExpMetaCRLF
};

/********************************************************
MetaAmpersand  -  Meta for "&"
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaAmpersandStrMeta =
{
   (Data *)"&"
};

PUBLIC CmAbnfElmDef soMsgDefMetaAmpersandStr =
{
#ifdef CM_ABNF_DBG
   "SO METAAMPERSANDSTR",
   "SORE_METAAMPERSAND",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 80,
  0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaAmpersandStrMeta,
   soRegExpMetaAmpersand
};

/********************************************************
MetaDQuote  -  Meta for Double Quote """
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaDQuoteStrMeta =
{
   (Data *)"\""
};

PUBLIC CmAbnfElmDef soMsgDefMetaDQuoteStr =
{
#ifdef CM_ABNF_DBG
   "SO METADQUOTESTR",
   "SORE_METADQUOTE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 81,
  0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaDQuoteStrMeta,
   soRegExpMetaDQuote
};

/********************************************************
MetaSemiColon  -  Meta for ";"
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaSemiColonStrMeta =
{
   (Data *)";"
};

PUBLIC CmAbnfElmDef soMsgDefMetaSemiColonStr =
{
#ifdef CM_ABNF_DBG
   "SO METASEMICOLONSTR",
   "SORE_METASEMICOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 82,
  0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaSemiColonStrMeta,
   soRegExpMetaSemiColon
};

/********************************************************
MetaQuestionMark  -  Meta for "?"
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaQuestionMarkStrMeta =
{
   (Data *)"?"
};

PUBLIC CmAbnfElmDef soMsgDefMetaQuestionMarkStr =
{
#ifdef CM_ABNF_DBG
   "SO METAQUESTIONMARKSTR",
   "SORE_METAQUESTIONMARK",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 83,
  0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaQuestionMarkStrMeta,
   soRegExpMetaQuestionMark
};

/********************************************************
MetaAt   -  Meta for "@"
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaAtStrMeta =
{
   (Data *)"@"
};

PUBLIC CmAbnfElmDef soMsgDefMetaAtStr =
{
#ifdef CM_ABNF_DBG
   "SO METAATSTR",
   "SORE_METAAT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 84,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaAtStrMeta,
   soRegExpMetaAt
};

/********************************************************
MetaStar -  Meta for "*"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefStarStrEnum =
{
   (Data *)"*",
   SO_CODINGS_METASTAR
};

PUBLIC CmAbnfElmDef soMsgDefStarStr =
{
#ifdef CM_ABNF_DBG
   "SO METASTARSTR",
   "SORE_METASTAR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 85,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefStarStrEnum,
   NULLP
};

/********************************************************
SIPVersionStr  -  Meta for "SIP/"
*********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefSIPVersionStrMeta =
{
   (Data *)"SIP/"
};

PUBLIC CmAbnfElmDef soMsgDefSIPVersionStr =
{
#ifdef CM_ABNF_DBG
   "SO SIPSTR",
   "SORE_SIP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 86,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefSIPVersionStrMeta,
   soRegExpSIPFS
};



/********************************************************
Enums
*********************************************************/
/********************************************************
INVITE - Enum for "INVITE"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefINVITEStrEnum =
{
   (Data *)"INVITE",
   SO_METHODSTD_INVITE
};

PUBLIC CmAbnfElmDef soMsgDefINVITEStr =
{
#ifdef CM_ABNF_DBG
   "SO INVITESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 87,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefINVITEStrEnum,
   NULLP
};

/********************************************************
ACK   -  Enum for "ACK"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefACKStrEnum =
{
   (Data *)"ACK",
   SO_METHODSTD_ACK
};

PUBLIC CmAbnfElmDef soMsgDefACKStr =
{
#ifdef CM_ABNF_DBG
   "SO ACKSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 88,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefACKStrEnum,
   NULLP
};

/********************************************************
OPTIONS  -  Enum for "OPTIONS"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefOPTIONSStrEnum =
{
   (Data *)"OPTIONS",
   SO_METHODSTD_OPTIONS
};

PUBLIC CmAbnfElmDef soMsgDefOPTIONSStr =
{
#ifdef CM_ABNF_DBG
   "SO OPTIONSSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 89,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefOPTIONSStrEnum,
   NULLP
};

/********************************************************
BYE   -  Enum for "BYE"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefBYEStrEnum =
{
   (Data *)"BYE",
   SO_METHODSTD_BYE
};

PUBLIC CmAbnfElmDef soMsgDefBYEStr =
{
#ifdef CM_ABNF_DBG
   "SO BYESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 90,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefBYEStrEnum,
   NULLP
};

#ifdef SO_CALLERPREF

/********************************************************
cancel -  Enum for "cancel"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefCancelStrEnum =
{
   (Data *)"cancel",
   SO_REQUESTDISP_CANCEL_CANCEL  
};

PUBLIC CmAbnfElmDef soMsgDefCancelStr =
{
#ifdef CM_ABNF_DBG
   "SO CANCEL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 91,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefCancelStrEnum,
   NULLP
};

/********************************************************
no-cancel -  Enum for "no-cancel"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefNoCancelStrEnum =
{
   (Data *)"no-cancel",
   SO_REQUESTDISP_CANCEL_NOCANCEL  
};

PUBLIC CmAbnfElmDef soMsgDefNoCancelStr =
{
#ifdef CM_ABNF_DBG
   "SO CANCEL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 92,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefNoCancelStrEnum,
   NULLP
};
#endif /* SO_CALLERPREF */


/********************************************************
CANCEL   -  Enum for "CANCEL"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefCANCELStrEnum =
{
   (Data *)"CANCEL",
   SO_METHODSTD_CANCEL
};

PUBLIC CmAbnfElmDef soMsgDefCANCELStr =
{
#ifdef CM_ABNF_DBG
   "SO CANCELSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 93,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefCANCELStrEnum,
   NULLP
};

#ifdef SO_CALLERPREF
/********************************************************
fork -  Enum for "fork"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefForkStrEnum =
{
   (Data *)"fork",
   SO_REQUESTDISP_FORK_FORK      
};

PUBLIC CmAbnfElmDef soMsgDefForkStr =
{
#ifdef CM_ABNF_DBG
   "SO FORK",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 94,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefForkStrEnum,
   NULLP
};

/********************************************************
no-fork -  Enum for "no-fork"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefNoForkStrEnum =
{
   (Data *)"no-fork",
   SO_REQUESTDISP_FORK_NOFORK      
};

PUBLIC CmAbnfElmDef soMsgDefNoForkStr =
{
#ifdef CM_ABNF_DBG
   "SO NO-FORK",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 95,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefNoForkStrEnum,
   NULLP
};
#endif /* SO_CALLERPREF */

/********************************************************
REGISTER -  Enum for "REGISTER"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefREGISTERStrEnum =
{
   (Data *)"REGISTER",
   SO_METHODSTD_REGISTER
};

PUBLIC CmAbnfElmDef soMsgDefREGISTERStr =
{
#ifdef CM_ABNF_DBG
   "SO REGISTERSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 96,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefREGISTERStrEnum,
   NULLP
};

/********************************************************
INFO  -  Enum for "INFO"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefINFOStrEnum =
{
   (Data *)"INFO",
   SO_METHODSTD_INFO
};

PUBLIC CmAbnfElmDef soMsgDefINFOStr =
{
#ifdef CM_ABNF_DBG
   "SO INFOSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 97,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefINFOStrEnum,
   NULLP
};

/********************************************************
COMET -  Enum for "COMET"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefCOMETStrEnum =
{
   (Data *)"COMET",
   SO_METHODSTD_COMET
};

PUBLIC CmAbnfElmDef soMsgDefCOMETStr =
{
#ifdef CM_ABNF_DBG
   "SO COMETSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 98,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefCOMETStrEnum,
   NULLP
};

/********************************************************
PRACK -  Enum for "PRACK"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefPRACKStrEnum =
{
   (Data *)"PRACK",
   SO_METHODSTD_PRACK
};

PUBLIC CmAbnfElmDef soMsgDefPRACKStr =
{
#ifdef CM_ABNF_DBG
   "SO PRACKSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 99,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefPRACKStrEnum,
   NULLP
};

/********************************************************
SUBSCRIBE -  Enum for "SUBSCRIBE"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSUBSCRIBEStrEnum =
{
   (Data *)"SUBSCRIBE",
   SO_METHODSTD_SUBSCRIBE
};

PUBLIC CmAbnfElmDef soMsgDefSUBSCRIBEStr =
{
#ifdef CM_ABNF_DBG
   "SO SUBSCRIBESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 100,
     sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSUBSCRIBEStrEnum,
   NULLP
};


/********************************************************
NOTIFY -  Enum for "NOTIFY"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefNOTIFYStrEnum =
{
   (Data *)"NOTIFY",
   SO_METHODSTD_NOTIFY
};

PUBLIC CmAbnfElmDef soMsgDefNOTIFYStr =
{
#ifdef CM_ABNF_DBG
   "SO NOTIFYSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 101,
     sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefNOTIFYStrEnum,
   NULLP
};
/********************************************************
REFER -  Enum for "REFER"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefREFERStrEnum =
{
   (Data *)"REFER",
   SO_METHODSTD_REFER
};

PUBLIC CmAbnfElmDef soMsgDefREFERStr =
{
#ifdef CM_ABNF_DBG
   "SO REFERSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 102,
                                                      sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefREFERStrEnum,
   NULLP
};


/********************************************************
MESSAGE -  Enum for "MESSAGE"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefMESSAGEStrEnum =
{
   (Data *)"MESSAGE",
   SO_METHODSTD_MESSAGE
};

PUBLIC CmAbnfElmDef soMsgDefMESSAGEStr =
{
#ifdef CM_ABNF_DBG
   "SO MESSAGESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 103,
     sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefMESSAGEStrEnum,
   NULLP
};

/********************************************************
UpdateStr -  Enum for "update"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefUPDATEStrEnum =
{
   (Data *)"UPDATE",
   SO_METHODSTD_UPDATE
};

PUBLIC CmAbnfElmDef soMsgDefUPDATEStr =
{
#ifdef CM_ABNF_DBG
   "SO MESSAGESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 104,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefUPDATEStrEnum,
   NULLP
};

/********************************************************
Mon   -  Enum for Monday "Mon"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefMonStrEnum =
{
   (Data *)"Mon",
   SO_WKDAY_MON
};

PUBLIC CmAbnfElmDef soMsgDefMonStr =
{
#ifdef CM_ABNF_DBG
   "SO MONSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 105,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefMonStrEnum,
   NULLP
};

/********************************************************
Tue   -  Enum for Tuesday "Tue"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTueStrEnum =
{
   (Data *)"Tue",
   SO_WKDAY_TUE
};

PUBLIC CmAbnfElmDef soMsgDefTueStr =
{
#ifdef CM_ABNF_DBG
   "SO TUESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 106,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTueStrEnum,
   NULLP
};

/********************************************************
Wed   -  Enum for Wednesday "Wed"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefWedStrEnum =
{
   (Data *)"Wed",
   SO_WKDAY_WED
};

PUBLIC CmAbnfElmDef soMsgDefWedStr =
{
#ifdef CM_ABNF_DBG
   "SO WEDSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 107,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefWedStrEnum,
   NULLP
};

/********************************************************
Thu   -  Enum for Thursday "Thu"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefThuStrEnum =
{
   (Data *)"Thu",
   SO_WKDAY_THU
};

PUBLIC CmAbnfElmDef soMsgDefThuStr =
{
#ifdef CM_ABNF_DBG
   "SO THUSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 108,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefThuStrEnum,
   NULLP
};

/********************************************************
Fri   -  Enum for Friday "Fri"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefFriStrEnum =
{
   (Data *)"Fri",
   SO_WKDAY_FRI
};

PUBLIC CmAbnfElmDef soMsgDefFriStr =
{
#ifdef CM_ABNF_DBG
   "SO FRISTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 109,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefFriStrEnum,
   NULLP
};

/********************************************************
Sat   -  Enum for Saturday "Sat"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSatStrEnum =
{
   (Data *)"Sat",
   SO_WKDAY_SAT
};

PUBLIC CmAbnfElmDef soMsgDefSatStr =
{
#ifdef CM_ABNF_DBG
   "SO SATSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 110,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSatStrEnum,
   NULLP
};

/********************************************************
Sun   -  Enum for Sunday "Sun"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSunStrEnum =
{
   (Data *)"Sun",
   SO_WKDAY_SUN
};

PUBLIC CmAbnfElmDef soMsgDefSunStr =
{
#ifdef CM_ABNF_DBG
   "SO SUNSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 111,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSunStrEnum,
   NULLP
};

/********************************************************
Jan   -  Enum for January "Jan"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefJanStrEnum =
{
   (Data *)"Jan",
   SO_MONTH_JAN
};

PUBLIC CmAbnfElmDef soMsgDefJanStr =
{
#ifdef CM_ABNF_DBG
   "SO JANSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 112,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefJanStrEnum,
   NULLP
};

/********************************************************
Feb   -  Enum for February "Feb"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefFebStrEnum =
{
   (Data *)"Feb",
   SO_MONTH_FEB
};

PUBLIC CmAbnfElmDef soMsgDefFebStr =
{
#ifdef CM_ABNF_DBG
   "SO FEBSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 113,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefFebStrEnum,
   NULLP
};

/********************************************************
Mar   -  Enum for March "Mar"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefMarStrEnum =
{
   (Data *)"Mar",
   SO_MONTH_MAR
};

PUBLIC CmAbnfElmDef soMsgDefMarStr =
{
#ifdef CM_ABNF_DBG
   "SO MARSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 114,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefMarStrEnum,
   NULLP
};

/********************************************************
Apr   -  Enum for April "Apr"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefAprStrEnum =
{
   (Data *)"Apr",
   SO_MONTH_APR
};

PUBLIC CmAbnfElmDef soMsgDefAprStr =
{
#ifdef CM_ABNF_DBG
   "SO APRSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 115,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefAprStrEnum,
   NULLP
};

/********************************************************
May   -  Enum for May "May"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefMayStrEnum =
{
   (Data *)"May",
   SO_MONTH_MAY
};

PUBLIC CmAbnfElmDef soMsgDefMayStr =
{
#ifdef CM_ABNF_DBG
   "SO MAYSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 116,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefMayStrEnum,
   NULLP
};

/********************************************************
Jun   -  Enum for June "Jun"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefJunStrEnum =
{
   (Data *)"Jun",
   SO_MONTH_JUN
};

PUBLIC CmAbnfElmDef soMsgDefJunStr =
{
#ifdef CM_ABNF_DBG
   "SO JUNSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 117,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefJunStrEnum,
   NULLP
};

/********************************************************
Jul   -  Enum for July "Jul"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefJulStrEnum =
{
   (Data *)"Jul",
   SO_MONTH_JUL
};

PUBLIC CmAbnfElmDef soMsgDefJulStr =
{
#ifdef CM_ABNF_DBG
   "SO JULSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 118,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefJulStrEnum,
   NULLP
};

/********************************************************
Aug   -  Enum for August "Aug"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefAugStrEnum =
{
   (Data *)"Aug",
   SO_MONTH_AUG
};

PUBLIC CmAbnfElmDef soMsgDefAugStr =
{
#ifdef CM_ABNF_DBG
   "SO AUGSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 119,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefAugStrEnum,
   NULLP
};

/********************************************************
Sep   -  Enum for September "Sep"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSepStrEnum =
{
   (Data *)"Sep",
   SO_MONTH_SEP
};

PUBLIC CmAbnfElmDef soMsgDefSepStr =
{
#ifdef CM_ABNF_DBG
   "SO SEPSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 120,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSepStrEnum,
   NULLP
};

/********************************************************
Oct   -  Enum for October "Oct"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefOctStrEnum =
{
   (Data *)"Oct",
   SO_MONTH_OCT
};

PUBLIC CmAbnfElmDef soMsgDefOctStr =
{
#ifdef CM_ABNF_DBG
   "SO OCTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 121,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefOctStrEnum,
   NULLP
};

/********************************************************
Nov   -  Enum for November "Nov"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefNovStrEnum =
{
   (Data *)"Nov",
   SO_MONTH_NOV
};

PUBLIC CmAbnfElmDef soMsgDefNovStr =
{
#ifdef CM_ABNF_DBG
   "SO NOVSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 122,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefNovStrEnum,
   NULLP
};

/********************************************************
Dec   -  Enum for December "Dec"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefDecStrEnum =
{
   (Data *)"Dec",
   SO_MONTH_DEC
};

PUBLIC CmAbnfElmDef soMsgDefDecStr =
{
#ifdef CM_ABNF_DBG
   "SO DECSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 123,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefDecStrEnum,
   NULLP
};

/********************************************************
UDP   -  Enum for Url Transport Param UDP "UDP"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTPUdpStrEnum =
{
   (Data *)"udp",
   SO_TRANSPORT_UDP
};

PUBLIC CmAbnfElmDef soMsgDefTPUdpStr =
{
#ifdef CM_ABNF_DBG
   "SO UDPSTR",
   "SORE_UDP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 124,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTPUdpStrEnum,
   NULLP
};

/********************************************************
tcp   -  Enum for Url Transport Param TCP "tcp"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTPTcpStrEnum =
{
   (Data *)"tcp",
   SO_TRANSPORT_TCP
};

PUBLIC CmAbnfElmDef soMsgDefTPTcpStr =
{
#ifdef CM_ABNF_DBG
   "SO TCPSTR",
   "SORE_TCP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 125,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTPTcpStrEnum,
   NULLP
};

/********************************************************
sctp  -  Enum for Url Transport Param SCTP "sctp"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTPSctpStrEnum =
{
   (Data *)"sctp",
   SO_TRANSPORT_SCTP
};

PUBLIC CmAbnfElmDef soMsgDefTPSctpStr =
{
#ifdef CM_ABNF_DBG
   "SO SCTPSTR",
   "SORE_SCTP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 126,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTPSctpStrEnum,
   NULLP
};

/********************************************************
tls   -  Enum for Url Transport Param TLS "tls"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTPTlsStrEnum =
{
   (Data *)"tls",
   SO_TRANSPORT_TLS
};

PUBLIC CmAbnfElmDef soMsgDefTPTlsStr =
{
#ifdef CM_ABNF_DBG
   "SO TLSSTR",
   "SORE_TLS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 127,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTPTlsStrEnum,
   NULLP
};

/********************************************************
UDP   -  Enum for Via Protocol UDP "UDP"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefUdpStrEnum =
{
   (Data *)"UDP",
   SO_TRANSPORT_UDP
};

PUBLIC CmAbnfElmDef soMsgDefUdpStr =
{
#ifdef CM_ABNF_DBG
   "SO UDPSTR",
   "SORE_UDP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 128,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefUdpStrEnum,
   NULLP
};

/********************************************************
tcp   -  Enum for Via Protocol TCP "tcp"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTcpStrEnum =
{
   (Data *)"TCP",
   SO_TRANSPORT_TCP
};

PUBLIC CmAbnfElmDef soMsgDefTcpStr =
{
#ifdef CM_ABNF_DBG
   "SO TCPSTR",
   "SORE_TCP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 129,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTcpStrEnum,
   NULLP
};

/********************************************************
sctp  -  Enum for Via Protocol SCTP "sctp"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSctpStrEnum =
{
   (Data *)"SCTP",
   SO_TRANSPORT_SCTP
};

PUBLIC CmAbnfElmDef soMsgDefSctpStr =
{
#ifdef CM_ABNF_DBG
   "SO SCTPSTR",
   "SORE_SCTP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 130,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSctpStrEnum,
   NULLP
};

/********************************************************
tls   -  Enum for Via Protocol TLS "tls"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTlsStrEnum =
{
   (Data *)"TLS",
   SO_TRANSPORT_TLS
};

PUBLIC CmAbnfElmDef soMsgDefTlsStr =
{
#ifdef CM_ABNF_DBG
   "SO TLSSTR",
   "SORE_TLS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 131,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTlsStrEnum,
   NULLP
};

/********************************************************
phone -  Enum for phone "phone"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefPhoneStrEnum =
{
   (Data *)"phone",
   SO_USERPARAM_PHONE
};

PUBLIC CmAbnfElmDef soMsgDefPhoneStr =
{
#ifdef CM_ABNF_DBG
   "SO PHONESTR",
   "SORE_PHONE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 132,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefPhoneStrEnum,
   NULLP
};

/********************************************************
ip -  Enum for IP "ip"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefIpStrEnum =
{
   (Data *)"ip",
   SO_USERPARAM_IP
};

PUBLIC CmAbnfElmDef soMsgDefIpStr =
{
#ifdef CM_ABNF_DBG
   "SO IPSTR",
   "SORE_IP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 133,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefIpStrEnum,
   NULLP
};

/********************************************************
Transport   -  Enum for "Transport"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTransportStrEnum =
{
   (Data *)"transport",
   SO_URLPARAMETER_TRANSPORTPARAM
};

PUBLIC CmAbnfElmDef soMsgDefTransportStr =
{
#ifdef CM_ABNF_DBG
   "SO TRANSPORTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 134,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTransportStrEnum,
   NULLP
};

/********************************************************
OtherTransportStr -  Enum for Other Transport
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefOtherTransportStrEnum =
{
   NULLP,
   SO_TRANSPORT_EXTN
};

PUBLIC CmAbnfElmDef soMsgDefOtherTransportStr =
{
#ifdef CM_ABNF_DBG
   "SO OTHERTRANSPORTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 135,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefOtherTransportStrEnum,
   NULLP
};

/********************************************************
User  -  Enum for "User"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefUserStrEnum =
{
   (Data *)"user",
   SO_URLPARAMETER_USERPARAM
};

PUBLIC CmAbnfElmDef soMsgDefUserStr =
{
#ifdef CM_ABNF_DBG
   "SO USERSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 136,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefUserStrEnum,
   NULLP
};

/********************************************************
OtherUserStr   -  Enum for Other User
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefOtherUserStrEnum =
{
   NULLP,
   SO_USERPARAM_OTHERUSER
};

PUBLIC CmAbnfElmDef soMsgDefOtherUserStr =
{
#ifdef CM_ABNF_DBG
   "SOTEST OTHERUSERSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 137,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefOtherUserStrEnum,
   NULLP
};

/********************************************************
Method   -  Enum for "Method"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefMethodStrEnum =
{
   (Data *)"Method",
   SO_URLPARAMETER_METHOD
};

PUBLIC CmAbnfElmDef soMsgDefMethodStr =
{
#ifdef CM_ABNF_DBG
   "SO METHODSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 138,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefMethodStrEnum,
   NULLP
};

/********************************************************
MethodStd   -  Enum for Standard Method
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefMethodStdStrEnum =
{
   NULLP,
   SO_METHOD_METHODSTD
};

PUBLIC CmAbnfElmDef soMsgDefMethodStdStr =
{
#ifdef CM_ABNF_DBG
   "SOTEST METHODSTDSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 139,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefMethodStdStrEnum,
   NULLP
};

/********************************************************
ExtensionMethodStr   -  Enum for Extension Method
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefExtensionMethodStrEnum =
{
   NULLP,
   SO_METHOD_EXTENSIONMETHOD
};

PUBLIC CmAbnfElmDef soMsgDefExtensionMethodStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 140,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefExtensionMethodStrEnum,
   NULLP
};

/********************************************************
comp   -  Enum for comp "comp"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefUrlCompStrEnum =
{  
   (Data *)"comp",
   SO_URLPARAMETER_COMP
};

PUBLIC CmAbnfElmDef soMsgDefUrlCompStr =
{  
#ifdef CM_ABNF_DBG
   "SO URL COMP STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 141,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefUrlCompStrEnum,
   NULLP
};

/********************************************************
ttl   -  Enum for TTL "ttl"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTtlStrEnum =
{
   (Data *)"ttl",
   SO_URLPARAMETER_TTLPARAM
};

PUBLIC CmAbnfElmDef soMsgDefTtlStr =
{
#ifdef CM_ABNF_DBG
   "SO TTLSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 142,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTtlStrEnum,
   NULLP
};

/********************************************************
comp   -  Enum for comp "comp"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefViaCompStrEnum =
{
   (Data *)"comp",
   SO_VIAPARAM_VIACOMP
};

PUBLIC CmAbnfElmDef soMsgDefViaCompStr =
{
#ifdef CM_ABNF_DBG
   "SO VIA COMP STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 143,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefViaCompStrEnum,
   NULLP
};

/*******************************************************
ViaTtl   -  Enum for TTL used in Via "ttl"
********************************************************/


PUBLIC CmAbnfElmTypeEnum soMsgDefViaTtlStrEnum =
{
   (Data *)"ttl",
   SO_VIAPARAM_VIATTL
};

PUBLIC CmAbnfElmDef soMsgDefViaTtlStr =
{
#ifdef CM_ABNF_DBG
   "SO TTLSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 144,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefViaTtlStrEnum,
   NULLP
};

#ifdef SO_NAT
/********************************************************
ViaRport -  Enum for Rport used in Via "rport"
********************************************************/


PUBLIC CmAbnfElmTypeEnum soMsgDefViaRportStrEnum =
{
   (Data *)"rport",
   SO_VIAPARAM_VIARPORT
};

PUBLIC CmAbnfElmDef soMsgDefViaRportStr =
{
#ifdef CM_ABNF_DBG
   "SO RPORTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 145,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefViaRportStrEnum,
   NULLP
};

/********************************************************
ViaRport -  Enum for Rport used in Via "rport"
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefViaRportValSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefPPort
};

PUBLIC CmAbnfElmTypeSeq soMsgDefViaRportValSeq =
{
   4,
   soMsgDefViaRportValSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefViaRport =
{
#ifdef CM_ABNF_DBG
   "SO VIARPORT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 146,
   sizeof(SoParameter),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefViaRportValSeq,
   soRegExpMetaEqual
};
#endif /* SO_NAT */

#ifdef SO_ENUM
/********************************************************
postd -  Enum for "postd"
*********************************************************/
PUBLIC CmAbnfElmTypeEnum soMsgDefPostdStrEnum =
{
   (Data *)"postd",
   SO_URLPARAMETER_POSTD
};

PUBLIC CmAbnfElmDef soMsgDefPostdStr =
{
#ifdef CM_ABNF_DBG
   "SO POSTDSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 147,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefPostdStrEnum,
   NULLP
};

/********************************************************
isub -  Enum for "isub"
*********************************************************/
PUBLIC CmAbnfElmTypeEnum soMsgDefIsubStrEnum =
{
   (Data *)"isub",
   SO_URLPARAMETER_ISUB
};

PUBLIC CmAbnfElmDef soMsgDefIsubStr =
{
#ifdef CM_ABNF_DBG
   "SO ISUBSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 148,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefIsubStrEnum,
   NULLP
};

/********************************************************
phone-context -  Enum for "phone-context"
*********************************************************/
PUBLIC CmAbnfElmTypeEnum soMsgDefPhoneContextStrEnum =
{
   (Data *)"phone-context",
   SO_URLPARAMETER_PHONECONTEXT
};

PUBLIC CmAbnfElmDef soMsgDefPhoneContextStr =
{
#ifdef CM_ABNF_DBG
   "SO PHONECONTEXTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 149,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefPhoneContextStrEnum,
   NULLP
};
#endif /* SO_ENUM */

/********************************************************
maddr -  Enum for Multicast address "maddr"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefMaddrStrEnum =
{
   (Data *)"maddr",
   SO_URLPARAMETER_MADDRHOST
};

PUBLIC CmAbnfElmDef soMsgDefMaddrStr =
{
#ifdef CM_ABNF_DBG
   "SO MADDRSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 150,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefMaddrStrEnum,
   NULLP
};

#ifdef SO_PINT
/********************************************************
tsp -  Enum for Telephone Service Provider domain "tsp"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTspStrEnum =
{
   (Data *)"tsp",
   SO_URLPARAMETER_TSPDOMAIN
};

PUBLIC CmAbnfElmDef soMsgDefTspStr =
{
#ifdef CM_ABNF_DBG
   "SO TSPSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 151,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTspStrEnum,
   NULLP
};
#endif /* end of SO_PINT for tsp addition */

/*******************************************************
ViaMaddr -  Enum for Maddr used in Via "maddr"
********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefViaMaddrStrEnum =
{
   (Data *)"maddr",
   SO_VIAPARAM_MADDR
};

PUBLIC CmAbnfElmDef soMsgDefViaMaddrStr =
{
#ifdef CM_ABNF_DBG
   "SO MADDRSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 152,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefViaMaddrStrEnum,
   NULLP
};


/********************************************************
HostNameStr -  Enum for Host Name
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHostNameStrEnum =
{
   NULLP,
   SO_HOST_HOSTNAME
};

PUBLIC CmAbnfElmDef soMsgDefHostNameStr =
{
#ifdef CM_ABNF_DBG
   "SO HOSTNAMESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 153,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHostNameStrEnum,
   NULLP
};

/********************************************************
Ipv4AddressStr -  Enum for IP version 4 Address
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefIpv4AddressStrEnum =
{
   NULLP,
   SO_HOST_IPV4ADDRESS
};

PUBLIC CmAbnfElmDef soMsgDefIpv4AddressStr =
{
#ifdef CM_ABNF_DBG
   "SOTEST IPV4ADDRSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 154,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefIpv4AddressStrEnum,
   NULLP
};

/********************************************************
Ipv6ReferenceStr  -  Enum for IP version 6 Reference
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefIpv6ReferenceStrEnum =
{
   NULLP,
   SO_HOST_IPV6REFERENCE
};

PUBLIC CmAbnfElmDef soMsgDefIpv6ReferenceStr =
{
#ifdef CM_ABNF_DBG
   "SO IPV6REFERENCESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 155,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefIpv6ReferenceStrEnum,
   NULLP
};

/**********************************************************
UserTypeStr -  Enum for Normal User Type
***********************************************************/
PUBLIC CmAbnfElmTypeEnum soMsgDefUserTypeStrEnum =
{
   NULLP,
   SO_USERTYPE_USER
};

PUBLIC CmAbnfElmDef soMsgDefUserTypeStr =
{
#ifdef CM_ABNF_DBG
   "SOTEST NORMALSUBSCRIBER",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 156,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefUserTypeStrEnum,
   NULLP
};

/*********************************************************
proxy -  Enum for "proxy"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefProxyStrEnum =
{
   (Data *)"proxy",
   SO_ACTION_PROXY
};

PUBLIC CmAbnfElmDef soMsgDefProxyStr =
{
#ifdef CM_ABNF_DBG
   "SO PROXYSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 157,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefProxyStrEnum,
   NULLP
};

/********************************************************
kwredirect  -  Enum for "redirect"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRedirectStrEnum =
{
   (Data *)"redirect",
   SO_ACTION_REDIRECT
};

PUBLIC CmAbnfElmDef soMsgDefRedirectStr =
{
#ifdef CM_ABNF_DBG
   "SO REDIRECTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 158,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRedirectStrEnum,
   NULLP
};

/********************************************************
TokenStr -  Enum for Token
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTokenStrEnum =
{
   NULLP,
   SO_PARAMVAL_TOKEN
};

PUBLIC CmAbnfElmDef soMsgDefTokenStr =
{
#ifdef CM_ABNF_DBG
   "SO TOKENSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 159,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTokenStrEnum,
   NULLP
};

/********************************************************
QuotedStrStr   -  Enum for Quoted Str
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefQuotedStrStrEnum =
{
   NULLP,
   SO_PARAMVAL_QUOTEDSTR
};

PUBLIC CmAbnfElmDef soMsgDefQuotedStrStr =
{
#ifdef CM_ABNF_DBG
   "SO QUOTEDSTRSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 160,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefQuotedStrStrEnum,
   NULLP
};

/* so002.102: change for lr parameter */
/********************************************************
LrStr - Enum for Lr Parameter
********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefLrStrEnum =
{
   /* so012.102 : Added typecase for lr below for g++ compilation */
   (Data *)"lr",
   SO_URLPARAMETER_LRPARAM
};

PUBLIC CmAbnfElmDef soMsgDefLrStr =
{
#ifdef CM_ABNF_DBG
   "SO LR STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 161,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefLrStrEnum,
   NULLP
};
  
/********************************************************
OtherParamStr  -  Enum for Other Parameter
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefOtherParamStrEnum =
{
   NULLP,
   SO_URLPARAMETER_OTHERPARAM
};

PUBLIC CmAbnfElmDef soMsgDefOtherParamStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 162,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefOtherParamStrEnum,
   NULLP
};

/********************************************************
q  -  Enum for "q="
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefQStrEnum =
{
   (Data *)"q",
   SO_CONTACTPARAMSTD_Q
};

PUBLIC CmAbnfElmDef soMsgDefQStr =
{
#ifdef CM_ABNF_DBG
   "SO QSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 163,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefQStrEnum,
   NULLP
};

/********************************************************
action   -  Enum for "action"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefActionStrEnum =
{
   (Data *)"action",
   SO_CONTACTPARAMSTD_ACTION
};

PUBLIC CmAbnfElmDef soMsgDefActionStr =
{
#ifdef CM_ABNF_DBG
   "SO ACTIONSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 164,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefActionStrEnum,
   NULLP
};

/********************************************************
expires  -  Meta for "expires"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefExpiresStrEnum =
{
   (Data *)"expires",
   SO_CONTACTPARAMSTD_EXPIRES
};

PUBLIC CmAbnfElmDef soMsgDefExpiresStr =
{
#ifdef CM_ABNF_DBG
   "SO EXPIRESSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 165,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefExpiresStrEnum,
   NULLP
};

/********************************************************
icon  -  Enum for "icon"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefIconStrEnum =
{
   (Data *)"icon",
   SO_CALLINFOPURPOSE_ICON
};

PUBLIC CmAbnfElmDef soMsgDefIconStr =
{
#ifdef CM_ABNF_DBG
   "SO ICONSTR",
   "SORE_ICON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 166,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefIconStrEnum,
   NULLP
};

/********************************************************
info  -  Enum for "info"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefInfoStrEnum =
{
   (Data *)"info",
   SO_CALLINFOPURPOSE_INFO
};

PUBLIC CmAbnfElmDef soMsgDefInfoStr =
{
#ifdef CM_ABNF_DBG
   "SO INFOSTR",
   "SORE_INFO",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 167,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefInfoStrEnum,
   NULLP
};

/********************************************************
card  -  Enum for "card"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefCardStrEnum =
{
   (Data *)"card",
   SO_CALLINFOPURPOSE_CARD
};

PUBLIC CmAbnfElmDef soMsgDefCardStr =
{
#ifdef CM_ABNF_DBG
   "SO CARDSTR",
   "SORE_CARD",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 168,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefCardStrEnum,
   NULLP
};

/********************************************************
Enum for Info parameter Extn
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefInfoParExtnStrEnum =
{
   NULLP,
   SO_INFOPARAM_EXTN
};

PUBLIC CmAbnfElmDef soMsgDefInfoParExtnStr =
{
#ifdef CM_ABNF_DBG
   "SO INFO PAR EXTN STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 169,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefInfoParExtnStrEnum,
   NULLP   
};

/********************************************************
purpose  -  Enum for Info parameter Purpose
*********************************************************/


PUBLIC CmAbnfElmTypeEnum soMsgDefPurposeStrEnum =
{
   (Data *)"purpose",
   SO_INFOPARAM_PURPOSE
};

PUBLIC CmAbnfElmDef soMsgDefPurposeStr =
{
#ifdef CM_ABNF_DBG
   "SO PURPOSESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 170,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefPurposeStrEnum,
   NULLP
};


/********************************************************
PurposeExtStr  -  Enum for Extension Purpose
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefPurposeExtStrEnum =
{
   NULLP,
   SO_CALLINFOPURPOSE_EXTN
};

PUBLIC CmAbnfElmDef soMsgDefPurposeExtStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 171,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefPurposeExtStrEnum,
   NULLP
};

/********************************************************
ContactParamStd   -  Enum for Standard Contact Parameter
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefContactParamStdStrEnum =
{
   NULLP,
   SO_CONTACTPARAM_STD
};

PUBLIC CmAbnfElmDef soMsgDefContactParamStdStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 172,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefContactParamStdStrEnum,
   NULLP
};

/********************************************************
ContactExtensionStr  -  Enum for Extension Contact
Parameter
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefContactExtensionStrEnum =
{  
   NULLP,
   SO_CONTACTPARAM_EXTN
}; 
   
PUBLIC CmAbnfElmDef soMsgDefContactExtensionStr =
{  
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 173,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefContactExtensionStrEnum,
   NULLP
}; 
   
#ifdef SO_CALLERPREF
/********************************************************
ContactParamFeat - Enum for FeatParams Parameter
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefContactFeatParamStrEnum =
{
   NULLP,  
   SO_CONTACTPARAM_FEAT
};

PUBLIC CmAbnfElmDef soMsgDefContactFeatParamStr =
{
#ifdef CM_ABNF_DBG
   "SO CP FEAT PARAM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 174,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefContactFeatParamStrEnum,
   NULLP   
};
#endif

/********************************************************
received -  Enum for "received"
*********************************************************/
PUBLIC CmAbnfElmTypeEnum soMsgDefReceivedStrEnum =
{
   (Data *)"received",
   SO_VIAPARAM_RECEIVED
};

PUBLIC CmAbnfElmDef soMsgDefReceivedStr =
{
#ifdef CM_ABNF_DBG
   "SO RECEIVEDSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 175,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefReceivedStrEnum,
   NULLP
};

#ifdef SO_CALLERPREF
/********************************************************
recurse -  Enum for "recurse"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRecurseStrEnum =
{
   (Data *)"recurse",
   SO_REQUESTDISP_RECURSE_RECURSE      
};

PUBLIC CmAbnfElmDef soMsgDefRecurseStr =
{
#ifdef CM_ABNF_DBG
   "SO RECURSE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 176,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRecurseStrEnum,
   NULLP
};

/********************************************************
no-recurse -  Enum for "no-recurse"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefNoRecurseStrEnum =
{
   (Data *)"no-recurse",
   SO_REQUESTDISP_RECURSE_NORECURSE      
};

PUBLIC CmAbnfElmDef soMsgDefNoRecurseStr =
{
#ifdef CM_ABNF_DBG
   "SO NORECURSE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 177,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefNoRecurseStrEnum,
   NULLP
};

/********************************************************
Parallel -  Enum for "parallel"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefParallelStrEnum =
{
   (Data *)"parallel",
   SO_REQUESTDISP_PARALLEL_PARALLEL
};

PUBLIC CmAbnfElmDef soMsgDefParallelStr =
{
#ifdef CM_ABNF_DBG
   "SO PARALLEL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 178,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefParallelStrEnum,
   NULLP
};

/********************************************************
no-recurse -  Enum for "sequential"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSequentialStrEnum =
{
   (Data *)"sequential",
   SO_REQUESTDISP_PARALLEL_SEQUENTIAL     
};

PUBLIC CmAbnfElmDef soMsgDefSequentialStr =
{
#ifdef CM_ABNF_DBG
   "SO SEQUENTIAL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 179,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSequentialStrEnum,
   NULLP
};

/********************************************************
queue -  Enum for "queue"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefQueueStrEnum =
{
   (Data *)"queue",
   SO_REQUESTDISP_QUEUE_QUEUE
};

PUBLIC CmAbnfElmDef soMsgDefQueueStr =
{
#ifdef CM_ABNF_DBG
   "SO QUEUE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 180,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefQueueStrEnum,
   NULLP
};

/********************************************************
no-queue -  Enum for "no-queue"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefNoQueueStrEnum =
{
   (Data *)"no-queue",
   SO_REQUESTDISP_QUEUE_NOQUEUE
};

PUBLIC CmAbnfElmDef soMsgDefNoQueueStr =
{
#ifdef CM_ABNF_DBG
   "SO NOQUEUE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 181,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefNoQueueStrEnum,
   NULLP
};
#endif /* SO_CALLERPREF */

/********************************************************
branch   -  Enum for "branch"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefBranchStrEnum =
{
   (Data *)"branch",
   SO_VIAPARAM_VIABRANCH
};

PUBLIC CmAbnfElmDef soMsgDefBranchStr =
{
#ifdef CM_ABNF_DBG
   "SO BRANCHSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 182,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefBranchStrEnum,
   NULLP
};

/********************************************************
optional -  Enum for "optional"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefOptionalStrEnum =
{
   (Data *)"optional",
   SO_HANDLINGPARMVALSTD_OPTIONAL
};

PUBLIC CmAbnfElmDef soMsgDefOptionalStr =
{
#ifdef CM_ABNF_DBG
   "SO OPTIONALSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 183,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefOptionalStrEnum,
   NULLP
};

/********************************************************
required -  Enum for "required"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequiredStrEnum =
{
   (Data *)"required",
   SO_HANDLINGPARMVALSTD_REQUIRED
};

PUBLIC CmAbnfElmDef soMsgDefRequiredStr =
{
#ifdef CM_ABNF_DBG
   "SO REQUIREDSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 184,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequiredStrEnum,
   NULLP
};

/********************************************************
gzip  -  Enum for "gzip"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefGzipStrEnum =
{
   (Data *)"gzip",
   SO_CONTENTCODINGCH_GZIP
};

PUBLIC CmAbnfElmDef soMsgDefGzipStr =
{
#ifdef CM_ABNF_DBG
   "SO GZIPSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 185,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefGzipStrEnum,
   NULLP
};

/********************************************************
compress -  Enum for "compress"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefCompressStrEnum =
{
   (Data *)"compress",
   SO_CONTENTCODINGCH_COMPRESS
};

PUBLIC CmAbnfElmDef soMsgDefCompressStr =
{
#ifdef CM_ABNF_DBG
   "SO COMPRESSSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 186,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefCompressStrEnum,
   NULLP
};

/********************************************************
deflate  -  Enum for "deflate"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefDeflateStrEnum =
{
   (Data *)"deflate",
   SO_CONTENTCODINGCH_DEFLATE
};

PUBLIC CmAbnfElmDef soMsgDefDeflateStr =
{
#ifdef CM_ABNF_DBG
   "SO DEFLATESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 187,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefDeflateStrEnum,
   NULLP
};

/********************************************************
identity -  Enum for "identity"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefIdentityStrEnum =
{
   (Data *)"identity",
   SO_CONTENTCODINGCH_IDENTITY
};

PUBLIC CmAbnfElmDef soMsgDefIdentityStr =
{
#ifdef CM_ABNF_DBG
   "SO IDENTITYSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 188,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefIdentityStrEnum,
   NULLP
};

#ifdef SO_ENUM
/********************************************************
TelUrl -  Enum for TEL URL 
*********************************************************/
PUBLIC CmAbnfElmTypeEnum soMsgDefTelUrlStrEnum =
{
   (Data *)"tel", 
   SO_ADDRSPEC_TELURL
};

PUBLIC CmAbnfElmDef soMsgDefTelUrlStr =
{
#ifdef CM_ABNF_DBG
   "SO TEL URL STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 189,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTelUrlStrEnum,
   NULLP
};
#endif /* SO_ENUM */

#ifdef SO_INSTMSG
/********************************************************
Im Url - Enum for IM URL 
*********************************************************/
PUBLIC CmAbnfElmTypeEnum soMsgDefImUrlStrEnum =
{
   (Data *)"im",
   SO_ADDRSPEC_IMURL
};

PUBLIC CmAbnfElmDef soMsgDefImUrlStr =
{
#ifdef CM_ABNF_DBG
   "SO IM URL STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 190,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefImUrlStrEnum,
   NULLP
};
#endif /* SO_INSTMSG */

/********************************************************
SipUrl -  Enum for SIP URL 
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSipUrlStrEnum =
{
   (Data *)"sip",
   SO_ADDRSPEC_SIPURL
};

PUBLIC CmAbnfElmDef soMsgDefSipUrlStr =
{
#ifdef CM_ABNF_DBG
   "SO SIP URL STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 191,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSipUrlStrEnum,
   NULLP
};

#ifdef SO_TLS
/********************************************************
Sips Url -  Enum for SIPS URL 
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSipsUrlStrEnum =
{
   (Data *)"sips",
   SO_ADDRSPEC_SIPSURL
};

PUBLIC CmAbnfElmDef soMsgDefSipsUrlStr =
{
#ifdef CM_ABNF_DBG
   "SO SIPS URL STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 192,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSipsUrlStrEnum,
   NULLP
};
#endif /* SO_TLS */

/********************************************************
AbsoluteUriStr -  Enum for Absolute URI
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefAbsoluteUriStrEnum =
{
   NULLP,
   SO_ADDRSPEC_ABSOLUTEURI
};

PUBLIC CmAbnfElmDef soMsgDefAbsoluteUriStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 193,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefAbsoluteUriStrEnum,
   NULLP
};

#ifdef SO_REFER
/**********************************************************
GenericParamStr   -  Enum for Generic Parameter
***********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefGenericParamStrEnum =
{
   NULLP,
   SO_REPLACES_GENERIC_PARAMS
};

PUBLIC CmAbnfElmDef soMsgDefGenericParamStr =
{
#ifdef CM_ABNF_DBG
   "SOTEST GENERICPARAMSTR",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 194,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefGenericParamStrEnum,
   NULLP
};

#endif
/********************************************************
AddrExtn   -  
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefAddrExtnStrEnum =
{
   NULLP,  
   SO_ADDRPARAM_GENERICPARAM
};

PUBLIC CmAbnfElmDef soMsgDefAddrExtnStr =
{
#ifdef CM_ABNF_DBG
   "SO ADDR EXTNSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 195,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefAddrExtnStrEnum,
   NULLP
};

/********************************************************
tag   -  Enum for "tag="
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTagStrEnum =
{
   (Data *)"tag",
   SO_ADDRPARAM_TAGPARAM
};

PUBLIC CmAbnfElmDef soMsgDefTagStr =
{
#ifdef CM_ABNF_DBG
   "SO TAGSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 196,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTagStrEnum,
   NULLP
};

/********************************************************
SIP   -  Enum for "SIP"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSIPStrEnum =
{
   (Data *)"SIP",
   SO_PROTOCOLNAME_SIP
};

PUBLIC CmAbnfElmDef soMsgDefSIPStr =
{
#ifdef CM_ABNF_DBG
   "SO SIPSTR",
   "SORE_SIP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 197,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSIPStrEnum,
   soRegExpSIP
};

/********************************************************
ViaExtensionStr   -  Enum for Via Extension
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefViaExtensionStrEnum =
{
   NULLP,
   SO_VIAPARAM_GENERICPARAM
};

PUBLIC CmAbnfElmDef soMsgDefViaExtensionStr =
{
#ifdef CM_ABNF_DBG
   "SO VIAEXTENSIONSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 198,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefViaExtensionStrEnum,
   NULLP
};

/********************************************************
handling -  Enum for "handling"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHandlingStrEnum =
{
   (Data *)"handling",
   SO_DISP_PARAM_HANDLING
};

PUBLIC CmAbnfElmDef soMsgDefHandlingStr =
{
#ifdef CM_ABNF_DBG
   "SO HANDLINGSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 199,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHandlingStrEnum,
   NULLP
};

/********************************************************
HandlingParmValstd   -  Enum for Standard Handling
Parameter
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHandlingParmValstdStrEnum =
{
   NULLP,
   SO_DISP_PARAM_HANDLING_STD
};

PUBLIC CmAbnfElmDef soMsgDefHandlingParmValstdStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 200,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHandlingParmValstdStrEnum,
   NULLP
};

/********************************************************
OtherHandling  -  Enum  for Other Handling
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefOtherHandlingStrEnum =
{
   NULLP,
   SO_DISP_PARAM_HANDLING_NONSTD
};

PUBLIC CmAbnfElmDef soMsgDefOtherHandlingStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 201,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefOtherHandlingStrEnum,
   NULLP
};

/********************************************************
Duration -  Enum for Duration
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRetryParExtnStrEnum =
{
   NULLP,
   SO_RETRYPARAM_EXTN
};

PUBLIC CmAbnfElmDef soMsgDefRetryParamExtnStr =
{
#ifdef CM_ABNF_DBG
   "SO RETRY PAR EXTN STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 202,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRetryParExtnStrEnum,
   NULLP
};


/********************************************************
Duration -  Enum for Duration
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefDurationStrEnum =
{
   (Data *)"duration",
   SO_RETRYPARAM_DURATION
};

PUBLIC CmAbnfElmDef soMsgDefDurationStr =
{
#ifdef CM_ABNF_DBG
   "SO DURATIONSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 203,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefDurationStrEnum,
   NULLP
};


/********************************************************
AllStarStr  -  Enum for "*//*"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefAllStarStrEnum =
{
   NULLP,
   SO_MEDIARANGEVAL_ALLSTAR
};

PUBLIC CmAbnfElmDef soMsgDefAllStarStr =
{
#ifdef CM_ABNF_DBG
   "SO ALLSTARSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 204,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefAllStarStrEnum,
   NULLP
};


/********************************************************
TypeStarStr -  Enum for Type/Star
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTypeStarStrEnum =
{
   NULLP,
   SO_MEDIARANGEVAL_TYPESTAR
};

PUBLIC CmAbnfElmDef soMsgDefTypeStarStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 205,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTypeStarStrEnum,
   NULLP
};


/********************************************************
TypeSubStr  -  Enum for Type/Sub
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTypeSubStrEnum =
{
   NULLP,
   SO_MEDIARANGEVAL_TYPESUB
};

PUBLIC CmAbnfElmDef soMsgDefTypeSubStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 206,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTypeSubStrEnum,
   NULLP
};

/**********************************************************
ContentCodingCh   -  Enum for Content Coding
**********************************************************/
PUBLIC CmAbnfElmTypeEnum soMsgDefContentCodingChStrEnum =
{
   NULLP,
   SO_CONTENTCODING_CONTENTCODINGCH
};

PUBLIC CmAbnfElmDef soMsgDefContentCodingChStr =
{
#ifdef CM_ABNF_DBG
   "SOTEST CONTENTCODINGCHSTR",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 207,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefContentCodingChStrEnum,
   NULLP
};


/********************************************************
ExtensionTokenStr -  Enum for Extension Token
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefExtensionTokenStrEnum =
{
   NULLP,
   SO_CONTENTCODING_EXTENSION
};

PUBLIC CmAbnfElmDef soMsgDefExtensionTokenStr =
{
#ifdef CM_ABNF_DBG
   "SOTEST EXTENSIONTOKENSTR",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 208,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefExtensionTokenStrEnum,
   NULLP
};

/********************************************************
NameAddrStr -  Enum for Name Address
********************************************************/
PUBLIC CmAbnfElmTypeEnum soMsgDefNameAddrStrEnum =
{
   NULLP,
   SO_ADDRCH_NAMEADDR
};

PUBLIC CmAbnfElmDef soMsgDefNameAddrStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 209,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefNameAddrStrEnum,
   NULLP
};

/*************************************************************
AddrSpec RequestURI Str -  Enum for Address Spec / Request URI
**************************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefAddrSpecStrEnum =
{
   NULLP,
   SO_ADDRCH_ADDRSPEC
};

PUBLIC CmAbnfElmDef soMsgDefAddrSpecStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 210,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefAddrSpecStrEnum,
   NULLP
};

/********************************************************
ProtocolExtStr -  Enum for Extension Protocol
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefProtocolExtStrEnum =
{
   NULLP,
   SO_PROTOCOLNAME_PROTOCOLEXT
};

PUBLIC CmAbnfElmDef soMsgDefProtocolExtStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 211,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefProtocolExtStrEnum,
   NULLP
};

/********************************************************
TransportStdStr   -  Enum for Standard Transport
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTransportStdStrEnum =
{
   NULLP,
   SO_TRANSPORT_TRANSPORTSTD
};

PUBLIC CmAbnfElmDef soMsgDefTransportStdStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 212,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTransportStdStrEnum,
   NULLP
};


/********************************************************
TransportExtStr   -  Enum for Extension Transport
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTransportExtStrEnum =
{
   NULLP,
   SO_TRANSPORT_TRANSPORTEXT
};

PUBLIC CmAbnfElmDef soMsgDefTransportExtStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 213,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTransportExtStrEnum,
   NULLP
};

/********************************************************
ContentCodingStr  -  Enum for Content Coding
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefContentCodingStrEnum =
{
   NULLP,
   SO_CODINGS_CONTENTCODING
};

PUBLIC CmAbnfElmDef soMsgDefContentCodingStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 214,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefContentCodingStrEnum,
   NULLP
};

/********************************************************
SentByHostPortStr -  Enum for SentBy Host/Port
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSentByHostPortStrEnum =
{
   NULLP,
   SO_SENTBY_HOSTPORT
};

PUBLIC CmAbnfElmDef soMsgDefSentByHostPortStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 215,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSentByHostPortStrEnum,
   NULLP
};

/**********************************************************
ConcealedHost  -  Enum for Concealed Host
***********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefConcealedHostStrEnum =
{
   NULLP,
   SO_SENTBY_CONCEALEDHOST
};

PUBLIC CmAbnfElmDef soMsgDefConcealedHostStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 216,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefConcealedHostStrEnum,
   NULLP
};

/********************************************************
ParameterStr   -  Enum for Parameter
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefDispTypeExtnStrEnum =
{
   NULLP,
   SO_DISP_PARAM_EXTN
};

PUBLIC CmAbnfElmDef soMsgDefDispTypeExtnStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 217,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefDispTypeExtnStrEnum,
   NULLP
};

/********************************************************
CallIdStr   -  Enum for "Call-ID"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefCallIdStrEnum =
{
   (Data *)"Call-ID",
   SO_HEADER_GEN_CALLID
};

PUBLIC CmAbnfElmDef soMsgDefCallIdStr =
{
#ifdef CM_ABNF_DBG
   "SO CALLIDSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 218,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefCallIdStrEnum,
   NULLP
};

/********************************************************
CallIdI  -  Enum for "i"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefCallIdIStrEnum =
{
   (Data *)"i",
   SO_HEADER_GEN_CALLIDI
};

PUBLIC CmAbnfElmDef soMsgDefCallIdIStr =
{
#ifdef CM_ABNF_DBG
   "SO ISTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 219,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefCallIdIStrEnum,
   NULLP
};

/********************************************************
ContactStr  -  Enum for "Contact"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderContactStrEnum =
{
   (Data *)"Contact",
   SO_HEADER_GEN_CONTACT
};

PUBLIC CmAbnfElmDef soMsgDefHeaderContactStr =
{
#ifdef CM_ABNF_DBG
   "SO CONTACTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 220,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderContactStrEnum,
   NULLP
};

/********************************************************
HeaderContactmStr -  Enum for "m"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderContactmStrEnum =
{
   (Data *)"m",
   SO_HEADER_GEN_CONTACTM
};

PUBLIC CmAbnfElmDef soMsgDefHeaderContactmStr =
{
#ifdef CM_ABNF_DBG
   "SO MSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 221,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderContactmStrEnum,
   NULLP
};

/********************************************************
HeaderFromF -  Enum for "f"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderFromFStrEnum =
{
   (Data *)"f",
   SO_HEADER_GEN_FROMF
};

PUBLIC CmAbnfElmDef soMsgDefHeaderFromFStr =
{
#ifdef CM_ABNF_DBG
   "SO FROMFSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 222,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderFromFStrEnum,
   NULLP
};

/********************************************************
HeaderSupportedKStr  -  Enum for "k"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderSupportedKStrEnum =
{
   (Data *)"k",
   SO_HEADER_GEN_SUPPORTEDK
};

PUBLIC CmAbnfElmDef soMsgDefHeaderSupportedKStr =
{
#ifdef CM_ABNF_DBG
   "SO HEADERSUPPORTEDKSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 223,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderSupportedKStrEnum,
   NULLP
};

/********************************************************
To -  Enum for "To" header
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderToStrEnum =
{
   (Data *)"To",
   SO_HEADER_GEN_TO
};

PUBLIC CmAbnfElmDef soMsgDefHeaderToStr =
{
#ifdef CM_ABNF_DBG
   "SO TOSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 224,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderToStrEnum,
   NULLP
};

/********************************************************
TotStr   -  Enum for "t"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderToTStrEnum =
{
   (Data *)"t",
   SO_HEADER_GEN_TOT
};

PUBLIC CmAbnfElmDef soMsgDefHeaderToTStr =
{
#ifdef CM_ABNF_DBG
   "SO TSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 225,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderToTStrEnum,
   NULLP
};


/********************************************************
ProductStr  -  Enum  for Product
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefProductStrEnum =
{
   NULLP,
   SO_PRODCOM_PRODUCT
};

PUBLIC CmAbnfElmDef soMsgDefProductStr =
{
#ifdef CM_ABNF_DBG
   "SO PRODUCTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 226,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefProductStrEnum,
   NULLP
};

/********************************************************
CommentStr  -  Enum for Comment
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefCommentStrEnum =
{
   NULLP,
   SO_PRODCOM_COMMENT
};

PUBLIC CmAbnfElmDef soMsgDefCommentStr =
{
#ifdef CM_ABNF_DBG
   "SO COMMENTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 227,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefCommentStrEnum,
   NULLP
};

/********************************************************
ViaStr   -  Enum for "Via"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderViaStrEnum =
{
   (Data *)"Via",
   SO_HEADER_GEN_VIA
};

PUBLIC CmAbnfElmDef soMsgDefHeaderViaStr =
{
#ifdef CM_ABNF_DBG
   "SO VIASTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 228,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderViaStrEnum,
   NULLP
};

/********************************************************
ViaVStr  -  Enum for "v"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderViaVStrEnum =
{
   (Data *)"v",
   SO_HEADER_GEN_VIAV
};

PUBLIC CmAbnfElmDef soMsgDefHeaderViaVStr =
{
#ifdef CM_ABNF_DBG
   "SO ViaVSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 229,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderViaVStrEnum,
   NULLP
};

/********************************************************
EmergencyStr   -  Enum for "emergency"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefEmergencyStrEnum =
{
   (Data *)"emergency",
   SO_PRIORITY_EMERGENCY
};

PUBLIC CmAbnfElmDef soMsgDefEmergencyStr =
{
#ifdef CM_ABNF_DBG
   "SO EMERGENCYSTR",
   "SORE_EMERGENCY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 230,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefEmergencyStrEnum,
   NULLP
};

/********************************************************
Urgent   -  Enum for "urgent"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefUrgentStrEnum =
{
   (Data *)"urgent",
   SO_PRIORITY_URGENT
};

PUBLIC CmAbnfElmDef soMsgDefUrgentStr =
{
#ifdef CM_ABNF_DBG
   "SO URGENTSTR",
   "SORE_URGENT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 231,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefUrgentStrEnum,
   NULLP
};

/********************************************************
NormalStr   -  Enum for "normal"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefNormalStrEnum =
{
   (Data *)"normal",
   SO_PRIORITY_NORMAL
};

PUBLIC CmAbnfElmDef soMsgDefNormalStr =
{
#ifdef CM_ABNF_DBG
   "SO NORMALSTR",
   "SORE_NORMAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 232,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefNormalStrEnum,
   NULLP
};

/********************************************************
NonurgentStr   -  Enum for "non-urgent"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefNonurgentStrEnum =
{
   (Data *)"non-urgent",
   SO_PRIORITY_NONURGENT
};

PUBLIC CmAbnfElmDef soMsgDefNonurgentStr =
{
#ifdef CM_ABNF_DBG
   "SO NONURGENTSTR",
   "SORE_NONURGENT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 233,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefNonurgentStrEnum,
   NULLP
};

/********************************************************
SubjectSStr -  Enum for "s"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestSubjectSStrEnum =
{
   (Data *)"s",
   SO_HEADER_GEN_SUBJECTS
};

PUBLIC CmAbnfElmDef soMsgDefRequestSubjectSStr =
{
#ifdef CM_ABNF_DBG
   "SO SubjectSSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 234,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestSubjectSStrEnum,
   NULLP
};

/********************************************************
RequestContentEncodingEStr -  Enum for "e"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestContentEncodingEStrEnum =
{
   (Data *)"e",
   SO_HEADER_ENT_CONTENTENCODINGE
};

PUBLIC CmAbnfElmDef soMsgDefRequestContentEncodingEStr =
{
#ifdef CM_ABNF_DBG
   "SO RequestContentEncodingESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 235,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestContentEncodingEStrEnum,
   NULLP
};

/********************************************************
RequestContentLengthStr  -  Enum for "Content-Length"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestContentLengthStrEnum =
{
   (Data *)"Content-Length",
   SO_HEADER_ENT_CONTENTLENGTH
};

PUBLIC CmAbnfElmDef soMsgDefRequestContentLengthStr =
{
#ifdef CM_ABNF_DBG
   "SO CONTENTLENGTHSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 236,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestContentLengthStrEnum,
   NULLP
};


/********************************************************
RequestContentLengthLStr   -  Enum for "l"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestContentLengthLStrEnum =
{
   (Data *)"l",
   SO_HEADER_ENT_CONTENTLENGTHL
};

PUBLIC CmAbnfElmDef soMsgDefRequestContentLengthLStr =
{
#ifdef CM_ABNF_DBG
   "SO LSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 237,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestContentLengthLStrEnum,
   NULLP
};

/********************************************************
RequestContentTypeStr   -  Enum for "Content-Type"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestContentTypeStrEnum =
{
   (Data *)"Content-Type",
   SO_HEADER_ENT_CONTENTTYPE
};

PUBLIC CmAbnfElmDef soMsgDefRequestContentTypeStr =
{
#ifdef CM_ABNF_DBG
   "SO CONTENTTYPESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 238,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestContentTypeStrEnum,
   NULLP
};

/********************************************************
RequestContentTypeCStr  -  Enum for "c"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestContentTypeCStrEnum =
{
   (Data *)"c",
   SO_HEADER_ENT_CONTENTTYPEC
};

PUBLIC CmAbnfElmDef soMsgDefRequestContentTypeCStr =
{
#ifdef CM_ABNF_DBG
   "SO CSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 239,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestContentTypeCStrEnum,
   NULLP
};

/********************************************************
AcceptStr   -  Enum for "Accept"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefAcceptStrEnum =
{
   (Data *)"Accept",
   SO_HEADER_GEN_ACCEPT
};

PUBLIC CmAbnfElmDef soMsgDefAcceptStr =
{
#ifdef CM_ABNF_DBG
   "SO ACCEPTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 240,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefAcceptStrEnum,
   NULLP
};

/********************************************************
CallInfoStr -  Enum for "Call-Info"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefCallInfoStrEnum =
{
   (Data *)"Call-Info",
   SO_HEADER_GEN_CALLINFO
};

PUBLIC CmAbnfElmDef soMsgDefCallInfoStr =
{
#ifdef CM_ABNF_DBG
   "SO CALLINFOSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 241,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefCallInfoStrEnum,
   NULLP
};

/********************************************************
ErrorInfoStr   -  Enum for "Error-Info"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefErrorInfoStrEnum =
{
   (Data *)"Error-Info",
   SO_HEADER_RSP_ERRORINFO
};

PUBLIC CmAbnfElmDef soMsgDefErrorInfoStr =
{
#ifdef CM_ABNF_DBG
   "SO ERRORINFOSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 242,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefErrorInfoStrEnum,
   NULLP
};


/********************************************************
CDMetaStarStr  -  Enum for "*"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefCDMetaStarStrEnum =
{
   NULLP,
   SO_CONTACTDESC_METASTAR
};

PUBLIC CmAbnfElmDef soMsgDefCDMetaStarStr =
{
#ifdef CM_ABNF_DBG
   "SO CDMETASTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 243,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefCDMetaStarStrEnum,
   NULLP
};


/********************************************************
ContactItemsStr   -  Enum for Contact Items
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefContactItemsStrEnum =
{
   NULLP,
   SO_CONTACTDESC_CONTACTITEMS
};

PUBLIC CmAbnfElmDef soMsgDefContactItemsStr =
{
#ifdef CM_ABNF_DBG
   "SO CONTACTITEMSSTR",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 244,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefContactItemsStrEnum,
   NULLP
};

/********************************************************
DateStr  -  Enum for "Date"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefDateStrEnum =
{
   (Data *)"Date",
   SO_HEADER_GEN_DATE
};

PUBLIC CmAbnfElmDef soMsgDefDateStr =
{
#ifdef CM_ABNF_DBG
   "SO DATESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 245,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefDateStrEnum,
   NULLP
};

/********************************************************
AlsoStr  -  Enum for "Also"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefAlsoStrEnum =
{
   (Data *)"Also",
   SO_HEADER_REQ_ALSO
};

PUBLIC CmAbnfElmDef soMsgDefAlsoStr =
{
#ifdef CM_ABNF_DBG
   "SO ALSOSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 246,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefAlsoStrEnum,
   NULLP
};

/********************************************************
MIMEversionStr -  Enum for "MIME-version"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefMIMEversionStrEnum =
{
   (Data *)"MIME-version",
   SO_HEADER_ENT_MIMEVERSION
};

PUBLIC CmAbnfElmDef soMsgDefMIMEversionStr =
{
#ifdef CM_ABNF_DBG
   "SO MIMEVERSIONSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 247,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefMIMEversionStrEnum,
   NULLP
};

/********************************************************
RecordRouteStr -  Enum for "RecordRoute"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRecordRouteStrEnum =
{
   (Data *)"Record-Route",   
   SO_HEADER_GEN_RECORDROUTE
};

PUBLIC CmAbnfElmDef soMsgDefRecordRouteStr =
{
#ifdef CM_ABNF_DBG
   "SO RECORDROUTESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 248,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRecordRouteStrEnum,
   NULLP
};

/********************************************************
UserAgentStr   -  Enum for "User-Agent"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefUserAgentStrEnum =
{
   (Data *)"User-Agent",
   SO_HEADER_GEN_USERAGENT
};

PUBLIC CmAbnfElmDef soMsgDefUserAgentStr =
{
#ifdef CM_ABNF_DBG
   "SO USERAGENTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 249,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefUserAgentStrEnum,
   NULLP
};

/********************************************************
MaxForwardsStr -  Enum for "Max-Forwards"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefMaxForwardsStrEnum =
{
   (Data *)"Max-Forwards",
   SO_HEADER_REQ_MAXFORWARDS
};

PUBLIC CmAbnfElmDef soMsgDefMaxForwardsStr =
{
#ifdef CM_ABNF_DBG
   "SO MAXFORWARDSSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 250,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefMaxForwardsStrEnum,
   NULLP
};

/********************************************************
PriorityStr -  Enum for "Priority:"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefPriorityStrEnum =
{
   (Data *)"Priority",
   SO_HEADER_REQ_PRIORITY
};

PUBLIC CmAbnfElmDef soMsgDefPriorityStr =
{
#ifdef CM_ABNF_DBG
   "SO PRIORITYSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 251,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefPriorityStrEnum,
   NULLP
};

/********************************************************
OtherPriorityStr  -  Enum for Other Priority
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefOtherPriorityStrEnum =
{
   NULLP,
   SO_PRIORITY_OTHERPRIORITY
};

PUBLIC CmAbnfElmDef soMsgDefOtherPriorityStr =
{
#ifdef CM_ABNF_DBG
   "SO OTHERPRIORITYSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 252,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefOtherPriorityStrEnum,
   NULLP
};

/********************************************************
RouteStr -  Enum for "Route"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRouteStrEnum =
{
   (Data *)"Route",
   SO_HEADER_REQ_ROUTE
};

PUBLIC CmAbnfElmDef soMsgDefRouteStr =
{
#ifdef CM_ABNF_DBG
   "SO ROUTESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 253,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRouteStrEnum,
   NULLP
};


/********************************************************
ResponseKeyStr -  Enum for "ResponseKey"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefResponseKeyStrEnum =
{
   (Data *)"Response-Key",
   SO_HEADER_REQ_RESPONSEKEY
};

PUBLIC CmAbnfElmDef soMsgDefResponseKeyStr =
{
#ifdef CM_ABNF_DBG
   "SO RESPONSEKEYSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 254,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefResponseKeyStrEnum,
   NULLP
};

/********************************************************
RequestExtensionStr  -  Enum for Extension Request
*********************************************************/
PUBLIC CmAbnfElmTypeEnum soMsgDefRequestExtensionStrEnum =
{
   NULLP,
   SO_HEADER_GEN_EXTENSION
};

PUBLIC CmAbnfElmDef soMsgDefRequestExtensionStr =
{
#ifdef CM_ABNF_DBG
   "SO REQUESTEXTENSION",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 255,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestExtensionStrEnum,
   NULLP
};

/********************************************************
ServerStr   -  Enum for "Server"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefServerStrEnum =
{
   (Data *)"Server",
   SO_HEADER_RSP_SERVER
};

PUBLIC CmAbnfElmDef soMsgDefServerStr =
{
#ifdef CM_ABNF_DBG
   "SO SERVERSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 256,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefServerStrEnum,
   NULLP
};

/********************************************************
UnsupportedStr -  Enum for "Unsupported"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefUnsupportedStrEnum =
{
   (Data *)"Unsupported",
   SO_HEADER_RSP_UNSUPPORTED
};

PUBLIC CmAbnfElmDef soMsgDefUnsupportedStr =
{
#ifdef CM_ABNF_DBG
   "SO UNSUPPORTEDSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 257,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefUnsupportedStrEnum,
   NULLP
};

/********************************************************
WarningStr  -  Enum for "Warning"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefWarningStrEnum =
{
   (Data *)"Warning",
   SO_HEADER_GEN_WARNING
};

PUBLIC CmAbnfElmDef soMsgDefWarningStr =
{
#ifdef CM_ABNF_DBG
   "SO WARNINGSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 258,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefWarningStrEnum,
   NULLP
};

/********************************************************
WWWAuthenticateStr   -  Enum for "WWW-Authenticate"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefWWWAuthenticateStrEnum =
{
   (Data *)"WWW-Authenticate",
   SO_HEADER_GEN_WWWAUTHENTICATE
};

PUBLIC CmAbnfElmDef soMsgDefWWWAuthenticateStr =
{
#ifdef CM_ABNF_DBG
   "SO WWWAUTHENTICATESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 259,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefWWWAuthenticateStrEnum,
   NULLP
};

#ifdef SO_EVENT
/********************************************************
EventStr   -  Enum for "Event"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefEventStrEnum =
{
   (Data *)"Event",
   SO_HEADER_REQ_EVENT
};

PUBLIC CmAbnfElmDef soMsgDefEventStr =
{
#ifdef CM_ABNF_DBG
   "SO EVENTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 260,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefEventStrEnum,
   NULLP
};

/********************************************************
EventStr   -  Enum for "Event"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefEventOStrEnum =
{
   (Data *)"o",
   SO_HEADER_REQ_EVENTO
};

PUBLIC CmAbnfElmDef soMsgDefEventOStr =
{
#ifdef CM_ABNF_DBG
   "SO EVENTOSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 261,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefEventOStrEnum,
   NULLP
};


/********************************************************
AllowEventsStr   -  Enum for "Allow-Events"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefAllowEventsStrEnum =
{
   (Data *)"Allow-Events",
   SO_HEADER_GEN_ALLOW_EVENTS
};

PUBLIC CmAbnfElmDef soMsgDefAllowEventsStr =
{
#ifdef CM_ABNF_DBG
   "SO ALLOWEVENTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 262,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefAllowEventsStrEnum,
   NULLP
};

/********************************************************
AllowEventsUStr   -  Enum for "Allow-Events"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefAllowEventsUStrEnum =
{
   (Data *)"u",
   SO_HEADER_GEN_ALLOW_EVENTSU
};

PUBLIC CmAbnfElmDef soMsgDefAllowEventsUStr =
{
#ifdef CM_ABNF_DBG
   "SO ALLOWEVENTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 263,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefAllowEventsUStrEnum,
   NULLP
};

#endif /* SO_EVENT */

/********************************************************
Refer-To -  Enum for "Refer-To"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefReferToStrEnum =
{
   (Data *)"Refer-To",
   SO_HEADER_REQ_REFERTO
};

PUBLIC CmAbnfElmDef soMsgDefReferToStr =
{
#ifdef CM_ABNF_DBG
   "SO REFERTO",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 264,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefReferToStrEnum,
   NULLP
};

/********************************************************
Referred-By -  Enum for "Referred-By"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefReferredByStrEnum =
{
   (Data *)"Referred-By",
   SO_HEADER_REQ_REFERBY
};

PUBLIC CmAbnfElmDef soMsgDefReferredByStr =
{
#ifdef CM_ABNF_DBG
   "SO REFERREDBY",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 265,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefReferredByStrEnum,
   NULLP
};

/********************************************************
ReferTo -  Enum for "Refer-To" short form "r"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefReferToRStrEnum =
{
   (Data *)"r",
   SO_HEADER_REQ_REFERTOR
};

PUBLIC CmAbnfElmDef soMsgDefReferToRStr =
{
#ifdef CM_ABNF_DBG
   "SO REFERTO",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 266,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefReferToRStrEnum,
   NULLP
};

/********************************************************
Referred-By -  Enum for "Referred-By" short form "b"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefReferredByBStrEnum =
{
   (Data *)"b",
   SO_HEADER_REQ_REFERBYB
};

PUBLIC CmAbnfElmDef soMsgDefReferredByBStr =
{
#ifdef CM_ABNF_DBG
   "SO REFERREDBYB",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 267,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefReferredByBStrEnum,
   NULLP
};

/********************************************************
Replaces Enum for "Replaces" 
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefReplacesStrEnum =
{
   (Data *)"Replaces",
   SO_HEADER_REQ_REPLACES
};

PUBLIC CmAbnfElmDef soMsgDefReplacesStr =
{
#ifdef CM_ABNF_DBG
   "SO REPLACES",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 268,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefReplacesStrEnum,
   NULLP
};

#ifdef SO_SESSTIMER 
/********************************************************
Session-Expires Enum for "Session-Expires"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSessionExpiresStrEnum =
{
   (Data *)"Session-Expires",
   SO_HEADER_GEN_SESSION_EXPIRES
};

PUBLIC CmAbnfElmDef soMsgDefSessionExpiresStr =
{
#ifdef CM_ABNF_DBG
   "SO SESSIONEXPIRES",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 269,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSessionExpiresStrEnum,
   NULLP
};

/********************************************************
Session-Expires short form Enum for "x"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSessionExpiresXStrEnum =
{
   (Data *)"x",
   SO_HEADER_GEN_SESSION_EXPIRESX
};

PUBLIC CmAbnfElmDef soMsgDefSessionExpiresXStr =
{
#ifdef CM_ABNF_DBG
   "SO SESSIONEXPIRES",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 270,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSessionExpiresXStrEnum,
   NULLP
};

/********************************************************
Min-SE Enum for "Min-SE"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefMinSEStrEnum =
{
   (Data *)"Min-SE",
   SO_HEADER_GEN_MINSE
};

PUBLIC CmAbnfElmDef soMsgDefMinSEStr =
{
#ifdef CM_ABNF_DBG
   "SO MINSE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 271,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefMinSEStrEnum,
   NULLP
};
#endif /* SO_SESSTIMER */

#ifdef SO_CALLERPREF
/********************************************************
RequestDispositionStr   -  Enum for "Request-Disposition"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestDispositionStrEnum =
{
   (Data *)"Request-Disposition",
   SO_HEADER_REQ_REQUESTDISPOSITION
};

PUBLIC CmAbnfElmDef soMsgDefRequestDispositionStr =
{
#ifdef CM_ABNF_DBG
   "SO REQUESTDISPOSITIONTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 272,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestDispositionStrEnum,
   NULLP
};

/********************************************************
RequestDispositionDStr   -  Enum for "d"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestDispositionDStrEnum =
{
   (Data *)"d",
   SO_HEADER_REQ_REQUESTDISPOSITIOND
};

PUBLIC CmAbnfElmDef soMsgDefRequestDispositionDStr =
{
#ifdef CM_ABNF_DBG
   "SO REQUESTDISPSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 273,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestDispositionDStrEnum,
   NULLP
};

/********************************************************
AcceptContactStr   -  Enum for "Accept-Contact"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefAcceptContactStrEnum =
{
   (Data *)"Accept-Contact",
   SO_HEADER_REQ_ACCEPT_CONTACT 
};

PUBLIC CmAbnfElmDef soMsgDefAcceptContactStr =
{
#ifdef CM_ABNF_DBG
   "SO ACCEPTCONTCACTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 274,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefAcceptContactStrEnum,
   NULLP
};

/********************************************************
AcceptContactAStr   -  Enum for "a"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefAcceptContactAStrEnum =
{
   (Data *)"a",
   SO_HEADER_REQ_ACCEPT_CONTACTA
};

PUBLIC CmAbnfElmDef soMsgDefAcceptContactAStr =
{
#ifdef CM_ABNF_DBG
   "SO ACCEPTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 275,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefAcceptContactAStrEnum,
   NULLP
};

/********************************************************
RejectContactStr   -  Enum for "Reject-Contact"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRejectContactStrEnum =
{
   (Data *)"Reject-Contact",
   SO_HEADER_REQ_REJECT_CONTACT 
};

PUBLIC CmAbnfElmDef soMsgDefRejectContactStr =
{
#ifdef CM_ABNF_DBG
   "SO REJECTCONTCACTSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 276,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRejectContactStrEnum,
   NULLP
};

/********************************************************
RejectContactJStr - Enum for "j"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRejectContactJStrEnum =
{
   (Data *)"j",
   SO_HEADER_REQ_REJECT_CONTACTJ
};

PUBLIC CmAbnfElmDef soMsgDefRejectContactJStr =
{
#ifdef CM_ABNF_DBG
   "SO REJECTJSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 277,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRejectContactJStrEnum,
   NULLP
};
#endif /* SO_CALLERPREF */


/* BEGIN: Three new headers support */

/********************************************************
_AnonymityStr - Enum for "Anonymity"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDef_AnonymityStrEnum =
{
   (Data *)"Anonymity",
   SO_HEADER_ANONMY
};

PUBLIC CmAbnfElmDef soMsgDef_AnonymityStr =
{
#ifdef CM_ABNF_DBG
   "SO ANONYMITYSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 278,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDef_AnonymityStrEnum,
   NULLP
};


/********************************************************
_RPID_PrivacyStr - Enum for "RPID-Privacy"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDef_RPID_PrivacyStrEnum =
{
   (Data *)"RPID-Privacy",
   SO_HEADER_RPID_PRIV
};

PUBLIC CmAbnfElmDef soMsgDef_RPID_PrivacyStr =
{
#ifdef CM_ABNF_DBG
   "SO RPID-Privacy",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 279,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDef_RPID_PrivacyStrEnum,
   NULLP
};


/********************************************************
_Remote_Party_IDStr - Enum for "Remote-Party-ID"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDef_Remote_Party_IDStrEnum =
{
   (Data *)"Remote-Party-ID",
   SO_HEADER_REM_PARTY_ID
};

PUBLIC CmAbnfElmDef soMsgDef_Remote_Party_IDStr =
{
#ifdef CM_ABNF_DBG
   "SO Remote-Party-Id",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 280,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDef_Remote_Party_IDStrEnum,
   NULLP
};

/********************************************************
Subscription-State - Enum for "Subscription-State"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSubscStateStrEnum =
{
   (Data *)"Subscription-State",
   SO_HEADER_SUBSC_STATE
};

PUBLIC CmAbnfElmDef soMsgDefSubscStateStr =
{
#ifdef CM_ABNF_DBG
    "SO SUBSC STATE ENUM" ,
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 281,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSubscStateStrEnum,
   NULLP
};

/* END: Three new headers support */



/********************************************************
RSeqStr  -  Enum for "RSeq"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRSeqStrEnum =
{
   (Data *)"RSeq",
   SO_HEADER_GEN_RSEQ
};

PUBLIC CmAbnfElmDef soMsgDefRSeqStr =
{
#ifdef CM_ABNF_DBG
   "SO RSEQSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 282,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRSeqStrEnum,
   NULLP
};

/********************************************************
HeaderAcceptLanguageStr -  Enum for "Accept-Language"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderAcceptLanguageStrEnum =
{
   (Data *)"Accept-Language",
   SO_HEADER_GEN_ACCEPTLANGUAGE
};

PUBLIC CmAbnfElmDef soMsgDefHeaderAcceptLanguageStr =
{
#ifdef CM_ABNF_DBG
   "SO AcceptLanguageSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 283,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderAcceptLanguageStrEnum,
   NULLP
};


/********************************************************
HeaderCSeqStr  -  Enum for "CSeq"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderCSeqStrEnum =
{
   (Data *)"CSeq",
   SO_HEADER_GEN_CSEQ
};

PUBLIC CmAbnfElmDef soMsgDefHeaderCSeqStr =
{
#ifdef CM_ABNF_DBG
   "SO HeaderCSeqSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 284,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderCSeqStrEnum,
   NULLP
};

/********************************************************
HeaderFromStr  -  Enum for "From"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderFromStrEnum =
{
   (Data *)"From",
   SO_HEADER_GEN_FROM
};

PUBLIC CmAbnfElmDef soMsgDefHeaderFromStr =
{
#ifdef CM_ABNF_DBG
   "SO HeaderFROMStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 285,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderFromStrEnum,
   NULLP
};

/********************************************************
EncryptionStr  -  Enum for "Encryption"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefEncryptionStrEnum =
{
   (Data *)"Encryption",
   SO_HEADER_GEN_ENCRYPTION
};

PUBLIC CmAbnfElmDef soMsgDefEncryptionStr =
{
#ifdef CM_ABNF_DBG
   "SO ENCRYPTIONSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 286,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefEncryptionStrEnum,
   NULLP
};

/********************************************************
HeaderRequireStr  -  Enum for "Require"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderRequireStrEnum =
{
   (Data *)"Require",
   SO_HEADER_GEN_REQUIRE
};

PUBLIC CmAbnfElmDef soMsgDefHeaderRequireStr =
{
#ifdef CM_ABNF_DBG
   "SO REQUIRESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 287,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderRequireStrEnum,
   NULLP
};


/********************************************************
HeaderSupportedStr   -  Enum for "Supported"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderSupportedStrEnum =
{
   (Data *)"Supported",
   SO_HEADER_GEN_SUPPORTED
};

PUBLIC CmAbnfElmDef soMsgDefHeaderSupportedStr =
{
#ifdef CM_ABNF_DBG
   "SO HEADERSUPPORTEDSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 288,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderSupportedStrEnum,
   NULLP
};

/********************************************************
HeaderTimestampStr   -  Enum for "Timestamp"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderTimestampStrEnum =
{
   (Data *)"Timestamp",
   SO_HEADER_GEN_TIMESTAMP
};

PUBLIC CmAbnfElmDef soMsgDefHeaderTimestampStr =
{
#ifdef CM_ABNF_DBG
   "SO TIMESTAMPSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 289,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderTimestampStrEnum,
   NULLP
};

#ifdef SO_CALLERPREF
/********************************************************
proxy-feature -  Enum for "proxy-feature"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefProxyFeatureStrEnum =
{
   NULLP,
   SO_REQUESTDISP_PROXY_FEATURE
};

PUBLIC CmAbnfElmDef soMsgDefProxyFeatureStr =
{
#ifdef CM_ABNF_DBG
   "SO PROXY",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 290,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefProxyFeatureStrEnum,
   NULLP
};

/********************************************************
cancel-feature -  Enum for "cancel-feature"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefCancelFeatureStrEnum =
{
   NULLP,
   SO_REQUESTDISP_CANCEL_FEATURE
};

PUBLIC CmAbnfElmDef soMsgDefCancelFeatureStr =
{
#ifdef CM_ABNF_DBG
   "SO PROXY",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 291,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefCancelFeatureStrEnum,
   NULLP
};

/********************************************************
fork-feature -  Enum for "fork-feature"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefForkFeatureStrEnum =
{
   NULLP,
   SO_REQUESTDISP_FORK_FEATURE
};

PUBLIC CmAbnfElmDef soMsgDefForkFeatureStr =
{
#ifdef CM_ABNF_DBG
   "SO PROXY",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 292,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefForkFeatureStrEnum,
   NULLP
};

/********************************************************
recurse-feature -  Enum for "recurse-feature"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRecurseFeatureStrEnum =
{
   NULLP,
   SO_REQUESTDISP_RECURSE_FEATURE
};

PUBLIC CmAbnfElmDef soMsgDefRecurseFeatureStr =
{
#ifdef CM_ABNF_DBG
   "SO RECURSE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 293,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRecurseFeatureStrEnum,
   NULLP
};

/********************************************************
parallel-feature -  Enum for "parallel-feature"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefParallelFeatureStrEnum =
{
   NULLP,
   SO_REQUESTDISP_PARALLEL_FEATURE
};

PUBLIC CmAbnfElmDef soMsgDefParallelFeatureStr =
{
#ifdef CM_ABNF_DBG
   "SO RECURSE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 294,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefParallelFeatureStrEnum,
   NULLP
};

/********************************************************
queue-feature -  Enum for "queue-feature"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefQueueFeatureStrEnum =
{
   NULLP,
   SO_REQUESTDISP_QUEUE_FEATURE 
};

PUBLIC CmAbnfElmDef soMsgDefQueueFeatureStr =
{
#ifdef CM_ABNF_DBG
   "SO RECURSE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 295,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefQueueFeatureStrEnum,
   NULLP
};
#endif /* SO_CALLERPREF */

/********************************************************
ResponseProxyAuthenticateStr  -  Enum for "Proxy-Authenticate"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefResponseProxyAuthenticateStrEnum =
{
   (Data *)"Proxy-Authenticate",
   SO_HEADER_RSP_PROXYAUTHENTICATE
};

PUBLIC CmAbnfElmDef soMsgDefResponseProxyAuthenticateStr =
{
#ifdef CM_ABNF_DBG
   "SO PROXYAUTHENTICATESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 296,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefResponseProxyAuthenticateStrEnum,
   NULLP
};

/********************************************************
ResponseRetryAfter   -  Enum for "Retry-After"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefResponseRetryAfterStrEnum =
{
   (Data *)"Retry-After",
   SO_HEADER_RSP_RETRYAFTER
};

PUBLIC CmAbnfElmDef soMsgDefResponseRetryAfterStr =
{
#ifdef CM_ABNF_DBG
   "SO RETRYAFTERSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 297,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefResponseRetryAfterStrEnum,
   NULLP
};


/********************************************************
HeaderAcceptEncodingStr -  Enum for "Accept-Encoding"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderAcceptEncodingStrEnum =
{
   (Data *)"Accept-Encoding",
   SO_HEADER_GEN_ACCEPTENCODING
};

PUBLIC CmAbnfElmDef soMsgDefHeaderAcceptEncodingStr =
{
#ifdef CM_ABNF_DBG
   "SO ACCEPTENCODINGSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 298,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderAcceptEncodingStrEnum,
   NULLP
};

/********************************************************
RequestAlertInfoStr  -  Enum for "Alert-Info"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestAlertInfoStrEnum =
{
   (Data *)"Alert-Info",
   SO_HEADER_GEN_ALERTINFO
};

PUBLIC CmAbnfElmDef soMsgDefRequestAlertInfoStr =
{
#ifdef CM_ABNF_DBG
   "SO ALERTINFOSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 299,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestAlertInfoStrEnum,
   NULLP
};

/********************************************************
RequestAuthorizationStr -  Enum for "Authorization"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestAuthorizationStrEnum =
{
   (Data *)"Authorization",
   SO_HEADER_REQ_AUTHORIZATION
};

PUBLIC CmAbnfElmDef soMsgDefRequestAuthorizationStr =
{
#ifdef CM_ABNF_DBG
   "SO AUTHORIZATIONSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 300,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestAuthorizationStrEnum,
   NULLP
};


/********************************************************
RequestInReplyToStr  -  Enum for "In-Reply-To"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestInReplyToStrEnum =
{
   (Data *)"In-Reply-To",
   SO_HEADER_REQ_INREPLYTO
};

PUBLIC CmAbnfElmDef soMsgDefRequestInReplyToStr =
{
#ifdef CM_ABNF_DBG
   "SO INREPLYTOSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 301,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestInReplyToStrEnum,
   NULLP
};

/********************************************************
RequestOrganizationStr  -  Enum for "Organization"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestOrganizationStrEnum =
{
   (Data *)"Organization",
   SO_HEADER_GEN_ORGANIZATION
};

PUBLIC CmAbnfElmDef soMsgDefRequestOrganizationStr =
{
#ifdef CM_ABNF_DBG
   "SO ORGANIZATIONSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 302,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestOrganizationStrEnum,
   NULLP
};

/********************************************************
RequestProxyAuthorizationStr  -  Enum for "Proxy-Authorization"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestProxyAuthorizationStrEnum =
{
   (Data *)"Proxy-Authorization",
   SO_HEADER_REQ_PROXYAUTHORIZATION
};

PUBLIC CmAbnfElmDef soMsgDefRequestProxyAuthorizationStr =
{
#ifdef CM_ABNF_DBG
   "SO ProxyAuthorizationSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 303,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestProxyAuthorizationStrEnum,
   NULLP
};

/********************************************************
RequestProxyRequireStr  -  Enum for "ProxyRequire"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestProxyRequireStrEnum =
{
   /* so002.102: should be Proxy-Require */
   (Data *)"Proxy-Require",
   SO_HEADER_GEN_PROXYREQUIRE
};

PUBLIC CmAbnfElmDef soMsgDefRequestProxyRequireStr =
{
#ifdef CM_ABNF_DBG
   "SO ProxyRequireSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 304,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestProxyRequireStrEnum,
   NULLP
};

/********************************************************
RequestSubjectStr -  Enum for "Subject"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestSubjectStrEnum =
{
   (Data *)"Subject",
   SO_HEADER_GEN_SUBJECT
};

PUBLIC CmAbnfElmDef soMsgDefRequestSubjectStr =
{
#ifdef CM_ABNF_DBG
   "SO SubjectSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 305,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestSubjectStrEnum,
   NULLP
};

/********************************************************
RequestAllowStr   -  Enum for "Allow"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestAllowStrEnum =
{
   (Data *)"Allow",
   SO_HEADER_GEN_ALLOW
};

PUBLIC CmAbnfElmDef soMsgDefRequestAllowStr =
{
#ifdef CM_ABNF_DBG
   "SO RequestAllowSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 306,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestAllowStrEnum,
   NULLP
};

/********************************************************
RequestContentDispositionStr  -  Enum for "Content-Disposition"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestContentDispositionStrEnum =
{
   (Data *)"Content-Disposition",
   SO_HEADER_ENT_CONTENTDISPOSITION
};

PUBLIC CmAbnfElmDef soMsgDefRequestContentDispositionStr =
{
#ifdef CM_ABNF_DBG
   "SO ContentDispositionSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 307,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestContentDispositionStrEnum,
   NULLP
};

/********************************************************
RequestContentEncodingStr  -  Enum for "Content-Encoding"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestContentEncodingStrEnum =
{
   (Data *)"Content-Encoding",
   SO_HEADER_ENT_CONTENTENCODING
};

PUBLIC CmAbnfElmDef soMsgDefRequestContentEncodingStr =
{
#ifdef CM_ABNF_DBG
   "SO ContentEncodingSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 308,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestContentEncodingStrEnum,
   NULLP
};


/********************************************************
RequestContentLanguageStr  -  Enum for "Content-Language"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestContentLanguageStrEnum =
{
   (Data *)"Content-Language",
   SO_HEADER_ENT_CONTENTLANGUAGE
};

PUBLIC CmAbnfElmDef soMsgDefRequestContentLanguageStr =
{
#ifdef CM_ABNF_DBG
   "SO ContentLanguageSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 309,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestContentLanguageStrEnum,
   NULLP
};


/********************************************************
RequestMinExpiresStr -  Enum for "MinExpires"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestMinExpiresStrEnum =
{  
   (Data *)"Min-Expires",
   SO_HEADER_GEN_MINEXPIRES
}; 

PUBLIC CmAbnfElmDef soMsgDefRequestMinExpiresStr =
{  
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 310,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestMinExpiresStrEnum,
   NULLP
}; 

/********************************************************
RequestExpiresStr -  Enum for "Expires"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestExpiresStrEnum =
{
   (Data *)"Expires",
   SO_HEADER_GEN_EXPIRES
};

PUBLIC CmAbnfElmDef soMsgDefRequestExpiresStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 311,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestExpiresStrEnum,
   NULLP
};


/********************************************************
RequestRAckStr -  Enum for "RAck"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestRAckStrEnum =
{
   (Data *)"RAck",
   SO_HEADER_GEN_RACK
};

PUBLIC CmAbnfElmDef soMsgDefRequestRAckStr =
{
#ifdef CM_ABNF_DBG
   "SO RackSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 312,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestRAckStrEnum,
   NULLP
};

/********************************************************
RequestStr  -  Enum for Request
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefRequestStrEnum =
{
   NULLP,
   SO_SIPMESSAGE_REQUEST
};

PUBLIC CmAbnfElmDef soMsgDefRequestStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 313,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestStrEnum,
   NULLP
};

/********************************************************
ResponseStr -  Enum for Response
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefResponseStrEnum =
{
   NULLP,
   SO_SIPMESSAGE_RESPONSE
};

PUBLIC CmAbnfElmDef soMsgDefResponseStr =
{
#ifdef CM_ABNF_DBG
   "SO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 314,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefResponseStrEnum,
   NULLP
};

#ifdef SO_RFC_3262
/********************************************************/
/********************************************************
RSeq  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefRSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefResponseNum,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRSeqSeq =
{
   3,
   soMsgDefRSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefRSeq =
{
#ifdef CM_ABNF_DBG
   "SO RESPONSENUMLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 315,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefRSeqSeq,
   NULLP
};

#endif /* SO_RFC_3262 */

/********************************************************
IP Address: U8: 0..255
*********************************************************/
PUBLIC CmAbnfElmTypeIntRange soMsgDefIPAdrRange = {1, 3, 0, 255};

PUBLIC CmAbnfElmDef soMsgDefIPAdr =
{
#ifdef CM_ABNF_DBG
   "SO_IP_ADR",
   "cmAbnfRegExpDgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 316,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT8,
   (U8 *)&soMsgDefIPAdrRange,
   cmAbnfRegExpDgt
};

/********************************************************
MethodStd   -  Standard Method   -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefMethodStdChoiceEnum[] =
{
   NULLP,
   &soMsgDefINVITEStr,
   &soMsgDefACKStr,
   &soMsgDefOPTIONSStr,
   &soMsgDefBYEStr,
   &soMsgDefCANCELStr,
   &soMsgDefREGISTERStr,
   &soMsgDefINFOStr,
   &soMsgDefCOMETStr,
   &soMsgDefPRACKStr,
   &soMsgDefREFERStr,
   &soMsgDefSUBSCRIBEStr,
   &soMsgDefNOTIFYStr,
   &soMsgDefMESSAGEStr,
   &soMsgDefUPDATEStr
};


PUBLIC CmAbnfElmTypeChoice soMsgDefMethodStdChoice =
{
   SO_METHODSTD_MAX,
   0,
   NULLP,
   NULLP,
   soMsgDefMethodStdChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefMethodStd =
{
#ifdef CM_ABNF_DBG
   "SO METHODSTD",
   "SORE_METHODSTDCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 317,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefMethodStdChoice,
   soRegExpMethodStdChoice
};

/********************************************************
Ipv4Address - IP version 4 Address  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefIpv4AddressSeqElmnt[] =
{
   &soMsgDefIPAdr,
   &soMsgDefMetaDotStr,
   &soMsgDefIPAdr,
   &soMsgDefMetaDotStr,
   &soMsgDefIPAdr,
   &soMsgDefMetaDotStr,
   &soMsgDefIPAdr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefIpv4AddressSeq =
{
   7,
   soMsgDefIpv4AddressSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefIpv4Address =
{
#ifdef CM_ABNF_DBG
   "SO IPV4ADDRESS",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 318,
   sizeof(SoIpv4Address),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefIpv4AddressSeq,
   NULLP
};

/********************************************************
Ipv6Reference  -  IP version 6 reference  -  Optional
Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefIpv6ReferenceSeqElmnt[] =
{
   &soMsgDefMetaOpenSqrBrStr,
   &soMsgDefIpv6Address,
   &soMsgDefMetaCloseSqrBrStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefIpv6ReferenceSeq =
{
   3,
   soMsgDefIpv6ReferenceSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefIpv6Reference =
{
#ifdef CM_ABNF_DBG
   "SO IPV6REFERENCE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 319,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefIpv6ReferenceSeq,
   NULLP
};

/********************************************************
WkDayChoice -  Week Day -  Choice
*********************************************************/


PUBLIC CmAbnfElmDef *soMsgDefWkDayChoiceEnum[] =
{
   NULLP,
   &soMsgDefMonStr,
   &soMsgDefTueStr,
   &soMsgDefWedStr,
   &soMsgDefThuStr,
   &soMsgDefFriStr,
   &soMsgDefSatStr,
   &soMsgDefSunStr
};


PUBLIC CmAbnfElmTypeChoice soMsgDefWkDayChoice =
{
   8,
   0,
   NULLP,
   NULLP,
   soMsgDefWkDayChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefWkDay =
{
#ifdef CM_ABNF_DBG
   "SO WKDAY",
   "SORE_WKDAYCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 320,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefWkDayChoice,
   soRegExpWkDayChoice
};

/********************************************************
Month -  Choice between months   -  Choice
*********************************************************/


PUBLIC CmAbnfElmDef *soMsgDefMonthChoiceEnum[] =
{
   NULLP,
   &soMsgDefJanStr,
   &soMsgDefFebStr,
   &soMsgDefMarStr,
   &soMsgDefAprStr,
   &soMsgDefMayStr,
   &soMsgDefJunStr,
   &soMsgDefJulStr,
   &soMsgDefAugStr,
   &soMsgDefSepStr,
   &soMsgDefOctStr,
   &soMsgDefNovStr,
   &soMsgDefDecStr
};


PUBLIC CmAbnfElmTypeChoice soMsgDefMonthChoice =
{
   13,
   0,
   NULLP,
   NULLP,
   soMsgDefMonthChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefMonth =
{
#ifdef CM_ABNF_DBG
   "SO MONTH",
   "SORE_MONTHCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 321,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefMonthChoice,
   soRegExpMonthChoice
};

/********************************************************
TransportParam -  Choice between Transport parameters
   -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefTransportParamChoiceEnum[] =
{
   NULLP,
   &soMsgDefTPUdpStr,
   &soMsgDefTPTcpStr,
   &soMsgDefTPSctpStr,
   &soMsgDefTPTlsStr,
   &soMsgDefOtherTransportStr
};

PUBLIC CmAbnfElmDef *soMsgDefTransportParamChoiceElmnt[] =
{
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   &soMsgDefOtherTransport
};


PUBLIC CmAbnfElmTypeChoice soMsgDefTransportParamChoice =
{
   6,
   0,
   NULLP,
   soMsgDefTransportParamChoiceElmnt,
   soMsgDefTransportParamChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefTransportParam =
{
#ifdef CM_ABNF_DBG
   "SO TRANSPORTPARAM",
   "SORE_TRANSPORTPARAMCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 322,
   sizeof(SoTransportParam),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefTransportParamChoice,
   soRegExpTransportParamChoice
};

/********************************************************
TransportParamList   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefTransportParamListSeqElmnt[] =
{
   &soMsgDefMetaEqualStr,
   &soMsgDefTransportParam
};

PUBLIC CmAbnfElmTypeSeq soMsgDefTransportParamListSeq =
{
   2,
   soMsgDefTransportParamListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefTransportParamList =
{
#ifdef CM_ABNF_DBG
   "SO TRANSPORTLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 323,
   sizeof(SoTransportParam),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefTransportParamListSeq,
   NULLP
};

/********************************************************
UserParam   -  Choice between different user parameters
   -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefUserParamChoiceEnum[] =
{
   NULLP,
   &soMsgDefPhoneStr,
   &soMsgDefIpStr,
   &soMsgDefOtherUserStr
};

PUBLIC CmAbnfElmDef *soMsgDefUserParamChoiceElmnt[] =
{
   NULLP,
   &soMsgDefPhoneStrSkip,
   &soMsgDefIpStrSkip,
   &soMsgDefOtherUser
};


PUBLIC CmAbnfElmTypeChoice soMsgDefUserParamChoice =
{
   4,
   0,
   NULLP,
   soMsgDefUserParamChoiceElmnt,
   soMsgDefUserParamChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefUserParam =
{
#ifdef CM_ABNF_DBG
   "SO USERPARAM",
   "SORE_USERPARAMCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 324,
   sizeof(SoUserParam),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefUserParamChoice,
   soRegExpUserParamChoice
};

/********************************************************
UserParamList  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefUserParamListSeqElmnt[] =
{
   &soMsgDefMetaEqualStr,
   &soMsgDefUserParam
};

PUBLIC CmAbnfElmTypeSeq soMsgDefUserParamListSeq =
{
   2,
   soMsgDefUserParamListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefUserParamList =
{
#ifdef CM_ABNF_DBG
   "SO USERPARAMLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 325,
   sizeof(SoUserParam),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefUserParamListSeq,
   NULLP
};


/********************************************************
Method   -  Choice of different Methods   -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefMethodChoiceEnum[] =
{
   NULLP,
   &soMsgDefMethodStdStr,
   &soMsgDefExtensionMethodStr
};

PUBLIC CmAbnfElmDef *soMsgDefMethodChoiceElmnt[] =
{
   NULLP,
   &soMsgDefMethodStd,
   &soMsgDefExtensionMethod
};


PUBLIC CmAbnfElmTypeChoice soMsgDefMethodChoice =
{
   3,
   0,
   NULLP,
   soMsgDefMethodChoiceElmnt,
   soMsgDefMethodChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefMethod =
{
#ifdef CM_ABNF_DBG
   "SO METHOD",
   "SORE_METHODCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 326,
   sizeof(SoExtVal),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefMethodChoice,
   soRegExpMethodChoice
};

/********************************************************
MethodList1 -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefMethodList1SeqElmnt[] =
{
   &soMsgDefMetaEqualStr,
   &soMsgDefMethod
};

PUBLIC CmAbnfElmTypeSeq soMsgDefMethodList1Seq =
{
   2,
   soMsgDefMethodList1SeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefMethodList1 =
{
#ifdef CM_ABNF_DBG
   "SO METHODLIST1",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 327,
   sizeof(SoExtVal),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefMethodList1Seq,
   NULLP
};

/********************************************************
TtlList  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefTtlListSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefTtl
};

PUBLIC CmAbnfElmTypeSeq soMsgDefTtlListSeq =
{
   4,
   soMsgDefTtlListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefTtlList =
{
#ifdef CM_ABNF_DBG
   "SO TTLLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 328,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefTtlListSeq,
   NULLP
};


/********************************************************
Host  -  Type of host   -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefHostChoiceEnum[] =
{
   NULLP,
   &soMsgDefHostNameStr,
   &soMsgDefIpv4AddressStr,
   &soMsgDefIpv6ReferenceStr
};

PUBLIC CmAbnfElmDef *soMsgDefHostChoiceElmnt[] =
{
   NULLP,
   &soMsgDefHostName,
   &soMsgDefIpv4Address,
   &soMsgDefIpv6Reference
};


PUBLIC CmAbnfElmTypeChoice soMsgDefHostChoice =
{
   4,
   0,
   NULLP,
   soMsgDefHostChoiceElmnt,
   soMsgDefHostChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefHost =
{
#ifdef CM_ABNF_DBG
   "SO HOST",
   "SORE_HOSTCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 329,
   sizeof(SoHost),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefHostChoice,
   soRegExpHostChoice
};

#ifdef SO_ENUM
/********************************************************
TelUserInfoAt  -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefTelUserInfoAtSeqElmnt[] =
{
   &soMsgDefTelephoneSubscriberOld
};

PUBLIC CmAbnfElmTypeSeq soMsgDefTelUserInfoAtSeq =
{
   1,
   soMsgDefTelUserInfoAtSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefTelUserInfoAt =
{
#ifdef CM_ABNF_DBG
   "SOTEST USERINFOAT",
   "SOTESTRE_TELURLOPT",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 330,
   sizeof(TknStrOSXL),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefTelUserInfoAtSeq,
   soRegExpTelUrlOpt2
};
#endif /* SO_ENUM */

/********************************************************
Maddr -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefMaddrSeqElmnt[] =
{
   &soMsgDefMetaEqualStr,
   &soMsgDefHost
};

PUBLIC CmAbnfElmTypeSeq soMsgDefMaddrSeq =
{
   2,
   soMsgDefMaddrSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefMaddr =
{
#ifdef CM_ABNF_DBG
   "SO MADDR",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 331,
   sizeof(SoHost),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefMaddrSeq,
   NULLP
};


/********************************************************
Comp Param -  Choice between Comp Param parameters
*********************************************************/

PUBLIC CmAbnfElmTypeEnum  soMsgDefSigCompStrEnum =
{   
    (Data *)"sigcomp",
    SO_COMP_SIGCOMP
};

PUBLIC CmAbnfElmDef  soMsgDefSigCompStr =
{   
#ifdef CM_ABNF_DBG
    "SIP SIG COMP ENUM ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 332,
    sizeof (TknU8),  
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefSigCompStrEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefCompExtnStrEnum =
{   
    (Data *)"",
    SO_COMP_EXTN
};

PUBLIC CmAbnfElmDef  soMsgDefCompExtnStr =
{   
#ifdef CM_ABNF_DBG
    "SIP COMP EXTN ENUM ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 333,
    sizeof (TknU8),  
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefCompExtnStrEnum,
    NULLP
};

PUBLIC CmAbnfElmDef *soMsgDefCompParamChoiceEnum[] =
{
   NULLP,
   &soMsgDefSigCompStr,
   &soMsgDefCompExtnStr,
};

PUBLIC CmAbnfElmDef *soMsgDefCompParamChoiceElmnt[] =
{
   NULLP,
   NULLP,
   &soMsgDefToken,
};


PUBLIC CmAbnfElmTypeChoice soMsgDefCompParamChoice =
{
   3,
   0,
   NULLP,
   soMsgDefCompParamChoiceElmnt,
   soMsgDefCompParamChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefCompParam =
{
#ifdef CM_ABNF_DBG
   "SO COMP PARAM",
   "SORE_COMPPARAMCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 334,
   sizeof(SoStrValue),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefCompParamChoice,
   soRegExpCompParam
};

/********************************************************
CompSeq   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefCompSeqElmnt[] =
{
   &soMsgDefMetaEqualStr,
   &soMsgDefCompParam
};

PUBLIC CmAbnfElmTypeSeq soMsgDefCompSeq =
{
   2,
   soMsgDefCompSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefComp =
{
#ifdef CM_ABNF_DBG
   "SO COMP",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 335,
   sizeof(SoStrValue),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefCompSeq,
   NULLP
};

/********************************************************
UrlHeader   -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefUrlHeaderSeqElmnt[] =
{
   &soMsgDefHName,
   &soMsgDefMetaEqualStr,
   &soMsgDefHValue
};

PUBLIC CmAbnfElmTypeSeq soMsgDefUrlHeaderSeq =
{
   3,
   soMsgDefUrlHeaderSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefUrlHeader =
{
#ifdef CM_ABNF_DBG
   "SO HEADER",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 336,
   sizeof(SoNameVal),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefUrlHeaderSeq,
   NULLP
};

/********************************************************
SipDateHdr  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefSipDateHdrSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefWkDay,
   &soMsgDefMetaCommaOptSpaceStr,
   &soMsgDefSkipAllSpaceEat,
   &soMsgDefDay,
   &soMsgDefMetaSpaceStr,
   &soMsgDefMonth,
   &soMsgDefMetaSpaceStr,
   &soMsgDefYear,
   &soMsgDefMetaSpaceStr,
   &soMsgDefHr,
   &soMsgDefMetaColonStr,
   &soMsgDefMn,
   &soMsgDefMetaColonStr,
   &soMsgDefSec,
   &soMsgDefMetaSpaceStr,
   &soMsgDefGMTStr,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefSipDateHdrSeq =
{
   18,
   soMsgDefSipDateHdrSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefSipDateHdr =
{
#ifdef CM_ABNF_DBG
   "SO_SIPDATE_HDR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 337,
   sizeof(SoSipDate),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefSipDateHdrSeq,
   NULLP
};

/********************************************************
UserInfo1   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefUserTypeChoiceEnum[] =
{
   NULLP,
   &soMsgDefUserTypeStr,
#ifdef SO_ENUM
   &soMsgDefTelSubscriberStr,
#endif
};

PUBLIC CmAbnfElmDef *soMsgDefUserTypeChoiceElmnt[] =
{
   NULLP,
   &soMsgDefUser,
#ifdef SO_ENUM
   &soMsgDefTelSubscriber
#endif
};


PUBLIC CmAbnfElmTypeChoice soMsgDefUserTypeChoice =
{
#ifdef SO_ENUM
   3,
#else
   2,
#endif
   0,
   NULLP,
   soMsgDefUserTypeChoiceElmnt,
   soMsgDefUserTypeChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefUserInfo1 =
{
#ifdef CM_ABNF_DBG
   "SO USERTYPE",
   "SORE_USERTYPECHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 338,
   sizeof(SoStrValue),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefUserTypeChoice,
   soRegExpUserTypeChoice
};

/********************************************************
Password -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefPasswordOptSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefPasswordText
};

PUBLIC CmAbnfElmTypeSeq soMsgDefPasswordOptSeq =
{
   2,
   soMsgDefPasswordOptSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefPassword =
{
#ifdef CM_ABNF_DBG
   "SOTEST PASSWORD",
   "SOTESTRE_METACOLON",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 339,
   sizeof(TknStrOSXL),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefPasswordOptSeq,
   soRegExpMetaColon
};

PUBLIC CmAbnfElmDef *soMsgDefOptPValueSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefPValue
};

PUBLIC CmAbnfElmTypeSeq soMsgDefOptPValueSeq =
{
   4,
   soMsgDefOptPValueSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefOptPValue =
{
#ifdef CM_ABNF_DBG
   "SOTEST P Value",
   "SORE_METAEQUAL",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 340,
   sizeof(TknU32),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefOptPValueSeq,
   soRegExpMetaSwsEqual
};

PUBLIC CmAbnfElmDef *soMsgDefOtherParamTypeSeqElmnt[] =
{
   &soMsgDefPName,
   &soMsgDefOptPValue
};   

PUBLIC CmAbnfElmTypeSeq soMsgDefOtherParamSeq =
{
   2,
   soMsgDefOtherParamTypeSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefOtherParam =
{
#ifdef CM_ABNF_DBG
   "SO OTHERPARAM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 341,
   sizeof(SoNameVal),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefOtherParamSeq,
   NULLP
};

/**********************************************************
QVFrac  -  Optional Sequence
***********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefQVFracSeqElmnt[] =
{
   &soMsgDefMetaDotStr,
   &soMsgDefFrac
};


PUBLIC CmAbnfElmTypeSeq soMsgDefQVFracSeq =
{
   2,
   soMsgDefQVFracSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefQVFrac =
{
#ifdef CM_ABNF_DBG
  "SOTEST QVFRAC",
  "SOTESTRE_QVFRAC",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 342,
   sizeof(TknU16),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefQVFracSeq,
   soRegExpMetaDot
};

/********************************************************
GenericParamOpt   -  Type of Generic Parameter  -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefGenericParamOptChoiceEnum[] =
{
   NULLP,
   &soMsgDefTokenStr,
   &soMsgDefQuotedStrStr
};

PUBLIC CmAbnfElmDef *soMsgDefGenericParamOptChoiceElmnt[] =
{
   NULLP,
   &soMsgDefTokenHost,
   &soMsgDefQuotedStr
};


PUBLIC CmAbnfElmTypeChoice soMsgDefGenericParamOptChoice =
{
   3,
   0,
   NULLP,
   soMsgDefGenericParamOptChoiceElmnt,
   soMsgDefGenericParamOptChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefGenericParamOpt =
{
#ifdef CM_ABNF_DBG
   "SO GENERICPARAMOPT",
   "SORE_GENERICPARAMOPTCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 343,
   sizeof(SoStrValue),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefGenericParamOptChoice,
   soRegExpGenericParamOptChoice
};

#if ((defined SO_ENUM) || (defined SO_PINT))
/********************************************************
Tsp -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefTspSeqElmnt[] =
{
   &soMsgDefMetaEqualStr,
   &soMsgDefHost
};

PUBLIC CmAbnfElmTypeSeq soMsgDefTspSeq =
{
   2,
   soMsgDefTspSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefTsp =
{
#ifdef CM_ABNF_DBG
   "SO TSP",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 344,
   sizeof(SoHost),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefTspSeq,
   NULLP
};

#endif

#ifdef SO_ENUM

/********************************************************
Postd -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefPostdSeqElmnt[] =
{
   &soMsgDefMetaEqualStr,
   &soMsgDefTelUserInfoAt
};

PUBLIC CmAbnfElmTypeSeq soMsgDefPostdSeq =
{
   2,
   soMsgDefPostdSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefPostd =
{
#ifdef CM_ABNF_DBG
   "SO POSTD",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 345,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefPostdSeq,
   NULLP
};

/********************************************************
Isub -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefIsubSeqElmnt[] =
{
   &soMsgDefMetaEqualStr,
   &soMsgDefTelUserInfoAt
};

PUBLIC CmAbnfElmTypeSeq soMsgDefIsubSeq =
{
   2,
   soMsgDefIsubSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefIsub =
{
#ifdef CM_ABNF_DBG
   "SO ISUB",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 346,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefIsubSeq,
   NULLP
};

/********************************************************
PhoneContext -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefPhoneContextSeqElmnt[] =
{
   &soMsgDefMetaEqualStr,
   &soMsgDefTelUserInfoAt
};

PUBLIC CmAbnfElmTypeSeq soMsgDefPhoneContextSeq =
{
   2,
   soMsgDefPhoneContextSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefPhoneContext =
{
#ifdef CM_ABNF_DBG
   "SO PHONECONTEXT",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 347,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefPhoneContextSeq,
   NULLP
};
#endif /* SO_ENUM */

/********************************************************
GenericParam1  -  Optional Sequence
*********************************************************/
/* so013.102: add LWS for EQUAL */
PUBLIC CmAbnfElmDef *soMsgDefGenericParam1OptSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &cmMsgDefMetaEqual,
   &soMsgDefMetaSws,
   &soMsgDefGenericParamOpt
};

PUBLIC CmAbnfElmTypeSeq soMsgDefGenericParam1OptSeq =
{
   4,
   soMsgDefGenericParam1OptSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefGenericParam1 =
{
#ifdef CM_ABNF_DBG
   "SO GENERICPARAM1",
   "SORE_EQUAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 348,
   sizeof(SoStrValue),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefGenericParam1OptSeq,
   soRegExpMetaSwsEqual
};

/********************************************************
GenericParam   -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefGenericParamSeqElmnt[] =
{
   &soMsgDefToken,
   &soMsgDefGenericParam1
};

PUBLIC CmAbnfElmTypeSeq soMsgDefGenericParamSeq =
{
   2,
   soMsgDefGenericParamSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefGenericParam =
{
#ifdef CM_ABNF_DBG
   "SO GENERICPARAM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 349,
   sizeof(SoParameter),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefGenericParamSeq,
   NULLP
};

/********************************************************
UrlParameter   -  Type of URL parameter
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefUrlParameterChoiceEnum[] =
{
   NULLP,
   &soMsgDefTransportStr,
   &soMsgDefUserStr,
   &soMsgDefMethodStr,
   &soMsgDefTtlStr,
   &soMsgDefMaddrStr,
   &soMsgDefLrStr,

#ifdef SO_PINT
   &soMsgDefTspStr,
#else
   &soMsgDefOtherParamStr,
#endif

#ifdef SO_ENUM
   &soMsgDefPhoneContextStr,
   &soMsgDefIsubStr,
   &soMsgDefPostdStr,
#else
   &soMsgDefOtherParamStr,
   &soMsgDefOtherParamStr,
   &soMsgDefOtherParamStr,
#endif /* SO_ENUM */

   &soMsgDefUrlCompStr,
   &soMsgDefOtherParamStr
};

PUBLIC CmAbnfElmDef *soMsgDefUrlParameterChoiceElmnt[] =
{
   NULLP,
   &soMsgDefTransportParamList,
   &soMsgDefUserParamList,
   &soMsgDefMethodList1,
   &soMsgDefTtlList,
   &soMsgDefMaddr,
   NULLP,

#ifdef SO_PINT
   &soMsgDefTsp,
#else
   &soMsgDefOtherParam,
#endif

#ifdef SO_ENUM
   &soMsgDefPhoneContext,
   &soMsgDefIsub,
   &soMsgDefPostd,
#else
   &soMsgDefOtherParam,
   &soMsgDefOtherParam,
   &soMsgDefOtherParam,
#endif /* SO_ENUM */

   &soMsgDefComp,
   &soMsgDefOtherParam
};


PUBLIC CmAbnfElmTypeChoice soMsgDefUrlParameterChoice =
{
   13,
   0,
   NULLP,
   soMsgDefUrlParameterChoiceElmnt,
   soMsgDefUrlParameterChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefUrlParameter =
{
#ifdef CM_ABNF_DBG
   "SO URLPARAMETER",
   "SORE_URLPARAMETERCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 350,
   sizeof(SoUrlParameter),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefUrlParameterChoice,
   soRegExpUrlParameterChoice
};

/********************************************************
HeaderExt   -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefHeaderExtSeqOfElmnt[] =
{
   &soMsgDefMetaAmpersandStr,
   &soMsgDefUrlHeader
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefHeaderExtSeqOf =
{
   0,
   SO_MAX_HEADEREXT,
   2,
   soMsgDefHeaderExtSeqOfElmnt,
   sizeof(SoNameVal),
};


PUBLIC CmAbnfElmDef soMsgDefHeaderExt =
{
#ifdef CM_ABNF_DBG
   "SO HEADEREXT",
   "SORE_HEADEREXT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 351,
   sizeof(SoHeaderExt),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefHeaderExtSeqOf,
   soRegExpHeaderExt
};


/********************************************************
QValue   -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefQValueSeqElmnt[] =
{
   &soMsgDefQVInt,
   &soMsgDefQVFrac
};

PUBLIC CmAbnfElmTypeSeq soMsgDefQValueSeq =
{
   2,
   soMsgDefQValueSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefQValue =
{
#ifdef CM_ABNF_DBG
   "SO QVALUE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 352,
   sizeof(SoQValue),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefQValueSeq,
   NULLP
};

/********************************************************
QValueList  -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefQValueListSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefQValue
};

PUBLIC CmAbnfElmTypeSeq soMsgDefQValueListSeq =
{
   4,
   soMsgDefQValueListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefQValueList =
{
#ifdef CM_ABNF_DBG
   "SO QVALUELIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 353,
   sizeof(SoQValue),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefQValueListSeq,
   NULLP
};


/********************************************************
Action   -  Type of Action -  Choice
*********************************************************/


PUBLIC CmAbnfElmDef *soMsgDefActionChoiceEnum[] =
{
   NULLP,
   &soMsgDefProxyStr,
   &soMsgDefRedirectStr
};


PUBLIC CmAbnfElmTypeChoice soMsgDefActionChoice =
{
   3,
   0,
   NULLP,
   NULLP,
   soMsgDefActionChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefAction =
{
#ifdef CM_ABNF_DBG
   "SO ACTION",
   "SORE_ACTIONCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 354,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefActionChoice,
   soRegExpActionChoice
};


/********************************************************
ActionList  -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefActionListSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefAction
};

PUBLIC CmAbnfElmTypeSeq soMsgDefActionListSeq =
{
   4,
   soMsgDefActionListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefActionList =
{
#ifdef CM_ABNF_DBG
   "SO ACTIONLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 355,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefActionListSeq,
   NULLP
};

/********************************************************
ContactParExpiresList   -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefContactParExpiresListSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefDeltaSeconds
};

PUBLIC CmAbnfElmTypeSeq soMsgDefContactParExpiresListSeq =
{
   4,
   soMsgDefContactParExpiresListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefContactParExpiresList =
{
#ifdef CM_ABNF_DBG
   "SO CONTACTPAREXPIRESLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 356,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefContactParExpiresListSeq,
   NULLP
};

/********************************************************
UserInfoAt  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefUserInfoSeqElmnt[] =
{
   &soMsgDefUserInfo1,
   &soMsgDefPassword,
   &soMsgDefMetaAtStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefUserInfoSeq =
{
   3,
   soMsgDefUserInfoSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefUserInfo =
{
#ifdef CM_ABNF_DBG
   "SO USERINFO",
   "SORE_USERINFO",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 357,
   sizeof(SoUserInfo),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefUserInfoSeq,
   soRegExpUserInfo
};


/********************************************************
UrlParametersTopic   -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefUrlParametersTopicSeqOfElmnt[] =
{
   &soMsgDefMetaSemiColonStr,
   &soMsgDefUrlParameter
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefUrlParametersTopicSeqOf =
{
   0,
   SO_MAX_URLPARAMETERS,
   2,
   soMsgDefUrlParametersTopicSeqOfElmnt,
   sizeof(SoUrlParameter)
};

PUBLIC CmAbnfElmDef soMsgDefUrlParametersTopic =
{
#ifdef CM_ABNF_DBG
   "SOTEST URLPARAMETERSTOPIC",
   "SOTESTRE_URLPARAMETERS",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 358,
   sizeof(SoUrlParameters),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefUrlParametersTopicSeqOf,
   soRegExpUrlParameters
};

/********************************************************
Headers  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefHeadersSeqElmnt[] =
{
   &soMsgDefMetaQuestionMarkStr,
   &soMsgDefUrlHeader,
   &soMsgDefHeaderExt
};

PUBLIC CmAbnfElmTypeSeq soMsgDefHeadersSeq =
{
   3,
   soMsgDefHeadersSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefHeaders =
{
#ifdef CM_ABNF_DBG
   "SO HEADERS",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 359,
   sizeof(SoHeaders),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefHeadersSeq,
   soRegExpSipUrlOpt5
};

/********************************************************
DisplayNameRep -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefDisplayNameRepSeqOfElmnt[] =
{
   &soMsgDefToken,
   &soMsgDefMetaDNLws,
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefDisplayNameRepSeqOf =
{
   0,
   SO_MAX_DISPLAYNAMEREP,
   2,
   soMsgDefDisplayNameRepSeqOfElmnt,
   sizeof(TknStrOSXL)
};


PUBLIC CmAbnfElmDef soMsgDefDisplayNameRep =
{
#ifdef CM_ABNF_DBG
   "SO DISPLAYNAMEREP",
   "SORE_DISPLAYNAMEREP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 360,
   sizeof(SoTknStrOSXLLst),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefDisplayNameRepSeqOf,
   soRegExpDisplayNameRep
};

/********************************************************
Port  -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefPortSeqElmnt[] =
{
   &soMsgDefMetaColonStr,
   &soMsgDefPPort
};

PUBLIC CmAbnfElmTypeSeq soMsgDefPortSeq =
{
   2,
   soMsgDefPortSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefPort =
{
#ifdef CM_ABNF_DBG
   "SOTEST PORT",
   "SORE_METACOLONNOSPACE",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 361,
   sizeof(TknU32),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefPortSeq,
   soRegExpMetaColonNoSpace
};

/********************************************************
HostPort -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefHostPortSeqElmnt[] =
{
   &soMsgDefHost,
   &soMsgDefPort
};

PUBLIC CmAbnfElmTypeSeq soMsgDefHostPortSeq =
{
   2,
   soMsgDefHostPortSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefHostPort =
{
#ifdef CM_ABNF_DBG
   "SO HOSTPORT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 362,
   sizeof(SoHostPort),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefHostPortSeq,
   NULLP
};

/********************************************************
AbsUriDesc  -  Type of Absolute URI Description - Choice
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefAbsUriDescRange = {1, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefAbsUriDesc =
{
#ifdef CM_ABNF_DBG
   "SO ABSURIDESC",
   "SORE_ABSURIDESC",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 363,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefAbsUriDescRange,
   soRegExpAbsUriDesc
};

/********************************************************
ContactParamStd   -  Type of Standard Contact Parameter
   -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContactParamStdChoiceEnum[] =
{
   NULLP,
   &soMsgDefQStr,
   &soMsgDefActionStr,
   &soMsgDefExpiresStr
};

PUBLIC CmAbnfElmDef *soMsgDefContactParamStdChoiceElmnt[] =
{
   NULLP,
   &soMsgDefQValueList,
   &soMsgDefActionList,
   &soMsgDefContactParExpiresList
};


PUBLIC CmAbnfElmTypeChoice soMsgDefContactParamStdChoice =
{
   4,
   0,
   NULLP,
   soMsgDefContactParamStdChoiceElmnt,
   soMsgDefContactParamStdChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefContactParamStd =
{
#ifdef CM_ABNF_DBG
   "SO CONTACTPARAMSTD",
   "SORE_CONTACTPARAMSTDCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 364,
   sizeof(SoContactParamStd),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefContactParamStdChoice,
   soRegExpContactParamStdChoice
};

#ifdef SO_CALLERPREF 
PUBLIC CmAbnfElmDef  *soMsgDefFeatParamValSeqElmnts[] =
{
    &soMsgDefMetaSws,
    &soMsgDefMetaEqualStr,
    &soMsgDefMetaSws,
    &soMsgDefQuotedStr,
    &soMsgDefMetaSws
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefFeatParamValSeq =
{
    5,
    soMsgDefFeatParamValSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefFeatParamVal =
{
#ifdef  CM_ABNF_DBG
    "SIP FEAT PARAM VAL ",
    "soRegExpMetaSwsEqual",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 365,
    sizeof(TknStrOSXL),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefFeatParamValSeq,
    soRegExpMetaSwsEqual
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatAudioEnum =
{
    (Data *)"audio",
    SO_FEAT_PAR_AUDIO
};

PUBLIC CmAbnfElmDef  soMsgDefFeatAudioEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT AUDIO ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 366,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatAudioEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatAutomataEnum =
{
    (Data *)"automata",
    SO_FEAT_PAR_AUTOMATA
};

PUBLIC CmAbnfElmDef  soMsgDefFeatAutomataEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT AUTOMATA ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 367,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatAutomataEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatClassEnum =
{
    (Data *)"class",
    SO_FEAT_PAR_CLASS
};

PUBLIC CmAbnfElmDef  soMsgDefFeatClassEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT CLASS ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 368,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatClassEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatDuplexEnum =
{
    (Data *)"duplex",
    SO_FEAT_PAR_DUPLEX
};

PUBLIC CmAbnfElmDef  soMsgDefFeatDuplexEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT DUPLEX ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 369,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatDuplexEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatDataEnum =
{
    (Data *)"data",
    SO_FEAT_PAR_DATA
};

PUBLIC CmAbnfElmDef  soMsgDefFeatDataEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT DATA ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 370,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatDataEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatControlEnum =
{
    (Data *)"control",
    SO_FEAT_PAR_CONTROL
};

PUBLIC CmAbnfElmDef  soMsgDefFeatControlEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT CONTROL ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 371,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatControlEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatMobilityEnum =
{
    (Data *)"mobility",
    SO_FEAT_PAR_MOBILITY
};

PUBLIC CmAbnfElmDef  soMsgDefFeatMobilityEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT MOBILITY ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 372,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatMobilityEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatDescriptionEnum =
{
    (Data *)"description",
    SO_FEAT_PAR_DESCRIPTION
};

PUBLIC CmAbnfElmDef  soMsgDefFeatDescriptionEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT DESCRIPTION ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 373,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatDescriptionEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatEventsEnum =
{
    (Data *)"events",
    SO_FEAT_PAR_EVENTS
};

PUBLIC CmAbnfElmDef  soMsgDefFeatEventsEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT EVENTS ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 374,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatEventsEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatPriorityEnum =
{
    (Data *)"priority",
    SO_FEAT_PAR_PRIORITY
};

PUBLIC CmAbnfElmDef  soMsgDefFeatPriorityEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT PRIORITY ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 375,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatPriorityEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatMethodsEnum =
{
    (Data *)"methods",
    SO_FEAT_PAR_METHODS
};

PUBLIC CmAbnfElmDef  soMsgDefFeatMethodsEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT METHODS ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 376,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatMethodsEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatSchemesEnum =
{
    (Data *)"schemes",
    SO_FEAT_PAR_SCHEMES
};

PUBLIC CmAbnfElmDef  soMsgDefFeatSchemesEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT SCHEMES ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 377,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatSchemesEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatApplicationEnum =
{
    (Data *)"application",
    SO_FEAT_PAR_APPLICATION
};

PUBLIC CmAbnfElmDef  soMsgDefFeatApplicationEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT APPLICATION ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 378,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatApplicationEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatVideoEnum =
{
    (Data *)"video",
    SO_FEAT_PAR_VIDEO
};

PUBLIC CmAbnfElmDef  soMsgDefFeatVideoEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT VIDEO ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 379,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatVideoEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatLanguageEnum =
{
    (Data *)"language",
    SO_FEAT_PAR_LANGUAGE
};

PUBLIC CmAbnfElmDef  soMsgDefFeatLanguageEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT LANGUAGE ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 380,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatLanguageEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatTypeEnum =
{
    (Data *)"type",
    SO_FEAT_PAR_TYPE
};

PUBLIC CmAbnfElmDef  soMsgDefFeatTypeEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT TYPE ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 381,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatTypeEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatIsFocusEnum =
{
    (Data *)"isfocus",
    SO_FEAT_PAR_ISFOCUS
};

PUBLIC CmAbnfElmDef  soMsgDefFeatIsFocusEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT IS FOCUS ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 382,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatIsFocusEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatActorEnum =
{
    (Data *)"actor",
    SO_FEAT_PAR_ACTOR
};

PUBLIC CmAbnfElmDef  soMsgDefFeatActorEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT ACTOR ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 383,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatActorEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatTextEnum =
{
    (Data *)"text",
    SO_FEAT_PAR_TEXT
};

PUBLIC CmAbnfElmDef  soMsgDefFeatTextEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT TEXT ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 384,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatTextEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefFeatExtnEnum =
{
    (Data *)"",
    SO_FEAT_PAR_EXTN
};

PUBLIC CmAbnfElmDef  soMsgDefFeatExtnEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP FEAT EXTN ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 385,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefFeatExtnEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefFeatParamListChcEnum[] =
{
   NULLP,
   &soMsgDefFeatAudioEnumDef,
   &soMsgDefFeatAutomataEnumDef,
   &soMsgDefFeatClassEnumDef,
   &soMsgDefFeatDuplexEnumDef,
   &soMsgDefFeatDataEnumDef,
   &soMsgDefFeatControlEnumDef,
   &soMsgDefFeatMobilityEnumDef,
   &soMsgDefFeatDescriptionEnumDef,
   &soMsgDefFeatEventsEnumDef,
   &soMsgDefFeatPriorityEnumDef,
   &soMsgDefFeatMethodsEnumDef,
   &soMsgDefFeatSchemesEnumDef,
   &soMsgDefFeatApplicationEnumDef,
   &soMsgDefFeatVideoEnumDef,
   &soMsgDefFeatLanguageEnumDef,
   &soMsgDefFeatTypeEnumDef,
   &soMsgDefFeatIsFocusEnumDef,
   &soMsgDefFeatActorEnumDef,
   &soMsgDefFeatTextEnumDef,
   &soMsgDefFeatExtnEnumDef,
};

PUBLIC CmAbnfElmDef  *soMsgDefFeatParamListChcElmnt[] =
{
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    &soMsgDefToken,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefFeatParamListChc =
{
    21,
    0,
    NULLP,
    soMsgDefFeatParamListChcElmnt,
    soMsgDefFeatParamListChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefFeatParamList =
{
#ifdef  CM_ABNF_DBG
    "SIP FEAT PARAM LIST ",
    "soRegExpFeatParam",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 386,
    sizeof(SoStrValue),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soMsgDefFeatParamListChc,
    soRegExpFeatParam
};

PUBLIC CmAbnfElmDef  *soMsgDefFeatParamSeqElmnts[] =
{
    &soMsgDefFeatParamList,
    &soMsgDefFeatParamVal
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefFeatParamSeq =
{
    2,
    soMsgDefFeatParamSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefFeatParam =
{
#ifdef  CM_ABNF_DBG
    "SIP FEAT PARAM ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 387,
    sizeof(SoStrValue),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefFeatParamSeq,
    NULLP
};
#endif

/********************************************************
Value -  Type of Value  -  Choice
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefValueChoiceEnum[] =
{
   NULLP,
   &soMsgDefTokenStr,
   &soMsgDefQuotedStrStr
};

PUBLIC CmAbnfElmDef *soMsgDefValueChoiceElmnt[] =
{
   NULLP,
   &soMsgDefToken,
   &soMsgDefQuotedStr
};


PUBLIC CmAbnfElmTypeChoice soMsgDefValueChoice =
{
   3,
   0,
   NULLP,
   soMsgDefValueChoiceElmnt,
   soMsgDefValueChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefValue =
{
#ifdef CM_ABNF_DBG
   "SO VALUE",
   "SORE_VALUECHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 388,
   sizeof(SoStrValue),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefValueChoice,
   soRegExpValueChoice
};

/********************************************************
CallInfoPurpose   -  Type of Call Info Purpose  -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefCallInfoPurposeChoiceEnum[] =
{
   NULLP,
   &soMsgDefIconStr,
   &soMsgDefInfoStr,
   &soMsgDefCardStr,
   &soMsgDefPurposeExtStr
};

PUBLIC CmAbnfElmDef *soMsgDefCallInfoPurposeChoiceElmnt[] =
{
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   &soMsgDefToken
};


PUBLIC CmAbnfElmTypeChoice soMsgDefCallInfoPurposeChoice =
{
   5,
   0,
   NULLP,
   soMsgDefCallInfoPurposeChoiceElmnt,
   soMsgDefCallInfoPurposeChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefCallInfoPurpose =
{
#ifdef CM_ABNF_DBG
   "SO CALLINFOPURPOSE",
   "SORE_CALLINFOPURPOSECHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 389,
   sizeof(SoCallInfoPurpose),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefCallInfoPurposeChoice,
   soRegExpCallInfoPurposeChoice
};

/********************************************************
CallInfoPurposeList  -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefCallInfoPurposeListSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefCallInfoPurpose,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefCallInfoPurposeListSeq =
{
   4,
   soMsgDefCallInfoPurposeListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefCallInfoPurposeList =
{
#ifdef CM_ABNF_DBG
   "SO CALLINFOPURPOSELIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 390,
   sizeof(SoCallInfoPurpose),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefCallInfoPurposeListSeq,
   NULLP
};

/********************************************************
DisplayName -  Type of Display Name -  Choice
*********************************************************/


PUBLIC CmAbnfElmDef *soMsgDefDisplayNameChoiceEnum[] =
{
   NULLP,
   &soMsgDefTokenStr,
   &soMsgDefQuotedStrStr
};

PUBLIC CmAbnfElmDef *soMsgDefDisplayNameChoiceElmnt[] =
{
   NULLP,
   &soMsgDefDisplayNameRep,
   &soMsgDefQuotedStr
};


PUBLIC CmAbnfElmTypeChoice soMsgDefDisplayNameChoice =
{
   3,
   0,
   NULLP,
   soMsgDefDisplayNameChoiceElmnt,
   soMsgDefDisplayNameChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefDisplayName =
{
#ifdef CM_ABNF_DBG
   "SO DISPLAYNAME",
   "SORE_DISPLAYNAMECHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 391,
   sizeof(SoDisplayName),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefDisplayNameChoice,
   soRegExpDisplayNameChoice
};

/* RFC 2806: Tel Url */
#ifdef SO_ENUM
/********************************************************
TelUrl   -  Sequence
*********************************************************/
PUBLIC CmAbnfElmTypeEnum  soMsgDefTelIsubEnum =
{
    (Data *)"isub",
    SO_TEL_ISUB
};

PUBLIC CmAbnfElmDef  soMsgDefTelIsubEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP TEL ISUB ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 392,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefTelIsubEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeRange  soMsgDefTelIsubRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  soMsgDefTelIsubVal =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL ISUB VAL",
    "soRegExpTelNum",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 393,
    sizeof (TknStrOSXL),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_OCTSTRXL,
    (U8 *) &soMsgDefTelIsubRange,
    soRegExpTelNum
};

PUBLIC CmAbnfElmDef  *soMsgDefTelIsubSeqElmnts[] =
{
    &soMsgDefMetaEqualStr,
    &soMsgDefTelIsubVal,
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefTelIsubSeq =
{
    2,
    soMsgDefTelIsubSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefTelIsub =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL ISUB ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 394,
    sizeof(TknStrOSXL),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefTelIsubSeq,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefTelPostdEnum =
{
    (Data *)"postd",
    SO_TEL_POSTD
};

PUBLIC CmAbnfElmDef  soMsgDefTelPostdEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP TEL POSTD ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 395,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefTelPostdEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeRange  soMsgDefTelPostdRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  soMsgDefTelPostdVal =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL POSTD VAL",
    "soRegExpTelLocNum",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 396,
    sizeof (TknStrOSXL),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_OCTSTRXL,
    (U8 *) &soMsgDefTelPostdRange,
    soRegExpTelLocNum
};

PUBLIC CmAbnfElmDef  *soMsgDefTelPostdSeqElmnts[] =
{
    &soMsgDefMetaEqualStr,
    &soMsgDefTelPostdVal,
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefTelPostdSeq =
{
    2,
    soMsgDefTelPostdSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefTelPostd =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL POSTD ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 397,
    sizeof(TknStrOSXL),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefTelPostdSeq,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefTelPhoneContextEnum =
{
    (Data *)"phone-context",
    SO_TEL_PHONE_CONTEXT
};

PUBLIC CmAbnfElmDef  soMsgDefTelPhoneContextEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP TEL PHONE CONTEXT ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 398,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefTelPhoneContextEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeRange  soMsgDefTelPhoneContextRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  soMsgDefTelPhoneContextVal =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL PHONE CONTEXT VAL",
    "soRegExpTelPhoneContext",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 399,
    sizeof (TknStrOSXL),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_OCTSTRXL,
    (U8 *) &soMsgDefTelPhoneContextRange,
    soRegExpTelPhoneContext
};

PUBLIC CmAbnfElmDef  *soMsgDefTelPhoneContextSeqElmnts[] =
{
    &soMsgDefMetaEqualStr,
    &soMsgDefTelPhoneContextVal,
};  

PUBLIC CmAbnfElmTypeSeq  soMsgDefTelPhoneContextSeq =
{
    2,
    soMsgDefTelPhoneContextSeqElmnts
};  

PUBLIC CmAbnfElmDef  soMsgDefTelPhoneContext =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL PHONECONTEXT ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 400,
    sizeof(TknStrOSXL),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefTelPhoneContextSeq,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefTelTspEnum =
{
    (Data *)"tsp",
    SO_TEL_TSP
};

PUBLIC CmAbnfElmDef  soMsgDefTelTspEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP TEL TSP ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 401,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefTelTspEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefTelTspSeqElmnts[] =
{  
    &soMsgDefMetaEqualStr,
    &soMsgDefHost,
};  
    
PUBLIC CmAbnfElmTypeSeq  soMsgDefTelTspSeq =
{   
    2,
    soMsgDefTelTspSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefTelTsp =
{   
#ifdef  CM_ABNF_DBG
    "SIP TEL TSP ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 402,
    sizeof(TknStrOSXL),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefTelTspSeq,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefTelRnEnum =
{
    (Data *)"rn",
    SO_TEL_RN
};

PUBLIC CmAbnfElmDef  soMsgDefTelRnEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP TEL RN ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 403,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefTelRnEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeRange  soMsgDefTelRnRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  soMsgDefTelRnVal =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL RN VAL ",
    "soRegExpTelPhoneContext",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 404,
    sizeof (TknStrOSXL),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_OCTSTRXL,
    (U8 *) &soMsgDefTelRnRange,
    soRegExpTelPhoneContext
};

PUBLIC CmAbnfElmDef  *soMsgDefTelRnSeqElmnts[] =
{
    &soMsgDefMetaEqualStr,
    &soMsgDefTelRnVal,
};  

PUBLIC CmAbnfElmTypeSeq  soMsgDefTelRnSeq =
{
    2,
    soMsgDefTelRnSeqElmnts
};  

PUBLIC CmAbnfElmDef  soMsgDefTelRn =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL RN ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 405,
    sizeof(TknStrOSXL),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefTelRnSeq,
    NULLP
};  

PUBLIC CmAbnfElmTypeEnum  soMsgDefTelNpdiEnum =
{
    (Data *)"npdi",
    SO_TEL_NPDI
};

PUBLIC CmAbnfElmDef  soMsgDefTelNpdiEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP TEL NPDI ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 406,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefTelNpdiEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefTelCicEnum =
{
    (Data *)"cic",
    SO_TEL_CIC
};

PUBLIC CmAbnfElmDef  soMsgDefTelCicEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP TEL CIC ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 407,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefTelCicEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeRange  soMsgDefTelCicRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  soMsgDefTelCicVal =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL CIC VAL ",
    "soRegExpTelPhoneContext",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 408,
    sizeof (TknStrOSXL),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_OCTSTRXL,
    (U8 *) &soMsgDefTelCicRange,
    soRegExpTelPhoneContext
};

PUBLIC CmAbnfElmDef  *soMsgDefTelCicSeqElmnts[] =
{
    &soMsgDefMetaEqualStr,
    &soMsgDefTelCicVal,
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefTelCicSeq =
{
    2,
    soMsgDefTelCicSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefTelCic =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL CIC ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 409,
    sizeof(TknStrOSXL),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefTelCicSeq,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefTelExtnEnum =
{
    (Data *)"",
    SO_TEL_EXTN
};

PUBLIC CmAbnfElmDef  soMsgDefTelExtnEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP TEL EXTN ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 410,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefTelExtnEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefTelNumParChcEnum[] =
{
    NULLP,
    &soMsgDefTelIsubEnumDef,
    &soMsgDefTelPostdEnumDef,
    &soMsgDefTelPhoneContextEnumDef,
    &soMsgDefTelTspEnumDef,
    &soMsgDefTelRnEnumDef,
    &soMsgDefTelNpdiEnumDef,
    &soMsgDefTelCicEnumDef,
    &soMsgDefTelExtnEnumDef,
};

PUBLIC CmAbnfElmDef  *soMsgDefTelNumParChcElmnt[] =
{
    NULLP,
    &soMsgDefTelIsub,
    &soMsgDefTelPostd,
    &soMsgDefTelPhoneContext,
    &soMsgDefTelTsp,
    &soMsgDefTelRn,
    NULLP,
    &soMsgDefTelCic,
    &soMsgDefGenericParam,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefTelNumParChc =
{
    9,
    0,
    NULLP,
    soMsgDefTelNumParChcElmnt,
    soMsgDefTelNumParChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefTelNumPar =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL NUM PAR ",
    "soRegExpTelNumPar",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 411,
    sizeof(SoTelNumPar),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soMsgDefTelNumParChc,
    soRegExpTelNumPar
};

PUBLIC CmAbnfElmDef  *soMsgDefTelNumParsSeqOfElmnts[] =
{
    &soMsgDefMetaSemiColonStr,
    &soMsgDefTelNumPar
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefTelNumParsSeqOf =
{
    0,
    SO_MAX_TELNUMPARS,
    2,
    soMsgDefTelNumParsSeqOfElmnts,
    sizeof (SoTelNumPar)
};

/* so007.201: Use soRegExpUrlParameters to treat
 * tag param in special way */
PUBLIC CmAbnfElmDef  soMsgDefTelNumPars =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL NUM PARS ",
    "soRegExpMetaSemiColon",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 412,
    sizeof(SoTelNumPars),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQOF,
    (U8 *) &soMsgDefTelNumParsSeqOf,
    soRegExpUrlParameters
};

PUBLIC CmAbnfElmTypeRange  soMsgDefTelLocNumRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  soMsgDefTelLocNum =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL LOC NUM ",
    "soRegExpTelLocNum",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 413,
    sizeof (TknStrOSXL),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_OCTSTRXL,
    (U8 *) &soMsgDefTelLocNumRange,
    soRegExpTelLocNum
};

PUBLIC CmAbnfElmDef  *soMsgDefTelLocalSeqElmnts[] =
{
    &soMsgDefTelLocNum,
    &soMsgDefTelNumPars
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefTelLocalSeq =
{
    2,
    soMsgDefTelLocalSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefTelLocal =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL LOCAL ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 414,
    sizeof(TknStrOSXL) + sizeof(SoTelNumPars),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefTelLocalSeq,
    NULLP
};

PUBLIC CmAbnfElmTypeRange  soMsgDefTelGlobNumRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  soMsgDefTelGlobNum =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL GLOB NUM ",
    "soRegExpTelNum",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 415,
    sizeof (TknStrOSXL),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_OCTSTRXL,
    (U8 *) &soMsgDefTelGlobNumRange,
    soRegExpTelNum
};

PUBLIC CmAbnfElmDef  *soMsgDefTelGlobalSeqElmnts[] =
{
    &soMsgDefTelGlobNum,
    &soMsgDefTelNumPars
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefTelGlobalSeq =
{
    2,
    soMsgDefTelGlobalSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefTelGlobal =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL GLOBAL ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 416,
    sizeof(TknStrOSXL) + sizeof(SoTelNumPars),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefTelGlobalSeq,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefTelGlobalEnum =
{
    (Data *)"+",
    SO_TEL_GLOBAL
};

PUBLIC CmAbnfElmDef  soMsgDefTelGlobalEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP TEL GLOBAL ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 417,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefTelGlobalEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefTelLocalEnum =
{
    (Data *)"",
    SO_TEL_LOCAL
};

PUBLIC CmAbnfElmDef  soMsgDefTelLocalEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP TEL LOCAL ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 418,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefTelLocalEnum,
    NULLP
};

/********************************************************
TelSubscriberStr  -  Enum for Tel Subscriber
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefTelSubscriberStrEnum =
{
   NULLP,
   SO_USERTYPE_TELEPHONESUBSCRIBER
};

PUBLIC CmAbnfElmDef soMsgDefTelSubscriberStr =
{
#ifdef CM_ABNF_DBG
   "SO TELSUBSCRIBERSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 419,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefTelSubscriberStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefTelSubscriberChcEnum[] =
{
   NULLP,
   &soMsgDefTelGlobalEnumDef,
   &soMsgDefTelLocalEnumDef,
};

PUBLIC CmAbnfElmDef  *soMsgDefTelSubscriberChcElmnt[] =
{
    NULLP,
    &soMsgDefTelGlobal,
    &soMsgDefTelLocal,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefTelSubscriberChc =
{
    3,
    0,
    NULLP,
    soMsgDefTelSubscriberChcElmnt,
    soMsgDefTelSubscriberChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefTelSubscriber =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL SUBSCRIBER ",
    "soRegExpTelUrl",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 420,
    sizeof(SoTelUrl),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soMsgDefTelSubscriberChc,
    soRegExpTelUrl
};

PUBLIC CmAbnfElmDef  *soMsgDefTelUrlSeqElmnts[] =
{
    &cmMsgDefMetaColon,
    &soMsgDefTelSubscriber
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefTelUrlSeq =
{
    2,
    soMsgDefTelUrlSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefTelUrl =
{
#ifdef  CM_ABNF_DBG
    "SIP TEL URL ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 421,
    sizeof(SoTelUrl),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefTelUrlSeq,
    NULLP
};
#endif /* SO_ENUM */

#ifdef SO_INSTMSG
/********************************************************
ImUrl   -  Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefImUrlSeqElmnt[] =
{
   &cmMsgDefMetaColon,
   &soMsgDefUserInfo,
   &soMsgDefHostPort,
   &soMsgDefUrlParametersTopic,
   &soMsgDefHeaders
};

PUBLIC CmAbnfElmTypeSeq soMsgDefImUrlSeq =
{
   5,
   soMsgDefImUrlSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefImUrl =
{
#ifdef CM_ABNF_DBG
   "SO TELURL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 422,
   sizeof(SoSipUrl),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefImUrlSeq,
   NULLP
};
#endif /* SO_INSTMSG */

/********************************************************
SipUrl   -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefSipUrlSeqElmnt[] =
{
   &cmMsgDefMetaColon,
   &soMsgDefUserInfo,
   &soMsgDefHostPort,
   &soMsgDefUrlParametersTopic,
   &soMsgDefHeaders
};

PUBLIC CmAbnfElmTypeSeq soMsgDefSipUrlSeq =
{
   5,
   soMsgDefSipUrlSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefSipUrl =
{
#ifdef CM_ABNF_DBG
   "SO SIPURL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 423,
   sizeof(SoSipUrl),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefSipUrlSeq,
   NULLP
};

#ifdef SO_TLS
/********************************************************
Sips Url   -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefSipsUrlSeqElmnt[] =
{
   &cmMsgDefMetaColon,
   &soMsgDefUserInfo,
   &soMsgDefHostPort,
   &soMsgDefUrlParametersTopic,
   &soMsgDefHeaders
};

PUBLIC CmAbnfElmTypeSeq soMsgDefSipsUrlSeq =
{
   5,
   soMsgDefSipsUrlSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefSipsUrl =
{
#ifdef CM_ABNF_DBG
   "SO SIPS URL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 424,
   sizeof(SoSipUrl),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefSipsUrlSeq,
   NULLP
};
#endif

/********************************************************
AbsoluteUri -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAbsoluteUriSeqElmnt[] =
{
   &soMsgDefScheme,
   &soMsgDefMetaColonStr,
   &soMsgDefAbsUriDesc
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAbsoluteUriSeq =
{
   3,
   soMsgDefAbsoluteUriSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAbsoluteUri =
{
#ifdef CM_ABNF_DBG
   "SO ABSOLUTEURI",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 425,
   sizeof(SoAbsoluteUri),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefAbsoluteUriSeq,
   NULLP
};

/********************************************************
ContactParam   -  Type of Contact Parameter  -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContactParamChoiceEnum[] =
{
   NULLP,
   &soMsgDefContactParamStdStr,
#ifdef SO_CALLERPREF
   &soMsgDefContactFeatParamStr,
#else
   &soMsgDefContactExtensionStr,
#endif /* SO_CALLERPREF */
   &soMsgDefContactExtensionStr,
};

PUBLIC CmAbnfElmDef *soMsgDefContactParamChoiceElmnt[] =
{
   NULLP,
   &soMsgDefContactParamStd,
#ifdef SO_CALLERPREF
   &soMsgDefFeatParam,
#else
   &soMsgDefGenericParam,
#endif
   &soMsgDefGenericParam,
};

PUBLIC CmAbnfElmTypeChoice soMsgDefContactParamChoice =
{
   4,
   0,
   NULLP,
   soMsgDefContactParamChoiceElmnt,
   soMsgDefContactParamChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefContactParam =
{
#ifdef CM_ABNF_DBG
   "SO CONTACTPARAM",
   "SORE_CONTACTPARAMCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 426,
   sizeof(SoContactParam),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefContactParamChoice,
   soRegExpContactParamChoice
};

/********************************************************
Branch   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefBranchSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeq soMsgDefBranchSeq =
{
   4,
   soMsgDefBranchSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefBranch =
{
#ifdef CM_ABNF_DBG
   "SO BRANCH",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 427,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefBranchSeq,
   NULLP
};


/********************************************************
Parameter   -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefMediaParameterSeqElmnt[] =
{
   &soMsgDefToken,
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefValue
};

PUBLIC CmAbnfElmTypeSeq soMsgDefMediaParameterSeq =
{
   5,
   soMsgDefMediaParameterSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefMediaParameter =
{
#ifdef CM_ABNF_DBG
   "SO PARAMETER",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 428,
   sizeof(SoParameter),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefMediaParameterSeq,
   NULLP
};

/********************************************************
AddrSpecReqUri -  Address Spec / Request URI  
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAddrSpecChoiceEnum[] =
{
   NULLP,
   &soMsgDefSipUrlStr,

#ifdef SO_TLS
   &soMsgDefSipsUrlStr,
#else
   &soMsgDefAbsoluteUriStr,
#endif /* SO_TLS */

#ifdef SO_ENUM                    
   &soMsgDefTelUrlStr, 
#else
   &soMsgDefAbsoluteUriStr,
#endif /* SO_ENUM */

#ifdef SO_INSTMSG
   &soMsgDefImUrlStr,
#else
   &soMsgDefAbsoluteUriStr,
#endif /* SO_INSTMSG */

   &soMsgDefAbsoluteUriStr,
};

PUBLIC CmAbnfElmDef *soMsgDefAddrSpecChoiceElmnt[] =
{
   NULLP,
   &soMsgDefSipUrl,

#ifdef SO_TLS
   &soMsgDefSipsUrl,
#else
   &soMsgDefAbsoluteUri,
#endif /* SO_TLS */

#ifdef SO_ENUM
   &soMsgDefTelUrl,
#else
   &soMsgDefAbsoluteUri,
#endif /* SO_ENUM */

#ifdef SO_INSTMSG
   &soMsgDefImUrl,
#else
   &soMsgDefAbsoluteUri,
#endif /* SO_INSTMSG */

   &soMsgDefAbsoluteUri,
};

PUBLIC CmAbnfElmTypeChoice soMsgDefAddrSpecChoice =
{
   6,
   0,
   NULLP,
   soMsgDefAddrSpecChoiceElmnt,
   soMsgDefAddrSpecChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefAddrSpec =
{
#ifdef CM_ABNF_DBG
   "SO ADDRSPECR",
   "SORE_ADDRSPEC",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 429,
   sizeof(SoAddrSpec),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefAddrSpecChoice,
   soRegExpAddrSpec
};

/********************************************************
HandlingParmValStd   -  Type of Standard Handling Param
   -  Choice
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefHandlingParmValstdChoiceEnum[] =
{
   NULLP,
   &soMsgDefOptionalStr,
   &soMsgDefRequiredStr
};


PUBLIC CmAbnfElmTypeChoice soMsgDefHandlingParmValstdChoice =
{
   3,
   0,
   NULLP,
   NULLP,
   soMsgDefHandlingParmValstdChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefHandlingParmValstd =
{
#ifdef CM_ABNF_DBG
   "SO HANDLINGPARMVALSTD",
   "SORE_HANDLINGPARMVALSTDCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 430,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefHandlingParmValstdChoice,
   soRegExpHandlingParmValstdChoice
};

/********************************************************
TypeStar -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefTypeStarSeqElmnt[] =
{
   &soMsgDefToken,
   &soMsgDefMetaForwardSlashStr,
   &soMsgDefMetaStarStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefTypeStarSeq =
{
   3,
   soMsgDefTypeStarSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefTypeStar =
{
#ifdef CM_ABNF_DBG
   "SO TYPESTAR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 431,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefTypeStarSeq,
   NULLP
};

/********************************************************
TypeSub  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefTypeSubSeqElmnt[] =
{
   &soMsgDefToken,
   &soMsgDefMetaForwardSlashStr,
   &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeq soMsgDefTypeSubSeq =
{
   3,
   soMsgDefTypeSubSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefTypeSub =
{
#ifdef CM_ABNF_DBG
   "SO TYPESUB",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 432,
   sizeof(SoTypeSub),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefTypeSubSeq,
   NULLP
};

/********************************************************
GenericParams  -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefGenericParamsSeqOfElmnt[] =
{
   &soMsgDefMetaSemiColonStr,
   &soMsgDefGenericParam
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefGenericParamsSeqOf =
{
   0,
   SO_MAX_GENERICPARAMS,
   2,
   soMsgDefGenericParamsSeqOfElmnt,
   sizeof(SoParameter)
};


PUBLIC CmAbnfElmDef soMsgDefGenericParams =
{
#ifdef CM_ABNF_DBG
   "SO GENERICPARAMS",
   "SORE_METASEMICOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 433,
   sizeof(SoParameters),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefGenericParamsSeqOf,
   soRegExpMetaSemiColon
};


/********************************************************
ContentCodingCh   -  Type of Content Coding  -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContentCodingChChoiceEnum[] =
{
   NULLP,
   &soMsgDefGzipStr,
   &soMsgDefCompressStr,
   &soMsgDefDeflateStr,
   &soMsgDefIdentityStr
};


PUBLIC CmAbnfElmTypeChoice soMsgDefContentCodingChChoice =
{
   5,
   0,
   NULLP,
   NULLP,
   soMsgDefContentCodingChChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefContentCodingCh =
{
#ifdef CM_ABNF_DBG
   "SO CONTENTCODINGCH",
   "SORE_CONTENTCODINGCHCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 434,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefContentCodingChChoice,
   soRegExpContentCodingChChoice
};

/********************************************************
InfoParam   -  Type of Info Parameter  -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefInfoParamChoiceEnum[] =
{
   NULLP,
   &soMsgDefPurposeStr,
   &soMsgDefInfoParExtnStr
};

PUBLIC CmAbnfElmDef *soMsgDefInfoParamChoiceElmnt[] =
{
   NULLP,
   &soMsgDefCallInfoPurposeList,
   &soMsgDefGenericParam
};


PUBLIC CmAbnfElmTypeChoice soMsgDefInfoParamChoice =
{
   3,
   0,
   NULLP,
   soMsgDefInfoParamChoiceElmnt,
   soMsgDefInfoParamChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefInfoParam =
{
#ifdef CM_ABNF_DBG
   "SO INFOPARAM",
   "SORE_INFOPARAMCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 435,
   sizeof(SoInfoParam),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefInfoParamChoice,
   soRegExpInfoParamChoice
};

/********************************************************
NameAddr -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefNameAddrSeqElmnt[] =
{
   &soMsgDefDisplayName,
   &soMsgDefMetaSws,
   &soMsgDefMetaLeftAngleBracketStr,
   &soMsgDefMetaSws,
   &soMsgDefAddrSpec,
   &soMsgDefMetaSws,
   &soMsgDefMetaRightAngleBracketStr,
   &soMsgDefMetaSws,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefNameAddrSeq =
{
   8,
   soMsgDefNameAddrSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefNameAddr =
{
#ifdef CM_ABNF_DBG
   "SO NAMEADDR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 436,
   sizeof(SoNameAddr),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefNameAddrSeq,
   NULLP
};

/********************************************************
ContactParams  -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContactParamsSeqOfElmnt[] =
{
   &soMsgDefMetaSemiColonStr,
   &soMsgDefContactParam,
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefContactParamsSeqOf =
{
   0,
   SO_MAX_CONTACTPARAMS,
   2,
   soMsgDefContactParamsSeqOfElmnt,
   sizeof(SoContactParam)
};


PUBLIC CmAbnfElmDef soMsgDefContactParams =
{
#ifdef CM_ABNF_DBG
   "SO CONTACTPARAMS",
   "SORE_CONTACTPARAMS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 437,
   sizeof(SoContactParams),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefContactParamsSeqOf,
   soRegExpMetaSemiColon
};

/********************************************************
TagParameter   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefTagParameterSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeq soMsgDefTagParameterSeq =
{
   4,
   soMsgDefTagParameterSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefTagParameter =
{
#ifdef CM_ABNF_DBG
   "SO TAGPARAMETER",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 438,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefTagParameterSeq,
   NULLP
};

/********************************************************
ProtocolExt -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefProtocolExtSeqElmnt[] =
{
   &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeq soMsgDefProtocolExtSeq =
{
   1,
   soMsgDefProtocolExtSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefProtocolExt =
{
#ifdef CM_ABNF_DBG
   "SO PROTOCOLEXT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 439,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefProtocolExtSeq,
   NULLP
};


/********************************************************
TransportStd   -  Type of Standard Transport -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefTransportStdChoiceEnum[] =
{
   NULLP,
   &soMsgDefUdpStr,
   &soMsgDefTcpStr,
   &soMsgDefSctpStr,
   &soMsgDefTlsStr,
};


PUBLIC CmAbnfElmTypeChoice soMsgDefTransportStdChoice =
{
   5,
   0,
   NULLP,
   NULLP,
   soMsgDefTransportStdChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefTransportStd =
{
#ifdef CM_ABNF_DBG
   "SO TRANSPORTSTD",
   "SORE_TRANSPORTSTDCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 440,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefTransportStdChoice,
   soRegExpTransportStdChoice
};

/********************************************************
TransportExt   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefTransportExtSeqElmnt[] =
{
   &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeq soMsgDefTransportExtSeq =
{
   1,
   soMsgDefTransportExtSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefTransportExt =
{
#ifdef CM_ABNF_DBG
   "SO TRANSPORTEXT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 441,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefTransportExtSeq,
   NULLP
};


/********************************************************
ViaMaddr -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefViaMaddrSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefHost
};

PUBLIC CmAbnfElmTypeSeq soMsgDefViaMaddrSeq =
{
   4,
   soMsgDefViaMaddrSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefViaMaddr =
{
#ifdef CM_ABNF_DBG
   "SO VIAMADDR",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 442,
   sizeof(SoHost),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefViaMaddrSeq,
   NULLP
};


/********************************************************
AddrType  -  Type of Addr
Choice between (IPv4address / IPv6address)
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAddrTypeChoiceEnum[] =
{
   NULLP,
   NULLP,
   &soMsgDefIpv4AddressStr,
   &soMsgDefIpv6ReferenceStr
};

PUBLIC CmAbnfElmDef *soMsgDefAddrTypeChoiceElmnt[] =
{
   NULLP,
   NULLP,
   &soMsgDefIpv4Address,
   &soMsgDefIpv6Address,
};


PUBLIC CmAbnfElmTypeChoice soMsgDefAddrTypeChoice =
{
   4,
   0,
   NULLP,
   soMsgDefAddrTypeChoiceElmnt,
   soMsgDefAddrTypeChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefAddrType =
{
#ifdef CM_ABNF_DBG
   "SO ADDR_TYPE",
   "SORE_ADDRTYPECHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 443,
   sizeof(SoHost),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefAddrTypeChoice,
   soRegExpAddrTypeChoice
};

/********************************************************
ViaReceived -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefViaReceivedSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefAddrType,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefViaReceivedSeq =
{
   4,
   soMsgDefViaReceivedSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefViaReceived =
{
#ifdef CM_ABNF_DBG
   "SO VIARECEIVED",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 444,
   sizeof(SoHost),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefViaReceivedSeq,
   NULLP
};


/********************************************************
ViaParam -  Type of Via Parameter   -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefViaParamChoiceEnum[] =
{
   NULLP,
   &soMsgDefViaTtlStr,
   &soMsgDefViaMaddrStr,
   &soMsgDefReceivedStr,
   &soMsgDefBranchStr,
#ifdef SO_NAT
   &soMsgDefViaRportStr, 
#else
   &soMsgDefViaExtensionStr,
#endif /* SO_NAT */

   &soMsgDefViaCompStr, 
   &soMsgDefViaExtensionStr
};

PUBLIC CmAbnfElmDef *soMsgDefViaParamChoiceElmnt[] =
{
   NULLP,
   &soMsgDefTtlList,
   &soMsgDefViaMaddr,
   &soMsgDefViaReceived,
   &soMsgDefBranch,
#ifdef SO_NAT
   &soMsgDefViaRport,
#else
   &soMsgDefGenericParam,
#endif /* SO_NAT */

   &soMsgDefComp,
   &soMsgDefGenericParam
};


PUBLIC CmAbnfElmTypeChoice soMsgDefViaParamChoice =
{
   8, 
   0,
   NULLP,
   soMsgDefViaParamChoiceElmnt,
   soMsgDefViaParamChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefViaParam =
{
#ifdef CM_ABNF_DBG
   "SO VIAPARAM",
   "SORE_VIAPARAMCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 445,
   sizeof(SoViaParam),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefViaParamChoice,
   soRegExpViaParamChoice
};


/********************************************************
ViaParamList   -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefViaParamListSeqElmnt[] =
{
   &soMsgDefViaParam,
   &soMsgDefSkipLinewrap
};

PUBLIC CmAbnfElmTypeSeq soMsgDefViaParamListSeq =
{
   2,
   soMsgDefViaParamListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefViaParamList =
{
#ifdef CM_ABNF_DBG
   "SO VIAPARAMLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 446,
   sizeof(SoViaParam),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefViaParamListSeq,
   NULLP
};

/********************************************************
HandlingParmVal   -  Type of Handling Parameter -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefHandlingParmValChoiceEnum[] =
{
   NULLP,
   &soMsgDefHandlingParmValstdStr,
   &soMsgDefOtherHandlingStr
};

PUBLIC CmAbnfElmDef *soMsgDefHandlingParmValChoiceElmnt[] =
{
   NULLP,
   &soMsgDefHandlingParmValstd,
   &soMsgDefToken
};


PUBLIC CmAbnfElmTypeChoice soMsgDefHandlingParmValChoice =
{
   3,
   0,
   NULLP,
   soMsgDefHandlingParmValChoiceElmnt,
   soMsgDefHandlingParmValChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefHandlingParmVal =
{
#ifdef CM_ABNF_DBG
   "SO HANDLINGPARMVAL",
   "SORE_HANDLINGPARMVALCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 447,
   sizeof(SoExtVal),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefHandlingParmValChoice,
   soRegExpHandlingParmValChoice
};


/********************************************************
HandlingParmValList  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefHandlingParmValListSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefHandlingParmVal
};

PUBLIC CmAbnfElmTypeSeq soMsgDefHandlingParmValListSeq =
{
   4,
   soMsgDefHandlingParmValListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefHandlingParmValList =
{
#ifdef CM_ABNF_DBG
   "SO HANDLINGPARMVALLIST",
   "EMPTY",
#endif   /* CM_BNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 448,
   sizeof(SoExtVal),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefHandlingParmValListSeq,
   NULLP
};

/********************************************************
MediaRangeVal  -  Type of MediaRange   -  Choice
********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefMediaRangeValChoiceEnum[] =
{
   NULLP,
   &soMsgDefAllStarStr,
   &soMsgDefTypeStarStr,
   &soMsgDefTypeSubStr
};

PUBLIC CmAbnfElmDef *soMsgDefMediaRangeValChoiceElmnt[] =
{
   NULLP,
   &soMsgDefAllStar,
   &soMsgDefTypeStar,
   &soMsgDefTypeSub
};


PUBLIC CmAbnfElmTypeChoice soMsgDefMediaRangeValChoice =
{
   4,
   0,
   NULLP,
   soMsgDefMediaRangeValChoiceElmnt,
   soMsgDefMediaRangeValChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefMediaRangeVal =
{
#ifdef CM_ABNF_DBG
   "SO MEDIARANGEVAL",
   "SORE_MEDIARANGEVALCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 449,
   sizeof(SoMediaRangeVal),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefMediaRangeValChoice,
   soRegExpMediaRangeValChoice
};


/********************************************************
Parameters  -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefMediaParametersSeqOfElmnt[] =
{
   &soMsgDefMetaSemiColonStr,
   &soMsgDefMediaParameter,
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefMediaParametersSeqOf =
{
   0,
   SO_MAX_PARAMETERS,
   2,
   soMsgDefMediaParametersSeqOfElmnt,
   sizeof(SoParameter)
};


PUBLIC CmAbnfElmDef soMsgDefMediaParameters =
{
#ifdef CM_ABNF_DBG
   "SO MEDIA PARAMETERS",
   "SORE_PARAMETERS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 450,
   sizeof(SoParameters),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefMediaParametersSeqOf,
   soRegExpParameters
   /* soRegExpMetaSemiColon */
};

/********************************************************
ContentCoding  -  Type of Content Coding  -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContentCodingChoiceEnum[] =
{
   NULLP,
   &soMsgDefContentCodingChStr,
   &soMsgDefExtensionTokenStr
};

PUBLIC CmAbnfElmDef *soMsgDefContentCodingChoiceElmnt[] =
{
   NULLP,
   &soMsgDefContentCodingCh,
   &soMsgDefToken
};


PUBLIC CmAbnfElmTypeChoice soMsgDefContentCodingChoice =
{
   3,
   0,
   NULLP,
   soMsgDefContentCodingChoiceElmnt,
   soMsgDefContentCodingChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefContentCoding =
{
#ifdef CM_ABNF_DBG
   "SO CONTENTCODING",
   "SORE_CONTENTCODINGCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 451,
   sizeof(SoExtVal),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefContentCodingChoice,
   soRegExpContentCodingChoice
};

/********************************************************
ProtocolName   -  Type of Protocol Name   -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefProtocolNameChoiceEnum[] =
{
   NULLP,
   &soMsgDefSIPStr,
   &soMsgDefProtocolExtStr
};

PUBLIC CmAbnfElmDef *soMsgDefProtocolNameChoiceElmnt[] =
{
   NULLP,
   &soMsgDefSIPStrSkip,
   &soMsgDefProtocolExt
};


PUBLIC CmAbnfElmTypeChoice soMsgDefProtocolNameChoice =
{
   3,
   0,
   NULLP,
   soMsgDefProtocolNameChoiceElmnt,
   soMsgDefProtocolNameChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefProtocolName =
{
#ifdef CM_ABNF_DBG
   "SO PROTOCOLNAME",
   "SORE_PROTOCOLNAMECHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 452,
   sizeof(SoProtocolName),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefProtocolNameChoice,
   soRegExpProtocolNameChoice
};


/********************************************************
ProtocolVersion   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefProtocolVersionSeqElmnt[] =
{
   &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeq soMsgDefProtocolVersionSeq =
{
   1,
   soMsgDefProtocolVersionSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefProtocolVersion =
{
#ifdef CM_ABNF_DBG
   "SO PROTOCOLVERSION",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 453,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefProtocolVersionSeq,
   NULLP
};


/********************************************************
Transport   -  Type of Transport -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefTransportChoiceEnum[] =
{
   NULLP,
   &soMsgDefTransportStdStr,
   &soMsgDefTransportExtStr
};

PUBLIC CmAbnfElmDef *soMsgDefTransportChoiceElmnt[] =
{
   NULLP,
   &soMsgDefTransportStd,
   &soMsgDefTransportExt
};


PUBLIC CmAbnfElmTypeChoice soMsgDefTransportChoice =
{
   3,
   0,
   NULLP,
   soMsgDefTransportChoiceElmnt,
   soMsgDefTransportChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefTransport =
{
#ifdef CM_ABNF_DBG
   "SO TRANSPORT",
   "SORE_TRANSPORTCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 454,
   sizeof(SoExtVal),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefTransportChoice,
   soRegExpTransportChoice
};


/********************************************************
ConcealedHost  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefConcealedHostSeqElmnt[] =
{
   &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeq soMsgDefConcealedHostSeq =
{
   1,
   soMsgDefConcealedHostSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefConcealedHost =
{
#ifdef CM_ABNF_DBG
   "SO CONCEALEDHOST",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 455,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefConcealedHostSeq,
   NULLP
};

/********************************************************
AuthParam   -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAuthParamSeqElmnt[] =
{
   &soMsgDefToken,
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefGenericParamOpt
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAuthParamSeq =
{
   5,
   soMsgDefAuthParamSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAuthParam =
{
#ifdef CM_ABNF_DBG
   "SO AUTHPARAM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 456,
   sizeof(SoParameter),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefAuthParamSeq,
   NULLP
};

/********************************************************
MediaRange  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefMediaRangeSeqElmnt[] =
{
   &soMsgDefMediaRangeVal,
   &soMsgDefMediaParameters
};

PUBLIC CmAbnfElmTypeSeq soMsgDefMediaRangeSeq =
{
   2,
   soMsgDefMediaRangeSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefMediaRange =
{
#ifdef CM_ABNF_DBG
   "SO MEDIARANGE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 457,
   sizeof(SoMediaRange),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefMediaRangeSeq,
   NULLP
};

/********************************************************
Codings  -  Type of Coding -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefCodingsChoiceEnum[] =
{
   NULLP,
   &soMsgDefContentCodingStr,
   &soMsgDefStarStr
};

PUBLIC CmAbnfElmDef *soMsgDefCodingsChoiceElmnt[] =
{
   NULLP,
   &soMsgDefContentCoding,
   &soMsgDefMetaStarStrSkip
};


PUBLIC CmAbnfElmTypeChoice soMsgDefCodingsChoice =
{
   3,
   0,
   NULLP,
   soMsgDefCodingsChoiceElmnt,
   soMsgDefCodingsChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefCodings =
{
#ifdef CM_ABNF_DBG
   "SO CODINGS",
   "SORE_CODINGSCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 458,
   sizeof(SoCodings),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefCodingsChoice,
   soRegExpCodingsChoice
};

/********************************************************
CallInfoSeqRep2   -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefCallInfoSeqRep2SeqOfElmnt[] =
{
   &soMsgDefMetaSemiColonStr,
   &soMsgDefInfoParam,
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefCallInfoSeqRep2SeqOf =
{
   0,
   SO_MAX_CALLINFOSEQ,
   2,
   soMsgDefCallInfoSeqRep2SeqOfElmnt,
   sizeof(SoInfoParam)
};


PUBLIC CmAbnfElmDef soMsgDefCallInfoSeqRep2 =
{
#ifdef CM_ABNF_DBG
   "SO CALLINFOSEQREP2",
   "SORE_CALLINFOSEQ",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 459,
   sizeof(SoInfoParams),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefCallInfoSeqRep2SeqOf,
   soRegExpMetaSemiColon
};

/********************************************************
ContactItem -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContactItemSeqElmnt[] =
{
   &soMsgDefAddrCh,
   &soMsgDefContactParams,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefContactItemSeq =
{
   2,
   soMsgDefContactItemSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefContactItem =
{
#ifdef CM_ABNF_DBG
   "SO CONTACTITEM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 460,
   sizeof(SoContactItem),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefContactItemSeq,
   NULLP
};


/********************************************************
AddrParam   -  Type of Address Parameter  -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAddrParamChoiceEnum[] =
{
   NULLP,
   &soMsgDefTagStr,
   &soMsgDefAddrExtnStr
};

PUBLIC CmAbnfElmDef *soMsgDefAddrParamChoiceElmnt[] =
{
   NULLP,
   &soMsgDefTagParameter,
   &soMsgDefGenericParam
};


PUBLIC CmAbnfElmTypeChoice soMsgDefAddrParamChoice =
{
   3,
   0,
   NULLP,
   soMsgDefAddrParamChoiceElmnt,
   soMsgDefAddrParamChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefAddrParam =
{
#ifdef CM_ABNF_DBG
   "SO ADDRPARAM",
   "SORE_ADDRPARAMCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 461,
   sizeof(SoAddrParam),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefAddrParamChoice,
   soRegExpAddrParamChoice
};

/********************************************************
Product  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefProductSeqElmnt[] =
{
   &soMsgDefToken,
   &soMsgDefProductVersion
};

PUBLIC CmAbnfElmTypeSeq soMsgDefProductSeq =
{
   2,
   soMsgDefProductSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefProduct =
{
#ifdef CM_ABNF_DBG
   "SO PRODUCT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 462,
   sizeof(SoNameVal),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefProductSeq,
   NULLP
};

/********************************************************
SentProtocol   -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefSentProtocolSeqElmnt[] =
{
   &soMsgDefProtocolName,
   &soMsgDefMetaForwardSlashStr,
   &soMsgDefProtocolVersion,
   &soMsgDefMetaForwardSlashStr,
   &soMsgDefTransport
};

PUBLIC CmAbnfElmTypeSeq soMsgDefSentProtocolSeq =
{
   5,
   soMsgDefSentProtocolSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefSentProtocol =
{
#ifdef CM_ABNF_DBG
   "SO SENTPROTOCOL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 463,
   sizeof(SoSentProtocol),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefSentProtocolSeq,
   NULLP
};



/********************************************************
 [ COLON port ]  -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefOptColonPortSeqElmnt[] =
{
   &soMsgDefMetaColonStr,
   &soMsgDefPPort
};

PUBLIC CmAbnfElmTypeSeq soMsgDefOptColonPortSeq =
{
   2,
   soMsgDefOptColonPortSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefOptColonPort =
{
#ifdef CM_ABNF_DBG
   "SOTEST PORT",
   "SORE_METACOLONNOSPACE",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 464,
   sizeof(TknU32),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefOptColonPortSeq,
   soRegExpMetaColonLineBreak
};

/********************************************************
host [ COLON port ]
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefHostOptColonPortSeqElmnt[] =
{
   &soMsgDefHost,
   &soMsgDefOptColonPort
};

PUBLIC CmAbnfElmTypeSeq soMsgDefHostOptColonPortSeq =
{
   2,
   soMsgDefHostOptColonPortSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefHostOptColonPort =
{
#ifdef CM_ABNF_DBG
   "SO HOSTPORT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 465,
   sizeof(SoHostPort),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefHostOptColonPortSeq,
   NULLP
};

/********************************************************
SentBy   -  Type of Host   -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefSentByChoiceEnum[] =
{
   NULLP,
   &soMsgDefSentByHostPortStr,
   &soMsgDefConcealedHostStr
};

PUBLIC CmAbnfElmDef *soMsgDefSentByChoiceElmnt[] =
{
   NULLP,
   &soMsgDefHostOptColonPort,
   &soMsgDefConcealedHost
};


PUBLIC CmAbnfElmTypeChoice soMsgDefSentByChoice =
{
   3,
   0,
   NULLP,
   soMsgDefSentByChoiceElmnt,
   soMsgDefSentByChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefSentBy =
{
#ifdef CM_ABNF_DBG
   "SO SENTBY",
   "SORE_SENTBYCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 466,
   sizeof(SoHostPortType),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefSentByChoice,
   soRegExpSentByChoice
};

/********************************************************
ViaParams   -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefViaParamsSeqOfElmnt[] =
{
   &soMsgDefMetaSemiColonStr,
   &soMsgDefViaParamList
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefViaParamsSeqOf =
{
   0,
   SO_MAX_VIAPARAMS,
   2,
   soMsgDefViaParamsSeqOfElmnt,
   sizeof(SoViaParam)
};


PUBLIC CmAbnfElmDef soMsgDefViaParams =
{
#ifdef CM_ABNF_DBG
   "SO VIAPARAMS",
   "SORE_VIAPARAMS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 467,
   sizeof(SoViaParams),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefViaParamsSeqOf,
   soRegExpMetaSemiColon
};

/********************************************************
ViaComment  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefViaCommentSeqElmnt[] =
{
   &soMsgDefComment
};

PUBLIC CmAbnfElmTypeSeq soMsgDefViaCommentSeq =
{
   1,
   soMsgDefViaCommentSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefViaComment =
{
#ifdef CM_ABNF_DBG
   "SO VIACOMMENT",
   "SORE_VIACOMMENT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 468,
   sizeof(TknStrOSXL),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefViaCommentSeq,
   soRegExpViaComment
};


/********************************************************
DispositionParam  -  Type of Disposition Parameter
   -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefDispositionParamChoiceEnum[] =
{
   NULLP,
   &soMsgDefHandlingStr,
   &soMsgDefDispTypeExtnStr
};

PUBLIC CmAbnfElmDef *soMsgDefDispositionParamChoiceElmnt[] =
{
   NULLP,
   &soMsgDefHandlingParmValList,
   &soMsgDefGenericParam
};


PUBLIC CmAbnfElmTypeChoice soMsgDefDispositionParamChoice =
{
   3,
   0,
   NULLP,
   soMsgDefDispositionParamChoiceElmnt,
   soMsgDefDispositionParamChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefDispositionParam =
{
#ifdef CM_ABNF_DBG
   "SO DISPOSITIONPARAM",
   "SORE_DISPOSITIONPARAMCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 469,
   sizeof(SoDispositionParam),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefDispositionParamChoice,
   soRegExpDispositionParamChoice
};

/********************************************************
ChallengeAuthParams  -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefChallengeAuthParamsSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefAuthParam
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefChallengeAuthParamsSeqOf =
{
   1,
   SO_MAX_CHALLENGEAUTHPARAMS,
   2,
   soMsgDefChallengeAuthParamsSeqOfElmnt,
   sizeof(SoParameter)
};

PUBLIC CmAbnfElmDef soMsgDefAuthParamList =
{
#ifdef CM_ABNF_DBG
   "SO CHALLENGEAUTHPARAMS LIST",
   "SORE_COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 470,
   sizeof(SoParameters),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefChallengeAuthParamsSeqOf,
   soRegExpMetaComma
};

PUBLIC CmAbnfElmDef *soMsgDefChallengeAuthParamsSeqElmnt[] =
{
   &soMsgDefAuthParam,
   &soMsgDefAuthParamList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefChallengeAuthParamsSeq =
{
   2,
   soMsgDefChallengeAuthParamsSeqElmnt,
};

PUBLIC CmAbnfElmDef soMsgDefChallengeAuthParams =
{
#ifdef CM_ABNF_DBG
   "SO CHALLENGEAUTHPARAMS",
   "SORE_CHALLENGEAUTHPARAMS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 471,
   sizeof(SoParameters),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefChallengeAuthParamsSeq,
   NULLP
};

/********************************************************
Duration -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefDurationSeqElmnt[] =
{
   &soMsgDefMetaSws ,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws ,
   &soMsgDefDeltaSeconds
};

PUBLIC CmAbnfElmTypeSeq soMsgDefDurationSeq =
{
   4,
   soMsgDefDurationSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefDuration =
{
#ifdef CM_ABNF_DBG
   "SOTEST DURATION",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 472,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefDurationSeq,
   NULLP
};


/********************************************************
RetryParam  -  Type of Retry Parameter -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefRetryParamChoiceEnum[] =
{
   NULLP,
   &soMsgDefDurationStr,
   &soMsgDefRetryParamExtnStr,
};

PUBLIC CmAbnfElmDef *soMsgDefRetryParamChoiceElmnt[] =
{
   NULLP,
   &soMsgDefDuration,
   &soMsgDefGenericParam
};


PUBLIC CmAbnfElmTypeChoice soMsgDefRetryParamChoice =
{
   3,
   0,
   NULLP,
   soMsgDefRetryParamChoiceElmnt,
   soMsgDefRetryParamChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefRetryParam =
{
#ifdef CM_ABNF_DBG
   "SO RETRYPARAM",
   "SORE_RETRYPARAMCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 473,
   sizeof(SoRetryParam),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefRetryParamChoice,
   soRegExpRetryParamChoice
};

/********************************************************
WarnAgent   -  Type of Warn Agent  
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefWarnAgentRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefWarnAgent =
{
#ifdef CM_ABNF_DBG
   "SO WARNAGENT",
   "SORE_WARNAGENT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 474,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefWarnAgentRange,
   soRegExpWarnAgent
};

/**********************************************************
AcceptEncodingOpt2   -  Optional Sequence
***********************************************************/

PUBLIC CmAbnfElmTypeMeta soMsgDefMetaQMeta =
{
   (Data *)"q"
};

PUBLIC CmAbnfElmDef soMsgDefMetaQ =
{
#ifdef CM_ABNF_DBG
   "SO METAQ",
   "SORE_METASPACE",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 475,
   0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaQMeta,
   soRegExpQ
};

PUBLIC CmAbnfElmDef *soMsgDefQEqQValueSeqElmnt[] =
{
   &soMsgDefMetaQ,
   &soMsgDefMetaSws,
   &cmMsgDefMetaEqual,
   &soMsgDefMetaSws,
   &soMsgDefQValue
};

PUBLIC CmAbnfElmTypeSeq soMsgDefQEqQValueSeq =
{
   5,
   soMsgDefQEqQValueSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefQEqQValue =
{
#ifdef CM_ABNF_DBG
   "SO QEqQValue",
   "SOTESTRE_ACCEPTSEQ",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 476,
   sizeof(SoQValue),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefQEqQValueSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum soMsgDefQValStrEnum =
{
   NULLP,
   SO_QVALUE_TYPE
};

PUBLIC CmAbnfElmDef soMsgDefQValStr =
{
#ifdef CM_ABNF_DBG
   "SO FROM TAG",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 477,
    sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefQValStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum soMsgDefGenParStrEnum =
{
   NULLP,
   SO_GENERIC_PARAM_TYPE
};

PUBLIC CmAbnfElmDef soMsgDefGenParStr =
{
#ifdef CM_ABNF_DBG
   "SO FROM TAG",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 478,
    sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefGenParStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *soMsgDefAcceptParamEnum[] =
{
   NULLP,
   &soMsgDefQValStr,
   &soMsgDefGenParStr
};

PUBLIC CmAbnfElmDef *soMsgDefAcceptParamElmnt[] =
{
   NULLP,
   &soMsgDefQEqQValue,
   &soMsgDefGenericParam
};


PUBLIC CmAbnfElmTypeChoice soMsgDefAcceptParamChoice =
{
   3,
   0,
   NULLP,
   soMsgDefAcceptParamElmnt,
   soMsgDefAcceptParamEnum
};

PUBLIC CmAbnfElmDef soMsgDefAcceptParam =
{
#ifdef CM_ABNF_DBG
   "SO PRODCOM",
   "SORE_PRODCOMCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 479,
   sizeof(SoAcceptParam),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefAcceptParamChoice,
   soRegExpQorOther
};

PUBLIC CmAbnfElmDef *soMsgDefAcceptParamsOptSeqOfElmnt[] =
{
   &soMsgDefMetaSws,
   &cmMsgDefMetaSemiColon,
   &soMsgDefMetaSws,
   &soMsgDefAcceptParam
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefAcceptParamsOptSeqOf  =
{
   0,
   SO_MAX_ACCEPT_PARAMS,
   4,
   soMsgDefAcceptParamsOptSeqOfElmnt,
   sizeof(SoAcceptParam)
};

PUBLIC CmAbnfElmDef soMsgDefAcceptParams =
{
#ifdef CM_ABNF_DBG
   "SO ACCEPTENCODINGOPT2",
   "SORE_ACCEPTSEQ",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 480,
   sizeof(SoAcceptParams),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefAcceptParamsOptSeqOf,
   soRegExpMetaSemiColon
};

/********************************************************
AcceptRep   -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAcceptRepSeqElmnt[] =
{
   &soMsgDefMediaRange,
   &soMsgDefAcceptParams,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAcceptRepSeq =
{
   2,
   soMsgDefAcceptRepSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAcceptRep =
{
#ifdef CM_ABNF_DBG
   "SO ACCEPTREP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 481,
   sizeof(SoAcceptSeq),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefAcceptRepSeq,
   NULLP
};


/**********************************************************
AcceptRepList  -  Sequence Of
***********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAcceptRepListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefAcceptRep
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefAcceptRepListSeqOf =
{
   1,
   SO_MAX_ACCEPTLIST,
   2,
   soMsgDefAcceptRepListSeqOfElmnt,
   sizeof(SoAcceptSeq)
};

PUBLIC CmAbnfElmDef soMsgDefAcceptRepList =
{
#ifdef CM_ABNF_DBG
   "SOTEST ACCEPTREPLIST",
   "SOTESTRE_COMMA",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 482,
   sizeof(SoAccept),
   (CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefAcceptRepListSeqOf,
   soRegExpMetaComma
};

/********************************************************
AcceptEncodingRep -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAcceptEncodingRepSeqElmnt[] =
{
   &soMsgDefCodings,
   &soMsgDefAcceptParams,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAcceptEncodingRepSeq =
{
   2,
   soMsgDefAcceptEncodingRepSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAcceptEncodingRep =
{
#ifdef CM_ABNF_DBG
   "SO ACCEPTENCODINGREP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 483,
   sizeof(SoAcceptEncodingSeq),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefAcceptEncodingRepSeq,
   NULLP
};


/********************************************************
AcceptLanguageRep -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAcceptLanguageRepSeqElmnt[] =
{
   &soMsgDefLanguageRange,
   &soMsgDefAcceptParams,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAcceptLanguageRepSeq =
{
   2,
   soMsgDefAcceptLanguageRepSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAcceptLanguageRep =
{
#ifdef CM_ABNF_DBG
   "SO ACCEPTLANGUAGEREP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 484,
   sizeof(SoAcceptLanguageSeq),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefAcceptLanguageRepSeq,
   NULLP
};

/********************************************************
ErrorInfoRep   -  Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefErrorInfoRepSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaLeftAngleBracketStr,
   &soMsgDefAbsoluteUri,
   &soMsgDefMetaRightAngleBracketStr,
   &soMsgDefMetaSws,
   &soMsgDefGenericParams,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefErrorInfoRepSeq =
{
   6,
   soMsgDefErrorInfoRepSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefErrorInfoRep =
{
#ifdef CM_ABNF_DBG
   "SO ErrorInfoRepSeq",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 485,
   sizeof(SoInfoSeq),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefErrorInfoRepSeq,
   NULLP
};


/********************************************************
ErrorInfoList  -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefErrorInfoListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefErrorInfoRep
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefErrorInfoListSeqOf =
{
   0,
   SO_MAX_ERRORINFOLIST,
   2,
   soMsgDefErrorInfoListSeqOfElmnt,
   sizeof(SoInfoSeq)
};

PUBLIC CmAbnfElmDef soMsgDefErrorInfoList =
{
#ifdef CM_ABNF_DBG
   "SO ErrorInfoLIST",
   "soRegExpMetaComma",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 486,
   sizeof(SoInfo),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefErrorInfoListSeqOf,
   soRegExpMetaComma
};


/********************************************************
ErrorInfoItem  -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefErrorInfoItemSeqElmnt[] =
{
   &soMsgDefErrorInfoRep,
   &soMsgDefErrorInfoList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefErrorInfoItemSeq =
{
   2,
   soMsgDefErrorInfoItemSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefErrorInfoItem =
{
#ifdef CM_ABNF_DBG
   "SO ErrorInfoItem",
   "SORE_LeftAngleBracket",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 487,
   sizeof(SoInfo),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefErrorInfoItemSeq,
   NULLP
};


/********************************************************
ErrorInfo   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefErrorInfoSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefErrorInfoItem,
   &soMsgDefMetaCRLFStr,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefErrorInfoSeq =
{
   3,
   soMsgDefErrorInfoSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefErrorInfo =
{
#ifdef CM_ABNF_DBG
   "SO ErrorInfo",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 488,
   sizeof(SoInfo),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefErrorInfoSeq,
   NULLP
};


/********************************************************
ContactItemsList  -  Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefContactItemsListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefContactItem
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefContactItemsListSeqOf =
{
   1,
   SO_MAX_CONTACTITEMS,
   2,
   soMsgDefContactItemsListSeqOfElmnt,
   sizeof(SoContactItem)
};

PUBLIC CmAbnfElmDef soMsgDefContactItemsList =
{
#ifdef CM_ABNF_DBG
   "SOTEST CONTACTITEMSLIST",
   "SOTESTRE_COMMA",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 489,
   sizeof(SoContactItems),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefContactItemsListSeqOf,
   soRegExpMetaComma
};


/**********************************************************
ContactItemsH  -  Optional Sequence Of
***********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContactItemsHSeqElmnt[] =
{
   &soMsgDefContactItem,
   &soMsgDefContactItemsList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefContactItemsHSeq =
{
   2,
   soMsgDefContactItemsHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefContactItemsH =
{
#ifdef CM_ABNF_DBG
   "SO CONTACTITEMS",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 490,
   sizeof(SoContactItems),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefContactItemsHSeq,
   NULLP
};


/********************************************************
ContactItems   -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefContactItemsSeqElmnt[] =
{
   &soMsgDefContactItemsH
};

PUBLIC CmAbnfElmTypeSeq soMsgDefContactItemsSeq =
{
   1,
   soMsgDefContactItemsSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefContactItems =
{
#ifdef CM_ABNF_DBG
   "SOTEST CONTACTITEMS",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 491,
   sizeof(SoContactItems),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefContactItemsSeq,
   NULLP
};


/********************************************************
RecordRouteRep -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefRecordRouteRepSeqElmnt[] =
{
   &soMsgDefNameAddr,
   &soMsgDefGenericParams,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRecordRouteRepSeq =
{
   2,
   soMsgDefRecordRouteRepSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefRecordRouteRep =
{
#ifdef CM_ABNF_DBG
   "SO RECORDROUTEREP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 492,
   sizeof(SoRouteSeq),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefRecordRouteRepSeq,
   NULLP
};

/********************************************************
OptionTagList  -  Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefOptionTagListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefOptionTagListSeqOf =
{
   1,
   SO_MAX_OPTIONTAG,
   2,
   soMsgDefOptionTagListSeqOfElmnt,
   sizeof(TknStrOSXL)
};

PUBLIC CmAbnfElmDef soMsgDefOptionTagList =
{
#ifdef CM_ABNF_DBG
   "SO OPTIONTAGLIST",
   "SORE_AUTHPARAMS",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 493,
   sizeof(TknStrOSXL),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefOptionTagListSeqOf,
   soRegExpMetaComma
};

/*******************************************************
OptionTagH  -  Optional Sequence Of
********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefOptionTagHSeqElmnt[] =
{
   &soMsgDefToken,
   &soMsgDefOptionTagList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefOptionTagHSeq =
{
   2,
   soMsgDefOptionTagHSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefOptionTagH =
{
#ifdef CM_ABNF_DBG
   "SO OPTIONTAGH",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 494,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefOptionTagHSeq,
   NULLP
};

/********************************************************
ProdCom  -  Product|Comment   -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefProdcomChoiceEnum[] =
{
   NULLP,
   &soMsgDefProductStr,
   &soMsgDefCommentStr
};

PUBLIC CmAbnfElmDef *soMsgDefProdcomChoiceElmnt[] =
{
   NULLP,
   &soMsgDefProduct,
   &soMsgDefComment
};


PUBLIC CmAbnfElmTypeChoice soMsgDefProdcomChoice =
{
   3,
   0,
   NULLP,
   soMsgDefProdcomChoiceElmnt,
   soMsgDefProdcomChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefProdcom =
{
#ifdef CM_ABNF_DBG
   "SO PRODCOM",
   "SORE_PRODCOMCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 495,
   sizeof(SoProdcom),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefProdcomChoice,
   soRegExpProdcomChoice
};


/********************************************************
ViaItem  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefViaItemSeqElmnt[] =
{
/*
   &soMsgDefSkipAllSpaceEat,
   &soMsgDefSkipLinewrap,
*/
   &soMsgDefSentProtocol,
   &soMsgDefMetaLws,
/*
   &soMsgDefMetaSpaceStr,
   &soMsgDefSkipLinewrap,
*/
   &soMsgDefSentBy,
/*
   &soMsgDefSkipAllSpaceEat,
   &soMsgDefSkipLinewrap,
*/
   &soMsgDefViaParams,
   &soMsgDefSkipLinewrap,
   &soMsgDefViaComment,
   &soMsgDefSkipLinewrap
};

PUBLIC CmAbnfElmTypeSeq soMsgDefViaItemSeq =
{
   7,
   soMsgDefViaItemSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefViaItem =
{
#ifdef CM_ABNF_DBG
   "SO VIAITEM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 496,
   sizeof(SoViaItem),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefViaItemSeq,
   NULLP
};

/********************************************************
ViaItemList -  Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefViaItemListSeqOfElmnt[] =
{
   &soMsgDefMetaViaParSep,
   &soMsgDefViaItem
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefViaItemListSeqOf =
{
   0,
   SO_MAX_VIA,
   2,
   soMsgDefViaItemListSeqOfElmnt,
   sizeof(SoViaItem)
};

PUBLIC CmAbnfElmDef soMsgDefViaItemList =
{
#ifdef CM_ABNF_DBG
   "SO ViaItemLIST",
   "SORE_COMMA",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 497,
   sizeof(SoVia),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefViaItemListSeqOf,
   soRegExpMetaComma
};

/********************************************************
MediaType   -  Type of ContentType  -  Choice
*********************************************************/

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaTypeTextEnum =
{
    (Data *)"text",
    SO_MEDIA_TYPE_TEXT
};

PUBLIC CmAbnfElmDef  soMsgDefMediaTypeTextEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA TYPE TEXT ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 498,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaTypeTextEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaTypeImageEnum =
{
    (Data *)"image",
    SO_MEDIA_TYPE_IMAGE
};

PUBLIC CmAbnfElmDef  soMsgDefMediaTypeImageEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA TYPE IMAGE ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 499,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaTypeImageEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaTypeAudioEnum =
{
    (Data *)"audio",
    SO_MEDIA_TYPE_AUDIO
};

PUBLIC CmAbnfElmDef  soMsgDefMediaTypeAudioEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA TYPE AUDIO ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 500,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaTypeAudioEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaTypeVideoEnum =
{
    (Data *)"video",
    SO_MEDIA_TYPE_VIDEO
};

PUBLIC CmAbnfElmDef  soMsgDefMediaTypeVideoEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA TYPE VIDEO ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 501,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaTypeVideoEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaTypeApplicationEnum =
{
    (Data *)"application",
    SO_MEDIA_TYPE_APPLICATION
};

PUBLIC CmAbnfElmDef  soMsgDefMediaTypeApplicationEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA TYPE APPLICATION ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 502,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaTypeApplicationEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaTypeMsgEnum =
{
    (Data *)"message",
    SO_MEDIA_TYPE_MESSAGE
};

PUBLIC CmAbnfElmDef  soMsgDefMediaTypeMsgEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA TYPE MSG ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 503,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaTypeMsgEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaTypeMultipartEnum =
{
    (Data *)"multipart",
    SO_MEDIA_TYPE_MULTIPART
};

PUBLIC CmAbnfElmDef  soMsgDefMediaTypeMultipartEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA TYPE MULTIPART ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 504,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaTypeMultipartEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaTypeExtnEnum =
{
    (Data *)"",
    SO_MEDIA_TYPE_EXTN
};

PUBLIC CmAbnfElmDef  soMsgDefMediaTypeExtnEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA TYPE EXTN ENUM",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 505,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaTypeExtnEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefMediaTypeChcEnum[] =
{
   NULLP,
   &soMsgDefMediaTypeTextEnumDef,
   &soMsgDefMediaTypeImageEnumDef,
   &soMsgDefMediaTypeAudioEnumDef,
   &soMsgDefMediaTypeVideoEnumDef,
   &soMsgDefMediaTypeApplicationEnumDef,
   &soMsgDefMediaTypeMsgEnumDef,
   &soMsgDefMediaTypeMultipartEnumDef,
   &soMsgDefMediaTypeExtnEnumDef,
};

PUBLIC CmAbnfElmDef  *soMsgDefMediaTypeChcElmnt[] =
{
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   &soMsgDefToken,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefMediaTypeChc =
{
    9,
    0,
    NULLP,
    soMsgDefMediaTypeChcElmnt,
    soMsgDefMediaTypeChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefMediaType =
{
#ifdef  CM_ABNF_DBG
    "SIP MEDIA TYPE ",
    "soRegExpMediaTypeChoice",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 506,
    sizeof(SoStrValue),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soMsgDefMediaTypeChc,
    soRegExpMediaTypeChoice
};

/********************************************************
MediaSubType   -  Type of SubType   -  Choice
*********************************************************/

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaSubTypeMixedEnum =
{
    (Data *)"mixed",
    SO_MEDIA_SUBTYPE_MIXED
};

PUBLIC CmAbnfElmDef  soMsgDefMediaSubTypeMixedEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA SUB TYPE MIXED ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 507,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaSubTypeMixedEnum,
    NULLP
};

/* so011.201: Change SDP to lowercase */
PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaSubTypeSdpEnum =
{
    (Data *)"sdp",
    SO_MEDIA_SUBTYPE_SDP
};

PUBLIC CmAbnfElmDef  soMsgDefMediaSubTypeSdpEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA SUB TYPE SDP ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 508,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaSubTypeSdpEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaSubTypeIsupEnum =
{
    (Data *)"ISUP",
    SO_MEDIA_SUBTYPE_ISUP
};

PUBLIC CmAbnfElmDef  soMsgDefMediaSubTypeIsupEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA SUB TYPE ISUP ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 509,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaSubTypeIsupEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaSubTypeQsigEnum =
{
    (Data *)"QSIG",
    SO_MEDIA_SUBTYPE_QSIG
};

PUBLIC CmAbnfElmDef  soMsgDefMediaSubTypeQsigEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA SUB TYPE QSIG ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 510,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaSubTypeQsigEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaSubTypeSipFragEnum =
{
    (Data *)"sipfrag", /* so029.201 : changed to small case */
    SO_MEDIA_SUBTYPE_SIPFRAG
};

PUBLIC CmAbnfElmDef  soMsgDefMediaSubTypeSipFragEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA SUB TYPE SIP FRAG ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 511,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaSubTypeSipFragEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaSubTypeSMSEnum =
{
    (Data *)"simple-message-summary",
    SO_MEDIA_SUBTYPE_SMS
};

PUBLIC CmAbnfElmDef  soMsgDefMediaSubTypeSMSEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA SUB TYPE SMS ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 512,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaSubTypeSMSEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMediaSubTypeExtnEnum =
{
    (Data *)"",
    SO_MEDIA_SUBTYPE_EXTN
};

PUBLIC CmAbnfElmDef  soMsgDefMediaSubTypeExtnEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MEDIA SUB TYPE EXTN ENUM",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 513,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMediaSubTypeExtnEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefMediaSubTypeChcEnum[] =
{
   NULLP,
   &soMsgDefMediaSubTypeMixedEnumDef,
   &soMsgDefMediaSubTypeSdpEnumDef,
   &soMsgDefMediaSubTypeIsupEnumDef,
   &soMsgDefMediaSubTypeQsigEnumDef,
   &soMsgDefMediaSubTypeSipFragEnumDef,
   &soMsgDefMediaSubTypeSMSEnumDef,
   &soMsgDefMediaSubTypeExtnEnumDef,
};

PUBLIC CmAbnfElmDef  *soMsgDefMediaSubTypeChcElmnt[] =
{
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   &soMsgDefToken,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefMediaSubTypeChc =
{
    8,
    0,
    NULLP,
    soMsgDefMediaSubTypeChcElmnt,
    soMsgDefMediaSubTypeChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefMediaSubType =
{
#ifdef  CM_ABNF_DBG
    "SIP MEDIA SUB TYPE ",
    "soRegExpMediaSubType",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 514,
    sizeof(SoStrValue),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soMsgDefMediaSubTypeChc,
    soRegExpMediaSubTypeChoice
};

/********************************************************
Challenge   -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefChallengeSeqElmnt[] =
{
   &soMsgDefToken,
   &soMsgDefMetaLws,
   &soMsgDefChallengeAuthParams
};

PUBLIC CmAbnfElmTypeSeq soMsgDefChallengeSeq =
{
   3,
   soMsgDefChallengeSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefChallenge =
{
#ifdef CM_ABNF_DBG
   "SO CHALLENGE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 515,
   sizeof(SoAuthorization),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefChallengeSeq,
   NULLP
};

/********************************************************
WarningItem -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefWarningItemSeqElmnt[] =
{
   &soMsgDefWarnCode,
   &soMsgDefMetaSpaceStr,
   &soMsgDefWarnAgent,
   &soMsgDefMetaSpaceStr,
   &soMsgDefQuotedStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefWarningItemSeq =
{
   5,
   soMsgDefWarningItemSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefWarningItem =
{
#ifdef CM_ABNF_DBG
   "SO WARNINGITEM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 516,
   sizeof(SoWarningItem),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefWarningItemSeq,
   NULLP
};

/********************************************************
AcceptH  -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAcceptHSeqElmnt[] =
{
   &soMsgDefAcceptRep,
   &soMsgDefAcceptRepList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAcceptHSeq =
{
   2,
   soMsgDefAcceptHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAcceptH =
{
#ifdef CM_ABNF_DBG
   "SO ACCEPT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 517,
   sizeof(SoAccept),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefAcceptHSeq,
   /* [RA] soRegExpAcceptH */
   soRegExpNotMetaCRLF
};


/********************************************************
Accept   -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefAcceptSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefAcceptH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAcceptSeq =
{
   3,
   soMsgDefAcceptSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefAccept =
{
#ifdef CM_ABNF_DBG
   "SOTEST ACCEPT",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 518,
   sizeof(SoAccept),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefAcceptSeq,
   NULLP
};


/********************************************************
AcceptEncodingRepList   -  Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefAcceptEncodingRepListSeqOfElmnt[] =
{
   &soMsgDefMetaSws,
   &cmMsgDefMetaComma,
   &soMsgDefMetaSws,
   &soMsgDefAcceptEncodingRep
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefAcceptEncodingRepListSeqOf =
{
   1,
   SO_MAX_ACCEPTENCODINGREPLIST,
   4,
   soMsgDefAcceptEncodingRepListSeqOfElmnt,
   sizeof(SoAcceptEncodingSeq),
};

PUBLIC CmAbnfElmDef soMsgDefAcceptEncodingRepList =
{
#ifdef CM_ABNF_DBG
   "SOTEST ACCEPTENCREPLIST",
   "SOTESTRE_COMMA",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 519,
   sizeof(SoAcceptEncoding),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefAcceptEncodingRepListSeqOf,
   soRegExpMetaComma
};


/********************************************************
AcceptEncodingH   -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAcceptEncodingHSeqElmnt[] =
{
   &soMsgDefAcceptEncodingRep,
   &soMsgDefAcceptEncodingRepList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAcceptEncodingHSeq =
{
   2,
   soMsgDefAcceptEncodingHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAcceptEncodingH =
{
#ifdef CM_ABNF_DBG
   "SO ACCEPTENCODINGH",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 520,
   sizeof(SoAcceptEncoding),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefAcceptEncodingHSeq,
   /* [RA] soRegExpAcceptEncodingH */
   soRegExpNotMetaCRLF
};


/********************************************************
AcceptLanguageRepList   -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAcceptLanguageRepListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefAcceptLanguageRep
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefAcceptLanguageRepListSeqOf =
{
   1,
   SO_MAX_ACCEPTLANGUAGE,
   2,
   soMsgDefAcceptLanguageRepListSeqOfElmnt,
   sizeof(SoAcceptLanguageSeq),
};

PUBLIC CmAbnfElmDef soMsgDefAcceptLanguageRepList =
{
#ifdef CM_ABNF_DBG
   "SOTEST ACCEPTLANGUAGEREPLIST",
   "SOTESTRE_COMMA",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 521,
   sizeof(SoAcceptLanguage),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefAcceptLanguageRepListSeqOf,
   soRegExpMetaComma
};


/********************************************************
AcceptLanguageH   -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAcceptLanguageHSeqElmnt[] =
{
   &soMsgDefAcceptLanguageRep,
   &soMsgDefAcceptLanguageRepList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAcceptLanguageHSeq =
{
   2,
   soMsgDefAcceptLanguageHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAcceptLanguageH =
{
#ifdef CM_ABNF_DBG
   "SO ACCEPTLANGUAGEH",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 522,
   sizeof(SoAcceptLanguage),
   (CM_ABNF_OPTIONAL |CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefAcceptLanguageHSeq,
   soRegExpNotMetaCRLF
};


/********************************************************
CallInfo = "Call-Info:" #( "<" AbsoluteUri ">" *(";" InfoParam) )
InfoParam = CallInfoPurpose | GenericParam
CallInfoPurpose = "purpose=" ("icon" | "info" | " card" | PurposeExt )
PurposeExt = token
*********************************************************/
/********************************************************
CallInfoRep -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefCallInfoRepSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaLeftAngleBracketStr,
   &soMsgDefAbsoluteUri,
   &soMsgDefMetaRightAngleBracketStr,
   &soMsgDefMetaSws,
   &soMsgDefCallInfoSeqRep2
};

PUBLIC CmAbnfElmTypeSeq soMsgDefCallInfoRepSeq =
{
   6,
   soMsgDefCallInfoRepSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefCallInfoRep =
{
#ifdef CM_ABNF_DBG
   "SO CALLINFOREP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 523,
   sizeof(SoCallInfoSeq),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefCallInfoRepSeq,
   NULLP
};


/********************************************************
CallInfoList   -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefCallInfoListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefCallInfoRep
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefCallInfoListSeqOf =
{
   0,
   SO_MAX_CALLINFOLIST,
   2,
   soMsgDefCallInfoListSeqOfElmnt,
   sizeof(SoCallInfoSeq),
};

PUBLIC CmAbnfElmDef soMsgDefCallInfoList =
{
#ifdef CM_ABNF_DBG
   "SO CALLINFOLIST",
   "SORE_COMMA",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 524,
   sizeof(SoCallInfo),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefCallInfoListSeqOf,
   soRegExpMetaComma
};


/********************************************************
CallInfoH   -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefCallInfoHSeqElmnt[] =
{
   &soMsgDefCallInfoRep,
   &soMsgDefCallInfoList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefCallInfoHSeq =
{
   2,
   soMsgDefCallInfoHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefCallInfoH =
{
#ifdef CM_ABNF_DBG
   "SO CALLINFOH",
   "SORE_LEFTANGLEBRACKET",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 525,
   sizeof(SoCallInfo),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefCallInfoHSeq,
   NULLP
};


/********************************************************
CallInfo -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefCallInfoSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefCallInfoH,
   &soMsgDefMetaCRLFStr,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefCallInfoSeq =
{
   3,
   soMsgDefCallInfoSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefCallInfo =
{
#ifdef CM_ABNF_DBG
   "SO CALLINFO",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 526,
   sizeof(SoCallInfo),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefCallInfoSeq,
   NULLP
};

/********************************************************
ContactDesc -  Type of Contact Descriptor -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContactDescChoiceEnum[] =
{
   NULLP,
   &soMsgDefCDMetaStarStr,
   &soMsgDefContactItemsStr
};

PUBLIC CmAbnfElmDef *soMsgDefContactDescChoiceElmnt[] =
{
   NULLP,
   &soMsgDefMetaStarStr,
   &soMsgDefContactItems
};


PUBLIC CmAbnfElmTypeChoice soMsgDefContactDescChoice =
{
   3,
   0,
   NULLP,
   soMsgDefContactDescChoiceElmnt,
   soMsgDefContactDescChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefContactDesc =
{
#ifdef CM_ABNF_DBG
   "SO CONTACTDESC",
   "SORE_CONTACTDESCCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 527,
   sizeof(SoContactItems) + sizeof(TknU8),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefContactDescChoice,
   soRegExpContactDescChoice
};

/********************************************************
AddrCh   -  NameAddr|AddrSpec -  Choice
*********************************************************/


PUBLIC CmAbnfElmDef *soMsgDefAddrChChoiceEnum[] =
{
   NULLP,
   &soMsgDefNameAddrStr,
   &soMsgDefAddrSpecStr,
};

PUBLIC CmAbnfElmDef *soMsgDefAddrChChoiceElmnt[] =
{
   NULLP,
   &soMsgDefNameAddr,
   &soMsgDefAddrSpec,
};


PUBLIC CmAbnfElmTypeChoice soMsgDefAddrChChoice =
{
   3,
   0,
   NULLP,
   soMsgDefAddrChChoiceElmnt,
   soMsgDefAddrChChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefAddrCh =
{
#ifdef CM_ABNF_DBG
   "SO ADDRCH",
   "SORE_ADDRCHCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 528,
   sizeof(SoAddrCh),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefAddrChChoice,
   soRegExpAddrChChoice
};

/********************************************************
Also = "Also" ":" 1# AddrCh
AddrCh = ( NameAddr | AddrSpec )
*********************************************************/
/********************************************************
AlsoRep  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAlsoRepSeqElmnt[] =
{
   &soMsgDefSkipLinewrap,
   &soMsgDefAddrCh,
   &soMsgDefSkipLinewrap
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAlsoRepSeq =
{
   3,
   soMsgDefAlsoRepSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAlsoRep =
{
#ifdef CM_ABNF_DBG
   "SO ALSOSEQ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 529,
   sizeof(SoAddrCh),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefAlsoRepSeq,
   NULLP
};


/********************************************************
AlsoRepList -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAlsoRepListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefAlsoRep
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefAlsoRepListSeqOf =
{
   0,
   SO_MAX_ALSOADDR,
   2,
   soMsgDefAlsoRepListSeqOfElmnt,
   sizeof(SoAddrCh)
};

PUBLIC CmAbnfElmDef soMsgDefAlsoRepList =
{
#ifdef CM_ABNF_DBG
   "SOTEST ALSOREPLIST",
   "SOTESTRE_COMMA",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 530,
   sizeof(SoAddrCh),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefAlsoRepListSeqOf,
   soRegExpMetaComma
};


/********************************************************
AlsoH -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAlsoHSeqElmnt[] =
{
   &soMsgDefAlsoRep,
   &soMsgDefAlsoRepList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAlsoHSeq =
{
   2,
   soMsgDefAlsoHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAlsoH =
{
#ifdef CM_ABNF_DBG
   "SO ALSO",
   "SORE_ALSO",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 531,
   sizeof(SoAlso),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefAlsoHSeq,
   NULLP
};


/********************************************************
Also  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAlsoSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefAlsoH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAlsoSeq =
{
   3,
   soMsgDefAlsoSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAlso =
{
#ifdef CM_ABNF_DBG
   "SO ALSO",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 532,
   sizeof(SoAlso),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefAlsoSeq,
   NULLP
};


/********************************************************
AddrParams  -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAddrParamsSeqOfElmnt[] =
{
   &soMsgDefMetaSemiColonStr,
   &soMsgDefAddrParam,
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefAddrParamsSeqOf =
{
   0,
   SO_MAX_ADDRPARAMS,
   2,
   soMsgDefAddrParamsSeqOfElmnt,
   sizeof(SoAddrParam)
};


PUBLIC CmAbnfElmDef soMsgDefAddrParams =
{
#ifdef CM_ABNF_DBG
   "SO ADDRPARAMS",
   "SORE_ADDRPARAMS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 533,
   sizeof(SoAddrParams),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefAddrParamsSeqOf,
   soRegExpAddrParams
};

/********************************************************
MimeVersionList   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefMimeVersionListSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefMimeVersionVal,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefMimeVersionListSeq =
{
   3,
   soMsgDefMimeVersionListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefMimeVersionList =
{
#ifdef CM_ABNF_DBG
   "SO MIMEVERSIONLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 534,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefMimeVersionListSeq,
   NULLP
};


/********************************************************
RecordRouteRepList   -  Sequence Of
*********************************************************/

/********************************************************
MetaRecordRouteParSep  - Encode rec-params in multiple 
Record-Route headers 
*********************************************************/
   
PUBLIC CmAbnfElmTypeMeta soMsgDefMetaRecordRouteParSepMeta =
{  
   (Data *)"\r\nRecord-Route:"
}; 

PUBLIC CmAbnfElmDef soMsgDefMetaRecordRouteParSep =
{
#ifdef CM_ABNF_DBG
   "SO METACOMMASTR",
   "SORE_METACOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 535,
  0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaRecordRouteParSepMeta,
   soRegExpMetaComma
}; 

PUBLIC CmAbnfElmDef *soMsgDefRecordRouteRepListSeqOfElmnt[] =
{
   &soMsgDefMetaRecordRouteParSep,
   &soMsgDefRecordRouteRep
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefRecordRouteRepListSeqOf =
{
   1,
   SO_MAX_RECORDROUTELIST,
   2,
   soMsgDefRecordRouteRepListSeqOfElmnt,
   sizeof(SoRouteSeq)
};

PUBLIC CmAbnfElmDef soMsgDefRecordRouteRepList =
{
#ifdef CM_ABNF_DBG
   "SO RECORDROUTELIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 536,
   sizeof(SoRoute),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefRecordRouteRepListSeqOf,
   soRegExpMetaComma
};

#ifdef SO_EVENT

/********************************************************
AllowEvents   -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAllowEventsRepListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefAllowEventsRepListSeqOf =
{
   1,  
   SO_MAX_ALLOW,  
   2, 
   soMsgDefAllowEventsRepListSeqOfElmnt,
   sizeof(TknStrOSXL)
};

PUBLIC CmAbnfElmDef soMsgDefAllowEventsRepList =
{
#ifdef CM_ABNF_DBG
   "SO ALLOW EVENTS",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 537,
   sizeof(SoTknStrOSXLLst),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefAllowEventsRepListSeqOf,
   soRegExpMetaComma
};
#endif /* SO_EVENT */

/********************************************************
RecordRouteH   -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefRecordRouteHSeqElmnt[] =
{
   &soMsgDefRecordRouteRep,
   &soMsgDefRecordRouteRepList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRecordRouteHSeq =
{
   2,
   soMsgDefRecordRouteHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefRecordRouteH =
{
#ifdef CM_ABNF_DBG
   "SO RECORDROUTEH",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 538,
   sizeof(SoRoute),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefRecordRouteHSeq,
   NULLP
};


#ifdef SO_EVENT
/********************************************************
RecordRouteH   -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAllowEventsHSeqElmnt[] =
{
   &soMsgDefToken,
   &soMsgDefAllowEventsRepList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAllowEventsHSeq =
{
   2,
   soMsgDefAllowEventsHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAllowEventsH =
{
#ifdef CM_ABNF_DBG
   "SO ALLOWEVENTSH",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 539,
   sizeof(SoTknStrOSXLLst),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefAllowEventsHSeq,
   NULLP
};

#endif /* SO_EVENT */
/**********************************************************
RecordRoute -  Optional Sequence
***********************************************************/


PUBLIC CmAbnfElmDef *soMsgDefRecordRouteSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefRecordRouteH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRecordRouteSeq =
{
   3,
   soMsgDefRecordRouteSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefRecordRoute =
{
#ifdef CM_ABNF_DBG
   "SO RECORDROUTE",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 540,
   sizeof(SoRoute),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefRecordRouteSeq,
   NULLP
};

/*******************************************************
DelayFrac   -  Optional Sequence
********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefDelayFracSeqElmnt[] =
{
   &soMsgDefMetaDotStr,
   &soMsgDefDFrac
};

PUBLIC CmAbnfElmTypeSeq soMsgDefDelayFracSeq =
{
   2,
   soMsgDefDelayFracSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefDelayFrac =
{
#ifdef CM_ABNF_DBG
   "SO DELAYFRAC",
   "SORE_DOT",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 541,
   sizeof(TknU32),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefDelayFracSeq,
   soRegExpMetaDot
};


/********************************************************
TimestampDelay -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefTimestampDelaySeqElmnt[] =
{
   &soMsgDefMetaLws,
   &soMsgDefDelay,
   &soMsgDefDelayFrac
};

PUBLIC CmAbnfElmTypeSeq soMsgDefTimestampDelaySeq =
{
   3,
   soMsgDefTimestampDelaySeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefTimestampDelay =
{
#ifdef CM_ABNF_DBG
   "SO TIMESTAMPDELAY",
   "SORE_METASPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 542,
   (sizeof(TknU32) + sizeof(TknU32)),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefTimestampDelaySeq,
   soRegExpMetaLws
};

/********************************************************
UserAgent   -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefUserAgentSeqElmnt[] =
{
   &soMsgDefProdcom,
   &soMsgDefServerList1
};

PUBLIC CmAbnfElmTypeSeq soMsgDefUserAgentSeq =
{
   2,
   soMsgDefUserAgentSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefUserAgent =
{
#ifdef CM_ABNF_DBG
   "SO USERAGENT",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 543,
   sizeof(SoProdcomLst),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefUserAgentSeq,
   NULLP
};


/********************************************************
UserAgentList  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefUserAgentListSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefUserAgent,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefUserAgentListSeq =
{
   3,
   soMsgDefUserAgentListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefUserAgentList =
{
#ifdef CM_ABNF_DBG
   "SO USERAGENTLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 544,
   sizeof(SoProdcomLst),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefUserAgentListSeq,
   NULLP
};


/********************************************************
ViaH  -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefViaHSeqElmnt[] =
{
   &soMsgDefViaItem,
   &soMsgDefViaItemList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefViaHSeq =
{
   2,
   soMsgDefViaHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefViaH =
{
#ifdef CM_ABNF_DBG
   "SO VIAH",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 545,
   sizeof(SoVia),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefViaHSeq,
   NULLP
};

/********************************************************
AlertInfo   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAlertInfoSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefErrorInfoItem,
   &soMsgDefMetaCRLFStr,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAlertInfoSeq =
{
   3,
   soMsgDefAlertInfoSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAlertInfo =
{
#ifdef CM_ABNF_DBG
   "SO ALERTINFO",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 546,
   sizeof(SoCallInfo),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefAlertInfoSeq,
   NULLP
};

/********************************************************
CallIdValList  -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefCallIdValListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefCallIdVal,
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefCallIdValListSeqOf =
{
   1,
   SO_MAX_INREPLYTO,
   2,
   soMsgDefCallIdValListSeqOfElmnt,
   sizeof(TknStrOSXL)
};

PUBLIC CmAbnfElmDef soMsgDefCallIdValList =
{
#ifdef CM_ABNF_DBG
   "SO CALLIDVALLIST",
   "SORE_COMMA",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 547,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefCallIdValListSeqOf,
   soRegExpMetaComma
};


/********************************************************
InReplyToH  -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefInReplyToHSeqElmnt[] =
{
   &soMsgDefCallIdVal,
   &soMsgDefCallIdValList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefInReplyToHSeq =
{
   2,
   soMsgDefInReplyToHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefInReplyToH =
{
#ifdef CM_ABNF_DBG
   "SO INREPLYTOH",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 548,
   sizeof(SoTknStrOSXLLst),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefInReplyToHSeq,
   NULLP
};

/********************************************************
MaxForwardsList   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefMaxForwardsListSeqElmnt[]=
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefMaxForwardsVal,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefMaxForwardsListSeq =
{
   3,
   soMsgDefMaxForwardsListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefMaxForwardsList =
{
#ifdef CM_ABNF_DBG
   "SO MAXFORWARDSLIST",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 549,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefMaxForwardsListSeq,
   NULLP
};

/********************************************************
Priority -  Type of Priority  -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefPriorityChoiceEnum[] =
{
   NULLP,
   &soMsgDefEmergencyStr,
   &soMsgDefUrgentStr,
   &soMsgDefNormalStr,
   &soMsgDefNonurgentStr,
   &soMsgDefOtherPriorityStr
};

PUBLIC CmAbnfElmDef *soMsgDefPriorityChoiceElmnt[] =
{
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   &soMsgDefToken
};


PUBLIC CmAbnfElmTypeChoice soMsgDefPriorityChoice =
{
   6,
   0,
   NULLP,
   soMsgDefPriorityChoiceElmnt,
   soMsgDefPriorityChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefPriority =
{
#ifdef CM_ABNF_DBG
   "SO PRIORITY",
   "SORE_PRIORITYCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 550,
   sizeof(SoPriority),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefPriorityChoice,
   soRegExpPriorityChoice
};

/********************************************************
Priority Header -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefPriorityHdrSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefPriority,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefPriorityHdrSeq =
{
   3,
   soMsgDefPriorityHdrSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefPriorityHdr =
{
#ifdef CM_ABNF_DBG
   "SO PRIORITY",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 551,
   sizeof(SoPriority),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefPriorityHdrSeq,
   NULLP
};

/********************************************************
ResponseKeyList   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefResponseKeyListSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefResponseKeyVal,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefResponseKeyListSeq =
{
   3,
   soMsgDefResponseKeyListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefResponseKeyList =
{
#ifdef CM_ABNF_DBG
   "SO RESPONSEKEYLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 552,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefResponseKeyListSeq,
   NULLP
};


/********************************************************
SubjectVal  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefSubjectValSeqElmnt[] =
{
   &soMsgDefSubjectTxt
};

PUBLIC CmAbnfElmTypeSeq soMsgDefSubjectValSeq =
{
   1,
   soMsgDefSubjectValSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefSubjectVal =
{
#ifdef CM_ABNF_DBG
   "SO SUBJECTVAL",
   "SORE_SUBJECTVAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 553,
   sizeof(TknStrOSXL),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefSubjectValSeq,
   soRegExpSubjectVal
};


/********************************************************
MethodList  -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefMethodListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefMethod
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefMethodListSeqOf =
{
   1,
   SO_MAX_ALLOW,
   2,
   soMsgDefMethodListSeqOfElmnt,
   sizeof(SoExtVal)
};

PUBLIC CmAbnfElmDef soMsgDefMethodList =
{
#ifdef CM_ABNF_DBG
   "SO METHODLIST",
   "SORE_COMMA",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 554,
   sizeof(SoAllow),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefMethodListSeqOf,
   soRegExpMetaComma
};


/********************************************************
Allow -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAllowSeqElmnt[] =
{
   &soMsgDefMethod,
   &soMsgDefMethodList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAllowSeq =
{
   2,
   soMsgDefAllowSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAllow =
{
#ifdef CM_ABNF_DBG
   "SO ALLOW",
   "SORE_ALLOW",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 555,
   sizeof(SoAllow),
   (CM_ABNF_OPTIONAL |CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefAllowSeq,
   soRegExpNotMetaCRLF
};


/********************************************************
AllowList   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAllowListSeqElmnt[]=
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefAllow,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAllowListSeq =
{
   3,
   soMsgDefAllowListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefAllowList =
{
#ifdef CM_ABNF_DBG
   "SO ALLOWLIST",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 556,
   sizeof(SoAllow),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefAllowListSeq,
   NULLP
};

/********************************************************
DispositionType   -  Type of Disposition Type   -  Choice
*********************************************************/

PUBLIC CmAbnfElmTypeEnum  soMsgDefDispTypeSessionEnum =
{
    (Data *)"session",
    SO_DISP_TYPE_SESSION
};

PUBLIC CmAbnfElmDef  soMsgDefDispTypeSessionEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP DISP TYPE SESSION ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 557,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefDispTypeSessionEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefDispTypeRenderEnum =
{
    (Data *)"render",
    SO_DISP_TYPE_RENDER
};

PUBLIC CmAbnfElmDef  soMsgDefDispTypeRenderEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP DISP TYPE RENDER ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 558,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefDispTypeRenderEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefDispTypeIconEnum =
{
    (Data *)"icon",
    SO_DISP_TYPE_ICON
};

PUBLIC CmAbnfElmDef  soMsgDefDispTypeIconEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP DISP TYPE ICON ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 559,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefDispTypeIconEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefDispTypeAlertEnum =
{
    (Data *)"alert",
    SO_DISP_TYPE_ALERT
};

PUBLIC CmAbnfElmDef  soMsgDefDispTypeAlertEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP DISP TYPE ALERT ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 560,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefDispTypeAlertEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefDispTypeExtnEnum =
{
    (Data *)"",
    SO_DISP_TYPE_EXTN
};

PUBLIC CmAbnfElmDef  soMsgDefDispTypeExtnEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP DISP TYPE EXTN ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 561,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefDispTypeExtnEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefDispositionTypeChcEnum[] =
{
   NULLP,
   &soMsgDefDispTypeSessionEnumDef,
   &soMsgDefDispTypeRenderEnumDef,
   &soMsgDefDispTypeIconEnumDef,
   &soMsgDefDispTypeAlertEnumDef,
   &soMsgDefDispTypeExtnEnumDef,
};

PUBLIC CmAbnfElmDef  *soMsgDefDispositionTypeChcElmnt[] =
{
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   NULLP,
   &soMsgDefToken,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefDispositionTypeChc =
{
    6,
    0,
    NULLP,
    soMsgDefDispositionTypeChcElmnt,
    soMsgDefDispositionTypeChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefDispositionType =
{
#ifdef  CM_ABNF_DBG
    "SIP DISPOSITION TYPE ",
    "soRegExpDispositionTypeChoice",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 562,
    sizeof(SoStrValue),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soMsgDefDispositionTypeChc,
    soRegExpDispositionTypeChoice
};

/********************************************************
DispositionParams -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefDispositionParamsSeqOfElmnt[] =
{
   &soMsgDefMetaSemiColonStr,
   &soMsgDefDispositionParam,
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefDispositionParamsSeqOf =
{
   0,
   SO_MAX_DISPOSITIONPARAMS,
   2,
   soMsgDefDispositionParamsSeqOfElmnt,
   sizeof(SoDispositionParam)
};


PUBLIC CmAbnfElmDef soMsgDefDispositionParams =
{
#ifdef CM_ABNF_DBG
   "SO DISPOSITIONPARAMS",
   "SORE_DISPOSITIONPARAMS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 563,
   sizeof(SoDispositionParams),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefDispositionParamsSeqOf,
   soRegExpMetaSemiColon
};


/********************************************************
ContentCodingList -  Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefContentCodingListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefContentCoding,
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefContentCodingListSeqOf =
{
   1,
   SO_MAX_CONTENTENCODING,
   2,
   soMsgDefContentCodingListSeqOfElmnt,
   sizeof(SoExtVal)
};

PUBLIC CmAbnfElmDef soMsgDefContentCodingList =
{
#ifdef CM_ABNF_DBG
   "SO CONTENTCODINGLIST",
   "SORE_COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 564,
   sizeof(SoExtVal),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefContentCodingListSeqOf,
   soRegExpMetaComma
};

/********************************************************
ContentEncodingH  -  Optional Sequence Of
*********************************************************/


PUBLIC CmAbnfElmDef *soMsgDefContentEncodingHSeqElmnt[] =
{
   &soMsgDefContentCoding,
   &soMsgDefContentCodingList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefContentEncodingHSeq =
{
   2,
   soMsgDefContentEncodingHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefContentEncodingH =
{
#ifdef CM_ABNF_DBG
   "SO CONTENTENCODING",
   "SORE_CONTENTENCODING",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 565,
   sizeof(SoExtVal),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefContentEncodingHSeq,
   NULLP
};


/********************************************************
LanguageTagList   -  Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefLanguageTagListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefLanguageTag,
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefLanguageTagListSeqOf =
{
   1,
   SO_MAX_CONTENTLANGUAGE,
   2,
   soMsgDefLanguageTagListSeqOfElmnt,
   sizeof(TknStrOSXL)
};

PUBLIC CmAbnfElmDef soMsgDefLanguageTagList =
{
#ifdef CM_ABNF_DBG
   "SO LANGUAGETAGLIST",
   "SORE_COMMA",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 566,
   sizeof(TknStrOSXL),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefLanguageTagListSeqOf,
   soRegExpMetaComma
};

/********************************************************
ContentLanguageH  -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContentLanguageHSeqElmnt[] =
{
   &soMsgDefLanguageTag,
   &soMsgDefLanguageTagList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefContentLanguageHSeq =
{
   2,
   soMsgDefContentLanguageHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefContentLanguageH =
{
#ifdef CM_ABNF_DBG
   "SO CONTENTLANGUAGE",
   "SORE_CONTENTLANGUAGE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 567,
   sizeof(SoTknStrOSXLLst),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefContentLanguageHSeq,
   NULLP
};

/********************************************************
Min-ExpiresList -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefMinExpiresSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefDeltaSeconds,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefMinExpiresSeq =
{
   3,
   soMsgDefMinExpiresSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefMinExpires =
{
#ifdef CM_ABNF_DBG
   "SO MINEXPIRESLIST",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 568,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefMinExpiresSeq,
   NULLP   
};

/********************************************************
ExpiresList -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefExpiresSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefDeltaSeconds,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefExpiresSeq =
{
   3,
   soMsgDefExpiresSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefExpires =
{
#ifdef CM_ABNF_DBG
   "SO EXPIRESLIST",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 569,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefExpiresSeq,
   NULLP
};

/********************************************************
Route -  Optional Sequence
*********************************************************/

/********************************************************
MetaRouteParSep  - Encode rec-params in multiple Route headers 
*********************************************************/
   
PUBLIC CmAbnfElmTypeMeta soMsgDefMetaRouteParSepMeta =
{  
   (Data *)"\r\nRoute:"
}; 

PUBLIC CmAbnfElmDef soMsgDefMetaRouteParSep =
{
#ifdef CM_ABNF_DBG
   "SO METACOMMASTR",
   "SORE_METACOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 570,
  0,
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_META,
   (U8 *)&soMsgDefMetaRouteParSepMeta,
   soRegExpMetaComma
}; 

PUBLIC CmAbnfElmDef *soMsgDefRouteRepListSeqOfElmnt[] =
{
   &soMsgDefMetaRouteParSep,
   &soMsgDefRecordRouteRep
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefRouteRepListSeqOf =
{
   1,
   SO_MAX_RECORDROUTELIST,
   2,
   soMsgDefRouteRepListSeqOfElmnt,
   sizeof(SoRouteSeq)
};

PUBLIC CmAbnfElmDef soMsgDefRouteRepList =
{
#ifdef CM_ABNF_DBG
   "SO ROUTELIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 571,
   sizeof(SoRoute),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefRouteRepListSeqOf,
   soRegExpMetaComma
};

/********************************************************
RouteH   -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefRouteHSeqElmnt[] =
{
   &soMsgDefRecordRouteRep,
   &soMsgDefRouteRepList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRouteHSeq =
{
   2,
   soMsgDefRouteHSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefRouteH =
{
#ifdef CM_ABNF_DBG
   "SO ROUTEH",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 572,
   sizeof(SoRoute),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefRouteHSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *soMsgDefRouteSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefRouteH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRouteSeq =
{
   3,
   soMsgDefRouteSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefRoute =
{
#ifdef   CM_ABNF_DBG
   "SO ROUTE",
   "SORE_ROUTE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 573,
   sizeof(SoRoute),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefRouteSeq,
   NULLP
};

#ifdef SO_EVENT
/********************************************************
Allow-Events -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefAllowEventsSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefAllowEventsH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAllowEventsSeq =
{
   3,
   soMsgDefAllowEventsSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefAllowEventsList =
{
#ifdef   CM_ABNF_DBG
   "SO ALLOWEVENTS",
   "NULLP",  
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 574,
   sizeof(SoTknStrOSXLLst),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefAllowEventsSeq,
   NULLP
};
#endif /* SO_EVENT */

/********************************************************
ExtensionList  -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefExtensionListSeqElmnt[] =
{
   &soMsgDefExtension,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefExtensionListSeq =
{
   2,
   soMsgDefExtensionListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefExtensionList =
{
#ifdef CM_ABNF_DBG
   "SO EXTENSIONLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 575,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefExtensionListSeq,
   NULLP
};


/********************************************************
ChallengeList  -  Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefChallengeListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefChallenge
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefChallengeListSeqOf =
{
   1,
   SO_MAX_PROXYAUTHENTICATE,
   2,
   soMsgDefChallengeListSeqOfElmnt,
   sizeof(SoAuthorization)
};

PUBLIC CmAbnfElmDef soMsgDefChallengeList =
{
#ifdef CM_ABNF_DBG
   "SO CHALLENGELIST",
   "SORE_COMMA",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 576,
   sizeof(SoAuthenticate),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefChallengeListSeqOf,
   soRegExpMetaLws
};


/********************************************************
ProxyAuthenticateH   -  Optional Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefProxyAuthenticateHSeqElmnt[] =
{
   &soMsgDefChallenge,
   &soMsgDefChallengeList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefProxyAuthenticateHSeq =
{
   2,
   soMsgDefProxyAuthenticateHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefProxyAuthenticateH =
{
#ifdef CM_ABNF_DBG
   "SO PROXYAUTHENTICATEH",
   "NULLP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 577,
   sizeof(SoAuthenticate),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefProxyAuthenticateHSeq,
   NULLP
};


/********************************************************
RetryAfterComment -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefRetryAfterCommentSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefComment,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRetryAfterCommentSeq =
{
   2,
   soMsgDefRetryAfterCommentSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefRetryAfterComment =
{
#ifdef CM_ABNF_DBG
   "SO RETRYAFTERCOMMENT",
   "SORE_RETRYAFTERCOMMENT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 578,
   sizeof(TknStrOSXL),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefRetryAfterCommentSeq,
   soRegExpRetryAfterComment
};

/********************************************************
RetryParams -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefRetryParamsSeqOfElmnt[] =
{
   &soMsgDefMetaSemiColonStr,
   &soMsgDefRetryParam
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefRetryParamsSeqOf =
{
   0,
   SO_MAX_RETRYPARAMS,
   2,
   soMsgDefRetryParamsSeqOfElmnt,
   sizeof(SoRetryParam)
};


PUBLIC CmAbnfElmDef soMsgDefRetryParams =
{
#ifdef CM_ABNF_DBG
   "SO RETRYPARAMS",
   "SORE_RETRYPARAMS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 579,
   sizeof(SoRetryParams),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefRetryParamsSeqOf,
   soRegExpMetaSemiColon
};

/********************************************************
ServerList1    -     Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefServerList1SeqOfElmnt[] =
{
   &soMsgDefMetaLws,
   &soMsgDefProdcom
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefServerList1SeqOf =
{
   0,
   SO_MAX_SERVER,
   2,
   soMsgDefServerList1SeqOfElmnt,
   sizeof(SoProdcom)
};

PUBLIC CmAbnfElmDef soMsgDefServerList1 =
{
#ifdef CM_ABNF_DBG
   "SO SERVERLIST1",
   "SORE USERAGENTLISTCHOICE",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 580,
   sizeof(SoProdcom),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefServerList1SeqOf,
   soRegExpUserAgentListChoice
};

/********************************************************
Server   -  Optional Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefServerSeqElmnt[] =
{
   &soMsgDefProdcom,
   &soMsgDefServerList1
};

PUBLIC CmAbnfElmTypeSeq soMsgDefServerSeq =
{
   2,
   soMsgDefServerSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefServer =
{
#ifdef CM_ABNF_DBG
   "SO SERVER",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 581,
   sizeof(SoProdcomLst),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefServerSeq,
   NULLP
};


/********************************************************
ServerList  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefServerListSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefServer,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefServerListSeq =
{
   3,
   soMsgDefServerListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefServerList =
{
#ifdef CM_ABNF_DBG
   "SO SERVERLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 582,
   sizeof(SoProdcomLst),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefServerListSeq,
   NULLP
};

/********************************************************
UnsupportedList   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefUnsupportedListSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefOptionTagH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefUnsupportedListSeq =
{
   3,
   soMsgDefUnsupportedListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefUnsupportedList =
{
#ifdef CM_ABNF_DBG
   "SO UNSUPPORTEDLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 583,
   sizeof(SoTknStrOSXLLst),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefUnsupportedListSeq,
   NULLP
};

/********************************************************
WarningItemList   -  Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefWarningItemListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefWarningItem
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefWarningItemListSeqOf =
{
   1,
   SO_MAX_WARNING,
   2,
   soMsgDefWarningItemListSeqOfElmnt,
   sizeof(SoWarningItem)
};

PUBLIC CmAbnfElmDef soMsgDefWarningItemList =
{
#ifdef CM_ABNF_DBG
   "SO WARNINGITEMLIST",
   "SORE_COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 584,
   sizeof(SoWarningItem),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefWarningItemListSeqOf,
   soRegExpMetaComma
};


/********************************************************
Warning  -  Optional Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefWarningSeqElmnt[] =
{
   &soMsgDefWarningItem,
   &soMsgDefWarningItemList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefWarningSeq =
{
   2,
   soMsgDefWarningSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefWarning =
{
#ifdef CM_ABNF_DBG
   "SO WARNING",
   "SORE_WARNING",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 585,
   sizeof(SoWarning),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefWarningSeq,
   NULLP
};


/********************************************************
WarningList -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefWarningListSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefWarning,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefWarningListSeq =
{
   3,
   soMsgDefWarningListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefWarningList =
{
#ifdef CM_ABNF_DBG
   "SO WARNINGLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 586,
   sizeof(SoWarning),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefWarningListSeq,
   NULLP
};

/********************************************************
WwwAuthenticate   -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefWwwAuthenticateSeqElmnt[] =
{
   &soMsgDefChallenge,
   &soMsgDefChallengeList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefWwwAuthenticateSeq =
{
   2,
   soMsgDefWwwAuthenticateSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefWwwAuthenticate =
{
#ifdef CM_ABNF_DBG
   "SO WWWAUTHENTICATE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 587,
   sizeof(SoAuthenticate),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefWwwAuthenticateSeq,
   NULLP
};


/********************************************************
WwwAuthenticateList  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefWwwAuthenticateListSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefWwwAuthenticate,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefWwwAuthenticateListSeq =
{
   3,
   soMsgDefWwwAuthenticateListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefWwwAuthenticateList =
{
#ifdef CM_ABNF_DBG
   "SO WWWAUTHENTICATELIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 588,
   sizeof(SoAuthenticate),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefWwwAuthenticateListSeq,
   NULLP
};


#ifdef SO_EVENT

/********************************************************
EventList  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefEventListSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefToken,
   &soMsgDefGenericParams,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefEventListSeq =
{
   4,
   soMsgDefEventListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefEventList =
{
#ifdef CM_ABNF_DBG
   "SO EVENTLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 589,
   sizeof(SoEventHeader),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefEventListSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSubStateActEnum =
{
    (Data *)"active" ,
    SO_SUB_STATE_ACT
};

PUBLIC CmAbnfElmDef  soMsgDefSubStateActEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO SUB STATE ACT ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 590,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSubStateActEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSubStatePendEnum =
{
    (Data *)"pending" ,
    SO_SUB_STATE_PEND
};

PUBLIC CmAbnfElmDef  soMsgDefSubStatePendEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO SUB STATE PEND ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 591,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSubStatePendEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSubStateTermEnum =
{
    (Data *)"terminated" ,
    SO_SUB_STATE_TERM
};

PUBLIC CmAbnfElmDef  soMsgDefSubStateTermEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO SUB STATE TERM ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 592,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSubStateTermEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSubStateTokenEnum =
{
    NULLP,
    SO_SUB_STATE_TOKEN
};

PUBLIC CmAbnfElmDef  soMsgDefSubStateTokenEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO TOKEN ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 593,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSubStateTokenEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefSubStateValChcEnum[] =
{
    NULLP ,
    &soMsgDefSubStateActEnumDef ,
    &soMsgDefSubStatePendEnumDef ,
    &soMsgDefSubStateTermEnumDef ,
    &soMsgDefSubStateTokenEnumDef ,
};

PUBLIC CmAbnfElmDef  *soMsgDefSubStateValChcElmnt[] =
{
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    &soMsgDefToken ,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefSubStateValChc =
{
    5 ,
    0 ,
    NULLP ,
    soMsgDefSubStateValChcElmnt ,
    soMsgDefSubStateValChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefSubStateVal =
{
#ifdef  CM_ABNF_DBG
    "SO SUB STATE VAL " ,
    "soRegExpSubStateVal" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 594,
    sizeof(SoStrValue) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &soMsgDefSubStateValChc ,
    soRegExpSubStateVal
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSbExReasDeactEnum =
{
    (Data *)"deactivated" ,
    SO_SB_EX_REAS_DEACT
};

PUBLIC CmAbnfElmDef  soMsgDefSbExReasDeactEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO SB EX REAS DEACT ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 595,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSbExReasDeactEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSbExReasProbatEnum =
{
    (Data *)"probation" ,
    SO_SB_EX_REAS_PROBAT
};

PUBLIC CmAbnfElmDef  soMsgDefSbExReasProbatEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO SB EX REAS PROBAT ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 596,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSbExReasProbatEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSbExReasRejctEnum =
{
    (Data *)"rejected" ,
    SO_SB_EX_REAS_REJCT
};

PUBLIC CmAbnfElmDef  soMsgDefSbExReasRejctEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO SB EX REAS REJCT ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 597,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSbExReasRejctEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSbExReasTmoutEnum =
{
    (Data *)"timeout" ,
    SO_SB_EX_REAS_TMOUT
};

PUBLIC CmAbnfElmDef  soMsgDefSbExReasTmoutEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO SB EX REAS TMOUT ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 598,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSbExReasTmoutEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSbExReasGiveupEnum =
{
    (Data *)"giveup" ,
    SO_SB_EX_REAS_GIVEUP
};

PUBLIC CmAbnfElmDef  soMsgDefSbExReasGiveupEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO SB EX REAS GIVEUP ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 599,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSbExReasGiveupEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSbExReasNoResEnum =
{
    (Data *)"noresource" ,
    SO_SB_EX_REAS_NO_RES
};

PUBLIC CmAbnfElmDef  soMsgDefSbExReasNoResEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO SB EX REAS NO RES ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 600,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSbExReasNoResEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSbExReasTokenEnum =
{
    NULLP,
    SO_SB_EX_REAS_TOKEN
};

PUBLIC CmAbnfElmDef  soMsgDefSbExReasTokenEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO SB EX REAS NO RES ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 601,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSbExReasTokenEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefSubExpParReasonActChcEnum[] =
{
    NULLP ,
    &soMsgDefSbExReasDeactEnumDef ,
    &soMsgDefSbExReasProbatEnumDef ,
    &soMsgDefSbExReasRejctEnumDef ,
    &soMsgDefSbExReasTmoutEnumDef ,
    &soMsgDefSbExReasGiveupEnumDef ,
    &soMsgDefSbExReasNoResEnumDef ,
    &soMsgDefSbExReasTokenEnumDef ,
};

PUBLIC CmAbnfElmDef  *soMsgDefSubExpParReasonActChcElmnt[] =
{
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    &soMsgDefToken ,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefSubExpParReasonActChc =
{
    8 ,
    0 ,
    NULLP ,
    soMsgDefSubExpParReasonActChcElmnt ,
    soMsgDefSubExpParReasonActChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefSubExpParReasonAct =
{
#ifdef  CM_ABNF_DBG
    "SO SUB EXP PAR REASON " ,
    "soRegExpSubExpReason" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 602,
    sizeof(SoStrValue) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &soMsgDefSubExpParReasonActChc ,
    soRegExpSubExpReason
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSubExpParReasonEnum =
{
    (Data *)"reason" ,
    SO_SUB_EXP_PAR_REASON
};

PUBLIC CmAbnfElmDef  soMsgDefSubExpParReasonEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO SUB EXP PAR REASON ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 603,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSubExpParReasonEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSubExpParExpiresEnum =
{
    (Data *)"expires" ,
    SO_SUB_EXP_PAR_EXPIRES
};

PUBLIC CmAbnfElmDef  soMsgDefSubExpParExpiresEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO SUB EXP PAR EXPIRES ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 604,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSubExpParExpiresEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSubExpParRetryAftEnum =
{
    (Data *)"retry-after" ,
    SO_SUB_EXP_PAR_RETRY_AFT
};

PUBLIC CmAbnfElmDef  soMsgDefSubExpParRetryAftEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO SUB EXP PAR RETRY AFT ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 605,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSubExpParRetryAftEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSubExpParGenericParamEnum =
{
    NULLP,
    SO_SUB_EXP_PAR_GENERIC_PARAM
};

PUBLIC CmAbnfElmDef  soMsgDefSubExpParGenericParamEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO GENERIC PARAM ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 606,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefSubExpParGenericParamEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefSubExpParReasonSeqElmnts[] =
{
    &soMsgDefMetaSws,
    &cmMsgDefMetaEqual,
    &soMsgDefMetaSws,
    &soMsgDefSubExpParReasonAct
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefSubExpParReasonSeq =
{
    4 ,
    soMsgDefSubExpParReasonSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefSubExpParReason =
{
#ifdef  CM_ABNF_DBG
    "SO SUB EXP PAR REASON" ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 607,
    sizeof(SoStrValue) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDefSubExpParReasonSeq ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefEqDeltaSecondsSeqElmnts[] =
{
    &soMsgDefMetaSws,
    &cmMsgDefMetaEqual,
    &soMsgDefMetaSws,
    &soMsgDefDeltaSeconds
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefEqDeltaSecondsSeq =
{
    4 ,
    soMsgDefEqDeltaSecondsSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefEqDeltaSeconds =
{
#ifdef  CM_ABNF_DBG
    "SO EQ DELTA SECONDS" ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 608,
   sizeof(TknU32),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDefEqDeltaSecondsSeq ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefSubExpParChcEnum[] =
{
    NULLP ,
    &soMsgDefSubExpParReasonEnumDef ,
    &soMsgDefSubExpParExpiresEnumDef ,
    &soMsgDefSubExpParRetryAftEnumDef ,
    &soMsgDefSubExpParGenericParamEnumDef ,
};

PUBLIC CmAbnfElmDef  *soMsgDefSubExpParChcElmnt[] =
{
    NULLP ,
    &soMsgDefSubExpParReason ,
    &soMsgDefEqDeltaSeconds,
    &soMsgDefEqDeltaSeconds,
    &soMsgDefGenericParam ,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefSubExpParChc =
{
    5 ,
    0 ,
    NULLP ,
    soMsgDefSubExpParChcElmnt ,
    soMsgDefSubExpParChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefSubExpPar =
{
#ifdef  CM_ABNF_DBG
    "SO SUB EXP PAR " ,
    "soRegExpSubExpPar" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 609,
    sizeof(SoSubExpParam) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &soMsgDefSubExpParChc ,
    soRegExpSubExpPar
};

PUBLIC CmAbnfElmDef  *soMsgDefOptSubExpParLstSeqOfElmnts[] =
{
    &soMsgDefMetaSws ,
    &cmMsgDefMetaSemiColon ,
    &soMsgDefMetaSws ,
    &soMsgDefSubExpPar
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefOptSubExpParLstSeqOf =
{
    0 ,
    SO_MAX_SUBEXP_PARAMS ,
    4 ,
    soMsgDefOptSubExpParLstSeqOfElmnts ,
    sizeof (SoSubExpParam)
};

PUBLIC CmAbnfElmDef  soMsgDefOptSubExpParLst =
{
#ifdef  CM_ABNF_DBG
    "SO OPT SUB EXP PAR LST " ,
    "soRegExpMetaSemiColon" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 610,
    sizeof(SoSubExpParams) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &soMsgDefOptSubExpParLstSeqOf ,
    soRegExpMetaSemiColon
};

PUBLIC CmAbnfElmDef  *soMsgDefSubscStateSeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr ,
    &soMsgDefSubStateVal ,
    &soMsgDefOptSubExpParLst,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefSubscStateSeq =
{
    4 ,
    soMsgDefSubscStateSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefSubscState =
{
#ifdef  CM_ABNF_DBG
    "SO SUBSC STATE " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 611,
    sizeof(SoSubscState) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &soMsgDefSubscStateSeq ,
    NULLP
};

#ifdef SO_REFER 

/********************************************************
Refer-To - Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefReferToSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefAddrCh,
   &soMsgDefGenericParams,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefReferToSeq =
{
   4,
   soMsgDefReferToSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefReferTo =
{
#ifdef CM_ABNF_DBG
   "SO REFERTO",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 612,
   sizeof(SoReferTo),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefReferToSeq,
   NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefRfByIdParSeqElmnts[] =
{
    &soMsgDefMetaSws ,
    &cmMsgDefMetaEqual ,
    &soMsgDefMetaSws ,
    &soMsgDefQuotedStrToken,
    &soMsgDefMetaSws
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefRfByIdParSeq =
{
    5,
    soMsgDefRfByIdParSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefRfByIdPar =
{
#ifdef  CM_ABNF_DBG
    "SO RF BY ID PAR " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 613,
    sizeof(TknStrOSXL) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDefRfByIdParSeq ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefRfByIdParEnum =
{
    (Data *)"cid" ,
    SO_RF_BY_ID_PAR
};

PUBLIC CmAbnfElmDef  soMsgDefRfByIdParEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO RF BY ID PAR ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 614,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefRfByIdParEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefRfByGenericParamEnum =
{
    NULLP,
    SO_RF_BY_GENERIC_PARAM
};

PUBLIC CmAbnfElmDef  soMsgDefRfByGenericParamEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO GENERIC PARAM ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 615,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDefRfByGenericParamEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefRfByParChcEnum[] =
{
    NULLP ,
    &soMsgDefRfByIdParEnumDef ,
    &soMsgDefRfByGenericParamEnumDef ,
};

PUBLIC CmAbnfElmDef  *soMsgDefRfByParChcElmnt[] =
{
    NULLP ,
    &soMsgDefRfByIdPar ,
    &soMsgDefGenericParam ,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefRfByParChc =
{
    3 ,
    0 ,
    NULLP ,
    soMsgDefRfByParChcElmnt ,
    soMsgDefRfByParChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefRfByPar =
{
#ifdef  CM_ABNF_DBG
    "SO RF BY PAR " ,
    "soRegExpRfByOrGenPar" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 616,
    sizeof(SoReferredByParam) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &soMsgDefRfByParChc ,
    soRegExpRfByOrGenPar
};

PUBLIC CmAbnfElmDef  *soMsgDefRfByParsSeqOfElmnts[] =
{
    &soMsgDefMetaSws ,
    &cmMsgDefMetaSemiColon ,
    &soMsgDefMetaSws ,
    &soMsgDefRfByPar
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefRfByParsSeqOf =
{
    0 ,
    SO_MAX_REFERD_BY_PARAMS ,
    4 ,
    soMsgDefRfByParsSeqOfElmnts ,
    sizeof (SoReferredByParam)
};

PUBLIC CmAbnfElmDef  soMsgDefRfByPars =
{
#ifdef  CM_ABNF_DBG
    "SO RF BY PARS " ,
    "soRegExpMetaSemiColon" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 617,
    sizeof(SoReferredByParams) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &soMsgDefRfByParsSeqOf ,
    soRegExpMetaSemiColon
};

/********************************************************
Referred-By -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefReferredBySeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefAddrCh,
   &soMsgDefRfByPars,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefReferredBySeq =
{
   4,
   soMsgDefReferredBySeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefReferredBy =
{
#ifdef CM_ABNF_DBG
   "SO Referred-By",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 618,
   sizeof(SoReferredBy),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefReferredBySeq,
   NULLP
};

/********************************************************
to-tag - Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefReplacesToTagSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeq soMsgDefReplacesToTagSeq =
{
   4,
   soMsgDefReplacesToTagSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefReplacesToTag =
{
#ifdef CM_ABNF_DBG
   "SO REPLACES TO TAG",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 619,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefReplacesToTagSeq,
   NULLP
};

/********************************************************
from-tag - Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefReplacesFromTagSeqElmnt[] =
{
   &soMsgDefMetaSws,
   &soMsgDefMetaEqualStr,
   &soMsgDefMetaSws,
   &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeq soMsgDefReplacesFromTagSeq =
{
   4,
   soMsgDefReplacesFromTagSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefReplacesFromTag =
{
#ifdef CM_ABNF_DBG
   "SO REPLACES FROM TAG",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 620,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefReplacesFromTagSeq,
   NULLP
};

/********************************************************
Replace Param -  Type of Replaces Parameter -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefReplacesParamChoiceEnum[] =
{
   NULLP,
   &soMsgDefReplacesToTagStr,
   &soMsgDefReplacesFromTagStr,
   &soMsgDefReplacesEarlyOnlyStr,
   &soMsgDefGenericParamStr
};

PUBLIC CmAbnfElmDef *soMsgDefReplacesParamChoiceElmnt[] =
{
   NULLP,
   &soMsgDefReplacesToTag,
   &soMsgDefReplacesFromTag,
   NULLP,
   &soMsgDefGenericParam
};


PUBLIC CmAbnfElmTypeChoice soMsgDefReplacesParamChoice =
{
   5,
   0,
   NULLP,
   soMsgDefReplacesParamChoiceElmnt,
   soMsgDefReplacesParamChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefReplacesParam =
{
#ifdef CM_ABNF_DBG
   "SO REPLACES PARAM",
   "SORE_REPLACES PARAM CHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 621,
   sizeof(SoReplacesParam),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefReplacesParamChoice,
   soRegExpReplacesParam
};

/********************************************************
ReplacesParams -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefReplacesParamsSeqOfElmnt[] =
{
   &soMsgDefMetaSemiColonStr,
   &soMsgDefReplacesParam
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefReplacesParamsSeqOf =
{
   0,
   SO_MAX_REPLACEPARAM,
   2,
   soMsgDefReplacesParamsSeqOfElmnt,
   sizeof(SoReplacesParam)
};


PUBLIC CmAbnfElmDef soMsgDefReplaceParams =
{
#ifdef CM_ABNF_DBG
   "SO REPLACE PARAMS",
   "SORE_REPLACEPARAMS",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 622,
   sizeof(SoReplacesParams),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefReplacesParamsSeqOf,
   soRegExpMetaSemiColon
};

/********************************************************
Replaces -  Sequence
*********************************************************/
/* Forward Declaration of call-id */
EXTERN CmAbnfElmDef soMsgDefCallIdVal;

PUBLIC CmAbnfElmDef *soMsgDefReplacesSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefCallIdVal,
   &soMsgDefReplaceParams,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefReplacesSeq =
{
   4,
   soMsgDefReplacesSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefReplaces =
{
#ifdef CM_ABNF_DBG
   "SO REPLACES",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 623,
   sizeof(SoReplaces),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefReplacesSeq,
   NULLP
};
#endif /* SO_REFER */
#endif /* SO_EVENT */

#ifdef SO_SESSTIMER

/********************************************************
SessionExpiresVal -  TknU32
*********************************************************/

PUBLIC CmAbnfElmTypeEnum  soMsgDefRefUacEnum =
{
    (Data *)"uac",
    SO_REFRESHER_UAC
};

PUBLIC CmAbnfElmDef  soMsgDefRefUacEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP REFRESHER UAC ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 624,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefRefUacEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefRefUasEnum =
{
    (Data *)"uas",
    SO_REFRESHER_UAS
};

PUBLIC CmAbnfElmDef  soMsgDefRefUasEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP REFRESHER UAS ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 625,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefRefUasEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefRefresherValChcEnum[] =
{
   NULLP,
   &soMsgDefRefUacEnumDef,
   &soMsgDefRefUasEnumDef,
};

PUBLIC CmAbnfElmDef  *soMsgDefRefresherValChcElmnt[] =
{
    NULLP,
    NULLP,
    NULLP,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefRefresherValChc =
{
    3,
    0,
    NULLP,
    NULLP,
    soMsgDefRefresherValChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefRefresherVal =
{
#ifdef  CM_ABNF_DBG
    "SIP REFRESHER VAL ",
    "soRegExpRefresherPar",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 626,
    sizeof(TknU8),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soMsgDefRefresherValChc,
    soRegExpRefresherPar
};

PUBLIC CmAbnfElmDef  *soMsgDefRefresherSeqElmnts[] =
{
    &soMsgDefMetaSws,
    &soMsgDefMetaEqualStr,
    &soMsgDefMetaSws,
    &soMsgDefRefresherVal
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefRefresherSeq =
{
    4,
    soMsgDefRefresherSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefRefresher =
{
#ifdef  CM_ABNF_DBG
    "SIP REFRESHER ",
    "NULLP",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 627,
    sizeof(TknU8),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefRefresherSeq,
    NULLP   
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefRefresherEnum =
{
    (Data *)"refresher",
    SO_SESSION_EXP_REFRESHER
};

PUBLIC CmAbnfElmDef  soMsgDefRefresherEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP SESSION EXP REFRESHER ENUM ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 628,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefRefresherEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefSessionExpExtnEnum =
{
    (Data *)"",
    SO_SESSION_EXP_EXTN
};

PUBLIC CmAbnfElmDef  soMsgDefSessionExpExtnEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP SESSION EXP EXTN ENUM ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 629,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefSessionExpExtnEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefSessExpParamChcEnum[] =
{
    NULLP,
    &soMsgDefRefresherEnumDef,
    &soMsgDefSessionExpExtnEnumDef,
};

PUBLIC CmAbnfElmDef  *soMsgDefSessExpParamChcElmnt[] =
{
    NULLP,
    &soMsgDefRefresher,
    &soMsgDefGenericParam,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefSessExpParamChc =
{
    3,
    0,
    NULLP,
    soMsgDefSessExpParamChcElmnt,
    soMsgDefSessExpParamChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefSessExpParam =
{
#ifdef  CM_ABNF_DBG
    "SIP SESS EXP PARAM ",
    "soRegExpSessExpPar",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 630,
    sizeof(SoSessExpParam),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soMsgDefSessExpParamChc,
    soRegExpSessExpPar
};

PUBLIC CmAbnfElmDef  *soMsgDefSessExpParamListSeqOfElmnts[] =
{
    &soMsgDefMetaSemiColonStr,
    &soMsgDefSessExpParam
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefSessExpParamListSeqOf =
{
    0,
    SO_MAX_SESSEXPPARS,
    2,
    soMsgDefSessExpParamListSeqOfElmnts,
    sizeof (SoSessExpParam)
};

PUBLIC CmAbnfElmDef  soMsgDefSessExpParamList =
{
#ifdef  CM_ABNF_DBG
    "SIP SESS EXP PARAM LIST ",
    "soRegExpMetaSemiColon",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 631,
    sizeof(SoSessExpParams),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQOF,
    (U8 *) &soMsgDefSessExpParamListSeqOf,
    soRegExpMetaSemiColon
};

PUBLIC CmAbnfElmTypeIntRange soMsgDefSessionExpValRange = {0, 10, 0, 0xFFFFFFFF};

PUBLIC CmAbnfElmDef soMsgDefSessionExpiresVal =
{
#ifdef CM_ABNF_DBG
   "SO_SESSEXP",
   "cmAbnfRegExpDgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 632,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefSessionExpValRange,
   cmAbnfRegExpDgt
};

/********************************************************
Session-Expires - Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefSessionExpresSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefSessionExpiresVal,
   &soMsgDefSessExpParamList,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefSessionExpiresSeq =
{
   4,
   soMsgDefSessionExpresSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefSessionExpires =
{
#ifdef CM_ABNF_DBG
   "SO SESSEXPIRES",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 633,
   sizeof(SoSessionExpires),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefSessionExpiresSeq,
   NULLP
};
#endif /* SO_SESSTIMER */

/********************************************************
AcceptEncoding -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAcceptEncodingSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefAcceptEncodingH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAcceptEncodingSeq =
{
   3,
   soMsgDefAcceptEncodingSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAcceptEncoding =
{
#ifdef CM_ABNF_DBG
   "SO ACCEPTENCODING",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 634,
   sizeof(SoAcceptEncoding),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefAcceptEncodingSeq,
   NULLP
};

/********************************************************
AcceptLanguage -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAcceptLanguageSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefAcceptLanguageH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAcceptLanguageSeq =
{
   3,
   soMsgDefAcceptLanguageSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAcceptLanguage =
{
#ifdef CM_ABNF_DBG
   "SO ACCEPTLANGUAGE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 635,
   sizeof(SoAcceptLanguage),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefAcceptLanguageSeq,
   NULLP
};

/********************************************************
CallId   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefCallIdSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefCallIdVal,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefCallIdSeq =
{
   3,
   soMsgDefCallIdSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefCallId =
{
#ifdef CM_ABNF_DBG
   "SO CALLID",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 636,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefCallIdSeq,
   NULLP
};

#ifdef SO_SESSTIMER
/********************************************************
MinSE Val -  TknU32
*********************************************************/

PUBLIC CmAbnfElmTypeIntRange soMsgDefMinSEValRange = {0, 10, 0, 0xFFFFFFFF};

PUBLIC CmAbnfElmDef soMsgDefMinSEVal =
{
#ifdef CM_ABNF_DBG
   "SO_MINSE",
   "cmAbnfRegExpDgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 637,
  sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefMinSEValRange,
   cmAbnfRegExpDgt
};

/********************************************************
Min-SE - Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefMinSESeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefMinSEVal,
   &soMsgDefGenericParams,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefMinSESeq =
{
   4,
   soMsgDefMinSESeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefMinSE =
{
#ifdef CM_ABNF_DBG
   "SO MINSE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 638,
   sizeof(SoMinSE),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefMinSESeq,
   NULLP
};
#endif /* SO_SESSTIMER */

#ifdef SO_CALLERPREF
/********************************************************
Request-Disposition - Proxy -  Choice
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefProxyFeatureChoiceEnum[] =
{
   NULLP,
   &soMsgDefProxyStr,
   &soMsgDefRedirectStr 
};


PUBLIC CmAbnfElmTypeChoice soMsgDefProxyFeatureChoice =
{
   3,
   0,
   NULLP,
   NULLP,
   soMsgDefProxyFeatureChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefProxyFeatureElmnt =
{
#ifdef CM_ABNF_DBG
   "SO PROXY",
   "SORE_PROXY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 639,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefProxyFeatureChoice,
   soRegExpProxyChoice
};

/********************************************************
Request-Disposition - Cancel -  Choice
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefCancelFeatureChoiceEnum[] =
{
   NULLP,
   &soMsgDefCancelStr,
   &soMsgDefNoCancelStr 
};

PUBLIC CmAbnfElmTypeChoice soMsgDefCancelFeatureChoice =
{
   3,
   0,
   NULLP,
   NULLP,
   soMsgDefCancelFeatureChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefCancelFeatureElmnt =
{
#ifdef CM_ABNF_DBG
   "SO CANCEL",
   "SORE_CANCEL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 640,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefCancelFeatureChoice,
   soRegExpCancelChoice
};

/********************************************************
Request-Disposition - Fork -  Choice
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefForkFeatureChoiceEnum[] =
{
   NULLP,
   &soMsgDefForkStr,
   &soMsgDefNoForkStr 
};

PUBLIC CmAbnfElmTypeChoice soMsgDefForkFeatureChoice =
{
   3,
   0,
   NULLP,
   NULLP,
   soMsgDefForkFeatureChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefForkFeatureElmnt =
{
#ifdef CM_ABNF_DBG
   "SO FORK",
   "SORE_FORK",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 641,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefForkFeatureChoice,
   soRegExpForkChoice
};

/********************************************************
Request-Disposition - Recurse -  Choice
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefRecurseFeatureChoiceEnum[] =
{
   NULLP,
   &soMsgDefRecurseStr,
   &soMsgDefNoRecurseStr 
};

PUBLIC CmAbnfElmTypeChoice soMsgDefRecurseFeatureChoice =
{
   3,
   0,
   NULLP,
   NULLP,
   soMsgDefRecurseFeatureChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefRecurseFeatureElmnt =
{
#ifdef CM_ABNF_DBG
   "SO FORK",
   "SORE_FORK",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 642,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefRecurseFeatureChoice,
   soRegExpRecurseChoice
};

/********************************************************
Request-Disposition - Parallel - Choice
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefParallelFeatureChoiceEnum[] =
{
   NULLP,
   &soMsgDefParallelStr,
   &soMsgDefSequentialStr 
};

PUBLIC CmAbnfElmTypeChoice soMsgDefParallelFeatureChoice =
{
   3,
   0,
   NULLP,
   NULLP,
   soMsgDefParallelFeatureChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefParallelFeatureElmnt =
{
#ifdef CM_ABNF_DBG
   "SO FORK",
   "SORE_FORK",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 643,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefParallelFeatureChoice,
   soRegExpParallelChoice
};

/********************************************************
Request-Disposition - Queue - Choice
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefQueueFeatureChoiceEnum[] =
{
   NULLP,
   &soMsgDefQueueStr,
   &soMsgDefNoQueueStr 
};

PUBLIC CmAbnfElmTypeChoice soMsgDefQueueFeatureChoice =
{
   3,
   0,
   NULLP,
   NULLP,
   soMsgDefQueueFeatureChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefQueueFeatureElmnt =
{
#ifdef CM_ABNF_DBG
   "SO QUEU",
   "SORE_QUEUE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 644,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefQueueFeatureChoice,
   soRegExpQueueChoice
};

/********************************************************
RequestDisposition - Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefRequestDispositionList1ChcEnum[] =
{
   NULLP,
   &soMsgDefProxyFeatureStr,
   &soMsgDefCancelFeatureStr,
   &soMsgDefForkFeatureStr,
   &soMsgDefRecurseFeatureStr,
   &soMsgDefParallelFeatureStr,
   &soMsgDefQueueFeatureStr,
};

PUBLIC CmAbnfElmDef *soMsgDefRequestDispositionList1ChcElmnt[] =
{
   NULLP,
   &soMsgDefProxyFeatureElmnt /**soMsgDefProxyFeature*/,
   &soMsgDefCancelFeatureElmnt /*soMsgDefCancelFeature*/,
   &soMsgDefForkFeatureElmnt /*soMsgDefForkFeature*/,
   &soMsgDefRecurseFeatureElmnt /*soMsgDefRecurseFeature*/,
   &soMsgDefParallelFeatureElmnt /*soMsgDefParallelFeature*/,
   &soMsgDefQueueFeatureElmnt /*soMsgDefQueueFeature */
};


PUBLIC CmAbnfElmTypeChoice soMsgDefRequestDispositionList1Choice =
{
   7,
   0,
   NULLP,
   soMsgDefRequestDispositionList1ChcElmnt,
   soMsgDefRequestDispositionList1ChcEnum 
};

PUBLIC CmAbnfElmDef soMsgDefRequestDispositionList1 =
{
#ifdef CM_ABNF_DBG
   "SO REQUESTDISPOSITION",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 645,
   sizeof(SoRequestDispositionParam),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefRequestDispositionList1Choice,
   soRegExpRequestDispositionChoice 
};

/********************************************************
RequestDispositionList - Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefRequestDispositionListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefRequestDispositionList1
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefRequestDispositionListSeqOf =
{
   1,
   SO_MAX_NUM_REQUEST_DISPOSITION,
   2,
   soMsgDefRequestDispositionListSeqOfElmnt,
   sizeof(SoRequestDispositionParam)
};

PUBLIC CmAbnfElmDef soMsgDefRequestDispositionList =
{
#ifdef CM_ABNF_DBG
   "SO REQUESTDISPOSITIONLIST",
   "SORE_COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 646,
   sizeof(SoRequestDispositionParam),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefRequestDispositionListSeqOf,
   soRegExpMetaComma
};

/********************************************************
RequestDispostionH - Optional Sequence Of
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefRequestDispositionHSeqElmnt[] =
{
   &soMsgDefRequestDispositionList1,
   &soMsgDefRequestDispositionList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRequestDispositionHSeq =
{
   2,
   soMsgDefRequestDispositionHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefRequestDispositionValH = 
{
#ifdef CM_ABNF_DBG
   "SO REQUESTDISPOSITION",
   "SORE_REQUESTDISPOSITION",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 647,
   sizeof(SoRequestDispositionParam),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefRequestDispositionHSeq,
   NULLP
};

/********************************************************
Request-Disposition - Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefRequestDispositionSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefRequestDispositionValH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRequestDispositionSeq =
{
   3,
   soMsgDefRequestDispositionSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefRequestDisposition =
{
#ifdef CM_ABNF_DBG
   "SO REQUEST-DISPOSITION",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 648,
   sizeof(SoRequestDisposition),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefRequestDispositionSeq,
   NULLP
};

/********************************************************
Accept-Contact - Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmTypeEnum  soMsgDefAcParamFpEnum =
{
    (Data *)"",
    SO_ACCEPTCONTACT_PAR_FP
};

PUBLIC CmAbnfElmDef  soMsgDefAcParamFpEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP AC PARAM FP ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 649,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefAcParamFpEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefAcParamRequireEnum =
{
    (Data *)"require",
    SO_ACCEPTCONTACT_PAR_REQUIRE
};

PUBLIC CmAbnfElmDef  soMsgDefAcParamRequireEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP AC PARAM REQUIRE ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 650,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefAcParamRequireEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefAcParamExplicitEnum =
{
    (Data *)"explicit",
    SO_ACCEPTCONTACT_PAR_EXPLICIT
};

PUBLIC CmAbnfElmDef  soMsgDefAcParamExplicitEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP AC PARAM EXPLICIT ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 651,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefAcParamExplicitEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefAcParamExtnEnum =
{
    (Data *)"",
    SO_ACCEPTCONTACT_PAR_EXTN
};

PUBLIC CmAbnfElmDef  soMsgDefAcParamExtnEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP AC PARAM EXTN ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 652,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefAcParamExtnEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefAcParamChcEnum[] =
{
   NULLP,
   &soMsgDefAcParamFpEnumDef,
   &soMsgDefAcParamRequireEnumDef,
   &soMsgDefAcParamExplicitEnumDef,
   &soMsgDefAcParamExtnEnumDef,
};

PUBLIC CmAbnfElmDef  *soMsgDefAcParamChcElmnt[] =
{
   NULLP,
   &soMsgDefFeatParam,
   NULLP,
   NULLP,
   &soMsgDefGenericParam,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefAcParamChc =
{
    5,
    0,
    NULLP,
    soMsgDefAcParamChcElmnt,
    soMsgDefAcParamChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefAcParam =
{
#ifdef  CM_ABNF_DBG
    "SIP AC PARAM ",
    "soRegExpMetaComma",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 653,
    sizeof(SoAcParam),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soMsgDefAcParamChc,
    soRegExpAcParam
};

PUBLIC CmAbnfElmDef  *soMsgDefAcParamOptListSeqOfElmnts[] =
{
    &soMsgDefMetaSemiColonStr,
    &soMsgDefAcParam
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefAcParamOptListSeqOf =
{
    0,
    SO_MAX_ACPARAM,
    2,
    soMsgDefAcParamOptListSeqOfElmnts,
    sizeof (SoAcParam)
};

PUBLIC CmAbnfElmDef  soMsgDefAcParamOptList =
{
#ifdef  CM_ABNF_DBG
    "SIP AC PARAM OPT LIST ",
    "soRegExpMetaSemiColon",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 654,
    sizeof(SoAcParams),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQOF,
    (U8 *) &soMsgDefAcParamOptListSeqOf,
    soRegExpMetaSemiColon
};

PUBLIC CmAbnfElmDef  *soMsgDefAcValSeqElmnts[] =
{
    &soMsgDefMetaStarStr,
    &soMsgDefAcParamOptList
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefAcValSeq =
{
    2,
    soMsgDefAcValSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefAcVal =
{
#ifdef  CM_ABNF_DBG
    "SIP AC VAL ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 655,
    sizeof(SoAcParams),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefAcValSeq,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefAcValOptListSeqOfElmnts[] =
{
    &soMsgDefMetaCommaStr,
    &soMsgDefAcVal
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefAcValOptListSeqOf =
{
    0,
    SO_MAX_ACPARAM,
    2,
    soMsgDefAcValOptListSeqOfElmnts,
    sizeof (SoAcParams)
};

PUBLIC CmAbnfElmDef  soMsgDefAcValOptList =
{
#ifdef  CM_ABNF_DBG
    "SIP AC VAL OPT LIST ",
    "soRegExpMetaComma",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 656,
    sizeof(SoAcceptContact),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQOF,
    (U8 *) &soMsgDefAcValOptListSeqOf,
    soRegExpMetaComma
};

PUBLIC CmAbnfElmDef  *soMsgDefAcceptContactListSeqElmnts[] =
{
    &soMsgDefAcVal,
    &soMsgDefAcValOptList
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefAcceptContactListSeq =
{
    2,
    soMsgDefAcceptContactListSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefAcceptContactList =
{
#ifdef  CM_ABNF_DBG
    "SIP ACCEPT CONTACT LIST ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 657,
    sizeof(SoAcceptContact),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQOF,
    (U8 *) &soMsgDefAcceptContactListSeq,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefAcceptContactSeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr,
    &soMsgDefAcceptContactList,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefAcceptContactSeq =
{
    3,
    soMsgDefAcceptContactSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefAcceptContact =
{
#ifdef  CM_ABNF_DBG
    "SIP ACCEPT CONTACT ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 658,
    sizeof(SoAcceptContact),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefAcceptContactSeq,
    NULLP
};

/********************************************************
Reject-Contact - Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmTypeEnum  soMsgDefRcParamFpEnum =
{
    (Data *)"",
    SO_REJECTCONTACT_PAR_FP
};

PUBLIC CmAbnfElmDef  soMsgDefRcParamFpEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP RC PARAM FP ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 659,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefRcParamFpEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefRcParamExtnEnum =
{
    (Data *)"",
    SO_REJECTCONTACT_PAR_EXTN
};

PUBLIC CmAbnfElmDef  soMsgDefRcParamExtnEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP RC PARAM EXTN ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 660,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefRcParamExtnEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefRcParamChcEnum[] =
{
    NULLP,
    &soMsgDefRcParamFpEnumDef,
    &soMsgDefRcParamExtnEnumDef,
};

PUBLIC CmAbnfElmDef  *soMsgDefRcParamChcElmnt[] =
{
    NULLP,
    &soMsgDefFeatParam,
    &soMsgDefGenericParam,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefRcParamChc =
{
    3,
    0,
    NULLP,
    soMsgDefRcParamChcElmnt,
    soMsgDefRcParamChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefRcParam =
{
#ifdef  CM_ABNF_DBG
    "SIP RC PARAM ",
    "soRegExpMetaComma",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 661,
    sizeof(SoRcParam),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soMsgDefRcParamChc,
    soRegExpRcParam
};

PUBLIC CmAbnfElmDef  *soMsgDefRcParamOptListSeqOfElmnts[] =
{
    &soMsgDefMetaSemiColonStr,
    &soMsgDefRcParam
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefRcParamOptListSeqOf =
{
    0,
    SO_MAX_RCPARAM,
    2,
    soMsgDefRcParamOptListSeqOfElmnts,
    sizeof (SoRcParam)
};

PUBLIC CmAbnfElmDef  soMsgDefRcParamOptList =
{
#ifdef  CM_ABNF_DBG
    "SIP RC PARAM OPT LIST ",
    "soRegExpMetaSemiColon",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 662,
    sizeof(SoRcParams),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQOF,
    (U8 *) &soMsgDefRcParamOptListSeqOf,
    soRegExpMetaSemiColon
};

PUBLIC CmAbnfElmDef  *soMsgDefRcValSeqElmnts[] =
{
    &soMsgDefMetaStarStr,
    &soMsgDefRcParamOptList
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefRcValSeq =
{
    2,
    soMsgDefRcValSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefRcVal =
{
#ifdef  CM_ABNF_DBG
    "SIP RC VAL ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 663,
    sizeof(SoRcParams),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefRcValSeq,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefRcValOptListSeqOfElmnts[] =
{
    &soMsgDefMetaCommaStr,
    &soMsgDefRcVal
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefRcValOptListSeqOf =
{
    0,
    SO_MAX_RCPARAM,
    2,
    soMsgDefRcValOptListSeqOfElmnts,
    sizeof (SoRcParams)
};

PUBLIC CmAbnfElmDef  soMsgDefRcValOptList =
{
#ifdef  CM_ABNF_DBG
    "SIP RC VAL OPT LIST ",
    "soRegExpMetaComma",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 664,
    sizeof(SoRejectContact),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQOF,
    (U8 *) &soMsgDefRcValOptListSeqOf,
    soRegExpMetaComma
};

PUBLIC CmAbnfElmDef  *soMsgDefRejectContactListSeqElmnts[] =
{
    &soMsgDefRcVal,
    &soMsgDefRcValOptList
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefRejectContactListSeq =
{
    2,
    soMsgDefRejectContactListSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefRejectContactList =
{
#ifdef  CM_ABNF_DBG
    "SIP REJECT CONTACT LIST ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 665,
    sizeof(SoRejectContact),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQOF,
    (U8 *) &soMsgDefRejectContactListSeq,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefRejectContactSeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr,
    &soMsgDefRejectContactList,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefRejectContactSeq =
{
    3,
    soMsgDefRejectContactSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefRejectContact =
{
#ifdef  CM_ABNF_DBG
    "SIP REJECT CONTACT ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 666,
    sizeof(SoRejectContact),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefRejectContactSeq,
    NULLP
};

#endif /* SO_CALLER_PREF */


/* BEGIN: Three new headers support */


PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpi_screen_noEnum =
{
    (Data *)"no" ,
    SO_RPI_SCREEN_NO
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_screen_noEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPI_SCREEN_NOENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 667,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpi_screen_noEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpi_screen_yesEnum =
{
    (Data *)"yes" ,
    SO_RPI_SCREEN_YES
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_screen_yesEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPI_SCREEN_YESENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 668,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpi_screen_yesEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_screenValChcEnum[] =
{
    NULLP ,
    &soMsgDef_rpi_screen_noEnumDef ,
    &soMsgDef_rpi_screen_yesEnumDef ,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDef_rpi_screenValChc =
{
    3 ,
    0 ,
    NULLP ,
    NULLP ,
    soMsgDef_rpi_screenValChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_screenVal =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_SCREENVAL " ,
    "soRegExpRpiScreenVal" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 669,
    sizeof(TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &soMsgDef_rpi_screenValChc ,
    soRegExpRpiScreenVal
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_screenSeqElmnts[] =
{
    &soMsgDefMetaSws ,
    &soMsgDefMetaEqualStr ,
    &soMsgDefMetaSws ,
    &soMsgDef_rpi_screenVal
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_rpi_screenSeq =
{
    4 ,
    soMsgDef_rpi_screenSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_screen =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_SCREEN" ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 670,
    sizeof(TknU8) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDef_rpi_screenSeq ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpi_pty_type_callingEnum =
{
    (Data *)"calling" ,
    SO_RPI_PTY_TYPE_CALLING
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_pty_type_callingEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPI_PTY_TYPE_CALLINGENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 671,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpi_pty_type_callingEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpi_pty_type_calledEnum =
{
    (Data *)"called" ,
    SO_RPI_PTY_TYPE_CALLED
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_pty_type_calledEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPI_PTY_TYPE_CALLEDENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 672,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpi_pty_type_calledEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpi_pty_type_TokenEnum =
{
    (Data *)"" ,
    SO_RPI_PTY_TYPE_TOKEN
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_pty_type_TokenEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO rpi_pty_type TOKEN ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 673,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpi_pty_type_TokenEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_pty_typeValChcEnum[] =
{
    NULLP ,
    &soMsgDef_rpi_pty_type_callingEnumDef ,
    &soMsgDef_rpi_pty_type_calledEnumDef ,
    &soMsgDef_rpi_pty_type_TokenEnumDef ,
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_pty_typeValChcElmnt[] =
{
    NULLP ,
    NULLP ,
    NULLP ,
    &soMsgDefToken ,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDef_rpi_pty_typeValChc =
{
    4 ,
    0 ,
    NULLP ,
    soMsgDef_rpi_pty_typeValChcElmnt ,
    soMsgDef_rpi_pty_typeValChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_pty_typeVal =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_PTY_TYPEVAL " ,
    "soRegExpRpiPtyTypeVal" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 674,
    sizeof(SoStrValue) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &soMsgDef_rpi_pty_typeValChc ,
    soRegExpRpiPtyTypeVal
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_pty_typeSeqElmnts[] =
{
    &soMsgDefMetaSws ,
    &soMsgDefMetaEqualStr ,
    &soMsgDefMetaSws ,
    &soMsgDef_rpi_pty_typeVal
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_rpi_pty_typeSeq =
{
    4 ,
    soMsgDef_rpi_pty_typeSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_pty_type =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_PTY_TYPE" ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 675,
    sizeof(SoStrValue) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDef_rpi_pty_typeSeq ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpi_id_type_subsEnum =
{
    (Data *)"subscriber" ,
    SO_RPI_ID_TYPE_SUBS
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_id_type_subsEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPI_ID_TYPE_SUBSENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 676,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpi_id_type_subsEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpi_id_type_userEnum =
{
    (Data *)"user" ,
    SO_RPI_ID_TYPE_USER
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_id_type_userEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPI_ID_TYPE_USERENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 677,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpi_id_type_userEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpi_id_type_termEnum =
{
    (Data *)"term" ,
    SO_RPI_ID_TYPE_TERM
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_id_type_termEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPI_ID_TYPE_TERMENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 678,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpi_id_type_termEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpi_id_type_TokenEnum =
{
    (Data *)"" ,
    SO_RPI_ID_TYPE_TOKEN
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_id_type_TokenEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO rpi_id_type TOKEN ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 679,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpi_id_type_TokenEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_id_typeValChcEnum[] =
{
    NULLP ,
    &soMsgDef_rpi_id_type_subsEnumDef ,
    &soMsgDef_rpi_id_type_userEnumDef ,
    &soMsgDef_rpi_id_type_termEnumDef ,
    &soMsgDef_rpi_id_type_TokenEnumDef ,
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_id_typeValChcElmnt[] =
{
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    &soMsgDefToken ,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDef_rpi_id_typeValChc =
{
    5 ,
    0 ,
    NULLP ,
    soMsgDef_rpi_id_typeValChcElmnt ,
    soMsgDef_rpi_id_typeValChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_id_typeVal =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_ID_TYPEVAL " ,
    "soRegExpRpiIdTypeVal" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 680,
    sizeof(SoStrValue) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &soMsgDef_rpi_id_typeValChc ,
    soRegExpRpiIdTypeVal
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_id_typeSeqElmnts[] =
{
    &soMsgDefMetaSws ,
    &soMsgDefMetaEqualStr ,
    &soMsgDefMetaSws ,
    &soMsgDef_rpi_id_typeVal
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_rpi_id_typeSeq =
{
    4 ,
    soMsgDef_rpi_id_typeSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_id_type =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_ID_TYPE" ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 681,
    sizeof(SoStrValue) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDef_rpi_id_typeSeq ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpiPrvElmTypFullEnum =
{
    (Data *)"full" ,
    SO_RPI_PRV_ELM_TYP_FULL
};

PUBLIC CmAbnfElmDef  soMsgDef_rpiPrvElmTypFullEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPIPRV ELM TYP FULL ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 682,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpiPrvElmTypFullEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpiPrvElmTypNameEnum =
{
    (Data *)"name" ,
    SO_RPI_PRV_ELM_TYP_NAME
};

PUBLIC CmAbnfElmDef  soMsgDef_rpiPrvElmTypNameEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPIPRV ELM TYP NAME ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 683,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpiPrvElmTypNameEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpiPrvElmTypUriEnum =
{
    (Data *)"uri" ,
    SO_RPI_PRV_ELM_TYP_URI
};

PUBLIC CmAbnfElmDef  soMsgDef_rpiPrvElmTypUriEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPIPRV ELM TYP URI ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 684,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpiPrvElmTypUriEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpiPrvElmTypOffEnum =
{
    (Data *)"off" ,
    SO_RPI_PRV_ELM_TYP_OFF
};

PUBLIC CmAbnfElmDef  soMsgDef_rpiPrvElmTypOffEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPIPRV ELM TYP OFF ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 685,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpiPrvElmTypOffEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpiPrvElmTypTokenEnum =
{
    (Data *)"" ,
    SO_RPI_PRV_ELM_TYP_TOKEN
};

PUBLIC CmAbnfElmDef  soMsgDef_rpiPrvElmTypTokenEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO rpiPrvElmTyp TOKEN ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 686,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpiPrvElmTypTokenEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_priv_element_typeChcEnum[] =
{
    NULLP ,
    &soMsgDef_rpiPrvElmTypFullEnumDef ,
    &soMsgDef_rpiPrvElmTypNameEnumDef ,
    &soMsgDef_rpiPrvElmTypUriEnumDef ,
    &soMsgDef_rpiPrvElmTypOffEnumDef ,
    &soMsgDef_rpiPrvElmTypTokenEnumDef ,
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_priv_element_typeChcElmnt[] =
{
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    &soMsgDefToken ,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDef_rpi_priv_element_typeChc =
{
    6 ,
    0 ,
    NULLP ,
    soMsgDef_rpi_priv_element_typeChcElmnt ,
    soMsgDef_rpi_priv_element_typeChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_priv_element_type =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_PRIV_ELEMENT_TYPE" ,
    "soRegExpRpiPrivElmType" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 687,
    sizeof(SoStrValue) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &soMsgDef_rpi_priv_element_typeChc ,
    soRegExpRpiPrivElmType
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpiPrvElmValNwEnum =
{
    (Data *)"network" ,
    SO_RPI_PRV_ELM_VAL_NW
};

PUBLIC CmAbnfElmDef  soMsgDef_rpiPrvElmValNwEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPIPRV ELM VAL NW ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 688,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpiPrvElmValNwEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpiPrvElmValTokenEnum =
{
    (Data *)"" ,
    SO_RPI_PRV_ELM_VAL_TOKEN
};

PUBLIC CmAbnfElmDef  soMsgDef_rpiPrvElmValTokenEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO rpiPrvElmVal TOKEN ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 689,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpiPrvElmValTokenEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_priv_element_valChcEnum[] =
{
    NULLP ,
    &soMsgDef_rpiPrvElmValNwEnumDef ,
    &soMsgDef_rpiPrvElmValTokenEnumDef ,
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_priv_element_valChcElmnt[] =
{
    NULLP ,
    NULLP ,
    &soMsgDefToken ,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDef_rpi_priv_element_valChc =
{
    3 ,
    0 ,
    NULLP ,
    soMsgDef_rpi_priv_element_valChcElmnt ,
    soMsgDef_rpi_priv_element_valChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_priv_element_val =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_PRIV_ELEMENT_VAL" ,
    "soRegExpRpiPrivElmVal" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 690,
    sizeof(SoStrValue) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &soMsgDef_rpi_priv_element_valChc ,
    soRegExpRpiPrivElmVal
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_Optpriv_element_valSeqElmnts[] =
{
    &cmMsgDefMetaHyphen ,
    &soMsgDef_rpi_priv_element_val
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_rpi_Optpriv_element_valSeq =
{
    2 ,
    soMsgDef_rpi_Optpriv_element_valSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_Optpriv_element_val =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_OPTPRIV_ELEMENT_VAL " ,
    "cmAbnfRegExpHyphen" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 691,
    sizeof(SoStrValue) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDef_rpi_Optpriv_element_valSeq ,
    cmAbnfRegExpHyphen
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_priv_elementSeqElmnts[] =
{
    &soMsgDef_rpi_priv_element_type ,
    &soMsgDef_rpi_Optpriv_element_val
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_rpi_priv_elementSeq =
{
    2 ,
    soMsgDef_rpi_priv_elementSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_priv_element =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_PRIV_ELEMENT" ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 692,
    sizeof(SoTypeVal) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDef_rpi_priv_elementSeq ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_Optpriv_elementLstSeqOfElmnts[] =
{
    &soMsgDefMetaCommaStr ,
    &soMsgDef_rpi_priv_element
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDef_rpi_Optpriv_elementLstSeqOf =
{
    1 ,
    SO_MAX_RPI_PRIV_LST ,
    2 ,
    soMsgDef_rpi_Optpriv_elementLstSeqOfElmnts ,
    sizeof (SoTypeVal)
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_Optpriv_elementLst =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_OPTPRIV_ELEMENT LST " ,
    "soRegExpMetaComma" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 693,
    sizeof(SoPrivLst) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &soMsgDef_rpi_Optpriv_elementLstSeqOf ,
    soRegExpMetaComma
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_priv_elementLstSeqElmnts[] =
{
    &soMsgDef_rpi_priv_element ,
    &soMsgDef_rpi_Optpriv_elementLst
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_rpi_priv_elementLstSeq =
{
    2 ,
    soMsgDef_rpi_priv_elementLstSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_priv_elementLst =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_PRIV_ELEMENTLST " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 694,
    sizeof(SoPrivLst) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQOF ,
    (U8 *) &soMsgDef_rpi_priv_elementLstSeq ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_priv_elementCondLstSeqElmnts[] =
{
    &soMsgDefMetaSws ,
    &soMsgDefMetaDQuoteStr ,
    &soMsgDef_rpi_priv_elementLst ,
    &soMsgDefMetaDQuoteStr ,
    &soMsgDefMetaSws
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_rpi_priv_elementCondLstSeq =
{
    5 ,
    soMsgDef_rpi_priv_elementCondLstSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_priv_elementCondLst =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_PRIV_ELEMENTCOND LST " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 695,
    sizeof(SoPrivLst) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CONDSEQOF ,
    (U8 *) &soMsgDef_rpi_priv_elementCondLstSeq ,
    soRegExpMetaSwsDQuote
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_privacyValSeqElmnts[] =
{
    &soMsgDef_rpi_priv_element ,
    &soMsgDef_rpi_priv_elementCondLst
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_rpi_privacyValSeq =
{
    2 ,
    soMsgDef_rpi_privacyValSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_privacyVal =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_PRIVACYVAL " ,
    "soRegExpMetaSwsDQuote" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 696,
    sizeof(SoPrivLst) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_CHSEQOF ,
    (U8 *) &soMsgDef_rpi_privacyValSeq ,
    soRegExpMetaSwsDQuote
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_privacySeqElmnts[] =
{
    &soMsgDefMetaSws ,
    &soMsgDefMetaEqualStr ,
    &soMsgDefMetaSws ,
    &soMsgDef_rpi_privacyVal
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_rpi_privacySeq =
{
    4 ,
    soMsgDef_rpi_privacySeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_privacy =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_PRIVACY" ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 697,
    sizeof(SoPrivLst) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDef_rpi_privacySeq ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokTypNPEnum =
{
    (Data *)"np" ,
    SO_OTHER_RPI_TOK_TYP_NP
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokTypNPEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKTYP NP ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 698,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokTypNPEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokTypTokenEnum =
{
    (Data *)"" ,
    SO_OTHER_RPI_TOK_TYP_TOKEN
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokTypTokenEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO TOKEN ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 699,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokTypTokenEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokTypHypTokEnum =
{
    (Data *)"-" ,
    SO_OTHER_RPI_TOK_TYP_HYP_TOK
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokTypHypTokEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKTYP HYP TOK ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 700,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokTypHypTokEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_other_rpi_tokenTypeChcEnum[] =
{
    NULLP ,
    &soMsgDef_other_rpi_tokTypNPEnumDef ,
    &soMsgDef_other_rpi_tokTypHypTokEnumDef ,
    &soMsgDef_other_rpi_tokTypTokenEnumDef ,
};

PUBLIC CmAbnfElmDef  *soMsgDef_other_rpi_tokenTypeChcElmnt[] =
{
    NULLP ,
    NULLP ,
    &soMsgDefToken ,
    &soMsgDefToken ,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDef_other_rpi_tokenTypeChc =
{
    4 ,
    0 ,
    NULLP ,
    soMsgDef_other_rpi_tokenTypeChcElmnt ,
    soMsgDef_other_rpi_tokenTypeChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokenType =
{
#ifdef  CM_ABNF_DBG
    "SO _OTHER_RPI_TOKENTYPE " ,
    "soRegExpOtherRpiTokenType" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 701,
    sizeof(SoStrValue) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &soMsgDef_other_rpi_tokenTypeChc ,
    soRegExpOtherRpiTokenType
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValOrdEnum =
{
    (Data *)"ordinary" ,
    SO_OTHER_RPI_TOK_VAL_ORD
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValOrdEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL ORD ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 702,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValOrdEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValResEnum =
{
    (Data *)"residential" ,
    SO_OTHER_RPI_TOK_VAL_RES
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValResEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL RES ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 703,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValResEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValBusEnum =
{
    (Data *)"business" ,
    SO_OTHER_RPI_TOK_VAL_BUS
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValBusEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL BUS ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 704,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValBusEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValPriEnum =
{
    (Data *)"priority" ,
    SO_OTHER_RPI_TOK_VAL_PRI
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValPriEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL PRI ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 705,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValPriEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValHotEnum =
{
    (Data *)"hotel" ,
    SO_OTHER_RPI_TOK_VAL_HOT
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValHotEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL HOT ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 706,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValHotEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValFailEnum =
{
    (Data *)"failure" ,
    SO_OTHER_RPI_TOK_VAL_FAIL
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValFailEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL FAIL ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 707,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValFailEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValHospEnum =
{
    (Data *)"hospital" ,
    SO_OTHER_RPI_TOK_VAL_HOSP
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValHospEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL HOSP ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 708,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValHospEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValPrisonEnum =
{
    (Data *)"prison" ,
    SO_OTHER_RPI_TOK_VAL_PRISON
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValPrisonEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL PRISON ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 709,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValPrisonEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValPolEnum =
{
    (Data *)"police" ,
    SO_OTHER_RPI_TOK_VAL_POL
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValPolEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL POL ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 710,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValPolEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValTstEnum =
{
    (Data *)"test" ,
    SO_OTHER_RPI_TOK_VAL_TST
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValTstEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL TST ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 711,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValTstEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValPayPhEnum =
{
    (Data *)"payphone" ,
    SO_OTHER_RPI_TOK_VAL_PAY_PH
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValPayPhEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL PAY PH ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 712,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValPayPhEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValCoinEnum =
{
    (Data *)"coin" ,
    SO_OTHER_RPI_TOK_VAL_COIN
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValCoinEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL COIN ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 713,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValCoinEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValPubPayPhEnum =
{
    (Data *)"payphone-public" ,
    SO_OTHER_RPI_TOK_VAL_PUB_PAY_PH
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValPubPayPhEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL PUB PAY PH ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 714,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValPubPayPhEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValPrivPayPhEnum =
{
    (Data *)"payphone-private" ,
    SO_OTHER_RPI_TOK_VAL_PRIV_PAY_PH
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValPrivPayPhEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL PRIV PAY PH ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 715,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValPrivPayPhEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValCoinlessEnum =
{
    (Data *)"coinless" ,
    SO_OTHER_RPI_TOK_VAL_COINLESS
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValCoinlessEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL COINLESS ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 716,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValCoinlessEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValRestrctEnum =
{
    (Data *)"restrict" ,
    SO_OTHER_RPI_TOK_VAL_RESTRCT
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValRestrctEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL RESTRCT ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 717,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValRestrctEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValCoinRestrctEnum =
{
    (Data *)"coin-restrict" ,
    SO_OTHER_RPI_TOK_VAL_COIN_RESTRCT
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValCoinRestrctEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL COIN RESTRCT ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 718,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValCoinRestrctEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValCoinlessRestrctEnum =
{
    (Data *)"coinless-restrict" ,
    SO_OTHER_RPI_TOK_VAL_COINLESS_RESTRCT
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValCoinlessRestrctEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL COINLESS RESTRCT ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 719,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValCoinlessRestrctEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValReserveEnum =
{
    (Data *)"reserved" ,
    SO_OTHER_RPI_TOK_VAL_RESERVE
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValReserveEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL RESERVE ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 720,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValReserveEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValOprEnum =
{
    (Data *)"operator" ,
    SO_OTHER_RPI_TOK_VAL_OPR
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValOprEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL OPR ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 721,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValOprEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValFreePhEnum =
{
    (Data *)"trans-freephone" ,
    SO_OTHER_RPI_TOK_VAL_FREE_PH
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValFreePhEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL FREE PH ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 722,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValFreePhEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValIsdnResEnum =
{
    (Data *)"isdn-res" ,
    SO_OTHER_RPI_TOK_VAL_ISDN_RES
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValIsdnResEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL ISDN RES ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 723,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValIsdnResEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValIsdnBusEnum =
{
    (Data *)"isdn-bus" ,
    SO_OTHER_RPI_TOK_VAL_ISDN_BUS
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValIsdnBusEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL ISDN BUS ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 724,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValIsdnBusEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValUnkEnum =
{
    (Data *)"unknown" ,
    SO_OTHER_RPI_TOK_VAL_UNK
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValUnkEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL UNK ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 725,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValUnkEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValEmgEnum =
{
    (Data *)"emergency" ,
    SO_OTHER_RPI_TOK_VAL_EMG
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValEmgEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL EMG ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 726,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValEmgEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValNonAppEnum =
{
    (Data *)"not-applicable" ,
    SO_OTHER_RPI_TOK_VAL_NON_APP
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValNonAppEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL NON APP ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 727,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValNonAppEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValCellOrdEnum =
{
    (Data *)"cellular-ordinary" ,
    SO_OTHER_RPI_TOK_VAL_CELL_ORD
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValCellOrdEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL CELL ORD ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 728,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValCellOrdEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokValCellRoamEnum =
{
    (Data *)"cellular-roaming" ,
    SO_OTHER_RPI_TOK_VAL_CELL_ROAM
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokValCellRoamEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKVAL CELL ROAM ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 729,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokValCellRoamEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_Optother_rpi_tokenValChcEnum[] =
{
    NULLP ,
    NULLP ,
    NULLP ,
    &soMsgDef_other_rpi_tokValOrdEnumDef ,
    &soMsgDef_other_rpi_tokValResEnumDef ,
    &soMsgDef_other_rpi_tokValBusEnumDef ,
    &soMsgDef_other_rpi_tokValPriEnumDef ,
    &soMsgDef_other_rpi_tokValHotEnumDef ,
    &soMsgDef_other_rpi_tokValFailEnumDef ,
    &soMsgDef_other_rpi_tokValHospEnumDef ,
    &soMsgDef_other_rpi_tokValPrisonEnumDef ,
    &soMsgDef_other_rpi_tokValPolEnumDef ,
    &soMsgDef_other_rpi_tokValTstEnumDef ,
    &soMsgDef_other_rpi_tokValPayPhEnumDef ,
    &soMsgDef_other_rpi_tokValCoinEnumDef ,
    &soMsgDef_other_rpi_tokValPubPayPhEnumDef ,
    &soMsgDef_other_rpi_tokValPrivPayPhEnumDef ,
    &soMsgDef_other_rpi_tokValCoinlessEnumDef ,
    &soMsgDef_other_rpi_tokValRestrctEnumDef ,
    &soMsgDef_other_rpi_tokValCoinRestrctEnumDef ,
    &soMsgDef_other_rpi_tokValCoinlessRestrctEnumDef ,
    &soMsgDef_other_rpi_tokValReserveEnumDef ,
    &soMsgDef_other_rpi_tokValOprEnumDef ,
    &soMsgDef_other_rpi_tokValFreePhEnumDef ,
    &soMsgDef_other_rpi_tokValIsdnResEnumDef ,
    &soMsgDef_other_rpi_tokValIsdnBusEnumDef ,
    &soMsgDef_other_rpi_tokValUnkEnumDef ,
    &soMsgDef_other_rpi_tokValEmgEnumDef ,
    &soMsgDef_other_rpi_tokValNonAppEnumDef ,
    &soMsgDef_other_rpi_tokValCellOrdEnumDef ,
    &soMsgDef_other_rpi_tokValCellRoamEnumDef ,
    NULLP ,
};

PUBLIC CmAbnfElmDef  *soMsgDef_Optother_rpi_tokenValChcElmnt[] =
{
    NULLP ,
    &soMsgDefValue ,  /* used during encoding only and not during decoding */
    &soMsgDefValue ,  /* used during encoding only and not during decoding */
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    NULLP ,
    &soMsgDefValue ,  /* used during decoding only and not during encoding */
};

PUBLIC CmAbnfElmTypeChoice  soMsgDef_Optother_rpi_tokenValChc =
{
    32 ,
    0 ,
    NULLP ,
    soMsgDef_Optother_rpi_tokenValChcElmnt ,
    soMsgDef_Optother_rpi_tokenValChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDef_Optother_rpi_tokenVal =
{
#ifdef  CM_ABNF_DBG
    "SO _OPTOTHER_RPI_TOKEN VAL " ,
    "soRegExpOtherRpiTokenVal" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 730,
    sizeof(SoStrValue) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &soMsgDef_Optother_rpi_tokenValChc ,
    soRegExpOtherRpiTokenVal
};

PUBLIC CmAbnfElmDef  *soMsgDef_other_rpi_tokenValSeqElmnts[] =
{
    &soMsgDefMetaSws ,
    &soMsgDefMetaEqualStr ,
    &soMsgDefMetaSws ,
    &soMsgDef_Optother_rpi_tokenVal
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_other_rpi_tokenValSeq =
{
    4 ,
    soMsgDef_other_rpi_tokenValSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokenVal =
{
#ifdef  CM_ABNF_DBG
    "SO _OTHER_RPI_TOKENVAL " ,
    "soRegExpMetaSwsEqual" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 731,
    sizeof(SoStrValue) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDef_other_rpi_tokenValSeq ,
    soRegExpMetaSwsEqual
};

PUBLIC CmAbnfElmDef  *soMsgDef_other_rpi_tokenSeqElmnts[] =
{
    &soMsgDef_other_rpi_tokenType ,
    &soMsgDef_other_rpi_tokenVal
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_other_rpi_tokenSeq =
{
    2 ,
    soMsgDef_other_rpi_tokenSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_token =
{
#ifdef  CM_ABNF_DBG
    "SO _OTHER_RPI_TOKEN" ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 732,
    sizeof(SoTypeVal) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDef_other_rpi_tokenSeq ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpi_screenEnum =
{
    (Data *)"screen" ,
    SO_RPI_SCREEN
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_screenEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPI_SCREENENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 733,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpi_screenEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpi_pty_typeEnum =
{
    (Data *)"party" ,
    SO_RPI_PTY_TYPE
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_pty_typeEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPI_PTY_TYPEENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 734,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpi_pty_typeEnum ,
    NULLP
};

/* so017.201 : Changes id_type to id-type */

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpi_id_typeEnum =
{
    (Data *)"id-type" ,
    SO_RPI_ID_TYPE
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_id_typeEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPI_ID_TYPEENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 735,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpi_id_typeEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_rpi_privacyEnum =
{
    (Data *)"privacy" ,
    SO_RPI_PRIVACY
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_privacyEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _RPI_PRIVACYENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 736,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_rpi_privacyEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_other_rpi_tokenEnum =
{
    (Data *)"" ,
    SO_RPI_OTHER_RPI_TOKEN
};

PUBLIC CmAbnfElmDef  soMsgDef_other_rpi_tokenEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _OTHER_RPI_TOKENENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 737,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_other_rpi_tokenEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_tokenChcEnum[] =
{
    NULLP ,
    &soMsgDef_rpi_screenEnumDef ,
    &soMsgDef_rpi_pty_typeEnumDef ,
    &soMsgDef_rpi_id_typeEnumDef ,
    &soMsgDef_rpi_privacyEnumDef ,
    &soMsgDef_other_rpi_tokenEnumDef ,
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpi_tokenChcElmnt[] =
{
    NULLP ,
    &soMsgDef_rpi_screen ,
    &soMsgDef_rpi_pty_type ,
    &soMsgDef_rpi_id_type ,
    &soMsgDef_rpi_privacy ,
    &soMsgDef_other_rpi_token ,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDef_rpi_tokenChc =
{
    6 ,
    0 ,
    NULLP ,
    soMsgDef_rpi_tokenChcElmnt ,
    soMsgDef_rpi_tokenChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDef_rpi_token =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI_TOKEN" ,
    "soRegExpRpiTokType" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 738,
    sizeof(SoRpiTok) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &soMsgDef_rpi_tokenChc ,
    soRegExpRpiTokType
};

PUBLIC CmAbnfElmDef  *soMsgDef_RpiOptLstSeqOfElmnts[] =
{
    &soMsgDefMetaSemiColonStr ,
    &soMsgDef_rpi_token
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDef_RpiOptLstSeqOf =
{
    0 ,
    SO_MAX_RPI_LST ,
    2 ,
    soMsgDef_RpiOptLstSeqOfElmnts ,
    sizeof (SoRpiTok)
};

PUBLIC CmAbnfElmDef  soMsgDef_RpiOptLst =
{
#ifdef  CM_ABNF_DBG
    "SO _RPI OPT LST " ,
    "soRegExpMetaSemiColon" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 739,
    sizeof(SoRpiTokLst) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &soMsgDef_RpiOptLstSeqOf ,
    soRegExpMetaSemiColon
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpidSeqElmnts[] =
{
    &soMsgDefNameAddr,
    &soMsgDef_RpiOptLst
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_rpidSeq =
{
    2 ,
    soMsgDef_rpidSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_rpid =
{
#ifdef  CM_ABNF_DBG
    "SO _RPID" ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 740,
    sizeof(SoRpid) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDef_rpidSeq ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpidOptLstSeqOfElmnts[] =
{
    &soMsgDefMetaCommaStr ,
    &soMsgDef_rpid
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDef_rpidOptLstSeqOf =
{
    1 ,
    SO_MAX_RPID_LST ,
    2 ,
    soMsgDef_rpidOptLstSeqOfElmnts ,
    sizeof (SoRpid)
};

PUBLIC CmAbnfElmDef  soMsgDef_rpidOptLst =
{
#ifdef  CM_ABNF_DBG
    "SO _RPIDOPT LST " ,
    "soRegExpMetaComma" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 741,
    sizeof(SoRemPartyId) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &soMsgDef_rpidOptLstSeqOf ,
    soRegExpMetaComma
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpidLstSeqElmnts[] =
{
    &soMsgDef_rpid ,
    &soMsgDef_rpidOptLst
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_rpidLstSeq =
{
    2 ,
    soMsgDef_rpidLstSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_rpidLst =
{
#ifdef  CM_ABNF_DBG
    "SO _RPIDLST " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 742,
    sizeof(SoRemPartyId) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQOF ,
    (U8 *) &soMsgDef_rpidLstSeq ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_Remote_Party_IDSeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr ,
    &soMsgDef_rpidLst ,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_Remote_Party_IDSeq =
{
    3 ,
    soMsgDef_Remote_Party_IDSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_Remote_Party_ID =
{
#ifdef  CM_ABNF_DBG
    "SO _REMOTE_ PARTY_ I D " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 743,
    sizeof(SoRemPartyId) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDef_Remote_Party_IDSeq ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpid_Optprivacy_tokenLstSeqOfElmnts[] =
{
    &soMsgDefMetaSemiColonStr ,
    &soMsgDef_rpi_token
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDef_rpid_Optprivacy_tokenLstSeqOf =
{
    1 ,
    SO_MAX_RPID_PRIV_TOK ,
    2 ,
    soMsgDef_rpid_Optprivacy_tokenLstSeqOfElmnts ,
    sizeof (SoRpiTok)
};

PUBLIC CmAbnfElmDef  soMsgDef_rpid_Optprivacy_tokenLst =
{
#ifdef  CM_ABNF_DBG
    "SO _RPID_OPTPRIVACY_TOKEN LST " ,
    "soRegExpMetaSemiColon" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 744,
    sizeof(SoRpiTokLst) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &soMsgDef_rpid_Optprivacy_tokenLstSeqOf ,
    soRegExpMetaSemiColon
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpid_privSeqElmnts[] =
{
    &soMsgDef_rpi_token ,
    &soMsgDef_rpid_Optprivacy_tokenLst
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_rpid_privSeq =
{
    2 ,
    soMsgDef_rpid_privSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_rpid_priv =
{
#ifdef  CM_ABNF_DBG
    "SO _RPID_PRIV" ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 745,
    sizeof(SoRpiTokLst) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQOF ,
    (U8 *) &soMsgDef_rpid_privSeq ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpid_OptprivLstSeqOfElmnts[] =
{
    &soMsgDefMetaCommaStr ,
    &soMsgDef_rpid_priv
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDef_rpid_OptprivLstSeqOf =
{
    1 ,
    SO_MAX_RPID_PRIV_LST ,
    2 ,
    soMsgDef_rpid_OptprivLstSeqOfElmnts ,
    sizeof (SoRpiTokLst)
};

PUBLIC CmAbnfElmDef  soMsgDef_rpid_OptprivLst =
{
#ifdef  CM_ABNF_DBG
    "SO _RPID_OPTPRIV LST " ,
    "soRegExpMetaComma" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 746,
    sizeof(SoRpidPrivcy) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &soMsgDef_rpid_OptprivLstSeqOf ,
    soRegExpMetaComma
};

PUBLIC CmAbnfElmDef  *soMsgDef_rpidPrivLstSeqElmnts[] =
{
    &soMsgDef_rpid_priv ,
    &soMsgDef_rpid_OptprivLst
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_rpidPrivLstSeq =
{
    2 ,
    soMsgDef_rpidPrivLstSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_rpidPrivLst =
{
#ifdef  CM_ABNF_DBG
    "SO _RPIDPRIV LST " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 747,
    sizeof(SoRpidPrivcy) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQOF ,
    (U8 *) &soMsgDef_rpidPrivLstSeq ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_RPID_PrivacySeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr ,
    &soMsgDef_rpidPrivLst ,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_RPID_PrivacySeq =
{
    3 ,
    soMsgDef_RPID_PrivacySeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_RPID_Privacy =
{
#ifdef  CM_ABNF_DBG
    "SO _R P I D_ PRIVACY " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 748,
    sizeof(SoRpidPrivcy) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDef_RPID_PrivacySeq ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_privacy_tagipAddrEnum =
{
    (Data *)"ipaddr" ,
    SO_PRIVACY_TAG_IP_ADDR
};

PUBLIC CmAbnfElmDef  soMsgDef_privacy_tagipAddrEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _PRIVACY_TAGIPADDR ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 749,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_privacy_tagipAddrEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_privacy_tagOffEnum =
{
    (Data *)"off" ,
    SO_PRIVACY_TAG_OFF
};

PUBLIC CmAbnfElmDef  soMsgDef_privacy_tagOffEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO _PRIVACY_TAGOFF ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 750,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_privacy_tagOffEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDef_privacy_tagTokenEnum =
{
    (Data *)"" ,
    SO_PRIVACY_TAG_TOKEN
};

PUBLIC CmAbnfElmDef  soMsgDef_privacy_tagTokenEnumDef =
{
#ifdef CM_ABNF_DBG
    "SO privacy_tag TOKEN ENUM DEF " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 751,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &soMsgDef_privacy_tagTokenEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDef_privacy_tagChcEnum[] =
{
    NULLP ,
    &soMsgDef_privacy_tagipAddrEnumDef ,
    &soMsgDef_privacy_tagOffEnumDef ,
    &soMsgDef_privacy_tagTokenEnumDef ,
};

PUBLIC CmAbnfElmDef  *soMsgDef_privacy_tagChcElmnt[] =
{
    NULLP ,
    NULLP ,
    NULLP ,
    &soMsgDefToken ,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDef_privacy_tagChc =
{
    4 ,
    0 ,
    NULLP ,
    soMsgDef_privacy_tagChcElmnt ,
    soMsgDef_privacy_tagChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDef_privacy_tag =
{
#ifdef  CM_ABNF_DBG
    "SO _PRIVACY_TAG" ,
    "soRegExpprivacyTag" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 752,
    sizeof(SoStrValue) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &soMsgDef_privacy_tagChc ,
    soRegExpprivacyTag
};

PUBLIC CmAbnfElmDef  *soMsgDef_AnonymitySeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr ,
    &soMsgDef_privacy_tag ,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDef_AnonymitySeq =
{
    3 ,
    soMsgDef_AnonymitySeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDef_Anonymity =
{
#ifdef  CM_ABNF_DBG
    "SO _ANONYMITY " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 753,
    sizeof(SoStrValue) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &soMsgDef_AnonymitySeq ,
    NULLP
};



/* END: Three new headers support */


/********************************************************
Contact  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContactSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefMetaSws,
   &soMsgDefContactDesc,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefContactSeq =
{
   4,
   soMsgDefContactSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefContact =
{
#ifdef CM_ABNF_DBG
   "SO CONTACT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 754,
   sizeof(SoContact),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefContactSeq,
   NULLP
};

/********************************************************
CSeq  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefCSeqSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefCSeqVal,
   &soMsgDefMetaLws,
   &soMsgDefMethod,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefCSeqSeq =
{
   5,
   soMsgDefCSeqSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefCSeq =
{
#ifdef CM_ABNF_DBG
   "SO CSEQ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 755,
   sizeof(SoCSeq),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefCSeqSeq,
   NULLP
};

/********************************************************
EncryptionList -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefEncryptionListSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefEncryption,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefEncryptionListSeq =
{
   3,
   soMsgDefEncryptionListSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefEncryptionList =
{
#ifdef CM_ABNF_DBG
   "SO ENCRYPTIONLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 756,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefEncryptionListSeq,
   NULLP
};

/********************************************************
HeaderReplyToStr  -  Enum for "ReplyTo"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderReplyToStrEnum =
{  
   (Data *)"Reply-To",
   SO_HEADER_GEN_REPLYTO
}; 

PUBLIC CmAbnfElmDef soMsgDefHeaderReplyToStr =
{  
#ifdef CM_ABNF_DBG
   "SO HeaderReplyToStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 757,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderReplyToStrEnum,
   NULLP
}; 

/********************************************************
ReplyTo  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefReplyToSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefAddrCh,
   &soMsgDefGenericParams,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefReplyToSeq =
{
   4,
   soMsgDefReplyToSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefReplyTo =
{
#ifdef CM_ABNF_DBG
   "SO ReplyTo",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 758,
   sizeof(SoReplyTo),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefReplyToSeq,
   NULLP
};

/********************************************************
From  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefFromSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefAddrCh,
   &soMsgDefAddrParams,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefFromSeq =
{
   4,
   soMsgDefFromSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefFrom =
{
#ifdef CM_ABNF_DBG
   "SO FROM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 759,
   sizeof(SoAddress),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefFromSeq,
   NULLP
};

/********************************************************
Require  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefRequireSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefOptionTagH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRequireSeq =
{
   3,
   soMsgDefRequireSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefRequire =
{
#ifdef CM_ABNF_DBG
   "SO REQUIRE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 760,
   sizeof(SoTknStrOSXLLst),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefRequireSeq,
   NULLP
};

/********************************************************
Supported   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefSupportedSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefOptionTagH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefSupportedSeq =
{
   3,
   soMsgDefSupportedSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefSupported =
{
#ifdef CM_ABNF_DBG
   "SO SUPPORTED",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 761,
   sizeof(SoTknStrOSXLLst),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefSupportedSeq,
   NULLP
};

/********************************************************
TimestampFrac  -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefTimestampFracSeqElmnt[] =
{
   &soMsgDefMetaDotStr,
   &soMsgDefTsFrac
};

PUBLIC CmAbnfElmTypeSeq soMsgDefTimestampFracSeq =
{
   2,
   soMsgDefTimestampFracSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefTimestampFrac =
{
#ifdef CM_ABNF_DBG
   "SO TIMESTAMPFRAC",
   "SORE_DOT",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 762,
   sizeof(TknU32),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefTimestampFracSeq,
   soRegExpMetaDot
};


/********************************************************
Timestamp   -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefTimestampSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefTimestampVal,
   &soMsgDefTimestampFrac,
   &soMsgDefTimestampDelay,
   &soMsgDefMetaCRLFStr,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefTimestampSeq =
{
   5,
   soMsgDefTimestampSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefTimestamp =
{
#ifdef CM_ABNF_DBG
   "SO TIMESTAMP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 763,
   sizeof(SoTimestamp),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefTimestampSeq,
   NULLP
};

/********************************************************
To -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefToSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefAddrCh,
   &soMsgDefAddrParams,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefToSeq =
{
   4,
   soMsgDefToSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefTo =
{
#ifdef CM_ABNF_DBG
   "SO TO",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 764,
   sizeof(SoAddress),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefToSeq,
   NULLP
};

/********************************************************
Via   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefViaSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefViaH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefViaSeq =
{
   3,
   soMsgDefViaSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefVia =
{
#ifdef CM_ABNF_DBG
   "SO VIA",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 765,
   sizeof(SoVia),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefViaSeq,
   NULLP
};

/********************************************************
RequestAuthenticationInfoStr -  Enum for "Authentication-Info"
*********************************************************/
   
PUBLIC CmAbnfElmTypeEnum soMsgDefRequestAuthenticationInfoStrEnum =
{  
   (Data *)"Authentication-Info",
   SO_HEADER_REQ_AUTHENTICATIONINFO
}; 
   
PUBLIC CmAbnfElmDef soMsgDefRequestAuthenticationInfoStr =
{  
#ifdef CM_ABNF_DBG
   "SO AUTHENTICATIONINFO STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 766,
   sizeof(TknU8),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefRequestAuthenticationInfoStrEnum,
   NULLP
}; 
   
/********************************************************
AuthenticationInfo  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAuthInfoSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefGenericParam
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefAuthInfoSeqOf =
{
   1,
   SO_MAX_AUTHINFOPARAMS,
   2,
   soMsgDefAuthInfoSeqOfElmnt,
   sizeof(SoParameter)
};

PUBLIC CmAbnfElmDef soMsgDefAuthInfoList =
{
#ifdef CM_ABNF_DBG
   "SO AUTHINFO LIST",
   "SORE_COMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 767,
   sizeof(SoParameters),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefAuthInfoSeqOf,
   soRegExpMetaComma
};

PUBLIC CmAbnfElmDef *soMsgDefAuthenticationInfoHSeqElmnt[] =
{
   &soMsgDefGenericParam,
   &soMsgDefAuthInfoList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAuthenticationInfoHSeq =
{
   2,
   soMsgDefAuthenticationInfoHSeqElmnt,
};

PUBLIC CmAbnfElmDef soMsgDefAuthenticationInfoH =
{
#ifdef CM_ABNF_DBG
   "SO AUTH INFO H",
   "NULLP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 768,
   sizeof(SoParameters),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefAuthenticationInfoHSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *soMsgDefAuthenticationInfoSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefAuthenticationInfoH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAuthenticationInfoSeq =
{
   3,
   soMsgDefAuthenticationInfoSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefAuthenticationInfo =
{
#ifdef CM_ABNF_DBG
   "SO AUTHENTICATIONINFO",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 769,
   sizeof(SoParameters),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefAuthenticationInfoSeq,
   NULLP
};

/********************************************************
Authorization  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefAuthorizationSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefChallenge,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefAuthorizationSeq =
{
   3,
   soMsgDefAuthorizationSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefAuthorization =
{
#ifdef CM_ABNF_DBG
   "SO AUTHORIZATION",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 770,
   sizeof(SoAuthorization),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefAuthorizationSeq,
   NULLP
};

/********************************************************
InReplyTo   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefInReplyToSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefInReplyToH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefInReplyToSeq =
{
   3,
   soMsgDefInReplyToSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefInReplyTo =
{
#ifdef CM_ABNF_DBG
   "SO INREPLYTO",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 771,
   sizeof(SoTknStrOSXLLst),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefInReplyToSeq,
   NULLP
};

/********************************************************
Organization   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefOrganizationSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefOrganizationVal,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefOrganizationSeq =
{
   3,
   soMsgDefOrganizationSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefOrganization =
{
#ifdef CM_ABNF_DBG
   "SO ORGANIZATION",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 772,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefOrganizationSeq,
   NULLP
};

/********************************************************
Proxy-Authorization  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefProxyAuthorizationSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefChallenge,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefProxyAuthorizationSeq =
{
   3,
   soMsgDefProxyAuthorizationSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefProxyAuthorization =
{
#ifdef CM_ABNF_DBG
   "SO PROXYAUTHORIZATION",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 773,
   sizeof(SoAuthorization),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefProxyAuthorizationSeq,
   NULLP
};

/********************************************************
ProxyRequire   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefProxyRequireSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefOptionTagH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefProxyRequireSeq =
{
   3,
   soMsgDefProxyRequireSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefProxyRequire =
{
#ifdef CM_ABNF_DBG
   "SO PROXYREQUIRE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 774,
   sizeof(SoTknStrOSXLLst),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefProxyRequireSeq,
   NULLP
};

/********************************************************
Subject  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefSubjectSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefSubjectVal,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefSubjectSeq =
{
   3,
   soMsgDefSubjectSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefSubject =
{
#ifdef CM_ABNF_DBG
   "SO SUBJECT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 775,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefSubjectSeq,
   NULLP
};

/********************************************************
ContentDisposition   -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContentDispositionSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefDispositionType,
   &soMsgDefDispositionParams,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefContentDispositionSeq =
{
   4,
   soMsgDefContentDispositionSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefContentDisposition =
{
#ifdef CM_ABNF_DBG
   "SO CONTENTDISPOSITION",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 776,
   sizeof(SoContentDisposition),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefContentDispositionSeq,
   NULLP
};

/********************************************************
ContentEncoding   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContentEncodingSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefContentEncodingH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefContentEncodingSeq =
{
   3,
   soMsgDefContentEncodingSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefContentEncoding =
{
#ifdef CM_ABNF_DBG
   "SO CONTENTENCODING",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 777,
   sizeof(SoContentEncoding),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefContentEncodingSeq,
   NULLP
};

/********************************************************
ContentLanguage   -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContentLanguageSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefContentLanguageH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefContentLanguageSeq =
{
   3,
   soMsgDefContentLanguageSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefContentLanguage =
{
#ifdef CM_ABNF_DBG
   "SO CONTENTLANGUAGE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 778,
   sizeof(SoTknStrOSXLLst),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefContentLanguageSeq,
   NULLP
};

/********************************************************
ContentLength  -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContentLengthSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefLength,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefContentLengthSeq =
{
   3,
   soMsgDefContentLengthSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefContentLength =
{
#ifdef CM_ABNF_DBG
   "SO CONTENTLENGTH",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 779,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefContentLengthSeq,
   NULLP
};

/********************************************************
ContentType -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefContentTypeSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefMediaType,
   &soMsgDefMetaForwardSlashStr,
   &soMsgDefMediaSubType,
   &soMsgDefMediaParameters,
   &soMsgDefMetaCRLFStr

};

PUBLIC CmAbnfElmTypeSeq soMsgDefContentTypeSeq =
{
   6,
   soMsgDefContentTypeSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefContentType =
{
#ifdef CM_ABNF_DBG
   "SO CONTENTTYPE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 780,
   sizeof(SoContentTypeHdr),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefContentTypeSeq,
   NULLP
};

/********************************************************
RAck  -  Sequence
*********************************************************/

#ifdef SO_RFC_3262
PUBLIC CmAbnfElmDef *soMsgDefRAckSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefResponseNum,
   &soMsgDefMetaLws,
   &soMsgDefCSeqNum,
   &soMsgDefMetaLws,
   &soMsgDefMethod,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRAckSeq =
{
   7,
   soMsgDefRAckSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefRAck =
{
#ifdef CM_ABNF_DBG
   "SO RACK",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 781,
   sizeof(SoRAck),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefRAckSeq,
   NULLP
};
#endif /* SO_RFC_3262 */

/********************************************************
ProxyAuthenticate -  Optional Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefProxyAuthenticateSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefProxyAuthenticateH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefProxyAuthenticateSeq =
{
   3,
   soMsgDefProxyAuthenticateSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefProxyAuthenticate =
{
#ifdef CM_ABNF_DBG
   "SO PROXYAUTHENTICATE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 782,
   sizeof(SoAuthenticate),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefProxyAuthenticateSeq,
   NULLP
};

/********************************************************
RetryAfter  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefRetryAfterSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefDeltaSeconds,
   &soMsgDefRetryAfterComment,
   &soMsgDefRetryParams,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRetryAfterSeq =
{
   5,
   soMsgDefRetryAfterSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefRetryAfter =
{
#ifdef CM_ABNF_DBG
   "SO RETRYAFTER",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 783,
   sizeof(SoRetryAfter),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefRetryAfterSeq,
   NULLP
};

/********************************************************
RFC 3329 : Security Mechanism
*********************************************************/

PUBLIC CmAbnfElmDef  *soMsgDefMechParDgAlgSeqElmnts[] =
{
    &soMsgDefMetaSws,
    &soMsgDefMetaEqualStr,
    &soMsgDefMetaSws,
    &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefMechParDgAlgSeq =
{
    4,
    soMsgDefMechParDgAlgSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefMechParDgAlg =
{
#ifdef  CM_ABNF_DBG
    "SIP MECH PAR DG ALG ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 784,
    sizeof(SoStrValue),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefMechParDgAlgSeq,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefMechParDgQopSeqElmnts[] =
{
    &soMsgDefMetaSws,
    &soMsgDefMetaEqualStr,
    &soMsgDefMetaSws,
    &soMsgDefToken
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefMechParDgQopSeq =
{
    4,
    soMsgDefMechParDgQopSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefMechParDgQop =
{
#ifdef  CM_ABNF_DBG
    "SIP MECH PAR DG QOP ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 785,
    sizeof(SoStrValue),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefMechParDgQopSeq,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefMechParDgVerifySeqElmnts[] =
{
    &soMsgDefMetaSws,
    &soMsgDefMetaEqualStr,
    &soMsgDefMetaSws,
    &soMsgDefMetaDQuoteStr,
    &soMsgDefToken,
    &soMsgDefMetaDQuoteStr,
    &soMsgDefMetaSws
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefMechParDgVerifySeq =
{
    7,
    soMsgDefMechParDgVerifySeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefMechParDgVerify =
{
#ifdef  CM_ABNF_DBG
    "SIP MECH PAR DG VERIFY ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 786,
    sizeof(SoStrValue),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefMechParDgVerifySeq,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMechParPrefEnum =
{
    (Data *)"q",
    SO_MECH_PAR_PREF
};

PUBLIC CmAbnfElmDef  soMsgDefMechParPrefEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MECH PAR PREF ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 787,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMechParPrefEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMechParDgAlgEnum =
{
    (Data *)"d-alg",
    SO_MECH_PAR_DG_ALG
};

PUBLIC CmAbnfElmDef  soMsgDefMechParDgAlgEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MECH PAR DG ALG ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 788,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMechParDgAlgEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMechParDgQopEnum =
{
    (Data *)"d-qop",
    SO_MECH_PAR_DG_QOP
};

PUBLIC CmAbnfElmDef  soMsgDefMechParDgQopEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MECH PAR DG QOP ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 789,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMechParDgQopEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMechParDgVerifyEnum =
{
    (Data *)"d-ver",
    SO_MECH_PAR_DG_VERIFY
};

PUBLIC CmAbnfElmDef  soMsgDefMechParDgVerifyEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MECH PAR DG VERIFY ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 790,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMechParDgVerifyEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMechParExtnEnum =
{
    (Data *)"",
    SO_MECH_PAR_EXTN
};

PUBLIC CmAbnfElmDef  soMsgDefMechParExtnEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MECH PAR EXTN ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 791,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMechParExtnEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefMechParChcEnum[] =
{
NULLP,
&soMsgDefMechParPrefEnumDef,
&soMsgDefMechParDgAlgEnumDef,
&soMsgDefMechParDgQopEnumDef,
&soMsgDefMechParDgVerifyEnumDef,
&soMsgDefMechParExtnEnumDef,

};

PUBLIC CmAbnfElmDef  *soMsgDefMechParChcElmnt[] =
{
    NULLP,
    &soMsgDefQValueList,
    &soMsgDefMechParDgAlg,
    &soMsgDefMechParDgQop,
    &soMsgDefMechParDgVerify,
    &soMsgDefGenericParam,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefMechParChc =
{
    6,
    0,
    NULLP,
    soMsgDefMechParChcElmnt,
    soMsgDefMechParChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefMechPar =
{
#ifdef  CM_ABNF_DBG
    "SIP MECH PAR ",
    "soRegExpMechPar",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 792,
    sizeof(SoMechPar),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soMsgDefMechParChc,
    soRegExpMechPar
};

PUBLIC CmAbnfElmDef  *soMsgDefMechParListSeqOfElmnts[] =
{
    &soMsgDefMetaSemiColonStr,
    &soMsgDefMechPar
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefMechParListSeqOf =
{
    0,
    SO_MAX_MECHPARS,
    2,
    soMsgDefMechParListSeqOfElmnts,
    sizeof (SoMechPar)
};

PUBLIC CmAbnfElmDef  soMsgDefMechParList =
{
#ifdef  CM_ABNF_DBG
    "SIP MECH PAR LIST ",
    "soRegExpMetaSemiColon",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 793,
    sizeof(SoMechPars),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQOF,
    (U8 *) &soMsgDefMechParListSeqOf,
    soRegExpMetaSemiColon
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMechNameDigestEnum =
{
    (Data *)"digest",
    SO_MECH_NAME_DIGEST
};

PUBLIC CmAbnfElmDef  soMsgDefMechNameDigestEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MECH NAME DIGEST ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 794,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMechNameDigestEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMechNameTlsEnum =
{
    (Data *)"tls",
    SO_MECH_NAME_TLS
};

PUBLIC CmAbnfElmDef  soMsgDefMechNameTlsEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MECH NAME TLS ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 795,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMechNameTlsEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMechNameIpsecIkeEnum =
{
    (Data *)"ipsec-ike",
    SO_MECH_NAME_IPSEC_IKE
};

PUBLIC CmAbnfElmDef  soMsgDefMechNameIpsecIkeEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MECH NAME IPSEC IKE ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 796,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMechNameIpsecIkeEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMechNameIpsecManEnum =
{
    (Data *)"ipsec-man",
    SO_MECH_NAME_IPSEC_MAN
};

PUBLIC CmAbnfElmDef  soMsgDefMechNameIpsecManEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MECH NAME IPSEC MAN ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 797,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMechNameIpsecManEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefMechNameTokenEnum =
{
    (Data *)"",
    SO_MECH_NAME_TOKEN
};

PUBLIC CmAbnfElmDef  soMsgDefMechNameTokenEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP MECH NAME TOKEN ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 798,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefMechNameTokenEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefMechNameChcEnum[] =
{
NULLP,
&soMsgDefMechNameDigestEnumDef,
&soMsgDefMechNameTlsEnumDef,
&soMsgDefMechNameIpsecIkeEnumDef,
&soMsgDefMechNameIpsecManEnumDef,
&soMsgDefMechNameTokenEnumDef,

};

PUBLIC CmAbnfElmDef  *soMsgDefMechNameChcElmnt[] =
{
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    &soMsgDefToken,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefMechNameChc =
{
    6,
    0,
    NULLP,
    soMsgDefMechNameChcElmnt,
    soMsgDefMechNameChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefMechName =
{
#ifdef  CM_ABNF_DBG
    "SIP MECH NAME ",
    "soRegExpMechName",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 799,
    sizeof(SoStrValue),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soMsgDefMechNameChc,
    soRegExpMechName
};

PUBLIC CmAbnfElmDef  *soMsgDefSecMechSeqElmnts[] =
{
    &soMsgDefMechName,
    &soMsgDefMechParList
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefSecMechSeq =
{
    2,
    soMsgDefSecMechSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefSecMech =
{
#ifdef  CM_ABNF_DBG
    "SIP SEC MECH ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 800,
    sizeof(SoSecMech),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQ,
    (U8 *) &soMsgDefSecMechSeq,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefSecMechOptListSeqOfElmnts[] =
{
    &soMsgDefMetaCommaStr,
    &soMsgDefSecMech
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefSecMechOptListSeqOf =
{
    0,
    SO_MAX_SECMECH,
    2,
    soMsgDefSecMechOptListSeqOfElmnts,
    sizeof (SoSecMech)
};

PUBLIC CmAbnfElmDef  soMsgDefSecMechOptList =
{
#ifdef  CM_ABNF_DBG
    "SIP SEC MECH OPT LIST ",
    "soRegExpMetaComma",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 801,
    sizeof(SoSecClient),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQOF,
    (U8 *) &soMsgDefSecMechOptListSeqOf,
    soRegExpMetaComma
};

PUBLIC CmAbnfElmDef  *soMsgDefSecMechListSeqElmnts[] =
{
    &soMsgDefSecMech,
    &soMsgDefSecMechOptList
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefSecMechListSeq =
{
    2,
    soMsgDefSecMechListSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefSecMechList =
{
#ifdef  CM_ABNF_DBG
    "SIP SEC MECH LIST ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 802,
    sizeof(SoSecClient),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQOF,
    (U8 *) &soMsgDefSecMechListSeq,
    NULLP
};

/********************************************************
Security-Verify -  Enum for "Security-Verify" header
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSecVerifyStrEnum =
{
   (Data *)"Security-Verify",
   SO_HEADER_SEC_VERIFY
};

PUBLIC CmAbnfElmDef soMsgDefSecVerifyStr =
{
#ifdef CM_ABNF_DBG
   "SO SEC VERIFY",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 803,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSecVerifyStrEnum,
   NULLP
};

/********************************************************
Security-Server -  Enum for "Security-Server" header
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSecServerStrEnum =
{
   (Data *)"Security-Server",
   SO_HEADER_SEC_SERVER
};

PUBLIC CmAbnfElmDef soMsgDefSecServerStr =
{
#ifdef CM_ABNF_DBG
   "SO SEC SERVER",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 804,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSecServerStrEnum,
   NULLP
};

/********************************************************
Security-Client -  Enum for "Security-Client" header
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefSecClientStrEnum =
{
   (Data *)"Security-Client",
   SO_HEADER_SEC_CLIENT
};

PUBLIC CmAbnfElmDef soMsgDefSecClientStr =
{
#ifdef CM_ABNF_DBG
   "SO SEC CLIENT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 805,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefSecClientStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefSecVerifySeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr,
    &soMsgDefSecMechList,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefSecVerifySeq =
{
    3,
    soMsgDefSecVerifySeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefSecVerify =
{
#ifdef  CM_ABNF_DBG
    "SIP SEC VERIFY ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 806,
    sizeof(SoSecVerify),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefSecVerifySeq,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefSecServerSeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr,
    &soMsgDefSecMechList,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefSecServerSeq =
{
    3,
    soMsgDefSecServerSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefSecServer =
{
#ifdef  CM_ABNF_DBG
    "SIP SEC SERVER ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 807,
    sizeof(SoSecServer),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefSecServerSeq,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefSecClientSeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr,
    &soMsgDefSecMechList,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefSecClientSeq =
{
    3,
    soMsgDefSecClientSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefSecClient =
{
#ifdef  CM_ABNF_DBG
    "SIP SEC CLIENT ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 808,
    sizeof(SoSecClient),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefSecClientSeq,
    NULLP
};

/* RFC 3326 : Reason Header */

PUBLIC CmAbnfElmTypeIntRange soMsgDefReasonCauseValRange = {0, 10, 0, 0xFFFFFFFF};

PUBLIC CmAbnfElmDef soMsgDefReasonCauseVal =
{
#ifdef CM_ABNF_DBG
   "SO REASON CAUSE VAL",
   "cmAbnfRegExpDgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 809,
   sizeof(TknU32),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_UINT32,
   (U8 *)&soMsgDefReasonCauseValRange,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef  *soMsgDefReasonTextSeqElmnts[] =
{
    &soMsgDefMetaSws,
    &soMsgDefMetaEqualStr,
    &soMsgDefMetaSws,
    &soMsgDefQuotedStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefReasonTextSeq =
{
    4,
    soMsgDefReasonTextSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefReasonText =
{
#ifdef  CM_ABNF_DBG
    "SIP REASON TEXT ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 810,
    sizeof(TknStrOSXL),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefReasonTextSeq,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefReasonCauseSeqElmnts[] =
{
    &soMsgDefMetaSws,
    &soMsgDefMetaEqualStr,
    &soMsgDefMetaSws,
    &soMsgDefReasonCauseVal
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefReasonCauseSeq =
{
    4,
    soMsgDefReasonCauseSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefReasonCause =
{
#ifdef  CM_ABNF_DBG
    "SIP REASON CAUSE ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 811,
    sizeof(TknU32),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefReasonCauseSeq,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefReasonCauseEnum =
{
    (Data *)"cause",
    SO_REASON_CAUSE
};

PUBLIC CmAbnfElmDef  soMsgDefReasonCauseEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP REASON CAUSE ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 812,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefReasonCauseEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefReasonTextEnum =
{
    (Data *)"text",
    SO_REASON_TEXT
};

PUBLIC CmAbnfElmDef  soMsgDefReasonTextEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP REASON TEXT ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 813,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefReasonTextEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum soMsgDefReasonExtnEnum =
{
    (Data *)"",
    SO_REASON_EXTN
};

PUBLIC CmAbnfElmDef  soMsgDefReasonExtnEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP REASON EXTN ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 814,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefReasonExtnEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soReasonParChcEnum[] =
{
    NULLP,
    &soMsgDefReasonCauseEnumDef,
    &soMsgDefReasonTextEnumDef,
    &soMsgDefReasonExtnEnumDef,
};

PUBLIC CmAbnfElmDef  *soReasonParChcElmnt[] =
{
    NULLP,
    &soMsgDefReasonCause,
    &soMsgDefReasonText,
    &soMsgDefGenericParam,
};

PUBLIC CmAbnfElmTypeChoice  soReasonParChc =
{
    4,
    0,
    NULLP,
    soReasonParChcElmnt,
    soReasonParChcEnum
};

PUBLIC CmAbnfElmDef  soReasonPar =
{
#ifdef  CM_ABNF_DBG
    "SIP PAR ",
    "soRegExpReasonPar",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 815,
    sizeof(SoReasonPar),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soReasonParChc,
    soRegExpReasonPar
};

PUBLIC CmAbnfElmDef  *soReasonParListSeqOfElmnts[] =
{
    &soMsgDefMetaSemiColonStr,
    &soReasonPar
};

PUBLIC CmAbnfElmTypeSeqOf  soReasonParListSeqOf =
{
    0,
    SO_MAX_REASONPARS,
    2,
    soReasonParListSeqOfElmnts,
    sizeof (SoReasonPar)
};

PUBLIC CmAbnfElmDef  soReasonParList =
{
#ifdef  CM_ABNF_DBG
    "SIP PAR LIST ",
    "soRegExpMetaSemiColon",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 816,
    sizeof(SoReasonPars),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQOF,
    (U8 *) &soReasonParListSeqOf,
    soRegExpMetaSemiColon
};

PUBLIC CmAbnfElmDef  *soMsgDefReasonValSeqElmnts[] =
{
    &soMsgDefProtocolName,
    &soReasonParList
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefReasonValSeq =
{
    2,
    soMsgDefReasonValSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefReasonVal =
{
#ifdef  CM_ABNF_DBG
    "SIP REASON VAL ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 817,
    sizeof(SoReasonVal),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQ,
    (U8 *) &soMsgDefReasonValSeq,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefReasonValOptListSeqOfElmnts[] =
{
    &soMsgDefMetaCommaStr,
    &soMsgDefReasonVal
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefReasonValOptListSeqOf =
{
    1,
    SO_MAX_REASONVAL,
    2,
    soMsgDefReasonValOptListSeqOfElmnts,
    sizeof (SoReasonVal)
};

PUBLIC CmAbnfElmDef  soMsgDefReasonValOptList =
{
#ifdef  CM_ABNF_DBG
    "SIP REASON VAL OPT LIST ",
    "soRegExpMetaComma",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 818,
    sizeof(SoReason),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQOF,
    (U8 *) &soMsgDefReasonValOptListSeqOf,
    soRegExpMetaComma
};

PUBLIC CmAbnfElmDef  *soMsgDefReasonValListSeqElmnts[] =
{
    &soMsgDefReasonVal,
    &soMsgDefReasonValOptList
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefReasonValListSeq =
{
    2,
    soMsgDefReasonValListSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefReasonValList =
{
#ifdef  CM_ABNF_DBG
    "SIP REASON VAL LIST ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 819,
    sizeof(SoReason),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQOF,
    (U8 *) &soMsgDefReasonValListSeq,
    NULLP
};

/********************************************************
ReasonStr   -  Enum for "Reason"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefHeaderReasonStrEnum =
{
   (Data *)"Reason",
   SO_HEADER_GEN_REASON
};

PUBLIC CmAbnfElmDef soMsgDefHeaderReasonStr =
{
#ifdef CM_ABNF_DBG
   "SO REASON STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 820,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefHeaderReasonStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefHeaderReasonSeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr,
    &soMsgDefReasonValList,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefHeaderReasonSeq =
{
    3,
    soMsgDefHeaderReasonSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefHeaderReason =
{
#ifdef  CM_ABNF_DBG
    "SIP HEADER REASON ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 821,
    sizeof(SoReason),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefHeaderReasonSeq,
    NULLP
};

/* RFC 3313 : P-Media-Authorization Header */
/********************************************************
PMediaAuthorization   -  Enum for "PMediaAuthorization"
*********************************************************/
   
PUBLIC CmAbnfElmTypeEnum soMsgDefPMediaAuthorizationStrEnum =
{  
   (Data *)"P-Media-Authorization",
   SO_HEADER_GEN_PMEDIAAUTHORIZATION
}; 
   
PUBLIC CmAbnfElmDef soMsgDefPMediaAuthorizationStr =
{  
#ifdef CM_ABNF_DBG
   "SO PMEDIAAutHORIZATION STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 822,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefPMediaAuthorizationStrEnum,
   NULLP
};

/********************************************************
P Media Authorization Token
*********************************************************/

PUBLIC CmAbnfElmTypeRange soMsgDefPMedaiAuthTknRange = {0, 0xFFFF};

PUBLIC CmAbnfElmDef soMsgDefPMediaAuthTkn =
{
#ifdef CM_ABNF_DBG
   "SO P MEDIA AUTH TKN",
   "SORE_PMEDIAAUTHTKN",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 823,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&soMsgDefPMedaiAuthTknRange,
   soRegExpPMediaAuthTkn
};

PUBLIC CmAbnfElmDef  *soMsgDefPMediaAuthTknOptListSeqOfElmnts[] =
{
    &soMsgDefMetaCommaStr ,
    &soMsgDefPMediaAuthTkn
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefPMediaAuthTknOptListSeqOf =
{
    0 ,
    SO_MAX_PMEDIAAUTHVAL ,
    2 ,
    soMsgDefPMediaAuthTknOptListSeqOfElmnts ,
    sizeof (TknStrOSXL)
};

PUBLIC CmAbnfElmDef  soMsgDefPMediaAuthTknOptList =
{
#ifdef  CM_ABNF_DBG
    "SIP P MEDIA AUTH TKN OPT LIST " ,
    "soRegExpMetaComma" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 824,
    sizeof(SoTknStrOSXLLst) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQOF ,
    (U8 *) &soMsgDefPMediaAuthTknOptListSeqOf ,
    soRegExpMetaComma
};

PUBLIC CmAbnfElmDef  *soMsgDefPMediaAuthTknListSeqElmnts[] =
{
    &soMsgDefPMediaAuthTkn ,
    &soMsgDefPMediaAuthTknOptList
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefPMediaAuthTknListSeq =
{
    2 ,
    soMsgDefPMediaAuthTknListSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefPMediaAuthTknList =
{
#ifdef  CM_ABNF_DBG
    "SIP P MEDIA AUTH TKN LIST " ,
    "EMPTY" ,
#endif
   CM_ABNF_ELMNID_SIP_BASE + 825,
    sizeof(SoTknStrOSXLLst) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQOF ,
    (U8 *) &soMsgDefPMediaAuthTknListSeq ,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefPMediaAuthorizationSeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr,
    &soMsgDefPMediaAuthTknList ,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefPMediaAuthorizationSeq =
{
    3,
    soMsgDefPMediaAuthorizationSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefPMediaAuthorization =
{
#ifdef  CM_ABNF_DBG
    "SIP P MEDIA AUTHORIZATION ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 826,
    sizeof(SoTknStrOSXLLst),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefPMediaAuthorizationSeq,
    NULLP
};

/* RFC 3323 : Privacy Header */

PUBLIC CmAbnfElmTypeEnum  soMsgDefPrivValHeaderEnum =
{
    (Data *)"header",
    SO_PRIV_VAL_HEADER
};

PUBLIC CmAbnfElmDef  soMsgDefPrivValHeaderEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP PRIV VAL HEADER ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 827,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefPrivValHeaderEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefPrivValSessonEnum =
{
    (Data *)"session",
    SO_PRIV_VAL_SESSON
};

PUBLIC CmAbnfElmDef  soMsgDefPrivValSessonEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP PRIV VAL SESSON ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 828,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefPrivValSessonEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefPrivValUserEnum =
{
    (Data *)"user",
    SO_PRIV_VAL_USER
};

PUBLIC CmAbnfElmDef  soMsgDefPrivValUserEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP PRIV VAL USER ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 829,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefPrivValUserEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefPrivValNoneEnum =
{
    (Data *)"none",
    SO_PRIV_VAL_NONE
};

PUBLIC CmAbnfElmDef  soMsgDefPrivValNoneEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP PRIV VAL NONE ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 830,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefPrivValNoneEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefPrivValCriticalEnum =
{
    (Data *)"critical",
    SO_PRIV_VAL_CRITICAL
};

PUBLIC CmAbnfElmDef  soMsgDefPrivValCriticalEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP PRIV VAL CRITICAL ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 831,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefPrivValCriticalEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefPrivValIdEnum =
{
    (Data *)"id",
    SO_PRIV_VAL_ID
};

PUBLIC CmAbnfElmDef  soMsgDefPrivValIdEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP PRIV VAL ID ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 832,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefPrivValIdEnum,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  soMsgDefPrivValTokenEnum =
{
    (Data *)"",
    SO_PRIV_VAL_TOKEN
};

PUBLIC CmAbnfElmDef  soMsgDefPrivValTokenEnumDef =
{
#ifdef CM_ABNF_DBG
    "SIP TOKEN ENUM DEF ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 833,
    sizeof (TknU8),
    0,
    CM_ABNF_TYPE_ENUM,
    (U8 *) &soMsgDefPrivValTokenEnum,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefPrivValChcEnum[] =
{
   NULLP,
   &soMsgDefPrivValHeaderEnumDef,
   &soMsgDefPrivValSessonEnumDef,
   &soMsgDefPrivValUserEnumDef,
   &soMsgDefPrivValNoneEnumDef,
   &soMsgDefPrivValCriticalEnumDef,
   &soMsgDefPrivValIdEnumDef,
   &soMsgDefPrivValTokenEnumDef,
};

PUBLIC CmAbnfElmDef  *soMsgDefPrivValChcElmnt[] =
{
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    NULLP,
    &soMsgDefToken,
};

PUBLIC CmAbnfElmTypeChoice  soMsgDefPrivValChc =
{
    8,
    0,
    NULLP,
    soMsgDefPrivValChcElmnt,
    soMsgDefPrivValChcEnum
};

PUBLIC CmAbnfElmDef  soMsgDefPrivVal =
{
#ifdef  CM_ABNF_DBG
    "SIP PRIV VAL ",
    "soRegExpPrivVal",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 834,
    sizeof(SoStrValue),
    ( CM_ABNF_MANDATORY ),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &soMsgDefPrivValChc,
    soRegExpPrivVal
};

PUBLIC CmAbnfElmDef  *soMsgDefPrivValOptListSeqOfElmnts[] =
{
    &soMsgDefMetaSemiColonStr,
    &soMsgDefPrivVal
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefPrivValOptListSeqOf =
{
    0,
    SO_MAX_PRIVVAL,
    2,
    soMsgDefPrivValOptListSeqOfElmnts,
    sizeof (SoStrValue)
};

PUBLIC CmAbnfElmDef  soMsgDefPrivValOptList =
{
#ifdef  CM_ABNF_DBG
    "SIP PRIV VAL OPT LIST ",
    "soRegExpMetaSemiColon",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 835,
    sizeof(SoPrivacy),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQOF,
    (U8 *) &soMsgDefPrivValOptListSeqOf,
    soRegExpMetaSemiColon
};

PUBLIC CmAbnfElmDef  *soMsgDefPrivValListSeqElmnts[] =
{
    &soMsgDefPrivVal,
    &soMsgDefPrivValOptList
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefPrivValListSeq =
{
    2,
    soMsgDefPrivValListSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefPrivValList =
{
#ifdef  CM_ABNF_DBG
    "SIP PRIV VAL LIST ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 836,
    sizeof(SoPrivacy),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQOF,
    (U8 *) &soMsgDefPrivValListSeq,
    NULLP
};

/********************************************************
Privacy -  Enum for "Privacy" header
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefPrivacyStrEnum =
{
   (Data *)"Privacy",
   SO_HEADER_GEN_PRIVACY
};

PUBLIC CmAbnfElmDef soMsgDefPrivacyStr =
{
#ifdef CM_ABNF_DBG
   "SO PRIVACY STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 837,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefPrivacyStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefPrivacySeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr,
    &soMsgDefPrivValList,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefPrivacySeq =
{
    3,
    soMsgDefPrivacySeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefPrivacy =
{
#ifdef  CM_ABNF_DBG
    "SIP PRIVACY ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 838,
    sizeof(SoPrivacy),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefPrivacySeq,
    NULLP
};

/* RFC 3325 : P-Asserted-Identity & P-Preferred-Identity Header */

PUBLIC CmAbnfElmDef  *soMsgDefPAssertedIdValOptListSeqOfElmnts[] =
{
    &soMsgDefMetaCommaStr,
    &soMsgDefAddrCh
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefPAssertedIdValOptListSeqOf =
{
    1,
    SO_MAX_PASSERTEDIDVAL,
    2,
    soMsgDefPAssertedIdValOptListSeqOfElmnts,
    sizeof (SoAddrCh)
};

PUBLIC CmAbnfElmDef  soMsgDefPAssertedIdValOptList =
{
#ifdef  CM_ABNF_DBG
    "SIP P ASSERTED ID VAL OPT LIST ",
    "soRegExpMetaComma",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 839,
    sizeof(SoPAssertedId),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQOF,
    (U8 *) &soMsgDefPAssertedIdValOptListSeqOf,
    soRegExpMetaComma
};

PUBLIC CmAbnfElmDef  *soMsgDefPAssertedIdValListSeqElmnts[] =
{
    &soMsgDefAddrCh,
    &soMsgDefPAssertedIdValOptList
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefPAssertedIdValListSeq =
{
    2,
    soMsgDefPAssertedIdValListSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefPAssertedIdValList =
{
#ifdef  CM_ABNF_DBG
    "SIP P ASSERTED ID VAL LIST ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 840,
    sizeof(SoPAssertedId),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQOF,
    (U8 *) &soMsgDefPAssertedIdValListSeq,
    NULLP
};

/********************************************************
PAssertedId -  Enum for "PAssertedId" header
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefPAssertedIdStrEnum =
{
   (Data *)"P-Asserted-Identity",
   SO_HEADER_GEN_PASSERTEDID
};

PUBLIC CmAbnfElmDef soMsgDefPAssertedIdStr =
{
#ifdef CM_ABNF_DBG
   "SO PASSERTEDID STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 841,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefPAssertedIdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefPAssertedIdSeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr,
    &soMsgDefPAssertedIdValList,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefPAssertedIdSeq =
{
    3,
    soMsgDefPAssertedIdSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefPAssertedId =
{
#ifdef  CM_ABNF_DBG
    "SIP P ASSERTED ID ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 842,
    sizeof(SoPAssertedId),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefPAssertedIdSeq,
    NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefPPreferredIdValOptListSeqOfElmnts[] =
{
    &soMsgDefMetaCommaStr,
    &soMsgDefAddrCh
};

PUBLIC CmAbnfElmTypeSeqOf  soMsgDefPPreferredIdValOptListSeqOf =
{
    1,
    SO_MAX_PPREFFEREDIDVAL,
    2,
    soMsgDefPPreferredIdValOptListSeqOfElmnts,
    sizeof (SoAddrCh)
};

PUBLIC CmAbnfElmDef  soMsgDefPPreferredIdValOptList =
{
#ifdef  CM_ABNF_DBG
    "SIP P PREFERRED ID VAL OPT LIST ",
    "soRegExpMetaComma",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 843,
    sizeof(SoPPreferredId),
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_SEQOF,
    (U8 *) &soMsgDefPPreferredIdValOptListSeqOf,
    soRegExpMetaComma
};

PUBLIC CmAbnfElmDef  *soMsgDefPPreferredIdValListSeqElmnts[] =
{
    &soMsgDefAddrCh,
    &soMsgDefPPreferredIdValOptList
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefPPreferredIdValListSeq =
{
    2,
    soMsgDefPPreferredIdValListSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefPPreferredIdValList =
{
#ifdef  CM_ABNF_DBG
    "SIP P PREFERRED ID VAL LIST ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 844,
    sizeof(SoPPreferredId),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQOF,
    (U8 *) &soMsgDefPPreferredIdValListSeq,
    NULLP
};

/********************************************************
PPreferredId -  Enum for "PPreferredId" header
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefPPreferredIdStrEnum =
{
   (Data *)"P-Preferred-Identity",
   SO_HEADER_GEN_PPREFERREDID
}; 

PUBLIC CmAbnfElmDef soMsgDefPPreferredIdStr =
{
#ifdef CM_ABNF_DBG
   "SO P PREFERRED ID STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 845,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefPPreferredIdStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef  *soMsgDefPPreferredIdSeqElmnts[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
    &soMsgDefMetaSwsColonStr,
    &soMsgDefPPreferredIdValList,
    &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq  soMsgDefPPreferredIdSeq =
{
    3,
    soMsgDefPPreferredIdSeqElmnts
};

PUBLIC CmAbnfElmDef  soMsgDefPPreferredId =
{
#ifdef  CM_ABNF_DBG
    "SIP P PREFERRED ID ",
    "EMPTY",
#endif
   CM_ABNF_ELMNID_SIP_BASE + 846,
    sizeof(SoPPreferredId),
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ),
    CM_ABNF_TYPE_OPTSEQ,
    (U8 *) &soMsgDefPPreferredIdSeq,
    NULLP
};

/* RFC 3608: Service Route Header */
/********************************************************
ServiceRouteRep -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefServiceRouteRepSeqElmnt[] =
{
   &soMsgDefNameAddr,
   &soMsgDefGenericParams,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefServiceRouteRepSeq =
{
   2,
   soMsgDefServiceRouteRepSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefServiceRouteRep =
{
#ifdef CM_ABNF_DBG
   "SO SERVICE ROUTEREP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 847,
   sizeof(SoRouteSeq),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefServiceRouteRepSeq,
   NULLP
};

/********************************************************
ServiceRouteRepList   -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefServiceRouteRepListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefServiceRouteRep
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefServiceRouteRepListSeqOf =
{
   1,
   SO_MAX_RECORDROUTELIST,
   2,
   soMsgDefServiceRouteRepListSeqOfElmnt,
   sizeof(SoRouteSeq)
};

PUBLIC CmAbnfElmDef soMsgDefServiceRouteRepList =
{
#ifdef CM_ABNF_DBG
   "SO SERVICE ROUTELIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 848,
   sizeof(SoRoute),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefServiceRouteRepListSeqOf,
   soRegExpMetaComma
};

/********************************************************
ServiceRouteH   -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefServiceRouteHSeqElmnt[] =
{
   &soMsgDefServiceRouteRep,
   &soMsgDefServiceRouteRepList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefServiceRouteHSeq =
{
   2,
   soMsgDefServiceRouteHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefServiceRouteH =
{
#ifdef CM_ABNF_DBG
   "SO SERVICE ROUTEH",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 849,
   sizeof(SoRoute),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefServiceRouteHSeq,
   NULLP
};

/********************************************************
Service-RouteStr -  Enum for "Service-Route"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefServiceRouteStrEnum =
{
   (Data *)"Service-Route",
   SO_HEADER_GEN_SERVICEROUTE
};

PUBLIC CmAbnfElmDef soMsgDefServiceRouteStr =
{
#ifdef CM_ABNF_DBG
   "SO SERVICE ROUTESTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 850,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefServiceRouteStrEnum,
   NULLP   
};

/********************************************************
ServiceRoute -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefServiceRouteSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefServiceRouteH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefServiceRouteSeq =
{
   3,
   soMsgDefServiceRouteSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefServiceRoute =
{
#ifdef   CM_ABNF_DBG
   "SO SERVICE ROUTE",
   "NULLP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 851,
   sizeof(SoRoute),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefServiceRouteSeq,
   NULLP
};

/* RFC 3327 : Path Header */
/********************************************************
PathRep -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefPathRepSeqElmnt[] =
{
   &soMsgDefNameAddr,
   &soMsgDefGenericParams,
};

PUBLIC CmAbnfElmTypeSeq soMsgDefPathRepSeq =
{
   2,
   soMsgDefPathRepSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefPathRep =
{
#ifdef CM_ABNF_DBG
   "SO PATH REP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 852,
   sizeof(SoRouteSeq),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefPathRepSeq,
   NULLP
};

/********************************************************
PathRepList   -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefPathRepListSeqOfElmnt[] =
{
   &soMsgDefMetaCommaStr,
   &soMsgDefPathRep
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefPathRepListSeqOf =
{
   1,
   SO_MAX_RECORDROUTELIST,
   2,
   soMsgDefPathRepListSeqOfElmnt,
   sizeof(SoRouteSeq)
};

PUBLIC CmAbnfElmDef soMsgDefPathRepList =
{
#ifdef CM_ABNF_DBG
   "SO PATH REPLIST",
   "EMPTY",
#endif   /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 853,
   sizeof(SoRoute),
   (CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefPathRepListSeqOf,
   soRegExpMetaComma
};

/********************************************************
PathH   -  Optional Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefPathHSeqElmnt[] =
{
   &soMsgDefPathRep,
   &soMsgDefPathRepList
};

PUBLIC CmAbnfElmTypeSeq soMsgDefPathHSeq =
{
   2,
   soMsgDefPathHSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefPathH =
{
#ifdef CM_ABNF_DBG
   "SO PATHH",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 854,
   sizeof(SoRoute),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&soMsgDefPathHSeq,
   NULLP
};

/********************************************************
PathStr -  Enum for "Path"
*********************************************************/

PUBLIC CmAbnfElmTypeEnum soMsgDefPathStrEnum =
{
   (Data *)"Path",
   SO_HEADER_GEN_PATH
};

PUBLIC CmAbnfElmDef soMsgDefPathStr =
{
#ifdef CM_ABNF_DBG
   "SO PATH STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 855,
   sizeof(TknU8),
   (0),
   CM_ABNF_TYPE_ENUM,
   (U8 *)&soMsgDefPathStrEnum,
   NULLP   
};

/********************************************************
Path -  Optional Sequence
*********************************************************/
PUBLIC CmAbnfElmDef *soMsgDefPathSeqElmnt[] =
{
/* so023.201 Changes for allowing a space between colon and header value */
   &soMsgDefMetaSwsColonStr,
   &soMsgDefPathH,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefPathSeq =
{
   3,
   soMsgDefPathSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefPath =
{
#ifdef   CM_ABNF_DBG
   "SO PATH",
   "NULLP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 856,
   sizeof(SoRoute),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefPathSeq,
   NULLP
};

/********************************************************
SipVersion
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefSipVersionSeqElmnt[] =
{
   &soMsgDefSIPVersionStr,
   &soMsgDefVersionVal
};

PUBLIC CmAbnfElmTypeSeq soMsgDefSipVersionSeq =
{
   2,
   soMsgDefSipVersionSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefSipVersion =
{
#ifdef CM_ABNF_DBG
   "SO SIPVERSION",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 857,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&soMsgDefSipVersionSeq,
   NULLP
};

/********************************************************
Header   -  Type of Header -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefHeaderChoiceEnum[] =
{
   NULLP,
   &soMsgDefAcceptStr,
   &soMsgDefHeaderAcceptEncodingStr,
   &soMsgDefHeaderAcceptLanguageStr,
   &soMsgDefRequestAlertInfoStr,
   &soMsgDefRequestAllowStr,
   &soMsgDefAlsoStr,
   &soMsgDefRequestAuthorizationStr,
   &soMsgDefRequestAuthenticationInfoStr,
   &soMsgDefCallIdStr,
   &soMsgDefCallIdIStr,
   &soMsgDefCallInfoStr,
   &soMsgDefHeaderContactStr,
   &soMsgDefHeaderContactmStr,
   &soMsgDefRequestContentDispositionStr,
   &soMsgDefRequestContentEncodingStr,
   &soMsgDefRequestContentEncodingEStr,
   &soMsgDefRequestContentLanguageStr,
   &soMsgDefRequestContentLengthStr,
   &soMsgDefRequestContentLengthLStr,
   &soMsgDefRequestContentTypeStr,
   &soMsgDefRequestContentTypeCStr,
   &soMsgDefHeaderCSeqStr,
   &soMsgDefDateStr,
   &soMsgDefEncryptionStr,
   &soMsgDefErrorInfoStr,
   &soMsgDefRequestExpiresStr,
   &soMsgDefHeaderFromStr,
   &soMsgDefHeaderFromFStr,
   &soMsgDefRequestInReplyToStr,
   &soMsgDefMaxForwardsStr,
   &soMsgDefMIMEversionStr,
   &soMsgDefRequestMinExpiresStr,
   &soMsgDefRequestOrganizationStr,
   &soMsgDefPriorityStr,
   &soMsgDefResponseProxyAuthenticateStr,
   &soMsgDefRequestProxyAuthorizationStr,
   &soMsgDefRequestProxyRequireStr,
   &soMsgDefRecordRouteStr,
   &soMsgDefHeaderReplyToStr,
   &soMsgDefHeaderRequireStr,
   &soMsgDefResponseKeyStr,
   &soMsgDefResponseRetryAfterStr,
   &soMsgDefRouteStr,
   &soMsgDefServerStr,
   &soMsgDefRequestSubjectStr,
   &soMsgDefRequestSubjectSStr,
   &soMsgDefHeaderSupportedStr,
   &soMsgDefHeaderSupportedKStr,
   &soMsgDefHeaderTimestampStr,
   &soMsgDefHeaderToStr,
   &soMsgDefHeaderToTStr,
   &soMsgDefUnsupportedStr,
   &soMsgDefUserAgentStr,
   &soMsgDefHeaderViaStr,
   &soMsgDefHeaderViaVStr,
#ifdef SO_RFC_3262
   &soMsgDefRequestRAckStr,
   &soMsgDefRSeqStr,
#else
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
#endif /* SO_RFC_3262 */
   &soMsgDefWarningStr,
   &soMsgDefWWWAuthenticateStr,

#ifdef SO_EVENT
   &soMsgDefEventStr,
   &soMsgDefEventOStr,
   &soMsgDefAllowEventsStr,
   &soMsgDefAllowEventsUStr,
#ifdef SO_REFER
   &soMsgDefReferToStr,
   &soMsgDefReferredByStr,
   &soMsgDefReferToRStr,
   &soMsgDefReferredByBStr,
   &soMsgDefReplacesStr,    
#else
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
#endif /* SO_REFER */
#else
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
#endif /* SO_EVENT */

#ifdef SO_SESSTIMER
   &soMsgDefSessionExpiresStr,
   &soMsgDefSessionExpiresXStr,
   &soMsgDefMinSEStr,
#else
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
#endif /* SO_SESSTIMER */

#ifdef SO_CALLERPREF
   &soMsgDefRequestDispositionStr,
   &soMsgDefRequestDispositionDStr,
   &soMsgDefAcceptContactStr,
   &soMsgDefAcceptContactAStr,
   &soMsgDefRejectContactStr,
   &soMsgDefRejectContactJStr,
#else
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
   &soMsgDefRequestExtensionStr,
#endif /* SO_CALLERPREF */

   &soMsgDef_AnonymityStr,
   &soMsgDef_RPID_PrivacyStr,
   &soMsgDef_Remote_Party_IDStr,

#ifdef SO_EVENT
   &soMsgDefSubscStateStr,
#else
   &soMsgDefRequestExtensionStr,
#endif /* SO_EVENT */

   /* RFC 3329 : Security Mechanism */
   &soMsgDefSecClientStr,
   &soMsgDefSecServerStr,
   &soMsgDefSecVerifyStr,

   /* RFC 3326 : Reason Header */
   &soMsgDefHeaderReasonStr,

   /* RFC 3313 : P-Media-Authorization Header */
   &soMsgDefPMediaAuthorizationStr,

   /* RFC 3323 : Privacy Header */
   &soMsgDefPrivacyStr,

   /* RFC 3325 : P-Asserted-Identity & P-Preferred-Identity Header */
   &soMsgDefPAssertedIdStr,
   &soMsgDefPPreferredIdStr,

   /* RFC 3608 : Service-Route Header */
   &soMsgDefServiceRouteStr,

   /* RFC 3327 : Path Header */
   &soMsgDefPathStr,

   &soMsgDefRequestExtensionStr
};

PUBLIC CmAbnfElmDef *soMsgDefHeaderChoiceElmnt[] =
{
   NULLP,
   &soMsgDefAccept,
   &soMsgDefAcceptEncoding,
   &soMsgDefAcceptLanguage,
   &soMsgDefAlertInfo,
   &soMsgDefAllowList,
   &soMsgDefAlso,
   &soMsgDefAuthorization,
   &soMsgDefAuthenticationInfo,
   &soMsgDefCallId,
   &soMsgDefCallId,
   &soMsgDefCallInfo,
   &soMsgDefContact,
   &soMsgDefContact,
   &soMsgDefContentDisposition,
   &soMsgDefContentEncoding,
   &soMsgDefContentEncoding,
   &soMsgDefContentLanguage,
   &soMsgDefContentLength,
   &soMsgDefContentLength,
   &soMsgDefContentType,
   &soMsgDefContentType,
   &soMsgDefCSeq,
   &soMsgDefSipDateHdr,
   &soMsgDefEncryptionList,
   &soMsgDefErrorInfo,
   &soMsgDefExpires,
   &soMsgDefFrom,
   &soMsgDefFrom,
   &soMsgDefInReplyTo,
   &soMsgDefMaxForwardsList,
   &soMsgDefMimeVersionList,
   &soMsgDefMinExpires,
   &soMsgDefOrganization,
   &soMsgDefPriorityHdr,
   &soMsgDefProxyAuthenticate,
   &soMsgDefProxyAuthorization,
   &soMsgDefProxyRequire,
   &soMsgDefRecordRoute,
   &soMsgDefReplyTo,
   &soMsgDefRequire,
   &soMsgDefResponseKeyList,
   &soMsgDefRetryAfter,
   &soMsgDefRoute,
   &soMsgDefServerList,
   &soMsgDefSubject,
   &soMsgDefSubject,
   &soMsgDefSupported,
   &soMsgDefSupported,
   &soMsgDefTimestamp,
   &soMsgDefTo,
   &soMsgDefTo,
   &soMsgDefUnsupportedList,
   &soMsgDefUserAgentList,
   &soMsgDefVia,
   &soMsgDefVia,
#ifdef SO_RFC_3262
   &soMsgDefRAck,
   &soMsgDefRSeq,
#else
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
#endif /* SO_RFC_3262 */
   &soMsgDefWarningList,
   &soMsgDefWwwAuthenticateList,

#ifdef SO_EVENT
   &soMsgDefEventList,  
   &soMsgDefEventList,  
   &soMsgDefAllowEventsList, 
   &soMsgDefAllowEventsList, 
#ifdef SO_REFER
   &soMsgDefReferTo,
   &soMsgDefReferredBy,
   &soMsgDefReferTo,
   &soMsgDefReferredBy,
   &soMsgDefReplaces,       
#else
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
#endif /* SO_REFER */

#else
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
#endif /* SO_EVENT */

#ifdef SO_SESSTIMER
   &soMsgDefSessionExpires,
   &soMsgDefSessionExpires,
   &soMsgDefMinSE,
#else
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
#endif /* SO_SESSTIMER */
#ifdef SO_CALLERPREF
   &soMsgDefRequestDisposition,      
   &soMsgDefRequestDisposition,      
   &soMsgDefAcceptContact,       
   &soMsgDefAcceptContact,       
   &soMsgDefRejectContact,       
   &soMsgDefRejectContact,       
#else
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
   &soMsgDefExtensionList,
#endif /* SO_CALLERPREF */

   &soMsgDef_Anonymity,
   &soMsgDef_RPID_Privacy,
   &soMsgDef_Remote_Party_ID,

#ifdef SO_EVENT
   &soMsgDefSubscState,
#else
   &soMsgDefExtensionList,
#endif

   /* RFC 3329 : Security Mechanism */
   &soMsgDefSecClient,
   &soMsgDefSecServer,
   &soMsgDefSecVerify,

   /* RFC 3326 : Reason Header */
   &soMsgDefHeaderReason,

   /* RFC 3313 : P-Media-Authorization Header */
   &soMsgDefPMediaAuthorization,

   /* RFC 3323 : Privacy Header */
   &soMsgDefPrivacy,

   /* RFC 3325 : P-Asserted-Identity & P-Preferred-Identity Header */
   &soMsgDefPAssertedId,
   &soMsgDefPPreferredId,

   /* RFC 3608 : Service-Route Header */
   &soMsgDefServiceRoute,

   /* RFC 3327 : Path Header */
   &soMsgDefPath,

   &soMsgDefExtensionList
};

PUBLIC CmAbnfElmTypeChoice soMsgDefHeaderChoice =
{
   SO_HEADER_MAXIMUM,
   0,
   NULLP,
   soMsgDefHeaderChoiceElmnt,
   soMsgDefHeaderChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefHeader =
{
#ifdef CM_ABNF_DBG
   "SO_HEADER",
   "SORE_HEADERCHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 858,
   sizeof(SoHeader),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefHeaderChoice,
   soRegExpHeaderChoice
};

/********************************************************
RequestLine -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefRequestLineSeqElmnt[] =
{
   &soMsgDefMethod,
   &soMsgDefMetaSpaceStr,
   &soMsgDefAddrSpec,
   &soMsgDefMetaSpaceStr,
   &soMsgDefSipVersion,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRequestLineSeq =
{
   6,
   soMsgDefRequestLineSeqElmnt
};

PUBLIC CmAbnfElmDef soMsgDefRequestLine =
{
#ifdef CM_ABNF_DBG
   "SO REQUESTLINE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 859,
   sizeof(SoRequestLine),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefRequestLineSeq,
   NULLP
};


/********************************************************
HeaderList  -  Sequence Of
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefHeaderListSeqOfElmnt[] =
{
   &soMsgDefHeader
};

PUBLIC CmAbnfElmTypeSeqOf soMsgDefHeaderListSeqOf =
{
   0,
   SO_MAX_HEADER,
   1,
   soMsgDefHeaderListSeqOfElmnt,
   sizeof(SoHeader)
};


PUBLIC CmAbnfElmDef soMsgDefHeaderList =
{
#ifdef CM_ABNF_DBG
   "SO_HEADER_LIST",
   "soRegExpNotMetaCRLF",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 860,
   sizeof(SoHeaderSeq),
   (CM_ABNF_OPTIONAL|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&soMsgDefHeaderListSeqOf,
   soRegExpNotMetaCRLF  /* so006.102: New Function to verify that end of 
                                      headers has reached. */
};

/********************************************************
StatusLine  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefStatusLineSeqElmnt[] =
{
   &soMsgDefSipVersion,
   &soMsgDefMetaSpaceStr,
   &soMsgDefStatusCode,
   &soMsgDefMetaSpaceStr,
   &soMsgDefReasonPhrase,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefStatusLineSeq =
{
   6,
   soMsgDefStatusLineSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefStatusLine =
{
#ifdef CM_ABNF_DBG
   "SO STATUSLINE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 861,
   sizeof(SoStatusLine),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefStatusLineSeq,
   NULLP
};

/********************************************************
Request  -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefRequestSeqElmnt[] =
{
   &soMsgDefRequestLine,
   &soMsgDefHeaderList,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefRequestSeq =
{
   3,
   soMsgDefRequestSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefRequest =
{
#ifdef CM_ABNF_DBG
   "SO REQUEST",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 862,
   sizeof(SoRequest),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefRequestSeq,
   NULLP
};

/********************************************************
Response -  Sequence
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefResponseSeqElmnt[] =
{
   &soMsgDefStatusLine,
   &soMsgDefHeaderList,
   &soMsgDefMetaCRLFStr
};

PUBLIC CmAbnfElmTypeSeq soMsgDefResponseSeq =
{
   3,
   soMsgDefResponseSeqElmnt
};


PUBLIC CmAbnfElmDef soMsgDefResponse =
{
#ifdef CM_ABNF_DBG
   "SO RESPONSE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 863,
   sizeof(SoResponse),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&soMsgDefResponseSeq,
   NULLP
};

/********************************************************
SipMessage  -  Type of SIP message  -  Choice
*********************************************************/

PUBLIC CmAbnfElmDef *soMsgDefSipMessageChoiceEnum[] =
{
   NULLP,
   &soMsgDefRequestStr,
   &soMsgDefResponseStr
};

PUBLIC CmAbnfElmDef *soMsgDefSipMessageChoiceElmnt[] =
{
   NULLP,
   &soMsgDefRequest,
   &soMsgDefResponse
};


PUBLIC CmAbnfElmTypeChoice soMsgDefSipMessageChoice =
{
   3,
   0,
   NULLP,
   soMsgDefSipMessageChoiceElmnt,
   soMsgDefSipMessageChoiceEnum
};

PUBLIC CmAbnfElmDef soMsgDefSipMessage =
{
#ifdef CM_ABNF_DBG
   "SO SIPMESSAGE",
   "SORE_SIPMESSAGECHOICE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SIP_BASE + 864,
   sizeof(((SoEvnt *)0)->t) + sizeof(TknU8),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&soMsgDefSipMessageChoice,
   soRegExpSipMessageChoice
};



/********************************************************************30**

         End of file:     so_db.c@@/main/4 - Tue Apr 20 12:46:14 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**


*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---      ms   1. initial release.
/main/1+    so002.11  us   1. miscellaneous.
            so005.101 zmc  1. database definition for realm should be OPTSEQOF
                              rather than SEQOF. This cause the authentication
                              encoding failure. An new database definition 
                              soMsgDefAuthParamList is added.
/main/1+    so011.101 hd   1. fix soMsgDefRecordRouteStrEnum - needed a "-" 
                              in Record-Route.
                      us   2. PPort: Maximum value for port is changed from 
                              99999 to 65535.
                           3. Delay:  The delay range is increased 
                              from 9999 to 0xFFFFFFFF.
                           4. TimestampVal: The range of values is 
                              increased from 100000 to 0xFFFFFFFF.
                           5. CSeqNum: The CSeq maximum value is 
                              changed from 9999 to 0xFFFF.
                           6. q: soMsgDefQStrEnum is modified from "q=" to "q"
/main/1+    so019.101 bdu  1. fix the problem with decoding
                               Authorization header.
                           2. fix the problem in UrlParameter.
/main/1+    so021.101 pk   1. Added soMsgDefPriorityHdrSeqElmnt
                           2. Changed soMsgDefPriority to soMsgDefPriorityHdr
                              in soMsgDefHeaderChoiceElmnt structure.
/main/1+    so024.101 cvp  1. Fixed database to decode Date header
                              with/without space after ','. While encoding
                              a space is always added.
/main/1+    so025.101 yj   1. Fixed database to support NAT
/main/2      ---      cy   1. Changed copyright header.
                           2. Miscellaneous changes.
/main/2+    so001.102 cvp  1. Correcting Subscription-Expires header 
                              decoding.
                           2. Removed definition of soMsgDefEventHeaderList. 
                      mc   3. global function reorg.
/main/2+    so002.102 bdu  1. change for lr parameter.
/main/2+    so004.102 bdu  1. fix the Event header decoding for Subscribe.
            so006.102 ps   1. New functions to optimize header comparison
                              and finding end of SIP headers.
            so009.102 zmc  1. add LWS for authorization decoding 
                              failure
            so012.102 pk   1. Added typecast for lr parameter for g++
                              compilation.
                           2. Fixed range value for the Cseq in the RACK
                              header
                      zmc  3. Add LWS for proxy-authorization 
                              decoding failure
            so013.102 zmc  1. Fix the other-param database bug
                           2. Add LWS for EQUAL
            so014.102 pg   1. SO_EVENT has been replaced with SO_EVENT_HDR flag.
                              If SO_EVENT has been defined then SO_EVENT_HDR has been
                              defined as well.
/main/4      ---       ms  1. Release for 2.1.
/main/4+    so001.201  up  1. Added new Meta for Display Name.
/main/4+    so007.201  up  1. Use soRegExpUrlParameters for Tel params
/main/4+    so011.201  up  1. Change SDP to lowercase for sub media type
/main/4+    so017.201  pk  1. Change id_type to id-type in rpId def
/main/4+    so023.201  ab  1. Changes to allow space after colon while encoding
/main/4+    so028.201  ss  1. Increased range of the timestamp delay fraction
/main/4+    so029.201  ss  1. Changed SIPFRAG to small case
                           2. Increased range of timestamp fraction
*********************************************************************91*/
