/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:    SIP User Agent

     Type:    C source file

     Desc:    Code for SIP User Agent

     File:    so_ua.c

     Sid:      so_ua.c@@/main/4 - Tue Apr 20 12:47:24 2004

     Prg:     pk

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"         /* environment options          */
#include "envdep.h"         /* environment dependent        */
#include "envind.h"         /* environment independent      */
#include "gen.h"            /* general layer                */
#include "ssi.h"            /* system services              */
#include "cm_llist.h"       /* common library               */
#include "cm5.h"            /* common timer module          */
#include "cm_hash.h"        /* common hash list             */
#include "cm_tpt.h"         /* common transport             */
#include "cm_tkns.h"        /* common tokens                */
#include "cm_sdp.h"         /* common SDP                   */
#include "cm_mblk.h"        /* common memory allocation     */
#include "cm_abnf.h"        /* common abnf library          */
#include "cm_dns.h"         /* common DNS                   */
#include "sot.h"            /* SOT interface                */
#include "lso.h"            /* layer management, SIP        */
#include "so.h"             /* SIP layer defines            */
#include "so_trans.h"       /* Transaction related structures */
#include "so_err.h"         /* SIP error defines            */
#include "so_cm.h"          /* SIP layer utility functions  */
#include "so_ua.h"          /* interface between UI and UA  */

/* header/extern include files (.x) */
#include "gen.x"            /* general layer                */
#include "ssi.x"            /* system services              */
#include "cm5.x"            /* common timer module          */
#include "cm_lib.x"         /* common library               */
#include "cm_llist.x"       /* common link list             */
#include "cm_hash.x"        /* common hash list             */
#include "cm_tkns.x"        /* common tokens                */
#include "cm_tpt.x"         /* common transport             */
#include "cm_xtree.x"       /* common radix tree            */
#include "cm_mblk.x"        /* common memory allocation     */
#include "cm_sdp.x"         /* common SDP                   */
#include "cm_abnf.x"        /* common abnf library          */
#include "cm_dns.x"         /* common DNS                   */
#include "sot.x"            /* SOT interface                */
#include "lso.x"            /* layer management SIP         */
#include "so_tcm.x"         /* Transport related structures */
#include "so.x"             /* SIP layer structures         */
#include "so_trans.x"       /* Transaction related structures */
#include "so_cm.x"          /* SIP layer utility functions  */
#include "so_dns.x"         /* SIP DNS functions            */
#include "so_tcm.x"         /* TCM defines                  */
#include "so_utl.x"         /* SIP utility functions        */
#include "so_cl.x"          /* Cache Library                */
#include "so_lcs.x"         /* SIP Location Services        */
#include "so_ua.x"          /* SIP UA                       */

#ifdef SO_UA


/***************************************************************/
/*             Private Function Prototypes                     */
/***************************************************************/

#ifdef SO_RFC_3262

PRIVATE SoProvRspCb *soUaLocateProvRspCb ARGS((SoCLegCb  *cLeg,
                                               SoEvnt    *evnt,
                                               U32       *rSeqVal
                                               ));


PRIVATE S16 soUaChkRelProvRspHdr ARGS((SoCLegCb  *cLeg,
                                       SoEvnt    *evnt,
                                       Bool      relRsp
                                       ));

PRIVATE S16 soUaPrcRelProvRsp ARGS((SoCLegCb  *cLeg,
                                    SoEvnt    *evnt
                                    ));

PRIVATE Void soUaStopRelRspTmr ARGS((SoCLegCb  *cLeg));

#endif /* SO_RFC_3262 */


PRIVATE S16 soUaOutProvRsp ARGS((SoCLegCb  *cLeg,
                                  SoEvnt    *evnt,
                                  Bool      *reliableRsp
                                  ));


PRIVATE Void soUaDelMultRspCLegs ARGS((SoCLegCb   *cLeg));

PRIVATE S16 soUaInc1xxRsp ARGS((SoCLegCb *cLeg,
                                SoEvnt   *evnt,
                                Bool     *passToUsr,
                                U16      responseCode
                                ));


PRIVATE Void soUaPrcExpiresHdr ARGS((SoCLegCb *cLeg,
                                     SoEvnt   *evnt
                                     ));


#ifdef SO_RFC_3262
PRIVATE S16 soUaIncRelProvRsp ARGS((SoCLegCb *cLeg, SoEvnt *evnt));
#endif

PRIVATE S16 soUaInc2xxRsp ARGS((SoCLegCb *cLeg,
                                SoEvnt   *evnt,
                                Bool     *passToUsr
                                ));

PRIVATE S16 soUaInc3xxRsp ARGS((SoCLegCb *cLeg,
                                SoEvnt   *evnt,
                                Bool     *passToUsr
                                ));

PRIVATE S16 soUaIntAckAndBye ARGS((SoCLegCb    *cLeg,
                                   SoEvnt      *rspEvnt
                                   ));

PRIVATE S16 soUaIntBye ARGS((SoCLegCb    *cLeg));
PRIVATE S16 soUaIntCancel ARGS((SoCLegCb    *cLeg));

PRIVATE S16 soUaChkLocalUserReg ARGS((SoCLegCb  *cLeg,
                                      SoEvnt    *evnt,
                                      U8        direction));


PRIVATE S16 soUaLocalReg ARGS((SoSSapCb  *ssap,
                               SoEvnt    *evnt
                               ));

PRIVATE S16 soUaRemoteReg ARGS((SoSSapCb *ssap,
                                SoEvnt   *evnt,
                                UConnId  suConnId
                                ));

PRIVATE S16 soUaChkOutInvHdr ARGS((SoCLegCb *cLeg,
                                   SoEvnt   *evnt
                                   ));

PRIVATE S16 soUaChkIncInvHdr ARGS((SoCLegCb *cLeg,
                                   SoEvnt   *evnt
                                   ));

/* so010.201 : Added new fn */
PRIVATE S16 soUaChkOut1xxHdr ARGS((SoCLegCb *cLeg,
                                   SoEvnt   *evnt
                                   ));

PRIVATE S16 soUaChkOut2xxHdr ARGS((SoCLegCb *cLeg,
                                   SoEvnt   *evnt
                                   ));

PRIVATE S16 soUaChkOutAckHdr ARGS ((SoCLegCb *cLeg,
                                    SoEvnt   *evnt
                                    ));

/* 
   so019.201: Renamed soUaChkOptionsHdr to soUaChkIncOptionsHdr 
              Added new soUaChkOutOptionsHdr and soUaChkOutByeHdr 
 */
PRIVATE S16 soUaChkOutOptionsHdr ARGS((SoCLegCb *cLeg,
                                       SoEvnt   *evnt
                                       ));

PRIVATE S16 soUaChkIncOptionsHdr ARGS((SoCLegCb *cLeg,
                                       SoEvnt   *evnt
                                       ));

PRIVATE S16 soUaChkOutByeHdr ARGS((SoCLegCb *cLeg,
                                   SoEvnt   *evnt
                                   ));


#ifdef SO_UPDATE
PRIVATE S16 soUaChkUpdateHdr ARGS((SoCLegCb *cLeg,
                                   SoEvnt   *evnt
                                   ));
#endif /* SO_UPDATE */


#ifdef SO_INSTMSG
/* 
   so019.201: Renamed soUaChkMessageHdr to soUaChkIncMessageHdr  
              Added new soUaChkOutMessageHdr  
 */
PRIVATE S16 soUaChkOutMessageHdr ARGS((SoCLegCb *cLeg, 
                                       SoEvnt *evnt
                                       ));

PRIVATE S16 soUaChkIncMessageHdr ARGS((SoCLegCb *cLeg, 
                                       SoEvnt *evnt
                                       ));
#endif

PRIVATE S16 soUaChkOutCancelHdr ARGS((SoCLegCb   *cLeg,
                                      SoEvnt     *evnt,
                                      SoTransCb  *transCb
                                      ));

PRIVATE S16 soUaChkIncCancelHdr ARGS((SoCLegCb *cLeg,
                                      SoEvnt   *evnt
                                      ));

PRIVATE S16 soUaChkInfoReqHdr ARGS((SoCLegCb *cLeg,
                                     SoEvnt   *evnt
                                     ));

PRIVATE S16 soUaChkInfoRspHdr ARGS((SoCLegCb  *cLeg,
                                    SoEvnt    *evnt
                                    ));

#ifdef SO_RFC_3262
#ifdef SO_EVENT
PRIVATE S16 soUaChkOutEventHdr ARGS((SoCLegCb  *cLeg,
                                    SoEvnt    *evnt
                                    ));

/* so032.201:- Passing the PRACK to User*/
#ifndef SO_RFC_3262_USER
PRIVATE S16 soUaGeneratePrack ARGS((SoCLegCb *cLeg, SoEvnt *evnt, 
                                    TknU32 *rSeq));
#endif /* !SO_RFC_3262_USER*/
#endif
#endif


PRIVATE S16 soUaChkThirdPartyReg ARGS((SoEntCb    *ent,
                                       SoEvnt     *evnt,
                                       SoAddress  **to,
                                       SoAddress  **from,
                                       Bool      *thirdPartyReg
                                       ));


PRIVATE S16 soUaChkRegHdr ARGS((SoEntCb    *ent,
                                SoEvnt     *evnt
                                ));


PRIVATE SoUaRegCb *soUaFindRegCb ARGS((SoEntCb    *ent,
                                       SoEvnt     *evnt,
                                       U8         **key,
                                       U16        *keyLen
                                       ));

PRIVATE SoUaRegCb *soUaCreateRegCb ARGS((SoEntCb    *ent,
                                         U8         **key,
                                         U16        *keyLen
                                         ));

PRIVATE S16 soUaFindRegCallCb ARGS((SoEntCb   *ent,
                                    SoEvnt    *evnt,
                                    SoCallCb  **callPtr
                                    ));

PRIVATE SoCLegCb *soUaFindRegCLeg ARGS((SoEvnt    *evnt,
                                        U8        *key,
                                        U16       keyLen,
                                        SoCallCb  *callCb,
                                        SoUaRegCb *regCb
                                        ));


/* so025.201 : Param saveMsg added to avoid storing event */
/* in userCtxt */
PRIVATE S16 soUaPrcContactInfo ARGS((SoCLegCb    *cLeg,
                                     SoEvnt      *evnt,
                                     Bool        *saveMsg
                                     ));

PRIVATE S16 soUaGetContactCb ARGS((SoCLegCb       *cLeg,
                                   SoRegContactCb **contactCb,
                                   SoContactItem  *newContact
                                   ));

PRIVATE S16 soBldContactRegEvnt ARGS((SoEvnt    *evnt,
                                      SoRegContactCb  *contactCb));

/* so017.201 : Updated fn prototype */
PRIVATE S16 soUaChkContactExp ARGS((SoEvnt    *evnt,
                                    SoRegContactCb *contactCb,
                                    U32            expiryTmrVal,
                                    Bool           *delContact,
                                    Bool           *foundContact
                                    ));

PRIVATE S16 soUaPrcContactsInRsp ARGS((SoCLegCb       *cLeg,
                                       SoEvnt         *evnt,
                                       SoRegContactCb *contactCb,
                                       U32            expiryTmrVal,
                                       Bool           contactInRsp,
                                       Bool           *delContact
                                       ));

PRIVATE Void soUaPrcRegErrRsp ARGS((SoCLegCb  *cLeg, U32 cSeqVal));

PRIVATE S16 soUaPrcRegRsp ARGS((SoCLegCb    *cLeg,
                                SoEvnt      *evnt,
                                U32         cSeqVal
                               ));

PRIVATE SoUaRegCb *soUaFindRegCb   ARGS((SoEntCb    *ent,
                                         SoEvnt     *evnt,
                                         U8         **key,
                                         U16        *keyLen
                                         ));


PRIVATE S16 soUaCalcRegClegKey ARGS((SoEvnt   *evnt,
                                     U8       **key,
                                     U16      *keyLen)); 

PRIVATE S16 soUaCreateRecurseContact ARGS((SoRecurseContact **recurseContact, 
                                           SoContactItem    *contactItem
                                           ));

PRIVATE S16 soUaStoreRecContact ARGS((SoEvnt       *evnt,
                                      SoRecurseCb  *recurseCb
                                      ));

PRIVATE S16 soUaInitRecurse ARGS((SoCLegCb   *cLeg,
                                  SoEvnt     *evnt
                                  ));


PRIVATE S16 soUaAddRecurseContacts ARGS((SoEvnt      *evnt,
                                         SoRecurseCb *recurseCb
                                         ));

PRIVATE S16 soUaRecurse ARGS((SoCLegCb   *cLeg,
                              SoEvnt     *evnt
                              ));

#ifdef SO_SESSTIMER

PRIVATE  S16 soUacSessTmrPrcReq ARGS((SoEntCb   *ent,
                                      SoCLegCb   *cLeg,
                                      SoEvnt     *evnt
                                      ));

PRIVATE  S16 soUacSessTmrPrc2xx  ARGS((SoEntCb   *ent,
                                      SoCLegCb   *cLeg,
                                      SoEvnt     *evnt
                                      ));

PRIVATE  S16 soUacSessTmrPrc422Rsp  ARGS((SoEntCb   *ent,
                                      SoCLegCb   *cLeg,
                                      SoEvnt     *evnt
                                      ));

PRIVATE  S16 soUasSessTmrPrcReq  ARGS((SoEntCb   *ent,
                                      SoCLegCb   *cLeg,
                                      SoEvnt     *evnt
                                      ));


PRIVATE  S16 soUasSessTmrPrc2xx ARGS((SoEntCb   *ent,
                                      SoCLegCb   *cLeg,
                                      SoEvnt     *evnt
                                      ));


PRIVATE  S16 soStopSessTimer ARGS((SoCLegCb    *cLeg));

PRIVATE  S16 soUaInitSessTmrCb ARGS((SoCLegCb          *cLeg,
                                     SoSessionExpires  *sessExp,
                                     SoMinSE           *minSe,
                                     U8                callRole
                                     ));

PRIVATE S16 soStartSessTimer ARGS((SoCLegCb    *cLeg));

#endif /* SO_SESSTIMER */

#ifdef SO_EVENT
PRIVATE S16 soSubscFSMUpdateReq ARGS((SoSubNode *node, 
                                      U8 sipMethod, 
                                      Bool isIncoming, 
                                      U8 subscriptionState)); 

PRIVATE S16 soSubscFSMUpdateRsp ARGS((SoSubNode *node, 
                                      U8 sipMethod, 
                                      U16 statusCode, 
                                      U8 subscriptionState,
                                      Bool retryAfter,
                                      TknU32     *expHdr)); 

PRIVATE S16 soSubscFSMUpdateTimeout ARGS((SoSubNode *node, 
                                          Bool isSubscExpTmr));

PRIVATE S16 soFindSubscNode     ARGS((SoCLegCb   *cLeg,
                                      TknStrOSXL *subId,
                                      SoSubNode **node,
                                      U8         subscType));

PRIVATE S16 soGetSubscInfo ARGS((SoEvnt *event, 
                                 TknStrOSXL *subId, 
                                 SoEventHeader **eventHdr, 
                                 TknU32     **expiresHdr, 
                                 U16 *numEventHdr, 
                                 U8 *subscriptionState,
                                 Bool *isReferEvent,
                                 TknU32 *notifyExpires,
                                 Bool *retryAfter));

PRIVATE S16 soAllocSubscNode ARGS((SoSubNode **node, 
                                   TknStrOSXL *subId,
                                   SoEvnt    *event,
                                   SoCLegCb   *cLeg,
                                   U8         subscType,
                                   Bool       isNotifier));


PRIVATE U8 soSubscCheckEventPkgType ARGS((SoEntCb *ent, 
                                   PTR event,
                                   Bool iseventHdr));
#endif /* SO_EVENT */

#ifdef SO_REPLACES
PRIVATE S16 soUaPrcInvReplacesHdr ARGS((SoCLegCb *cLeg,  
                                        SoEvnt  *evnt ));
#endif /* SO_REPLACES */


/* so026.201: Macro to save subscription node information in       *
 * transaction control block and increment reference count in      *
 * subscription node control block.                                */
#define SO_UA_SAVE_REF(_userCtxt, _node)                             \
{                                                                    \
   if (_node)                                                        \
   {                                                                 \
     (_userCtxt).subscCb  = (_node);                                 \
     (_node)->refCount ++;                                           \
                                                                     \
     SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf, "\nSAVE_REF: Type "\
     "(%d), RefCount (%d) \n", (_node)->type, (_node)->refCount));   \
   }                                                                 \
}








/***************************************************************/
/*      Interface Functions to Upper Interface Module          */
/***************************************************************/

/*
*
*       Fun:   soUaInviteReq
*
*       Desc:  This function handles an INVITE from the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaInviteReq
(
SoSSapCb *ssap,       /* SSAP cb              */
SoEvnt   *evnt,       /* Invite Message Event */        
UConnId  suConnId     /* Connection Id        */
)
#else
PUBLIC S16 soUaInviteReq(ssap, evnt, suConnId)
SoSSapCb *ssap;       /* SSAP cb              */
SoEvnt   *evnt;       /* Invite Message Event */        
UConnId  suConnId;    /* Connection Id        */
#endif 
{
   SoCallCb        *callCb;    /* Call Control Block */
   SoCLegCb        *cLeg;      /* Call Leg Cb        */
   Bool            newCall;    /* New call or not    */
   SoUserCtxt      userCtxt;   /* User Context Cb    */
   S16             ret;        /* return Value       */

   TRC2(soUaInviteReq);

  /*--- so014.201: Initialize local variable ---*/
   ret = ROK;
   cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

   SODBGP_SO(SO_DBGMASK_UA,
             (soCb.init.prntBuf,
              "soUaInviteReq: \n"
              "Outgoing Invite: spId : %d; suConnId : %ld"
              "Call Leg Id : %lx; Trans Id : %lx \n",
              ssap->sapId, suConnId, evnt->callLegId, evnt->transId));

   newCall = FALSE;

   /* Check if Resources are available for the call */
   if (soUtlChkRes(evnt, SO_USER)!= ROK)
     RETVALUE(SOT_ERR_RSRC);

   /* Try to Locate Call */
   soCoreLocateSuCallCtxt(ssap, evnt, suConnId, SO_CONNID_NOTUSED, 
                          &callCb, &cLeg);

   /* If there is no call, create one */
   if (callCb == NULLP)
   {
      /* If call doesnot exist, create a new call cb */
      callCb = soCoreCreateCallCb(ssap, ssap->sys, suConnId, 
                                  evnt, SO_USER);
      
      if (callCb == NULLP)
        RETVALUE(SOT_ERR_RSRC);

      newCall = TRUE;
   }
   else
   {
      if (cLeg != NULLP)
        RETVALUE(SOT_ERR_CLEG_EXISTS);
   }


   /* Create a new call leg */
   cLeg = soDlgCreateCleg(callCb, evnt, SO_USER);
   if (cLeg == NULLP)
   {
      if (newCall == TRUE)
        soCoreDeleteCallCb(callCb);
      RETVALUE(SOT_ERR_RSRC);
   }

  /* so022.201 : Save user connection identifier in call leg */
   cLeg->userConnId = suConnId;

   /* If there is a pending Invite being processed , we should
      reject this invite */
   if (cLeg->sentInvite != NULLP)
     RETVALUE(SOT_ERR_INVITE_REQ_FAILED);

   /* Store the outgoing Invite in the call leg */
   cLeg->sentInvite = evnt;

   /* Check if user is locally Registered */
   ret = soUaChkLocalUserReg(cLeg, evnt, SO_USER);
   if (ret != SOT_ERR_NOERR)
   {
     /* so040.201: Set event pointer to NULLP in cLeg so that it is not deleted 
     in soDlgDeleteCleg. When error is returned, Event is deleted in soUiErrInd */
     cLeg->sentInvite = NULLP;
     SO_UA_DEL_CALL_CTXT(cLeg, callCb, ret);
   }

  
   /* Check the headers in the incoming INVITE */
   ret = soUaChkOutInvHdr(cLeg, evnt);
   if (ret != SOT_ERR_NOERR)
   {
     /* so040.201: set event pointer to nullp in cleg so that it is not deleted 
     in soDlgDeleteCleg. When error is returned, Event is deleted in soUiErrInd */
    cLeg->sentInvite = NULLP;
     SO_UA_DEL_CALL_CTXT(cLeg, callCb, ret);
   }

  /* Check for offer Answer exchange */
#ifdef SO_EXT_OFFER_ANS
  ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_USER);
  if (ret != SOT_ERR_NOERR)
  {
     /* so040.201: set event pointer to nullp in cleg so that it is not deleted 
     in soDlgDeleteCleg. When error is returned, Event is deleted in soUiErrInd */
     cLeg->sentInvite = NULLP;
     SO_UA_DEL_CALL_CTXT(cLeg, callCb, ret);
  }
#endif /* SO_EXT_OFFER_ANS */


   /* Check for Session Timer */
#ifdef SO_SESSTIMER 
  ret = soUacSessTmrPrcReq(callCb->ent, cLeg, evnt);
  if (ret != SOT_ERR_NOERR)
  {
     /* so040.201: set event pointer to nullp in cleg so that it is not deleted 
     in soDlgDeleteCleg. When error is returned, Event is deleted in soUiErrInd */
    cLeg->sentInvite = NULLP;
    SO_UA_DEL_CALL_CTXT(cLeg, callCb, ret);
  }
#endif /* SO_SESSTIMER */
  
  /* Fill the user context that will be stored in 
     the transaction layer */
  SO_FILL_USER_CTXT(userCtxt, TRUE, FALSE);


#ifdef LSO_ACNT
   /* Fillin mediaType for Accounting */
   soUtlPrcContentType(cLeg, evnt);
#endif


  /* Send the INVITE to the dialog module for further 
     processing */
  ret = soDlgUaOutReq(cLeg, &userCtxt, evnt);
  if (ret != SOT_ERR_NOERR)
  {
    /* This event will get deleted from above. So it
       can be marked to NULLP within the call leg */
    cLeg->sentInvite = NULLP;
    SO_UA_DEL_CALL_CTXT(cLeg, callCb, ret);
  }

  /* Start Expires Header */
  soUaPrcExpiresHdr(cLeg, evnt);
  RETVALUE(SOT_ERR_NOERR);


}





/*
*
*       Fun:   soUaCnStReq
*
*       Desc:  This function handles an 1xx Responses, INFO
*              messages received from the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaCnStReq
(
SoSSapCb *ssap,     /* SSAP cb */
SoEvnt *evnt,        /* Message From User */
UConnId spConnId,   /* Service Provider Conn Id */
UConnId suConnId    /* Service User Conn Id */
)
#else
PUBLIC S16 soUaCnStReq(ssap, evnt, spConnId, suConnId)
SoSSapCb *ssap;     /* SSAP cb */
SoEvnt *evnt;        /* Message From User */
UConnId spConnId;   /* Service Provider Conn Id */
UConnId suConnId;   /* Service User Conn Id */
#endif
{
  SoCallCb   *callCb;     /* call cb */
  SoCLegCb   *cLeg;       /* Call Leg Cb */
  SoUserCtxt userCtxt;   /* UserCtxt */
  SoTransCb   *transCb;   /* Transaction Cb */
  Bool       reliableRsp; /* Reliable Provisional Response */
  S16        ret;         /* Return Value */

 /* so033.201 :- Adding Rack in outgoing PRACK message, if not provided
  * by the Application*/
#ifdef SO_RFC_3262
#ifdef SO_RFC_3262_USER
  SoCSeq      *cSeq;      /* new CSeq header in PRACK */
  /* so038.201 :- If Rack is present in outgoing PRACK message, donot add it again*/
  SoRAck      *rAck;      /* RAck header field */
#endif
#endif  

  TRC2(soUaCnStReq);

  /*--- so014.201: Initialize local variable ---*/
  ret = ROK;
  cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

  reliableRsp = FALSE;
  transCb = NULLP;

  /* Locate the call & call leg for the message */
  soCoreLocateSuCallCtxt(ssap, evnt, suConnId, spConnId, &callCb,
                         &cLeg);
  if (callCb == NULLP)
    RETVALUE(SOT_ERR_CALL_NOTFOUND);

  if (cLeg == NULLP)
    RETVALUE(SOT_ERR_CLEG_NOTFOUND);

  /* If request check for required headers */
  if (evnt->sipMessageType.val == SO_SIPMESSAGE_REQUEST)
  {

    SODBGP_SO(SO_DBGMASK_UA,
              (soCb.init.prntBuf,
               "soUaCnStReq: \n"
               "Outgoing %s : spId : %d; spConnId : %ld"
               "Call Leg Id : %lx; Trans Id : %lx \n",
               soSOTEventDescrip[evnt->eventType.val - 1],
               ssap->sapId, spConnId, evnt->callLegId, evnt->transId));

    /* if message is INFO check fr specific headers */
    if (evnt->eventType.val == SOT_ET_INFO)
       soUaChkInfoReqHdr(cLeg, evnt);

    /* so033.201 :- Adding Rack in outgoing PRACK message, if not provided
     * by the Application*/
#ifdef SO_RFC_3262
#ifdef SO_RFC_3262_USER
    if (evnt->eventType.val == SOT_ET_PRACK)
    {    
       /* so038.201 :- If Rack is present in outgoing PRACK message, 
        * donot add it again*/
       /* Find rAck header in message */
       ret = soCmFindHdrChoice(evnt, (U8 **) &rAck, SO_HEADER_GEN_RACK);
       if (ret != ROK)
       {
          /* RAck header is not present, add it */       
          /* Find CSeq from evnt */
          if (soCmFindHdrChoice(evnt, (U8 **) &cSeq, SO_HEADER_GEN_CSEQ)
                != ROK)
          {
             SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                      "soUaCnStReq: soCmFindHdrChoice failed to Get CSEQ\n"));             
             RETVALUE(RFAILED);
          }

          /* Add a RACK */
          ret = soUtlAddRAckHdr(evnt, cSeq, cLeg->relProvRspInfo.currRseq);
          if (ret != ROK)
          {
             SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                      "soUaCnStReq: soUtlAddRAckHdr failed\n"));             
             RETVALUE(ret);
          }
       }

       /* Check for offer Answer exchange */
#ifdef SO_EXT_OFFER_ANS
       ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_USER);
       if (ret != SOT_ERR_NOERR)
       {
          SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                   "soUaCnStReq: soDlgChkOfferAns failed\n"));             
          RETVALUE(ret);
       }
#endif /* SO_EXT_OFFER_ANS */

    }
#endif /* SO_RFC_3262_USER */
#endif /* SO_RFC_3262 */

    /* Fill the user context that will be stored in the transaction layer */
    /*--- so009.201: Event can be deleted after sending request ----*/
    SO_FILL_USER_CTXT(userCtxt, FALSE, FALSE);

    /* Send request to dialog module */
    ret = soDlgUaOutReq(cLeg, &userCtxt, evnt);
  }
  else
  {
    SODBGP_SO(SO_DBGMASK_UA,
              (soCb.init.prntBuf,
               "soUaCnStReq: \n"
               "Outgoing 1xx : Event : %s, spId : %d; spConnId : %ld"
               "Call Leg Id : %lx; Trans Id : %lx \n",
               soSOTEventDescrip[evnt->eventType.val - 1],
               ssap->sapId, spConnId, evnt->callLegId, evnt->transId));

    /* If response find request transaction*/
#ifdef SO_REL_1_2_INF
     /* Get tranaction Cb from cLeg List */
     transCb = soDlgLocateRspTran(cLeg, evnt);
     if (transCb == NULLP)
        RETVALUE(SOT_ERR_TRAN_NOTFOUND);
#endif

     /* Check for INFO specific headers */
     if (evnt->eventType.val == SOT_ET_INFO)
        ret = soUaChkInfoRspHdr(cLeg, evnt);
     else
     {
        /* so010.201 : Add new fn to fill hdr */
        ret = soUaChkOut1xxHdr(cLeg, evnt);

        if (ret != SOT_ERR_NOERR)
           RETVALUE(ret);
           
       ret = soUaOutProvRsp(cLeg, evnt, &reliableRsp);
     }
     
     /* If message was a reliable one, it would have gotten 
      * sent out by the internal function itself. In all
      * other cases, send out response from here */
     /* so010.201 : Delete the sent response as we have no more use for it */
     if ((ret == SOT_ERR_NOERR) && (reliableRsp == FALSE))
     {
       ret = soDlgUaOutRsp(cLeg, evnt, transCb);
       if (cLeg->sentRsp != NULLP)
       {
          SPutMsg (cLeg->sentRsp);
          cLeg->sentRsp = NULLP;
       }
     }
  }
  
  RETVALUE(ret);
    
} /* soUaCnStReq */



/*
*
*       Fun:   soUaAckReq
*
*       Desc:  This function handles an outgoing ACK
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaAckReq
(
SoSSapCb *ssap,     /* SSAP cb */
SoEvnt *evnt,        /* Message From User */
UConnId spConnId,   /* Service Provider Conn Id */
UConnId suConnId    /* Service User Conn Id */
)
#else
PUBLIC S16 soUaAckReq(ssap, evnt, spConnId, suConnId)
SoSSapCb *ssap;     /* SSAP cb */
SoEvnt *evnt;        /* Message From User */
UConnId spConnId;   /* Service Provider Conn Id */
UConnId suConnId;   /* Service User Conn Id */
#endif
{
  SoCallCb   *callCb;     /* call cb */
  SoCLegCb   *cLeg;       /* Call Leg Cb */
  SoUserCtxt userCtxt;   /* UserCtxt */
  Bool       reliableRsp; /* Reliable Provisional Response */
  S16        ret;         /* Return Value */

  TRC2(soUaAckReq);

  /*--- so014.201: Initialize local variable ---*/
  ret = ROK;
  cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

  reliableRsp = FALSE;

  SODBGP_SO(SO_DBGMASK_UA,
              (soCb.init.prntBuf,
               "soUaAckReq: \n"
               "Outgoing Ack : spId : %d; spConnId : %ld"
               "Call Leg Id : %lx; Trans Id : %lx \n",
               ssap->sapId, spConnId, evnt->callLegId, evnt->transId));

  /* Locate the call & call leg for the message */
  soCoreLocateSuCallCtxt(ssap, evnt, suConnId, spConnId, &callCb,
                         &cLeg);
  if (callCb == NULLP)
    RETVALUE(SOT_ERR_CALL_NOTFOUND);

  if (cLeg == NULLP)
    RETVALUE(SOT_ERR_CLEG_NOTFOUND);

  ret = soUaChkOutAckHdr(cLeg, evnt);
  if (ret != SOT_ERR_NOERR)
    RETVALUE(ret);

  /* Fill the user context that will be stored in the transaction layer */
  /*--- so009.201: ACK Event can be deleted after sending message ---*/
  SO_FILL_USER_CTXT(userCtxt, FALSE, FALSE);

  /* Send request to dialog module */
  ret = soDlgUaOutReq(cLeg, &userCtxt, evnt);

#ifdef LSO_ACNT
  if (ret == SOT_ERR_NOERR)
  {
    soMiPrcAccounting(cLeg, LSO_ACNT_EST);
  }
#endif /* LSO_ACNT */

  RETVALUE(ret);
    
} /* soUaAckReq */





/*
*
*       Fun:   soUaConRsp
*
*       Desc:  This function handles an 2xx-6xx Responses to an
*              INVITE, received from the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaConRsp
(
SoSSapCb  *ssap,     /* SSAP Cb */
SoEvnt    *evnt,     /* Event Message */
UConnId   spConnId,  /* Service Provider Conn Id */
UConnId   suConnId   /* Service Provider ConnId */
)
#else
PUBLIC S16 soUaConRsp(ssap, evnt, spConnId, suConnId)
SoSSapCb  *ssap;     /* SSAP Cb */
SoEvnt    *evnt;     /* Event Message */
UConnId   spConnId;  /* Service Provider Conn Id */
UConnId   suConnId;  /* Service Provider ConnId */
#endif
{
  SoCallCb   *callCb;       /* Call CB        */
  SoCLegCb   *cLeg;         /* Call Leg Cb    */
  SoTransCb  *transCb;      /* Transaction Cb */
  U16        responseCode;  /* Response Code  */
  U16        responseClass; /* Response Class */
  S16        ret;           /* Return Value */

  TRC2(soUaConRsp);

  /*--- so014.201: Initialize local variable ---*/
  ret     = ROK;
  transCb = NULLP;
  responseCode = evnt->t.response.statusLine.statusCode.val;
  responseClass = responseCode/100;

  SODBGP_SO(SO_DBGMASK_UA,
            (soCb.init.prntBuf,
             "soUaConRsp: \n"
             "Outgoing Invite Response : Response Code : %d;"
             "spId : %d; spConnId : %ld"
             "Call Leg Id : %lx; Trans Id : %lx \n",
             responseCode, ssap->sapId, spConnId, evnt->callLegId, evnt->transId));

  /* Find call & call leg */
  soCoreLocateSuCallCtxt(ssap, evnt, suConnId, spConnId, &callCb, &cLeg);

  if (callCb == NULLP)
    RETVALUE(SOT_ERR_CALL_NOTFOUND);

  if (cLeg == NULLP)
    RETVALUE(SOT_ERR_CLEG_NOTFOUND);

  /* If response is a 2xx */
  if (responseClass == SO_STACODE_TYPE_SUCCESS)
  {
    /* Check for 2xx headers */
    ret = soUaChkOut2xxHdr(cLeg, evnt);
    if (ret != SOT_ERR_NOERR)
      RETVALUE(ret);


#ifdef SO_RFC_3262
    /* If there are any pending Prvisional responses,
       donot send the 2xx, store it in the call leg */
    if ((cmLListLen(&cLeg->relProvRspInfo.pendProvRspLst) != 0) ||
        (CM_HASH_NMBENT(&cLeg->relProvRspInfo.provRspCbLst) != 0))
    {
      cLeg->relProvRspInfo.pend2xxEvnt = evnt;
      RETVALUE(SOT_ERR_NOERR);
    }
#endif


    /* Check for Offer-Answer exchange */
#ifdef SO_EXT_OFFER_ANS
    ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_USER);
    if (ret != SOT_ERR_NOERR)
      RETVALUE(ret);
#endif /* SO_EXT_OFFER_ANS */

   /* Check for Session Timer */
#ifdef SO_SESSTIMER 
    ret = soUasSessTmrPrc2xx(ssap->sys, cLeg, evnt);
    if (ret != SOT_ERR_NOERR)
      RETVALUE(ret);
#endif /* SO_SESSTIMER */

   }

#ifdef SO_REL_1_2_INF
  /* Get tranaction Cb from cLeg List */
  transCb = soDlgLocateRspTran(cLeg, evnt);
#endif


  /* Send response to dialog layer */
  ret = soDlgUaOutRsp(cLeg, evnt, transCb);
  if (ret != SOT_ERR_NOERR)
    RETVALUE(ret);

  /*--- so041.201: If it is a 2xx for an INVITE, save encoded  --*
   *--- message for retransmission and start timer             --*/
  if ((responseClass == SO_STACODE_TYPE_SUCCESS) && 
      (cLeg->sentRsp != NULLP))
  {
    SO_PRC_OUT_2XX_INFO(cLeg, cLeg->sentRsp);
    cLeg->sentRsp = NULLP;
  }
#ifdef SO_RFC_3262
  else if (responseClass > SO_STACODE_TYPE_SUCCESS)
  {
    /* For failure responses stop the reliable 1xx retx timers */
    soUaStopRelRspTmr(cLeg);
  }
#endif

  /* Stop the Expires Timer */
  soSchedTmr(cLeg, SO_TMR_EXPIRES, TMR_STOP, NOTUSED);

  /* so010.201 : Delete the sent response as we have no more use for it */
  if (cLeg->sentRsp != NULLP)
  {
     SPutMsg (cLeg->sentRsp);
     cLeg->sentRsp = NULLP;
  }

  RETVALUE(SOT_ERR_NOERR);
}




/*
*
*       Fun:   soUaModReq
*
*       Desc:  This function a Re-Invite equest received from the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaModReq
(
SoSSapCb *ssap,     /* SSAP cb */
SoEvnt *evnt,       /* Message From User */
UConnId spConnId,   /* Service Provider Conn Id */
UConnId suConnId    /* Service User Conn Id */
)
#else
PUBLIC S16 soUaModReq(ssap, evnt, spConnId, suConnId)
SoSSapCb *ssap;     /* SSAP cb */
SoEvnt *evnt;       /* Message From User */
UConnId spConnId;   /* Service Provider Conn Id */
UConnId suConnId;   /* Service User Conn Id */
#endif
{
  SoCallCb   *callCb;     /* call cb */
  SoCLegCb   *cLeg;       /* Call Leg Cb */
  SoUserCtxt userCtxt;   /* UserCtxt */
  S16        ret;         /* Return Value */

  TRC2(soUaModReq);

  /*--- so014.201: Initialize local variable ---*/
  ret     = ROK;
  cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

  SODBGP_SO(SO_DBGMASK_UA,
            (soCb.init.prntBuf,
             "soUaModReq: \n"
             "Outgoing Re-Invite: spId : %d; spConnId : %ld"
             "Call Leg Id : %lx; Trans Id : %lx \n",
              ssap->sapId, spConnId, evnt->callLegId, evnt->transId));

  /* Locate the call & call leg for the message */
  soCoreLocateSuCallCtxt(ssap, evnt , suConnId, spConnId, &callCb,
                         &cLeg);

  if (callCb == NULLP)
    RETVALUE(SOT_ERR_CALL_NOTFOUND);

  if (cLeg == NULLP)
    RETVALUE(SOT_ERR_CLEG_NOTFOUND);

  /* Check out INVITE specific headers */
  ret = soUaChkOutInvHdr(cLeg, evnt);
  if (ret != ROK)
    RETVALUE(ret);

  /*- so009.201: Re-INVITE Event can be deleted after sending message --*/
  SO_FILL_USER_CTXT(userCtxt, FALSE, FALSE);

  /* Update  Remote Traget URI */
  ret = soDlgUpdRemoteTrgtURI(cLeg, evnt);

   /* Check for Session Timer */
#ifdef SO_SESSTIMER 
  /* so003.201 : check for SOT_ERR_NOERR */
  ret = soUacSessTmrPrcReq(callCb->ent, cLeg, evnt);
  if (ret != SOT_ERR_NOERR)
    RETVALUE(ret);
#endif /* SO_SESSTIMER */
   
  if (ret == SOT_ERR_NOERR)
    ret = soDlgUaOutReq(cLeg, &userCtxt, evnt);

  RETVALUE(ret);
} /* soUaModReq */






/*
*
*       Fun:   soUaCAMReq
*
*       Desc:  This function a CAM message received from the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaCAMReq
(
SoSSapCb *ssap,     /* SSAP cb */
SoEvnt   *evnt,     /* Message From User */
UConnId spConnId,   /* Service Provider Conn Id */
UConnId suConnId    /* Service User Conn Id */
)
#else
PUBLIC S16 soUaCAMReq(ssap, evnt, spConnId, suConnId)
SoSSapCb *ssap;     /* SSAP cb */
SoEvnt   *evnt;       /* Message From User */
UConnId  spConnId;   /* Service Provider Conn Id */
UConnId  suConnId;   /* Service User Conn Id */
#endif
{
  SoCallCb   *callCb;     /* call cb          */
  SoCLegCb   *cLeg;       /* Call Leg Cb      */
  Bool       newCall;     /* TRUE if new call */
  S16        ret;         /* Return Value     */
  SoUserCtxt userCtxt;    /* UserCtxt         */
#ifdef SO_EVENT
  SoSubNode  *node;       /* Subscription Node*/
  Bool       saveMsg;
#endif /* SO_EVENT */ 

  TRC2(soUaCAMReq);

  /*--- so014.201: Initialize local variable ---*/
  ret     = ROK;
  cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

  newCall = FALSE;
  callCb  = NULLP;
  cLeg    = NULLP;

  SODBGP_SO(SO_DBGMASK_UA,
            (soCb.init.prntBuf,
             "soUaCAMReq: \n"
             "Outgoing CAM Req: Event: %s,  spId : %d; suConnId : %ld"
             "Call Leg Id : %lx; Trans Id : %lx \n",
             soSOTEventDescrip[evnt->eventType.val - 1], 
             ssap->sapId, suConnId, evnt->callLegId, evnt->transId));

  /* If spConnId is valid, look for call ctxt */
  if (spConnId != SOT_CONNID_NOTUSED)
  {
    /* Locate the call & call leg for the message */
    soCoreLocateSuCallCtxt(ssap, evnt, suConnId, spConnId, &callCb,
                           &cLeg);
  }
  else
  {
    newCall = TRUE;
    soCoreCreateCallCtxt(ssap, ssap->sys, evnt, suConnId, SO_USER,
                         &callCb, &cLeg);
  }

  if (callCb == NULLP)
    RETVALUE(SOT_ERR_CALL_NOTFOUND);
  
  /*---- so035.201, so041.201: ------------------------------------------*

  *-- If SUBSCRIBE is retried after being challenged, application should *
  *-- provide same "SpConnId", same "callId header" and new "cLegId".    *
  *-- Application may choose to proive a new suConnId as well.           *

  *-- In this case we will have to add a new dialog control block.       */
  if (cLeg == NULLP)
  {
     if (evnt->eventType.val == SOT_ET_SUBSCRIBE)
     {
        if ((cLeg = soDlgCreateCleg (callCb, evnt, SO_USER)) == NULLP)
           RETVALUE(SOT_ERR_RSRC);
        
        cLeg->userConnId = suConnId;
     }
     else
        RETVALUE(SOT_ERR_CLEG_NOTFOUND);
  }
  /*------ so035.201: change Ends ---------------------------------------*/

  /* Check for Options Specific Header */
  if (evnt->eventType.val == SOT_ET_OPTIONS)
    ret = soUaChkOutOptionsHdr(cLeg, evnt);

#ifdef SO_UPDATE
  /*-- Verify that UAS also supports UDPATE method --*/
   else if (evnt->eventType.val == SOT_ET_UPDATE)
   {
      ret = soUaChkUpdateHdr(cLeg, evnt);

      /* Check for offer Answer exchange */
#ifdef SO_EXT_OFFER_ANS
      if (ret == ROK)
      {
         ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_USER);
      }
#endif /* SO_EXT_OFFER_ANS */
      

#ifdef SO_SESSTIMER 
      /* so003.201 : Support for Session-Timer for UPDATE */
      /* Check for Session Timer */
      if (ret == ROK) 
         ret = soUacSessTmrPrcReq(callCb->ent, cLeg, evnt);
#endif /* SO_SESSTIMER */
   }
#endif /* SO_UPDATE */

#ifdef SO_INSTMSG
  /* If event  is a Instant message check for 
     specific headers */
  else if (evnt->eventType.val == SOT_ET_MESSAGE)
    ret = soUaChkOutMessageHdr(cLeg, evnt);
#endif /* SO_INSTMSG */

#ifdef SO_EVENT
  /* set save msg to be false */
  saveMsg = FALSE;

  /* initialize node */
  node = NULLP;

  /* If message if Subscribe, Notify, Refer, call
     respective fuinctions to process the messages */
  if(evnt->eventType.val == SOT_ET_SUBSCRIBE)
  {
    ret =  soUaSubscReq(&node, &saveMsg, cLeg, evnt);
  }
  else if(evnt->eventType.val == SOT_ET_NOTIFY)
  {
    ret =  soUaNotifyReq(&node,  cLeg->call->ssapCb, cLeg, evnt);
  }

#ifdef SO_REFER
  else if(evnt->eventType.val == SOT_ET_REFER)
  {
    ret =  soUaReferReq(&node, cLeg, evnt);
  }
#endif /* SO_REFER */  
 
#endif /* SO_EVENT */    
  
  if (ret != SOT_ERR_NOERR)
  {
#ifdef SO_EVENT     
    if(node != NULLP)
    {
       /* soEvnt will be deleted at SOT */
       node->event = NULLP;
       soDlgDelCurSubscNode(node);
    }
#endif
    
    if (newCall == TRUE)
    {
      soCoreDeleteCallCb(callCb);
    }
    RETVALUE(ret);
  }
  
  /* Fill the user context that will be stored in 
     the transaction layer */
  SO_FILL_USER_CTXT(userCtxt, FALSE, FALSE);

#ifdef SO_EVENT
  /* If message is an event related message
     store the subscription node */
   userCtxt.saveMsg = saveMsg;

  /* so026.201: Save subscription CB in Transaction Control block  */
   SO_UA_SAVE_REF (userCtxt, node);

#endif /* SO_EVENT */  
  
  /* Send request to dialog layer */
  ret = soDlgUaOutReq(cLeg, &userCtxt, evnt);
  if (ret != SOT_ERR_NOERR)
  {
#ifdef SO_EVENT    
    if(node)
    {
      node->event = NULLP;
      soDlgDelCurSubscNode(node);
    }
#endif /* SO_EVENT */ 
    if (newCall == TRUE)
    {
      soCoreDeleteCallCb(callCb);
    }
  }
  
  RETVALUE(ret);
} /* soUaCAMReq */





/*
*
*       Fun:   soUaCAMRsp
*
*       Desc:  This function a CAM response received from the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaCAMRsp
(
SoSSapCb *ssap,     /* SSAP cb */
SoEvnt   *evnt,       /* Message From User */
UConnId  spConnId,   /* Service Provider Conn Id */
UConnId  suConnId    /* Service User Conn Id */
)
#else
PUBLIC S16 soUaCAMRsp(ssap, evnt, spConnId, suConnId)
SoSSapCb *ssap;     /* SSAP cb */
SoEvnt   *evnt;        /* Message From User */
UConnId  spConnId;   /* Service Provider Conn Id */
UConnId  suConnId;   /* Service User Conn Id */
#endif
{
  SoCallCb   *callCb;       /* call cb */
  SoCLegCb   *cLeg;         /* Call Leg Cb */
  SoTransCb  *transCb;      /* Transaction Cb */
  S16        ret;           /* Return Value */
  U16        responseCode;  /* Response Class */
  U16        responseClass; /* Response Class */
#ifdef SO_EVENT
  SoSubNode  *node;
#endif  

  TRC2(soUaCAMRsp);

  transCb = NULLP;
#ifdef SO_EVENT
  node = NULLP;
#endif  
  callCb = NULLP;
  cLeg    = NULLP;
  ret     = SOT_ERR_NOERR;

  responseCode = evnt->t.response.statusLine.statusCode.val;
  responseClass = responseCode/100;

  SODBGP_SO(SO_DBGMASK_UA,
            (soCb.init.prntBuf,
             "soUaCAMRsp: \n"
             "Outgoing CAM Rsp: Event: %s,  Response Type: %d"
             "spId : %d; suConnId : %ld"
             "Call Leg Id : %lx; Trans Id : %lx \n",
             soSOTEventDescrip[evnt->eventType.val - 1], responseCode, 
             ssap->sapId, suConnId, evnt->callLegId, evnt->transId));


  /* Locate the call & call leg for the message */
  soCoreLocateSuCallCtxt(ssap, evnt, suConnId, spConnId, &callCb,
                         &cLeg);
  if (callCb == NULLP)
      RETVALUE(SOT_ERR_CALL_NOTFOUND);
    
  if (cLeg == NULLP)
    RETVALUE(SOT_ERR_CLEG_NOTFOUND);

  /* Get tranaction Cb from cLeg List */
  transCb = soDlgLocateRspTran(cLeg, evnt);
  if (transCb == NULLP)
    RETVALUE(SOT_ERR_TRAN_NOTFOUND);

  /* If message is Option check for specific headers */
  if (evnt->eventType.val == SOT_ET_OPTIONS)
  {
     ret = soUaChkIncOptionsHdr(cLeg, evnt);
     /* so038.201:Added error check condition */
     if (ret != SOT_ERR_NOERR)
        RETVALUE(ret);
  }
#ifdef SO_UPDATE
  /* If message is an update set the reset pend flag
     so that other update can be sent out*/
   else if (evnt->eventType.val == SOT_ET_UPDATE)
   {
      /* Check for Offer-Answer exchange */
#ifdef SO_EXT_OFFER_ANS
      ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_USER);
      if (ret != SOT_ERR_NOERR)
         RETVALUE(ret);
#endif /* SO_EXT_OFFER_ANS */
      
      cLeg->updatePend = FALSE;

#ifdef SO_SESSTIMER 
      /* so003.201 : Support for Session-Timer for UPDATE */
      /* Check for Session Timer */
      if (responseClass == SO_STACODE_TYPE_SUCCESS)
      {
         ret = soUasSessTmrPrc2xx(ssap->sys, cLeg, evnt);
         if (ret != SOT_ERR_NOERR)
            RETVALUE(ret);
      }
#endif /* SO_SESSTIMER */
   }
#endif /* SO_UPDATE */

#ifdef SO_INSTMSG
  else if (evnt->eventType.val == SOT_ET_MESSAGE)
  {
     ret = soUaChkIncMessageHdr(cLeg, evnt);
     /* so038.201:ng: Added error check condition */
     if (ret != SOT_ERR_NOERR)
        RETVALUE(ret);
  }
#endif /* SO_INSTMSG */

#ifdef SO_EVENT
  /* If message is Subscrice, Notify or Refer call
     respective processing functions */
  else if (evnt->eventType.val == SOT_ET_SUBSCRIBE)
     ret = soUaSubscRspReq(&node, cLeg, evnt, transCb);

  else if (evnt->eventType.val == SOT_ET_NOTIFY)
     ret = soUaNotifyRspReq(&node, cLeg->call->ssapCb, 
                            cLeg, evnt, transCb);
     /* for the case of transmitting the standlone notify. */
#ifdef SO_REFER
  else if (evnt->eventType.val == SOT_ET_REFER)
     ret = soUaReferRspReq(&node, cLeg, evnt, transCb);
#endif  

  if(ret != ROK)
  {
    if(node != NULLP)
    {
       /* soEvnt will be deleted at SOT */
       node->event = NULLP;
       soDlgDelCurSubscNode(node);
    }
    RETVALUE(RFAILED);
  }
#endif  /* SO_EVENT */

  /* Send Rsp to Dialog layer */
  ret = soDlgUaOutRsp(cLeg, evnt, transCb);
  
  if (ret == ROK)
  {

    /* Delete Call leg, if no txns are present */
    soDlgChkAndDelCLeg(cLeg);
  }
#ifdef SO_EVENT
  else
  {
     /* so035.201: Check if node is not NULLP and set node->event to NULLP */   
     if(node != NULLP)
     {
       /* soEvnt will be deleted at SOT */
       node->event = NULLP;
       soDlgDelCurSubscNode(node);
     }
  }
#endif /* SO_EVENT */   

  RETVALUE(ret);
} /* soUaCAMRsp */






/*
*
*       Fun:   soUaByeReq
*
*       Desc:  This function processes BYE request received from the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaByeReq
(
SoSSapCb *ssap,     /* SSAP cb */
SoEvnt *evnt,       /* Message From User */
UConnId spConnId,   /* Service Provider Conn Id */
UConnId suConnId    /* Service User Conn Id */
)
#else
PUBLIC S16 soUaByeReq(ssap, evnt, spConnId, suConnId)
SoSSapCb *ssap;     /* SSAP cb */
SoEvnt *evnt;        /* Message From User */
UConnId spConnId;   /* Service Provider Conn Id */
UConnId suConnId;   /* Service User Conn Id */
#endif
{
  SoCallCb      *callCb;     /* call cb */
  SoCLegCb      *cLeg;       /* Call Leg Cb */
  SoUserCtxt    userCtxt;   /* UserCtxt */
  S16           ret;         /* return Value       */

  TRC2(soUaByeReq);

  /*--- so014.201: Initialize local variable ---*/
  ret     = ROK;
  cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

  SODBGP_SO(SO_DBGMASK_UA,
            (soCb.init.prntBuf,
             "soUaByeReq: \n"
             "Outgoing Bye Req: spId : %d; suConnId : %ld"
             "Call Leg Id : %lx; Trans Id : %lx \n",
             ssap->sapId, suConnId, evnt->callLegId, evnt->transId));

  /* Locate the call & call leg for the message */
  soCoreLocateSuCallCtxt(ssap, evnt, suConnId, spConnId, &callCb,
                         &cLeg);
  if (callCb == NULLP)
      RETVALUE(SOT_ERR_CALL_NOTFOUND);
    
  if (cLeg == NULLP)
    RETVALUE(SOT_ERR_CLEG_NOTFOUND);

  /* Fill the user context that will be stored in the transaction layer */
  SO_FILL_USER_CTXT(userCtxt, FALSE, FALSE);

  /* so019.201: Change to check the Bye header */
  ret = soUaChkOutByeHdr(cLeg, evnt);
  if (ret != SOT_ERR_NOERR)
    RETVALUE(ret);

  /* Pass request to dialog layer for processing */
  ret = soDlgUaOutReq(cLeg, &userCtxt, evnt);
  if (ret == SOT_ERR_NOERR)
  {
    /* Stop the Expires Timer */
    soSchedTmr(cLeg, SO_TMR_EXPIRES, TMR_STOP, NOTUSED);
  }

#ifdef SO_SESSTIMER
  /* so011.201: Stop Session Timer */
  soStopSessTimer(cLeg);
#endif

  /* so029.201: invoke the new method soDlgCloseAllPendingTxn */
  /* so035.201: Fixed bye clearing - Removed soDlgCloseAllPendingTxn */
  /* so041.201: Send 487 for all UAS pending transactions: Added soDlgCloseAllPendingTxn */
  soDlgCloseAllPendingTxn(cLeg);

  RETVALUE(ret);
}





/*
*
*       Fun:   soUaLocalRel
*
*       Desc:  This function locally releases the call context as
*              requested by service user.
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaLocalRel
(
SoSSapCb *ssap,     /* SSAP cb */
SoEvnt *evnt,       /* Message From User */
UConnId spConnId,   /* Service Provider Conn Id */
UConnId suConnId    /* Service User Conn Id */
)
#else
PUBLIC S16 soUaLocalRel(ssap, evnt, spConnId, suConnId)
SoSSapCb *ssap;     /* SSAP cb */
SoEvnt *evnt;        /* Message From User */
UConnId spConnId;   /* Service Provider Conn Id */
UConnId suConnId;   /* Service User Conn Id */
#endif
{
  SoCallCb      *callCb;     /* call cb */
  SoCLegCb      *cLeg;       /* Call Leg Cb */

  TRC2(soUaLocalRel);

  SODBGP_SO(SO_DBGMASK_UA,
            (soCb.init.prntBuf,
             "soUaLocalRel: \n"
             "Local Call Release: spId : %d; suConnId : %ld"
             "Call Leg Id : %lx; Trans Id : %lx \n",
             ssap->sapId, suConnId, evnt->callLegId, evnt->transId));

  /* Locate the call & call leg for the message */
  soCoreLocateSuCallCtxt(ssap, evnt, suConnId, spConnId, &callCb,
                         &cLeg);
  if (callCb == NULLP)
      RETVALUE(SOT_ERR_CALL_NOTFOUND);
    
  if (cLeg == NULLP)
    RETVALUE(SOT_ERR_CLEG_NOTFOUND);

  /* Delete dialog first and if its last dialog in call, delete 
   * call too. */
  soDlgDeleteCleg(callCb, cLeg);

  soCoreChkAndDelCall(callCb);

  RETVALUE(SOT_ERR_NOERR);
}




/*
*
*       Fun:   soUaByeRsp
*
*       Desc:  This function processes the response to a BYE 
*              received from the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaByeRsp
(
SoSSapCb *ssap,     /* SSAP cb */
SoEvnt *evnt,       /* Message From User */
UConnId spConnId,   /* Service Provider Conn Id */
UConnId suConnId    /* Service User Conn Id */
)
#else
PUBLIC S16 soUaByeRsp(ssap, evnt, spConnId, suConnId)
SoSSapCb *ssap;     /* SSAP cb */
SoEvnt *evnt;        /* Message From User */
UConnId spConnId;   /* Service Provider Conn Id */
UConnId suConnId;   /* Service User Conn Id */
#endif
{
  SoCallCb   *callCb;     /* call cb */
  SoCLegCb   *cLeg;       /* Call Leg Cb */
  SoTransCb  *transCb;    /* Transaction Control Block */
  S16        ret;         /* Return Value */

  TRC2(soUaByeRsp);

  /*--- so014.201: Initialize local variable ---*/
  ret     = ROK;
  transCb = NULLP;

  SODBGP_SO(SO_DBGMASK_UA,
            (soCb.init.prntBuf,
             "soUaByeRsp: \n"
             "Outgoing Bye Rsp: spId : %d; suConnId : %ld"
             "Call Leg Id : %lx; Trans Id : %lx \n",
             ssap->sapId, suConnId, evnt->callLegId, evnt->transId));

  /* Locate the call & call leg for the message */
  soCoreLocateSuCallCtxt(ssap, evnt, suConnId, spConnId, &callCb,
                         &cLeg);
  if (callCb == NULLP)
      RETVALUE(SOT_ERR_CALL_NOTFOUND);
    
  if (cLeg == NULLP)
    RETVALUE(SOT_ERR_CLEG_NOTFOUND);

#ifdef SO_REL_1_2_INF
  /* Get tranaction Cb from cLeg List */
  transCb = soDlgLocateRspTran(cLeg, evnt);
  if (transCb == NULLP)
    RETVALUE(SOT_ERR_TRAN_NOTFOUND);
#endif

 
  ret = soDlgUaOutRsp(cLeg, evnt, transCb);
  if (ret != ROK)
    RETVALUE(ret);

#ifdef LSO_ACNT
  if (ret == SOT_ERR_NOERR)
  {
    soMiPrcAccounting(cLeg, LSO_ACNT_REL);
  }
#endif /* LSO_ACNT */

  /* so029.201 : Close all the remaining transactions except BYE transaction */
  /* so035.201: Fixed bye clearing - Replaced  soDlgCloseAllPendingTxn with soDlgDeleteAllTxn*/ 
  /* so038.201: Clear all other pending transactions gracefully 
                replaced soDlgDeleteAllTxn */
  soDlgCloseAllPendingTxn(cLeg);


  /* so033.201: For the case when a Re-Invite is responded with a Bye */
  /* so41.201: Removed code to delete UAC transaction in early state.
     ACK cannot be sent for 487, which is expected when Re-Invite is 
     responded with a Bye.  */

  /* Delete Call leg, if no txns are present */
  soDlgChkAndDelCLeg(cLeg);

  RETVALUE(ret);
}






/*
*
*       Fun:   soUaCIMReq
*
*       Desc:  This function processes a CIM Req  received from the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaCIMReq
(
SoSSapCb *ssap,     /* SSAP Cb   */
SoEvnt   *evnt,     /* Event CB  */
UConnId  spConnId,  /* Sp ConnId */
UConnId  suConnId   /* SuConnId  */
)
#else
PUBLIC S16 soUaCIMReq(ssap, evnt, spConnId, suConnId)
SoSSapCb *ssap;    /* SSAP Cb */
SoEvnt   *evnt;    /* Eent CB */
UConnId  spConnId; /* Sp ConnId */
UConnId  suConnId; /* SuConnId  */
#endif
{

  S16        ret;         /* Return Value */
  SoUserCtxt userCtxt;   /* UserCtxt */
  SoCallCb   *callCb;     /* Call Control Block */
  SoCLegCb   *cLeg;       /* Call Leg Cb        */

  TRC2(soUaCIMReq);

  cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

  ret = SOT_ERR_NOERR;
  callCb = NULLP;
  cLeg = NULLP;


  SODBGP_SO(SO_DBGMASK_UA,
            (soCb.init.prntBuf,
             "soUaCIMReq: \n"
             "Outgoing CIM Req: Event: %s,  spId : %d; suConnId : %ld"
             "Call Leg Id : %lx; Trans Id : %lx \n",
             soSOTEventDescrip[evnt->eventType.val - 1], 
             ssap->sapId, suConnId, evnt->callLegId, evnt->transId));


  switch (evnt->eventType.val)
  {
    case SOT_ET_REGISTER_LOC:
      ret = soUaLocalReg(ssap, evnt);
      break;
      
    case SOT_ET_REGISTER:
      ret = soUaRemoteReg(ssap, evnt, suConnId);
      break;
      
    case SOT_ET_NOTIFY:
    case SOT_ET_UNKNOWN:
      /* Create a Call context */
      /* so022.201: Pass suConnId to be saved in call leg */
      soCoreCreateCallCtxt(ssap, ssap->sys, evnt, suConnId, 
                           SO_USER, &callCb, &cLeg);
        
      if ((callCb == NULLP) || (cLeg == NULLP))
        RETVALUE(SOT_ERR_RSRC);
    
      /* Fill the user context that will be stored in the transaction layer */
      /*--- so014.201: Event structure need not be saved in dialog layer ---*/
      SO_FILL_USER_CTXT (userCtxt, FALSE, FALSE);

      /*- Send the request to dialog module -*/
      ret = soDlgUaOutReq(cLeg, &userCtxt, evnt);
      if (ret != SOT_ERR_NOERR)
      {
        soCoreDeleteCallCb(callCb);
      }
      break;
      /* so009.201 : To support INFO outside a call */
    case SOT_ET_INFO:
      /* Create a Call context */
      /* so022.201: Pass suConnId to be saved in call leg */
      soCoreCreateCallCtxt(ssap, ssap->sys, evnt, suConnId, 
                           SO_USER, &callCb, &cLeg);
        
      if ((callCb == NULLP) || (cLeg == NULLP))
        RETVALUE(SOT_ERR_RSRC);
    
      soUaChkInfoReqHdr(cLeg, evnt);

      /* Fill the user context that will be stored in the transaction layer */
      /*--- so014.201: Event structure need not be saved in dialog layer ---*/
      SO_FILL_USER_CTXT (userCtxt, FALSE, FALSE);

      /*- Send the request to dialog module -*/
      ret = soDlgUaOutReq(cLeg,&userCtxt, evnt);
      if (ret != SOT_ERR_NOERR)
      {
        soCoreDeleteCallCb(callCb);
      }

      break;

    default:
      ret = SOT_ERR_INV_REQUEST;
      break;
  }
  RETVALUE(ret);

}




/*
*
*       Fun:   soUaCIMRsp
*
*       Desc:  This function processes a CIM Rsp  received from the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaCIMRsp
(
SoSSapCb *ssap,   /* SSAP Cb */
SoEvnt   *evnt,   /* Event CB */
UConnId  spConnId,  /* Sp ConnId */
UConnId  suConnId   /* SuConnId  */
)
#else
PUBLIC S16 soUaCIMRsp(ssap, evnt,spConnId, suConnId)
SoSSapCb *ssap;   /* SSAP Cb */
SoEvnt   *evnt;   /* Eent CB */
UConnId  spConnId; /* Sp ConnId */
UConnId  suConnId; /* SuConnId  */
#endif
{

  S16        ret;           /* Return Value */
  SoCallCb   *callCb;       /* Call Control Block */
  SoCLegCb   *cLeg;         /* Call Leg Cb        */
  SoTransCb  *transCb;      /* Transaction Cb */
  U16        responseCode;  /* Response Class */

  TRC2(soUaCIMRsp);

  /*--- so014.201: Initialize local variable ---*/
  ret     = ROK;
  transCb = NULLP;
  responseCode = evnt->t.response.statusLine.statusCode.val;

  SODBGP_SO(SO_DBGMASK_UA,
            (soCb.init.prntBuf,
             "soUaCIMRsp: \n"
             "Outgoing CIM Req: Event: %s,  Response Type : %d,"
             "spId : %d; suConnId : %ld"
             "Call Leg Id : %lx; Trans Id : %lx \n",
             soSOTEventDescrip[evnt->eventType.val - 1], responseCode,
             ssap->sapId, suConnId, evnt->callLegId, evnt->transId));

  switch (evnt->eventType.val)
  {
    case SOT_ET_NOTIFY:
    case SOT_ET_UNKNOWN:
       /* so009.201 : To support INFO outside a call */
    case SOT_ET_INFO:
      /* so011.201: Support to handle REGISTER message at UAC. The 
         feature has been added under the flag SO_XX_UA_PRC_REGISTER. */
#ifdef SO_XX_UA_PRC_REGISTER
    case SOT_ET_REGISTER:
#endif /* SO_XX_UA_PRC_REGISTER */
      /* Try to Locate Call */
      soCoreLocateSuCallCtxt(ssap, evnt, suConnId, spConnId, 
                             &callCb, &cLeg);

      if ((callCb == NULLP) || (cLeg == NULLP))
        RETVALUE(SOT_ERR_TRAN_NOTFOUND);

#ifdef SO_REL_1_2_INF
      /* Get tranaction Cb from cLeg List */
      transCb = soDlgLocateRspTran(cLeg, evnt);
#endif


      /* Send response to dialog layer */
      ret = soDlgUaOutRsp(cLeg, evnt, transCb);
      if (ret != SOT_ERR_NOERR)
        RETVALUE(ret);

      break;
    default:
      ret = SOT_ERR_INV_REQUEST;
      break;
  }
  RETVALUE(ret);

}


/*
*
*       Fun:   soUaCancelReq
*
*       Desc:  This function handles an outgoing CANCEL
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaCancelReq
(
SoSSapCb *ssap,     /* SSAP cb */
SoEvnt *evnt,        /* Message From User */
UConnId spConnId,   /* Service Provider Conn Id */
UConnId suConnId    /* Service User Conn Id */
)
#else
PUBLIC S16 soUaCancelReq(ssap, evnt, spConnId, suConnId)
SoSSapCb *ssap;     /* SSAP cb */
SoEvnt *evnt;        /* Message From User */
UConnId spConnId;   /* Service Provider Conn Id */
UConnId suConnId;   /* Service User Conn Id */
#endif
{
  SoCallCb   *callCb;     /* call cb */
  SoCLegCb   *cLeg;       /* Call Leg Cb */
  SoUserCtxt userCtxt;   /* UserCtxt */
  SoTransCb   *transCb;   /* Transaction Cb */
  S16        ret;         /* Return Value */

  TRC2(soUaCancelReq);

  /*--- so014.201: Initialize local variable ---*/
  ret     = ROK;
  cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

  SODBGP_SO(SO_DBGMASK_UA,
            (soCb.init.prntBuf,
             "soUaCancelReq: \n"
             "Outgoing Cancel Req: Event: %s,  spId : %d; suConnId : %ld"
             "Call Leg Id : %lx; Trans Id : %lx \n",
             soSOTEventDescrip[evnt->eventType.val - 1], 
             ssap->sapId, suConnId, evnt->callLegId, evnt->transId));

   /* Locate the call & call leg for the message */
  soCoreLocateSuCallCtxt(ssap, evnt, suConnId, spConnId, &callCb,
                         &cLeg);
  if (callCb == NULLP)
    RETVALUE(SOT_ERR_CALL_NOTFOUND);

  if (cLeg == NULLP)
    RETVALUE(SOT_ERR_CLEG_NOTFOUND);

  /*
   * so014.201: If the call leg has not reached early state yet,
   *   hold onto the cancel until it does.
   */
  if (cLeg->clegState <= SO_CLEG_STATE_INITIAL)
  {
    cLeg->pendingCancel = evnt;
    RETVALUE (ROK);
  }

  /* See if the transaction to be cancelled exists */
  transCb = soDlgLocateCancelTrans(cLeg, evnt, SO_USER);
  if (transCb == NULLP)
    RETVALUE(SOT_ERR_TRAN_LOCATE);

  /* 
   * so014.201: Temprory Store The Context Of CANCELED transaction.
   *     It Will Be Used By  Dialog Layer To Find Next Hop Address.
   *     Please note that we are overloading "userPtr" in User 
   *     Context to save transaction context. Dialog layer will o-
   *     verwrite this values ones it has used it.
   */
   userCtxt.userPtr = (PTR) transCb;

  /* Stop the Expires Timer */
  soSchedTmr(cLeg, SO_TMR_EXPIRES, TMR_STOP, NOTUSED);

  /* Check for outgoing cancel specific headers */
  ret = soUaChkOutCancelHdr(cLeg, evnt, transCb);
  if (ret != ROK)
    RETVALUE(SOT_ERR_ADD_HDR_FAILED);

  cLeg->cancelTmrCb.cSeqVal = transCb->transCSeq;
  cLeg->cancelTmrCb.method = transCb->transMethod;

  /* If the user (client) is sending a cancel when the final
     200ok for an INVITE is received send an ACK ans then a BYE */
  if (cLeg->clegState == SO_CLEG_STATE_ACK_PEND)
  {
    if (cLeg->role == SO_CLIENT)
    {
      ret = soUaIntAckAndBye(cLeg, evnt);
      if (ret != ROK)
        ret = SOT_ERR_ADD_HDR_FAILED;
    }
    else
      (Void) soCmFreeEvent(evnt);
  }

  /* Else send CANCEL out */
  /* so014.201: Cancel For RE-INVITE Request */
  if ((cLeg->clegState == SO_CLEG_STATE_PROCEEDING) || 
      (cLeg->clegState == SO_CLEG_STATE_EARLY)      ||
      (cLeg->clegState == SO_CLEG_STATE_MODIFY))
  {       
    
    /* Fill the user context that will be stored in 
       the transaction layer */
    SO_FILL_USER_CTXT(userCtxt, FALSE, FALSE);

    ret = soDlgUaOutReq(cLeg, &userCtxt, evnt);
    if (ret == SOT_ERR_NOERR)
    {     
      soSchedTmr(cLeg, SO_TMR_CANCEL, TMR_START, soCb.reCfg.tmrReTxCfg.t1 *64);
    }
  }
  else
  {
    /*-- so029.201: Handle CANCEL Request in Unexpected State --*/

     SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf, 
       "\n soUaCancelReq: GOT Cancel In Unexpeceted STATE (%ld, %lx, %lx, %d)\n",
       cLeg->call->spConnId, cLeg->userConnId, cLeg->legId, cLeg->clegState));

     RETVALUE (SOT_ERR_CLEGSTATE_INVALID);
  }


  RETVALUE(ret);
}


/***************************************************************/
/*         Dialog Module Interface Functions                   */
/***************************************************************/

/*
*
*       Fun:   soUaInviteInd
*
*       Desc:  This function handles an INVITE from the Remote End.
*              It returns the statuscode of the response to be sent
*              as the return value.
*              
*              SOT_RSP_NONE : If function completed successfully
*              SOT_RSP_ERROR: If an error was encountered but no
*                             rsp needs to be sent to the remote.
*              SOT_RSP_XXX  : If a specific error type XXX needs 
*                             to be returned to the user.
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaInviteInd
(
SoCLegCb *cLeg,   /* Cleg Cb */
SoEvnt   *evnt    /* Event  */
)
#else
PUBLIC S16 soUaInviteInd(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
  S16  ret;   /* Retrun Value */

  TRC2(soUaInviteInd);

  /*--- so014.201: Initialize local variable ---*/
  ret     = ROK;

  SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soUaInviteInd: Invite Received"));

  /* Check if message is destined for a known user */
  ret = soUaChkLocalUserReg(cLeg, evnt, SO_REMOTE);
  if (ret != SOT_RSP_NONE)
    RETVALUE(ret);

  /* Validate INVITE specific headers */
  ret = soUaChkIncInvHdr(cLeg, evnt);
  if (ret != SOT_RSP_NONE)
    RETVALUE(SOT_RSP_400_BAD_REQUEST);

#ifdef SO_REPLACES
  ret = soUaPrcInvReplacesHdr(cLeg,evnt);
  if (ret != SOT_RSP_NONE)
    RETVALUE(ret);
#endif /* SO_REPLACES */

  /* Check for Session Timer */
#ifdef SO_SESSTIMER 
  ret = soUasSessTmrPrcReq(cLeg->call->ent, cLeg, evnt);
  if (ret != SOT_ERR_NOERR)
    RETVALUE(ret);
#endif /* SO_SESSTIMER */

  /*so033.201 :- Handle Offer-Answer in Incoming INVITE*/
  /* INVITE may contain an offer, so check for offer exchange */
#ifdef SO_EXT_OFFER_ANS
  ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_REMOTE);
  if (ret != SOT_ERR_NOERR)
  {
     /* Send 500  */
     RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
  }
#endif
  

  /* Send a 100 trying, if configured to do so */
  /* so031.201: Added NULLP for the transCb argument */
  if (cLeg->call->ent->reCfg.snd100Always == TRUE) 
  {
    ret = soDlgSendResponse(cLeg, NULLP, evnt, SOT_RSP_100_TRYING, 
                            SO_EXTRSP_NONE);
    if (ret != ROK)
      RETVALUE(SOT_RSP_ERROR);
  }


#ifdef LSO_ACNT
   /* Fillin mediaType for Accounting */
   soUtlPrcContentType(cLeg, evnt);
#endif

  /* If call leg is in Active state , the message is a Re-INVITE */
  if (cLeg->clegState == SO_CLEG_STATE_MODIFY)
  {
    ret = soDlgUpdRemoteTrgtURI(cLeg, evnt);
    if (ret != ROK)
      RETVALUE(SOT_RSP_400_BAD_REQUEST);

    /* so016.201: Update Req Uri in case of session refresh */
    ret = soDlgUpdModReqUri(cLeg, evnt, SO_REMOTE);
    if (ret != ROK) 
      RETVALUE(RFAILED);

    /* so009.201 : Added new parameter userConnId to function call */
    ret = soUiModInd(cLeg->userConnId, cLeg->call, evnt);

  }
  else
  {
    /* Message is the first INVITE */
    ret = soUiConInd(cLeg->call, evnt);

  }

  if (ret != ROK)
    RETVALUE(SOT_RSP_500_SRV_INT_ERROR);

  RETVALUE(SOT_RSP_NONE);
} /* soUaInviteInd */



/*
*
*       Fun:   soUaAckInd
*
*       Desc:  This function handles an ACK from the Remote End
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaAckInd
(
SoCLegCb *cLeg,   /* Cleg Cb */
SoEvnt   *evnt    /* Event  */
)
#else
PUBLIC S16 soUaAckInd(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
  S16  ret;   /* Retrun Value */

  TRC2(soUaAckInd);

  /*--- so014.201: Initialize local variable ---*/
  ret     = ROK;

  /* Stop 2xx Retx Timer */
  soSchedTmr(cLeg, SO_TMR_2XX_RETX, TMR_STOP, NOTUSED);

  /* Stop 2xx Expiry Timer */
  soSchedTmr(cLeg, SO_TMR_2XX_EXPIRY, TMR_STOP, NOTUSED);

#ifdef LSO_ACNT
   soMiPrcAccounting(cLeg, LSO_ACNT_EST);
#endif

  /* so009.102: Encoded 2xx message buffer is not needed */
   if (cLeg->rspCb.rspMsg)
   {
     SPutMsg (cLeg->rspCb.rspMsg);
     cLeg->rspCb.rspMsg = NULLP;
   }

   /* Send Ack to the user */
   /* so009.201 : Added new parameter userConnId to function call */
   ret = soUiAckInd(cLeg->userConnId, cLeg->call, evnt);

  if (ret != ROK)
    RETVALUE(SOT_RSP_ERROR);
  else
    RETVALUE(SOT_RSP_NONE);
} /*  soUaAckInd */






/*
*
*       Fun:   soUaCAMInd
*
*       Desc:  This function handles a CAM message from the Remote End
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaCAMInd
(
SoCLegCb *cLeg,   /* Cleg Cb */
SoEvnt   *evnt    /* Event  */
)
#else
PUBLIC S16 soUaCAMInd(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
  S16  ret;   /* Retrun Value */

  TRC2(soUaCAMInd);

  /*--- so014.201: Initialize local variable ---*/
  ret     = ROK;

  /* so009.201 : Added new parameter userConnId to function call */
  ret = soUiCAMInd(cLeg->userConnId, cLeg->call, evnt);
  if (ret != ROK)
    RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
  else
    RETVALUE(SOT_RSP_NONE);
}



#ifdef SO_UPDATE
/*
*
*       Fun:   soUaUpdateInd
*
*       Desc:  This function handles an Update from the Remote End
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaUpdateInd
(
SoCLegCb *cLeg,   /* Cleg Cb */
SoEvnt   *evnt    /* Event  */
)
#else
PUBLIC S16 soUaUpdateInd(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
  S16  ret;        /* Retrun Value */
  U8   direction;  /* Direction */

  TRC2(soUaUpdateInd);

  /*--- so014.201: Initialize local variable ---*/
  ret       = ROK;
  direction = SO_REMOTE;

  if (cLeg->updatePend == TRUE)
    RETVALUE(SOT_RSP_500_SRV_INT_ERROR);

  /* Update may contain an offer, so check for offer exchange */
#ifdef SO_EXT_OFFER_ANS
  ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_REMOTE);
  if (ret != SOT_ERR_NOERR)
  {
     if (direction == SO_USER)
     {
        /* Send 491 with retyr after header */
       RETVALUE(SOT_RSP_491_RETRY_AFTER);
     }
     if (direction == SO_REMOTE)
     {
        /* Send 500  */
        RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
     }
  }
#endif

  /*--- mark that update is pending ---*/
  cLeg->updatePend = TRUE;

#ifdef SO_SESSTIMER 
  /* so003.201 : Support for Session-Timer for UPDATE */
  /* Check for Session Timer */
  ret = soUasSessTmrPrcReq(cLeg->call->ent, cLeg, evnt);
  if (ret != SOT_ERR_NOERR)
    RETVALUE(ret);
#endif /* SO_SESSTIMER */

  /* Update  Remote Target URI */
  ret = soDlgUpdRemoteTrgtURI(cLeg, evnt);

  /* so016.201: Update Req Uri in case of session refresh */
  ret = soDlgUpdModReqUri(cLeg, evnt, SO_REMOTE);
  if (ret != ROK) 
    RETVALUE(RFAILED);

  /* so009.201 : Added new parameter userConnId to function call */
  if (ret == SOT_ERR_NOERR)
    ret = soUiCAMInd(cLeg->userConnId, cLeg->call, evnt);
  
  if (ret != ROK)
    RETVALUE(SOT_RSP_500_SRV_INT_ERROR);


  RETVALUE(SOT_RSP_NONE);
}
#endif /* SO_UPDATE */




/*
*
*       Fun:   soUaByeInd
*
*       Desc:  This function handles an Bye from the Remote End
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaByeInd
(
SoCLegCb *cLeg,   /* Cleg Cb */
SoEvnt   *evnt    /* Event  */
)
#else
PUBLIC S16 soUaByeInd(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
  S16  ret;   /* Retrun Value */

  TRC2(soUaByeInd);

  /*--- so014.201: Initialize local variable ---*/
  ret       = ROK;

  /* Stop the Expires Timer */
  soSchedTmr(cLeg, SO_TMR_EXPIRES, TMR_STOP, NOTUSED);

  /* Stop 2xx Retx Timer */
  soSchedTmr(cLeg, SO_TMR_2XX_RETX, TMR_STOP, NOTUSED);

  /* Stop 2xx Expiry Timer */
  soSchedTmr(cLeg, SO_TMR_2XX_EXPIRY, TMR_STOP, NOTUSED);

#ifdef SO_SESSTIMER
  /* so011.201: Stop Session Timer */
  soStopSessTimer(cLeg);
#endif

  /* so009.201 : Added new parameter userConnId to function call */
  ret = soUiRelInd(cLeg->userConnId, cLeg->call, evnt);
  if (ret != ROK)
    RETVALUE(SOT_RSP_500_SRV_INT_ERROR);

  RETVALUE(SOT_RSP_NONE);

} /* soUaByeInd */




/*
*
*       Fun:   soUaInfoInd
*
*       Desc:  This function handles an ACK from the Remote End
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaInfoInd
(
SoCLegCb *cLeg,   /* Cleg Cb */
SoEvnt   *evnt    /* Event  */
)
#else
PUBLIC S16 soUaInfoInd(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
  S16  ret;   /* Retrun Value */

  TRC2(soUaInfoInd);

  /*--- so014.201: Initialize local variable ---*/
  ret       = ROK;

  /* so009.201 : To support INFO outside a call */
  if (cLeg->clegState == SO_CLEG_STATE_INITIAL)
  {
     ret = soUiCIMInd(cLeg->call->ssapCb, cLeg->userConnId,
                      cLeg->call->spConnId, evnt);
  }
  else
  {
     /* so009.201 : Added new parameter suConnId to function call */
     ret = soUiCnStInd(cLeg->userConnId, cLeg->call, evnt);
  }

  if (ret != ROK)
    RETVALUE(SOT_RSP_500_SRV_INT_ERROR);

  RETVALUE(SOT_RSP_NONE);
}



#ifdef SO_INSTMSG
/*
*
*       Fun:   soUaMessageInd
*
*       Desc:  This function handles an Instant Message from the Remote End
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaMessageInd
(
SoCLegCb *cLeg,   /* Cleg Cb */
SoEvnt   *evnt    /* Event  */
)
#else
PUBLIC S16 soUaMessageInd(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
  S16  ret;   /* Retrun Value */

  TRC2(soUaMessageInd);

  /*--- so014.201: Initialize local variable ---*/
  ret       = ROK;

  /* so009.201 : Added new parameter userConnId to function call */
  ret = soUiCAMInd(cLeg->userConnId, cLeg->call, evnt);

  if (ret != ROK)
    RETVALUE(SOT_RSP_500_SRV_INT_ERROR);

  RETVALUE(SOT_RSP_NONE);
}
#endif /* SO_INSTMSG */

/* so011.201: Support to handle REGISTER message at UAC. The 
   feature has been added under the flag SO_XX_UA_PRC_REGISTER. */
#ifdef SO_XX_UA_PRC_REGISTER
/*
*
*       Fun:   soUaRegisterInd
*
*       Desc:  This function handles register messages received at the UA
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaRegisterInd
(
SoCLegCb *cLeg,   /* Cleg Cb */
SoEvnt   *evnt    /* Event  */
)
#else
PUBLIC S16 soUaRegisterInd(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
  S16  ret;   /* Retrun Value */

  TRC2(soUaRegisterInd);

  /*--- so014.201: Initialize local variable ---*/
  ret       = ROK;

  ret = soUiCIMInd(cLeg->call->ssapCb, cLeg->userConnId,
                      cLeg->call->spConnId, evnt);

  if (ret != ROK)
    RETVALUE(SOT_RSP_500_SRV_INT_ERROR);

  RETVALUE(SOT_RSP_NONE);
}
#endif /* SO_XX_UA_PRC_REGISTER */

/*
*
*       Fun:   soUaCancelInd
*
*       Desc:  This function handles a CANCEL from the Remote End
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaCancelInd
(
SoCLegCb *cLeg,   /* Cleg Cb */
SoEvnt   *evnt    /* Event  */
)
#else
PUBLIC S16 soUaCancelInd(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
  S16        ret;   /* Retrun Value */
  SoTransCb  *transCb; /* Transaction cb */

  TRC2(soUaCancelInd);

  ret = soUaChkIncCancelHdr(cLeg, evnt);
  if (ret != ROK) 
  {
    (Void) soCmFreeEvent(evnt);
    RETVALUE(SOT_RSP_400_BAD_REQUEST);
  }

  /* See if the transaction to be cancelled exists */
  transCb = soDlgLocateCancelTrans(cLeg, evnt, SO_REMOTE);
  if (transCb == NULLP)
    RETVALUE(SOT_RSP_481_CLEG_TRAN_NOT_EXIST);

  /* If an INVITE is being cancelled, stop all the
     relevant timers */
  if (transCb->transMethod == SO_METHODSTD_INVITE)
  {
    /* Stop the Expires Timer */
    soSchedTmr(cLeg, SO_TMR_EXPIRES, TMR_STOP, NOTUSED);

    /* Stop 2xx Retx Timer */
    soSchedTmr(cLeg, SO_TMR_2XX_RETX, TMR_STOP, NOTUSED);

    /* Stop 2xx Expiry Timer */
    soSchedTmr(cLeg, SO_TMR_2XX_EXPIRY, TMR_STOP, NOTUSED);

#ifdef SO_RFC_3262
    /* Stop 1xx Expiry Timer for Reliable Response */
    soUaStopRelRspTmr(cLeg);
#endif

    /* If there is a pending cancel release it */
    if (cLeg->pendingCancel != NULLP)
    {
      (Void) soCmFreeEvent(cLeg->pendingCancel);
     /*---- so015.201: Set Pointer as NULLP also ----*/
      cLeg->pendingCancel = NULLP;
    }
  }

  /* Send a 2xx Response for the message */
  /* so031.201: Added NULLP for the transCb argument */
  ret = soDlgSendResponse(cLeg, NULLP, evnt, SOT_RSP_200_OK, SO_EXTRSP_NONE);
  if (ret != ROK)
    RETVALUE(SOT_RSP_ERROR);

  if ((transCb->transMethod == SO_METHODSTD_INVITE)
      || (transCb->transMethod == SO_METHODSTD_INFO))
  {
     /* so009.201 : Added new parameter userConnId to function call */
     /* so013.201 : Before sending out the CancelInd change the transId 
        in the event to reflect the original transaction being cancelled 
        and not the canceled transaction */
     evnt->transId = transCb->transId;

    /*--- so041.201: Any API should be provided to application, only if ---*
     *    dialog state in not already terminated.                       ---*/
     if (cLeg->clegState != SO_CLEG_STATE_TERMINATED)
     {
         ret = soUiCancelInd(cLeg->userConnId, cLeg->call, evnt);
        
         if (ret != ROK)
           RETVALUE(SOT_RSP_ERROR);
     }
  }

  RETVALUE(SOT_RSP_NONE);

} /* soUaCancelInd */





/*
*
*       Fun:   soUaCometInd
*
*       Desc:  This function handles a COMET msg from the Remote End
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaCometInd
(
SoCLegCb *cLeg,   /* Cleg Cb */
SoEvnt   *evnt    /* Event  */
)
#else
PUBLIC S16 soUaCometInd(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
  S16  ret;   /* Retrun Value */

  TRC2(soUaCometInd);

  /* so009.201 : Added new parameter suConnId to function call */
  ret = soUiCnStInd(cLeg->userConnId, cLeg->call, evnt);

  if (ret != ROK)
    RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
  else
    RETVALUE(SOT_RSP_NONE);

}


/*
*
*       Fun:   soUaUnknownInd
*
*       Desc:  This function handles an UNknown message
*               from the Remote End
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaUnknownInd
(
SoCLegCb *cLeg,   /* Cleg Cb */
SoEvnt   *evnt    /* Event  */
)
#else
PUBLIC S16 soUaUnknownInd(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
  S16  ret;   /* Retrun Value */

  TRC2(soUaUnknownInd);

  /* so009.201 : Used user conn id instead of suConnId in callCb */
  ret = soUiCIMInd(cLeg->call->ssapCb, cLeg->userConnId, 
                   cLeg->call->spConnId, evnt);
  if (ret != ROK)
    RETVALUE(SOT_RSP_500_SRV_INT_ERROR);

  RETVALUE(SOT_RSP_NONE);

}





/*
*
*       Fun:   soUaOptionsInd
*
*       Desc:  This function handles an Options message
*               from the Remote End
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaOptionsInd
(
SoCLegCb *cLeg,   /* Cleg Cb */
SoEvnt   *evnt    /* Event  */
)
#else
PUBLIC S16 soUaOptionsInd(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
  S16  ret;   /* Retrun Value */

  TRC2(soUaOptionsInd);

  /* so009.201 : Added new parameter userConnId to function call */
  ret = soUiCAMInd(cLeg->userConnId, cLeg->call, evnt);
 
  if (ret != ROK)
    RETVALUE(SOT_RSP_500_SRV_INT_ERROR);

  RETVALUE(SOT_RSP_NONE);
}






#ifdef SO_RFC_3262
/*
*
*       Fun:   soUaPrackInd
*
*       Desc:  This function handles a PRACK msg from the Remote End
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaPrackInd
(
SoCLegCb *cLeg,   /* Cleg Cb */
SoEvnt   *evnt    /* Event  */
)
#else
PUBLIC S16 soUaPrackInd(cLeg, evnt)
SoCLegCb *cLeg;   /* Cleg Cb */
SoEvnt   *evnt;   /* Event  */
#endif
{
  S16          ret;           /* Retrun Value */
  SoRAck       *rAck;         /* RAck structure in PRACK message  */
  U32          cSeqVal;       /* CSeq Value */
  SoProvRspCb  *provRspCb;    /* Provisional Response Cb */
  SoProvRspCb  *tmpProvRspCb; /* Provisional Response Cb */
  CmLList      *curNode;      /* Current node in list         */
  SoEvnt       *tmpEvnt;      /* Stored Evenet */

  TRC2(soUaPrackInd);

  /* Find RAck in message */
  /* Find rAck header in message */
  ret = soCmFindHdrChoice(evnt, (U8 **) &rAck, SO_HEADER_GEN_RACK);
  if (ret != ROK)
     /* RAck header not present */
     RETVALUE(SOT_RSP_400_BAD_REQUEST);

   /* Check if rSeq number is present in rAck */
   if (rAck->responseNum.pres == NOTPRSNT)
     RETVALUE(SOT_RSP_400_BAD_REQUEST);

   /* Check if cSeq number is present in rAck */
   if (rAck->cSeqNum.pres == NOTPRSNT)
     RETVALUE(SOT_RSP_400_BAD_REQUEST);


   /* Set cSeqVal */
   cSeqVal = rAck->cSeqNum.val;

   provRspCb = soUaLocateProvRspCb(cLeg, evnt, &rAck->responseNum.val);

   if (provRspCb == NULLP)
     RETVALUE(SOT_RSP_481_CLEG_TRAN_NOT_EXIST);

 /* so032.201:- Passing the PRACK to User*/
#ifndef SO_RFC_3262_USER   
   /* Send a 2xx Response for the message */
   /* so031.201: Added NULLP for the transCb argument */
   ret = soDlgSendResponse(cLeg, NULLP, evnt, SOT_RSP_200_OK, SO_EXTRSP_NONE);

   if (ret != ROK)
     RETVALUE(SOT_RSP_ERROR);
#else /* SO_RFC_3262_USER*/   
   /*so033.201:- Check Offer-Answer in PRACK if not generated internally*/
   /* Flag SO_RFC_3262_USER is defined, then check for Offer -Answer*/
#ifdef SO_EXT_OFFER_ANS
      ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_REMOTE);
      if (ret != SOT_ERR_NOERR)
          RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
#endif /* SO_EXT_OFFER_ANS */
   
#endif /* SO_RFC_3262_USER*/   

   /* Stop the 1xx Retx Timer */
   soSchedTmr(provRspCb, SO_TMR_1XX_RETX, TMR_STOP, NOTUSED);

   /* Stop the Expiry Timer for the provisional response also.*/
   soSchedTmr(provRspCb, SO_TMR_1XX_EXPIRY, TMR_STOP, NOTUSED);

   /* so010.201: Encoded 1xx message buffer is not needed */
   if (provRspCb->rspCb.rspMsg)
   {
     SPutMsg (provRspCb->rspCb.rspMsg);
     provRspCb->rspCb.rspMsg = NULLP;
   }

   if (cLeg->relProvRspInfo.firstPrackPend == TRUE)
     cLeg->relProvRspInfo.firstPrackPend = FALSE;

   /* Free the provisional Response Cb  and remove it from the hash list */
   cmHashListDelete(&cLeg->relProvRspInfo.provRspCbLst, (PTR) provRspCb);
   SOFREE(provRspCb, sizeof(SoProvRspCb));

   /* If there are any pending 1xx to be sent send them out */
   ret = ROK;
   if (cmLListLen(&cLeg->relProvRspInfo.pendProvRspLst) != 0)
   {
     
     curNode = cmLListFirst(&cLeg->relProvRspInfo.pendProvRspLst);
     while (curNode != NULLP)
     {
       tmpProvRspCb    = (SoProvRspCb *)curNode->node;
       curNode  = curNode->next;
       
       /* Remove prov rsp from list */
       cmLListDelFrm(&cLeg->relProvRspInfo.pendProvRspLst, 
                     &tmpProvRspCb->pendLstNode);

       /* Send out the response to the dialog layer */
       ret = soDlgUaOutRsp(cLeg, tmpProvRspCb->evnt, NULLP);
       
       if (ret != ROK)
       {
         break;
       }

       /* If message was sent out ok store 1xx info */
       if (cLeg->sentRsp != NULLP)
       {
         ret = soUaPrcSent1xxInfo(cLeg, evnt, tmpProvRspCb);
         if (ret != SOT_ERR_NOERR)
         {
           SOFREE(tmpProvRspCb, sizeof(SoProvRspCb));
           break;
         }
         
         /* Insert ProvRspCb into appropriate hash list */
         ret = cmHashListInsert(&cLeg->relProvRspInfo.provRspCbLst, 
                                (PTR)tmpProvRspCb,
                                (U8 *)&tmpProvRspCb->rSeq,
                                sizeof(U32));
       }

     }

     if (ret != ROK)
     {
       if (tmpProvRspCb != NULLP)
       {
         tmpEvnt = tmpProvRspCb->evnt;
         /* so009.201 : Used user conn id instead of suConnId in callCb */
         /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
         soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
                    cLeg->call->spConnId, 
                    tmpEvnt, tmpEvnt->callLegId, tmpEvnt->eventType.val, 
                    ret, FALSE, FALSE);
#else
         soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
                    cLeg->call->spConnId, 
                    tmpEvnt, tmpEvnt->callLegId, tmpEvnt->eventType.val, 
                    ret, FALSE);
#endif
         tmpProvRspCb->evnt = NULLP;
         SOFREE(tmpProvRspCb, sizeof(SoProvRspCb));
       }
       
       /* Clear the remaining pending responses */
       curNode = cmLListFirst(&cLeg->relProvRspInfo.pendProvRspLst);
       while (curNode != NULLP)
       {
         tmpProvRspCb    = (SoProvRspCb *)curNode->node;
         curNode  = curNode->next;
         tmpEvnt = tmpProvRspCb->evnt;

         /* so009.201 : Used user conn id instead of suConnId in callCb */
         /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
         soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
                    cLeg->call->spConnId, 
                    tmpEvnt, tmpEvnt->callLegId, tmpEvnt->eventType.val, 
                    ret, FALSE, FALSE);
#else
         soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
                    cLeg->call->spConnId, 
                    tmpEvnt, tmpEvnt->callLegId, tmpEvnt->eventType.val, 
                    ret, FALSE);
#endif
         tmpProvRspCb->evnt = NULLP;
         SOFREE(tmpProvRspCb, sizeof(SoProvRspCb));

       }
 
     }
   }
   else
   {
     if (CM_HASH_NMBENT(&cLeg->relProvRspInfo.provRspCbLst) == 0)
     {
       /* If there are no more pending 1xx, check if there is a pending
          2xx and send it out */
       if (cLeg->relProvRspInfo.pend2xxEvnt != NULLP)
       {
          /* so009.201 : Used user conn id instead of suConnId in callCb */
          /* so026.201 : Cannot send 200 Ok problem*/
         ret = soUaConRsp(cLeg->call->ssapCb, 
                          cLeg->relProvRspInfo.pend2xxEvnt,
                          cLeg->call->spConnId,
                          cLeg->userConnId);
         if (ret != ROK)
         {
           (Void) soCmFreeEvent(cLeg->relProvRspInfo.pend2xxEvnt);
         }
         cLeg->relProvRspInfo.pend2xxEvnt = NULLP;
       }
     }
   }
   /* so032.201:- Passing the PRACK to User*/
#ifdef SO_RFC_3262_USER
   soUiCnStInd(cLeg->userConnId, cLeg->call, evnt);
#else /* SO_RFC_3262_USER*/
   /* so010.201 : Added code to release event here  instaead */
   (Void) soCmFreeEvent(evnt);
#endif /* !SO_RFC_3262_USER*/

   RETVALUE(SOT_RSP_NONE);
}
#endif



/*
*
*       Fun:   soUaInviteCfm
*
*       Desc:  This function handles an incoming INVITE response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaInviteCfm
(
SoCLegCb   *cLeg,     /* Cll Leg Cb */ 
SoEvnt     *evnt      /* Event Cb */
)
#else
PUBLIC S16 soUaInviteCfm(cLeg, evnt)
SoCLegCb   *cLeg;     /* Call Leg Cb */
SoEvnt     *evnt;     /* Event Cb */
#endif
{
  U16      responseCode;  /* Response Code  */
  U16      responseClass; /* Response Class */
  Bool     passToUser;    /* Pass the response to the user/not */  
  S16      ret;           /* Return Value */
  SoCallCb *callCb;       /* Call Cb */
  U8       clegState;     /* Call Leg State */


  TRC2(soUaInviteCfm);

  /*--- so014.201: Initialize local variable ---*/
  ret       = ROK;

  responseCode = evnt->t.response.statusLine.statusCode.val;
  responseClass = responseCode/100;

  passToUser = TRUE;

  if ((responseClass >= SO_STACODE_TYPE_SUCCESS) && 
      (cLeg->recurseCb.recursState != SO_RECURSION_ON))
  {
     /* If it is a final response, check if there are other
     multiple response call legs present.If yes,
     delete all of them and issue ind to user */
    soUaDelMultRspCLegs(cLeg);

    /* If the response is not a 3xx or a 422 delete the stored
       invite as it is no longer required. 
       For 3xx it may be required for further recursion.
       For 422 it may be required to send a invite with
       modified minse values */

    if ((responseClass != SO_STACODE_TYPE_REDIR) 
#ifdef SO_SESSTIMER 
        && (responseCode !=  SOT_RSP_422_SESSTIMER_TOO_SMALL)
#endif
        )
    {
      /* Free the stored invite */
      if (cLeg->sentInvite != NULLP)
        (Void) soCmFreeEvent(cLeg->sentInvite);
      cLeg->sentInvite = NULLP;
    }
  }


  switch (responseClass)
  {
    case SO_STACODE_TYPE_INFORM:
      ret = soUaInc1xxRsp(cLeg, evnt,&passToUser, responseCode);
      if (ret != ROK)
          RETVALUE(RFAILED);

      /* so009.201 : Added new parameter userConnId to function call */
      if (passToUser == TRUE)
        ret = soUiCnStInd(cLeg->userConnId, cLeg->call, evnt);
      else    
        /* so012.201: Event no longer required, free the same */
        (Void) soCmFreeEvent(evnt);

      break;

    case SO_STACODE_TYPE_SUCCESS:
      ret = soUaInc2xxRsp(cLeg, evnt, &passToUser);
      if (ret != ROK)
        RETVALUE(RFAILED);

#ifdef SO_EXT_OFFER_ANS
      ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_REMOTE);
      if (ret != SOT_ERR_NOERR)
        RETVALUE(RFAILED);
#endif /* SO_EXT_OFFER_ANS */

#ifdef SO_SESSTIMER 
      ret = soUacSessTmrPrc2xx(cLeg->call->ent, cLeg, evnt);
      if (ret != SOT_ERR_NOERR)
        break;
#endif /* SO_SESSTIMER */

      if (passToUser == TRUE)
      {
       /* so026.201: After passing final response to application,  *
        *            we can reset the recursion state              */
        if (cLeg->recurseCb.recursState == SO_RECURSION_ON)
            cLeg->recurseCb.recursState = 0;

        /* so001.201 : Check for cLeg active state */
        /* so009.201 : Added suConnId to be passed in all upward bound primitives */
        if ((cLeg->clegState == SO_CLEG_STATE_MODIFY_ACK) ||
            (cLeg->clegState == SO_CLEG_STATE_ACTIVE))
          ret = soUiModCfm(cLeg->userConnId, cLeg->call, evnt);
        else
          ret = soUiConCfm(cLeg->userConnId, cLeg->call, evnt);
      }
      break;

    case SO_STACODE_TYPE_REDIR:
     /*-- so009.201: Recursion Is Only Allowed For Initial Invite --*/
      if (cLeg->clegState == SO_CLEG_STATE_MODIFY_ACK)
      {
         /* so009.201 : Added new parameter userConnId to function call */
         ret = soUiModCfm(cLeg->userConnId, cLeg->call, evnt);
      }
      else
      {
         ret = soUaInc3xxRsp(cLeg, evnt, &passToUser);
         
         if (passToUser == TRUE)
         {
          /* so026.201: After passing final response to application,  *
           *            we can reset the recursion state              */
           if (cLeg->recurseCb.recursState == SO_RECURSION_ON)
               cLeg->recurseCb.recursState = 0;

           if (cLeg->sentInvite != NULLP)
             (Void) soCmFreeEvent(cLeg->sentInvite);
         
           cLeg->sentInvite = NULLP;
           /* so009.201 : Added suConnId to be passed in all upward bound primitives */
           ret = soUiConCfm(cLeg->userConnId, cLeg->call, evnt);
         }

        /*-- so029.201: If not passed to user, free response event --*/
         else
         {
            (Void) soCmFreeEvent(evnt);
         }
      }
      break;


    case SO_STACODE_TYPE_CLERR:
    case SO_STACODE_TYPE_SRVERR:
    case SO_STACODE_TYPE_GLFAIL:
      /* If call Leg is under recursion proceed with the
         recursion procedure */
      if (cLeg->recurseCb.recursState == SO_RECURSION_ON)
      {
        /* Contibue to Recurse */
        ret = soUaRecurse(cLeg, cLeg->sentInvite);
        if (ret == ROK)
        {
          /*- so029.201: If not passed to user, free response event -*/
          (Void) soCmFreeEvent(evnt);
          break;
        }
      }

      if (cLeg->pendingCancel != NULLP)
      {
        (Void) soCmFreeEvent (cLeg->pendingCancel);
        /*---- so015.201: Set Pointer as NULLP also ----*/
        cLeg->pendingCancel = NULLP;
      }

      /* so013.201: Stop the Expires Timer */
      soSchedTmr(cLeg, SO_TMR_EXPIRES, TMR_STOP, NOTUSED);

      /* Stop the Cancel Timer */
      soSchedTmr(cLeg, SO_TMR_CANCEL, TMR_STOP, NOTUSED);


      /* so009.201: Fix to disable session negotiation on 422 rsp */
#if (defined(SO_SESSTIMER) && !defined(SO_DIS_SESS_NEG))
     /*-- so009.201: 422 Response Is Only Expeted For Initial Invite --*/
      if ((responseCode    ==  SOT_RSP_422_SESSTIMER_TOO_SMALL) &&
          (cLeg->clegState != SO_CLEG_STATE_MODIFY_ACK))
      {
        ret = soUacSessTmrPrc422Rsp(cLeg->call->ent, cLeg, evnt);
        RETVALUE(ret);
      }
#endif
      callCb = cLeg->call;
      clegState = cLeg->clegState;

      /* so026.201: After passing final response to application,  *
       *            we can reset the recursion state              */
       if (cLeg->recurseCb.recursState == SO_RECURSION_ON)
           cLeg->recurseCb.recursState = 0;

      /* so009.201 : Added suConnId to be passed in all upward bound primitives */
      /* so029.201 : Check for cLeg active state */       
      if ((clegState == SO_CLEG_STATE_MODIFY_ACK) ||
            (clegState == SO_CLEG_STATE_ACTIVE))
         ret = soUiModCfm(cLeg->userConnId, callCb, evnt);
      else
        ret = soUiConCfm(cLeg->userConnId, callCb, evnt);

      break;
  }


  RETVALUE(ret);

} /* soUaInviteCfm */



/*
*
*       Fun:   soUaCancelCfm
*
*       Desc:  This function handles an incoming CANCEL response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaCancelCfm
(
SoCLegCb   *cLeg,     /* Call Leg Cb */ 
SoEvnt     *evnt      /* Event Cb */
)
#else
PUBLIC S16 soUaCancelCfm(cLeg, evnt)
SoCLegCb   *cLeg;     /* Call Leg Cb */
SoEvnt     *evnt;     /* Event Cb */
#endif
{

  /* The response to a CANCEL is not passed to the user,
     drop the event here. */

  soCmFreeEvent(evnt);
  RETVALUE(ROK);
} /* soUaCancelCfm */



/*
*
*       Fun:   soUaByeCfm
*
*       Desc:  This function handles an incoming BYE response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaByeCfm
(
SoCLegCb   *cLeg,     /* Call Leg Cb */ 
SoEvnt     *evnt      /* Event Cb */
)
#else
PUBLIC S16 soUaByeCfm(cLeg, evnt)
SoCLegCb   *cLeg;     /* Call Leg Cb */
SoEvnt     *evnt;     /* Event Cb */
#endif
{
  S16      ret;           /* Return Value */
  Bool     intBye;        /* internalley generated Bye */
  SoCallCb *callCb;       /* Call cb */
  /* so009.201 : Added new parameter suConnId */
  UConnId  suConnId;

  TRC2(soUaByeCfm);

  ret = ROK;
  intBye = FALSE;

  callCb = cLeg->call;
  intBye = cLeg->intBye;
  /* so009.201 : Added userConnId instead of suConnId */
  suConnId = cLeg->userConnId;

#ifdef LSO_ACNT
  soMiPrcAccounting(cLeg, LSO_ACNT_REL);
#endif /* LSO_ACNT */

  /* so029.201: Close all the remaining transactions except BYE transaction */
  /* so035.201: Fixed bye clearing - Replaced  soDlgCloseAllPendingTxn with soDlgDeleteAllTxn*/
  /* so041.201: Moved soDlgDeleteAllTxn to soDlgCloseAllPendingTxn in soUaByeReq */

  /* If Bye was sent internally dont send the 200OK to the user
     else pass it to the user */
  if (intBye == TRUE)
    soCmFreeEvent(evnt);
  else
     /* so009.201 : Added new parameter suConnId to function call */
    ret = soUiRelCfm(suConnId, callCb, evnt);
  
  RETVALUE(ret);

} /* soUaByeCfm */




/*
*
*       Fun:   soUaInfoCfm
*
*       Desc:  This function handles an incoming INFO response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaInfoCfm
(
SoCLegCb   *cLeg,     /* Call Leg Cb */ 
SoEvnt     *evnt      /* Event Cb */
)
#else
PUBLIC S16 soUaInfoCfm(cLeg, evnt)
SoCLegCb   *cLeg;     /* Call Leg Cb */
SoEvnt     *evnt;     /* Event Cb */
#endif
{
  S16      ret;           /* Return Value */

  /*--- so014.201: Initialize local variable ---*/
  ret       = ROK;

#ifdef SO_1XX_PASS
  /*--- so013.201: Pass 1xx Response To User ---*/
  if (evnt->t.response.statusLine.statusCode.val/100 == SO_STACODE_TYPE_INFORM)
  {
    ret = soUiCnStInd (cLeg->userConnId, cLeg->call, evnt);
    RETVALUE(ret);
  }
#endif

  /* so009.201 : To support INFO outside a call */
  if (cLeg->clegState == SO_CLEG_STATE_INITIAL)
  {
     ret = soUiCIMCfm(cLeg->call->ssapCb, cLeg->userConnId,
                      cLeg->call->spConnId, evnt);
  }
  else
  {
     /* so009.201 : Added new parameter userConnId to function call */
     ret = soUiCnStInd(cLeg->userConnId, cLeg->call, evnt);
  }
  RETVALUE(ret);
}



/*
*
*       Fun:   soUaMessageCfm
*
*       Desc:  This function handles an incoming MESSAGE response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaMessageCfm
(
SoCLegCb   *cLeg,     /* Call Leg Cb */ 
SoEvnt     *evnt      /* Event Cb */
)
#else
PUBLIC S16 soUaMessageCfm(cLeg, evnt)
SoCLegCb   *cLeg;     /* Call Leg Cb */
SoEvnt     *evnt;     /* Event Cb */
#endif
{
  S16      ret;           /* Return Value */

  /*--- so014.201: Initialize local variable ---*/
  ret       = ROK;

#ifdef SO_1XX_PASS
  /*--- so013.201: Pass 1xx Response To User ---*/
  if (evnt->t.response.statusLine.statusCode.val/100 == SO_STACODE_TYPE_INFORM)
  {
    ret = soUiCnStInd (cLeg->userConnId, cLeg->call, evnt);
    RETVALUE(ret);
  }
#endif

  /* so009.201 : Added new parameter userConnId to function call */
  ret = soUiCAMCfm(cLeg->userConnId, cLeg->call, evnt);
  RETVALUE(ret);
} /* soUaMessageCfm */



/*
*
*       Fun:   soUaRegisterCfm
*
*       Desc:  This function handles an incoming REGISTER response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaRegisterCfm
(
SoCLegCb   *cLeg,      /* Call Leg Cb */ 
SoEvnt     *evnt,      /* Event Cb */
SoUserCtxt *userCtxt   /* User Context passed to the txn layer */
)
#else
PUBLIC S16 soUaRegisterCfm(cLeg, evnt, userCtxt)
SoCLegCb   *cLeg;     /* Call Leg Cb */
SoEvnt     *evnt;     /* Event Cb */
SoUserCtxt *userCtxt; /* User Context passed to the txn layer */
#endif
{
  SoEntCb  *ent;          /* Entity Cb */
  U16      responseCode;  /* Response Code  */
  U16      responseClass; /* Response Class */
  S16      ret;           /* Return Value */
  SoSSapCb *ssap;         /* SSAP */
  UConnId  suConnId;      /* su ConnId */
  UConnId  spConnId;      /* Service Provider ConnId */
#ifdef SO_PATH_ROUTE
  SoRoute  *serviceRoute; 
#endif
   SoCSeq      *cSeq;      /* new CSeq header */

  TRC2(soUaRegCfm);

  ent = cLeg->call->ent;
  ret = ROK;

  responseCode = evnt->t.response.statusLine.statusCode.val;
  responseClass = responseCode/100;

  /* Drop the 1xx response to a Register */
  if (responseClass == SO_STACODE_TYPE_INFORM)
  {
#ifdef SO_1XX_PASS
   /*--- so013.201: Pass 1xx Response To User ---*/
    if (userCtxt->intMsg != TRUE)
      ret = soUiCnStInd (cLeg->userConnId, cLeg->call, evnt);
    else
#endif
      soCmFreeEvent(evnt);

    RETVALUE(ret);
  }

  /* If 3rd part reg/ mcast reg/ if no timers are to be run in
     the layer */
  if ((cLeg->regInfo.thirdPartyReg == TRUE) || 
      ((ent->s.ua.reCfg.alertUsrOnExp != TRUE) && 
       (ent->s.ua.reCfg.refreshOnExp != TRUE)))
  {
     /* so009.201 : Used user conn id instead of suConnId in callCb */
    ret = soUiCIMCfm(cLeg->call->ssapCb, cLeg->userConnId,
                     cLeg->call->spConnId, evnt);
    RETVALUE(ret);
  }
  
 
  /* Keep a local copy of suconnid, ssap etc. because the call & 
     call leg may get deleted */
  /* so009.201 : Used user conn id instead of suConnId in callCb */
  suConnId = cLeg->userConnId;
  spConnId = cLeg->call->spConnId;
  ssap     = cLeg->call->ssapCb;

  /* Extract Cseq from Response */
  /* Copy CSeq from old evnt into new one */
  if (soCmFindHdrChoice(evnt, (U8 **) &cSeq, SO_HEADER_GEN_CSEQ)
      != ROK)
    RETVALUE(RFAILED);

  /* If response is an error, clear the contacts */
  if (responseClass > SO_STACODE_TYPE_SUCCESS)
  {
    soUaPrcRegErrRsp(cLeg, cSeq->cSeqVal.val);
  }
  else
  {
    ret = soUaPrcRegRsp(cLeg, evnt, cSeq->cSeqVal.val);
  }
  
  if (ret != ROK)
    RETVALUE(ret);

#ifdef SO_PATH_ROUTE
  if(ent->s.ua.reCfg.refreshOnExp == TRUE)
  {
     /* for automatic refresh, we need to check if service-route header
      * present in message. If so, we need to pass this 200 to user
      * because user need to update the service route value.*/
     ret = soCmFindHdrChoice (evnt, (U8 **) &serviceRoute,
                            SO_HEADER_GEN_SERVICEROUTE);

     /* so009.201 : Used user conn id instead of suConnId in callCb */
     if (ret == ROK)
     {
       ret = soUiCIMCfm(cLeg->call->ssapCb, cLeg->userConnId,
                     cLeg->call->spConnId, evnt);   
     }
     /* so024.201: Free the Memory, when we neither sending CIMCfm
      * nor sending the Error Indication*/
     else
     {
        /* Only Local function fails, so we cannot sending negative
         * response. Make the return value OK*/
        ret = ROK;
 
      }

  }
#endif /* SO_PATH_ROUTE */ 
  
  if (userCtxt->intMsg != TRUE)
    ret = soUiCIMCfm(ssap, cLeg->userConnId,
                     cLeg->call->spConnId, evnt);
  else
  {
    if (responseClass > SO_STACODE_TYPE_SUCCESS)
    {
       /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(ssap, suConnId, spConnId, 
                 evnt, 0, SOT_ET_REGISTER, SOT_ERR_REGISTER_REQ_FAILED, TRUE, TRUE);
#else
      soUiErrInd(ssap, suConnId, spConnId, 
                 evnt, 0, SOT_ET_REGISTER, SOT_ERR_REGISTER_REQ_FAILED, TRUE);
#endif
    }
    /* so024.201: Free the Memory, when we neither sending CIMCfm
     * nor sending the Error Indication*/
    else
    {
       /* Delete the event */
       if (evnt != NULLP)
       {     
          soCmFreeEvent(evnt);
       }   
    }
     
   }

  RETVALUE(ret);

}


/*
*
*       Fun:   soUaOptionsCfm
*
*       Desc:  This function handles an incoming Options response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/

#ifdef ANSI
PUBLIC S16 soUaOptionsCfm
(
SoCLegCb   *cLeg,     /* Call Leg Cb */ 
SoEvnt     *evnt      /* Event Cb */
)
#else
PUBLIC S16 soUaOptionsCfm(cLeg, evnt)
SoCLegCb   *cLeg;     /* Call Leg Cb */
SoEvnt     *evnt;     /* Event Cb */
#endif
{
  S16      ret;           /* Return Value */
  SoCallCb *callCb;       /* Call cb */

  TRC2(soUaOptionsCfm);

  /*--- so014.201: Initialize local variable ---*/
  ret       = ROK;

  callCb = cLeg->call;

#ifdef SO_1XX_PASS
  /*--- so013.201: Pass 1xx Response To User ---*/
  if (evnt->t.response.statusLine.statusCode.val/100 == SO_STACODE_TYPE_INFORM)
  {
    ret = soUiCnStInd (cLeg->userConnId, cLeg->call, evnt);
    RETVALUE(ret);
  }
#endif

  /* so009.201 : Added new parameter userConnId to function call */
  ret = soUiCAMCfm(cLeg->userConnId, cLeg->call, evnt);

  RETVALUE(ret);

} /* SoUaOptionsCfm */





/*
*
*       Fun:   soUaUnknownCfm
*
*       Desc:  This function handles an incoming Unknown response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaUnknownCfm
(
SoCLegCb   *cLeg,     /* Call Leg Cb */ 
SoEvnt     *evnt      /* Event Cb */
)
#else
PUBLIC S16 soUaUnknownCfm(cLeg, evnt)
SoCLegCb   *cLeg;     /* Call Leg Cb */
SoEvnt     *evnt;     /* Event Cb */
#endif
{
  S16      ret;       /* Return Value */

  TRC2(soUaUnknownCfm);

  /*--- so014.201: Initialize local variable ---*/
  ret       = ROK;

#ifdef SO_1XX_PASS
  /*--- so013.201: Pass 1xx Response To User ---*/
  if (evnt->t.response.statusLine.statusCode.val/100 == SO_STACODE_TYPE_INFORM)
  {
    ret = soUiCnStInd (cLeg->userConnId, cLeg->call, evnt);
    RETVALUE(ret);
  }
#endif

  /* so009.201 : Used user conn id instead of suConnId in callCb */
  ret = soUiCIMCfm(cLeg->call->ssapCb, cLeg->userConnId,
                     cLeg->call->spConnId, evnt);

  RETVALUE(ret);

}



/*
*
*       Fun:   soUaCometCfm
*
*       Desc:  This function handles an incoming COMET response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaCometCfm
(
SoCLegCb   *cLeg,     /* Cll Leg Cb */ 
SoEvnt     *evnt      /* Event Cb */
)
#else
PUBLIC S16 soUaCometCfm(cLeg, evnt)
SoCLegCb   *cLeg;     /* Call Leg Cb */
SoEvnt     *evnt;     /* Event Cb */
#endif
{
  S16      ret;       /*Return Value */

  TRC2(soUaCometCfm);
  /* so009.201 : Added new parameter userConnId to function call */
  ret = soUiCnStInd(cLeg->userConnId, cLeg->call, evnt);
  RETVALUE(ret);
}




#ifdef SO_UPDATE
/*
*
*       Fun:   soUaUpdateCfm
*
*       Desc:  This function handles an incoming UPDATE response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaUpdateCfm
(
SoCLegCb   *cLeg,     /* Call Leg Cb */ 
SoEvnt     *evnt      /* Event Cb */
)
#else
PUBLIC S16 soUaUpdateCfm(cLeg, evnt)
SoCLegCb   *cLeg;     /* Call Leg Cb */
SoEvnt     *evnt;     /* Event Cb */
#endif
{
  S16      ret;           /* Return Value */
  SoCallCb *callCb;       /* Call cb */
  U16      responseClass; /* Response Class */

  responseClass = evnt->t.response.statusLine.statusCode.val/100;

  TRC2(soUaUpdateCfm);

  /*--- so014.201: Initialize local variable ---*/
  ret       = ROK;

#ifdef SO_1XX_PASS
  /*--- so013.201: Pass 1xx Response To User ---*/
  if (responseClass == SO_STACODE_TYPE_INFORM)
  {
    ret = soUiCnStInd (cLeg->userConnId, cLeg->call, evnt);
    RETVALUE(ret);
  }
#endif

  callCb = cLeg->call;

  /* Check for offer Answer exchange */
#ifdef SO_EXT_OFFER_ANS
  if (responseClass >= SO_STACODE_TYPE_REDIR)
  {
     /* For 3xx-6xx response offer-answer is already taken care in Dlg,
      so don't do it here again.*/
  }
  else
  {
     ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_REMOTE);
     if (ret != SOT_ERR_NOERR)
     {
        RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
     }
  }
#endif /* SO_EXT_OFFER_ANS */
  

  /* Update  Remote Target URI */
  ret = soDlgUpdRemoteTrgtURI(cLeg, evnt);

  /* so013.201: Update Req Uri in case of session refresh */
  ret = soDlgUpdModReqUri(cLeg, evnt, SO_REMOTE);
  if (ret != ROK) 
    RETVALUE(RFAILED);

#ifdef SO_SESSTIMER 
   /* so003.201 : Support for Session-Timer for UPDATE */
   /* If response is a 2xx */
   if ((responseClass == SO_STACODE_TYPE_SUCCESS) &&
       ((ret = soUacSessTmrPrc2xx(cLeg->call->ent, cLeg, evnt)) != SOT_ERR_NOERR))
      RETVALUE(ret);
#endif /* SO_SESSTIMER */

   /* so009.201 : Added new parameter userConnId to function call */
  ret = soUiCAMCfm(cLeg->userConnId, cLeg->call, evnt);

  RETVALUE(ret);
}
#endif /* SO_UPDATE */



#ifdef SO_RFC_3262
/*
*
*       Fun:   soUaPrackCfm
*
*       Desc:  This function handles an incoming PRACK response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaPrackCfm
(
SoCLegCb   *cLeg,     /* Call Leg Cb */ 
SoEvnt     *evnt      /* Event Cb */
)
#else
PUBLIC S16 soUaPrackCfm(cLeg, evnt)
SoCLegCb   *cLeg;     /* Call Leg Cb */
SoEvnt     *evnt;     /* Event Cb */
#endif
{
#ifdef SO_RFC_3262_USER
#ifdef SO_EXT_OFFER_ANS
  S16        ret;         /* Return Value */
#endif
#endif
  TRC2(soUaPrackCfm);

  SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soUaPrackCfm: PRACK confirm received \n"));

#ifndef SO_RFC_3262_USER
  (Void) soCmFreeEvent(evnt);
#else /* SO_RFC_3262_USER*/
   /*so033.201:- Check Offer-Answer in PRACK if not generated internally*/
  /* Check for offer Answer exchange */
#ifdef SO_EXT_OFFER_ANS
  ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_REMOTE);
  if (ret != SOT_ERR_NOERR)
  {
     RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
  }
#endif /* SO_EXT_OFFER_ANS */
  
     soUiCnStInd (cLeg->userConnId, cLeg->call, evnt);
#endif /* !SO_RFC_3262_USER*/  

  RETVALUE(ROK);
}

/***************************************************************/
/*                 UA Core Support Functions                   */
/***************************************************************/

/*
*
*       Fun:   soUaLocateProvRspCb
*
*       Desc:  This function locates a reliable provisional
*              response cb 
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE SoProvRspCb *soUaLocateProvRspCb
(
SoCLegCb  *cLeg,     /* Call Leg Cb */
SoEvnt    *evnt,     /* Event cb    */
U32       *rSeqVal    /* RSeq value */
)
#else
PRIVATE SoProvRspCb  *soUaLocateProvRspCb(cLeg, evnt, rSeqVal)
SoCLegCb  *cLeg;     /* Call Leg Cb */
SoEvnt    *evnt;     /* Event cb    */
U32       *rSeqVal;  /* RSeq value */
#endif
{

  TknU32      *rSeq;      /* RSeq header field to create      */
  S16         ret;        /* return Value */
  SoProvRspCb *provRspCb; /* provisional Response Cb */

  TRC3(soUaLocateProvRspCb);

  if (*rSeqVal == 0)
  {
    /* Find rSeq header in message */
    ret = soCmFindHdrChoice(evnt, (U8 **) &rSeq,
                            SO_HEADER_GEN_RSEQ);

    if (ret != ROK)
      RETVALUE(NULLP);

    *rSeqVal = rSeq->val;
  }

  /* Find prov rsp cb from the list stored in the call leg */
  ret = cmHashListFind(&cLeg->relProvRspInfo.provRspCbLst, (U8 *)rSeqVal,
                 sizeof(U32), (U16) 0, (PTR *) &provRspCb);

  if (ret != ROK)
    RETVALUE(NULLP);

  RETVALUE(provRspCb);

} /* soUaLocateProvRspCb */






/*
*
*       Fun:   soUaChkRelProvRspHdr
*
*       Desc:  This function validates the headers specific to 
*              a reliable provisional response 
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaChkRelProvRspHdr
(
SoCLegCb  *cLeg,     /* Call Leg Cb */
SoEvnt    *evnt,     /* Event cb    */
Bool      relRsp     /* Reliable Response / not */
)
#else
PRIVATE S16 soUaChkRelProvRspHdr(cLeg, evnt, relRsp)
SoCLegCb  *cLeg;     /* Call Leg Cb */
SoEvnt    *evnt;     /* Event cb    */
Bool      relRsp;    /* Reliable Response / not */
#endif
{
  TknU32      *rSeq;      /* RSeq header field to create      */
  S16         ret;        /* Return Value */
  U32         rSeqVal;    /* RSeq Val */
  Bool        selfAdded;  /* so035.201: For adding contact header */

  TRC3(soUaChkRelProvRspHdr);
  
  rSeqVal   = 0;
  selfAdded = FALSE;

  /* Find rSeq header in message */
  ret = soCmFindHdrChoice(evnt, (U8 **) &rSeq,
                          SO_HEADER_GEN_RSEQ);

  /* If message is not a reliable response, it must not 
     contain a RSeq header. */
  if (ret == ROK)
  {
    if (relRsp == FALSE)
    {
      RETVALUE(SOT_ERR_REL_PROVRSP_NOTALLWD);
    }
  }
  else if (relRsp == TRUE)
  {
    /* Allocate a Rseq value */
     if (cLeg->relProvRspInfo.provRspSent != TRUE)
     {
       cLeg->relProvRspInfo.currRseq= 0xABCD;
       rSeqVal = cLeg->relProvRspInfo.currRseq;
       /* so006.201: Increment currRseq counter */
       cLeg->relProvRspInfo.currRseq++;
     }
     else
     {
       rSeqVal = cLeg->relProvRspInfo.currRseq;
       cLeg->relProvRspInfo.currRseq++;
     }
     /* Add the Rseq header */
     ret = soUtlAddRSeqHdr(evnt, rSeqVal);
     if (ret != ROK)
       RETVALUE(SOT_ERR_RSEQ_FAIL);
  }

  /* Check if message contains the 100rel Ta in the Require 
     header */
  ret = soUtlChkOptionTag(evnt, SO_HEADER_GEN_REQUIRE,
                          SO_OPTIONTAG_100REL);
  if (ret == ROK)
  {
    /* If message is not reliable, it shouldnot contain
       the 100rel tag in the 'Require header */
    if (relRsp == FALSE)
      RETVALUE(SOT_ERR_REL_PROVRSP_NOTALLWD);
  }
  else if (relRsp == TRUE)
  {
    ret = soUtlAddRequireHdr(evnt, SO_OPTIONTAG_100REL);
    if (ret != ROK)
      RETVALUE(SOT_ERR_REQUIRE_FAIL);

    /* so035.201: Moved Addition of Contact Header to outside of this check */
    /* so006.201: Add CONTACT header for 18x response */
  }
   /* so035.201: selfAdded flag to add or replace contact header */
  /* so035.201: Add CONTACT header for 18x response */
  if (relRsp == TRUE)
  {
    ret = soUtlAddContactHdr(cLeg, evnt, LSO_TPTPROT_NULL, &selfAdded);
    if (ret != ROK) 
      RETVALUE(SOT_ERR_ADD_HDR_FAILED);
  }

  RETVALUE(SOT_ERR_NOERR);

} /* soUaChkRelProvRspHdr */





/*
*
*       Fun:   soUaPrcRelProvRsp
*
*       Desc:  This function adds the required headers for a
*              reliable provisioal response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaPrcRelProvRsp
(
SoCLegCb  *cLeg,     /* Call Leg Cb */
SoEvnt    *evnt      /* Event cb    */
)
#else
PRIVATE S16 soUaPrcRelProvRsp(cLeg, evnt)
SoCLegCb  *cLeg;     /* Call Leg Cb */
SoEvnt    *evnt;     /* Event cb    */
#endif
{
  S16         ret;        /* Return Value */
  SoProvRspCb *provRspCb; /* provisional Response Cb */
  U32         rSeqVal;    /* RSeq value */

  TRC3(soUaPrcRelProvRsp);

  /*--- so014.201: Initialize local variable ---*/
  ret     = ROK;
  rSeqVal = 0;

  /* Check for offer Answer exchange */
#ifdef SO_EXT_OFFER_ANS
  ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_USER);
  
  if (ret != SOT_ERR_NOERR)
    RETVALUE(ret);
#endif /* SO_EXT_OFFER_ANS */


  provRspCb = soUaLocateProvRspCb(cLeg, evnt, &rSeqVal);

  if (provRspCb != NULLP)
    RETVALUE(SOT_ERR_RSEQ_FAIL);
 
  SOALLOC(&provRspCb, sizeof(SoProvRspCb));
  if (provRspCb == NULLP)
    RETVALUE(SOT_ERR_RSRC);

  /* Initialize Provisional Response Cb parameters */
  provRspCb->rSeq = rSeqVal;
  provRspCb->cLeg = cLeg;
  provRspCb->rspCb.rspMsg = NULLP;
  provRspCb->evnt = NULLP;
  provRspCb->transId = evnt->transId;
  /* Initialize all provisional response Timers */
  soCmInitTimer(&provRspCb->rspCb.soRspRetxTmr);
  soCmInitTimer(&provRspCb->rspCb.soRspExpTmr);

  /* If a response for the first reliable response
     has not been received, donot send a new one. Instead,
     insert the provRspCb into a pending list */
  if ((cLeg->relProvRspInfo.provRspSent == TRUE) &&
      (cLeg->relProvRspInfo.firstPrackPend == TRUE))
  {
    provRspCb->evnt = evnt;
    provRspCb->pendLstNode.node = (PTR) provRspCb;
    cmLListAdd2Tail(&cLeg->relProvRspInfo.pendProvRspLst, 
                    &provRspCb->pendLstNode);
    RETVALUE(SOT_ERR_NOERR);
  }
  else
  {

    /* Insert ProvRspCb into appropriate hash list */
    ret = cmHashListInsert(&cLeg->relProvRspInfo.provRspCbLst, (PTR)provRspCb,
                          (U8 *)&provRspCb->rSeq,
                          sizeof(U32));

    if (ret != ROK)
    {  
      SOFREE(provRspCb, sizeof(SoProvRspCb));
      RETVALUE(SOT_ERR_RSRC);
    }
       

    /* Send out the response to the dialog layer */
    ret = soDlgUaOutRsp(cLeg, evnt, NULLP);
    if (ret != ROK)
    {
      SOFREE(provRspCb, sizeof(SoProvRspCb));
      RETVALUE(ret);
    }

    /* If the response has been sent out correctly and the encoding process 
       is  complete, start the necessary timers and update the required fields
       in the provRspCb */
    if (cLeg->sentRsp != NULLP)
    {
      ret = soUaPrcSent1xxInfo(cLeg, evnt, provRspCb);
      if (ret != SOT_ERR_NOERR)
      {
        SOFREE(provRspCb, sizeof(SoProvRspCb));
        RETVALUE(ret);
      }

    }
  }
  
  RETVALUE(SOT_ERR_NOERR);
}

/*
*
*       Fun:   soUaPrcSent1xxInfo
*
*       Desc:  This function starts timer ans stores any
*              required information for an outgoing reliable 1xx, after
*              it has been successfully sent out.
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaPrcSent1xxInfo
(
SoCLegCb     *cLeg,      /* Call Leg Cb */
SoEvnt       *evnt,      /* Event cb */
SoProvRspCb   *provRspCb  /* Provisional rsp Cb */
)
#else
PUBLIC S16 soUaPrcSent1xxInfo(cLeg, evnt, provRspCb)
SoCLegCb     *cLeg;      /* Call Leg Cb */
SoEvnt       *evnt;      /* Event cb */
SoProvRspCb  *provRspCb; /* Provisional rsp Cb */
#endif
{
  U32         rSeqVal;    /* RSeq Val */

  TRC3(soUaPrcSent1xxInfo);

  rSeqVal = 0;

  if (provRspCb == NULLP)
  {
    provRspCb = soUaLocateProvRspCb(cLeg, evnt, &rSeqVal);
    
    if (provRspCb == NULLP)
      RETVALUE(SOT_ERR_RSEQ_FAIL);
  }

  /* Start a timer for the 1xx response */
  provRspCb->rspCb.tmrVal = soCb.reCfg.tmrReTxCfg.t1;
  soSchedTmr(provRspCb, SO_TMR_1XX_RETX, TMR_START, provRspCb->rspCb.tmrVal);

   /* Start the Expiry Timer for the provisional response also.
      If the provisional response has been retransmitted for 64 * T1
      ned to clear transactio  */
   soSchedTmr(provRspCb, SO_TMR_1XX_EXPIRY, TMR_START, 
              soCb.reCfg.tmrReTxCfg.t1 *64);

  /* Store the buffer */
  provRspCb->rspCb.rspMsg = cLeg->sentRsp;
  cLeg->sentRsp = NULLP;

  if (cLeg->relProvRspInfo.provRspSent != TRUE)
  {
    cLeg->relProvRspInfo.provRspSent = TRUE;
    cLeg->relProvRspInfo.firstPrackPend = TRUE;
  }

  RETVALUE(SOT_ERR_NOERR);
} /* soUaPrcSent1xxInfo */



/* so032.201:- Passing the PRACK to User*/
#ifndef SO_RFC_3262_USER
/*
*
*       Fun:   soUaGeneratePrack
*
*       Desc:  This function generates a PRACK
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaGeneratePrack
(
SoCLegCb    *cLeg,    /* Call Leg Cb */
SoEvnt      *evnt,     /* Event Cb */
TknU32       *rSeq      /* Rseq value */
)
#else
PRIVATE S16 soUaGeneratePrack(cLeg, evnt, rSeq)
SoCLegCb    *cLeg;    /* Call Leg Cb */
SoEvnt      *evnt;     /* Event Cb */
TknU32      *rSeq;     /* Rseq value */
#endif
{

   SoCSeq      *cSeq;      /* new CSeq header in PRACK */
   SoEvnt      *prackEvnt; /* PRACK event */
   SoUserCtxt  userCtxt;  /* User Context Cb    */
   S16         ret;        /* return Value       */

   TRC3(soUaGeneratePrack);
   
   cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

   ret = soUaRequestBuild(cLeg, SOT_ET_PRACK, &prackEvnt);
   
   if (ret != ROK)
     RETVALUE(RFAILED);
   
   /* Copy CSeq from old evnt into new one */
   if (soCmFindHdrChoice(evnt, (U8 **) &cSeq, SO_HEADER_GEN_CSEQ)
       != ROK)
     RETVALUE(RFAILED);

   
   /* Add a RACK */
   ret = soUtlAddRAckHdr(prackEvnt, cSeq, rSeq->val);
   if (ret != ROK)
     RETVALUE(ret);

  /* Fill the user context that will be stored in 
     the transaction layer */
   
   SO_FILL_USER_CTXT(userCtxt, FALSE, FALSE);
   
   ret = soDlgUaOutReq(cLeg, &userCtxt, prackEvnt);
   
   RETVALUE(ret);
} 
#endif /*!SO_RFC_3262_USER*/
#endif /* SO_RFC_3262 */




/*
*
*       Fun:   soUaOutProvRsp
*
*       Desc:  This function handles an 1xx Response from the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaOutProvRsp
(
SoCLegCb  *cLeg,         /* Call Leg Cb */
SoEvnt    *evnt,         /* Event cb    */
Bool      *reliableRsp   /* True if Reliable Prov Rsp */
)
#else
PRIVATE S16 soUaOutProvRsp(cLeg, evnt, reliableRsp)
SoCLegCb  *cLeg;         /* Call Leg Cb */
SoEvnt    *evnt;         /* Event cb    */
Bool      *reliableRsp;  /* True if Reliable Prov Rsp */
#endif
{
  SoEntCb   *ent;          /* Entity Cb */
  U16       responseCode;  /* Response Code */
  S16       ret;           /* return Value       */

  TRC3(soUaOutProvRsp);

  responseCode = evnt->t.response.statusLine.statusCode.val;
  ent = cLeg->call->ent;
  
  ret = SOT_ERR_NOERR;
  *reliableRsp = FALSE;

  /* so032.201:- Passing the PRACK to User*/
  if ((responseCode != SOT_RSP_100_TRYING) &&
         (responseCode != SOT_RSP_200_OK))  
  {
#ifdef SO_RFC_3262
    /* Check if peer requires a reliable response */
    if (cLeg->relProvRspInfo.peerReqRelRsp == TRUE)
    {
      *reliableRsp = TRUE;
    }
    else if (ent->s.ua.reCfg.relProvRspReq)
    { 
      if (cLeg->relProvRspInfo.peerSuppRelRsp)
      {
         *reliableRsp = TRUE;
      }
      else 
      {
         /* so024.201 : return ROK in this case */
         RETVALUE(ROK);
      }
    }
    /* so024.201: If both supports 100rel and user wants it then send it */
    else if ((ent->s.ua.reCfg.relProvRspSupp) &&
             (cLeg->relProvRspInfo.peerSuppRelRsp))
    {
       if (soUtlChkOptionTag(evnt, SO_HEADER_GEN_REQUIRE,
                SO_OPTIONTAG_100REL) == ROK)
          *reliableRsp = TRUE;
    }

    ret = soUaChkRelProvRspHdr(cLeg, evnt, *reliableRsp);
    if (ret != SOT_ERR_NOERR)
    {
      RETVALUE(ret);
    }

    if (*reliableRsp == TRUE)
    {
      ret = soUaPrcRelProvRsp(cLeg, evnt);
      RETVALUE(ret);
    }
    
#endif /* SO_RFC_3262 */
  
  }

   /*so033.201:- Check Offer-Answer in PRACK if not generated internally*/
#ifdef SO_RFC_3262
#ifdef SO_RFC_3262_USER
  if ((responseCode == SOT_RSP_200_OK) && (evnt->eventType.val == SOT_ET_PRACK))
  {
       /* Check for offer Answer exchange */
#ifdef SO_EXT_OFFER_ANS
       ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_USER);
       if (ret != SOT_ERR_NOERR)
       {
          SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                   "soUaOutProvRsp: soDlgChkOfferAns failed\n"));             
          RETVALUE(ret);
       }
#endif /* SO_EXT_OFFER_ANS */

  }
#endif /* SO_RFC_3262_USER */
#endif /* SO_RFC_3262 */

  RETVALUE(ret);
} /* soUaOutProvRsp */



/*
*
*       Fun:   soUaDelMultRspCLegs
*
*       Desc:  This function deletes the call legs created by
*              receiving multiple responses for an INVITE, once
*              a final response is received on any of the legs
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE Void soUaDelMultRspCLegs
(
SoCLegCb   *cLeg         /* Cleg cb */
)
#else
PRIVATE Void soUaDelMultRspCLegs(cLeg)
SoCLegCb   *cLeg;        /* Cleg cb */
#endif
{

  SoCallCb   *callCb;     /* Call Cb */
  CmLList    *curNode;    /* Current node in list         */
  PTR        curItem;     /* Current item                 */
  SoCLegCb   *otherLeg;   /* Temp Call Leg control block  */
  U32        legId;       /* Leg Id                       */
  /* so009.201 : New parameter */
  UConnId    suConnId;

  TRC3(soUaDelMultRspCLegs);

  callCb = cLeg->call;

  /* Destroy all call legs except the specified
     one from the call */
  curNode = cmLListFirst(&callCb->cLegLst);
  while (curNode != NULLP)
  {
     curItem  = cmLListNode(curNode);
     curNode  = curNode->next;
     otherLeg     = (SoCLegCb *)curItem;
      
     if ((otherLeg->clegState < SO_CLEG_STATE_ACK_PEND) &&
         (otherLeg != cLeg))
     {
       legId = otherLeg->legId;
       suConnId = otherLeg->userConnId;

       soDlgDeleteCleg(callCb, otherLeg);
       /* so009.201 : Used user conn id instead of suConnId in callCb */
       /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
       soUiErrInd(callCb->ssapCb, suConnId, callCb->spConnId, 
                  NULLP, legId, 0, SOT_ERR_MULTRSP_CLEG, TRUE, FALSE);
#else
       soUiErrInd(callCb->ssapCb, suConnId, callCb->spConnId, 
                  NULLP, legId, 0, SOT_ERR_MULTRSP_CLEG, TRUE);
#endif
     }
  }
  
  RETVOID;
}



/*
*
*       Fun:   soUaInc1xxRsp
*
*       Desc:  This function processes an incoming 1xx response.
*              the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaInc1xxRsp
(
SoCLegCb *cLeg,         /* Cleg cb */
SoEvnt   *evnt,         /* Event   */
Bool     *passToUsr,    /* pass primitive to the user/not */
U16      responseCode   /* Response Code  */
)
#else
PRIVATE S16 soUaInc1xxRsp(cLeg, evnt, passToUsr, responseCode)
SoCLegCb *cLeg;         /* Cleg cb */
SoEvnt   *evnt;         /* Event   */
Bool     *passToUsr;    /* pass primitive to the user/not */
U16      responseCode;  /* Response Code  */
#endif
{
   S16         ret;            /* Return Value */
   SoUserCtxt  userCtxt;       /* User context */
   Bool        reliableRsp;    /* 1xx is reliable / not */

   TRC3(soUaPrc1xxRsp);

   cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

  *passToUsr = TRUE;
  ret        = ROK;
  reliableRsp = FALSE;

  if (responseCode == SOT_RSP_100_TRYING)
  {
#ifndef SO_100TRY_PASS
    *passToUsr = FALSE;
#endif
  }
  else
  {
     /* Store the allow event, if available, in the cleg */
     ret = soUtlStoreAllow(evnt, &cLeg->storedHdrs.peerAllow);
     if (ret != ROK)
        RETVALUE(RFAILED);
    /* Update the Route header received in the 1xx */
    if (cLeg->clegState == SO_CLEG_STATE_EARLY)
    {
      /*--- so020.201: Update the Remote Target URI ---*/
      ret = soDlgUpdRemoteTrgtURI(cLeg, evnt);
      if (ret != ROK)
        RETVALUE(RFAILED);
    
      /*------------  Update the Route Set  -----------*/
      ret = soDlgUpdRoute(cLeg, evnt, SO_REMOTE);
      if (ret != ROK)
        RETVALUE(RFAILED);
    }


#ifdef SO_RFC_3262
    /* Check if inv=coming response is a reliable provisional
       response */
    if (soUtlChkOptionTag(evnt, SO_HEADER_GEN_REQUIRE,
                            SO_OPTIONTAG_100REL) == ROK)
    {
      ret = soUaIncRelProvRsp(cLeg, evnt);
      if (ret != ROK)
        RETVALUE(RFAILED);
      reliableRsp = TRUE;
    }
    else
    {
      if (cLeg->call->ent->s.ua.reCfg.relProvRspReq == TRUE)
      {
        *passToUsr = FALSE;
        RETVALUE(RFAILED);
      }
    }
#endif

#ifdef SO_EXT_OFFER_ANS
    /* Check for offer or answer sdp in the response, if it is a 
       reliable one */
    if (reliableRsp == TRUE)
    {
      ret = soDlgChkOfferAns(cLeg, evnt, evnt->sipMessageType.val, SO_REMOTE);
      if (ret != SOT_ERR_NOERR)
      {
        *passToUsr = FALSE;
        RETVALUE(RFAILED);
      }
    }
#endif /* SO_EXT_OFFER_ANS */
  }

  /*------- If there is a pending CANCEL send it out ------*/
  if (cLeg->pendingCancel)
  {
      SoTransCb  *transCb;
      SoEvnt     *cancel;
     
      cancel              = cLeg->pendingCancel;
      cLeg->pendingCancel = NULLP;
     
     /*------- so014.201: Find the Transaction being CANCELED -------*/
       transCb = soDlgLocateCancelTrans (cLeg, cancel, SO_USER);
       if (transCb == NULLP)
       {
         soCmFreeEvent (cancel); RETVALUE (ROK);
       }
     
      /* 
       * s0014.201: Temprory Store The Context Of CANCELED transaction.
       *     It Will Be Used By  Dialog Layer To Find Next Hop Address.
       *     Please note that we are overloading "userPtr" in User 
       *     Context to save transaction context. Dialog layer will o-
       *     verwrite this values ones it has used it.
       */
       userCtxt.userPtr = (PTR) transCb;
     
      /*-- Fill user context to be stored in the transaction layer --*/
       SO_FILL_USER_CTXT (userCtxt, FALSE, FALSE);
     
      /*-------- Check for outgoing CANCEL specific headers ---------*/
      ret = soUaChkOutCancelHdr (cLeg, cancel, transCb);
      if (ret != ROK)
      {
         soCmFreeEvent (cancel); RETVALUE (ROK);
      }
    
      cLeg->cancelTmrCb.cSeqVal = transCb->transCSeq;
      cLeg->cancelTmrCb.method  = transCb->transMethod;
     
      ret = soDlgUaOutReq (cLeg, &userCtxt, cancel);
     
      if (ret != SOT_ERR_NOERR)
      {
         soCmFreeEvent (cancel); RETVALUE (ROK);
      }
     
      soSchedTmr(cLeg, SO_TMR_EXPIRES, TMR_STOP , NOTUSED);
      soSchedTmr(cLeg, SO_TMR_CANCEL , TMR_START, soCb.reCfg.tmrReTxCfg.t1*64);
    
     /*--------- No need to pass provisional response to user -------*/
      *passToUsr = FALSE;

  } /* End of if (CANCEL Pending) */

  RETVALUE (ROK);
}




/*
*
*       Fun:   soUaPrcExpiresHdr
*
*       Desc:  This extracts the Expires header from a message 
*              and starts the expires timer if required.
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE Void soUaPrcExpiresHdr
(
SoCLegCb *cLeg,         /* Cleg cb */
SoEvnt   *evnt           /* Event   */
)
#else
PRIVATE Void soUaPrcExpiresHdr(cLeg, evnt)
SoCLegCb *cLeg;         /* Cleg cb */
SoEvnt   *evnt;          /* Event   */
#endif
{
   S16         ret;            /* Return Value */
   TknU32      *expires;       /* local pointer to expires header  */
   U32         expiresHdrVal;  /* Expires value                    */

   TRC3(soUaPrcExpiresHdr);
   
   /* Stop Timer if it already running */
   soSchedTmr(cLeg, SO_TMR_EXPIRES, TMR_STOP, NOTUSED);
   
   /* Find header in message */
   ret = soCmFindHdrChoice(evnt, (U8 **) &expires,
                           SO_HEADER_GEN_EXPIRES);
   if (ret != ROK)
   {
     /* If message doesnot have a expires header use the dflt value */
     expiresHdrVal = cLeg->call->ent->s.ua.reCfg.dfltExpiresInInvite;
   }
   else
   {
     if (expires->pres != NOTPRSNT)
        expiresHdrVal = expires->val;
     else 
        expiresHdrVal = 0;
   }
   
   /* If there is a valid expires hdr value start the timer */
   if (expiresHdrVal != 0)
   {
     soSchedTmr(cLeg, SO_TMR_EXPIRES, TMR_START,
                (expiresHdrVal * SO_TMRVAL_1_S));
   }

   RETVOID;
} /* soUaPrcExpiresHdr */





#ifdef SO_RFC_3262
/*
*
*       Fun:   soUaIncRelProvRsp
*
*       Desc:  This function 
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaIncRelProvRsp
(
SoCLegCb     *cLeg,    /* Call Leg Cb */
SoEvnt       *evnt     /* Event Cb */
)
#else
PRIVATE S16 soUaIncRelProvRsp(cLeg, evnt)
SoCLegCb     *cLeg;    /* Call Leg Cb */
SoEvnt       *evnt;    /* Event Cb */
#endif
{

  TknU32     *rSeq;     /* RSeq */
  S16        ret;       /* Return Value */

  TRC3(soUaIncRelProvRsp);

  /* Find rSeq header in response */
  ret = soCmFindHdrChoice(evnt, (U8 **) &rSeq,
                          SO_HEADER_GEN_RSEQ);
  if (ret != ROK)
    RETVALUE(RFAILED);

  if (rSeq->pres == NOTPRSNT)
    RETVALUE(RFAILED);

  if ((cLeg->relProvRspInfo.currRseq != SO_RSEQ_NOTUSED) && 
      (rSeq->val != (cLeg->relProvRspInfo.currRseq+1)))
    RETVALUE(RFAILED);
  
  /* so009.201 : Update Remote Target URI */
  /* If it is a reliable 1xx for an INVITE, update the Remote Traget URI */
  ret = soDlgUpdRemoteTrgtURI(cLeg, evnt);
  if (ret != ROK)
    RETVALUE(RFAILED);

  /* so009.201: Update route if reqd */
  if (cLeg->clegState != SO_CLEG_STATE_MODIFY)
    ret = soDlgUpdRoute(cLeg, evnt, SO_REMOTE);
  if (ret != ROK)
    RETVALUE(RFAILED);

  /* so032.201:- Passing the PRACK to User*/
#ifndef SO_RFC_3262_USER  
  /* If the response was a reliable rsp send
     a PRACK for it */
  ret = soUaGeneratePrack(cLeg, evnt, rSeq);
#endif /* SO_RFC_3262_USER*/
  if (ret == ROK)
    cLeg->relProvRspInfo.currRseq = rSeq->val;

  RETVALUE(ret);

}

#endif /* SO_RFC_3262 */



/*
*
*       Fun:   soUaPrc2xxRsp
*
*       Desc:  This function processes an incoming 1xx response.
*              the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaInc2xxRsp
(
SoCLegCb *cLeg,      /* Cleg Cb */
SoEvnt   *evnt,       /* Event Cb */
Bool     *passToUsr  /* pass to the user/ not */
)
#else
PRIVATE S16 soUaInc2xxRsp(cLeg, evnt, passToUsr)
SoCLegCb *cLeg;      /* Cleg Cb */
SoEvnt   *evnt;       /* Event Cb */
Bool     *passToUsr;  /* pass to the user/ not */
#endif
{
  S16         ret;           /* value returned by the function  */

  TRC3(soUaInc2xxRsp);

  *passToUsr = TRUE;

  /* Stop the Expires Timer */
  soSchedTmr(cLeg, SO_TMR_EXPIRES, TMR_STOP, NOTUSED);

  /* Stop the Expires Timer */
  soSchedTmr(cLeg, SO_TMR_CANCEL, TMR_STOP, NOTUSED);


  /* If it is a 2xx for an INVITE, update the Remote Traget URI */
  ret = soDlgUpdRemoteTrgtURI(cLeg, evnt);
  if (ret != ROK)
    RETVALUE(RFAILED);

  /* If it is not a response to a REINVITE, 
     update the route header based on the Record Route in the response */
  /* so004.201: Changed state for updation of Route */
  /* so013.201: Update Req Uri in case of session refresh */
  if (cLeg->clegState != SO_CLEG_STATE_MODIFY_ACK)
    ret = soDlgUpdRoute(cLeg, evnt, SO_REMOTE);
  else
    /* so013.201: Only update Req Uri */
    ret = soDlgUpdModReqUri(cLeg, evnt, SO_REMOTE);

  /* Store the allow event, if available, in the cleg */
  ret = soUtlStoreAllow(evnt, &cLeg->storedHdrs.peerAllow);
  if (ret != ROK)
    RETVALUE(RFAILED);


  /* Store the cSeq in the Ack */
  SO_UA_STORE_ACK_CSEQ(cLeg, evnt, ret);

  if (ret != ROK)
    RETVALUE(RFAILED);

  if (cLeg->pendingCancel != NULLP)
  {
    ret = soUaIntAckAndBye(cLeg, evnt);
    (Void) soCmFreeEvent(cLeg->pendingCancel);
    cLeg->pendingCancel = NULLP;
    *passToUsr = FALSE;
  } 

  RETVALUE(ret);
} /* soUaInc2xxRsp */



/*
*
*       Fun:   soUaPrc3xxRsp
*
*       Desc:  This function processes an incoming 3xx response.
*              the user
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaInc3xxRsp
(
SoCLegCb *cLeg,      /* Cleg Cb */
SoEvnt   *evnt,       /* Event Cb */
Bool     *passToUsr  /* pass to the user/ not */
)
#else
PRIVATE S16 soUaInc3xxRsp(cLeg, evnt, passToUsr)
SoCLegCb *cLeg;      /* Cleg Cb */
SoEvnt   *evnt;       /* Event Cb */
Bool     *passToUsr;  /* pass to the user/ not */
#endif
{
  S16         ret;           /* value returned by the function  */

  TRC3(soUaInc3xxRsp);

  /*--- so014.201: Initialize local variable ---*/
  ret        = ROK;
  *passToUsr = TRUE;

  if (cLeg->call->ent->reCfg.alwRecurse != TRUE)
    RETVALUE(ROK);

  /* If recursion has not stared, initialize the recursion
   control block */
  if (cLeg->recurseCb.recursState != SO_RECURSION_ON)
  {
    ret = soUaInitRecurse(cLeg, evnt);
    if (ret != ROK)
      RETVALUE(ret);
  }
  else
  {
    ret = soUaAddRecurseContacts(evnt, &cLeg->recurseCb);
  }

  /* Recurse */
  ret = soUaRecurse(cLeg, cLeg->sentInvite);

  if (ret == ROK)
    *passToUsr = FALSE;

  RETVALUE(ret);
} /* soUaInc3xxRsp */





/*
*
*       Fun:   soUaIntAckAndBye
*
*       Desc:  Constructs an ACK followed by aBYE for a call
*              for which a 2xx was received.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaIntAckAndBye
(
SoCLegCb    *cLeg,        /* Call Leg Cb */
SoEvnt      *rspEvnt       /* Response for which the ack is being sent */
)
#else
PRIVATE S16 soUaIntAckAndBye(cLeg, rspEvnt)
SoCLegCb    *cLeg;       /* Call Leg Cb */
SoEvnt      *rspEvnt;     /* Response for which the ack is being sent */
#endif
{
   S16         ret;          /* value returned by function calls */
   SoEvnt      *ackEvnt;     /* new event */
   SoUserCtxt  userCtxt;     /* User Context */
   SoCSeq      *rspCSeq;     /* cSeq in the response */

   TRC2(soUaIntAckAndBye);

  /*--- so014.201: Initialize local variable ---*/
   ret        = ROK;
   cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

   ret = soUaRequestBuild(cLeg, SOT_ET_ACK, &ackEvnt);
   if (ret != ROK)
     RETVALUE(RFAILED);

   /* Copy Cseq from the received message to the ACK */
   ret = soCmFindHdrChoice(rspEvnt, (U8 **) &rspCSeq, SO_HEADER_GEN_CSEQ);
   if (ret != ROK)
   {
     RETVALUE(RFAILED);
   }

   /* Copy Cseq from the received message to the ACK */
   ret = soCmFindHdrChoice(rspEvnt, (U8 **) &rspCSeq, SO_HEADER_GEN_CSEQ);
   if (ret != ROK)
   {
     RETVALUE(RFAILED);
   }

   /* Insert the CSeq into the message */
   ret = soUtlInsertCSeq(cLeg, ackEvnt, rspCSeq->cSeqVal.val, NULLP);
    if (ret != ROK)
      RETVALUE(RFAILED);

   /* Fill the user context that will be stored in the transaction layer */
   SO_FILL_USER_CTXT(userCtxt, FALSE, TRUE);
   
   /* Pass request to dialog layer for processing */
   ret = soDlgUaOutReq(cLeg, &userCtxt, ackEvnt);
   
   /* SEnd a BYE */
   if (ret == SOT_ERR_NOERR)
   {
    ret = soUaIntBye(cLeg);
   }
   else
     ret = RFAILED;

   RETVALUE(ret);
} /* end of soUaIntAckAndBye */






/*
*
*       Fun:   soUaIntBye
*
*       Desc:  Constructs a Bye internally, to clear
*              the call.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaIntBye
(
SoCLegCb    *cLeg        /* Call Leg Cb */
)
#else
PRIVATE S16 soUaIntBye(cLeg)
SoCLegCb    *cLeg;       /* Call Leg Cb */
#endif
{
   S16         ret;          /* value returned by function calls */
   SoEvnt      *byeEvnt;     /* new event */
   SoUserCtxt  userCtxt;     /* User Context */

   TRC2(soUaIntBye);

   cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

   ret = soUaRequestBuild(cLeg, SOT_ET_BYE, &byeEvnt);
   if (ret != ROK)
     RETVALUE(RFAILED);

  /* Fill the user context that will be stored in the transaction layer */
  SO_FILL_USER_CTXT(userCtxt, FALSE, TRUE);

  /* Pass request to dialog layer for processing */
  ret = soDlgUaOutReq(cLeg, &userCtxt, byeEvnt);

  if (ret == SOT_ERR_NOERR)
  {
    cLeg->intBye = TRUE;
    /* Stop the Expires Timer */    
    soSchedTmr(cLeg, SO_TMR_EXPIRES, TMR_STOP, NOTUSED);
  }
  else
    ret = RFAILED;

#ifdef SO_SESSTIMER
  /* so011.201: Stop Session Timer */
  soStopSessTimer(cLeg);
#endif

   RETVALUE(ret);
} /* end of soUaIntBye */




/*
*
*       Fun:   soUaIntCancel
*
*       Desc:  Constructs a Cancel internally, to clear
*              the call.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaIntCancel
(
SoCLegCb    *cLeg        /* Call Leg Cb */
)
#else
PRIVATE S16 soUaIntCancel(cLeg)
SoCLegCb    *cLeg;       /* Call Leg Cb */
#endif
{
   S16         ret;          /* value returned by function calls */
   SoEvnt      *cancelEvnt;     /* new event */
   SoUserCtxt  userCtxt;     /* User Context */
   SoTransCb   *transCb;

   TRC2(soUaIntCancel);

   cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

   ret = soUaRequestBuild(cLeg, SOT_ET_CANCEL, &cancelEvnt);
   if (ret != ROK)
     RETVALUE(RFAILED);

   /*------- so014.201: Find the Transaction being CANCELED -------*/
   transCb = soDlgLocateCancelTrans (cLeg, NULLP, SO_INTERNAL);
   if (transCb == NULLP)
   {
     soCmFreeEvent (cancelEvnt);
     RETVALUE (ROK);
   }

  /* 
   * s0014.201: Temprory Store The Context Of CANCELED transaction.
   *     It Will Be Used By  Dialog Layer To Find Next Hop Address.
   *     Please note that we are overloading "userPtr" in User 
   *     Context to save transaction context. Dialog layer will o-
   *     verwrite this values ones it has used it.
   */
   userCtxt.userPtr = (PTR) transCb;
     
  /*-- Fill user context to be stored in the transaction layer --*/
   SO_FILL_USER_CTXT (userCtxt, FALSE, TRUE);
     
  /*----------- so003.201: Add Via for internal CANCEL ----------*/
  /*-------- Check for outgoing CANCEL specific headers ---------*/
   ret = soUaChkOutCancelHdr (cLeg, cancelEvnt, transCb);
   if (ret != ROK) 
   {
      soCmFreeEvent (cancelEvnt);
      RETVALUE (SOT_ERR_ADD_HDR_FAILED);
   }

   /*----------- Store cseq & method for cancel timer -----------*/
   cLeg->cancelTmrCb.cSeqVal = transCb->transCSeq;
   cLeg->cancelTmrCb.method  = transCb->transMethod;

   /*-------- Pass request to dialog layer for processing -------*/
   ret = soDlgUaOutReq (cLeg, &userCtxt, cancelEvnt);
   
   if (ret == SOT_ERR_NOERR)
   {
     /* Stop the Expires Timer */
     soSchedTmr(cLeg, SO_TMR_EXPIRES, TMR_STOP, NOTUSED);
     /* Start Cancel Timer     */
     soSchedTmr(cLeg, SO_TMR_CANCEL, TMR_START, soCb.reCfg.tmrReTxCfg.t1 *64);    
   }
   else
     ret = RFAILED;

   RETVALUE(ret);

} /* end of soUaIntCancel */




/*
*
*       Fun:   soUaEndCall
*
*       Desc:  Constructs a Cancel/ Bye  internally, and sends an
*              err indication to the user
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soUaEndCall
(
SoCLegCb    *cLeg        /* Call Leg Cb */
)
#else
PUBLIC Void soUaEndCall(cLeg)
SoCLegCb    *cLeg;       /* Call Leg Cb */
#endif
{
   S16         ret;          /* value returned by function calls */
   SoCallCb    *callCb;      /* Call cb */
   U16         legId;        /* Call Leg Id */
   /* so009.201 : Used user conn id instead of suConnId in callCb */
   UConnId     suConnId;

   callCb = cLeg->call;
   ret    = ROK;

   /* Send the appropriate message to the remote end 
      based on the call leg state */
   if (cLeg->clegState == SO_CLEG_STATE_INITIAL)
   {
     ret = ROKDNA;
   }
   else if (cLeg->clegState < SO_CLEG_STATE_EARLY)
   {
     if (cLeg->role == SO_CLIENT)
       ret = soUaIntCancel(cLeg);
     else
       ret = ROKDNA;
   }
   else
     ret = soUaIntBye(cLeg);

   /* so009.201 : Used user conn id instead of suConnId in callCb */
   callCb = cLeg->call;
   legId  = cLeg->legId;
   suConnId = cLeg->userConnId;

   if (ret != ROK)
     soDlgDeleteCleg(callCb, cLeg);

   /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
   soUiErrInd(callCb->ssapCb, suConnId, 
              callCb->spConnId, NULLP, legId,SOT_ET_INVALID,
              SOT_ERR_ENT_DIS, TRUE, FALSE);
#else
   soUiErrInd(callCb->ssapCb, suConnId, 
              callCb->spConnId, NULLP, legId,SOT_ET_INVALID,
              SOT_ERR_ENT_DIS, TRUE);
#endif

  /* All Call Leg may have been deleted, so check if call needs 
     to be deleted also. */
  soCoreChkAndDelCall(callCb);

  RETVOID;

} /* end of soUaEndCall */



/***********************************************************************
*
*       Fun:    soUaLocalReg
*
*       Desc:   Handles a local registration request from call control
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_ua.c
*
**********************************************************************/
#ifdef ANSI
PRIVATE S16 soUaLocalReg
(
SoSSapCb    *ssap,    /* Control handler receiving this message */
SoEvnt      *evnt     /* Event Structure */  
)
#else
PRIVATE S16 soUaLocalReg(ssap, evnt)
SoSSapCb    *ssap;    /* Control handler receiving this message   */
SoEvnt      *evnt;    /* Event Structure */
#endif /* ANSI */
{
   S16         ret;           /* value returned by the function  */
   SoClRegEnt  *cacheEntry;   /* Cache entry for updates from REGISTER */
   SoEntCb     *ent;          /* Entity Cb */      
   Bool        thirdPartyReg; /* Third party reg is TRUE */
   SoAddress   *to;           /* To Address */
   SoAddress   *from;         /* From Address */
   SoEvnt      *rspEvnt;      /* Response Event */

   TRC2(soUaLocalReg);

   ent = ssap->sys;
   
   /* Check if user is registering a 3rd party and
      if it is allowed */
   ret = soUaChkThirdPartyReg(ent, evnt, &to, &from, &thirdPartyReg);

   if (ret != ROK)
     RETVALUE(SOT_ERR_LOCREG_INV);


   /* Insert To address into cache */
   ret = soClPrcRegistryEntry(&ent->s.ua.localUsrReg,
                              evnt, TRUE, &cacheEntry, to,
                              NULLP, NULLP);
   if (ret != ROK)
      RETVALUE(SOT_ERR_LOCREG_FAILED);
   else
   {
     /* Build a response to send to the user */
      ret = soUtlBuildRspEvnt(ssap->sys, &rspEvnt, 
                              evnt,
     /* so011.201: Passing paramater event type */
                              SOT_ET_INVALID,
                              SOT_RSP_200_OK, SO_EXTRSP_NONE);
      if (ret != ROK)
        RETVALUE(SOT_ERR_RSRC);

      /* Now just fill in contacts in return message */
      if (cacheEntry != NULLP)
      {
         ret = soClContactHdrFromCacheEntry(rspEvnt, cacheEntry, TRUE, TRUE);
         if (ret != ROK)
           RETVALUE(SOT_ERR_ADD_HDR_FAILED);
      }
                 
      soUiCIMCfm(ssap, SOT_CONNID_NOTUSED, SOT_CONNID_NOTUSED,rspEvnt); 
      (Void) soCmFreeEvent(evnt);

   }
   RETVALUE(ROK);
} /* end of soUaLocalReg */



/***********************************************************************
*
*       Fun:    soUaRemoteReg
*
*       Desc:   Handles a remote registration request from call control
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_ua.c
*
**********************************************************************/
#ifdef ANSI
PRIVATE S16 soUaRemoteReg
(
SoSSapCb    *ssap,    /* Control handler receiving this message */
SoEvnt      *evnt,     /* Event Structure */  
UConnId     suConnId
)
#else
PRIVATE S16 soUaRemoteReg(ssap, evnt, suConnId)
SoSSapCb    *ssap;    /* Control handler receiving this message   */
SoEvnt      *evnt;    /* Event Structure */
UConnId     suConnId;
#endif /* ANSI */
{
   SoEntCb   *ent;           /* Entity Cb */
   Bool      thirdPartyReg;  /* 3rd Party Reg */
   U8        *key;           /* String version of contact */
   U16       keyLen;         /* length of address */
   SoCallCb  *callCb;        /* Call cb */
   SoCLegCb  *cLeg;          /* Call Leg Cb */
   SoAddress *to;            /* To Address */
   SoAddress *from;          /* From Address */
   SoUserCtxt userCtxt;     /* User Context Cb    */
   S16        ret;           /* return Value       */
   SoUaRegCb  *regCb;        /* Registration Cb */
   Bool       newRegCb;      /* New Registrar cb */
   Bool       newCall;       /* New Call cb */
   Bool       newLeg;        /* New Call leg  cb */
   U8         *cLegKey;      /* String version of contact */
   U16        cLegKeyLen;    /* length of address */
   SoUACb     *uaCb;         /* UA cb */
   U32        currCSeq;      /* Cseq to be used for the current registration */
   CmLList    *curNode;      /* Current node in list  */
   PTR        curItem;       /* Current item          */
   SoRegContactCb  *pendContact;  /* Contact cb */
   Bool       saveMsg = TRUE; /*so025.201 */

   TRC2(soUaRemoteReg);
   
   thirdPartyReg = FALSE;
   cLeg          = NULLP;
   callCb        = NULLP;
   key           = NULLP;
   keyLen        = 0;
   cLegKey       = NULLP;
   cLegKeyLen    = 0;
   to            = NULLP;
   from          = NULLP;
   ent           = ssap->sys;
   newRegCb      = FALSE;
   newCall       = FALSE;
   newLeg        = FALSE;
   currCSeq      = 0;

   uaCb = &ent->s.ua;

  /*--- so009.201: Initialize user context ---*/
   cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

   /* Check if it ia a third part registration and if such a 
      registration is allowed */
   ret = soUaChkThirdPartyReg(ent, evnt, &to, &from, &thirdPartyReg);
   
   if (ret != ROK)
     RETVALUE(SOT_ERR_LOCREG_INV);
  
   /* Check for Registration Specific Headers */
   ret = soUaChkRegHdr(ent, evnt);
   if (ret != ROK)
     RETVALUE(ret);
   
   
   /* Find the Registration control Block from the entCb */
   regCb = soUaFindRegCb(ent, evnt, &key, &keyLen);
   if ((key == NULLP) || (keyLen == 0))
     RETVALUE(SOT_ERR_RSRC);
   
   /* If no regcb is located */
   if (regCb == NULLP)
   {
     /* Create a New Reg Cb */
     regCb = soUaCreateRegCb(ent, &key, &keyLen);
     
     if (regCb == NULLP)
     {
       /* Free the key allocated temporarily */
       SOFREE(key, keyLen);
       RETVALUE(SOT_ERR_RSRC);
     }
     else
       newRegCb = TRUE;
   }
   
   /* Free the key allocated temporarily */
   SOFREE(key, keyLen);

   /* Try to find the registration call cb */
   callCb = NULLP;

   /* Find the call cb associated with registrations */
   ret = soUaFindRegCallCb(ssap->sys, evnt, &callCb);
       
   if (ret != ROK)
   {
     ret = SOT_ERR_RSRC;
     goto SOUAREMOTEREG_ERR;
   }
     
   cLeg = NULLP;

   /* Find the key associated with the registration call leg. A 
      registration call leg represents one add-of-record being 
      registered. The key will be the combination of the to & from
      address in the regitration */
   ret = soUaCalcRegClegKey(evnt, &cLegKey, &cLegKeyLen);
   if ((ret != SOT_ERR_NOERR) || (cLegKeyLen == 0) ||
       (cLegKey == NULLP))
   {
     goto SOUAREMOTEREG_ERR;
   }

   /* If a call cb was not found, it implies that it is the
      first registration  so create a new callcb */
   if (callCb == NULLP)
   {
     /*--- so013.201: Save the user connection identifier ---*/
     callCb = soCoreCreateCallCb(ssap, ent, suConnId, evnt, SO_USER);

     if (callCb == NULLP)
     {
       ret = SOT_ERR_RSRC;
       goto SOUAREMOTEREG_ERR;
     }
 
     /*- so014.201: Make newCall as TRUE after successful creation -*/
     newCall = TRUE;
   }
   else
   {
     /* Try to locate the call leg associated with the registration */
     cLeg = soUaFindRegCLeg(evnt, cLegKey, cLegKeyLen, callCb, regCb);
   }


   /* If call leg match is not found, create a new call leg */
   if (cLeg == NULLP)
   {
     cLeg = soDlgCreateCleg(callCb, evnt, SO_USER);

     if (cLeg == NULLP)
     {
       ret = SOT_ERR_RSRC;
       goto SOUAREMOTEREG_ERR;
     }
     else
     {
       newLeg = TRUE;
       cLeg->regInfo.regAddrKeyLen = cLegKeyLen;
       SOALLOC(&cLeg->regInfo.regAddrKey, cLegKeyLen);
       
       if (cLeg->regInfo.regAddrKey == NULLP)
       {
         ret = SOT_ERR_RSRC;
         goto SOUAREMOTEREG_ERR;
       }
       else
       {
         cmMemcpy(cLeg->regInfo.regAddrKey, cLegKey, cLegKeyLen);
         cLeg->regInfo.regCb = regCb;

         /* Insert Call leg into call cb list */

         ret = cmHashListInsert(&callCb->regCLegLst, (PTR) (cLeg),
                                (U8 *) cLeg->regInfo.regAddrKey,
                                (U16)cLegKeyLen);
         if (ret != ROK)
         {
           ret = SOT_ERR_RSRC;
           goto SOUAREMOTEREG_ERR;
         }

       }
     }
   }

   /* Free the locally allocated key& keylen */
   SOFREE(cLegKey, cLegKeyLen);
   cLegKeyLen = 0;
   cLegKey = NULLP;
   
   /* Insert Correct CSeq for the Registration */
   cLeg->storedHdrs.cSeqHiTx = regCb->currCSeq;
   currCSeq = cLeg->storedHdrs.cSeqHiTx;

   /* Process the contact Information Received in the Registration,
    if REGISTER is not multicast / thrid party */

   if (thirdPartyReg == TRUE)
     cLeg->regInfo.thirdPartyReg = TRUE;
   
   else if ((uaCb->reCfg.refreshOnExp == TRUE) ||
            (uaCb->reCfg.alertUsrOnExp == TRUE))
   {
     /*--- so009.201: Event is only required if refresh is TRUE ---*/
     /* Fill the user context that will be stored in 
        the transaction layer */
     /* so025.201 : : In dereg case, evnt should not be stored by dialog */
     ret =soUaPrcContactInfo(cLeg, evnt, &saveMsg);
     SO_FILL_USER_CTXT(userCtxt, saveMsg, FALSE);

     if(ret != SOT_ERR_NOERR)
       goto SOUAREMOTEREG_ERR;
   }
  
   /* Increment regCb cseq */
   regCb->currCSeq++;

   ret = soDlgUaOutReq(cLeg, &userCtxt, evnt);
   if (ret != SOT_ERR_NOERR)
     goto SOUAREMOTEREG_ERR;

   RETVALUE(SOT_ERR_NOERR);
   
   /* If there is any error, clear the context */
  SOUAREMOTEREG_ERR:
    if ((cLegKeyLen != 0) &&
        (cLegKey != NULLP))
    {
      SOFREE(cLegKey, cLegKeyLen);
    }

    /* Remove the pending contacts if the register
       request failed */
    if (cLeg != NULLP)
    {
      curNode = cmLListFirst(&cLeg->regInfo.pendContactLst);
      while (curNode != (CmLList *)NULLP)
      {
         curItem  = cmLListNode(curNode);
         curNode  = curNode->next;
         pendContact = (SoRegContactCb *)curItem;
         if (pendContact->currCSeq == currCSeq)
         {
           /* Event will be released outside by the calling fn. So make it
              NULLP in the contact cb */
           pendContact->storedReq = NULLP;
           SO_UA_DEL_CONTACT(cLeg, pendContact);
         }
      }
    }

    if (newLeg == TRUE)
    {
      soDlgDeleteCleg(callCb, cLeg);
    }
    if (newCall == TRUE)
    {
      soCoreDeleteCallCb(callCb);
    }
    if (newRegCb == TRUE)
    {
      soUaDeleteRegCb(ent, regCb);
    }
   

   RETVALUE(ret);

} /* soUaRemoteReg */





/*
*
*       Fun:   soUaPrcRegErrRsp
*
*       Desc:  This function handles a error response received for
*              a REGISTER
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE Void soUaPrcRegErrRsp
(
SoCLegCb  *cLeg,     /* Call Leg Cb */
U32       cSeqVal    /* CSeq Value rcvd in response */
)
#else
PRIVATE Void soUaPrcRegErrRsp(cLeg, cSeqVal)
SoCLegCb  *cLeg;    /* Call Leg Cb */
U32       cSeqVal;  /* CSeq Value rcvd in response */
#endif
{
   U16               numPendContacts; /* Number of contacts for which
                                         the registration was sent */
   CmLList           *curNode;        /* Current node in list     */
   PTR               curItem;         /* Current item             */
   SoRegContactCb    *pendContact;    /* Contact cb */
   SoEvnt            *storedRegEvnt;  /* Stored event */
 
   TRC3(soUaPrcRegErrRsp);

   numPendContacts = cmLListLen(&cLeg->regInfo.pendContactLst); 
   if (numPendContacts == 0)
     RETVOID;

   /* Delete Contact from all lists */
   curNode = cmLListFirst(&cLeg->regInfo.pendContactLst);
   while (curNode != (CmLList *)NULLP)
   {
     curItem  = cmLListNode(curNode);
     curNode  = curNode->next;
     pendContact = (SoRegContactCb *)curItem;

     if (pendContact->currCSeq == cSeqVal)
     {
       storedRegEvnt = pendContact->storedReq;
       pendContact->storedReq = NULLP;
       SO_UA_DEL_CONTACT(cLeg, pendContact);
     }
   }

   /* Delete the stored register event */
   if (storedRegEvnt != NULLP)
     soCmFreeEvent(storedRegEvnt);

   RETVOID;
}




/*
*
*       Fun:   soUaPrcRegRsp
*
*       Desc:  This function handles an incoming REGISTER response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaPrcRegRsp
(
SoCLegCb    *cLeg,    /* Call Leg Cb */
SoEvnt      *evnt,    /* Event Cb    */
U32         cSeqVal   /* CSeq Value rcvd in response */
)
#else
PRIVATE S16 soUaPrcRegRsp(cLeg, evnt, cSeqVal)
SoCLegCb    *cLeg;    /* Call Leg Cb */
SoEvnt      *evnt;    /* Event Cb    */
U32         cSeqVal;  /* CSeq Value rcvd in response */
#endif
{
   TknU32         *expiresHdr;    /* Expires header        */
   U32            expiresTmrVal;  /* Expires timer value   */
   SoEntCb        *ent;           /* Entity Cb             */
   CmLList        *curNode;       /* Current node in list  */
   PTR            curItem;        /* Current item          */
   SoRegContactCb *contactCb;     /* Contact Control Block */
   Bool           delContact;     /* Contact to be deleted / not */
   S16            ret;            /* Return Value */
   Bool           contactInRsp;   /* Contact Headers found in response */
   SoEvnt         *origEvnt;      /* original Event */

   TRC3(soUaPrcRegRsp);

   /*----so014.201: Initialize all the local vaiables ----*/
    ret          = ROK;
    ent          = cLeg->call->ent;
    contactInRsp = FALSE;
    origEvnt     = NULLP;
    contactCb    = NULLP;

    /* so024.201: Dont process conatacts if dereg */
   if (cLeg->regInfo.deRegAll == TRUE)
   {
      soUaDeregister(cLeg);
      cLeg->regInfo.deRegAll = FALSE;
      RETVALUE(ROK);
   }
   /* Extract expires header if required */
   soCmFindHdrChoice(evnt, (U8 **)&expiresHdr, SO_HEADER_GEN_EXPIRES);
   if (expiresHdr != NULLP)
   {
     /* Calculate seconds till expiry */
     if (expiresHdr->pres != NOTPRSNT)
        expiresTmrVal = expiresHdr->val;
     else 
        expiresTmrVal = 0;

    /* so024.201: Dont process conatacts if dereg */
     if (cLeg->regInfo.deRegAll == TRUE)
     {
       soUaDeregister(cLeg);
       RETVALUE(ROK);
     }
   }
   else
   {
     /* If message doesnot have expires header , chk if value 
        has been configured */
     if (ent->s.ua.reCfg.dfltExpiresInRegister != 0)
       expiresTmrVal = ent->s.ua.reCfg.dfltExpiresInRegister;
     else
       expiresTmrVal = (SO_TMRVAL_1_HOUR / SO_TMRVAL_1_S); 
   }

   /* so004.201: Moved code to soUaPrcContactsInRsp */

   /* Check if Rsp contains any contacts */
   SO_UA_CHK_RSP_FOR_CONTACTS(&evnt->t.response.response, contactInRsp);
   
   /* Go through each contact in the pending list to process
      the result received from the Registrar. The pending list
      contains the list of contacts  that the user was trying 
      to register in a particular Registration message */
   curNode = cmLListFirst(&cLeg->regInfo.pendContactLst);
   while (curNode != NULLP)
   {
     ret = ROK;
     delContact = FALSE;
     curItem  =   cmLListNode(curNode);
     curNode  =   curNode->next;
     contactCb = (SoRegContactCb *)curItem;
     
     if (contactCb->currCSeq != cSeqVal)
       continue;
     
     /* Remove contact from pending contact list */
     cmLListDelFrm(&(cLeg->regInfo.pendContactLst), 
                   &(contactCb->cLegLstNode));
     contactCb->cLegLstNode.node = NULLP;

     if ((contactCb->userRegPend == TRUE) &&
         (origEvnt == NULLP))
       origEvnt = contactCb->storedReq;

     /* Process contact details */
     ret = soUaPrcContactsInRsp(cLeg, evnt, contactCb, expiresTmrVal, 
                                contactInRsp, &delContact);
     
     if ((ret != ROK) || (delContact == TRUE))
     {
       if (contactCb->storedReq == origEvnt)
         contactCb->storedReq = NULLP;

       SO_UA_DEL_CONTACT(cLeg,contactCb);
       continue;
     }
     
   } /* while */
   
   /* if the initial Registration message was not cleared do so now , 
      since new registration events have been constructed for each
      individual contact */
   if (origEvnt != NULLP)
     soCmFreeEvent(origEvnt);
   
   RETVALUE(ret);
   
}




/*
*
*       Fun:   soUaPrcContactsInRsp
*
*       Desc:  This function handles a error response received for
*              a REGISTER
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaPrcContactsInRsp
(
SoCLegCb       *cLeg,        /* Call Leg Cb */
SoEvnt         *evnt,        /* Event Cb */
SoRegContactCb *contactCb,   /* Contact cb */
U32            expiryTmrVal, /* Expiry Timer Value */
Bool           contactInRsp, /* Contacts present in rsp./ not */
Bool           *delContact   /* TRUE if contact is to be deleted */
)
#else
PRIVATE S16 soUaPrcContactsInRsp(cLeg, evnt, contactCb, expiryTmrVal,
                                 contactInRsp, delContact)
SoCLegCb       *cLeg;        /* Call Leg Cb */
SoEvnt         *evnt;        /* Event Cb */
SoRegContactCb *contactCb;   /* Contact cb */
U32            expiryTmrVal; /* Expiry Timer Value */
Bool           contactInRsp; /* Contacts present in rsp./ not */
Bool           *delContact;  /* TRUE if contact is to be deleted */
#endif
{
   S16             ret;        /* return Value       */
   /* so017.201 : Added new param  */
   Bool            foundContact; /* TRUE if contact is present in rsp */
   TRC3(soUaPrcContactsInRsp);

   ret = ROK;
   /* so017.201 : Added new param  */
   foundContact = FALSE;

  /* If response contained contacts check for the 
     current contact in the list so that expiry timer 
     values can be updated */
  if (contactInRsp == TRUE)
  {
     /* so017.201 : Added new param to function call */
    ret = soUaChkContactExp(evnt ,contactCb, expiryTmrVal, delContact, &foundContact);
  }
  /* so017.201 : Changed condition to take care of the situation
    when the registrar does send contacts in the respnse but the current
    contact is not present because it has been de-registered */
  if ((contactInRsp != TRUE) || (foundContact == FALSE))
  {
    /* If the response doesnot contain any contacts, use 
       the values stored during the sending of the REGISTER */
    
    /* If no Expiry timer or if value was 0, it implies that the
       contact was being deregistered, so delete it */
    if ((contactCb->expiryTmrVal.pres == PRSNT_NODEF) &&
        (contactCb->expiryTmrVal.val == 0))
      *delContact = TRUE;
    else if (contactCb->expiryTmrVal.pres != PRSNT_NODEF)
    {
      /* If the contact didnot contain a expires value originally, 
         see if we have a configured value.
         If not, delete it */
      if (expiryTmrVal != 0)
      {
         /* so017.201 : If the expires is non -zero it implies
            it is not a de-reg in that case if the  response 
            contained contacts but not this one, it is incorrect */

         if ((contactInRsp == TRUE) && (foundContact == FALSE))
            ret = RFAILED;
         else
         {
            contactCb->expiryTmrVal.pres = PRSNT_NODEF;
            contactCb->expiryTmrVal.val = expiryTmrVal;
         }
      }
      else
        *delContact = TRUE;
    }
    else if ((contactInRsp == TRUE) && (foundContact == FALSE))
       ret = RFAILED;
  }
  
  /* If any error or if contact is to be deleted return */
  if ((ret != ROK) || (*delContact == TRUE))
  {
    RETVALUE(ret);
  }

  /* added by weigy at 060714, If the expires of register request is zero, the expires of response 
  is no-zero, send error indication and return failure */
  if( contactCb->storedReq == NULL )
  {
    SODBGP_SO (SO_DBGMASK_ERR, (soCb.init.prntBuf,
                 "The expire of response is no-zero\n"));

    RETVALUE(RFAILED);
  }

  /* Else build and store a event that will be used to refresh the contact */
  ret = soBldContactRegEvnt(evnt, contactCb);  
  if (ret != ROK)
  {
    *delContact = TRUE;
    RETVALUE(ret);
  }
  
  /* so004.201: Adjust timer value to notify _before_ expiry */
  if (contactCb->expiryTmrVal.val > SO_TMRVAL_REMREG_ACTION)
     contactCb->expiryTmrVal.val = 
         contactCb->expiryTmrVal.val - SO_TMRVAL_REMREG_ACTION;

  soSchedTmr(contactCb, SO_TMR_UA_CONTACT_EXP, TMR_STOP, NOTUSED);
  soSchedTmr(contactCb, SO_TMR_UA_CONTACT_EXP, TMR_START,
             (contactCb->expiryTmrVal.val * SO_TMRVAL_1_S));
  RETVALUE(ROK);
}






/*
*
*       Fun:   soUaChkContactExp
*
*       Desc:  This function processes the expiry headers received
*              in an incoming response.
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
/* so017.201 : Added new params to the function */
#ifdef ANSI
PRIVATE S16 soUaChkContactExp
( 
SoEvnt         *evnt,        /* Event Cb */
SoRegContactCb *contactCb,   /* Contact Cb */
U32            expiryTmrVal, /* Expiry Timer Value */
Bool           *delContact,  /* TRUE if contact is to deleted */
Bool           *foundContact /* TRUE if contact was found in response */
)
#else
PRIVATE S16 soUaChkContactExp(evnt, contactCb, expiryTmrVal, delContact, foundContact)
SoEvnt         *evnt;        /* Event Cb */
SoRegContactCb *contactCb;   /* Contact Cb */
U32            expiryTmrVal; /* Expiry Timer Value */
Bool           *delContact;  /* TRUE if contact is to deleted */
Bool           *foundContact; /* TRUE if contact was found in response */
#endif
{
   U16            i;            /* Index */
   U16            j;            /* Index */
   SoHeaderSeq    *hdrSeq;      /* Header sequence to search */ 
   SoHeader       *curHdr;      /* Current header */
   SoContactItem  *contactItem; /* contact Item */
   S16            ret;          /* return Value */
   Bool           foundExp;     /* True, if expiry is found */
   SoContactParam *cPar;        /* Contact item parameter      */
   SoContact      *contactHdr;  /* Contact header part of message */
   U32            cItem;        /* Counter for contact items */
   SoAddrSpec     *contactAddr; /* Contact address */
   U8             *key;         /* String version of contact */
   U16            keyLen;       /* length of address */

   TRC3(soUaChkContactExp);

  /*--- so014.201: Initialize local variable ---*/
   ret        = ROK;

   hdrSeq = &evnt->t.response.response;
   foundExp = FALSE;
   *foundContact = FALSE;
   
   for (i = 0; i < hdrSeq->numComp.val; i++)
   {
     curHdr = hdrSeq->header[i];
     if (SO_CMP_TKN_LIT(&curHdr->headerType, SO_HEADER_GEN_CONTACT) != TRUE)
       continue;
    
     /* Contact header found - process */
     contactHdr = &curHdr->t.contact;
        
     for (cItem = 0; 
          cItem < SO_GET_NUM_COMP(&contactHdr->contactItems.numComp);
          cItem++)
    {
      contactItem =contactHdr->contactItems.contactItem[cItem];
      
      SO_ADDRSPEC_FROM_ADDRCH(contactAddr, &contactItem->contactAddrChoice);
      
      /* Calculate the key , based o the addr provided 
         in conatct */
      if ((ret = soUtlCalcAddrKey(contactAddr, &key, &keyLen))!= ROK)
        RETVALUE(RFAILED);
      
      /* Look for the correct contact in the incoming messge.
         The incoming message may contain all the contacts
         registered with the registrar. We only need to
         process the info for the contacts for ehich the
         current message was sent */
      if ((keyLen == contactCb->keyLength) &&
          (!cmStrncmp(key, contactCb->key, keyLen)))
      {
        *foundContact = TRUE;
        /* Free Key & keyLength */
        SOFREE(key, keyLen);

        for (j = 0; j < SO_GET_NUM_COMP(&contactItem->contactParams.numComp);j++)
        {
          cPar = contactItem->contactParams.contactParam[j];
          
          if ((cPar != NULLP) && 
              (SO_CMP_TKN_LIT(&cPar->contactParamType,
                              SO_CONTACTPARAM_STD) == TRUE) &&
              (cPar->t.contactParamStd.contactParamStdType.val ==
               SO_CONTACTPARAMSTD_EXPIRES))
          {
            foundExp = TRUE;

            /* so029.201 : if the contact in the pending contact list 
               contains expires = 0, and the response 200 OK contains 
               expires != 0, then also delete the contact. */
            if(contactCb->expiryTmrVal.pres != NOTPRSNT)
            {
               if(contactCb->expiryTmrVal.val == 0)
               {
                  *delContact = TRUE;
                  break;
               }
            }

            if (cPar->t.contactParamStd.t.contactParExpires.pres != NOTPRSNT)
               contactCb->expiryTmrVal.val =
                  cPar->t.contactParamStd.t.contactParExpires.val;
            else
               contactCb->expiryTmrVal.val = 0;

            contactCb->expiryTmrVal.pres = PRSNT_NODEF;

            if (contactCb->expiryTmrVal.val == 0)
              *delContact = TRUE;
            break;
          }
        } /* for j */
        
        /* If contact doesnot have a expires field, take the 
           value of the Expirs header as default time for
           contact. */
        /*-- so033.201: In case of de-registration this value 
          identifies whether to remove the contact or re-register
          the same --*/
        if ((contactCb->expiryTmrVal.pres == PRSNT_NODEF) &&
              (contactCb->expiryTmrVal.val == 0))
        {
           *delContact = TRUE;
        }
        else if (foundExp == FALSE)
        {
          contactCb->expiryTmrVal.pres = PRSNT_NODEF;
          contactCb->expiryTmrVal.val = expiryTmrVal;
          if (expiryTmrVal == 0)
            *delContact = TRUE;
        }

        /* If contact is found break */
        if (*foundContact == TRUE)
          break;
      } /* If contact key & len match */
      
      /* Free Key & keyLength */
      SOFREE(key, keyLen);
      
    } /* Got thru cItems list */
     
     if (*foundContact == TRUE)
       break;
     
   } /* for i */
   
   /* so017.201 : Changed return Value */
   if (*foundContact == FALSE)
     RETVALUE(ROK);

   RETVALUE(ROK);
}



/*
*
*       Fun:   soUaDeregister
*
*       Desc:  Deregister UA
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soUaDeregister
(
SoCLegCb     *cLeg    /* Call Leg Cb */
)
#else
PUBLIC Void soUaDeregister(cLeg)
SoCLegCb     *cLeg;    /* Call Leg Cb */
#endif
{
  SoRegContactCb   *contactCb;   /* Contact Cb */

  /* Delete Contacts */
  while (cmHashListGetNext(&cLeg->regInfo.contactLst, (PTR)NULLP,
                           (PTR *) &contactCb) == ROK)
  {
    SO_UA_DEL_CONTACT(cLeg, contactCb);   
  }
  RETVOID;
  
}



/*
*
*       Fun:   soBldContactRegEvnt
*
*       Desc:  Build Registration message for re-registration
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soBldContactRegEvnt
(
SoEvnt          *evnt,       /* Event cb */
SoRegContactCb  *contactCb   /* Contact Cb */
)
#else
PRIVATE S16 soBldContactRegEvnt(evnt, contactCb)
SoEvnt           *evnt;        /* Event cb */
SoRegContactCb   *contactCb;   /* Contact Cb */
#endif
{
  SoEvnt        *origEvnt;    /* Original egister message */
  S16           ret;          /* return Value       */
  U16           i;            /* Index */
  SoHeaderSeq   *hdrSeq;      /* Header sequence to search */ 
  SoHeader      *curHdr;      /* Current header */
  Bool          foundContact; /* TRUE if contact match is found */
  SoContact     *contactHdr;  /* Contact header part of message */
  U32           cItem;        /* Counter for contact items */
  U32           numCItems;    /* Number of Contact Items */
  SoContactItem *contactItem; /* Single contact item to process */
  SoAddrSpec    *contactAddr; /* Contact address */
  U8            *key;         /* String version of contact */
  U16           keyLen;       /* length of address */
  U16           idx;          /*index */

  TRC3(soBldContactRegEvnt);
  
  /*--- so014.201: Initialize local variable ---*/
  ret          = ROK;
  foundContact = FALSE;
  origEvnt = contactCb->storedReq;
  
  if (contactCb->userRegPend == TRUE)
  {
    contactCb->storedReq = NULLP;
    if (soCmCreateEvent(&contactCb->storedReq, SOT_ET_REGISTER) != ROK)
    {
      RETVALUE(RFAILED);
    }
    ret = soUtlCpySoEvnt(contactCb->storedReq, origEvnt);
    if (ret != ROK)
    {
      contactCb->storedReq = NULL; /*chendh it was free in soUtlCpySoEvnt,if failure*/
      RETVALUE(RFAILED);
    }

    evnt->callLegId = origEvnt->callLegId;
    evnt->transId   = origEvnt->transId;

    hdrSeq = &contactCb->storedReq->t.request.request;

    i =0;

    while (i < hdrSeq->numComp.val)
    {
      foundContact = FALSE;
      
      curHdr = hdrSeq->header[i];
      if (SO_CMP_TKN_LIT(&curHdr->headerType, SO_HEADER_GEN_CONTACT) != TRUE)
      {
        i++;
        continue;
      }

      /* Contact header found - process */
      contactHdr = &curHdr->t.contact;

      cItem = 0;
      numCItems = SO_GET_NUM_COMP(&contactHdr->contactItems.numComp);

      while (cItem < numCItems)
      {
        contactItem = contactHdr->contactItems.contactItem[cItem];
                
        SO_ADDRSPEC_FROM_ADDRCH(contactAddr, &contactItem->contactAddrChoice);
        
        if (contactAddr == NULLP)
        {    
          RETVALUE(RFAILED);
        }   

        /* Calculate the key , based o the addr provided in conatct */
        if ((ret = soUtlCalcAddrKey(contactAddr, &key, &keyLen))
            != ROK)
        {
          if (key != NULLP)
            SOFREE(key, keyLen);
          cItem++;
          continue;
        }
        
        if ((keyLen == contactCb->keyLength) && 
            (!cmStrncmp(key, contactCb->key, keyLen)))
        {
          foundContact = TRUE;
          cItem++;
        }
        else
        {
          /* If the current contact is not the specified contact remove
             it from the contactHdr */
          for (idx = cItem+1; idx < numCItems; idx ++)
            contactHdr->contactItems.contactItem[idx-1] =
              contactHdr->contactItems.contactItem[idx];
          
          contactHdr->contactItems.contactItem[numCItems -1] = contactItem;
          
          /* Remove this parameter */
          ret = soCmShrinkList((Void ***)&contactHdr->contactItems.contactItem,
                        sizeof(SoContactItem),
                        &contactHdr->contactItems.numComp,
                        contactCb->storedReq);

          if (ret != ROK)
          {
            if (key != NULLP)
              SOFREE(key, keyLen);

            RETVALUE(RFAILED);
          }
          numCItems = SO_GET_NUM_COMP(&contactHdr->contactItems.numComp);
          
        }

        SOFREE(key, keyLen); 
        
      } /* while cItem */       

      /* if the specified contact is not found in the current header,
         delete the current header */
      if (foundContact != TRUE)
      {
        soCmRemoveHdrChoice(contactCb->storedReq, i, 
                            SO_HEADER_GEN_CONTACT);
      }
      else
        i++;
    } /* while i */

    contactCb->userRegPend = FALSE;

  } /* ReReg not done */

  RETVALUE(ROK);
}


/***************************************************************/
/*                 UA Core Utility Functions                   */
/***************************************************************/

/*
*
*       Fun:   soUaChkOutInvHdr
*
*       Desc:  This function validates/adds  the headers of an outgoing INVITE
*
*       Notes: 
*
*       File:  so_ua.c
*
*/

#ifdef ANSI
PRIVATE S16 soUaChkOutInvHdr
(
SoCLegCb *cLeg,     /* Call leg */  
SoEvnt   *evnt      /* Event */
)
#else
PRIVATE S16 soUaChkOutInvHdr(cLeg, evnt)
SoCLegCb *cLeg;     /* Call leg */ 
SoEvnt   *evnt;     /* Event */
#endif
{
  SoEntCb  *ent;  /* Entity */
  S16      ret;        /* return Value       */

  TRC2(soUaChkOutInvHdr);
  
  ret = SOT_ERR_NOERR;
  ent = cLeg->call->ent;
  
  if (ent == NULLP)
    RETVALUE(SOT_ERR_ENT_INVALID);
  
  /* Insert Allow header, if configured to do so and
     if one is not present already */
  if (ent->reCfg.hdrCfg.insAllow == TRUE)
    ret = soUtlAddAllowHdr(ent, evnt);


  /* Insert Supported header, if configured to do so and
     if one is not present already */
  if ((ret == SOT_ERR_NOERR) &&
      (ent->reCfg.hdrCfg.insSupported == TRUE))
    ret = soUtlAddSuppHdr(ent, evnt);
  

  /* Insert Expires header, if configured to do so and
     if one is not present already */
  if ((ret == SOT_ERR_NOERR) && 
      (ent->reCfg.hdrCfg.insExpires == TRUE))
    ret = soUtlAddExpires(ent, evnt);


  /* Insert Organization header, if configured to do so and
     if one is not present already */
  if ((ret == SOT_ERR_NOERR) &&
      (ent->reCfg.hdrCfg.insOrg.pres != NOTPRSNT))
    ret = soUtlAddOrgHdr(ent, evnt);


  /* Insert Subject header, if configured to do so and
     if one is not present already */
  if ((ret == SOT_ERR_NOERR) &&
      (ent->reCfg.hdrCfg.insSubject.pres != NOTPRSNT))
    ret = soUtlAddSubjectHdr(ent, evnt);

  /* Insert Date header, if configured to do so and
     if one is not present already */
  /* so038.201: Added error check condition*/
  if ((ret == SOT_ERR_NOERR) &&
      (ent->reCfg.hdrCfg.insDate == TRUE))
     ret = soUtlInsertDate(ent, evnt);

  if (ret != SOT_ERR_NOERR)
       RETVALUE(ret);

  /* If Reliable provisional response is supported, add the
     100 rel option tag */
#ifdef SO_RFC_3262
  if ((ret == SOT_ERR_NOERR) && /*chendh*/
  	ent->s.ua.reCfg.relProvRspReq == TRUE)
  {
    ret = soUtlAddRequireHdr(evnt, SO_OPTIONTAG_100REL);
  }
#endif

  RETVALUE(ret);

}





/*
*
*       Fun:   soUaChkIncInvHdr
*
*       Desc:  This function validates/adds  the headers of an incoming INVITE
*
*       Notes: 
*
*       File:  so_ua.c
*
*/

#ifdef ANSI
PRIVATE S16 soUaChkIncInvHdr
(
SoCLegCb *cLeg,     /* Call leg */  
SoEvnt   *evnt        /* Evnt */
)
#else
PRIVATE S16 soUaChkIncInvHdr(cLeg, evnt)
SoCLegCb *cLeg;     /* Call leg */ 
SoEvnt   *evnt;       /* Event */
#endif
{
  SoEntCb         *ent;       /* Entity */
  S16             ret;        /* return Value */

  TRC2(soUaChkIncInvHdr);

  ret = SOT_RSP_NONE;

  ent = cLeg->call->ent;
  
  if (ent == NULLP)
    RETVALUE(SOT_RSP_400_BAD_REQUEST);
  
  /* Start the Expires Tmr if required */
  soUaPrcExpiresHdr(cLeg, evnt);

  /* Store the allow event, if available, in the cleg */
  ret = soUtlStoreAllow(evnt, &cLeg->storedHdrs.peerAllow);
  if (ret != ROK)
    RETVALUE(SOT_RSP_400_BAD_REQUEST);

#ifdef SO_RFC_3262
  /* Check if a 100rel tag is present in the supported header. If yes,
     set the supported flag in call leg to TRUE */
  if (soUtlChkOptionTag(evnt, SO_HEADER_GEN_SUPPORTED,
                        SO_OPTIONTAG_100REL) == ROK)
  {
    cLeg->relProvRspInfo.peerSuppRelRsp = TRUE;
  } 

  if (soUtlChkOptionTag(evnt, SO_HEADER_GEN_REQUIRE,
                        SO_OPTIONTAG_100REL) == ROK)
  {
    /* If receiving side doesnot support reliable responses
       but the remote requires it, reject it with a 420 */
    if (ent->s.ua.reCfg.relProvRspSupp == FALSE)
    {
      RETVALUE(SOT_RSP_420_BAD_EXTENSION);
    }
    if (cLeg->relProvRspInfo.peerSuppRelRsp == FALSE)
      cLeg->relProvRspInfo.peerSuppRelRsp = TRUE;

    cLeg->relProvRspInfo.peerReqRelRsp = TRUE;
  } 
 
#endif /* SO_RFC_3262 */
  
  RETVALUE(ret);

}


/* so010.201 : Added new function */
/*
*
*       Fun:   soUaChkOut1xxHdr
*
*       Desc:  This function validates/adds  the headers of an outgoing INVITE
*
*       Notes: 
*
*       File:  so_ua.c
*
*/

#ifdef ANSI
PRIVATE S16 soUaChkOut1xxHdr
(
SoCLegCb *cLeg,    /* Cleg Cb */
SoEvnt   *evnt     /* Event Cb */
)
#else
PRIVATE S16 soUaChkOut1xxHdr(cLeg, evnt)
SoCLegCb *cLeg;    /* Cleg Cb */
SoEvnt   *evnt;    /* Event Cb */
#endif
{

   SoEntCb  *ent;  /* Entity */
   S16      ret;   /* return Value       */

   TRC3(soUaChkOut1xxHdr);
   
   /* so011.201: Init fields */
   ret = ROK;
   ent = cLeg->call->ent;

   /* No specific headers required for 100 */
   if (evnt->t.response.statusLine.statusCode.val == 100)
      RETVALUE(ROK);

   if (ent->reCfg.hdrCfg.insAllow == TRUE)
     ret = soUtlAddAllowHdr(ent, evnt);
   
   if ((ret == ROK) && (ent->reCfg.hdrCfg.insDate == TRUE))
     ret = soUtlInsertDate(ent, evnt);    

  if ((ret == ROK) &&
      (ent->reCfg.hdrCfg.insOrg.pres != NOTPRSNT))
    ret = soUtlAddOrgHdr(ent, evnt);

   if (ret != ROK)
     RETVALUE(SOT_ERR_ADD_HDR_FAILED);
   else
     RETVALUE(SOT_ERR_NOERR);
}





/*
*
*       Fun:   soUaChkOut2xxHdr
*
*       Desc:  This function validates/adds  the headers of an outgoing INVITE
*
*       Notes: 
*
*       File:  so_ua.c
*
*/

#ifdef ANSI
PRIVATE S16 soUaChkOut2xxHdr
(
SoCLegCb *cLeg,    /* Cleg Cb */
SoEvnt   *evnt     /* Event Cb */
)
#else
PRIVATE S16 soUaChkOut2xxHdr(cLeg, evnt)
SoCLegCb *cLeg;    /* Cleg Cb */
SoEvnt   *evnt;    /* Event Cb */
#endif
{

   SoEntCb  *ent;  /* Entity */
   S16      ret;   /* return Value       */
   Bool     selfAdded; /* so035.201: For adding contact header */

   TRC3(soUaChkOut2xxHdr);

   selfAdded = FALSE;
   
   ent = cLeg->call->ent;
   /* so035.201: selfAdded flag to add or replace contact header */
   ret = soUtlAddContactHdr(cLeg, evnt, LSO_TPTPROT_NULL, &selfAdded);
   if (ret != ROK)
    RETVALUE(SOT_ERR_ADD_HDR_FAILED);

   if (ent->reCfg.hdrCfg.insAllow == TRUE)
     ret = soUtlAddAllowHdr(ent, evnt);
   
   /* Insert Supported header, if configured to do so and
      if one is not present already */
   if ((ret == ROK) &&
       (ent->reCfg.hdrCfg.insSupported == TRUE))
     ret = soUtlAddSuppHdr(ent, evnt);
   
   
   if ((ret == ROK) && (ent->reCfg.hdrCfg.insAccept == TRUE))
   {
     ret = soUtlAddAcceptHdr(ent, evnt, &cLeg->storedHdrs.localAddr);
   }
   
   if (ret != ROK)
     RETVALUE(SOT_ERR_ADD_HDR_FAILED);
   else
     RETVALUE(SOT_ERR_NOERR);
}




/*
*
*       Fun:   soUaChkOutAckHdr
*
*       Desc:  This function validates/adds  the headers of an outgoing ACK
*
*       Notes: 
*
*       File:  so_ua.c
*
*/

#ifdef ANSI
PRIVATE S16 soUaChkOutAckHdr
(
SoCLegCb *cLeg,     /* Call leg */  
SoEvnt   *evnt        /* Event */
)
#else
PRIVATE S16 soUaChkOutAckHdr(cLeg, evnt)
SoCLegCb *cLeg;     /* Call leg */ 
SoEvnt   *evnt;       /* Event */
#endif
{
  SoEntCb  *ent;  /* Entity */
  S16      ret;        /* return Value       */

  SoCSeq     *cSeq;     /* CSeq Hdr */

  TRC2(soUaChkOutAckHdr);
  
  ret = SOT_ERR_NOERR;
  ent = cLeg->call->ent;
  
  if (ent == NULLP)
    RETVALUE(SOT_ERR_ENT_INVALID);
  
  ret = soCmFindHdrChoice(evnt, (U8 **) &cSeq,SO_HEADER_GEN_CSEQ);

  if (ret != ROK)
  {
    ret = soUtlInsertCSeq(cLeg, evnt, cLeg->ackCb.cSeqVal, NULLP);
    if (ret != ROK)
      RETVALUE(SOT_ERR_ADD_HDR_FAILED);
  }
  else
  {
    if ((cSeq->cSeqVal.pres == NOTPRSNT) ||
        (cLeg->ackCb.cSeqVal != cSeq->cSeqVal.val))
    {
      RETVALUE(SOT_ERR_CSEQ_UNACCEPTABLE);
    }
  }

  /* so019.201: Change to insert Date header */
  /* Insert Date header, if configured to do so and
     if one is not present already */
  if (ent->reCfg.hdrCfg.insDate == TRUE)
  {
    ret = soUtlInsertDate(ent, evnt);
    if (ret != SOT_ERR_NOERR)
      RETVALUE(ret);
  }

  RETVALUE(SOT_ERR_NOERR);

} /* soUaChkOutAckHdr */



/*
*       so019.201: New function to check the outgoing OPTION header  
*
*       Fun:   soUaChkOutOptionsHdr
*
*       Desc:  This function validates/adds  the headers of an outgoing INVITE
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaChkOutOptionsHdr
(
SoCLegCb *cLeg,    /* Call Leg Cb */ 
SoEvnt   *evnt     /* Event CB */
)
#else
PRIVATE S16 soUaChkOutOptionsHdr(cLeg, evnt)
SoCLegCb *cLeg;    /* Call Leg Cb */ 
SoEvnt   *evnt;    /* Event CB */
#endif
{
  SoEntCb *ent;   /* Entity Control Block */
  S16     ret;    /* return Value       */


  TRC3(soUaChkOutOptionsHdr);

  ent = cLeg->call->ent;
  ret = ROK;

  if (ent == NULLP)
    RETVALUE(ROK);

  if (ent->reCfg.hdrCfg.insAccept == TRUE)
  {
     ret = soUtlAddAcceptHdr(ent, evnt, &cLeg->storedHdrs.localAddr);
  }
  
  if (evnt->sipMessageType.val != SO_SIPMESSAGE_REQUEST)
  {
    /* Insert Allow header, if not already present */
    if ((ret == ROK) && (ent->reCfg.hdrCfg.insAllow == TRUE))
        ret = soUtlAddAllowHdr(ent, evnt);
    
    /* Insert Supported header, if not already present */
    if ((ret == ROK) && (ent->reCfg.hdrCfg.insSupported == TRUE))
      ret = soUtlAddSuppHdr(ent, evnt);
  }

  /* so019.201: Change to insert Date header */
  /* Insert Date header, if configured to do so and
     if one is not present already */
  if (ent->reCfg.hdrCfg.insDate == TRUE)
  {
    ret = soUtlInsertDate(ent, evnt);
    if (ret != SOT_ERR_NOERR)
      RETVALUE(ret);
  }

  RETVALUE(ret);
} /* soUaChkOutOptionsHdr */




/*
*       so019.201: Rename soUaChkOptionsHdr to soUaChkIncOptionsHdr  
*
*       Fun:   soUaChkIncOptionsHdr
*
*       Desc:  This function validates/adds  the headers of an outgoing INVITE
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaChkIncOptionsHdr
(
SoCLegCb *cLeg,    /* Call Leg Cb */ 
SoEvnt   *evnt     /* Event CB */
)
#else
PRIVATE S16 soUaChkIncOptionsHdr(cLeg, evnt)
SoCLegCb *cLeg;    /* Call Leg Cb */ 
SoEvnt   *evnt;    /* Event CB */
#endif
{
  SoEntCb *ent;   /* Entity Control Block */
  S16     ret;    /* return Value       */


  TRC3(soUaChkIncOptionsHdr);

  ent = cLeg->call->ent;
  ret = ROK;

  if (ent == NULLP)
    RETVALUE(ROK);

  if (ent->reCfg.hdrCfg.insAccept == TRUE)
  {
     ret = soUtlAddAcceptHdr(ent, evnt, &cLeg->storedHdrs.localAddr);
  }
  
  if (evnt->sipMessageType.val != SO_SIPMESSAGE_REQUEST)
  {
    /* Insert Allow header, if not already present */
    if ((ret == ROK) && (ent->reCfg.hdrCfg.insAllow == TRUE))
        ret = soUtlAddAllowHdr(ent, evnt);
    
    /* Insert Supported header, if not already present */
    if ((ret == ROK) && (ent->reCfg.hdrCfg.insSupported == TRUE))
      ret = soUtlAddSuppHdr(ent, evnt);
  }

  RETVALUE(ret);
} /* soUaChkIncOptionsHdr */

#ifdef SO_UPDATE
/*
*
*       Fun:   soUaChkUpdateHdr
*
*       Desc:  This function validates that the UAS also supports the update
*              method
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaChkUpdateHdr
(
SoCLegCb *cLeg,    /* Call Leg Cb */ 
SoEvnt   *evnt     /* Event CB */
)
#else
PRIVATE S16 soUaChkUpdateHdr(cLeg, evnt)
SoCLegCb *cLeg;    /* Call Leg Cb */ 
SoEvnt   *evnt;    /* Event CB */
#endif
{
  U16 i;
  /* so010.201: Change to insert supported header */
  S16     ret;    /* return Value       */
  SoEntCb *ent;   /* Entity Control Block */

  TRC3(soUaChkUpdateHdr);

  /* so010.201: Change to insert supported header */
  ent = cLeg->call->ent;
  ret = ROK;

  if (ent == NULLP)
    RETVALUE(ROK);

  if ((cLeg->clegState <= SO_CLEG_STATE_INITIAL) || 
      (cLeg->clegState == SO_CLEG_STATE_PROCEEDING))
     RETVALUE(RFAILED);

  for (i = 0; i < SO_GET_NUM_COMP(&cLeg->storedHdrs.peerAllow.numComp); i++)
  {
     if ((SO_CMP_TKN_LIT(&cLeg->storedHdrs.peerAllow.method[i]->type, \
                         SO_METHOD_METHODSTD)) &&
         (SO_CMP_TKN_LIT(&cLeg->storedHdrs.peerAllow.method[i]->t.std, \
                         SO_METHODSTD_UPDATE)))
     {
        /* so011.201: UPDATE is supported, check if we have to add
           Supported header */
        /* so010.201: Insert Supported header, if not already present */
        if (ent->reCfg.hdrCfg.insSupported == TRUE)
           ret = soUtlAddSuppHdr(ent, evnt);

        RETVALUE(ret);
     }
  }

  RETVALUE(SOT_ERR_METHOD_NOTSUPP);

} /* soUaChkUpdateHdr */

#endif /* SO_UPDATE */


/*
*       so019.201: New function to check outgoing BYE header 
*
*       Fun:   soUaChkOutByeHdr
*
*       Desc:  Checks for outgoing Bye Header
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaChkOutByeHdr
(
SoCLegCb    *cLeg,     /* Call Leg Cb */
SoEvnt      *evnt      /* Event Cb */
)
#else
PRIVATE S16 soUaChkOutByeHdr(cLeg, evnt)
SoCLegCb    *cLeg;     /* Call Leg Cb */
SoEvnt      *evnt;     /* Event Cb */
#endif
{

  S16     ret;    /* return Value       */
  SoEntCb *ent;   /* Entity Control Block */

  TRC3(soUaChkOutByeHdr);

  ent = cLeg->call->ent;
  ret = ROK;

  /* Insert Date header, if configured to do so and
     if one is not present already */
  if (ent->reCfg.hdrCfg.insDate == TRUE)
  {
    ret = soUtlInsertDate(ent, evnt);
    if (ret != SOT_ERR_NOERR)
      RETVALUE(ret);
  }

  RETVALUE(SOT_ERR_NOERR);
} /* soUaChkOutByeHdr */


#ifdef SO_INSTMSG
/*
*       so019.201: New function to check outgoing MESSAGE header 
*
*       Fun:   soUaChkOutMessageHdr
*
*       Desc:  Checks for OutGoing Instant Message Header
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaChkOutMessageHdr
(
SoCLegCb    *cLeg,     /* Call Leg Cb */
SoEvnt      *evnt      /* Event Cb */
)
#else
PRIVATE S16 soUaChkOutMessageHdr(cLeg, evnt)
SoCLegCb    *cLeg;     /* Call Leg Cb */
SoEvnt      *evnt;     /* Event Cb */
#endif
{

  SoContact    *contact;       /* Ptr to contact    */
  S16     ret;    /* return Value       */
  SoEntCb *ent;   /* Entity Control Block */

  TRC3(soUaChkOutMessageHdr);

  ent = cLeg->call->ent;
  ret = ROK;

  if (soCmFindHdrChoice(evnt, (U8 **) &contact,
                        SO_HEADER_GEN_CONTACT) == ROK)
    RETVALUE(SOT_ERR_INVALID_HDR);

  /* Insert Date header, if configured to do so and
     if one is not present already */
  if (ent->reCfg.hdrCfg.insDate == TRUE)
  {
    ret = soUtlInsertDate(ent, evnt);
    if (ret != SOT_ERR_NOERR)
      RETVALUE(ret);
  }

  RETVALUE(SOT_ERR_NOERR);
} /* soUaChkOutMessageHdr */

#endif /* SO_INSTMSG */



#ifdef SO_INSTMSG
/*
*       so019.201: Rename soUaChkMessageHdr to soUaChkOutMessageHdr 
*
*       Fun:   soUaChkIncMessageHdr
*
*       Desc:  Checks for In Coming Instant Message Header
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaChkIncMessageHdr
(
SoCLegCb    *cLeg,     /* Call Leg Cb */
SoEvnt      *evnt      /* Event Cb */
)
#else
PRIVATE S16 soUaChkIncMessageHdr(cLeg, evnt)
SoCLegCb    *cLeg;     /* Call Leg Cb */
SoEvnt      *evnt;     /* Event Cb */
#endif
{

  SoContact    *contact;       /* Ptr to contact    */

  TRC3(soUaChkIncMessageHdr);

  if (soCmFindHdrChoice(evnt, (U8 **) &contact,
                        SO_HEADER_GEN_CONTACT) == ROK)
    RETVALUE(SOT_ERR_INVALID_HDR);

  RETVALUE(SOT_ERR_NOERR);
} /* soUaChkIncMessageHdr */

#endif /* SO_INSTMSG */



/*
*
*       Fun:   soUaChkOutCancelHdr
*
*       Desc:  This function validates the header for an incoming CANCEl
*              Require & PROXY-REQUIRE header cannot be present in a CANCEL
*
*       Notes: 
*
*       File:  so_ua.c
*
*/

#ifdef ANSI
PRIVATE S16 soUaChkOutCancelHdr
(
SoCLegCb   *cLeg,       /* Call leg */  
SoEvnt     *evnt,       /* Event */
SoTransCb  *transCb     /* Transaction to be cancelled */
)
#else
PRIVATE S16 soUaChkOutCancelHdr(cLeg, evnt, transCb)
SoCLegCb   *cLeg;       /* Call leg */ 
SoEvnt     *evnt;       /* Event */
SoTransCb  *transCb;    /* Transaction to be cancelled */
#endif
{
  SoEntCb         *ent;          /* Entity */
  SoRoute         *route;
  SoTknStrOSXLLst *require;      /* require structure in message */
  SoTknStrOSXLLst *prxyRequire;  /* require structure in message */
  U16             hdrIdx;        /* Index of header in message      */
  SoCSeq          *cSeq;         /* CSeq Value */
  SoVia           *via;          /* VIA header */
  S16             ret;           /* Return Value */

  TRC2(soUaChkOutCancelHdr);

  /*--- so014.201: Initialize local variable ---*/
  ret = ROK;
  ent = cLeg->call->ent;

  if (soCmFindHdrChIndex(evnt, (U8 **) &require, &hdrIdx,
                        SO_HEADER_GEN_REQUIRE) == ROK)
  {
    /* Remove The Require header */
    soCmRemoveHdrChoice(evnt, hdrIdx, SO_HEADER_GEN_REQUIRE);
  }

  if (soCmFindHdrChIndex(evnt, (U8 **) &prxyRequire, &hdrIdx,
                        SO_HEADER_GEN_PROXYREQUIRE) == ROK)
  {
    /* Remove The Require header */
    soCmRemoveHdrChoice(evnt, hdrIdx, SO_HEADER_GEN_PROXYREQUIRE);

  }

  /* Copy the CSEQ Value from INVITE Transaction */
  ret = soCmFindHdrChoice(evnt, (U8 **) &cSeq,SO_HEADER_GEN_CSEQ);

  if (ret == ROK)
  {
    if ((cSeq->cSeqVal.pres == NOTPRSNT) ||
        (transCb->transCSeq != cSeq->cSeqVal.val))
    {
      RETVALUE(SOT_ERR_CSEQ_UNACCEPTABLE);
    }
  }
  else
  {
    ret = soUtlInsertCSeq(cLeg, evnt, transCb->transCSeq, NULLP);
    if (ret != ROK)
      RETVALUE(SOT_ERR_ADD_HDR_FAILED);
  }

  /* so001.201: Copy the VIA from INVITE Transaction */
  if (soCmFindHdrChIndex(evnt, (U8 **) &via, &hdrIdx,
                         SO_HEADER_GEN_VIA) == ROK)
  {
    soCmRemoveHdrChoice(evnt, hdrIdx, SO_HEADER_GEN_VIA);
  }
  
  ret = soCmCreateHdrChoice (evnt, (U8 **) &via, SO_HEADER_GEN_VIA);
  if (ret != ROK)
      RETVALUE(SOT_ERR_ADD_HDR_FAILED);

  ret = soUtlCpySoVia (via, &transCb->via, &evnt->memCp);
  if (ret != ROK)
      RETVALUE(SOT_ERR_ADD_HDR_FAILED);

  /* so014.201: Copy the Route from INVITE Transaction */
  if (soCmFindHdrChIndex(evnt, (U8 **) &route, &hdrIdx,
                         SO_HEADER_REQ_ROUTE) == ROK)
  {
    soCmRemoveHdrChoice(evnt, hdrIdx, SO_HEADER_REQ_ROUTE);
  }
  
  /* 
   * If Route Was Send In Original INVITE, CANCEL Must Have
   * Same Route Header.
   */
  if (transCb->route.numComp.pres && transCb->route.numComp.val)
  {
      ret = soCmCreateHdrChoice (evnt, (U8 **) &route, SO_HEADER_REQ_ROUTE);
      if (ret != ROK)
          RETVALUE (SOT_ERR_ADD_HDR_FAILED);
      
      ret = soUtlCpySoRoute (route, &transCb->route, &evnt->memCp);
      if (ret != ROK)
          RETVALUE (SOT_ERR_ADD_HDR_FAILED);
  }

  /* so014.201: Copy the Request URI from INVITE Transaction */
  cmMemset ((U8 *)&evnt->t.request.requestLine.addrSpec,
            0, 
            sizeof (SoAddrSpec));

  ret = soUtlCpySoAddrSpec (&evnt->t.request.requestLine.addrSpec,
                            &transCb->origReqURI,
                            &evnt->memCp);
  if (ret != ROK)
    RETVALUE (RFAILED);
  
  /* so019.201: Change to insert Date header */
  /* Insert Date header, if configured to do so and
     if one is not present already */
  if (ent->reCfg.hdrCfg.insDate == TRUE)
  {
    ret = soUtlInsertDate(ent, evnt);
    if (ret != SOT_ERR_NOERR)
      RETVALUE(ret);
  }

  RETVALUE(ROK);
} /* soUaChkOutCancelHdr */





/*
*
*       Fun:   soUaChkIncCancelHdr
*
*       Desc:  This function validates the header for an incoming CANCEl
*              Require & PROXY-REQUIRE header cannot be present in a CANCEL
*
*       Notes: 
*
*       File:  so_ua.c
*
*/

#ifdef ANSI
PRIVATE S16 soUaChkIncCancelHdr
(
SoCLegCb *cLeg,       /* Call leg */  
SoEvnt   *evnt        /* Event */
)
#else
PRIVATE S16 soUaChkIncCancelHdr(cLeg, evnt)
SoCLegCb *cLeg;       /* Call leg */ 
SoEvnt   *evnt;       /* Event */
#endif
{
  SoEntCb         *ent;          /* Entity */
  SoTknStrOSXLLst *require;      /* require structure in message */
  SoTknStrOSXLLst *prxyRequire;  /* require structure in message */

  TRC2(soUaChkIncCancelHdr);

  ent = cLeg->call->ent;

  if (soCmFindHdrChoice(evnt, (U8 **) &require,
                        SO_HEADER_GEN_REQUIRE) == ROK)
    RETVALUE(RFAILED);

  if (soCmFindHdrChoice(evnt, (U8 **) &prxyRequire,
                        SO_HEADER_GEN_PROXYREQUIRE) == ROK)
    RETVALUE(RFAILED);

  RETVALUE(ROK);
} /* soUaChkIncCancelHdr */





/*
*
*       Fun:   soUaChkInfoReqHdr
*
*       Desc:  This function validates/adds  the headers of an Info 
*
*       Notes: 
*
*       File:  so_ua.c
*
*/

#ifdef ANSI
PRIVATE S16 soUaChkInfoReqHdr
(
SoCLegCb *cLeg,     /* Call leg */  
SoEvnt *evnt        /* Event */
)
#else
PRIVATE S16 soUaChkInfoReqHdr(cLeg, evnt)
SoCLegCb *cLeg;     /* Call leg */ 
SoEvnt *evnt;       /* Event */
#endif
{
   SoEntCb  *ent;  /* Entity */
   S16      ret;   /* Retuen Value */

   TRC2(soUaChkInfoReqHdr);

   ret = SOT_ERR_NOERR;
   ent = cLeg->call->ent;
  
   if (ent == NULLP)
      RETVALUE(SOT_ERR_ENT_INVALID);


   /* Insert Expires header, if configured to do so and
      if one is not present already */
   if ((ret == SOT_ERR_NOERR) && 
      (ent->reCfg.hdrCfg.insExpires == TRUE))
      ret = soUtlAddExpires(ent, evnt);


   /* Insert Organization header, if configured to do so and
     if one is not present already */
   if ((ret == SOT_ERR_NOERR) &&
      (ent->reCfg.hdrCfg.insOrg.pres != NOTPRSNT))
      ret = soUtlAddOrgHdr(ent, evnt);


   if ((ret == SOT_ERR_NOERR) &&
      (ent->reCfg.hdrCfg.insAccept == TRUE))
     ret = soUtlAddAcceptHdr(ent, evnt, &cLeg->storedHdrs.localAddr);

    if (ret != ROK)
       RETVALUE(SOT_ERR_ADD_HDR_FAILED);
    else
       RETVALUE(SOT_ERR_NOERR);
} /* end of soUaChkInfoReqHdr */




/*
*
*       Fun:   soUaChkInfoRspHdr
*
*       Desc:  This function validates/adds  the headers of an Info Response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/

#ifdef ANSI
PRIVATE S16 soUaChkInfoRspHdr
(
SoCLegCb  *cLeg,     /* Call leg */  
SoEvnt    *evnt      /* Event */
)
#else
PRIVATE S16 soUaChkInfoRspHdr(cLeg, evnt)
SoCLegCb  *cLeg;     /* Call leg */ 
SoEvnt    *evnt;     /* Event */
#endif
{
   SoEntCb      *ent;  /* Entity        */
   S16          ret;   /* return Value  */

   TRC2(soUaChkInfoRspHdr);

   ent = cLeg->call->ent;
   ret = SOT_ERR_NOERR;
   if (ent == NULLP)
      RETVALUE(SOT_ERR_ENT_INVALID);

   /* Insert Allow header, if configured to do so and
      if one is not present already */
   if (ent->reCfg.hdrCfg.insAllow == TRUE)
      ret = soUtlAddAllowHdr(ent, evnt);

   if (ret != ROK)
      RETVALUE(SOT_ERR_ADD_HDR_FAILED);
   else
      RETVALUE(SOT_ERR_NOERR);
} /* end of soUaChkInfoRSpHdr */



#ifdef SO_EVENT
/*
*
*       Fun:   soUaChkOutEventHdr
*
*       Desc:  This function validates/adds  the headers of an outgoing
*              Subscribe/ Notify message 
*
*       Notes: 
*
*       File:  so_ua.c
*
*/

#ifdef ANSI
PRIVATE S16 soUaChkOutEventHdr
(
SoCLegCb *cLeg,     /* Call leg */  
SoEvnt   *evnt        /* Event */
)
#else
PRIVATE S16 soUaChkOutEventHdr(cLeg, evnt)
SoCLegCb *cLeg;     /* Call leg */ 
SoEvnt   *evnt;       /* Event */
#endif
{
  SoEntCb  *ent;  /* Entity */
  S16      ret;        /* return Value       */

  TRC2(soUaChkOutEventHdr);
  
  ret = SOT_ERR_NOERR;
  ent = cLeg->call->ent;
  
  if (ent == NULLP)
    RETVALUE(SOT_ERR_ENT_INVALID);
  

  /* Insert Contact header, if configured to do so and
     if one is not present already */

  /* Commented out, taken care after DNS query
  ret = soUtlAddContactHdr(cLeg, evnt, LSO_TPTPROT_NULL); 
  */

  /* so019.201: Change to insert Date header */
  /* Insert Date header, if configured to do so and
     if one is not present already */
  if (ent->reCfg.hdrCfg.insDate == TRUE)
  {
    ret = soUtlInsertDate(ent, evnt);
    if (ret != SOT_ERR_NOERR)
      RETVALUE(ret);
  }

  RETVALUE(ret);

}
#endif



/*
*
*       Fun:   soUaChkLocalUserReg
*
*       Desc:  Check is user is registered locally (if cfgd to so so)
*
*       Notes: 
*
*       File:  so_ua.c
*
*/

#ifdef ANSI
PRIVATE S16 soUaChkLocalUserReg
(
SoCLegCb  *cLeg,     /* Call leg */  
SoEvnt    *evnt,     /* Event */
U8        direction  /* Call Direction */
)
#else
PRIVATE S16 soUaChkLocalUserReg(cLeg, evnt, direction)
SoCLegCb  *cLeg;     /* Call leg */ 
SoEvnt    *evnt;     /* Event */
U8        direction;  /* Call Direction */
#endif
{
  SoEntCb        *ent;      /* Entity Cb */
  S16            ret;       /* return Value */
  SoAddrSpec     *addrSpec;  /* Addres Spec  */
  SoClRegEnt     *regEntry; /* Entry stored in cache */
  U16            findCount; /* Counter */
  U16            statusCode; /* Response Status Code */
        
  ent = cLeg->call->ent;
  statusCode = 0;


  /* user is localy registered */
  SO_ADDRSPEC_FROM_ADDRCH(addrSpec, &cLeg->storedHdrs.localAddr.addrCh);

  ret = soClFindUser (&ent->s.ua.localUsrReg, addrSpec,
                      &regEntry, &findCount);
  if (ret != ROK)
  {
    if (ent->s.ua.reCfg.chkLocUsrReg != TRUE)
      RETVALUE(SOT_ERR_NOERR);
    
    /* Update Err Statistics */
    ent->errSts.unkwnUser++;
    soCb.sts.errSts.unkwnUser++;

    if (direction == SO_USER)
      RETVALUE(SOT_ERR_USER_LOC_REG_REQD);
    else
      RETVALUE(SOT_RSP_404_NOT_FOUND);
  }

  /* this is not gateway */
  if (findCount == 0)
  {    
    if (ent->s.ua.reCfg.chkLocUsrReg != TRUE)
      RETVALUE(SOT_ERR_NOERR);

    /* Update Err Statistics */
    ent->errSts.unkwnUser++;
    soCb.sts.errSts.unkwnUser++;

    if (direction == SO_USER)
      RETVALUE(SOT_ERR_USER_LOC_REG_REQD);
    else
      RETVALUE(SOT_RSP_404_NOT_FOUND);
  }

  if (regEntry->tempUnavail == TRUE)
  {
    /* update statistics */
    ent->errSts.usrUnavail++;
    soCb.sts.errSts.usrUnavail++;

    if (direction == SO_USER)
      RETVALUE(SOT_ERR_USER_UNAVAIL);
    else
      RETVALUE(SOT_RSP_480_TEMP_UNAVAIL);
  }


  RETVALUE(SOT_ERR_NOERR);

}





/* *** REGISTRATION Related Functions ****  */


/*
*
*       Fun:   soUaChkThirdPartyReg
*
*       Desc:  Check if Registration is for a third party 
*              and if it is allowed.
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaChkThirdPartyReg
(
SoEntCb  *ent,           /* Entity */
SoEvnt   *evnt,           /* Event   */
SoAddress **to,          /* to address */
SoAddress **from,        /* From address */
Bool      *thirdPartyReg /* Third party Reg is True/not */
)
#else
PRIVATE S16 soUaChkThirdPartyReg(ent, evnt, to, from, thirdPartyReg)
SoEntCb   *ent;           /* Entity */
SoEvnt    *evnt;           /* Event   */
SoAddress **to;           /* to address */
SoAddress **from;         /* From address */
Bool      *thirdPartyReg; /* Third party Reg is True/not */
#endif
{

  Bool    addrMatch;   /* Addresses are the same/ not */
  S16     ret;         /* Return Value */

  TRC3(soUaChkThirdPartyReg);

  *thirdPartyReg = FALSE;

   /* Find From header in the event structure */
   ret = soCmFindHdrChoice(evnt, (U8 **) from,
                               SO_HEADER_GEN_FROM);
   /* From not found */
   if (ret != ROK)
   {
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
         "soUaCmpToFrom: From header missing\n"));
      RETVALUE(RFAILED);
   }

   /* Find To header in the evnt structure */
   ret = soCmFindHdrChoice(evnt, (U8 **) to,
                              SO_HEADER_GEN_TO);
   /* To not found */
   if (ret != ROK)
   {
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
         "soUaCmpToFrom: To header missing\n"));
      RETVALUE(RFAILED);
   }

   addrMatch = FALSE;
   ret = soUtlCmpSoAddress(*to, *from);
   
   if (ret != ROK)
   {
     if (ent->s.ua.reCfg.alw3rdParty != TRUE)
     {
       RETVALUE(RFAILED);
     }
     else
       *thirdPartyReg = TRUE;
   }
  
   RETVALUE(ROK);
}




/***********************************************************************
*
*       Fun:    soUaChkRegHdr
*
*       Desc:   Handles a remote registration request from call control
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_ua.c
*
**********************************************************************/
#ifdef ANSI
PRIVATE S16 soUaChkRegHdr
(
SoEntCb    *ent,         /* Entity Cb */
SoEvnt     *evnt        /* Event */
)
#else
PRIVATE S16 soUaChkRegHdr(ent, evnt)
SoEntCb    *ent;         /* Entity Cb */
SoEvnt     *evnt;        /* Event */
#endif
{
  SoUACb        *uaEnt;         /* UA entity */
  SoRequestLine *reqLine;       /* message request line */
  SoHostPort    *fromHostPort;  /* From SoHostPort structure */
  S16           ret;            /* return Value       */
  SoRoute       *route;         /* Specified Route */
  /* so016.201 : If no Expires header then insert Expires header */
  TknU32        *expires;

  TRC3(soUaChkRegHdr);

  uaEnt = &ent->s.ua;

  reqLine = &evnt->t.request.requestLine;

  /* so019.201: Change to insert Date header */
  /* Insert Date header, if configured to do so and
     if one is not present already */
  if (ent->reCfg.hdrCfg.insDate == TRUE)
  {
    ret = soUtlInsertDate(ent, evnt);
    if (ret != SOT_ERR_NOERR)
      RETVALUE(ret);
  }

  /* so016.201 : If no Expires header then insert Expires header */
  ret = soCmFindHdrChoice(evnt, (U8 **)&expires, SO_HEADER_GEN_EXPIRES);
  if (ret != ROK)
  {
     /* so021.201 Check if expired hdr is configured to be inserted */
     if ((ent->reCfg.hdrCfg.insExpires == TRUE) && 
          uaEnt->reCfg.dfltExpiresInRegister != 0)
     {
        ret = soCmCreateHdrChoice (evnt, (U8 **) &expires, 
                                   SO_HEADER_GEN_EXPIRES);
        if (ret == ROK)
        {
           SO_FILL_TKNU32(expires, 
                          (uaEnt->reCfg.dfltExpiresInRegister));
        }
        else
        {
           RETVALUE(SOT_ERR_ADD_HDR_FAILED);
        }
     }
  }

  if (reqLine->addrSpec.addrSpecType.pres != NOTPRSNT)
    RETVALUE(SOT_ERR_NOERR);

  /* Check if Route is present. If yes return OK since
   the Request URI will get filled at a later point */
  ret = soCmFindHdrChoice(evnt, (U8 **)&route, SO_HEADER_REQ_ROUTE);
  if (ret == ROK)
    RETVALUE(SOT_ERR_NOERR);

  /* Check if registrar address is pre-configured */
  if ((uaEnt->reCfg.regSrvAddr.type != CM_TPTADDR_IPV4) &&
      (uaEnt->reCfg.regSrvAddr.type != CM_TPTADDR_IPV6))
    RETVALUE(SOT_ERR_NO_REG_SVR_CFG);

  /* Build complete requestLine */
  reqLine = &evnt->t.request.requestLine;
  reqLine->pres.pres = PRSNT_NODEF;
  reqLine->method.type.pres  = PRSNT_NODEF;
  reqLine->method.type.val   = SO_METHOD_METHODSTD;
  reqLine->method.t.std.pres = PRSNT_NODEF;
  reqLine->method.t.std.val  = SO_METHODSTD_REGISTER;

  /* use registrar server address, if present */
  if ((uaEnt->reCfg.regSrvAddr.type == CM_TPTADDR_IPV4) ||
      (uaEnt->reCfg.regSrvAddr.type == CM_TPTADDR_IPV6))
  {
    fromHostPort = &reqLine->addrSpec.t.sipUrl.hostPort;
    ret = soCmTptAddrToHostPort(fromHostPort,
                                &uaEnt->reCfg.regSrvAddr, evnt);
    if (ret == ROK)
    {
      SO_FILL_TKNU8(&reqLine->addrSpec.addrSpecType, 
                    SO_ADDRSPEC_SIPURL);
      SO_FILL_TKNU8(&reqLine->addrSpec.t.sipUrl.pres, PRSNT_NODEF);
      SO_FILL_TKNU8(&reqLine->addrSpec.t.sipUrl.hostPort.pres,
                    PRSNT_NODEF);
      RETVALUE(SOT_ERR_NOERR);
    }
  }

  if (ret != ROK)
    RETVALUE(SOT_ERR_NO_REG_SVR_CFG);

  RETVALUE(SOT_ERR_NOERR);
}




/*****************************************************************************
*
*      Fun:   soUaCalcRegClegKey
*
*      Desc:  Calculate key for an address. The key is
*             the normalized address
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes: 
*      File:  so_ua.c
*
*****************************************************************************/
#ifdef ANSI
PRIVATE S16 soUaCalcRegClegKey
(
SoEvnt          *evnt,   /* Event Cb */
U8              **key,   /* String version of contact */
U16             *keyLen  /* length of address */
)
#else
PRIVATE S16 soUaCalcRegClegKey(evnt, key, keyLen)
SoEvnt          *evnt;    /* Event Cb */
U8              **key;    /* String version of contact */
U16             *keyLen;  /* length of address */
#endif
{
    S16        ret;       /* return Value */
    U8         *tmpkey;   /* temp key */
    U16        tmpLen1;   /* Key length */
    U16        tmpLen2;   /* key Length */
    SoAddress  *to;       /* To address */
    SoAddress  *from;     /* From Address */

    TRC2(soUaCalcRegClegKey);

    ret = ROK;

    /* Find To header in the event structure */
    ret = soCmFindHdrChoice(evnt, (U8 **) &to,
                              SO_HEADER_GEN_TO);
    /* To not found */
    if (ret != ROK)
    {
      RETVALUE(RFAILED);
    }

    /* Find To header in the event structure */
    ret = soCmFindHdrChoice(evnt, (U8 **) &from,
                              SO_HEADER_GEN_FROM);
    /* To not found */
    if (ret != ROK)
    {
      RETVALUE(RFAILED);
    }



    /* get length */
    ret = soCmNormAddress((U8 *)NULLP, to, &tmpLen1, FALSE);
    if (ret != ROK)
    {
      RETVALUE(RFAILED);
    }

    /* get length */
    ret = soCmNormAddress((U8 *)NULLP, from, &tmpLen2, FALSE);
    if (ret != ROK)
    {
      RETVALUE(RFAILED);
    }

   *keyLen = tmpLen1 + tmpLen2;

   SOALLOC(key, *keyLen);
   
   if (*key == NULLP)
     RETVALUE(RFAILED);

   if (tmpLen1 >tmpLen2)
   {
     SOALLOC(&tmpkey, tmpLen1);
     if (tmpkey == NULLP)
     {
       SOFREE(*key, *keyLen);
       *key = NULLP;
       RETVALUE(RFAILED);
     }
   }
   else
   {
     SOALLOC(&tmpkey, tmpLen2);
     if (tmpkey == NULLP)
     {
       SOFREE(*key, *keyLen);
       *key = NULLP;
       RETVALUE(RFAILED);
     }
   }

   /* Normalize to */
   ret = soCmNormAddress((U8 *)tmpkey, to, &tmpLen1, FALSE);

   if (ret == ROK)
   {
     cmMemcpy(*key, tmpkey, tmpLen1);
     
     cmMemset((U8 *)tmpkey,0,tmpLen2);
     /* Normalize to */
     ret = soCmNormAddress((U8 *)tmpkey, from, &tmpLen2, FALSE);
     
     if (ret == ROK)
     {
       cmMemcpy((*key)+tmpLen1, tmpkey, tmpLen2);
     }
   }
    
   if (tmpLen1 >tmpLen2)
   {
     SOFREE(tmpkey, tmpLen1);
   }
   else
   {
     SOFREE(tmpkey, tmpLen2);
   }
 
   RETVALUE(ROK);
} /* soUaCalcRegClegKey */


/***********************************************************************
*
*       Fun:    soUaFindRegCb
*
*       Desc:   Function locates a cb associated with a registrar
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_ua.c
*
**********************************************************************/
#ifdef ANSI
PRIVATE SoUaRegCb *soUaFindRegCb
(
SoEntCb    *ent,         /* Entity Cb */
SoEvnt     *evnt,        /* Event */
U8         **key,        /* String version of contact */
U16        *keyLen       /* length of address */
)
#else
PRIVATE SoUaRegCb *soUaFindRegCb(ent, evnt, key, keyLen)
SoEntCb    *ent;         /* Entity Cb */
SoEvnt     *evnt;        /* Event */
U8         **key;        /* String version of contact */
U16        *keyLen;      /* length of address */
#endif
{

  SoUaRegCb  *regCb;     /* Registrar Cb */
  S16        ret;        /* Return Value */

  TRC3(soUaFindRegCb);

  /* Calculate key based on Request URI address spec */
  ret = soUtlCalcAddrKey(&evnt->t.request.requestLine.addrSpec, key, keyLen);
  if (ret != SOT_ERR_NOERR)
  {
    *key = NULLP;
    RETVALUE(NULLP);
  }

  /* try to locate regCb*/
  ret = cmHashListFind(&ent->s.ua.regCbLst,(U8 *)(*key),
                       (U16)(*keyLen),0,(PTR *)&regCb);
  if (ret != ROK)
    RETVALUE(NULLP);

  RETVALUE(regCb);
}



/***********************************************************************
*
*       Fun:    soUaCreateRegCb
*
*       Desc:   Function creates a new cb to be associated with a 
*               registrar
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_ua.c
*
**********************************************************************/
#ifdef ANSI
PRIVATE SoUaRegCb *soUaCreateRegCb
(
SoEntCb    *ent,         /* Entity Cb */
U8         **key,        /* String version of contact */
U16        *keyLen       /* length of address */
)
#else
PRIVATE SoUaRegCb *soUaCreateRegCb(ent, key, keyLen)
SoEntCb    *ent;         /* Entity Cb */
U8         **key;        /* String version of contact */
U16        *keyLen;      /* length of address */
#endif
{
  SoUaRegCb  *regCb;     /* Registrar Cb */
  S16        ret;        /* Return Value */

  /*--- so014.201: Initialize local variable ---*/
  ret   = ROK;
  regCb = NULLP;

  SOALLOC(&regCb, sizeof(SoUaRegCb));

  if (regCb == NULLP)
    RETVALUE(NULLP);

  regCb->currCSeq = SO_CSEQ_START;
  regCb->normReqURILen = *keyLen;

  /* Store normalized reqURI in regCb */
  SOALLOC(&regCb->normReqURI, regCb->normReqURILen);
  if (regCb->normReqURI == NULLP)
  {
    SOFREE(regCb, sizeof(SoUaRegCb));
    RETVALUE(NULLP);
  }

  cmMemcpy(regCb->normReqURI, *key, *keyLen);

  ret = cmHashListInsert(&ent->s.ua.regCbLst, (PTR)regCb,
                         (U8 *)regCb->normReqURI,
                         (U16)regCb->normReqURILen);
  if (ret != ROK)
  {
    SOFREE(regCb->normReqURI, regCb->normReqURILen);
    SOFREE(regCb, sizeof(SoUaRegCb));
    RETVALUE(NULLP);
  }
                         
  RETVALUE(regCb);
} /* soUaCreateRegCb */





/*****************************************************************************
*
*      Fun:   soUaDeleteRegCb
*
*      Desc:  Clear the regCb and all contacts associated with it
*
*      Ret:   ROK     - successful
*             RFAILED - unsuccessful
*
*      Notes: 
*      File:  so_ua.c
*
*****************************************************************************/
#ifdef ANSI
PUBLIC S16 soUaDeleteRegCb
(
SoEntCb   *ent,     /* Entity Cb */
SoUaRegCb *regCb    /* registrar Info cb */
)
#else
PUBLIC S16 soUaDeleteRegCb(ent, regCb)
SoEntCb   *ent;     /* Entity Cb */
SoUaRegCb *regCb;   /* registrar Info cb */
#endif
{

   TRC2(soUaDeleteRegCb);

   if (regCb == NULLP)
     RETVALUE(ROK);

   if (regCb->normReqURI != NULLP)
   {
     SOFREE(regCb->normReqURI, regCb->normReqURILen);
   }

   cmHashListDelete (&ent->s.ua.regCbLst, (PTR) regCb);

   SOFREE(regCb, sizeof(SoUaRegCb));

   RETVALUE(ROK);
} /*soUaDeleteRegCb */




/***********************************************************************
*
*       Fun:    soUaFindRegCallCb
*
*       Desc:   Function locates a call cb associated with Registrations.
*               There will be only one such call for one UA.
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_ua.c
*
**********************************************************************/
#ifdef ANSI
PRIVATE S16 soUaFindRegCallCb
(
SoEntCb   *ent,       /* Entity Cb */ 
SoEvnt    *evnt,      /* Event Cb */
SoCallCb  **callPtr   /* Call Cb pointer to be returned */
)
#else
PRIVATE S16 soUaFindRegCallCb(ent, evnt, callPtr)
SoEntCb   *ent;       /* Entity Cb */ 
SoEvnt    *evnt;      /* Event Cb */
SoCallCb  **callPtr;  /* Call Cb pointer to be returned */
#endif
{

  S16        ret;     /* Return Value */
  SoCallCb   *callCb; /*Call Cb */
  TknStrOSXL *callId; /* Pointer to where CallId must be placed */
 
  TRC3(soUaFindRegCallCb);

  /* so001.201 : Init pointers */
  callCb = NULLP;
  callId = NULLP;
  *callPtr = NULLP;

  /* Check whether User has specifed a Call Id for registrartion */
  ret = soCmFindHdrChoice(evnt, (U8 **) &callId, SO_HEADER_GEN_CALLID);

  /* Check if layer has a callId is already stored in the entity */
  if (ent->s.ua.regCallId.pres != NOTPRSNT)
  {
    /* if callId is not present in event */
    if (callId == NULLP)
    {
      /* Create new callId */
      if ( soCmCreateHdrChoice(evnt, (U8 **)&callId,
                               SO_HEADER_GEN_CALLID)!=ROK )
        RETVALUE(SOT_ERR_ADD_HDR_FAILED);

      /* Copy callId fron ent to event */
      if (soUtlCpyTknStrOSXL(callId, &ent->s.ua.regCallId, &evnt->memCp) != ROK)
        RETVALUE(SOT_ERR_RSRC);
    }
    else
    {
      /* Both callIds are present, compare them */
      /*--- so014.201: If callId has changed use the new call-ID ---*/
      if (soUtlCmpTknStrOSXL (&ent->s.ua.regCallId,callId, NULLP) != TRUE)
      {
        /* Locate the call cb using the callCb associated
           with the callId stored in the enitty*/
        (Void) cmHashListFind(&ent->callIdLst,
                              (U8 *) ent->s.ua.regCallId.val,
                              (U16) ent->s.ua.regCallId.len, 
                              (U16) 0, (PTR *) &callCb);
        
        if (callCb != NULLP)
        {
          soCoreDeleteCallCb(callCb);
          callCb = NULLP;
        }
        
        soUtlDelTknStrOSXL(&ent->s.ua.regCallId);

        if (soUtlCpyTknStrOSXL(&ent->s.ua.regCallId, callId, NULLP) != ROK)
          RETVALUE(SOT_ERR_RSRC);

        RETVALUE(SOT_ERR_NOERR);
      } /* If callIds are not the same */

    } /* else */

  } /* If entity doesnot has a stored regCallId */

  else if (callId != NULLP)
  {
    /* Entity doesnot contain regCallId, but user has provided one*/

    /* Copy callId information from callId to ent */
    if (soUtlCpyTknStrOSXL(&ent->s.ua.regCallId, callId, NULLP) != ROK)
      RETVALUE(SOT_ERR_RSRC);
  }
  /* If ent & event do not contain callId create one */
  else
  {
    /* Create new callId */
    if ( soCmCreateHdrChoice(evnt, (U8 **)&callId, SO_HEADER_GEN_CALLID)!=ROK )
      RETVALUE(SOT_ERR_ADD_HDR_FAILED);

    soUtlGenCallId(&ent->s.ua.regCallId);

    if ( soUtlCpyTknStrOSXL(callId, &ent->s.ua.regCallId, &evnt->memCp)!=ROK )
      RETVALUE(SOT_ERR_RSRC);

    RETVALUE(SOT_ERR_NOERR);
  }
       
  (Void) cmHashListFind(&ent->callIdLst,
                        (U8 *) ent->s.ua.regCallId.val,
                        (U16) ent->s.ua.regCallId.len,
                        (U16) 0, (PTR *) &callCb);
  *callPtr = callCb;
  RETVALUE(SOT_ERR_NOERR);

} /* soUaFindRegCallCb */





/***********************************************************************
*
*       Fun:    soUaFindRegCLeg
*
*       Desc:   Function located a call leg associated with the
*               REGISTER message.
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_ua.c
*
**********************************************************************/
#ifdef ANSI
PRIVATE SoCLegCb *soUaFindRegCLeg
(
SoEvnt    *evnt,       /* Event Cb */
U8        *key,        /* key to access call leg */
U16       keyLen,      /* Key length of call leg key */
SoCallCb  *callCb,     /* Call associated with registers */
SoUaRegCb *regCb       /* Cb associated with the registrar */
)
#else
PRIVATE SoCLegCb *soUaFindRegCLeg(evnt, key, keyLen, callCb, regCb)
SoEvnt    *evnt;       /* Event Cb */
U8        *key;        /* key to access call leg */
U16       keyLen;      /* Key length of call leg key */
SoCallCb  *callCb;     /* Cb associated with registrar */
SoUaRegCb *regCb;      /* Cb associated with the registrar */
#endif
{

  S16        ret;       /* Return Value */
  SoCLegCb   *cLeg;     /* tmp call leg structure */
  Bool       found;     /* found call leg / not */
  U16        cntr;      /* Index */

  TRC3(soUaFindRegCLeg);

  /*--- so014.201: Initialize local variable ---*/
  ret   = ROK;
  cLeg  = NULLP;

  /* try to locate call leg */
  cntr = 0;
  found = FALSE;
  
  while (!found)
  {
    /* Try to Locate call leg */
    ret = cmHashListFind(&callCb->regCLegLst,(U8 *)(key),
                         (U16)(keyLen),cntr,(PTR *)&cLeg);

    if ((ret != ROK) || (cLeg == NULLP))
      RETVALUE(NULLP);

    if (cLeg->regInfo.regCb == regCb)
    {
      found = TRUE;
      break;
    }
    else
      cntr++;
  }

  if (found == TRUE)
  {
    RETVALUE(cLeg);
  }
  else
    RETVALUE(NULLP);
} /* soUaFindRegCLeg */




/***********************************************************************
*
*       Fun:    soUaPrcContactInfo
*
*       Desc:   Processes contact information present in an
*               outgoing REGISTER. A contactCb is created for
*               every new contact being registered and any 
*               registration timers are started, if required. 
*               This procedure is done only if the layer is
*               configiured to maintain Registration Refresh timers.
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_ua.c
*
**********************************************************************/
#ifdef ANSI
PRIVATE S16 soUaPrcContactInfo
(
SoCLegCb    *cLeg,    /* Call Leg Cb */
SoEvnt      *evnt,    /* Event Cb */
Bool        *saveMsg
)
#else
PRIVATE S16 soUaPrcContactInfo(cLeg, evnt, saveMsg)
SoCLegCb    *cLeg;    /* Call Leg Cb */
SoEvnt      *evnt;    /* Event Cb */
Bool        *saveMsg;
#endif
{
  SoHeaderSeq    *hdrSeq;        /* Header sequence to search */ 
  U16            contactsFound;  /* Number of contacts found */ 
  TknU32         *expiresHdr;    /* Expires header        */
  U32            expiresVal;     /* Expires timer value   */
  U16            i;              /* Index */
  SoHeader       *curHdr;        /* Current header */
  SoContact      *contactHdr;    /* Contact header part of message */
  U32            cItem;          /* Counter for contact items */
  SoRegContactCb *contactCb;     /* Contact Control Block */
  SoContactItem  *contactItem;   /* contact Item */
  S16            ret;            /* return Value */
  SoContactParam *contactParam;  /*so026.201 */

  TRC3(soUaPrcContactInfo);

  /* Initialize Variables */
  /*--- so014.201: Initialize local variable ---*/
  ret            = ROK;
  hdrSeq         = NULLP;
  contactsFound  = 0;
  expiresHdr     = NULLP;
  expiresVal     = 0;
  curHdr         = NULLP;
  contactHdr     = NULLP;
  *saveMsg = FALSE; /* so026.201 : initialize saveMsg */
  
  /* Extract the Expires Header, if present */
  soCmFindHdrChoice(evnt, (U8 **)&expiresHdr, SO_HEADER_GEN_EXPIRES);

  /* If Expires header is present, calclate the expiration time */
  if (expiresHdr != NULLP)
  {
    /* Calculate seconds till expiry */
     if (expiresHdr->pres != NOTPRSNT)
        expiresVal = expiresHdr->val;
     else 
        expiresVal = 0;
  }

   /* Process all Contact header fields */
   contactsFound = 0;

   hdrSeq = &evnt->t.request.request;

   /* Go thorugh all the headers in the message, to find contact hedaers */
   for (i = 0; i < hdrSeq->numComp.val; i++)
   {
     curHdr = hdrSeq->header[i];
     if (SO_CMP_TKN_LIT(&curHdr->headerType, SO_HEADER_GEN_CONTACT) != TRUE)
       continue;

     /* Contact header found - process */
     contactHdr = &curHdr->t.contact;

     /* Check if contact is of type '*' */
     if (SO_CMP_TKN_LIT(&contactHdr->contactDescType,
                        SO_CONTACTDESC_METASTAR) == TRUE)
     {
       /* Only single contact header allowed. If others are found return eror.*/
       if (contactsFound != 0)
       {
         /* Already some previously processed */
         RETVALUE(SOT_ERR_REG_CONTACT_STAR);
       }

       /* Check if expires timer value is 0 */
       if ((expiresHdr == NULLP) || (expiresVal != 0))
       {
         RETVALUE(SOT_ERR_REG_CONTACT_STAR);
       }

       cLeg->regInfo.deRegAll = TRUE;
       RETVALUE(SOT_ERR_NOERR);
     }

     contactsFound++;

     /* Non - * contact header, process all contact items
        in header */
     for (cItem = 0;
          cItem < SO_GET_NUM_COMP(&contactHdr->contactItems.numComp);
          cItem++)
     {
       U32  expiryTmrVal = 0;
       Bool expiresPres = FALSE;
       U8   j;

       contactCb = NULLP;
       contactItem = contactHdr->contactItems.contactItem[cItem];
       if ((ret = soUaGetContactCb(cLeg, &contactCb, 
                                   contactItem)) != SOT_ERR_NOERR)
         RETVALUE(ret);

       contactCb->currCSeq = cLeg->storedHdrs.cSeqHiTx;

       /* so026.201:- First check if the contactCb has expiry time, 
                     if yes use it.*/
       expiresPres = FALSE;

       if(contactItem->contactParams.numComp.pres == PRSNT_NODEF)
       {
          for (j = 0 ; j < contactItem->contactParams.numComp.val; j++ )
          {
            contactParam = contactItem->contactParams.contactParam[j];

            if((contactParam->contactParamType.pres == PRSNT_NODEF) && 
               (contactParam->contactParamType.val == SO_CONTACTPARAM_STD))
            {
               if((contactParam->t.contactParamStd.contactParamStdType.pres ==  
                                                               PRSNT_NODEF) && 
                  (contactParam->t.contactParamStd.contactParamStdType.val == 
                                                   SO_CONTACTPARAMSTD_EXPIRES))
               {
                  if(contactParam->t.contactParamStd.t.contactParExpires.pres == 
                                                                  PRSNT_NODEF)
                  {
                     expiresPres = TRUE;
                     expiryTmrVal = 
                           contactParam->t.contactParamStd.t.contactParExpires.val;
                  }
               }
            }
          }
       }
       /* so026.201: find if the request is reg/dereg */
       if( expiresPres == TRUE)
       {
         if(expiryTmrVal == 0)
          {
            /* This is the case of dereg, event will be deleted by txn */
             contactCb->storedReq = NULLP;
            /*-- so033.201: In case of de-registration this value 
                 identifies whether to remove the contact or re-register
                 the same --*/
             contactCb->expiryTmrVal.pres = PRSNT_NODEF;
             contactCb->expiryTmrVal.val = 0;
          }
          else
          {
             *saveMsg = TRUE;
             contactCb->storedReq = evnt;
          }
       }
       else
       {
          /* Expires param in Contact header not present so check for
          * Expires header 
          */
       
          if ((expiresHdr != NULLP) && (expiresVal == 0))
          {
            /* This is the case of dereg, event will be deleted by txn */
             contactCb->storedReq = NULLP;
            /*-- so033.201: In case of de-registration this value 
                 identifies whether to remove the contact or re-register
                 the same --*/
             contactCb->expiryTmrVal.pres = PRSNT_NODEF;
             contactCb->expiryTmrVal.val = 0;
          }
          else
          {
             *saveMsg = TRUE;
             contactCb->storedReq = evnt;
          }
       }
     }
   }

   RETVALUE(SOT_ERR_NOERR);

} /* soUaPrcContactInfo */





/***********************************************************************
*
*       Fun:    soUaGetContactCb
*
*       Desc:   Processes contact information present in an
*               outgoing REGISTER. A contactCb is created for
*               every new contact being registered and any 
*               registration timers are started, if required. 
*               This procedure is done only if the layer is
*               configiured to maintain Registration Refresh timers.
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_ua.c
*
**********************************************************************/
#ifdef ANSI
PRIVATE S16 soUaGetContactCb
(
SoCLegCb       *cLeg,        /* CLeg Cb */
SoRegContactCb **contactCb,  /* contact cb ptr */
SoContactItem  *newContact   /* New contact Item */
)
#else
PRIVATE S16 soUaGetContactCb(cLeg, contactCb, newContact)
SoCLegCb       *cLeg;        /* CLeg Cb */
SoRegContactCb **contactCb;  /* contact cb ptr */
SoContactItem  *newContact;  /* New contact Item */
#endif
{

   SoAddrSpec       *contactAddr;   /* Contact address */
   U8               *key;           /* String version of contact */
   U16              keyLen;         /* length of address */
   SoRegContactCb   *tmpContactCb;  /* newly allocated contact cb */
   S16              ret;            /* Return Value */
   SoContactParam   *cPar;          /* Contact item parameter      */
   U32              j;              /* Counter */
   CmLList         *curNode;        /* Current node in list  */
   PTR             curItem;         /* Current item          */
   SoRegContactCb  *pendContact;    /* Contact cb */

   TRC3(soUaGetContactCb);

   SO_ADDRSPEC_FROM_ADDRCH(contactAddr, &newContact->contactAddrChoice);

   /* Calculate the key , based on the addr provided in conatct */
   ret = soUtlCalcAddrKey(contactAddr, &key, &keyLen);
   if (ret != ROK)
     RETVALUE(SOT_ERR_REGISTER_REQ_FAILED);
 
   *contactCb = NULLP;


   /* See if Contact is already available in the hashlist */     
   ret = cmHashListFind(&cLeg->regInfo.contactLst,(U8 *)key,
                        (U16)keyLen,0,(PTR *)contactCb);
   
   /* New Contact */
   if ((ret!= ROK) || (*contactCb == NULLP))
   {
     ret = ROK;

     SOALLOC(contactCb, sizeof(SoRegContactCb));

     if ((contactCb == NULLP) || ((*contactCb) == NULLP))
     {
       SOFREE(key, keyLen);
       RETVALUE(SOT_ERR_RSRC);
     }
   
     tmpContactCb = *contactCb;
     tmpContactCb->cLeg = cLeg; 
     soCmInitTimer(&tmpContactCb->expiryTmr);
     tmpContactCb->expiryTmrVal.pres = NOTPRSNT;
     tmpContactCb->expiryTmrVal.val = 0;
     tmpContactCb->storedReq = NULLP;
     
     tmpContactCb->keyLength = keyLen;
     tmpContactCb->userRegPend = TRUE;

     SOALLOC(&tmpContactCb->key, tmpContactCb->keyLength);

     if (tmpContactCb->key == NULLP)
     {
       SOFREE(*contactCb, sizeof(SoRegContactCb));
       SOFREE(key, keyLen);
       *contactCb = NULLP;
       RETVALUE(SOT_ERR_RSRC);
     }
     
     /* Copy the key into the contact Cb */
     cmMemcpy(tmpContactCb->key, key, keyLen);

     soCmInitTimer(&tmpContactCb->expiryTmr);

     SOFREE(key, keyLen);
     
     cLeg->regInfo.numRegContacts++;

     ret = cmHashListInsert(&cLeg->regInfo.contactLst, 
                            (PTR)(tmpContactCb),
                            (U8 *)tmpContactCb->key,
                            (U16)tmpContactCb->keyLength);
     if (ret !=ROK)
     {
       SOFREE(*contactCb, sizeof(SoRegContactCb));
       *contactCb = NULLP;
       RETVALUE(SOT_ERR_RSRC);
     }
   }

   else
   {
     SOFREE(key, keyLen);

     /* If there was a stored event remove it since the new one will
        have to get copied into the contactCb */

     if ((*contactCb)->userRegPend == TRUE)
     {
       RETVALUE(SOT_ERR_REG_IN_PROGRESS);
     }

     if ((*contactCb)->storedReq != NULLP)
     {
       (Void) soCmFreeEvent((*contactCb)->storedReq);
       (*contactCb)->storedReq = NULLP;
     }

     /* If an interim auto re-registration message has been
        sent out for the same contact, ignore the response
        by removing the node from the prndingContactLst */
     curNode = cmLListFirst(&cLeg->regInfo.pendContactLst);
     while (curNode != (CmLList *)NULLP)
     {
       curItem  = cmLListNode(curNode);
       curNode  = curNode->next;
       pendContact = (SoRegContactCb *)curItem;

       if (pendContact == (*contactCb))
       {
         cmLListDelFrm(&(cLeg->regInfo.pendContactLst), 
                       &(pendContact->cLegLstNode));
         break;
       }
     }

     (*contactCb)->userRegPend = TRUE;

     /* Existing Contact : Update fields */     
     /* Stop re_reg timer if it is running */
     soSchedTmr(*contactCb, SO_TMR_UA_CONTACT_EXP, TMR_STOP, NOTUSED);
     (*contactCb)->expiryTmrVal.pres = NOTPRSNT;
   }
   
   /* Insert the contact Control Block into the list in cLeg */
   cmLListNode(&((*contactCb)->cLegLstNode)) = (PTR) (*contactCb);
   cmLListAdd2Tail(&cLeg->regInfo.pendContactLst, &((*contactCb)->cLegLstNode)); 

   for (j = 0;
        j < SO_GET_NUM_COMP(&newContact->contactParams.numComp);j++)
   {
     cPar = newContact->contactParams.contactParam[j];

     if ((cPar != NULLP) && 
         (SO_CMP_TKN_LIT(&cPar->contactParamType,
                         SO_CONTACTPARAM_STD) == TRUE) &&
         (cPar->t.contactParamStd.contactParamStdType.val ==
          SO_CONTACTPARAMSTD_EXPIRES))
     {
       if (cPar->t.contactParamStd.t.contactParExpires.pres != NOTPRSNT)
          (*contactCb)->expiryTmrVal.val =
               cPar->t.contactParamStd.t.contactParExpires.val;
       else
          (*contactCb)->expiryTmrVal.val = 0;

       (*contactCb)->expiryTmrVal.pres = PRSNT_NODEF;
       break;
     }
   } /* For */

   RETVALUE(SOT_ERR_NOERR);
} /* soUaGetContactCb */





/* *** Recursion Related Functions  ****/
/*
*
*       Fun:   soUaCreateRecurseContact
*
*       Desc:  Creates a new recursion contact cb to store in the 
*              call leg
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaCreateRecurseContact
(
SoRecurseContact **recurseContact, 
SoContactItem    *contactItem
)
#else
PRIVATE S16 soUaCreateRecurseContact(recurseContact, contactItem)
SoRecurseContact **recurseContact; 
SoContactItem    *contactItem;
#endif
{
   S16              j;             /* index */
   SoContactParam   *cPar;         /* Contact item parameter      */
   Bool             found;         /* q value found */
   SoRecurseContact *tmpRecContact; /* temp contact cb */
   SoContactItem    *newContact;   /* New Contact */

   TRC3(soUaCreateRecurseContact);

   found = FALSE;

   SOALLOC(recurseContact, sizeof(SoRecurseContact));
   if (*recurseContact == NULLP)
     RETVALUE(RFAILED);

   tmpRecContact = *recurseContact;

   SOALLOC(&newContact, sizeof(SoContactItem));
   if (newContact == NULLP)
     RETVALUE(RFAILED);

   tmpRecContact->recursionDone = FALSE;

   if (soUtlCpySoContactItem(newContact, contactItem, 
                             (CmMemListCp *)NULLP)!=ROK )
   {
     SOFREE(*recurseContact, sizeof(SoRecurseContact));
     SOFREE(newContact, sizeof(SoContactItem));
     RETVALUE(RFAILED);
   }
   
   /* Copy the q value from the contact into the recurseContact
      structure */
   if (newContact->pres.pres != NOTPRSNT) 
   {
     for (j = 0;j < SO_GET_NUM_COMP(&newContact->contactParams.numComp);j++)
     {
       cPar = newContact->contactParams.contactParam[j];
       if ((cPar != NULLP) && 
           (SO_CMP_TKN_LIT(&cPar->contactParamType,
                           SO_CONTACTPARAM_STD) == TRUE) &&
           (cPar->t.contactParamStd.contactParamStdType.val ==
            SO_CONTACTPARAMSTD_Q))
       {
         if (cPar->t.contactParamStd.t.qValue.pres.pres == NOTPRSNT)
           continue;
         cmMemcpy((U8 *)&tmpRecContact->qValue,
                  (U8 *)&cPar->t.contactParamStd.t.qValue,
                  sizeof(SoQValue));
         found = TRUE;
       }
     }
     
     if (found == FALSE)
     {
       tmpRecContact->qValue.pres.pres = PRSNT_NODEF;
       tmpRecContact->qValue.qVInt.pres = PRSNT_NODEF;
       tmpRecContact->qValue.qVInt.val = 0;
       tmpRecContact->qValue.qVFrac.pres = PRSNT_NODEF;
       tmpRecContact->qValue.qVFrac.val = 0;
     }
   }
   tmpRecContact->contact = newContact;
   RETVALUE(ROK);
} /* soUaCreateRecurseContact */




/*
*
*       Fun:   soUaStoreRecContact
*
*       Desc:  This function stores the contacts to be used for recursion
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaStoreRecContact
(
SoEvnt       *evnt,       /* Event */
SoRecurseCb  *recurseCb  /* Recursion Cb */
)
#else
PRIVATE S16 soUaStoreRecContact(evnt, recurseCb)
SoEvnt       *evnt;       /* Event */
SoRecurseCb  *recurseCb;  /* Recursion Cb */
#endif
{

  SoHeaderSeq    *hdrSeq;   /* Sequence of headers */
  SoHeader       *hdr;      /* Current header */
  SoContact      *contact;  /* Contact Hdr */
  U16            i;         /* Index */
  U16            j;         /* Index */
  U32            numCItems; /* Number of Contact Items */
  SoContactItem  *contactItem;  /* Single contact item to process */
  S16            ret;       /* Return Value */
  SoRecurseContact *recurseContact; /* Recurse Contact */

  TRC3(soUaStoreRecContact);

  /*--- so014.201: Initialize local variable ---*/
  ret    = ROK;
  hdrSeq = &evnt->t.response.response;

  for (i = 0; i < SO_GET_NUM_COMP(&hdrSeq->numComp); i++)
  {
    hdr = hdrSeq->header[i];
    
    if (SO_CMP_TKN_LIT(&hdr->headerType, SO_HEADER_GEN_CONTACT)
        == TRUE)
    {
       contact = &hdr->t.contact;
       numCItems = SO_GET_NUM_COMP(&contact->contactItems.numComp);

       for (j = 0; j < (U16)(numCItems); j++)
       {
         contactItem = contact->contactItems.contactItem[j];

         /* Create a new recurse contact structure to store in the 
            call leg */
         ret = soUaCreateRecurseContact(&recurseContact, contactItem);
         if (ret != ROK)
           RETVALUE(ret);
         /* Add new control block into list in call leg */
         cmLListNode(&recurseContact->contactNode) = 
           (PTR) recurseContact;
         cmLListAdd2Tail(&recurseCb->recContactLst, 
                         &recurseContact->contactNode);
         
         recurseContact = NULLP;
       }
    }
  }
  
  RETVALUE(ROK);
} /* soUaStoreRecContact */





/*
*
*       Fun:   soUInitRecurse
*
*       Desc:  This function 
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaInitRecurse
(
SoCLegCb   *cLeg,   /* Call leg cb */
SoEvnt     *evnt     /* Event */
)
#else
PRIVATE S16 soUaInitRecurse(cLeg, evnt)
SoCLegCb   *cLeg;   /* Call leg cb */
SoEvnt     *evnt;   /* Event */
#endif
{

   S16     ret;      /* Return Value */

   TRC3(soUaInitRecurse);

   cLeg->recurseCb.recursState = SO_RECURSION_ON;

   /* Clear contents of the recursion cb */
   soDlgDelRecurseCb(cLeg);

   /* Store the contact header received if the message has a contact header */
   ret = soUaStoreRecContact(evnt, &cLeg->recurseCb);
   if (ret != ROK)
   {
     /* Clear contents of the recursion cb */
     soDlgDelRecurseCb(cLeg);
     RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* soUaInitRecurse */





/*
*
*       Fun:   soUaAddRecurseContacts
*
*       Desc:  Add contacts into the recursion list
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaAddRecurseContacts
(
SoEvnt      *evnt,       /* Event */
SoRecurseCb *recurseCb   /* Recursion cb */
)
#else
PRIVATE S16 soUaAddRecurseContacts(evnt, recurseCb)
SoEvnt      *evnt;       /* Event */
SoRecurseCb *recurseCb;  /* Recursion cb */
#endif
{
   SoHeaderSeq    *hdrSeq;   /* Sequence of headers */
   SoHeader       *hdr;      /* Current header */
   SoContact      *contact;  /* Contact Hdr */
   U32            numCItems; /* Number of Contact Items */
   SoContactItem  *contactItem;   /* Single contact item to process */
   SoContactItem  *storedContact; /* Single contact item to process */
   SoRecurseContact *recurseContact; /* Recurse Contact */
   Bool             found;        /* Contact found */
   U16              i;            /* Index */
   U16              j;            /* Index */
   S16              ret;          /* Return Value */
   CmLList          *curNode;     /* Current node in list     */

   TRC3(soUaAddRecurseContacts);

  /*--- so014.201: Initialize local variable ---*/
   ret   = ROK;
   found = TRUE;
   hdrSeq = &evnt->t.response.response;
  
   for (i = 0; i < SO_GET_NUM_COMP(&hdrSeq->numComp); i++)
   {
     hdr = hdrSeq->header[i];
     
     if (SO_CMP_TKN_LIT(&hdr->headerType, SO_HEADER_GEN_CONTACT) == TRUE)
     {
       contact = &hdr->t.contact;
       numCItems = SO_GET_NUM_COMP(&contact->contactItems.numComp);

       for (j = 0; j < numCItems; j++)
       {
         contactItem = contact->contactItems.contactItem[j];

         if (contactItem->pres.pres != PRSNT_NODEF)
           continue;
         
         found = FALSE;
         curNode = cmLListFirst(&recurseCb->recContactLst);
         while ((found != TRUE) && (curNode != NULLP))
         {
           recurseContact = 
             (SoRecurseContact *)curNode->node;
           storedContact = recurseContact->contact;
           curNode = curNode->next;
           if (storedContact == NULLP)
             continue;
           if (soUtlCmpAddrInContact(contactItem,
                                  storedContact) == ROK)
             found = TRUE;
         }


         if (found != TRUE)
         {
           recurseContact = NULLP;
           ret = soUaCreateRecurseContact(&recurseContact, contactItem);
           if (ret != ROK)
             continue;
           
           /* Add new control block into list in call leg */
           cmLListNode(&recurseContact->contactNode) = 
             (PTR) recurseContact;           
           
           cmLListAdd2Tail(&recurseCb->recContactLst, 
                           &recurseContact->contactNode);   
         } /* if found */
       } /* for */
     } /* If contact header */
   } /* for i */

   RETVALUE(ROK);
} /* soUaAddRecurseContacts */






/*
*
*       Fun:   soUaRecurse
*
*       Desc:  Perform Recursion
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE S16 soUaRecurse
(
SoCLegCb   *cLeg,    /* Call leg cb */
SoEvnt     *evnt     /* Event */
)
#else
PRIVATE S16 soUaRecurse(cLeg, evnt)
SoCLegCb   *cLeg;    /* Call leg cb */
SoEvnt     *evnt;    /* Event */
#endif
{

   SoRecurseCb      *recurseCb;      /* Recursion Cb */
   U16              numContacts;     /* Number of Contacts */
   CmLList          *curNode;        /* Current node in list    */
   SoRecurseContact *newContact;     /* Recurse Contact */
   SoRecurseContact *recurseContact; /* Contact */
   SoContactItem    *storedContact;  /* Single contact item to process */
   Bool             isGreater;       /* TRUE if Value is greater */
   SoUserCtxt       userCtxt;       /* User Context Cb    */
   S16              ret;             /* Return Value */
   SoAddrSpec       *addrSpec;       /* Address Spec */
   SoCSeq           *cSeq;           /* Cseq header */

   TRC3(soUaRecurse);

  /*--- so014.201: Initialize local variable ---*/
   ret   = ROK;
   cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

   recurseCb = &cLeg->recurseCb;
   isGreater = FALSE;

   numContacts = cmLListLen(&recurseCb->recContactLst); 

   if (numContacts == 0)
     RETVALUE(RFAILED);
   
   /* Got thorugh the list of stored contacts. Select the
      contact with the highest q value that has not already been 
      used for recursion */   
   curNode = cmLListFirst(&recurseCb->recContactLst);
   
   if (curNode != NULLP)
     newContact = (SoRecurseContact *)curNode->node;
   
   while (curNode != NULLP)
   {
     recurseContact = (SoRecurseContact *)curNode->node;
     storedContact = recurseContact->contact;
     curNode = curNode->next;
     
     if (recurseContact->recursionDone == TRUE)
       continue;
     
     if (storedContact == NULLP)
       continue;
     
     if (newContact->recursionDone == TRUE)
       newContact = recurseContact;
     
     soCmpQVal(&recurseContact->qValue,&newContact->qValue, &isGreater);
     if ((isGreater == TRUE) && 
         (recurseContact->recursionDone != TRUE))
     {
       newContact = recurseContact;
     }
   }
   
   if (newContact->recursionDone == TRUE)
   {
     cLeg->recurseCb.recursState = SO_NO_RECURSION;
     RETVALUE(RFAILED);
   }
   
   cLeg->recurseCb.recursState = SO_RECURSION_ON;
   
   SO_ADDRSPEC_FROM_ADDRCH(addrSpec,
                           &newContact->contact->contactAddrChoice);
      
   if (addrSpec == NULLP)
   {
     newContact->recursionDone = TRUE;
     ret = soUaRecurse(cLeg, evnt);
     if (ret != ROK)
       RETVALUE(RFAILED);
   }
   
   /* Copy first contact into request URI */
   /* Overwrite contents of request URI in call leg with the new contact */
   soUtlDelSoAddrSpec(&cLeg->storedHdrs.reqURI);

   ret = soUtlCpySoAddrSpec(&cLeg->storedHdrs.reqURI,
                            addrSpec, NULLP);
   if (ret != ROK)
     RETVALUE(RFAILED);

   /*----------- so025.201: Reset remote tag stored -----------*/
   (Void) soCmRemoveRemoteTag (cLeg->call->ent, cLeg);
   
   /* Update the message CSeq */
   if (soCmFindHdrChoice(evnt, (U8 **) &cSeq, SO_HEADER_GEN_CSEQ)
       == ROK)
   {
     cSeq->cSeqVal.val++;
     cLeg->storedHdrs.cSeqHiTx = cSeq->cSeqVal.val;

    /*--- so038.201: Update the dialog creating CSEQ Value ---*/
     cLeg->storedHdrs.dlgCreateCSeq = cLeg->storedHdrs.cSeqHiTx;
   }
   else
     RETVALUE(RFAILED);

   /* Fill the user context that will be stored in 
      the transaction layer */
   SO_FILL_USER_CTXT(userCtxt, TRUE, FALSE);

   /* Allocate new transId for the Invite */
   /* Generate a new transaction id for the cancel */
   SO_TXN_AllOC_TRANSID (evnt->transId, 
                         evnt->eventType.val, cLeg->call->ent);

   ret = soDlgUaOutReq(cLeg, &userCtxt, evnt);
   
   if (ret == ROK)
     newContact->recursionDone = TRUE;

   RETVALUE(ret);
} /* SoUarecurse */




/*
*
*       Fun:   soUaRequestBuild
*
*       Desc:  This function builds a new request message from information
*              in the call, call leg 
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaRequestBuild
(
SoCLegCb    *cLeg,       /* Call Leg Cb */
U8          evntType,    /* Event Type */
SoEvnt      **newEvnt  /* PRACK event */ 
)
#else
PUBLIC S16 soUaRequestBuild(cLeg, evntType, newEvnt)
SoCLegCb    *cLeg;       /* Call Leg Cb */
U8          evntType;    /* Event Type */
SoEvnt      **newEvnt;   /* PRACK event */ 
#endif
{
   S16         ret;          /* value returned by function calls */
   SoEvnt      *tmpEvnt;     /* new event */

   TRC2(soUaRequestBuild);

   /* Allocate memory for the event structure */
   ret = soCmCreateEvent(newEvnt, evntType);
   if (ret != ROK)
   {
      RETVALUE(ret);
   }

   tmpEvnt = *newEvnt;

   /* Set message type to request */
   SO_FILL_TKNU8(&tmpEvnt->sipMessageType, SO_SIPMESSAGE_REQUEST);
   tmpEvnt->t.request.pres.pres = PRSNT_NODEF;
   tmpEvnt->t.request.requestLine.pres.pres = PRSNT_NODEF;

   SO_FILL_TKNU8(&tmpEvnt->t.request.requestLine.method.type,
                 SO_METHOD_METHODSTD);
   SO_FILL_TKNU8(&tmpEvnt->t.request.requestLine.method.t.std,
                 evntType);

   /* Set version */
   SO_FILL_TKNSTROSXL(&tmpEvnt->t.request.requestLine.sipVersion,
                      soCb.cfg.protVer,
                      cmStrlen((U8 *)soCb.cfg.protVer), tmpEvnt, ret);

   /* Generate a new transaction id for the request */
   SO_TXN_AllOC_TRANSID (tmpEvnt->transId, 
                         tmpEvnt->eventType.val,
                         cLeg->call->ent);
   
   /* New transaction belongs to same dialog        */
   tmpEvnt->callLegId  = cLeg->legId;

   RETVALUE(ret);
} /* end of soUaRequestBuild */



/***************************************************************/
/*                 UA Timer Call Back Functions                */
/***************************************************************/

/*
*
*       Fun:   soUa2xxTmrExpiry
*
*       Desc:  This function processes expiry of a 2xx 
*              retransmission timer.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soUa2xxRetxTimeout
(
SoCLegCb    *cLeg   /* Call Leg Cb */
)
#else
PUBLIC Void soUa2xxRetxTimeout(cLeg)
SoCLegCb    *cLeg;  /* Call Leg Cb */
#endif
{

  SoTcmConn tcmConn;

  if (cLeg->rspCb.tmrVal < soCb.reCfg.tmrReTxCfg.t2)
  {
    cLeg->rspCb.tmrVal = cLeg->rspCb.tmrVal * 2;
  }
  
  if (cLeg->rspCb.rspMsg != NULLP)
  {
    /* Start Retx Timer & 2xx expiry timer */
    soSchedTmr(cLeg, SO_TMR_2XX_RETX, TMR_START, cLeg->rspCb.tmrVal);
    cmMemset ((U8 *)&tcmConn, 0, sizeof (SoTcmConn));
    tcmConn.tcmConnType = SO_UNKNOWN;

    /* so025.201 Correction in flag */
#if (defined(SO_NAT) && defined(SO_USE_UDP_SRVR))
    /* so024.201: Get tcm conn from rsp Cb */
    soTptSendRsp(cLeg->call->ent, cLeg->call->ssapCb, 
                 &cLeg->rspCb.rcvdVia, NULLP,
                 &cLeg->rspCb.rspMsg, &cLeg->rspCb.tcmConn);
#else
    soTptSendRsp(cLeg->call->ent, cLeg->call->ssapCb, 
                 &cLeg->rspCb.rcvdVia, NULLP,
                 &cLeg->rspCb.rspMsg, &tcmConn);
#endif

  }

  RETVOID;
} /* soUa2xxRetxTimeout */




/*
*
*       Fun:   soUa2xxTmrExpiry
*
*       Desc:  This function processes expiry of a 2xx 
*              retransmission timer.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soUa2xxTmrExpiry
(
SoCLegCb    *cLeg   /* Call Leg Cb */
)
#else
PUBLIC Void soUa2xxTmrExpiry(cLeg)
SoCLegCb    *cLeg;  /* Call Leg Cb */
#endif
{
  TRC2(soUa2xxTmrExpiry);

  /* Stop 2xx Retx Timer */
  soSchedTmr(cLeg, SO_TMR_2XX_RETX, TMR_STOP, NOTUSED);

  /* so010.201 : If timer has expired and there is a response here, delete it */
  if (cLeg->rspCb.rspMsg != NULLP)
  {
     SPutMsg (cLeg->rspCb.rspMsg);
     cLeg->rspCb.rspMsg = NULLP;
  }

  soUaIntBye(cLeg);

  /* Send Indication to the user */
  /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
  soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
             cLeg->call->spConnId, NULLP, cLeg->legId,SOT_ET_INVITE,
             SOT_ERR_TIMEOUT, TRUE, FALSE);
#else
  soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
             cLeg->call->spConnId, NULLP, cLeg->legId,SOT_ET_INVITE,
             SOT_ERR_TIMEOUT, TRUE);
#endif

  RETVOID;
}



#ifdef SO_RFC_3262

/*
*
*       Fun:   soUa1xxRetxTimeout
*
*       Desc:  This function processes expiry of a 1xx 
*              retransmission timer. This is applicable
*              only to reliable provisional responses
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soUa1xxRetxTimeout
(
SoProvRspCb *provRspCb  /* provisional Response Cb */
)
#else
PUBLIC Void soUa1xxRetxTimeout(provRspCb)
SoProvRspCb *provRspCb;  /* provisional Response Cb */
#endif
{
  SoCLegCb  *cLeg;      /* Call Leg associated with the 
                           provisional response */
  SoTcmConn tcmConn;    /* Temp transport connection to send 2x  */

  TRC2(soUa1xxTmrExpiry);

  cLeg = provRspCb->cLeg;

  if (provRspCb->rspCb.tmrVal < soCb.reCfg.tmrReTxCfg.t2)
  {
    provRspCb->rspCb.tmrVal = provRspCb->rspCb.tmrVal * 2;
  }
  
  if (provRspCb->rspCb.rspMsg != NULLP)
  {
    soSchedTmr(provRspCb, SO_TMR_1XX_RETX, TMR_START, provRspCb->rspCb.tmrVal);
    cmMemset ((U8 *)&tcmConn, 0, sizeof (SoTcmConn));
    tcmConn.tcmConnType = SO_UNKNOWN;

    /* so025.201 Correction in flag */
#if (defined(SO_NAT) && defined(SO_USE_UDP_SRVR))
    /* so024.201: Use tcmConn from rsp Cb */
    soTptSendRsp(cLeg->call->ent,  cLeg->call->ssapCb, 
                 &cLeg->rspCb.rcvdVia, NULLP,
                 &provRspCb->rspCb.rspMsg, &cLeg->rspCb.tcmConn);
#else
    soTptSendRsp(cLeg->call->ent,  cLeg->call->ssapCb, 
                 &cLeg->rspCb.rcvdVia, NULLP,
                 &provRspCb->rspCb.rspMsg, &tcmConn);
#endif

  }

  RETVOID;
} /* soUa1xxTmrExpiry */



/*
*
*       Fun:   soUa1xxTmrExpiry
*
*       Desc:  This function processes expiry of a 2xx 
*              retransmission timer.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soUa1xxTmrExpiry
(
SoProvRspCb *provRspCb  /* Prov Rsp cb */
)
#else
PUBLIC Void soUa1xxTmrExpiry(provRspCb)
SoProvRspCb *provRspCb;  /* Prov Rsp cb */
#endif
{
  SoCLegCb  *cLeg;
  SoEvnt   *rspEvnt;      /* Response Event */
  U16      legId;         /* Call Leg Id */
  SoCallCb *callCb;       /* Call Cb */
  S16      ret;           /* Return Value */
  /* so009.201 : New parameter */
  UConnId  suConnId;      /* SuConnId */

  TRC2(soUa1xxTmrExpiry);

  ret = ROK;
  cLeg = provRspCb->cLeg;
  legId = cLeg->legId;
  callCb = cLeg->call;
  /* so009.201 : Used user conn id instead of suConnId in callCb */
  suConnId = cLeg->userConnId;

  /* Send 500 for the original INVITE */
  ret = soUtlBuildRspEvnt(cLeg->call->ent, &rspEvnt, NULLP, 
  /* so011.201: Parameter eventType to be passed */
                    SOT_ET_INVITE,
                    SOT_RSP_500_SRV_INT_ERROR,
                    SO_EXTRSP_NONE);
  /* so038.201: Added error check condition */
  if(ret != ROK )
  {
     SODBGP_SO(SO_DBGMASK_ERR, (soCb.init.prntBuf,
              "soUa1xxTmrExpiry: Failed to build response event.\n"));
     RETVOID;
  }
  rspEvnt->transId = provRspCb->transId;
  rspEvnt->callLegId = cLeg->legId;

  ret = soDlgUaOutRsp(cLeg, rspEvnt, NULLP);
  if (ret != ROK)
  {
    (Void) soCmFreeEvent (rspEvnt);  
    /* The call leg needs to be deleted explicilty since 
       an error response couldnot be sent out for it.*/
    soDlgDeleteCleg(callCb, cLeg);
  }
  else
  {
    /* Clear all prov rsp info */
    soDlgDelRelProvRspInfo(cLeg);
  }

  /* Send Indication to the user */
  /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
  soUiErrInd(callCb->ssapCb, suConnId, 
             callCb->spConnId, NULLP, legId,SOT_ET_INVITE,
             SOT_ERR_TIMEOUT, TRUE, FALSE);
#else
  soUiErrInd(callCb->ssapCb, suConnId, 
             callCb->spConnId, NULLP, legId,SOT_ET_INVITE,
             SOT_ERR_TIMEOUT, TRUE);
#endif
  
  /* Call Leg may have been deleted, so check if call needs 
     to be deleted also. */
  soCoreChkAndDelCall(callCb);

  RETVOID;
}
#endif /* SO_RFC_3262 */




/*
*
*       Fun:   soUaExpiresTmrExpiry
*
*       Desc:  This function is invoked when the Expires timer
*              expires.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soUaExpiresTmrExpiry
(
SoCLegCb    *cLeg   /* Call Leg Cb */
)
#else
PUBLIC Void soUaExpiresTmrExpiry(cLeg)
SoCLegCb    *cLeg;  /* Call Leg Cb */
#endif
{

  SoCallCb   *callCb;     /* CALL CB */
  SoSSapCb   *sSapCb;     /* CALL CB */
  UConnId    suConnId;
  UConnId    spConnId;
  U32        cLegId;
  S16        ret;         /* Return Value */

  TRC2(soUaExpiresTmrExpiry);

  /*--- so014.201: Initialize local variable ---------------------------------*/
  ret      = ROK;
  callCb   = cLeg->call;
  sSapCb   = callCb->ssapCb;
  /*----- so009.201 : Used user conn id instead of suConnId in callCb --------*/
  suConnId = cLeg->userConnId;
  spConnId = callCb->spConnId;
  cLegId   = cLeg->legId;

  SODBGP_SO (SO_DBGMASK_UA, (soCb.init.prntBuf,
             "\n Expires Timer EXPIRED (%d) \n", cLeg->clegState));             

  if (cLeg->role == SO_UAC)
  {
    /*--- so012.201: AT UAC side send CANCEL if no final response received. --*/

    /*--- so015.201: Send CANCEL only for early/proceeding stage -------------*/
    if ((cLeg->clegState == SO_CLEG_STATE_EARLY) ||
        (cLeg->clegState == SO_CLEG_STATE_PROCEEDING))
      ret = soUaIntCancel (cLeg);

    if (ret != ROK)
      soDlgDeleteCleg (callCb, cLeg);

    /*--- so041.201: Please note that in UAC side, we are not informing ------*
     *--- application that call is deleted. We are just sending CANCEL and ---*
     *--- and actual call clearign will be done when either we get 487 for ---*
     *--- INVITE, or CANCEL timeout.                                       ---*

     *--- Ideally Expires timer should be large enough to be greater that ----*
     *--- time it takes for INVITE transaction to finish (when no 1xx is  ----*
     *--- received. If expires timer timeout before receiving 1xx, we will ---*
     *--- simply ignore the event.                                         ---*/
  }

  else
  {
     /*--- so041.201: Expires timer timesout in server.                       *
      
      *--- (1) Close all pending server transactions.                      ---*
      *--- (2) Inform application that call is cleared and no action is    ---*
      *---     required to be taken by application for any pending event.  ---*
      *---     Application can clear its context.                          ---*/

     (Void) soDlgCloseAllPendingTxn (cLeg);

     /*--- For Initial INVITE, we should termniating call leg on expires   ---*
      *--- timer expiry                                                       */
      if (cLeg->clegState <= SO_CLEG_STATE_EARLY)
          cLeg->clegState =  SO_CLEG_STATE_TERMINATED;

     /*--- Delete the call leg, if there is no transaction alive           ---*/
      soCoreChkAndDelCall (callCb);

     /*------- so025.201 : For 1.2 interface pass if internal message --------*/
#ifdef SO_REL_1_2_INF
      soUiErrInd (sSapCb, suConnId, spConnId, NULLP, cLegId, SOT_ET_INVITE,
                  SOT_ERR_EXPIRES_TIMEOUT, TRUE, FALSE);
#else
      soUiErrInd (sSapCb, suConnId, spConnId, NULLP, cLegId, SOT_ET_INVITE,
                  SOT_ERR_EXPIRES_TIMEOUT, TRUE);
#endif
   }

  RETVOID;

} /* soUaExpiresTmrExpiry */



/*
*
*       Fun:   soUaExpiresTmrExpiry
*
*       Desc:  This function is invoked when the Expires timer
*              expires.
*
*       Ret:   ROK        success
*              RFAILED    failure
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soUaCancelTimeout
(
SoCLegCb    *cLeg   /* Call Leg Cb */
)
#else
PUBLIC Void soUaCancelTimeout(cLeg)
SoCLegCb    *cLeg;  /* Call Leg Cb */
#endif
{
  SoTransCb   *transCb;  /* Transaction cb */
  SoCallCb    *callCb;   /* Call Cb*/
  UConnId     suConnId;  /* SU conn Id */
  UConnId     spConnId;  /* spConnId */
  SoSSapCb    *ssap;     /* SSAP cb */
  U32         legId;     /* Leg Id */
  /* so020.201 : Previous entry in hash list */
  SoTransCb   *prevTransCb;

  TRC2(soUaCancelTimeout);

  /* See if the transaction to be cancelled exists */
  transCb = soDlgLocateCancelTrans(cLeg, NULLP, SO_OTHER);
  if (transCb == NULLP)
    RETVOID;

  soTxnDeleteTrans(transCb);

  /* so019.201 : Delete cancel transaction as well */
  /* so020.201 : use last transCb to findout next element in list */
  prevTransCb = NULLP;
  while (cmHashListGetNext(&cLeg->tranCbLst,
                           (PTR)prevTransCb,
                           (PTR*)&transCb) == ROK)
  {
     if(transCb->transMethod == SOT_ET_CANCEL)
     {
        soTxnDeleteTrans(transCb);
        break;
     }
     else
        prevTransCb = transCb;
  }

  callCb= cLeg->call;
  ssap = callCb->ssapCb;

  /* so009.201 : Used user conn id instead of suConnId in callCb */
  suConnId = cLeg->userConnId;
  spConnId = callCb->spConnId;
  legId    = cLeg->legId;

  if (CM_HASH_NMBENT(&cLeg->tranCbLst) == 0)
  {
    soDlgDeleteCleg(callCb, cLeg);
  }
  if (cmLListLen(&callCb->cLegLst) == 0)
    soCoreDeleteCallCb(callCb);

  /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
  soUiErrInd(ssap, suConnId, spConnId, 
             NULLP, legId, SOT_ET_CANCEL, SOT_ERR_CANCEL_TIMEOUT, TRUE, FALSE);
#else
  soUiErrInd(ssap, suConnId, spConnId, 
             NULLP, legId, SOT_ET_CANCEL, SOT_ERR_CANCEL_TIMEOUT, TRUE);
#endif

  RETVOID;
  
}




/*
*
*       Fun:   soUaRegTimeout
*
*       Desc:  Registration timeout for remote registration
*
*       Ret:   ROK/RFAILED
*
*       Notes: Used to notify service user and/or to automatically reregister
*
*               SCC has reviewed for RC testing and resource release
*
*       File:  so_ua
*
*/

#ifdef ANSI
PUBLIC Void soUaRegTimeout
(
SoRegContactCb    *contactCb  /* Contact control block */
)
#else
PUBLIC Void soUaRegTimeout (contactCb)
SoRegContactCb    *contactCb; /* Contact control block */
#endif
{
   SoCLegCb    *cLeg;      /* call leg for this request       */
   SoCLegCb    tmpCLeg;    /* Tmp call leg                    */
   S16         ret;        /* Return value                    */
   SoEvnt      *evnt;      /* Register event */
   SoUserCtxt  userCtxt;    /* user context */
   /* so026.201 : Register event */
   SoEvnt      *newEvnt = NULLP;      
   SoContact     *contact;       /* Ptr to contact    */
   SoContact     *newContact;       /* Ptr to contact    */

   TRC2(soUaRegTimeout);

  /*--- so014.201: Initialize local variable ---*/
  ret      = ROK;
   cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

   cLeg = contactCb->cLeg;

   if (cLeg == NULLP)
   {
     SODBGP_SO(SO_DBGMASK_UA,
               (soCb.init.prntBuf,
                "soUaRegTimeOut: No call leg found \n"));
     SOFREE(contactCb, sizeof(SoRegContactCb));
     RETVOID;

   }

   evnt = contactCb->storedReq;

   /* update statistics */
   cLeg->call->ent->otherSts.regTO++;
   soCb.sts.otherSts.regTO++;

   /* If User needs to be informed on expiry */
   if (cLeg->call->ent->s.ua.reCfg.alertUsrOnExp == TRUE)
   {
     /* Send REG_TMO event to service user */
     SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
               "soUaRegTimeout: Registration timeout indication to SU"));

     /* so011.201: Clear the call leg before sending the indication
        to the user application. Create a tmp call Leg to pass on the 
        information to the user application */

     /* Update relevant call leg fields. Update other cLeg fields here 
        too, if required so in the future */
     tmpCLeg.legId = cLeg->legId;
     tmpCLeg.call = cLeg->call;
     tmpCLeg.userConnId = cLeg->userConnId;

     /* Do not delete evnt yet */
     contactCb->storedReq = NULLP;

     /* Delete the contact */
     SO_UA_DEL_CONTACT(cLeg, contactCb);

     if (cLeg->regInfo.numRegContacts == 0)
     {
       soDlgDeleteCleg(cLeg->call, cLeg);
     }

     /* Send indication to user application */
     soRefreshInd(&tmpCLeg, evnt, SOT_ET_REG_TMO);

     /* Free the Stored Evnt */
     soCmFreeEvent(evnt);

     RETVOID;
   }

   /* If User is not to be informed and if automatic refresh
      is not enabled. Dont do anything. Clear the contact */
   if (cLeg->call->ent->s.ua.reCfg.refreshOnExp == FALSE)
   {
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
         "soUaRegTimeout: Registration timeout - no autorefresh\n"));

      /* delete the contact */
      SO_UA_DEL_CONTACT(cLeg, contactCb);
      if (cLeg->regInfo.numRegContacts == 0)
      {
        soDlgDeleteCleg(cLeg->call, cLeg);
      }


      RETVOID;
   }


   /* If contact info need to be auto refreshed */

   /* so026.201 : create a new event and delete the old one */
   ret = soUaRequestBuild(cLeg, SOT_ET_REGISTER, &newEvnt);
   /* Create a new event */
   if (ret != ROK)
   {
      RETVOID;
   }
   if (soCmFindHdrChoice(evnt, (U8 **) &contact, SO_HEADER_GEN_CONTACT) == ROK)
   {
      if (soCmCreateHdrChoice(newEvnt, (U8 **)&newContact, SO_HEADER_GEN_CONTACT) != ROK)
         RETVOID;

      ret = soUtlCpySoContact(newContact, contact, &newEvnt->memCp);
      if (ret != ROK) 
         RETVOID;
   }
   contactCb->storedReq = newEvnt;

   /* Free the old event */
   (Void) soCmFreeEvent(evnt);

   /* Adjust cSeq */
   cLeg->storedHdrs.cSeqHiTx = cLeg->regInfo.regCb->currCSeq;

   /* Store new CSeq in the contactCb */
   contactCb->currCSeq = cLeg->storedHdrs.cSeqHiTx;

   if (ret == ROK)
     ret = soUtlAddExpires(cLeg->call->ent, newEvnt);

   if (ret != ROK)
   {
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
            "soUaRegTimeout: Failed to create reregister message\n"));
      /* To do return error to the user  */

      /* delete the contact */
      SO_UA_DEL_CONTACT(cLeg, contactCb);
      if (cLeg->regInfo.numRegContacts == 0)
      {
        soDlgDeleteCleg(cLeg->call, cLeg);
      }
      RETVOID;
   }

   /* Increment the CSeq stored in the regCb */
   cLeg->regInfo.regCb->currCSeq++;


   /* Put the contact into the pending List in the call Leg */
   cmLListNode(&((contactCb)->cLegLstNode)) = (PTR) (contactCb);
   cmLListAdd2Tail(&cLeg->regInfo.pendContactLst, &((contactCb)->cLegLstNode)); 


   /* Update the transaction Id  based on the call Leg */
   /* Generate a new transaction id for the cancel */
   SO_TXN_AllOC_TRANSID (newEvnt->transId, newEvnt->eventType.val, cLeg->call->ent);

   SO_FILL_USER_CTXT(userCtxt, TRUE, TRUE);
   ret = soDlgUaOutReq(cLeg, &userCtxt, newEvnt);
   if (ret != SOT_ERR_NOERR)
   { 
     SO_UA_DEL_CONTACT(cLeg, contactCb);
     if (cLeg->regInfo.numRegContacts == 0)
     {
       soDlgDeleteCleg(cLeg->call, cLeg);
     }
   }

   RETVOID;
} /* soUaRegTimeout */




/***************************************************************/
/*                 Session Timer Related Functions             */
/***************************************************************/
/* so003.201 : Session-Timer feature made compliant to draft 14. */
#ifdef SO_SESSTIMER


/**************************************************************
*
*       Fun:    soUacSessTmrPrcReq
*
*       Desc:   This function will 
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_ua.c
*
*************************************************************/

#ifdef ANSI
PRIVATE  S16 soUacSessTmrPrcReq
(
SoEntCb        *ent,       /* Entity Cb */
SoCLegCb       *cLeg,      /* Call Leg Cb */
SoEvnt         *evnt       /* Event Cb */      
)
#else
PRIVATE  S16 soUacSessTmrPrcReq(ent, cLeg, evnt)
SoEntCb        *ent;       /* Entity Cb */
SoCLegCb       *cLeg;      /* Call Leg Cb */
SoEvnt         *evnt;      /* Event Cb */ 
#endif /* ANSI */
{  
   S16               cnt;
   SoSessionExpires  *soSessExp;
   SoSessExpParam    *param;
   SoMinSE           *soMinSe;
   Bool              sessExpiresFound;
   Bool              minSeFound;
   Bool              refrshrFound;

   TRC2(soUacSessTmrPrcReq);

   /* Initialisations */
   soSessExp = NULLP;
   soMinSe = NULLP;
   sessExpiresFound = FALSE;
   refrshrFound = FALSE;
   minSeFound = FALSE;

   /* Find session expire header in the message */
   if (soCmFindHdrChoice(evnt, (U8 **) &soSessExp, SO_HEADER_GEN_SESSION_EXPIRES) == ROK)
      sessExpiresFound = TRUE;

   /* Check if UAC asked for Session-Timer feature 
    *
    * Session-Timer feature can be invoked for the first time in 
    * the following ways:
    *
    * 1: User sent Session-Expires header in (INVITE)
    * 2: User sent Session-Expires header in (re-INVITE)
    * 3: User sent Session-Expires header in (UPDATE)
    * 4: Stack is configured to send default Session-Expires
   */ 
   if ((sessExpiresFound             == FALSE) && 
       (ent->reCfg.useSessTmr        == FALSE) &&
       (cLeg->sessTmrCb.sessTimerVal == 0))
      RETVALUE(SOT_ERR_NOERR);

   /* Allow UPDATE only if Session-Expires header is present, SIP stack does 
    * not add Session-Expires header in UPDATE by default */
   /* Allow UPDATE to refresh only if first 2xx response is already received */
   if ((evnt->eventType.val == SOT_ET_UPDATE) &&
       ((sessExpiresFound   == FALSE) || 
        (cLeg->clegState    <  SO_CLEG_STATE_ACK_PEND)))
      RETVALUE(SOT_ERR_NOERR);

   /* Find the Min-SE header in the message */ 
   if (soCmFindHdrChoice(evnt, (U8 **) &soMinSe, SO_HEADER_GEN_MINSE) == ROK)
      minSeFound = TRUE;

   /* If we reach here, Session-Timer has to be invoked */
   /* Check if Session-Timer is already running */
   if (cLeg->sessTmrCb.sessTimerVal == 0)
   {
      /* This is the feature initiation. Check if the configuration 
         mandates default Session-Expires header */
      if ((sessExpiresFound == FALSE) && (ent->reCfg.useSessTmr == TRUE))
      {
         /* Add the session expires header to the message */
         if (soCmCreateHdrChoice(evnt, (U8 **)&soSessExp, SO_HEADER_GEN_SESSION_EXPIRES) != ROK)
            RETVALUE(SOT_ERR_RSRC);

         soSessExp->deltaSeconds.pres   = PRSNT_NODEF;
         soSessExp->deltaSeconds.val    = ent->reCfg.sessTmrVal;
         soSessExp->params.numComp.pres = NOTPRSNT;
      }

      /* If there is no min SE and the stack is configured to have a 
         min SE then add it here */
      if ((minSeFound == FALSE) && (ent->reCfg.minSe != 0))
      {
         /* Add the MIN-SE header to the message */
         if (soCmCreateHdrChoice(evnt, (U8 **)&soMinSe, SO_HEADER_GEN_MINSE) != ROK)
            RETVALUE(SOT_ERR_RSRC);
          
         soMinSe->pres.pres = PRSNT_NODEF;
         soMinSe->deltaSeconds.pres = PRSNT_NODEF;
         soMinSe->deltaSeconds.val = ent->reCfg.minSe;
          
         minSeFound = TRUE;
      }

      /* If the user has added the MinSe header, then make sure that the
         Session Timer value is same/greater than MinSe */
      if ((minSeFound == TRUE) && 
          (soSessExp->deltaSeconds.val < soMinSe->deltaSeconds.val))
         soSessExp->deltaSeconds.val = soMinSe->deltaSeconds.val;

      /* Initialize Session-Timer control block */
      soUaInitSessTmrCb(cLeg, soSessExp, soMinSe, SO_CALLROLE_UAC);
   }
   else
   {
      /* Session-Timer is already running, this message is for 
         refresh, stop running timers, and renegotiate session timer */

      /* If needed stop the session timer */
      /* so030.201: Stop Session Timer on 2xx Resp only */

      /* Add Session-Expires header if not present */
      if (sessExpiresFound == FALSE)
      {
         if (soCmCreateHdrChoice(evnt, (U8 **)&soSessExp, SO_HEADER_GEN_SESSION_EXPIRES) != ROK)
            RETVALUE(SOT_ERR_RSRC);
       
         /* Initialise Session Expires header */
         soSessExp->deltaSeconds.pres = PRSNT_NODEF;
         soSessExp->deltaSeconds.val = cLeg->sessTmrCb.sessTimerVal;
         sessExpiresFound = TRUE;
      }

      /* Draft mentions optional Min-SE in INVITE, also if 
       * 422 response is received, Min-SE is a must in INVITE.
       * To avoid polling for 422, Min-SE will be added whenever
       * it is present in session timer block. For a re-INVITE, 
       * always use the Min-SE value stored in session timer block, 
       * as this will be the max of the configured value and 
       * the 422 response.
      */ 
      if ((minSeFound == FALSE) && 
          (cLeg->sessTmrCb.minSe != 0))
      {
         /* Add the MIN-SE header to the message */
         if (soCmCreateHdrChoice(evnt, (U8 **)&soMinSe, SO_HEADER_GEN_MINSE) != ROK)
            RETVALUE(SOT_ERR_RSRC);

         soMinSe->pres.pres = PRSNT_NODEF;
         soMinSe->deltaSeconds.pres = PRSNT_NODEF;
         soMinSe->deltaSeconds.val = cLeg->sessTmrCb.minSe;

         minSeFound = TRUE;
      }

      if (minSeFound == TRUE) 
      {
         /* If the user has added the MinSe header, then make sure that the
            value is same/greater than MinSe in session timer block */
         if (soMinSe->deltaSeconds.val < cLeg->sessTmrCb.minSe)
            soMinSe->deltaSeconds.val = cLeg->sessTmrCb.minSe;

         /* If the user has added the MinSe header, then make sure that the
            Session Timer value is same/greater than MinSe */
         if (soSessExp->deltaSeconds.val < soMinSe->deltaSeconds.val)
            soSessExp->deltaSeconds.val = soMinSe->deltaSeconds.val;
      }

      /* If the user didn't specify then the value of the refresher depends 
         on the call role */
      if (soSessExp->params.numComp.pres != NOTPRSNT)
      {  
         for (cnt = 0; cnt < soSessExp->params.numComp.val; cnt++)
         {  
            param = soSessExp->params.param[cnt];

            if ((param->type.pres        != NOTPRSNT) &&
                (param->type.val         == SO_SESSION_EXP_REFRESHER) &&
                (param->u.refresher.pres == PRSNT_NODEF))
            {  
               refrshrFound = TRUE;
               break;
            }
         }
      }

      if (refrshrFound == FALSE)
      {
         if (soUtlCpyGetMem((Ptr*)&(soSessExp->params.param),
                             sizeof(Ptr)*(1), &evnt->memCp) != ROK)
            RETVALUE(SOT_ERR_RSRC);

         if (soUtlCpyGetMem((Ptr*)&(soSessExp->params.param[0]),
                             sizeof(SoSessExpParam), &evnt->memCp) != ROK)
         {
            SOFREE(soSessExp->params.param, sizeof(Ptr)*(1));
            RETVALUE(SOT_ERR_RSRC);
         }

         soSessExp->params.numComp.pres = PRSNT_NODEF;
         soSessExp->params.numComp.val = 1;

         param = soSessExp->params.param[0];
         param->type.pres = PRSNT_NODEF;
         param->type.val = SO_SESSION_EXP_REFRESHER;
         param->u.refresher.pres = PRSNT_NODEF;

         /* If the user didn't specify then the value of the refresher depends 
            on the callrole */
         param->u.refresher.val = SO_REFRESHER_UAC;

         if (((cLeg->sessTmrCb.callRole  == SO_CALLROLE_UAS) && 
              (cLeg->sessTmrCb.refresher == SO_REFRESHER_UAC)) ||
             ((cLeg->sessTmrCb.callRole  == SO_CALLROLE_UAC) && 
              (cLeg->sessTmrCb.refresher == SO_REFRESHER_UAS)))
            param->u.refresher.val = SO_REFRESHER_UAS;
      }

      /* re-Initialize Session-Timer control block */
      soUaInitSessTmrCb(cLeg, soSessExp, soMinSe, SO_CALLROLE_UAC);
   }

   RETVALUE(SOT_ERR_NOERR);
}





/*****************************************************************************
*
*       Fun:    soUacSessTmrPrc2xx
*
*       Desc:   This function will process the 2xx response in the UAC side
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*               SCC has reviewed for RC testing and resource release
*
*       File:   so_ua.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE  S16 soUacSessTmrPrc2xx
(
SoEntCb        *ent,       /* Entity Cb */
SoCLegCb       *cLeg,      /* Call Leg Cb */
SoEvnt         *evnt       /* Event Cb */      
)
#else
PRIVATE  S16 soUacSessTmrPrc2xx(ent, cLeg, evnt)
SoEntCb        *ent;       /* Entity Cb */
SoCLegCb       *cLeg;      /* Call Leg Cb */
SoEvnt         *evnt;      /* Event Cb */ 
#endif /* ANSI */
{  
   SoSessionExpires  *soSessExp;
   Bool              sessExpiresFound;
   Bool              refrshrFound;
   Bool              reqTimerTagPres;
   S16               cnt;
   SoSessExpParam    *param;

   TRC2(soUacSessTmrPrc2xx);
   
   /* Initialisations */
   soSessExp = NULLP;
   sessExpiresFound = FALSE;
   reqTimerTagPres = FALSE;
   refrshrFound = FALSE;
   
   /* We reach here for 2XX response to an INVITE/UPDATE */

   /* Check if there is a require timer present if yes then we must have a 
    * Session - Expires. Other wise we will raise an error. */
   if (soUtlChkOptionTag(evnt, SO_HEADER_GEN_REQUIRE, SO_OPTIONTAG_TIMER) == ROK)
      reqTimerTagPres = TRUE; 

   /* Find Session-Expire header in the message */
   if (soCmFindHdrChoice(evnt, (U8 **) &soSessExp, 
                         SO_HEADER_GEN_SESSION_EXPIRES) == ROK)
      sessExpiresFound = TRUE;

   /* If Require & !sessExpiresFound, return ERROR */
   if ((reqTimerTagPres == TRUE) && (sessExpiresFound == FALSE))
      RETVALUE(SOT_ERR_MAND_HDR);

   /* Check if the feature is enabled. The feature may have been invoked by
    * UAC by sending Session-Expires in INVITE/UPDATE. UAS can also enable
    * the feature by sending Session-Expires in 200 OK. */
   if ((sessExpiresFound == FALSE) && 
       (cLeg->sessTmrCb.sessTimerVal == 0))
      RETVALUE(SOT_ERR_NOERR);

   /* Check if UAS supports Session-Timer */
   if (sessExpiresFound == TRUE)
   {
      /* UAC supports Session-Timer. Store final changed value 
       * of Session-Expires in session timer block. Also set
       * callRole, in case, UAC did not initiate the feature */
      cLeg->sessTmrCb.sessTimerVal = soSessExp->deltaSeconds.val;
      cLeg->sessTmrCb.callRole = SO_REFRESHER_UAC;

      /* Check for refresher value */
      if (cLeg->sessTmrCb.refresher == SO_REFRESHER_NONE)
      {
         /* refresher not set by UAC, check refresher in msg */
         if (soSessExp->params.numComp.pres != NOTPRSNT)
         {  
            for (cnt = 0; cnt < soSessExp->params.numComp.val; cnt++)
            {  
               param = soSessExp->params.param[cnt];

               if ((param->type.pres        != NOTPRSNT) &&
                   (param->type.val         == SO_SESSION_EXP_REFRESHER) &&
                   (param->u.refresher.pres == PRSNT_NODEF))
               {  
                  cLeg->sessTmrCb.refresher = param->u.refresher.val;
                  refrshrFound = TRUE;
                  break;
               }
            }
         }

         /* UAS did not specify the refresher value, strange, set to UAC */
         if (refrshrFound == FALSE)
            cLeg->sessTmrCb.refresher = SO_REFRESHER_UAC;
      }
   }
   else
      /* UAS does not support Session-Timer, assume as if UAS asked for 
       * UAC to be the refresher */
      cLeg->sessTmrCb.refresher = SO_REFRESHER_UAC;

   /* Start Session-Expires timer */
   soStartSessTimer(cLeg);

   RETVALUE(SOT_ERR_NOERR);
} /* end of soUacSessTmrPrc2xx */



/*****************************************************************************
*
*       Fun:    soUacSessTmrPrc422Rsp
*
*       Desc:   This function will process the 422 response in the UAC side
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*               SCC has reviewed for RC testing and resource release
*
*       File:   so_ua.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE  S16 soUacSessTmrPrc422Rsp
(
SoEntCb       *ent,       /* Entity Cb */
SoCLegCb       *cLeg,      /* Call Leg Cb */
SoEvnt         *evnt       /* Event Cb */      
)
#else
PRIVATE  S16 soUacSessTmrPrc422Rsp(ent, cLeg, evnt)
SoEntCb       *ent;       /* Entity Cb */
SoCLegCb       *cLeg;      /* Call Leg Cb */
SoEvnt         *evnt;      /* Event Cb */ 
#endif /* ANSI */
{  
   S16               ret = ROK;
   SoSessionExpires  *soSessExp;
   SoMinSE           *soMinSe, *soMinSeOld;
   Bool              reqTimerTagPres;
   SoUserCtxt        userCtxt;

   TRC2(soUacSessTmrPrc422Rsp);

   cmMemset ((U8 *)&userCtxt, 0, sizeof (SoUserCtxt));

   /* Initialisations */
   soSessExp = NULLP;
   soMinSe = NULLP;
   reqTimerTagPres = FALSE;

   /* We reach here for 422 response to an INVITE */
   /* Retry INVITE with changed values of Session-Expires */

   /* Find to Min Se header in message */
   if (soCmFindHdrChoice(evnt, (U8 **) &soMinSe, SO_HEADER_GEN_MINSE) != ROK)
      RETVALUE(SOT_ERR_MAND_HDR);

   /* Find to session exipre header in sentReq message */
   if (soCmFindHdrChoice(cLeg->sentInvite, (U8 **) &soSessExp, 
                            SO_HEADER_GEN_SESSION_EXPIRES) != ROK)
      RETVALUE(SOT_ERR_MAND_HDR);

   /* Add Min-SE header to the previously sent INVITE message, if 
    * it is not already present */
   if (soCmFindHdrChoice(cLeg->sentInvite, (U8 **) &soMinSeOld,
                         SO_HEADER_GEN_MINSE) != ROK)
      if (soCmCreateHdrChoice(cLeg->sentInvite, (U8 **)&soMinSeOld, SO_HEADER_GEN_MINSE) != ROK)
         RETVALUE(SOT_ERR_RSRC);

   soSessExp->deltaSeconds.val  = soMinSe->deltaSeconds.val;

   soMinSeOld->pres.pres = PRSNT_NODEF;
   soMinSeOld->deltaSeconds.pres = PRSNT_NODEF;
   soMinSeOld->deltaSeconds.val =  soMinSe->deltaSeconds.val;
    
   /* Re-Init Data in Session-timer control block */
   soUaInitSessTmrCb(cLeg, soSessExp, soMinSeOld, SO_CALLROLE_UAC);

   /* Since INVITE is being re-sent, reset cleg state */
   /*---- so018.201: Also reset remote tag stored  ---*/
   cLeg->clegState = SO_CLEG_STATE_NONE;

   (Void) soCmRemoveRemoteTag (ent, cLeg);

   /*-- so038.201:Update dialog creating CSEQ Value --*/
   cLeg->storedHdrs.dlgCreateCSeq = cLeg->storedHdrs.cSeqHiTx;

   /* Generate a new transaction id for the re-INVITE */
   SO_TXN_AllOC_TRANSID (cLeg->sentInvite->transId, 
                         cLeg->sentInvite->eventType.val, cLeg->call->ent);

   SO_FILL_USER_CTXT(userCtxt, TRUE, FALSE);
   ret = soDlgUaOutReq(cLeg, &userCtxt, cLeg->sentInvite);

   if (ret != SOT_ERR_NOERR)
   {
      /* so009.201 : Used user conn id instead of suConnId in callCb */
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
     soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
                cLeg->call->spConnId, 
                cLeg->sentInvite, 
                cLeg->sentInvite->callLegId, 
                cLeg->sentInvite->eventType.val, ret, TRUE, FALSE);
#else
     soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
                cLeg->call->spConnId, 
                cLeg->sentInvite, 
                cLeg->sentInvite->callLegId, 
                cLeg->sentInvite->eventType.val, ret, TRUE);
#endif
     cLeg->sentInvite = NULLP;
   }
   
   RETVALUE(ret);
} /* end of soUacSessTmrPrc422Rsp */




/*****************************************************************************
*
*       Fun:    soUasSessTmrPrcReq
*
*       Desc:   This function will process the Invite Request in the UAS side
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*               SCC has reviewed for RC testing and resource release
*
*       File:   so_ua.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE  S16 soUasSessTmrPrcReq 
(
SoEntCb       *ent,       /* Entity Cb */
SoCLegCb       *cLeg,      /* Call Leg Cb */
SoEvnt         *evnt       /* Event Cb */      
)
#else
PRIVATE  S16 soUasSessTmrPrcReq(ent, cLeg, evnt)
SoEntCb       *ent;       /* Entity Cb */
SoCLegCb       *cLeg;      /* Call Leg Cb */
SoEvnt         *evnt;      /* Event Cb */ 
#endif /* ANSI */
{  
   SoSessionExpires  *soSessExp;
   SoMinSE           *soMinSe;
   Bool              reqTimerTagPres;
   U32               minSeVal;

   TRC2(soUasSessTmrPrcReq);
   
   /* Initialisations */
   soSessExp = NULLP;
   soMinSe = NULLP;
   reqTimerTagPres = FALSE;
   minSeVal = 0;
   
   /* Check if UAC sent Session-Expires */
   if (soCmFindHdrChoice(evnt, (U8 **) &soSessExp, SO_HEADER_GEN_SESSION_EXPIRES) != ROK)
   {
      /* so034.201 : In case of receipt of ReInvite without Session Expire
       * header the role of the UAC/UAS is not changed
       */
       /* so041.201 : In case previous call role was UAC & refresher also UAC, 
        * now call role is modified to UAS since ReInvite without Session 
        * Expire header is recieved, the role of refersher UAC/UAS needs to be 
        * changed
        */
       if ((cLeg->sessTmrCb.callRole  == SO_CALLROLE_UAC) &&
              (cLeg->sessTmrCb.refresher == SO_REFRESHER_UAC))
          cLeg->sessTmrCb.refresher = SO_REFRESHER_NONE;

      RETVALUE(SOT_ERR_NOERR);
   }

   /* This may be the feature initiation, or it may be a re-negotiation */
   /* If needed stop the session timer */
   /* so030.201: Stop Session Timer on 2xx Resp only */

   /* Find the Min-SE header in the message */ 
   if (soCmFindHdrChoice(evnt, (U8 **) &soMinSe, SO_HEADER_GEN_MINSE) == ROK)
      minSeVal = soMinSe->deltaSeconds.val;  

   /* Take the max of the incoming and the configured value */
   minSeVal = (minSeVal > ent->reCfg.minSe) ? minSeVal : ent->reCfg.minSe;

   /* Make sure that the Session Timer value is same/greater than MinSe */
   if (soSessExp->deltaSeconds.val < minSeVal)
      RETVALUE(SOT_RSP_422_SESSTIMER_TOO_SMALL);

   /* Initialize Session-Timer control block */
   /* Store MAX minSeVal in cLeg */
   soUaInitSessTmrCb(cLeg, soSessExp, soMinSe, SO_CALLROLE_UAS);
   cLeg->sessTmrCb.minSe = minSeVal;

   RETVALUE(SOT_ERR_NOERR);
} /* end of soUasSessTmrPrcReq */




/*****************************************************************************
*
*       Fun:    soUasSessTmrPrc2xx
*
*       Desc:   This function will send the 2xx response
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*               SCC has reviewed for RC testing and resource release
*
*       File:   so_ua.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE  S16 soUasSessTmrPrc2xx
(
SoEntCb       *ent,       /* Entity Cb */
SoCLegCb       *cLeg,      /* Call Leg Cb */
SoEvnt         *evnt       /* Event Cb */      
)
#else
PRIVATE  S16 soUasSessTmrPrc2xx(ent, cLeg, evnt)
SoEntCb       *ent;       /* Entity Cb */
SoCLegCb       *cLeg;      /* Call Leg Cb */
SoEvnt         *evnt;      /* Event Cb */ 
#endif /* ANSI */
{  
   SoSessionExpires  *soSessExp;
   S16               cnt;
   SoSessExpParam    *param;
   Bool              sessExpiresFound;
   Bool              refrshrFound;

   TRC2(soUasSessTmrPrc2xx);

   /* Initialisations */
   soSessExp = NULLP;
   sessExpiresFound = FALSE;
   refrshrFound = FALSE;

   /* We reach here for 2XX response to an INVITE/UPDATE on UAS side */
   /* Find session expire header in the message */
   if (soCmFindHdrChoice(evnt, (U8 **) &soSessExp, SO_HEADER_GEN_SESSION_EXPIRES) == ROK)
      sessExpiresFound = TRUE;

   /*so024.201 : Session Timer Configuration on UAS side also*/
   /* Check if feature enabled */
   if ((sessExpiresFound == FALSE) && 
       (cLeg->sessTmrCb.sessTimerVal == 0) &&
       (ent->reCfg.useSessTmr != TRUE))
      RETVALUE(SOT_ERR_NOERR);

   /* If we reach here, Session-Timer is enabled */
   /* Add the session expires header to the message */
   if (sessExpiresFound == FALSE)
   {
      if (soCmCreateHdrChoice(evnt, (U8 **)&soSessExp, SO_HEADER_GEN_SESSION_EXPIRES) != ROK)
         RETVALUE(SOT_ERR_RSRC);

      /* Initialise Session Expires header */
      soSessExp->deltaSeconds.pres = PRSNT_NODEF;
      /* so024.201 : Session Timer Configuration on UAS side also*/
      if ((ent->reCfg.useSessTmr == TRUE) && 
            (cLeg->sessTmrCb.sessTimerVal == 0))
      {
        soSessExp->deltaSeconds.val = ent->reCfg.sessTmrVal;
      }
      else
      {
        soSessExp->deltaSeconds.val = cLeg->sessTmrCb.sessTimerVal;
      }
      
   }

   /* Store final changed value of Session-Expires 
    * in Session timer block (if User sent Session-Expires header
    * and the value is different from the one in cLeg */
   cLeg->sessTmrCb.sessTimerVal = soSessExp->deltaSeconds.val;

   /* Set callRole in case UAS initiated the feature and 
    * UAC did not */
   cLeg->sessTmrCb.callRole = SO_REFRESHER_UAS;

   /* Find refresher parameter */
   if (soSessExp->params.numComp.pres != NOTPRSNT)
   {  
      for (cnt = 0; cnt < soSessExp->params.numComp.val; cnt++)
      {  
         param = soSessExp->params.param[cnt];

         if ((param->type.pres        != NOTPRSNT) &&
             (param->type.val         == SO_SESSION_EXP_REFRESHER) &&
             (param->u.refresher.pres == PRSNT_NODEF))
         {  
            refrshrFound = TRUE;
            break;
         }
      }
   }

   if (refrshrFound == FALSE)
   {
      if (soUtlCpyGetMem((Ptr*)&(soSessExp->params.param),
                          sizeof(Ptr)*(1), &evnt->memCp) != ROK)
         RETVALUE(SOT_ERR_RSRC);

      if (soUtlCpyGetMem((Ptr*)&(soSessExp->params.param[0]),
                          sizeof(SoSessExpParam), &evnt->memCp) != ROK)
      {
         SOFREE(soSessExp->params.param, sizeof(Ptr)*(1));
         RETVALUE(SOT_ERR_RSRC);
      }

      soSessExp->params.numComp.pres = PRSNT_NODEF;
      soSessExp->params.numComp.val = 1;

      param = soSessExp->params.param[0];
      param->type.pres = PRSNT_NODEF;
      param->type.val = SO_SESSION_EXP_REFRESHER;
      param->u.refresher.pres = PRSNT_NODEF;

      /* Init the value of refresher */
      param->u.refresher.val = SO_REFRESHER_UAS;
   }

   /* Check if refresher value already given by UAC, if so,
    * override the one given by UAS */
   if (cLeg->sessTmrCb.refresher != SO_REFRESHER_NONE)
      param->u.refresher.val = cLeg->sessTmrCb.refresher;
   else
      /* Store final refresher value */
      cLeg->sessTmrCb.refresher = param->u.refresher.val;

   /* Start Session-Expires timer */
   soStartSessTimer(cLeg);

   RETVALUE(SOT_ERR_NOERR);
} /* end of soUasSessTmrPrc2xx */





/*****************************************************************************
*
*       Fun:    soUaxSessTmrExpiry
*
*       Desc:   This function will process the session timer expiry 
*
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*               SCC has reviewed for RC testing and resource release
*
*       File:   so_ua.c
*
*****************************************************************************/

#ifdef ANSI
PUBLIC Void soUaxSessTmrExpiry
(
SoCLegCb       *cLeg      /* Call Leg Cb */
)
#else
PUBLIC Void soUaxSessTmrExpiry(cLeg)
SoCLegCb       *cLeg;     /* Call Leg Cb */
#endif /* ANSI */
{
   /* so030.201: Stop Session Timer on 2xx Resp only */
   if (cLeg->clegState == SO_CLEG_STATE_MODIFY)
   {
      soStartSessTimer(cLeg);
      RETVOID;
   }

   /* If the feature has to be reset, init Session timer 
    * control block except for Min-SE value, if the feature 
    * will be reinvoked, prior negotiated value of Min-SE can
    * be used. The consequence of this is if the feature started
    * by user sending Session-Expires header, that information 
    * will be lost. The present implementation does not support 
    * run time turning off the feature.*/

   /* Check whether refresher or refreshee */
   if (cLeg->sessTmrCb.callRole == cLeg->sessTmrCb.refresher)
      soRefreshInd(cLeg, NULL, SOT_ET_INT_SESSTIMER_EXPD);
   else
      /* so006.201: Set correct eventType */
      /* so009.201 : Used user conn id instead of suConnId in callCb */
      /* so025.201 : For 1.2 interface pass if internal message */
#ifdef SO_REL_1_2_INF
      soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
             cLeg->call->spConnId, NULLP, cLeg->legId, SOT_ET_INT_SESSTIMER_EXPD,
             SOT_RELTYPE_LOCAL, TRUE, FALSE);
#else
      soUiErrInd(cLeg->call->ssapCb, cLeg->userConnId, 
             cLeg->call->spConnId, NULLP, cLeg->legId, SOT_ET_INT_SESSTIMER_EXPD,
             SOT_RELTYPE_LOCAL, TRUE);
#endif
} /* end of soUaxSessTmrExpiry */
         




/*****************************************************************************
*
*       Fun:    soStopSessTimer
*
*       Desc:   This function stops the session timers  
*               
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   po_core.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE  S16 soStopSessTimer
(
SoCLegCb    *cLeg         /* Call leg control block */
)
#else
PRIVATE  S16 soStopSessTimer(cLeg)
SoCLegCb    *cLeg;        /* Call leg control block */
#endif /* ANSI */
{  
   S16   ret;

   TRC2(soStopSessTimer);

   /* Initialisations */
   ret = ROK;

   if (cLeg->sessTmrCb.sessTmrRunning != TRUE)
      RETVALUE(ROK);

   soSchedTmr(cLeg, SO_TMR_SESSION_TIMER, TMR_STOP, NOTUSED);  

   cLeg->sessTmrCb.sessTmrRunning = FALSE;

   RETVALUE(ROK);
   
} /* end of soStopSessTimer */





/*****************************************************************************
*
*       Fun:    soUaInitSessTmrCb
*
*       Desc:   Initialises/Updates the values in the soSessTmrCb 
*               
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   so_ua.c
*
*****************************************************************************/
#ifdef ANSI
PRIVATE  S16 soUaInitSessTmrCb
(
SoCLegCb          *cLeg,         /* Call leg control block */
SoSessionExpires  *sessExp,      /* Session Expires */
SoMinSE           *minSe,        /* MinSE */
U8                callRole       /* call role */
)
#else
PRIVATE  S16 soUaInitSessTmrCb(cLeg, sessExp, minSe, callRole)
SoCLegCb          *cLeg;         /* Call leg control block */
SoSessionExpires  *sessExp;      /* Session Expires */
SoMinSE           *minSe;        /* MinSE */
U8                callRole;      /* call role */
#endif /* ANSI */
{  
   S16 cnt;
   SoSessExpParam    *param;

   TRC2(soUaInitSessTmrCb);

   /* Step 1: Init parameters */
   cLeg->sessTmrCb.callRole = callRole;
   cLeg->sessTmrCb.sessTmrRunning = FALSE;       
   cLeg->sessTmrCb.minSe = 0;
   cLeg->sessTmrCb.refresher = SO_REFRESHER_NONE;
   cLeg->sessTmrCb.sessTimerVal = 0;

   if ((sessExp == NULLP) && (minSe == NULLP))
      RETVALUE(ROK);

   /* Step 2: Store Min-SE value */
   if (minSe != NULLP)
   {
      if ((minSe->pres.pres == PRSNT_NODEF) &&
          (minSe->deltaSeconds.pres == PRSNT_NODEF))
         cLeg->sessTmrCb.minSe = minSe->deltaSeconds.val;  
   }
  
   /* Step 3: Store Session-Expires value */
   if (sessExp != NULLP)
   {
      /* Fill in the values from the event */
      if ((sessExp->pres.pres == PRSNT_NODEF) &&
          (sessExp->deltaSeconds.pres == PRSNT_NODEF))
         cLeg->sessTmrCb.sessTimerVal = sessExp->deltaSeconds.val;

      /* Step 4: Store refresher value */
      if (sessExp->params.numComp.pres != NOTPRSNT)
      {
         for (cnt = 0; cnt < sessExp->params.numComp.val; cnt++)
         {
            param = sessExp->params.param[cnt];

            if ((param->type.pres != NOTPRSNT) && 
                (param->type.pres == SO_SESSION_EXP_REFRESHER))
               cLeg->sessTmrCb.refresher = param->u.refresher.val;
         }
      }
   }

   RETVALUE(ROK);
} /* end of soUaInitSessTmrCb */





/*****************************************************************************
*
*       Fun:    soStartSessTimer
*
*       Desc:   This function starts the session timers  
*               
*       Ret:    ROK     - succeeded
*               RFAILED - failed
*
*       Notes:  None
*
*       File:   po_core.c
*
*****************************************************************************/

#ifdef ANSI
PRIVATE S16 soStartSessTimer
(
SoCLegCb    *cLeg         /* Call leg control block */
)
#else
PRIVATE S16 soStartSessTimer(cLeg)
SoCLegCb    *cLeg;        /* Call leg control block */
#endif /* ANSI */
{  
   S16   ret;          /* Return Value */
   U16   timerVal;     /* Timer Value */

   TRC2(soStartSessTimer);

   /* Initialisations */
   ret = ROK;
   cLeg->sessTmrCb.sessTmrRunning = FALSE;

   if (cLeg->sessTmrCb.sessTimerVal == 0)
      RETVALUE(ROK);

#ifdef SO_UA
   if (cLeg->call->ent->entityType == LSO_ENT_UA)
   {
      if (cLeg->sessTmrCb.callRole == cLeg->sessTmrCb.refresher)
         timerVal = cLeg->sessTmrCb.sessTimerVal/2;
      else
      {
         if ((cLeg->sessTmrCb.sessTimerVal/3) > 10)
            timerVal = cLeg->sessTmrCb.sessTimerVal - 10;
         else
            timerVal = cLeg->sessTmrCb.sessTimerVal - 
                        (cLeg->sessTmrCb.sessTimerVal/3);
      }
   }
#endif /* SO_UA */

#ifdef SO_NS
   if (cLeg->call->ent->entityType == LSO_ENT_NS)
      timerVal = cLeg->sessTmrCb.sessTimerVal;
#endif /* SO_NS */

   /* The internal clock is of 100 ms. Hence to convert seconds into equiv
    * milliseconds multiply by 10 */
   timerVal *= 10;

   soSchedTmr(cLeg, SO_TMR_SESSION_TIMER, TMR_STOP, NOTUSED); 
   soSchedTmr(cLeg, SO_TMR_SESSION_TIMER, TMR_START, timerVal); 

   cLeg->sessTmrCb.sessTmrRunning = TRUE;

   RETVALUE(ROK);
   
} /* end of soStartSessTimer */
#endif /* SO_SESSTIMER */




#ifdef SO_EVENT

/*
*
*       Fun:   soFindSubscNode
*
*       Desc:  This function find subsc node  
*              
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PRIVATE S16 soFindSubscNode
(
SoCLegCb   *cLeg,
TknStrOSXL *subId,
SoSubNode **node,
U8         subscType
)
#else
PRIVATE S16 soFindSubscNode(cLeg, subId, node, subscType)
SoCLegCb   *cLeg;
TknStrOSXL *subId;
SoSubNode **node;
U8         subscType;
#endif
{
   CmLList *curNode;
   CmLListCp *subCp;
   SoSubNode *tmpNode;
   
   TRC3(soFindSubscNode);

   /*so028.201:- Debug traces added*/
   if (subId->pres != NOTPRSNT)
   SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
            "soFindSubscNode: Received subId is : "
            "Val = [%s] , Len = [%d],Pres = [%d]\n",
            subId->val, subId->len, subId->pres));
   
   /*so028.201:- Debug traces added*/
   SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
            "soFindSubscNode: Received  :subscType = [%d]\n",
            subscType));

   subCp = &cLeg->subscCb.subCp;
   curNode = cmLListFirst(subCp);
   while (curNode != (CmLList *)NULLP)
   {
      tmpNode   = (SoSubNode *)cmLListNode(curNode);
      curNode  = curNode->next;

      /*so028.201:- Debug traces added*/
      if (tmpNode->subId.pres != NOTPRSNT)
         SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                  "soFindSubscNode: Tmp Node subId is : "
                  "Val = [%s] , Len = [%d],Pres = [%d]\n",
                  tmpNode->subId.val, tmpNode->subId.len, tmpNode->subId.pres));

      /*so028.201:- Debug traces added*/
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
               "soFindSubscNode: Tmp node subscType = [%d]\n",
               tmpNode->type));

      /*---- so026.201: Skip if the state is deleted ----*/
      if (tmpNode->state == SO_SUBSC_FSM_TERMINATE_DONE)
         continue;

      if(subscType == SO_SUBSC_TYPE_REFER)
      {
         if(tmpNode->type == SO_SUBSC_TYPE_REFER)
         {
            if(subId->pres == NOTPRSNT && 
                  tmpNode->subId.pres == NOTPRSNT)
            {
               *node = tmpNode;
               RETVALUE(ROK);
            }
            else if(subId->pres == PRSNT_NODEF && 
                  tmpNode->subId.pres == PRSNT_NODEF && 
                  subId->len == tmpNode->subId.len)
            {
               if(cmMemcmp(subId->val, tmpNode->subId.val, subId->len) == 0)
               {
                  *node = tmpNode;
                  RETVALUE(ROK);
               }
            }          
            /*so028.201: Multiple Refers in a dialog*/
            else if(subId->pres == NOTPRSNT &&
                  tmpNode->subId.pres == PRSNT_NODEF)
            {
               SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                        "[soFindSubscNode]: Notify doesnot conatin id \n"));

               /* This is the special case when First NOTIFY doesn't
                * comes with the "id" field 
                */
               *node = tmpNode;
               RETVALUE(ROK);
            }                        
         }
      }
      else if(subscType == SO_SUBSC_TYPE_SUBSC)
      {
         if(tmpNode->type == SO_SUBSC_TYPE_SUBSC)
         {
            if(subId->pres == NOTPRSNT && tmpNode->subId.pres == NOTPRSNT)
            {
               *node = tmpNode;
               RETVALUE(ROK);
            }
            else if(subId->pres == PRSNT_NODEF && 
                  tmpNode->subId.pres == PRSNT_NODEF && 
                  subId->len == tmpNode->subId.len)
            {
               if(cmMemcmp(subId->val, tmpNode->subId.val, subId->len) == 0)
               {
                  *node = tmpNode;
                  RETVALUE(ROK);
               }
            }          
         }
      }
      else
      {
         /*so028.201:- Debug traces added*/
         SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                  "[soFindSubscNode]: Unknown value for subscType \n"));         
         *node = NULLP;
         RETVALUE(RFAILED);
      }    
   }

   /*so028.201:- Debug traces added*/
   SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
            "[soFindSubscNode]: Subscriber node not Found\n"));
   *node = NULLP;
   RETVALUE(RFAILED);
}   


/*
*
*       Fun:   soAllocSubscNode
*
*       Desc:  This function alloc and init subsc node  
*              
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PRIVATE S16 soAllocSubscNode
(
SoSubNode **node, 
TknStrOSXL *subId,
SoEvnt    *event,
SoCLegCb   *cLeg,
U8         subscType,
Bool       isNotifier

)
#else
PRIVATE S16 soAllocSubscNode(node, subId, event, cLeg,
                   subscType, isNotifier)
SoSubNode **node; 
TknStrOSXL *subId;
SoEvnt    *event;
SoCLegCb   *cLeg;
U8         subscType;
Bool       isNotifier;
#endif
{
   TRC3(soAllocSubscNode);   
   SOALLOC(node, sizeof(SoSubNode));
            
   if(*node == NULLP)
      RETVALUE(RFAILED);
   if(soUtlCpyTknStrOSXL(&((*node)->subId), subId, NULLP) 
      != ROK)
   {
       SOFREE(*node, sizeof(SoSubNode));
       RETVALUE(RFAILED);
   }
   (*node)->type = subscType;
   (*node)->evntPkgType = SO_EVNT_PKG_NON_SUPRT;
   (*node)->state = SO_SUBSC_FSM_INIT;        /* fsm state */
   (*node)->expVal = 0;
   (*node)->isNotifier = isNotifier;
   (*node)->numNotifyMsg = 0;
   (*node)->subscriptionState = SO_SUBSCRIPTION_STATE_NULL;
   (*node)->event = event;
   (*node)->cLeg = cLeg;
   soCmInitTimer(&(*node)->subscTimer);

  /*---- so026.201: Initialize reference count ----*/
   (*node)->refCount = 0;
   
   /*so028.201:- Debug traces added*/
   if (subId->pres != NOTPRSNT)
   SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
            "soAllocSubscNode: Received subId is : "
            "Val = [%s] , Len = [%d],Pres = [%d]\n",
            subId->val, subId->len, subId->pres));

   SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
            "soAllocSubscNode: Received  :subscType = [%d]\n",
            subscType));

   SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
            "soAllocSubscNode: Received  :isNotifier = [%d]\n",
            isNotifier));

   RETVALUE(ROK);
}

/*
*
*       Fun:   SsoSubscFSMUpdateReq
*
*       Desc:  This function update the subsc fsm
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PRIVATE S16 soSubscFSMUpdateReq
(
SoSubNode *node, 
U8 sipMethod, 
Bool isIncoming, 
U8 subscriptionState
)
#else
PRIVATE S16 soSubscFSMUpdateReq(node, sipMethod, 
                       isIncoming, subscriptionState)
SoSubNode *node; 
U8 sipMethod; 
Bool isIncoming; 
U8 subscriptionState;
#endif
{

   TRC3(soSubscFSMUpdateReq);

   if(node->state == SO_SUBSC_FSM_TERMINATE_DONE)
      RETVALUE(RFAILED);
      
   if(subscriptionState == SO_SUBSCRIPTION_STATE_TERMINATED)
   {
      /* this only happens for notify and 
       * mark the node terminated */
      if(node->type == SO_SUBSC_TYPE_NOTIFY)
      {
         node->state = SO_SUBSC_FSM_TERMINATE_DONE;
         (Void)soSchedTmr(node,SO_TMR_SUBSC_EXP,
                          TMR_STOP, NOTUSED);
      }
      else
      {
         node->state = SO_SUBSC_FSM_TERMINATE;
         (Void)soSchedTmr(node,SO_TMR_SUBSC_EXP,
                       TMR_STOP, NOTUSED);
      }

     /*--- so025.201: Delete of subscription moved to more generic place ---*/

      RETVALUE(ROK);
   }
   else if(subscriptionState == SO_SUBSCRIPTION_STATE_PENDING)
   {
      /* invalid state change so terminate the node */
      if(node->subscriptionState == SO_SUBSCRIPTION_STATE_ACTIVE)
      {
         node->state = SO_SUBSC_FSM_TERMINATE_DONE;
         (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                           TMR_STOP, NOTUSED);
         RETVALUE(ROK);
      }
   }
   
   if(sipMethod == SO_METHODSTD_NOTIFY)
   {
      if(node->state == SO_SUBSC_FSM_REFRESH)
      {
         node->state = SO_SUBSC_FSM_NOTIFY_REFRESH;
      }
      else if(node->state == SO_SUBSC_FSM_TIMEOUT)
      {
         node->state = SO_SUBSC_FSM_NOTIFY_TIMEOUT;
      }
      /* only error case will reach here. 
       * The last notify should have 
       * subscription_state = terminated 
       * and this has been processed before. */ 
      else if(node->state == SO_SUBSC_FSM_TERMINATE)
      {
         if(node->type == SO_SUBSC_TYPE_NOTIFY)
         {
            node->state = SO_SUBSC_FSM_TERMINATE_DONE;
            (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                              TMR_STOP, NOTUSED);
         }
      }
      RETVALUE(ROK);
   }
   switch (node->type)
   {
#ifdef SO_REFER      
      case SO_SUBSC_TYPE_REFER:
         /* does not belong to subscribe 
          * so terminate teh node */
         if(sipMethod == SO_METHODSTD_SUBSCRIBE)
         {   
            node->state = SO_SUBSC_FSM_TERMINATE_DONE;
            (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
         }
         else
            node->state = SO_SUBSC_FSM_INIT;
         break;
#endif    
      case SO_SUBSC_TYPE_SUBSC:
         /* expVal == 0 means unsubscribe 
          * so set fsm to terminate */
         if(node->expVal == 0 && 
            node->state != SO_SUBSC_FSM_INIT)
         {
            (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                              TMR_STOP, NOTUSED);
            /* start 32 second timer */
            (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                              TMR_START, 32*SO_TMRVAL_1_S); 
            /* set fsm to terminate */
            node->state = SO_SUBSC_FSM_TERMINATE;
            break;
         }
         if(node->state == SO_SUBSC_FSM_NEUTRAL) 
         {
            node->state = SO_SUBSC_FSM_REFRESH;
            (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
            if(node->expVal)
          (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                           TMR_START, node->expVal);
         }
         else if (node->state == SO_SUBSC_FSM_REFRESH || 
                  node->state == SO_SUBSC_FSM_TIMEOUT)
         {
            node->state = SO_SUBSC_FSM_NEUTRAL;
            (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
            if(node->expVal)
               (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                           TMR_START, node->expVal);
         }
         else if (node->state == SO_SUBSC_FSM_NOTIFY_REFRESH || 
                  node->state == SO_SUBSC_FSM_NOTIFY_TIMEOUT)
         {
            node->state = SO_SUBSC_FSM_NOTIFY;
            (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
            if(node->expVal)
               (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                           TMR_START, node->expVal);
         }
         break;  
      default:
         node->state = SO_SUBSC_FSM_TERMINATE_DONE;
         (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
         break;
   }
   RETVALUE(ROK);      
}




/*
*
*       Fun:   SsoSubscFSMUpdateRsp
*
*       Desc:  This function update the subsc fsm
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PRIVATE S16 soSubscFSMUpdateRsp
(
SoSubNode *node, 
U8 sipMethod, 
U16 statusCode,
U8 subscriptionState,
Bool retryAfter,
TknU32     *expHdr 
)
#else
PRIVATE S16 soSubscFSMUpdateRsp(node,       sipMethod,
                                statusCode, subscriptionState, 
                                retryAfter, expHdr)
SoSubNode *node; 
U8 sipMethod; 
U16 statusCode; 
U8 subscriptionState;
Bool retryAfter;
TknU32 *expHdr; 
#endif
{

   TRC3(soSubscFSMUpdateRsp);

   /*so031.201 Adding for the fix of challenge of NOTIFY request so 
     that Subscription is not deleted after getting 407/401 response */
   if(sipMethod == SO_METHODSTD_NOTIFY)
   {
      if((statusCode == SOT_RSP_407_PROXY_AUTH_REQD ) ||
         (statusCode == SOT_RSP_401_UNAUTHORIZED))
      {
         node->state = SO_SUBSC_FSM_NEUTRAL;
         /*so032.201 :- To remove the memory leak*/
         RETVALUE(ROK);
      }
      /*so032.201 :- To remove the memory leak*/
   }
      
   if(node->state == SO_SUBSC_FSM_TERMINATE_DONE)
      RETVALUE(RFAILED);
   
   if(sipMethod == SO_METHODSTD_NOTIFY)
   {
      /* it is the time to set fsm to final 
       * terminate state when transmitting the 
       * last response of the notify */
      if(node->state == SO_SUBSC_FSM_TERMINATE)
      {
         (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
         node->state = SO_SUBSC_FSM_TERMINATE_DONE;
      }
      /* for error case set node terniomated done */
      else if((statusCode == 481) || 
              (statusCode >= 400 && !retryAfter))
      {
         node->state = SO_SUBSC_FSM_TERMINATE_DONE;
         (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
      }
      else if(node->state == SO_SUBSC_FSM_REFRESH)
      {
         node->state = SO_SUBSC_FSM_NOTIFY_REFRESH;
      }
      else if(node->state == SO_SUBSC_FSM_TIMEOUT)
      {
         node->state = SO_SUBSC_FSM_NOTIFY_TIMEOUT;
      }

     /* so033.201: Remove the state transition to FSM_NOTIFY  *
      * state. FSM_NOTIFY is a dead state and there is no     *
      * transition out of it, except for timeout              */

      else if((node->state == SO_SUBSC_FSM_INIT) || 
              (node->state == SO_SUBSC_FSM_202))
      {
         node->state = SO_SUBSC_FSM_NOTIFY_NO200;
      }
      RETVALUE(ROK);
   }
   
   switch (node->type)
   {
#ifdef SO_REFER      
      case SO_SUBSC_TYPE_REFER:
    /* refer can be terminated by usintg subscribe */     
         if(sipMethod == SO_METHODSTD_SUBSCRIBE)
    {
            /* no subscribe allowed for refer 
             * node so terminate the node */
            node->state = SO_SUBSC_FSM_TERMINATE_DONE;
            (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
            RETVALUE(RFAILED);
    }    
    else if(statusCode >= 200 && statusCode < 300)
         {
            node->state = SO_SUBSC_FSM_NEUTRAL;
            if(node->expVal)
               (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                           TMR_START, node->expVal);
         }
         else if(statusCode >= 300)
         {
            /* error status code so terminate the refer node */
            node->state = SO_SUBSC_FSM_TERMINATE_DONE;
            (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
         }
         break;
#endif    
      case SO_SUBSC_TYPE_SUBSC:
         if(expHdr != NULLP && 
           node->expVal == 0)
         {
            (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                              TMR_STOP, NOTUSED);
            (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                              TMR_START, 32*SO_TMRVAL_1_S); 
            /* set fsm to terminate */
            node->state = SO_SUBSC_FSM_TERMINATE;
            break;
         }
   
         if(node->state == SO_SUBSC_FSM_INIT && 
            statusCode == 202)
         {
            if(node->expVal)
          (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                           TMR_START, node->expVal);
            node->state = SO_SUBSC_FSM_202;
            break;
         }
         
         if(statusCode == 200)
         {
            /* For subscribe response, no state change 
             * if the node is 
             * at terminate state. */
            if(node->state == SO_SUBSC_FSM_NOTIFY_NO200 || 
               node->state == SO_SUBSC_FSM_NOTIFY_REFRESH || 
               node->state == SO_SUBSC_FSM_NOTIFY_TIMEOUT)
            {
               node->state = SO_SUBSC_FSM_NOTIFY;
               (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
               if(node->expVal)
                  (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                           TMR_START, node->expVal);
            }
            else if(node->state == SO_SUBSC_FSM_INIT ||  
                    node->state == SO_SUBSC_FSM_REFRESH || 
                    node->state == SO_SUBSC_FSM_202 || 
                    node->state == SO_SUBSC_FSM_TIMEOUT)
            {
               node->state = SO_SUBSC_FSM_NEUTRAL;
               (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
               if(node->expVal)
                  (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                           TMR_START, node->expVal);
            }
         }
         else
         {
            /* error handling. If has retry after 
             * keep the state unchanged. Otherwise 
             * terminate the node  */
            if(retryAfter != TRUE)
            {
               node->state = SO_SUBSC_FSM_TERMINATE_DONE;
               (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
            }
         }
         break;
      default:
         /* should not hit here. This is in 
          * error so terminate the node */
         node->state = SO_SUBSC_FSM_TERMINATE_DONE;
         (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
         break;
   }
   RETVALUE(ROK);      
}




/*
*
*       Fun:   soSubscFSMUpdateTimeout
*
*       Desc:  This function update the subsc fsm
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PRIVATE S16 soSubscFSMUpdateTimeout
(
SoSubNode *node, 
Bool isSubscExpTmr
)
#else
PRIVATE S16 soSubscFSMUpdateTimeout(node, isSubscExpTmr)
SoSubNode *node; 
Bool isSubscExpTmr;
#endif
{

   TRC3(soSubscFSMUpdateTimeout);

   if(node->state == SO_SUBSC_FSM_TERMINATE_DONE)
      RETVALUE(RFAILED);
   
   if(isSubscExpTmr)
   {
      switch(node->state)
      {
         case SO_SUBSC_FSM_INIT:
         case SO_SUBSC_FSM_202:
         case SO_SUBSC_FSM_NOTIFY_NO200:
         case SO_SUBSC_FSM_REFRESH:
         case SO_SUBSC_FSM_NOTIFY_REFRESH:
         case SO_SUBSC_FSM_TIMEOUT:
         case SO_SUBSC_FSM_NOTIFY_TIMEOUT:
            node->state = SO_SUBSC_FSM_TERMINATE_DONE;
            (Void)soSchedTmr(node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
            break;
         case SO_SUBSC_FSM_NEUTRAL: 
            /* only possible timer is subscExp timer */
            (Void)soSchedTmr(node,SO_TMR_SUBSC_EXP,
                             TMR_STOP, NOTUSED);
            if(node->type != SO_SUBSC_TYPE_REFER)
            {
               node->state = SO_SUBSC_FSM_TIMEOUT;
            }
            else
            {
               node->state = SO_SUBSC_FSM_TERMINATE_DONE;
               (Void)soSchedTmr(node,SO_TMR_SUBSC_EXP,
                                TMR_STOP, NOTUSED);
            }
            break;
         case SO_SUBSC_FSM_NOTIFY:
            (Void)soSchedTmr(node,SO_TMR_SUBSC_EXP,
                           TMR_STOP, NOTUSED);
#ifdef SO_REFER      
            if(node->type == SO_SUBSC_TYPE_REFER)
            {
                node->state = SO_SUBSC_FSM_TERMINATE_DONE;
                (Void)soSchedTmr(node,SO_TMR_SUBSC_EXP,
                                 TMR_STOP, NOTUSED);
                break;   
            }
#endif    
            node->state = SO_SUBSC_FSM_NOTIFY_TIMEOUT;
            break;
         default:
            /* tear down the node for errors */
            node->state = SO_SUBSC_FSM_TERMINATE_DONE;
            (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                          TMR_STOP, NOTUSED);
            break;
      }
      RETVALUE(ROK);
   }
   switch(node->state)
   {
      case SO_SUBSC_FSM_INIT:
         /* timeout in init state so tear down the node */
         node->state = SO_SUBSC_FSM_TERMINATE_DONE;
         (Void)soSchedTmr(node,SO_TMR_SUBSC_EXP,
                          TMR_STOP, NOTUSED);
         break;
      case SO_SUBSC_FSM_REFRESH:
      case SO_SUBSC_FSM_NOTIFY_REFRESH:
         /* refresh failed */
         (Void)soSchedTmr(node,SO_TMR_SUBSC_EXP,
                          TMR_STOP, NOTUSED);
         node->state = SO_SUBSC_FSM_TERMINATE_DONE;   
         break;
      case SO_SUBSC_FSM_TIMEOUT:
      case SO_SUBSC_FSM_NOTIFY_TIMEOUT:
         (Void)soSchedTmr(node,SO_TMR_SUBSC_EXP,
                          TMR_STOP, NOTUSED);
         node->state = SO_SUBSC_FSM_TERMINATE_DONE;
         break;
      case SO_SUBSC_FSM_202:
      case SO_SUBSC_FSM_NEUTRAL: 
      case SO_SUBSC_FSM_NOTIFY:
      case SO_SUBSC_FSM_NOTIFY_NO200:
      case SO_SUBSC_FSM_TERMINATE:
         /* reach statable state so no state change needed */
         break;
      default:
         /* tear down the node for errors */
         node->state = SO_SUBSC_FSM_TERMINATE_DONE;
         (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                        TMR_STOP, NOTUSED);
         break;
   }
   RETVALUE(ROK);      
}




/*
*
*       Fun:   soCpySubscId
*
*       Desc:  This function copy subscId to errEvnt/refreshEvnt
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soCpySubscId
(
SoEvnt      *event, 
TknStrOSXL  *str,
CmMemListCp *memCp
)
#else
PUBLIC S16 soCpySubscId(event, str, memCp) 
SoEvnt      *event; 
TknStrOSXL  *str;
CmMemListCp *memCp;
#endif
{
   
   U16           i;
   SoParameter   *param;
   SoEventHeader *eventHdr;
   
   TRC3(soCpySubscId);
  
   if(soCmFindHdrChoice(event, (U8 **)&eventHdr,
                           SO_HEADER_REQ_EVENT) != ROK)
   {
      RETVALUE(RFAILED);
   }      
   for(i = 0; i < eventHdr->params.numComp.val;i++)
   {
      param = eventHdr->params.parameter[i];
      if((param->token.len == 2) && 
         (param->token.val[0] == 'i') &&
         (param->token.val[1] == 'd')) 
      {
         if(soUtlCpyTknStrOSXL(str, 
          &param->paramVal.value, memCp) 
            != ROK)
         {
             RETVALUE(RFAILED);
         }
         break;
      }
   }
   RETVALUE(ROK);
}

/*
*
*       Fun:   soGetSubscInfo
*
*       Desc:  This function gets the info from subsc/refer message
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PRIVATE S16 soGetSubscInfo
(
SoEvnt        *event,              /* Event */
TknStrOSXL    *subId,              /* Subscription Id */
SoEventHeader **eventHdr,          /* Subscription header */
TknU32        **expiresHdr,        /* Expires Header */
U16           *numEventHdr,       
U8            *subscriptionState,  /* Subscription State */
Bool          *isReferEvent,       /* Event is a Refer Event/ not */
TknU32        *notifyExpires,      /* Expiration of Notify */
Bool          *retryAfter          /* Time after which request can be retried */
)
#else
PRIVATE S16 soGetSubscInfo(event, subId, eventHdr, 
                           expiresHdr, numEventHdr, 
                           subscriptionState, isReferEvent,
                           notifyExpires, retryAfter)
SoEvnt        *event;              /* Event */
TknStrOSXL    *subId;              /* Subscription Id */
SoEventHeader **eventHdr;          /* Subscription header */
TknU32        **expiresHdr;        /* Expires Header */
U16           *numEventHdr;       
U8            *subscriptionState;  /* Subscription State */
Bool          *isReferEvent;       /* Event is a Refer Event/ not */
TknU32        *notifyExpires;      /* Expiration of Notify */
Bool          *retryAfter;         /* Time after which request can be retried */

#endif
{

   U16           i;
   SoHeader      *hdr;          /* Header to check */
   SoHeaderSeq   *hdrSeq;
   SoEventHeader *tmpEventHdr;
   SoParameter   *param;
   SoSubscState  *subStateHdr;
   SoSubExpParam *subExpParm;
#ifdef SO_REFER   
   Txt referStr[] = "refer";
#endif /* SO_REFER */

   TRC3(soGetSubscInfo);

   *numEventHdr       = 0;
   *eventHdr          = NULLP;
   *expiresHdr        = NULLP;
   *isReferEvent      = FALSE;
   *isReferEvent      = FALSE;
   *subscriptionState = SO_SUBSCRIPTION_STATE_INVALID;
   subStateHdr        = NULLP;
   notifyExpires->pres = NOTPRSNT;

   if (subId == NULLP)
      RETVALUE(RFAILED);

   subId->pres = NOTPRSNT;
   subId->len = 0;
   subId->val = NULLP;  
    

   if (SO_CMP_TKN_LIT(&event->sipMessageType,
      SO_SIPMESSAGE_REQUEST) == TRUE)
   {
      hdrSeq = &event->t.request.request;
   }
   else
   {
      hdrSeq = &event->t.response.response;
   }

   /* Locate the subscription hedaer, event header and expire header if any */
   for(i = 0; i < SO_GET_NUM_COMP(&hdrSeq->numComp); i++)
   {
       hdr = hdrSeq->header[i];

       if(hdr->headerType.val == SO_HEADER_GEN_EXPIRES)
          *expiresHdr = (TknU32 *)&hdr->t.expires;

       else if(hdr->headerType.val == SO_HEADER_REQ_EVENT)
       {
          *numEventHdr += 1;
          *eventHdr = (SoEventHeader *)&hdr->t.event;
       }

       else if(hdr->headerType.val == SO_HEADER_SUBSC_STATE)
          subStateHdr = (SoSubscState *)&hdr->t.subscSt;
   }
  
   /* get the subsc state, expire delta , and retry after from subStateHdr */
   retryAfter = FALSE;
   if(subStateHdr != NULLP)
   {
     /* extract teh subscription state from notify request */
     if(subStateHdr->subVal.valueType.pres == PRSNT_NODEF)
     {
       switch(subStateHdr->subVal.valueType.val)
       {
          case SO_SUB_STATE_ACT:
             *subscriptionState = SO_SUBSCRIPTION_STATE_ACTIVE;
             break;
          case SO_SUB_STATE_PEND:
             *subscriptionState = SO_SUBSCRIPTION_STATE_PENDING;
             break;
          case SO_SUB_STATE_TERM:
             *subscriptionState = SO_SUBSCRIPTION_STATE_TERMINATED;
             break;
          case SO_SUB_STATE_TOKEN:
          default:        
             *subscriptionState = SO_SUBSCRIPTION_STATE_INVALID;
             break;
       }
     }
     /* extract the expire timeout for the subscription timer */
     if(subStateHdr->subExpParams.numComp.pres == PRSNT_NODEF)
     {
       for(i=0; i < subStateHdr->subExpParams.numComp.val; i++)
       {
         subExpParm = subStateHdr->subExpParams.subExpParamList[i];
         if(subExpParm->type.pres == PRSNT_NODEF)
         {
            if(subExpParm->type.val == SO_SUB_EXP_PAR_EXPIRES)
            {
               notifyExpires->pres =  
                 subExpParm->u.expires.pres;
               notifyExpires->val = 
                 subExpParm->u.expires.val;
            }
            else if(subExpParm->type.val == 
                    SO_SUB_EXP_PAR_RETRY_AFT)
            {
               *retryAfter = TRUE;
            }
         }
       }
     }
   }

   /* If there is a event header, check if the event is refer. If yes mark 
    * the isRefer flag to TRUE */
   tmpEventHdr = *eventHdr;

   if(*numEventHdr > 0) 
   {
#ifdef SO_REFER      
      if((*eventHdr)->pres.pres == PRSNT_NODEF && 
         (*eventHdr)->eventName.pres == PRSNT_NODEF &&
         ((*eventHdr)->eventName.len == 5) &&
         cmMemcmp((*eventHdr)->eventName.val, 
            (CONSTANT U8 *)referStr, (*eventHdr)->eventName.len) == 0)
      {
         /*so028.201:- Debug traces added*/
         SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soGetSubscInfo: Refer string matched\n"));

         *isReferEvent = TRUE;
      }
      else
      {
         /*so028.201:- Debug traces added*/
         SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soGetSubscInfo: Refer string not matched\n"));
      }
#endif
      /* extract the subscribe id from the token. 
       * id is used for locaing the subscription node. */
      for(i = 0; i < tmpEventHdr->params.numComp.val;i++)
      {
         param = tmpEventHdr->params.parameter[i];
         if((param->token.len == 2) && 
            (param->token.val[0] == 'i') &&
            (param->token.val[1] == 'd')) 
         {
           subId->val = param->paramVal.value.val;
           subId->len = param->paramVal.value.len;
           subId->pres = param->paramVal.value.pres;
           break;
         }
      }
      
   }

   /*so028.201:- Debug traces added*/
   if (subId->pres != NOTPRSNT)
   SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
            "soGetSubscInfo: subId is : Val = [%s] , Len = [%d]," 
            "Pres = [%d]\n",
            subId->val, subId->len, subId->pres));
   RETVALUE(ROK);
}






/*
*
*       Fun:   soSubscCheckEventPkgType
*
*       Desc:  Takes the 'event' header from evnt struct, and 
*              classifies the event package name found in the
*              event header as standard, nonstandard or not
*              supported
*
*       Ret:   RFAILED                 Problem encountered
*              SO_EVNT_PKG_STD         The event package is standard
*              SO_EVNT_PKG_NON_STD     The evnt pkg is non-standard  
*              SO_EVNT_PKG_NON_SUPRT   The evnt pkg is not supported 
*
*       Notes: This function assumes that the header is present in evnt.
*
*       File:  so_subsc.c
*
*/


#ifdef ANSI
PRIVATE U8 soSubscCheckEventPkgType
(
SoEntCb *ent,        /* Entity */          
PTR event,
Bool isEventHdr
)
#else
PRIVATE U8 soSubscCheckEventPkgType (ent, event, isEventHdr)
SoEntCb *ent;        /* Entity */
PTR event; 
Bool isEventHdr;
#endif
{
   SoEventHeader *soEvent;          /* Event header pointer             */
   U16     indx;                    /* Header index                     */
   U16     x;                       /* Counter for loops                */
   U16     totalLength;             /* Total lenght of match string     */
   /* so008.201: Addition */
   Txt     matchString[LSO_STR_SZ]; /* String size                      */

   TRC3(soSubscCheckEventPkgType);

   if(isEventHdr)
      soEvent = (SoEventHeader *)event;
   else
   {
      if(soCmFindHdrChIndex((SoEvnt *)event,
    (U8**)&soEvent,&indx,SO_HEADER_REQ_EVENT) ==  RFAILED)
      {
         SODBGP_SO(SO_DBGMASK_CORE,
                (soCb.init.prntBuf,
                 "\nsoSubscCheckEventPkgType: No Event header present "
                 "in SIP message\n"));
         RETVALUE(RFAILED);
      }
   }
      

   /* Compare the event header in the event structure with the list of
      configured event package names */

   cmMemcpy((U8*)matchString,
            soEvent->eventName.val,
            soEvent->eventName.len);
   totalLength=soEvent->eventName.len;
   
   matchString[totalLength]=0x00;  /* Terminate string */

   /* For each header package name in evnt */
   for(x=0;x<ent->reCfg.nmbStdEvntPkg;x++)
   {
      /* Compare current item in stdConfig list with match string */
      /* If complete match, return SO_EVNT_PKG_STD */
      /* so020.201 : changed to compare two strings ignoring case of the strings */
      if(!soCmStrcasecmp( (U8 *)ent->reCfg.supportedStdEvntPkg[x].str,
                   (U8 *)matchString ))
      {
         RETVALUE( SO_EVNT_PKG_STD);
      }
   }


   /* If none found in stdList, go on to the nonStd list */
   
   /* For each header package name in evnt */
   /* For each header package name in evnt */
   for(x=0;x<ent->reCfg.nmbNonStdEvntPkg;x++)
   {
      /* Compare current item in stdConfig list with match string */
      /* If complete match, return SO_EVNT_PKG_NON_STD */
      /* so020.201 : changed to compare two strings ignoring case of the strings */
      if(!soCmStrcasecmp( (U8 *)ent->reCfg.supportedNonStdEvntPkg[x].str,
                   (U8 *)matchString ))
      {
         RETVALUE( SO_EVNT_PKG_NON_STD);
      }
   }

   /* Return SO_EVNT_PKG_NON_SUPRT, no event packages found */
   RETVALUE( SO_EVNT_PKG_NON_SUPRT);
} /* soSubscCheckEventPkgType */




/*
*
*       Fun:   soUaSubscReq
*
*       Desc:  This function processes a Refer Req  received from the user
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaSubscReq
(
SoSubNode  **outNode, 
Bool       *saveMsg,
SoCLegCb   *cLeg, 
SoEvnt     *event
)
#else
PUBLIC S16 soUaSubscReq(outNode, saveMsg, cLeg, event)
SoSubNode  **outNode; 
Bool       *saveMsg;
SoCLegCb   *cLeg; 
SoEvnt     *event;
#endif
{
   SoSubNode     *node;
   S16           ret;
   SoEventHeader *eventHdr; 
   TknU32        *expHdr; 
   U16           numEventHdr;
   TknStrOSXL    subId;
   U8            subscriptionState;
   Bool          isReferEvent;
   TknU32        notifyExpires;
   Bool          retry;
   U8            evntPkgType;
   SoSSapCb      *ssap; 

   TRC3(soUaSubscReq);
  
   expHdr = NULLP; 
   ssap = cLeg->call->ssapCb;
   *outNode = NULLP;

   *saveMsg = FALSE;

   /* Get subscription related info */
   ret = soGetSubscInfo(event, &subId, &eventHdr, &expHdr,
                        &numEventHdr, &subscriptionState, &isReferEvent,
                        &notifyExpires,
                        &retry);
         
   if(ret != ROK)
   {
      /*so028.201:- Debug traces added*/
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soUaSubscReq: soGetSubscInfo failed\n"));      
      RETVALUE(RFAILED);
   }

   if(numEventHdr > 1 || numEventHdr == 0)
   {
      /*so028.201:- Debug traces added*/
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                "soUaSubscReq: Failed: numEventHdr not equal to 1\n"));

      RETVALUE(RFAILED);   
   }

   /* Check if package is supported. If not return error */
   evntPkgType = soSubscCheckEventPkgType (cLeg->call->ent, 
                                           (PTR)event, FALSE);

   if(evntPkgType == SO_EVNT_PKG_NON_SUPRT)
   {
      /*so028.201:- Debug traces added*/
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                "soUaSubscReq:  soSubscCheckEventPkgType failed\n"));
      
      
      RETVALUE(RFAILED);
   }      

   node = NULLP;

   /*If it is a Refer event */
   if (isReferEvent)
   {
      if(soFindSubscNode(cLeg, &subId, &node, SO_SUBSC_TYPE_REFER) == ROK)
      {
         if(node->state == SO_SUBSC_FSM_INVALID || 
            node->state == SO_SUBSC_FSM_TERMINATE_DONE)
         {
            /*so028.201:- Debug traces added*/
            SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                     "soUaSubscReq: isReferEvent not NULL,"
                     " Unexpected FSM state\n"));

           RETVALUE(RFAILED);
         }    

         if((expHdr != NULLP) && 
            (expHdr->pres == PRSNT_NODEF))
         {
            expHdr->val = 0;
         }

         /* refresh */
         soSubscFSMUpdateReq(node, SO_METHODSTD_SUBSCRIBE, FALSE, 
                             subscriptionState); 
         node->cLeg = cLeg;
         if(node->event)
         {
            (Void)soCmFreeEvent(node->event);
         }

         node->event = NULLP;
         *outNode = node;
         /*----- so025.201: Removed printf statement -------*/

         RETVALUE(ROK);
      }

      /*so028.201:- Debug traces added*/
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
               "soUaSubscReq: isReferEvent not NULL, Return RFAILED\n"));
      

      RETVALUE(RFAILED);
   } 

   
   *saveMsg = TRUE;

   /* Try to see if subsciption node is present already. If not
      allocate one and then call state machine. */

   if(soFindSubscNode(cLeg, &subId, &node, SO_SUBSC_TYPE_SUBSC) == ROK)
   {
      if(node->state == SO_SUBSC_FSM_TERMINATE_DONE || 
         node->state == SO_SUBSC_FSM_INVALID)
      {
        /*so028.201:- Debug traces added*/
         SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                  "soUaSubscReq: Unexpected FSM state\n"));         
         RETVALUE(RFAILED);
      }
    
      if(node->event)
      {
        (Void) soCmFreeEvent(node->event);
      }
      /* refresh */
      node->event = event;
      node->cLeg = cLeg;
   }
   else
   {
      soAllocSubscNode(&node, &subId, event, cLeg,
             SO_SUBSC_TYPE_SUBSC, FALSE);
      if(node == NULLP)
      {
         /*so028.201:- Debug traces added*/
         SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                  "soUaSubscReq: soAllocSubscNode Failed\n"));         
         RETVALUE(RFAILED);
      }

      if(subId.pres == NOTPRSNT)
         cLeg->subscCb.defaultSubsc = TRUE;

      cLeg->subscCb.numSubsc++;

      /* save expires value */
      if((expHdr != NULLP) && 
         (expHdr->pres == PRSNT_NODEF))
      {
         node->expVal = (expHdr->val * SO_TMRVAL_1_S);
      }

      node->node.node = (PTR)node;
      node->type = SO_SUBSC_TYPE_SUBSC;

      cmLListAdd2Tail(&cLeg->subscCb.subCp, &node->node);
   }

   /*------ so025.201: Removed printf from code ------*/

   soSubscFSMUpdateReq(node, SO_METHODSTD_SUBSCRIBE, FALSE, 
                       subscriptionState);    
   *outNode = node;

   /* Add any suscribe specific headers */
   ret = soUaChkOutEventHdr(cLeg, event);

   RETVALUE(ret);
}




/*
*
*       Fun:   soUaSubscRspReq
*
*       Desc:  This function processes a Refer/subscribe rsp  
*              received from the user
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaSubscRspReq
(
SoSubNode  **outNode, 
SoCLegCb   *cLeg, 
SoEvnt     *event,
SoTransCb   *transCb
)
#else
PUBLIC S16 soUaSubscRspReq(outNode, cLeg, event, transCb)
SoSubNode  **outNode; 
SoCLegCb   *cLeg; 
SoEvnt     *event;
SoTransCb   *transCb;
#endif
{
   SoSubNode     *node;
   S16           ret;
   SoEventHeader *eventHdr; 
   TknU32        *expiresHdr; 
   U16           numEventHdr;
   TknStrOSXL    subId;
   U16           statusCode;
   U8            subscriptionState;
   Bool          isReferEvent;
   TknU32        notifyExpires;
   Bool          retry;
   
   TRC3(soUaSubscRspReq);
   
   expiresHdr = NULLP;
   *outNode = NULLP;
   node = (SoSubNode *)transCb->userContext.subscCb;
   if(node == NULLP)
   {
      RETVALUE(RFAILED);
   }
   ret = soGetSubscInfo(event, &subId, 
                   &eventHdr, &expiresHdr,
                   &numEventHdr, &subscriptionState, &isReferEvent,
                   &notifyExpires,
                   &retry);
   
   if(ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   if(expiresHdr != NULLP)
      node->expVal = ((expiresHdr->val+32) * SO_TMRVAL_1_S);
   statusCode = event->t.response.statusLine.statusCode.val;
   soSubscFSMUpdateRsp(node, SO_METHODSTD_SUBSCRIBE, 
                       statusCode, subscriptionState, retry,
                       expiresHdr); 
   *outNode = node;
   RETVALUE(ROK);
}




/*
*
*       Fun:   soUaSubscInd
*
*       Desc:  This function processes a Refer/subscribe rsp  
*              received from the user
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaSubscInd
(
SoCLegCb   *cLeg, 
SoEvnt     *event,
SoTransCb   *transCb
)
#else
PUBLIC S16 soUaSubscInd(cLeg, event, transCb)

SoCLegCb   *cLeg; 
SoEvnt     *event;
SoTransCb   *transCb;
#endif
{
   SoSubNode     *node;
   S16           ret;
   SoSSapCb      *ssap; 
   SoEventHeader *eventHdr; 
   TknU32        *expiresHdr; 
   U16           numEventHdr;
   TknStrOSXL    subId;
   U8            subscriptionState;
   Bool          isReferEvent;
   TknU32        notifyExpires;
   Bool          retry;
   U8            entityType;
   U8            evntPkgType;

   TRC3(soUaSubscInd);
   
   ssap = cLeg->call->ssapCb;
   entityType = cLeg->call->ent->entityType;

   ret = soGetSubscInfo(event, &subId, 
                   &eventHdr, &expiresHdr,
                   &numEventHdr, &subscriptionState, &isReferEvent,
                   &notifyExpires,
                   &retry);
         
   if(ret != ROK)
      RETVALUE(SOT_RSP_400_BAD_REQUEST);


   if(numEventHdr > 1 || numEventHdr == 0)
   {
      if(entityType == LSO_ENT_UA)   
        RETVALUE(SOT_RSP_400_BAD_REQUEST);
   }

   evntPkgType = soSubscCheckEventPkgType (cLeg->call->ent, 
                                           (PTR)eventHdr, TRUE);
   if(evntPkgType == SO_EVNT_PKG_NON_SUPRT)
   {
     if(entityType == LSO_ENT_UA)      
         RETVALUE(SOT_RSP_489_BAD_EVENT);
   }

   node = NULLP;

   if(soFindSubscNode(cLeg, &subId, &node, SO_SUBSC_TYPE_SUBSC) != ROK)
   {
      if(soAllocSubscNode(&node, &subId, NULLP, cLeg,
             SO_SUBSC_TYPE_SUBSC, TRUE) != ROK)
      {
         if(entityType == LSO_ENT_UA)      
            RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
      }

      if(subId.pres == NOTPRSNT)
         cLeg->subscCb.defaultSubsc = TRUE;

      cLeg->subscCb.numSubsc++;
         
      /* save expires value */
      if((expiresHdr!= NULLP) && 
         (expiresHdr->pres == PRSNT_NODEF))
      {
         node->expVal = ((expiresHdr->val+32) * SO_TMRVAL_1_S);
      }

      soSubscFSMUpdateReq(node, SO_METHODSTD_SUBSCRIBE, TRUE, 
                          subscriptionState);

      /* insert into link list */  
      node->node.node = (PTR)node;
      cmLListAdd2Tail(&cLeg->subscCb.subCp, &node->node);

      /* so026.201: Save subscription CB in Transaction Control block  */
       SO_UA_SAVE_REF (transCb->userContext, node);

      /* update route for subscribe created leg only. */ 
      if (cLeg->call->sessCreatedBy == SOT_ET_SUBSCRIBE)
      {
         ret = soDlgUpdRoute(cLeg, event, SO_REMOTE);
         if (ret != ROK)
         {
            RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
         }
      }
      soUaCAMInd(cLeg, event);
   }
   else
   { 
      /* refresh: need to reject request if the 
       * node in terminate_done state */
      if(soSubscFSMUpdateReq(node, SO_METHODSTD_SUBSCRIBE, TRUE, 
                       subscriptionState) == RFAILED)
         RETVALUE(SOT_RSP_481_CLEG_TRAN_NOT_EXIST);


     /* so026.201: Save subscription CB in Transaction Control block  */
      SO_UA_SAVE_REF (transCb->userContext, node);

      soUaCAMInd(cLeg, event);
   }
   RETVALUE(ROK);
}






/*
*
*       Fun:   soUaSubscCfm
*
*       Desc:  This function processes a Refer/subscribe rsp  
*              received from the user
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaSubscCfm
(
SoCLegCb   *cLeg, 
SoEvnt     *event,
SoUserCtxt *userCtxt
)
#else
PUBLIC S16 soUaSubscCfm(cLeg, event, userCtxt)

SoCLegCb   *cLeg; 
SoEvnt     *event;
SoUserCtxt *userCtxt;
#endif
{
   SoSubNode     *node;
   S16           ret;
   SoCallCb      *callCb;   
   CmLList       *lst;
   SoSubNode     *tmpNode;
   SoEventHeader *eventHdr; 
   TknU32        *expiresHdr; 
   U16           numEventHdr;
   TknStrOSXL    subId;
   U16           statusCode;
   U8            subscriptionState;
   Bool          isReferEvent;
   TknU32        notifyExpires;
   Bool          retry;
   Bool          hit;
   
   TRC3(soUaSubscCfm);
   
   node = (SoSubNode *)userCtxt->subscCb;
   hit = FALSE;
   callCb = cLeg->call;

   ret = soGetSubscInfo(event, &subId, 
                   &eventHdr, &expiresHdr,
                   &numEventHdr, &subscriptionState, &isReferEvent,
                   &notifyExpires,
                   &retry);
   
   if(ret != ROK)
   {
      (Void) soCmFreeEvent(event);
      RETVALUE(RFAILED);
   }

#ifdef SO_1XX_PASS
  /*--- so013.201: Pass 1xx Response To User ---*/
  if (event->t.response.statusLine.statusCode.val/100 == SO_STACODE_TYPE_INFORM)
  {
    ret = soUiCnStInd (cLeg->userConnId, cLeg->call, event);
    RETVALUE(ret);
  }
#endif

   /* handling forking here */
   if(node == NULLP)
   {
      if(soFindSubscNode(cLeg, &subId, &node, 
                     SO_SUBSC_TYPE_SUBSC) == ROK)
      {
         if(node->state == SO_SUBSC_FSM_TERMINATE_DONE || 
            node->state == SO_SUBSC_FSM_INVALID)
         {
            soCmFreeEvent(event);
            RETVALUE(RFAILED);
         }
      }
      else
      {
        soAllocSubscNode(&node, &subId, event, cLeg,
                         SO_SUBSC_TYPE_SUBSC, FALSE);
        if(node == NULLP)
        {
          (Void) soCmFreeEvent(event);
          RETVALUE(RFAILED);
        }
        /* for forking, we need to copy the event */
         callCb = cLeg->call;
         lst = cmLListFirst(&callCb->cLegLst);
         while (lst != (CmLList *)NULLP)
         {
           cLeg = (SoCLegCb *)cmLListNode(lst);
           if(soFindSubscNode(cLeg, &subId, &tmpNode, 
                              SO_SUBSC_TYPE_SUBSC) != ROK)
           {
             lst  = lst->next;
           }
            else
            {
              if(soUtlCpySoEvnt(node->event, tmpNode->event) == ROK)
                hit = TRUE;
              break;
            }
         }
         /* invalid forking case so ignore it */
         if(hit != TRUE)
         {
            soCmFreeEvent(event);
            node->state = SO_SUBSC_FSM_TERMINATE_DONE; 
            soDlgDelCurSubscNode(node);
            RETVALUE(RFAILED);   
         } 
         if(subId.pres == NOTPRSNT)
           cLeg->subscCb.defaultSubsc = TRUE;
         cLeg->subscCb.numSubsc++;
         /* save expires value */
         if((expiresHdr != NULLP) && 
            (expiresHdr->pres == PRSNT_NODEF))
         {
           node->expVal=(expiresHdr->val*SO_TMRVAL_1_S);
         }

        /* so026.201: Save subscription CB in Transaction Control block  */
         SO_UA_SAVE_REF ((*userCtxt), node);

         cmLListAdd2Tail(&cLeg->subscCb.subCp, &node->node);
         if(node->expVal)
           (Void)soSchedTmr (node,SO_TMR_SUBSC_EXP,
                             TMR_START, node->expVal);
      }      
   }
   statusCode = event->t.response.statusLine.statusCode.val;
   if(soSubscFSMUpdateRsp(node, SO_METHODSTD_SUBSCRIBE, 
                       statusCode, subscriptionState, retry,
                       expiresHdr) != ROK)
   {
      (Void) soCmFreeEvent(event);
      RETVALUE(RFAILED);
   }
   /* Update route if the session was created by a subscribe */
   if (callCb->sessCreatedBy == SOT_ET_SUBSCRIBE)
   {
     ret = soDlgUpdRoute(cLeg, event, SO_REMOTE);
     if (ret != ROK)
     {
        (Void) soCmFreeEvent(event);
        RETVALUE(RFAILED);
     }
   }

   /* so009.201 : Added new parameter userConnId to function call */
   soUiCAMCfm(cLeg->userConnId, cLeg->call, event);

   /* so025.201: After receiving response, we can teriminate      *
    *    subscription control block if it is no longer required   */
   if (node && (node->state == SO_SUBSC_FSM_TERMINATE_DONE))
   {
       soDlgDelCurSubscNode (node);

      /*- so026.201: Return ROKDNA to indicate CLeg may be deleted -*/
       RETVALUE (ROKDNA);
   }

   RETVALUE(ROK);
}




/*
*
*       Fun:   soUaNotifyReq
*
*       Desc:  This function processes a notify req  
*              received from the user
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaNotifyReq
(
SoSubNode **outNode, 
SoSSapCb *ssap, 
SoCLegCb   *cLeg, 
SoEvnt     *event
)
#else
PUBLIC S16 soUaNotifyReq(outNode, ssap, cLeg, event)
SoSubNode **outNode; 
SoSSapCb *ssap; 
SoCLegCb   *cLeg; 
SoEvnt     *event;
#endif
{
   S16           ret;
   SoEventHeader *eventHdr; 
   TknU32        *expiresHdr; 
   U16           numEventHdr;
   TknStrOSXL    subId;
   U8            subscriptionState;
   Bool          isReferEvent;
   TknU32        notifyExpires;
   Bool          retry;
   SoSubNode     *node;
   U8            evntPkgType;

   TRC3(soUaNotifyReq);
   
   *outNode = NULLP;
   notifyExpires.pres = NOTPRSNT; 
   ret = soGetSubscInfo(event, &subId, 
                   &eventHdr, &expiresHdr,
                   &numEventHdr, &subscriptionState, &isReferEvent,
                   &notifyExpires,
                   &retry);
   
   if(ret != ROK)
   { 
     /*so028.201:- Debug traces added*/
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soUaNotifyReq: soGetSubscInfo failed\n"));      
      RETVALUE(RFAILED);
   }

   if(numEventHdr > 1 || numEventHdr == 0)
   {
      /*so028.201:- Debug traces added*/
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soUaNotifyReq: Failed : Value of numEventHdr not proper\n"));          
      RETVALUE(RFAILED);   
   }

   /* Check if package is supported. If not return error */
   evntPkgType = soSubscCheckEventPkgType (cLeg->call->ent, 
                                           (PTR)event, FALSE);

   if(evntPkgType == SO_EVNT_PKG_NON_SUPRT)
   {
      /*so028.201:- Debug traces added*/
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soUaNotifyReq:  soSubscCheckEventPkgType failed\n"));
      RETVALUE(RFAILED);
   }   
   node = NULLP;
   
   if(isReferEvent == TRUE)
   {
#ifdef SO_REFER      
      if(soFindSubscNode(cLeg, &subId, &node, SO_SUBSC_TYPE_REFER) 
                         != ROK)
      {
         /*so028.201:- Debug traces added*/
         SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soUaNotifyReq: soFindSubscNode failed for SUBSC_TYPE_REFER\n"));         
         RETVALUE(RFAILED);
      }
      if(node->state == SO_SUBSC_FSM_TERMINATE_DONE)
      {
         /*so028.201:- Debug traces added*/
         SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soUaNotifyReq: Failed :- Node in Terminated State\n"));         
         RETVALUE(RFAILED);
      }
      if(notifyExpires.pres == PRSNT_NODEF)
         node->expVal = notifyExpires.val*SO_TMRVAL_1_S;
      soSubscFSMUpdateReq(node, SO_METHODSTD_NOTIFY, FALSE, 
                       subscriptionState); 
      *outNode = node;
      RETVALUE(ROK);
#else
      /*so028.201:- Debug traces added*/
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soUaNotifyReq: Failed:- REFER not supported\n"));      
      RETVALUE(RFAILED);

#endif /* SO_REFER */      
   }
   if(soFindSubscNode(cLeg, &subId, &node, SO_SUBSC_TYPE_SUBSC) != ROK)
   {
      /* for CIMReq only. It shoudl not hit here */

     /*so028.201:- Debug traces added*/
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soUaNotifyReq: soFindSubscNode failed for SUBSC_TYPE_SUBSC\n"));      
      RETVALUE(RFAILED);
   }
   else
   {
      if(node->state == SO_SUBSC_FSM_TERMINATE_DONE)
      {
         /*so028.201:- Debug traces added*/
         SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soUaNotifyReq: Failed : Terminated\n"));         
         RETVALUE(RFAILED);
      }
      soSubscFSMUpdateReq(node, SO_METHODSTD_NOTIFY, FALSE, 
                          subscriptionState); 
      *outNode = node;
   }

   /* so019.201: Change to check the outgoing Notify header */
   ret = soUaChkOutEventHdr(cLeg, event);

   RETVALUE(ret); 
}




/*
*
*       Fun:   soUaNotifyRspReq
*
*       Desc:  This function processes a notify rsp  
*              received from the user
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaNotifyRspReq
(
SoSubNode **outNode, 
SoSSapCb *ssap, 
SoCLegCb   *cLeg, 
SoEvnt     *event,
SoTransCb  *transCb
)
#else
PUBLIC S16 soUaNotifyRspReq(outNode, ssap, cLeg, event, transCb)
SoSubNode **outNode;
SoSSapCb *ssap; 
SoCLegCb   *cLeg; 
SoEvnt     *event;
SoTransCb  *transCb;
#endif
{
   S16 ret;
   SoEventHeader *eventHdr; 
   TknU32        *expiresHdr; 
   U16           numEventHdr;
   TknStrOSXL    subId;
   U8            subscriptionState;
   Bool          isReferEvent;
   U16           statusCode;
   TknU32        notifyExpires;
   Bool          retry;
   SoSubNode     *node;

   TRC3(soUaNotifyRspReq);
   
   *outNode = NULLP;
   ret = soGetSubscInfo(event, &subId, 
                   &eventHdr, &expiresHdr,
                   &numEventHdr, &subscriptionState, &isReferEvent,
                   &notifyExpires,
                   &retry);
   
   if(ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   
   statusCode = event->t.response.statusLine.statusCode.val;
   
   if(transCb->userContext.subscCb)
   {
      *outNode = transCb->userContext.subscCb;

     /*----- so025.201: Update the Subscription State Machine -------*/
      
      if(soSubscFSMUpdateRsp(*outNode, SO_METHODSTD_NOTIFY, 
                          statusCode, subscriptionState, retry, NULLP) != ROK)
      {
         *outNode = NULLP;
         RETVALUE(RFAILED);
      }

      RETVALUE(ROK);
   }
   if(isReferEvent == TRUE)
   {
#ifdef SO_REFER      
      if(soFindSubscNode(cLeg, &subId, &node, SO_SUBSC_TYPE_REFER) 
                         != ROK)
      {
         RETVALUE(RFAILED);
      }
      RETVALUE(soSubscFSMUpdateRsp(node, SO_METHODSTD_NOTIFY, 
                          statusCode, subscriptionState, retry, NULLP)); 
#else
      RETVALUE(RFAILED);
#endif /* SO_REFER */
   }
#ifdef SO_OUTDLGNOTIFY
   /* so032.201: Support for outside Dialog Notifications */  
   /* Check if this is out of dialog notify. Don't check subsn for outside dialog notify.*/
   if(cLeg->outdlgNotify == TRUE)
     RETVALUE(ROK);
#endif
   if(soFindSubscNode(cLeg, &subId, &node, SO_SUBSC_TYPE_SUBSC) != ROK)
   {

      /* should be a CIM case for standlone notify rsp . 
       * so return failure */
      RETVALUE(RFAILED);
   }
   else
   {
      if(soSubscFSMUpdateRsp(node, SO_METHODSTD_NOTIFY, 
                          statusCode, subscriptionState, retry, NULLP) != ROK)
         RETVALUE(RFAILED);
      *outNode = node;
   }
   RETVALUE(ROK); 
}




/*
*
*       Fun:   soUaNotifyInd
*
*       Desc:  This function processes a notify req  
*              received from the net
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaNotifyInd
(
SoSSapCb *ssap, 
SoCLegCb   *cLeg, 
SoEvnt     *event,
SoTransCb  *transCb
)
#else
PUBLIC S16 soUaNotifyInd(ssap, cLeg, event, transCb)

SoSSapCb *ssap; 
SoCLegCb   *cLeg; 
SoEvnt     *event;
SoTransCb  *transCb;
#endif
{
   S16 ret;
   SoEventHeader *eventHdr; 
   TknU32        *expiresHdr; 
   U16           numEventHdr;
   TknStrOSXL    subId;
   U8            subscriptionState;
   Bool          isReferEvent;
   TknU32        notifyExpires;
   Bool          retry;
   SoCallCb      *callCb;   
   CmLList       *lst;
   SoSubNode     *tmpNode;
   SoSubNode     *node;
   Bool          hit;
   U8            evntPkgType;
   
   TRC3(soUaNotifyInd);
  
   hit = FALSE;
   notifyExpires.pres = NOTPRSNT; 
   ret = soGetSubscInfo(event, &subId, 
                   &eventHdr, &expiresHdr,
                   &numEventHdr, &subscriptionState, &isReferEvent,
                   &notifyExpires,
                   &retry);
   
   if(ret != ROK)
   {
      RETVALUE(SOT_RSP_400_BAD_REQUEST);
   }

   if(numEventHdr > 1 || numEventHdr == 0)
   {
      RETVALUE(SOT_RSP_400_BAD_REQUEST);
   }

   /* Check if package is supported. If not return error */
   evntPkgType = soSubscCheckEventPkgType (cLeg->call->ent, 
                                           (PTR)event, FALSE);

   /* 489 code:bad event */
   if(evntPkgType == SO_EVNT_PKG_NON_SUPRT)
      RETVALUE(SOT_RSP_489_BAD_EVENT);
   
   node = NULLP;

#ifdef SO_REFER
   if (isReferEvent)
     soFindSubscNode(cLeg, &subId, &node, SO_SUBSC_TYPE_REFER);
   else
#endif
     soFindSubscNode(cLeg, &subId, &node, SO_SUBSC_TYPE_SUBSC);

   /* refer has to have cLeg */
   if(node == NULLP && cLeg == NULLP && isReferEvent == TRUE)
   {
     RETVALUE(SOT_RSP_400_BAD_REQUEST);
   }
   else
   {
     /* so026.201: Save subscription CB in Transaction Control block  */
        SO_UA_SAVE_REF (transCb->userContext, node);
   }


   /* forking refer handling */
   if(node == NULLP && cLeg != NULLP && isReferEvent == TRUE)
   {
#ifdef SO_REFER      
         soAllocSubscNode(&node, &subId, event, cLeg,
                  SO_SUBSC_TYPE_REFER, FALSE);

         if(node == NULLP)
            RETVALUE(SOT_RSP_400_BAD_REQUEST);

        /* so026.201: Save subscription CB in Transaction Control block  */
         SO_UA_SAVE_REF (transCb->userContext, node);

         if (subId.pres == NOTPRSNT && cLeg->subscCb.defaultRefer == FALSE)
            cLeg->subscCb.defaultRefer = TRUE;
         else
         {
            node->state = SO_SUBSC_FSM_TERMINATE_DONE;
            RETVALUE(SOT_RSP_400_BAD_REQUEST);
         }

         cLeg->subscCb.numSubsc++;
         node->node.node = (PTR)node;
         cmLListAdd2Tail(&cLeg->subscCb.subCp, &node->node);
         soSubscFSMUpdateReq(node, SO_METHODSTD_NOTIFY, TRUE, 
                             subscriptionState); 
         ret = soUaCAMInd(cLeg, event);

         if(ret != ROK)
            (Void) soCmFreeEvent(event);

         RETVALUE(ROK);
#else
         RETVALUE(SOT_RSP_400_BAD_REQUEST);
#endif      
   }

   /* this is CIMReq case so pass the notify to user */
   if(node == NULLP && cLeg->call->cLegLst.count == 1)
   {
#ifdef SO_OUTDLGNOTIFY
      /* so032.201: Support for outside Dialog Notifications */  
      /* Identify this is a outside Dialog Notifications */  
      cLeg->outdlgNotify = TRUE;
      /* so032.201: Use CAM always for Notifys */ 
      ret = soUaCAMInd(cLeg, event);
#else
      /* so009.201 : Used user conn id instead of suConnId in callCb */
      ret = soUiCIMInd(cLeg->call->ssapCb, cLeg->userConnId, 
                       cLeg->call->spConnId, event);
#endif
      if(ret != ROK)
        RETVALUE(SOT_RSP_400_BAD_REQUEST);
      /* done so return here */
      RETVALUE(ROK);  
   }

   /* this is the forking case */
   if(node == NULLP)
   {
#ifdef SO_OUTDLGNOTIFY
      /* so032.201: Support for outside Dialog Notifications */  
      /* Identify this is a outside Dialog Notifications & indicate to user layer in CAM */
      cLeg->outdlgNotify = TRUE;
      ret = soUaCAMInd(cLeg, event);
      if(ret != ROK)
        RETVALUE(SOT_RSP_400_BAD_REQUEST);
		else
        RETVALUE(ROK);  
#endif

      soAllocSubscNode(&node, &subId, event, cLeg,
             SO_SUBSC_TYPE_SUBSC, FALSE);
      if(node == NULLP)
      {
         RETVALUE(SOT_RSP_400_BAD_REQUEST);
      }

      if(subId.pres == NOTPRSNT && cLeg->subscCb.defaultSubsc == TRUE)
      {
         node->state = SO_SUBSC_FSM_TERMINATE_DONE;
         RETVALUE(SOT_RSP_481_CLEG_TRAN_NOT_EXIST);
      }

      cLeg->subscCb.defaultSubsc = TRUE;
      cLeg->subscCb.numSubsc++;

      /* save expires value */
      if(isReferEvent)
      {
        if(notifyExpires.pres == PRSNT_NODEF)     
          node->expVal = notifyExpires.val*SO_TMRVAL_1_S;     
      }
      else 
      {
        if((expiresHdr != NULLP) &&  
           (expiresHdr->pres == PRSNT_NODEF))
         {
            node->expVal=expiresHdr->val*SO_TMRVAL_1_S;
         }

         /* for forking, we need to copy the event */
         callCb = cLeg->call;
         lst = cmLListFirst(&callCb->cLegLst);

         while (lst != (CmLList *)NULLP)
         {
           cLeg = (SoCLegCb *)cmLListNode(lst);
           if(soFindSubscNode(cLeg, &subId, &tmpNode, 
                              SO_SUBSC_TYPE_SUBSC) != ROK)
           {
             lst  = lst->next;
           }
           else
           {
             if(soUtlCpySoEvnt(node->event, tmpNode->event) == ROK)
               hit = TRUE;
             break;
           }
         }

         if(hit != TRUE)
         {
           node->state = SO_SUBSC_FSM_TERMINATE_DONE; 
           RETVALUE(SOT_RSP_481_CLEG_TRAN_NOT_EXIST); 
         } 

      }      
   
      node->node.node = (PTR)node;
      cmLListAdd2Tail(&cLeg->subscCb.subCp, &node->node);
   }

   if(node->state == SO_SUBSC_FSM_TERMINATE_DONE)
   {
     RETVALUE(SOT_RSP_400_BAD_REQUEST);
   }
   soSubscFSMUpdateReq(node, SO_METHODSTD_NOTIFY, TRUE, 
                       subscriptionState); 

   ret = soUaCAMInd(cLeg, event);
   if(ret != ROK)
      (Void) soCmFreeEvent(event);

   RETVALUE(ROK);
}




/*
*
*       Fun:   soUaNotifyCfm
*
*       Desc:  This function processes a notify response  
*              received from the net
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaNotifyCfm
(
SoSSapCb *ssap, 
SoCLegCb   *cLeg, 
SoEvnt     *event,
SoUserCtxt *userCtxt
)
#else
PUBLIC S16 soUaNotifyCfm(ssap, cLeg, event, userCtxt)

SoSSapCb *ssap; 
SoCLegCb   *cLeg; 
SoEvnt     *event;
SoUserCtxt *userCtxt;
#endif
{
   S16 ret;
   SoEventHeader *eventHdr; 
   TknU32        *expiresHdr; 
   U16           numEventHdr;
   TknStrOSXL    subId;
   U8            subscriptionState;
   Bool          isReferEvent;
   U16           statusCode;
   TknU32        notifyExpires;
   Bool          retry;
   SoSubNode     *node;
   
   TRC3(soUaNotifyCfm);
  
   ret = soGetSubscInfo(event, &subId, 
                   &eventHdr, &expiresHdr,
                   &numEventHdr, &subscriptionState, &isReferEvent,
                   &notifyExpires,
                   &retry);
   
   if(ret != ROK)
   {
      (Void) soCmFreeEvent(event);
      RETVALUE(RFAILED);
   }
 
#ifdef SO_1XX_PASS
  /*--- so013.201: Pass 1xx Response To User ---*/
  if (event->t.response.statusLine.statusCode.val/100 == SO_STACODE_TYPE_INFORM)
  {
    ret = soUiCnStInd (cLeg->userConnId, cLeg->call, event);
    RETVALUE(ret);
  }
#endif

   statusCode = event->t.response.statusLine.statusCode.val;
   
   node = (SoSubNode *)userCtxt->subscCb;
   if(isReferEvent == TRUE)
   {
#ifdef SO_REFER
      if(!node)
      {
         (Void) soCmFreeEvent(event);
         RETVALUE(RFAILED);
      }
            
      soSubscFSMUpdateRsp(node, SO_METHODSTD_NOTIFY, 
                       statusCode, subscriptionState, retry, NULLP); 

      soUaCAMInd(cLeg, event);

     /* so025.201: After receiving response, we can teriminate     *
      *    subscription control block if it is no longer required  */
      if (node->state == SO_SUBSC_FSM_TERMINATE_DONE)
      {
          soDlgDelCurSubscNode (node);

         /*- so026.201: Return ROKDNA to indicate CLeg may be deleted -*/
          RETVALUE (ROKDNA);
      }

      RETVALUE(ROK);
#else
      (Void) soCmFreeEvent(event);
      RETVALUE(RFAILED);
#endif /* SO_REFER */      
   }
   if(!node)
   {
      ret = soUiCIMCfm (ssap, cLeg->userConnId, 
                        cLeg->call->spConnId, event);
      RETVALUE(ROK);
   }
   else
   {
      soSubscFSMUpdateRsp(node, SO_METHODSTD_NOTIFY, 
                          statusCode, subscriptionState,retry, NULLP); 

      /* so009.201 : Added new parameter userConnId to function call */
      soUiCAMCfm(cLeg->userConnId, cLeg->call, event);

     /* so025.201: After receiving response, we can teriminate     *
      *    subscription control block if it is no longer required  */
      if (node->state == SO_SUBSC_FSM_TERMINATE_DONE)
      {
          soDlgDelCurSubscNode (node);

         /*- so026.201: Return ROKDNA to indicate CLeg may be deleted -*/
          RETVALUE (ROKDNA);
      }

      RETVALUE(ROK);
   }
}




/*
*
*       Fun:   soUaSubscTimerHandle
*
*       Desc:  This function processes a timeout event
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaSubscTimerHandle
(
SoSubNode *node, 
Bool isSubscExpTimer 
)
#else
PUBLIC S16 soUaSubscTimerHandle(node, isSubscExpTimer)
SoSubNode *node; 
Bool isSubscExpTimer;
#endif
{
   S16 ret;

   TRC3(soUaSubscTimerHandle);
   
  /*--- so014.201: Initialize local variable ---*/
   ret      = ROK;

   if(isSubscExpTimer)
   {
      soUaSubscTimeout(node);
   }
   else
   {
     ret = soSubscFSMUpdateTimeout(node, isSubscExpTimer);
     if(ret != ROK || 
        node->state == SO_SUBSC_FSM_TERMINATE_DONE)
     {
        soDlgDelCurSubscNode(node);
     }
   }
   RETVALUE(ROK);
}
/*
*
*       Fun:   soUaSubscTimeout
*
*       Desc:  This function processes a timeout event
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaSubscTimeout
(
SoSubNode *node 
)
#else
PUBLIC S16 soUaSubscTimeout(node)
SoSubNode *node; 
#endif
{
   SoCSeq      *cSeqHdr;   /* CSeq header field               */
   U16         hdrIdx;     /* Index of header in message      */
   S16         ret;        /* Return value                    */
   SoCLegCb    *cLeg;
   SoEvnt      *tmpEvent;
   Bool        callCleared;
   SoUserCtxt  usrCtxt;
   
   TRC3(soUaSubscTimeout);

  /*--- so014.201: Initialize local variable ---*/
   ret      = ROK;
   cmMemset((U8 *)(&usrCtxt), 0, sizeof(SoUserCtxt)); 
   callCleared = FALSE;

   cLeg = node->cLeg;

   if(node->type == SO_SUBSC_TYPE_REFER)
   {
      soUiSubscErrInd(node->cLeg->call->ssapCb, node->cLeg->userConnId, 
                 cLeg->call->spConnId, node->event, &node->subId,
                 node->cLeg->legId, SOT_ET_REFER,
                 SOT_ERR_REFER_TMO, callCleared);
      node->event = NULLP;
      soDlgDelCurSubscNode(node); 
      RETVALUE(ROK);
   }
   
   if(soSubscFSMUpdateTimeout(node, TRUE) != ROK)
   {
      node->state = SO_SUBSC_FSM_TERMINATE_DONE;
      soSchedTmr(node, SO_TMR_SUBSC_EXP,TMR_STOP, NOTUSED);
      soUiSubscErrInd(node->cLeg->call->ssapCb, node->cLeg->userConnId, 
                 node->cLeg->call->spConnId, node->event, &node->subId,
                 node->cLeg->legId, SOT_ET_SUBSCRIBE, 
                 SOT_ERR_SUBSC_TMO, callCleared);
      node->event = NULLP;
      soDlgDelCurSubscNode(node); 
      RETVALUE(RFAILED);
   }
   if(node->state == SO_SUBSC_FSM_TERMINATE_DONE)
   {
      soUiSubscErrInd(node->cLeg->call->ssapCb, node->cLeg->userConnId, 
                 node->cLeg->call->spConnId, node->event, &node->subId, 
                 node->cLeg->legId, 
                 SOT_ET_SUBSCRIBE, SOT_ERR_SUBSC_TMO, callCleared);
      node->event = NULLP;
      soDlgDelCurSubscNode(node); 
      RETVALUE(RFAILED);
   }
   if (cLeg->call->ent->reCfg.alertUsrOnEvntExp == TRUE && 
       node->isNotifier != TRUE)
   {
      /* Send SUBSC_TMO event to service user */
      SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
         "soUaSubscTimeout: Subscription timeout "
         "indication to SU on %s %d",
         (cLeg->call->ent->entityType==\
         SO_ENT_NS)?"NS":"UA",
         cLeg->call->ent->entId));
      /* update statistics */  
      cLeg->call->ent->otherSts.regTO++;
      soCb.sts.otherSts.regTO++;

      /* the node is going to be deleted within 32 second if 
       * no further refresh */
      soSchedTmr(node, SO_TMR_SUBSC_EXP,TMR_START, (32*SO_TMRVAL_1_S)); 
      tmpEvent = node->event;
      node->event = NULLP;
      soRefreshInd(node->cLeg, tmpEvent, SOT_ET_SUBSC_TMO);
      soCmFreeEvent(tmpEvent);
      RETVALUE(ROK);
   }

   if(node->isNotifier == TRUE)
   {
      node->state = SO_SUBSC_FSM_TERMINATE_DONE;
      /* so009.201 : Used user conn id instead of suConnId in callCb */
      soUiSubscErrInd(node->cLeg->call->ssapCb, 
                 node->cLeg->userConnId, 
                 node->cLeg->call->spConnId, 
                 node->event, &node->subId, node->cLeg->legId,
                 SOT_ET_SUBSCRIBE, SOT_ERR_SUBSC_TMO, TRUE);
      node->event = NULLP;
      soDlgDelCurSubscNode(node); 
      RETVALUE(ROK);
   }
   /* else we must automatically re-subscribe for subscriber 
    * Create new transaction using previous message 
    */
    
   /* Send SUBSCRIBE refresh message */
   SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                      "soUaSubscribeTimeout: Subscription timeout "
                             "generate refresh SUBSCRIBE from %s %d",
                             (cLeg->call->ent->entityType==\
                              SO_ENT_NS)?"NS":"UA",
                             cLeg->call->ent->entId));

   ret = soCmFindHdrChIndex(node->event, (U8 **) &cSeqHdr, &hdrIdx,
      SO_HEADER_GEN_CSEQ);
   if (ret == ROK)
   {
      soCmRemoveHdrChoice(node->event, hdrIdx, SO_HEADER_GEN_CSEQ);
   }
   soSchedTmr(node, SO_TMR_SUBSC_EXP,TMR_START, node->expVal); 

  /* so029.201: Save subscription CB in Transaction Control block  */
   SO_UA_SAVE_REF (usrCtxt, node);

   usrCtxt.saveMsg = TRUE;

   ret = soDlgUaOutReq(cLeg, &usrCtxt, node->event);
   RETVALUE(ROK);
}   

#ifdef SO_REFER
/*
*
*       Fun:   soUaReferReq
*
*       Desc:  This function processes a Refer Req  received from the user
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaReferReq
(
SoSubNode  **outNode, 
SoCLegCb   *cLeg, 
SoEvnt     *event
)
#else
PUBLIC S16 soUaReferReq(outNode, cLeg, event)
SoSubNode  **outNode; 
SoCLegCb   *cLeg; 
SoEvnt     *event;
#endif
{
   SoSubNode     *node;
   S16           ret;
   SoEventHeader *eventHdr; 
   TknU32        *expiresHdr; 
   U16           numEventHdr;
   TknStrOSXL    subId;
   U8            subscriptionState;
   Bool          isReferEvent;
   TknU32        notifyExpires;
   Bool          retry;
   
   *outNode = NULLP;
   ret = soGetSubscInfo(event, &subId, 
                   &eventHdr, &expiresHdr,
                   &numEventHdr, &subscriptionState, &isReferEvent,
                   &notifyExpires,
                   &retry);
         
   if(ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   node = NULLP;
   if(soFindSubscNode(cLeg, &subId, &node, SO_SUBSC_TYPE_REFER) == ROK)
   {
      /* subId used already */      
      RETVALUE(RFAILED);
   }
   if(soAllocSubscNode(&node, &subId, NULLP, cLeg,
             SO_SUBSC_TYPE_REFER, TRUE) != ROK)
      RETVALUE(RFAILED);   
   node->subId.pres = subId.pres;
   node->subId.val = subId.val;
   node->type = SO_SUBSC_TYPE_REFER;
   if(subId.pres == NOTPRSNT)
      cLeg->subscCb.defaultRefer = TRUE;
   cLeg->subscCb.numRefer++;
   node->state = SO_SUBSC_FSM_INIT;
   node->subscriptionState = SO_SUBSCRIPTION_STATE_INVALID;
   node->isNotifier = FALSE;
   node->node.node = (PTR)node;
   cmLListAdd2Tail(&cLeg->subscCb.subCp, &node->node);
   soSubscFSMUpdateReq(node, SO_METHODSTD_REFER, FALSE, 
                       subscriptionState); 
   *outNode = node;

   /* so019.201: Change to check the outgoing Refer header */
   ret = soUaChkOutEventHdr(cLeg, event);

   RETVALUE(ret);
}

/*
*
*       Fun:   soUaReferRspReq
*
*       Desc:  This function processes a Refer/subscribe rsp  
*              received from the user
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaReferRspReq
(
SoSubNode  **outNode,
SoCLegCb   *cLeg, 
SoEvnt     *event,
SoTransCb   *transCb
)
#else
PUBLIC S16 soUaReferRspReq(outNode, cLeg, event, transCb)
SoSubNode  **outNode;
SoCLegCb   *cLeg; 
SoEvnt     *event;
SoTransCb   *transCb;
#endif
{
   SoSubNode     *node;
   S16           ret;
   Bool          retry;
   SoEventHeader *eventHdr; 
   TknU32        *expiresHdr; 
   U16           numEventHdr;
   TknStrOSXL    subId;
   U16           statusCode;
   U8            subscriptionState;
   Bool          isReferEvent;
   TknU32        notifyExpires;
   
   *outNode = NULLP;
   node = (SoSubNode *)transCb->userContext.subscCb;
   ret = soGetSubscInfo(event, &subId, 
                   &eventHdr, &expiresHdr,
                   &numEventHdr, &subscriptionState, &isReferEvent,
                   &notifyExpires,
                   &retry);
   
   if(ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   if(expiresHdr != NULLP)
      node->expVal = (expiresHdr->val+32) * SO_TMRVAL_1_S;
   statusCode = event->t.response.statusLine.statusCode.val;
   if(soSubscFSMUpdateRsp(node, SO_METHODSTD_REFER, 
                       statusCode, subscriptionState, retry, NULLP) != ROK)
      RETVALUE(RFAILED);

   *outNode = node;
   RETVALUE(ROK);
}





/*
*
*       Fun:   soUaReferInd
*
*       Desc:  This function processes a Refer Ind  
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaReferInd
(
SoCLegCb   *cLeg, 
SoEvnt     *event,
SoTransCb   *transCb
)
#else
PUBLIC S16 soUaReferInd(cLeg, event, transCb)

SoCLegCb   *cLeg; 
SoEvnt     *event;
SoTransCb   *transCb;
#endif
{
   SoSubNode *node;
   S16       ret;
  
   SoEventHeader *eventHdr; 
   TknU32        *expiresHdr; 
   U16           numEventHdr;
   TknStrOSXL    subId;
   U8            subscriptionState;
   Bool          isReferEvent;
   TknU32        notifyExpires;
   Bool          retry;

   /*so028.201:  Multiple Refers in a dialog*/
   SoCSeq        *cSeq;      /* CSeq header */
   S16       len;   
   
   ret = soGetSubscInfo(event, &subId, 
                   &eventHdr, &expiresHdr,
                   &numEventHdr, &subscriptionState, &isReferEvent,
                   &notifyExpires,
                   &retry);
   
   if(ret != ROK)
   {
      RETVALUE(SOT_RSP_400_BAD_REQUEST);
   }
   node = NULLP;
   /* should have no refer node in teh list */
   if(soFindSubscNode(cLeg, &subId, &node, SO_SUBSC_TYPE_REFER) == ROK)
   {
     RETVALUE(SOT_RSP_400_BAD_REQUEST);
   }

   if(soAllocSubscNode(&node, &subId, NULLP, cLeg,
               SO_SUBSC_TYPE_REFER, FALSE) != ROK)
   {
      /* no memory so return server internal error code */
      RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
   }
      
   /*so028.201: Multiple Refers in a dialog*/
   if(soCmFindHdrChoice(event, (U8 **)&cSeq,
                           SO_HEADER_GEN_CSEQ) != ROK)
   {
      RETVALUE(RFAILED);
   }      
 
   SOALLOC(&(node->subId.val), sizeof(SO_MAX_UINTSZ_UA));
   if (node->subId.val == NULLP)
    RETVALUE(SOT_ERR_RSRC);

   /* Cseq is added as subs ID inorder to process multiple REFER messages 
    * within same diagloue
    */
   soUtlIntToStr(cSeq->cSeqVal.val, node->subId.val,&len);

   SODBGP_SO(SO_DBGMASK_UA, (soCb.init.prntBuf,
                            "soUaReferInd: cSeq.val = %lu, subId.val = %s, len = %d\n",
                            cSeq->cSeqVal.val,node->subId.val, len));      

   node->subId.pres = cSeq->cSeqVal.pres;
   node->subId.len = len;

   node->type = SO_SUBSC_TYPE_REFER;
   if(subId.pres == NOTPRSNT)
      cLeg->subscCb.defaultRefer = TRUE;
   cLeg->subscCb.numRefer++;
   node->state = SO_SUBSC_FSM_INIT;
   node->subscriptionState = SO_SUBSCRIPTION_STATE_INVALID;
   soSubscFSMUpdateReq(node, SO_METHODSTD_REFER, TRUE, 
                       subscriptionState); 
   node->isNotifier = TRUE;
   node->node.node = (PTR)node;
   cmLListAdd2Tail(&cLeg->subscCb.subCp, &node->node);

  /* so026.201: Save subscription CB in Transaction Control block  */
   SO_UA_SAVE_REF (transCb->userContext, node);

   /* update route for subscribe created leg only. */ 
   if (cLeg->call->sessCreatedBy == SOT_ET_REFER)
   {
      ret = soDlgUpdRoute(cLeg, event, SO_REMOTE);
      if (ret != ROK)
      {
         RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
      }
   }
 
   soUaCAMInd(cLeg, event);

   RETVALUE(ROK);
}



/*
*
*       Fun:   soUaReferCfm
*
*       Desc:  This function processes a Refer/subscribe rsp  
*              received from the user
*
*       Notes: 
*
*       File:  so_subsc.c
*
*/
#ifdef ANSI
PUBLIC S16 soUaReferCfm
(
SoCLegCb   *cLeg, 
SoEvnt     *event,
SoUserCtxt *userCtxt
)
#else
PUBLIC S16 soUaReferCfm(cLeg, event, userCtxt)

SoCLegCb   *cLeg; 
SoEvnt     *event;
SoUserCtxt *userCtxt;
#endif
{
   SoSubNode     *node;
   S16           ret;
   SoEventHeader *eventHdr; 
   TknU32        *expiresHdr; 
   U16           numEventHdr;
   TknStrOSXL    subId;
   U16           statusCode;
   U8            subscriptionState;
   Bool          isReferEvent;
   Bool          retry;
   TknU32        notifyExpires;

  /*--- so014.201: Initialize local variable ---*/
   ret      = ROK;

#ifdef SO_1XX_PASS
  /*--- so013.201: Pass 1xx Response To User ---*/
  if (event->t.response.statusLine.statusCode.val/100 == SO_STACODE_TYPE_INFORM)
  {
    ret = soUiCnStInd (cLeg->userConnId, cLeg->call, event);
    RETVALUE(ret);
  }
#endif

   retry = FALSE;
   node = (SoSubNode *)userCtxt->subscCb;
   /* forking refer */
   if(node == NULLP)
   {
      soAllocSubscNode(&node, &subId, event, cLeg,
               SO_SUBSC_TYPE_REFER, FALSE);
      if(node == NULLP)
      {
         (Void) soCmFreeEvent(event);
         RETVALUE(RFAILED);
      }

      if(subId.pres == NOTPRSNT && cLeg->subscCb.defaultRefer == FALSE )
         cLeg->subscCb.defaultRefer = TRUE;
      else
      {
         node->state = SO_SUBSC_FSM_TERMINATE_DONE;
         (Void) soCmFreeEvent(event);
         soDlgDelCurSubscNode(node);
         RETVALUE(RFAILED);
      }
      cLeg->subscCb.numRefer++;
      node->node.node = (PTR)node;
      cmLListAdd2Tail(&cLeg->subscCb.subCp, &node->node);

     /* so026.201: Save subscription CB in Transaction Control block  */
      SO_UA_SAVE_REF ((*userCtxt), node);

   }
   ret = soGetSubscInfo(event, &subId, 
                   &eventHdr, &expiresHdr,
                   &numEventHdr, &subscriptionState, &isReferEvent,
                   &notifyExpires,
                   &retry);
   if(ret != ROK)
   {
      node->state = SO_SUBSC_FSM_TERMINATE_DONE;
      (Void) soCmFreeEvent(event);
      soDlgDelCurSubscNode(node);
      RETVALUE(RFAILED);
   }
      
   statusCode = event->t.response.statusLine.statusCode.val;
   soSubscFSMUpdateRsp(node, SO_METHODSTD_REFER, statusCode, 
             subscriptionState, retry, NULLP); 
   /* Update route if the session was created by a subscribe */
   if (cLeg->call->sessCreatedBy == SOT_ET_REFER)
   {
     ret = soDlgUpdRoute(cLeg, event, SO_REMOTE);
     if (ret != ROK)
     {
        (Void) soCmFreeEvent(event);
        RETVALUE(RFAILED);
     }
   }

   /* so009.201 : Added new parameter userConnId to function call */
   soUiCAMCfm(cLeg->userConnId, cLeg->call, event);

   /* so025.201: After receiving response, we can teriminate      *
    *    subscription control block if it is no longer required   */
   if (node->state == SO_SUBSC_FSM_TERMINATE_DONE)
   {
       soDlgDelCurSubscNode (node);

      /*- so026.201: Return ROKDNA to indicate CLeg may be deleted -*/
       RETVALUE (ROKDNA);
   }

   RETVALUE(ROK);
}

#endif /* SO_REFER */

#endif /* SO_EVENT */

#ifdef SO_REPLACES

/*****************************************************************************
*
*       Fun:    soUaPrcInvReplacesHdr
*
*       Desc:   Check whether the incoming INVITE contains a replaces
*               header.
*               If the incoming INVITE has a Replaces header then a 
*               matching call-leg is found. If found then its suConId/
*               spConId and cLegId are updated in the SoMsgCb->evnt 
*               structure 
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   so_ua.c
*
*****************************************************************************/
#ifdef ANSI
PUBLIC S16 soUaPrcInvReplacesHdr
(
SoCLegCb      *cLeg,     /* Cleg Cb */
SoEvnt        *evnt      /* Message Cb containing SOT event          */
)
#else
PUBLIC S16 soUaPrcInvReplacesHdr(cLeg, evnt)
SoCLegCb      *cLeg;     /* Cleg Cb */
SoEvnt        *evnt;     /* Message Cb containing SOT event          */
#endif /* ANSI */
{  
   S16         ret;
   SoReplaces  *soReplaces;
   TknStrOSXL  *repCallId;
   TknStrOSXL  *toTag;
   TknStrOSXL  *fromTag;
   U16         i;
   SoCLegCb    *cLegCb, *tmpCLeg;
   CmLList    *curNode;
   SoCallCb   *callCb;
   PTR        curItem;
   
   TRC2(soUaPrcInvReplacesHdr);

   /* Initialization */
  /*--- so014.201: Initialize local variable ---*/
   ret        = ROK;
   soReplaces = NULLP;
   repCallId = NULLP;
   toTag = NULLP;
   fromTag = NULLP;
   cLegCb = NULLP;
   callCb = NULLP;
   tmpCLeg =NULLP;

   if (evnt == NULLP)
      RETVALUE(RFAILED);

   /* Find replaces header in message */
   ret = soCmFindHdrChoice (evnt, (U8 **) &soReplaces,
                            SO_HEADER_REQ_REPLACES);
   
   if (ret != ROK)
      RETVALUE(SOT_RSP_NONE);

   if (soReplaces->pres.pres != PRSNT_NODEF)
   {
     /*so024.201: Generate the proper error for Incorrect Replace Header*/
     RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
   }
   
   repCallId = &soReplaces->callId;
   
   /* We found a Replaces header. Now try to locate the call-leg */
   /* so032.201: Pass event type to locate call control block */
   callCb = soCoreLocateCallCb(cLeg->call->ent, SO_CONNID_NOTUSED, 
                               SO_CONNID_NOTUSED, repCallId, SOT_ET_UNKNOWN);
   if(callCb == NULLP)
   {
       /*so024.201: Generate the proper error for Incorrect Replace Header*/
       RETVALUE(SOT_RSP_481_CLEG_TRAN_NOT_EXIST);
   }

   if (soReplaces->replacesParams.numComp.pres != PRSNT_NODEF)
   {
       /*so024.201: Generate the proper error for Incorrect Replace Header*/
       RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
    }

   for (i = 0; i < soReplaces->replacesParams.numComp.val; i++)
   {
      if (soReplaces->replacesParams.replacesParam[i]->paramType.pres != 
            PRSNT_NODEF)
         break;

      if (soReplaces->replacesParams.replacesParam[i]->paramType.val ==
            SO_REPLACES_PARAMTYPE_TOTAG)
      {
         toTag = &soReplaces->replacesParams.replacesParam[i]->u.toTag;
      }
      else if (soReplaces->replacesParams.replacesParam[i]->paramType.val ==
            SO_REPLACES_PARAMTYPE_FROMTAG)
      {
         fromTag =  &soReplaces->replacesParams.replacesParam[i]->u.fromTag;
      }
   }

   if ((toTag == NULLP) || (fromTag == NULLP))
   {
       /*so024.201: Generate the proper error for Incorrect Replace Header*/
       RETVALUE(SOT_RSP_500_SRV_INT_ERROR);
    }

   curNode = cmLListFirst(&callCb->cLegLst);
   while (curNode != (CmLList *)NULLP)
   {
      curItem  = cmLListNode(curNode);
      curNode  = curNode->next;
      tmpCLeg = (SoCLegCb *)curItem;
      if(SO_CMP_TKNSTR(&tmpCLeg->storedHdrs.localTag, toTag) == TRUE && 
          SO_CMP_TKNSTR(&tmpCLeg->storedHdrs.remoteTag, fromTag) == TRUE)
      {
         cLegCb = tmpCLeg;
         break;
      }
   }
  
   if(cLegCb == NULLP)
      /*no match found,reject with 481 response */
      ret = SOT_RSP_481_CLEG_TRAN_NOT_EXIST;
   
   else if(cLegCb->clegState == SO_CLEG_STATE_TERMINATED)
      /*dialog already terminated,decline with 603 response */
      ret = SOT_RSP_603_DECLINE;
   else if(cLegCb->call->sessCreatedBy == SOT_ET_INVITE)
   {
      /* so009.201 : Used user conn id instead of suConnId in callCb */
      evnt->rplcSuConId = cLegCb->userConnId;
      evnt->rplcSpConId = cLegCb->call->spConnId;
      evnt->rplcCLegId = cLegCb->legId;
   }

   RETVALUE(ret);
} /* end of soUasPrcInvReplaces */
#endif /* SO_REPLACES */

#ifdef SO_RFC_3262
/*
*
*       Fun:   soUaStopRelRspTmr
*
*       Desc:  This function stops all 1XX timers
*              for reliable response
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PRIVATE Void soUaStopRelRspTmr
(
SoCLegCb *cLeg    /* Cleg Cb */
)
#else
PRIVATE Void soUaStopRelRspTmr(cLeg)
SoCLegCb *cLeg;   /* Cleg Cb */
#endif
{
  SoProvRspCb  *provRspCb;    /* Provisional Response Cb */
  CmLList      *curNode;      /* Current node in list         */

  TRC2(soUaStopRelRspTmr);

  /* Check if it is reliable response call */
  if ((cLeg->relProvRspInfo.peerReqRelRsp == TRUE) ||
      ((cLeg->call->ent->s.ua.reCfg.relProvRspReq) && 
       (cLeg->relProvRspInfo.peerSuppRelRsp)))
  {
     /* Step 1 : Find all the Prov. Rsp. Cb in provRspCbLst, 
        stop the timers and release the Cb */
   
     while (cmHashListGetNext(&cLeg->relProvRspInfo.provRspCbLst, (PTR)NULLP,
                              (PTR *) &provRspCb) == ROK)
     {
        /* Stop the 1xx Retx Timer */
        soSchedTmr(provRspCb, SO_TMR_1XX_RETX, TMR_STOP, NOTUSED);
   
        /* Start the Expiry Timer for the provisional response also.*/
        soSchedTmr(provRspCb, SO_TMR_1XX_EXPIRY, TMR_STOP, NOTUSED);
   
        /* Free the provisional Response Cb  and remove it from the hash list */
        cmHashListDelete(&cLeg->relProvRspInfo.provRspCbLst, (PTR) provRspCb);
        SOFREE(provRspCb, sizeof(SoProvRspCb));
     }        
   
   
     /* Step 2 : Find all the pending Prov. Rsp. Cb in pendProvRspLst, 
        release the Cb */
      
     curNode = cmLListFirst(&cLeg->relProvRspInfo.pendProvRspLst);
     while (curNode != NULLP)
     {
        provRspCb    = (SoProvRspCb *)curNode->node;
   
        if (provRspCb->evnt != NULLP)
           soCmFreeEvent(provRspCb->evnt);
   
        cmLListDelFrm (&cLeg->relProvRspInfo.pendProvRspLst, curNode);
        SOFREE(provRspCb, sizeof(SoProvRspCb));
   
        curNode = cmLListFirst(&cLeg->relProvRspInfo.pendProvRspLst);
     }
  }
   
  RETVOID;
}
#endif /* SO_RFC_3262 */



/* so015.201 : Added new utility Function */

/*
*
*       Fun:   soUaChkAndClearIntCtxt
*
*       Desc:  This function clears context based on event type, in case of sending 
*              failure.
*
*       Notes: 
*
*       File:  so_ua.c
*
*/
#ifdef ANSI
PUBLIC Void soUaChkAndClearIntCtxt
(
SoCLegCb     *cLeg,    /* Call Leg Cb */
SoEvnt       *evnt     /* Event Cb */
)
#else
PUBLIC Void soUaChkAndClearIntCtxt(cLeg, evnt)
SoCLegCb     *cLeg;    /* Call Leg Cb */
SoEvnt       *evnt;    /* Event Cb */
#endif
{

   SoCSeq      *cSeq;      /* new CSeq header */

   TRC2(soUaChkAndClearIntCtxt);

   /* For now only REGISTER has been identified to create contexts
      that need clearing. In future, if more such scenarios occur, this function
      can be re-used */

   if (evnt->eventType.val == SOT_ET_REGISTER)
   {
      /* If REGISTER sending failed, we need to clear pending contacts
         if we are maintaining it */

      /* Copy CSeq from old evnt into new one */
      if (soCmFindHdrChoice(evnt, (U8 **) &cSeq, SO_HEADER_GEN_CSEQ) != ROK)
         RETVOID;

      soUaPrcRegErrRsp(cLeg, cSeq->cSeqVal.val);
   }

   /* so035.201: Delete all transactions in case a Bye sending failed */
   if (evnt->eventType.val == SOT_ET_BYE)
   {
      soDlgDeleteAllTxn(cLeg);
   }

   RETVOID;
}

/* so029.201 : Added function */
/* so038.201 : Removed soUaClosePendingTrans since it is not used */

#endif /* SO_UA */

/********************************************************************30**

         End of file:     so_ua.c@@/main/4 - Tue Apr 20 12:47:24 2004

*********************************************************************31*/

/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------
   1.1         osp       1. Initial version

*********************************************************************71*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---    pk       1. Release for 2.1.
/main/4+  so001.201 ps       1. For CANCEL request, core module must pass
                                VIA  header that is same as VIA header of
                                corresponding INVITE request.
                    up       2. Init pointers in soUaFindRegCallCb
                             3. Validate refresher param in session Hdr
/main/4+  so003.201 up       1. Session-Timer feature made compliant to 
                                draft 14.
                             2. Add Via for internal CANCEL.
/main/4+  so004.201 pk       1. Changed state for updation of Route
                    up       2. Adjust timer value to notify _before_ expiry
/main/4+  so006.201 up       1. Increment currRseq counter
                    pk       2. Set correct eventType at Session expiry
                    pk       3. Add CONTACT header for 18x response.
/main/4+  so008.201 up       1. Variable addition
/main/4+  so009.201 pk       1. Added parameter userConnId in cLeg.
                                Changed interfaces to include userConnId.
                             2. Changes done to support INFO outside a call.
                             3. Updated remote target URIs for reliable
                                provisional responses.
                             4. Deallocate encoded message buffer on getting
                                ACK message.
                             5. Fix to disable session negotiation on 422 rsp
/main/4+  so010.201 pk       1. Fixed memory leaks.
                    up       2. Added supported header for Update.
                             3. Reset refresher for session refresh.
/main/4+  so011.201 up       1. Add supported header for Update.
                    up       2. Stop Session Timer when the call is cleared.
                    up       3. Init ret value for soUaChkOut1xxHdr.
                    up       4. Store orig Route List and Req URI for CANCEL.
                    up       5. Use orig Route List and Req URI for CANCEL.
                    up       6. On REGISTER timeout, clear the call leg before 
                                sending the indication to user app.
                    ab       7. Passing paramater event type
                    up       8. Support to handle REGISTER message at UAC.
                                The feature has been added under the flag 
                                SO_XX_UA_PRC_REGISTER.
/main/4+  so012.201 up       1. Free SIP 100 message evnt if not passed to
                                the user.
                             2. On Expires timer expiry, send CANCEL if no 
                                final response received.
/main/4+  so013.201 up       1. Update Req Uri in case of session refresh.
                             2. For incoming CANCEL request, send the original
                                INVITE transaction to the user.
                             3. Stop the Expires Timer for 4XX/5XX/6XX response.
                    ps       4. Pass 1XX Response to the user.
/main/4+  so014.201 ps       1. ReqURI/route for INVITE saved in transaction to
                                be used for CANCEL Request.
                    ps       2. Initialize local variables in soUaPrcRegRsp() fn.
                    ps       3. Corrected check for case when new call-ID is
                                provided during Registration.
                    ps       4. For outgoing INFO/Unknown method, event structure
                                need not be saved in dialog layer.
/main/4+  so015.201 ps       1. Delete the subscription if subscription state is
                                terminated.
                             2. Initialize event pointer.
                    pk       3. Added new function to delete registration.
                    ps       4. For expires timer expiry, send CANCEL only 
                                if early/proceeding stage is reached.
/main/4+  so016.201 ad       1. If no Expires header then insert 
                                Expires header in Register.
                    ab       2. Update Req Uri in case of session refresh
/main/4+  so017.201 pk       1. Register procedre fixes to take care of
                                contacts being de-regsieterd and that are
                                not returned in response.
/main/4+  so018.201 ps       1. Reset remote tag in calleg while sending 
                                request after 422 response.
/main/4+  so019.201 sg       1. Change to insert Date header for ACK, BYE, CANCEL
                                OPTION, REGISTER, SUBSCRIBE, NOTIFY, REFER, and
                                MESSAGE request method.
                             2. Delete cancel transaction as well during cancel timeout 
/main/4+  so020.201 ps       1. Update remote target URI on getting 1xx response
                                from UAS.
                    ss       2. Case insensitive string comparison.
                    ss       3. Used last transCb to findout next element in list
/main/5+  so021.201 ab       1. Check if expired hdr is configured to be inserted
/main/5+  so022.201 ps       1. Save user connection identifier in call leg
/main/5+  so024.201 ab       1. If both sides support 100rel and user adds Require:100rel
                                then add it in outgoing 1xx response.
                    ad       2. Session Timer Configuration on UAS side also
                    ab       3. Dont process contacts if dereg resp
                    ad       4. Generate the proper error for Incorrect Replace 
                                Header
                    ab       5. Get tcmConn from rspCb for 1xx and 2xx retx in case
                                of NAT and UDP server.
                    ad       6. Free the Memory, when we neither sending
                                CIMCfm nor sending the Error Indication
/main/5+  so024.201 ss       1. Updated handing of incoming msg in case 
                                reliable response is not asked.
/main/5+  so025.201 ps       1. Reset call leg information before recursing on 3xx.
                    ab       2. Correction to SO_USE_UDP_SRVR flag
                    ss       3. Deleting event in case of de-registration
                                without storing in contactCb
                    ab       4. For 1.2 interface pass if internal message
                    ps       5. Correct deletion of subscription state machine
/main/5+  so026.201 ps       1. Reset recursion "on" state before providing final
                                response to application.
                    ad       2. Correcting Cannot send 200 Ok problem
                    ss       3. In case of registration referesh, created a
                                new event structure and deleted the old one.
                    ps       4. Subcription control block should be deleted
                                only after ists last reference to TCB is
                                removed.
                    ss       5. Used expiry time value coming as a part of 
                                contact hdr in reg/dereg.
/main/5+  so028.201 ad       1. Multiple Refers in a dialog.
/main/5+  so029.201 ps       1. transCb reference count in subscription node 
                                should be updated only if TCB is created.
                             2. Handle CANCEL request from user in Unexpected
                                State.
                             3. If INVITE response is not passed to user, we
                                should free event structure.
                    ad       4. Check for cLeg active state also, in case of
                                failure response for Re-Invite.     
                    ss       5. Updated deletion of contact CB
                    ss       6. Added new function to close all pending txns
/main/5+  so030.201 ss       1. Stop Session Timer on 2xx Resp only
/main/5+  so031.201 aj       1. Added transCb argument in function 
                                soDlgSendResponse
                             2. Adding for the fix of challenge of NOTIFY request.   
/main/5+  so032.201 ng       1. Pass event type to locate call control block(ab)
                    ng       2. To remove the memory leak.(ad)
                    ng       3. Passing the PRACK to User.(ad)
                    ng       1. Support for outside Dialog Notifications   
/main/5+  so033.201 ng       1. Corrected function soCpySubscId(ss)
/main/5+  so033.201 ng       1. Removed state transition to a dead state(ps)
                             2. Adding Rack in outgoing PRACK message 
                             3. Handle Offer-Answer in Incoming INVITE 
                             4. Check Offer-Answer in PRACK if not generated 
                                internally 
                    ng       5. Clearing early Invite transactions on receiving(ab)
                                Bye for the same dialog
                    ng       6. In case of de-registration, identify (ss) 
                                whether to remove the contact or re-register the same
/main/5+  so034.201 ng       1. In case of receipt of ReInvite without Session Expire (aj)
                                header the role of the UAC is not changed 
          so034.201 ng       1. Removed UNUSED(tmrEvnt) and corrected type for suConnId, spConnId
/main/5+  so035.201 ng       1. Passing flag selfAdded to soUtlAddContactHdr to indicate
                                if Contact was added by the Stack.(ab)
                    ng       1. Moved Addition of Contact Header to outside of this check(ab)
                    ng       2. Added support for Offer-Answer in Update.(ad)
                    ng       3. Check if node is not NULLP and set node->event 
                                to NULLP if soDlgUaOutRsp return error in soUaCAMRsp   
                    ng       4. Fixed bye clearing - Removed soDlgCloseAllPendingTxn and replaced 
                                with soDlgDeleteAllTxn(pk)
                    ng       5. If it is a subscribe and the call leg doesnot match it may imply that 
                                the user is retrying after a 407, so create a new callleg to send out
                                the updated subscribe(pk) 
                    ng       6. Delete all transactions in case a Bye sending failed (pk)
/main/5+  so038.201 ps       1. In case CLegCb is reused for internal 3xx
                                recursion,update dialog creating CSEQ number.
                             2. If Rack is present in outgoing PRACK message, 
                                donot add it again   
/main/5+  so038.201  ng      1. Added error check condition
                     pk      2 Clear all other pending transactions gracefully 
                               replaced soDlgDeleteAllTxn 
                             3. Removed soUaClosePendingTrans since it is not used
/main/5+  so040.201  aj      1. set event pointer to nullp in cleg so that it 
                                is not deleted in soDlgDeleteCleg. When error 
                                is returned, Event is deleted in soUiErrInd 
/main/5+  so041.201  ps      1. Corrected handling of expires  timer expiry. 
                                Application should be informed  with ErrInd
                                only if call is cleared internally. For UAC,
                                we should only send out CANCEL. For UAS, we 
                                should delete context and then send ErrInd()
                                to application. 
                             2. Added comments while getting cLeg for 
                                SUBSCRIBE request retried by application.
                     ng      3. Send 487 for pending UAS transactions in SoByeReq
                                and soUaByeRsp 
                             4. Removed code to delete UAC transaction in early
                                state in soUaByeRsp. ACK cannot be sent for 487, 
                                which is expected when Re-Invite is responded 
                                with a Bye.
                             5. In case previous call role was UAC & refresher 
                                also UAC, now call role is modified to UAS since 
                                ReInvite without Session Expire header is 
                                recieved, the role of refersher UAC/UAS needs to 
                                be changed in soUasSessTmrPrcReq
*********************************************************************91*/

