/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     SIP Portable Upper Interface

     Type:     C source file

     Desc:     C source code for SO layer portable Upper Interface

     File:     so_ptui.c

     Sid:      so_ptui.c@@/main/4 - Tue Apr 20 12:46:58 2004

     Prg:      wvdl

*********************************************************************21*/

/*
The following functions are provided in this file:
   SoUiSotBndCfm           - Bind Confirm
   SoUiSotCIMCfm           - CIM Confirm
   SoUiSotCIMInd           - CIM Indication
   SoUiSotConCfm           - Connection Confirm
   SoUiSotConInd           - Connection Indication
   SoUiSotCnStInd          - Connection Status
   SoUiSotRelCfm           - Release Confirm
   SoUiSotRelInd           - Release Indication
   SoUiSotModCfm           - Modify Confirm
   SoUiSotModInd           - Modify Indication

It should be noted that not all of these functions may be required
by a particular network layer service user.
*/


/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "so_err.h"        /* SIP error defines */
#include "cm_tkns.h"       /* common tokens */
#include "cm_tpt.h"        /* common transport */
#include "cm_sdp.h"        /* common SDP */
#include "cm_mblk.h"       /* common memory allocation */
#include "sot.h"           /* SOT interface defines */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common tokens */
#include "cm_tpt.x"        /* common transport */
#include "cm_mblk.x"       /* common memory allocation */
#include "cm_sdp.x"        /* common SDP */
#include "sot.x"           /* SOT interface structures */

/* local defines */
#define SO_MAX_UISOT_SEL         5       /* maximum no. selectors */

#if (!defined(LWLCSOUISOT) || !defined(LCSOUISOT))
#define PTSOUISOT
#else
#ifndef SV
#define PTSOUISOT
#else
#endif
#endif

/* forward references */
#ifdef PTSOUISOT
PUBLIC S16 PtUiSotBndCfm      ARGS((Pst     *pst,
                                    SuId    suId,
                                    U8      status));
#ifdef SO_REL_1_2_INF
PUBLIC S16 PtUiSotCIMInd      ARGS((Pst     *pst,
                                    SuId    suId,
                                    SoEvnt  *soEvnt));
PUBLIC S16 PtUiSotCIMCfm      ARGS((Pst     *pst,
                                    SuId    suId,
                                    SoEvnt  *soEvnt));
#else
PUBLIC S16 PtUiSotCIMInd      ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *soEvnt));
PUBLIC S16 PtUiSotCIMCfm      ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *soEvnt));
#endif /* SO_REL_1_2_INF */
PUBLIC S16 PtUiSotConInd      ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId spConnId,
                                    SoEvnt  *soEvnt));
PUBLIC S16 PtUiSotConCfm      ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *soEvnt));
PUBLIC S16 PtUiSotCAMInd      ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *soEvnt));
PUBLIC S16 PtUiSotCAMCfm      ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *soEvnt));
PUBLIC S16 PtUiSotCnStInd     ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *soEvnt));
PUBLIC S16 PtUiSotRelCfm      ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *soEvnt));
#ifdef SO_REL_1_2_INF
PUBLIC S16 PtUiSotRelInd      ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    U8      relType,
                                    SoEvnt  *soEvnt));
#else
PUBLIC S16 PtUiSotRelInd      ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *soEvnt));
#endif /* SO_REL_1_2_INF */
PUBLIC S16 PtUiSotModInd      ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *soEvnt));
PUBLIC S16 PtUiSotModCfm      ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *soEvnt));
#ifndef SO_REL_1_2_INF
PUBLIC S16 PtUiSotAckInd      ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *soEvnt));
PUBLIC S16 PtUiSotCancelInd     ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *soEvnt));
PUBLIC S16 PtUiSotErrInd      ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *errEvnt));
PUBLIC S16 PtUiSotRefreshInd  ARGS((Pst     *pst,
                                    SuId    suId,
                                    UConnId suConnId,
                                    UConnId spConnId,
                                    SoEvnt  *refreshEvnt));
#ifdef SO_UA
PUBLIC S16 PtUiSotAuditCfm    ARGS((Pst     *pst,
                                    SuId    suId,
                                    SoEvnt  *soEvnt));
#endif /* SO_UA */
#endif /* SO_REL_1_2_INF*/
/*so036.201: Changes for CALEA */
#ifdef SO_CALEA
PUBLIC S16 PtUiSotRawMsg      ARGS((Pst         *pst,
                                    SuId        suId,
                                    UConnId     suConnId,
                                    UConnId     spConnId,
                                    U32         transId,
                                    U32         callLegId,
                                    U32         messageId,
                                    U8          eventType,
                                    U8          sipMessageType,
                                    Buffer      *mBuf
                                    ));
#endif

#endif /* PTSOUISOT */

/* Primitive mapping tables */

PUBLIC SotBndCfm SoUiSotBndCfmMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotBndCfm,        /* 0 - loosely coupled (default mechanism)  */
#else
   PtUiSotBndCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotBndCfm,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotBndCfm,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotBndCfm,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotBndCfm,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotBndCfm,        /* 3 - loosely coupled (default mechanism)  */
#else
   PtUiSotBndCfm,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotBndCfm,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotBndCfm,        /* 4 - lightweight loosely coupled, portable */
#endif
};

PUBLIC SotCIMInd SoUiSotCIMIndMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotCIMInd,        /* 0 - loosely coupled (default mechanism)  */
#else
   PtUiSotCIMInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotCIMInd,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotCIMInd,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotCIMInd,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotCIMInd,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotCIMInd,        /* 3 - loosely coupled (default mechanism)  */
#else
   PtUiSotCIMInd,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotCIMInd,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotCIMInd,        /* 4 - lightweight loosely coupled, portable */
#endif
};

PUBLIC SotCIMCfm SoUiSotCIMCfmMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotCIMCfm,        /* 0 - loosely coupled (default mechanism)  */
#else
   PtUiSotCIMCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotCIMCfm,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotCIMCfm,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotCIMCfm,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotCIMCfm,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotCIMCfm,        /* 3 - loosely coupled (default mechanism)  */
#else
   PtUiSotCIMCfm,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotCIMCfm,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotCIMCfm,        /* 4 - lightweight loosely coupled, portable */
#endif
};

PUBLIC SotConInd SoUiSotConIndMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotConInd,        /* 0 - loosely coupled (default mechanism)  */
#else
   PtUiSotConInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotConInd,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotConInd,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotConInd,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotConInd,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotConInd,        /* 3 - loosely coupled (default mechanism)  */
#else
   PtUiSotConInd,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotConInd,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotConInd,        /* 4 - lightweight loosely coupled, portable */
#endif
};

PUBLIC SotConCfm SoUiSotConCfmMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotConCfm,        /* 0 - loosely coupled (default mechanism)  */
#else
   PtUiSotConCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotConCfm,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotConCfm,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotConCfm,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotConCfm,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotConCfm,        /* 3 - loosely coupled (default mechanism)  */
#else
   PtUiSotConCfm,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotConCfm,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotConCfm,        /* 4 - lightweight loosely coupled, portable */
#endif
};


PUBLIC SotCnStInd SoUiSotCnStIndMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotCnStInd,        /* 0 - loosely coupled (default mechanism) */
#else
   PtUiSotCnStInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotCnStInd,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotCnStInd,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotCnStInd,        /* 2 - lightweight loosely couple, Service User SV */
#else
   PtUiSotCnStInd,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotCnStInd,        /* 3 - loosely coupled (default mechanism) */
#else
   PtUiSotCnStInd,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotCnStInd,        /* 4 - lightweight loosely couple, Service User SV */
#else
   PtUiSotCnStInd,        /* 4 - lightweight loosely coupled, portable */
#endif
};

PUBLIC SotRelCfm SoUiSotRelCfmMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotRelCfm,        /* 0 - loosely coupled (default mechanism) */
#else
   PtUiSotRelCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotRelCfm,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotRelCfm,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotRelCfm,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotRelCfm,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotRelCfm,        /* 3 - loosely coupled (default mechanism) */
#else
   PtUiSotRelCfm,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotRelCfm,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotRelCfm,        /* 4 - lightweight loosely coupled, portable */
#endif
};

PUBLIC SotRelInd SoUiSotRelIndMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotRelInd,        /* 0 - loosely coupled (default mechanism) */
#else
   PtUiSotRelInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotRelInd,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotRelInd,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotRelInd,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotRelInd,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotRelInd,        /* 3 - loosely coupled (default mechanism) */
#else
   PtUiSotRelInd,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotRelInd,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotRelInd,        /* 4 - lightweight loosely coupled, portable */
#endif
};

PUBLIC SotModInd SoUiSotModIndMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotModInd,        /* 0 - loosely coupled (default mechanism) */
#else
   PtUiSotModInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotModInd,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotModInd,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotModInd,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotModInd,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotModInd,        /* 3 - loosely coupled (default mechanism) */
#else
   PtUiSotModInd,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotModInd,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotModInd,        /* 4 - lightweight loosely coupled, portable */
#endif
};

PUBLIC SotModCfm SoUiSotModCfmMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotModCfm,        /* 0 - loosely coupled (default mechanism) */
#else
   PtUiSotModCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotModCfm,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotModCfm,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotModCfm,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotModCfm,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotModCfm,        /* 3 - loosely coupled (default mechanism) */
#else
   PtUiSotModCfm,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotModCfm,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotModCfm,        /* 4 - lightweight loosely coupled, portable */
#endif
};

PUBLIC SotCAMInd SoUiSotCAMIndMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotCAMInd,        /* 0 - loosely coupled (default mechanism) */
#else
   PtUiSotCAMInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotCAMInd,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotCAMInd,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotCAMInd,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotCAMInd,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotCAMInd,        /* 3 - loosely coupled (default mechanism) */
#else
   PtUiSotCAMInd,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotCAMInd,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotCAMInd,        /* 4 - lightweight loosely coupled, portable */
#endif
};

PUBLIC SotCAMCfm SoUiSotCAMCfmMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotCAMCfm,        /* 0 - loosely coupled (default mechanism) */
#else
   PtUiSotCAMCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotCAMCfm,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotCAMCfm,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotCAMCfm,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotCAMCfm,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotCAMCfm,        /* 3 - loosely coupled (default mechanism) */
#else
   PtUiSotCAMCfm,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotCAMCfm,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotCAMCfm,        /* 4 - lightweight loosely coupled, portable */
#endif
};

#ifndef SO_REL_1_2_INF
PUBLIC SotAckInd SoUiSotAckIndMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotAckInd,        /* 0 - loosely coupled (default mechanism) */
#else
   PtUiSotAckInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotAckInd,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotAckInd,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotAckInd,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotAckInd,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotAckInd,        /* 3 - loosely coupled (default mechanism) */
#else
   PtUiSotAckInd,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotAckInd,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotAckInd,        /* 4 - lightweight loosely coupled, portable */
#endif
};

PUBLIC SotCancelInd SoUiSotCancelIndMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotCancelInd,        /* 0 - loosely coupled (default mechanism) */
#else
   PtUiSotCancelInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotCancelInd,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotCancelInd,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotCancelInd,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotCancelInd,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotCancelInd,        /* 3 - loosely coupled (default mechanism) */
#else
   PtUiSotCancelInd,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotCancelInd,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotCancelInd,        /* 4 - lightweight loosely coupled, portable */
#endif
};

PUBLIC SotErrInd SoUiSotErrIndMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotErrInd,        /* 0 - loosely coupled (default mechanism) */
#else
   PtUiSotErrInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotErrInd,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotErrInd,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotErrInd,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotErrInd,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotErrInd,        /* 3 - loosely coupled (default mechanism) */
#else
   PtUiSotErrInd,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotErrInd,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotErrInd,        /* 4 - lightweight loosely coupled, portable */
#endif
};

PUBLIC SotRefreshInd SoUiSotRefreshIndMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotRefreshInd,        /* 0 - loosely coupled (default mechanism) */
#else
   PtUiSotRefreshInd,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotRefreshInd,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotRefreshInd,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotRefreshInd,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotRefreshInd,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotRefreshInd,        /* 3 - loosely coupled (default mechanism) */
#else
   PtUiSotRefreshInd,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotRefreshInd,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotRefreshInd,        /* 4 - lightweight loosely coupled, portable */
#endif
};

#ifdef SO_UA
PUBLIC SotAuditCfm SoUiSotAuditCfmMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotAuditCfm,        /* 0 - loosely coupled (default mechanism) */
#else
   PtUiSotAuditCfm,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotAuditCfm,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotAuditCfm,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotAuditCfm,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotAuditCfm,        /* 2 - lightweight loosely coupled, portable */
#endif
#ifdef LCSOUISOT
   cmPkSotAuditCfm,        /* 3 - loosely coupled (default mechanism) */
#else
   PtUiSotAuditCfm,        /* 3 - loosely coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotAuditCfm,        /* 4 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotAuditCfm,        /* 4 - lightweight loosely coupled, portable */
#endif
};
#endif /* SO_UA */ 
#endif /* SO_REL_1_2_INF */

#ifdef SO_CALEA
PUBLIC SotRawMsg SoUiSotRawMsgMt [SO_MAX_UISOT_SEL] =
{
#ifdef LCSOUISOT
   cmPkSotRawMsg,        /* 0 - loosely coupled (default mechanism)  */
#else
   PtUiSotRawMsg,        /* 0 - loosely coupled, portable */
#endif
#ifdef SV
   SvLiSotRawMsg,        /* 1 - tightly coupled, Service User SV */
#else
   PtUiSotRawMsg,        /* 1 - tightly coupled, portable */
#endif
#ifdef LWLCSOUISOT
   cmPkSotRawMsg,        /* 2 - lightweight loosely coupled, Service User SV */
#else
   PtUiSotRawMsg,        /* 2 - lightweight loosely coupled, portable */
#endif
};
#endif

/* Primitive Mapping Dispatching Functions */

/*
 *
 *       Fun:   SoUiSotBndCfm
 *
 *       Desc:  This function resolves the SotBndCfm primitive
 *
 *       Ret:  ROK -      ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotBndCfm
(
Pst  *pst,
SuId suId,
U8   status
)
#else
PUBLIC S16 SoUiSotBndCfm (pst, suId, status)
Pst   *pst;
SuId  suId;
U8    status;
#endif
{
   TRC3(SoUiSotBndCfm)

   (*SoUiSotBndCfmMt[pst->selector])(pst, suId, status);

   RETVALUE(ROK);
} /* SoUiSotBndCfm */

/*
 *
 *       Fun:   SoLiSotCIMInd
 *
 *       Desc:  This function resolves the SotCIMInd primitive
 *
 *       Ret:  ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef SO_REL_1_2_INF
#ifdef ANSI
PUBLIC S16 SoUiSotCIMInd
(
Pst    *pst,
SuId   suId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 SoUiSotCIMInd (pst, suId, soEvnt)
Pst    *pst;
SuId   suId;
SoEvnt *soEvnt;
#endif
#else /*SO_REL_1_2_INF */
#ifdef ANSI
PUBLIC S16 SoUiSotCIMInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotCIMInd (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
#endif /* SO_REL_1_2_INF */
{
   TRC3(SoUiSotCIMInd)

#ifdef SO_REL_1_2_INF
   RETVALUE((*SoUiSotCIMIndMt[pst->selector])(pst, suId, soEvnt));
#else
   RETVALUE((*SoUiSotCIMIndMt[pst->selector])(pst, suId, suConnId,
                                               spConnId, soEvnt));
#endif /* SO_REL_1_2_INF */

} /* SoUiSotCIMInd */

/*
 *
 *       Fun:   SoLiSotCIMCfm
 *
 *       Desc:  This function resolves the SotCIMCfm primitive
 *
 *       Ret:  ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef SO_REL_1_2_INF
#ifdef ANSI
PUBLIC S16 SoUiSotCIMCfm
(
Pst    *pst,
SuId   suId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 SoUiSotCIMCfm (pst, suId, soEvnt)
Pst    *pst;
SuId   suId;
SoEvnt *soEvnt;
#endif
#else /* SO_REL_1_2_INF */
#ifdef ANSI
PUBLIC S16 SoUiSotCIMCfm
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotCIMCfm (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
#endif /* SO_REL_1_2_INF */
{
   TRC3(SoUiSotCIMCfm)

#ifdef SO_REL_1_2_INF
   RETVALUE((*SoUiSotCIMCfmMt[pst->selector])(pst, suId, soEvnt));
#else
   RETVALUE((*SoUiSotCIMCfmMt[pst->selector])(pst, suId, suConnId,
                                               spConnId, soEvnt));
#endif /* SO_REL_1_2_INF */

} /* SoUiSotCIMCfm */

/*
 *
 *       Fun:   SoLiSotConInd
 *
 *       Desc:  This function resolves the SotConInd primitive
 *
 *       Ret:  ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotConInd
(
Pst         *pst,
SuId        suId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotConInd (pst, suId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(SoUiSotConInd)

   RETVALUE( (*SoUiSotConIndMt[pst->selector])(pst, suId, spConnId, soEvnt));

} /* SoUiSotConInd */

/*
 *
 *       Fun:   SoLiSotConCfm
 *
 *       Desc:  This function resolves the SotConCfm primitive
 *
 *       Ret:  ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotConCfm
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotConCfm (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(SoUiSotConCfm)

   RETVALUE((*SoUiSotConCfmMt[pst->selector])(pst, suId, suConnId, spConnId, soEvnt));

} /* SoUiSotConCfm */


/*
 *
 *       Fun:   SoUiSotCnStInd
 *
 *       Desc:  This function resolves the SotCnStInd primitive
 *
 *       Ret:   ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotCnStInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotCnStInd (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(SoUiSotCnStInd)

   RETVALUE((*SoUiSotCnStIndMt[pst->selector])(pst, suId, suConnId, spConnId, soEvnt));

} /* SoUiSotCnStInd */

/*
 *
 *       Fun:   SoUiSotRelCfm
 *
 *       Desc:  This function resolves the SotRelCfm primitive
 *
 *       Ret:  ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotRelCfm
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotRelCfm (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(SoUiSotRelCfm)

   RETVALUE( (*SoUiSotRelCfmMt[pst->selector])(pst, suId, suConnId, spConnId,  soEvnt));

} /* SoUiSotRelCfm */

/*
 *
 *       Fun:   SoUiSotRelInd
 *
 *       Desc:  This function resolves the SotRelInd primitive
 *
 *       Ret:  ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef SO_REL_1_2_INF
#ifdef ANSI
PUBLIC S16 SoUiSotRelInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
U8          relType,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotRelInd (pst, suId, suConnId, spConnId, relType, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
U8          relType;
SoEvnt      *soEvnt;
#endif
#else /*SO_REL_1_2_INF */
#ifdef ANSI
PUBLIC S16 SoUiSotRelInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotRelInd (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
#endif /* SO_REL_1_2_INF */
{
   TRC3(SoUiSotRelInd)

#ifdef SO_REL_1_2_INF
   RETVALUE( (*SoUiSotRelIndMt[pst->selector])(pst, suId, suConnId, spConnId,relType,
                                     soEvnt));
#else
   RETVALUE( (*SoUiSotRelIndMt[pst->selector])(pst, suId, suConnId, spConnId,
                                     soEvnt));
#endif /* SO_REL_1_2_INF */
   
} /* SoUiSotRelInd */

/*
 *
 *       Fun:   SoUiSotModInd
 *
 *       Desc:  This function resolves the SotModInd primitive
 *
 *       Ret:  ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotModInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotModInd (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(SoUiSotModInd)

   RETVALUE((*SoUiSotModIndMt[pst->selector])(pst, suId, suConnId, spConnId,  soEvnt));

} /* SoUiSotModInd */

/*
 *
 *       Fun:   SoUiSotModCfm
 *
 *       Desc:  This function resolves the SotModCfm primitive
 *
 *       Ret:  ROK -     ok
 *
 *       Notes: none
 *
         File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotModCfm
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotModCfm (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(SoUiSotModCfm)

   RETVALUE((*SoUiSotModCfmMt[pst->selector])(pst, suId, suConnId, spConnId,  soEvnt));

} /* SoUiSotModCfm */


/*
 *
 *       Fun:   SoUiSotCAMInd
 *
 *       Desc:  This function resolves the SotCAMInd primitive
 *
 *       Ret:  ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotCAMInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotCAMInd (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(SoUiSotCAMInd)

   RETVALUE((*SoUiSotCAMIndMt[pst->selector])(pst, suId, suConnId, spConnId,  soEvnt));

} /* SoUiSotModInd */

/*
 *
 *       Fun:   SoUiSotCAMCfm
 *
 *       Desc:  This function resolves the SotCAMCfm primitive
 *
 *       Ret:  ROK -     ok
 *
 *       Notes: none
 *
         File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotCAMCfm
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotCAMCfm (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(SoUiSotCAMCfm)

   RETVALUE((*SoUiSotCAMCfmMt[pst->selector])(pst, suId, suConnId, spConnId,  soEvnt));

} /* SoUiSotCAMCfm */

#ifndef SO_REL_1_2_INF
/*
 *
 *       Fun:   SoUiSotAckInd
 *
 *       Desc:  This function resolves the SotAckInd primitive
 *
 *       Ret:   ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotAckInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotAckInd (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(SoUiSotAckInd)

   RETVALUE((*SoUiSotAckIndMt[pst->selector])(pst, suId, suConnId, spConnId, soEvnt));

} /* SoUiSotAckInd */

/*
 *
 *       Fun:   SoUiSotCancelInd
 *
 *       Desc:  This function resolves the SotCancelInd primitive
 *
 *       Ret:   ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotCancelInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotCancelInd (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(SoUiSotCancelInd)

   RETVALUE((*SoUiSotCancelIndMt[pst->selector])(pst, suId, suConnId, spConnId, soEvnt));

} /* SoUiSotCancelInd */

/*
 *
 *       Fun:   SoUiSotErrInd
 *
 *       Desc:  This function resolves the SotErrInd primitive
 *
 *       Ret:  ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotErrInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *errEvnt
)
#else
PUBLIC S16 SoUiSotErrInd (pst, suId, suConnId, spConnId, errEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *errEvnt;
#endif
{
   TRC3(SoUiSotErrInd)

   RETVALUE( (*SoUiSotErrIndMt[pst->selector])(pst, suId, suConnId, spConnId,
                                      errEvnt));

} /* SoUiSotErrInd */

/*
 *
 *       Fun:   SoUiSotRefreshInd
 *
 *       Desc:  This function resolves the SotRefreshInd primitive
 *
 *       Ret:  ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotRefreshInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *refreshEvnt
)
#else
PUBLIC S16 SoUiSotRefreshInd (pst, suId, suConnId, spConnId, refreshEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *refreshEvnt;
#endif
{
   TRC3(SoUiSotRefreshInd)

   RETVALUE((*SoUiSotRefreshIndMt[pst->selector])(pst, suId, suConnId, spConnId,
                                     refreshEvnt));

} /* SoUiSotRefreshInd */

#ifdef SO_UA
/*
 *
 *       Fun:   SoUiSotAuditCfm
 *
 *       Desc:  This function resolves the SotAuditCfm primitive
 *
 *       Ret:   ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotAuditCfm
(
Pst         *pst,
SuId        suId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 SoUiSotAuditCfm (pst, suId, soEvnt)
Pst         *pst;
SuId        suId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(SoUiSotAuditCfm)

   RETVALUE((*SoUiSotAuditCfmMt[pst->selector])(pst,suId, soEvnt));

} /* SoUiSotAuditCfm */
#endif /* SO_UA */
#endif /* SO_REL_1_2_INF */

#ifdef SO_CALEA
/*
 *
 *       Fun:   SoUiSotRawMsg
 *
 *       Desc:  This function resolves the SotRawMsg primitive
 *
 *       Ret:  ROK -     ok
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 SoUiSotRawMsg
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
U32         transId,
U32         callLegId,
U32         messageId,
U8          eventType,
U8          sipMessageType,
Buffer      *mBuf
)
#else
PUBLIC S16 SoUiSotRawMsg (pst, suId, suConnId, spConnId, transId, callLegId,
                          messageId, eventType, sipMessageType, mBuf)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
U32         transId;
U32         callLegId;
U32         messageId;
U8          eventType;
U8          sipMessageType;
Buffer      *mBuf;
#endif
{
   TRC3(SoUiSotRawMsg)

   RETVALUE( (*SoUiSotRawMsgMt[pst->selector])(pst, suId, suConnId, spConnId,
                                               transId, callLegId, messageId,
                                               eventType, sipMessageType, mBuf));

} /* SoUiSotRawMsg */
#endif

#ifdef PTSOUISOT
/* Portable Stub Functions */

/*
 *
 *       Fun:   PtUiSotBndCfm
 *
 *       Desc:  Portable version of SotBndCfm primitive
 *
 *       Ret:  RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotBndCfm
(
Pst  *pst,
SuId suId,
U8   status
)
#else
PUBLIC S16 PtUiSotBndCfm (pst, suId, status)
Pst   *pst;
SuId  suId;
U8    status;
#endif
{
   TRC3(PtUiSotBndCfm)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(status);

   RETVALUE(RFAILED);
} /* PtUiSotBndCfm */

/*
 *
 *       Fun:   PtUiSotCIMInd
 *
 *       Desc:  Portable version of SotCIMInd primitive
 *
 *       Ret:  RFAILED - failed
 *
 *       Notes: none
 *
         File:  so_ptui.c
 *
 */
#ifdef SO_REL_1_2_INF
#ifdef ANSI
PUBLIC S16 PtUiSotCIMInd
(
Pst           *pst,         /* post structure */
SuId          suId,         /* service user SAP identifier */
SoEvnt        *evnt         /* SIP messages event structure */
)
#else
PUBLIC S16 PtUiSotCIMInd (pst, suId, evnt)
Pst           *pst;         /* post structure */
SuId          suId;         /* service user SAP identifier */
SoEvnt        *evnt;        /* SIP messages event structure */
#endif
#else /* SO_REL_1_2_INF */
#ifdef ANSI
PUBLIC S16 PtUiSotCIMInd
(
Pst           *pst,         /* post structure */
SuId          suId,         /* service user SAP identifier */
UConnId       suConnId,     /* SU connId */
UConnId       spConnId,     /* SP connId */
SoEvnt        *evnt         /* SIP messages event structure */
)
#else
PUBLIC S16 PtUiSotCIMInd (pst, suId, suConnId, spConnId, evnt)
Pst           *pst;         /* post structure */
SuId          suId;         /* service user SAP identifier */
UConnId       suConnId;     /* SU connId */
UConnId       spConnId;     /* SP connId */
SoEvnt        *evnt;        /* SIP messages event structure */
#endif
#endif /* SO_REL_1_2_INF */
{
   TRC3(PtUiSotCIMInd)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
#ifndef SO_REL_1_2_INF
   UNUSED(suConnId);
   UNUSED(spConnId);
#endif   
   UNUSED(evnt);

   RETVALUE(RFAILED);
} /* PtUiSotCIMInd */

/*
 *
 *       Fun:   PtUiSotCIMCfm
 *
 *       Desc:  Portable version of SotCIMCfm primitive
 *
 *       Ret:  RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef SO_REL_1_2_INF
#ifdef ANSI
PUBLIC S16 PtUiSotCIMCfm
(
Pst           *pst,         /* post structure */
SuId          suId,         /* service user SAP identifier */
SoEvnt        *evnt         /* SIP messages event structure */
)
#else
PUBLIC S16 PtUiSotCIMCfm (pst, suId, evnt)
Pst           *pst;         /* post structure */
SuId          suId;         /* service user SAP identifier */
SoEvnt        *evnt;        /* SIP messages event structure */
#endif
#else /* SO_REL_1_2_INF */
#ifdef ANSI
PUBLIC S16 PtUiSotCIMCfm
(
Pst           *pst,         /* post structure */
SuId          suId,         /* service user SAP identifier */
UConnId       suConnId,     /* SU connId */
UConnId       spConnId,     /* SP connId */
SoEvnt        *evnt         /* SIP messages event structure */
)
#else
PUBLIC S16 PtUiSotCIMCfm (pst, suId, suConnId, spConnId, evnt)
Pst           *pst;         /* post structure */
SuId          suId;         /* service user SAP identifier */
UConnId       suConnId;     /* SU connId */
UConnId       spConnId;     /* SP connId */
SoEvnt        *evnt;        /* SIP messages event structure */
#endif
#endif /* SO_REL_1_2_INF */
{
   TRC3(PtUiSotCIMCfm)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
#ifndef SO_REL_1_2_INF
   UNUSED(suConnId);
   UNUSED(spConnId);
#endif   
   UNUSED(evnt);

   RETVALUE(RFAILED);
} /* PtUiSotCIMCfm */

/*
 *
 *       Fun:   PtUiSotConInd
 *
 *       Desc:  Portable version of SotConInd primitive
 *
 *       Ret:  RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotConInd
(
Pst         *pst,
SuId        suId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 PtUiSotConInd (pst, suId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(PtUiSotConInd)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(spConnId);
   UNUSED(soEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotConInd */

/*
 *
 *       Fun:   PtUiSotConCfm
 *
 *       Desc:  Portable version of SotConCfm primitive
 *
 *       Ret:  RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotConCfm
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 PtUiSotConCfm (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(PtUiSotConCfm)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(spConnId);
   UNUSED(soEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotConCfm */


/*
 *
 *       Fun:   PtUiSotCnStInd
 *
 *       Desc:  Portable version of SotCnStInd primitive
 *
 *       Ret:   RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotCnStInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 PtUiSotCnStInd (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(PtUiSotCnStInd)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(spConnId);
   UNUSED(soEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotCnStInd */

/*
 *
 *       Fun:   PtUiSotRelCfm
 *
 *       Desc:  Portable version of SotRelCfm primitive
 *
 *       Ret:  RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotRelCfm
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 PtUiSotRelCfm (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(PtUiSotRelCfm)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(spConnId);
   UNUSED(soEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotRelCfm */


/*
 *
 *       Fun:   PtUiSotRelInd
 *
 *       Desc:  Portable version of SotRelInd primitive
 *
 *       Ret:  RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef SO_REL_1_2_INF
#ifdef ANSI
PUBLIC S16 PtUiSotRelInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
U8          relType,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 PtUiSotRelInd (pst, suId, suConnId, spConnId, relType, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
U8          relType;
SoEvnt      *soEvnt;
#endif
#else /* SO_REL_1_2_INF */
#ifdef ANSI
PUBLIC S16 PtUiSotRelInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 PtUiSotRelInd (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
#endif /* SO_REL_1_2_INF */
{
   TRC3(PtUiSotRelInd)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(spConnId);
#ifdef SO_REL_1_2_INF   
   UNUSED(relType);
#endif   
   UNUSED(soEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotRelInd */

/*
 *
 *       Fun:   PtUiSotModInd
 *
 *       Desc:  Portable version of SotModInd primitive
 *
 *       Ret:  RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotModInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 PtUiSotModInd (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(PtUiSotModInd)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(spConnId);
   UNUSED(soEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotModInd */

/*
 *
 *       Fun:   PtUiSotModCfm
 *
 *       Desc:  Portable version of SotModCfm primitive
 *
 *       Ret:  RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotModCfm
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 PtUiSotModCfm (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(PtUiSotModCfm)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(spConnId);
   UNUSED(soEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotModCfm */


/*
 *
 *       Fun:   PtUiSotCAMInd
 *
 *       Desc:  Portable version of SotCAMInd primitive
 *
 *       Ret:  RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotCAMInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 PtUiSotCAMInd (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(PtUiSotCAMInd)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(spConnId);
   UNUSED(soEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotCAMInd */

/*
 *
 *       Fun:   PtUiSotCAMCfm
 *
 *       Desc:  Portable version of SotModCfm primitive
 *
 *       Ret:  RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotCAMCfm
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 PtUiSotCAMCfm (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(PtUiSotCAMCfm)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(spConnId);
   UNUSED(soEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotCAMCfm */

#ifndef SO_REL_1_2_INF
/*
 *
 *       Fun:   PtUiSotAckInd
 *
 *       Desc:  Portable version of SotAckInd primitive
 *
 *       Ret:   RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotAckInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 PtUiSotAckInd (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(PtUiSotAckInd)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(spConnId);
   UNUSED(soEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotAckInd */

/*
 *
 *       Fun:   PtUiSotCancelInd
 *
 *       Desc:  Portable version of SotCancelInd primitive
 *
 *       Ret:   RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotCancelInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 PtUiSotCancelInd (pst, suId, suConnId, spConnId, soEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(PtUiSotCancelInd)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(spConnId);
   UNUSED(soEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotCancelInd */

/*
 *
 *       Fun:   PtUiSotErrInd
 *
 *       Desc:  Portable version of SotErrInd primitive
 *
 *       Ret:   RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotErrInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *errEvnt
)
#else
PUBLIC S16 PtUiSotErrInd (pst, suId, suConnId, spConnId, errEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *errEvnt;
#endif
{
   TRC3(PtUiSotErrInd)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(spConnId);
   UNUSED(errEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotErrInd */

/*
 *
 *       Fun:   PtUiSotRefreshInd
 *
 *       Desc:  Portable version of SotRefreshInd primitive
 *
 *       Ret:   RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotRefreshInd
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
SoEvnt      *refreshEvnt
)
#else
PUBLIC S16 PtUiSotRefreshInd (pst, suId, suConnId, spConnId, refreshEvnt)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
SoEvnt      *refreshEvnt;
#endif
{
   TRC3(PtUiSotRefreshInd)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(spConnId);
   UNUSED(refreshEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotRefreshInd */

#ifdef SO_UA
/*
 *
 *       Fun:   PtUiSotAuditCfm
 *
 *       Desc:  Portable version of SotAuditCfm primitive
 *
 *       Ret:   RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotAuditCfm
(
Pst         *pst,
SuId        suId,
SoEvnt      *soEvnt
)
#else
PUBLIC S16 PtUiSotAuditCfm (pst,suId, soEvnt)
Pst         *pst;
SuId        suId;
SoEvnt      *soEvnt;
#endif
{
   TRC3(PtUiSotAuditCfm)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(soEvnt);

   RETVALUE(RFAILED);
} /* PtUiSotAuditCfm */
#endif /* SO_UA */
#endif /* SO_REL_1_2_INF */

/*
 *
 *       Fun:   PtUiSotRawMsg
 *
 *       Desc:  Portable version of SotRawMsg primitive
 *
 *       Ret:  RFAILED - failed
 *
 *       Notes: none
 *
 *       File:  so_ptui.c
 *
 */
#ifdef ANSI
PUBLIC S16 PtUiSotRawMsg
(
Pst         *pst,
SuId        suId,
UConnId     suConnId,
UConnId     spConnId,
U32         transId,
U32         callLegId,
U32         messageId,
U8          eventType,
U8          sipMessageType,
Buffer      *mBuf
)
#else
PUBLIC S16 PtUiSotRawMsg (pst, suId, suConnId, spConnId, transId, callLegId,
                          messageId, eventType, sipMessageType, mBuf)
Pst         *pst;
SuId        suId;
UConnId     suConnId;
UConnId     spConnId;
U32         transId;
U32         callLegId;
U32         messageId;
U8          eventType;
U8          sipMessageType;
Buffer      *mBuf;
#endif
{
   TRC3(PtUiSotRawMsg)

   SOLOGINVSEL;
   UNUSED(pst);
   UNUSED(suId);
   UNUSED(suConnId);
   UNUSED(spConnId);
   UNUSED(transId);
   UNUSED(callLegId);
   UNUSED(messageId);
   UNUSED(eventType);
   UNUSED(sipMessageType);
   UNUSED(mBuf);

   RETVALUE(RFAILED);
} /* PtUiSotRawMsg */




#endif /* PTSOUISOT */

/********************************************************************30**

         End of file:     so_ptui.c@@/main/4 - Tue Apr 20 12:46:58 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---     ms   1. initial release.
/main/4+    so036.201 ng    1. Changes for SO_CALEA
*********************************************************************91*/
