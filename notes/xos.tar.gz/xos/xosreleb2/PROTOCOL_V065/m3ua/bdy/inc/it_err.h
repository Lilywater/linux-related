/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     M3UA Layer error file.

     Type:     C include file

     Desc:     Error Hash Defines required by M3UA layer

     File:     it_err.h

     Sid:      it_err.h@@/main/7 - Thu Apr  1 03:52:14 2004

     Prg:      pn

*********************************************************************21*/

#ifndef __ITERRH__
#define __ITERRH__


#define ITLOGERROR(errCls, errCode, errVal, errDesc)                    \
        SLogError(itGlobalCb.itInit.ent, itGlobalCb.itInit.inst,        \
                  itGlobalCb.itInit.procId,                             \
                  __FILE__, __LINE__, (ErrCls)errCls, (ErrCode)errCode, \
                  (ErrVal)errVal, errDesc)

/* logging error if prntBuf is well-defined */
#define ITLOGERR(errcls)       ITLOGERROR((errcls), EIT408, ERRZERO, prntBuf)

#if (ERRCLASS & ERRCLS_DEBUG)
/* logging invalid selector in portable primitive stubs */
#define ITLOGINVSEL                                                           \
   {                                                                          \
      sprintf(prntBuf, "Invalid selector\n");                                 \
      ITLOGERR(ERRCLS_DEBUG);                                                 \
   }
#else
#define ITLOGINVSEL
#endif /* (ERRCLASS & ERRCLS_DEBUG) */


#define   EITBASE     0
#define   EITXXX      (EITBASE   +0)    /* reserved */
#define   ERRIT       (EITBASE   +0)    /* reserved */

#define   EIT001      (ERRIT +    1)    /*         it.h: 909 */
#define   EIT002      (ERRIT +    2)    /*         it.h: 911 */
#define   EIT003      (ERRIT +    3)    /*         it.h: 913 */
#define   EIT004      (ERRIT +    4)    /*         it.h:1104 */

#define   EIT005      (ERRIT +    5)    /*    it_bdy1.c: 322 */
#define   EIT006      (ERRIT +    6)    /*    it_bdy1.c: 345 */
#define   EIT007      (ERRIT +    7)    /*    it_bdy1.c: 363 */
#define   EIT008      (ERRIT +    8)    /*    it_bdy1.c: 377 */
#define   EIT009      (ERRIT +    9)    /*    it_bdy1.c: 401 */
#define   EIT010      (ERRIT +   10)    /*    it_bdy1.c: 496 */
#define   EIT011      (ERRIT +   11)    /*    it_bdy1.c: 533 */
#define   EIT012      (ERRIT +   12)    /*    it_bdy1.c: 568 */
#define   EIT013      (ERRIT +   13)    /*    it_bdy1.c: 590 */
#define   EIT014      (ERRIT +   14)    /*    it_bdy1.c: 608 */
#define   EIT015      (ERRIT +   15)    /*    it_bdy1.c: 623 */
#define   EIT016      (ERRIT +   16)    /*    it_bdy1.c: 638 */
#define   EIT017      (ERRIT +   17)    /*    it_bdy1.c: 659 */
#define   EIT018      (ERRIT +   18)    /*    it_bdy1.c: 679 */
#define   EIT019      (ERRIT +   19)    /*    it_bdy1.c: 699 */
#define   EIT020      (ERRIT +   20)    /*    it_bdy1.c: 719 */
#define   EIT021      (ERRIT +   21)    /*    it_bdy1.c: 753 */
#define   EIT022      (ERRIT +   22)    /*    it_bdy1.c: 782 */
#define   EIT023      (ERRIT +   23)    /*    it_bdy1.c: 811 */
#define   EIT024      (ERRIT +   24)    /*    it_bdy1.c: 838 */
#define   EIT025      (ERRIT +   25)    /*    it_bdy1.c: 865 */
#define   EIT026      (ERRIT +   26)    /*    it_bdy1.c: 892 */
#define   EIT027      (ERRIT +   27)    /*    it_bdy1.c: 926 */
#define   EIT028      (ERRIT +   28)    /*    it_bdy1.c: 945 */
#define   EIT029      (ERRIT +   29)    /*    it_bdy1.c: 966 */
#define   EIT030      (ERRIT +   30)    /*    it_bdy1.c: 984 */
#define   EIT031      (ERRIT +   31)    /*    it_bdy1.c:1005 */
#define   EIT032      (ERRIT +   32)    /*    it_bdy1.c:1021 */
#define   EIT033      (ERRIT +   33)    /*    it_bdy1.c:1040 */
#define   EIT034      (ERRIT +   34)    /*    it_bdy1.c:1057 */
#define   EIT035      (ERRIT +   35)    /*    it_bdy1.c:1136 */
#define   EIT036      (ERRIT +   36)    /*    it_bdy1.c:1158 */
#define   EIT037      (ERRIT +   37)    /*    it_bdy1.c:1173 */
#define   EIT038      (ERRIT +   38)    /*    it_bdy1.c:1254 */
#define   EIT039      (ERRIT +   39)    /*    it_bdy1.c:1313 */
#define   EIT040      (ERRIT +   40)    /*    it_bdy1.c:1322 */
#define   EIT041      (ERRIT +   41)    /*    it_bdy1.c:1398 */
#define   EIT042      (ERRIT +   42)    /*    it_bdy1.c:1416 */
#define   EIT043      (ERRIT +   43)    /*    it_bdy1.c:1440 */
#define   EIT044      (ERRIT +   44)    /*    it_bdy1.c:1454 */
#define   EIT045      (ERRIT +   45)    /*    it_bdy1.c:1643 */
#define   EIT046      (ERRIT +   46)    /*    it_bdy1.c:1745 */
#define   EIT047      (ERRIT +   47)    /*    it_bdy1.c:1839 */
#define   EIT048      (ERRIT +   48)    /*    it_bdy1.c:1869 */
#define   EIT049      (ERRIT +   49)    /*    it_bdy1.c:1884 */
#define   EIT050      (ERRIT +   50)    /*    it_bdy1.c:1910 */
#define   EIT051      (ERRIT +   51)    /*    it_bdy1.c:1924 */
#define   EIT052      (ERRIT +   52)    /*    it_bdy1.c:1962 */
#define   EIT053      (ERRIT +   53)    /*    it_bdy1.c:1979 */
#define   EIT054      (ERRIT +   54)    /*    it_bdy1.c:1994 */
#define   EIT055      (ERRIT +   55)    /*    it_bdy1.c:2016 */
#define   EIT056      (ERRIT +   56)    /*    it_bdy1.c:2031 */
#define   EIT057      (ERRIT +   57)    /*    it_bdy1.c:2040 */
#define   EIT058      (ERRIT +   58)    /*    it_bdy1.c:2131 */
#define   EIT059      (ERRIT +   59)    /*    it_bdy1.c:2209 */
#define   EIT060      (ERRIT +   60)    /*    it_bdy1.c:2240 */
#define   EIT061      (ERRIT +   61)    /*    it_bdy1.c:2254 */
#define   EIT062      (ERRIT +   62)    /*    it_bdy1.c:2285 */
#define   EIT063      (ERRIT +   63)    /*    it_bdy1.c:2300 */
#define   EIT064      (ERRIT +   64)    /*    it_bdy1.c:2330 */
#define   EIT065      (ERRIT +   65)    /*    it_bdy1.c:2346 */
#define   EIT066      (ERRIT +   66)    /*    it_bdy1.c:2370 */
#define   EIT067      (ERRIT +   67)    /*    it_bdy1.c:2453 */
#define   EIT068      (ERRIT +   68)    /*    it_bdy1.c:2462 */
#define   EIT069      (ERRIT +   69)    /*    it_bdy1.c:2478 */
#define   EIT070      (ERRIT +   70)    /*    it_bdy1.c:2488 */
#define   EIT071      (ERRIT +   71)    /*    it_bdy1.c:2713 */
#define   EIT072      (ERRIT +   72)    /*    it_bdy1.c:2723 */
#define   EIT073      (ERRIT +   73)    /*    it_bdy1.c:2746 */
#define   EIT074      (ERRIT +   74)    /*    it_bdy1.c:2762 */
#define   EIT075      (ERRIT +   75)    /*    it_bdy1.c:2780 */
#define   EIT076      (ERRIT +   76)    /*    it_bdy1.c:2795 */
#define   EIT077      (ERRIT +   77)    /*    it_bdy1.c:2810 */
#define   EIT078      (ERRIT +   78)    /*    it_bdy1.c:2832 */
#define   EIT079      (ERRIT +   79)    /*    it_bdy1.c:2849 */
#define   EIT080      (ERRIT +   80)    /*    it_bdy1.c:2941 */
#define   EIT081      (ERRIT +   81)    /*    it_bdy1.c:2949 */
#define   EIT082      (ERRIT +   82)    /*    it_bdy1.c:2964 */
#define   EIT083      (ERRIT +   83)    /*    it_bdy1.c:3042 */
#define   EIT084      (ERRIT +   84)    /*    it_bdy1.c:3050 */
#define   EIT085      (ERRIT +   85)    /*    it_bdy1.c:3065 */
#define   EIT086      (ERRIT +   86)    /*    it_bdy1.c:3149 */
#define   EIT087      (ERRIT +   87)    /*    it_bdy1.c:3157 */
#define   EIT088      (ERRIT +   88)    /*    it_bdy1.c:3173 */
#define   EIT089      (ERRIT +   89)    /*    it_bdy1.c:3187 */
#define   EIT090      (ERRIT +   90)    /*    it_bdy1.c:3273 */
#define   EIT091      (ERRIT +   91)    /*    it_bdy1.c:3281 */
#define   EIT092      (ERRIT +   92)    /*    it_bdy1.c:3296 */
#define   EIT093      (ERRIT +   93)    /*    it_bdy1.c:3306 */
#define   EIT094      (ERRIT +   94)    /*    it_bdy1.c:3385 */
#define   EIT095      (ERRIT +   95)    /*    it_bdy1.c:3393 */
#define   EIT096      (ERRIT +   96)    /*    it_bdy1.c:3407 */
#define   EIT097      (ERRIT +   97)    /*    it_bdy1.c:3435 */
#define   EIT098      (ERRIT +   98)    /*    it_bdy1.c:3451 */
#define   EIT099      (ERRIT +   99)    /*    it_bdy1.c:3521 */
#define   EIT100      (ERRIT +  100)    /*    it_bdy1.c:3529 */
#define   EIT101      (ERRIT +  101)    /*    it_bdy1.c:3538 */
#define   EIT102      (ERRIT +  102)    /*    it_bdy1.c:3556 */
#define   EIT103      (ERRIT +  103)    /*    it_bdy1.c:3594 */
#define   EIT104      (ERRIT +  104)    /*    it_bdy1.c:3666 */
#define   EIT105      (ERRIT +  105)    /*    it_bdy1.c:3674 */
#define   EIT106      (ERRIT +  106)    /*    it_bdy1.c:3683 */
#define   EIT107      (ERRIT +  107)    /*    it_bdy1.c:3702 */
#define   EIT108      (ERRIT +  108)    /*    it_bdy1.c:3769 */
#define   EIT109      (ERRIT +  109)    /*    it_bdy1.c:3777 */
#define   EIT110      (ERRIT +  110)    /*    it_bdy1.c:3786 */
#define   EIT111      (ERRIT +  111)    /*    it_bdy1.c:3795 */
#define   EIT112      (ERRIT +  112)    /*    it_bdy1.c:3804 */
#define   EIT113      (ERRIT +  113)    /*    it_bdy1.c:3887 */
#define   EIT114      (ERRIT +  114)    /*    it_bdy1.c:3895 */
#define   EIT115      (ERRIT +  115)    /*    it_bdy1.c:3904 */
#define   EIT116      (ERRIT +  116)    /*    it_bdy1.c:3913 */
#define   EIT117      (ERRIT +  117)    /*    it_bdy1.c:3922 */
#define   EIT118      (ERRIT +  118)    /*    it_bdy1.c:3931 */
#define   EIT119      (ERRIT +  119)    /*    it_bdy1.c:4016 */
#define   EIT120      (ERRIT +  120)    /*    it_bdy1.c:4024 */
#define   EIT121      (ERRIT +  121)    /*    it_bdy1.c:4033 */
#define   EIT122      (ERRIT +  122)    /*    it_bdy1.c:4042 */
#define   EIT123      (ERRIT +  123)    /*    it_bdy1.c:4063 */
#define   EIT124      (ERRIT +  124)    /*    it_bdy1.c:4090 */
#define   EIT125      (ERRIT +  125)    /*    it_bdy1.c:4103 */
#define   EIT126      (ERRIT +  126)    /*    it_bdy1.c:4116 */
#define   EIT127      (ERRIT +  127)    /*    it_bdy1.c:4184 */
#define   EIT128      (ERRIT +  128)    /*    it_bdy1.c:4192 */
#define   EIT129      (ERRIT +  129)    /*    it_bdy1.c:4201 */
#define   EIT130      (ERRIT +  130)    /*    it_bdy1.c:4210 */
#define   EIT131      (ERRIT +  131)    /*    it_bdy1.c:4219 */
#define   EIT132      (ERRIT +  132)    /*    it_bdy1.c:4235 */
#define   EIT133      (ERRIT +  133)    /*    it_bdy1.c:4311 */
#define   EIT134      (ERRIT +  134)    /*    it_bdy1.c:4320 */
#define   EIT135      (ERRIT +  135)    /*    it_bdy1.c:4330 */
#define   EIT136      (ERRIT +  136)    /*    it_bdy1.c:4340 */
#define   EIT137      (ERRIT +  137)    /*    it_bdy1.c:4350 */
#define   EIT138      (ERRIT +  138)    /*    it_bdy1.c:4360 */
#define   EIT139      (ERRIT +  139)    /*    it_bdy1.c:4370 */
#define   EIT140      (ERRIT +  140)    /*    it_bdy1.c:4387 */
#define   EIT141      (ERRIT +  141)    /*    it_bdy1.c:4400 */
#define   EIT142      (ERRIT +  142)    /*    it_bdy1.c:4489 */
#define   EIT143      (ERRIT +  143)    /*    it_bdy1.c:4497 */
#define   EIT144      (ERRIT +  144)    /*    it_bdy1.c:4506 */
#define   EIT145      (ERRIT +  145)    /*    it_bdy1.c:4515 */
#define   EIT146      (ERRIT +  146)    /*    it_bdy1.c:4524 */
#define   EIT147      (ERRIT +  147)    /*    it_bdy1.c:4603 */
#define   EIT148      (ERRIT +  148)    /*    it_bdy1.c:4611 */
#define   EIT149      (ERRIT +  149)    /*    it_bdy1.c:4621 */
#define   EIT150      (ERRIT +  150)    /*    it_bdy1.c:4631 */
#define   EIT151      (ERRIT +  151)    /*    it_bdy1.c:4641 */
#define   EIT152      (ERRIT +  152)    /*    it_bdy1.c:4651 */
#define   EIT153      (ERRIT +  153)    /*    it_bdy1.c:4722 */
#define   EIT154      (ERRIT +  154)    /*    it_bdy1.c:4730 */
#define   EIT155      (ERRIT +  155)    /*    it_bdy1.c:4739 */
#define   EIT156      (ERRIT +  156)    /*    it_bdy1.c:4748 */
#define   EIT157      (ERRIT +  157)    /*    it_bdy1.c:4757 */
#define   EIT158      (ERRIT +  158)    /*    it_bdy1.c:4766 */
#define   EIT159      (ERRIT +  159)    /*    it_bdy1.c:4932 */
#define   EIT160      (ERRIT +  160)    /*    it_bdy1.c:4940 */
#define   EIT161      (ERRIT +  161)    /*    it_bdy1.c:4954 */
#define   EIT162      (ERRIT +  162)    /*    it_bdy1.c:4982 */
#define   EIT163      (ERRIT +  163)    /*    it_bdy1.c:4996 */
#define   EIT164      (ERRIT +  164)    /*    it_bdy1.c:5128 */
#define   EIT165      (ERRIT +  165)    /*    it_bdy1.c:5691 */
#define   EIT166      (ERRIT +  166)    /*    it_bdy1.c:5703 */

#define   EIT167      (ERRIT +  167)    /*    it_bdy2.c: 296 */
#define   EIT168      (ERRIT +  168)    /*    it_bdy2.c: 307 */
#define   EIT169      (ERRIT +  169)    /*    it_bdy2.c: 682 */
#define   EIT170      (ERRIT +  170)    /*    it_bdy2.c: 693 */
#define   EIT171      (ERRIT +  171)    /*    it_bdy2.c: 705 */
#define   EIT172      (ERRIT +  172)    /*    it_bdy2.c: 721 */
#define   EIT173      (ERRIT +  173)    /*    it_bdy2.c: 790 */
#define   EIT174      (ERRIT +  174)    /*    it_bdy2.c: 804 */
#define   EIT175      (ERRIT +  175)    /*    it_bdy2.c: 823 */
#define   EIT176      (ERRIT +  176)    /*    it_bdy2.c:4320 */
#define   EIT177      (ERRIT +  177)    /*    it_bdy2.c:4835 */
#define   EIT178      (ERRIT +  178)    /*    it_bdy2.c:5344 */
#define   EIT179      (ERRIT +  179)    /*    it_bdy2.c:5491 */
#define   EIT180      (ERRIT +  180)    /*    it_bdy2.c:7114 */
#define   EIT181      (ERRIT +  181)    /*    it_bdy2.c:7116 */
#define   EIT182      (ERRIT +  182)    /*    it_bdy2.c:7118 */
#define   EIT183      (ERRIT +  183)    /*    it_bdy2.c:7123 */
#define   EIT184      (ERRIT +  184)    /*    it_bdy2.c:7173 */
#define   EIT185      (ERRIT +  185)    /*    it_bdy2.c:7240 */
#define   EIT186      (ERRIT +  186)    /*    it_bdy2.c:7418 */
#define   EIT187      (ERRIT +  187)    /*    it_bdy2.c:7431 */
#define   EIT188      (ERRIT +  188)    /*    it_bdy2.c:7434 */
#define   EIT189      (ERRIT +  189)    /*    it_bdy2.c:7437 */
#define   EIT190      (ERRIT +  190)    /*    it_bdy2.c:7688 */
#define   EIT191      (ERRIT +  191)    /*    it_bdy2.c:7690 */
#define   EIT192      (ERRIT +  192)    /*    it_bdy2.c:7789 */
#define   EIT193      (ERRIT +  193)    /*    it_bdy2.c:7907 */
#define   EIT194      (ERRIT +  194)    /*    it_bdy2.c:7921 */
#define   EIT195      (ERRIT +  195)    /*    it_bdy2.c:7923 */
#define   EIT196      (ERRIT +  196)    /*    it_bdy2.c:7941 */
#define   EIT197      (ERRIT +  197)    /*    it_bdy2.c:7986 */
#define   EIT198      (ERRIT +  198)    /*    it_bdy2.c:8011 */
#define   EIT199      (ERRIT +  199)    /*    it_bdy2.c:8013 */
#define   EIT200      (ERRIT +  200)    /*    it_bdy2.c:8080 */
#define   EIT201      (ERRIT +  201)    /*    it_bdy2.c:8137 */
#define   EIT202      (ERRIT +  202)    /*    it_bdy2.c:8279 */
#define   EIT203      (ERRIT +  203)    /*    it_bdy2.c:8404 */
#define   EIT204      (ERRIT +  204)    /*    it_bdy2.c:8411 */
#define   EIT205      (ERRIT +  205)    /*    it_bdy2.c:8544 */
#define   EIT206      (ERRIT +  206)    /*    it_bdy2.c:8547 */
#define   EIT207      (ERRIT +  207)    /*    it_bdy2.c:8586 */
#define   EIT208      (ERRIT +  208)    /*    it_bdy2.c:8886 */
#define   EIT209      (ERRIT +  209)    /*    it_bdy2.c:8888 */
#define   EIT210      (ERRIT +  210)    /*    it_bdy2.c:8890 */
#define   EIT211      (ERRIT +  211)    /*    it_bdy2.c:8892 */
#define   EIT212      (ERRIT +  212)    /*    it_bdy2.c:8928 */
#define   EIT213      (ERRIT +  213)    /*    it_bdy2.c:8931 */
#define   EIT214      (ERRIT +  214)    /*    it_bdy2.c:8935 */
#define   EIT215      (ERRIT +  215)    /*    it_bdy2.c:8948 */
#define   EIT216      (ERRIT +  216)    /*    it_bdy2.c:8950 */
#define   EIT217      (ERRIT +  217)    /*    it_bdy2.c:8952 */
#define   EIT218      (ERRIT +  218)    /*    it_bdy2.c:8954 */
#define   EIT219      (ERRIT +  219)    /*    it_bdy2.c:8956 */
#define   EIT220      (ERRIT +  220)    /*    it_bdy2.c:8963 */
#define   EIT221      (ERRIT +  221)    /*    it_bdy2.c:8965 */
#define   EIT222      (ERRIT +  222)    /*    it_bdy2.c:8967 */
#define   EIT223      (ERRIT +  223)    /*    it_bdy2.c:8969 */
#define   EIT224      (ERRIT +  224)    /*    it_bdy2.c:9037 */
#define   EIT225      (ERRIT +  225)    /*    it_bdy2.c:9039 */
#define   EIT226      (ERRIT +  226)    /*    it_bdy2.c:9041 */
#define   EIT227      (ERRIT +  227)    /*    it_bdy2.c:9209 */
#define   EIT228      (ERRIT +  228)    /*    it_bdy2.c:9211 */
#define   EIT229      (ERRIT +  229)    /*    it_bdy2.c:9213 */
#define   EIT230      (ERRIT +  230)    /*    it_bdy2.c:9217 */
#define   EIT231      (ERRIT +  231)    /*    it_bdy2.c:9219 */
#define   EIT232      (ERRIT +  232)    /*    it_bdy2.c:9227 */
#define   EIT233      (ERRIT +  233)    /*    it_bdy2.c:9316 */
#define   EIT234      (ERRIT +  234)    /*    it_bdy2.c:9318 */
#define   EIT235      (ERRIT +  235)    /*    it_bdy2.c:9326 */
#define   EIT236      (ERRIT +  236)    /*    it_bdy2.c:9419 */
#define   EIT237      (ERRIT +  237)    /*    it_bdy2.c:9421 */
#define   EIT238      (ERRIT +  238)    /*    it_bdy2.c:9423 */
#define   EIT239      (ERRIT +  239)    /*    it_bdy2.c:9425 */
#define   EIT240      (ERRIT +  240)    /*    it_bdy2.c:9430 */
#define   EIT241      (ERRIT +  241)    /*    it_bdy2.c:9432 */
#define   EIT242      (ERRIT +  242)    /*    it_bdy2.c:9435 */
#define   EIT243      (ERRIT +  243)    /*    it_bdy2.c:9440 */
#define   EIT244      (ERRIT +  244)    /*    it_bdy2.c:9442 */
#define   EIT245      (ERRIT +  245)    /*    it_bdy2.c:9450 */
#define   EIT246      (ERRIT +  246)    /*    it_bdy2.c:9548 */
#define   EIT247      (ERRIT +  247)    /*    it_bdy2.c:9571 */
#define   EIT248      (ERRIT +  248)    /*    it_bdy2.c:9573 */
#define   EIT249      (ERRIT +  249)    /*    it_bdy2.c:9575 */
#define   EIT250      (ERRIT +  250)    /*    it_bdy2.c:9578 */
#define   EIT251      (ERRIT +  251)    /*    it_bdy2.c:9580 */
#define   EIT252      (ERRIT +  252)    /*    it_bdy2.c:9582 */
#define   EIT253      (ERRIT +  253)    /*    it_bdy2.c:9587 */
#define   EIT254      (ERRIT +  254)    /*    it_bdy2.c:9589 */
#define   EIT255      (ERRIT +  255)    /*    it_bdy2.c:9594 */
#define   EIT256      (ERRIT +  256)    /*    it_bdy2.c:9605 */
#define   EIT257      (ERRIT +  257)    /*    it_bdy2.c:9607 */
#define   EIT258      (ERRIT +  258)    /*    it_bdy2.c:9609 */
#define   EIT259      (ERRIT +  259)    /*    it_bdy2.c:9636 */
#define   EIT260      (ERRIT +  260)    /*    it_bdy2.c:9638 */
#define   EIT261      (ERRIT +  261)    /*    it_bdy2.c:9642 */
#define   EIT262      (ERRIT +  262)    /*    it_bdy2.c:9644 */
#define   EIT263      (ERRIT +  263)    /*    it_bdy2.c:9652 */
#define   EIT264      (ERRIT +  264)    /*    it_bdy2.c:9935 */
#define   EIT265      (ERRIT +  265)    /*    it_bdy2.c:9939 */
#define   EIT266      (ERRIT +  266)    /*    it_bdy2.c:9946 */
#define   EIT267      (ERRIT +  267)    /*    it_bdy2.c:10008 */
#define   EIT268      (ERRIT +  268)    /*    it_bdy2.c:10011 */
#define   EIT269      (ERRIT +  269)    /*    it_bdy2.c:10015 */
#define   EIT270      (ERRIT +  270)    /*    it_bdy2.c:10017 */
#define   EIT271      (ERRIT +  271)    /*    it_bdy2.c:10019 */
#define   EIT272      (ERRIT +  272)    /*    it_bdy2.c:10022 */
#define   EIT273      (ERRIT +  273)    /*    it_bdy2.c:10024 */
#define   EIT274      (ERRIT +  274)    /*    it_bdy2.c:10026 */
#define   EIT275      (ERRIT +  275)    /*    it_bdy2.c:10088 */
#define   EIT276      (ERRIT +  276)    /*    it_bdy2.c:10090 */
#define   EIT277      (ERRIT +  277)    /*    it_bdy2.c:10093 */
#define   EIT278      (ERRIT +  278)    /*    it_bdy2.c:10095 */
#define   EIT279      (ERRIT +  279)    /*    it_bdy2.c:10097 */
#define   EIT280      (ERRIT +  280)    /*    it_bdy2.c:10100 */
#define   EIT281      (ERRIT +  281)    /*    it_bdy2.c:10102 */
#define   EIT282      (ERRIT +  282)    /*    it_bdy2.c:10104 */
#define   EIT283      (ERRIT +  283)    /*    it_bdy2.c:10107 */
#define   EIT284      (ERRIT +  284)    /*    it_bdy2.c:10109 */
#define   EIT285      (ERRIT +  285)    /*    it_bdy2.c:10111 */
#define   EIT286      (ERRIT +  286)    /*    it_bdy2.c:10194 */
#define   EIT287      (ERRIT +  287)    /*    it_bdy2.c:10196 */
#define   EIT288      (ERRIT +  288)    /*    it_bdy2.c:10198 */
#define   EIT289      (ERRIT +  289)    /*    it_bdy2.c:10202 */
#define   EIT290      (ERRIT +  290)    /*    it_bdy2.c:10204 */
#define   EIT291      (ERRIT +  291)    /*    it_bdy2.c:10206 */
#define   EIT292      (ERRIT +  292)    /*    it_bdy2.c:10211 */
#define   EIT293      (ERRIT +  293)    /*    it_bdy2.c:10213 */
#define   EIT294      (ERRIT +  294)    /*    it_bdy2.c:10216 */
#define   EIT295      (ERRIT +  295)    /*    it_bdy2.c:10218 */
#define   EIT296      (ERRIT +  296)    /*    it_bdy2.c:10224 */
#define   EIT297      (ERRIT +  297)    /*    it_bdy2.c:10226 */
#define   EIT298      (ERRIT +  298)    /*    it_bdy2.c:10230 */
#define   EIT299      (ERRIT +  299)    /*    it_bdy2.c:10240 */
#define   EIT300      (ERRIT +  300)    /*    it_bdy2.c:10242 */
#define   EIT301      (ERRIT +  301)    /*    it_bdy2.c:10248 */
#define   EIT302      (ERRIT +  302)    /*    it_bdy2.c:10250 */
#define   EIT303      (ERRIT +  303)    /*    it_bdy2.c:10258 */
#define   EIT304      (ERRIT +  304)    /*    it_bdy2.c:10262 */
#define   EIT305      (ERRIT +  305)    /*    it_bdy2.c:10268 */
#define   EIT306      (ERRIT +  306)    /*    it_bdy2.c:10270 */
#define   EIT307      (ERRIT +  307)    /*    it_bdy2.c:10272 */
#define   EIT308      (ERRIT +  308)    /*    it_bdy2.c:10274 */
#define   EIT309      (ERRIT +  309)    /*    it_bdy2.c:10337 */
#define   EIT310      (ERRIT +  310)    /*    it_bdy2.c:10339 */
#define   EIT311      (ERRIT +  311)    /*    it_bdy2.c:10393 */
#define   EIT312      (ERRIT +  312)    /*    it_bdy2.c:10395 */
#define   EIT313      (ERRIT +  313)    /*    it_bdy2.c:10560 */
#define   EIT314      (ERRIT +  314)    /*    it_bdy2.c:10562 */
#define   EIT315      (ERRIT +  315)    /*    it_bdy2.c:10594 */
#define   EIT316      (ERRIT +  316)    /*    it_bdy2.c:10596 */
#define   EIT317      (ERRIT +  317)    /*    it_bdy2.c:10660 */
#define   EIT318      (ERRIT +  318)    /*    it_bdy2.c:10757 */
#define   EIT319      (ERRIT +  319)    /*    it_bdy2.c:10823 */
#define   EIT320      (ERRIT +  320)    /*    it_bdy2.c:10848 */
#define   EIT321      (ERRIT +  321)    /*    it_bdy2.c:10894 */
#define   EIT322      (ERRIT +  322)    /*    it_bdy2.c:10920 */
#define   EIT323      (ERRIT +  323)    /*    it_bdy2.c:11000 */
#define   EIT324      (ERRIT +  324)    /*    it_bdy2.c:11003 */
#define   EIT325      (ERRIT +  325)    /*    it_bdy2.c:11006 */
#define   EIT326      (ERRIT +  326)    /*    it_bdy2.c:11009 */
#define   EIT327      (ERRIT +  327)    /*    it_bdy2.c:11030 */
#define   EIT328      (ERRIT +  328)    /*    it_bdy2.c:11076 */
#define   EIT329      (ERRIT +  329)    /*    it_bdy2.c:11139 */
#define   EIT330      (ERRIT +  330)    /*    it_bdy2.c:11172 */
#define   EIT331      (ERRIT +  331)    /*    it_bdy2.c:11230 */
#define   EIT332      (ERRIT +  332)    /*    it_bdy2.c:11444 */
#define   EIT333      (ERRIT +  333)    /*    it_bdy2.c:11448 */

#define   EIT334      (ERRIT +  334)    /*    it_bdy3.c: 222 */
#define   EIT335      (ERRIT +  335)    /*    it_bdy3.c: 360 */
#define   EIT336      (ERRIT +  336)    /*    it_bdy3.c: 381 */
#define   EIT337      (ERRIT +  337)    /*    it_bdy3.c: 399 */
#define   EIT338      (ERRIT +  338)    /*    it_bdy3.c: 417 */
#define   EIT339      (ERRIT +  339)    /*    it_bdy3.c: 434 */
#define   EIT340      (ERRIT +  340)    /*    it_bdy3.c: 449 */
#define   EIT341      (ERRIT +  341)    /*    it_bdy3.c: 464 */
#define   EIT342      (ERRIT +  342)    /*    it_bdy3.c: 483 */
#define   EIT343      (ERRIT +  343)    /*    it_bdy3.c: 503 */
#define   EIT344      (ERRIT +  344)    /*    it_bdy3.c: 522 */
#define   EIT345      (ERRIT +  345)    /*    it_bdy3.c: 760 */
#define   EIT346      (ERRIT +  346)    /*    it_bdy3.c: 776 */
#define   EIT347      (ERRIT +  347)    /*    it_bdy3.c: 791 */
#define   EIT348      (ERRIT +  348)    /*    it_bdy3.c: 800 */
#define   EIT349      (ERRIT +  349)    /*    it_bdy3.c: 810 */
#define   EIT350      (ERRIT +  350)    /*    it_bdy3.c: 820 */
#define   EIT351      (ERRIT +  351)    /*    it_bdy3.c: 830 */
#define   EIT352      (ERRIT +  352)    /*    it_bdy3.c: 840 */
#define   EIT353      (ERRIT +  353)    /*    it_bdy3.c: 850 */
#define   EIT354      (ERRIT +  354)    /*    it_bdy3.c: 860 */
#define   EIT355      (ERRIT +  355)    /*    it_bdy3.c: 870 */
#define   EIT356      (ERRIT +  356)    /*    it_bdy3.c: 882 */
#define   EIT357      (ERRIT +  357)    /*    it_bdy3.c: 894 */
#define   EIT358      (ERRIT +  358)    /*    it_bdy3.c: 907 */
#define   EIT359      (ERRIT +  359)    /*    it_bdy3.c: 920 */
#define   EIT360      (ERRIT +  360)    /*    it_bdy3.c: 933 */
#define   EIT361      (ERRIT +  361)    /*    it_bdy3.c: 946 */
#define   EIT362      (ERRIT +  362)    /*    it_bdy3.c: 957 */
#define   EIT363      (ERRIT +  363)    /*    it_bdy3.c: 969 */
#define   EIT364      (ERRIT +  364)    /*    it_bdy3.c: 982 */
#define   EIT365      (ERRIT +  365)    /*    it_bdy3.c: 995 */
#define   EIT366      (ERRIT +  366)    /*    it_bdy3.c:1008 */
#define   EIT367      (ERRIT +  367)    /*    it_bdy3.c:1019 */
#define   EIT368      (ERRIT +  368)    /*    it_bdy3.c:1209 */
#define   EIT369      (ERRIT +  369)    /*    it_bdy3.c:1483 */
#define   EIT370      (ERRIT +  370)    /*    it_bdy3.c:1897 */
#define   EIT371      (ERRIT +  371)    /*    it_bdy3.c:1916 */
#define   EIT372      (ERRIT +  372)    /*    it_bdy3.c:1935 */
#define   EIT373      (ERRIT +  373)    /*    it_bdy3.c:1956 */
#define   EIT374      (ERRIT +  374)    /*    it_bdy3.c:1975 */
#define   EIT375      (ERRIT +  375)    /*    it_bdy3.c:2059 */
#define   EIT376      (ERRIT +  376)    /*    it_bdy3.c:2078 */
#define   EIT377      (ERRIT +  377)    /*    it_bdy3.c:2097 */
#define   EIT378      (ERRIT +  378)    /*    it_bdy3.c:2117 */
#define   EIT379      (ERRIT +  379)    /*    it_bdy3.c:2139 */
#define   EIT380      (ERRIT +  380)    /*    it_bdy3.c:2271 */
#define   EIT381      (ERRIT +  381)    /*    it_bdy3.c:2283 */
#define   EIT382      (ERRIT +  382)    /*    it_bdy3.c:2398 */
#define   EIT383      (ERRIT +  383)    /*    it_bdy3.c:2452 */
#define   EIT384      (ERRIT +  384)    /*    it_bdy3.c:2513 */
#define   EIT385      (ERRIT +  385)    /*    it_bdy3.c:2630 */
#define   EIT386      (ERRIT +  386)    /*    it_bdy3.c:2642 */
#define   EIT387      (ERRIT +  387)    /*    it_bdy3.c:2653 */
#define   EIT388      (ERRIT +  388)    /*    it_bdy3.c:2668 */
#define   EIT389      (ERRIT +  389)    /*    it_bdy3.c:2681 */
#define   EIT390      (ERRIT +  390)    /*    it_bdy3.c:2701 */
#define   EIT391      (ERRIT +  391)    /*    it_bdy3.c:2725 */
#define   EIT392      (ERRIT +  392)    /*    it_bdy3.c:2747 */
#define   EIT393      (ERRIT +  393)    /*    it_bdy3.c:2763 */
#define   EIT394      (ERRIT +  394)    /*    it_bdy3.c:2780 */
#define   EIT395      (ERRIT +  395)    /*    it_bdy3.c:2796 */
#define   EIT396      (ERRIT +  396)    /*    it_bdy3.c:2807 */
#define   EIT397      (ERRIT +  397)    /*    it_bdy3.c:2818 */
#define   EIT398      (ERRIT +  398)    /*    it_bdy3.c:2829 */
#define   EIT399      (ERRIT +  399)    /*    it_bdy3.c:2844 */
#define   EIT400      (ERRIT +  400)    /*    it_bdy3.c:2857 */
#define   EIT401      (ERRIT +  401)    /*    it_bdy3.c:2874 */
#define   EIT402      (ERRIT +  402)    /*    it_bdy3.c:2889 */
#define   EIT403      (ERRIT +  403)    /*    it_bdy3.c:2902 */
#define   EIT404      (ERRIT +  404)    /*    it_bdy3.c:2920 */
#define   EIT405      (ERRIT +  405)    /*    it_bdy3.c:2931 */
#define   EIT406      (ERRIT +  406)    /*    it_bdy3.c:2943 */
#define   EIT407      (ERRIT +  407)    /*    it_bdy3.c:2955 */
#define   EIT408      (ERRIT +  408)    /*    it_bdy3.c:2967 */
#define   EIT409      (ERRIT +  409)    /*    it_bdy3.c:2981 */
#define   EIT410      (ERRIT +  410)    /*    it_bdy3.c:2994 */

#define   EIT411      (ERRIT +  411)    /*    it_bdy4.c: 491 */
#define   EIT412      (ERRIT +  412)    /*    it_bdy4.c: 507 */
#define   EIT413      (ERRIT +  413)    /*    it_bdy4.c: 525 */
#define   EIT414      (ERRIT +  414)    /*    it_bdy4.c: 558 */
#define   EIT415      (ERRIT +  415)    /*    it_bdy4.c: 617 */
#define   EIT416      (ERRIT +  416)    /*    it_bdy4.c:1284 */
#define   EIT417      (ERRIT +  417)    /*    it_bdy4.c:1493 */
#define   EIT418      (ERRIT +  418)    /*    it_bdy4.c:1602 */
#define   EIT419      (ERRIT +  419)    /*    it_bdy4.c:2036 */
#define   EIT420      (ERRIT +  420)    /*    it_bdy4.c:2049 */
#define   EIT421      (ERRIT +  421)    /*    it_bdy4.c:2063 */
#define   EIT422      (ERRIT +  422)    /*    it_bdy4.c:2080 */
#define   EIT423      (ERRIT +  423)    /*    it_bdy4.c:2093 */
#define   EIT424      (ERRIT +  424)    /*    it_bdy4.c:2108 */
#define   EIT425      (ERRIT +  425)    /*    it_bdy4.c:2121 */
#define   EIT426      (ERRIT +  426)    /*    it_bdy4.c:2133 */
#define   EIT427      (ERRIT +  427)    /*    it_bdy4.c:2145 */
#define   EIT428      (ERRIT +  428)    /*    it_bdy4.c:2156 */
#define   EIT429      (ERRIT +  429)    /*    it_bdy4.c:2175 */
#define   EIT430      (ERRIT +  430)    /*    it_bdy4.c:2513 */
#define   EIT431      (ERRIT +  431)    /*    it_bdy4.c:2524 */
#define   EIT432      (ERRIT +  432)    /*    it_bdy4.c:2536 */
#define   EIT433      (ERRIT +  433)    /*    it_bdy4.c:2549 */
#define   EIT434      (ERRIT +  434)    /*    it_bdy4.c:2562 */
#define   EIT435      (ERRIT +  435)    /*    it_bdy4.c:2585 */
#define   EIT436      (ERRIT +  436)    /*    it_bdy4.c:2596 */
#define   EIT437      (ERRIT +  437)    /*    it_bdy4.c:2609 */
#define   EIT438      (ERRIT +  438)    /*    it_bdy4.c:2622 */
#define   EIT439      (ERRIT +  439)    /*    it_bdy4.c:2637 */
#define   EIT440      (ERRIT +  440)    /*    it_bdy4.c:10115 */
#define   EIT441      (ERRIT +  441)    /*    it_bdy4.c:10128 */

#define   EIT442      (ERRIT +  442)    /*    it_bdy5.c: 578 */

#define   EIT443      (ERRIT +  443)    /*   it_ex_ms.c: 287 */
#define   EIT444      (ERRIT +  444)    /*   it_ex_ms.c: 340 */
#define   EIT445      (ERRIT +  445)    /*   it_ex_ms.c: 378 */
#define   EIT446      (ERRIT +  446)    /*   it_ex_ms.c: 412 */
#define   EIT447      (ERRIT +  447)    /*   it_ex_ms.c: 454 */
#define   EIT448      (ERRIT +  448)    /*   it_ex_ms.c: 475 */

#define   EIT449      (ERRIT +  449)    /*    it_ptli.c:1788 */
#define   EIT450      (ERRIT +  450)    /*    it_ptli.c:1832 */
#define   EIT451      (ERRIT +  451)    /*    it_ptli.c:1877 */
#define   EIT452      (ERRIT +  452)    /*    it_ptli.c:1928 */

#define   EIT453      (ERRIT +  453)    /*    it_ptui.c: 939 */
#define   EIT454      (ERRIT +  454)    /*    it_ptui.c: 990 */
#define   EIT455      (ERRIT +  455)    /*    it_ptui.c:1036 */
#define   EIT456      (ERRIT +  456)    /*    it_ptui.c:1077 */
#define   EIT457      (ERRIT +  457)    /*    it_ptui.c:1128 */
#define   EIT458      (ERRIT +  458)    /*    it_ptui.c:1172 */
#define   EIT459      (ERRIT +  459)    /*    it_ptui.c:1217 */



#endif /* __ITERRH__ */



/********************************************************************30**

         End of file:     it_err.h@@/main/7 - Thu Apr  1 03:52:14 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/3      ---    pn   1. initial release.

/main/3      ---     as   1. Updates to Release 1.2 
/main/4      ---     sg   1. Updated error codes.
             ---     sg   2. Updates to Release 1.3
/main/5      ---     sg   1. Update to Release 1.4
/main/6      ---     nt   1. Update to Release 1.5
/main/7      ---     rs   1. Update to Release 1.6.
*********************************************************************91*/
