/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     M3UA Layer

     Type:     C include file

     Desc:     Defines required by SCTP

     File:     it.h

     Sid:      it.h@@/main/8 - Thu Apr  1 03:50:48 2004

     Prg:      pn, jjb, mrw

*********************************************************************21*/

#ifndef __ITH__
#define __ITH__

#ifdef IT_RUG
#ifndef TDS_ROLL_UPGRADE_SUPPORT
#error "IT_RUG cannot be defined without TDS_ROLL_UPGRADE_SUPPORT"
#endif 
#ifndef SNT2
#error "SNT2 flag must be defined for rolling upgrade, please enable"
#endif
#ifndef IT_FTHA
#error "IT_FTHA flag must be defined for rolling upgrade, please enable"
#endif
#ifndef TDS_CORE2
#error "TDS_CORE2 flag must be defined for rolling upgrade, please enable"
#endif
#endif /* IT_RUG */

/* Layer name */
#define ITLAYERNAME              "M3UA_LAYER"

/* M3UA protocol version */
#define IT_M3UA_VERSION          0x01     /* M3UA IETF version 1.0 */

/* M3UA Multiple Proc Support */
#ifdef SS_MULTIPLE_PROCS
#ifndef IT_MAX_INSTANCES
#define IT_MAX_INSTANCES         1
#endif
#define itGlobalCb (*itGlobalCbPtr)
#endif /* SS_MULTIPLE_PROCS */

/* Maximum M3UA header in data message */
#define IT_M3UA_MAXHDR           (7 * sizeof(U32))

/* Minimum number of streams */
#define IT_MIN_STRMS             2

/* Maximum number of RK timers */
#define IT_MAX_REG_TMR           2

/* Maximum M3UA DIAG size */
#define IT_M3UA_MAXDIAG          40       

/* Constant Defines */
#define MAX16BIT                 0xffff      /* Maximum value of U16 */
#define MAX32BIT                 0xffffffffL /* Maximum value of U32 */

#define IT_M3UA_DFLT             0xFF          /* M3UA layer Default value */

#define IT_M3UA_DATA_HDR_SIZE    12         /* Size of Header in Data message */

/* Maximum number of timers in layer */
#define IT_TQSIZE                100

/* Maximum octets of user information used for routing */
#define IT_MAX_USERINFO          10
/* 
 * Maximum number of network contexts allowed - 
 * limited to 0x40, because there are only 6 bits available in search key
 * (i.e. nwkId must be in the range 0 .. 0x3f)
 */
#define IT_MAX_NWK               0x40

/* Maximum sio/sioMask value - limited by bits available in search key */
#define IT_MAX_SIO               0x0f

/* Maximum number of SLS contexts for load sharing */
#define IT_MAX_SLSCTX            256 

/* Maximum SLS value for 4 bit SLS */
#define IT_MAX_SLS4 0x0f

/* Maximum SLS value for 5 bit SLS */
#define IT_MAX_SLS5 0x1f

/* Maximum SLS value for 8 bit SLS */
#define IT_MAX_SLS8 0xff

/* DPC Mask for Maximum DPC Length */
#define IT_MAX_DPC_MASK 0xffffff

/* MAximum number of XUDT context blocks */
#define IT_MAX_XUDT_CTX          32
/* Invalid SCT SAP suId */
#define IT_MAX_SCT_BND_RETRY     3
#define IT_MAX_MTP3_BND_RETRY     3

/* Maximum size for a static array that can be packed into a buffer */
#define IT_MAX_M3UA_MSG_LEN     100

/* PS Type */
#define IT_PS_LOCAL     1     /* Local PS */
#define IT_PS_REMOTE    2     /* Remote PS */
/* MTP3 specific info */

#define CCITT_MINMSG    5     /* minimum CCITT message length */
#define ANSI_MINMSG     8     /* minimum ANSI message length */
#define CHINA_MINMSG    8     /* minimum CHINA message length */
#define MAXHDRSIZE      10    /* maximum size of the mtp3 header message */
#define SI_SNM          0     /* Signalling Network Management messages */
#define SI_SNT          1     /* Signalling Network Testing and Maintenance 
                                 messages */
#define SI_SCCP         3     /* Signalling Connection Control Part */
#define SI_TUP          4     /* Telephone User Part */
#define SI_ISUP         5     /* ISDN User Part */
#define SI_DUP          6     /* Data User Part */
#define SI_MTUP         8     /* MTP Testing User Part */
#define SI_SNTS         2     /* Signalling Network Testing and Maintenance 
                                 special messages */
#define SI_DUPF         7     /* Data User Part Facility */
#define SI_BISUP        9     /* Broadband ISDN User Part */
#define SI_SISUP        10    /* Satellite ISDN User Part */
#define SI_AAL2         12    /* ATM Adaptation Layer 2 */
/* it013.106 - Added MGCP support. */
#define SI_MGCP         14    /* MGCP */
/* it017.106 - Removed the definition of MAXSI as it is not being used. */

#define SI_MTP3         0xFF    /* MTP3 as M3UA service provider */
/* ITU/ANSI tags */

#define SCCP_CR                     0x01  /* SCCP CR i.e. tag */  
#define SCCP_CC                     0x02  /* SCCP CC i.e. tag */  
#define SCCP_CREF                   0x03  /* SCCP CREF i.e. tag */  
#define SCCP_UDT                    0x09  /* SCCP UDT i.e. tag */  
#define SCCP_UDTS                   0x0A  /* SCCP UDTS i.e. tag */  
#define SCCP_XUDT                   0x11  /* SCCP XUDT i.e. tag */  
#define SCCP_XUDTS                  0x12  /* SCCP XUDTS i.e. tag */  
#define SCCP_LUDT                   0x13  /* SCCP LUDT i.e. tag */  
#define SCCP_LUDTS                  0x14  /* SCCP LUDTS i.e. tag */  

#define SCCP_PARAM_CALLED_PARTY     0x03  /* SCCP called party parameter tag */
#define SCCP_PARAM_SEGMENTATION     0x10  /* SCCP segmentation parameter tag */
#define SCCP_PARAM_LONG_DATA        0x13  /* SCCP long data parameter tag */

#define SCCP_AI_PCI_ITU             0x01  /* SCCP address-point code tag ITU */
#define SCCP_AI_SSNI_ITU            0x02  /* SCCP address-SSN tag ITU */
#define SCCP_AI_PCI_ANSI            0x02  /* SCCP address-point code tag ANSI */
#define SCCP_AI_SSNI_ANSI           0x01  /* SCCP address-SSN tag ANSI */       

#define TCAP_MSGTYPE_BEGIN          0x62  /* TCAP BEGIN message */
#define TCAP_MSGTYPE_END            0x64  /* TCAP END message */
#define TCAP_MSGTYPE_CONTINUE       0x65  /* TCAP CONTINUE message */
#define TCAP_MSGTYPE_ABORT          0x67  /* TCAP ABORT message */

#define TCAP_TAG_ORIGTID            0x48  /* TCAP originating TID tag */
#define TCAP_TAG_DESTTID            0x49  /* TCAP destination TID tag */

#define ST_ANS_MSG_UNI_TAG          0xE1  /* Uni-directional message */
#define ST_ANS_MSG_QWP_TAG          0xE2  /* Query with Permission */
#define ST_ANS_MSG_QWOP_TAG         0xE3  /* Query without Permission */
#define ST_ANS_MSG_RSP_TAG          0xE4  /* Response */
#define ST_ANS_MSG_CWP_TAG          0xE5  /* Conversation with Permission */
#define ST_ANS_MSG_CWOP_TAG         0xE6  /* Conversation without Permission */
#define ST_ANS_MSG_ABT_TAG          0xF6  /* Abort */

#define ST_ANS_TID_TAG              0xC7  /* Ansi Transaction ID */
#define ST_ANS_PABT_TAG             0xD7  /* Ansi P-Abort Cause Tag */
#define ST_ANS_UABT_TAG             0xD8  /* Ansi U-Abort Information Tag */
#define ST_ANS_COMP_SEQ_TAG         0xE8  /* Ansi Component Sequence */

/* MUP defines */

#define IT_MSG_UP            1    /* Message on its way up */
#define IT_MSG_DOWN          2    /* Message on its way down */

#define IT_MSGHDR_NONE       1    /* Message has no header */
#define IT_MSGHDR_PRES       2    /* Message has header */
#define IT_MSGHDR_PRESEX     3    /* Message has header, contents extracted */

#define IT_MSG_UNROUTED      1    /* Message not routed */
#define IT_MSG_ROUTED_ONE    2    /* Stage 1 routing complete */
#define IT_MSG_ROUTED_TWO    3    /* Stage 2 routing complete */
#define IT_MSG_RDY_MMH       4    /* Message ready to be sent to MMH */
#define IT_MSG_RDY_NSAP      5    /* Message ready to be sent to UI */
#define IT_MSG_QUEUED_PSM    6    /* Message queued by PSM */
#define IT_MSG_QUEUED_CC     7    /* Message queued by CC */
#define IT_MSG_REJECTED      8    /* Message invalid and rejected */
#define IT_MSG_DISCARD       9    /* Message to be discarded */
#define IT_MSG_QUEUED_LSCSLS 10   /* Message queued in SLS context block */

#define IT_USER_GEN          1    /* Extract general info */
#define IT_USER_TCAP         2    /* Extract TCAP-specific info */
#define IT_USER_SEGLOCREF    3    /* Extract SCCP segmentation local ref */

/* AT defines */

#define IT_DPCCB_UNKNOWN     0    /* route type currently unknown */
#define IT_DPCCB_SPMC        1    /* routing config type LIT_RTTYPE_PS */
#define IT_DPCCB_SS7         2    /* routing config type LIT_RTTYPE_NIF */
#define IT_DPCCB_LOCAL       3    /* routing config type LIT_RTTYPE_LOCAL */
#define IT_DPCCB_NONROUTE    4    /* non-routing DPC CB */

/* ASM defines */

#define IT_LOCAL_PSPID           0     /* Reserved ID for local PSP */

#define IT_EVT_ASP_UP            1     /* ASPUP received */
#define IT_EVT_ASP_DN            2     /* ASPDN received */
#define IT_EVT_ASP_AC            3     /* ASPAC received */
#define IT_EVT_ASP_IA            4     /* ASPIA received */
#define IT_EVT_ASP_UP_ACK        5     /* ASPUP ACK received */
#define IT_EVT_ASP_DN_ACK        6     /* ASPDN ACK received */
#define IT_EVT_ASP_AC_ACK        7     /* ASPAC ACK received */
#define IT_EVT_ASP_IA_ACK        8     /* ASPIA ACK received */
#define IT_EVT_AS_PEND_TIMEOUT   9     /* AS-PENDING timeout */
#define IT_EVT_AS_DOWN           10    /* Notify(AS-DOWN) received */
#define IT_EVT_AS_INACTIVE       11    /* Notify(AS-INACTIVE) received */
#define IT_EVT_AS_ACTIVE         12    /* Notify(AS-ACTIVE) received */
#define IT_EVT_AS_PENDING        13    /* Notify(AS-PENDING) received */
#define IT_EVT_AS_SWTCH_TIMEOUT  14    /* AS T-switch timeout */
#define IT_EVT_OTHER_OUTRES      15    /* Notify Insuf Resources received */
#define IT_EVT_RECONFIG          16    /* Change in configuration */
#define IT_EVT_DREGREQ           17    /* Deregistration request received */

/* MMH defines */

#define IT_M3UA_MGMT_STREAM      0        /* SCTP stream 0 used for 
                                             management */

/* M3UA protocol message classes */
#define IT_MSGCLASS_MGMT         0x00     /* MGMT message class */
#define IT_MSGCLASS_M3UA_XFER    0x01     /* M3UA data transfer message class */
#define IT_MSGCLASS_SSNM         0x02     /* SS7 network management msg class */
#define IT_MSGCLASS_ASPSM        0x03     /* ASP state maintenance msg class */
#define IT_MSGCLASS_ASPTM        0x04     /* ASP traffic maintenance msg cls */
#define IT_MSGCLASS_QPTM         0x05     /* unsupported message class */
#define IT_MSGCLASS_MAUP         0x06     /* unsupported message class */
#define IT_MSGCLASS_SUACL        0x07     /* unsupported message class */
#define IT_MSGCLASS_SUACO        0x08     /* unsupported message class */
#define IT_MSGCLASS_RKM          0x09     /* Routing Key Mgmt message class */

/* M3UA protocol message types */
#define IT_M3UA_ERROR            0x0000   /* M3UA ERROR message */
#define IT_M3UA_NOTIFY           0x0001   /* M3UA NOTIFY message */
#define IT_M3UA_DATA             0x0101   /* M3UA DATA message */
#define IT_SSNM_DUNA             0x0201   /* M3UA DUNA message */
#define IT_SSNM_DAVA             0x0202   /* M3UA DAVA message */
#define IT_SSNM_DAUD             0x0203   /* M3UA DAUD message */
#define IT_SSNM_SCON             0x0204   /* M3UA SCON message */
#define IT_SSNM_DUPU             0x0205   /* M3UA DUPU message */
#define IT_SSNM_DRST             0x0206   /* M3UA DRST message */
#define IT_ASPM_ASPUP            0x0301   /* M3UA ASPUP message */
#define IT_ASPM_ASPDN            0x0302   /* M3UA ASPDN message */
#define IT_ASPM_BEAT             0x0303   /* M3UA BEAT message */
#define IT_ASPM_ASPUP_ACK        0x0304   /* M3UA ASPUP_ACK message */
#define IT_ASPM_ASPDN_ACK        0x0305   /* M3UA ASPDN_ACK message */
#define IT_ASPM_BEAT_ACK         0x0306   /* M3UA BEAT_ACK message */
#define IT_ASPM_ASPAC            0x0401   /* M3UA ASPAC message */
#define IT_ASPM_ASPIA            0x0402   /* M3UA ASPIA message */
#define IT_ASPM_ASPAC_ACK        0x0403   /* M3UA ASPAC_ACK message */
#define IT_ASPM_ASPIA_ACK        0x0404   /* M3UA ASPIA_ACK message */
#define IT_RKM_REGREQ            0x0901   /* M3UA REG REQ message */
#define IT_RKM_REGRSP            0x0902   /* M3UA REG RSP message */
#define IT_RKM_DREGREQ           0x0903   /* M3UA DEREG REQ message */
#define IT_RKM_DREGRSP           0x0904   /* M3UA DEREG RSP message */

/* M3UA protocol parameter tags */

#define IT_M3UA_TAG_INFO         0x0004     /* M3UA INFO parameter tag */
#define IT_M3UA_TAG_RCTX         0x0006     /* M3UA RCTX parameter tag */
#define IT_M3UA_TAG_DIAG         0x0007     /* M3UA DIAG parameter tag */
#define IT_M3UA_TAG_HBEATDATA    0x0009     /* M3UA HBEATDATA parameter tag */

#define IT_M3UA_TAG_TRAFMODE     0x000b     /* M3UA TRAFMODE parameter tag */
#define IT_M3UA_TAG_ERRCODE      0x000c     /* M3UA ERRCODE parameter tag */
#define IT_M3UA_TAG_STATUS       0x000d     /* M3UA STATUS parameter tag */
#define IT_M3UA_TAG_ASPID        0x0011     /* M3UA ASP ID parameter tag */
#define IT_M3UA_TAG_ADPC         0x0012     /* M3UA ADPC parameter tag */

#define IT_M3UA_TAG_CORELTN_ID   0x0013    /* M3UA Correlation Id */

#define IT_M3UA_TAG_NWKAPP       0x0200     /* M3UA NWKAP parameter tag */
#define IT_M3UA_TAG_CAUSEUSER    0x0204     /* M3UA CAUSEUSER parameter tag */
#define IT_M3UA_TAG_CONGLEVEL    0x0205     /* M3UA CONGINDI parameter tag */
#define IT_M3UA_TAG_CNCRNDPC     0x0206     /* M3UA CNCRNDPC parameter tag */
#define IT_M3UA_TAG_RK           0x0207     /* M3UA RK parameter tag */
#define IT_M3UA_TAG_REGRSLT      0x0208     /* M3UA REGRSLT parameter tag */
#define IT_M3UA_TAG_DREGRSLT     0x0209     /* M3UA DREGRSLT parameter tag */
#define IT_M3UA_TAG_LCLRKID      0x020a    /* M3UA LocalRK-id parameter tag */
#define IT_M3UA_TAG_DPC          0x020b     /* M3UA DPC parameter tag */
#define IT_M3UA_TAG_SI           0x020c     /* M3UA SI parameter tag */
#define IT_M3UA_TAG_OPC          0x020e     /* M3UA OPC parameter tag */
#define IT_M3UA_TAG_CICRNG       0x020f     /* M3UA CIC parameter tag */
#define IT_M3UA_TAG_DATA         0x0210    /* M3UA Protocol Data tag */
#define IT_M3UA_TAG_REGSTA       0x0212     /* TBD: REG Status prmeter tag  */
#define IT_M3UA_TAG_DREGSTA      0x0213     /* TBD: DREG Status prmeter tag */


/* Tag index values */
#define IT_M3UA_TAG_IDX_NWKAPP       0     /* M3UA NWKAP parameter tag idx */
#define IT_M3UA_TAG_IDX_DATA         1    /* M3UA Protocol Data tag */
#define IT_M3UA_TAG_IDX_INFO         2     /* M3UA INFO parameter tag idx */
#define IT_M3UA_TAG_IDX_ADPC         3     /* M3UA ADPC parameter tag idx */
#define IT_M3UA_TAG_IDX_RCTX         4     /* M3UA RCTX parameter tag idx */
#define IT_M3UA_TAG_IDX_DIAG         5     /* M3UA DIAG parameter tag idx */
#define IT_M3UA_TAG_IDX_HBEATDATA    6     /* M3UA HBEATDATA parameter tagidx */
#define IT_M3UA_TAG_IDX_CAUSEUSER    7     /* M3UA CAUSEUSER parameter tagidx */
#define IT_M3UA_TAG_IDX_TRAFMODE     8   /* M3UA TRAFMODE parameter tag idx */
#define IT_M3UA_TAG_IDX_ERRCODE      9   /* M3UA ERRCODE parameter tag idx */
#define IT_M3UA_TAG_IDX_STATUS       10  /* M3UA STATUS parameter tag idx */
#define IT_M3UA_TAG_IDX_CONGLEVEL    11  /* M3UA CONGINDI parameter tag idx */
#define IT_M3UA_TAG_IDX_CNCRNDPC     12   /* M3UA CNCRNDPC parameter tag idx */
#define IT_M3UA_TAG_IDX_RK           13   /* M3UA RK parameter tag idx */
#define IT_M3UA_TAG_IDX_REGRSLT      14    /* M3UA REGRSLT parameter tag idx */
#define IT_M3UA_TAG_IDX_DREGRSLT     15    /* M3UA DREGRSLT parameter tag idx */
#define IT_M3UA_TAG_IDX_LCLRKID      16    /* M3UA LocalRK-id prmeter tag idx */
#define IT_M3UA_TAG_IDX_DPC          17    /* M3UA DPC parameter tag idx */
#define IT_M3UA_TAG_IDX_SI           18    /* M3UA SI parameter tag idx */
#define IT_M3UA_TAG_IDX_OPC          19    /* M3UA OPC parameter tag idx */
#define IT_M3UA_TAG_IDX_CICRNG       20    /* M3UA CIC parameter tag idx */
#define IT_M3UA_TAG_IDX_REGSTA       21    /* M3UA DREGRSLTS prmeter tag idx */
#define IT_M3UA_TAG_IDX_DREGSTA      22    /* M3UA DREGRSLTS prmeter tag idx */
#define IT_M3UA_TAG_IDX_CORELTN_ID   23    /* Correlation ID prmeter tag idx */
#define IT_M3UA_TAG_IDX_ASPID        24    /* ASP ID parameter tag idx */
#define IT_M3UA_TAGARRAYSIZE         25    /* size of tag storage array */

/* M3UA protocol error codes */
#define IT_M3UA_ERROR_INV_VERSION      0x01     /* Invalid version */
#define IT_M3UA_ERROR_UNSUP_MSGCLS     0x03     /* Unsupported message class */
#define IT_M3UA_ERROR_UNSUP_MSGTYPE    0x04     /* Unsupported message type */
#define IT_M3UA_ERROR_UNSUPP_THM       0x05     /* Unsupported Traffic 
                                                   Handling Mode */
#define IT_M3UA_ERROR_UNEXP_MSG        0x06     /* Unexpected message */
#define IT_M3UA_ERROR_PROTO_ERR        0x07     /* Protocol error */
#define IT_M3UA_ERROR_INV_STRMID       0x09     /* Invalid stream identifier */
#define IT_M3UA_ERROR_RFSD_MGMTBLKD    0x0d    /* Refused mgmt blocking */
#define IT_M3UA_ERROR_ASPID_REQD       0x0e    /* ASP ID Required */    
#define IT_M3UA_ERROR_INV_ASPID        0x0f    /* Invalid ASP ID */
#define IT_M3UA_ERROR_INV_PARMVAL      0x11    /* Invalid parameter value */
#define IT_M3UA_ERROR_PARAM_FIELD_ERROR  0x12  /* Parameter Field Error */
#define IT_M3UA_ERROR_UNEXPECTED_PARAM   0x13  /* Unexpected Parameter */
#define IT_M3UA_ERROR_DPC_STATUS_UNKNOWN 0x14 /* Unknown DPC Status */
#define IT_M3UA_ERROR_INV_NWKAPP         0x15 /* Invalid Network Appearance */

#define IT_M3UA_ERROR_MISSING_PARAM      0x16 /* Missing Parameter */
#define IT_M3UA_ERROR_INV_RCTX           0x19     /* Invalid Routing Context */
#define IT_M3UA_ERROR_NO_AS_FOR_ASP      0x1a    /* No configured AS for ASP */

/* Ps Configuration Types */
#define IT_PS_CFG_STAT             0
#define IT_PS_CFG_DYN              1


/* M3UA protocol notify types */
#define IT_M3UA_NTFY_TYPE_ASCHG     1     /* Application Server State Change */
#define IT_M3UA_NTFY_TYPE_OTHER     2     /* Other */

/* M3UA traffic handling modes */
#define IT_M3UA_THM_OVERRIDE           1  /* override */ 
#define IT_M3UA_THM_LOADSHARE          2  /* load sharing */
#define IT_M3UA_THM_BROADCAST          3  /* load sharing */

#define IT_M3UA_DFLT_THM        IT_M3UA_THM_LOADSHARE  /* Default THM */

/* M3UA protocol notify identifiers */
#define IT_M3UA_NTFY_INFO_AS_INACTIVE  2  /* AS-INACTIVE */ 
#define IT_M3UA_NTFY_INFO_AS_ACTIVE    3  /* AS-ACTIVE */
#define IT_M3UA_NTFY_INFO_AS_PENDING   4  /* AS-PENDING */
#define IT_M3UA_NTFY_INFO_INSUF_RSRC   1  /* Insuf ASP rsrcs active */
#define IT_M3UA_NTFY_INFO_ALT_ASPACT   2  /* Alternative ASP active */

#define IT_M3UA_NTFY_INFO_ASP_FLR      3  /* ASP Failed */

/* M3UA protocol ASPDN reason */
#define IT_M3UA_REASON_UNSPEC          0  /* unspecified reason */
#define IT_M3UA_REASON_USER_UNAVAIL    1  /* user unavailable */
#define IT_M3UA_REASON_MGMNTINH        2  /* management blocking */

/* M3UA protocol DUPU causes */
#define IT_M3UA_DUPU_CAUSE_UNKNOWN     0  /* unknown cause */
#define IT_M3UA_DUPU_CAUSE_UNEQUIPPED  1  /* unequipped user */
#define IT_M3UA_DUPU_CAUSE_INACC       2  /* inaccessible user */

/* MIF defines */

#define IT_DPC_UNKNOWN        0     /* DPC state is unknown */
#define IT_DPC_AVAILABLE      1     /* DPC state is available */
#define IT_DPC_CONGESTED      2     /* DPC state is congested */
#define IT_DPC_UNAVAILABLE    3     /* DPC state is unavailable */
#define IT_DPC_RESTRICTED     4     /* DPC state is restricted */


/* source of event */
#define IT_MIF_SS7            1     /* From NIF (SGP) */
#define IT_MIF_SPMC           2     /* From management cluster */
#define IT_MIF_DATAREQ        3     /* From a data request */
#define IT_MIF_USER           4     /* From a user bind request */
#define IT_MIF_RST            5     /* From a restart timeout */
#define IT_MIF_SGP            6     /* From remote SGP */

/* type of event */
#define IT_MIF_NONE           0     /* NULL event */
#define IT_MIF_PC_UNA         1     /* Point code unavailable */
#define IT_MIF_PC_AVA         2     /* Point code available */
#define IT_MIF_PC_CON         3     /* Point code available, but congested */
#define IT_MIF_PC_UPU         4     /* User part unavailable */
#define IT_MIF_ASP_DOWN       5     /* Peer down */
#define IT_MIF_ASP_UP         6     /* Peer up */
#define IT_MIF_ASP_CONG       7     /* Peer congestion change */
#define IT_MIF_RST_COMP       8     /* Restart complete timeout */
#define IT_MIF_AS_ACTIVE      9     /* AS has become active */
#define IT_MIF_AS_INACTIVE    10    /* AS has become inactive */
#define IT_MIF_AS_PENDING     11    /* AS is pending */
#define IT_MIF_AS_CONG        12    /* AS congestion change */
#define IT_MIF_RST_BEG        13    /* Restart begin */
#define IT_MIF_RST_END        14    /* Restart end */
#define IT_MIF_PC_NEW         15    /* Newly-created DPC CB */
#define IT_MIF_PC_SUM         16    /* Request for sum of cluster status */
#define IT_MIF_USER_UP        17    /* Local user up */
#define IT_MIF_USER_DOWN      18    /* Local user down */
#define IT_MIF_PC_CHANGED     19    /* Modified DPC CB */
#define IT_MIF_ASP_ACTIVE     20    /* ASPAC or ASPAC ACK */
#define IT_MIF_ASP_INACTIVE   21    /* ASPIA or ASPIA ACK */
#define IT_MIF_NWK_ISOLATED   22    /* network isolated w.r.t. remote peer */
#define IT_MIF_NWK_RESTORED   23    /* network restored w.r.t. remote peer */
#define IT_MIF_MTP3_NOTPRSNT  24    /* co-resident MTP3 not present */
#define IT_MIF_MTP3_PRSNT     25    /* co-resident MTP3 present */
#define IT_MIF_PC_RST         26    /* Point code restricted */
#define IT_MIF_AS_DOWN        27    /* Point code restricted */

/* mifSt in aspCb, nSapCb */
#define IT_MIF_UNLISTED       1     /* not listed */
#define IT_MIF_LISTED         2     /* listed */
#define IT_MIF_ELIMINATED     3     /* eliminated */

/*Auto Start Timer Time*/
/* add chenning 2006/8/28 */
#define IT_TMR_TM_AUTOSTRRT    4

/* TC defines */
#define IT_TMR_SCT_BND        1     /* Lower SAP bind retry timer */
#define IT_TMR_AS_PENDING     2     /* AS-PENDING timer */
#define IT_TMR_STA_POLL       4     /* MTP3 status poll timer */
#define IT_TMR_DAUD           5     /* DAUD timer */
#define IT_TMR_NWK_RST        6     /* Network restart timer */
#define IT_TMR_HBEAT_RX       7     /* M3UA RX Heartbeat timer */
#define IT_TMR_HBEAT_TX       8     /* M3UA TX Heartbeat timer */
#define IT_TMR_ASPM           9    /* ASPM retry timer */
#define IT_TMR_FAILOVER       10    /* Fail-over timer */
#define IT_TMR_CONGPOLL       11    /* Congestion poll timer */
#define IT_TMR_SCT_ENDPOPEN   12    /* Lower SAP endpoint retry timer */
#define IT_TMR_LSC_CTX        13    /* Loadsharing context timer */
#define IT_TMR_ASSOC_REQ      14    /* Association request confirm timer */
#define IT_TMR_DUNA_SETTLE    15    /* Duna settle timer */
#define IT_TMR_RKM            16    /* RKM  timer */
#define IT_TMR_LSCSLS_SEQ     17    /* Sequence Cntrl timer for SLS Loadshare */
#define IT_TMR_MTP3_SAP_BND    18    /* NIF SAP bind retry timer */

#define IT_SG_TMR_RECONNECT  		21
/* Timer values */
#define IT_VAL_LSC_CTX        60    /* Timeout value for loadsharing context */

/* tags for itPsmValidateRctx */
#define IT_VRCTX_RMV_UNSUPP   1     /* Remove unsupported RCTXs */
#define IT_VRCTX_RMV_RESTART  2     /* Remove RCTXs with restarting networks */
#define IT_VRCTX_OVERRIDE     3     /* Remove RCTXs that are not act/standby */
#define IT_VRCTX_LOADSHARE    4     /* Remove RCTXs that are not loadsharing */
#define IT_VRCTX_BUILD        5     /* Build RCTX from local configuration */
#define IT_VRCTX_BUILD_DE_ACK      6     /* Build RCTX for IPSP DE Ack */
#define IT_VRCTX_RMV_UNSUPP_DE_ACK 7     /* Build RCTX for IPSP DE Ack */

/* M3UA Registration status values in REG RSP */
#define IT_RK_SUCC_REGD      0
#define IT_RK_UNKNOWN        1
#define IT_RK_INV_DPC        2
#define IT_RK_INV_NWK_APP    3 
#define IT_INV_RK            4
#define IT_PERM_DENIED       5
#define IT_CANT_SUPP_UNIQ_RK 6 
#define IT_RK_NOT_PROVISION  7 
#define IT_RK_INSUF_RSRCS    8 
#define IT_RK_UNSPP_PRMTR    9 
#define IT_RK_UNSPP_THM     10 

/* Request states in RKRCB */
#define IT_RSP_AWAITING      1
#define IT_RK_REGISTERED     2

/* request Type in RKRTCB */
#define IT_REG_REQ         1
#define IT_DEREG_REQ       2

/* M3UA De-Registration status values in DEREG RSP */
#define IT_RC_SUCC_DREGD      0
#define IT_INV_RC             2
#define IT_RC_PERM_DENIED     3 
#define IT_RC_NOT_REGD        4 
#define IT_RC_CURR_ACTIVE     5 

/* M3UA PS mode Registration mode */
#define IT_RC_DYNAMIC_REGD       0x01
#define IT_RC_STATIC_REGD        0x10

/* layer specific debug classes */
#define IT_DBGMASK_AT    (DBGMASK_LYR << 0) /* debug class for Addr. Transl */
#define IT_DBGMASK_MMH   (DBGMASK_LYR << 1) /* debug class for MMH */
#define IT_DBGMASK_DATA  (DBGMASK_LYR << 2) /* debug class for DATA request */
#define IT_DBGMASK_DUMMYSM  (DBGMASK_LYR << 3) /* debug class for Dummy Stack Manager */
#define IT_DBGMASK_MSGTRACE  (DBGMASK_LYR << 4) /* debug class for Message Trace */
/* Invalid PS Id */
#define IT_INVALID_PS_ID  0xffffffffL

/* DFHTA-hooks */
#define ITSHUTDOWN   40   /* Reason for calling itActvInit */
#define IT_EVENT_NON_CRIT 1 /* Non critical event of DFTHA */
#define IT_EVENT_CRIT     2 /* Critical event of DFTHA     */


/* M3UA Macros */

/* Extract service indicator from SIO */
#define IT_SRVIND(_sio)       ((_sio) & 0x0F)

/* Extract message priority from SIO */
#define IT_SIOPRI(_sio)       (((_sio) >> 4) & 0x03)

/* Extract cause from srvInfo in UPU status ind from MTP3 */
#define IT_SIOCAUSE(_sio)     (((_sio) >> 4) & 0x0F)

/* Remove priority from srvInfo */
#define IT_SIOFILTER(_sio)    ((_sio) & 0xCF)

/* Convert congestion queue size to priority */
#define IT_CONGPRIOR(_len)                                                    \
   (U8)( ((_len) <= itGlobalCb.genCfg.congLevel1) ? SN_PRI0 :                  \
         ((_len) <= itGlobalCb.genCfg.congLevel2) ? SN_PRI1 :                  \
         ((_len) <= itGlobalCb.genCfg.congLevel3) ? SN_PRI2 : SN_PRI3 )
     
/* debug macro for m3ua */
#define ITDBGP(_msgClass, _arg)                                               \
        DBGP(&(itGlobalCb.itInit), ITLAYERNAME, _msgClass, _arg)

/* zero out a buffer */
#define IT_ZERO(_str, _len)                                                   \
        cmMemset((U8 *)_str, 0, _len);

/* Initialize a timer */
#define IT_INITTIMER(_tmr)                                                    \
        cmInitTimers((_tmr), 1)
        
/* Is timer active? */
#define IT_TMRACTIVE(_tmr)                                                    \
        (((_tmr)->tmrEvnt == TMR_NONE) ? FALSE : TRUE)

/* allocate and zero out a static buffer */
#define IT_ALLOC(_size, _datPtr)                                              \
{                                                                             \
   if (SGetSBuf(itGlobalCb.itInit.region,                                     \
                  itGlobalCb.itInit.pool,                                     \
                  (Data**)&_datPtr, _size) == ROK)                            \
   {                                                                          \
      cmMemset((U8*)_datPtr, 0, _size);                                       \
      /* add to general status */                                             \
      itGlobalCb.genSta.memAlloc += (_size);                                  \
   }                                                                          \
   else                                                                       \
   {                                                                          \
      (_datPtr) = NULLP;                                                      \
      (Void) itMiStaInd(STITGEN, LCM_CATEGORY_RESOURCE,                       \
                        LCM_EVENT_SMEM_ALLOC_FAIL,                            \
                        LCM_CAUSE_MEM_ALLOC_FAIL, 0);                         \
   }                                                                          \
}

/* deallocate a static buffer */
#define IT_FREE(_size, _datPtr)                                               \
{                                                                             \
   (Void)SPutSBuf(itGlobalCb.itInit.region,                                   \
                  itGlobalCb.itInit.pool,                                     \
                  (Data *)_datPtr, _size);                                    \
   (_datPtr) = NULLP;                                                         \
   /* subtract from general status */                                         \
   itGlobalCb.genSta.memAlloc -= (_size);                                     \
}

#define IT_PSPnENDP2ASSOC(_pspId, endPId)                                    \
        (UConnId)((UConnId)(LIT_MAX_PSP)*(endPId) + _pspId)

/* Macro for converting assocId to suId */
#define IT_ASSOC2SUID(_assocId)                                                \
    (SuId)(_assocId / LIT_MAX_PSP)

/* Macro for converting assocId to pspId */
#define IT_ASSOC2PSPID(_assocId)                                             \
    (ItPspId)(_assocId % LIT_MAX_PSP)

/* it015.106 - Used sctSuId instead of assocId for updating the statistics. */
/* M3UA statistics: increment data error counter */
#define IT_STS_INC_DATERR(_msg, _cntr)                                        \
{                                                                             \
   if ((_msg)->dir == IT_MSG_DOWN)                                            \
   {                                                                          \
      ((ItNSapCb *)(_msg)->originator)->sntSts.dataErrSts._cntr++;            \
      itGlobalCb.genSts.downDataErrSts._cntr++;                               \
   }                                                                          \
   else                                                                       \
   {                                                                          \
      ItAssocCb *tmpAssocCb;                                                  \
      SuId   sctSuId;                                                        \
      tmpAssocCb = (ItAssocCb *)(_msg)->originator;                          \
      sctSuId  = IT_ASSOC2SUID(tmpAssocCb->assocId);                         \
      tmpAssocCb->owner->pspSts.assocSts[sctSuId].dataErrSts._cntr++;     \
      itGlobalCb.genSts.upDataErrSts._cntr++;                                 \
   }                                                                          \
}                                                                             
                                                                              
/* start timer where there is no TmrCfg structure available */
#define IT_TC_START_TMR(_tmr, _cb, _evt, _val)                                \
{                                                                             \
   TmrCfg _tmpTmr;                                                            \
   _tmpTmr.enb = TRUE;                                                        \
   _tmpTmr.val = (_val);                                                      \
   itTcStartTimer((_tmr), (_cb), (_evt), &_tmpTmr);                           \
}

/* General usage: discard the message buffer */
#define IT_DROPDATA(_msg)                                                     \
{                                                                             \
   if ((_msg) != (Buffer *)NULLP)                                             \
   {                                                                          \
      (Void) SPutMsg(_msg);                                                   \
      (_msg) = (Buffer *)NULLP;                                               \
   }                                                                          \
}

/* Macros for M3UA protocol message packing and unpacking */
#if (ERRCLASS & ERRCLS_ADD_RES)
#define IT_MMH_CHKLOG(_msg, _ret, _errCode)                                   \
{                                                                             \
   if (_ret != ROK)                                                           \
   {                                                                          \
      if ((_msg) != (Buffer *)NULLP)                                          \
      {                                                                       \
         (Void) SPutMsg(_msg);                                                \
         (_msg) = (Buffer *)NULLP;                                            \
      }                                                                       \
      ITLOGERROR(ERRCLS_ADD_RES, _errCode, (ErrVal) _ret,                     \
            "Packing/unpacking failure");                                     \
      RETVALUE(RFAILED);                                                      \
   }                                                                          \
}
#else 
#define IT_MMH_CHKLOG(_msg, _ret, _errCode)                                   \
{                                                                             \
   if (_ret != ROK)                                                           \
   {                                                                          \
      if ((_msg) != (Buffer *)NULLP)                                          \
      {                                                                       \
         (Void) SPutMsg(_msg);                                                \
         (_msg) = (Buffer *)NULLP;                                            \
      }                                                                       \
      RETVALUE(RFAILED);                                                      \
   }                                                                          \
}
#endif

/* M3UA message type: extract message class */
#define IT_MMH_MSGCLASS(_msgType)      (((_msgType) & 0xFF00) >> 8)


/* M3UA protocol message: pack U8 at end of message */
#define IT_MMH_PK_U8(_msg, _val, _ret)                                        \
{                                                                             \
   (_ret) = SAddPstMsg((Data) (_val), (_msg));                                \
}
                                                                              
/* M3UA protocol message: pack U8 at beginning of message */
#define IT_MMH_PREPK_U8(_val)                                     \
{                                                                             \
   pkArray[pkCtr++] = (Data) _val; \
}                                                                             
                                                                              
/* M3UA protocol message: get U8 value from message */
#define IT_MMH_EXAM_U8(_msg, _val, _idx, _ret)                                \
{                                                                             \
   (_ret) = SExamMsg((Data *)&(_val), (_msg), _idx);                          \
   (_idx)++;                                                                  \
}                                                                             
                                                                              
/* M3UA protocol message: pack U16 at end of message */
#define IT_MMH_PK_U16(_msg, _val, _ret)                                       \
{                                                                             \
   IT_MMH_PK_U8(_msg, (U8) GetHiByte(_val), _ret)                             \
   if ((_ret) == ROK)                                                         \
      IT_MMH_PK_U8(_msg, (U8) GetLoByte(_val), _ret)                          \
}                                                                             
                                                                              
/* M3UA protocol message: pack U16 at beginning of message */
#define IT_MMH_PREPK_U16(_val)                                    \
{                                                                             \
   IT_MMH_PREPK_U8((U8) GetLoByte(_val))                          \
   IT_MMH_PREPK_U8((U8) GetHiByte(_val))                       \
}
/* M3UA protocol message: get U16 value from message */
#define IT_MMH_EXAM_U16(_msg, _val, _idx, _ret)                               \
{                                                                             \
   U8 _tmp8;                                                                  \
   _val = 0;                                                                  \
   IT_MMH_EXAM_U8(_msg, _tmp8, _idx, _ret)                                    \
   if ((_ret) == ROK)                                                         \
   {                                                                          \
      _val = PutHiByte(_val, _tmp8);                                          \
      IT_MMH_EXAM_U8(_msg, _tmp8, _idx, _ret)                                 \
      _val = PutLoByte(_val, _tmp8);                                          \
   }                                                                          \
}
                                                                              
/* M3UA protocol message: pack U32 at end of message */
#define IT_MMH_PK_U32(_msg, _val, _ret)                                       \
{                                                                             \
   U16 _tmp16;                                                                \
   _tmp16 = (U16) GetHiWord(_val);                                            \
   IT_MMH_PK_U16(_msg, _tmp16, _ret)                                          \
   if ((_ret) == ROK)                                                         \
   {                                                                          \
      _tmp16 = (U16) GetLoWord(_val);                                         \
      IT_MMH_PK_U16(_msg, _tmp16, _ret)                                       \
   }                                                                          \
}
#define IT_MMH_PREPK_U32(_tmpU32)                       \
{                                               \
   U16 _tmp;                                    \
   _tmp = (U16) GetLoWord(_tmpU32);             \
   pkArray[pkCtr++] = (Data) GetLoByte(_tmp);     \
   pkArray[pkCtr++] = (Data) GetHiByte(_tmp);     \
   _tmp = (U16) GetHiWord(_tmpU32);             \
   pkArray[pkCtr++] = (Data) GetLoByte(_tmp);     \
   pkArray[pkCtr++] = (Data) GetHiByte(_tmp);     \
}

/* M3UA protocol message: pack DPC at beginning of message */           
#define IT_MMH_PREPK_DPC(_val,_dpcLen)                              \
{                                                                             \
   U16   _tmp16;                                                              \
   _tmp16 = (U16) GetLoWord(_val);                                            \
   if (_dpcLen == DPC14)                                                      \
      _tmp16 &= 0x3fff;                                                       \
   IT_MMH_PREPK_U16(_tmp16)                                       \
   if (_dpcLen == DPC24)                                                   \
   {                                                                       \
    _tmp16 = (U16) GetHiWord(_val);                                        \
    _tmp16 &= 0xff;                                                        \
   }                                                                       \
   else                                                                    \
   {                                                                       \
      _tmp16 = 0;                                                          \
   }                                                                       \
   IT_MMH_PREPK_U16(_tmp16)                                    \
}

/* M3UA protocol message: get U32 value from message */
#define IT_MMH_EXAM_U32(_msg, _val, _idx, _ret)                               \
{                                                                             \
   U16 _tmp16;                                                                \
   _val = 0;                                                                  \
   IT_MMH_EXAM_U16(_msg, _tmp16, _idx, _ret)                                  \
   if ((_ret) == ROK)                                                         \
   {                                                                          \
      _val = PutHiWord(_val, _tmp16);                                         \
      IT_MMH_EXAM_U16(_msg, _tmp16, _idx, _ret)                               \
      _val = PutLoWord(_val, _tmp16);                                         \
   }                                                                          \
}                                                                             
                                                                              
/* M3UA protocol message: pack DPC at end of message */
#define IT_MMH_PK_DPC(_msg, _val, _dpcLen, _ret)                              \
{                                                                             \
   U16 _tmp16;                                                                \
   U8 __tmp8;                                                                 \
   _tmp16 = (U16)(((_dpcLen) == DPC24) ? (U16) GetHiWord(_val) : 0);          \
   __tmp8 = (U8) GetLoByte(_tmp16);                                           \
   IT_MMH_PK_U8(_msg, __tmp8, _ret)                                           \
   if ((_ret) == ROK)                                                         \
   {                                                                          \
      _tmp16 = (U16) GetLoWord(_val);                                         \
      if ((_dpcLen) == DPC14)                                                 \
      {                                                                       \
         _tmp16 &= 0x3fff;                                                    \
      }                                                                       \
      IT_MMH_PK_U16(_msg, _tmp16, _ret)                                       \
   }                                                                          \
}                                                                             
                                                                              
/* M3UA protocol message: get DPC value from message */
#define IT_MMH_EXAM_DPC(_msg, _val, _dpcLen, _idx, _ret)                      \
{                                                                             \
   U16 _tmp16;                                                                \
   U8 __tmp8;                                                                 \
   _val = 0;                                                                  \
   IT_MMH_EXAM_U8(_msg, __tmp8, _idx, _ret)                                   \
   if ((_ret) == ROK)                                                         \
   {                                                                          \
      _tmp16 = 0;                                                             \
      if ((_dpcLen) == DPC24)                                                 \
      {                                                                       \
         _tmp16 = PutLoByte(_tmp16, __tmp8);                                  \
      }                                                                       \
      _val = PutHiWord(_val, _tmp16);                                         \
      IT_MMH_EXAM_U16(_msg, _tmp16, _idx, _ret)                               \
      if ((_dpcLen) == DPC14)                                                 \
      {                                                                       \
         _tmp16 &= 0x3fff;                                                    \
      }                                                                       \
      _val = PutLoWord(_val, _tmp16);                                         \
   }                                                                          \
}                                                                             
                                                                              
/* Convert parameter length to M3UA tag length (includes tag itself) */
#define IT_MMH_LEN_ADJ(_len)              ((_len) + 4)                        
                                                                              
/* Convert M3UA tag length to parameter length */
#define IT_MMH_LEN_UNADJ(_len)            ((_len) - 4)                        
                                                                              
/* Convert DPC CB type to route entry type */
#define IT_DPC2RTTYPE(_dpcType)                                               \
   (U8)(((_dpcType) == IT_DPCCB_SPMC) ? LIT_RTTYPE_PS :                       \
   (((_dpcType) == IT_DPCCB_LOCAL) ? LIT_RTTYPE_LOCAL :                       \
   (((_dpcType) == IT_DPCCB_SS7) ? LIT_RTTYPE_MTP3 :                           \
   LIT_RTTYPE_NOTFOUND)))
                                                                           
/* Convert route entry type to DPC CB type */
#define IT_RTTYPE2DPC(_rtType)                                                \
   (U8)(((_rtType) == LIT_RTTYPE_PS) ? IT_DPCCB_SPMC :                        \
   (((_rtType) == LIT_RTTYPE_LOCAL) ? IT_DPCCB_LOCAL :                        \
   IT_DPCCB_SS7))
/* M3UA statistics: increment MTP3 transmit counter */
#define IT_STS_INC_MTP3_TX(_nSap, _cntr)                                      \
{                                                                             \
   (_nSap)->sntSts.txMtp3Sts._cntr++;                                         \
   itGlobalCb.genSts.txMtp3Sts._cntr++;                                       \
}                                                                             

/* Pack Network Appearance Parameter */
#define IT_MMH_PK_NWK_APP(_mBuf, _nwkAppVal, _ret)                            \
{                                                                             \
   IT_MMH_PK_U16(_mBuf, IT_M3UA_TAG_NWKAPP, _ret)                             \
   IT_MMH_CHKLOG(_mBuf, _ret, EIT001)                                         \
   IT_MMH_PK_U16(_mBuf, IT_MMH_LEN_ADJ(sizeof(U32)), _ret)                    \
   IT_MMH_CHKLOG(_mBuf, _ret, EIT002)                                         \
   IT_MMH_PK_U32(_mBuf, _nwkAppVal, _ret)                                     \
   IT_MMH_CHKLOG(_mBuf, _ret, EIT003)                                         \
}        
/* M3UA statistics: increment MTP3 transmit status counter */
#define IT_STS_INC_MTP3_TX_STA(_nSap, _status)                                \
{                                                                             \
   switch (_status)                                                           \
   {                                                                          \
      case SN_PAUSE:                                                          \
         IT_STS_INC_MTP3_TX(_nSap, pause)                                     \
         break;                                                               \
      case SN_RESUME:                                                         \
         IT_STS_INC_MTP3_TX(_nSap, resume)                                    \
         break;                                                               \
      case SN_CONG:                                                           \
      case SN_STPCONG:                                                        \
         IT_STS_INC_MTP3_TX(_nSap, cong)                                      \
         break;                                                               \
      case SN_RMTUSRUNAV:                                                     \
         IT_STS_INC_MTP3_TX(_nSap, upu)                                       \
         break;                                                               \
      case SN_RSTBEG:                                                         \
         IT_STS_INC_MTP3_TX(_nSap, rstBeg);                                   \
         break;                                                               \
      case SN_RSTEND:                                                         \
         IT_STS_INC_MTP3_TX(_nSap, rstEnd);                                   \
         break;                                                               \
      default:                                                                \
         break;                                                               \
   }                                                                          \
}                                                                             
                                                                              
                                                                              
/* M3UA statistics: increment MTP3 receive counter */
#define IT_STS_INC_MTP3_RX(_nSap, _cntr)                                      \
{                                                                             \
   (_nSap)->sntSts.rxMtp3Sts._cntr++;                                         \
   itGlobalCb.genSts.rxMtp3Sts._cntr++;                                       \
}                                                                             
                                                                              
/* M3UA statistics: increment M3UA transmit counter */
#define IT_STS_INC_M3UA_TX(_assoc, _cntr)                                     \
{                                                                             \
   SuId   sctSuId;\
   sctSuId  = IT_ASSOC2SUID(_assoc->assocId);\
   (_assoc)->owner->pspSts.assocSts[sctSuId].txM3uaSts._cntr++;            \
   itGlobalCb.genSts.txM3uaSts._cntr++;                                       \
}                                                                             
                                                                              
/* M3UA statistics: increment M3UA receive counter */
#define IT_STS_INC_M3UA_RX(_assoc, _cntr)                                     \
{                                                                             \
   SuId   sctSuId;\
   sctSuId  = IT_ASSOC2SUID(_assoc->assocId);\
   (_assoc)->owner->pspSts.assocSts[sctSuId].rxM3uaSts._cntr++;         \
   itGlobalCb.genSts.rxM3uaSts._cntr++;                                       \
}                                                                             
                                                                              
/* M3UA statistics: increment M3UA transmit SSNM counter */
#define IT_STS_INC_M3UA_TX_SSNM(_assoc, _msgType)                             \
{                                                                             \
   switch (_msgType)                                                          \
   {                                                                          \
      case IT_SSNM_DUNA:                                                      \
         IT_STS_INC_M3UA_TX(_assoc, duna);                                    \
         break;                                                               \
      case IT_SSNM_DAVA:                                                      \
         IT_STS_INC_M3UA_TX(_assoc, dava);                                    \
         break;                                                               \
      case IT_SSNM_DRST:                                                      \
         IT_STS_INC_M3UA_TX(_assoc, drst);                                    \
         break;                                                               \
      case IT_SSNM_DAUD:                                                      \
         IT_STS_INC_M3UA_TX(_assoc, daud);                                    \
         break;                                                               \
      case IT_SSNM_SCON:                                                      \
         IT_STS_INC_M3UA_TX(_assoc, scon);                                    \
         break;                                                               \
      case IT_SSNM_DUPU:                                                      \
         IT_STS_INC_M3UA_TX(_assoc, dupu);                                    \
         break;                                                               \
      default:                                                                \
         break;                                                               \
   }                                                                          \
}                                                                             
                                                                              
/* M3UA statistics: increment M3UA receive SSNM counter */
#define IT_STS_INC_M3UA_RX_SSNM(_assoc, _msgType)                             \
{                                                                             \
   switch (_msgType)                                                          \
   {                                                                          \
      case IT_SSNM_DUNA:                                                      \
         IT_STS_INC_M3UA_RX(_assoc, duna);                                    \
         break;                                                               \
      case IT_SSNM_DAVA:                                                      \
         IT_STS_INC_M3UA_RX(_assoc, dava);                                    \
         break;                                                               \
      case IT_SSNM_DRST:                                                      \
         IT_STS_INC_M3UA_RX(_assoc, drst);                                    \
         break;                                                               \
      case IT_SSNM_DAUD:                                                      \
         IT_STS_INC_M3UA_RX(_assoc, daud);                                    \
         break;                                                               \
      case IT_SSNM_SCON:                                                      \
         IT_STS_INC_M3UA_RX(_assoc, scon);                                    \
         break;                                                               \
      case IT_SSNM_DUPU:                                                      \
         IT_STS_INC_M3UA_RX(_assoc, dupu);                                    \
         break;                                                               \
      default:                                                                \
         break;                                                               \
   }                                                                          \
}                                                                             
                                                                              
/* M3UA statistics: increment SNT transmit counter */
#define IT_STS_INC_DATA_TX_SNT(_nSap, _mBuf)                                  \
{                                                                             \
   MsgLen _len;                                                               \
   SFndLenMsg(_mBuf, &_len);                                                  \
   (_nSap)->sntSts.txDataSts.nPdus++;                                         \
   (_nSap)->sntSts.txDataSts.pduBytes += _len;                                \
   itGlobalCb.genSts.uiTxDataSts.nPdus++;                                     \
   itGlobalCb.genSts.uiTxDataSts.pduBytes += _len;                            \
}                                                                             
                                                                              
/* M3UA statistics: increment SNT receive counter */
#define IT_STS_INC_DATA_RX_SNT(_nSap, _mBuf)                                  \
{                                                                             \
   MsgLen _len;                                                               \
   SFndLenMsg(_mBuf, &_len);                                                  \
   (_nSap)->sntSts.rxDataSts.nPdus++;                                         \
   (_nSap)->sntSts.rxDataSts.pduBytes += _len;                                \
   itGlobalCb.genSts.uiRxDataSts.nPdus++;                                     \
   itGlobalCb.genSts.uiRxDataSts.pduBytes += _len;                            \
}                                                                             
                                                                              
/* M3UA statistics: increment SCT transmit counter */
#define IT_STS_INC_DATA_TX_SCT(_assoc, _mBuf)                                 \
{                                                                             \
   MsgLen _len;                                                               \
   SuId   sctSuId;\
   sctSuId  = IT_ASSOC2SUID(_assoc->assocId);\
   SFndLenMsg(_mBuf, &_len);                                                  \
   (_assoc)->owner->pspSts.assocSts[sctSuId].txDataSts.nPdus++;   \
   (_assoc)->owner->pspSts.assocSts[sctSuId].txDataSts.pduBytes += _len; \
   _assoc->sctSap->sctSts.txDataSts.nPdus++;                                  \
   _assoc->sctSap->sctSts.txDataSts.pduBytes += _len;                         \
   itGlobalCb.genSts.liTxDataSts.nPdus++;                                     \
   itGlobalCb.genSts.liTxDataSts.pduBytes += _len;                            \
}                                                                             
                                                                              
/* M3UA statistics: increment SCT receive counter */
#define IT_STS_INC_DATA_RX_SCT(_assoc, _mBuf)                                 \
{                                                                             \
   MsgLen _len;                                                               \
   SuId   sctSuId;\
   sctSuId  = IT_ASSOC2SUID(_assoc->assocId);\
   SFndLenMsg(_mBuf, &_len);                                                  \
   (_assoc)->owner->pspSts.assocSts[sctSuId].rxDataSts.nPdus++;      \
   (_assoc)->owner->pspSts.assocSts[sctSuId].rxDataSts.pduBytes += _len;\
   (_assoc)->sctSap->sctSts.rxDataSts.nPdus++;                                \
   (_assoc)->sctSap->sctSts.rxDataSts.pduBytes += _len;                       \
   itGlobalCb.genSts.liRxDataSts.nPdus++;                                     \
   itGlobalCb.genSts.liRxDataSts.pduBytes += _len;                            \
}

/* it016.106 - Added new macros for updating the association unavailability 
 * and congestion statistics. */
#ifdef LITV3
/* Association statistics: increment unav counter */
#define IT_STS_INC_ASSOC_UNAV(_assoc)                                         \
{                                                                             \
   SuId   sctSuId;                                                            \
   sctSuId  = IT_ASSOC2SUID(_assoc->assocId);                                 \
   (_assoc)->owner->pspSts.assocSts[sctSuId].unavSts.unav++;                  \
}

/* Association statistics: increment cong counter */
#define IT_STS_INC_ASSOC_CONG(_assoc, _congLevel)                             \
{                                                                             \
   SuId   sctSuId;                                                            \
   sctSuId  = IT_ASSOC2SUID(_assoc->assocId);                                 \
   switch (_congLevel)                                                        \
   {                                                                          \
      case SN_PRI0:                                                           \
         (_assoc)->owner->pspSts.assocSts[sctSuId].congSts.cong++;            \
         break;                                                               \
      case SN_PRI1:                                                           \
         (_assoc)->owner->pspSts.assocSts[sctSuId].congSts.cong1++;           \
         break;                                                               \
      case SN_PRI2:                                                           \
         (_assoc)->owner->pspSts.assocSts[sctSuId].congSts.cong2++;           \
         break;                                                               \
      case SN_PRI3:                                                           \
         (_assoc)->owner->pspSts.assocSts[sctSuId].congSts.cong3++;           \
         break;                                                               \
      default:                                                                \
         break;                                                               \
   }                                                                          \
}

/* Association statistics: update durCong */
#define IT_STS_UPD_ASSOC_DUR_CONG(_assoc, _dur)                                  \
{                                                                             \
   SuId   sctSuId;                                                            \
   sctSuId  = IT_ASSOC2SUID(_assoc->assocId);                                 \
   (_assoc)->owner->pspSts.assocSts[sctSuId].congSts.durCong += _dur;                 \
}

/* Association statistics: update durUnav */
#define IT_STS_UPD_ASSOC_DUR_UNAV(_assoc, _dur)                                  \
{                                                                             \
   SuId   sctSuId;                                                            \
   sctSuId  = IT_ASSOC2SUID(_assoc->assocId);                                 \
   (_assoc)->owner->pspSts.assocSts[sctSuId].unavSts.durUnav += _dur;                 \
}
#endif /* LITV3 */

/* it023.106 - Added new macros for updating PS based sts. */
#ifdef LITV6
/* PS statistics: update DATA or SSNM rx sts. */
#define IT_STS_INC_RX_PS(_ps, _msgType)                                  \
{                                                                             \
   switch (_msgType)                                                          \
   {                                                                          \
      case IT_M3UA_DATA:                                                      \
         (_ps)->psSts.rxM3uaSts.data++;                                         \
         break;                                                               \
      case IT_SSNM_DUNA:                                                      \
         (_ps)->psSts.rxM3uaSts.duna++;                                         \
         break;                                                               \
      case IT_SSNM_DAVA:                                                      \
         (_ps)->psSts.rxM3uaSts.dava++;                                         \
         break;                                                               \
      case IT_SSNM_DRST:                                                      \
         (_ps)->psSts.rxM3uaSts.drst++;                                         \
         break;                                                               \
      case IT_SSNM_DAUD:                                                      \
         (_ps)->psSts.rxM3uaSts.daud++;                                         \
         break;                                                               \
      case IT_SSNM_SCON:                                                      \
         (_ps)->psSts.rxM3uaSts.scon++;                                         \
         break;                                                               \
      case IT_SSNM_DUPU:                                                      \
         (_ps)->psSts.rxM3uaSts.dupu++;                                         \
         break;                                                               \
      default:                                                                \
         break;                                                               \
   }                                                                          \
}

/* PS statistics: update DATA tx sts. */
#define IT_STS_INC_TX_PS(_ps, _msgType)                                  \
{                                                                             \
   switch (_msgType)                                                          \
   {                                                                          \
      case IT_M3UA_DATA:                                                      \
         (_ps)->psSts.txM3uaSts.data++;                                         \
         break;                                                               \
      default:                                                                \
         break;                                                               \
   }                                                                          \
}

/* PS statistics: increment unav counter */
#define IT_STS_INC_PS_UNAV(_ps)                                         \
{                                                                             \
   (_ps)->psSts.unavSts.unav++;                                               \
}

/* PS statistics: update durUnav */
#define IT_STS_UPD_PS_DUR_UNAV(_ps, _dur)                                  \
{                                                                             \
   (_ps)->psSts.unavSts.durUnav += _dur;                                      \
}
#endif /* LITV6 */

/* M3UA RX Trace Mask */
#define IT_MSGT2TRCEVNT(_msgType)                                          \
   (U8) (((_msgType) == IT_MSGCLASS_MGMT) ? LIT_MGMT_RX:                   \
   (((_msgType) == IT_MSGCLASS_M3UA_XFER) ? LIT_DATA_RX:              \
   (((_msgType) == IT_MSGCLASS_SSNM) ? LIT_SSNM_RX:                        \
   (((_msgType) == IT_MSGCLASS_ASPSM) ? LIT_ASPSM_RX:                      \
   (((_msgType) == IT_MSGCLASS_ASPTM) ? LIT_ASPTM_RX:                      \
   LIT_RKM_RX)))))                                                         

/* M3UA TX Trace Mask */
#define IT_MSGT2TXRCEVNT(_msgType)                                          \
   (U8) (((_msgType) == IT_MSGCLASS_MGMT) ? LIT_MGMT_TX:                   \
   (((_msgType) == IT_MSGCLASS_M3UA_XFER) ? LIT_DATA_TX:              \
   (((_msgType) == IT_MSGCLASS_SSNM) ? LIT_SSNM_TX:                        \
   (((_msgType) == IT_MSGCLASS_ASPSM) ? LIT_ASPSM_TX:                      \
   (((_msgType) == IT_MSGCLASS_ASPTM) ? LIT_ASPTM_TX:                      \
   LIT_RKM_TX)))))                                                         

#define IT_PK_PAD32(_nmbEnt, _mBuf)                                            \
{                                                                           \
   U8  cur; /* index */                                                           \
   for (cur = 0;                                                            \
           cur < ((sizeof(U32) - (_nmbEnt % sizeof(U32))) % sizeof(U32));  \
           cur++)                                                          \
   {                                                                           \
      IT_MMH_PK_U8(_mBuf, 0, ret);                                           \
      IT_MMH_CHKLOG(_mBuf, ret, EIT004)                                           \
   }                                                                           \
}                                                                         

/* Macro to Memset rtFilter and assign the values which will remain
 * unchanged for a given Routing Key (RK) */
#define IT_SET_FIXED_RK_PRMTR(_routeCb, _nwkId, _dpc, _dpcMask )                     \
{                                                                                                                        \
   cmMemset((U8 *)&(_routeCb->rtFilter), 0, sizeof(ItRtFilter));         \
   _routeCb->rteCfg.nwkId = _nwkId;                                        \
   _routeCb->rteCfg.rtFilter.dpc = _dpc;                                   \
   _routeCb->rteCfg.rtFilter.dpcMask = 0xffffffff;                           \
}                                                                         

/* Macro to set tag values */
#define IT_MMH_SET_TAGS(_tag)                                             \
{                                                                                                                        \
   _tag[IT_M3UA_TAG_IDX_NWKAPP].tag    =  IT_M3UA_TAG_NWKAPP;              \
   _tag[IT_M3UA_TAG_IDX_DATA].tag      =  IT_M3UA_TAG_DATA;               \
   _tag[IT_M3UA_TAG_IDX_INFO].tag      =  IT_M3UA_TAG_INFO;                \
   _tag[IT_M3UA_TAG_IDX_ADPC].tag      =  IT_M3UA_TAG_ADPC;                \
   _tag[IT_M3UA_TAG_IDX_RCTX].tag      =  IT_M3UA_TAG_RCTX;                \
   _tag[IT_M3UA_TAG_IDX_DIAG].tag      =  IT_M3UA_TAG_DIAG;                 \
   _tag[IT_M3UA_TAG_IDX_HBEATDATA].tag =  IT_M3UA_TAG_HBEATDATA;           \
   _tag[IT_M3UA_TAG_IDX_CAUSEUSER].tag =  IT_M3UA_TAG_CAUSEUSER;           \
   _tag[IT_M3UA_TAG_IDX_TRAFMODE].tag  =  IT_M3UA_TAG_TRAFMODE;         \
   _tag[IT_M3UA_TAG_IDX_ERRCODE].tag   =  IT_M3UA_TAG_ERRCODE;           \
   _tag[IT_M3UA_TAG_IDX_STATUS].tag    =  IT_M3UA_TAG_STATUS;          \
   _tag[IT_M3UA_TAG_IDX_CONGLEVEL].tag  =  IT_M3UA_TAG_CONGLEVEL;          \
   _tag[IT_M3UA_TAG_IDX_CNCRNDPC].tag  =  IT_M3UA_TAG_CNCRNDPC;          \
   _tag[IT_M3UA_TAG_IDX_RK].tag        =  IT_M3UA_TAG_RK;              \
   _tag[IT_M3UA_TAG_IDX_REGRSLT].tag   =  IT_M3UA_TAG_REGRSLT;         \
   _tag[IT_M3UA_TAG_IDX_DREGRSLT].tag  =  IT_M3UA_TAG_DREGRSLT;         \
   _tag[IT_M3UA_TAG_IDX_LCLRKID].tag   =  IT_M3UA_TAG_LCLRKID;         \
   _tag[IT_M3UA_TAG_IDX_DPC].tag       =  IT_M3UA_TAG_DPC;           \
   _tag[IT_M3UA_TAG_IDX_SI].tag        =  IT_M3UA_TAG_SI;            \
   _tag[IT_M3UA_TAG_IDX_OPC].tag       =  IT_M3UA_TAG_OPC;            \
   _tag[IT_M3UA_TAG_IDX_CICRNG].tag    =  IT_M3UA_TAG_CICRNG;          \
   _tag[IT_M3UA_TAG_IDX_REGSTA].tag    =  IT_M3UA_TAG_REGSTA;          \
   _tag[IT_M3UA_TAG_IDX_DREGSTA].tag   =  IT_M3UA_TAG_DREGSTA;         \
   _tag[IT_M3UA_TAG_IDX_CORELTN_ID].tag = IT_M3UA_TAG_CORELTN_ID;         \
   _tag[IT_M3UA_TAG_IDX_ASPID].tag     =  IT_M3UA_TAG_ASPID;         \
}

/* Macro for getting Remote PS list from a PSP */
#define IT_GET_RPS_FRM_PSP(_assocCb, _rCtx, _rCtxLen)                \
{                                                                  \
   U16  indx;   /* index */                                         \
                                                                   \
   cmMemset((U8 *)_rCtx, 0, sizeof(ItRtCtx) * LIT_MAX_PSID);       \
   _rCtxLen = 0;                                                   \
   for (indx = 0; indx < _assocCb->nmbPs; indx++)                    \
   {                                                               \
      if (_assocCb->ps[indx]->psCfg.lclFlag != TRUE)                 \
      {                                                            \
         _rCtx[_rCtxLen].rtCtx     = _assocCb->ps[indx]->psCfg.psId; \
         _rCtx[_rCtxLen].ntfySend  = FALSE;                        \
         _rCtx[_rCtxLen].ntfyStaId = 0;                            \
         _rCtxLen++;                                               \
      }                                                            \
   }                                                               \
}

/* Macro for calculating total number of SLS contexts for a PS */
#define IT_LSC_NUMB_SLS_CTX(_psCb,_maxSls)                      \
{                                                               \
   switch (_psCb->nwk->nwkCfg.slsLen)                           \
   {                                                            \
      case LIT_SLS4:                                            \
         _maxSls = IT_MAX_SLS4;                                 \
         break;                                                 \
      case LIT_SLS5:                                            \
         _maxSls = IT_MAX_SLS5;                                 \
         break;                                                 \
      case LIT_SLS8:                                            \
         _maxSls = IT_MAX_SLS8;                                 \
         break;                                                 \
   }                                                            \
   /* Total number of SLS */                                    \
   _maxSls++;                                                   \
}                                              

#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
/* Macro for verifying RC is active or not in DPC or global list's RCB */
#define IT_SEARCH_RCB_NSAP(_list, _nrCtx, _nrCtxLen, _rcOkCount)   \
{                                                               \
     ItRouteCb *curRouteCb;                                      \
     ItRtCtx    rCtxTmp1;\
     U16       k;      \
                \
     curRouteCb = (ItRouteCb *)NULLP; \
 \
      for (curRouteCb = (ItRouteCb *)cmLListFirst(_list); \
           curRouteCb;\
           curRouteCb = (ItRouteCb *)cmLListNext(_list)) \
      {\
         if (curRouteCb->owner != NULLP)\
         {\
             /* Check whether this route is also based on SAP and \
                sap's state is Bound? */\
             if (((curRouteCb->rteCfg.nSapIdPres == TRUE)\
              && ((itGlobalCb.nSap[curRouteCb->rteCfg.nSapId]->sntSta.hlSt\
                                                      == LIT_SAP_BOUND))))\
             {\
                /* match the owner id with any of the RC sent in ASPM msg */\
                for (k = _rcOkCount; k < _nrCtxLen; k++)\
                {\
                   if (curRouteCb->rteCfg.psId == nrCtx[k].rtCtx)\
                   {\
                      /* Swap the matched RC with orig list */\
                      rCtxTmp1 = nrCtx[_rcOkCount];\
                      nrCtx[_rcOkCount++] = nrCtx[k];\
                      nrCtx[k] = rCtxTmp1;\
                      break;\
                   }\
                } /* End of forloop on nrCtxLen */\
             } /* End of nSapIdPres == TRUE && sntSta.hlSt == LIT_SAP_BOUND*/\
         } /* End of curRouteCb->owner == NULLP */\
      } /* End of for on RCBs*/\
} /* End of IT_SEARCH_RCB_NSAP */
#endif /* end of ITASP and OG_RTE_ON_LPS_STA */

#define IT_CMP_IPV6_ADDR(_addr1, _addr2, _ret)    \
{                                                                       \
   U16 _i;                                                              \
   (_ret) = TRUE;                                                      \
   for (_i = 0; _i < CM_IPV6ADDR_SIZE; _i++)                             \
   {                                                                    \
      if ((_addr1)[_i] != (_addr2[_i]))           \
      {                                                                 \
         (_ret) = FALSE;                                               \
         break;                                                         \
      }                                                                 \
   }                                                                    \
}
/* Begin DFTHA-hooks changes */
/* Following macro SHOULD be called at the beginning of every incoming primitive */
#ifdef ZV
#define ITADDZVUPDPEERCTR() zvCb.zvUpdPeerCtr++;
#else
#define ITADDZVUPDPEERCTR()
#endif

/* Following macro SHOULD be called at every exit point from a primitive */
#ifdef ZV
#define ITZVUPDPEER() { \
   zvUpdPeer(); \
   zvCb.zvUpdPeerCtr--; \
}
#else
#define ITZVUPDPEER()
#endif

#ifdef ZV 
#define ITCHKPROTSTATE(errCode, element, id, ret, evnt)  {\
   ret = ROK; \
   /* non critical are accepted at active & Standby too in case of DFTHA */ \
   if ((evnt == IT_EVENT_NON_CRIT) && \
      (!((itProtState == CMPFTHA_STATE_ACTIVE)  || \
       ((zvCb.genCfg.distEnv) && (itProtState == CMPFTHA_STATE_STANDBY))))) \
   { \
      ITLOGERROR(ERRCLS_DEBUG, errCode, (ErrVal) itProtState, \
                 "non critical event received on standby"); \
      /* inform layer manager */ \
      itMiStaInd(element, LCM_CATEGORY_INTERFACE, LCM_EVENT_INV_EVT,\
                                  LCM_CAUSE_PROT_NOT_ACTIVE, (U32)id); \
      ret = RFAILED; \
   } \
   /* Critical events are accepted only at Active copy */ \
   if ((evnt == IT_EVENT_CRIT) && (itProtState != CMPFTHA_STATE_ACTIVE)) \
   { \
      ITLOGERROR(ERRCLS_DEBUG, errCode, (ErrVal) itProtState, \
                 "critical event received on standby"); \
      /* inform layer manager */ \
      itMiStaInd(element, LCM_CATEGORY_INTERFACE, LCM_EVENT_INV_EVT,\
                                  LCM_CAUSE_PROT_NOT_ACTIVE, (U32)id); \
      ret = RFAILED; \
   } \
}
#else
#define ITCHKPROTSTATE(errCode, element, id, ret, evnt)   {\
   ret = ROK; \
}
#endif

/* End of DFTHA-hooks changes */


#endif /* __ITH__ */


/********************************************************************30**

         End of file:     it.h@@/main/8 - Thu Apr  1 03:50:48 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision History:

*********************************************************************61*/
/********************************************************************70**

  version    initials                   description
-----------  ---------  ------------------------------------------------

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/4      ---     pn   1. backbone draft.
/main/4      ---      mrw  1. Update to Release 1.2
/main/5      ---      sg   1. Routing and IPSP changes,SLS hash defines
             ---      sg   2. Update to Release 1.3.
/main/6      ---      sg   1. Update to Relese 1.4
/main/6    it001.104  sg   1. Added new hash define for DPC Mask and 
                              Invalid PS Id.
/main/6    it021.104  nt   1. Added new Macro for verifying RC is 
                              active or not in DPC or global list's RCB
/main/6    it023.104  vt   1. changes for double deallocation issues
/main/7      ---      nt   1. Update to Release 1.5
/main/8      ---      rs   1. Update to Release 1.6.
/main/8    it012.106  jc   1. Added suppport for SS_MULTIPLE_PROCS
/main/8    it013.106  sg   1. Added SI_MGCP to support MGCP as M3UA user.
/main/8    it015.106  sg   1. Used sctSuId instead of assocId for updating 
                              the statistics.
/main/8    it016.106  sg   1. Added new macros for updating association 
                              unavailability and congestion statistics. 
/main/8    it017.106  sg   1. Removed the definition of MAXSI as it is not 
                              being used.
/main/8    it023.106  sg   1. Added macros for updating PS statistics under
                              compilation flag LITV6.
*********************************************************************91*/
