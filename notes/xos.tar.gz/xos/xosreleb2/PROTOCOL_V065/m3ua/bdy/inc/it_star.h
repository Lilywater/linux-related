/*************************************************
  Copyright (C), 1995-2006, XinWei Tech. Co., Ltd.
  
  File name:    it_star.h
  
  Subsystem   : sm
  
  Description: ����M3UAЭ���SCTPż���ͷ���ҵ��
  
  Others:         

  History: 
  Programmer  Date         Rev    Description
  --------------- ---------- -------- ------------------------------
  chenning   6/26/2006    1.0        created 
*************************************************/ 

#ifndef _IT_STAR_H_
#define _IT_STAR_H_


#ifdef __cplusplus
extern "C" {
#endif
/*--------------------------------------------------------*/

/*--------------------------------------------------------*/
/* Macro for the current M3UA status on ASP side */
#define IT_ASP_INITIALIZATION	0
#define IT_ASP_ACTIVE_SIDE		1
#define IT_ASP_STANDBY_SIDE	2

/*chenning ���Ӳ�Ʒ��������M3UA��ʼ��ʱ����������2006 9 18*/
#if (defined(CP_UA_IF_TYPE_SS) )
#define IT_AUTO_CLIENTSIDE 1
#else
#define IT_AUTO_CLIENTSIDE 0
#endif

#if (defined(CP_UA_IF_TYPE_HLR) )
#define IT_AUTO_SERVERSIDE 1
#else
#define IT_AUTO_SERVERSIDE 0
#endif


#ifdef ITASP
EXTERN VOID itSgReconnect(ItPspId pspId);
EXTERN VOID itAspReconnectTimeout(ItPspCb * pspCb);
EXTERN S16 StartWork(S16 suId);
EXTERN VOID itTerminateAssoc(ItAssocCb   *assocCb);
#endif

#ifdef __cplusplus
}
#endif

#endif

