/**************************************************

**************************************************/
#ifndef _IT_INIT_H_
#define _IT_INIT_H_

/* defines for configuration */
#ifndef ITINITINST_0
#define ITINITINST_0    0         /* instance */
#endif

#ifndef ITINITINST_1
#define ITINITINST_1    1         /* instance for fault tolerance */
#endif

EXTERN PUBLIC S16 itTst ARGS((Void));
EXTERN PUBLIC S16 it_init_fun ARGS((SSTskId tskId));

#endif /* _IT_INIT_H_ */
