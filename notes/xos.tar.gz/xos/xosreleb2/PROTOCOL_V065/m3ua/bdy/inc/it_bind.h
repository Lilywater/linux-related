
#ifndef __IT_BINDH__
#define __IT_BINDH__
PUBLIC Void ItBindSctSap(SuId suId,SpId spId);
PUBLIC Void ItBindNSap(SuId suId,SpId spId);
PUBLIC S16 ItLSapBindSb(SuId suId);
PUBLIC Void ItSetupAssReq(UConnId       assocId);
PUBLIC Void ItOpenEndpReq(void);

 
#endif  /*__IT_BINDH__*/