/*************************************************
  Copyright (C), 1995-2006, XinWei Tech. Co., Ltd.
  
  File name:    it_adtr.h
  
  Subsystem   : it
  
  Description: ����ISUP����ʱ��M3UAֱ��ͨ��XOS�������ݸ�ATT
  
  Others:         

  History: 
  Programmer  Date         Rev    Description
  --------------- ---------- -------- ------------------------------
  chenning   7/13/2006    1.0        created 
*************************************************/ 

#ifndef __IT_ADTR_H__
#define __IT_ADTR_H__

#ifdef __cplusplus
extern "C" {
#endif
/********************* macro *******************************/


/********************  enum ********************************/


/********************* struct *******************************/
#ifdef LCITUISNT_XOS
typedef struct m3ua2ATT_tag
{
t_XOSCOMMHEAD XosHdr;
Dpc opc;
Dpc dpc;
U8  buf[1];
}ItATTTest;
#endif
/********************** extern *******************************/

#ifdef LCITUISNT_XOS
EXTERN S16 ItPkSntUDatInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* Service User Id */
Dpc cgAdr,                  /* Calling Address */
Dpc cdAdr,                  /* Called Address */
SrvInfo srvInfo,            /* Service Information Octet */
LnkSel lnkSel,              /* signalling Link Selection */
Buffer *mBuf                /* Pointer to the Buffer */
);
#endif

#ifdef __cplusplus
}
#endif

#endif

